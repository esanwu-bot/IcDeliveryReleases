# -*- coding: utf-8 -*-
"""安全访问器：跨模块共用的嵌套容器降级（2026-11-02）。

**为什么独立成模块**：`parse_datasheets` / `qc/deterministic_extract` / `qc/source_url`
都要读同一批容器（`specs.electrical` / `absolute_max` / `onboard_device_specs.*` …）。
各写一份 helper 早晚会漂移；让它们互相 import 又会造成循环依赖
（`parse_datasheets` 已经在函数内延迟 import `deterministic_extract`）。
放这里，三处单向 import。

**语义**（与 `parse_datasheets.sanitize_doc` 的分工）：
* `sanitize_doc` 负责**写回清洗**（把脏容器归一）；
* 这里只负责**读取时不崩**：读不到就返回空容器。
两者的口径必须一致：非 dict 的 `specs` → `{}`；非 list 的 `electrical` → `[]`。

真实事故（20 件压测 4 件）：模型把 `specs.onboard_device_specs` 写成 `null`/字符串，
`specs.get("onboard_device_specs", {}).get("electrical", [])` 直接抛
`AttributeError: 'str' object has no attribute 'get'`。
"""
from __future__ import annotations


def safe_dict(d: object, key: str) -> dict:
    """安全取子对象：`d` 不是 dict、或 `d[key]` 不是 dict → 返回 `{}`。"""
    if not isinstance(d, dict):
        return {}
    val = d.get(key)
    return val if isinstance(val, dict) else {}


def safe_list(d: object, key: str) -> list:
    """安全取数组：`d` 不是 dict、或 `d[key]` 不是 list → 返回 `[]`。

    只保证"能遍历"，**不**过滤元素类型 —— 元素级的 `isinstance(x, dict)` 仍由调用方
    按各自语义处理（有些容器允许字符串，例如 `features`）。
    """
    if not isinstance(d, dict):
        return []
    val = d.get(key)
    return val if isinstance(val, list) else []


def dict_rows(d: object, key: str) -> list:
    """安全取"只装对象"的数组：非 list → `[]`；非 dict 元素一律剔除。

    这是 `specs.electrical` / `absolute_max` / 隔离桶里的同类容器的标准读法。
    """
    return [e for e in safe_list(d, key) if isinstance(e, dict)]
