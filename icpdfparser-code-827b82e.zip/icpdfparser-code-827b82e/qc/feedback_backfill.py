#!/usr/bin/env python3
"""客户反馈 V2 回溯：把首批 11 个客户反馈与证据 / 回归 / 修复关联起来。

只做五件事（全部只追加，不改 facts / Gold / item / 既有 QC 结论）：
  1. metadata    : 用 V2 seed CSV 写入根因假设、所需证据、验收标准，并更正反馈来源；
  2. fix         : 为 BUF634PG4 登记 r4 修复记录；
  3. regression  : 导入 r5 `qc_regression --post` 真实结果，更新样本回归状态；
  4. evidence    : 把已人工核验的原厂字段证据（source_field_evidence）挂到反馈问题；
  5. transition  : 把 BUF634PG4 推进到 REGRESSION_PASSED（仍等待人工验收）。

默认 dry-run；加 --apply 才写库。所有写操作都会进入 customer_feedback_audit_log。
不自动验收、不关闭任何问题；P0 不被 seed 的 P1 覆盖。
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import feedback as FB                      # noqa: E402

ACTOR = "system:feedback-backfill"
HUMAN = "user:admin"
CUSTOMER_REF = "CUSTOMER-SPOTCHECK-2026-10-26 (IMG-01)"
SOURCE_NOTE = ("反馈来源：2026-10-26（周一）客户对未走 QC 流程的初始交付包抽查；"
               "批次为后续 QC 定位批次，不是反馈产生时的 QC 结论。")
R5_REPORT = "data/qc/post-r4/regression-20261028-075128.json"
R5_KEY = "r5-post-20261028-075128"
R5_SCOPE = ("r5 `qc_regression --post` 定向回归（11 件 fixture，r4 facts 修补后；"
            "报告 regression-20261028-075128.json）")

# 只挂“字段证据已人工核验”的原厂证据；未核验的 ready 行不冒充证据。
EVIDENCE_FIELDS = {
    "BUF634PG4": ["basic_info.mpn", "specs.package.type", "specs.package.pins"],
    "CD74FCT244SM96": ["basic_info.mpn", "specs.package.type",
                       "pin[11].name", "pin[19].name"],
    "DAC8555IPWG4": ["basic_info.mpn", "electrical[34].value",
                     "electrical[35].value"],
}

# 只有证据卡身份备注里已写明的修订号才回填，不猜版本。
REVISIONS = {
    "CD74FCT244SM96": "SCBS722B (2003-08)",
    "DAC8555IPWG4": "SLAS475B (2006-10)",
}

# BUF634PG4 r4 facts 修补（见 HANDOFF 2026-10-28 r4 节）
BUF_FIX = {
    "issue_key": "CF-QC28-007",
    "release_version": "r4-20261028",
    "summary": ("按冻结 Gold（SBOS030B Rev B p20 订购行 PDIP/P/8）修正 "
                "BUF634PG4 封装 SOIC-8→PDIP-8，并同步 ordering/description/"
                "features/seo/多语言/派生 txt·symbol·alts，共 13 处"),
    "changed_paths": [
        "specs.package.type", "specs.package.dimensions",
        "ordering_info[BUF634PG4].package", "features[7]",
        "basic_info.description", "seo.keywords",
        "multi_language.ja/ko/de/es.description",
        "multi_language.ja/ko/de/es.features[7]", "metadata.r4_patch",
        "data/txt/BUF634PG4.{txt,ja,ko,de,es}.txt",
        "data/seo/BUF634PG4.json", "data/symbols/BUF634PG4.html",
        "data/alts/BUF634PG4.{json,html}",
    ],
}

BUF_TRANSITIONS = (
    ("IN_PROGRESS", "r4 已按冻结 Gold 修正 BUF634PG4 封装与衍生件，进入回归准备"),
    ("READY_FOR_REGRESSION", "r5 --post 报告 regression-20261028-075128.json 已生成"),
    ("REGRESSION_PASSED",
     "BUF634PG4 fixture PASS（package_contains PDIP）；等待人工验收，不自动关闭"),
)


def log(action, **kw):
    print(json.dumps({"action": action, **kw}, ensure_ascii=False))


def issues_by_mpn(db):
    rows = db.q(
        "SELECT i.*, s.mpn sample_mpn, s.id sample_link_id, s.parser_version, "
        "s.rule_version, s.field_path sample_field_path, "
        "s.expected_value sample_expected, s.actual_value sample_actual, "
        "s.source_revision sample_revision "
        "FROM customer_feedback_issue i "
        "JOIN customer_feedback_sample s ON s.issue_id=i.id ORDER BY s.id")
    out = {}
    for r in rows:
        out.setdefault(r["sample_mpn"], r)
    return out


def seed_metadata(db, path, apply):
    rows = list(csv.DictReader(Path(path).open(encoding="utf-8-sig")))
    idx = issues_by_mpn(db)
    changed = skipped = missing = 0
    for row in rows:
        mpn = (row.get("mpn") or "").strip()
        issue = idx.get(mpn)
        if not issue:
            missing += 1
            log("metadata_missing", mpn=mpn)
            continue
        payload = {}
        for src, dst in (("initial_root_cause_hypothesis", "root_cause_hypothesis"),
                         ("required_evidence", "required_evidence"),
                         ("acceptance_criteria", "acceptance_criteria")):
            val = (row.get(src) or "").strip()
            if val and (issue.get(dst) or "") != val:
                payload[dst] = val
        steps = issue.get("reproduction_steps") or ""
        if SOURCE_NOTE not in steps:
            payload["reproduction_steps"] = (steps + "\n" if steps else "") + SOURCE_NOTE
        if issue.get("source") != "CUSTOMER" or \
                issue.get("customer_reference") != CUSTOMER_REF:
            if apply:
                db.x("UPDATE customer_feedback_issue SET source=?,customer_reference=?,"
                     "updated_at=?,version=version+1 WHERE issue_key=?",
                     ("CUSTOMER", CUSTOMER_REF, FB.now(), issue["issue_key"]))
                FB._audit(db, issue["id"], ACTOR, "source_corrected",
                          issue["status"], issue["status"], {
                              "reason": "客户 2026-10-26（周一）对初始交付包抽查反馈",
                              "old_source": issue.get("source"),
                              "new_source": "CUSTOMER",
                              "old_customer_reference": issue.get("customer_reference"),
                              "new_customer_reference": CUSTOMER_REF,
                          })
            log("source_correct", issue=issue["issue_key"], mpn=mpn)
        sample_payload = {}
        if not (issue.get("sample_revision") or "") and mpn in REVISIONS:
            sample_payload["source_revision"] = REVISIONS[mpn]
        for src, dst, cur in (
                ("expected_behavior", "expected_value", "sample_expected"),
                ("actual_behavior", "actual_value", "sample_actual")):
            val = (issue.get(src) or "").strip()
            if val and not (issue.get(cur) or "").strip():
                sample_payload[dst] = val
        if sample_payload:
            log("sample_metadata", issue=issue["issue_key"], mpn=mpn,
                fields=sorted(sample_payload), applied=bool(apply))
            if apply:
                FB.update_sample(db, issue["sample_link_id"], sample_payload, ACTOR)
        if not payload:
            skipped += 1
            continue
        changed += 1
        log("metadata", issue=issue["issue_key"], mpn=mpn,
            fields=sorted(payload), applied=bool(apply))
        if apply:
            FB.update_issue(db, issue["issue_key"], payload, ACTOR)
    return {"seed_rows": len(rows), "changed": changed, "skipped": skipped,
            "missing": missing}


def import_regression(db, report_path, apply):
    rep = json.loads(Path(report_path).read_text(encoding="utf-8"))
    idx = issues_by_mpn(db)
    added = skipped = missing = 0
    for row in rep.get("rows") or []:
        mpn, result = row[0], row[1]
        issue = idx.get(mpn)
        if not issue:
            missing += 1
            log("regression_missing_issue", mpn=mpn, result=result)
            continue
        run_key = "%s:%s" % (R5_KEY, issue["issue_key"])
        if db.q1("SELECT 1 FROM customer_feedback_regression WHERE run_key=?",
                 (run_key,)):
            skipped += 1
            continue
        if result not in ("PASS", "FAIL"):
            log("regression_skip_result", mpn=mpn, result=result)
            skipped += 1
            continue
        failed_asserts = row[-1] if row[-1] not in ("-", "", None) else ""
        summary = ("asserts failed: " + failed_asserts)[:500] if result == "FAIL" else ""
        fix_id = 0
        if apply and issue["issue_key"] == BUF_FIX["issue_key"]:
            fx = db.q1("SELECT id FROM customer_feedback_fix WHERE issue_id=? "
                       "AND release_version=?", (issue["id"],
                                                 BUF_FIX["release_version"]))
            fix_id = fx["id"] if fx else 0
        log("regression", issue=issue["issue_key"], mpn=mpn, run_key=run_key,
            result=result, failed_asserts=failed_asserts, applied=bool(apply))
        if apply:
            FB.add_regression(db, issue["issue_key"], {
                "run_key": run_key,
                "fix_id": fix_id,
                "scope_type": "TARGETED_SUITE",
                "scope_description": R5_SCOPE,
                "test_suite_version": "qc_regression-post-r5",
                "commit_sha": "",
                "rule_version": "",
                "result": result,
                "total_cases": 1,
                "passed_cases": 1 if result == "PASS" else 0,
                "failed_cases": 1 if result == "FAIL" else 0,
                "report_storage_key": R5_REPORT,
                "failure_summary": summary,
                "started_at": "2026-10-28T07:51:28+08:00",
                "finished_at": "2026-10-28T07:51:28+08:00",
            }, "system:qc-regression")
            FB.update_sample(db, issue["sample_link_id"],
                             {"regression_status": result}, "system:qc-regression")
        added += 1
    return {"fixtures": len(rep.get("rows") or []), "added": added,
            "skipped": skipped, "missing": missing}


def import_evidence(db, apply):
    added = skipped = 0
    for mpn, paths in EVIDENCE_FIELDS.items():
        issue = issues_by_mpn(db).get(mpn)
        if not issue:
            log("evidence_missing_issue", mpn=mpn)
            continue
        ev = db.q1("SELECT * FROM source_evidence WHERE mpn=?", (mpn,))
        if not ev:
            log("evidence_card_missing", mpn=mpn)
            continue
        doc = db.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],))
        if not doc:
            log("evidence_document_missing", mpn=mpn)
            continue
        for path in paths:
            row = db.q1(
                "SELECT * FROM source_field_evidence WHERE evidence_id=? "
                "AND field_path=? AND verification_status='verified' "
                "ORDER BY id DESC LIMIT 1", (ev["id"], path))
            if not row or not row.get("evidence_quote") or not row.get("page_number"):
                log("evidence_field_skip", mpn=mpn, field_path=path)
                skipped += 1
                continue
            dup = db.q1(
                "SELECT id FROM customer_feedback_evidence WHERE issue_id=? "
                "AND document_sha256=? AND page_number=? AND field_path=? "
                "AND quote_text=?",
                (issue["id"], doc["pdf_sha256"], row["page_number"], path,
                 row["evidence_quote"]))
            if dup:
                skipped += 1
                continue
            log("evidence", issue=issue["issue_key"], mpn=mpn, field_path=path,
                page=row["page_number"], source_field_evidence=row["id"],
                applied=bool(apply))
            if not apply:
                added += 1
                continue
            e = FB.add_evidence(db, issue["issue_key"], {
                "sample_link_id": issue["sample_link_id"],
                "evidence_type": "MANUFACTURER_PDF",
                "source_url": doc["source_url"],
                "document_title": Path(doc["local_path"] or "").name,
                "document_revision": doc.get("document_revision") or "",
                "document_sha256": doc["pdf_sha256"],
                "page_number": row["page_number"],
                "field_path": path,
                "quote_text": row["evidence_quote"],
            }, HUMAN)
            reason = ("导入已人工核验的原厂字段证据 source_field_evidence#%d"
                      "（字段 %s，核验人 %s）" %
                      (row["id"], path, row.get("reviewer") or HUMAN))
            db.x("UPDATE customer_feedback_evidence SET review_status='HUMAN_VERIFIED',"
                 "reviewer=?,reviewed_at=?,review_reason=? WHERE id=?",
                 (row.get("reviewer") or HUMAN, row.get("verified_at") or FB.now(),
                  reason, e["id"]))
            FB._audit(db, issue["id"], row.get("reviewer") or HUMAN,
                      "evidence_review", "", "", {
                          "evidence_id": e["id"],
                          "status": "HUMAN_VERIFIED",
                          "source_field_evidence": row["id"],
                          "field_path": path,
                          "reason": reason,
                      })
            added += 1
        if apply:
            has = db.q1("SELECT 1 FROM customer_feedback_evidence WHERE issue_id=? "
                        "AND review_status='HUMAN_VERIFIED' LIMIT 1", (issue["id"],))
            if has:
                FB.update_sample(db, issue["sample_link_id"],
                                 {"evidence_status": "HUMAN_VERIFIED"}, ACTOR)
    return {"added": added, "skipped": skipped}


def add_buf_fix(db, apply):
    issue = issues_by_mpn(db).get("BUF634PG4")
    if not issue:
        return {"fix": 0}
    existing = db.q1("SELECT id FROM customer_feedback_fix WHERE issue_id=? "
                     "AND release_version=?", (issue["id"],
                                               BUF_FIX["release_version"]))
    if existing:
        return {"fix": 0}
    log("fix", issue=issue["issue_key"], release_version=BUF_FIX["release_version"],
        applied=bool(apply))
    if apply:
        FB.add_fix(db, issue["issue_key"], {
            "commit_sha": "",
            "release_version": BUF_FIX["release_version"],
            "parser_version": issue.get("parser_version") or "",
            "rule_version": issue.get("rule_version") or "",
            "summary": BUF_FIX["summary"],
            "changed_paths": BUF_FIX["changed_paths"],
        }, ACTOR)
    return {"fix": 1}


def buf_transitions(db, apply):
    issue = issues_by_mpn(db).get("BUF634PG4")
    if not issue:
        return {"transitions": 0}
    steps = 0
    cur = db.q1("SELECT status FROM customer_feedback_issue WHERE issue_key=?",
                (issue["issue_key"],))["status"]
    if cur in ("REGRESSION_PASSED", "PENDING_HUMAN_ACCEPTANCE", "ACCEPTED",
               "CLOSED", "WAIVED"):
        log("transition_skip", issue=issue["issue_key"], current=cur,
            reason="already at/after REGRESSION_PASSED")
        return {"transitions": 0}
    for target, reason in BUF_TRANSITIONS:
        if cur == target:
            continue
        if target not in FB.TRANSITIONS.get(cur, ()):
            log("transition_skip", issue=issue["issue_key"], current=cur,
                target=target)
            break
        steps += 1
        log("transition", issue=issue["issue_key"], current=cur, target=target,
            applied=bool(apply))
        if apply:
            FB.transition(db, issue["issue_key"], target, reason, ACTOR)
        cur = target
    return {"transitions": steps}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed", default=str(ROOT / "data" / "seed_feedback_11.csv"))
    ap.add_argument("--regression-report", default="")
    ap.add_argument("--only", default="metadata,fix,regression,evidence,transition")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()

    from app import db as db_mod
    db = db_mod                      # 模块级 q/q1/x 与业务服务注入契约一致
    db.conn()                        # 确保 DDL / 增量迁移已执行
    only = {x.strip() for x in a.only.split(",") if x.strip()}
    out = {}
    if "metadata" in only:
        out["metadata"] = seed_metadata(db, a.seed, a.apply)
    if "fix" in only:
        out["fix"] = add_buf_fix(db, a.apply)
    if "regression" in only:
        if not a.regression_report:
            print("--regression-report is required for regression", file=sys.stderr)
            return 2
        out["regression"] = import_regression(db, a.regression_report, a.apply)
    if "evidence" in only:
        out["evidence"] = import_evidence(db, a.apply)
    if "transition" in only:
        out["transition"] = buf_transitions(db, a.apply)
    print(json.dumps({"apply": a.apply, "summary": out}, ensure_ascii=False,
                     indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
