"""Gold 核验单生成器（三遍法规则引擎）——把手册的逐字段核验法沉到服务端。

输入 Gold 字段（防御式读列，schema 漂移不炸）+ QC 信号（qc_finding ∪ risk_case）
+ 可选 parsed JSON（补条件/上下文线索），输出分组 Markdown 核验单，供双屏对照与归档。

红线内建：
  * 模板只预填**位置与格式**，值/quote 必须人眼读原厂 PDF；
  * 空白行给 `not_specified` 模板（**绝不补 0**）；
  * 高风险行标注 quote 必填（API 侧同样拦截，见 app/api/qe.py）；
  * 机器草稿标注「P4 假设」，禁止当答案。

自包含约束：会被 server 进程 import，**import 时零 stdout 副作用**（与 qc/goldset.py 同口径），
不 import qc.table_audit / qc.qc_regression。CLI 才打印/写文件。

用法：
  python qc/cheatsheet.py --mpn DAC8555IPWG4
  python qc/cheatsheet.py --gold-id 11 --out qc/cheatsheets/DAC8555IPWG4.md
  python qc/cheatsheet.py --all-draft --out-dir qc/cheatsheets/
退出码：0 正常；3 全部找不到 Gold/字段。
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

# 容器内直接 `python /app/qc/cheatsheet.py` 时 sys.path[0] 是 /app/qc（脚本目录），
# `from app import db` 会失败；这里把仓库根加进 sys.path（无 stdout 副作用）。
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# ---------------------------------------------------------------- 识别规则
CUR_RE = re.compile(r"\b(current|icc|idd|ioff|ion|ibias|ileak|leakage|quiescent|"
                    r"ios|iout|iin|ib)\b|µa|\bua\b|\bma\b", re.I)
FSR_RE = re.compile(r"%\s*(of\s+)?fsr|gain|offset|accuracy|nonlinearity|inl|dnl", re.I)
POWER_PIN = re.compile(r"^(vdd|vcc|vee|vss|gnd|v\+|v-|v−|avdd|dvdd|iovdd|vref|vrefh|vrefl|"
                       r"vssa|vdda|vref\+|vref-)$", re.I)
# 高风险 = 客户直接据此选型/接线；证据必须含原文 quote
PASS_TITLE = {1: "Pass 1 · 身份与封装（~15min）",
              2: "Pass 2 · 电气 / 引脚 / 极限（~40min）",
              3: "Pass 3 · 叙述扫尾（~10min）"}

SIGNAL_LEGEND = {
    "unit_dimension": "µA↔mA 量纲核对（单位列以表格为准）",
    "unit_dimension_unresolved": "量纲冲突且表格未决：证据必须 quote 单位列",
    "row_mispair": "行归属双查（本行 vs 邻行数值）",
    "footnote_missing": "证据必须带脚注原文",
    "pin_gap": "先数 pin 号连续性 + 单封装列",
    "pin_mismatch": "引脚名以 Pin Functions 表为准",
    "direction_reversal": "方向以真值表回显为准",
    "package_mismatch": "封装以 Ordering 表 literal 行为准",
    "identity_unverified": "订购表未落实 literal：只徽章不签准确 SKU",
    "identity_family": "家族号≠请求号：mpn 还原、family 保留",
    "option_conflation": "频点/档位以订购行绑定为准",
    "condition_leak": "条件数值不得入值（VCC=0V 类）",
    "range_collapse": "MIN/TYP/MAX 分列核对",
    "qualifier_loss": "限定语三列核对",
}


def _s(v, n=60) -> str:
    s = "" if v is None else (json.dumps(v, ensure_ascii=False)
                              if isinstance(v, (dict, list)) else str(v))
    return s if len(s) <= n else s[:n - 1] + "…"


def has_quote(text: str) -> bool:
    """证据是否含原文引用（引号片段或「原文」字样）——高风险字段的硬要求。"""
    t = text or ""
    if "原文" in t:
        return True
    return bool(re.search(r'["“][^"”\n]{1,120}["”]', t))


def risk_of(field_path: str, field_name: str = "", unit: str = "",
            expected: str = "") -> str:
    """风险级：高·quote（选型/接线关键）> 中 > 低。API 侧复用此判定。

    高风险 = 身份/封装 + 电流类电气 + **电源脚名**（手册 §3.1 清单）；
    Gold 的 pin 字段 `field_name` 恒为 "pin"，故引脚名从 `expected` 判定。
    """
    p = (field_path or "").strip()
    if p in ("basic_info.mpn", "basic_info.manufacturer",
             "specs.package.type", "specs.package.pins"):
        return "高·quote"
    if re.match(r"^specs\.(absolute_max|esd)\[", p) and \
            re.match(r"^(v|vdd|vcc|vin|vout)", (field_name or "").strip(), re.I):
        return "高·quote"
    if re.match(r"^(electrical|specs\.electrical)\[\d+\]", p):
        if CUR_RE.search(field_name or "") or (unit or "") in ("µA", "uA", "mA", "mW"):
            return "高·quote"
        return "中"                                       # %FSR/精度类：中（需脚注，金额未到高）
    if re.match(r"^(pin\[|pin_configuration\[)", p):
        name = (expected or field_name or "").strip()
        return "高·quote" if POWER_PIN.match(name) else "中"
    return "低"


def is_high_risk(field_path: str, field_name: str = "", unit: str = "",
                 expected: str = "") -> bool:
    return risk_of(field_path, field_name, unit, expected) == "高·quote"


# ---------------------------------------------------------------- 定位规则
def locate(field: dict, mpn: str, json_doc=None) -> dict:
    """field_path → {pass_, sec, row, col, tpl, ns, risk, sig}

    `pin[N].name` 的 N 是**引脚号**（1 起，与印刷引脚号一致）；
    `electrical[N].value` 的 N 是 parsed JSON `specs.electrical[N]` 下标。
    """
    p = (field.get("field_path") or "").strip()
    param = field.get("field_name") or ""
    unit = field.get("unit") or ""
    draft = _s(field.get("expected"), 40)
    risk = risk_of(p, param, unit)
    sig: set[str] = set()

    if p == "basic_info.mpn":
        return dict(pass_=1, sec="Ordering Information / PACKAGE OPTION ADDENDUM（搜 ORDERING）",
                    row=f"{mpn} 行", col="Device 列", risk="高·quote",
                    sig={"identity_family", "identity_unverified"},
                    tpl=f'p.__ Ordering 表 {mpn} 行 Device 列，原文 "{mpn}"',
                    ns=f"p.__ Ordering 表无 {mpn} 行 → source_unresolved，不得猜")
    if p == "basic_info.manufacturer":
        return dict(pass_=1, sec="封面署名 / Ordering 表（搜 Texas Instruments）", row="署名行",
                    col="—", risk="高·quote", sig=set(),
                    tpl=f'p.__ 封面署名/Ordering 表，原文 "{draft or "Texas Instruments"}"',
                    ns="p.__ 封面署名缺失 → not_specified")
    if p == "basic_info.category":
        return dict(pass_=1, sec="封面标题行 / Description 首句", row="—", col="—", risk="低",
                    sig=set(), tpl=f'p.__ 封面标题行，原文 "{{pdf值}}"（草稿P4: {draft}）',
                    ns="p.__ 无分类表述 → not_specified")
    if p == "specs.package.type":
        return dict(pass_=1, sec="Ordering 表 Package 列 + 封装外形图（搜 PACKAGE OPTION）",
                    row=f"{mpn} 行", col="Package 列", risk="高·quote",
                    sig={"package_mismatch"},
                    tpl=f'p.__ Ordering 表 {mpn} 行 Package 列（后缀→封装族），与外形图互证，'
                        f'原文 "{{pdf值}}"（草稿P4: {draft}）',
                    ns="p.__ Ordering 表未列封装 → source_unresolved")
    if p == "specs.package.pins":
        return dict(pass_=1, sec="封装外形图 / 引脚表头", row="—", col="引脚计数", risk="高·quote",
                    sig={"package_mismatch", "pin_gap"},
                    tpl=f'p.__ 外形图/引脚表头，原文 "{{pdf值}} pins"（草稿P4: {draft}）',
                    ns="p.__ 图内无计数 → not_specified")

    m = re.match(r"^(?:specs\.)?electrical\[(\d+)\]", p)
    if m:
        idx = int(m.group(1))
        cond = ""
        try:
            cond = (_json_elec(json_doc, idx) or {}).get("condition") or ""
        except Exception:                                        # noqa: BLE001
            cond = ""
        if CUR_RE.search(param) or unit in ("µA", "uA", "mA"):
            sig |= {"unit_dimension", "unit_dimension_unresolved", "row_mispair"}
        if FSR_RE.search(param):
            sig |= {"footnote_missing", "range_collapse", "qualifier_loss"}
        tpl = (f'p.__ Electrical Characteristics 表 {param or "{symbol}"} 行 '
               f'{{col: MIN/TYP/MAX}} 列，原文 "{{值}} {unit}"'.rstrip())
        if FSR_RE.search(param):
            tpl += ' + 脚注(n) 原文 "{脚注}"'
        return dict(pass_=2, sec="Electrical Characteristics 表（搜 Electrical Characteristics）",
                    row=f"{param or 'symbol'} 行", col="{col: MIN/TYP/MAX}",
                    risk="高·quote" if (CUR_RE.search(param) or unit in ("µA", "uA", "mA")) else "中",
                    sig=sig, tpl=tpl,
                    ns=f"p.__ EC 表 {param or '该'} 行此列空 → expected=not_specified，"
                       f"证据「原厂未规定」",
                    cond=cond)
    m = re.match(r"^(?:pin|pin_configuration)\[(\d+)\]", p)
    if m:
        n = int(m.group(1))
        if p.startswith("pin_configuration"):                    # 旧口径 0 起
            n += 1
        return dict(pass_=2, sec="Pin Functions / Pin Configurations 表（搜 Pin Functions）",
                    row=f"pin {n} 行", col="NAME 列",
                    risk=risk_of(p, param, unit, draft),         # 电源脚名 → 高·quote
                    sig={"pin_gap", "pin_mismatch", "direction_reversal"},
                    tpl=f'p.__ Pin Functions 表 pin{n} 行 NAME 列，原文 "{{pdf值}}"'
                        + (f'（草稿P4: {draft}）' if draft else ""),
                    ns=f"p.__ 引脚表 pin{n} 无 NAME → not_specified（NC 也算值，不空白）")
    if re.match(r"^specs\.(absolute_max|esd)\[", p):
        return dict(pass_=2, sec="Absolute Maximum Ratings / ESD Ratings 表（搜 Absolute Maximum）",
                    row=f"{param or 'symbol'} 行", col="{col: MIN/MAX}",
                    risk="高·quote" if POWER_PIN.match((param or "").strip()) else "中",
                    sig={"range_collapse", "qualifier_loss"},
                    tpl=f'p.__ AMR 表 {param or "{symbol}"} 行 限值列，原文 "{{值}} {unit}"（stress 注记）',
                    ns="p.__ AMR 表此行无限值 → not_specified")
    if re.match(r"^specs\.thermal\[", p):
        return dict(pass_=2, sec="Thermal Information 表（搜 Thermal）", row=f"{param or 'RθJA'} 行",
                    col="封装列", risk="中", sig=set(),
                    tpl=f'p.__ Thermal 表 {param or "{symbol}"} 行 封装列，原文 "{{值}} {unit}"',
                    ns="p.__ Thermal 表无本封装列 → not_specified")
    m = re.match(r"^(features|applications)\[(\d+)\]", p)
    if m:
        kind, i = m.group(1), int(m.group(2)) + 1
        return dict(pass_=3, sec=f"首页 {kind.capitalize()} 列表", row=f"第 {i} 条", col="—",
                    risk="低", sig=set(),
                    tpl=f'p.__ {kind.capitalize()} 第{i}条，原文 "{{pdf值}}"'
                        + (f'（草稿P4: {draft}…）' if draft else ""),
                    ns=f"p.__ 列表不足 {i} 条 → not_specified")
    if p == "basic_info.description":
        return dict(pass_=3, sec="Description 首段", row="段 1", col="—", risk="低", sig=set(),
                    tpl=f'p.__ Description 段1 首句，原文 "{{pdf值}}"'
                        + (f'（草稿P4: {draft}…）' if draft else ""),
                    ns="p.__ 无 Description 段 → not_specified")
    return dict(pass_=3, sec="按 field_path 语义定位（订购/多语言/SEO 类核对）", row="—", col="—",
                risk="低", sig=set(),
                tpl=f'p.__ {{表/段}} {{行}}，原文 "{{pdf值}}"'
                    + (f'（草稿P4: {draft}）' if draft else ""),
                ns="p.__ 原文未规定 → not_specified")


def _json_elec(json_doc, idx: int) -> dict | None:
    if not json_doc:
        return None
    try:
        arr = ((json_doc.get("specs") or {}).get("electrical")
               or json_doc.get("electrical") or [])
        return arr[idx] if 0 <= idx < len(arr) else None
    except Exception:                                            # noqa: BLE001
        return None


def _banners(pass_no: int, signals: set) -> list[str]:
    b = []
    if pass_no == 1 and ({"package_mismatch", "identity_family", "identity_unverified"} & signals):
        b.append("⚠ 身份/封装信号：身份三查先行（首页标题+制造商 → Ordering 完整订购型号 → "
                 "封装图/后缀互证）；封装以 Ordering literal 行为准。")
    if pass_no == 2:
        if {"pin_gap", "pin_mismatch", "direction_reversal"} & signals:
            b.append("⚠ 引脚信号：先数 pin 号 1..N 连续性与单封装列；电源脚/方向脚证据必须 quote。")
        if ({"unit_dimension", "unit_dimension_unresolved", "row_mispair", "footnote_missing",
             "range_collapse", "qualifier_loss", "condition_leak"} & signals):
            b.append("⚠ 参数表信号：µA 行查量纲与行归属；%FSR/gain/offset 行带脚注原文；"
                     "MIN/TYP/MAX 分列核对。")
    return b


def render_from_fields(fields, mpn, signals=None, json_doc=None, meta=None) -> str:
    signals = set(signals or [])
    meta = meta or {}
    located = [(f, locate(f, mpn, json_doc)) for f in fields]
    hi_total = sum(1 for _, L in located if L["risk"] == "高·quote")
    now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    out = [f"# {mpn} · Gold 核验单（三遍法）",
           f"> 生成 {now} · gold_id={meta.get('gold_id', '-')} version={meta.get('version', '-')}"
           f" status={meta.get('status', '-')} · 字段 {len(fields)} · 高风险 {hi_total}"
           f" · 信号 {len(signals)}",
           "> 页码口径 = PDF 物理页(1 起)；高风险字段证据必须含原文 quote；"
           "空白 = not_specified，绝不补 0。",
           "> 判定三动作：确认(verified+页码+证据) / 推翻(conflict+PDF 正确值+证据) / "
           "补充(+补录字段，可直达 verified)。机器草稿仅为 P4 假设，禁止当答案。", ""]
    for ps in (1, 2, 3):
        rows = [(f, L) for f, L in located if L["pass_"] == ps]
        if not rows:
            continue
        out.append(f"## {PASS_TITLE[ps]}　[{len(rows)} 字段]")
        for b in _banners(ps, signals):
            out.append(f"> {b}")
        out.append("")
        for f, L in rows:
            sigs = sorted(L["sig"] & signals)
            out.append(f"- [ ] `{f.get('field_path')}`　风险: **{L['risk']}**"
                       + (f"　信号: {', '.join(sigs)}" if sigs else ""))
            out.append(f"    - 翻表: {L['sec']} · {L['row']} / {L['col']}")
            out.append(f"    - 证据: {L['tpl']}")
            out.append(f"    - 空白: {L['ns']}")
            draft_line = (f"    - 草稿(P4): `{_s(f.get('expected'), 60)}`"
                          + (f"　unit=`{f.get('unit')}`" if f.get("unit") else "")
                          + (f"　cond=`{_s(f.get('cond') or L.get('cond'), 40)}`"
                             if (f.get("cond") or L.get("cond")) else ""))
            out.append(draft_line)
        out.append("")
    out += ["## 完成标准",
            "- D1：≥15 个关键字段 verified（页码+证据；高风险含 quote）→ 器件切 `review`；"
            "**当天不冻结**。",
            "- D4：全字段 verified + conflict 处置完 + 隔日抽查 10–20% → 证据卡冻结"
            "（守卫 8 条，target_fields 覆盖整件）。", "", "## 信号图例"]
    legend = [f"- `{k}`: {v}" for k, v in SIGNAL_LEGEND.items() if k in signals]
    out += legend or ["- （本件无 QC 信号）"]
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- DB 接入
def _d(dbm):
    if dbm is not None:
        return dbm
    from app import db as _db
    return _db


def load_signals(db, mpn: str) -> set:
    sig: set = set()
    for sql in ("SELECT DISTINCT kind FROM qc_finding WHERE mpn=?",
                "SELECT DISTINCT kind FROM risk_case WHERE mpn=?"):
        try:
            for r in db.q(sql, (mpn,)):
                v = next(iter(r.values()), None)
                if v:
                    sig.add(v)
        except Exception:                                        # noqa: BLE001
            pass
    return sig


def load_gold(db, mpn: str | None = None, gold_id: int | None = None):
    rows = (db.q("SELECT * FROM gold_set WHERE id=? LIMIT 1", (gold_id,)) if gold_id
            else db.q("SELECT * FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,)))
    if not rows:
        return None, []
    g = rows[0]
    fields = db.q("SELECT * FROM gold_field WHERE gold_id=? ORDER BY id", (g["id"],))
    return g, fields


def render_gold(mpn: str | None = None, gold_id: int | None = None,
                include_json: bool = True, db_mod=None) -> str | None:
    db = _d(db_mod)
    g, fields = load_gold(db, mpn=mpn, gold_id=gold_id)
    if not g or not fields:
        return None
    mpn = g.get("mpn") or mpn or ""
    json_doc = None
    if include_json:
        try:
            from qc import goldset
            loc = goldset.locate(mpn)
            if loc and loc.get("json"):
                json_doc = json.loads(Path(loc["json"]).read_text(encoding="utf-8"))
        except Exception:                                        # noqa: BLE001
            json_doc = None
    return render_from_fields(fields, mpn, signals=load_signals(db, mpn), json_doc=json_doc,
                              meta={"gold_id": g.get("id"), "version": g.get("version"),
                                    "status": g.get("status")})


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpn")
    ap.add_argument("--gold-id", type=int)
    ap.add_argument("--all-draft", action="store_true")
    ap.add_argument("--out")
    ap.add_argument("--out-dir")
    ap.add_argument("--no-json", action="store_true")
    a = ap.parse_args(argv)
    db = _d(None)
    if a.all_draft:
        jobs = [(r["mpn"], r["id"]) for r in
                db.q("SELECT id, mpn FROM gold_set WHERE status='draft' ORDER BY id")]
    else:
        if not (a.mpn or a.gold_id):
            ap.error("需要 --mpn / --gold-id / --all-draft")
        jobs = [(a.mpn, a.gold_id)]
    if a.out_dir:
        Path(a.out_dir).mkdir(parents=True, exist_ok=True)
    miss = 0
    for mpn, gid in jobs:
        md = render_gold(mpn=mpn, gold_id=gid, include_json=not a.no_json, db_mod=db)
        if not md:
            miss += 1
            print(f"[{mpn or gid}] 无 Gold/字段", file=sys.stderr)
            continue
        if a.out_dir:
            p = Path(a.out_dir) / f"{mpn}.md"
            p.write_text(md, encoding="utf-8")
            print(f"written {p}")
        elif a.out and len(jobs) == 1:
            Path(a.out).parent.mkdir(parents=True, exist_ok=True)
            Path(a.out).write_text(md, encoding="utf-8")
            print(f"written {a.out}")
        else:
            sys.stdout.write(md)
    return 3 if (miss and miss == len(jobs)) else 0


if __name__ == "__main__":
    raise SystemExit(main())