#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""存量重渲染的**只读**审计：把 `not_ok` 分门别类，并把真信号逐条取证。

为什么需要它
------------
`qc/symbols_rerender.py` 只回答「能覆盖 / 不能覆盖」，不回答「不能覆盖的那些是什么」。
2418 件 `not_ok` 里混着四种完全不同的东西：

1. **内容塌缩**（旧页 46 KB 的三视图，新页 1.3 KB 的说明页）—— **绝对不能接受**；
2. **旧页主语是旧名字**（JSON 的 mpn 后来被规范化过，旧页标题还是旧名）—— 新页是对的；
3. **渲染器代际差异**（符号图形变了、文本没动）—— 可以按批接受；
4. **真信号**（页面断言了状态不允许的东西）—— 要改代码或改数据，不能靠放行。

把这几类混成一个 `not_ok` 计数，等于把「可以放行」和「绝不能放行」扔进同一个桶。
本工具只做**事实提取与分层**，不做放行决定（放行由人裁决后写进 allowlist）。

数据来源（三者都只读）
----------------------
- 测量结果 `--measure`：`symbols_rerender.py --json` 的产物（status / 字节数 / 文本增删）；
- 沙箱新页 `--sandbox`：同一批渲染产物（真信号的 evidence 要在这上面重跑 `EM.check`）；
- 磁盘旧页 `--symbols` + `--parsed`：旧页文本、旧页标题里的 mpn、JSON 主语。

分层口径（唯一定义处：`STRATA`，改口径只改这里，不在报告里手算）
----------------------------------------------------------------
按**优先级**判，先命中先落层：

| 层 | 判据 | 能否进 allowlist |
| --- | --- | --- |
| `collapse` | `new*3 <= old` 或旧页可见文本多出 >= 10 条 | **永不** |
| `mpn_renamed` | 旧页标题的 mpn ≠ 本件 mpn，替换后符号块相同且文本不越界 | 可以（新页跟当前 JSON 一致） |
| `text_out_of_bounds` | 有允许集以外的文本增删，且不属于上面两类 | 需逐件裁决 |
| `symbol_only` | 符号图形变了、文本零增删、体积变化 < 10% | 可以（渲染器升级） |
| `symbol_plus_text` | 符号图形变了、文本零增删、体积变化 >= 10% | 需抽样看图 |
| `other` | 以上都不沾 | 需人工看 |

用法
----
    python qc/symbols_rerender_audit.py
    python qc/symbols_rerender_audit.py \
        --measure .sandbox/rerender_after_bga.json \
        --sandbox .sandbox/symbols_rerender_after_bga \
        --md docs/qc/20261031_not_ok_strata.md
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc.symbols_render_diff import (          # noqa: E402
    NEW_CAPTIONS, OLD_CAPTIONS, _strip_boundary, _symbol_block, _visible,
    _without_symbol, text_is_allowed,
)

#: 分层判据（唯一定义处）。顺序 = 优先级 = 报告里的呈现顺序。
STRATA: tuple[tuple[str, str, str], ...] = (
    ("collapse", "内容塌缩：新页不到旧页 1/3，或旧页可见文本多出 >= 10 条", "永不"),
    ("mpn_renamed", "旧页标题是旧 mpn；替换为新 mpn 后符号块相同、文本不越界", "可以"),
    ("text_out_of_bounds", "有允许集以外的文本增删，且不属于上面两类", "逐件"),
    ("symbol_only", "符号图形变了，文本零增删，体积变化 < 10%", "可以"),
    ("symbol_plus_text", "符号图形变了，文本零增删，体积变化 >= 10%", "抽样"),
    ("other", "以上都不沾，需人工看", "逐件"),
)

#: 塌缩门槛。改这里等于改判据，报告里的数会跟着变。
COLLAPSE_BYTE_RATIO = 3           # new * 3 <= old
COLLAPSE_TEXT_LOSS = 10           # 旧页比新页多 >= 10 条可见文本
SIZE_STABLE = 0.10                # symbol_only / symbol_plus_text 的分界

_TITLE_MPN_RE = re.compile(r"<title>([^<]*?)\s*三视图</title>", re.I)


def visible_text(page: str) -> list[str]:
    """**可比的**可见文本：剥掉符号块与边界小节，与 `symbols_rerender` 同口径。

    两侧都要剥。只剥一侧会让已覆盖过的旧页凭空多出「被删文本」（边界小节那几条），
    分层就会把「本来一模一样」的件算成越界。
    """
    return _visible(_strip_boundary(_without_symbol(page)))


def _title_mpn(page: str) -> str:
    m = _TITLE_MPN_RE.search(page)
    return (m.group(1).strip() if m else "")


def _mpn_index(parsed_dir: Path) -> dict[str, Path]:
    """mpn → 最新 parsed JSON（与 `symbols_rerender.index_parsed` 同口径）。"""
    out: dict[str, Path] = {}
    for p in Path(parsed_dir).glob("*.json"):
        stem = p.stem
        mpn = stem[:-9] if len(stem) > 9 and stem[-9] == "_" else stem
        prev = out.get(mpn)
        if prev is None or p.stat().st_mtime >= prev.stat().st_mtime:
            out[mpn] = p
    return out


def classify(row: dict, old_page: str, new_page: str) -> tuple[str, dict]:
    """判层 + 返回判定用到的事实（报告里逐件可复核）。"""
    mpn = row["mpn"]
    old_b = int(row.get("old_bytes") or 0)
    new_b = int(row.get("new_bytes") or 0)
    old_t = visible_text(old_page)
    new_t = visible_text(new_page)
    facts: dict = {
        "old_bytes": old_b, "new_bytes": new_b,
        "old_texts": len(old_t), "new_texts": len(new_t),
        "text_lost": len(old_t) - len(new_t),
    }

    # ① 塌缩优先：任何其它解释都不能覆盖它
    if (old_b and new_b and new_b * COLLAPSE_BYTE_RATIO <= old_b) \
            or facts["text_lost"] >= COLLAPSE_TEXT_LOSS:
        return "collapse", facts

    # ② 旧页主语是旧名字：把旧页里的旧 mpn 换成本件 mpn 再比一次
    old_mpn = _title_mpn(old_page)
    if old_mpn and old_mpn != mpn:
        norm_old = old_page.replace(old_mpn, mpn)
        norm_t = visible_text(_strip_boundary(norm_old))
        norm_set, new_set = set(norm_t), set(new_t)
        removed = [t for t in norm_t if t not in new_set
                   and not text_is_allowed(t, OLD_CAPTIONS, mpn)]
        added = [t for t in new_t if t not in norm_set
                 and not text_is_allowed(t, NEW_CAPTIONS, mpn)]
        same_sym = _symbol_block(norm_old) == _symbol_block(new_page)
        facts.update({"old_mpn": old_mpn, "symbol_same_after_rename": same_sym,
                      "extras_after_rename": (removed + added)[:3]})
        if same_sym and not removed and not added:
            return "mpn_renamed", facts

    # ③ 文本越界（沿用测量结果里的口径，保持两边一致）
    if (row.get("n_removed_extra") or 0) or (row.get("n_added_extra") or 0):
        facts["removed_extra"] = (row.get("removed_extra") or [])[:3]
        facts["added_extra"] = (row.get("added_extra") or [])[:3]
        return "text_out_of_bounds", facts

    # ④⑤ 只是图变了
    if not row.get("symbol_same") and not row.get("no_anchor"):
        ratio = abs(new_b - old_b) / max(old_b, 1)
        facts["size_ratio"] = round(ratio, 3)
        return ("symbol_only" if ratio < SIZE_STABLE else "symbol_plus_text"), facts

    facts["symbol_same"] = row.get("symbol_same")
    facts["no_anchor"] = row.get("no_anchor")
    return "other", facts


def _signal_detail(mpn: str, sandbox: Path, parsed: dict[str, Path], pkgs: Path) -> dict:
    """真信号取证：在沙箱新页上重跑门禁，拿完整的 finding + 证据。

    测量结果里的 `findings` 只有 kind 字符串、没有 evidence，而裁决要靠 evidence，
    所以这里重跑一次（只读页面，不重渲染）。
    """
    from qc import engineering_model as EM
    import symbol_svg as S

    src = parsed.get(mpn)
    page_path = Path(sandbox, f"{mpn}.html")
    if src is None or not page_path.is_file():
        return {"mpn": mpn, "error": "缺 JSON 或沙箱页"}
    doc = json.loads(src.read_text(encoding="utf-8"))
    page = page_path.read_text(encoding="utf-8", errors="replace")
    state = EM.derive_state_for_page(doc, pkgs, page)
    pins = len(doc.get("pin_configuration") or [])
    declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
    pkg0, pkgn = S.package_of(doc, 0), S.package_of(doc, pins)
    ev = state["package_outline"].get("evidence") or {}
    return {
        "mpn": mpn, "json": src.name,
        "package_type": pkgn, "package_type_at_0": pkg0,
        "pins": pins, "declared_pins": declared,
        # 渲染器用 `declared or len(pins)` 建 key，状态层用 `declared`：
        # 两者不同源时，页面的 `<img src>` 与 state 的 package_key 必然对不上（A2 就这么报的）。
        "key_renderer": S.canon_pkg(pkgn, declared or pins),
        "key_state": ev.get("package_key"),
        "outline_status": state["package_outline"]["status"],
        "outline_reason": ev.get("reason"),
        "geometry_3d": state["geometry_3d"]["status"],
        "findings": EM.check(doc, page, state),
    }


def audit(measure: Path, sandbox: Path, symbols: Path,
          parsed_dir: Path, pkgs: Path, samples: int = 8) -> dict:
    data = json.loads(Path(measure).read_text(encoding="utf-8"))
    rows = data.get("rows") or []
    parsed = _mpn_index(parsed_dir)

    buckets: dict[str, list[dict]] = {name: [] for name, _, _ in STRATA}
    for r in rows:
        if r.get("status") != "not_ok":
            continue
        mpn = r["mpn"]
        old_p, new_p = Path(symbols, f"{mpn}.html"), Path(sandbox, f"{mpn}.html")
        old_page = old_p.read_text(encoding="utf-8", errors="replace") if old_p.is_file() else ""
        new_page = new_p.read_text(encoding="utf-8", errors="replace") if new_p.is_file() else ""
        name, facts = classify(r, old_page, new_page)
        buckets[name].append({"mpn": mpn, **facts, "findings": r.get("findings") or []})

    where = {x["mpn"]: name for name, rows_ in buckets.items() for x in rows_}
    signals = []
    for r in rows:
        if not (r.get("findings") and r.get("status") == "not_ok"):
            continue
        detail = _signal_detail(r["mpn"], sandbox, parsed, pkgs)
        detail["stratum"] = where.get(r["mpn"], "")
        signals.append(detail)

    bga_notes = 0
    for rows_ in buckets.values():
        for x in rows_:
            p = Path(sandbox, f"{x['mpn']}.html")
            if p.is_file() and "BGA 球位待核" in p.read_text(encoding="utf-8", errors="replace"):
                bga_notes += 1

    return {
        "generated_from": Path(measure).name,
        "not_ok_total": sum(len(v) for v in buckets.values()),
        "strata_def": [{"name": n, "criteria": c, "allowlist": a} for n, c, a in STRATA],
        "strata": {k: {"count": len(v), "samples": v[:samples]} for k, v in buckets.items()},
        "bga_note_pages": bga_notes,
        "signals": signals,
    }


def _md(report: dict) -> str:
    L: list[str] = [
        "# `not_ok` 分层审计（只读）\n",
        f"来源测量：`{report['generated_from']}`；`not_ok` 合计 "
        f"**{report['not_ok_total']}** 件。\n",
        "| 层 | 判据 | 件数 | 能否进 allowlist |",
        "| --- | --- | --- | --- |",
    ]
    for d in report["strata_def"]:
        L.append(f"| `{d['name']}` | {d['criteria']} | "
                 f"{report['strata'][d['name']]['count']} | {d['allowlist']} |")
    L.append(f"\n新渲染为「BGA 球位待核」说明页：**{report['bga_note_pages']}** 件。\n")

    L.append("\n## 每层样本\n")
    for d in report["strata_def"]:
        name = d["name"]
        rows = report["strata"][name]["samples"]
        if not rows:
            continue
        L.append(f"### `{name}`（{report['strata'][name]['count']} 件）\n")
        L.append("| mpn | 旧→新 字节 | 文本 旧→新（丢） | 体积比 | 越界文本（前 3） |")
        L.append("| --- | --- | --- | --- | --- |")
        for r in rows:
            extra = ("／".join((r.get("removed_extra") or []) + (r.get("added_extra") or []))
                     or "／".join(r.get("extras_after_rename") or []) or "—")
            L.append(f"| `{r['mpn']}` | {r.get('old_bytes')}→{r.get('new_bytes')} "
                     f"| {r.get('old_texts')}→{r.get('new_texts')}（{r.get('text_lost')}） "
                     f"| {r.get('size_ratio', '—')} | {extra[:90]} |")
        L.append("")

    if report["signals"]:
        L.append("\n## 真信号逐件取证\n")
        cross: dict[str, int] = {}
        for s in report["signals"]:
            cross[s.get("stratum", "?")] = cross.get(s.get("stratum", "?"), 0) + 1
        L.append("信号落层：" + "／".join(f"`{k}` {v} 件" for k, v in sorted(cross.items())) + "\n")
        for s in report["signals"]:
            if s.get("error"):
                L.append(f"### `{s['mpn']}` — {s['error']}\n")
                continue
            L.append(f"### `{s['mpn']}`（层：`{s.get('stratum')}`）\n")
            L.append(f"- 封装原文：`{s['package_type']}`；脚数 {s['pins']}（声明 {s['declared_pins']}）")
            L.append(f"- key：渲染器 `{s['key_renderer']}` ／ 状态层 `{s['key_state']}`")
            L.append(f"- 状态：outline={s['outline_status']}（{s['outline_reason']}）、"
                     f"3d={s['geometry_3d']}")
            for f in s["findings"]:
                L.append(f"- **{f['kind']}**（{f['severity']}）：{f['message']}")
                L.append(f"  - 证据：`{str(f['evidence'])[:220]}`")
            L.append("")
    return "\n".join(L) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="not_ok 分层审计（只读）")
    ap.add_argument("--measure", default=str(ROOT / ".sandbox" / "rerender_after_bga.json"))
    ap.add_argument("--sandbox", default=str(ROOT / ".sandbox" / "symbols_rerender_after_bga"))
    ap.add_argument("--symbols", default=str(ROOT / "data" / "symbols"))
    ap.add_argument("--parsed", default=str(ROOT / "data" / "parsed"))
    ap.add_argument("--pkg-lib", default=str(ROOT / "data" / "pkgs"))
    ap.add_argument("--json", default=str(ROOT / ".sandbox" / "rerender_audit.json"))
    ap.add_argument("--md", default="")
    ap.add_argument("--samples", type=int, default=8)
    a = ap.parse_args(argv)

    measure = Path(a.measure)
    if not measure.is_file():
        print(f"找不到测量结果 {measure}；先跑 "
              f"qc/symbols_rerender.py --json {measure}", file=sys.stderr)
        return 2
    report = audit(measure, Path(a.sandbox), Path(a.symbols), Path(a.parsed),
                   Path(a.pkg_lib), a.samples)

    Path(a.json).parent.mkdir(parents=True, exist_ok=True)
    Path(a.json).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    text = _md(report)
    if a.md:
        Path(a.md).parent.mkdir(parents=True, exist_ok=True)
        Path(a.md).write_text(text, encoding="utf-8")

    print(f"not_ok 合计 {report['not_ok_total']} 件")
    for d in report["strata_def"]:
        print(f"  {d['name']:<18} {report['strata'][d['name']]['count']:>5}"
              f"   allowlist={d['allowlist']}")
    print(f"  （其中新渲染为 BGA 说明页 {report['bga_note_pages']} 件）")
    print(f"真信号 {len(report['signals'])} 件；明细 → {a.json}" + (f" / {a.md}" if a.md else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
