# -*- coding: utf-8 -*-
"""重解析防呆守卫：新产物不如旧产物时，强制保留旧 JSON。

为什么必须有它（batch20 实测）
------------------------------
盲跑重解析会把「可用的旧数据」换成「坏的空气数据」。实测两例：
  * `ADC12QJ1600ALREP`：新产物 `specs.electrical` 为空（模型空表），
    但确定性抽取的 thermal=3 / esd=2 是好的；
  * `ADC12QJ1600-SP`：`invalid_json`，整件失败。
这两类若直接覆盖 `data/parsed`，就是把原本正常的旧数据删掉。

口径（只认可测差异，不做语义猜测）
----------------------------------
accept = False 当且仅当满足任一条：
  1. 新文档不是 dict（解析失败 / 读盘失败）→ `invalid_json`
  2. `specs.electrical` 为空且旧的非空 → `electrical_empty`
  3. `specs.electrical` 行数 < 旧行数 → `electrical_shrunk`
  4. 旧有的 `thermal` / `esd` 行数在新产物里变少 → `container_lost`
否则 accept = True（包括「新产物 thermal/esd 仍为 0」——那是源文档没有该表，
不是覆盖理由；见 `source_has_container_evidence()`）。

注意：守卫**不判断值对不对**，它只挡「结构上明显更差」的覆盖。值层面的
好坏由 `qc/fact_acceptance.py` 与人工复核负责，两件事不能混。
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

CONTAINERS = ("thermal", "esd")


def _rows(doc, key: str) -> list:
    if not isinstance(doc, dict):
        return []
    sp = doc.get("specs")
    if not isinstance(sp, dict):
        return []
    v = sp.get(key)
    return v if isinstance(v, list) else []


def guard(old: dict | None, new: dict | None) -> dict:
    """比较新旧文档，返回 `{accept, reason, old, new}`。"""
    if not isinstance(new, dict):
        return {"accept": False, "reason": "invalid_json",
                "old": _metrics(old), "new": _metrics(new)}
    om, nm = _metrics(old), _metrics(new)
    if om["electrical"] and not nm["electrical"]:
        return {"accept": False, "reason": "electrical_empty", "old": om, "new": nm}
    if nm["electrical"] < om["electrical"]:
        return {"accept": False, "reason": "electrical_shrunk", "old": om, "new": nm}
    for c in CONTAINERS:
        if nm[c] < om[c]:
            return {"accept": False, "reason": f"container_lost:{c}",
                    "old": om, "new": nm}
    return {"accept": True, "reason": "", "old": om, "new": nm}


def _metrics(doc) -> dict:
    d = doc if isinstance(doc, dict) else {}
    m = {c: len(_rows(d, c)) for c in CONTAINERS}
    m["electrical"] = len(_rows(d, "electrical"))
    m["absolute_max"] = len(_rows(d, "absolute_max"))
    m["pins"] = len(d.get("pin_configuration") or [])
    return m


def apply_dir(old_dir: str | Path, new_dir: str | Path,
              out_csv: str | Path | None = None) -> dict:
    """逐件守卫；返回汇总。**只读**，不改任何 JSON（回滚由调用方执行）。"""
    old_dir, new_dir = Path(old_dir), Path(new_dir)
    rejects, accepts = [], []
    for np_ in sorted(new_dir.glob("*.json")):
        if np_.name.startswith("_"):
            continue
        mpn = np_.stem.rsplit("_", 1)[0]
        op = old_dir / f"{mpn}.json"
        if not op.is_file():                       # 旧目录按 safe_name 命中
            hits = sorted(old_dir.glob(f"{mpn}*.json"))
            op = hits[0] if hits else None
        try:
            new = json.loads(np_.read_text(encoding="utf-8"))
        except Exception:                                        # noqa: BLE001
            new = None
        old = None
        if op is not None:
            try:
                old = json.loads(Path(op).read_text(encoding="utf-8"))
            except Exception:                                    # noqa: BLE001
                old = None
        r = guard(old, new)
        r["file"] = np_.name
        (accepts if r["accept"] else rejects).append(r)

    if out_csv:
        p = Path(out_csv)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=(
                "file", "accept", "reason", "old_electrical", "new_electrical",
                "old_thermal", "new_thermal", "old_esd", "new_esd"))
            w.writeheader()
            for r in accepts + rejects:
                w.writerow({
                    "file": r["file"], "accept": r["accept"], "reason": r["reason"],
                    "old_electrical": r["old"]["electrical"],
                    "new_electrical": r["new"]["electrical"],
                    "old_thermal": r["old"].get("thermal", 0),
                    "new_thermal": r["new"].get("thermal", 0),
                    "old_esd": r["old"].get("esd", 0),
                    "new_esd": r["new"].get("esd", 0),
                })
    return {"accept": len(accepts), "reject": len(rejects),
            "rejected": [{"file": r["file"], "reason": r["reason"]} for r in rejects]}
