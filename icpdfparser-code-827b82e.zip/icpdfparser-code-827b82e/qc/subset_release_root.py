#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从已验收的装配根里**取子集**，生成新的交付验收根（不重解析、不重归一）。

为什么不是重跑 `stage_release`
------------------------------
`stage_release --normalize` 会重新生成 txt / symbols / seo / pdfs。子集发布包要的是
**与人工审过的那批内容逐字节相同**的物料：重新生成一遍，哪怕结果应当幂等，
也等于把「审的东西」和「发的东西」拆成了两次运行 —— 复核方无法自证两者一致。

本脚本因此只做搬运 + 逐文件哈希核对：
  1. 按型号把 `parsed/ pdfs/ seo/ symbols/ txt/` 的物料复制到新根；
  2. 复制后逐文件比对 SHA-256，不一致立即失败（搬运坏掉比搬错更该拦）；
  3. `_pipeline_stamp.json` / `_stage_report.json` 按型号裁剪，不重写内容；
  4. `signoff.json` 等根级文件按 `--also` 显式指定才带（避免把不属于本批的
     说明文件顺手带进包）。

事实表 (`facts_audit.*` / `risk_queue.csv`) **不搬**：它必须按新范围重算，
否则包里的分母还是剔掉的型号 —— 那正是 `qc/fact_acceptance.py` 的职责。

用法
----
    python qc/subset_release_root.py \
        --src data/staging_batch20_v3_final \
        --out data/staging_batch20_v3_release \
        --mpns LM317,LM358,CDC6CE025000ADLET,CDC6CE025000ADLFR,NE555 \
        --also signoff.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

#: 子目录 → 文件名模式。`txt/` 每件两个文件（正文 + i18n 侧车），故用前缀匹配。
SUBDIRS = ("parsed", "pdfs", "seo", "symbols", "txt")

#: 根级按型号组织的元文件：只裁剪、不重算。
PER_MPN_META = ("_pipeline_stamp.json",)


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _files_for(d: Path, mpn: str) -> list[Path]:
    """该型号在 `d/` 下的全部物料：`MPN.*` 与 `MPN.*.json` 两种命名都算。"""
    if not d.is_dir():
        return []
    return sorted(p for p in d.iterdir()
                  if p.is_file() and (p.name == mpn or p.name.startswith(mpn + ".")))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="从已验收装配根取子集")
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--mpns", required=True, help="逗号分隔（文件名主干口径）")
    ap.add_argument("--also", default="", help="额外复制的根级文件，逗号分隔")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args(argv)

    src, out = Path(a.src), Path(a.out)
    mpns = [x.strip() for x in a.mpns.split(",") if x.strip()]
    if not src.is_dir():
        print(f"源目录不存在：{src}", file=sys.stderr)
        return 2
    if not mpns:
        print("--mpns 为空", file=sys.stderr)
        return 2
    if out.exists():
        if not a.force:
            print(f"{out} 已存在；加 --force 覆盖", file=sys.stderr)
            return 2
        shutil.rmtree(out)

    copied: list[dict] = []
    missing: list[str] = []
    for sub in SUBDIRS:
        (out / sub).mkdir(parents=True, exist_ok=True)
        for m in mpns:
            files = _files_for(src / sub, m)
            if not files:
                missing.append(f"{sub}/{m}")
                continue
            for p in files:
                dst = out / sub / p.name
                shutil.copy2(p, dst)
                copied.append({"rel": f"{sub}/{p.name}", "src_sha256": _sha(p),
                               "dst_sha256": _sha(dst)})

    for name in PER_MPN_META:
        p = src / name
        if not p.is_file():
            continue
        d = json.loads(p.read_text(encoding="utf-8"))
        block = d.get("mpns")
        if isinstance(block, dict):
            d["mpns"] = {k: v for k, v in block.items() if k in mpns}
        (out / name).write_text(
            json.dumps(d, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    for name in (x.strip() for x in a.also.split(",") if x.strip()):
        p = src / name
        if not p.is_file():
            print(f"缺少根级文件：{p}（--also 指定了但源里没有）", file=sys.stderr)
            return 2
        shutil.copy2(p, out / name)

    bad = [c["rel"] for c in copied if c["src_sha256"] != c["dst_sha256"]]
    report = {
        "schema": "subset-root/v1",
        "src": str(src), "out": str(out), "mpns": mpns,
        "files": len(copied), "missing": missing, "mismatch": bad,
        "also": [x.strip() for x in a.also.split(",") if x.strip()],
        "policy": ("只搬运已验收物料并逐文件核对 SHA-256；不重解析、不重归一。"
                   "事实表须另跑 qc/fact_acceptance.py 按新范围重算。"),
    }
    (out / "_subset_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"{len(copied)} 个文件 -> {out}")
    if missing:
        print(f"缺物料（型号/子目录）：{', '.join(missing)}", file=sys.stderr)
    if bad:
        print(f"搬运后哈希不一致：{', '.join(bad)}", file=sys.stderr)
    return 0 if not (missing or bad) else 1


if __name__ == "__main__":
    raise SystemExit(main())
