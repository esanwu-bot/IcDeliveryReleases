# -*- coding: utf-8 -*-
"""v3 ↔ v4 表选择 A/B（只读，零 LLM）。

对每个 MPN：读 JSON + PDF，`scan_tables` + `mark_foreign_tables`，逐条只读复算
`decide_table`（v4）与同一函数的 v3 模式（`MATCH_V4=False`），统计：

    matched / ambiguous / unmatched / foreign   —— 决策层
    patched / unresolved                        —— audit_electrical 写盘层

并输出「误杀面」：v3 matched → v4 非 matched 的条目（含选择的表、分数），
用来判断资格闸门有没有把真电气表挡在门外。

用法：
  python qc/ab_match_v4.py --mpns-file data/_tmp_cohort.txt --out data/_tmp_ab_report.json
"""
from __future__ import annotations

import argparse
import copy
import glob
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import pymupdf as fitz                                    # noqa: E402
from qc import table_audit as TA                          # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def _stem(name: str) -> str:
    return re.sub(r"_[0-9a-f]{8}$", "", Path(name).stem)


def find_json(mpn: str, dirs: list[Path]) -> Path | None:
    safe = re.sub(r"[/#\s]+", "_", mpn)
    best = None
    for d in dirs:
        for raw in glob.glob(str(d / f"{safe}_*.json")):
            p = Path(raw)
            if _stem(p.name) != safe:
                continue
            if best is None or p.stat().st_mtime > best.stat().st_mtime:
                best = p
    return best


def find_pdf(mpn: str) -> Path | None:
    safe = re.sub(r"[/#\s]+", "_", mpn)
    hits = sorted(glob.glob(str(ROOT / "data/pdfs" / f"{safe}__*.pdf")))
    return Path(hits[0]) if hits else None


def counts(entries, tables, v4: bool) -> tuple[Counter, list]:
    old = TA.MATCH_V4
    TA.MATCH_V4 = v4
    c = Counter()
    transitions = []
    try:
        for i, e in enumerate(entries):
            sym = str(e.get("symbol") or "")
            param = str(e.get("name") or e.get("parameter") or "")
            status, info = TA.decide_table(tables, sym, param,
                                           str(e.get("condition") or ""), str(e.get("value", "")))
            c[status] += 1
            tbl = info.get("table") if status in ("matched", "ambiguous_tie", "foreign_part") else None
            transitions.append({
                "i": i, "name": param, "value": str(e.get("value", "")), "status": status,
                "table": (tbl or {}).get("page"), "ti": (tbl or {}).get("ti"),
                "ri": info.get("ri"),
                "gate": bool(TA.table_has_value_roles(tbl)) if tbl else None,
            })
    finally:
        TA.MATCH_V4 = old
    return c, transitions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpns-file", required=True)
    ap.add_argument("--json-dir", action="append", default=[])
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    mpns = [ln.strip() for ln in Path(a.mpns_file).read_text(encoding="utf-8").splitlines()
            if ln.strip() and not ln.startswith("#")]
    dirs = [Path(x) for x in (a.json_dir or [])] or [ROOT / "data/parsed"]
    report, totals = [], Counter()
    falses = []

    for mpn in mpns:
        jp, pp = find_json(mpn, dirs), find_pdf(mpn)
        if not jp or not pp:
            report.append({"mpn": mpn, "missing": {"json": not jp, "pdf": not pp}})
            continue
        doc = json.loads(jp.read_text(encoding="utf-8"))
        entries = ((doc.get("specs") or {}).get("electrical")) or []
        tables = TA.scan_tables(fitz.open(pp))
        TA.mark_foreign_tables(tables, mpn)

        c3, t3 = counts(entries, tables, v4=False)
        c4, t4 = counts(entries, tables, v4=True)

        # 写盘层：audit_electrical 在副本上跑，只统计**新获得** columns 的条目
        orig_cols = {i for i, e in enumerate(entries) if e.get("columns")}

        def audit(entries_src):
            ents = copy.deepcopy(entries_src)
            finds = TA.audit_electrical(ents, tables, "specs.electrical")
            patched = sum(1 for i, e in enumerate(ents)
                          if e.get("columns") and i not in orig_cols)
            unres = sum(1 for f in finds if str(f.get("kind", "")).endswith("unresolved"))
            return patched, unres

        old = TA.MATCH_V4
        TA.MATCH_V4 = False
        try:
            p3, u3 = audit(entries)
        finally:
            TA.MATCH_V4 = old
        TA.MATCH_V4 = True
        try:
            p4, u4 = audit(entries)
        finally:
            TA.MATCH_V4 = old

        trans = []
        for x, y in zip(t3, t4):
            if x["status"] != y["status"] or (x["table"], x["ti"]) != (y["table"], y["ti"]):
                trans.append({"name": x["name"], "v3": x["status"], "v3_table": x["table"],
                              "v4": y["status"], "v4_table": y["table"], "v4_ri": y["ri"],
                              "v4_gate": y["gate"]})
                if x["status"] == "matched" and y["status"] != "matched":
                    falses.append({"mpn": mpn, "name": x["name"], "v3_table": x["table"],
                                   "v4": y["status"]})
        row = {"mpn": mpn, "n": len(entries),
               "v3": {"matched": c3["matched"], "ambiguous": c3["ambiguous_tie"],
                      "unmatched": c3["unmatched"], "foreign": c3["foreign_part"],
                      "patched": p3, "unresolved": u3},
               "v4": {"matched": c4["matched"], "ambiguous": c4["ambiguous_tie"],
                      "unmatched": c4["unmatched"], "foreign": c4["foreign_part"],
                      "patched": p4, "unresolved": u4},
               "diff": trans}
        report.append(row)
        for arm in ("v3", "v4"):
            for k, v in row[arm].items():
                totals[f"{arm}.{k}"] += v
        totals["n"] += len(entries)

    out = {"n_mpns": len(mpns), "totals": dict(totals),
           "false_kills": falses, "rows": report}
    Path(a.out).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"{'mpn':<24}{'n':>5} {'v3 M/A/U/F':>18} {'v3 P/U':>10}   {'v4 M/A/U/F':>18} {'v4 P/U':>10}  diff")
    for r in report:
        if r.get("missing"):
            print(f"{r['mpn']:<24}  MISSING {r['missing']}")
            continue
        v3, v4 = r["v3"], r["v4"]
        print(f"{r['mpn']:<24}{r['n']:>5} "
              f"{v3['matched']}/{v3['ambiguous']}/{v3['unmatched']}/{v3['foreign']:>10}"
              f"  {v3['patched']}/{v3['unresolved']:<6}"
              f" {v4['matched']}/{v4['ambiguous']}/{v4['unmatched']}/{v4['foreign']:>10}"
              f"  {v4['patched']}/{v4['unresolved']:<6} {len(r['diff']):>3}")
    print("\n合计：", dict(totals))
    print(f"误杀（v3 matched → v4 非 matched）：{len(falses)} 条")
    for f in falses[:20]:
        print("  ", f)


if __name__ == "__main__":
    main()
