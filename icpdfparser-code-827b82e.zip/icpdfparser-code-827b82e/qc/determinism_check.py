#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""同一份 PDF 解析两次，核心字段是否**逐字节一致**。

为什么要这个工具
----------------
`qwen-flash` 采样不稳定：同一 PDF、`temperature=0.0`，两次输出的电气表行名
措辞会变（`Sampling Rate - Single Channel Mode` ↔ `Sampling Rate (Single Channel)`），
个别值也会飘（`Power Consumption` 一次 `4.01 W` 一次 `4 W`）。

客户会用 Codex 复跑我们的产物。**不可复现比算错更致命** —— 算错能靠对账发现，
不可复现会让每一次复跑都变成一次新的争论。

处置不是「求模型稳定」（做不到），而是**把结构确定的字段从模型手里拿回来**：
`qc/deterministic_extract.py` 用文本层正则强制抽 pins / thermal / esd / VCMI / VID，
模型只负责剩下难结构化的行。本工具验证这条分工真的成立：

    核心字段（代码抽）→ 必须 byte-identical，不一致 = FAIL
    其余电气行（模型抽）→ 允许漂移，如实计数并列出差异行 = WARN

用法
----
  python qc/determinism_check.py data/_v4run_a data/_v4run_b
  python qc/determinism_check.py data/_v4run_a data/_v4run_b --json out.json
  python qc/determinism_check.py data/_v4run_a data/_v4run_b --strict-elec   # 电气表也要求全等

退出码：0 = 核心字段全等；1 = 有核心字段不一致；2 = 输入不全（缺文件/缺目录）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                    # noqa: E402

#: 核心字段 = 走确定性抽取的那些（见 qc/deterministic_extract.py）。
#: 口径只有一处定义：`DE.core_digest()`。这里**不再自己写一套匹配规则** ——
#: 产物自带的 `metadata.core_sha256` 与本工具算的必须是同一个函数，
#: 否则「我们自证一致」和「客户复跑算出来的」会互相打架。
CORE_KEYS = ("pins", "thermal", "esd", "vcmi_vid")


def _canon(obj) -> str:
    """规范序列化：键排序 + 紧凑分隔符。这是「逐字节一致」的口径。"""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _digest(obj) -> str:
    return hashlib.sha256(_canon(obj).encode("utf-8")).hexdigest()


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _electrical(doc: dict) -> list[dict]:
    return list((doc.get("specs") or {}).get("electrical") or [])


def _norm_name(name: str) -> str:
    """行名归一化，只用于**配对**两边的电气行（不用于判定相等）。

    模型会把 `(Single Channel)` 写成 `- Single Channel Mode`，
    把 `Noiseless Aperture Delay Step` 写成 `Aperture Delay Adjustment Step`。
    归一化只削括号/连字符/常见后缀，不做语义替换 —— 语义对齐靠不了字符串。
    """
    s = str(name or "").lower()
    s = re.sub(r"[\(\)\[\]]", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())


def compare(a: dict, b: dict) -> dict:
    """比对两份解析结果。返回结构化结论，不打印。"""
    rep: dict = {"core": {}, "elec": {}, "ok": True}

    da, db = DE.core_digest(a), DE.core_digest(b)
    for key in CORE_KEYS:
        va, vb = da.get(key) or {}, db.get(key) or {}
        rep["core"][key] = {
            "a": va, "b": vb,
            "same": va.get("sha256") == vb.get("sha256"),
        }
    rep["ok"] = all(v["same"] for v in rep["core"].values())

    # ---- 非核心电气行：允许漂移，但要数清楚漂了多少
    fa, fb = _electrical(a), _electrical(b)
    na = {_norm_name(e.get("name")): e for e in fa}
    nb = {_norm_name(e.get("name")): e for e in fb}
    only_a = sorted(set(na) - set(nb))
    only_b = sorted(set(nb) - set(na))
    val_diff = []
    for k in sorted(set(na) & set(nb)):
        va = {kk: na[k].get(kk) for kk in ("value", "unit", "condition")}
        vb = {kk: nb[k].get(kk) for kk in ("value", "unit", "condition")}
        if _canon(va) != _canon(vb):
            val_diff.append({"name": na[k].get("name"),
                             "b_name": nb[k].get("name"),
                             "a": va, "b": vb})
    rep["elec"] = {
        "a_count": len(fa), "b_count": len(fb),
        "only_a": [na[k].get("name") for k in only_a],
        "only_b": [nb[k].get("name") for k in only_b],
        "value_diff": val_diff,
        "identical": _digest(fa) == _digest(fb),
    }
    return rep


def _pair(dir_a: Path, dir_b: Path) -> list[tuple[Path, Path]]:
    """按文件名配对两边的 JSON（排除 `_summary.csv` 之类非 JSON）。"""
    ja = {p.name: p for p in dir_a.glob("*.json")}
    jb = {p.name: p for p in dir_b.glob("*.json")}
    return [(ja[n], jb[n]) for n in sorted(set(ja) & set(jb))]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="两次解析的核心字段逐字节比对")
    ap.add_argument("dir_a", help="第一次解析输出目录（或单个 JSON）")
    ap.add_argument("dir_b", help="第二次解析输出目录（或单个 JSON）")
    ap.add_argument("--json", dest="json_out", default="", help="把结论写成 JSON")
    ap.add_argument("--strict-elec", action="store_true",
                    help="电气表（模型抽的部分）也要求完全一致")
    args = ap.parse_args(argv)

    pa, pb = Path(args.dir_a), Path(args.dir_b)
    if pa.is_file() and pb.is_file():
        pairs = [(pa, pb)]
    elif pa.is_dir() and pb.is_dir():
        pairs = _pair(pa, pb)
    else:
        print("输入必须是两个目录或两个 JSON 文件", file=sys.stderr)
        return 2
    if not pairs:
        print("两边没有同名 JSON，无法配对", file=sys.stderr)
        return 2

    reports, rc = [], 0
    for fa, fb in pairs:
        rep = compare(_load(fa), _load(fb))
        rep["file"] = fa.name
        reports.append(rep)
        if not rep["ok"]:
            rc = 1
        elif args.strict_elec and not rep["elec"]["identical"]:
            rc = 1

        print(f"\n== {fa.name}")
        for k, v in rep["core"].items():
            mark = "SAME" if v["same"] else "DIFF"
            extra = ""
            if "count" in v.get("a", {}):
                extra = f"  a={v['a']['count']} b={v['b']['count']}"
            print(f"  [core] {k:<10} {mark}{extra}")
        e = rep["elec"]
        drift = len(e["only_a"]) + len(e["only_b"]) + len(e["value_diff"])
        print(f"  [elec] rows a={e['a_count']} b={e['b_count']} "
              f"identical={e['identical']} drift={drift}")
        for n in e["only_a"]:
            print(f"         only in A: {n}")
        for n in e["only_b"]:
            print(f"         only in B: {n}")
        for d in e["value_diff"]:
            # 值相同也要打印条件差异 —— 否则报告里出现「A=1.05 to 1.15 V |
            # B=1.05 to 1.15 V」会被读成误报，实际差在 condition。
            ca = (d["a"].get("condition") or "").strip()
            cb = (d["b"].get("condition") or "").strip()
            print(f"         value: {d['name']} | A={d['a']['value']} "
                  f"{d['a'].get('unit') or ''} | B={d['b']['value']} "
                  f"{d['b'].get('unit') or ''}")
            if ca != cb:
                print(f"                cond A={ca or '(empty)'} | B={cb or '(empty)'}")

    if args.json_out:
        Path(args.json_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json_out).write_text(
            json.dumps({"reports": reports, "rc": rc}, ensure_ascii=False,
                       indent=2) + "\n", encoding="utf-8")
        print(f"\nreport -> {args.json_out}")

    print(f"\n结论：核心字段{'全等' if rc == 0 else '存在差异'}"
          f"（{len(pairs)} 件）；rc={rc}")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
