# -*- coding: utf-8 -*-
"""源文档覆盖率闸门：源里有这张表，JSON 里一行都没有 → 报警。

**为什么现有 `audit_column_collapse` 看不见这个问题**：它的判据是「容器里的行
只取到第一列」，需要容器先有条目才能逐行比对。整张表一行都没抽出来时，
它连比对对象都没有 —— 直接放行（`[]`）。于是「源文档明明有热阻表、最终页面
上一个数字都没有」这种最严重的情况，反而是唯一不被拦的一种。

`ADS1675REF` 是反例，必须留在回归里：它 40 页全文没有 thermal / θ /
junction-to，`specs.thermal=[]` 就是正确结果。**为了追求非空而制造数据，
比缺数据更糟。**

三态，不把「没有」和「不知道」混为一谈
----------------------------------------
========  ==========  ==========================================
源文档    JSON        结论
========  ==========  ==========================================
present   非空        通过
present   空          **high**：`source_container_not_extracted`
absent    空          通过
unknown   空          **review**：`source_container_state_unknown`
========  ==========  ==========================================

`unknown` 单独一态的意义：判不出来时报警会制造噪音（把正文里的热学描述当成
参数表），判通过又会让盲区永远静默。所以只标 review，交给人看。

判据为什么要「结构优先」
------------------------
不能拿「全文出现 thermal / θ」当有表的证据 —— 应用说明、目录、脚注里都会出现。
判定顺序：

1. **表格结构**：`find_tables` 扫出的表里出现 ≥2 个该容器的参数名；
2. **版式兜底**：某页有该容器的段落标题（`Thermal Information`）**且** ≥2 个
   参数名独立成行 —— 纯文本排版的表 `find_tables` 会漏，但这两条一起够硬；
3. 只剩零散关键词 → `unknown`；
4. 关键词一个都没有 → `absent`。

本模块**只读**：不改抽取逻辑、不补参数、不动 `audit_column_collapse`、
不改变任何已有的发布判定。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

PRESENT = "present"
ABSENT = "absent"
UNKNOWN = "unknown"

#: 报警码。**不要**叫 `thermal_missing` —— 那个名字无法区分「源文档没有」与
#: 「有表但没抽到」，而这两件事的处置完全相反（前者通过，后者 must fix）。
CODE_MISSING = "source_container_not_extracted"
CODE_UNKNOWN = "source_container_state_unknown"

#: 各容器「真的是一张参数表」的证据：参数名。**不用裸词 thermal。**
PARAM_TOKENS = {
    "thermal": ("RθJA", "RθJC(top)", "RθJC(bot)", "RθJB", "ψJT", "ψJB"),
    "esd": ("HBM", "CDM", "V(ESD)", "Machine Model"),
}

#: 段落标题（版式兜底用）。
SECTION_HEADERS = {
    "thermal": ("thermal information",),
    "esd": ("esd ratings", "electrostatic discharge"),
}

#: 只用来判断「是不是提到了这个话题」——命中不等于有表，只把 absent 降级成 unknown。
TOPIC_KEYWORDS = {
    "thermal": ("thermal", "junction-to", "°c/w", "θja", "θjc", "ψjt", "ψjb"),
    "esd": ("esd", "electrostatic", "hbm", "cdm"),
}

#: 文本层少于这么多字符就认为「读不到字」（扫描件/纯图）→ unknown。
#: 这种情况下「没找到关键词」不代表「源文档没有」，只是我们看不见。
MIN_TEXT_CHARS = 200

#: 规范化的最小集：去空白与圆括号、大写。与 `deterministic_extract` 同口径，
#: 但**不 import 它** —— 本模块要能在抽取模块改坏时独立给出结论。
_NORM_RE = re.compile(r"[\s()]")


def _norm(s: str) -> str:
    return _NORM_RE.sub("", (s or "")).upper()


def _page_lines(page) -> list[str]:
    return [x.strip() for x in page.get_text().splitlines() if x.strip()]


def _count_params(norms: set[str], token_norms: set[str]) -> set[str]:
    """这一页里出现了哪几个参数名（整行相等，或「参数名 + 描述」同行）。"""
    hit: set[str] = set()
    for tk in token_norms:
        for line in norms:
            if line == tk or line.startswith(tk):
                hit.add(tk)
                break
    return hit


def source_container_state(doc, container: str, *, tables=None,
                           max_pages: int = 80) -> dict:
    """源文档里这个容器是 `present` / `absent` / `unknown`，附证据。

    返回 ``{"state": ..., "pages": [...], "why": "..."}``。`pages` 是 1 基页码。
    """
    tokens = PARAM_TOKENS.get(container, ())
    if not tokens:
        return {"state": UNKNOWN, "pages": [], "why": f"未知容器 {container}"}
    token_norms = {_norm(t) for t in tokens}
    headers = SECTION_HEADERS.get(container, ())
    keywords = TOPIC_KEYWORDS.get(container, ())

    covered = min(doc.page_count, max_pages)

    # 0. 读不到字就别装看得见。
    total_chars = 0
    for pno in range(covered):
        total_chars += len(doc[pno].get_text() or "")
        if total_chars >= MIN_TEXT_CHARS:
            break
    if total_chars < MIN_TEXT_CHARS:
        return {"state": UNKNOWN, "pages": [],
                "why": f"文本层不足 {MIN_TEXT_CHARS} 字符（疑似扫描件），无法判定"}

    # 1. 结构优先：find_tables 见过一张含 ≥2 个该容器参数名的表。
    if tables is None:
        try:
            from qc import table_audit as TA
            tables = TA.scan_tables(doc)
        except Exception:                                  # noqa: BLE001
            tables = []
    for tbl in tables or []:
        cells = {_norm(str(c)) for row in (tbl.get("rows") or []) for c in row}
        hit = {tk for tk in token_norms if any(c == tk or c.startswith(tk) for c in cells)}
        if len(hit) >= 2:
            return {"state": PRESENT, "pages": [tbl.get("page")],
                    "why": f"表格结构里出现 {len(hit)} 个参数名"}

    # 2. 版式兜底：标题 + ≥2 个参数名独立成行（纯文本表 find_tables 会漏）。
    saw_header_pages: list[int] = []
    saw_keyword = False
    for pno in range(covered):
        lines = _page_lines(doc[pno])
        if not lines:
            continue
        low = " ".join(lines).lower()
        if any(h in low for h in headers):
            saw_header_pages.append(pno + 1)
            hit = _count_params({_norm(x) for x in lines}, token_norms)
            if len(hit) >= 2:
                return {"state": PRESENT, "pages": [pno + 1],
                        "why": f"段落标题 + {len(hit)} 个参数名成行"}
        if not saw_keyword and any(k in low for k in keywords):
            saw_keyword = True

    # 3. 只有话题词 → 判不出来（正文提到 ≠ 有参数表）。
    if saw_header_pages or saw_keyword:
        return {"state": UNKNOWN, "pages": saw_header_pages,
                "why": "只命中话题词/标题，没有找到参数表结构"}

    # 4. 一个词都没有 → 确认没有。
    if doc.page_count > covered:
        # 只扫了前 N 页，不能说「确认没有」。
        return {"state": UNKNOWN, "pages": [],
                "why": f"只扫描了前 {covered} 页（共 {doc.page_count} 页），未覆盖全文"}
    return {"state": ABSENT, "pages": [], "why": "全文未出现该容器的任何痕迹"}


def check(spec: dict, state_by_container: dict) -> list[dict]:
    """按三态表出结论。`state_by_container` 形如 `{"thermal": 上面返回的 dict}`。

    单独收状态而不是在内部扫 PDF：扫描要开文件、很慢，调用方往往已经算过一遍
    （`detect` 里就是这么复用的）。这条也让本函数成为**纯函数**，好测。
    """
    specs = (spec or {}).get("specs") if isinstance(spec, dict) else {}
    if specs is None:
        specs = spec if isinstance(spec, dict) else {}
    out: list[dict] = []
    for container, info in (state_by_container or {}).items():
        state = (info or {}).get("state")
        rows = (specs or {}).get(container) or []
        if state == PRESENT and not rows:
            out.append({
                "code": CODE_MISSING,
                "kind": CODE_MISSING,          # 与既有 findings 的字段名对齐，便于合流统计
                "severity": "high",
                "field": container,
                "state": state,
                "pages": (info or {}).get("pages") or [],
                "detail": (f"源文档有 {container} 参数表"
                           f"（{'; '.join((info or {}).get('why', '').split('|'))}），"
                           f"但结构化结果 `specs.{container}` 为空 —— "
                           f"不是「源文档没有」，是抽取遗漏"),
            })
        elif state == UNKNOWN and not rows:
            out.append({
                "code": CODE_UNKNOWN,
                "kind": CODE_UNKNOWN,
                "severity": "review",
                "field": container,
                "state": state,
                "pages": (info or {}).get("pages") or [],
                "detail": (f"{container} 容器判不出有无（{(info or {}).get('why', '')}），"
                           f"且结构化结果为空 —— 需要人工确认，不直接判失败"),
            })
    return out


def run(pdf_path: str | Path, spec: dict, *, containers=("thermal", "esd"),
        max_pages: int = 80) -> list[dict]:
    """开 PDF、逐容器判定、返回 findings（`detect` 侧直接调这个）。"""
    import pymupdf

    states: dict[str, dict] = {}
    with pymupdf.open(str(pdf_path)) as doc:
        tables = None
        try:
            from qc import table_audit as TA
            tables = TA.scan_tables(doc)
        except Exception:                                  # noqa: BLE001
            tables = []
        for c in containers:
            states[c] = source_container_state(doc, c, tables=tables,
                                               max_pages=max_pages)
    return check(spec, states)


def main(argv: list[str] | None = None) -> int:
    import argparse
    import sys

    ap = argparse.ArgumentParser(description="源文档覆盖率闸门（只读）")
    ap.add_argument("--json", required=True, help="待查的结构化结果")
    ap.add_argument("--pdf", required=True, help="对应原版 PDF")
    ap.add_argument("--container", action="append", default=None,
                    help="只查某容器（可重复，默认 thermal + esd）")
    ap.add_argument("--max-pages", type=int, default=80)
    a = ap.parse_args(argv)

    doc = json.loads(Path(a.json).read_text(encoding="utf-8"))
    findings = run(a.pdf, doc, containers=tuple(a.container or ("thermal", "esd")),
                   max_pages=a.max_pages)
    print(json.dumps({"findings": findings, "count": len(findings)},
                     ensure_ascii=False, indent=2))
    return 1 if any(f["severity"] == "high" for f in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
