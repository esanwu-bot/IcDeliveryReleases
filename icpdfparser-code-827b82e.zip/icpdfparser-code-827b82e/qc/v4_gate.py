"""V4 dry-run 的逐件质量门禁：把 228 件判成 PASS / REVIEW / BLOCK，并算安全子集。

为什么要有这一层
----------------
V4 把电气去重签名从「净 −769」翻成「净 +266」，但净增益衡量的是**数量**，
不是内容：3,279 条旧签名被移除、3,545 条新签名加入。旧值未必都错，新值未必都对。
替代型号还净减 50。所以不能用「189 件订货行改善」直接推断可写回数量，
必须逐件判门禁，未解释的差异进人工复核。

门禁判据（全部命中才 PASS）
--------------------------
1. 原件身份一致：`metadata.pdf_hash` == 实际 PDF 的 SHA256，且 == `item.pdf_path` 对应文件
2. 电气去重签名不退化（含持平）
3. 替代型号不减少
4. 订货行不退化
5. 解析成功（status == ok）

掉到旧版 60% 以下或出现未解释的大规模签名更替，即使净增也标记为 REVIEW，
不进安全子集。

只读：不写 parsed / backup / 数据库，只写 --out-dir 下的报告。

用法（容器内）
--------------
    python qc/v4_gate.py --diff /tmp/v4_dryrun/v4_quality_diff.csv \
        --out-dir /tmp/v4_gate
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                              # noqa: E402
from qc.json_merge import merge_doc                        # noqa: E402
from qc.reparse_ordering import _safe                      # noqa: E402

# 签名更替超过这个比例就要求人工复核（净增也可能是换了一批参数）
CHURN_REVIEW_LOST = 20
CHURN_REVIEW_RATIO = 0.5


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _norm_key(s: str) -> str:
    """签名归一化：大小写、空白、异体符号统一。

    为什么需要这一层
    ----------------
    strict 口径把 `VCC = 1.65V, IO = 4mA` 与 `VCC = 1.65 V, IO = 4 mA` 当成
    两个不同条件，于是「写法差异」被报成「参数丢失」。实测
    `74LVC1G3157DRYRG4`：strict 下新旧交集 0 条，归一化后交集 16 条。
    归一化不改变数量判定，但决定「丢了什么」的判断是否正确。
    """
    s = str(s or "").lower()
    for a, b in (("\u2212", "-"), ("\u2013", "-"), ("\u2014", "-"),   # 各种减号
                 ("\u00b5", "u"), ("\u03bc", "u"),                     # 微符号两种编码
                 ("\u03a9", "ohm"), ("\u2126", "ohm"),                 # 欧姆符号
                 ("\u00b0", "deg")):                                   # 度
        s = s.replace(a, b)
    return re.sub(r"\s+", "", s)


def _sig(e: dict, mode: str = "norm") -> tuple:
    g = lambda k: str((e or {}).get(k) or "").strip()
    if mode == "norm":
        return (re.sub(r"\s+", " ", g("name").lower()),
                _norm_key(g("condition")), _norm_key(g("unit")))
    return (g("name").lower(), g("condition").lower(), g("unit").lower())


def _sigs(doc: dict, mode: str = "norm") -> dict:
    out = {}
    for e in ((doc.get("specs") or {}).get("electrical") or []):
        if isinstance(e, dict) and _sig(e, mode)[0]:
            out[_sig(e, mode)] = out.get(_sig(e, mode), 0) + 1
    return out


def _alt_values(doc: dict) -> list[str]:
    out = []
    for a in (doc.get("alternatives") or []):
        if isinstance(a, dict):
            v = str(a.get("mpn") or a.get("model") or a.get("part") or "").strip()
        else:
            v = str(a or "").strip()
        if v:
            out.append(v)
    return out


def _load_attrib(path: str) -> dict:
    """读入 v4_attrib 的签名级归因，按 MPN 汇总 A/B/C/D 计数。

    A 选页截断、B 已入选未抽出、C 页外命中、D 全文无命中。
    A/B 说明差异可归因；C/D 说明旧值本身缺送入模型的证据，只能待核验。
    """
    out: dict = {}
    if not path or not Path(path).exists():
        return out
    for r in csv.DictReader(Path(path).open(encoding="utf-8-sig")):
        if r.get("mode") != "alt" or r.get("kind") != "仅旧":
            continue
        c = (r.get("cause") or "").strip()
        e = out.setdefault(r["mpn"], {"A": 0, "B": 0, "C": 0, "D": 0})
        if c in e:
            e[c] += 1
    return out


def _load_identity(path: str) -> dict:
    """读入 v4_identity_audit 的审计结果，按 MPN 取路径/多文件信息。"""
    out: dict = {}
    if not path or not Path(path).exists():
        return out
    for r in csv.DictReader(Path(path).open(encoding="utf-8-sig")):
        out[r["mpn"]] = r
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V4 dry-run 逐件质量门禁")
    ap.add_argument("--diff", default="/tmp/v4_dryrun/v4_quality_diff.csv")
    ap.add_argument("--tmp-parsed", default="/tmp/v4_dryrun/parsed")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--out-dir", default="/tmp/v4_gate")
    ap.add_argument("--sig-mode", default="norm", choices=["norm", "strict"],
                    help="签名口径：norm 归一化空白与异体符号（默认），strict 原样")
    ap.add_argument("--attrib-csv", default="",
                    help="v4_attrib 的签名级归因 CSV，用于替代型号分层")
    ap.add_argument("--identity-csv", default="",
                    help="v4_identity_audit 的审计 CSV，用于路径歧义判定")
    ap.add_argument("--merged-dir", default="",
                    help="输出合并产物的目录；留空则不产出（只判门禁）")
    a = ap.parse_args(argv)

    tmp = Path(a.tmp_parsed)
    backup = Path(a.backup)
    data_root = Path(a.data_root)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect(data_root / "workbench.sqlite3")
    pdfs = data_root / "pdfs"

    attrib = _load_attrib(a.attrib_csv)
    if a.attrib_csv:
        print("读入替代型号归因 %d 件" % len(attrib))
    ident = _load_identity(a.identity_csv)
    if a.identity_csv:
        print("读入身份审计 %d 件" % len(ident))
    merged_dir = Path(a.merged_dir) if a.merged_dir else None
    if merged_dir:
        merged_dir.mkdir(parents=True, exist_ok=True)
        print("合并产物输出：%s（临时目录，不写生产）" % merged_dir)

    rows = list(csv.DictReader(Path(a.diff).open(encoding="utf-8-sig")))
    print("读入 %d 件" % len(rows))

    gate_rows, alt_rows = [], []
    for r in rows:
        mpn = r["mpn"]

        d = db.execute("SELECT pdf_path, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        db_pdf = Path(d[0].replace("\\", "/")).name if d and d[0] else ""
        db_json = Path(d[1].replace("\\", "/")).name if d and d[1] else ""

        # 旧数据 = 批次前备份。v4_quality_diff.csv 没带备份文件名，按 DB 的
        # json_path 反查；取不到再按 MPN 前缀找。绝不拿已被覆盖的现文件当基线。
        old_name = db_json if db_json and (backup / db_json).exists() else ""
        if not old_name:
            hits = sorted(p.name for p in backup.glob(_safe(mpn) + "_*.json"))
            old_name = hits[0] if hits else ""
        if not old_name:
            print("  [!] 无备份基线：%s" % mpn)
        old = _load(backup / old_name) if old_name else {}
        new = _load(tmp / r["out_file"]) if r.get("out_file") else {}

        # 源身份
        resolved = r.get("resolved_pdf") or ""
        pdf_sha = r.get("pdf_sha256") or ""
        meta_hash = str((new.get("metadata") or {}).get("pdf_hash") or "")[:16]
        db_pdf_matches = "是" if db_pdf == resolved else "否"
        db_json_matches = "是" if db_json and db_json == old_name else "否"

        o_s, n_s = _sigs(old, a.sig_mode), _sigs(new, a.sig_mode)
        # strict 口径只用于对照：看归一化到底纠正了多少「假丢失」
        o_strict, n_strict = _sigs(old, "strict"), _sigs(new, "strict")
        strict_inter = len(set(o_strict) & set(n_strict))
        norm_inter = len(set(o_s) & set(n_s))
        lost = sorted(set(o_s) - set(n_s))
        gain = sorted(set(n_s) - set(o_s))
        o_alt, n_alt = _alt_values(old), _alt_values(new)
        alt_removed = [x for x in o_alt if x.upper() not in {y.upper() for y in n_alt}]
        alt_added = [x for x in n_alt if x.upper() not in {y.upper() for y in o_alt}]

        # ---- 合并验证：写回前必须确认历史字段（尤其 multi_language）不会丢 ----
        # dry-run 的解析结果一定没有 multi_language（运行时未设 ICPDF_LANGS），
        # 直接写回会抹掉旧值，所以合并能否保住它是硬门禁，不是可选项。
        merged, merge_rows, merge_blocked = merge_doc(old, new, mpn)
        if merged_dir:
            (merged_dir / ("%s.merged.json" % _safe(mpn))).write_text(
                json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
        ml_ok = (not old.get("multi_language")) or \
            merged.get("multi_language") == old.get("multi_language")

        i = lambda k: int(r.get(k) or 0)
        o_order, n_order = i("order_old"), i("order_new")
        ac = attrib.get(mpn) or {}
        idr = ident.get(mpn) or {}
        reasons = []
        if r.get("status") != "ok":
            reasons.append("解析未成功")
        if r.get("src_same") == "否":
            reasons.append("原件哈希不一致")
        if db_pdf_matches == "否":
            reasons.append("item.pdf_path 与解析用 PDF 不一致")
        if db_json_matches == "否":
            reasons.append("DB json_path 与备份基线不一致")
        if merge_blocked:
            reasons.append("合并冲突需人工复核")
        if not ml_ok:
            reasons.append("多语言字段未能保留")
        if int(idr.get("sibling_json_n") or 0) >= 2:
            reasons.append("同 MPN 多份 JSON 未消歧")
        if n_order < o_order:
            reasons.append("订货行退化")
        if len(n_s) < len(o_s):
            reasons.append("电气签名退化 %d->%d" % (len(o_s), len(n_s)))
        if len(n_alt) < len(o_alt):
            # 分层：A/B 有明确归因，C/D 是旧值缺证据——两者都不放行，
            # 但标签不同，C/D 走「待核验」而不是「真实退化」。
            if ac.get("A") or ac.get("B"):
                tag = "可归因(A%d/B%d)" % (ac.get("A", 0), ac.get("B", 0))
            elif ac.get("C") or ac.get("D"):
                tag = "旧值缺证据待核验(C%d/D%d)" % (ac.get("C", 0), ac.get("D", 0))
            else:
                tag = "未归因"
            reasons.append("替代型号减少 %d->%d %s" % (len(o_alt), len(n_alt), tag))

        # 复核标记：净增也可能是换了一批
        churn = "否"
        if len(lost) >= CHURN_REVIEW_LOST and len(lost) > len(gain) * CHURN_REVIEW_RATIO:
            churn = "是"
        if len(o_s) and len(n_s) < len(o_s) * 0.6:
            churn = "是"

        gate = "BLOCK" if reasons else ("REVIEW" if churn == "是" else "PASS")
        gate_rows.append({
            "mpn": mpn, "gate": gate, "reasons": "；".join(reasons) or "-",
            "need_review": churn,
            "status": r.get("status"),
            "resolved_pdf": resolved, "pdf_sha256": pdf_sha,
            "meta_pdf_hash": meta_hash, "src_same": r.get("src_same"),
            "db_pdf_path": db_pdf, "db_pdf_matches": db_pdf_matches,
            "json_file": old_name, "db_json_path": db_json,
            "db_json_matches": db_json_matches,
            "order_old": o_order, "order_new": n_order, "order_delta": n_order - o_order,
            "order_hits_request": r.get("order_hits_request"),
            "elec_uniq_old": len(o_s), "elec_uniq_new": len(n_s),
            "elec_delta": len(n_s) - len(o_s),
            "elec_lost": len(lost), "elec_gain": len(gain),
            "elec_ratio": round(len(n_s) / len(o_s), 3) if o_s else "",
            "elec_intersect": norm_inter,
            "strict_intersect": strict_inter,
            "ml_old": "有" if old.get("multi_language") else "无",
            "ml_new": "有" if new.get("multi_language") else "无",
            "ml_kept": ("是" if ml_ok else "否") if old.get("multi_language") else "-",
            "merge_blocked": "；".join(merge_blocked) or "-",
            "alt_cause_A": ac.get("A", 0), "alt_cause_B": ac.get("B", 0),
            "alt_cause_C": ac.get("C", 0), "alt_cause_D": ac.get("D", 0),
            "sibling_json_n": idr.get("sibling_json_n", ""),
            "alt_old": len(o_alt), "alt_new": len(n_alt), "alt_delta": len(n_alt) - len(o_alt),
            "feat_old": len(old.get("features") or []),
            "feat_new": len(new.get("features") or []),
            "feat_delta": len(new.get("features") or []) - len(old.get("features") or []),
            "lost_sample": " ; ".join("|".join(s) for s in lost[:6]),
            "gain_sample": " ; ".join("|".join(s) for s in gain[:4]),
        })

        if len(n_alt) < len(o_alt):
            pdf = pdfs / resolved if resolved else None
            sel = ""
            if pdf and pdf.exists():
                try:
                    import fitz
                    with fitz.open(str(pdf)) as doc:
                        pages = [(k, doc[k].get_text("text") or "")
                                 for k in range(doc.page_count)]
                    text, used, dropped = PD.select_pages(pages)
                    sel = ",".join(str(int(n)) for n in
                                   re.findall(r"--- Page (\d+) ---", text))
                except Exception as e:                       # noqa: BLE001
                    sel = "读取失败 %s" % type(e).__name__
            alt_rows.append({
                "mpn": mpn, "alt_old": len(o_alt), "alt_new": len(n_alt),
                "alt_delta": len(n_alt) - len(o_alt),
                "removed": " | ".join(alt_removed[:10]),
                "added": " | ".join(alt_added[:10]),
                "old_values": " | ".join(o_alt[:12]),
                "new_values": " | ".join(n_alt[:12]),
                "sel_pages": sel, "resolved_pdf": resolved,
                "order_old": o_order, "order_new": n_order,
                "elec_old": len(o_s), "elec_new": len(n_s),
                "gate": gate,
            })

    def dump(name, rs, cols=None):
        p = out_dir / name
        if not rs:
            p.write_text("", encoding="utf-8")
            print("  写 %s（0 行）" % p)
            return
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=cols or list(rs[0].keys()),
                               extrasaction="ignore")
            w.writeheader()
            w.writerows(rs)
        print("  写 %s（%d 行）" % (p, len(rs)))

    from collections import Counter
    cc = Counter(r["gate"] for r in gate_rows)
    print("\n=== 门禁分布 ===")
    for k in ("PASS", "REVIEW", "BLOCK"):
        print("  %-7s %d 件" % (k, cc.get(k, 0)))
    rc = Counter()
    for r in gate_rows:
        for s in r["reasons"].split("；"):
            if s and s != "-":
                rc[s.split(" ")[0]] += 1
    print("\n阻断原因（按首词归类）:")
    for k, v in rc.most_common():
        print("   %-16s %d 件" % (k, v))

    # 归一化对照与多语种保留情况
    ml_keep = sum(1 for r in gate_rows if r["ml_old"] == "有" and r["ml_new"] == "有")
    ml_lose = sum(1 for r in gate_rows if r["ml_old"] == "有" and r["ml_new"] == "无")
    print("\n签名口径：%s ；新旧交集 归一化 %d / strict %d（合计 228 件）"
          % (a.sig_mode, sum(r["elec_intersect"] for r in gate_rows),
             sum(r["strict_intersect"] for r in gate_rows)))
    print("多语种字段：旧有 %d 件，其中新仍保留 %d 件、丢失 %d 件"
          % (sum(1 for r in gate_rows if r["ml_old"] == "有"), ml_keep, ml_lose))

    safe = [r for r in gate_rows if r["gate"] == "PASS"]
    summary = {
        "diff": a.diff, "total": len(gate_rows),
        "gate": dict(cc),
        "safe_subset_n": len(safe),
        "safe_subset_mpn": sorted(r["mpn"] for r in safe),
        "alt_regression_n": len(alt_rows),
        "block_reasons": dict(rc),
        "review_n": cc.get("REVIEW", 0),
        "review_mpn": sorted(r["mpn"] for r in gate_rows if r["gate"] == "REVIEW"),
        "sig_mode": a.sig_mode,
        "ml_old_has": sum(1 for r in gate_rows if r["ml_old"] == "有"),
        "ml_new_has": sum(1 for r in gate_rows if r["ml_new"] == "有"),
        "ml_lost_if_write": ml_lose,
    }
    print("\n=== 产物 ===")
    dump("v4_quality_gate.csv", gate_rows)
    dump("v4_alt_regression.csv", alt_rows)
    dump("v4_safe_subset.csv", safe)
    (out_dir / "v4_gate_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("  写 v4_gate_summary.json")
    print("\n安全子集（无电气退化、无替代型号减少、源身份一致、订货不退化）：%d 件" % len(safe))
    print("替代型号减少：%d 件" % len(alt_rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
