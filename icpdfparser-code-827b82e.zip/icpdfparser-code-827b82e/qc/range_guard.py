# -*- coding: utf-8 -*-
"""`range` 结构的下游守卫 —— 列角色没核验过，就别留一个能读的 `{min,max}`。

为什么要有这一层
----------------
V9 复审 P0-1 的原话是「下游投毒」：`ADS1201U` 的
`Differential Input Voltage Range (With VBIAS)` 那一行，原表是

    Differential Input Voltage Range | With VBIAS(1) | -20 | See Note 2 | +20 | V

`TYP` 格里印的是脚注 `See Note 2`，不是数。JSON 里却写着

    "range": {"min": "-20", "max": "+20"},
    "range_origin": "column_roles_verified"

而同一份包的事实表判 `verified_value` + `missing_cols=min,max`。
于是同一件事有两种状态：**事实表说列角色没定，JSON 说列角色已核验**。
任何读 `range` 的下游都会拿到一个「看起来已核验」的区间 —— 它可能是对的，
但**我方并没有证明它对**，这正是投毒定义。

修法分两层
----------
1. 源头（`qc/deterministic_extract.py`）：`TYP` 列是文字/脚注时，干脆不产出
   `range`，`range_origin` 记 `column_roles_unverified`。
2. 下游（本模块）：读之前必须过 :func:`safe_range`；打包前跑一次
   :func:`enforce` 做**物理抹除**，把历史上的残留清掉。

两者一个是「不再产生」，一个是「产生过的也不许被读」——
只做前者，旧 JSON 照样能被读；只做后者，新数据继续埋雷。
"""
from __future__ import annotations

SCHEMA = "range-guard/v1"

#: 敢声称「这两格就是 MIN/MAX」的来源。
TRUSTED_ORIGINS = frozenset({
    "column_roles_verified",      # 逐格复核过 MIN/TYP/MAX 的位置
    "pdf_columns",                # 从 PDF 表格列直取
    "pdf_columns_with_role",      # 同上且列角色已判
    "pdf_prose_formula",          # 正文公式（`-0.3V to AVDD+0.3V` 这类）
    "derived_from_value",         # 从 `a to b` 字符串里切出来的
})

#: 事实表一旦判到这几种结论，就说明**这一行的证据不到「行/段」级**。
#: 在这个前提下再声称列角色已核验，是自相矛盾。
WEAK_VERDICTS = frozenset({
    "verified_value", "value_on_label_page", "value_in_pdf",
    "partial", "unchecked", "not_found", "container_verified",
})

UNVERIFIED = "column_roles_unverified"


def _verdict(item: dict) -> str:
    v = item.get("verification")
    if not isinstance(v, dict):
        return ""
    return str(v.get("fact_verdict") or "").strip()


def _status(item: dict) -> str:
    """这一行自述的核验状态（`verification.status`）。"""
    v = item.get("verification")
    if not isinstance(v, dict):
        return ""
    return str(v.get("status") or "").strip().lower()


def _missing_cols(row: dict) -> list[str]:
    """事实表记着的「原表印了、这一行没落列」的列名（V9+ / ADS1201U）。

    落点有两种：事实表写进行上的 `missing_cols`，或被同步进
    `verification.missing_cols`。两边都读；空串 / `None` / 只剩逗号都算
    **没有缺列**，不许把「字段不存在」当成「缺了列」。
    """
    if not isinstance(row, dict):
        return []
    raw = row.get("missing_cols")
    if raw in (None, ""):
        ver = row.get("verification")
        raw = ver.get("missing_cols") if isinstance(ver, dict) else None
    return [c.strip() for c in str(raw or "").split(",") if c.strip()]


def is_trusted(item: dict) -> bool:
    """这一行的 `range` 能不能当「已核验的 MIN/MAX」读。"""
    if not isinstance(item, dict):
        return False
    rng = item.get("range")
    if not isinstance(rng, dict):
        return False
    if rng.get("min") in (None, "") or rng.get("max") in (None, ""):
        return False
    origin = str(item.get("range_origin") or "").strip()
    if origin not in TRUSTED_ORIGINS:
        return False
    # V11 P0-2：状态自述 `unresolved` 的行，无论 origin 写什么都不能当正式
    # 区间读 —— 页面已经打了 †，API 却吐出 `{min,max}` 就是契约分裂。
    if _status(item) == "unresolved":
        return False
    # `column_roles_verified` 要的是「列角色被单独核验过」。
    # 事实表把它降成 `verified_value` / `value_on_label_page` 等等，
    # 意思就是「只到坐标，没到列」—— 这时候它还叫 verified 就是撒谎。
    if origin == "column_roles_verified" and _contradicts(item):
        return False
    return True


def safe_range(item: dict) -> dict | None:
    """**读 `range` 的唯一入口**：不可信就返回 `None`，不返回一个打折的区间。

    返回 `None` 而不是 `{"min": "", "max": ""}`：空字符串会被下游拼成
    `" to "` 这种残句，静默得比报错更糟。
    """
    return item.get("range") if is_trusted(item) else None


def _iter_rows(node, path=""):
    """递归找出所有「像规格行」的 dict（带 `range` 键的那些）。"""
    if isinstance(node, dict):
        if "range" in node:
            yield path, node
        for k, v in node.items():
            if isinstance(v, (dict, list)):
                yield from _iter_rows(v, f"{path}/{k}")
    elif isinstance(node, list):
        for i, v in enumerate(node):
            if isinstance(v, (dict, list)):
                yield from _iter_rows(v, f"{path}[{i}]")


def _is_contradiction(row: dict) -> bool:
    """声称「列角色已核验」，事实表却只给了坐标级结论 —— 这才是投毒。

    与 `is_trusted()` 的区别：`is_trusted` 还额外拒收「只有一端的 range」
    （`{"min":"", "max":"26.25"}` 这种单值行），那是**残句**问题不是投毒问题，
    读的时候挡掉就够了，没必要改交付 JSON。
    """
    return _contradicts(row)


def _contradicts(row: dict) -> bool:
    """这一行的 `range` 与它实际掌握的证据是否自相矛盾。

    三条判据，任一条成立即矛盾：

    0. `verification.status=unresolved` —— 页面已经明说「列角色未核验」，
       却还带着能读的 `{min,max}`（V11 P0-2，ADS1201U `Differential Input
       Voltage Range`）。**与 origin 无关**：`derived_from_value` 一样中招。
    1. 事实表只给了坐标级结论（`verified_value` 等）—— 意思就是「只到坐标，
       没到列」，此时还叫 `column_roles_verified` 就是撒谎（V9 P0-1 原判据）。
    2. 事实表记着 `missing_cols` 非空 —— 原表印了 MIN/MAX，这一行没落进列，
       列位是谁根本没定。**与结论强弱无关**：`verified_row` 也能撞上这条
       （ADS1201U：`-20 / See Note 2 / +20`，`missing_cols=min,max`）。
    """
    if _status(row) == "unresolved":
        return True
    if str(row.get("range_origin") or "").strip() != "column_roles_verified":
        return False
    if _verdict(row) in WEAK_VERDICTS:
        return True
    return bool(_missing_cols(row))


def enforce(doc: dict) -> dict:
    """物理抹除**自相矛盾**的 `range`，返回清理报告（就地修改）。

    V11 起扩大到 `verification.status=unresolved` 的任何 origin：这类行只许留
    `unverified_range_candidate`。其余组合仍按最少改写处理 —— 可信的行一个字
    不动，「只有一半的 range」也不动（那是残句问题，读的时候挡）。
    """
    stripped: list[dict] = []
    for path, row in _iter_rows((doc or {}).get("specs") or {}, "/specs"):
        if not _is_contradiction(row):
            continue
        rng = row.pop("range", None)
        if rng is None:
            continue
        if isinstance(rng, dict) and not row.get("unverified_range_candidate"):
            row["unverified_range_candidate"] = rng
        miss = _missing_cols(row)
        if _status(row) == "unresolved":
            why = "verification.status=unresolved"
        else:
            why = f"事实表判 {_verdict(row) or '未判'}"
        if miss:
            why += f"、缺 {'/'.join(miss)} 列"
        why += "，列角色未独立核验"
        row["range_origin"] = UNVERIFIED
        row["range_note"] = (f"{why}；原 `range` 结构已抹除，"
                             f"候选见 `unverified_range_candidate`，勿当 MIN/MAX 读")
        stripped.append({"path": path, "name": str(row.get("name") or ""),
                         "cond": str(row.get("condition") or ""),
                         "had": rng, "why": why})
    return {"schema": SCHEMA, "n_stripped": len(stripped), "stripped": stripped}
