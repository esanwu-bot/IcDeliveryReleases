"""把交付包里的 `multi_language` 回填到被重解析覆盖掉的生产 JSON。

背景
----
`qc/reparse_ordering.py` 用 `parse_pdf()` 的全新 doc 覆盖写文件，`_carry_over()`
只回带 `KEEP_BASIC` / `KEEP_PKG` 两组字段，`multi_language` 不在其中。
2026-10-28 11:12–11:57 的订货重解析因此让 235 个文件（230 个 MPN）丢了四语内容，
而 `parsed_backup_ordering/` 与交付包 `delivery-20261026-i18n/` 都还保有。

范围
----
只做一件事：给生产 JSON **补一个顶层键 `multi_language`**，其余字段一个都不碰。
不重解析、不重翻译、不重渲染、不写数据库。

安全约束（按审阅要求逐条落到代码里）
------------------------------------
1. 范围锁定：必须传 `--plan-csv`（已审阅的逐件清单），不重新筛选；
   `--expect-count` 可把件数再钉死。
2. 备份不静默覆盖：备份目录已有同名文件即整批停止，需 `--overwrite-backup`。
3. 记录 SHA-256：源、备份、新文件三份哈希都写进报告。
4. 备份后再比一次哈希：备份必须与源一致，否则该件失败。
5. 一件失败即整批失败（退出码非 0），不打印"全部成功"。
6. 顶层键守卫：写入前断言 `键集合 = 旧键集合 ∪ {multi_language}`，
   且所有旧键的值深度相等；任何不符即该件不写。
7. 原子写：临时文件 + `os.replace`，不留半截文件。

用法
----
默认是 dry-run（只读、只出报告）：

    python qc/i18n_restore.py --plan-csv plan.csv --delivery-dir /data/delivery \\
        --parsed-dir /app/data/parsed --report-csv /tmp/restore_dryrun.csv

写入生产（需双开关）：

    python qc/i18n_restore.py --plan-csv plan.csv --delivery-dir /data/delivery \\
        --parsed-dir /app/data/parsed --report-csv /tmp/restore.csv \\
        --do-write --i-understand

写后核验：

    python qc/i18n_restore.py --plan-csv plan.csv --delivery-dir /data/delivery \\
        --parsed-dir /app/data/parsed --verify-only
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime, timezone

LANGS = ("ja", "ko", "de", "es")
REQUIRED_LANG_KEYS = ("title", "description", "meta")
OPTIONAL_LIST_KEYS = ("features", "applications")
ML = "multi_language"


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(doc: dict) -> bytes:
    return json.dumps(doc, ensure_ascii=False, indent=2).encode("utf-8")


def load_plan(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = [r for r in csv.DictReader(f) if (r.get("prod_json") or "").strip()]
    for r in rows:
        for k in ("prod_json", "mpn", "delivery_zip", "delivery_member"):
            if not r.get(k):
                raise SystemExit(f"清单缺列 {k}: {r}")
    return rows


def read_delivery_ml(zip_cache: dict, delivery_dir: str, zip_name: str, member: str) -> dict:
    """兼容入口：只要 ml，丢弃软警告。硬错照旧 raise。"""
    return read_delivery_ml_checked(zip_cache, delivery_dir, zip_name, member)[0]


def read_delivery_ml_checked(zip_cache: dict, delivery_dir: str, zip_name: str,
                             member: str) -> tuple[dict, list[str]]:
    """读交付包里的多语言块，返回 ``(ml, warns)``。

    校验分两层，刻意不是同一种处置：

    **硬错（raise）**：`title`/`description`/`meta` 任一为空 —— 这才是真正的空壳。
    写进去等于用一个空标题覆盖原文档，属于把问题从「缺」变成「错」，必须拦。

    **软警告（warns）**：`features`/`applications` **存在但是空列表**。
    这两个是可选字段，**键不存在是合法的**（现有契约与单测都要求三字段件通过），
    所以只有「给了个空数组」才说明上游抽取没抽到东西。
    2026-10-30 实测 172 件里 31 件属此类（集中在 F2800xx 家族），
    但它们四语的 title+description+meta 有 1565~4091 字符，是真内容、不是空壳，
    因此**照常写入**，只把「不完整」显式记进报告，
    避免"写成功了"与"内容完整"被混为一谈。
    """
    zpath = os.path.join(delivery_dir, zip_name)
    zf = zip_cache.get(zpath)
    if zf is None:
        zf = zipfile.ZipFile(zpath)
        zip_cache[zpath] = zf
    doc = json.loads(zf.read(member))
    ml = doc.get(ML)
    if not isinstance(ml, dict) or not ml:
        raise ValueError("交付 JSON 无 multi_language")
    missing = [l for l in LANGS if l not in ml]
    if missing:
        raise ValueError(f"交付 JSON 缺语言 {missing}")
    warns: list[str] = []
    for lang in LANGS:
        body = ml[lang]
        if not isinstance(body, dict):
            raise ValueError(f"{lang} 不是对象")
        lost = [k for k in REQUIRED_LANG_KEYS if not body.get(k)]
        if lost:
            raise ValueError(f"{lang} 缺字段 {lost}")
        for k in OPTIONAL_LIST_KEYS:
            if k not in body:
                continue                    # 可选字段缺键 = 合法，不告警
            if not isinstance(body[k], list):
                raise ValueError(f"{lang}.{k} 不是列表")
            if not body[k]:
                warns.append(f"{k} 为空")
    return ml, warns


def atomic_write(path: str, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".restore_", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def restore_one(row: dict, args, zip_cache: dict) -> dict:
    out = {"prod_json": row.get("prod_json", "").strip(), "mpn": row.get("mpn", ""), "status": "",
           "src_sha256": "", "backup_sha256": "", "new_sha256": "", "langs": "",
           "warn": "", "error": ""}
    try:
        return _restore_one(row, args, zip_cache, out)
    except Exception as exc:  # noqa: BLE001 - 单件异常转为该件失败，保留已采到的哈希
        out.update(status="FAIL", error=f"{type(exc).__name__}: {exc}")
        return out


def _restore_one(row: dict, args, zip_cache: dict, out: dict) -> dict:
    name = row["prod_json"].strip()
    src = os.path.join(args.parsed_dir, name)
    if not os.path.exists(src):
        out.update(status="FAIL", error="生产文件不存在")
        return out

    src_sha = sha256_file(src)
    out["src_sha256"] = src_sha
    with open(src, encoding="utf-8") as f:
        old = json.load(f)
    if old.get(ML):
        out.update(status="SKIP_ALREADY", langs=",".join(sorted(old[ML])))
        return out

    ml, warns = read_delivery_ml_checked(zip_cache, args.delivery_dir, row["delivery_zip"], row["delivery_member"])
    out["langs"] = ",".join(sorted(ml))
    if warns:
        # 4 语 × 2 字段的同类警告压成一条，否则报告里 8 条噪声淹没重点
        out["warn"] = "空列表: " + ",".join(sorted({w.replace(" 为空", "") for w in warns}))

    new = dict(old)
    new[ML] = ml
    if set(new) != set(old) | {ML}:
        out.update(status="FAIL", error="顶层键集合异常")
        return out
    for k, v in old.items():
        if new[k] != v:
            out.update(status="FAIL", error=f"旧键 {k} 被改动")
            return out

    if not args.do_write:
        out["status"] = "PLAN_PARTIAL" if out["warn"] else "PLAN"
        return out

    os.makedirs(args.backup_dir, exist_ok=True)
    bpath = os.path.join(args.backup_dir, name)
    if os.path.exists(bpath) and not args.overwrite_backup:
        out.update(status="FAIL", error="备份已存在（需 --overwrite-backup）")
        return out
    shutil.copy2(src, bpath)
    bsha = sha256_file(bpath)
    out["backup_sha256"] = bsha
    if bsha != src_sha:
        out.update(status="FAIL", error="备份哈希与源不一致")
        return out

    atomic_write(src, dump(new))
    nsha = sha256_file(src)
    out["new_sha256"] = nsha
    with open(src, encoding="utf-8") as f:
        check = json.load(f)
    if not check.get(ML) or set(check) != set(old) | {ML}:
        out.update(status="FAIL", error="写后校验失败")
        return out
    for k, v in old.items():
        if check[k] != v:
            out.update(status="FAIL", error=f"写后 {k} 不一致")
            return out
    out["status"] = "DONE_PARTIAL" if out["warn"] else "DONE"
    return out


def verify_one(row: dict, args) -> dict:
    name = row["prod_json"].strip()
    src = os.path.join(args.parsed_dir, name)
    out = {"prod_json": name, "mpn": row["mpn"], "status": "", "langs": "", "error": ""}
    if not os.path.exists(src):
        out.update(status="FAIL", error="生产文件不存在")
        return out
    try:
        with open(src, encoding="utf-8") as f:
            doc = json.load(f)
    except Exception as exc:  # noqa: BLE001 - 报告需要原始异常
        out.update(status="FAIL", error=f"解析失败 {exc}")
        return out
    ml = doc.get(ML) or {}
    out["langs"] = ",".join(sorted(ml))
    miss = [l for l in LANGS if l not in ml]
    out.update(status="FAIL" if miss else "OK", error=f"缺语言 {miss}" if miss else "")
    return out


def main(argv: list[str] | None = None) -> int:
    if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="回填交付包 multi_language 到生产 JSON（默认 dry-run）")
    ap.add_argument("--plan-csv", required=True)
    ap.add_argument("--delivery-dir", required=True)
    ap.add_argument("--parsed-dir", required=True)
    ap.add_argument("--backup-dir", default="")
    ap.add_argument("--report-csv", default="")
    ap.add_argument("--expect-count", type=int, default=0)
    ap.add_argument("--do-write", action="store_true")
    ap.add_argument("--i-understand", action="store_true")
    ap.add_argument("--overwrite-backup", action="store_true")
    ap.add_argument("--verify-only", action="store_true")
    args = ap.parse_args(argv)

    if args.verify_only and args.do_write:
        raise SystemExit("--verify-only 与 --do-write 不能同时使用")
    if args.do_write and not args.i_understand:
        raise SystemExit("写生产需要同时给出 --do-write --i-understand")

    if args.do_write and not args.backup_dir:
        args.backup_dir = os.path.join(
            os.path.dirname(os.path.abspath(args.parsed_dir)),
            "parsed_backup_i18n_restore_" + datetime.now(timezone.utc).strftime("%Y%m%d"),
        )

    rows = load_plan(args.plan_csv)
    if args.expect_count and len(rows) != args.expect_count:
        raise SystemExit(f"清单 {len(rows)} 件，与 --expect-count {args.expect_count} 不符")

    mode = "verify" if args.verify_only else ("write" if args.do_write else "dry-run")
    print(f"模式 {mode} | 清单 {len(rows)} 件 | parsed {args.parsed_dir}")
    if args.do_write:
        print(f"备份目录 {args.backup_dir}")

    zip_cache: dict = {}
    results = []
    try:
        for row in rows:
            try:
                res = verify_one(row, args) if args.verify_only else restore_one(row, args, zip_cache)
            except Exception as exc:  # noqa: BLE001 - 单件异常不吞，转为该件失败
                res = {"prod_json": row.get("prod_json", ""), "mpn": row.get("mpn", ""),
                       "status": "FAIL", "src_sha256": "", "backup_sha256": "",
                       "new_sha256": "", "langs": "", "error": f"{type(exc).__name__}: {exc}"}
            results.append(res)
            print(f"  {res['status']:<13} {res['prod_json']} {res.get('error','')}")
    finally:
        for zf in zip_cache.values():
            zf.close()

    if args.report_csv:
        fields = ["prod_json", "mpn", "status", "src_sha256", "backup_sha256", "new_sha256",
                  "langs", "warn", "error"]
        with open(args.report_csv, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            w.writerows(results)
        print(f"报告 {args.report_csv}")

    counts: dict[str, int] = {}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    print("汇总 " + " ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    partial = sum(1 for r in results if r["status"].endswith("_PARTIAL"))
    if partial:
        # 不能只说"成功 169 件"——其中 N 件是缺 features/applications 的不完整回填。
        # 数字分开报，读报告的人才不会把"写进去了"当成"内容齐了"。
        print(f"注意：{partial} 件多语言块缺 features/applications（空列表），"
              f"已照常回填但内容不完整，详见报告 warn 列")
    return 0 if not counts.get("FAIL") else 1


if __name__ == "__main__":
    sys.exit(main())
