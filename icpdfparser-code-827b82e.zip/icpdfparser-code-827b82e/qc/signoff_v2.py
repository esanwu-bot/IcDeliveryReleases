#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成/校验 `content-signoff/v2` 签核文件（11 字段 × 逐件）。

为什么要 v2
-----------
v1 只有 `content_approved` 一个布尔值，复核方无法从它回答「谁、何时、依据什么、
接受了哪些风险、放弃了哪些维度」。v2 把这些逐件写死，并给出**可重算**的绑定。

哈希绑定为什么不写 ZIP 的 SHA
-----------------------------
`signoff.json` 在 ZIP 内，ZIP 的 SHA 又由成员内容决定 —— 把它写进自身是**自指死循环**：

* 先打包得 `pre_zip_sha256`，再写进 signoff 重打包 → 最终 ZIP 与内嵌值不符；
* 打包后再改 signoff → ZIP 变了，内嵌值又失效。

所以这里采用**链式绑定**（每一环都能被独立重算，无环）：

    signoff.json  ──含──> facts_audit.json / risk_queue.csv 的 sha256
    manifest.members ──含──> signoff.json 的 sha256
    ZIP           ──含──> 上述全部
    包校验报告.json（ZIP 之外）──含──> ZIP 的 sha256 与每个成员的 sha256

`package_sha256` 因此**只在 ZIP 之外**的副本里有值：`signoff.final.json`（`finalize` 子命令产）。
ZIP 内的那份显式写 `null` + 说明，不假装自己知道自己的哈希。

用法
----
    python qc/signoff_v2.py build    --staging data/staging_batch20_v3_release \
                                     --v1 data/staging_batch20_v3_release/signoff.json \
                                     --out   data/staging_batch20_v3_release/signoff.json
    python qc/signoff_v2.py finalize --pkg data/_delivery_releases/<包名>
    python qc/signoff_v2.py verify   --pkg data/_delivery_releases/<包名>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

SCHEMA = "content-signoff/v2"
#: 算「该维度批准」时认的结论。与 `delivery_bundle.ANCHORED_VERDICTS` 同一口径。
ANCHORED_VERDICTS = ("verified_row", "verified_paragraph", "verified_value")
#: 身份放行集合，与 `delivery_bundle.IDENTITY_APPROVED_STATES` 同一口径。
IDENTITY_OK = frozenset({"IDENTITY_SUPPORTED", "BOARD_CONFIRMED"})
#: 复核方点名要求的 11 个字段。少一个就等于没按契约交付，故用常量锁死。
REQUIRED_FIELDS = ("mpn", "reviewer", "reviewed_at", "decision",
                   "machine_anchor_gate", "risk_accepted", "approved_dimensions",
                   "excluded_dimensions", "evidence_refs", "reason",
                   "package_sha256")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha_norm(p: Path) -> str:
    """文本成员的第二口径：CRLF→LF 归一后哈希（与 `qc/bundle_selfcheck.py` 一致）。

    包里同时存在两种口径不是笔误：ZIP 成员按**原始字节**落盘（复核方 `sha256sum`
    对得上），而自检报告按归一后哈希（`git clone` 在 Windows 上会把 LF 写成 CRLF，
    不归一就会「哈希对、大小不对」地白查一轮）。

    合规文件里出现两个同名不同值的哈希 = 漏洞，所以这里把两口径**分别命名并各给一个值**，
    再声明它们各自对应哪份报告 —— 「不一致」由此变成「可对账」。
    """
    data = p.read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(data).hexdigest()


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _pages_by_label(risk_rows: list[dict], mpn: str) -> dict[str, set[str]]:
    """`label -> 出现的 PDF 页码集合`，只取该型号的行。"""
    out: dict[str, set[str]] = {}
    for r in risk_rows:
        if str(r.get("mpn") or "") != mpn:
            continue
        page = str(r.get("page") or "").strip()
        if not page:
            continue
        out.setdefault(str(r.get("label") or ""), set()).add(page)
    return out


def _split_label(blocked: str) -> str:
    """`RθJA (have=container_verified, need=row_anchor)` -> `RθJA`。"""
    return blocked.split(" (have=")[0].strip()


def _csv_rows(p: Path) -> list[dict]:
    import csv
    with p.open(encoding="utf-8-sig") as f:
        return [dict(r) for r in csv.DictReader(f)]


def build(staging: Path, v1_path: Path, out_path: Path) -> int:
    facts = _load(staging / "facts_audit.json")
    risk_path = staging / "risk_queue.csv"
    risk_rows = _csv_rows(risk_path)
    # 维度划分要的是**逐行**事实（含 `container`），而 `by_kind` 只有 table/prose
    # 两个聚合桶。用错口径会把「electrical 有 121/148 到坐标级」读成「这个维度没批准」，
    # 于是签核人明明逐字段审过，`approved_dimensions` 却是空数组（外审 P1）。
    facts_rows = _csv_rows(staging / "facts_audit.csv")
    v1 = _load(v1_path) if v1_path.is_file() else {}
    v1_mpns = v1.get("mpns") or {}

    facts_sha = _sha(staging / "facts_audit.json")
    facts_norm = _sha_norm(staging / "facts_audit.json")
    risk_sha = _sha(risk_path)
    risk_norm = _sha_norm(risk_path)

    mpns: dict[str, dict] = {}
    for mpn, rec in (facts.get("mpns") or {}).items():
        old = v1_mpns.get(mpn) or {}
        pages = _pages_by_label(risk_rows, mpn)
        blocked = list(rec.get("blocked") or [])
        labels = sorted({_split_label(b) for b in blocked})

        # 逐条 blocked 都要能指到 PDF 页码；指不到的显式写 `page_unresolved`，
        # 不拿一个「看起来合理」的页码凑数。
        ev = []
        for lab in labels:
            pg = sorted(pages.get(lab) or [], key=lambda x: (len(x), x))
            ev.append({"pdf": f"{mpn}.pdf",
                       "container_label": lab,
                       "pages": pg,
                       "count": sum(1 for b in blocked if _split_label(b) == lab),
                       "page_unresolved": not pg})
        # 维度划分**逐容器按事实算**：某容器的每一条都到了坐标级，才算该维度批准。
        # v2 首版用 table/prose 聚合口径，导致 CDC6C 两件的 `approved_dimensions`
        # 是空数组 —— 而它们又 `content_approved=true`，合规上自相矛盾（外审 P1）。
        # 前缀 `container:` 用来和下面的 `electrical_pin_mapping_unverified` 消歧：
        # 前者是「电特性表这一段」，后者是「引脚定义能不能接线」，不是一回事。
        buckets: dict[str, list[str]] = {}
        for r in facts_rows:
            if str(r.get("mpn") or "") != mpn:
                continue
            buckets.setdefault(str(r.get("container") or "unknown"), []).append(
                str(r.get("verdict") or ""))
        approved, excluded = [], []
        for container, verdicts in sorted(buckets.items()):
            anchored = sum(1 for v in verdicts if v in ANCHORED_VERDICTS)
            line = f"container:{container} ({anchored}/{len(verdicts)} anchored)"
            (approved if anchored == len(verdicts) else excluded).append(line)
        # 身份维度不是行级参数，单独按 `identity_state` 记；它在放行集合里才算批准。
        pj = staging / "parsed" / f"{mpn}.json"
        pdoc = _load(pj) if pj.is_file() else {}
        istate = str((pdoc.get("basic_info") or {}).get("identity_state") or "")
        if istate in IDENTITY_OK:
            approved.insert(0, f"identity ({istate})")
        else:
            excluded.insert(0, f"identity ({istate or 'unknown'})")
        pin = "not_recorded"
        pin_reason = ""
        pin_detail = ""
        if pj.is_file():
            pv = (pdoc.get("metadata") or {}).get("pin_validation") or {}
            pin = str(pv.get("status") or "not_recorded")
            pin_reason = str(pv.get("reason") or "")
            # `passed` 在这里的含义是 `actual_count == expected_count`，即**总数对账**
            # 通过；它没有逐脚核对引脚名称与功能。不把这个层次写出来，下游会把
            # `passed` 读成「可以照着接线」，那是最贵的一种误读。
            if pin == "passed":
                a, e = pv.get("actual_count"), pv.get("expected_count")
                if a is not None and e is not None:
                    pin_detail = f"；仅总数对账 actual={a}/expected={e}，未逐脚核对名称与功能"
                else:
                    pin_detail = "；仅总数对账，未逐脚核对名称与功能"
        # 固定的机器可判标识：不管 `pin_validation` 是哪一档，引脚**接线级**可用性
        # 本轮都没拿到，一律进 excluded，别让下游以为「passed 就可以接线」。
        excluded.append(
            "electrical_pin_mapping_unverified "
            f"(pin_validation={pin}" + (f", {pin_reason}" if pin_reason else "")
            + pin_detail + ")")

        # 外审 P1 的硬防线：签了 content_approved 却一个维度都没批，等于「无内容可审」，
        # 在任何审计口径下都读作自相矛盾。宁可在构建期炸掉，也不把矛盾打进包里。
        if not approved:
            raise SystemExit(
                f"{mpn}: content_approved=True 但 approved_dimensions 为空，"
                f"逐容器事实里没有任何维度全数到坐标级（{sorted(buckets)}）。"
                "请先复查 facts_audit.csv 的 container/verdict，不得签空批复。")

        mpns[mpn] = {
            "mpn": mpn,
            "reviewer": old.get("signoff_by") or v1.get("signoff_by") or "wuxiaoxian",
            "reviewed_at": old.get("signed_at") or v1.get("signed_at") or "",
            "decision": "APPROVED_WITH_WARNINGS",
            "machine_anchor_gate": str(rec.get("anchor_gate") or "").upper(),
            "risk_accepted": old.get("waiver") or "",
            "approved_dimensions": approved,
            "excluded_dimensions": excluded,
            "evidence_refs": ev,
            "reason": (
                f"人工逐字段复核 {rec.get('n_rows')} 行后签署：机器侧 "
                f"{len(blocked)} 条未达坐标级门槛（不达标清单见 evidence_refs），"
                "内容与 PDF 逐条对照一致，接受该风险放行内容审批；"
                "机器结论 anchor_gate 保持 blocked 不改。"),
            "package_sha256": None,
            "package_sha256_note": (
                "本文件位于 ZIP 内，ZIP 的 SHA-256 不可能写进它自身（自指）。"
                "最终 ZIP 的哈希见同目录外层 `signoff.final.json` 与 `包校验报告.json#zip_sha256`。"),
            # 与 v1 的兼容键：`delivery_bundle._content_signoff` 读这四个
            "content_approved": True,
            "release_approved": False,
            "signoff_by": old.get("signoff_by") or v1.get("signoff_by") or "wuxiaoxian",
            "signed_at": old.get("signed_at") or v1.get("signed_at") or "",
            "waiver": old.get("waiver") or "",
            "anchor_gate_at_signoff": old.get("anchor_gate_at_signoff") or "blocked",
            "blocked_items": len(blocked),
        }

    doc = {
        "schema": SCHEMA,
        "batch": v1.get("batch") or "",
        "signed_at": v1.get("signed_at") or datetime.now().strftime("%Y-%m-%d"),
        "signoff_by": v1.get("signoff_by") or "wuxiaoxian",
        "scope": v1.get("scope") or "",
        "policy": v1.get("policy") or "",
        "excluded": v1.get("excluded") or {},
        "binding": {
            "scheme": "facts-anchor/v2",
            # 同一份文件在两种口径下有两个哈希，**两个都正确**，只是用途不同：
            #   raw        = ZIP 成员原始字节，复核方直接 `sha256sum` 对得上；
            #   normalized = CRLF→LF 归一，供 `git clone`（Windows 写 CRLF）后比对。
            # 首版只命名了一种却在两处报告里混用，被外审读成「绑定了旧文件」。
            # 命名而非替换，让「不一致」变成「可对账」。
            "facts_audit_sha256_raw": facts_sha,
            "facts_audit_sha256_normalized": facts_norm,
            "risk_queue_sha256_raw": risk_sha,
            "risk_queue_sha256_normalized": risk_norm,
            "hash_convention": {
                "raw": "ZIP 成员原始字节的 sha256（sha256sum 可直接复核）",
                "normalized": "字节流 CRLF→LF 归一后的 sha256（与 包校验报告.json 同口径）",
            },
            "package_sha256": None,
            "note": (
                "链式绑定（无环）：signoff → facts_audit/risk_queue 的哈希；"
                "manifest.members → signoff 的哈希；ZIP → 全部；"
                "包校验报告.json（ZIP 外）→ ZIP 的哈希。"
                "任何一环被改动，下游哈希对不上，可用 `verify` 子命令一键复核。"
                "两份哈希口径并存不是笔误：raw 供 sha256sum 直核，normalized 供 "
                "包校验报告 对账，`verify` 会分别校验两者。"),
        },
        "mpns": mpns,
    }
    missing = [m for m, r in mpns.items()
               if any(k not in r or r[k] in (None, "") and k != "package_sha256"
                      for k in REQUIRED_FIELDS)]
    out_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    print(f"写入 {out_path}：{len(mpns)} 件；字段缺失 {missing or '无'}")
    unresolved = [f"{m}/{e['container_label']}" for m, r in mpns.items()
                  for e in r["evidence_refs"] if e["page_unresolved"]]
    print(f"页码未定位：{unresolved or '无'}")
    return 0


def finalize(pkg: Path) -> int:
    """在 ZIP 之外生成 `signoff.final.json`：把最终 ZIP 的 SHA 写进去。"""
    z = pkg / "part-0001-of-0001.zip"
    shard = pkg / "part-0001-of-0001" / "signoff.json"
    if not z.is_file() or not shard.is_file():
        print("缺 ZIP 或包内 signoff.json", file=sys.stderr)
        return 2
    doc = _load(shard)
    doc["package_sha256"] = _sha(z)
    doc["package_zip"] = z.name
    doc["package_bytes"] = z.stat().st_size
    doc["finalized_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
    # 包内那份改为指路，避免两份内容不一致时读者不知道该信哪个
    doc["binding"]["package_sha256"] = doc["package_sha256"]
    doc["binding"]["note"] += "（本副本在 ZIP 之外，故自指字段有值。）"
    out = pkg / "signoff.final.json"
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"写入 {out}：package_sha256={doc['package_sha256'][:16]}…")
    return 0


def verify(pkg: Path) -> int:
    """三重核对：ZIP 哈希、facts/risk 哈希、manifest 成员哈希。"""
    import zipfile
    z = pkg / "part-0001-of-0001.zip"
    bad: list[str] = []
    if not z.is_file():
        print("缺 ZIP", file=sys.stderr)
        return 2
    zip_sha = _sha(z)
    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        # ZIP 内成员是**相对卷根**的路径（无 `part-0001-of-0001/` 前缀），
        # 分卷目录只是解压出来的落点，两者内容一一对应。
        sign = json.loads(zf.read("signoff.json").decode("utf-8"))
        facts_b = zf.read("facts_audit.json")
        risk_b = zf.read("risk_queue.csv")
    facts_raw = hashlib.sha256(facts_b).hexdigest()
    risk_raw = hashlib.sha256(risk_b).hexdigest()
    facts_norm = hashlib.sha256(facts_b.replace(b"\r\n", b"\n")).hexdigest()
    risk_norm = hashlib.sha256(risk_b.replace(b"\r\n", b"\n")).hexdigest()
    b = sign.get("binding") or {}
    # 两口径**分别**核对：raw 与 normalized 只要有一个对不上就报，绝不用「另一个口径
    # 碰巧能对上」来放行 —— 那正是首版把「绑错文件」掩盖成「口径差异」的路径。
    for key, got, what in (
            ("facts_audit_sha256_raw", facts_raw, "facts_audit.json[raw]"),
            ("facts_audit_sha256_normalized", facts_norm, "facts_audit.json[normalized]"),
            ("risk_queue_sha256_raw", risk_raw, "risk_queue.csv[raw]"),
            ("risk_queue_sha256_normalized", risk_norm, "risk_queue.csv[normalized]")):
        if b.get(key) != got:
            bad.append(f"{what} 哈希与 signoff.binding.{key} 不符"
                       f"（包内 {got[:16]}… / 绑定 {str(b.get(key))[:16]}…）")
    # 包校验报告里的文本成员哈希是 normalized 口径，此处顺带把两份报告对齐
    rep_early = pkg / "包校验报告.json"
    if rep_early.is_file():
        members = (_load(rep_early).get("verified_members") or [])
        for name, want in (("facts_audit.json", facts_norm),
                           ("risk_queue.csv", risk_norm)):
            got_rep = next((str(m.get("sha256") or "") for m in members
                            if str(m.get("member") or "").endswith(name)), "")
            if got_rep and got_rep != want:
                bad.append(f"包校验报告.json 中 {name} 的 sha256 与 ZIP 内实测不符"
                           f"（报告 {got_rep[:16]}… / 实测 {want[:16]}…）")
    # 外层副本（若已 finalize）
    fin = pkg / "signoff.final.json"
    if fin.is_file():
        f = _load(fin)
        if f.get("package_sha256") != zip_sha:
            bad.append("signoff.final.json 的 package_sha256 与实际 ZIP 不符")
    # manifest 成员哈希
    rep = pkg / "包校验报告.json"
    if rep.is_file():
        r = _load(rep)
        if r.get("zip_sha256") and r["zip_sha256"] != zip_sha:
            bad.append("包校验报告.json 的 zip_sha256 与实际 ZIP 不符")
    # 11 字段齐备
    for mpn, rec in (sign.get("mpns") or {}).items():
        miss = [k for k in REQUIRED_FIELDS if k not in rec]
        if miss:
            bad.append(f"{mpn} 缺字段 {miss}")
        if rec.get("decision") != "APPROVED_WITH_WARNINGS":
            bad.append(f"{mpn} decision 不是 APPROVED_WITH_WARNINGS")
        # 空批复 = 自相矛盾（外审 P1），复核侧也要能独立抓到
        if rec.get("content_approved") is True and not (rec.get("approved_dimensions") or []):
            bad.append(f"{mpn} content_approved=True 但 approved_dimensions 为空")
        if not any("electrical_pin_mapping_unverified" in str(x)
                   for x in (rec.get("excluded_dimensions") or [])):
            bad.append(f"{mpn} excluded_dimensions 未声明 electrical_pin_mapping_unverified")
    print(f"ZIP 成员 {len(names)} 个；zip_sha256={zip_sha}")
    print("核对结果：" + ("全部通过" if not bad else "；".join(bad)))
    return 0 if not bad else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="content-signoff/v2 生成与校验")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--staging", required=True)
    b.add_argument("--v1", default="")
    b.add_argument("--out", default="")
    f = sub.add_parser("finalize")
    f.add_argument("--pkg", required=True)
    v = sub.add_parser("verify")
    v.add_argument("--pkg", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "build":
        st = Path(a.staging)
        return build(st, Path(a.v1) if a.v1 else st / "signoff.json",
                     Path(a.out) if a.out else st / "signoff.json")
    if a.cmd == "finalize":
        return finalize(Path(a.pkg))
    return verify(Path(a.pkg))


if __name__ == "__main__":
    raise SystemExit(main())
