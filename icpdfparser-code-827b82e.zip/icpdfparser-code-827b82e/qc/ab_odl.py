"""A/B 对比：同一批 PDF 用两个抽取后端解析后的 QC 质量（只审计，不写回）。

前置（parse_datasheets.py 分别跑出两份 JSON）：
    python parse_datasheets.py --only "MPN1,MPN2,..." --pdf-backend pymupdf        --out-dir data/ab_odl/pymupdf
    python parse_datasheets.py --only "MPN1,MPN2,..." --pdf-backend opendataloader --out-dir data/ab_odl/odl

用法：
    python qc/ab_odl.py --a-dir data/ab_odl/pymupdf --b-dir data/ab_odl/odl
    （可选 --label-a pymupdf --label-b opendataloader，只影响打印与报告字段名）

报告：data/qc/ab_odl/ab_report-<时间戳>.json（逐型号 findings + 汇总）。
"""
from __future__ import annotations

import argparse
import datetime
import json
import sys
from pathlib import Path

try:
    from . import table_audit as TA
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import table_audit as TA

ROOT = Path(__file__).resolve().parent.parent
REPORT_DIR = ROOT / "data" / "qc" / "ab_odl"


def _docs(d: Path) -> dict[str, Path]:
    """{mpn: json 路径}——按去掉 _hash8 后缀的文件名归并，同型号取排序最后一个。"""
    out: dict[str, Path] = {}
    if not d.exists():
        return out
    for p in sorted(d.glob("*.json")):
        if p.name.endswith((".alts.json", ".seo.json", ".pre_audit")) or p.name.startswith("_"):
            continue
        out.setdefault(TA.HASH_SUFFIX.sub("", p.stem), p)
    return out


def _brief(doc: dict) -> dict:
    bi = doc.get("basic_info") or {}
    return {"mpn": bi.get("mpn"), "package": bi.get("package"),
            "confidence": (doc.get("metadata") or {}).get("confidence"),
            "electrical": len(((doc.get("specs") or {}).get("electrical")) or []),
            "pins": len(doc.get("pin_configuration") or [])}


def _audit(json_path: Path, pdf: Path, mpn: str) -> dict:
    doc = json.loads(json_path.read_text(encoding="utf-8"))
    res = TA.audit_json(doc, str(pdf), write=False, requested=mpn)
    kinds: dict[str, int] = {}
    for f in res["findings"]:
        kinds[f["kind"]] = kinds.get(f["kind"], 0) + 1
    return {"brief": _brief(doc), "kinds": kinds,
            "n_findings": len(res["findings"]), "n_unresolved": len(res["unresolved"]),
            "verification": res["verification"],
            "findings": res["findings"]}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a-dir", required=True)
    ap.add_argument("--b-dir", required=True)
    ap.add_argument("--label-a", default="A")
    ap.add_argument("--label-b", default="B")
    a = ap.parse_args()

    da, db = _docs(Path(a.a_dir)), _docs(Path(a.b_dir))
    only_a, only_b = sorted(set(da) - set(db)), sorted(set(db) - set(da))
    common = sorted(set(da) & set(db))
    rows, miss_pdf = [], []
    tot = {"a": {"f": 0, "u": 0, "kinds": {}}, "b": {"f": 0, "u": 0, "kinds": {}}}

    for mpn in common:
        pdf = TA._find_pdf_in(TA.PDFS, mpn) or TA._find_pdf_in(TA.QC_PDFS, mpn)
        if not pdf:
            miss_pdf.append(mpn)
            continue
        ra, rb = _audit(da[mpn], pdf, mpn), _audit(db[mpn], pdf, mpn)
        for side, r in (("a", ra), ("b", rb)):
            tot[side]["f"] += r["n_findings"]
            tot[side]["u"] += r["n_unresolved"]
            for k, n in r["kinds"].items():
                tot[side]["kinds"][k] = tot[side]["kinds"].get(k, 0) + n
        rows.append({"mpn": mpn, "pdf": pdf.name, "a": ra, "b": rb})

    print(f"=== 抽取后端 A/B QC 对比： A={a.label_a}  B={a.label_b}  型号数={len(rows)} ===")
    print(f"{'MPN':<22} {'A find/unres':>13} {'B find/unres':>13} {'A elec/pin':>10} {'B elec/pin':>10}")
    for r in rows:
        ra, rb = r["a"], r["b"]
        print(f"{r['mpn']:<22} {ra['n_findings']:>6}/{ra['n_unresolved']:<6} "
              f"{rb['n_findings']:>6}/{rb['n_unresolved']:<6} "
              f"{ra['brief']['electrical']:>4}/{ra['brief']['pins']:<5} "
              f"{rb['brief']['electrical']:>4}/{rb['brief']['pins']:<5}")
    print(f"合计 A: findings={tot['a']['f']} unresolved={tot['a']['u']}  |  "
          f"B: findings={tot['b']['f']} unresolved={tot['b']['u']}")
    kinds = sorted(set(tot["a"]["kinds"]) | set(tot["b"]["kinds"]))
    if kinds:
        print(f"{'缺陷类':<30} {'A':>4} {'B':>4}")
        for k in kinds:
            print(f"{k:<30} {tot['a']['kinds'].get(k, 0):>4} {tot['b']['kinds'].get(k, 0):>4}")
    for tag, lst in (("仅A目录", only_a), ("仅B目录", only_b), ("缺PDF", miss_pdf)):
        if lst:
            print(f"{tag}: {', '.join(lst)}")

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    rp = REPORT_DIR / f"ab_report-{ts}.json"
    rp.write_text(json.dumps({
        "label_a": a.label_a, "label_b": a.label_b,
        "a_dir": str(Path(a.a_dir)), "b_dir": str(Path(a.b_dir)),
        "total": tot, "rows": rows, "only_a": only_a, "only_b": only_b,
        "missing_pdf": miss_pdf}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"report -> {rp}")


if __name__ == "__main__":
    main()
