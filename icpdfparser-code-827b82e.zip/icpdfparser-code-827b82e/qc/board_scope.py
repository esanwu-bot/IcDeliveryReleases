#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""板卡类参数的**归属**三态：整板 / 板载器件 / 未定。

为什么要拆
----------
`specs.scope` 只能给一个值。BOOST-DRV8711 的用户指南里同时有两类参数：

    Voltage Range                    8.2 to 52 V    External power supply input   ← 整板
    Continuous Current per H-Bridge  4.5 A          Max continuous                ← 板载 DRV8711

一个值盖不住，于是页面把两者印在同一张表里，读者会拿 DRV8711 的 4.5 A 当整板能力
（评审原话：「绝不能让板载芯片参数漏进整板规格」）。

三条判据（全部可重放，不看模型怎么说）
--------------------------------------
1. **源文档是器件数据手册** → 表里每一行都是 `onboard_device`。
   判据：`basic_info.identity` 是板卡类，而 `doc_type == "datasheet"`。
   ADS8568EVM-PDK 挂的是 SBAS543（ADS8568 器件手册），整板的电源/连接器规格
   根本不在那份 PDF 里 —— 这种情况**一行整板参数都没有**，不能假装有。
2. **源文档是用户指南 + 行名/条件命中整板接口词汇** → `board_level`。
   词汇表只收「板子才有的东西」：电源输入、连接器、跳线、开关、指示灯、
   排针、端子、USB、散热、外形尺寸。
3. **命中片内模块词汇**（H 桥 / 栅极驱动 / 电荷泵 / 步进细分）→ `onboard_device`。
   板级判据**先**过一遍：`Power Input Voltage` 里也有 `voltage`，顺序反了会判错。
4. **其余** → `unresolved`。不猜。宁可标未定，也不把器件参数算到板子头上。

输出
----
每行加 **`attribution`**（`board_level` / `onboard_device` / `unresolved`），
并在 `metadata.board_attribution` 里给三组名字 —— 需求方要的是「三个数组」，
页面按 attribution 分组渲染。

为什么键名叫 `attribution` 而不是 `scope`
------------------------------------------
`scope` 是**合同层已经占用的键**（`qc/scope_contract.py`），词表只有
`device` / `board` / `onboard_device` / `unresolved`，而且
`canonical_view()` 会拿它决定这一行**留在主表还是搬进隔离桶**。
第一版把 `board_level` 写进 `row["scope"]`，`normalize_scope()` 不认识
这个词 → 归一成 `unresolved` → `_row_scope()` 判定「与文档 scope 不一致」→
**两行全被搬进 `unresolved_specs`**，BOOST-DRV8711 唯一一条真整板参数
（`Voltage Range 8.2 to 52 V`）就这样从页面上消失了。没有报错，没有告警，
只是表空了。复用别人的键名做另一套词表，代价就是这个。
"""
from __future__ import annotations

import re

#: 板卡类身份（与 `qc/normalize_doc._BOARD_IDENTITIES` 同口径）
BOARD_IDENTITIES = frozenset({"evaluation_board", "reference_design",
                              "module", "board"})

#: 「只有板子才有」的词汇。命中即 `board_level`。
#: 刻意不含 `current` / `voltage` 这种两边都有的词 —— 那会把 DRV8711 的
#: `Continuous Current per H-Bridge` 也判成整板参数。
_BOARD_WORDS = (
    "power input", "input power", "external power", "supply input",
    "input supply", "output voltage", "input voltage", "voltage range",
    "connector", "header", "jumper", "switch", "led", "terminal block",
    "banana", "jack", "usb", "fan", "heatsink", "heat sink",
    "board dimension", "dimensions", "footprint", "mounting hole",
    "current consumption", "quiescent current of the board",
    "boost stage", "buck stage", "onboard led",
)

#: 「只可能是片内模块」的词汇 —— 命中即 `onboard_device`。
#: 与 `_BOARD_WORDS` 互补：BOOST-DRV8711 的
#: `Continuous Current per H-Bridge 4.5 A` 指的是板载 DRV8711 的 H 桥能力，
#: 不命中整板词汇就落进 `unresolved`，读者会以为"不知道算谁的"。
#: 这里只收芯片内部结构名（H 桥 / 栅极驱动 / 电荷泵 / 步进细分），
#: 不收 `current` / `voltage` 这种两边都有的词。
_DEVICE_WORDS = (
    "h-bridge", "h bridge", "full-bridge", "half-bridge", "bridge output",
    "gate drive", "gate driver", "pre-driver", "predriver", "charge pump",
    "microstep", "step angle", "winding current", "coil current",
    "internal reference", "on-chip",
)

_WORD_RE = re.compile("|".join(re.escape(w) for w in _BOARD_WORDS), re.I)
_DEV_RE = re.compile("|".join(re.escape(w) for w in _DEVICE_WORDS), re.I)


def is_board(doc: dict) -> bool:
    bi = doc.get("basic_info") or {}
    return str(bi.get("identity") or "").strip() in BOARD_IDENTITIES


def _row_text(row: dict) -> str:
    return " ".join(str(row.get(k) or "") for k in
                    ("name", "parameter", "symbol", "condition", "conditions"))


def classify_row(row: dict, device_datasheet: bool) -> str:
    """单行归属。`device_datasheet=True` 时一律 `onboard_device`（判据 1）。"""
    if device_datasheet:
        return "onboard_device"
    text = _row_text(row)
    # 整板词汇优先：`Power Input Voltage` 里同时有 `voltage`，但它命中的是
    # `power input`，必须判整板。先查板级再查器件级，顺序不能反。
    if _WORD_RE.search(text):
        return "board_level"
    if _DEV_RE.search(text):
        return "onboard_device"
    return "unresolved"


def apply_board_scope(doc: dict) -> dict:
    """给板卡件的规格行打 `scope`，并写 `metadata.board_attribution`。

    非板卡件直接返回 `{}`：芯片页的每一行本来就是器件参数，没有"归属"问题，
    凭空加一个 `scope: device` 只会让 schema 变宽。
    """
    if not is_board(doc):
        return {}
    bi = doc.get("basic_info") or {}
    doc_type = str(bi.get("doc_type") or "").strip()
    # 判据 1：板卡身份 + 源文件是器件数据手册 → 表里没有整板参数
    device_datasheet = doc_type == "datasheet"

    specs = doc.setdefault("specs", {})
    groups: dict[str, list[str]] = {"board_level": [], "onboard_device": [],
                                    "unresolved": []}
    total = 0
    for container in ("electrical", "absolute_max", "ac_performance",
                      "thermal", "esd"):
        rows = specs.get(container)
        if not isinstance(rows, list):
            continue
        for r in rows:
            if not isinstance(r, dict):
                continue
            scope = classify_row(r, device_datasheet)
            r["attribution"] = scope
            name = str(r.get("name") or r.get("parameter")
                       or r.get("symbol") or "").strip()
            groups[scope].append(f"{container}:{name}" if name else container)
            total += 1

    if not total:
        return {}
    meta = doc.setdefault("metadata", {})
    meta["board_attribution"] = {
        "identity": str(bi.get("identity") or ""),
        "source_doc_type": doc_type or "unknown",
        "rule": ("source_doc_is_device_datasheet" if device_datasheet
                 else "board_interface_vocabulary"),
        "note": ("attribution=unresolved 表示「整板还是板载器件」未能从源文档判定，"
                 "不是数值有问题；与 verification.status=unresolved（列角色未核）"
                 "是两件事。"),
        **{k: v for k, v in groups.items()},
    }
    return {"device_datasheet": device_datasheet,
            "counts": {k: len(v) for k, v in groups.items()}}
