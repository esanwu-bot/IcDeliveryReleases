# -*- coding: utf-8 -*-
"""智能合并：以**旧 JSON 的 electrical 为基底**，把新产物的 thermal/esd 合并进来。

为什么需要它（1102 实测）
------------------------
`BQ79614PAPRQ1`（222 页 / 532k 字符）在 `MAX_PAGES=16 / MAX_CHARS=50000` 的选页预算下，
模型只看到 44k 字符，电气行 57 → 22（丢 56 行，其中 47 行原文找得到）。
选页预算的根因另修（自适应预算），但**存量件不能等**：老电气是人工复核过的资产，
新产物唯一可靠的增量是确定性抽取的 thermal / esd。

口径（只做加法，不做替换）
--------------------------
* `electrical` —— **一律保留旧值**（新值更少或为空都不覆盖）；
* `thermal` / `esd` —— 旧为空时取新；旧非空时保留旧（不覆盖已审计数据）；
* `absolute_max` / `ac_performance` —— 同理：旧空取新，绝不覆盖；
* 写入 `metadata.merge_patch` 记录来源与计数，便于复核方查账。

用法：
    python qc/merge_patch.py --old data/staging_xxx/parsed --new <reparse> \
        --out data/merged --mpns BQ79614PAPRQ1
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

CONTAINERS = ("thermal", "esd")
KEEP_OLD = ("electrical", "absolute_max", "ac_performance")


def merge_docs(old: dict, new: dict) -> tuple[dict, dict]:
    """返回 `(合并后的 doc, 报告)`。**就地不动入参**。"""
    out = copy.deepcopy(old) if isinstance(old, dict) else {}
    old_sp = (old or {}).get("specs") or {}
    new_sp = (new or {}).get("specs") or {}
    sp = out.setdefault("specs", {})

    rep = {"kept_old": {}, "taken_new": {}, "skipped_new": {}}
    for k in KEEP_OLD:
        old_rows = old_sp.get(k) or []
        new_rows = new_sp.get(k) or []
        if old_rows:
            sp[k] = old_rows
            rep["kept_old"][k] = len(old_rows)
            if len(new_rows) < len(old_rows):
                rep["skipped_new"][k] = f"{len(new_rows)} < {len(old_rows)}"
        else:
            sp[k] = new_rows
            rep["taken_new"][k] = len(new_rows)
    for k in CONTAINERS:
        old_rows = old_sp.get(k) or []
        new_rows = new_sp.get(k) or []
        if old_rows:
            sp[k] = old_rows
            rep["kept_old"][k] = len(old_rows)
        else:
            sp[k] = new_rows
            rep["taken_new"][k] = len(new_rows)

    meta = out.setdefault("metadata", {})
    meta["merge_patch"] = {
        "rule": "keep_old_electrical + fill_new_therma_esd/v1",
        "source_old_mpn": str(((old or {}).get("basic_info") or {}).get("mpn") or ""),
        "source_new_mpn": str(((new or {}).get("basic_info") or {}).get("mpn") or ""),
        **rep,
    }
    return out, rep


def _index(d: Path) -> dict[str, Path]:
    out: dict[str, Path] = {}
    for p in sorted(d.glob("*.json")):
        if p.name.startswith("_"):
            continue
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except Exception:                                        # noqa: BLE001
            continue
        mpn = str((doc.get("basic_info") or {}).get("mpn") or "")
        if mpn:
            out[mpn] = p
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="旧电气 + 新 thermal/esd 智能合并")
    ap.add_argument("--old", required=True)
    ap.add_argument("--new", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--mpns", default="", help="逗号分隔；留空 = 新目录里全部")
    a = ap.parse_args(argv)
    old_i, new_i = _index(Path(a.old)), _index(Path(a.new))
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    want = [m.strip() for m in a.mpns.split(",") if m.strip()] or list(new_i)
    n = 0
    for mpn in want:
        if mpn not in old_i or mpn not in new_i:
            print(f"[跳过] {mpn}: old={mpn in old_i} new={mpn in new_i}")
            continue
        old = json.loads(old_i[mpn].read_text(encoding="utf-8"))
        new = json.loads(new_i[mpn].read_text(encoding="utf-8"))
        doc, rep = merge_docs(old, new)
        safe = mpn.replace("/", "_")
        (out / f"{safe}.json").write_text(
            json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
        sp = doc.get("specs") or {}
        print(f"{mpn:<22} elec={len(sp.get('electrical') or [])} "
              f"thermal={len(sp.get('thermal') or [])} "
              f"esd={len(sp.get('esd') or [])}  "
              f"新增={rep['taken_new']}")
        n += 1
    print(f"\n合并 {n} 件 -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
