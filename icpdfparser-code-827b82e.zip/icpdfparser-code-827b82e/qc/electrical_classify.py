#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""electrical 行的来源分类：真电气参数 vs Features 描述。

**为什么不用关键词**：上一版用「含 allow / supports / feature 等动词」判 Features，
在 `Chip enable access time | 5 | ns`、`Output enable to output valid | 8 | ns`
上翻车了——这两个是标准时序参数，`enable` 在这里是名词「使能」（chip enable /
output enable 是信号名），和 Features 里的动词 `allow` 完全是两回事。
`enable`/`select`/`output` 在参数名和特性描述里都高频出现，**词表没有极性可分**。

改用**可测量特征**：真电气参数必然有「可测量的值」（unit + 数值），
Features 条目只有「特性描述」。抓住这一点就不需要任何关键词。

分类（只对 ECHO_NAME / FEATURE_DESCRIPTION 报警）：
  REAL_ELECTRICAL       — 有 unit 且 value 含数值 → 明确是参数，不报警
  ECHO_NAME             — value 回灌 name → 报警（DAC37J84 的典型形态）
  FEATURE_DESCRIPTION   — value 是长描述句（>40 且无数字）→ 报警
  INSUFFICIENT_EVIDENCE — 证据不足 → **不报警**（宁可漏检，不可假阳）

**已知盲区（本模块识别不了，不要指望它）**：抓不到「无依据编数」。
AFE4490RHAT 的 v1 产物把 Power Dissipation 抽成 `2.3 mW`，而 PDF 真值是
`2.84 mW`——模型在看不到 p14 的情况下自己编了个像样的数。这行有 unit、
有数值、不回灌、非描述句，本模块会判 `REAL_ELECTRICAL`，一条判据都抓不到。

识别它需要回答「**这个数在模型看到的上下文里有没有原文出处**」，那必须有
上下文可查——`qc/prompt_dryrun.py::_ctx_lookup` 正是做这件事的，本模块
的行级判据拿不到上下文，结构上做不到。要补这条检测，得把上下文传进来
（或另起一个带上下文的审计入口），**当前未实现**。

用法：
    from qc.electrical_classify import classify_electrical_row, ALARM_CLASSES
"""
from __future__ import annotations

import re

from qc.sentinels import BLANK_SENTINELS

REAL_ELECTRICAL = "REAL_ELECTRICAL"
ECHO_NAME = "ECHO_NAME"
FEATURE_DESCRIPTION = "FEATURE_DESCRIPTION"
INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"

ALARM_CLASSES = (ECHO_NAME, FEATURE_DESCRIPTION)

_NUM_RE = re.compile(r"[±+\-]?\d")
_WS = re.compile(r"[^a-z0-9]+")

DESC_MIN_LEN = 40                                            # 判定「描述句」的长度门槛


def _norm(s) -> str:
    return _WS.sub(" ", str(s or "").lower()).strip()


def has_measurable_characteristics(row: dict) -> bool:
    """真电气参数的强特征：**有 unit 且 value 含数值**。

    这条优先于一切负向判据——只要成立就直接判真参数，不管 name 长什么样。
    `Chip enable access time` 因为有 `ns` + `5`，根本进不了负向分支。
    """
    if not isinstance(row, dict):
        return False
    unit = str(row.get("unit") or "").strip()
    value = str(row.get("value") or "").strip()
    if unit.lower() in BLANK_SENTINELS or value.lower() in BLANK_SENTINELS:
        return False
    if not unit or not value:
        return False
    return bool(_NUM_RE.search(value))


def _is_echo_name(name: str, value: str) -> bool:
    """value 回灌 name（或互为子串）。"""
    if not name or not value or len(value) < 3:
        return False
    return value == name or value in name or name in value


def _is_description_sentence(text: str) -> bool:
    """长描述句：长度超过门槛且不含数字。"""
    if not text or len(text) <= DESC_MIN_LEN:
        return False
    return not _NUM_RE.search(text)


def classify_electrical_row(row: dict) -> str:
    """给单条 electrical 行定类。见模块 docstring 的四类语义。"""
    if not isinstance(row, dict):
        return INSUFFICIENT_EVIDENCE
    name = str(row.get("name") or "").strip()
    value = str(row.get("value") or "").strip()

    # ---- 优先判真电气：有可测量特征就放行，不看 name/关键词 ----
    if has_measurable_characteristics(row):
        return REAL_ELECTRICAL

    # ---- 没有可测量特征，才走负向判据 ----
    if _is_echo_name(name, value):
        return ECHO_NAME
    # 只按 **value** 判描述句，不看 name 长度。
    # 实测：`Performance, Total integrated noise current, ...`（AFE4490RHAT）
    # 的 name 有 50+ 字符，但那是真参数——v2 只是把 section 前缀带进了名字
    # （v1 同一行叫 `Total Integrated Noise Current`，值 1.2 nARMS）。
    # 同理 v1 里 `Wideband Digital Quadrature Modulator Correction`（value 空）
    # 也是真参数名。**name 长 ≠ Features 描述**。
    if _is_description_sentence(value):
        return FEATURE_DESCRIPTION

    # 无 unit、value 无数值、name/value 也都不长：
    # 可能是抽坏的参数，也可能是 legit 但缺 unit 的行——证据不足，不报警。
    return INSUFFICIENT_EVIDENCE


def audit_electrical_rows(doc: dict) -> list[dict]:
    """整件审计，返回需要报警的行（含索引与证据）。"""
    rows = ((doc or {}).get("specs") or {}).get("electrical") or []
    out: list[dict] = []
    for i, r in enumerate(rows):
        cls = classify_electrical_row(r)
        if cls not in ALARM_CLASSES:
            continue
        out.append({
            "index": i,
            "sub_class": cls,
            "name": str((r or {}).get("name") or "")[:80],
            "value": str((r or {}).get("value") or "")[:80],
            "unit": str((r or {}).get("unit") or "")[:20],
            "condition": str((r or {}).get("condition") or "")[:80],
        })
    return out
