"""原厂证据链自动化 E1–E4：机器起草全链路，人工一键确认。

边界（先钉死）：`identity=verified` / 字段 `verified` / `freeze` **只能人工写**。
本模块只做「机器起草」——把可定位的证据（页/表/行/列/原文 quote/三向比对/冻结就绪度）
准备好，人工从「找 + 录」变成「看 + 点」。

  E1 文档登记(自动)   sha256 / 页数 / 文本层 / 官方域 → tier=P0|P1
  E2 身份预检(自动出报告)  封面标题 + Ordering literal + 后缀 + SHA 一致性 → 绿/黄/红
  E3 字段证据定位(自动起草)  每个 Gold 字段 → page/table/row/col/quote（候选 ≤5）
  E4 三向比对(自动标冲突)   quote vs Gold expected vs parsed → ready/conflict_draft

quote 来源纪律：**只从 P0 原厂 PDF 字节确定性抽取**（fitz search_for + 表格单元格原文）；
无文本层 → `ocr_pending`（不造证据）；多候选 → `ambiguous` 交人工选，**不自动取第一个**。

自包含：不 import qc.table_audit（它有模块级 stdout 包装），路径解析用 qc/goldset.py。
import 零 stdout 副作用；CLI 才打印。

用法：
  python qc/evidence_chain.py --mpn BUF634PG4 --stage all --dry
  python qc/evidence_chain.py --mpn BUF634PG4 --stage e3
  python qc/evidence_chain.py --mpn BUF634PG4 --stage all          # 落草稿
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from qc import evidence_verify as EV        # noqa: E402  （纯函数 + 迁移工具）
from qc import source_evidence as SE        # noqa: E402

NUM = re.compile(r"[±+-]?\d+(?:[.,]\d+)?")
REV_RE = re.compile(r"\bRev(?:ision)?[\s:.]+\s*([A-Z][0-9]?|[0-9]+(?:\.[0-9]+)?)\b")
MAX_PAGES = 60          # 单件扫描页上限（大 datasheet 保护）
CAND_CAP = 5


def _norm(v) -> str:
    return re.sub(r"\s+", "", str(v or "")).lower()


def _json_doc(mpn: str) -> dict | None:
    try:
        from qc import goldset
        loc = goldset.locate(mpn)
        if loc and loc.get("json"):
            return json.loads(Path(loc["json"]).read_text(encoding="utf-8"))
    except Exception:                                            # noqa: BLE001
        pass
    return None


def _pdf(mpn: str):
    try:
        from qc import goldset
        return (goldset.locate(mpn) or {}).get("pdf")
    except Exception:                                            # noqa: BLE001
        return None


def _manufacturer(db, mpn: str) -> str:
    g = db.q1("SELECT manufacturer FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    if g and (g.get("manufacturer") or "").strip():
        return g["manufacturer"].strip()
    doc = _json_doc(mpn) or {}
    return ((doc.get("basic_info") or {}).get("manufacturer") or "").strip()


def _source_url(db, mpn: str) -> str:
    """从 item / doc_source 找该型号下载链接（有则用于官方域名判定）。"""
    for sql, args in (("SELECT url FROM doc_source WHERE mpn_key=? OR url LIKE ? LIMIT 1",
                       (mpn, f"%{mpn}%")),
                      ("SELECT pdf_url FROM item WHERE mpn=? LIMIT 1", (mpn,))):
        try:
            r = db.q1(sql, args)
            if r:
                v = next((x for x in r.values() if x and str(x).startswith("http")), "")
                if v:
                    return str(v)
        except Exception:                                        # noqa: BLE001
            continue
    return ""


def _revision(pdf: Path) -> str:
    try:
        import fitz
        with fitz.open(pdf) as dz:
            txt = "".join(dz[i].get_text() for i in range(min(2, dz.page_count)))
            if dz.page_count:
                txt += dz[dz.page_count - 1].get_text()
        m = REV_RE.search(txt)
        return m.group(1) if m else ""
    except Exception:                                            # noqa: BLE001
        return ""


def _text_layer(pdf: Path) -> bool:
    try:
        import fitz
        with fitz.open(pdf) as dz:
            for i in range(min(3, dz.page_count)):
                if len(dz[i].get_text().strip()) > 40:
                    return True
        return False
    except Exception:                                            # noqa: BLE001
        return False


# ---------------------------------------------------------------- E1 文档登记
def e1_register(db, mpn: str, dry: bool = False) -> dict:
    pdf = _pdf(mpn)
    if not pdf or not Path(pdf).is_file():
        return {"stage": "e1", "ok": False, "why": "pdf 缺失"}
    pdf = Path(pdf)
    mfr = _manufacturer(db, mpn)
    url = _source_url(db, mpn)
    sha = SE.sha256_file(pdf)
    insp = SE.inspect_pdf(pdf, url, mfr)
    official = bool(insp.get("is_official"))
    text_layer = _text_layer(pdf)
    rev = _revision(pdf)
    rep = {"stage": "e1", "ok": True, "sha256": sha, "pages": insp.get("page_count"),
           "text_layer": text_layer, "url": url, "manufacturer": mfr,
           "tier": "P0" if official else "P1", "revision": rev,
           "official_domain": official}
    if not dry:
        ev = SE.create_evidence(mpn, mfr, [], "machine", db)
        r = SE.add_document(ev, rep["tier"], url, str(pdf), "datasheet_pdf", "machine", db)
        db.x("UPDATE source_document SET document_revision=? WHERE id=?", (rev, r["document_id"]))
        rep["evidence_id"] = ev
        rep["document_id"] = r["document_id"]
        if not text_layer:
            # 无文本层：不造证据，整卡置 unresolved（走 OCR 支线）
            SE.set_evidence_status(ev, "source_unresolved",
                                   "无文本层：quote 无法确定性抽取，走 OCR 支线", "machine", db)
            rep["no_text_layer"] = True
    return rep


# ---------------------------------------------------------------- E2 身份预检
def e2_precheck(db, ev_id: int, mpn: str, dry: bool = False) -> dict:
    pdf = _pdf(mpn)
    if not pdf:
        return {"stage": "e2", "ok": False, "why": "pdf 缺失"}
    import fitz
    checks: dict = {}
    with fitz.open(pdf) as dz:
        p0 = re.sub(r"\s", "", dz[0].get_text().upper())
        fam = re.sub(r"[^A-Z0-9]", "", mpn.upper())[:6]
        checks["cover_title"] = fam in p0
        checks["cover_manufacturer"] = "TEXASINSTRUMENTS" in p0 or "ANALOGDEVICES" in p0
        lit, lit_page = False, None
        for pno in range(min(dz.page_count, MAX_PAGES)):
            for t in dz[pno].find_tables().tables:
                rows = t.extract() or []
                if any(_norm(c) == _norm(mpn) for row in rows for c in (row or [])):
                    lit, lit_page = True, pno + 1
                    break
            if lit:
                break
        checks["ordering_literal"] = lit
        tail = "".join(dz[i].get_text() for i in
                       range(max(0, dz.page_count - 3), dz.page_count)).upper()
        checks["suffix_in_addendum"] = (mpn.upper()[-6:] in re.sub(r"\s", "", tail)) \
            if len(mpn) > 6 else None
        checks["text_layer"] = _text_layer(Path(pdf))
    checks["sha_match_gold"] = _sha_match_gold(db, mpn, ev_id)
    vals = [v for v in checks.values() if v is not None]
    verdict = "green" if all(vals) else ("red" if not checks["ordering_literal"] else "yellow")
    rep = {"stage": "e2", "checks": checks, "verdict": verdict, "ordering_page": lit_page,
           "note": "预检只出报告：identity=verified 必须人工确认（覆盖型号由人工填写）"}
    if not dry:
        db.x("UPDATE source_evidence SET precheck_json=? WHERE id=?",
             (json.dumps(rep, ensure_ascii=False), ev_id))
        SE._log(db, ev_id, 0, "precheck", "machine",
                details={"verdict": verdict, "checks": checks})
    return rep


def _sha_match_gold(db, mpn: str, ev_id: int) -> bool | None:
    g = db.q1("SELECT pdf_sha256 FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    e = db.q1("SELECT d.pdf_sha256 s FROM source_document d JOIN source_evidence ev "
              "ON ev.document_id=d.id WHERE ev.id=?", (ev_id,))
    if not g or not e:
        return None
    gs, es = (g.get("pdf_sha256") or ""), (e.get("s") or "")
    if not gs or not es:
        return None
    return gs == es


# ---------------------------------------------------------------- E3 字段证据定位
def e3_locate(db, ev_id: int, mpn: str, dry: bool = False, cap: int = CAND_CAP) -> dict:
    pdf = _pdf(mpn)
    if not pdf:
        return {"stage": "e3", "ok": False, "why": "pdf 缺失"}
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    if not gold:
        return {"stage": "e3", "ok": False, "why": "无 Gold"}
    fields = db.q("SELECT * FROM gold_field WHERE gold_id=? ORDER BY id", (gold["id"],))
    hints = _audit_hints(mpn)
    import fitz
    out, n_loc, n_amb, n_miss = [], 0, 0, 0
    with fitz.open(pdf) as dz:
        tcache: dict = {}
        for f in fields:
            cands = _value_search(dz, tcache, f, hints.get(f["field_path"]))
            if len(cands) == 1:
                status = "ready"
            elif len(cands) > 1:
                status = "ambiguous"
            else:
                status = "ocr_pending"
            top = cands[0] if cands else None
            n_loc += 1 if top else 0
            n_amb += 1 if status == "ambiguous" else 0
            n_miss += 0 if top else 1
            out.append({"field_id": f["id"], "path": f["field_path"], "status": status,
                        "locator": top, "candidates": cands[:cap]})
            if not dry and top:
                _upsert_field_ev(db, ev_id, f, top, cands[:cap], status)
    return {"stage": "e3", "located": n_loc, "ambiguous": n_amb, "missing": n_miss,
            "fields_total": len(fields), "fields": out}


def _audit_hints(mpn: str) -> dict:
    """吃 table_audit 已算过的定位（不重算）：metadata.audit.findings[].source{page}。"""
    doc = _json_doc(mpn) or {}
    try:
        fl = (((doc.get("metadata") or {}).get("audit") or {}).get("findings")) or []
        return {f["path"]: (f.get("source") or {}) for f in fl
                if isinstance(f, dict) and f.get("path")}
    except Exception:                                            # noqa: BLE001
        return {}


# ---------------------------------------------------------------- E3 值定位守卫
# 事故背景（2026-10-27，BUF634PG4 `specs.package.type`）：
#   expected="SOIC-8" 的数字变体被 NUM 抽成 **"-8"**（连字符被当成负号，长度 2 过门槛），
#   在归一化文本里命中图号 "Figure 6-8"，机器于是把图注当封装证据。
# 三条守卫（只收紧“值命中”，不改候选上限、不自动取舍）：
#   G1 数字变体先剥符号，再按**位数**设门槛（<2 位不进候选，"8" 不会命中 "6-8"）；
#   G2 纯数字必须落在**独立数字 token**上：前不接数字/小数点，后不接数字/小数点，
#      也不接在区间写法（`1-25`）尾部；
#   G3 文本行候选要求行内至少 MIN_LINE_LEN 个字符（裸 "8" 无上下文，不算证据）。
MIN_NUM_DIGITS = 2
MIN_SUB_LEN = 4
MIN_LINE_LEN = 3
MIN_STRUCT_CELL = 16          # 结构字段：长单元格里的纯数字命中不算证据（`–20 mA` 句子）
_DASHES = "-\u2013\u2014\u2212"
_NUM_ONLY = re.compile(r"\d+(?:\.\d+)?")


def _cell_hits(nc: str, variants, structural: bool) -> list:
    """单元格命中：结构字段的长单元格只认**非纯数字**变体（防短数字落在整句里）。"""
    hits = [v for v in variants if _match(nc, v)]
    if structural and len(nc) > MIN_STRUCT_CELL:
        hits = [v for v in hits if not _NUM_ONLY.fullmatch(v)]
    return hits


def _variants(val) -> set:
    """expected → 归一化变体集合（全串 + 数字串）；数字串剥符号、按位数设门槛。"""
    s = str(val or "").strip()
    out = set()
    full = _norm(s)
    if full:
        out.add(full)
    m = NUM.search(s)
    if m:
        num = m.group(0).replace(",", "").lstrip("+-±\u2212")
        if len(re.sub(r"\D", "", num)) >= MIN_NUM_DIGITS:
            out.add(_norm(num))
    return out


def _match(norm_text: str, v: str) -> bool:
    """归一化文本是否命中变体：纯数字走 token 边界，字符串做长度受限的子串。"""
    if not norm_text or not v:
        return False
    if norm_text == v:
        return True
    if re.fullmatch(r"\d+(?:\.\d+)?", v):
        if len(v.replace(".", "")) < MIN_NUM_DIGITS:
            return False
        pat = (r"(?<![\d.])" r"(?<!\d[" + re.escape(_DASHES) + r"])"
               + re.escape(v) + r"(?![\d.])")
        return re.search(pat, norm_text) is not None
    return len(v) >= MIN_SUB_LEN and v in norm_text


def _value_search(dz, tcache: dict, field: dict, hint=None) -> list:
    """在 PDF 里找 expected 值的单元格/行原文：候选 ≤CAND_CAP，不自动取舍。

    先扫**表格单元格**（结构化、可给出行列）；无命中则回退到**文本行**
    （很多 datasheet 参数在正文/分栏而非表格里，table=-1 表示非表格行）。
    误抓守卫见上方 G1–G3：图号/页眉/裸数字不会成为候选。
    **G4 结构字段（封装/引脚）只认表格单元格**：这两类值常是短数字（8/20），
    文本行里任意数字（如电流 `–20 mA`）都会命中，宁缺勿错 → ocr_pending 交人工。
    """
    val = field.get("expected")
    if val in (None, ""):
        return []
    variants = _variants(val)
    if not variants:
        return []
    fp = str(field.get("field_path") or "")
    structural = fp.startswith("specs.package") or re.match(r"^(pin|pin_configuration)\[", fp)
    order = list(range(min(dz.page_count, MAX_PAGES)))
    if hint and hint.get("page"):
        hp = int(hint["page"]) - 1
        order = [hp] + [p for p in order if p != hp]
    text_cands: list = []
    for pno in order:
        page = dz[pno]
        ptext = page.get_text()
        if not any(v in _norm(ptext) for v in variants):     # 快速预筛：本页无此值
            continue
        tabs = tcache.setdefault(pno, [t.extract() for t in page.find_tables().tables])
        cands: list = []
        for ti, rows in enumerate(tabs):
            for ri, row in enumerate(rows or []):
                for ci, cell in enumerate(row or []):
                    if not cell:
                        continue
                    nc = _norm(cell)
                    if nc and _cell_hits(nc, variants, structural):
                        cands.append({"page": pno + 1, "table": ti, "row": ri, "col": ci,
                                      "quote": re.sub(r"\s+", " ", str(cell)).strip()})
                        if len(cands) >= CAND_CAP:
                            return cands
        if cands:
            return cands
        if structural:
            continue                                      # G4：结构字段不取文本行兜底
        for line in ptext.splitlines():                       # 文本行兜底（table=-1）
            nl = _norm(line)
            if len(nl) < MIN_LINE_LEN:
                continue                                      # 裸 "8"/"—" 无上下文，不作证据
            if any(_match(nl, v) for v in variants):
                text_cands.append({"page": pno + 1, "table": -1, "row": 0, "col": 0,
                                   "quote": re.sub(r"\s+", " ", line).strip()})
                if len(text_cands) >= CAND_CAP:
                    return text_cands
        if text_cands:
            return text_cands
    return text_cands


def _upsert_field_ev(db, ev_id: int, field: dict, top: dict, cands: list, status: str) -> None:
    """幂等：同 evidence+field_path 已存在则更新（保留人工 reviewer/verified 不动）。"""
    exist = db.q1("SELECT id, reviewer FROM source_field_evidence WHERE evidence_id=? "
                  "AND field_path=?", (ev_id, field["field_path"]))
    cj = json.dumps(cands, ensure_ascii=False)
    if exist:
        if (exist.get("reviewer") or "").strip():
            return                                        # 人工已处置，机器不覆盖
        db.x("UPDATE source_field_evidence SET page_number=?, evidence_quote=?, "
             "candidates_json=?, verification_status=?, table_name=?, row_key=?, column_key=? "
             "WHERE id=?",
             (int(top["page"]), top.get("quote") or "", cj, status,
              f"table#{top.get('table')}", f"row{top.get('row')}", f"col{top.get('col')}",
              exist["id"]))
        return
    fid = SE.add_field_evidence(
        ev_id, field["field_path"], page_number=int(top["page"]),
        table_name=f"table#{top.get('table')}", row_key=f"row{top.get('row')}",
        column_key=f"col{top.get('col')}",
        cell_value=top.get("quote") or "", evidence_quote=top.get("quote") or "",
        gold_field_id=int(field.get("id") or 0), operator="machine", db_mod=db)
    db.x("UPDATE source_field_evidence SET candidates_json=?, engine='pymupdf',"
         " verification_status=? WHERE id=?", (cj, status, fid))


# ---------------------------------------------------------------- E4 三向比对
def e4_crosscheck(db, ev_id: int, mpn: str, dry: bool = False) -> dict:
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    parsed = _json_doc(mpn)
    rows = db.q("SELECT * FROM source_field_evidence WHERE evidence_id=? "
                "AND (reviewer IS NULL OR reviewer='')", (ev_id,))
    rep = {"stage": "e4", "ready": 0, "conflict": 0, "skipped": 0}
    for r in rows:
        if r["verification_status"] in ("ocr_pending",):
            rep["skipped"] += 1
            continue
        g = db.q1("SELECT expected FROM gold_field WHERE gold_id=? AND field_path=?",
                  (gold["id"], r["field_path"])) if gold else None
        q = _norm(r.get("evidence_quote"))
        gv = _norm((g or {}).get("expected"))
        p = _norm(_path_get(parsed or {}, r["field_path"]))
        if q and gv and q == gv:
            st = "ready"
        elif q and gv and (q in gv or gv in q):
            st = "ready"                                  # 单元格含值（如 "10 µA" vs "10"）
        elif q and gv:
            st = "conflict_draft"                         # 不改 expected，交人工裁决
        else:
            st = r["verification_status"]
        if st == "ready":
            rep["ready"] += 1
        elif st == "conflict_draft":
            rep["conflict"] += 1
        if not dry:
            db.x("UPDATE source_field_evidence SET verification_status=? WHERE id=?", (st, r["id"]))
            if st == "conflict_draft":
                SE._log(db, ev_id, 0, "crosscheck_conflict", "machine",
                        details={"field_path": r["field_path"],
                                 "quote": r.get("evidence_quote"), "gold": (g or {}).get("expected"),
                                 "parsed": _path_get(parsed or {}, r["field_path"])})
    return rep


def _path_get(doc, path: str):
    """按 field_path 取 parsed JSON 值（electrical[3].value / pin[2].name ...）。"""
    cur = doc
    for name, br in re.findall(r"([^\.\[\]]+)|\[(.*?)\]", str(path or "")):
        k = name or br
        if isinstance(cur, list):
            cur = cur[int(k)] if k.lstrip("-").isdigit() and int(k) < len(cur) else None
        elif isinstance(cur, dict):
            cur = cur.get(k)
        else:
            return None
    return cur


# ---------------------------------------------------------------- 编排
def run_all(db, mpn: str, dry: bool = False) -> dict:
    EV.ensure_cols(db)
    r1 = e1_register(db, mpn, dry)
    # dry 且尚无卡时可跑 E2–E4 预览（各阶段 dry 都不写库）；非 dry 时 E1 必已建卡
    ev = r1.get("evidence_id") or _latest_ev(db, mpn) or 0
    if not ev and not dry:
        return {"mpn": mpn, "dry": dry, "e1": r1, "e2": {"skipped": True},
                "e3": {"skipped": True}, "e4": {"skipped": True}}
    r2 = e2_precheck(db, ev, mpn, dry)
    r3 = e3_locate(db, ev, mpn, dry)
    r4 = e4_crosscheck(db, ev, mpn, dry)
    return {"mpn": mpn, "dry": dry, "evidence_id": ev or None, "e1": r1, "e2": r2,
            "e3": r3, "e4": r4}


def _latest_ev(db, mpn: str):
    r = db.q1("SELECT id FROM source_evidence WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    return r["id"] if r else None


def freeze_readiness(db, ev_id: int) -> dict:
    """E6 冻结就绪度：把 source_evidence.can_freeze 的守卫逐项展开成绿/黄/红。"""
    ev = db.q1("SELECT * FROM source_evidence WHERE id=?", (ev_id,))
    if not ev:
        return {"error": "evidence_not_found"}
    doc = db.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],)) or {}
    gold = db.q1("SELECT * FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (ev["mpn"],)) or {}
    fields = db.q("SELECT * FROM source_field_evidence WHERE evidence_id=?", (ev_id,))
    gold_fields = db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold.get("id") or 0,))
    checks = []

    def add(key, ok, level, detail):
        checks.append({"key": key, "ok": bool(ok), "level": level, "detail": detail})

    add("evidence_status", ev["status"] not in ("source_unresolved", "conflict"), "red",
        f"证据卡状态 {ev['status']}")
    add("identity_verified", (doc.get("identity_status") or "") == "verified", "red",
        f"文档身份 {doc.get('identity_status') or 'pending'}（须人工确认覆盖型号）")
    add("official_source", bool(doc.get("is_official")), "red",
        "来源是否原厂官方域名")
    cov = json.loads(doc.get("covered_mpn_json") or "[]")
    add("mpn_covered", (ev["mpn"] or "").strip().upper() in
        {str(x).strip().upper() for x in cov}, "red",
        f"已确认覆盖型号 {cov or '（未确认）'}")
    conflict = [f for f in fields if "conflict" in (f["verification_status"] or "")]
    add("no_conflict", not conflict, "red",
        f"未裁决冲突 {len(conflict)} 条" if conflict else "无未裁决冲突")
    verified = {f["field_path"] for f in fields if f["verification_status"] == "verified"}
    add("field_evidence", bool(verified), "red", f"已核验字段证据 {len(verified)} 条")
    missing = [f["field_path"] for f in gold_fields if f["field_path"] not in verified]
    add("all_gold_fields", not missing, "red",
        f"缺 {len(missing)} 个 Gold 字段证据" + (f"（如 {missing[0]}）" if missing else ""))
    sha_ok = (not (gold.get("pdf_sha256") or "")) or \
             (doc.get("pdf_sha256") or "") == (gold.get("pdf_sha256") or "")
    add("sha_consistent", sha_ok, "red", "Gold 登记 SHA 与证据卡文档一致")
    add("target_fields_cover", True, "yellow",
        "证据卡 target_fields 覆盖整件（留空表示按整件校验）")

    ok, why = SE.can_freeze(dict(ev, gold_pdf_sha256=gold.get("pdf_sha256") or ""),
                            doc, fields, gold_fields)
    return {"ev_id": ev_id, "mpn": ev["mpn"], "gold_id": gold.get("id"),
            "ready": bool(ok), "message": why, "checks": checks,
            "verified_fields": len(verified), "gold_fields": len(gold_fields)}


# ---------------------------------------------------------------- CLI
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpn")
    ap.add_argument("--stage", choices=["e1", "e2", "e3", "e4", "all", "readiness"], default="all")
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--all-draft", action="store_true")
    a = ap.parse_args(argv)
    db = EV._db(None)
    EV.ensure_cols(db)
    if a.all_draft:
        mpns = [r["mpn"] for r in db.q("SELECT mpn FROM gold_set WHERE status='draft' ORDER BY id")]
    else:
        if not a.mpn:
            ap.error("需要 --mpn 或 --all-draft")
        mpns = [a.mpn]
    outs = []
    for mpn in mpns:
        ev = _latest_ev(db, mpn)
        if a.stage == "readiness":
            outs.append(freeze_readiness(db, ev) if ev else {"mpn": mpn, "why": "无证据卡"})
        elif a.stage == "all":
            outs.append(run_all(db, mpn, a.dry))
        else:
            fn = {"e1": lambda: e1_register(db, mpn, a.dry),
                  "e2": lambda: e2_precheck(db, ev, mpn, a.dry),
                  "e3": lambda: e3_locate(db, ev, mpn, a.dry),
                  "e4": lambda: e4_crosscheck(db, ev, mpn, a.dry)}[a.stage]
            outs.append(fn())
    print(json.dumps(outs if len(outs) > 1 else outs[0], ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())