"""流水线凭证：**禁止绕过同步直接重打包**（2026-11-03 外审 P0-1）。

外审一票否决的直接触发点：交付包里的 JSON 是**旧的**，`verification` 字段一片空，
而事实表是**新的**，两边的结论对不上。根因不是某一处写错，而是装配链被抄了近路 ——
`delivery_bundle.py` 只校验「源文件在打包期间没变」，从不问「这份 JSON 是流水线
产出的，还是上一次跑剩下的」。哈希自洽 + 内容是旧的，是最难查的一类错。

凭证的做法：每个阶段跑完，在装配根写一行记录，记下**它处理过的 JSON 的内容指纹**
和**它保证过的事**（归一化跑过 / 电气行都有 verification.status / 事实表同步过）。
打包前逐条核：阶段齐、指纹对得上、保证仍然成立。缺一条就拒绝出包，并在错误里
直接给出该补的命令 —— 让人一眼知道怎么修，而不是猜。

指纹用**文本归一化口径**（CRLF→LF），与项目里其它文本哈希一致；
二进制（PDF）不参与，凭证只关心 JSON。
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

STAMP_NAME = "_pipeline_stamp.json"
SCHEMA = "pipeline-stamp/v1"

#: 要求逐行带 `verification.status` 的容器。
#: **不含 thermal / esd**：这两类是确定性抽取的容器级结论，逐行 status 天然为空，
#: 把它们算进缺口会让每个包都过不了闸门，等于把闸门关死（实测 544 行里 46 行
#: 全在这两个容器）。而 electrical / absolute_max 是模型抽的、逐行要审的，
#: 同步跑没跑过，看这两处最准。
AUDITED_CONTAINERS = ("electrical", "absolute_max")


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def json_digest(path: str | Path) -> str:
    """JSON 文件的内容指纹（CRLF→LF 归一后取 sha256）。

    不用原始字节：`core.autocrlf=true` 的机器 clone 下来会把换行改掉，
    原始字节哈希在那边永远对不上，凭证就变成「只有原机器能验」。
    """
    b = Path(path).read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(b).hexdigest()


def verification_gaps(doc: dict) -> tuple[int, int]:
    """返回 `(缺 status 的行数, 应审行总数)`，只数 `AUDITED_CONTAINERS`。"""
    miss = total = 0
    specs = doc.get("specs") or {}
    for c in AUDITED_CONTAINERS:
        for r in specs.get(c) or []:
            total += 1
            if not str((r.get("verification") or {}).get("status") or "").strip():
                miss += 1
    return miss, total


def read(root: str | Path) -> dict:
    p = Path(root) / STAMP_NAME
    if not p.is_file():
        return {"schema": SCHEMA, "mpns": {}}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"schema": SCHEMA, "mpns": {}}
    d.setdefault("schema", SCHEMA)
    d.setdefault("mpns", {})
    return d


def record(root: str | Path, stage: str, mpn: str, doc: dict,
           json_path: str | Path) -> dict:
    """记录一个阶段跑完（合并写，不覆盖别的型号/阶段）。

    `json_sha256` **每阶段覆盖**，取最后一个阶段写下的那份：打包器要核的是
    「我看到的这份 JSON 是不是最后一个阶段产出的」，不是「第一个阶段产出的」。
    用 `setdefault` 会让 `fact_status_sync` 补写完 status 之后凭证必然对不上。
    """
    root = Path(root)
    data = read(root)
    e = data["mpns"].setdefault(mpn, {})
    miss, total = verification_gaps(doc)
    e["json_sha256"] = json_digest(json_path)
    e["verification_missing_at_stage"] = miss
    e["verification_total"] = total
    e[stage] = {"at": _now(), "json_sha256": e["json_sha256"]}
    if stage == "stage_release":
        # `normalize` 只在第一次装配时有意义；第二趟 `--keep-out` 不带
        # `--normalize`，但归一结果已经在 JSON 里了 —— 所以用 `or` 累积，
        # 不能被第二趟覆盖成 False。
        e["normalized"] = bool(e.get("normalized")
                               or (doc.get("metadata") or {}).get("normalize"))
        e["column_collapse_quarantined"] = len(
            (doc.get("specs") or {}).get("unresolved_column_collapse") or [])
        # D4 引脚硬闸（2026-11-04）：记下装配期重放后的真实状态。
        # 打包器据此断言「包内 pin_validation 是这一趟算出来的」，而不是
        # 解析期遗留的旧值或空字段 —— V3-CANDIDATE 就是这么漏的。
        _pv = (doc.get("metadata") or {}).get("pin_validation") or {}
        e["pin_validation_status"] = str(_pv.get("status") or "")
        e["pin_validation_reason"] = str(_pv.get("reason") or "")
    data["updated_at"] = _now()
    (root / STAMP_NAME).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return e


def require(root: str | Path, mpns) -> dict:
    """打包前**硬校验**。不满足就抛 `RuntimeError`，错误里给出该补的命令。"""
    root = Path(root)
    data = read(root)
    parsed = root / "parsed"
    bad: list[str] = []
    for mpn in mpns:
        jp = parsed / f"{mpn}.json"
        e = (data.get("mpns") or {}).get(mpn) or {}
        if not e:
            bad.append(f"{mpn}: 无流水线凭证（该型号没跑过 stage_release）")
            continue
        if not jp.is_file():
            bad.append(f"{mpn}: 缺 parsed/{mpn}.json")
            continue
        cur = json_digest(jp)
        if e.get("json_sha256") != cur:
            bad.append(f"{mpn}: JSON 在流水线之后被改过"
                       f"（凭证 {str(e.get('json_sha256'))[:12]} ≠ 现值 {cur[:12]}）")
            continue
        if not e.get("stage_release"):
            bad.append(f"{mpn}: 缺 stage_release 阶段")
        elif not e.get("normalized"):
            bad.append(f"{mpn}: stage_release 没带 --normalize")
        if not e.get("fact_status_sync"):
            bad.append(f"{mpn}: 缺 fact_status_sync 阶段（事实表与 JSON 未对齐）")
        # 缺口**从当前文件现算**，不信凭证里的旧数：同步正是来补这些缺口的，
        # 拿装配那一刻的计数判会把「补好了」判成「没补」。
        try:
            doc = json.loads(jp.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            bad.append(f"{mpn}: parsed/{mpn}.json 读不出来")
            continue
        miss, total = verification_gaps(doc)
        if miss:
            bad.append(f"{mpn}: electrical/absolute_max 有 {miss}/{total} "
                       f"行没有 verification.status（同步没跑或跑漏）")
    if bad:
        raise RuntimeError(
            "拒绝出包：交付包必须由完整流水线产出，不能拿旧 JSON 原地重打。\n"
            "  " + "\n  ".join(bad) + "\n"
            "请按顺序重跑：\n"
            "  1) python -m qc.stage_release --staging <根> --keep-out --normalize\n"
            "  2) python -m qc.fact_acceptance --staging <根>      # 产出 facts_verdicts.json\n"
            "  3) python -m qc.fact_status_sync --staging <根> --facts <根>/facts_audit.json\n"
            "  4) python -m qc.stage_release --staging <根> --keep-out   # 注入 †\n"
            "  5) python delivery_bundle.py --acceptance-root <根> --out <包目录>\n")
    return data
