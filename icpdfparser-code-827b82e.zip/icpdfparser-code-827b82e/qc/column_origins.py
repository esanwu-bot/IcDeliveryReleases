# -*- coding: utf-8 -*-
"""``columns_raw`` 的来源词表 —— **单源**。

为什么单独一个模块，而不是两边各写字面量：

`qc/table_audit.py::patch_cols`（写盘闸门）和 `qc/five_stage.py::_set_columns`
（渲染回填）都会给 ``columns_raw`` 打 ``column_origin``。下游 G0 按这个值判断
「这条列证据是不是 PDF 表头锚点」。两边各写各的字符串，一旦一边加值、另一边
不认，证据链就在中间断掉 —— 而且断得很安静：字段有值、门禁放行、来源是错的。

三条取值对应三条**物理来源**，不可互换
------------------------------------

``pdf_header_anchors``
    列下标与表头 bbox 的 x 区间一一对应。A16 的 ``cell_spans_columns``
    守得住这一段：数据格超出表头该列区间就拒写。

``pdf_x_split``
    A13 按 x 簇把融合列切开，列边界来自**几何聚类**，不是表头 bbox。
    两个直接后果：① 表头词只有一份，切出来的两列共用一个词；
    ② 切分后 ``hx`` 被清空（列数变了，下标对不上），A16 对这类表**整体失效**。
    下游必须知道「这批列没有跨列校验兜底」。

``pdf_words_repair``
    A10 用 ``get_text("words")`` 按坐标重拼过的格。``find_tables().extract()``
    会把右对齐数值列重排（``'-2.0'`` → ``'20\\n- .'``），重拼后的值不是
    ``extract()`` 原值，但比原值可信 —— 记下来是为了让核对者知道该回哪一份。
"""
from __future__ import annotations

COLUMN_ORIGINS: frozenset[str] = frozenset({
    "pdf_header_anchors",
    "pdf_x_split",
    "pdf_words_repair",
})

#: 默认值：直接来自表头锚点。旧数据与未标注路径一律按它解释。
DEFAULT_ORIGIN = "pdf_header_anchors"
