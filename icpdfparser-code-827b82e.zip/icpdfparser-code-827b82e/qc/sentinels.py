#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""电气行取值口径的单一事实源（哨兵值 + 来源守卫）。

为什么集中成一份：此前 `json_to_txt._BLANK_SENTINELS`、`review.py` 的 sentinel
正则、`qc/cheatsheet.py` 的口径各写各的，任何一处漏改就会漂移——
表现为「同一份 JSON 在渲染层当空、在审查层当值」。

**`not_specified` 不是新引入的值**：`worker/fixers.py::fix_elec_shape` 一直在
把缺失字段标成它（"绝不补 0"），本项目口径见 `qc/cheatsheet.py`。这里只是
把它收口成单一定义，供三处消费端引用。

用法：
    from qc.sentinels import is_blank, is_not_specified, looks_like_feature_row
"""
from __future__ import annotations

import re

# 「明确无值」的唯一标记，区别于其它占位符：
# 下游见到它应当**停止重试**（原表就没这一格），而不是当作缺失去重建。
NOT_SPECIFIED = "not_specified"

# 所有视作空白的取值。注意 "n/a"、"-" 这类是「表里有占位符」，
# 语义上和 not_specified 等价，都不可当成真实数值渲染。
BLANK_SENTINELS = frozenset({
    "not_specified", "not specified", "unspecified", "unknown",
    "unknown_value", "n/a", "na", "none", "null", "nil",
    "-", "—", "–", "−", "--", "",
})


def is_blank(v) -> bool:
    """是否视作空白（渲染成 `-`，不参与数值比较）。"""
    return str(v or "").strip().lower() in BLANK_SENTINELS


def is_not_specified(v) -> bool:
    """是否是「明确无值」标记。下游据此停止重试，区别于普通空值。"""
    return str(v or "").strip().lower() == NOT_SPECIFIED


# 注：「Features 条目误入 electrical」的检测**不在这里**，见
# `qc/electrical_classify.py`。两者职责不同：本模块回答「这个取值是不是空」，
# 那边回答「这行是不是电气表行」。混在一起会让任一侧的改动牵动另一侧。
