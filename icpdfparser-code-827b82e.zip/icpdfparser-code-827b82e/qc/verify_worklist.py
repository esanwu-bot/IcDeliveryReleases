"""必须人工量清单（verify worklist）：把"挂接后 G6/G7 仍红"的剩余人工量精确分组。

定位：**判定归人，定位归机器**。本模块只读、不写库，回答两个问题：
  ① 还剩多少必须人工做的事？② 做完的最短路径是什么（点击数下限）？

分组（= 人工必须做的全部，其余皆机器）：
  A 高风险逐条核验（quote 复核 + 点击，**不可批量**）
  B 非高风险可批量（整批 1 次点击，服务端十项重校验兜底）
  C 待判定：机器未定位到 quote → 人工判 `not_specified` 或自找证据
  D 多候选 `ambiguous` → 人工选候选
  F `conflict*` → 人工裁决
  E `ocr_pending`（无文本层）→ 当前不可点，挂阶段 5 OCR 支线（不计入今日点击）

`clicks_est = |A| + (1 if B else 0) + |C| + |D| + |F|` —— 这是红线下的**人工下限**。

用法：
  python qc/verify_worklist.py --mpn DAC8555IPWG4
  python qc/verify_worklist.py --mpn DAC8555IPWG4 --json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

DONE = ("verified",)
CONFLICT = ("conflict", "conflict_draft")


def _db(dbm=None):
    if dbm is not None:
        return dbm
    from app import db as _dbm
    return _dbm


def build(db, mpn: str | None = None, ev_id: int | None = None) -> dict | None:
    from qc import high_risk as HR
    ev = (db.q1("SELECT * FROM source_evidence WHERE id=?", (ev_id,)) if ev_id
          else db.q1("SELECT * FROM source_evidence WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,)))
    if not ev:
        return None
    mpn = ev["mpn"]
    fes = db.q("SELECT * FROM source_field_evidence WHERE evidence_id=? ORDER BY id", (ev["id"],))
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    gf = {}
    if gold:
        for g in db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold["id"],)):
            gf[g["field_path"]] = g
    G: dict[str, list] = {"A": [], "B": [], "C": [], "D": [], "E": [], "F": []}
    done_v = done_other = 0
    for f in fes:
        st = f.get("verification_status") or "pending"
        if st in DONE:
            done_v += 1
            continue
        if st in ("not_specified", "not_applicable"):
            done_other += 1
            continue
        g = gf.get(f["field_path"]) or {}
        hr = HR.classify(f["field_path"], g.get("field_name") or "", g.get("unit") or "",
                         draft_name=g.get("expected") or "", draft_desc=g.get("cond") or "")
        item = {"id": f["id"], "path": f["field_path"], "page": f.get("page_number") or 0,
                "quote": (f.get("evidence_quote") or "")[:60], "status": st,
                "reasons": hr, "risk": HR.reason_text(hr) if hr else ""}
        if st in CONFLICT:
            G["F"].append(item)
        elif st == "ambiguous":
            G["D"].append(item)
        elif st == "ocr_pending":
            G["E"].append(item)
        elif hr:
            G["A"].append(item)
        elif (f.get("page_number") or 0) > 0 and (f.get("evidence_quote") or "").strip():
            G["B"].append(item)
        else:
            G["C"].append(item)
    total = len(fes)
    closed = done_v + done_other
    clicks = len(G["A"]) + (1 if G["B"] else 0) + len(G["C"]) + len(G["D"]) + len(G["F"])
    return {"mpn": mpn, "evidence_id": ev["id"], "total": total, "verified": done_v,
            "not_specified": done_other, "closed": closed,
            "progress": round(closed / total, 3) if total else 1.0,
            "groups": {k: v for k, v in G.items()},
            "batch_ids": [x["id"] for x in G["B"]],
            "counts": {k: len(v) for k, v in G.items()},
            "clicks_est": clicks,
            "g6g7_clear_when": "A/B/C/D/F 全处置完（E 挂 OCR 支线不计）",
            "human_only": "字段 verified / page+quote / 空白判 not_specified / 冲突裁决 —— 仅人工"}


def render(r: dict) -> str:
    G, C = r["groups"], r["counts"]
    lines = [f"[{r['mpn']}] 必须人工量清单 · 进度 {r['closed']}/{r['total']}"
             f"（verified {r['verified']} + not_specified {r['not_specified']}）",
             f"  预计点击：{r['clicks_est']} 次"
             f"（A 逐条 {C['A']} + B 批量 {1 if C['B'] else 0} + C {C['C']} "
             f"+ D {C['D']} + F {C['F']}；E {C['E']} 不计）"]
    if G["A"]:
        lines.append(f"  A 高风险逐条（quote 复核，不可批量）{C['A']}：")
        lines += [f"     - {x['path']}  p{x['page']} 「{x['quote']}」 {x['risk']}"
                  for x in G["A"]]
    if G["B"]:
        ids = r["batch_ids"]
        lines.append(f"  B 非高风险可批量（1 次点击）{C['B']}："
                     f"ids={ids[:8]}{'…' if len(ids) > 8 else ''}")
    for k, t in (("C", "C 待判定（not_specified / 自找证据）"),
                 ("D", "D 多候选（人工选）"),
                 ("F", "F conflict（人工裁决）"),
                 ("E", "E OCR 阻塞（不计今日，挂阶段5）")):
        if G[k]:
            lines.append(f"  {t} {C[k]}：" + ", ".join(x["path"] for x in G[k][:6])
                         + (" …" if C[k] > 6 else ""))
    lines.append(f"  G6/G7 转绿条件：{r['g6g7_clear_when']}")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpn")
    ap.add_argument("--evidence-id", type=int)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    if not (a.mpn or a.evidence_id):
        ap.error("需要 --mpn 或 --evidence-id")
    r = build(_db(None), mpn=a.mpn, ev_id=a.evidence_id)
    if not r:
        print("找不到证据卡", file=sys.stderr)
        return 3
    print(json.dumps(r, ensure_ascii=False, indent=1) if a.json else render(r))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())