#!/usr/bin/env python3
"""电气表页取证：确认「电气表页是否在选页预算内」（1102-V3.4 兜底口径前置）。

判定树（诚实优先，读不到就说读不到）：
  电气锚点全空                     -> source_no_table   （类 ADS1286U，不计空表率）
  生产选页可读 且 电气页在列        -> model_gap         （上下文有表仍空 -> 模型短板，进 plus 兜底）
  生产选页可读 且 电气页不在列      -> selection_gap     （选页没保住 -> 修选页/上方案①）
  生产选页读不到                   -> need_rerun_with_dump（重跑带选页 dump，不猜）

纪律（AGENT.md §14 / §8.5）：只读 PDF；不调 LLM；不写生产 parsed/库/交付目录；
报告只写 --out；逐页锚点扫描是确定性检测，不是整份重解。
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

ELEC_ANCHORS = [
    ("electrical_characteristics", re.compile(r"\bELECTRICAL\s+CHARACTERISTICS\b", re.I)),
    ("recommended_operating",      re.compile(r"\bRECOMMENDED\s+OPERATING\s+CONDITIONS\b", re.I)),
    ("dc_characteristics",         re.compile(r"\bDC\s+CHARACTERISTICS\b", re.I)),
    ("ac_characteristics",         re.compile(r"\bAC\s+CHARACTERISTICS\b", re.I)),
    ("timing_switching",           re.compile(r"\b(TIMING|SWITCHING)\s+CHARACTERISTICS\b", re.I)),
]
OTHER_MANDATORY = [
    ("thermal", re.compile(r"\bTHERMAL\s+INFORMATION\b", re.I)),
    ("esd",     re.compile(r"\bESD\s+RATINGS\b", re.I)),
    ("absmax",  re.compile(r"\bABSOLUTE\s+MAXIMUM\s+RATINGS\b", re.I)),
    ("ordering",re.compile(r"\b(ORDERING\s+INFORMATION|PACKAGE\s+OPTION\s+ADDENDUM)\b", re.I)),
]
ALL = ELEC_ANCHORS + OTHER_MANDATORY


def resolve_pdf(arg: str, mpn: str) -> Path:
    p = Path(arg)
    if p.is_file():
        return p
    if p.is_dir():
        cands = sorted(p.glob(f"{mpn}*.pdf")) or sorted(p.glob(f"*{mpn}*.pdf"))
        if len(cands) == 1:
            return cands[0]
        if cands:
            raise SystemExit(f"多个候选 PDF: {[c.name for c in cands]}，请显式传文件路径")
    raise SystemExit(f"找不到 PDF: arg={arg} mpn={mpn}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_toc_page(text: str) -> bool:
    """目录页伪命中：`Electrical Characteristics: DC .... 11` 也算标题命中。

    规则来自 `qc/page_filters.is_toc_page`（与 `select_pages` 共用同一份词表）。
    """
    try:
        from qc.page_filters import is_toc_page
        return is_toc_page(text)
    except Exception:                                  # noqa: BLE001
        low = (text or "").lower()
        return "table of contents" in low or (text or "").count("....") >= 2


def scan(pdf: Path):
    import pymupdf
    doc = pymupdf.open(str(pdf))
    hits, snippets = {k: [] for k, _ in ALL}, {}
    for i in range(doc.page_count):
        text = doc[i].get_text("text") or ""
        if _is_toc_page(text):
            continue                      # 目录页不计入锚点（否则 verdict 会被 TOC 骗）
        for key, rx in ALL:
            m = rx.search(text)
            if m:
                hits[key].append(i + 1)  # 1-based
                snippets.setdefault(key, {})[i + 1] = \
                    re.sub(r"\s+", " ", text[m.start():m.start() + 120]).strip()
    return doc.page_count, hits, snippets


def load_selected(parsed_json, run_log, mpn):
    """按优先级读生产选页；读不到返回 None（绝不猜）。"""
    if parsed_json and Path(parsed_json).exists():
        try:
            md = (json.loads(Path(parsed_json).read_text(encoding="utf-8")) or {}).get("metadata") or {}
        except Exception:
            md = {}
        for key in ("selected_pages", "pages_selected"):
            v = md.get(key)
            if isinstance(v, list) and v:
                return {"source": f"parsed_json:{key}", "pages": [int(x) for x in v],
                        "code": md.get("selection_source") or "production_run"}
        ps = md.get("page_selection") or {}
        if isinstance(ps, dict) and isinstance(ps.get("selected"), list) and ps["selected"]:
            return {"source": "parsed_json:page_selection.selected",
                    "pages": [int(x) for x in ps["selected"]]}
    if run_log and Path(run_log).exists():
        rx = re.compile(r"selected\s*=\s*\[([0-9,\s\-]+)\]")
        for line in Path(run_log).read_text(errors="replace").splitlines():
            if mpn and mpn not in line:
                continue
            m = rx.search(line)
            if m:
                nums = []
                for tok in m.group(1).replace(" ", "").split(","):
                    if not tok:
                        continue
                    if "-" in tok:
                        a, b = tok.split("-", 1); nums += list(range(int(a), int(b) + 1))
                    else:
                        nums.append(int(tok))
                if nums:
                    return {"source": "run_log", "pages": nums}
    return None


def _code_sha() -> str:
    """重算选页所用代码版本 —— verdict 必须可复现（Qwen 3.8 裁决要求）。"""
    import os, subprocess
    sha = (os.getenv("ICPDF_CODE_SHA") or "").strip()
    if sha:
        return sha
    try:
        root = Path(__file__).resolve().parent.parent
        return subprocess.check_output(["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                                       text=True, timeout=5).strip()
    except Exception:                                  # noqa: BLE001
        return "unknown"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf_arg")
    ap.add_argument("--mpn", default="")
    ap.add_argument("--parsed-json", default="")
    ap.add_argument("--run-log", default="")
    ap.add_argument("--max-pages", type=int, default=16)
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    pdf = resolve_pdf(a.pdf_arg, a.mpn or Path(a.pdf_arg).stem.split("_")[0])
    total, hits, snippets = scan(pdf)
    elec_pages = sorted({p for k, _ in ELEC_ANCHORS for p in hits[k]})
    first_elec = elec_pages[0] if elec_pages else None
    sel = load_selected(a.parsed_json, a.run_log, a.mpn)

    if not elec_pages:
        verdict = "source_no_table"
    elif sel is None:
        verdict = "need_rerun_with_dump"
    elif sel.get("code") == "deterministic_reselect":
        # 重算选页 ≠ 生产那次运行的选页：空卷结论来自旧代码，
        # 不能拿新代码的选页去证明"模型看到了表"（AGENT.md §5 第七次候选）。
        verdict = "selection_uncertain"
    elif first_elec in sel["pages"]:
        verdict = "model_gap"
    else:
        verdict = "selection_gap"

    report = {
        "mpn": a.mpn or pdf.stem, "pdf": pdf.name, "pdf_sha256": sha256(pdf),
        "total_pages": total, "max_pages_budget": a.max_pages,
        "reselect_commit": _code_sha(),
        "electrical_anchor_pages": {k: hits[k] for k, _ in ELEC_ANCHORS if hits[k]},
        "electrical_first_page": first_elec,
        "other_mandatory_pages": {k: hits[k] for k, _ in OTHER_MANDATORY if hits[k]},
        "anchor_snippets": snippets,
        "production_selection": sel,
        "electrical_in_production_selection":
            (first_elec in sel["pages"]) if (sel and first_elec) else None,
        "verdict": verdict,
        "verdict_meaning": {
            "source_no_table": "源文档无电气表标题，不计空表率、不进兜底队列",
            "model_gap": "电气页已在上下文仍交空卷 -> 模型短板，允许 plus 兜底 1 次",
            "selection_gap": "电气页未进预算 -> 修选页/上方案①，不进兜底队列",
            "need_rerun_with_dump": "读不到生产选页，重跑带选页 dump 后再判，不猜",
        }[verdict],
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if a.out:
        out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[report] -> {out}", file=sys.stderr)


if __name__ == "__main__":
    main()
