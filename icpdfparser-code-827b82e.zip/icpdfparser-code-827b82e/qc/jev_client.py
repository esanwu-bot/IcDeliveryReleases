# -*- coding: utf-8 -*-
"""百炼 `decision-model-preview` 语义裁判客户端（ADAPT JEV-BAILIAN）。

协议：TypeSafe System One（``POST /compatible-mode/v1/systemone``）
Endpoint：``https://{WorkspaceId}.cn-beijing.maas.aliyuncs.com/compatible-mode/v1/systemone``
鉴权：``DASHSCOPE_API_KEY``（百炼 Key）+ ``ICPDF_BAILIAN_WORKSPACE``（业务空间 ID）

**设计原则：永远不抛异常阻断主流程。**
任何网络 / 解析 / 校验失败、任何低于阈值的置信度，一律返回 ``None``，
调用方按「语义裁判不可用」处理（abstain），绝不降级成猜测。

**边界：只做语义裁判，不做物理仲裁。**
它可以帮规则打分打平时的候选行挑一个，但 `cell_num` 闸门、`fused_cols` 拦截、
`cell_spans_columns` 跨列校验、`SKIP_VALUES_NOT_IN_ROW` 一条都不受影响。
最坏结果是「JEV 选错行 → 多一条 unresolved」，不是「多一条脏写盘」。

依赖只用标准库：批量环境里 pymupdf 已经够重了，不再引入 dashscope-sdk。
"""
from __future__ import annotations

import json
import os
import random
import time
import urllib.error
import urllib.request

MODEL = "decision-model-preview"
TIMEOUT = float(os.getenv("ICPDF_JEV_TIMEOUT", "10"))
CONF_THRESHOLD = float(os.getenv("ICPDF_JEV_CONF", "0.75"))
MAX_RETRIES = int(os.getenv("ICPDF_JEV_RETRIES", "3"))

#: 运行期统计（进程内累计，供批量任务末尾打印；多进程各算各的）
STATS = {"call": 0, "ok": 0, "abstain": 0, "http_err": 0, "net_err": 0, "low_conf": 0}


def workspace() -> str:
    return os.getenv("ICPDF_BAILIAN_WORKSPACE", "").strip()


def available() -> bool:
    """环境是否齐备。**不发请求**，只判配置 —— 用来在批量开始前决定是否启用。"""
    return bool(workspace() and os.getenv("DASHSCOPE_API_KEY"))


def _endpoint() -> str:
    return (f"https://{workspace()}.cn-beijing.maas.aliyuncs.com"
            f"/compatible-mode/v1/systemone")


def decide_choice(state: str, instructions: str, criteria: dict,
                  threshold: float | None = None) -> tuple[str, float] | None:
    """返回 ``(choice_id, confidence)``；任何异常 / 低置信度返回 ``None``。

    ``criteria``：``{choice_id: 选项描述}``，1~255 项。
    """
    if not available() or not criteria:
        return None
    key = os.getenv("DASHSCOPE_API_KEY")
    payload = {
        "model": MODEL,
        "state": state,
        "questions": {
            "choice": {
                "type": "choice",
                "instructions": instructions,
                "criteria": criteria,
            }
        },
    }
    req = urllib.request.Request(
        _endpoint(),
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}",
                 "Content-Type": "application/json"},
        method="POST",
    )

    STATS["call"] += 1
    body = None
    for attempt in range(MAX_RETRIES):
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                body = json.loads(resp.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as exc:
            STATS["http_err"] += 1
            # 429/5xx 才值得重试；4xx（除 429）是请求本身的问题，重试没意义
            if exc.code in (429, 500, 502, 503, 504) and attempt < MAX_RETRIES - 1:
                # 指数退避 + 随机抖动：多进程同时撞限流时避免「惊群」
                time.sleep((2 ** attempt) + random.uniform(0, 1))
                continue
            return None
        except Exception:
            STATS["net_err"] += 1
            return None

    if not isinstance(body, dict):
        STATS["abstain"] += 1
        return None

    # ── 响应校验：字段缺失 / 越界 / 不在选项里，一律 abstain ──
    try:
        ans = body["answers"]["choice"]
        choice = ans.get("choice")
        conf = float(ans.get("confidence", 0.0))
    except (KeyError, TypeError, ValueError):
        STATS["abstain"] += 1
        return None
    if not isinstance(choice, str) or choice not in criteria or not (0.0 <= conf <= 1.0):
        STATS["abstain"] += 1
        return None
    if conf < (CONF_THRESHOLD if threshold is None else threshold):
        STATS["low_conf"] += 1
        return None
    STATS["ok"] += 1
    return choice, conf


def summary() -> str:
    return (f"JEV call={STATS['call']} ok={STATS['ok']} "
            f"low_conf={STATS['low_conf']} abstain={STATS['abstain']} "
            f"http_err={STATS['http_err']} net_err={STATS['net_err']}")
