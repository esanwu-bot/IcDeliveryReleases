"""写回前演练：生成 228 件临时合并产物，并对 10 件样本做六项校验。

为什么分成两步
--------------
228 件合并产物是「候选池」，供后续逐件复核与分批写回反复取用，必须一次生成、
可重复验证。10 件演练是「规则验证」，要覆盖各类边界，证明合并与门禁在真实
数据上确实按预期工作。两者目的不同，不能互相替代。

六项校验
--------
1. 历史字段与 multi_language 保留
2. 数据库引用可解析，且不修改数据库（只读连接 + 前后快照）
3. 路径映射明确，不把 Windows 本地路径误当容器路径
4. 源 PDF SHA-256 与解析元数据一致；历史哈希不一致必须显式报告
5. 电气与订货 QC 回归通过，未解决的退化仍被阻断
6. 生产目录、SQLite、路径引用前后无变化

授权边界：只写独立临时目录，不写生产 JSON、不写 SQLite、不改 item.json_path。

用法（容器内）
--------------
    python qc/v4_writeback_drill.py --out-dir /tmp/v4_writeback
    python qc/v4_writeback_drill.py --out-dir /tmp/v4_writeback --drill-only
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.json_merge import PARSE_OWNED, merge_doc             # noqa: E402
from qc.reparse_ordering import _safe                        # noqa: E402

# 10 件演练样本（按类别挑选，覆盖边界与风险项）
DRILL_SAMPLES = [
    ("COP8-PGMA-44QFP", "历史字段(identity/device_mpn/device_scope)+替代减少"),
    ("EM430F5137RF900", "多语言三键结构"),
    ("2N7001TQDCKRQ1", "多语言五键结构"),
    ("74LVCH8T245NSRG4", "电气显著增加(+48)"),
    ("AM1806BZWT3", "电气显著增加(+30)"),
    ("5962-8404701VCA", "Ordering 显著改善(+32)"),
    ("CC1350STKUS", "替代型号减少(-6)"),
    ("DAC0800LCM", "专项对比(替代减少)"),
    ("74LVC1G373DCKRE4", "电气退化(-50)"),
    ("AFE7903IALK", "电气退化(-72)"),
]


def _sha_bytes(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _name(p: str) -> str:
    return Path(p.replace("\\", "/")).name if p else ""


def _kind_of(p: str) -> str:
    if not p:
        return "空"
    if len(p) > 1 and p[1] == ":" and p[0].isalpha():
        return "Windows本地路径"
    if p.startswith("/"):
        return "容器绝对路径"
    return "相对路径/裸文件名"


def snapshot(data_root: Path) -> dict:
    """生产侧快照：文件数、DB 大小与 mtime、item 表计数。只读。"""
    parsed = data_root / "parsed"
    db_path = data_root / "workbench.sqlite3"
    st = db_path.stat()
    con = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True)
    n_item = con.execute("SELECT COUNT(*) FROM item").fetchone()[0]
    n_json = con.execute(
        "SELECT COUNT(*) FROM item WHERE json_path IS NOT NULL AND json_path<>''"
    ).fetchone()[0]
    con.close()
    return {
        "parsed_count": len(list(parsed.glob("*.json"))),
        "db_size": st.st_size,
        "db_mtime": round(st.st_mtime, 3),
        "item_count": n_item,
        "item_with_json": n_json,
    }


# ---------------------------------------------------------------- 阶段 A
def stage_all(a, data_root: Path, out_dir: Path) -> tuple[list, list]:
    backup, tmp = Path(a.backup), Path(a.tmp_parsed)
    merged_dir = out_dir / "merged"
    merged_dir.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect("file:%s?mode=ro" % (data_root / "workbench.sqlite3"), uri=True)
    pdfs = data_root / "pdfs"
    rows = list(csv.DictReader(Path(a.diff).open(encoding="utf-8-sig")))
    print("读入 %d 件" % len(rows))

    # 同 MPN 多份 JSON 的歧义判定
    json_index = {p.name for p in (data_root / "parsed").glob("*.json")}
    by_mpn: dict[str, list[str]] = {}
    for n in json_index:
        by_mpn.setdefault(n.rsplit("_", 1)[0], []).append(n)

    report, targets = [], []
    for r in rows:
        mpn = r["mpn"]
        d = db.execute("SELECT pdf_path, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        db_pdf, db_json = (d[0] if d else ""), (d[1] if d else "")
        jn, pn = _name(db_json), _name(db_pdf)

        old_name = jn if jn and (backup / jn).exists() else ""
        if not old_name:
            hits = sorted(x.name for x in backup.glob(_safe(mpn) + "_*.json"))
            old_name = hits[0] if hits else ""
        new_hits = sorted(tmp.glob(_safe(mpn) + "_*.json"))

        sibs = by_mpn.get(mpn, [])
        rec = {
            "mpn": mpn, "candidate": "否", "no_candidate_reason": "",
            "db_json_kind": _kind_of(db_json), "db_pdf_kind": _kind_of(db_pdf),
            "old_name": old_name, "new_name": new_hits[0].name if new_hits else "",
            "old_sha256": "", "new_sha256": "", "merged_sha256": "",
            "target_name": "", "target_in_prod": "", "target_dup": "否",
            "ml_old": "", "ml_kept": "", "legacy_fields": "", "legacy_lost": "",
            "n_updated": 0, "n_kept_legacy": 0, "n_orphan": 0, "n_skipped": 0,
            "merge_blocked": "", "pdf_sha16": "", "meta_pdf_hash16": "",
            "hash_consistent": "",
        }

        # ---- 前置检查：映射不唯一 / 备份缺失 / PDF 缺失 都不生成候选 ----
        bad = []
        if not old_name:
            bad.append("无备份基线")
        if not new_hits:
            bad.append("无 dry-run 产物")
        if len(sibs) >= 2:
            bad.append("同 MPN 多份 JSON 未消歧")
        pdf = pdfs / pn if pn else None
        if pn and not (pdf and pdf.exists()):
            bad.append("源 PDF 不存在")
        if bad:
            rec["no_candidate_reason"] = "；".join(bad)
            report.append(rec)
            continue

        old, new = _load(backup / old_name), _load(new_hits[0])
        merged, mrows, blocked = merge_doc(old, new, mpn)

        dst = merged_dir / ("%s.merged.json" % _safe(mpn))
        dst.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")

        # 目标路径模拟：按现行命名规范 {mpn}_{pdfhash8}.json
        meta_hash = str((new.get("metadata") or {}).get("pdf_hash") or "")
        tgt = "%s_%s.json" % (_safe(mpn), meta_hash[:8]) if meta_hash else ""
        pdf_sha = _sha_bytes(pdf) if pdf and pdf.exists() else ""

        legacy = []
        for top, allowed in PARSE_OWNED.items():
            if allowed is None:
                continue
            ov = old.get(top)
            if isinstance(ov, dict):
                legacy += ["%s.%s" % (top, k) for k in ov if k not in allowed]
            elif isinstance(ov, list):
                for it in ov:
                    if isinstance(it, dict):
                        legacy += ["%s[].%s" % (top, k) for k in it if k not in allowed]
        legacy += [k for k in old if k not in PARSE_OWNED]
        lost = []
        for top, allowed in PARSE_OWNED.items():
            if allowed is None:
                continue
            ov = old.get(top)
            mv = merged.get(top)
            if isinstance(ov, dict) and isinstance(mv, dict):
                lost += ["%s.%s" % (top, k) for k in ov
                         if k not in allowed and k not in mv]
                for kold, vold in ov.items():
                    if isinstance(vold, list):
                        for ito in vold:
                            if not isinstance(ito, dict):
                                continue
                            for k2 in ito:
                                if k2 in allowed:
                                    continue
                                if not any(isinstance(m, dict) and k2 in m
                                           for m in (mv.get(kold) or [])):
                                    lost.append("%s.%s[].%s" % (top, kold, k2))
        for k in old:
            if k not in PARSE_OWNED and (k not in merged or merged[k] != old[k]):
                lost.append(k)

        rec.update({
            "candidate": "是",
            "old_sha256": _sha_bytes(backup / old_name)[:16],
            "new_sha256": _sha_bytes(new_hits[0])[:16],
            "merged_sha256": _sha_bytes(dst)[:16],
            "target_name": tgt,
            "target_in_prod": "是" if tgt and (data_root / "parsed" / tgt).exists() else "否",
            "ml_old": "有" if old.get("multi_language") else "无",
            "ml_kept": ("是" if merged.get("multi_language") == old.get("multi_language")
                        else "否") if old.get("multi_language") else "-",
            "legacy_fields": "|".join(sorted(set(legacy))[:6]),
            "legacy_lost": "|".join(sorted(set(lost))[:6]),
            "n_updated": sum(1 for x in mrows if x["action"] == "updated"),
            "n_kept_legacy": sum(1 for x in mrows if x["action"] == "kept_legacy"),
            "n_orphan": sum(1 for x in mrows if x["action"] == "orphan_kept"),
            "n_skipped": sum(1 for x in mrows if x["action"] == "new_field_skipped"),
            "merge_blocked": "；".join(blocked) or "-",
            "pdf_sha16": pdf_sha[:16],
            "meta_pdf_hash16": meta_hash[:16],
            "hash_consistent": ("是" if pdf_sha[:16] == meta_hash[:16] else "否")
            if pdf_sha and meta_hash else "",
        })
        if tgt:
            targets.append((mpn, tgt))
        report.append(rec)

    dup = [t for t, c in Counter(t for _, t in targets).items() if c > 1]
    for rec in report:
        if rec["target_name"] in dup:
            rec["target_dup"] = "是"
    return report, targets


# ---------------------------------------------------------------- 阶段 B
def stage_drill(a, data_root: Path, out_dir: Path, report: dict, targets: dict) -> list:
    gate = {}
    gp = Path(a.gate_csv)
    if gp.exists():
        for r in csv.DictReader(gp.open(encoding="utf-8-sig")):
            gate[r["mpn"]] = r
    db_ro = sqlite3.connect("file:%s?mode=ro" % (data_root / "workbench.sqlite3"), uri=True)
    pdfs = data_root / "pdfs"

    out = []
    for mpn, why in DRILL_SAMPLES:
        rec = report.get(mpn, {})
        g = gate.get(mpn, {})
        d = db_ro.execute("SELECT pdf_path, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        db_pdf, db_json = (d[0] if d else ""), (d[1] if d else "")

        checks = {}
        # 1 历史字段与多语言保留
        checks["1_历史字段与多语言保留"] = (
            rec.get("ml_kept") in ("是", "-") and not rec.get("legacy_lost"))
        # 2 数据库引用可解析（只读连接本身保证不写库，快照另行比对）
        jn = _name(db_json)
        checks["2_数据库引用可解析"] = bool(jn) and bool(
            db_ro.execute("SELECT 1 FROM item WHERE mpn=?", (mpn,)).fetchone())
        # 3 路径映射明确：容器路径才可直接用，Windows 路径只能按 basename 反查
        kj, kp = _kind_of(db_json), _kind_of(db_pdf)
        tgt = rec.get("target_name") or ""
        checks["3_路径映射明确"] = bool(tgt) and tgt.startswith(_safe(mpn)) and tgt.endswith(".json")
        # 4 PDF SHA256 与解析元数据一致
        checks["4_哈希一致"] = rec.get("hash_consistent") == "是"
        # 5 QC 回归：有退化的件绝不能进安全子集；判 BLOCK 必须有登记在案的原因。
        #   判据取门禁 CSV 的实际字段，不取样本类别文字——文字会与实际原因不一致
        #   （COP8-PGMA-44QFP 标的是历史字段件，实际同时是替代型号减少件）。
        try:
            elec_d = int(g.get("elec_delta") or 0)
            alt_d = int(g.get("alt_delta") or 0)
            order_d = int(g.get("order_delta") or 0)
        except ValueError:
            elec_d = alt_d = order_d = 0
        degraded = elec_d < 0 or alt_d < 0 or order_d < 0
        reasons = (g.get("reasons") or "").strip()
        if degraded:
            checks["5_QC回归"] = g.get("gate") != "PASS"
        else:
            checks["5_QC回归"] = bool(g.get("gate")) and (
                g.get("gate") != "BLOCK" or (bool(reasons) and reasons != "-"))
        # 6 生产无变化由前后快照统一判定，main 里比对后回填
        checks["6_生产无变化"] = None

        ok = all(v for v in checks.values() if v is not None)
        unresolved = (g.get("gate") == "BLOCK")
        out.append({
            "mpn": mpn, "样本类别": why,
            "verdict": "PASS" if ok else "FAIL",
            **{k: ("待快照" if v is None else ("是" if v else "否"))
               for k, v in checks.items()},
            "gate": g.get("gate", "-"),
            "gate_reasons": (g.get("reasons") or "")[:90],
            "ml_kept": rec.get("ml_kept", ""),
            "legacy_fields": rec.get("legacy_fields", ""),
            "legacy_lost": rec.get("legacy_lost", ""),
            "target_name": tgt, "target_dup": rec.get("target_dup", ""),
            "db_json_kind": kj, "db_pdf_kind": kp,
            "pdf_sha16": rec.get("pdf_sha16", ""),
            "meta_pdf_hash16": rec.get("meta_pdf_hash16", ""),
            "hash_consistent": rec.get("hash_consistent", ""),
            "仍阻断": "是" if unresolved else "否",
            "candidate": rec.get("candidate", ""),
        })
    db_ro.close()
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="写回前演练（临时目录，不动生产）")
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--tmp-parsed", default="/tmp/v4_dryrun/parsed")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--diff", default="/tmp/v4_dryrun/v4_quality_diff.csv")
    ap.add_argument("--gate-csv", default="/tmp/v4_gate3/v4_quality_gate.csv")
    ap.add_argument("--out-dir", default="/tmp/v4_writeback")
    ap.add_argument("--drill-only", action="store_true", help="只做演练，跳过 228 件生成")
    a = ap.parse_args(argv)

    data_root, out_dir = Path(a.data_root), Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    before = snapshot(data_root)
    (out_dir / "snapshot_before.json").write_text(
        json.dumps(before, ensure_ascii=False, indent=2), encoding="utf-8")
    print("=== 生产快照（前）===")
    print("   ", before)

    report, drill = [], []
    if not a.drill_only:
        print("\n=== 阶段 A：生成 228 件临时合并产物 ===")
        report, targets = stage_all(a, data_root, out_dir)
        cand = sum(1 for r in report if r["candidate"] == "是")
        print("   候选 %d / %d 件；目标路径重复 %d 个"
              % (cand, len(report),
                 sum(1 for r in report if r["target_dup"] == "是")))
        print("   未生成候选的原因：")
        for k, v in Counter(r["no_candidate_reason"] for r in report
                            if r["candidate"] == "否").most_common():
            print("      %-28s %d 件" % (k, v))
        if report:
            p = out_dir / "v4_merge_report_228.csv"
            with p.open("w", newline="", encoding="utf-8-sig") as fh:
                w = csv.DictWriter(fh, fieldnames=list(report[0].keys()))
                w.writeheader()
                w.writerows(report)
            print("   写 %s（%d 行）" % (p, len(report)))
        rmap = {r["mpn"]: r for r in report}
    else:
        p = out_dir / "v4_merge_report_228.csv"
        rmap = {}
        if p.exists():
            for r in csv.DictReader(p.open(encoding="utf-8-sig")):
                rmap[r["mpn"]] = r
        print("   复用已有报告 %d 件" % len(rmap))

    print("\n=== 阶段 B：10 件样本六项校验 ===")
    drill = stage_drill(a, data_root, out_dir, rmap, None)

    after = snapshot(data_root)
    (out_dir / "snapshot_after.json").write_text(
        json.dumps(after, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n=== 生产快照（后）===")
    print("   ", after)
    prod_clean = before == after
    print("   前后一致：%s" % ("是" if prod_clean else "否"))
    if not prod_clean:
        for k in before:
            if before[k] != after.get(k):
                print("      差异 %s：%s -> %s" % (k, before[k], after.get(k)))

    # 第 6 项只能在全部写操作结束后判定，所以在这里回填并重算 verdict
    for d in drill:
        d["6_生产无变化"] = "是" if prod_clean else "否"
        got = [d[k] for k in d if k.startswith(("1_", "2_", "3_", "4_", "5_", "6_"))]
        d["verdict"] = "PASS" if all(v == "是" for v in got) else "FAIL"
    if drill:
        p = out_dir / "v4_drill_report.csv"
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(drill[0].keys()))
            w.writeheader()
            w.writerows(drill)
        print("   写 %s（%d 行）" % (p, len(drill)))
    for d in drill:
        print("   %-20s %-5s %-28s gate=%-6s 多语言保留=%s"
              % (d["mpn"], d["verdict"], d["样本类别"][:28], d["gate"], d["ml_kept"]))
        bad = [k for k in d if k.startswith(("1_", "2_", "3_", "4_", "5_", "6_"))
               and d[k] == "否"]
        if bad:
            print("        未通过：%s" % ",".join(bad))

    n_pass = sum(1 for d in drill if d["verdict"] == "PASS")
    print("\n演练通过 %d / %d 件" % (n_pass, len(drill)))

    # 数量与覆盖核对
    n_files = len(list((out_dir / "merged").glob("*.merged.json")))
    cand = sum(1 for r in rmap.values() if r.get("candidate") == "是")
    print("\n=== 数量与覆盖核对 ===")
    print("   输入 %d 件 / 候选 %d 件 / merged 文件 %d 个 -> %s"
          % (len(rmap), cand, n_files,
             "一致" if cand == n_files else "不一致"))
    print("   目标路径重复 %d 个" % sum(1 for r in rmap.values()
                                   if r.get("target_dup") == "是"))
    print("   目标文件在生产已存在（写回即覆盖同名）%d 件"
          % sum(1 for r in rmap.values() if r.get("target_in_prod") == "是"))
    print("   merged 目录位于 %s（不在生产 parsed 下：%s）"
          % (out_dir / "merged",
             "是" if "parsed" not in str(out_dir / "merged").replace(
                 str(data_root), "") else "否"))

    # 最终安全子集
    gp = Path(a.gate_csv)
    if gp.exists():
        safe = [r for r in csv.DictReader(gp.open(encoding="utf-8-sig"))
                if r["gate"] == "PASS"]
        keep = [r for r in safe if rmap.get(r["mpn"], {}).get("candidate") == "是"]
        p = out_dir / "v4_final_safe_subset.csv"
        if keep:
            with p.open("w", newline="", encoding="utf-8-sig") as fh:
                w = csv.DictWriter(fh, fieldnames=list(keep[0].keys()))
                w.writeheader()
                w.writerows(keep)
        print("\n最终安全子集：门禁 PASS %d 件 ∩ 合并候选 %d 件 = %d 件"
              % (len(safe), sum(1 for r in rmap.values() if r["candidate"] == "是"),
                 len(keep)))
        print("   写 %s" % p)
    return 0 if n_pass == len(drill) and before == after else 1


if __name__ == "__main__":
    raise SystemExit(main())
