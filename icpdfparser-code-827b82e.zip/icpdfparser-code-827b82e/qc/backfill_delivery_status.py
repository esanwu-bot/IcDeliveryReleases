#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读盘点：按现有 review 报告重算历史批次的状态，先出差异报告。

为什么先不写回
--------------
历史批次里的 `rf_quality_audit.json` 可能被别的流水线（隔离、人工标注）改过，
直接覆盖会丢信息且不可回滚。所以本工具默认 **dry-run**：

  python qc/backfill_delivery_status.py                 # 只出 CSV + JSON 差异报告
  python qc/backfill_delivery_status.py --batch rf-...  # 只盘一个批次
  python qc/backfill_delivery_status.py --apply         # 写独立 sidecar（仍不动 audit）

`--apply` 只写 `data/qc/<batch>/rf_status_derived.json`，`delivery_history` 见到它
就优先用派生状态；删掉该文件即回退到 audit 口径——不覆盖、可回滚、可对比。

每行都带：旧状态、新状态、P0/P1、未通过的证据检查数、所用 review 文件的
SHA-256、原因、报告自带的 rule_version 与本次推导版本，便于逐条复核。

口径边界（刻意不做的事）
------------------------
* 不因「型号名就在隔离区」就判阻断：隔离是人工结论，不是 review 结论。
  audit 里有 `quarantined` 而 review 里数不出 P0 时，单独标 `quarantine_conflict`。
* 不把缺失/无法识别的报告当成通过：一律 INCOMPLETE / LEGACY_UNRESOLVED。
"""
from __future__ import annotations

import argparse
import csv
import datetime
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import review_status as RS      # noqa: E402

TOOL_VERSION = "backfill-1"
DERIVED_NAME = "rf_status_derived.json"
CSV_COLS = ("batch_id", "mpn", "old_status", "old_label", "new_status",
            "new_label", "p0", "p1", "p2", "advisory", "incomplete_checks",
            "verdict", "format", "review_file", "review_sha256", "changed",
            "reason", "rule_version", "status_rule_version", "quarantine_conflict",
            "error")


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _read_json(p: Path) -> tuple[dict, str, str]:
    """→ (数据, 原始字节 SHA-256, 错误)。解析失败时仍保留哈希，便于事后核对。"""
    try:
        raw = p.read_bytes()
    except OSError as e:
        return {}, "", "%s: %s" % (type(e).__name__, str(e)[:120])
    sha = _sha256_bytes(raw)
    try:
        d = json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        return {}, sha, "%s: %s" % (type(e).__name__, str(e)[:120])
    return (d if isinstance(d, dict) else {}), sha, ""


def _manifest(d: Path) -> list[dict]:
    f = d / "manifest.csv"
    if not f.is_file():
        return []
    try:
        with f.open(encoding="utf-8-sig", newline="") as fh:
            return [r for r in csv.DictReader(fh) if (r.get("mpn") or "").strip()]
    except OSError:
        return []


def _review_path(d: Path, mpn: str) -> Path:
    # 与 review_fix.safe_stem 同口径（`/` 等字符归一成 `_` 再大写）
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(mpn)).upper()
    return d / "review" / ("%s.review.json" % safe)


def scan_batch(d: Path) -> dict:
    """重算一个批次：返回 {old, new, rows, ...}；不写任何文件。"""
    audit, _sha, audit_err = _read_json(d / "rf_quality_audit.json")
    old_code = str(audit.get("status_code") or "")
    old_label = str(audit.get("status_label") or "")
    rows = _manifest(d)
    if not rows:
        rows = [{"mpn": f.name[: -len(".review.json")]}
                for f in sorted((d / "review").glob("*.review.json"))]
    quarantined = set((audit.get("quarantined") or {}).get("mpns") or [])
    out_rows = []
    for r in rows:
        mpn = (r.get("mpn") or "").strip()
        rp = _review_path(d, mpn)
        review, sha, err = {}, "", ""
        if rp.is_file():
            review, sha, err = _read_json(rp)
            if not review:
                err = err or "review 报告内容为空"
        else:
            err = "缺 review 报告"
        a = RS.analyze(review)
        conflict = bool(mpn in quarantined and a["status_code"] != RS.STATUS_BLOCKED)
        out_rows.append({
            "mpn": mpn,
            "old_status": (r.get("status_code") or "").strip(),
            "old_label": (r.get("status_label") or "").strip(),
            "new_status": a["status_code"],
            "new_label": a["status_label"],
            "p0": a["p0"], "p1": a["p1"], "p2": a["p2"],
            "advisory": a["advisory"],
            "incomplete_checks": a["incomplete_checks"],
            "verdict": a["verdict"],
            "format": a["format"],
            "review_file": str(rp.relative_to(d)) if rp.is_file() else "",
            "review_sha256": sha,
            "changed": (r.get("status_code") or "").strip() != a["status_code"],
            "reason": a["reason"] or "",
            "rule_version": a["rule_version"],
            "status_rule_version": a["status_rule_version"],
            "quarantine_conflict": conflict,
            "error": err or "",
        })
    new_code = RS.rollup([r["new_status"] for r in out_rows])
    return {
        "batch": d.name,
        "old_status": old_code,
        "old_label": old_label,
        "new_status": new_code,
        "new_label": RS.label(new_code),
        "changed": old_code != new_code,
        "p0_total": sum(r["p0"] for r in out_rows),
        "p1_total": sum(r["p1"] for r in out_rows),
        "status_counts": RS.counts(out_rows),
        "rows": out_rows,
        "quarantined": sorted(quarantined),
        "quarantine_conflicts": [r["mpn"] for r in out_rows
                                 if r["quarantine_conflict"]],
        "generated_at": str(audit.get("generated_at") or ""),
        "audit_error": audit_err,
    }


def _write_sidecar(d: Path, got: dict) -> Path:
    now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    payload = {
        "status_code": got["new_status"],
        "status_label": got["new_label"],
        "status_rule_version": RS.STATUS_RULE_VERSION,
        "tool_version": TOOL_VERSION,
        "generated_at": now,
        "p0_total": got["p0_total"],
        "p1_total": got["p1_total"],
        "status_counts": got["status_counts"],
        "source": {"previous_status_code": got["old_status"],
                   "previous_status_label": got["old_label"]},
        "mpns_detail": {r["mpn"]: {k: r[k] for k in
                                  ("new_status", "new_label", "p0", "p1",
                                   "incomplete_checks", "verdict",
                                   "review_sha256", "reason", "rule_version")}
                        for r in got["rows"]},
    }
    p = d / DERIVED_NAME
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    tmp.replace(p)
    return p


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="按现有 review 报告只读重算历史批次状态（默认 dry-run）")
    ap.add_argument("--base", default=str(ROOT / "data" / "qc"))
    ap.add_argument("--batch", default="", help="只盘一个批次号")
    ap.add_argument("--out", default="", help="CSV 路径（默认 data/qc/backfill_status_<date>.csv）")
    ap.add_argument("--apply", action="store_true",
                    help="写 rf_status_derived.json（不覆盖 audit/manifest/zip）")
    a = ap.parse_args(argv)

    base = Path(a.base)
    if not base.is_dir():
        print("目录不存在：%s" % base)
        return 2
    dirs = [d for d in sorted(base.iterdir()) if d.is_dir()]
    if a.batch:
        dirs = [d for d in dirs if d.name == a.batch]
    picked = []
    skipped = []
    for d in dirs:
        if not (d / "rf_quality_audit.json").is_file():
            continue
        audit, _sha, _err = _read_json(d / "rf_quality_audit.json")
        if str(audit.get("delivery_kind") or "") != "review_fix":
            skipped.append(d.name)
            continue
        picked.append(d)
    if not picked:
        print("没有可盘点的 review-fix 批次（跳过 %d 个非 review-fix 目录）"
              % len(skipped))
        return 1

    gots = [scan_batch(d) for d in picked]
    stamp = datetime.date.today().strftime("%Y%m%d")
    out = Path(a.out) if a.out else base / ("backfill_status_%s.csv" % stamp)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(CSV_COLS), extrasaction="ignore")
        w.writeheader()
        for g in gots:
            for r in g["rows"]:
                w.writerow(dict(r, batch_id=g["batch"]))

    summary = {
        "tool_version": TOOL_VERSION,
        "status_rule_version": RS.STATUS_RULE_VERSION,
        "generated_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "base": str(base),
        "batches": [
            {k: g[k] for k in ("batch", "old_status", "old_label", "new_status",
                               "new_label", "changed", "p0_total", "p1_total",
                               "status_counts", "quarantined",
                               "quarantine_conflicts", "generated_at",
                               "audit_error")}
            for g in gots
        ],
        "skipped_non_review_fix": skipped,
        "totals": {
            "batches": len(gots),
            "changed_batches": sum(1 for g in gots if g["changed"]),
            "rows": sum(len(g["rows"]) for g in gots),
            "changed_rows": sum(1 for g in gots for r in g["rows"] if r["changed"]),
            "blocked": sum(1 for g in gots for r in g["rows"]
                           if r["new_status"] == RS.STATUS_BLOCKED),
            "still_warn": sum(1 for g in gots for r in g["rows"]
                              if r["new_status"] == RS.STATUS_STILL_WARN),
            "qa_pass": sum(1 for g in gots for r in g["rows"]
                           if r["new_status"] == RS.STATUS_QA_PASS),
            "incomplete": sum(1 for g in gots for r in g["rows"]
                              if r["new_status"] in (RS.STATUS_INCOMPLETE,
                                                     RS.STATUS_LEGACY_UNRESOLVED)),
        },
    }
    js = out.with_suffix(".json")
    js.write_text(json.dumps(summary, ensure_ascii=False, indent=2),
                  encoding="utf-8")
    applied = []
    if a.apply:
        applied = [str(_write_sidecar(base / g["batch"], g)) for g in gots]

    t = summary["totals"]
    print("批次 %d（改动 %d）· 型号 %d（状态变化 %d）"
          % (t["batches"], t["changed_batches"], t["rows"], t["changed_rows"]))
    print("新状态：阻断 %d / 警告 %d / 通过 %d / 证据不完整 %d"
          % (t["blocked"], t["still_warn"], t["qa_pass"], t["incomplete"]))
    for g in gots:
        flag = "→" if g["changed"] else "="
        print("  %s %s  %s %s   P0=%d P1=%d"
              % (flag, g["batch"], g["old_status"] or "—", g["new_status"],
                 g["p0_total"], g["p1_total"]))
        if g["quarantine_conflicts"]:
            print("    ! 人工隔离标注 P0、但 review 未见 P0：%s"
                  % ", ".join(g["quarantine_conflicts"]))
    print("CSV : %s" % out)
    print("JSON: %s" % js)
    if applied:
        print("已写 sidecar %d 个（audit/manifest/zip 未动）" % len(applied))
    else:
        print("dry-run：未写任何批次文件（加 --apply 才写 sidecar）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
