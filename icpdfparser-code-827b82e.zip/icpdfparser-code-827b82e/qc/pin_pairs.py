#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qc/pin_pairs.py — 差分对物理相邻性检查（零依赖，不碰 PDF）。

为什么单独拆出来：
  `pin_mismatch` 依赖「PDF 表 → JSON」同一条链路的映射，一旦解析时把名字按前缀
  分组重排（先全部 +、再全部 -），整组引脚号会错位，而两边一起错会互相印证，
  掩盖问题。这条规则只看 JSON 自身结构（脚号 + 名字里的 bank/通道号/极性），
  能独立抓出这类方向性错误，所以它是**不依赖 PDF 的独立证据**。

拆分前它住在 qc/table_audit.py 里，而那个模块顶层 import pymupdf、缺库直接
sys.exit(3)，还被 app / worker 这种常驻进程引用会产生副作用。抽出后：
  * qc/table_audit.py 继续 re-export（老调用方与既有单测不用改）；
  * app/services/review.py 规则层可直接用（红线审查零 token 命中）；
  * 可作为批量扫描器扫全库，统计「同一种错位还命中多少件」。
"""
from __future__ import annotations

import datetime
import json
import re
from pathlib import Path

# 名字形态：{bank}{可选下划线}{通道号}{极性}，如 RX0+ / DA12- / LANE_3+
PAIR_NAME = re.compile(r"^([A-Za-z]{2,5})_?(\d{1,2})([+-])$")

# 负极性在真实数据里常写成 Unicode 破折号而不是 ASCII '-'：实测前 2000 件里
# U+2013 出现 1256 次、U+2212 出现 423 次。不归一化就会把「负端全部漏收」，
# 只剩一堆 '+'，于是判成「同极性成对」——这是本检测器最大的假阳性来源。
_DASHES = str.maketrans({
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
    "\u2014": "-", "\u2212": "-", "\uff0d": "-",
})

# 判定门槛：少于 4 个脚（不足两对）或数量为奇数时不判，避免单端信号误报
MIN_PAIRS_ENTRIES = 4


def normalize_name(name) -> str:
    """统一破折号变体，去首尾空白。"""
    return str(name or "").strip().translate(_DASHES)


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def finding(path: str, kind: str, jv, tv) -> dict:
    """与 qc/table_audit.finding 同构，保持既有报告/台账字段一致。"""
    return {"path": path, "kind": kind, "json": jv, "table": tv, "at": _now()}


def collect_banks(doc: dict) -> dict[str, list[tuple[int, str, str]]]:
    """按 bank 收集 (脚号, 通道号, 极性)，只收名字符合差分对形态且脚号为整数的。"""
    banks: dict[str, list[tuple[int, str, str]]] = {}
    for pe in doc.get("pin_configuration") or []:
        if not isinstance(pe, dict):
            continue
        m = PAIR_NAME.match(normalize_name(pe.get("name")))
        if m and isinstance(pe.get("pin"), int):
            banks.setdefault(m.group(1).upper(), []).append(
                (pe["pin"], m.group(2), m.group(3)))
    return banks


# 球栅/网格封装：脚号是行列坐标序号，同通道 P/N 在网格上常隔一整行（实测
# ADC12DJ2700 的 DA 组各对脚号恒定相差 12）。这类封装上「按号相邻」不成立，
# 直接不做推断——否则 292 脚的 ADC 系列会整批误报。
BALL_GRID = re.compile(r"BGA|LGA|CSP|WLCSP|SIP|BALL|GRID", re.I)


def is_ball_grid(doc: dict) -> bool:
    pk = (doc.get("specs") or {}).get("package") or {}
    return bool(BALL_GRID.search(str(pk.get("type") or "")))


def audit_pin_pairs(doc: dict) -> list[dict]:
    """差分对结构自洽性检查（不看 PDF，只比 JSON 自身的脚号与名字）。

    缺陷形态：解析时把名字按前缀分组重排（先全部 +、再全部 -），同一通道的
    P/N 被塞进两段不相邻的脚号里。判据是「同一通道 P 与 N 的脚号间距」：

      * 全部为 1        → 正常（厂商表按脚号交替给出 P/N）；
      * 全 bank 同一个值且 >1 → 可疑：名字疑似按前缀分组重排（报 pin_pair_broken）；
      * 间距各不相同    → 正常：封装布线本来就不对称（QFN 两侧各放一半），不报。

    四道降假阳性闸（都是实测踩出来的）：
      1. 极性归一化：负端常用 Unicode 破折号（– / −），不归一化会整批漏收负端；
      2. 球栅封装直接跳过：脚号是网格坐标，相邻性无意义；
      3. bank 内 (通道号, 极性) 重复：说明多个通道共用前缀（名字没区分通道），
         配对逻辑不成立，跳过而不误报；
      4. bank 只有单一极性：可能是单端信号，只报 pin_polarity_missing（P2）。
    """
    if is_ball_grid(doc):
        return []
    finds: list[dict] = []
    for bank, lst in collect_banks(doc).items():
        if len(lst) < MIN_PAIRS_ENTRIES or len(lst) % 2:
            continue                                    # 不足两对或数量不齐，不判
        lanes: dict[str, dict[str, int]] = {}
        for pin, lane, sign in lst:
            lanes.setdefault(lane, {})[sign] = pin
        flat = [(lane, sign) for _, lane, sign in lst]
        if len(set(flat)) < len(flat):
            continue                                    # 通道号重复：多通道共用前缀
        signs = {s for _, _, s in lst}
        if len(signs) < 2:
            pins = ",".join(str(n) for n, _, _ in sorted(lst)[:6])
            finds.append(finding(f"pin_pair[{bank}]", "pin_polarity_missing",
                                 f"{len(lst)} 脚全为 {signs.pop() or '?'}",
                                 f"pin {pins}"))
            continue
        if any(len(v) < 2 for v in lanes.values()):
            continue                                    # 有通道只出现单侧，不可证
        deltas = {abs(v["+"] - v["-"]) for v in lanes.values()}
        if len(deltas) != 1:
            continue                                    # 间距不一致 = 封装布线，非错位
        delta = deltas.pop()
        if delta == 1:
            continue                                    # 正常
        sample = sorted(lanes.items())[:4]
        finds.append(finding(
            f"pin_pair[{bank}]", "pin_pair_broken",
            "间距恒为 %d：%s" % (delta, ", ".join(
                f"{lane}:+{v['+']}/-{v['-']}" for lane, v in sample)),
            f"{len(lanes)} 对同间距"))
    return finds


def summarize(finds: list[dict]) -> dict:
    """压成「哪些 bank 真错位、哪些 bank 只缺极性」，两类不可混谈。"""
    banks: dict[str, int] = {}
    broken = missing = 0
    for f in finds:
        kind = f.get("kind")
        if kind not in ("pin_pair_broken", "pin_polarity_missing"):
            continue
        if kind == "pin_polarity_missing":
            missing += 1
            continue
        broken += 1
        m = re.match(r"pin_pair\[([^\]]+)\]", str(f.get("path") or ""))
        if m:
            banks[m.group(1)] = banks.get(m.group(1), 0) + 1
    return {"broken_pairs": broken, "polarity_missing": missing, "banks": banks}


def audit_doc_path(path: str | Path) -> dict:
    """扫单个 JSON 文件；文件缺失/不可解析时返回 error 而不是抛异常（批量扫用）。"""
    p = Path(path)
    out: dict = {"file": str(p), "mpn": "", "findings": [], "error": ""}
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:                              # noqa: BLE001
        out["error"] = f"{type(e).__name__}: {e}"
        return out
    if not isinstance(doc, dict):
        out["error"] = "not_a_json_object"
        return out
    out["mpn"] = str((doc.get("basic_info") or {}).get("mpn")
                     or (doc.get("metadata") or {}).get("requested_mpn") or p.stem)
    out["findings"] = audit_pin_pairs(doc)
    out.update(summarize(out["findings"]))
    return out


def scan_files(paths, limit: int = 0) -> dict:
    """批量扫描。limit=0 表示不限。

    返回 {scanned, hit, broken_hit, polarity_hit, errors, items[], by_bank{}}；
    broken_hit 是「可证的错位」件数，polarity_hit 只代表「bank 缺一侧极性」，
    两者严重度不同，不要合并成一个数对外报。
    """
    items: list[dict] = []
    by_bank: dict[str, int] = {}
    scanned = errors = broken_hit = polarity_hit = 0
    for p in paths:
        if limit and scanned >= limit:
            break
        scanned += 1
        r = audit_doc_path(p)
        if r["error"]:
            errors += 1
            continue
        if r["findings"]:
            items.append(r)
            broken_hit += 1 if r.get("broken_pairs") else 0
            polarity_hit += 1 if r.get("polarity_missing") else 0
            for b, c in (r.get("banks") or {}).items():
                by_bank[b] = by_bank.get(b, 0) + c
    return {"scanned": scanned, "hit": len(items), "broken_hit": broken_hit,
            "polarity_hit": polarity_hit, "errors": errors,
            "items": items, "by_bank": by_bank}
