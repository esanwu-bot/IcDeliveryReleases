#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HANDOFF 2026-10-26 | qc/qc_diff.py 产物链 diff 生成器（agent-Qwen 交付 + 项目适配）
背景：QC 工作台「审计日志抽屉 → 产物链 diff 视图」的数据后端；与 diff 原型 HTML 字段 1:1。
基线：pre = data/parsed/{sn}.json.pre_audit（table_audit --write 的备份，ADAPT A2 实际命名）
      facts = data/facts/{sn}.facts.json（SSOT 侧车；与 patched 按公共骨架对比，应 0 差异）
行为：
  - 递归对比（dict 逐键 / list 按对齐键 pin|symbol|name|mpn|index 或下标）；
  - kind/src/note 归因：优先取 metadata.audit.findings 的同路径/同父路径记录，
    否则按补丁自带 source{page,table,row} 或字段后缀启发推断；
  - 产物链清单：parsed/pre_audit/facts/txt(en,ja,ko,de,es)/symbol.svg 存在性+大小+mtime；
  - --revert 逐字段回滚暂存（写 data/qc/staged/{sn}.revert.json，不直接覆盖正式 json；
    工作台「应用回滚」确认后覆盖正式 json 并仅投 render_item，不重解 PDF——客户约束）；
  - 跨机路径：DB 里 json_path 为落库机绝对路径时，按「反斜杠归一+文件名」回退。
环境变量：无新增。退出码：0 正常；3 缺 patched/baseline。
用法：
  python qc/qc_diff.py ADC3910S065IRSMT                       # 表格态
  python qc/qc_diff.py ADC3910S065IRSMT --mode json --write-diff
  python qc/qc_diff.py ADC3910S065IRSMT --baseline facts      # SSOT 一致性（应 0 差异）
  python qc/qc_diff.py ADC3910S065IRSMT --mode uni
  python qc/qc_diff.py --all-patched --write-diff              # 批量落 data/qc/diffs/
  python qc/qc_diff.py ADC3910S065IRSMT --revert "specs.electrical[3].unit" --write
前置：先跑 table_audit --write（或 qc_regression --write）生成 .json.pre_audit 基线。
server 进程安全：本模块无 stdout 包装等副作用，app/api/qc.py 直接 import。
项目适配（相对交付原版）：
  A1 路径根 = 项目根（脚本在 qc/ 下）；
  A2 locate 走 safe_name 归一 + 实际备份名 {sn}.json.pre_audit（兼容 {sn}.pre_audit.json）；
  A3 回滚暂存移到 data/qc/staged/（隔离目录，不混进 data/parsed 的 *.json glob）。
"""
from __future__ import annotations
import argparse, csv, datetime, json, re, sqlite3, sys
from pathlib import Path

ROOT   = Path(__file__).resolve().parent.parent          # ADAPT A1
PARSED = ROOT / "data" / "parsed"
FACTS  = ROOT / "data" / "facts"
TXT    = ROOT / "data" / "txt"
SYM    = ROOT / "data" / "symbols"
DIFFS  = ROOT / "data" / "qc" / "diffs"
STAGED = ROOT / "data" / "qc" / "staged"                 # ADAPT A3
DB     = ROOT / "data" / "workbench.sqlite3"
QC_JSON = ROOT / "qc" / "json"                           # 夹具基线（locate 第三级回退）
LANGS  = ("ja", "ko", "de", "es")
ALIGN_KEYS = ("pin", "symbol", "name", "mpn", "index", "title_ar", "title", "id")
NUM_TOL = 1e-9
TOK = re.compile(r"([^\.\[\]]+)|\[(.*?)\]")
HASH_SUFFIX = re.compile(r"_[0-9a-f]{8}$")               # 产物文件名去哈希后缀

KIND_NOTE = {
    "unit_dimension":   "维度本体：单位与参数/符号维度冲突，以表格单位列为准",
    "range_collapse":   "MIN/TYP/MAX 列角色被塌缩为区间，按表头恢复三列角色",
    "qualifier_loss":   "限定语丢失（只留最左数），按表格列恢复",
    "row_mispair":      "行错配：值属同表另一行，按行回显重绑定",
    "condition_leak":   "条件数值泄漏进值（如 VCC=0V 读成 Ioff=0），按本行限值列恢复",
    "pin_mismatch":     "引脚功能与引脚表不一致（按封装隔离）",
    "direction_reversal": "传输方向与真值表回显不一致",
    "package_mismatch": "封装应来自订购表 literal 行",
    "option_conflation": "家族选项频点/档位误用，按订购行绑定",
    "identity_family":  "家族号≠请求型号，mpn 还原、family 保留",
    "identity_unverified": "订购表未落实 literal 型号，只徽章不改写",
    "footnote_missing": "表脚注上标未绑定",
    "backup":           "补丁前原值留存字段",
    "trace":            "表格定位_trace（page/table/row）",
    "verify":           "verification 状态字段",
}


def now(): return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
def _nb(s): return str(s).replace("\\", "/")
def safe_name(mpn: str) -> str:
    """ADAPT A2：与 qc/table_audit 同口径（/ # 空格 → _）。"""
    return re.sub(r"[/#\s]+", "_", (mpn or "").strip())


# ── 路径解析（跨机回退，同 resolve_artifact 口径）──
def _resolve(stored, base):
    if not stored: return None
    sp = Path(_nb(stored))
    if sp.exists(): return sp
    c = base / sp.name
    return c if c.exists() else None


def _db_json(mpn):
    if not DB.exists(): return None
    try:
        con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
        cols = [r[1] for r in con.execute("pragma table_info(item)")]
        mcol = next((c for c in ("mpn", "requested_mpn", "part_number") if c in cols), None)
        row = con.execute(f"select json_path from item where {mcol}=? limit 1", (mpn,)).fetchone() if mcol else None
        con.close()
        return _resolve(row[0], PARSED) if row and row[0] else None
    except Exception:
        return None


def _find_json(mpn):
    """按 safe_name+哈希后缀口径在 PARSED / qc_json 扫描（夹具件落在 qc/json 基线）。"""
    target = safe_name(mpn).lower()
    for d in (PARSED, QC_JSON):
        if not d.exists(): continue
        for p in sorted(d.glob("*.json")):
            if p.name.endswith((".alts.json", ".seo.json")) or ".pre_audit" in p.name or ".revert" in p.name:
                continue
            stem = HASH_SUFFIX.sub("", p.stem).lower()
            if stem == target or stem.startswith(target + "_"):
                return p
    return None


def locate(mpn):
    sn = safe_name(mpn)
    cur = PARSED / f"{sn}.json"
    if not cur.exists(): cur = _db_json(mpn) or _find_json(mpn) or cur
    # pre 备份与 patched 同目录（table_audit --write 对 src_json 路径备份；夹具件即 qc/json 下）
    pre = None
    if cur and cur.exists():
        for cand in (cur.with_name(cur.name + ".pre_audit"),
                     cur.with_name(HASH_SUFFIX.sub("", cur.stem) + ".pre_audit.json")):
            if cand.exists(): pre = cand; break
    fac = FACTS / f"{sn}.facts.json"
    return {"patched": cur if cur.exists() else None, "sn": sn,
            "pre": pre, "facts": fac if fac.exists() else None}


# ── 递归 diff ──
def eq(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)): return abs(a - b) <= NUM_TOL
    if isinstance(a, str) and isinstance(b, str): return a.strip() == b.strip()
    return a == b


def align_key(lst):
    dicts = [e for e in lst if isinstance(e, dict)]
    if not dicts: return None
    for k in ALIGN_KEYS:
        vals = [e.get(k) for e in dicts if e.get(k) is not None]
        if len(vals) == len(dicts) and len({str(v) for v in vals}) == len(vals): return k
    return None


def mk(p, op, pre, post): return {"p": p, "op": op, "pre": pre, "post": post}


def walk(pre, post, path, out, st):
    if isinstance(pre, dict) and isinstance(post, dict):
        for k in sorted(set(pre) | set(post)):
            p = f"{path}.{k}" if path else k
            if k not in pre:   out.append(mk(p, "add", None, post[k])); st["add"] += 1
            elif k not in post: out.append(mk(p, "del", pre[k], None)); st["del"] += 1
            else: walk(pre[k], post[k], p, out, st)
        return
    if isinstance(pre, list) and isinstance(post, list):
        kp = align_key(pre); kq = align_key(post)
        if kp and kp == kq:
            idx = {str(e.get(kp)): i for i, e in enumerate(post) if isinstance(e, dict)}
            seen = set()
            for e in pre:
                if not isinstance(e, dict): continue
                key = str(e.get(kp)); seen.add(key); p = f"{path}[{key}]"
                j = idx.get(key)
                if j is None: out.append(mk(p, "del", e, None)); st["del"] += 1
                else: walk(e, post[j], p, out, st)
            for e in post:
                if isinstance(e, dict) and str(e.get(kp)) not in seen:
                    out.append(mk(f"{path}[{e.get(kp)}]", "add", None, e)); st["add"] += 1
            return
        for i in range(max(len(pre), len(post))):
            p = f"{path}[{i}]"
            if i >= len(pre):   out.append(mk(p, "add", None, post[i])); st["add"] += 1
            elif i >= len(post): out.append(mk(p, "del", pre[i], None)); st["del"] += 1
            else: walk(pre[i], post[i], p, out, st)
        return
    if eq(pre, post): st["same"] += 1; return
    out.append(mk(path, "mod", pre, post)); st["mod"] += 1


def prune(post, base):
    """facts 基线：只比公共骨架，骨架外键不计 add（验证 SSOT 一致性用）"""
    if isinstance(base, dict) and isinstance(post, dict):
        return {k: prune(post[k], base[k]) for k in base if k in post}
    if isinstance(base, list) and isinstance(post, list):
        kb, kq = align_key(base), align_key(post)
        if kb and kb == kq:
            idx = {str(e.get(kb)): e for e in post if isinstance(e, dict)}
            return [prune(idx[str(e.get(kb))], e) for e in base
                    if isinstance(e, dict) and str(e.get(kb)) in idx]
        return [prune(post[i], b) for i, b in enumerate(base) if i < len(post)]
    return post


# ── kind/src 归因 ──
def _parent_of(p): return p.rsplit(".", 1)[0] if "." in p else p


def _get(doc, path):
    cur = doc
    for name, br in TOK.findall(path):
        key = name or br
        if isinstance(cur, list):
            i = int(key) if key.lstrip("-").isdigit() else _idx(cur, key)
            if i is None: return None
            cur = cur[i]
        elif isinstance(cur, dict) and key in cur: cur = cur[key]
        else: return None
    return cur


def _idx(lst, key):
    k = align_key(lst)
    if not k: return None
    for i, e in enumerate(lst):
        if isinstance(e, dict) and str(e.get(k)) == key: return i
    return None


def enrich(fields, doc):
    fl = ((doc.get("metadata") or {}).get("audit") or {}).get("findings") or []
    for fd in fields:
        hit = next((f for f in fl if f.get("path") == fd["p"]
                    or fd["p"].startswith(f.get("path", "") + ".")
                    or _parent_of(fd["p"]) == _parent_of(f.get("path", ""))), None)
        if hit: fd["kind"] = hit.get("kind", "change")
        elif fd["p"].endswith(".unit"): fd["kind"] = "unit_dimension"
        elif fd["p"].endswith(".columns"): fd["kind"] = "qualifier_loss"
        elif fd["p"].endswith("value_raw_original"): fd["kind"] = "backup"
        elif fd["p"].endswith(".source"): fd["kind"] = "trace"
        elif "verification" in fd["p"]: fd["kind"] = "verify"
        else: fd["kind"] = "change"
        src = hit.get("table") if hit else None
        if not src:
            par = _get(doc, _parent_of(fd["p"]))
            if isinstance(par, dict) and par.get("source"):
                s = par["source"]; src = f"p{s.get('page')} · Table {s.get('table')} · row{s.get('row')}"
        fd["src"] = src or ""
        fd["note"] = KIND_NOTE.get(fd["kind"], "")
    return fields


def artifacts(mpn, loc):
    sn = loc.get("sn") or safe_name(mpn)
    arts = []
    def add(kind, p, note):
        p = Path(p) if p else None
        ok = bool(p and p.exists())
        arts.append({"kind": kind, "path": str(p) if p else None, "exists": ok,
                     "bytes": p.stat().st_size if ok else None,
                     "mtime": datetime.datetime.fromtimestamp(p.stat().st_mtime).astimezone().isoformat(timespec="seconds") if ok else None,
                     "note": note})
    add("parsed_json", loc["patched"], "当前 patched")
    add("pre_audit",  loc["pre"],   "补丁前备份（diff 基线）")
    add("facts",      loc["facts"], "SSOT 侧车")
    add("txt_en", TXT / f"{sn}.txt", "渲染产物")
    for lg in LANGS: add(f"txt_{lg}", TXT / f"{sn}.{lg}.txt", "渲染产物变体")
    sym = SYM / f"{sn}.html"                     # ADAPT A4：本项目符号页为 .html（item.symbol_path 同口径）
    if not sym.exists():
        sym = SYM / f"{sn}.svg"                  # 兜底通用 .svg 命名
    add("symbol_svg", sym, "随引脚表联动")
    return arts


# ── payload ──
def build(mpn, baseline="pre"):
    loc = locate(mpn)
    if not loc["patched"]: return None
    doc = json.loads(loc["patched"].read_text(encoding="utf-8"))
    bp = loc["pre"] if baseline == "pre" else loc["facts"]
    if not bp:
        return {"mpn": mpn, "baseline": baseline,
                "error": "baseline 缺失（先跑 table_audit/qc_regression --write）",
                "stats": {"add": 0, "mod": 0, "del": 0, "same": 0},
                "fields": [], "artifacts": artifacts(mpn, loc),
                "verification": (doc.get("metadata") or {}).get("verification") or {},
                "audit_kinds": ((doc.get("metadata") or {}).get("audit") or {}).get("patched_kinds", [])}
    base = json.loads(bp.read_text(encoding="utf-8"))
    post = prune(doc, base) if baseline == "facts" else doc
    out, st = [], {"add": 0, "mod": 0, "del": 0, "same": 0}
    walk(base, post, "", out, st)
    enrich(out, doc)
    return {"mpn": mpn, "baseline": baseline, "generated_at": now(), "stats": st, "fields": out,
            "artifacts": artifacts(mpn, loc),
            "verification": (doc.get("metadata") or {}).get("verification") or {},
            "audit_kinds": ((doc.get("metadata") or {}).get("audit") or {}).get("patched_kinds", [])}


# ── 回滚暂存 ──
def _set(doc, path, val):
    toks = TOK.findall(path); cur = doc
    for i, (name, br) in enumerate(toks):
        key = name or br; last = i == len(toks) - 1
        if isinstance(cur, list):
            j = int(key) if key.lstrip("-").isdigit() else _idx(cur, key)
            if j is None: return False
            if last: cur[j] = val
            else: cur = cur[j]
        else:
            if last: cur[key] = val
            elif key not in cur: return False
            else: cur = cur[key]
    return True


def _del(doc, path):
    toks = TOK.findall(path); cur = doc
    for i, (name, br) in enumerate(toks):
        key = name or br; last = i == len(toks) - 1
        if isinstance(cur, list):
            j = int(key) if key.lstrip("-").isdigit() else _idx(cur, key)
            if j is None: return False
            if last: cur.pop(j)
            else: cur = cur[j]
        else:
            if last: cur.pop(key, None); return True
            if key not in cur: return False
            cur = cur[key]
    return True


def revert(mpn, paths, write=False):
    """逐字段回滚：add → 删字段；mod/del → 恢复基线原值。write=True 落暂存文件。

    暂存不直接覆盖正式 json（客户约束：覆盖 + render_item 由工作台二次确认）。
    """
    pay = build(mpn, "pre")
    if not pay or pay.get("error"): return pay
    loc = locate(mpn)
    doc = json.loads(loc["patched"].read_text(encoding="utf-8"))
    byp = {f["p"]: f for f in pay["fields"]}
    done, missed = [], []
    for p in paths:
        f = byp.get(p)
        if not f: missed.append(p); continue
        ok = _del(doc, p) if f["op"] == "add" else _set(doc, p, f["pre"])
        (done if ok else missed).append(p)
    staged = STAGED / f"{loc['sn']}.revert.json"
    if write and done:
        STAGED.mkdir(parents=True, exist_ok=True)
        staged.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"mpn": mpn, "reverted": done, "missed": missed,
            "staged": str(staged) if write and done else None,
            "next": "确认后将 staged 覆盖正式 json 并投递 render_item（仅重渲染，不重解 PDF）；台账追加 revert 记录"}


# ── 渲染四态 ──
def _s(v): return "∅" if v is None else (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v))


def to_table(p):
    if p.get("error"): return f"[{p['mpn']}] {p['error']}"
    L = [f"[{p['mpn']}] baseline={p['baseline']} stats={p['stats']}"]
    for f in p["fields"]:
        L.append(f"  {f['op']:>3} {f['p']:<48} {_s(f['pre'])[:40]:<42} → {_s(f['post'])[:40]:<42} [{f['kind']}] {f['src']}")
    if not p["fields"]: L.append("  （无差异）")
    return "\n".join(L)


def to_uni(p):
    if p.get("error"): return p["error"]
    L = [f"--- a/{p['baseline']}基线", f"+++ b/parsed({p['mpn']})"]
    for f in p["fields"]:
        L.append(f"  # {f['kind']} · {f['src'] or f['note']}")
        if f["op"] != "add":  L.append(f"- {f['p']}: {_s(f['pre'])}")
        if f["op"] != "del":  L.append(f"+ {f['p']}: {_s(f['post'])}")
    return "\n".join(L) or "（无差异）"


def to_csv(p, w):
    wr = csv.writer(w); wr.writerow(["mpn", "path", "op", "kind", "pre", "post", "src", "note"])
    for f in p["fields"]:
        wr.writerow([p["mpn"], f["p"], f["op"], f["kind"], _s(f["pre"]), _s(f["post"]), f["src"], f["note"]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mpns", nargs="*")
    ap.add_argument("--all-patched", action="store_true")
    ap.add_argument("--baseline", choices=["pre", "facts"], default="pre")
    ap.add_argument("--mode", choices=["json", "table", "uni", "csv"], default="table")
    ap.add_argument("--write-diff", action="store_true")
    ap.add_argument("--revert", nargs="*", default=None)
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    mpns = list(a.mpns)
    if a.all_patched:                                     # ADAPT A2：两种备份命名都扫
        sn = {p.name.split(".json")[0] for p in PARSED.glob("*.json.pre_audit")}
        sn |= {p.name.split(".pre_audit.json")[0] for p in PARSED.glob("*.pre_audit.json")}
        mpns += sorted(sn)
    if not mpns: ap.error("需要型号或 --all-patched")
    miss = 0
    for m in mpns:
        if a.revert is not None:
            r = revert(m, a.revert, write=a.write)
            print(json.dumps(r, ensure_ascii=False)); continue
        p = build(m, a.baseline)
        if not p: miss += 1; print(f"[{m}] 缺 patched json"); continue
        if a.write_diff:
            DIFFS.mkdir(parents=True, exist_ok=True)
            (DIFFS / f"{locate(m)['sn']}.diff.json").write_text(
                json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")
        if a.mode == "json":   print(json.dumps(p, ensure_ascii=False, indent=1))
        elif a.mode == "uni":  print(to_uni(p))
        elif a.mode == "csv":  to_csv(p, sys.stdout)
        else:                  print(to_table(p))
    sys.exit(3 if miss and miss == len(mpns) else 0)


if __name__ == "__main__":
    main()
