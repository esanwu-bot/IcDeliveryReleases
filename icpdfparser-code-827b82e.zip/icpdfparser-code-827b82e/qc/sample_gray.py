# -*- coding: utf-8 -*-
"""1102-V3.3 灰度抽样：只读 workbench，排除评估板/套件，产出 list.txt + symlink 目录。

为什么必须排除板卡件（100 件灰度的教训）：
  交付库里有大量 `...EVM` / `...EVAL` / `...PDK` 的评估板手册，原厂往往**不给**
  完整电气表（只有板级参数），`electrical >= 3` 的校验会把它们全部判死，
  于是在灰度日志里表现为「一连串 empty_electrical」——那不是抽取器的缺陷，
  是样本被板卡污染。抽样侧就要把它们挡在门外，别让它们污染 baseline。

用法：
  python qc/sample_gray.py --db data/workbench.sqlite3 --pdfs data/pdfs \\
      --n 100 --out /root/_gray100
"""
from __future__ import annotations

import argparse
import os
import sqlite3
from pathlib import Path

#: 板卡/套件/参考设计的型号特征（大写匹配）。宁可错杀，也别让板卡混进芯片基线。
BOARD_TOKENS = (
    "EVM", "EVAL", "EVK", "PDK", "BOOST", "KIT", "DEMO", "DEVBOARD",
    "REFERENCE", "REFDES", "ADAPTER", "XLR", "MODULE",
)


def is_board_like(mpn: str) -> bool:
    """评估板/套件/参考设计判定。`EVM`、`EVAL`、`PDK`、`BOOST`、`KIT` 等即命中。"""
    up = (mpn or "").upper()
    return any(t in up for t in BOARD_TOKENS)


def pick(db: str, pdfs: Path, n: int, max_bytes: int) -> list[tuple[str, Path]]:
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    cols = [r[1] for r in con.execute("pragma table_info(item)")]
    mpn_col = next((c for c in ("requested_mpn", "mpn", "part_number") if c in cols), None)
    if not mpn_col or "pdf_path" not in cols:
        raise SystemExit(f"schema 不匹配：缺 {mpn_col!r}/pdf_path，现有列 {cols}")
    q = f"select {mpn_col}, pdf_path from item where pdf_path is not null"
    if "status" in cols:
        q += " and status='done'"
    rows = con.execute(q).fetchall()
    con.close()

    seen, out = set(), []
    for mpn, pdf in rows:
        mpn = str(mpn or "").strip()
        if not mpn or mpn in seen or is_board_like(mpn):
            continue
        src = pdfs / Path(str(pdf).replace("\\", "/")).name
        if not src.is_file() or src.stat().st_size > max_bytes:
            continue
        seen.add(mpn)
        out.append((mpn, src))
        if len(out) >= n:
            break
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/workbench.sqlite3")
    ap.add_argument("--pdfs", default="data/pdfs")
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--max-mb", type=int, default=6)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    out_dir = Path(a.out)
    (out_dir / "pdfs").mkdir(parents=True, exist_ok=True)
    # 必须解析成**绝对路径**：符号链接写相对路径时，容器内挂载点不同会全部失效
    # （实测 `FileNotFoundError: /pdfs/LM358.pdf`）。
    items = pick(a.db, Path(a.pdfs).resolve(), a.n, a.max_mb * 1024 * 1024)
    for mpn, src in items:
        link = out_dir / "pdfs" / f"{mpn.replace('/', '_')}.pdf"
        if link.is_symlink() or link.exists():
            link.unlink()
        os.symlink(src, link)
    (out_dir / "list.txt").write_text("".join(m + "\n" for m, _ in items), encoding="utf-8")
    print(f"picked={len(items)} -> {out_dir}/list.txt（板卡件已排除）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
