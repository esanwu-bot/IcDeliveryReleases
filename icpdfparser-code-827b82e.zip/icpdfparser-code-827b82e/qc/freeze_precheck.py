"""冻结前置自查：守卫 8 条 + 粒度 + 字段收口，一键绿红表（阶段 B 清单 §4 的 1:1 实现）。

检查项（与《阶段 B 逐件检查清单》§4 对应）：
  G1 status           证据卡非 source_unresolved
  G2 identity         身份 verified 且有人工核验人（verified_by 非空）
  G3 官方 P0          存在 tier=P0 或官方域名命中的文档
  G4 覆盖型号         无 open 的 identity_unverified 风险 case
  G5 字段证据         每个 Gold 字段都有证据行，且无 conflict* 残留
  G6 页码             verified 行 page_number > 0
  G7 核验人           verified 行 reviewer 非空（机器草稿不算）
  G8 Gold SHA         source_document.pdf_sha256 == gold_set.pdf_sha256
  G9 粒度             source_evidence.target_fields_json ⊇ Gold 全字段
  G10 字段收口        gold_field 无 pending/conflict 残留（空白=not_specified 也要显式核验）

末尾附**服务端 `can_freeze` 复核行**（口径漂移自检）：不一致以服务端为准。
红行自带处置建议；`missing_fe` / `missing_tf` 输出可粘贴的补挂接清单。

红线：**只读自查**——不写库、不冻结；页码口径 = PDF 物理页（1 起）。
退出码：0 全绿 / 1 有红 / 3 找不到证据卡。import 零 stdout 副作用（server 安全）。

用法：
  python qc/freeze_precheck.py --mpn BUF634PG4
  python qc/freeze_precheck.py --mpn DAC8555IPWG4 --json
  python qc/freeze_precheck.py --all          # 冻结日批量 triage
  docker exec icpdf-server python /app/qc/freeze_precheck.py --all
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

CLOSED_OK = {"verified"}
NOT_SPEC = "not_specified"


def _db(dbm=None):
    if dbm is not None:
        return dbm
    from app import db as _dbm
    return _dbm


def _int(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _tables(db) -> set:
    return {r["name"] for r in db.q("SELECT name FROM sqlite_master WHERE type='table'")}


def _official(url: str) -> bool:
    try:
        from qc import source_evidence as SE
        return bool(SE.is_official_url(url or ""))
    except Exception:                                            # noqa: BLE001
        return False


def _tf_set(raw) -> set:
    if not raw:
        return set()
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
        if isinstance(v, list):
            return {str(x).strip() for x in v if str(x).strip()}
    except Exception:                                            # noqa: BLE001
        pass
    return {x.strip() for x in str(raw).split(",") if x.strip()}


def run(db, mpn: str | None = None, evidence_id: int | None = None) -> dict | None:
    ev = (db.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,)) if evidence_id
          else db.q1("SELECT * FROM source_evidence WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,)))
    if not ev:
        return None
    mpn = ev.get("mpn") or mpn
    doc = db.q1("SELECT * FROM source_document WHERE id=?", (ev.get("document_id") or 0,)) or {}
    fes = db.q("SELECT * FROM source_field_evidence WHERE evidence_id=?", (ev["id"],))
    gold = db.q1("SELECT * FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,)) or {}
    gf = db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold.get("id") or 0,)) if gold else []
    gpaths = [g["field_path"] for g in gf]
    out = {"mpn": mpn, "evidence_id": ev["id"], "gold_id": gold.get("id"),
           "gold_status": gold.get("status"), "checks": []}

    def add(no, name, ok, detail, fix):
        out["checks"].append({"no": no, "name": name, "ok": bool(ok),
                              "detail": detail, "fix": fix})

    st = ev.get("status") or ""
    add(1, "status", st != "" and st != "source_unresolved", f"status={st or '(空)'}",
        "source_unresolved → 补证据或标未核实，不冻结")

    istat = (doc.get("identity_status") or "")
    irev = (ev.get("verified_by") or "").strip()
    add(2, "identity verified+reviewer", istat == "verified" and bool(irev),
        f"identity={istat or 'pending'}, reviewer={irev or 'null'}",
        "证据卡 → 人工确认身份（接口仅人工可写，机器写不进）")

    is_p0 = (doc.get("source_tier") or "").upper() == "P0" or bool(doc.get("is_official"))
    add(3, "官方 P0", bool(doc.get("id")) and is_p0,
        f"tier={doc.get('source_tier') or '—'}, 官方域={bool(doc.get('is_official'))}, "
        f"url={(doc.get('source_url') or '—')[:48]}",
        "镜像/CDN 域名 → 换 ti.com / ti.com.cn 原件重登记")

    rc = 0
    if "risk_case" in _tables(db):
        r = db.q1("SELECT count(*) c FROM risk_case WHERE mpn=? AND kind='identity_unverified' "
                  "AND status IN ('open','confirming','to_regression')", (mpn,))
        rc = r["c"] if r else 0
    cov = _tf_set(doc.get("covered_mpn_json"))
    covered = (mpn or "").strip().upper() in {str(x).strip().upper() for x in cov}
    add(4, "覆盖型号(人工确认+无open风险)", covered and rc == 0,
        f"covered={cov or '（未人工确认）'}, open_risk={rc}",
        "订购表未覆盖 literal 后缀 → source_unresolved 流程；覆盖型号只能人工确认")

    conf_fe = [f for f in fes if "conflict" in (f.get("verification_status") or "")]
    conf_gf = [g for g in gf if (g.get("status") or "") == "conflict"]
    fe_any = {f.get("field_path") for f in fes}
    fe_ver = {f.get("field_path") for f in fes
              if (f.get("verification_status") or "") in CLOSED_OK}
    no_ev = [p for p in gpaths if p not in fe_any]
    miss_fe = [p for p in gpaths if p not in fe_ver]
    add(5, "字段证据(每字段已验证+无conflict)",
        (not conf_fe) and (not conf_gf) and (not miss_fe),
        f"conflict(fe/gf)={len(conf_fe)}/{len(conf_gf)}, 无证据行={len(no_ev)}, "
        f"未核验={len(miss_fe)}",
        "conflict → 先裁决（改 expected=原厂值 或 保留+note）；"
        "未核验 → 逐字段 verify（高风险须 quote）或批量确认非高风险")

    ver_rows = [f for f in fes if (f.get("verification_status") or "") in CLOSED_OK]
    bad_pg = [f for f in ver_rows if _int(f.get("page_number")) <= 0]
    add(6, "页码>0(verified行)", not bad_pg, f"bad={len(bad_pg)}",
        "补页码（口径 = PDF 物理页 1 起）")

    bad_rev = [f for f in ver_rows if not (f.get("reviewer") or "").strip()]
    add(7, "核验人非空(verified行)", not bad_rev, f"bad={len(bad_rev)}",
        "机器草稿未确认 → 回人工核验（单字段 verify 或批量确认）")

    gsha = (gold.get("pdf_sha256") or "").strip()
    dsha = (doc.get("pdf_sha256") or "").strip()
    add(8, "Gold SHA一致", (not gsha) or (gsha == dsha),
        f"gold={(gsha or '—')[:12]}…, doc={(dsha or '—')[:12]}…",
        "版本漂移 → 重登记文档 + 重验受影响字段（勿静默覆盖）")

    tf_raw = ev.get("target_fields_json")
    tf = _tf_set(tf_raw)
    miss_tf = [p for p in gpaths if p not in tf]
    add(9, "粒度:target_fields⊇全字段", bool(tf_raw) and not miss_tf,
        f"target={len(tf)}/{len(gpaths)}, 缺={len(miss_tf)}"
        + (f" 如{miss_tf[:3]}" if miss_tf else ""),
        "冻结前把 target_fields 补成 Gold 全字段路径（防「部分核验冻整件」）")

    pending = [g for g in gf if (g.get("status") or "pending") not in CLOSED_OK]
    n_ns = sum(1 for g in gf if (g.get("expected") or "").strip().lower() == NOT_SPEC)
    add(10, "字段收口(无pending残留)", not pending,
        f"closed={len(gf) - len(pending)}/{len(gf)}（其中 not_specified {n_ns}）"
        + (f", 如{[g['field_path'] for g in pending[:3]]}" if pending else ""),
        "回阶段 B §1 补核验；空白 = not_specified（也要显式入证）")

    # 服务端 can_freeze 复核行（口径漂移自检）
    try:
        from qc import source_evidence as SE
        ok, why = SE.can_freeze(dict(ev, gold_pdf_sha256=gsha), doc, fes, gf)
        out["server_can_freeze"] = bool(ok)
        out["server_message"] = why
    except Exception as e:                                       # noqa: BLE001
        out["server_can_freeze"] = None
        out["server_message"] = f"复核失败：{e}"
    out["missing_fe"] = miss_fe          # G5 判据：缺「已验证」证据的字段（含待核验）
    out["missing_no_evidence"] = no_ev   # 真正需要「挂接」的字段（连证据行都没有）
    out["missing_tf"] = miss_tf
    return out


def attach_list(db, r: dict) -> list:
    """G5/G9 缺失明细 → 补挂接清单（含 cheatsheet 定位与证据模板预填）。

    每行：{mpn, evidence_id, gap, field_path, locator, tpl, risk}；`gap` ∈
    field_evidence（**连证据行都没有** → 需挂接）/ target_fields（缺 target 粒度）。
    ⚠️ 口径提醒：`missing_fe` 是 G5 判据（含"有行未核验"），而挂接只需 `missing_no_evidence`；
    二者不可混用，否则会把"待核验"误报成"缺挂接"。
    只读：不动库。风险级与证据模板直接复用 qc/cheatsheet.py 的规则引擎，避免两套口径。
    """
    from qc import cheatsheet as CS
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (r["mpn"],))
    gf = {}
    if gold:
        for g in db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold["id"],)):
            gf[g["field_path"]] = g
    rows = []
    need = r.get("missing_no_evidence")
    if need is None:                       # 兼容旧调用：退回 G5 口径（更宽）
        need = r.get("missing_fe") or []
    for gap, paths in (("field_evidence", need),
                       ("target_fields", r.get("missing_tf") or [])):
        for p in paths:
            g = gf.get(p) or {}
            L = CS.locate({"field_path": p, "field_name": g.get("field_name") or "",
                           "expected": g.get("expected"), "unit": g.get("unit") or ""},
                          r["mpn"])
            rows.append({"mpn": r["mpn"], "evidence_id": r["evidence_id"], "gap": gap,
                         "field_path": p,
                         "locator": f"{L['sec']} · {L['row']} / {L['col']}",
                         "tpl": L["tpl"], "ns": L.get("ns", ""), "risk": L["risk"],
                         "status": "missing" if gap == "field_evidence" else "not_in_target"})
    return rows


def render_attach(rows: list) -> str:
    if not rows:
        return "── 补挂接清单：无缺失 ──"
    lines = ["── 补挂接清单（可粘贴）──"]
    for gap, tag in (("field_evidence", "缺字段证据 G5"), ("target_fields", "缺 target_fields G9")):
        sub = [x for x in rows if x["gap"] == gap]
        if not sub:
            continue
        lines.append(f"[{tag}] {len(sub)} 条：")
        for x in sub:
            lines.append(f"  {x['field_path']:<38} | {x['locator']} | 证据模板: {x['tpl']} | {x['risk']}")
    fe = [x["field_path"] for x in rows if x["gap"] == "field_evidence"]
    if fe:
        lines.append("粘贴格式（抽屉「批量挂接」框 / attach_missing --from jsonl，每行一个 field_path）：")
        lines += [f"  {p}" for p in fe]
    return "\n".join(lines)


def render_text(r: dict) -> str:
    lines = [f"[{r['mpn']}] 冻结前置自查 · evidence#{r['evidence_id']} "
             f"gold#{r['gold_id']}({r['gold_status']})"]
    for c in r["checks"]:
        lines.append(f" {'✓' if c['ok'] else '✗'} G{c['no']:>2} {c['name']:<32} {c['detail']}")
        if not c["ok"]:
            lines.append(f"     └ 处置: {c['fix']}")
    good = sum(1 for c in r["checks"] if c["ok"])
    total = len(r["checks"])
    ready = good == total
    tail = f" 汇总: {good}/{total} 绿 → 冻结就绪: {'YES' if ready else 'NO'}"
    if r.get("server_can_freeze") is not None:
        flag = "" if r["server_can_freeze"] == ready else "（与服务端不一致→查 schema/口径漂移）"
        tail += f" · 服务端can_freeze={r['server_can_freeze']}{flag}"
    lines.append(tail)
    if r.get("missing_fe"):
        lines.append(" 补挂接清单(缺字段证据, 可粘贴): " + " ".join(r["missing_fe"]))
    if r.get("missing_tf"):
        lines.append(" 补 target_fields(可粘贴): " + json.dumps(r["missing_tf"], ensure_ascii=False))
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpn")
    ap.add_argument("--evidence-id", type=int)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--emit-attach", metavar="JSONL", help="导出补挂接清单为 jsonl")
    ap.add_argument("--no-attach", action="store_true", help="text 模式不打印补挂接清单")
    a = ap.parse_args(argv)
    db = _db(None)
    if a.all:
        reps = [r for r in (run(db, mpn=e["mpn"]) for e in
                            db.q("SELECT DISTINCT mpn FROM source_evidence ORDER BY mpn")) if r]
        if a.json:
            print(json.dumps(reps, ensure_ascii=False, indent=1))
            return 0 if reps and all(all(c["ok"] for c in r["checks"]) for r in reps) else 1
        for r in reps:
            good = sum(1 for c in r["checks"] if c["ok"])
            print(f"{r['mpn']:<22} {good}/{len(r['checks'])} 绿 "
                  f"{'READY' if good == len(r['checks']) else '未就绪'}")
        return 0 if reps and all(all(c["ok"] for c in r["checks"]) for r in reps) else 1
    if not (a.mpn or a.evidence_id):
        ap.error("需要 --mpn / --evidence-id / --all")
    r = run(db, mpn=a.mpn, evidence_id=a.evidence_id)
    if not r:
        print("找不到证据卡", file=sys.stderr)
        return 3
    if a.emit_attach:
        rows = attach_list(db, r)
        out = Path(a.emit_attach)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + "\n",
                       encoding="utf-8")
        print(f"written {a.emit_attach} ({len(rows)} 行)")
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=1))
    else:
        print(render_text(r) + ("" if a.no_attach else "\n" + render_attach(attach_list(db, r))))
    return 0 if all(c["ok"] for c in r["checks"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())