"""补挂接执行器：把 freeze_precheck 的 G5/G9 缺失明细以**机器草稿**落库。

  gap=field_evidence → 建 `source_field_evidence` 草稿（page/quote 空、reviewer 空、状态 pending）
  gap=target_fields  → 并入 `source_evidence.target_fields_json`（**并集**，不删现有）

幂等：同 `evidence_id + field_path` 已有证据行则跳过；target 已含该路径则跳过。
留痕：`source_verification_log` actor=machine，action=`attach_draft` / `target_extend`（append-only）。

红线：**只起草，不写 verified**；page_number / evidence_quote 仍由人工核验填写
（G6/G7 守卫不变 —— 挂接后 G5/G9 转绿只是"有了位置"，不等于"已核验"）。

用法：
  python qc/freeze_precheck.py --mpn DAC8555IPWG4 --emit-attach data/qc/attach.jsonl
  python qc/attach_missing.py --from data/qc/attach.jsonl --dry
  python qc/attach_missing.py --from data/qc/attach.jsonl --apply
  python qc/attach_missing.py --mpn DAC8555IPWG4 --apply          # 现算现挂
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

TARGET_COL = "target_fields_json"


def _db(dbm=None):
    if dbm is not None:
        return dbm
    from app import db as _dbm
    return _dbm


def _tf_set(raw) -> list:
    if not raw:
        return []
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
        if isinstance(v, list):
            return [str(x).strip() for x in v if str(x).strip()]
    except Exception:                                            # noqa: BLE001
        pass
    return [x.strip() for x in str(raw).split(",") if x.strip()]


def apply_rows(db, rows: list, dry: bool = True) -> dict:
    """逐行落草稿；返回 {field_evidence, target_fields, skipped, details}。"""
    from qc import source_evidence as SE
    done = {"field_evidence": 0, "target_fields": 0, "skipped": 0, "details": []}
    for r in rows or []:
        ev = int(r.get("evidence_id") or 0)
        p = str(r.get("field_path") or "").strip()
        gap = r.get("gap") or "field_evidence"
        if not ev or not p:
            done["skipped"] += 1
            done["details"].append({"field_path": p, "gap": gap, "why": "缺 evidence_id/field_path"})
            continue
        card = db.q1("SELECT * FROM source_evidence WHERE id=?", (ev,))
        if not card:
            done["skipped"] += 1
            done["details"].append({"field_path": p, "gap": gap, "why": "证据卡不存在"})
            continue
        if gap == "field_evidence":
            if db.q1("SELECT id FROM source_field_evidence WHERE evidence_id=? AND field_path=?",
                     (ev, p)):
                done["skipped"] += 1
                continue
            gf = db.q1("SELECT g.id FROM gold_field g WHERE g.gold_id=(SELECT id FROM gold_set "
                       "WHERE mpn=? ORDER BY id DESC LIMIT 1) AND g.field_path=?",
                       (card["mpn"], p)) or {}
            if not dry:
                SE.add_field_evidence(ev, p, page_number=0, table_name="", row_key="",
                                      column_key="", cell_value="", evidence_quote="",
                                      gold_field_id=int(gf.get("id") or 0),
                                      operator="machine", db_mod=db)
                SE._log(db, ev, int(card.get("document_id") or 0), "attach_draft", "machine",
                        details={"field_path": p, "note": "机器草稿：page/quote 待人工填"})
            done["field_evidence"] += 1
        else:
            tf = _tf_set(card.get(TARGET_COL))
            if p in tf:
                done["skipped"] += 1
                continue
            if not dry:
                tf.append(p)
                db.x(f"UPDATE source_evidence SET {TARGET_COL}=?, updated_at=? WHERE id=?",
                     (json.dumps(tf, ensure_ascii=False), SE.now(), ev))
                SE._log(db, ev, int(card.get("document_id") or 0), "target_extend", "machine",
                        details={"added": p, "total": len(tf)})
            done["target_fields"] += 1
    return done


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="src", help="freeze_precheck --emit-attach 的 jsonl")
    ap.add_argument("--mpn")
    ap.add_argument("--apply", action="store_true", help="写库（默认 dry）")
    a = ap.parse_args(argv)
    db = _db(None)
    if a.src:
        rows = [json.loads(x) for x in Path(a.src).read_text(encoding="utf-8").splitlines()
                if x.strip()]
    elif a.mpn:
        from qc import freeze_precheck as FP
        r = FP.run(db, mpn=a.mpn)
        if not r:
            print("找不到证据卡", file=sys.stderr)
            return 3
        rows = FP.attach_list(db, r)
    else:
        ap.error("需要 --from 或 --mpn")
    out = apply_rows(db, rows, dry=not a.apply)
    out["dry"] = not a.apply
    out["next"] = ("草稿已挂接：人工填 page+quote 并 verify 后 G6/G7 才转绿；"
                   "重跑 freeze_precheck 复核")
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())