"""629 件异常证据卡工作清单 + 汇总 + 修复工作单 + 回归计划（只读）。

输入：
  * `qc/auto_qc_evidence_review_worklist.csv`（629 行，人工核查底稿）
  * `auto_qc_issue_matrix.json`（全量交叉矩阵，行与 worklist 按 item_id 对齐）
输出：
  * `evidence_cards.csv`（保留人工字段为空；新增机器 PDF 探针字段）
  * `evidence_card_summary.md`
  * `repair_worklist.csv`（按根因分组的任务级清单）
  * `regression_plan.md`

边界：不修改 facts / Gold / item；`evidence_pdf_page`/`evidence_quote` 是**人工字段**，
保持为空；机器 PDF 命中写入独立的 `machine_pdf_page/quote/status`，并标记为机器预检。
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = Path("/app/data") if Path("/app/data").is_dir() else ROOT / "data"
DEFAULT_WORKLIST = ROOT / "qc" / "auto_qc_evidence_review_worklist.csv"
DEFAULT_MATRIX = ROOT / "auto_qc_issue_matrix.json"
RULE_VERSION = "issue-matrix-2026-10-28-v1"

GROUPS = {
    "A1": {
        "priority": "P1",
        "automation": "HUMAN_BUSINESS_DECISION",
        "human_required": "YES",
        "action": "确认业务对象是板卡/模块还是内部组件；确认组件 PDF 关联口径；"
                  "必要时标记 family_inherited 或改用组件型号，禁止直接批量覆盖。",
        "entry": "业务口径确认（对象/型号映射）",
        "exit": "每件有业务结论、证据与审核人；受影响单件/批次回归通过",
        "scope": "单件 + 该器件所在批次",
    },
    "A2": {
        "priority": "P1",
        "automation": "RULE_APPROVAL_THEN_TARGETED_RERUN",
        "human_required": "YES",
        "action": "定义基础型号/可订购型号/封装后缀/汽车级后缀归一化规则；"
                  "先写规则测试，再只重跑命中的变体。",
        "entry": "归一化规则评审通过 + 测试样例",
        "exit": "合法变体不再误报；真实错配仍保留 FAIL；无回归",
        "scope": "单件 + 受影响批次（按规则命中集）",
    },
    "A3": {
        "priority": "P0",
        "automation": "HUMAN_SOURCE_RECOVERY",
        "human_required": "YES",
        "action": "对照原厂 PDF 型号/订购表/版本，确认是型号错、文件关联错还是业务映射错；"
                  "恢复正确 PDF/关联后再修复。",
        "entry": "每件有原厂 PDF 型号/页码/quote 证据",
        "exit": "来源正确或明确标为无法确认；受影响单件/批次回归通过",
        "scope": "单件 + 该器件所在批次",
    },
    "E": {
        "priority": "P0",
        "automation": "HUMAN_VERIFY_THEN_METADATA_FIX",
        "human_required": "YES",
        "action": "核对 PDF 文件、item SHA、facts 源 SHA、修订号；确认版本后修元数据或换 PDF，"
                  "不得仅凭 SHA 差异自动替换。",
        "entry": "版本/来源证据卡完成",
        "exit": "三方 SHA/版本关系明确；元数据修复有审核记录；单件/批次回归通过",
        "scope": "单件 + 受影响批次",
    },
    "I": {
        "priority": "P1",
        "automation": "PARSER_FIX_THEN_TARGETED_REGRESSION",
        "human_required": "YES",
        "action": "按 PDF 表格结构分类（条件/单位/引脚/行配对），补解析规则与回归夹具；"
                  "先跑定向测试再重跑受影响批次。",
        "entry": "代表性 PDF 结构分析 + 新测试用例",
        "exit": "目标行正确解析；原 PASS 断言无回归；保留修复前后差异",
        "scope": "单件 + 受影响批次（不含全量重跑）",
    },
}


def _now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _norm(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", (s or "").upper())


def _family(mpn: str) -> str:
    m = re.match(r"([A-Za-z]+)", mpn or "")
    if m and len(m.group(1)) >= 2:
        return m.group(1).upper()[:12]
    return _norm(mpn)[:4] or "—"


def _group_key(group: str) -> str:
    for k in GROUPS:
        if (group or "").startswith(k + "_"):
            return k
    return "?"


def _load_csv(path: Path) -> tuple[list, list]:
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        return list(r), list(r.fieldnames or [])


def _load_matrix(path: Path) -> dict:
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    return {str(r["item_id"]): r for r in d.get("rows") or []}


def _pdf_probe(path: Path | None, row: dict) -> dict:
    out = {"machine_pdf_page": "", "machine_pdf_quote": "",
           "machine_probe_status": "NO_PDF", "machine_probe_note": ""}
    if not path or not path.is_file():
        out["machine_probe_note"] = "PDF 文件不存在"
        return out
    try:
        try:
            import pymupdf
        except Exception:                                    # noqa: BLE001
            import fitz as pymupdf                       # type: ignore
        doc = pymupdf.open(str(path))
    except Exception as e:                                   # noqa: BLE001
        out["machine_probe_status"] = "ERROR"
        out["machine_probe_note"] = "PDF 打开失败: %s" % e
        return out
    itemn = _norm(row.get("mpn"))
    jsonn = _norm(row.get("json_mpn"))
    want_ec = row.get("electrical_empty") in ("True", "true", True) or \
        row.get("electrical_row_bad") in ("True", "true", True)
    item_hit = json_hit = ec_hit = None
    item_line = json_line = ec_line = ""
    try:
        for i in range(doc.page_count):
            txt = doc[i].get_text()
            nt = _norm(txt)
            if not item_hit and itemn and itemn in nt:
                item_hit = i + 1
                for ln in txt.splitlines():
                    if itemn in _norm(ln):
                        item_line = ln.strip()
                        break
            if not json_hit and jsonn and jsonn != itemn and jsonn in nt:
                json_hit = i + 1
                for ln in txt.splitlines():
                    if jsonn in _norm(ln):
                        json_line = ln.strip()
                        break
            if want_ec and not ec_hit and "electrical characteristics" in txt.lower():
                ec_hit = i + 1
                for ln in txt.splitlines():
                    if "electrical characteristics" in ln.lower():
                        ec_line = ln.strip()
                        break
            if item_hit and (json_hit or not jsonn) and (ec_hit or not want_ec):
                break
        doc.close()
    except Exception as e:                                   # noqa: BLE001
        try:
            doc.close()
        except Exception:                                    # noqa: BLE001
            pass
        out["machine_probe_status"] = "ERROR"
        out["machine_probe_note"] = "PDF 读取失败: %s" % e
        return out
    if item_hit and json_hit:
        status = "ITEM_AND_JSON"
    elif item_hit:
        status = "ITEM_ONLY"
    elif json_hit:
        status = "JSON_ONLY"
    else:
        status = "NONE"
    if ec_hit:
        status += "_EC"
    page = item_hit or json_hit or ec_hit or ""
    quote = item_line or json_line or ec_line or ""
    note = "item=%s; json=%s; EC=%s" % (
        ("p%s" % item_hit) if item_hit else "未命中",
        ("p%s" % json_hit) if json_hit else "未命中",
        ("p%s" % ec_hit) if ec_hit else ("不适用" if not want_ec else "未命中"))
    out.update({"machine_pdf_page": page or "",
                "machine_pdf_quote": (quote or "")[:300],
                "machine_probe_status": status, "machine_probe_note": note})
    return out


def build_cards(worklist: list, matrix: dict, data_dir: Path,
                probe_pdf: bool = True) -> list:
    cards = []
    for row in worklist:
        r = dict(row)
        m = matrix.get(str(r.get("item_id"))) or {}
        for k in ("root_cause_group", "root_cause_groups", "fix_class",
                  "pdf_name", "json_mpn", "pdf_sha256_item", "pdf_sha256_file",
                  "facts_pdf_hash", "gold_status"):
            if not r.get(k) and m.get(k):
                r[k] = m.get(k)
        g = _group_key(r.get("root_cause_group") or "")
        meta = GROUPS.get(g, {})
        r["automation_class"] = meta.get("automation", "HUMAN_REVIEW")
        r["human_required"] = meta.get("human_required", "YES")
        r["priority"] = meta.get("priority", "P1")
        r["machine_pdf_page"] = ""
        r["machine_pdf_quote"] = ""
        r["machine_probe_status"] = "SKIPPED"
        r["machine_probe_note"] = ""
        r["probe_checked_at"] = ""
        if probe_pdf:
            p = data_dir / "pdfs" / (r.get("pdf_name") or "")
            pr = _pdf_probe(p if p.is_file() else None, r)
            r.update(pr)
            r["probe_checked_at"] = _now()
        # 人工字段不自动填充
        r.setdefault("human_verdict", "")
        r.setdefault("human_reviewer", "")
        r.setdefault("human_reviewed_at", "")
        r.setdefault("evidence_pdf_page", "")
        r.setdefault("evidence_quote", "")
        r.setdefault("adjudication_reason", "")
        if not (r.get("repair_status") or "").strip():
            r["repair_status"] = "PENDING_HUMAN_REVIEW"
        cards.append(r)
    return cards


def summarize(cards: list) -> dict:
    by_group = collections.Counter(c["root_cause_group"] for c in cards)
    by_code = collections.Counter()
    for c in cards:
        for code in (c.get("fail_codes") or "").split(";"):
            if code:
                by_code[code] += 1
    batches_by_group = collections.defaultdict(set)
    top_batch = collections.defaultdict(collections.Counter)
    for c in cards:
        g = c["root_cause_group"]
        batches_by_group[g].add(c.get("batch_id") or "")
        top_batch[g][c.get("batch_id") or ""] += 1
    probe = collections.Counter(c.get("machine_probe_status") for c in cards)
    i_sub = collections.Counter()
    i_batches = collections.defaultdict(set)
    i_top = collections.defaultdict(collections.Counter)
    for c in cards:
        if not (c.get("root_cause_group") or "").startswith("I_"):
            continue
        st = c.get("machine_probe_status") or ""
        sub = "I1_EC文本存在" if ("EC" in st and not st.startswith("NONE")) \
            else "I2_EC文本未找到"
        i_sub[sub] += 1
        i_batches[sub].add(c.get("batch_id") or "")
        i_top[sub][c.get("batch_id") or ""] += 1
    human = {
        "total": len(cards),
        "verdict_filled": sum(1 for c in cards if (c.get("human_verdict") or "").strip()),
        "reviewer_filled": sum(1 for c in cards if (c.get("human_reviewer") or "").strip()),
        "reviewed_at_filled": sum(1 for c in cards if (c.get("human_reviewed_at") or "").strip()),
        "evidence_page_filled": sum(1 for c in cards
                                    if (c.get("evidence_pdf_page") or "").strip()),
        "evidence_quote_filled": sum(1 for c in cards
                                     if (c.get("evidence_quote") or "").strip()),
    }
    return {
        "generated_at": _now(),
        "total": len(cards),
        "by_group": dict(by_group.most_common()),
        "by_group_batches": {g: len(bs) for g, bs in batches_by_group.items()},
        "by_code": dict(by_code.most_common()),
        "by_brand": dict(collections.Counter(c.get("brand") or "—"
                                            for c in cards).most_common()),
        "by_family": dict(collections.Counter(_family(c.get("mpn"))
                                             for c in cards).most_common(15)),
        "top_batches_by_group": {g: dict(cnt.most_common(5))
                                 for g, cnt in top_batch.items()},
        "machine_probe": dict(probe.most_common()),
        "i_subgroups": {k: {"count": v, "batches": len(i_batches[k]),
                            "top_batches": dict(i_top[k].most_common(5))}
                        for k, v in i_sub.items()},
        "human_filled": human,
        "rule_version": RULE_VERSION,
    }


def _summary_md(cards: list, s: dict) -> str:
    lines = ["# 629 件异常证据卡汇总", "",
             "生成时间：%s  " % s["generated_at"],
             "规则版本：`%s`  " % s["rule_version"],
             "范围：**629 件 FAIL**（来自 451 批 / 13,504 件自动 QC）；"
             "品牌：Texas Instruments。", "",
             "> 边界：本文件只做只读汇总；`human_verdict/reviewer/reviewed_at/evidence_pdf_page/"
             "evidence_quote` 全部保持为空；`machine_pdf_*` 是机器 PDF 文本探针，"
             "不是人工证据。未修改 facts / Gold / item。", "",
             "## 1. 分组统计", "",
             "| 分组 | 数量 | 涉及批次 | 首要处理方向 |", "|---|---:|---:|---|"]
    for g, n in s["by_group"].items():
        key = _group_key(g)
        lines.append("| %s | %d | %d | %s |" % (
            g, n, s["by_group_batches"].get(g, 0),
            GROUPS.get(key, {}).get("priority", "P1") + " · " +
            GROUPS.get(key, {}).get("automation", "HUMAN_REVIEW")))
    lines += ["| **合计** | **%d** | — | — |" % s["total"], "",
              "## 2. 问题码", "",
              "| 错误码 | 器件 |", "|---|---:|"]
    for k, v in s["by_code"].items():
        lines.append("| `%s` | %d |" % (k, v))
    lines += ["", "## 3. 集中度", "",
              "| 维度 | Top |", "|---|---|",
              "| 品牌 | %s |" % "；".join("%s×%d" % (k, v)
                                         for k, v in s["by_brand"].items()),
              "| 型号家族 | %s |" % "；".join("%s×%d" % (k, v)
                                           for k, v in s["by_family"].items()),
              "", "### 3.1 各分组最集中批次", "",
              "| 分组 | Top 批次 |", "|---|---|"]
    for g, top in s["top_batches_by_group"].items():
        lines.append("| %s | %s |" % (g, "；".join("%s×%d" % (k, v)
                                                  for k, v in top.items())))
    lines += ["", "## 4. 机器 PDF 探针覆盖", "",
              "| 状态 | 件数 |", "|---|---:|"]
    for k, v in s["machine_probe"].items():
        lines.append("| `%s` | %d |" % (k, v))
    if s.get("i_subgroups"):
        lines += ["", "### 4.1 I 组细分（机器探针）", "",
                  "| 子类 | 件数 | 涉及批次 | 说明 |", "|---|---:|---:|---|"]
        desc = {
            "I1_EC文本存在": "PDF 含 Electrical Characteristics 文本，优先查表格结构/解析规则",
            "I2_EC文本未找到": "PDF 未命中 EC 文本，先核对源/版本/型号，不能硬修解析器",
        }
        for k, v in s["i_subgroups"].items():
            lines.append("| %s | %d | %d | %s |" % (
                k, v["count"], v["batches"], desc.get(k, "")))
    h = s["human_filled"]
    lines += ["", "## 5. 人工字段完成度", "",
              "| 字段 | 已填 | 总数 |", "|---|---:|---:|"]
    for label, key in (("human_verdict", "verdict_filled"),
                       ("human_reviewer", "reviewer_filled"),
                       ("human_reviewed_at", "reviewed_at_filled"),
                       ("evidence_pdf_page", "evidence_page_filled"),
                       ("evidence_quote", "evidence_quote_filled")):
        lines.append("| `%s` | %d | %d |" % (label, h[key], h["total"]))
    lines += ["", "→ 当前人工裁决 **0/%d**；不能把机器探针或分组标签当作人工结论。"
              % h["total"], "",
              "## 6. 样例（每类前 3，完整见 `evidence_cards.csv`）", "",
              "| 分组 | item -> JSON / PDF | 机器探针 |", "|---|---|---|"]
    seen = collections.Counter()
    for c in cards:
        g = c["root_cause_group"]
        if seen[g] >= 3:
            continue
        seen[g] += 1
        lines.append("| %s | %s -> %s / %s | %s |" % (
            g, c.get("mpn"), c.get("json_mpn") or "—", c.get("pdf_name") or "—",
            c.get("machine_probe_status")))
    lines += ["", "## 7. 产物", "",
              "- `evidence_cards.csv`：629 张证据卡（人工字段留空）",
              "- `repair_worklist.csv`：按根因分组的任务级修复清单",
              "- `regression_plan.md`：定向回归与审计计划",
              "- 原始输入：`qc/auto_qc_evidence_review_worklist.csv`、"
              "`auto_qc_issue_matrix.csv/.json`", ""]
    return "\n".join(lines)


def _repair_md(s: dict) -> str:
    lines = ["# 629 件异常修复工作单（按根因分组）", "",
             "生成时间：%s  " % s["generated_at"],
             "规则版本：`%s`" % s["rule_version"], "",
             "> 任务级清单，不代表已批准修复；每件执行前必须先完成证据卡人工裁决。"
             "未修改生产数据。", "",
             "| 任务 | 分组 | 数量 | 批次 | 优先级 | 自动化类别 | 人工 | 状态 |",
             "|---|---|---:|---:|---|---|---|---|"]
    for i, (g, n) in enumerate(s["by_group"].items(), 1):
        key = _group_key(g)
        meta = GROUPS.get(key, {})
        lines.append("| RW-%s | %s | %d | %d | %s | `%s` | %s | OPEN |" % (
            key, g, n, s["by_group_batches"].get(g, 0),
            meta.get("priority", "P1"), meta.get("automation", "HUMAN_REVIEW"),
            meta.get("human_required", "YES")))
    lines += ["", "## 任务详情", ""]
    for g, n in s["by_group"].items():
        key = _group_key(g)
        meta = GROUPS.get(key, {})
        lines += ["### %s · %s（%d 件）" % (key, g, n), "",
                  "- 优先级：%s" % meta.get("priority", "P1"),
                  "- 自动化类别：`%s`" % meta.get("automation", "HUMAN_REVIEW"),
                  "- 人工必需：%s" % meta.get("human_required", "YES"),
                  "- 建议动作：%s" % meta.get("action", "先做证据卡"),
                  "- 进入条件：%s" % meta.get("entry", "—"),
                  "- 退出标准：%s" % meta.get("exit", "—"),
                  "- 回归范围：%s" % meta.get("scope", "单件 + 批次"),
                  "- 集中批次：%s" % "；".join(
                      "%s×%d" % (k, v) for k, v in
                      s["top_batches_by_group"].get(g, {}).items()), ""]
    lines += ["## 自动化边界", "",
              "- **没有**可以直接批量执行的组；I 类需先写规则/测试，A2 需规则评审，"
              "A1/A3/E 需人工证据或业务裁决。",
              "- 修复后只重跑受影响单件/批次；不做全量重跑，不弱化断言。", ""]
    return "\n".join(lines)


def _regression_md(s: dict) -> str:
    return """# 629 件异常修复后的回归计划

生成时间：%s
规则版本：`%s`

> 原则：先证据、后修复；先单件、后批次；保留修复前快照；
> 不以“全绿”为目标，不以弱化断言或排除样本换取 PASS。

## 1. 通用门禁

1. 每件修复必须有 `evidence_card_id` 对应的证据卡与人工裁决。
2. 修复前保存：`item` 元数据、PDF SHA、facts JSON、批次 audit/ZIP SHA。
3. 修复后记录：修改前后值、证据页码/quote、规则版本、审核人、时间。
4. 回归范围限定为受影响器件 + 所在批次；禁止直接全量重跑掩盖局部问题。
5. 若原 PASS 断言失败，按回归失败处理，不得弱化断言。

## 2. 分组计划

### A1 板卡/模块映射（81 件）
- 先确认业务对象：板卡/模块本身，还是内部组件。
- 若为合法继承：标记 `family_inherited` 并保留业务依据；否则修正型号/映射。
- 回归：对应单件 + 所在批次；验证 package/pins/identity 不回归。

### A2 可订购/封装变体（129 件）
- 先定义归一化规则：基础型号、封装后缀、汽车级、速度档。
- 先加规则单元测试；只重跑规则命中的变体，禁止影响其他型号。
- 回归：合法变体不再误报；真实错配仍 FAIL；原 PASS 不回归。

### A3 源 PDF/关联错配（266 件）
- 对照原厂 PDF 型号/订购表/版本，确认是型号错、文件关联错还是业务映射错。
- 恢复正确 PDF 或关联；无法确认的保留 `source_unresolved`，不得猜。
- 回归：单件 + 所在批次；核对 PDF SHA、facts 源 SHA 与证据页码。

### E PDF 文件版本漂移（97 件）
- 核对 `pdf_sha256_item`、`pdf_sha256_file`、`facts_pdf_hash`、修订号、来源 URL。
- 确认后修元数据或更换 PDF；不得仅凭 SHA 差异自动替换。
- 回归：单件 + 所在批次；核对三方 SHA/版本关系。

### I 电气表解析结构（56 件）
- 先按机器探针细分：I1（PDF 含 EC 文本）优先查表格结构/解析规则；
  I2（PDF 未命中 EC 文本）先核对源 PDF/版本/型号，不能硬修解析器。
- 为每类补回归夹具/单元测试；修复规则后只重跑受影响批次。
- 回归：目标行正确解析；原 PASS 断言不回归；保留修复前后差异。

## 3. 批次重跑命令（单批）

```bash
# <N> = 批次号后四位，例如 qc30-20261028-0166 -> 166
docker exec icpdf-server python /app/qc/auto_qc.py \\
  --db /app/data/workbench.sqlite3 --data-dir /app/data --out-dir /app/data/qc \\
  --run-id 20261028 --batch-size 30 --start <N> --limit 1 --force --pdf-probe sample
```

- 重跑会重写该批次报告/audit/ZIP，ZIP SHA 会变化；修复前必须备份旧批次目录/Audit。
- 多批次修复逐个执行，不合并成全量重跑。

## 4. 验收记录模板

| 字段 | 内容 |
|---|---|
| evidence_card_id |  |
| 修复前值/状态 |  |
| 修复后值/状态 |  |
| 证据页码/quote |  |
| 规则版本 | `%s` |
| 审核人/时间 |  |
| 单件回归 | PASS/FAIL |
| 批次回归 | PASS/FAIL |
| 未解决项 |  |

## 5. 当前状态

- 629 件证据卡：人工裁决 0/629。
- 无全量重跑、无生产 facts/Gold/item 修改。
- 本计划不预设任何批次会转为 PASS。
""" % (_now(), RULE_VERSION, RULE_VERSION)


def write_outputs(cards: list, s: dict, out_dir: Path,
                  input_fields: list) -> list:
    out_dir.mkdir(parents=True, exist_ok=True)
    extra = ["automation_class", "human_required", "priority",
             "machine_pdf_page", "machine_pdf_quote", "machine_probe_status",
             "machine_probe_note", "probe_checked_at"]
    fields = list(input_fields) + [k for k in extra if k not in input_fields]
    cards_path = out_dir / "evidence_cards.csv"
    with cards_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for c in cards:
            w.writerow({k: c.get(k, "") for k in fields})
    (out_dir / "evidence_card_summary.md").write_text(
        _summary_md(cards, s), encoding="utf-8")
    (out_dir / "repair_worklist.csv").write_text(
        _repair_csv(s), encoding="utf-8-sig")
    (out_dir / "regression_plan.md").write_text(
        _regression_md(s), encoding="utf-8")
    return [cards_path, out_dir / "evidence_card_summary.md",
            out_dir / "repair_worklist.csv", out_dir / "regression_plan.md"]


def _repair_csv(s: dict) -> str:
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["task_id", "root_cause_group", "subgroup", "count",
                "affected_batches", "priority", "automation_class",
                "human_required", "action", "entry_criteria", "exit_criteria",
                "regression_scope", "top_batches", "owner", "human_reviewer",
                "status"])
    for g, n in s["by_group"].items():
        key = _group_key(g)
        meta = GROUPS.get(key, {})
        if key == "I" and s.get("i_subgroups"):
            for sub, v in s["i_subgroups"].items():
                i1 = sub.startswith("I1")
                w.writerow([
                    "RW-%s" % ("I1" if i1 else "I2"), g, sub, v["count"],
                    v["batches"],
                    "P1" if i1 else "P0",
                    "PARSER_FIX_THEN_TARGETED_REGRESSION" if i1
                    else "SOURCE_GAP_HUMAN_REVIEW", "YES",
                    ("按 PDF 表格结构分类（条件/单位/引脚/行配对），补解析规则与回归夹具；"
                     "先跑定向测试再重跑受影响批次。" if i1 else
                     "PDF 未命中 EC 文本：先核对源 PDF/版本/型号，确认是否缺表；"
                     "无法确认则标 source_unresolved，禁止硬修解析器。"),
                    "代表性 PDF 结构分析 + 新测试用例" if i1 else
                    "原厂 PDF/版本/型号证据核对",
                    "目标行正确解析；原 PASS 断言无回归；保留修复前后差异" if i1 else
                    "明确 source_unresolved 或补齐源证据；单件/批次回归",
                    "单件 + 受影响批次（不含全量重跑）",
                    ";".join("%s×%d" % (k, n0) for k, n0 in
                             v.get("top_batches", {}).items()),
                    "", "", "OPEN"])
            continue
        w.writerow([
            "RW-%s" % key, g, "", n, s["by_group_batches"].get(g, 0),
            meta.get("priority", "P1"), meta.get("automation", "HUMAN_REVIEW"),
            meta.get("human_required", "YES"), meta.get("action", ""),
            meta.get("entry", ""), meta.get("exit", ""),
            meta.get("scope", ""),
            ";".join("%s×%d" % (k, v) for k, v in
                     s["top_batches_by_group"].get(g, {}).items()),
            "", "", "OPEN"])
    return buf.getvalue()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="629 件证据卡与修复工作单（只读）")
    ap.add_argument("--worklist", default=str(DEFAULT_WORKLIST))
    ap.add_argument("--matrix", default=str(DEFAULT_MATRIX))
    ap.add_argument("--data-dir", default=str(DEFAULT_DATA))
    ap.add_argument("--out-dir", default=str(DEFAULT_DATA / "qc" / "_staging"))
    ap.add_argument("--no-probe", action="store_true")
    args = ap.parse_args(argv)
    worklist, fields = _load_csv(Path(args.worklist))
    matrix = _load_matrix(Path(args.matrix))
    cards = build_cards(worklist, matrix, Path(args.data_dir),
                        probe_pdf=not args.no_probe)
    s = summarize(cards)
    outs = write_outputs(cards, s, Path(args.out_dir), fields)
    for p in outs:
        print("written %s" % p)
    print(json.dumps(s, ensure_ascii=False)[:1200])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
