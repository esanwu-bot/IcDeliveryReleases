"""页预算策略测算：在 228 件真实 PDF 上离线比较多种选页策略，用数据定额度。

为什么需要这个
------------
`select_pages` 的 `RANK_QUOTA=(3,3,3)` 只限制页数、不限制字符，长页照样吃满
`MAX_CHARS`，结果电气档（rank 3）排在末位只能捡剩余预算——228 件里 221 件
触发裁剪，去重电气签名净减 769。

修的时候额度不能拍脑袋定：短文档给太大保底是浪费，长文档给太小又保不住电气页。
所以本脚本对每份 PDF 只读一次页，然后在**同一批页**上跑多种策略，横向比较：
  * 电气页入选数（对比旧实现的基线，看是否恢复）
  * 订货页入选数（保住本批次换来的订货信息改善）
  * 总字符数（决定 token 成本）
  * 是否触发预算裁剪

只读：不写 parsed / backup / 数据库，只写 --out 指定的 CSV。

用法（容器内）
--------------
    python qc/tune_page_budget.py --mpns-file /tmp/all228.txt --out /tmp/budget.csv
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                              # noqa: E402
from qc.reparse_ordering import _safe                      # noqa: E402
from qc.diagnose_elec_loss import ELEC_KEYS, OLD_KEY_PAGES  # noqa: E402

MAX_PAGES, MAX_CHARS = PD.MAX_PAGES, PD.MAX_CHARS


def rank_of(text: str) -> int:
    low = text.lower()
    for n, keys in enumerate(PD.PAGE_PRIORITY, start=1):
        if any(k in low for k in keys):
            return n
    return len(PD.PAGE_PRIORITY) + 1


def classify(pages):
    """一次扫描，产出 head / 分档候选 / 旧实现选页 / 电气候选页集合。"""
    head, cand = [], []
    for i, text in pages:
        if i >= PD.PAGE_SCAN_CAP:
            break
        if not text.strip():
            continue
        if i < 3:
            head.append((i, text))
        else:
            cand.append((rank_of(text), i, text))
    elec = {i for i, t in pages
            if i < PD.PAGE_SCAN_CAP and any(k in t.lower() for k in ELEC_KEYS)}
    # 旧实现选页（49e4c93 口径）
    old, buf = [], 0
    for i, text in pages:
        if i >= MAX_PAGES:
            break
        if not text.strip():
            continue
        if i < 3 or any(k in text.lower() for k in OLD_KEY_PAGES):
            old.append(i)
            buf += len(text)
            if buf > MAX_CHARS:
                break
    return head, cand, elec, set(old)


def s0_current(head, cand, max_pages=MAX_PAGES, max_chars=MAX_CHARS, quota=PD.RANK_QUOTA):
    """现状：按 (rank, page) 排序，每档页数配额，全局字符预算。"""
    chosen, chars, taken = [], 0, {}
    for rank, i, text in [(0, i, t) for i, t in head] + sorted(cand, key=lambda x: (x[0], x[1])):
        q = quota[rank - 1] if 1 <= rank <= len(quota) else 99
        if taken.get(rank, 0) >= q:
            continue
        if len(chosen) >= max_pages or chars + len(text) > max_chars:
            continue
        chosen.append((i, rank))
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)
    return chosen, chars


def s1_elec_floor(head, cand, elec_floor, max_pages=MAX_PAGES, max_chars=MAX_CHARS,
                  quota=PD.RANK_QUOTA):
    """电气档字符保底：先给 rank3 预留 elec_floor，再用剩余预算按档填充。"""
    chosen, chars, taken = [], 0, {}
    pages_left = max_pages
    # 保底阶段：rank3 按页序取，直到达到保底或配额/页数用尽
    floor_got = 0
    for rank, i, text in sorted([c for c in cand if c[0] == 3], key=lambda x: x[1]):
        if floor_got >= elec_floor or taken.get(3, 0) >= quota[2] or pages_left <= 0:
            break
        if chars + len(text) > max_chars:
            break
        chosen.append((i, rank))
        taken[3] = taken.get(3, 0) + 1
        chars += len(text)
        floor_got += len(text)
        pages_left -= 1
    # 补充阶段：head 优先，再按 (rank, page)
    for rank, i, text in [(0, i, t) for i, t in head] + sorted(cand, key=lambda x: (x[0], x[1])):
        if (i, rank) in chosen:
            continue
        q = quota[rank - 1] if 1 <= rank <= len(quota) else 99
        if taken.get(rank, 0) >= q:
            continue
        if pages_left <= 0 or chars + len(text) > max_chars:
            continue
        chosen.append((i, rank))
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)
        pages_left -= 1
    return chosen, chars


def s2_per_rank_budget(head, cand, budgets, max_pages=MAX_PAGES, max_chars=MAX_CHARS,
                       quota=PD.RANK_QUOTA):
    """各档独立字符预算：rank 各自有上限，另受总预算与总页数约束。"""
    chosen, chars, taken = [], 0, {}
    used: dict[int, int] = {}
    pages_left = max_pages
    for rank, i, text in [(0, i, t) for i, t in head] + sorted(cand, key=lambda x: (x[0], x[1])):
        q = quota[rank - 1] if 1 <= rank <= len(quota) else 99
        if taken.get(rank, 0) >= q:
            continue
        cap = budgets.get(rank, max_chars)
        if used.get(rank, 0) + len(text) > cap:
            continue
        if pages_left <= 0 or chars + len(text) > max_chars:
            continue
        chosen.append((i, rank))
        taken[rank] = taken.get(rank, 0) + 1
        used[rank] = used.get(rank, 0) + len(text)
        chars += len(text)
        pages_left -= 1
    return chosen, chars


def s3_floor_roundrobin(head, cand, floors, max_pages=MAX_PAGES, max_chars=MAX_CHARS,
                        quota=PD.RANK_QUOTA):
    """保底 + 轮转：先让每档拿到字符保底，再按档轮转分配剩余预算。"""
    chosen, chars, taken = [], 0, {}
    used: dict[int, int] = {}
    pages_left = max_pages

    def take(rank, i, text):
        nonlocal chars, pages_left
        chosen.append((i, rank))
        taken[rank] = taken.get(rank, 0) + 1
        used[rank] = used.get(rank, 0) + len(text)
        chars += len(text)
        pages_left -= 1

    for i, text in [(i, t) for i, t in head]:
        if pages_left <= 0 or chars + len(text) > max_chars:
            continue
        take(0, i, text)
    # 保底：每档按页序补足字符下限
    for rank in sorted(floors):
        for r, i, text in sorted([c for c in cand if c[0] == rank], key=lambda x: x[1]):
            if used.get(rank, 0) >= floors[rank] or taken.get(rank, 0) >= quota[rank - 1]:
                break
            if pages_left <= 0 or chars + len(text) > max_chars:
                break
            take(rank, i, text)
    # 轮转：每轮每档各取一页，直到页数或预算用尽
    while pages_left > 0:
        progressed = False
        for rank in sorted({c[0] for c in cand} | {1, 2, 3}):
            if taken.get(rank, 0) >= (quota[rank - 1] if 1 <= rank <= len(quota) else 99):
                continue
            nxt = next((c for c in sorted(cand, key=lambda x: x[1])
                        if c[0] == rank and (c[1], c[0]) not in chosen), None)
            if nxt is None:
                continue
            _, i, text = nxt
            if chars + len(text) > max_chars:
                continue
            take(rank, i, text)
            progressed = True
        if not progressed:
            break
    return chosen, chars


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="页预算策略离线测算（只读）")
    ap.add_argument("--mpns-file", default="")
    ap.add_argument("--mpn", action="append", default=[], help="只测算指定料号（可重复）")
    ap.add_argument("--data-dir", default=str(ROOT / "data" / "parsed"), dest="data_dir")
    ap.add_argument("--pdfs", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--db", default=str(ROOT / "data" / "workbench.sqlite3"))
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)

    import sqlite3
    pdfs = Path(a.pdfs)
    db = sqlite3.connect(a.db) if Path(a.db).exists() else None
    mpns = list(a.mpn)
    if a.mpns_file and Path(a.mpns_file).exists():
        mpns += [x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()]
    mpns = list(dict.fromkeys(mpns))
    if not mpns:
        print("没有指定 MPN")
        return 2
    print("测算 %d 件" % len(mpns))

    # 关键发现：旧实现能选到 10 页电气页，而 RANK_QUOTA=(3,3,3) 把 rank3 压到最多 3 页
    # ——页数配额与字符预算是双重约束，所以配额与总页数必须一起进扫描维度。
    strategies = [
        ("S0现状(3,3,3)页12", lambda h, c: s0_current(h, c)),
        ("S8(3,2,5)保底12k页13", lambda h, c: s1_elec_floor(h, c, 12000, quota=(3, 2, 5),
                                                            max_pages=13)),
        ("V1(2,2,6)保底12k页13", lambda h, c: s1_elec_floor(h, c, 12000, quota=(2, 2, 6),
                                                            max_pages=13)),
        ("V2(3,1,6)保底12k页13", lambda h, c: s1_elec_floor(h, c, 12000, quota=(3, 1, 6),
                                                            max_pages=13)),
        ("V3(2,2,6)保底14k页14", lambda h, c: s1_elec_floor(h, c, 14000, quota=(2, 2, 6),
                                                            max_pages=14)),
        ("V4(3,2,6)保底14k页14", lambda h, c: s1_elec_floor(h, c, 14000, quota=(3, 2, 6),
                                                            max_pages=14)),
        ("V5(3,2,7)保底16k页15", lambda h, c: s1_elec_floor(h, c, 16000, quota=(3, 2, 7),
                                                            max_pages=15)),
        ("S9(2,2,8)保底16k页16", lambda h, c: s1_elec_floor(h, c, 16000, quota=(2, 2, 8),
                                                            max_pages=16)),
    ]

    acc = {name: {"elec": 0, "order": 0, "chars": 0, "over": 0,
                  "elec_lt_old": 0, "n": 0} for name, _ in strategies}
    base_old_elec = 0
    rows = []

    for k, mpn in enumerate(mpns, 1):
        pdf = None
        if db:
            r = db.execute("SELECT pdf_path FROM item WHERE mpn=?", (mpn,)).fetchone()
            if r and r[0]:
                cand_p = pdfs / Path(r[0].replace("\\", "/")).name
                if cand_p.exists():
                    pdf = cand_p
        if pdf is None:
            hits = sorted(pdfs.glob(_safe(mpn) + "*.pdf"))
            pdf = hits[0] if hits else None
        if pdf is None:
            continue
        try:
            import fitz
            with fitz.open(str(pdf)) as doc:
                pages = [(i, doc[i].get_text("text") or "") for i in range(doc.page_count)]
        except Exception:                                    # noqa: BLE001
            continue
        head, cand, elec, old_sel = classify(pages)
        old_elec = len([i for i in old_sel if i in elec])
        base_old_elec += old_elec
        row = {"mpn": mpn, "old_elec_pages": old_elec, "elec_cand": len(elec)}
        for name, fn in strategies:
            chosen, chars = fn(head, cand)
            ep = len([1 for i, _ in chosen if i in elec])
            op = len([1 for i, r in chosen if r == 1])
            acc[name]["elec"] += ep
            acc[name]["order"] += op
            acc[name]["chars"] += chars
            acc[name]["n"] += 1
            if chars >= MAX_CHARS * 0.98:
                acc[name]["over"] += 1
            if ep < old_elec:
                acc[name]["elec_lt_old"] += 1
            row[name + "_elec"] = ep
            row[name + "_order"] = op
            row[name + "_chars"] = chars
        rows.append(row)
        if k % 40 == 0:
            print("  已测算 %d/%d" % (k, len(mpns)), flush=True)

    n = len(rows)
    print("\n=== 策略横向比较（%d 件，旧实现电气页基线合计 %d）===" % (n, base_old_elec))
    print("%-16s %8s %8s %10s %8s %10s" % ("策略", "电气页", "订货页", "字符/件", "触顶件", "低于旧基线"))
    for name, _ in strategies:
        d = acc[name]
        print("%-16s %8.2f %8.2f %10.0f %8d %10d"
              % (name, d["elec"] / max(n, 1), d["order"] / max(n, 1),
                 d["chars"] / max(n, 1), d["over"], d["elec_lt_old"]))
    print("\n（电气页 = 平均入选的电气候选页数；低于旧基线 = 电气页比旧实现少的件数）")

    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("\n明细已写 %s（%d 行）" % (out, len(rows)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
