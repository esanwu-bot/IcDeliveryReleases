"""QC 交付历史（按批次扫描 `data/qc/<batch>/`，只读）。

一个“交付批次”目录的约定：
  * `manifest.csv`           批次清单（至少含 mpn / fields / pdf_sha256 等列）
  * `*.zip`                  交付包（取目录内第一个 .zip）
  * `核验报告.md` / `ACCEPTANCE.md`  可读报告（优先前者）
  * `*quality_audit.json`    机器可读核验结果（可选）

本模块不做任何写操作，也不 import app.* 之外的重模块；供 `/api/qe/deliveries` 使用。
"""
from __future__ import annotations

import csv
import datetime
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

from qc import review_status as RS

ROOT = Path(__file__).resolve().parent.parent
#: 交付物历史经过三代格式，三代**并存**（老批次不迁移：只读、可回溯）。
#:
#: | 代 | 目录 | 特征 |
#: | --- | --- | --- |
#: | gen1 | `data/exports/delivery-YYYYMMDD[-xxx]/` | 早期分卷打包，只有 zip + manifest |
#: | gen2 | `data/qc/qc30-YYYYMMDD-NNNN/` | 自动 QC 批次（30 件/批），`r6核验报告.md` + L1–L4 |
#: | gen3 | `data/delivery-YYYYMMDD[-Vx]/` | 严格交付包，`manifest.json` + `包校验报告.json` |
#:
#: 第二代（gen2）四层门禁 / 复审批次：`data/qc/<batch>/`。
DEFAULT_BASE = ROOT / "data" / "qc"
#: 第三代（gen3）正式交付物（AGENT.md §16）：直接放在 `data/` 下。
DELIVERY_BASE = ROOT / "data"
#: 第一代（gen1）早期分卷导出：`data/exports/delivery-YYYYMMDD`（含 `-nopdf` 变体）。
EXPORTS_BASE = ROOT / "data" / "exports"
#: 第三代正式交付包：`delivery-YYYYMMDD[-Vn[.m]]`。补丁位（`-V3.1`）是
#: 「对 V3 的定点重打」，只认整数会让这类包在工作台上查不到（1102-V3.1）。
DELIVERY_NAME_RE = re.compile(r"^delivery-\d{8}(?:-V\d+(?:\.\d+)?)?$")
EXPORTS_NAME_RE = re.compile(r"^delivery-\d{8}")
#: 查找顺序 = 代数从新到旧：同名批次优先认新格式。
BASES = (DELIVERY_BASE, EXPORTS_BASE, DEFAULT_BASE)
SAFE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
DATE_RE = re.compile(r"(20\d{2})(\d{2})(\d{2})")
LAYERS = ("L1", "L2", "L3", "L4")
GATES = ("PACKAGE_PASS", "PROVENANCE_PASS", "DATA_SEMANTICS_PASS",
         "DOWNSTREAM_PASS", "RELEASE_APPROVED")
MANUAL_DIR = "manual_review"
IMG_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}

# 四层门禁批次之外，还有一种「自动 review + 自动修复」批次（delivery_kind=review_fix）。
# 它不走 L1–L4，状态按最近一次复审的 P0/P1 推导（口径见 qc/review_status.py）。
KIND_FOUR_LAYER = "four_layer"
KIND_REVIEW_FIX = "review_fix"
# 四层批次的 status_code 直接沿用 verdict，label 用于前端展示
VERDICT_LABELS = {"PASS": "四层全通过", "FAIL": "L1 未通过",
                  "PARTIAL": "部分通过", "UNKNOWN": "无核验结果"}
# review-fix 批次的状态标签与推导版本（审计里没写时兜底）
RF_STATUS_LABELS = dict(RS.STATUS_LABELS)
RF_STATUS_RULE_VERSION = RS.STATUS_RULE_VERSION
# 只读盘点工具的产物：与 audit 分开存，删除即回退到 audit 口径
DERIVED_NAME = "rf_status_derived.json"
# 版本后缀：rf-20261028-001-V2（V1 省略后缀）；交付包另有补丁位 V3.1
_VERSION_RE = re.compile(r"^(?P<base>.+?)(?:-V(?P<v>\d+(?:\.\d+)?))?$")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_dir(base: Path, batch_id: str) -> Path | None:
    if not batch_id or not SAFE_RE.match(batch_id) or ".." in batch_id:
        return None
    base = base.resolve()
    p = (base / batch_id).resolve()
    if p.parent != base:
        return None
    return p if p.is_dir() else None


def _base_rule(root: Path) -> tuple[re.Pattern | None, str]:
    """某个扫描根的「目录名规则 + 代数标签」。

    按**调用时**的模块全局取值（不预计算），这样测试替换 `DH.BASES` /
    `DH.DELIVERY_BASE` 时规则跟着变。
    """
    if root == DELIVERY_BASE:
        return DELIVERY_NAME_RE, "gen3"
    if root == EXPORTS_BASE:
        return EXPORTS_NAME_RE, "gen1"
    return None, "gen2"


def _accepts(root: Path, d: Path) -> bool:
    """这个目录算不算该根下的一个批次目录（名字层面，不看内容）。"""
    rule, _gen = _base_rule(root)
    return bool(rule.match(d.name)) if rule else True


def _resolve(batch_id: str, base: Path | None = None) -> Path | None:
    """按批次号定位目录：显式给了 `base` 就只找那一个根，否则按代数从新到旧找。

    为什么需要这一步：工作台原来只扫 `data/qc/`，而 1101 起的正式包全在
    `data/delivery-*`。结果页面上最新批次停在一周前 —— 不是数据丢了，
    是**扫描根和产出根不是同一个**。
    """
    roots = (Path(base),) if base else BASES
    for root in roots:
        p = _safe_dir(root, batch_id)
        if p and p.is_dir() and _accepts(root, p):
            return p
    return None


def _zip_manifest(z: Path) -> str | None:
    try:
        with zipfile.ZipFile(z) as zf:
            for n in zf.namelist():
                if n == "manifest.csv" or n.endswith("/manifest.csv"):
                    return n
    except Exception:                                        # noqa: BLE001
        return None
    return None


def _is_batch(p: Path) -> bool:
    z = _zip(p)
    if not z:
        return False
    return (p / "manifest.csv").is_file() or _zip_manifest(z) is not None


def _zip(p: Path) -> Path | None:
    zs = sorted(p.glob("*.zip"))
    return zs[0] if zs else None


def _report(p: Path) -> Path | None:
    """优先四层核验报告（允许 r6核验报告.md 等前缀），其次验收/交付说明/README。"""
    for name in ("核验报告.md", "report.md"):
        f = p / name
        if f.is_file():
            return f
    cands = sorted(p.glob("*核验报告.md"))
    if cands:
        return cands[0]
    # 正式交付包的说明文件叫《交付说明.md》（delivery_bundle 产出），
    # 不叫「核验报告」。不认它就等于让每个 delivery- 批次都「没有报告」。
    for name in ("交付说明.md", "ACCEPTANCE.md", "README.md"):
        f = p / name
        if f.is_file():
            return f
    return None


def _parse_version(batch_id: str) -> tuple[str, int | float]:
    """`rf-20261028-001-V2` → ("rf-20261028-001", 2)；无后缀即 V1。

    补丁位（`delivery-20261102-V3.1`）返回 `3.1`（float），整数形态仍返回
    `int` —— 老用例的 `version == 2` 与 JSON 里的数字类型都不变。
    排序键是 `(date, base_id, version, mtime)`，int 与 float 可直接比较；
    但**不能**按字符串比（`V3.10` 会排到 `V3.2` 前面）。
    """
    m = _VERSION_RE.match(batch_id or "")
    if not m:
        return batch_id, 1
    raw = m.group("v") or "1"
    return m.group("base"), (float(raw) if "." in raw else int(raw))


def _versions(base: Path, batch_id: str) -> list[dict]:
    """同一批次线的全部版本（V1…Vn），只读目录名 + audit，不递归读 review。"""
    root, ver = _parse_version(batch_id)
    out = []
    for d in base.iterdir():
        if not d.is_dir():
            continue
        b, v = _parse_version(d.name)
        if b != root:
            continue
        a = _audit(d)
        code = str(a.get("status_code") or "")
        out.append({
            "id": d.name, "version": v,
            "status_code": code,
            "status_label": str(a.get("status_label")
                                or RF_STATUS_LABELS.get(code) or code),
            "p0": int(a.get("p0_total") or 0),
            "p1": int(a.get("p1_total") or 0),
            "generated_at": a.get("generated_at") or "",
            "mtime": d.stat().st_mtime,
        })
    out.sort(key=lambda x: x["version"])
    return out


def _derived(p: Path) -> dict:
    """读只读盘点工具写的派生状态（`rf_status_derived.json`）；没有返回 {}。"""
    f = p / DERIVED_NAME
    if not f.is_file():
        return {}
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


def _audit(p: Path) -> dict:
    """机器可读核验结果。

    两种来源：
    * `*quality_audit.json` —— 四层门禁 / 复审批次；
    * `包校验报告.json` —— 正式交付包（`delivery_bundle` 产出），里面有
      `self_check` / `self_check_items` / 分卷 sha256 / 逐型号门禁状态。
    """
    for f in sorted(p.glob("*quality_audit.json")):
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except Exception:                                    # noqa: BLE001
            continue
    f = p / "包校验报告.json"
    if f.is_file():
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except Exception:                                    # noqa: BLE001
            pass
    return {}


def _date(p: Path, batch_id: str) -> str:
    m = DATE_RE.search(batch_id)
    if m:
        return "%s-%s-%s" % m.groups()
    import datetime
    return datetime.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d")


def _verdict(layers: dict) -> tuple[str, str]:
    st = {k: (layers.get(k) or {}).get("status") for k in LAYERS}
    if not any(st.values()):
        return "UNKNOWN", "无核验结果"
    if all(v == "PASS" for v in st.values()):
        return "PASS", "L1–L4 全部 PASS"
    if st.get("L1") and st["L1"] != "PASS":
        return "FAIL", "L1 包完整性未通过"
    bad = [k for k in LAYERS if st.get(k) == "FAIL"]
    nc = [k for k in LAYERS if st.get(k) == "NOT_CHECKED"]
    note = []
    if bad:
        note.append("%s FAIL" % "/".join(bad))
    if nc:
        note.append("%s 未完成" % "/".join(nc))
    return "PARTIAL", "；".join(note)


def _manifest_rows(p: Path, z: Path | None) -> list[dict]:
    """读批次清单：优先目录内 manifest.csv，否则读 ZIP 内的 manifest.csv。"""
    f = p / "manifest.csv"
    if f.is_file():
        try:
            with f.open(encoding="utf-8-sig", newline="") as fh:
                return list(csv.DictReader(fh))
        except Exception:                                    # noqa: BLE001
            return []
    if not z:
        return []
    name = _zip_manifest(z)
    if not name:
        return []
    try:
        with zipfile.ZipFile(z) as zf:
            text = zf.read(name).decode("utf-8-sig", errors="replace")
        return list(csv.DictReader(io.StringIO(text)))
    except Exception:                                        # noqa: BLE001
        return []


def _gate_status(value) -> str:
    """把 `包校验报告.json` 里的取值翻成门禁状态词。"""
    if value is True:
        return "PASS"
    if value is False:
        return "FAIL"
    s = str(value or "").strip().lower()
    if s in ("pass", "passed", "ok", "true"):
        return "PASS"
    if s in ("fail", "failed", "false"):
        return "FAIL"
    if s in ("not_approved", "pending", "not_checked", ""):
        return "NOT_CHECKED"
    return "UNKNOWN"


def _delivery_verdict(audit: dict) -> tuple[str, str, dict, dict]:
    """正式交付包 → `(verdict, note, layers, release_gates)`。

    刻意**不**伪造 L1–L4：交付包根本没有四层门禁这套东西，硬套一层标签
    等于把「没做」写成「做了」。这里只映射包里真实存在的字段：
    `packaging_validation` / `selfcheck.n_failed` / `zip_crc` /
    `source_hashes_unchanged` / `engineering_validation`。
    """
    sc = audit.get("selfcheck") or {}
    n_failed = sc.get("n_failed")
    n_items = sc.get("n_items")
    gates = {
        "PACKAGE_PASS": {"status": _gate_status(audit.get("packaging_validation"))},
        "PROVENANCE_PASS": {"status": "PASS" if audit.get("source_hashes_unchanged")
                            else ("FAIL" if audit.get("source_hashes_unchanged") is False
                                  else "NOT_CHECKED")},
        "DATA_SEMANTICS_PASS": {"status": "PASS" if n_failed == 0 else
                                ("FAIL" if n_failed else "NOT_CHECKED")},
        "DOWNSTREAM_PASS": {"status": "NOT_CHECKED"},
        "RELEASE_APPROVED": {"status": _gate_status(audit.get("engineering_validation"))},
    }
    self_check = str(audit.get("self_check") or "").strip().lower()
    if self_check == "pass" or (n_failed == 0 and n_items):
        note = f"包内自检 {n_items or '?'} 项全绿（自证链逐项重算）"
        return "PASS", note, {}, gates
    if self_check and self_check != "pass":
        return "FAIL", f"包内自检未通过（self_check={self_check}）", {}, gates
    if n_failed:
        return "FAIL", f"包内自检 {n_failed} 项不一致", {}, gates
    return "UNKNOWN", "无核验结果", {}, gates


def get_batch(batch_id: str, base: Path | None = None,
              full: bool = True) -> dict | None:
    p = _resolve(batch_id, base)
    if not p or not _is_batch(p):
        return None
    base = p.parent          # 下游（版本列表 / 人工截图）都按「该批次所在的根」找
    z = _zip(p)
    rows = _manifest_rows(p, z)
    mpns = sorted({(r.get("mpn") or "").strip() for r in rows if (r.get("mpn") or "").strip()})
    audit = _audit(p)
    details = audit.get("details") or {}
    layers = audit.get("layers") or {}
    if "layers" not in audit and ("packaging_validation" in audit
                                  or "selfcheck" in audit):
        # 正式交付包（`包校验报告.json`）不是四层门禁那套 schema，
        # 按它自己的字段如实翻译，不硬套 L1–L4。
        verdict, note, layers, gates = _delivery_verdict(audit)
    else:
        verdict, note = _verdict(layers)
        gates = audit.get("release_gates") or {}
    release_gate_status = {}
    for k in GATES:
        g = gates.get(k) or {}
        release_gate_status[k] = g.get("status") or "UNKNOWN"
    release = {
        "approved": bool(audit.get("release_approved")),
        "status": (gates.get("RELEASE_APPROVED") or {}).get("status") or "UNKNOWN",
        "gates": release_gate_status,
        "supplemental": audit.get("supplemental_summary") or {},
    }
    rep = _report(p)
    manual = list_manual(batch_id, base)
    fields = 0
    for r in rows:
        total = (r.get("fields_total") or "").strip()     # r6 manifest 口径
        if total.isdigit():
            fields += int(total)
            continue
        f = (r.get("fields") or "").split("/")[0].strip()  # 旧口径 36/36
        if f.isdigit():
            fields += int(f)
    kind = str(audit.get("delivery_kind") or KIND_FOUR_LAYER)
    derived = _derived(p) if kind == KIND_REVIEW_FIX else {}
    rf_extra: dict = {}
    if kind == KIND_REVIEW_FIX:
        # review-fix 批次：优先用只读盘点工具写的派生状态（与 audit 分开存），
        # 没有派生文件就照实展示 audit 里的编码——旧口径（REVIEWED_FIXED 等）
        # 明确标 legacy，不擅自翻成阻断/通过。
        src = derived or audit
        code = str(src.get("status_code") or "")
        if code in RF_STATUS_LABELS:
            source = "derived" if derived else "audit"
            label_ = str(src.get("status_label") or RF_STATUS_LABELS[code])
        else:
            source = "audit_legacy"
            label_ = str(src.get("status_label")
                         or VERDICT_LABELS.get(code) or code or "旧口径未重算")
        status = {"code": code, "label": label_, "source": source,
                  "legacy": source == "audit_legacy",
                  "rule_version": str(src.get("status_rule_version") or "")}
        verdict = "UNKNOWN"
        note = label_ or "自动 review + 修复批次"
        rf_extra = {
            "p0_total": int(src.get("p0_total") or 0),
            "p1_total": int(src.get("p1_total") or 0),
            "status_counts": src.get("status_counts") or {},
            "status_rule_version": str(src.get("status_rule_version") or ""),
            "generated_at": str(src.get("generated_at") or ""),
            "mpns_detail": (src.get("mpns_detail") or {}) if derived else {},
            # 人工隔离是独立标注（P0 依据是人工 PDF 复核，不一定在 review 里），
            # 单独展示，不并进 P0/P1 计数
            "quarantined": audit.get("quarantined") or {},
        }
    else:
        status = {"code": verdict, "label": VERDICT_LABELS.get(verdict, verdict),
                  "source": "layers", "legacy": False, "rule_version": ""}
        note = note or ""
    base_id, version = _parse_version(p.name)
    # 版本链只在看单批详情时展开：列表里逐批扫同线目录会退化成 O(n²)
    siblings = (_versions(base, p.name)
                if kind == KIND_REVIEW_FIX and full else [])
    _gen = _base_rule(base)[1]
    return {
        "id": p.name,
        # 三代格式的统一字段名：前端只认这几个，不必知道内部 `id` / `zip.size`
        "batch_id": p.name,
        "generation": _gen,
        "gate_status": verdict,
        "report_url": (f"/api/qe/deliveries/{p.name}/report.html" if rep else ""),
        "zip_url": (f"/api/qe/deliveries/{p.name}/zip" if z else ""),
        "zip_size": (int(details.get("zip_size") or z.stat().st_size) if z else 0),
        "zip_sha256": (str(details.get("zip_sha256") or _sha256(z)) if z else ""),
        "label": audit.get("package") or p.name,
        "kind": kind,
        "status": status,
        "base_id": base_id,
        "version": version,
        "versions": siblings,
        "review_fix_derived": rf_extra,
        "date": _date(p, p.name),
        "mtime": p.stat().st_mtime,
        "mpns": mpns,
        "sample_count": len(mpns),
        "fields_total": fields,
        "manifest": rows if full else [],
        "manifest_rows": len(rows),
        "layers": {k: (layers.get(k) or {}) for k in LAYERS},
        "audit_version": audit.get("audit_version") or 1,
        "generated_at": audit.get("generated_at") or "",
        "release": release,
        "release_gates": {k: (gates.get(k) or {}) for k in GATES},
        "supplemental": audit.get("supplemental_summary") or {},
        "facts_review": ((audit.get("details") or {}).get("facts_review") or {}),
        "auto_qc": audit.get("auto_qc") or {},
        "review_fix": audit.get("review_fix") or {},
        "summary": audit.get("summary") or {},
        "verdict": verdict,
        "verdict_note": note,
        "report": {"name": rep.name if rep else "", "available": bool(rep),
                   "json": bool(audit)},
        "manual_review": {"count": len(manual), "items": manual,
                          "available": bool(manual)},
        "zip": ({"name": z.name,
                 "size": int(details.get("zip_size") or z.stat().st_size),
                 "sha256": details.get("zip_sha256") or _sha256(z),
                 "mb": round((int(details.get("zip_size") or z.stat().st_size))
                             / 1048576.0, 2)} if z else None),
    }


def list_batches(base: Path | None = None) -> list[dict]:
    roots = (Path(base),) if base else BASES
    out: list[dict] = []
    for root in roots:
        if not root.is_dir():
            continue
        for d in root.iterdir():
            if not d.is_dir() or not _accepts(root, d) or not _is_batch(d):
                continue
            b = get_batch(d.name, root, full=False)
            if b:
                out.append(b)
    # 同日多版本按**语义版本**排，不靠 mtime：V3 和 V2 都是 2026-11-02，
    # 谁后拷进来 mtime 就更新，光按 mtime 排会让「最新批次」显示成 V2。
    out.sort(key=lambda b: (b["date"], b["base_id"], b["version"], b["mtime"]),
             reverse=True)
    return out


def report_md(batch_id: str, base: Path | None = None) -> tuple[str, str] | None:
    """返回 (报告文本, 文件名)；无报告返回 None。"""
    p = _resolve(batch_id, base)
    if not p:
        return None
    rep = _report(p)
    if not rep:
        return None
    return rep.read_text(encoding="utf-8", errors="replace"), rep.name


def zip_path(batch_id: str, base: Path | None = None) -> Path | None:
    p = _resolve(batch_id, base)
    return _zip(p) if p else None


# ---------------------------------------------------------------- 人工核对截图
def _manual_dir(batch_id: str, base: Path | None = None,
                create: bool = False) -> Path | None:
    p = _resolve(batch_id, base)
    if not p:
        return None
    d = p / MANUAL_DIR
    if create:
        d.mkdir(parents=True, exist_ok=True)
    return d if d.is_dir() else None


def _is_image(name: str) -> bool:
    return Path(name).suffix.lower() in IMG_EXTS


def list_manual(batch_id: str, base: Path | None = None) -> list[dict]:
    """列出一个批次的人工核对截图（只列图片，不递归）。"""
    d = _manual_dir(batch_id, base)
    if not d:
        return []
    items = []
    for f in sorted(d.iterdir(), key=lambda x: (x.stat().st_mtime, x.name), reverse=True):
        if f.is_file() and _is_image(f.name):
            st = f.stat()
            items.append({"name": f.name, "size": st.st_size,
                          "mtime": datetime.datetime.fromtimestamp(
                              st.st_mtime).isoformat(timespec="seconds"),
                          "url": "/api/qe/deliveries/%s/manual-review/%s"
                                 % (batch_id, f.name)})
    return items


def manual_path(batch_id: str, name: str, base: Path | None = None) -> Path | None:
    d = _manual_dir(batch_id, base)
    if not d or not SAFE_RE.match(name or "") or not _is_image(name):
        return None
    d = d.resolve()
    p = (d / name).resolve()
    if p.parent != d:
        return None
    return p if p.is_file() else None


def _looks_image(ext: str, data: bytes) -> bool:
    if ext == ".png":
        return data.startswith(b"\x89PNG\r\n\x1a\n")
    if ext in (".jpg", ".jpeg"):
        return data.startswith(b"\xff\xd8\xff")
    if ext == ".gif":
        return data.startswith(b"GIF87a") or data.startswith(b"GIF89a")
    if ext == ".webp":
        return len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP"
    return False


def save_manual(batch_id: str, filename: str, data: bytes,
                base: Path | None = None) -> dict:
    """保存人工核对截图；返回落盘信息。调用方负责大小/数量限制。"""
    ext = Path(filename or "").suffix.lower()
    if ext not in IMG_EXTS:
        raise ValueError("仅支持 PNG/JPG/WebP/GIF 图片")
    if not data or not _looks_image(ext, data):
        raise ValueError("文件内容不是有效的 %s 图片" % ext)
    d = _manual_dir(batch_id, base, create=True)
    if not d:
        raise ValueError("交付批次不存在")
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", Path(filename).stem)[:40].strip("_") or "shot"
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = d / ("%s-%s%s" % (stamp, stem, ext))
    n = 1
    while dest.exists():
        dest = d / ("%s-%s-%d%s" % (stamp, stem, n, ext))
        n += 1
    dest.write_bytes(data)
    return {"name": dest.name, "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "url": "/api/qe/deliveries/%s/manual-review/%s" % (batch_id, dest.name)}
