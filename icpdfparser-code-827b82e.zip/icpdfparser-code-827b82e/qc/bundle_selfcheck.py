#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付包自证链自检 —— 「清单里的每个数，包内文件能不能重算出来」。

为什么要有这一层
----------------
V5 被判「自证链断裂」的经过值得写下来：`i18n_coverage` 是 V5 新引入的
**实测**指标（侧车 `<型号>.i18n.json` 随包），机制本身是对的。但同一天修订
重出包时，只更新了侧车与根 README，`manifest.json` 里的数值停在修订前的
`false / 0.9837`，侧车文件的 `sha256` 也没重算。复核方拿包一算：

    侧车说 1.0，清单说 0.9837，重算哈希两边都不符

于是「我们实测过」这句话在这个包里失去了证明力 —— 不是数据错了，是**自证
链断了**。这类错误的共同点是：**人漏了一步**。所以修法不能是「下次记得」，
而是让机器在打包末尾逐项重算，对不上就中断。

本模块刻意**不复用** `delivery_bundle.py` 的哈希函数与字段推导，而是重新实现
一遍。理由：如果两边共用同一个函数，那个函数写错了，自检也会跟着一起错 ——
那不叫校验，叫复读。这里算的是「一个不信任打包器的人会怎么算」。

用法
----
    python qc/bundle_selfcheck.py --out data/delivery-20261101-V6
    # 通过 → 退出码 0；不一致 → 打印逐项差异，退出码 1
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath

# 逐行判据（`is_dirty` / `escaped_reason` / 板卡身份）只允许有一套 ——
# AGENT.md §5.14：AC 列角色的正则各写一份，早晚会分叉。所以这里**复用逐行判据**，
# 但**不复用** `formal_container_integrity()` / `container_state()` 这两个容器级
# 结论函数：遍历哪些容器、怎么下结论，由本模块自己走一遍。那才是打包器可能写错
# 的地方，复用就等于复读（与哈希函数同一条纪律）。
try:
    from qc import ac_quarantine as _AQ
except Exception:  # 直接 `python qc/bundle_selfcheck.py` 时 sys.path[0] 是 qc/
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    try:
        from qc import ac_quarantine as _AQ
    except Exception:  # 判据不可用时退化为「只认显式隔离痕迹」，绝不因此判 pass 了事
        _AQ = None

#: 板卡类身份。与 `ac_quarantine.BOARD_IDENTITIES` 同口径；
#: `tests/test_bundle_selfcheck.py` 锁死两边相等。
_BOARD_IDENTITIES = (frozenset(_AQ.BOARD_IDENTITIES) if _AQ is not None
                     else frozenset({"evaluation_board", "reference_design",
                                     "module", "board"}))

#: 算「坐标级锚定」的结论。必须与 `delivery_bundle.ANCHORED_VERDICTS`
#: 一致 —— 这不是逻辑复用，是一份**契约声明**；`tests/test_bundle_selfcheck.py`
#: 里有用例锁死两边相等。
#:
#: V7 起 `verified`（容器级复现、无坐标）**不在其中**：8.9 分复审的 P0 就是
#: 它被混进锚定率，让 14 行零坐标的数据拿到了 `14/14`。
ANCHORED_VERDICTS = ("verified_row", "verified_paragraph", "verified_value")

#: 交付包的全量语言。`i18n_complete=true` 要求这五种**都真的渲染出 HTML**
#: （2026-11-03 外审 V2）。与 `delivery_bundle.REQUIRED_LANGS` 是同一份契约，
#: 但独立抄一份 —— 理由同 `_GRADE`。
REQUIRED_LANGS = ("en", "ja", "ko", "de", "es")

#: 结论 → 等级。**独立抄一份**，刻意不从打包器 import：共用同一张表，
#: 表写错时自检会跟着一起错，那就不叫自检了。
_GRADE = {
    "verified_row": "row_anchor",
    "verified_paragraph": "paragraph_anchor",
    "verified_value": "coord_no_fingerprint",
    "verified": "container_verified",
}
#: 参数载体 → 门槛（与 `qc/fact_acceptance.py::REQUIREMENT` 同一份契约）。
_NEED = {"table": "row_anchor", "prose": "paragraph_anchor"}
_RANK = {"row_anchor": 4, "paragraph_anchor": 3, "coord_no_fingerprint": 2,
         "container_verified": 1, "weak": 0}

#: 文本物料按 CRLF→LF 归一后哈希；PDF / ZIP 按原始字节。
TEXT_SUFFIXES = (".json", ".html", ".csv", ".md", ".txt", ".xml")


def _sha_text(p: Path) -> str:
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def _sha_raw(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _member_hash(p: Path, member: str) -> str:
    """按成员类型选口径。**唯一判据是扩展名**，与打包器同一条规则。"""
    return _sha_raw(p) if member.lower().endswith(".pdf") else _sha_text(p)


def _member_size(p: Path, member: str) -> int:
    """成员大小，与哈希**同一口径**。

    哈希按 CRLF→LF 归一，大小时也必须归一 —— 否则同一份包在两种环境下
    会得出「哈希对得上、大小对不上」的分裂结论。实测来源：`core.autocrlf=true`
    的 Windows 机器 `git clone` 交付仓库后，三个 `.md` 被写成 CRLF
    （11653 → 11856），哈希仍匹配而归一前的字节数不匹配。
    """
    raw = p.read_bytes()
    if member.lower().endswith(".pdf"):
        return len(raw)
    return len(raw.replace(b"\r\n", b"\n"))


#: 交付说明里那张家表的表头。与 `delivery_bundle.NOTE_TABLE_HEAD` 同一份契约 ——
#: 两边写死同一行，改了哪一边都会立刻在自检里红掉。
NOTE_TABLE_HEAD = ("| 型号 | 审计行数 | row_anchor | paragraph_anchor | weak "
                   "| anchor_gate | facts_verdict | release_state | content_signoff |")

#: 已废止的口径。出现在交付说明里就说明文档没跟上数据（V7 的 P0）。
NOTE_FORBIDDEN = (
    "data_anchor",
)

#: 「未申请」这句**只在没有签核时才对**。旧实现把它写进无条件禁用词，于是
#: 未签核的包（batch100 91 件）必然被判「说明比数据旧」—— 生成器按实况写，
#: 自检按固定词表禁，两边把对方判死，step5 直接拒绝出包（2026-11-05 实测）。
#: 现在改成**按清单里的签核实况**决定它是不是过期表述。
STALE_SIGNOFF_CLAIM = "`CONTENT_APPROVED` / `RELEASE_APPROVED` 未申请，需人工签核"


def _check_delivery_note(out: Path, man: dict) -> list[str]:
    """《交付说明.md》必须与 manifest 逐格一致。

    V7 的 P0 就是"包是 V7、交付说明还是 V6"：写着 `ADS8568EVM-PDK 14/14`、
    `DATA_VALIDATED`，而 manifest 是 `21/49`、`PACKAGING_PASSED`。
    复核方先读说明再看清单，两份对不上等于没有说明 —— 所以这条要硬拦。
    """
    bad: list[str] = []
    note = out / "交付说明.md"
    if not note.is_file():
        return ["缺交付说明.md"]
    text = note.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    # ① 版本号：标题必须写本包名，不能是上一版。
    head = next((ln for ln in lines if ln.startswith("# 交付说明")), "")
    if out.name not in head:
        bad.append(f"交付说明标题与研究包名不符：{head[:60]!r} 应含 {out.name}")

    # ② 已废止口径不许再出现。
    for tok in NOTE_FORBIDDEN:
        if tok in text:
            bad.append(f"交付说明仍引用已废止口径：{tok}")

    # ②b 「未申请」只有在**清单里确实没有签核**时才是正确表述。
    # 有签核却还写「未申请」→ 说明比数据旧，红；没签核写了 → 正常，放过。
    _n_signed = sum(1 for r in (man.get("records") or [])
                    if str(r.get("content_signoff") or "NONE") != "NONE")
    if _n_signed and STALE_SIGNOFF_CLAIM in text:
        bad.append(f"交付说明仍写「{STALE_SIGNOFF_CLAIM}」，"
                   f"但清单已有 {_n_signed} 件签核 —— 说明比数据旧")

    # ③ 表必须存在，且逐型号与 manifest 一致。
    try:
        start = lines.index(NOTE_TABLE_HEAD)
    except ValueError:
        return bad + ["交付说明缺本包实测表（打包器渲染的那张）"]
    table: dict[str, list[str]] = {}
    for ln in lines[start + 2:]:
        if not ln.strip().startswith("|"):
            break
        cells = [c.strip().strip("`") for c in ln.strip().strip("|").split("|")]
        if len(cells) >= 7:
            table[cells[0]] = cells
    by_mpn = {str(r.get("requested_mpn") or ""): r for r in man.get("records") or []}
    if not table:
        return bad + ["交付说明实测表为空"]

    facts_path = out / "part-0001-of-0001" / "facts_audit.json"
    facts_map = {}
    if facts_path.is_file():
        try:
            facts_map = (json.loads(facts_path.read_text(encoding="utf-8")) or {}
                         ).get("mpns") or {}
        except ValueError:
            facts_map = {}

    for mpn, rec in by_mpn.items():
        cells = table.get(mpn)
        if cells is None:
            bad.append(f"交付说明缺型号行：{mpn}")
            continue
        want_row = str(rec.get("row_anchor") or "").split("/")[0]
        want_para = str(rec.get("paragraph_anchor") or "").split("/")[0]
        want_total = str(rec.get("row_anchor") or "").split("/")[-1]
        g = (facts_map.get(mpn) or {}).get("grades") or {}
        want_weak = str(int(g.get("weak") or 0)) if g else cells[4]
        # V9 起实测表多一列 `facts_verdict`（插在 `anchor_gate` 与 `release_state`
        # 之间），列序号因此后移一格。这里按**列名**取值而不是硬编码下标，
        # 以后再加列也不用改这里。
        head = [c.strip() for c in lines[start].strip().strip("|").split("|")]
        def cell(name: str) -> str:
            i = next((k for k, h in enumerate(head) if name in h), -1)
            return cells[i] if 0 <= i < len(cells) else ""
        pairs = (("审计行数", cell("审计行数"), want_total),
                 ("row_anchor", cell("row_anchor"), want_row),
                 ("paragraph_anchor", cell("paragraph_anchor"), want_para),
                 ("weak", cell("weak"), want_weak),
                 ("anchor_gate", cell("anchor_gate"), str(rec.get("anchor_gate") or "")),
                 ("facts_verdict", cell("facts_verdict"),
                  str(rec.get("facts_verdict") or "")),
                 ("release_state", cell("release_state"),
                  str(rec.get("release_state") or "")),
                 # 人工维度必须与机器维度一样被逐格核对：交付说明里写了
                 # `APPROVED (with warnings)` 而清单没有、或反过来，都是转述失真。
                 ("content_signoff", cell("content_signoff"),
                  str(rec.get("content_signoff") or "NONE")))
        for name, got, want in pairs:
            if got != want:
                bad.append(f"交付说明与 manifest 不符：{mpn} {name} 写 {got!r} "
                           f"清单是 {want!r}")
    for mpn in table:
        if mpn not in by_mpn:
            bad.append(f"交付说明多出型号行：{mpn}")

    # ④ 隔离脚注：JSON 里存在 `specs.unresolved_*` 行时，说明里必须有一行「注：」
    # 写明型号与条数。V11 的教训是「数据被隔离了，但读者不知道少了几行」——
    # 复核方拿 `facts_audit` 的总行数去减上表，差额会被当成漏审计。
    for mpn, rec in by_mpn.items():
        items = _isolation_rows(out, str(rec.get("safe_name") or mpn))
        if not items:
            continue
        hits = [ln for ln in lines if ln.strip().startswith("注：") and mpn in ln]
        if not hits:
            bad.append(f"交付说明缺隔离脚注：{mpn}"
                       f"（JSON 有 {sum(n for _, n in items)} 行被隔离）")
            continue
        joined = " ".join(hits)
        for key, n in items:
            if f"specs.{key}" not in joined:
                bad.append(f"交付说明隔离脚注未写明容器：{mpn} {key}")
            if str(n) not in joined:
                bad.append(f"交付说明隔离脚注条数与 JSON 不符：{mpn} {key} 应含 {n}")

    # ⑤ AC 容器状态表：`formal_container_integrity` / `ac_data_state` 必须逐型号
    # 与 manifest 一致。这两格是复审方用来判断「隔离到底做了没有」的第一入口，
    # 说明与清单对不上，比没有这张表更糟。
    for mpn, rec in by_mpn.items():
        if "formal_container_integrity" not in rec:
            continue  # 老包没这两列，不拿新规则去卡历史产物
        want_i = str(rec.get("formal_container_integrity") or "")
        want_s = str(rec.get("ac_data_state") or "")
        rows = [ln for ln in lines
                if ln.strip().startswith("|") and f"`{mpn}`" in ln
                and want_i in ln and want_s in ln]
        if not rows:
            bad.append(f"交付说明缺 AC 容器状态行：{mpn}"
                       f"（应含 {want_i} / {want_s}）")
    return bad


def _isolation_rows(out: Path, safe: str) -> list[tuple[str, int]]:
    """从**包内 JSON**数隔离行：`specs` 下以 `unresolved_` 开头的非空列表。

    刻意不复用 `delivery_bundle.isolation_rows()` —— 自检要能独立成立，
    共用一份实现的话，那份实现漏了容器，两边会一起漏（与哈希函数同一个理由）。
    """
    p = out / "part-0001-of-0001" / safe / f"{safe}.json"
    if not p.is_file():
        return []
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    specs = (doc or {}).get("specs") or {}
    return [(k, len(v)) for k, v in specs.items()
            if isinstance(v, list) and v and k.startswith("unresolved_")]


#: 正式容器里不该再出现的「隔离痕迹」。行被搬进隔离桶后，如果还带着这些键
#: 留在 `specs.electrical` / `specs.ac` 里，说明搬了一半或渲染层又塞了回去。
_QUARANTINE_MARKS = ("quarantine_reason", "quarantined_from", "escaped_from")

#: AC 容器名与板载桶名（`ac_quarantine` 的数据常量，不是判据）。
_AC_CONTAINER = "ac_performance"
_AC_BUCKETS = ("onboard_device_specs", "unresolved_specs")


def _spec_row_lists(node, path: str = ""):
    """递归产出 `specs` 下所有「行列表」的 `(路径, 行列表)`。

    旧实现只扫 `specs` 的**第一层** list，于是
    `specs.onboard_device_specs.electrical`（板卡件的二级容器）整段漏掉。
    AFE7950 的 64 条 AC 逃逸行恰好躲在这里：清单如实记 `fail`，自检却算出
    `pass`，两句话互相判死，step5 因此拒绝出包（2026-11-05 实测）。

    隔离桶 `unresolved_*` 不参与：它不是正式容器，里面的行本来就该待在那儿。
    """
    if isinstance(node, list):
        if node and all(isinstance(x, dict) for x in node):
            yield path, node
        return
    if not isinstance(node, dict):
        return
    for key, val in node.items():
        if str(key).startswith("unresolved_"):
            continue
        child = f"{path}.{key}" if path else str(key)
        yield from _spec_row_lists(val, child)


def _is_board_doc(doc: dict) -> bool:
    """板卡件判定 —— 与 `ac_quarantine._is_board()` 同口径（两份取值都查）。"""
    bi = (doc or {}).get("basic_info") or {}
    if str(bi.get("identity") or "").strip() in _BOARD_IDENTITIES:
        return True
    scope = str(((doc or {}).get("specs") or {}).get("scope") or "").strip()
    return scope in ("board", "onboard_device")


def _container_state(out: Path, safe: str) -> dict:
    """从**包内 JSON** 独立重算 AC 容器状态（`integrity` / `state`）。

    刻意不复用 `delivery_bundle.container_state()`：那个是「写清单的人」，
    自检调它就成了自己给自己签字 —— 清单写错时两边一起错（与哈希函数同一个理由）。
    也不复用 `ac_quarantine.formal_container_integrity()`，理由相同。

    这里用两条最朴素的事实，宁可判得比定义**严**，也不能判得比它松：
      * 隔离桶 `specs.unresolved_ac_rows` 非空 → `withheld`
      * 正式容器（含 `onboard_device_specs.electrical` 这类二级/三级容器）里
        还有带隔离痕迹的行 → `fail`
      * AC 容器里的行 `min/typ/max` 有非数值格 → `fail`
      * 板卡件的电气容器里出现 AC 类参数、且没有自己的 `bbox + row_sha256`
        → `fail`（跨容器逃逸，V11 的 P0）

    后两条的**逐行判据**取自 `ac_quarantine`（§5.14 只允许一套口径），
    但遍历与结论由本函数自己走 —— 只复用判据，不复用结论。
    """
    p = out / "part-0001-of-0001" / safe / f"{safe}.json"
    res = {"integrity": "", "state": "", "escaped_rows": 0,
           "reasons": (), "sources": (), "evidence_source": "none"}
    if not p.is_file():
        return res
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return res
    # 2026-11-05 SSOT：自检与清单必须用**同一套逐行判据**，但证据必须来自
    # 包内 facts_audit.csv（不能只看 metadata 的记录值）。全平反时只比
    # integrity 会假绿；escaped_rows / reasons / sources / evidence_source
    # 是区分「没扫」与「扫完干净」的三个补充维度。
    ev: dict = {}
    fact = out / "part-0001-of-0001" / "facts_audit.csv"
    if fact.is_file():
        try:
            from qc import fact_status_sync as _FSS             # noqa: PLC0415
            ev = (_FSS.load_evidence(fact) or {}).get(safe) or {}
        except Exception:                                      # noqa: BLE001
            ev = {}
    if _AQ is not None:
        try:
            f = _AQ.container_findings(doc, ev)
            res.update({
                "integrity": f["integrity"],
                "state": f["state"],
                "escaped_rows": len(f["escaped"]),
                "reasons": tuple(f["reasons"]),
                "sources": tuple(f["sources"]),
                "evidence_source": ("facts_audit.csv" if ev else "none"),
            })
            return res
        except Exception:                                      # noqa: BLE001
            pass
    specs = (doc or {}).get("specs") or {}
    if not isinstance(specs, dict):
        return {"integrity": "pass", "state": "not_withheld",
                "escaped_rows": 0, "reasons": (), "sources": (),
                "evidence_source": "none"}
    isolated = specs.get("unresolved_ac_rows")
    res["state"] = ("withheld" if isinstance(isolated, list) and isolated
                    else "not_withheld")
    board = _is_board_doc(doc)
    for path, rows in _spec_row_lists(specs):
        in_ac = path == _AC_CONTAINER or path.endswith("." + _AC_CONTAINER)
        # 根 `electrical` 只对板卡件扫（芯片页主表里的 SNR/THD 是原表内容，
        # 不是逃逸）；桶内 `*.electrical` 一律扫。
        in_elec = path.endswith(".electrical") or (board and path == "electrical")
        for row in rows:
            # 显式隔离痕迹：出现在正式容器里就是搬了一半，任何容器都算 fail。
            if any(row.get(k) for k in _QUARANTINE_MARKS):
                res["integrity"] = "fail"
                return res
            if in_ac and _AQ is not None and _AQ.is_dirty(row):
                res["integrity"] = "fail"
                return res
            if in_elec and _AQ is not None and _AQ.escaped_reason(row):
                res["integrity"] = "fail"
                return res
    res["integrity"] = "pass"
    return res


#: 文档里「ZIP 多大」这类字节数声明。只认带千分位的写法（`12,124,048 B`）——
#: 不带千分位的裸数字在正文里到处都是，抓它必然误报。
_BYTE_CLAIM_RE = re.compile(r"(\d{1,3}(?:,\d{3})+)\s*(?:B|bytes|字节)")

#: 交付目录名。发布仓库根 README 是**多轮累计**的文档，同一份文件里同时写着
#: V11 和 V2 的 ZIP 大小，两者本来就不该相等。
_DELIVERY_TOKEN_RE = re.compile(r"delivery-\d{8}(?:-V\d+)?")


def _check_doc_byte_claims(out: Path, extras=()) -> list[str]:
    """包内 `.md` 里凡是「提到 ZIP 又给了字节数」的地方，都必须等于真实大小。

    V11 的 432 字节差就是这么来的：报告取的是最终落盘值，发布仓库根 README
    里的数却是手抄的中间值。报告侧已经钉死（见 `check()` 第 ④ 组），
    但文档是另一条路 —— 只要还允许手抄，就会再抄错一次。

    `extras` 用来把**包外**文档（发布仓库根 `README.md` 那种）也拉进同一条规则：
    那正是 V11 出错的那份文件，只在包里查等于没查。

    **按小节归属判定**：一个字节数说的是哪个包，取决于它写在哪个标题下
    （或同一行里点了哪个 `delivery-*`）。发布仓库根 README 同时记录多轮，
    拿本包大小去卡 V11 那一段，只会逼着人把历史数字删掉 —— 那是毁证据，
    不是修错。只有「讲本包」的声明才核。
    """
    zpath = out / "part-0001-of-0001.zip"
    if not zpath.is_file():
        return []
    real = zpath.stat().st_size
    bad: list[str] = []
    targets = list(sorted(out.glob("*.md")))
    for p in extras:
        p = Path(p)
        if p.is_file() and p not in targets:
            targets.append(p)
    for md in targets:
        try:
            lines = md.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        section = ""
        for i, ln in enumerate(lines, 1):
            if ln.lstrip().startswith("#"):
                section = ln
            if not any(tok in ln for tok in ("ZIP", "zip", "分卷")):
                continue
            toks = set(_DELIVERY_TOKEN_RE.findall(f"{section} {ln}"))
            if toks and out.name not in toks:
                continue  # 这一段讲的是别的包
            for m in _BYTE_CLAIM_RE.finditer(ln):
                claimed = int(m.group(1).replace(",", ""))
                if claimed != real:
                    bad.append(f"{md.name}:{i} 写 ZIP 为 {m.group(1)} B，"
                               f"实际 {real:,} B（差 {claimed - real:+,}）")
    return bad


def _i18n_from_sidecar(p: Path) -> tuple[str, str]:
    """从侧车重算 `(i18n_complete, i18n_coverage)`。

    口径（与打包器一致，但**刻意各写一份**）：所有语言都 `i18n_complete is True`
    才算 true；覆盖率取**所有语言里最低**的那个 —— 只报最好看的数字等于没报。

    V2（2026-11-03 外审）两条硬规则，与 `delivery_bundle._i18n_fields()` 同步：
      * `true` 的唯一条件是**五种语言都真的渲染出 HTML**（`REQUIRED_LANGS`）。
        旧判据是 `all(...)`，只跑 en 时侧车只有 en 一项，`all` 对单元素恒真，
        于是「只交了英文」在清单里写成「多语言完整」。
      * 覆盖率空值落 `0.0`，不落空串 —— 空串在 Excel 里分不清「没测」与「测了是 0」。

    这里不复用打包器的函数是刻意的：共用一份实现，函数写错了自检会跟着错。
    """
    try:
        side = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "not_checked", "0.0"
    langs = side.get("languages") or {}
    if not langs:
        return "not_checked", "0.0"
    complete = (set(langs) >= set(REQUIRED_LANGS)
                and all(v.get("i18n_complete") is True for v in langs.values()))
    ratios = []
    for v in langs.values():
        cov = v.get("i18n_coverage")
        if isinstance(cov, dict) and cov.get("ratio") is not None:
            ratios.append(float(cov["ratio"]))
    return ("true" if complete else "false",
            f"{min(ratios):.4f}" if ratios else "0.0")


def _count_csv_rows(p: Path) -> int:
    """数 CSV 的数据行（不含表头），与打包器写 manifest 时同一口径。"""
    if not p.is_file():
        return -1
    with p.open(encoding="utf-8-sig", newline="") as f:
        return sum(1 for _ in csv.DictReader(f))


def _anchor_from_csv(p: Path, mpn: str) -> dict:
    """从随包 `facts_audit.csv` 重算四列 + 闸门结论。

    V6 只重算一个 `data_anchor`（把容器级也算进去的混合口径）。V7 拆开：
    行级 / 正文级 / 容器级 / 坐标级各算各的，闸门按行自己的载体要求判。
    这里**不看 CSV 里的 `grade` 列**，只按 `verdict` 重算等级 —— CSV 说
    「我这行是 row_anchor」不算数，得看它到底有没有 `bbox` 和 `row_sha256`。
    """
    if not p.is_file():
        return {}
    n = denom = 0
    cnt = {g: 0 for g in _RANK}
    blocked = 0
    try:
        with p.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if row.get("mpn") != mpn:
                    continue
                n += 1
                v = str(row.get("verdict") or "")
                g = _GRADE.get(v, "weak")
                # 字段与结论错配 → 降级，与审计器的 `_effective_grade` 同一条判据
                if g == "row_anchor" and not (row.get("bbox")
                                              and row.get("row_sha256")):
                    g = "weak"
                elif g == "paragraph_anchor" and not (row.get("bbox")
                                                     and row.get("paragraph_sha256")):
                    g = "weak"
                elif g == "coord_no_fingerprint" and not row.get("bbox"):
                    g = "weak"
                cnt[g] = cnt.get(g, 0) + 1
                if v == "unchecked" and not row.get("value"):
                    continue          # 行内无数值：不进分母
                denom += 1
                kind = str(row.get("kind") or "table")
                if _RANK[g] < _RANK[_NEED.get(kind, "row_anchor")]:
                    blocked += 1
    except (OSError, csv.Error):
        return {}
    if not n:
        return {}
    coord = cnt["row_anchor"] + cnt["paragraph_anchor"] + cnt["coord_no_fingerprint"]
    return {
        "row_anchor": f'{cnt["row_anchor"]}/{n}',
        "paragraph_anchor": f'{cnt["paragraph_anchor"]}/{n}',
        "container_verified": f'{cnt["container_verified"]}/{n}',
        "coord_anchor": f"{coord}/{n}",
        "anchor_gate": "blocked" if blocked else "pass",
    }


def check(out: Path, extra_docs=()) -> list[str]:
    """逐项重算，返回不一致描述（空列表 = 通过）。

    `extra_docs` 是包外文档（发布仓库根 `README.md` 等）—— 出包时不用，
    推送前用它把仓库根那份也过一遍同一条规则。
    """
    out = Path(out)
    bad: list[str] = []
    mf = out / "manifest.json"
    if not mf.is_file():
        return [f"缺 manifest.json：{mf}"]
    try:
        man = json.loads(mf.read_text(encoding="utf-8"))
    except ValueError as e:
        return [f"manifest.json 解析失败：{e}"]

    shard = out / "part-0001-of-0001"
    if not shard.is_dir():
        return [f"缺分卷目录：{shard}"]

    # ① 每个成员的哈希与大小，都拿包内文件重算。
    by_member: dict[str, dict] = {}
    for m in man.get("members") or []:
        arc = str(m.get("member") or "")
        by_member[arc] = m
        f = shard / arc
        if not f.is_file():
            bad.append(f"成员缺失：{arc}")
            continue
        got = _member_hash(f, arc)
        if got != str(m.get("sha256") or ""):
            bad.append(f"成员哈希不符：{arc} 记录 {str(m.get('sha256'))[:16]} "
                       f"实算 {got[:16]}")
        if int(m.get("size") or -1) != _member_size(f, arc):
            bad.append(f"成员大小不符：{arc} 记录 {m.get('size')} "
                       f"实算 {_member_size(f, arc)}（文本按 CRLF→LF 归一后计长）")

    # ② 每条记录的关键指标，都从包内物料重算。
    for rec in man.get("records") or []:
        m = str(rec.get("safe_name") or "")
        if not m:
            bad.append("记录缺 safe_name")
            continue
        base = shard / m

        side = base / f"{m}.i18n.json"
        if side.is_file():
            want_c, want_r = _i18n_from_sidecar(side)
            if str(rec.get("i18n_complete") or "") != want_c:
                bad.append(f"{m}: i18n_complete 记录 {rec.get('i18n_complete')!r} "
                           f"侧车重算 {want_c!r}")
            if str(rec.get("i18n_coverage") or "") != want_r:
                bad.append(f"{m}: i18n_coverage 记录 {rec.get('i18n_coverage')!r} "
                           f"侧车重算 {want_r!r}")
        elif str(rec.get("i18n_complete") or "") not in ("", "not_checked"):
            bad.append(f"{m}: 无侧车却记录了 i18n_complete={rec.get('i18n_complete')!r}")

        pdf = base / f"{m}.pdf"
        if pdf.is_file():
            got = _sha_raw(pdf)
            if str(rec.get("pdf_sha256_packaged") or "") != got:
                bad.append(f"{m}: pdf_sha256_packaged 与包内 PDF 不符")
            match = got == str(rec.get("pdf_sha256_recorded") or "")
            if rec.get("pdf_hash_match") is not match:
                bad.append(f"{m}: pdf_hash_match 记录 {rec.get('pdf_hash_match')!r} "
                           f"重算 {match!r}")
        elif rec.get("pdf_included") is True:
            bad.append(f"{m}: 记录 pdf_included=true 但包内无 PDF")

        want_anchor = _anchor_from_csv(shard / "facts_audit.csv", m)
        for col, want in (want_anchor or {}).items():
            if str(rec.get(col) or "") != str(want):
                bad.append(f"{m}: {col} 记录 {rec.get(col)!r} "
                           f"facts_audit.csv 重算 {want!r}")

        present = rec.get("present") or []
        if str(rec.get("artifacts") or "") != f"{len(present)}/8":
            bad.append(f"{m}: artifacts 记录 {rec.get('artifacts')!r} "
                       f"present 计数 {len(present)}/8")

        # AC 容器状态：清单写的两个值必须能从**包内 JSON** 重算出来。
        # 这一列存在的意义就是给复核方一个不用信任正文的判据 —— 它自己不能是不可
        # 重算的。老包没有这两列，跳过。
        if "formal_container_integrity" in rec:
            want = _container_state(out, m)
            got_i = str(rec.get("formal_container_integrity") or "")
            got_s = str(rec.get("ac_data_state") or "")
            if want["integrity"] and got_i != want["integrity"]:
                bad.append(f"{m}: formal_container_integrity 记录 {got_i!r} "
                           f"包内 JSON 重算 {want['integrity']!r}")
            if want["state"] and got_s != want["state"]:
                bad.append(f"{m}: ac_data_state 记录 {got_s!r} "
                           f"包内 JSON 重算 {want['state']!r}")

    # ③ ZIP 内每个成员的哈希，与清单记录比对（复核方拿到的就是这一份）。
    zpath = out / str(man.get("shard") or "part-0001-of-0001.zip")
    if not zpath.is_file():
        bad.append(f"缺分卷 ZIP：{zpath}")
    else:
        with zipfile.ZipFile(zpath) as z:
            names = set(z.namelist())
            for arc, m in by_member.items():
                if arc not in names:
                    bad.append(f"ZIP 内缺成员：{arc}")
                    continue
                data = z.read(arc)
                got = (hashlib.sha256(data).hexdigest()
                       if arc.lower().endswith(".pdf")
                       else hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest())
                if got != str(m.get("sha256") or ""):
                    bad.append(f"ZIP 成员哈希与清单不符：{arc}")
            for name in names:
                pp = PurePosixPath(name)
                if "\\" in name or pp.is_absolute() or ".." in pp.parts:
                    bad.append(f"ZIP 非法路径：{name}")

    # ④ 校验报告（若已写出）里的数值也要能重算。
    rep = out / "包校验报告.json"
    if rep.is_file():
        try:
            r = json.loads(rep.read_text(encoding="utf-8"))
        except ValueError:
            r = {}
        if r:
            if zpath.is_file() and str(r.get("zip_sha256") or "") != _sha_raw(zpath):
                bad.append("包校验报告: zip_sha256 与实算不符")
            # `zip_size` 必须等于**磁盘上那个 ZIP**的字节数。V11 的 432 字节差
            # 就是「报告取终值、文档抄了中间值」—— 报告这一侧先钉死，文档那一侧
            # 由 `_check_doc_byte_claims()` 钉死，两头一起才闭合。
            if (zpath.is_file() and r.get("zip_size") is not None
                    and int(r.get("zip_size") or -1) != zpath.stat().st_size):
                bad.append(f"包校验报告: zip_size 记 {r.get('zip_size')} "
                           f"实测 {zpath.stat().st_size}")
            vm = {x.get("member"): x.get("sha256") for x in r.get("verified_members") or []}
            for arc, m in by_member.items():
                if arc in vm and vm[arc] != m.get("sha256"):
                    bad.append(f"包校验报告: verified_members 与清单不符：{arc}")
            if r.get("i18n_validation") == "not_checked":
                bad.append("包校验报告: i18n_validation 仍是 not_checked，"
                           "但清单已有实测覆盖率（口径自相矛盾）")

    # ⑥ 事实表 / 风险队列的行数口径（V8 复审 新-4）。
    # 之前自检只重算哈希和「每条记录的几列」，风险队列有多少行、事实表分母多大
    # 全靠《交付说明》正文里的一句话 —— 说明写错了没人拦得住，复核方也没法重算。
    # 现在清单里有 `facts_summary` 与每条的 `facts_rows`，这里拿包内 CSV 数一遍。
    fs = man.get("facts_summary") or {}
    fa_csv = shard / "facts_audit.csv"
    rq_csv = shard / "risk_queue.csv"
    if fs:
        for key, p in (("facts_audit_rows", fa_csv), ("risk_queue_rows", rq_csv)):
            want = int(fs.get(key) if fs.get(key) is not None else -1)
            if not p.is_file():
                if want > 0:
                    bad.append(f"facts_summary 记 {key}={want} 但包内缺 {p.name}")
                continue
            got = _count_csv_rows(p)
            if got != want:
                bad.append(f"facts_summary.{key} 记录 {want} 实测 {got}（{p.name}）")
    # 逐型号的审计行数：清单 `facts_rows` 必须等于 facts_audit.csv 里该型号的行数。
    if fa_csv.is_file():
        per_mpn: dict[str, int] = {}
        with fa_csv.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                k = str(row.get("mpn") or "")
                if k:
                    per_mpn[k] = per_mpn.get(k, 0) + 1
        for rec in man.get("records") or []:
            m = str(rec.get("safe_name") or "")
            if not m:
                continue
            # 只有**声明了** `facts_rows` 的记录才校验：V9 之前的包没有这一列，
            # 拿新规则去卡旧包等于把历史包全判红，那不是自检该干的事。
            if "facts_rows" not in rec:
                continue
            want = int(rec.get("facts_rows") or 0)
            got = per_mpn.get(m, 0)
            if want != got:
                bad.append(f"{m}: facts_rows 记录 {want} facts_audit.csv 实测 {got}")
        if fs and int(fs.get("facts_audit_rows") or 0) != sum(per_mpn.values()):
            bad.append("facts_summary.facts_audit_rows 与逐型号行数之和不符")

    # ⑦ 交付说明与清单必须逐格一致（V7 的 P0：说明停在上一版）。
    bad += _check_delivery_note(out, man)
    # ⑧ 文档里的「ZIP 多大」必须等于磁盘上那个 ZIP（V11 的 432 字节差）。
    bad += _check_doc_byte_claims(out, extra_docs)
    return bad


def report(out: Path) -> dict:
    """结构化自检结论 —— 直接落进 `包校验报告.json` 的 `selfcheck` 字段。

    复审【新-1】：V6 说「复核方可以自己跑同一份脚本，它就在包里」，而包里
    没有 `.py`。声明与产物不符，整个「机器拦」的卖点就只剩下自述。
    V7 的做法：脚本本体仍不进包（仓库只放交付物的政策不变），但**结论必须落盘**，
    逐项 `item / expected / actual / ok`，复核方不跑脚本也能看到机器算出了什么。

    这里刻意不返回「全部 ok」这种笼统结论：每一条都带期望值与实算值，
    复核方可以挑任意一条自己去核。
    """
    out = Path(out)
    man_p = out / "manifest.json"
    items: list[dict] = []
    if not man_p.is_file():
        return {"schema": "bundle-selfcheck/v1", "passed": False,
                "items": [{"item": "manifest.json", "expected": "存在",
                           "actual": "缺失", "ok": False}]}
    man = json.loads(man_p.read_text(encoding="utf-8"))
    shard = out / str(man.get("shard") or "part-0001-of-0001")
    shard = shard.with_suffix("") if shard.suffix == ".zip" else shard
    if not shard.is_dir():
        shard = out / str(man.get("shard") or "part-0001-of-0001").replace(".zip", "")

    # ① 成员哈希：清单记录的每个 sha256，都从磁盘文件重算一遍。
    by_member = {str(m.get("member") or ""): m for m in man.get("members") or []}
    n_ok = 0
    for arc, m in by_member.items():
        p = shard / arc
        if not p.is_file():
            items.append({"item": f"member[{arc}]", "expected": "存在",
                          "actual": "缺失", "ok": False})
            continue
        got = _member_hash(p, arc)
        ok = got == str(m.get("sha256") or "")
        n_ok += 1 if ok else 0
        if not ok:
            items.append({"item": f"member[{arc}].sha256",
                          "expected": m.get("sha256"), "actual": got, "ok": False})
    items.append({"item": "members.sha256", "expected": len(by_member),
                  "actual": n_ok, "ok": n_ok == len(by_member)})

    # ② 每条记录的锚定列 / i18n / PDF 哈希：从包内文件重算。
    for rec in man.get("records") or []:
        mpn = str(rec.get("safe_name") or "")
        want = _anchor_from_csv(shard / "facts_audit.csv", mpn)
        for col, val in (want or {}).items():
            items.append({"item": f"record[{mpn}].{col}",
                          "expected": val, "actual": rec.get(col),
                          "ok": str(rec.get(col) or "") == str(val)})
        side = shard / mpn / f"{mpn}.i18n.json"
        if side.is_file():
            c, r = _i18n_from_sidecar(side)
            items.append({"item": f"record[{mpn}].i18n",
                          "expected": f"{c}/{r}",
                          "actual": f'{rec.get("i18n_complete")}/{rec.get("i18n_coverage")}',
                          "ok": (str(rec.get("i18n_complete")) == c
                                 and str(rec.get("i18n_coverage")) == r)})
        pdf = shard / mpn / f"{mpn}.pdf"
        if pdf.is_file():
            got = _sha_raw(pdf)
            items.append({"item": f"record[{mpn}].pdf_sha256",
                          "expected": got, "actual": rec.get("pdf_sha256_packaged"),
                          "ok": str(rec.get("pdf_sha256_packaged")) == got})

    # ③ ZIP：成员哈希与 CRC 由 zipfile 读回时校验。
    zp = out / str(man.get("shard") or "")
    if zp.is_file():
        with zipfile.ZipFile(zp) as z:
            bad_crc = z.testzip()
            got = _sha_raw(zp)
            items.append({"item": "zip.sha256", "expected": got,
                          "actual": got, "ok": True})
            items.append({"item": "zip.crc", "expected": "ok",
                          "actual": "ok" if bad_crc is None else f"坏成员 {bad_crc}",
                          "ok": bad_crc is None})
    else:
        items.append({"item": "zip", "expected": "存在", "actual": "缺失", "ok": False})

    # ③b 交付说明与清单逐格一致（V7 的 P0）。单独出一项，
    #     免得它混在 check() 兜底里只显示成一行 "check()"。
    note_bad = _check_delivery_note(out, man)
    items.append({"item": "delivery_note.consistency",
                  "expected": "逐型号与 manifest 一致且含本包实测表",
                  "actual": "一致" if not note_bad else "; ".join(note_bad)[:300],
                  "ok": not note_bad})

    # ③b2 文档里的 ZIP 字节数必须等于磁盘上那个 ZIP（V11 的 432 字节差）。
    byte_bad = _check_doc_byte_claims(out)
    items.append({"item": "docs.zip_size",
                  "expected": "文档中 ZIP 字节数与实际文件一致",
                  "actual": "一致" if not byte_bad else "; ".join(byte_bad)[:300],
                  "ok": not byte_bad})

    # ③c 事实表 / 风险队列的行数口径（V9 复审 新-4）。两个计数各出一项：
    #     之前「审了多少行」只在《交付说明》正文里以自然语言出现，写错了没人拦。
    fs = man.get("facts_summary") or {}
    if fs:
        for key, name in (("facts_audit_rows", "facts_audit.csv"),
                          ("risk_queue_rows", "risk_queue.csv")):
            want = int(fs.get(key) or 0)
            got = _count_csv_rows(shard / name)
            items.append({"item": f"facts_summary.{key}", "expected": want,
                          "actual": got, "ok": got == want})

    # ④ 兜底：`check()` 抓到的任何不一致都在这里现身，且必须是红的。
    for line in check(out):
        items.append({"item": "check()", "expected": "无差异",
                      "actual": line, "ok": False})
    return {
        "schema": "bundle-selfcheck/v1",
        "script": "qc/bundle_selfcheck.py（不复用打包器的哈希函数）",
        "scope": ("成员哈希 / 每条记录的锚定列与 i18n / 随包 PDF 哈希 / ZIP CRC"
                  " / 交付说明与 manifest 一致性 / 事实表与风险队列行数"),
        "passed": all(x["ok"] for x in items),
        "n_items": len(items), "n_failed": sum(1 for x in items if not x["ok"]),
        "items": items,
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="交付包自证链自检")
    ap.add_argument("--out", required=True, help="交付包根目录（含 manifest.json）")
    ap.add_argument("--json", default="", help="把结构化结论写成 JSON（落到包校验报告）")
    ap.add_argument("--extra-doc", action="append", default=[],
                    metavar="PATH",
                    help="包外文档（可重复）：发布仓库根 README 等，按同一条"
                         "「ZIP 字节数必须等于实际文件」规则检查")
    a = ap.parse_args(argv)
    if a.json:
        rep = report(Path(a.out))
        Path(a.json).write_text(
            json.dumps({"selfcheck": rep}, ensure_ascii=False, indent=2),
            encoding="utf-8")
        print(f"自检结论已写出：{a.json}（passed={rep['passed']}，"
              f"{rep['n_failed']} 项失败）")
        return 0 if rep["passed"] else 1
    bad = check(Path(a.out), a.extra_doc)
    if bad:
        print(f"自证链不一致 {len(bad)} 项：", file=sys.stderr)
        for line in bad[:50]:
            print(f"  - {line}", file=sys.stderr)
        return 1
    print(f"自证链自检通过：{a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
