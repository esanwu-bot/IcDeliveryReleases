"""docstrange（Nanonets）云端 PDF -> Markdown：适配新版 /api/v1 端点。

背景：旧端点 `POST /extract` 已废弃（返回 429
`{"detail":"The /extract endpoint is deprecated. Please migrate to /api/v1/extract."}`），
docstrange 1.1.8 客户端仍硬编码旧端点，故这里直接对接新契约：
  POST /api/v1/extract/async   multipart: file + output_format=markdown -> record_id
  GET  /api/v1/extract/results/{record_id}                  -> result.markdown.content
  （/sync 端点仅支持 ≤5 页，datasheet 一律走 async）

凭据优先级：NANONETS_API_KEY 环境变量 > ~/.docstrange/credentials.json 的 access_token
（后者由 `docstrange login` 浏览器授权生成，首次需人工确认；默认 24h 过期）。

云端安全边界（必读）：
  * 上传会把 PDF **全文**发到第三方服务器 → 默认**关闭**，需显式开启：
      环境变量 ICPDF_DS_CLOUD=1   或   CLI `--allow-cloud`
  * 来源白名单：qc/pdfs、data/pdfs、data/datasets（可用 ICPDF_DS_ALLOW_DIRS 追加，
    分号分隔）；uploads/ 与含 customer|private|客户|内部 等标记的路径**一律拒绝**。
  * parse_datasheets.py 显式选择 `--pdf-backend docstrange` 即视为确认上云（自动置开
    关），但来源白名单与敏感路径检查同样生效。

计量：成功时向 stderr 打一行 `[ds-metric] {json}`
（pages/chars/proc_s/wall_s），供 A/B 实验分账：云端转换成本 ≠ 下游 LLM 成本。

用法：python qc/ds_cloud.py <pdf> <out.md> [--timeout=N] [--allow-cloud] [--dry-run]
退出码：0 成功 / 1 失败（原因写 stderr，供 parse_datasheets.ds_convert 汇总）
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

BASE = "https://extraction-api.nanonets.com"
ROOT = Path(__file__).resolve().parent.parent

# 只允许公开原厂 datasheet 样本目录上云
SAFE_DIRS = (ROOT / "qc" / "pdfs", ROOT / "data" / "pdfs", ROOT / "data" / "datasets")
# 路径命中即拒绝：客户/私有/内部文档不允许出网
DENY_MARKERS = ("upload", "customer", "private", "confidential", "客户", "内部")


def _cred_path() -> Path:
    env = os.environ.get("ICPDF_DS_CRED", "").strip()
    return Path(env) if env else Path(os.path.expanduser("~")) / ".docstrange" / "credentials.json"


def _under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def cloud_allowed() -> bool:
    return os.environ.get("ICPDF_DS_CLOUD", "").strip().lower() in ("1", "true", "yes", "on")


def check_source(pdf: Path) -> Path:
    """云端来源校验：开关 → 文件存在 → 白名单 → 敏感路径。返回 resolve 后的路径。"""
    if not cloud_allowed():
        raise SystemExit("云端开关未开启：设置 ICPDF_DS_CLOUD=1 或加 --allow-cloud"
                         "（docstrange 会把 PDF 全文上传第三方服务器）")
    rp = pdf.resolve()
    if not rp.is_file():
        raise SystemExit(f"文件不存在：{rp}")
    extra = [Path(x.strip()) for x in os.environ.get("ICPDF_DS_ALLOW_DIRS", "").split(";")
             if x.strip()]
    if not any(_under(rp, d) for d in SAFE_DIRS + tuple(extra)):
        raise SystemExit(f"拒绝上传：{rp} 不在公开样本目录白名单"
                         f"（{', '.join(str(d) for d in SAFE_DIRS)}；"
                         f"可用 ICPDF_DS_ALLOW_DIRS 追加）")
    low = str(rp).lower()
    for m in DENY_MARKERS:
        if m in low:
            raise SystemExit(f"拒绝上传：路径含敏感标记「{m}」→ {rp}")
    return rp


def _token() -> str:
    tok = os.environ.get("NANONETS_API_KEY", "").strip()
    if tok:
        return tok
    cred = _cred_path()
    if cred.exists():
        rec = json.loads(cred.read_text(encoding="utf-8"))
        tok = (rec.get("access_token") or "").strip()
        exp = float(rec.get("expires_at") or 0)
        if tok and exp and time.time() >= exp:
            raise SystemExit("凭据已过期：请重新执行 `docstrange login`")
        if tok:
            return tok
    raise SystemExit("未认证：先跑 `docstrange login`（浏览器授权）或设置 NANONETS_API_KEY")


def convert(pdf: Path, out: Path, timeout: int = 2400, dry_run: bool = False) -> None:
    rp = check_source(pdf)
    if dry_run:
        print(f"[ds] dry-run 将通过云端转换：{rp.name} -> {out}（未上传、未计费）",
              file=sys.stderr)
        return

    import requests

    hdr = {"Authorization": f"Bearer {_token()}"}
    t0 = time.time()
    with rp.open("rb") as f:
        r = requests.post(f"{BASE}/api/v1/extract/async", headers=hdr,
                          files={"file": (rp.name, f, "application/pdf")},
                          data={"output_format": "markdown"}, timeout=300)
    if r.status_code not in (200, 202):
        raise SystemExit(f"submit HTTP {r.status_code}: {r.text[:300]}")
    job = r.json()
    rid = job.get("record_id")
    print(f"[ds] {rp.name} record_id={rid}", file=sys.stderr)

    delay, deadline = 5, time.time() + timeout
    while time.time() < deadline:
        time.sleep(delay)
        rr = requests.get(f"{BASE}/api/v1/extract/results/{rid}", headers=hdr, timeout=120)
        if rr.status_code != 200:
            raise SystemExit(f"poll HTTP {rr.status_code}: {rr.text[:300]}")
        data = rr.json()
        status = (data.get("status") or "").lower()
        if status in ("completed", "success", "done", "finished"):
            md_obj = (data.get("result") or {}).get("markdown") or {}
            md = md_obj.get("content") if isinstance(md_obj, dict) else None
            if not isinstance(md, str) or not md.strip():
                raise SystemExit(f"空 markdown（keys={list(md_obj)[:6]}）")
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(md, encoding="utf-8")
            metric = {"mpn": rp.stem, "pages": data.get("pages_processed"),
                      "chars": len(md), "proc_s": data.get("processing_time"),
                      "wall_s": round(time.time() - t0, 1)}
            print(f"[ds] ok {rp.name} chars={len(md)} pages={metric['pages']} "
                  f"proc_s={metric['proc_s']} wall_s={metric['wall_s']}", file=sys.stderr)
            print("[ds-metric] " + json.dumps(metric, ensure_ascii=False), file=sys.stderr)
            return
        if status in ("failed", "error", "cancelled"):
            raise SystemExit(f"job {status}: {str(data.get('message'))[:300]}")
        delay = min(delay + 5, 20)
    raise SystemExit(f"轮询超时（{timeout}s）：record_id={rid}")


def main() -> int:
    argv = sys.argv[1:]
    if "--allow-cloud" in argv:
        os.environ["ICPDF_DS_CLOUD"] = "1"
    dry_run = "--dry-run" in argv
    timeout = 2400
    for a in argv:
        if a.startswith("--timeout="):
            timeout = int(a.split("=", 1)[1])
    pos = [a for a in argv if not a.startswith("--")]
    if len(pos) != 2:
        print("用法：python qc/ds_cloud.py <pdf> <out.md> "
              "[--timeout=N] [--allow-cloud] [--dry-run]", file=sys.stderr)
        return 2
    convert(Path(pos[0]), Path(pos[1]), timeout, dry_run)
    return 0


if __name__ == "__main__":
    sys.exit(main())
