"""身份回放结果 → 人工复核分桶（对应 docs/20261030人工修规则操作说明.md §5）。

为什么要有这个文件
------------------
分桶逻辑上一轮是临时脚本，跑完就删了 —— 结果「那张 110 件的复核表怎么来的」
无从复现。规则改一次、回放重跑一次，就得重新手工拼一遍 CSV。
这里把它固定成 CLI，**表结构与 `apply_manual_review.py` 读的列严格对齐**，
避免再出现「人填了 7 列、脚本读 3 列、读完 0 件还 exit 0」那次事故。

四个桶（顺序即人工处理优先级）
------------------------------
    A 漏网板卡   判 chip/PASS，但料号带板卡后缀形态   -> 规则漏了，必须重判
    B 后缀拦截   板卡后缀命中但缺原厂证据（REVIEW）    -> 人工逐条看 PDF（主战场）
    C 回退误判   芯片结论其实是同族回退推出来的 + 带后缀 -> 同族回退越权
    D 后缀误伤   板卡结论来自低置信 token（DK/EB）     -> 可能是芯片被误判成套件

A/C/D 都应该趋近 0；**B 是设计上就该阻断的**，不是缺陷。
"""
from __future__ import annotations

import argparse
import csv
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 低置信 token 规则：`DK`/`EB` 在芯片订货号里也是合法写法（EB 是封装代号、
# DK6 是 C2000 封装代字），所以「命中这两条规则」本身不构成结论，必须人工抽检。
# 反过来，EVM/EVK/EMK/EVAL/BOOST/KIT 这些长 token 不可能出现在裸芯片订货号里。
_LOW_CONF_RULE_IDS = frozenset({
    "GENERIC_BOARD_SUFFIX_DK",
    "TI_BOARD_SUFFIX_EB",
})

# 高置信板卡 token（出现在芯片订货号里的概率可忽略）
_HIGH_TOKEN_RE = re.compile(
    r"(?:EVM|EVK|EMK|EVAL|EVB|BOOST|KIT|PDK|DONGLE)(?=$|[-_/ \d])", re.I)

BUCKET_A = "A_漏网板卡"
BUCKET_B = "B_REVIEW拦截"
BUCKET_C = "C_回退误判"
BUCKET_D = "D_低置信后缀待确认"

_ORDER = {BUCKET_A: 0, BUCKET_C: 1, BUCKET_D: 2, BUCKET_B: 3}

# 与 apply_manual_review.py 的读取列一一对应；proposed_* 留空由人填
COLUMNS = [
    "桶类别", "file", "mpn", "manufacturer", "current_state", "current_identity",
    "current_rule_id", "proposed_action", "proposed_identity", "evidence",
    "pdf_hint", "reviewer", "review_time", "notes",
]

LEGAL_ACTIONS = ("BOARD_CONFIRMED", "chip", "identity_review")


def _pdf_hint(mpn: str, pdf_dir: Path) -> str:
    """本地 PDF 路径（`MPN__slug.pdf` 双下划线命名）。找不到返回空串，不猜。"""
    if not pdf_dir.is_dir():
        return ""
    want = mpn.upper()
    alias = re.sub(r"[^A-Za-z0-9]+", "_", mpn).strip("_").upper()
    for p in pdf_dir.iterdir():
        u = p.name.upper()
        if u.startswith(want + "__") or u.startswith(alias + "__"):
            return str(p).replace("\\", "/")
    return ""


def bucket_of(row: dict) -> str:
    """单行归桶。判定只用回放 CSV 里已有的列，不重新 classify（保证可复现）。

    三条容易踩的假阳性（都实测过）：
    * `EB` 是芯片封装代号 —— `DAC081C08XEB`、`ADS8320EB/250` 是芯片，不是漏网板卡；
    * `PDK` 里含 `DK` —— `ADS1246EVM-PDK` 是板卡，不能因为"含 DK"进误伤桶；
    * 规则命中但被判成芯片（EB 的 `when_orderable=chip`）不是漏网，是设计如此。
    所以 A/C 只在「**高置信 token 存在、但规则压根没命中**」时成立。
    """
    state = (row.get("state") or "").strip()
    identity = (row.get("identity") or "").strip()
    verdict = (row.get("verdict") or "").strip()
    rule_id = (row.get("rule_id") or "").strip()
    mpn = (row.get("mpn") or "").strip()
    same_family = (row.get("same_family_n") or "0").strip() or "0"

    if state == "IDENTITY_REVIEW":
        return BUCKET_B

    if identity == "chip" and verdict == "PASS":
        # 规则没命中 + 料号里有不可能的芯片 token -> 规则漏网
        if not rule_id and _HIGH_TOKEN_RE.search(mpn):
            return BUCKET_C if same_family not in ("", "0") else BUCKET_A
        return ""

    # 板卡结论建立在低置信 token 上 -> 需人工抽检（可能误伤芯片）
    if identity in ("evaluation_board", "development_kit") and rule_id in _LOW_CONF_RULE_IDS:
        return BUCKET_D

    return ""


def _registry_board_mpns() -> dict[str, str]:
    """规则注册表里已登记为板卡用例的 MPN（`expected=BOARD*`）。

    「这件已经人工核过了」不能只存在于某个人的记忆或一次性脚本里，
    所以 D 桶的预填只认注册表里的 test_case —— 有据可查、可回归。
    """
    import json
    path = Path(__file__).resolve().parent / "mpn_identity_rules.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, str] = {}
    for r in data.get("rules") or []:
        for c in (r.get("test_cases") or []):
            exp = str(c.get("expected") or "").upper()
            mpn = str(c.get("mpn") or "").strip()
            if mpn and exp in ("BOARD", "BOARD_CONFIRMED"):
                out[mpn] = str(c.get("evidence") or "").strip()
    return out


def build(replay_csv: Path, out_csv: Path, pdf_dir: Path,
          preset: dict[str, tuple[str, str, str]] | None = None) -> dict:
    """读回放 → 写复核表。只输出 A/B/C/D 四桶，其余（SUPPORTED 芯片等）不进表。"""
    rows = list(csv.DictReader(open(replay_csv, encoding="utf-8-sig")))
    preset = dict(preset or {})
    registered = _registry_board_mpns()
    out = []
    for r in rows:
        b = bucket_of(r)
        if not b:
            continue
        mpn = (r.get("mpn") or "").strip()
        # D 桶若已在注册表登记为板卡用例，就预填成"签字即可"，不再占人工判断
        if b == BUCKET_D and mpn in registered and mpn not in preset:
            preset[mpn] = ("BOARD_CONFIRMED", (r.get("identity") or "").strip(),
                           "规则注册表已登记为 BOARD 用例：" + registered[mpn][:120])
        act, ident, note = preset.get(mpn, ("", "", ""))
        out.append({
            "桶类别": b,
            "file": (r.get("file") or "").strip(),
            "mpn": mpn,
            "manufacturer": (r.get("manufacturer") or "").strip(),
            "current_state": (r.get("state") or "").strip(),
            "current_identity": (r.get("identity") or "").strip(),
            "current_rule_id": (r.get("rule_id") or "").strip(),
            "proposed_action": act,
            "proposed_identity": ident,
            "evidence": (r.get("evidence") or "").strip(),
            "pdf_hint": _pdf_hint(mpn, pdf_dir),
            "reviewer": "",
            "review_time": "",
            "notes": note,
        })

    out.sort(key=lambda x: (_ORDER.get(x["桶类别"], 9),
                            x["current_rule_id"], x["mpn"]))

    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(out)

    return {
        "总行数": len(rows),
        "入表件数": len(out),
        "分桶": dict(Counter(x["桶类别"] for x in out)),
        "有PDF": sum(1 for x in out if x["pdf_hint"]),
        "已预填": sum(1 for x in out if x["proposed_action"]),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="身份回放 → 人工复核分桶表")
    ap.add_argument("--replay", default="data/identity_replay_20261030.csv")
    ap.add_argument("--out", default="data/manual_review_20261030.csv")
    ap.add_argument("--pdf-dir", default="data/pdfs")
    args = ap.parse_args(argv)

    replay, out = Path(args.replay), Path(args.out)
    if not replay.exists():
        print(f"找不到回放文件：{replay}")
        return 2

    stat = build(replay, out, Path(args.pdf_dir))
    print(f"回放 {stat['总行数']} 件 → 入表 {stat['入表件数']} 件 → {out}")
    for k in (BUCKET_A, BUCKET_C, BUCKET_D, BUCKET_B):
        print(f"  {k:14} {stat['分桶'].get(k, 0):4}")
    print(f"  有 PDF 定位 {stat['有PDF']} / 已预填 {stat['已预填']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
