"""电气参数损失诊断：把逐件损失关联到「选页 → 预算 → 提取 → JSON」的哪个阶段。

为什么要这个脚本
----------------
重解析批次把订货行补上了，但电气参数总量净减 817 条。净减只是一个警报，
不是根因结论：损失可能来自
  (1) 页筛选把电气特性页挤出去；
  (2) 字符预算被订货表页吃满导致电气页落选；
  (3) 页选上了但表格提取失败；
  (4) 下游字段过滤/合并覆盖；
  (5) 根本不是损失，只是重复条目被去重或单位写法变了。

所以本脚本对每一件同时做两件事：
  A. 复现旧选页（前 max_pages 页 + KEY_PAGES 关键词 + 超预算 break + 硬截断）
     与新选页（select_pages：前 3 页 + 分档配额 + 整页取舍），
     统计「电气候选页有几页入选」的前后变化 —— 这是页筛选假设的直接证据。
  B. JSON 侧按 (名称, 条件, 单位) 去重后比较参数签名集合，
     区分「真实损失 / 新增 / 重复条目变化 / 单位写法变化」，
     避免把格式差异当成参数丢失。

只读：不写 parsed / backup / 数据库，只写 --out 指定的 CSV。

用法（容器内）
--------------
    python qc/diagnose_elec_loss.py --mpns-file /tmp/all228.txt \
        --out /tmp/elec_loss.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                              # noqa: E402
from qc.reparse_ordering import _safe                      # noqa: E402

MAX_PAGES, MAX_CHARS = PD.MAX_PAGES, PD.MAX_CHARS

# 旧实现的关键词表（49e4c93 版本）
OLD_KEY_PAGES = (
    "electrical characteristics", "absolute maximum", "recommended operating",
    "pin configuration", "pin functions", "terminal functions",
    "ordering information", "package option addendum", "device comparison",
    "specifications", "features",
)

# 电气特性页判定关键词：比 PAGE_PRIORITY 第 3 档更全，便于算「候选页」
ELEC_KEYS = (
    "electrical characteristics", "absolute maximum", "recommended operating",
    "switching characteristics", "dc characteristics", "ac characteristics",
    "timing requirements", "thermal information", "esd ratings",
)


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


# ---------------------------------------------------------------- 旧选页复现
def old_select(pages, max_pages=MAX_PAGES, max_chars=MAX_CHARS):
    """复现 49e4c93 的 extract_pdf_text 选页逻辑（含硬截断）。"""
    buf, used, truncated = [], 0, False
    for i, text in pages:
        if i >= max_pages:
            break
        if not text.strip():
            continue
        if i < 3 or any(k in text.lower() for k in OLD_KEY_PAGES):
            buf.append((i, text))
            used += 1
            if sum(len(b) for b in (f"\n--- Page {j+1} ---\n{t}" for j, t in buf)) > max_chars:
                truncated = True
                break
    return buf, truncated


# ---------------------------------------------------------------- 新选页（带分档统计）
def new_select(pages, max_pages=MAX_PAGES, max_chars=MAX_CHARS):
    """复现当前 select_pages，并返回每页的档位与分档字符占用。"""
    head, ranked = [], []
    for i, text in pages:
        if i >= PD.PAGE_SCAN_CAP:
            break
        if not text.strip():
            continue
        if i < 3:
            head.append((0, i, text))
            continue
        low = text.lower()
        rank = len(PD.PAGE_PRIORITY) + 1
        for n, keys in enumerate(PD.PAGE_PRIORITY, start=1):
            if any(k in low for k in keys):
                rank = n
                break
        ranked.append((rank, i, text))

    chosen, chars = [], 0
    taken: dict[int, int] = {}
    dropped = False
    rank_chars: dict[int, int] = {}
    for rank, i, text in head + sorted(ranked, key=lambda x: (x[0], x[1])):
        quota = PD.RANK_QUOTA[rank - 1] if 1 <= rank <= len(PD.RANK_QUOTA) else 99
        if taken.get(rank, 0) >= quota:
            continue
        if len(chosen) >= max_pages or chars + len(text) > max_chars:
            dropped = True
            continue
        chosen.append((i, text, rank))
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)
        rank_chars[rank] = rank_chars.get(rank, 0) + len(text)
    return sorted(chosen), dropped, rank_chars, chars


def _elec_sig(e: dict) -> tuple:
    """参数签名：名称 + 条件 + 单位（不含 value，避免数值写法差异被当成不同参数）。"""
    g = lambda k: str((e or {}).get(k) or "").strip().lower()
    return (g("name"), g("condition"), g("unit"))


def _keys(doc: dict) -> str:
    ks = set()
    for e in ((doc.get("specs") or {}).get("electrical") or []):
        if isinstance(e, dict):
            ks.update(e.keys())
    return "|".join(sorted(ks)) or "-"


def _n_order(doc: dict) -> int:
    return len(doc.get("ordering_info") or [])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="电气参数损失逐件诊断（只读）")
    ap.add_argument("--mpns-file", default="")
    ap.add_argument("--mpn", action="append", default=[])
    ap.add_argument("--data-dir", default=str(ROOT / "data" / "parsed"), dest="data_dir")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--pdfs", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--db", default=str(ROOT / "data" / "workbench.sqlite3"))
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)

    data_dir, backup, pdfs = Path(a.data_dir), Path(a.backup), Path(a.pdfs)
    mpns = list(a.mpn)
    if a.mpns_file and Path(a.mpns_file).exists():
        mpns += [x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()]
    mpns = list(dict.fromkeys(mpns))
    if not mpns:
        print("没有指定 MPN")
        return 2

    db = sqlite3.connect(a.db) if Path(a.db).exists() else None
    cur_index = {p.name: p for p in data_dir.glob("*.json")}
    bak_index = {p.name: p for p in backup.glob("*.json")}
    print("诊断 %d 件（MAX_PAGES=%d MAX_CHARS=%d）" % (len(mpns), MAX_PAGES, MAX_CHARS))

    rows = []
    for k, mpn in enumerate(mpns, 1):
        key = _safe(mpn)
        # ---- 定位 PDF：优先数据库 pdf_path，其次前缀兜底 ----
        pdf = None
        if db:
            r = db.execute("SELECT pdf_path FROM item WHERE mpn=?", (mpn,)).fetchone()
            if r and r[0]:
                cand = pdfs / Path(r[0].replace("\\", "/")).name
                if cand.exists():
                    pdf = cand
        if pdf is None:
            hits = sorted(pdfs.glob(key + "*.pdf"))
            pdf = hits[0] if hits else None
        if pdf is None:
            rows.append({"mpn": mpn, "err": "无 PDF"})
            continue

        # ---- 定位新旧 JSON ----
        db_json = ""
        if db:
            r = db.execute("SELECT json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
            if r and r[0]:
                db_json = Path(r[0].replace("\\", "/")).name
        fname = db_json if db_json in cur_index else ""
        if not fname:
            c = sorted(n for n in cur_index if n.startswith(key + "_"))
            fname = c[0] if c else ""
        new_doc = _load(cur_index[fname]) if fname in cur_index else {}
        old_doc = _load(bak_index[fname]) if fname in bak_index else {}

        # ---- 读页 ----
        try:
            import fitz
            with fitz.open(str(pdf)) as doc:
                total = doc.page_count
                pages = [(i, doc[i].get_text("text") or "") for i in range(total)]
        except Exception as e:                                   # noqa: BLE001
            rows.append({"mpn": mpn, "err": "读 PDF 失败 %s" % type(e).__name__})
            continue

        o_sel, o_trunc = old_select(pages)
        n_sel, n_dropped, rank_chars, n_chars = new_select(pages)
        o_pages = [i + 1 for i, _ in o_sel]
        n_pages = [i + 1 for i, _, _ in n_sel]

        # 电气候选页与入选数
        elec_cand = [i + 1 for i, t in pages
                     if i < PD.PAGE_SCAN_CAP and any(x in t.lower() for x in ELEC_KEYS)]
        o_e = [p for p in o_pages if p in elec_cand]
        n_e = [p for p in n_pages if p in elec_cand]

        # ---- JSON 侧去重比较 ----
        def sigs(doc):
            out = {}
            for e in ((doc.get("specs") or {}).get("electrical") or []):
                if isinstance(e, dict):
                    s = _elec_sig(e)
                    if s[0]:
                        out[s] = out.get(s, 0) + 1
            return out

        o_s, n_s = sigs(old_doc), sigs(new_doc)
        lost = sorted(set(o_s) - set(n_s))
        gain = sorted(set(n_s) - set(o_s))
        o_raw = len((old_doc.get("specs") or {}).get("electrical") or [])
        n_raw = len((new_doc.get("specs") or {}).get("electrical") or [])

        # ---- 损失归因 ----
        cause = []
        if not lost:
            cause.append("无签名级损失")
        else:
            if len(n_e) < len(o_e):
                cause.append("电气页落选 %d->%d" % (len(o_e), len(n_e)))
            if n_dropped:
                cause.append("新选页触发预算裁剪")
            if len(n_e) >= len(o_e) and not n_dropped:
                cause.append("电气页仍入选，损失在下游")
            if o_trunc and not n_dropped:
                cause.append("旧版硬截断")
        if PD.is_datasheet("".join(t for _, t in o_sel)) and not PD.is_datasheet(
                "".join(t for _, t, _ in n_sel)):
            cause.append("新选页 is_datasheet 判定翻转")

        rows.append({
            "mpn": mpn,
            "pdf": pdf.name, "pdf_sha256": _sha(pdf)[:16],
            "json_file": fname, "has_backup": "是" if fname in bak_index else "否",
            "order_old": _n_order(old_doc), "order_new": _n_order(new_doc),
            "elec_raw_old": o_raw, "elec_raw_new": n_raw,
            "elec_uniq_old": len(o_s), "elec_uniq_new": len(n_s),
            "elec_lost": len(lost), "elec_gain": len(gain),
            "elec_dup_old": o_raw - len(o_s), "elec_dup_new": n_raw - len(n_s),
            "keys_old": _keys(old_doc), "keys_new": _keys(new_doc),
            "lost_sample": " ; ".join("|".join(s) for s in lost[:5]),
            "gain_sample": " ; ".join("|".join(s) for s in gain[:3]),
            "pages_total": total,
            "old_pages": ",".join(map(str, o_pages[:15])),
            "new_pages": ",".join(map(str, n_pages[:15])),
            "elec_cand_n": len(elec_cand),
            "elec_cand_pages": ",".join(map(str, elec_cand[:12])),
            "elec_sel_old": len(o_e), "elec_sel_new": len(n_e),
            "elec_sel_old_pages": ",".join(map(str, o_e[:8])),
            "elec_sel_new_pages": ",".join(map(str, n_e[:8])),
            "new_chars": n_chars, "max_chars": MAX_CHARS,
            "new_dropped": "是" if n_dropped else "否",
            "rank1_chars": rank_chars.get(1, 0), "rank2_chars": rank_chars.get(2, 0),
            "rank3_chars": rank_chars.get(3, 0),
            "old_truncated": "是" if o_trunc else "否",
            "is_ds_old": PD.is_datasheet("".join(t for _, t in o_sel)),
            "is_ds_new": PD.is_datasheet("".join(t for _, t, _ in n_sel)),
            "cause": "，".join(cause),
        })
        if k % 40 == 0:
            print("  已诊断 %d/%d" % (k, len(mpns)), flush=True)

    rows = [r for r in rows if "err" not in r or not r.get("err")]
    # ---- 汇总 ----
    tot_lost = sum(r.get("elec_lost", 0) for r in rows)
    tot_gain = sum(r.get("elec_gain", 0) for r in rows)
    raw_o = sum(r.get("elec_raw_old", 0) for r in rows)
    raw_n = sum(r.get("elec_raw_new", 0) for r in rows)
    uniq_o = sum(r.get("elec_uniq_old", 0) for r in rows)
    uniq_n = sum(r.get("elec_uniq_new", 0) for r in rows)
    print("\n=== 电气参数损失汇总（%d 件）===" % len(rows))
    print("原始条数 %d -> %d（净 %+d）" % (raw_o, raw_n, raw_n - raw_o))
    print("去重签名 %d -> %d（净 %+d）" % (uniq_o, uniq_n, uniq_n - uniq_o))
    print("签名级：丢失 %d 条 / 新增 %d 条" % (tot_lost, tot_gain))
    print("重复条目：旧 %d 条 / 新 %d 条" % (
        sum(r.get("elec_dup_old", 0) for r in rows),
        sum(r.get("elec_dup_new", 0) for r in rows)))

    from collections import Counter
    cc = Counter()
    for r in rows:
        if r.get("elec_lost", 0) <= 0:
            cc["无损失"] += 1
            continue
        if "电气页落选" in r["cause"]:
            cc["电气页落选"] += 1
        if "预算裁剪" in r["cause"]:
            cc["预算裁剪"] += 1
        if "损失在下游" in r["cause"]:
            cc["页入选但下游丢失"] += 1
    print("\n归因分布（同一件可命中多项）：")
    for k, v in cc.most_common():
        print("   %-16s %d 件" % (k, v))

    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        cols = list(rows[0].keys())
        with out.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        print("\n明细已写 %s（%d 行）" % (out, len(rows)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
