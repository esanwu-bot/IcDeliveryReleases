"""finding kind / code 的单一事实源。

背景
----
线路 A 内部**不止两套**规则引擎（AGENT.md 第 5 节只记了两套），实际是
三套规则引擎 + 一套 LLM 词表，各自命名互不相通：

| 来源 | 产出字段 | 命名 | 谁在用 |
|---|---|---|---|
| ``app/services/review.py::_rule_checks`` | ``kind`` | 小写 snake_case | 自动修复闭环 ``review_item`` → ``fix_dispatch`` |
| ``qc/auto_qc.py`` r1–r4 | ``code`` | 大写 | 批量 QC / ``qc_regression`` |
| ``qc/table_audit.py`` | ``kind`` | 小写 snake_case | ``qc_regression`` / diff 归因 |
| ``review.RULES_TEXT``（LLM 提示词） | ``kind`` | 小写 snake_case | 模型自由产出，**无枚举约束** |

四者共享同一批缺陷语义，但没有单一注册表。步 5b 的教训是：在 ``auto_qc`` 里加
``ELECTRICAL_LIKE_FEATURE`` 对自动修复闭环**完全无效**，因为 ``fix_dispatch``
只认 review 的 ``kind``（AGENT.md §5）。

本模块只做三件事，**不改任何引擎行为**：

1. 登记每个来源各自产出的名字（集合 + 模式）；
2. ``normalize()`` 把跨来源写法归一为 canonical；
3. ``check_known()`` 供测试抓「新加规则忘了注册」。

注册表内容**由磁盘源码 AST 盘点生成**（``qc/finding_kinds_audit.py``），
不是凭记录整理。``tests/test_finding_kinds.py`` 会重扫源码比对，
未注册的名字直接 FAIL——这是显式失败，不是运行时静默退化。

import 零 stdout（server 进程安全，AGENT.md §4）。
"""
from __future__ import annotations

import re
import warnings

# ─────────────────────────────────────────────────────────────────────
# 1. 四个来源各自的名字
# ─────────────────────────────────────────────────────────────────────

#: ``app/services/review.py::_rule_checks`` 及其子规则产出的 kind（21 个）
REVIEW_KINDS: frozenset[str] = frozenset({
    # 身份 / 封装（规则 1–2）
    "identity_conflict",
    "identity_review",
    "identity_evidence_incomplete",
    "board_confirmed_unmarked",
    "board_package_mismatch",
    "board_identity_missing",
    "mpn_rewritten",
    # 渲染 / 转义（规则 3）
    "escape_entity_in_json",
    "double_escape_multi",
    # 电气表（规则 4 / 4b / 5）
    "electrical_field_missing",
    "electrical_like_feature",
    "unit_duplicated",
    # 引脚（规则 6）
    "pin_pair_broken",
    "pin_polarity_missing",
    # 多语言（规则 7 / 9）
    "i18n_english_residue",
    "i18n_body_untranslated",
    # 文案（规则 8 / 9）
    "hero_overview_duplicate",
    "sentinel_leaked_to_copy",
    # 替代料 / SEO（规则 9）
    "alts_json_has_miss",
    "alts_no_internal_link",
    "seo_shared_icon_unmarked",
    "pin_count_mismatch",
})

#: ``qc/engineering_model.py::check`` 产出的 kind（5 个，符号页 A1–A5）。
#: 单独成来源：这些字面量不在 `review.py` 里，混进 REVIEW_KINDS 会让
#: 「源码扫描 ⊆ 注册表」永远报 stale（注册表写着 review 有、review 源码里没有）。
ENGINEERING_KINDS: frozenset[str] = frozenset({
    # A1 页面有几何数值，但轮廓非模板、3D 未生成
    "symbol_page_geometry_unsupported",
    # A2 状态说没生成，页面却画了 3D / 球阵几何
    "symbol_page_3d_node_without_state",
    # A3 轮廓状态是 template，页面仍印「未核验」
    "symbol_page_outline_text_conflict",
    # A4 板卡身份 / 板卡页与 not_applicable 状态不一致
    "symbol_page_board_state_mismatch",
    # A5「工程模型边界」小节与 render_notes(state) 不一致
    "symbol_page_boundary_text_drift",
})

#: ``qc/auto_qc.py`` r1–r4 产出的 code（29 个字面量）
AUTO_QC_CODES: frozenset[str] = frozenset({
    # r1 身份与来源
    "PDF_MISSING",
    "PDF_MAGIC",
    "PDF_SHA_MISMATCH",
    "PDF_SHA_MISSING",
    "JSON_MISSING",
    "JSON_PARSE",
    "MPN_MISSING",
    "MPN_MISMATCH",
    "MPN_FAMILY_INHERITED",
    "BRAND_MISSING",
    "PDF_PROBE_ERROR",
    "PDF_TEXT_MPN_NOT_FOUND",
    # r2 结构与产物
    "SPECS_MISSING",
    "ELECTRICAL_EMPTY",
    "PACKAGE_TYPE_MISSING",
    "PACKAGE_PINS_MISSING",
    "PIN_CONFIG_EMPTY",
    "PIN_COUNT_MISMATCH",
    "MULTILANG_IN_JSON_MISSING",
    "SEO_IN_JSON_EMPTY",
    # r3 字段语义
    "UNIT_MISSING",
    "ELECTRICAL_ROW_BAD",
    "ELECTRICAL_NOT_SPECIFIED",
    "ELECTRICAL_LIKE_FEATURE",
    "TXT_MPN_MISSING",
    "SYMBOL_EMPTY",
    # r4 facts vs Gold
    "GOLD_FIELD_MISSING",
    "GOLD_FIELD_MISMATCH",
    "GOLD_NOT_APPLICABLE",
})

#: ``qc/auto_qc.py`` 里由 ``"..." % var`` 拼出来的 code（无法静态枚举，
#: 用模式登记；``_add()`` 第 4 个位置参数）。
AUTO_QC_CODE_PATTERNS: tuple[str, ...] = (
    r"^ART_[A-Z_]+_MISSING$",        # ART_TXT_MISSING / ART_SEO_MISSING /
                                     # ART_SYMBOL_MISSING / ART_ALT_JSON_MISSING /
                                     # ART_ALT_HTML_MISSING
    r"^LANG_[A-Z]{2}_MISSING$",      # LANG_JA_MISSING … LANG_ES_MISSING
    r"^LANG_MPN_MISSING_[A-Z]{2}$",  # LANG_MPN_MISSING_JA …
    r"^JSON_BAD_[A-Z_]+$",           # JSON_BAD_SEO / JSON_BAD_ALT_JSON
)
_AUTO_QC_RE = tuple(re.compile(p) for p in AUTO_QC_CODE_PATTERNS)

#: ``qc/table_audit.py::finding(path, kind, ...)`` 产出的 kind（25 个）
TABLE_AUDIT_KINDS: frozenset[str] = frozenset({
    "range_collapse",
    # 2026-11-03 外审 V1（ALG-A22 / Issue #14 #15 #23）：多封装表里只取第一列。
    # 与 `fused_column_blocking` 同级阻断 —— 都是「列语义丢了」：
    # 值与哪一列/哪个封装对应没有证据，裸数字不能进交付。
    "column_collapse",
    # ADAPT A12：写盘前「干净单值」闸门拦下的条目（格子是公式 / 两格并一格 / 范围格）。
    # 与 to_num 的诊断用途区分开：诊断可以捞第一个数，写盘不行。
    "cell_unparsable_unresolved",
    # 2026-10-31：关键参数（电压/温度/分辨率/电流/功率…）的 MIN/NOM/MAX 列融合，
    # 角色根本读不出 → **阻断**，不进 patched 桶，该件不得进 ok 列表。
    # 取证：ADC12DJ5200SE p10 ROC 表 18 行全部走这条路，旧逻辑只记 unresolved，
    # 闸门全程零判定，VCMI 丢掉 MIN 写成 "0.3 to 0.55" 照样出包。
    "fused_column_blocking",
    "qualifier_loss",
    "row_mispair",
    "row_missing",
    "row_ambiguous_unresolved",
    # ADAPT D1g：匹配到了行、行内有干净数值，但本条 value 不在该行任何列值里。
    # ADS1201 的模拟输入上限错误就是这种「matched 但静默放行」形态。
    "value_unsupported_unresolved",
    "unit_dimension",
    "unit_dimension_unresolved",
    "condition_leak",
    "footnote_missing",
    "table_unresolved",
    # ADAPT A18：表标题里的型号与本品同族但不是本品（如 PDF 里并列
    # `for CY74FCT16245T` 与 `for CY74FCT162H245T` 两张同构表），
    # 且只有外族表有候选行 —— 不猜该用哪张，交人工。
    "table_foreign_part_unresolved",
    "option_conflation",
    "identity_unverified",
    "identity_family",
    # 身份修正未传播：旧家族号仍留在 SEO/替代料/温区等下游字段
    "identity_stale_unresolved",
    "package_mismatch",
    # 封装名是板卡形态（Evaluation Board），身份却不是板卡 —— scope 归属冲突
    "package_scope_unresolved",
    "pin_table_unresolved",
    "pin_mismatch",
    "direction_reversal",
    "pin_gap",
})

#: ``review.RULES_TEXT`` 里给模型枚举的「尽量复用」kind（15 个）。
#: 注意：这是**建议词表**，模型实际可能产出任意 snake_case——因此
#: ``check_known`` 对 llm 引擎只做提示，不参与严格闸门。
LLM_KINDS: frozenset[str] = frozenset({
    "identity_board_unresolved",
    "board_package_mismatch",
    "pin_mismatch",
    "pin_pair_broken",
    "electrical_condition_leak",
    "unit_dimension",
    "i18n_english_residue",
    "hero_overview_duplicate",
    "double_escape_multi",
    "escape_entity_in_json",
    "features_boilerplate",
    "faq_boilerplate",
    "package_mismatch",
    "identity_unverified",
    "mpn_rewritten",
})

#: 模型产出但不在提示词枚举里的兜底 kind：``_sanitize_llm_findings`` 在模型
#: 没给 kind 时写这个值。它同样会被 ``fix_dispatch`` 看到（无模板 → 人工）。
LLM_FREE_KINDS: frozenset[str] = frozenset({"llm_finding"})

#: 已登记的「动态产出点」：审计脚本扫到这些表达式时不判缺陷。
#: 结构为 engine -> {ast 表达式: 说明}。
DYNAMIC_ALLOWED: dict[str, dict[str, str]] = {
    "review": {
        "kind": "review.py::_sanitize_llm_findings 的 LLM 直通——模型可产出任意 "
                "snake_case，清洗后写回；未命中 ACTION_TEMPLATES 时自动落 manual_review。",
    },
}
#: ``worker/tasks.py::ACTION_TEMPLATES`` 的键——**消费侧**。
#: 不变量：必须 ⊆ 生产侧全集（REVIEW_KINDS ∪ TABLE_AUDIT_KINDS ∪ ENGINEERING_KINDS
#: ∪ LLM_KINDS ∪ LLM_FREE_KINDS）。
#: 拼错不报错、只静默退化成人工（AGENT.md §5，已犯一次）。
ACTION_KINDS: frozenset[str] = frozenset({
    "double_escape_multi",
    "escape_entity_in_json",
    "unit_duplicated",
    "electrical_field_missing",
    "electrical_like_feature",
    "unit_dimension",
    "electrical_condition_leak",
    "row_mispair",
    "hero_overview_duplicate",
    "features_boilerplate",
    "faq_boilerplate",
    "identity_board_unresolved",
    "identity_review",
    "identity_conflict",
    "identity_evidence_incomplete",
    "board_confirmed_unmarked",
    "alts_json_has_miss",
    "seo_shared_icon_unmarked",
    "sentinel_leaked_to_copy",
    "board_identity_missing",
    "board_package_mismatch",
    "mpn_rewritten",
    "pin_mismatch",
    "pin_pair_broken",
    "package_mismatch",
    "identity_unverified",
    "i18n_english_residue",
    "pin_polarity_missing",
    "pin_count_mismatch",
    # 符号页工程模型边界（qc/engineering_model.py::check 产出）
    "symbol_page_geometry_unsupported",
    "symbol_page_3d_node_without_state",
    "symbol_page_outline_text_conflict",
    "symbol_page_board_state_mismatch",
    "symbol_page_boundary_text_drift",
})

# ─────────────────────────────────────────────────────────────────────
# 2. 跨来源等价类
# ─────────────────────────────────────────────────────────────────────
# canonical 优先取 review kind（fix_dispatch 只认它），其次 table_audit。
# 只登记**已核实**的对应关系；单来源独有的不登记（无等价可言），不猜。
#
# 判定依据：
#   EXACT  = 两侧调用同一个判据函数 / 同一个条件表达式
#   APPROX = 语义接近但分桶不同（已在 CONFLICTS 里写明差异）

EQUIVALENCES: dict[str, dict[str, str | None]] = {
    # review 与 auto_qc 共用 qc.electrical_classify.classify_electrical_row
    "electrical_like_feature": {
        "review": "electrical_like_feature",
        "auto_qc": "ELECTRICAL_LIKE_FEATURE",
        "table_audit": None,
        "llm": None,
    },
    # 两侧判据都是「json mpn != 请求 mpn」，同族继承各自单独放行
    "mpn_rewritten": {
        "review": "mpn_rewritten",
        "auto_qc": "MPN_MISMATCH",
        "table_audit": None,
        "llm": "mpn_rewritten",
    },
    # APPROX：review 的 missing 含 unit，auto_qc 把 unit 单独拆到 UNIT_MISSING
    "electrical_field_missing": {
        "review": "electrical_field_missing",
        "auto_qc": "ELECTRICAL_ROW_BAD",
        "table_audit": None,
        "llm": None,
    },
    # 同名跨来源（table_audit 产、LLM 复用、ACTION 消费）
    "pin_mismatch": {
        "review": None,
        "auto_qc": None,
        "table_audit": "pin_mismatch",
        "llm": "pin_mismatch",
    },
    "unit_dimension": {
        "review": None,
        "auto_qc": None,
        "table_audit": "unit_dimension",
        "llm": "unit_dimension",
    },
    "package_mismatch": {
        "review": None,
        "auto_qc": None,
        "table_audit": "package_mismatch",
        "llm": "package_mismatch",
    },
    "row_mispair": {
        "review": None,
        "auto_qc": None,
        "table_audit": "row_mispair",
        "llm": None,
    },
    # APPROX：table_audit 的 identity_unverified 与 review 的 identity_review
    # 都表示「身份待人工核验」，但触发条件不同（前者看 PDF 文本能否命中，
    # 后者看 _identity() 的 state）
    "identity_unverified": {
        "review": None,
        "auto_qc": None,
        "table_audit": "identity_unverified",
        "llm": "identity_unverified",
    },
    # 命名分叉：table_audit 产 condition_leak，ACTION/LLM 认 electrical_condition_leak
    "condition_leak": {
        "review": None,
        "auto_qc": None,
        "table_audit": "condition_leak",
        "llm": "electrical_condition_leak",
    },
}

ENGINES = ("review", "auto_qc", "table_audit", "engineering_model", "llm", "action")

# ─────────────────────────────────────────────────────────────────────
# 3. 已确认的分歧（只登记，不改行为）
# ─────────────────────────────────────────────────────────────────────
# 每条都是「同一件、同一字段、两个来源判定不一致」。**不改引擎**，
# 因为改判据属于行为变更，必须单独授权（AGENT.md §5「改判据等于用判据
# 判定判据」）。登记在此的作用是：不再靠记忆，且测试能守住不新增。

CONFLICTS: tuple[dict, ...] = (
    {
        "id": "condition_leak_naming_split",
        "kind": "NAMING",
        "detail": (
            "同一缺陷两个名字：table_audit 产 condition_leak，而 "
            "ACTION_TEMPLATES / _KIND_CATEGORY / LLM 提示词用 electrical_condition_leak。"
        ),
        "names": {"table_audit": "condition_leak",
                  "action": "electrical_condition_leak"},
        # 实测更正（2026-10-29）：早先记为「table_audit 的 finding 在 fix_dispatch 里
        # 匹配不到模板 → 静默退化成人工」，**这个影响判断是错的**。
        # fix_dispatch 只读 review.json 的 rule_findings + llm_findings；
        # table_audit 在 audit_json(write=True) 里自己 patch_cols 并写回源 JSON
        # （qc/table_audit.py:371-378），**从不经过 fix_dispatch**。
        # 所以命名分叉不影响自动修复能力，真实影响是下面三条。
        "impact": (
            "① 跨体系按名检索/统计对不上：qc/goldset.py::P1_KINDS 与 "
            "qc/cheatsheet.py 用 condition_leak，worker/_KIND_CATEGORY 用 "
            "electrical_condition_leak；② ACTION_TEMPLATES 的 "
            "electrical_condition_leak 只能被 LLM 命中（规则层永不产），"
            "该模板生效完全依赖模型自由产出，不稳定；"
            "③ 命名不一致掩盖了更该关注的问题——两条写路径都会改 condition 字段。"
        ),
        "fix": (
            "不要为了「让 finding 有人管」改名——table_audit 本来就自己管。"
            "若要统一，属命名重构 + 统计口径变更，需单独授权；"
            "真正该先查的是 condition_dual_write_paths 那条。"
        ),
        # 保留被推翻的判断（append-only 精神）：下一个 agent 需要知道
        # 「曾经有人这么判过，后来被代码事实推翻」，而不是只看到正确答案。
        "retracted": [
            {
                "claim": "table_audit 的 condition_leak finding 在 fix_dispatch 里"
                         "匹配不到模板 → 静默退化成人工",
                "why_wrong": (
                    "fix_dispatch 只读 review.json 的 rule_findings + llm_findings"
                    "（worker/tasks.py:619,626）；table_audit 在 "
                    "audit_json(write=True) 里自己 patch_cols 并写回源 JSON"
                    "（qc/table_audit.py:371-378），从不经过 fix_dispatch。"
                    "不存在「匹配不到模板」这一步。"
                ),
                "root_cause": (
                    "把 5b 的教训（auto_qc 加的 code 对 fix_dispatch 无效）"
                    "机械套到了 table_audit 上，但两者走的是完全不同的路径——"
                    "没核对就下结论，且结论「看着像对的」。"
                    "这是 AGENT.md §5「QC 判据纪律」记录的第三次同类错误。"
                ),
                "retracted_at": "2026-10-29",
            },
        ],
    },
    {
        # id 为历史命名：初查时以为只冲突 condition 一个字段，
        # 实测发现 patch_cols 是**整行重写**，condition 只是其中一列。
        # 到 2026-10-29 晚，语义又变了：真正的关系不是「两条修复路径互打」，
        # 而是「LLM 初解析值被 table_audit 覆盖」。id 保留（改名代价大、
        # 会让历史检索断链），准确含义写在 detail 首句。
        "id": "condition_dual_write_paths",
        "kind": "ARCHITECTURE",
        "detail": (
            "**本条目 id 已名不副实**：`condition_dual_write_paths` 现在指的不是"
            "「两条修复路径互打」，而是「LLM 初解析值被 table_audit 整行覆盖」——"
            "`fix_elec_row` 那条路径只写 condition 且遇已有值跳过，实际从不与 "
            "`patch_cols` 争同一字段。"
            "`table_audit.patch_cols` 对 specs.electrical[i] 是**整行重写**："
            "`value_raw_original` / `columns` / `columns_raw` / "
            "`value`（第 159 行**无条件**赋值）/ `unit` / `condition` / `source`。"
        ),
        "names": {"table_audit": "condition_leak",
                  "review": "electrical_condition_leak"},
        # 实测（2026-10-29 晚，11 件夹具 / 6 件触发 / 14 行）。
        # 早先记「8 行」「9 行」都偏低：8 是只数了 condition 变了的行；
        # 9 是拿 write=True 的产物与 .pre_audit 备份 diff（备份已存在时不会被覆盖，
        # 见 table_audit.py:376，基线可能是旧的）。现改为把 HEAD 版
        # audit_electrical 直接跑在干净夹具上、内存比对，得 14 行。
        #   value 14/14 被重写，condition 8/14 被改，unit 仅 1/14 被改
        #   （BUF634 row[14]: mA → µA，其余 unit 恰好相同）。
        #   旧值可从 value_raw_original 恢复（单次调用前提下）。
        "impact": (
            "**覆盖面比初判大得多**：不是「condition 单向覆盖」，而是整行 value 一起被"
            "表格列替换（value 14/14 改、condition 8/14 改、unit 仅 1/14 改）。"
            "condition 被改的 8 行里 6 行明显变差（空格乱插 / 整格拼接 / 条件被截断丢模式）；"
            "value 侧**14/14 全部改错，无一例是修正**——BQ24300 三行已逐字对过 PDF，"
            "其余 11 行的命中行也逐条核过（跨表、参数块合并、MIN 列丢负号）。"
            "**不要再用「数值看起来更整齐」推断方向。**"
        ),
        "fix": (
            "先定 `locate_row` 的命中是否正确（见 locate_row_duplicate_match），"
            "再决定 patch_cols 是「只补空值不覆盖」还是「保留 value_raw_original 供回滚」。"
            "**不要**先加 finding——若根因是行错位，加 finding 只是给错数据贴标签。"
        ),
        # 本轮改写 detail / impact 时把两条旧判断直接替换掉了——那是静默删除，
        # 违反本模块刚立的规则（AGENT.md §5.3）。按 append-only 精神补回。
        "retracted": [
            {
                "claim": "specs.electrical[i] 的两条写路径「唯一重叠字段是 condition」，"
                         "patch_cols 只补 condition，value / unit 不碰",
                "why_wrong": (
                    "patch_cols 是**整行重写**：`value` 在第 159 行**无条件**赋值，"
                    "同时还写 value_raw_original / columns / columns_raw / unit / source。"
                    "11 件夹具实测 value **14/14 被改**、condition 8/14 被改、unit 1/14 被改。"
                    "「唯一重叠」这个前提从第一步就是错的。"
                ),
                "root_cause": (
                    "只读了 `fix_elec_row` 的 docstring（「只写 condition，value/unit "
                    "一律不碰」），就把它当成了两条路径的「重叠面」；**没有打开 "
                    "patch_cols 的函数体**。和上一条同源：用一侧的注释推断另一侧的代码。"
                ),
                "retracted_at": "2026-10-29",
            },
            {
                "claim": "覆盖是单向的，且「表格列 > 文本窗口猜测」，按证据强度方向是对的，"
                         "只是替换过程不可追溯",
                "why_wrong": (
                    "实测 14 行覆盖里 condition 被改 8 行，其中 **6 行明显变差**（空格乱插 / 整格拼接 / "
                    "条件被截断丢模式）；value 侧不是「未定」而是**14/14 全部改错**——"
                    "BUF634 三行模式错配（180 MHz → 30 MHz、15 mA → 5 µA），"
                    "BQ24300 三行保护域错配（OCP → OVP）。方向不是「对」，是**没验过**。"
                ),
                "root_cause": (
                    "拿「数据来源层级」（结构化表格 vs PDF 文本窗口）代替了「实际输出比对」，"
                    "来源更权威就默认结果更好。这是推理代替实测，"
                    "与 §5 记录的同类错误一致：结论「看着像对的」所以没跑夹具。"
                ),
                "retracted_at": "2026-10-29",
            },
            {
                "claim": "BQ24300 row[12]/[13] 的 [5, 64] → [64, 8]「更像修正了 LLM "
                         "初解析的错位」，即 patch_cols 至少有一例是改对的",
                "why_wrong": (
                    "对 PDF 后完全相反：`page=3, table=0` 的 row[22] `tBLANK(OCP)`=5 ms、"
                    "row[23] `tREC(OCP)`=64 ms，与原 JSON **逐字一致——原值本来就对**。"
                    "audit 命中的 row[18] `tBLANK(OVP)`=64 µs、row[19] `tON(OVP)`=8 ms "
                    "是**过压**保护，不是过流保护。所以 14 行全部改错，没有一例是修正。"
                ),
                "root_cause": (
                    "把「数值从看似错位的形态变回有序」当成了修正证据——"
                    "但 64/8 只是另一个参数（OVP）的真实取值，凑巧有序。"
                    "**数值合理性不是证据，PDF 原文才是。** 这是同一天第二次"
                    "用直觉代替取证（前一次是 IO=±100 mA 判断，凑巧对了）。"
                ),
                "retracted_at": "2026-10-29",
            },
        ],
    },
    {
        "id": "locate_row_duplicate_match",
        "kind": "DEFECT",
        "detail": (
            "`table_audit.locate_row` 对不同的电气参数行可能命中**同一张表行**。"
            "三处实测：① ADC3910S065IRSMT row[5]『Spur Free Dynamic Range』与 "
            "row[6]『Spur Free Dynamic Range (excluding DC, HD2, HD3)』"
            "同时命中 `page=9, table=0, row=21`，两行 value 都变成 `83 MIN`（原 63 / 85）；"
            "② 74LVC1G132DCKTG4 的『High-level output voltage』与"
            "『Output off leakage current』同时命中 `page=4, table=0, row=2`"
            "（一行是绝对最大额定值『VO Voltage range』），两条都变成 `5 MIN`；"
            "③ ADS7812B 的『Unipolar Zero Error』与『VS』同时命中 "
            "`page=2, table=1, row=3`（该行是整块 DC ACCURACY 合并单元格），"
            "两条都变成 `5 MAX`。两个不同参数不可能共用同一表行。"
        ),
        "names": {},
        "impact": (
            "一旦命中，该行 value/unit/condition 全部被错误覆盖，且覆盖后看起来"
            "「有页码、有 MIN 列」很像正确结果——比缺失更难发现。"
            "6 件触发件里 3 件有这种情况，说明它不是孤例。"
            "与 locate_row_ignores_qualifier 同源：都缺「候选行唯一性 + 限定词约束」。"
            "**已于 2026-10-29 晚修复**（`locate_row/unique-v1`：同一 (表,行) 被多个条目"
            "认领 → 全部 `row_ambiguous_unresolved`，谁都不写），本条保留为历史记录。"
        ),
        "fix": (
            "`locate_row` 需要加「一行只能被匹配一次」的约束（或用符号列精确匹配后"
            "从候选集移除已用行）；属判据变更，需单独授权 + 对 11 件夹具回归。"
        ),
    },
    {
        "id": "locate_row_ignores_qualifier",
        "kind": "DEFECT",
        # 原 id 为 locate_row_mode_variant_mismatch（创建于 2026-10-29 上午）。
        # 同日 BQ24300 的对 PDF 结果证明不只是「模式」——保护域（OVP/OCP）同理，
        # 故改名以覆盖整类「限定词丢失」。改名理由记在 detail 首句，不另设 retracted
        # （被推翻的是「范围」，不是「判断」）。
        "detail": (
            "（本条目原名 `locate_row_mode_variant_mismatch`，因实测发现不止 mode，"
            "故改名；判断未变，只是范围扩大。）"
            "`table_audit.locate_row` **只按参数名匹配，不看任何限定词**——"
            "模式（mode）、保护域（OVP/OCP）、测试条件都算限定词。两处实测："
            "① BUF634PG4 `page=5, table=0` 的 row[24] =『Bandwidth –3dB, RL = 1 kΩ / "
            "Low quiescent current mode / 30』、row[25] =『Wide bandwidth mode / 180』。"
            "原 JSON value=180 且 condition 明写 Wide bandwidth（自洽且正确），"
            "audit 命中 row[24]，value 改 `30 MIN`、condition 换成 `RL = 1 kΩ`；"
            "同件 Quiescent current 15 mA（wide bandwidth）→ `5 MIN` µA，差三个数量级。"
            "② BQ24300DSGR：JSON row[12]『Blanking time, input overcurrent detected』"
            "= 5 ms、row[13]『Recovery time from input overcurrent condition』= 64 ms，"
            "与 PDF `page=3, table=0` 的 row[22] `tBLANK(OCP)`=5 ms、"
            "row[23] `tREC(OCP)`=64 ms **完全一致（原值本来就对）**；"
            "audit 却命中 row[18] `tBLANK(OVP)`=64 µs、row[19] `tON(OVP)`=8 ms——"
            "把「过流保护」的行配到了「过压保护」的行，只因为都叫 blanking/recovery time。"
        ),
        "names": {},
        "impact": (
            "不是偶发错位，而是**结构性**：凡参数表把同一参数按限定词拆成相邻子行的器件"
            "（运放/LDO/时钟缓冲器按 mode、保护 IC 按 OVP/OCP、ADC 按 test condition），"
            "匹配器都会稳定取到第一个子行，把另一档的规格搬过来，"
            "同时抹掉 condition 里的限定词。"
            "结果「有页码、有 MIN 列、condition 也非空」，比缺失更难发现。"
            "11 件夹具实测的 14 行被改**全部是这一类，无一例是正确修正**。"
        ),
        "fix": (
            "匹配必须带限定词：先用参数名缩候选，再用原行 condition / 符号后缀"
            "（`(OVP)` / `(OCP)` / Wide bandwidth / Low quiescent / TA= / RL=）"
            "在同一参数的多行里选；选不出就报 unresolved，**不要猜**。"
            "`patch_cols` 另需保留模式列（PDF 里是独立无表头列，见 "
            "`ROLE_PATTERNS` 未覆盖）。属判据变更，需单独授权 + 11 件回归。"
            "**状态（2026-10-29 晚）**：唯一性闸门 `locate_row/unique-v1` 已落地，"
            "但本类问题**未解**——闸门只是把「多候选/抢同一行」变成 ambiguous。"
            "落地后 11 件夹具的写入由 14 行降为 **0 行**（224 条 ambiguous），"
            "即限定词解析完成前，`write=True` 实际上不会改任何东西。这是安全侧的"
            "正确行为，但也意味着**开生产写入必须先做本项**。"
        ),
    },
    {
        "id": "row_incomplete_bucketing",
        "kind": "SEMANTIC",
        "detail": (
            "review 的 electrical_field_missing 把「缺 unit」算进缺字段；"
            "auto_qc 把缺 unit 拆到 UNIT_MISSING，ELECTRICAL_ROW_BAD 只数缺 name/value。"
            "同一件可能 review 报 5 条缺字段、auto_qc 只报 2 条坏行 + 3 条缺单位。"
        ),
        "names": {"review": "electrical_field_missing",
                  "auto_qc": "ELECTRICAL_ROW_BAD"},
        "impact": "两条线的「电气表坏行数」不可直接相加或对比",
        "fix": "统一分桶口径（是否把 unit 计入坏行），需裁决后改判据",
    },
    {
        "id": "sentinel_opposite_semantics",
        "kind": "SEMANTIC",
        "detail": (
            "review 的 sentinel_leaked_to_copy 判「not_specified 泄到文案里」是缺陷；"
            "auto_qc 的 ELECTRICAL_NOT_SPECIFIED 判「原表无值、非缺陷」。"
            "两者可同时出现且都成立——前者是渲染层问题，后者是数据层豁免。"
        ),
        "names": {"review": "sentinel_leaked_to_copy",
                  "auto_qc": "ELECTRICAL_NOT_SPECIFIED"},
        # 实测（2026-10-29）：确认**会同时出现**，不是理论冲突。
        # json_to_txt.spec_value() 只吞 unit 侧的 sentinel，不吞 value 侧：
        #   {"value":"not_specified","unit":""}    -> "not_specified"      ← 泄漏
        #   {"value":"12","unit":"not_specified"}  -> "12"                 ← 吞掉
        #   {"value":"not_specified","unit":"bit"} -> "not_specified bit"  ← 泄漏
        # 所以「value=not_specified 的行」必然同时触发两条 finding：
        # auto_qc 计数（数据层豁免）+ review 报警（渲染层缺陷）。
        "impact": (
            "不是矛盾，是分工：同一条电气行会同时出现在两条线的结果里。"
            "看单条 finding 会误以为互相冲突；实为数据层「原表无值」"
            "与渲染层「该值被当文案输出」两件事。"
            "顺带暴露一个渲染层缺口：spec_value() 只对 unit 侧做 sentinel 吞并，"
            "value 侧的 not_specified 会原样输出。"
        ),
        "fix": (
            "无需改判据。若要消除泄漏本身，应在 spec_value() 里对 value 侧也做"
            "sentinel 处理（属渲染行为变更，需单独授权 + 回归对比）。"
        ),
    },
    {
        "id": "electrical_like_feature_severity",
        "kind": "SEVERITY",
        "detail": (
            "同一判据（qc.electrical_classify），行数 >2 时 auto_qc 判 FAIL、"
            "review 固定 P1（→ WARN）。件级状态因此可能一个 FAIL 一个 WARN。"
        ),
        "names": {"review": "electrical_like_feature",
                  "auto_qc": "ELECTRICAL_LIKE_FEATURE"},
        "impact": "同一件在两条线上件级状态不一致（行数 >2 时）",
        "fix": "把升格规则（count>2 → BLOCKER）下沉到共享层，需单独授权",
    },
)

# ─────────────────────────────────────────────────────────────────────
# 4. 源码提取配置（审计脚本与测试共用同一份，避免两处路径漂移）
# ─────────────────────────────────────────────────────────────────────
# 三套引擎的写法完全不同，**不能用统一的 kwarg 扫描**：
#
#   review.py      : out.append({"kind": "mpn_rewritten", ...})     → dict 字面量
#   auto_qc.py     : _add(findings, SEV_FAIL, "r1", "PDF_MISSING")  → 第 4 个位置参数
#   table_audit.py : finding(path, "range_collapse", val, cols)     → 第 2 个位置参数
#
# 早期方案用「扫 kind= / code= 关键字参数」，三处全部扫出 0 个，
# 测试因此**全绿但什么都没校验**（假绿）。这是本模块最重要的教训。

ENGINE_SOURCES: dict[str, dict] = {
    "review": {
        "path": "app/services/review.py",
        "how": "dict_key",
        "key": "kind",
    },
    "auto_qc": {
        "path": "qc/auto_qc.py",
        "how": "call_arg",
        "func": "_add",
        "index": 3,
    },
    "table_audit": {
        "path": "qc/table_audit.py",
        "how": "call_arg",
        "func": "finding",
        "index": 1,
    },
    # 符号页工程模型边界 A1–A5：产出点在 qc/engineering_model.py::_finding(kind, ...)
    "engineering_model": {
        "path": "qc/engineering_model.py",
        "how": "call_arg",
        "func": "_finding",
        "index": 0,
    },
}

#: 消费侧：``worker/tasks.py::ACTION_TEMPLATES`` 的键
ACTION_TEMPLATES_SOURCE: tuple[str, str] = ("worker/tasks.py", "ACTION_TEMPLATES")

#: LLM 词表：``review.RULES_TEXT`` 里「尽量复用: a | b | c>」那一段
LLM_PROMPT_SOURCE: tuple[str, str] = (
    "app/services/review.py", r"尽量复用:\s*([^>\"\n]+)")


# ─────────────────────────────────────────────────────────────────────
# 5. AST 扫描（审计脚本与测试共用）
# ─────────────────────────────────────────────────────────────────────

def scan_source(path, *, how: str, key: str = "", func: str = "",
                index: int = 0) -> tuple[set[str], list[str]]:
    """从源码提取字面量集合。返回 (字面量, 无法静态解析的表达式)。

    非字面量（``"ART_%s_MISSING" % var``、``kind=CONST``）会进第二个返回值，
    由审计脚本显式打印——这是本模块的已知盲区，必须人工核，不能当 0 处理。
    """
    import ast
    from pathlib import Path

    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError("引擎源码不存在：%s" % p)
    tree = ast.parse(p.read_text(encoding="utf-8"))
    lits: set[str] = set()
    dyn: list[str] = []

    def _take(node) -> None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            lits.add(node.value)
        else:
            dyn.append(ast.unparse(node))

    for node in ast.walk(tree):
        if how == "dict_key" and isinstance(node, ast.Dict):
            for k, v in zip(node.keys, node.values):
                if isinstance(k, ast.Constant) and k.value == key:
                    _take(v)
        elif how == "call_arg" and isinstance(node, ast.Call):
            if ast.unparse(node.func).split(".")[-1] != func:
                continue
            if len(node.args) > index:
                _take(node.args[index])
    return lits, dyn


def scan_engine(engine: str) -> tuple[set[str], list[str]]:
    """按 ENGINE_SOURCES 的配置扫某个引擎。"""
    if engine not in ENGINE_SOURCES:
        raise ValueError("未知 engine=%r，合法值：%s"
                         % (engine, sorted(ENGINE_SOURCES)))
    return scan_source(**ENGINE_SOURCES[engine])


def scan_action_kinds(path) -> set[str]:
    """扫 ``ACTION_TEMPLATES = {"k": ...}`` 的字符串键。"""
    import ast
    from pathlib import Path

    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError("源码不存在：%s" % p)
    tree = ast.parse(p.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for tgt in node.targets:
                if isinstance(tgt, ast.Name) and tgt.id == "ACTION_TEMPLATES" \
                        and isinstance(node.value, ast.Dict):
                    return {k.value for k in node.value.keys
                            if isinstance(k, ast.Constant)
                            and isinstance(k.value, str)}
    return set()


def scan_llm_prompt_kinds(path) -> set[str]:
    """从 ``RULES_TEXT`` 的「尽量复用: a | b | c>」抠出模型建议词表。"""
    from pathlib import Path

    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError("源码不存在：%s" % p)
    m = re.search(LLM_PROMPT_SOURCE[1], p.read_text(encoding="utf-8"))
    if not m:
        return set()
    return {x.strip() for x in m.group(1).split("|") if x.strip()}


def is_auto_qc_code(name: str) -> bool:
    """auto_qc 的运行时拼接 code 是否被模式覆盖（ART_* / LANG_* / JSON_BAD_*）。"""
    return any(rx.match(name) for rx in _AUTO_QC_RE)


# ─────────────────────────────────────────────────────────────────────
# 6. 归一化
# ─────────────────────────────────────────────────────────────────────

_KNOWN: dict[str, frozenset[str]] = {
    "review": REVIEW_KINDS,
    "auto_qc": AUTO_QC_CODES,
    "table_audit": TABLE_AUDIT_KINDS,
    "engineering_model": ENGINEERING_KINDS,
    "llm": LLM_KINDS | LLM_FREE_KINDS,
    "action": ACTION_KINDS,
}

#: 实测下界（2026-10-29 磁盘盘点）。只允许上调，不允许下调——
#: 防止注册表被误改空/误缩水后测试仍然全绿（第二道防线：
#: 第一道是「源码扫描 ⊆ 注册表」，它只能抓新增，抓不到被删）。
#: 2026-10-29 晚：另一条工作线在 `review.py` / `ACTION_TEMPLATES` 里新增了
#: `pin_count_mismatch`，现已同步登记到 REVIEW_KINDS / ACTION_KINDS 并补全最小值。
#: 2026-10-30：符号页工程模型边界 A1–A5 五个 kind 落在 `qc/engineering_model.py`，
#: 作为独立来源 `engineering_model` 登记；消费侧（ACTION_TEMPLATES）新增 5 个键。
#: 2026-10-30 晚（A17）：`table_audit` 实际已 22 个，下限停在 21 —— 下限是
#: 「防某个 kind 被无声删掉」的最后一道，落后 1 等于少守一个 kind，随本次一并抬到实测值。
#: 2026-10-31（A18）：新增 `table_foreign_part_unresolved`，实测 23，下限同步抬到 23
#: —— 注册与引擎同一次提交，且下限跟着实测走，不给「下限落后」留窗口。
REVIEW_KINDS_MIN = 22
AUTO_QC_CODES_MIN = 29
TABLE_AUDIT_KINDS_MIN = 25
LLM_KINDS_MIN = 15
ACTION_KINDS_MIN = 34
ENGINEERING_KINDS_MIN = 5

LOWER_BOUNDS: dict[str, int] = {
    "review": REVIEW_KINDS_MIN,
    "auto_qc": AUTO_QC_CODES_MIN,
    "table_audit": TABLE_AUDIT_KINDS_MIN,
    "llm": LLM_KINDS_MIN,
    "action": ACTION_KINDS_MIN,
    "engineering_model": ENGINEERING_KINDS_MIN,
}

#: 生产侧全集——ACTION_TEMPLATES 的键必须落在这个范围内
PRODUCERS: frozenset[str] = (REVIEW_KINDS | TABLE_AUDIT_KINDS | LLM_KINDS
                             | LLM_FREE_KINDS | ENGINEERING_KINDS)

_ALIAS: dict[str, str] = {}
for _canonical, _mapping in EQUIVALENCES.items():
    for _engine, _name in _mapping.items():
        if not _name:
            continue
        prev = _ALIAS.get(_name)
        # 同名跨来源必须指向同一个 canonical，否则归一有歧义
        if prev is not None and prev != _canonical:
            raise RuntimeError(
                "finding_kinds: 名字 %r 同时映射到 %r 与 %r，归一化有歧义"
                % (_name, prev, _canonical))
        _ALIAS[_name] = _canonical


def is_known(name: str, engine: str) -> bool:
    """name 是否在 engine 的注册表里（auto_qc 支持模式匹配）。"""
    if engine not in _KNOWN:
        raise ValueError("未知 engine=%r，合法值：%s" % (engine, sorted(_KNOWN)))
    if not isinstance(name, str) or not name:
        return False
    if name in _KNOWN[engine]:
        return True
    if engine == "auto_qc":
        return any(rx.match(name) for rx in _AUTO_QC_RE)
    return False


def normalize(name: str) -> str | None:
    """任意来源写法 → canonical。未登记返回 None（不抛异常，生产可安全调用）。"""
    if not isinstance(name, str) or not name:
        return None
    hit = _ALIAS.get(name)
    if hit:
        return hit
    # 未进等价类但本身就是一个来源里的合法名字 → 以自身为 canonical
    for engine in ("review", "table_audit", "engineering_model", "llm", "auto_qc"):
        if is_known(name, engine):
            return name
    return None


def equivalents(canonical: str) -> dict[str, str | None]:
    """查 canonical 在四个来源里的写法；未登记返回空 dict。"""
    row = EQUIVALENCES.get(canonical)
    return dict(row) if row else {}


def names_of(canonical: str) -> set[str]:
    """canonical 及它在各来源的全部别名（含自身）。"""
    out = {canonical}
    out.update(n for n in (EQUIVALENCES.get(canonical) or {}).values() if n)
    return out


def check_known(names, engine: str, *, strict: bool = False) -> set[str]:
    """校验 names 是否都在 engine 的注册表里。

    strict=True：未知名立即 raise（测试用）。
    strict=False（默认）：只 warnings.warn，返回未知名集合。
    """
    if engine not in _KNOWN:
        raise ValueError("未知 engine=%r，合法值：%s" % (engine, sorted(_KNOWN)))
    unknown = {n for n in names if not is_known(n, engine)}
    if unknown:
        msg = ("[finding_kinds] engine=%s 有未注册的名字：%s。"
               "请在 qc/finding_kinds.py 对应集合补充。"
               % (engine, sorted(unknown)))
        if strict:
            raise ValueError(msg)
        warnings.warn(msg, stacklevel=2)
    return unknown


def conflict_for(name: str) -> list[dict]:
    """返回与该名字相关的已登记分歧（按 canonical 归组后匹配）。"""
    canon = normalize(name) or name
    out = []
    for c in CONFLICTS:
        if canon in {normalize(n) or n for n in c["names"].values()}:
            out.append(c)
    return out


def catalog() -> dict:
    """机器可读清单（供审计脚本 / 文档生成）。"""
    return {
        "engines": list(ENGINES),
        "counts": {k: len(v) for k, v in _KNOWN.items()},
        "patterns": list(AUTO_QC_CODE_PATTERNS),
        "equivalences": {k: dict(v) for k, v in EQUIVALENCES.items()},
        "conflicts": [dict(c) for c in CONFLICTS],
    }
