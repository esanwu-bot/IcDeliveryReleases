#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把一次解析产物装配成**交付验收根**（parsed / txt / symbols / alts / seo）。

本脚本原名 `qc/v4_stage.py`（V4 交付时新建）。V5/1101 起改名 `stage_release.py`：
它装配的是**任何一版**的验收根，不该带着版本号。历史命令见 `V4_修复说明.md`。

为什么要有这个脚本
------------------
V3 的验收根是临时脚本拼的（`.sandbox/` 里，不入库、复跑不了）。客户问「这个包
是怎么来的」时，只能回答「当时手动跑的」。V4 起装配路径入库，一条命令可重放：

    python qc/stage_release.py --src data/_v4run5 --carry data/staging_20261031_v3/parsed \
        --alts-from data/staging_20261031_v3/alts --out data/staging_20261031_v4

三条口径（都会写进 `_stage_report.json`）
----------------------------------------
1. **fresh**：本次重解析的产物，原样进包。
2. **carry**：本次解析**主动跳过**的型号（`is_datasheet()` 判为 User Guide /
   Quick Start 的板卡），沿用指定旧目录的产物，并记 `reason`。
   —— 板卡页不是芯片页，四验收点与它们无关；但「悄悄换回旧文件」不行，必须留痕。
3. **stamp**：JSON 里缺 `metadata.core_sha256` 时补算。指纹只由落盘内容决定，
   补算不改变任何数据；老产物因此也能被客户复跑比对。

物料缺项一律如实留空，不从全局旧目录凑齐（`delivery_bundle.py` 的验收模式
会把缺项写进 manifest 的 `missing` 列）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import json_to_txt as J                                       # noqa: E402
import symbol_svg as S                                        # noqa: E402
from app.services import seo_image as SEO                     # noqa: E402
from app.services.parts import safe_name                      # noqa: E402
from qc import core_validation as CV                          # noqa: E402
from qc import deterministic_extract as DE                    # noqa: E402
from qc import normalize_doc as ND                            # noqa: E402
from qc import source_url as SU                               # noqa: E402

#: 客户五件（请求型号口径）
MPNS = ("ADC12DJ5200SE", "ADS1201U-1/1K", "ADS8568EVM-PDK",
        "BOOST-DRV8711", "BOOSTXL-C2KLED")
LANGS = ("ja", "ko", "de", "es")


def _load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def _index(src: Path) -> dict[str, Path]:
    """目录里的 JSON 按 `basic_info.mpn` 建索引（文件名带 hash，不能按名匹配）。"""
    out: dict[str, Path] = {}
    for p in sorted(src.glob("*.json")):
        try:
            d = _load(p)
        except Exception:                                      # noqa: BLE001
            continue
        m = str((d.get("basic_info") or {}).get("mpn") or "")
        if m:
            out[m] = p
    return out


def _stamp(doc: dict, force: bool = False) -> dict:
    """核心指纹。`force=True` 时无条件重算（归一改过内容就必须重算）。

    指纹描述的是**落盘内容**。归一改动了 `specs.temperature` / 删了电气行，
    指纹不跟着变，就等于拿旧指纹给新内容背书。
    """
    meta = doc.setdefault("metadata", {})
    old = meta.get("core_sha256")
    if isinstance(old, dict) and not force:
        return {"stamped": False, "changed": False}
    new = DE.core_digest(doc)
    meta["core_sha256"] = new

    def _sha(entry) -> str:
        # `core_sha256` 里除了各类指纹（dict）还有 `method`（纯字符串，说明口径）。
        # 早先直接 `.get("sha256")`，一碰到 `method` 就 AttributeError，
        # 装配在第一个型号就崩（实测）。
        return str(entry.get("sha256") or "") if isinstance(entry, dict) else ""

    changed = isinstance(old, dict) and any(
        _sha(old.get(k)) != _sha(new.get(k)) for k in new)
    return {"stamped": True, "changed": changed, "before": old}


def _revalidate(doc: dict, mpn: str, pdf: Path | None = None) -> dict:
    """用**当前**校验口径重算 core_validation。

    解析时写的旧值不能直接信：`check_core()` 曾经把 ADC12DJ5200SE 的四条验收点
    硬编码在通用校验里，导致 `ADS1201U-1/1K` 这类没有 VCMI/VID 行的器件被记成
    失败。重算后把「解析时」与「重算」两栏都留在 metadata 里，谁改的口径一目了然。
    """
    meta = doc.setdefault("metadata", {})
    old = meta.get("core_validation")
    # 1102-V3.2：`specs.thermal` / `specs.esd` 为空时，先查**源 PDF 文本层**有没有这张表。
    # 没有 = `not_applicable`（老 TI datasheet 常不印这两张表），不能再判 UNRESOLVED；
    # 有表却为空 = 抽取失败，照旧报错。判据只认 PDF 原词，不认模型自述。
    absent: set[str] = set()
    sp = doc.get("specs") or {}
    # 主动扣下的容器（列塌缩隔离）：既不判「源文档没有」，也不判「抽到了却丢了」。
    # 判据只看隔离记录，不看容器是否为空 —— 「空」有四种成因，只有这一种是我们
    # 自己的决定，混在一起就分不清该不该拦。
    _cs = (doc.get("metadata") or {}).get("column_collapse_state") or {}
    withheld = {k for k in ("thermal", "esd")
                if k in (_cs.get("containers") or []) and not (sp.get(k) or [])}
    if pdf and Path(str(pdf)).is_file():
        try:
            import pymupdf                                    # noqa: PLC0415
            with pymupdf.open(str(pdf)) as fd:
                for k in ("thermal", "esd"):
                    if not (sp.get(k) or []) and not DE.source_has_container(fd, k):
                        absent.add(k)
        except Exception:                                      # noqa: BLE001
            absent = set()
    new = DE.check_core(doc, meta.get("deterministic_extract"), frozenset(absent),
                        frozenset(withheld)) + \
        DE.check_acceptance(doc, mpn)
    # 1102-V2 P1：AC 脏行搬进隔离桶后错误清单会归零，但「没有错误」不等于
    # 「没有扣下数据」。有 unresolved_ac_rows 时写 pass_with_quarantine +
    # quarantine_count，下游才分得清「原厂没给 AC 参数」与「我们主动扣下了」。
    value = CV.stamp(meta, doc, new or CV.PASS)
    # 第二趟（`--keep-out` 重渲染）时 `old` 已经是**上一次重算**的值，
    # 再覆写 `core_validation_at_parse` 会把真正的解析时状态冲掉。
    # 第一次记下后就不再改。
    meta.setdefault("core_validation_at_parse", old)
    meta["core_validation"] = value
    meta["core_validation_note"] = ("qc/stage_release.py 用当前口径重算；"
                                    "check_core=通用结构，check_acceptance=型号级验收点；"
                                    "有 unresolved_ac_rows 时记 pass_with_quarantine（数据被隔离，"
                                    "不是没有数据）")
    return {"at_parse": old, "recomputed": value,
            "quarantine_count": CV.quarantine_count(doc)}


def _pdf_for(safe: str, pdf_dir: Path | None, pdf_hash: str = "") -> Path | None:
    """找源 PDF。找不到返回 None（归一照样能跑，只是少几项）。

    **先按型号收窄候选，再用 `metadata.pdf_hash` 定案**。

    为什么不能只按文件名：本地约定是 `{请求订货号}__{抓取文件名}`，而请求号在
    不同批次里会变 —— 同一个 `adc12dj5200se.pdf` 抓下来挂过 `ADC12DJ5200SEEVM`，
    重解析挂的是 `ADC12DJ5200SEAAV`。只按 `ADC12DJ5200SE__*` 去找**一个都匹配
    不上**，归一就静默跳过：V4 温度掉单位、链接变空都是这么漏过去的。

    为什么不直接全目录哈希：`data/pdfs` 有上万份 PDF，五件跑一遍能把进程拖死
    （实测被 SIGTERM）。候选通常只有 1~2 个，哈希代价可以忽略。
    """
    if not pdf_dir or not pdf_dir.is_dir():
        return None
    cands: list[Path] = []
    for pat in (f"{safe}__*.pdf", f"{safe}*.pdf"):
        cands = sorted(pdf_dir.glob(pat))
        if cands:
            break
    if not cands:
        return None
    if len(cands) == 1 or not pdf_hash:
        return cands[0]
    for p in cands:
        if hashlib.sha256(p.read_bytes()).hexdigest() == pdf_hash:
            return p
    return cands[0]


def stage_one(mpn: str, src_json: Path, out: Path, alts_from: Path | None,
              langs: tuple[str, ...], source: str, reason: str = "",
              pdf_dir: Path | None = None, normalize: bool = False) -> dict:
    doc = _load(src_json)
    bi = doc.setdefault("basic_info", {})
    safe = safe_name(mpn)
    if safe_name(str(bi.get("mpn") or "")) != safe:
        raise ValueError(f"{mpn}: JSON 的 basic_info.mpn={bi.get('mpn')!r} 与请求型号不一致")

    # 归一必须在指纹之前：温度补单位、应力行归位都会改内容。
    # 源 PDF 只解析一次，归一与随包交付共用同一份 —— 各自去找可能拿到不同文件，
    # 那就会出现「页面按 A 归一、包里放的是 B」这种最难查的不一致。
    pdf = _pdf_for(safe, pdf_dir,
                   str((doc.get("metadata") or {}).get("pdf_hash") or ""))
    # ── 列塌缩红线（2026-11-03 外审 V1）──────────────────────────────────
    # 必须在 `_stamp` 之前：隔离会改 `specs`，改完再算 `core_sha256`，
    # 否则指纹记的是隔离前的状态，复核方重算必然对不上。
    # 也必须在此刻探测：装配阶段是「最后一次能拦住脏数据」的位置，
    # 等到打包才发现，包已经装好了。
    try:
        from qc import collapse_quarantine as CQ                  # noqa: PLC0415
        _cc_finds = [f for f in CQ.detect(doc, pdf)
                     if f.get("kind") == "column_collapse"]
        if _cc_finds:
            doc.setdefault("metadata", {})["column_collapse"] = {
                "detected": True,
                "containers": sorted({f["path"].split(".", 1)[-1] for f in _cc_finds}),
                "tables": [f["table"] for f in _cc_finds],
            }
            CQ.quarantine(doc)
    except Exception as e:                                        # noqa: BLE001
        doc.setdefault("metadata", {})["column_collapse_detect_error"] = \
            f"{type(e).__name__}: {e}"[:200]
    # ── D4 引脚硬闸重放（2026-11-04）────────────────────────────────────
    # 装配期必须**重放**，不能只信解析期写下的 `metadata.pin_validation`：
    # V3-CANDIDATE 的 7 件冻结于硬闸上线之前，包内该字段**全部为空**。
    # 补状态只剩两条路 —— 重新调 LLM（引入采样漂移，§5.1）或在装配期重算。
    # `apply_pin_gate` 只吃「PDF + 现有引脚集」，与解析期同一实现、幂等。
    # 必须在 `_stamp` 之前：它可能替换/重排 `pin_configuration`，改完再算指纹。
    try:
        import pymupdf as _fitz                                  # noqa: PLC0415
        from qc import deterministic_extract as _DE              # noqa: PLC0415
        if pdf and pdf.is_file():
            with _fitz.open(str(pdf)) as _fd:
                _pin_rep = _DE.apply_pin_gate(doc, _fd)
            doc.setdefault("metadata", {})["pin_gate_replay"] = {
                "at": datetime.now(timezone.utc).astimezone()
                .isoformat(timespec="seconds"),
                "pdf": pdf.name,
                "result": _pin_rep,
            }
        else:
            # 没有 PDF 就对不了封装表：不许留空让下游当成「没这道闸」，
            # 明确写 unverified，打包闸门据此 BLOCKED。
            doc.setdefault("metadata", {})["pin_validation"] = {
                "status": "unverified", "reason": "no_pdf",
                "note": "装配期拿不到源 PDF，引脚无法与封装表对账",
            }
    except Exception as e:                                        # noqa: BLE001
        doc.setdefault("metadata", {})["pin_validation"] = {
            "status": "unverified", "reason": "pin_replay_failed",
            "error": f"{type(e).__name__}: {e}"[:200],
        }

    norm: dict = {}
    if normalize:
        norm = ND.normalize(doc, pdf, SU.load_url_map(ROOT / "data" / "manifest.csv"))
        norm["pdf"] = str(pdf) if pdf else ""
        doc.setdefault("metadata", {})["normalize"] = norm

    digest = _stamp(doc, force=bool(norm))
    core = _revalidate(doc, mpn, pdf)
    (out / "parsed").mkdir(parents=True, exist_ok=True)
    (out / "parsed" / f"{safe}.json").write_text(
        json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    # 流水线凭证（2026-11-03 外审 P0-1）：记下这份 JSON 的**内容指纹**与归一状态。
    # 打包器据此拒绝「拿旧 JSON 原地重打」—— 那条近路让交付包里的
    # `verification` 与事实表对不上，是这次一票否决的直接成因。
    from qc import pipeline_stamp as PS                           # noqa: PLC0415
    PS.record(out, "stage_release", mpn, doc, out / "parsed" / f"{safe}.json")

    # 事实表结论（`qc/fact_acceptance.py` 写在同一目录）。有它就挂到内存里
    # 给渲染层用，**不写回 JSON** —— 那是渲染期输入，不是解析产物，
    # 写进 JSON 会让 `core_sha256` 随渲染次序漂移。
    # 顺序因此是两趟：装配 → 事实表 → 再装配（`--keep-out`）。
    _fvf = out / "facts_verdicts.json"
    if _fvf.is_file():
        try:
            _all = (json.loads(_fvf.read_text(encoding="utf-8")) or {}).get("mpns") or {}
        except (ValueError, TypeError, OSError):
            _all = {}
        if _all.get(safe):
            doc.setdefault("metadata", {})["facts_verdicts"] = _all[safe]

    # ---- SEO 侧车 + HTML（<img> 的 alt/title 由同一份 plan 改写）
    plan = SEO.build(doc, mpn)
    (out / "seo").mkdir(parents=True, exist_ok=True)
    side = Path(plan["_path"])
    if side.is_file():
        shutil.copy2(side, out / "seo" / f"{safe}.seo.json")

    (out / "txt").mkdir(parents=True, exist_ok=True)
    diag_en: dict = {}
    html = SEO.optimize_html(J.render(doc, "en", diag_en), plan)
    (out / "txt" / f"{safe}.txt").write_text(html, encoding="utf-8")
    have_langs = []
    i18n_langs: dict = {"en": {"i18n_complete": True, "i18n_coverage": None,
                               "fallback_events": 0}}
    ml = doc.get("multi_language") or {}
    for lg in langs:
        if not (ml.get(lg) or {}):
            continue
        diag: dict = {}
        h = SEO.optimize_html(J.render(doc, lg, diag), plan)
        (out / "txt" / f"{safe}.{lg}.txt").write_text(h, encoding="utf-8")
        have_langs.append(lg)
        i18n_langs[lg] = {
            "i18n_complete": diag.get("i18n_complete"),
            "i18n_coverage": diag.get("i18n_coverage"),
            "fallback_events": len(diag.get("fallback_events") or []),
        }
    # 语言覆盖率侧车：交付清单里的 `i18n_complete` 只能从这里读。
    # 打包器是「只装配已有物料」模式，不允许在打包时重渲染一遍来算覆盖率 ——
    # 那会让清单里的数字与实际交付的 HTML 不是同一次渲染的产物。
    (out / "txt" / f"{safe}.i18n.json").write_text(json.dumps({
        "schema": "i18n-coverage/v1",
        "mpn": mpn,
        "languages": i18n_langs,
        # 管脚描述按硬件工程惯例保留英文原文（IEEE 器件手册口径），
        # 不算「未翻译残留」。页面上有对应小字说明。
        "pin_desc_exempt": bool(doc.get("pin_configuration")),
        "pin_desc_exempt_reason": (
            "pin_configuration descriptions are kept in the source language "
            "(IEEE device-datasheet convention); not an untranslated residue"),
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- 三视图
    # `inline_pkg=True` 是**交付包的硬要求**：包脱离站点打开，
    # 站内绝对路径 `/upload/pkg/X.svg` 在包里就是裂图（V8 实测 ADS1201U
    # 中间/右边两格全是浏览器裂图图标）。共享封装图在交付件里一律内联。
    (out / "symbols").mkdir(parents=True, exist_ok=True)
    (out / "symbols" / f"{safe}.html").write_text(
        S.render_page(doc, pkg_dir=ROOT / "data" / "pkgs", inline_pkg=True),
        encoding="utf-8")

    # ---- 源 PDF 原件随包交付
    # 为什么必须随包：复核方拿到的是产物，没有 PDF 就只能「相信」哈希记录，
    # 无法独立重算、也无法逐行对照 —— 这正是 1101 包被判「不能视为重新核验」的原因。
    # 为什么复制前先算哈希：把「包内 PDF 与 JSON 记的 pdf_hash 是否同一份」变成
    # 装配期就能断言的事，而不是留给复核方去发现不一致。
    pdf_info: dict = {"included": False, "file": "", "sha256": "", "match": None}
    if pdf and pdf.is_file():
        want = str((doc.get("metadata") or {}).get("pdf_hash") or "")
        got = hashlib.sha256(pdf.read_bytes()).hexdigest()
        (out / "pdfs").mkdir(parents=True, exist_ok=True)
        shutil.copy2(pdf, out / "pdfs" / f"{safe}.pdf")
        pdf_info = {
            "included": True, "file": f"pdfs/{safe}.pdf", "sha256": got,
            "match": (got == want) if want else None,
            "source_name": pdf.name,
        }

    # ---- 替代料侧车：只在显式给了来源目录时复制，并记下来源
    alt_note = ""
    if alts_from and alts_from.is_dir():
        copied = []
        for suf in (".alts.json", ".alts.html"):
            p = alts_from / f"{safe}{suf}"
            if p.is_file():
                (out / "alts").mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, out / "alts" / f"{safe}{suf}")
                copied.append(suf.lstrip("."))
        alt_note = ",".join(copied) or "missing"

    sp = doc.get("specs") or {}
    return {
        "mpn": mpn, "safe_name": safe, "source": source, "reason": reason,
        "src_json": str(src_json),
        "pdf": pdf_info,
        "electrical": len(sp.get("electrical") or []),
        "absolute_max": len(sp.get("absolute_max") or []),
        "thermal": len(sp.get("thermal") or []),
        "esd": len(sp.get("esd") or []),
        "pins": len(doc.get("pin_configuration") or []),
        "scope": sp.get("scope"), "identity": bi.get("identity"),
        "identity_state": bi.get("identity_state"),
        "core_sha256": (doc.get("metadata") or {}).get("core_sha256"),
        "digest_stamped": digest["stamped"],
        "digest_changed": digest["changed"],
        "datasheet_url": bi.get("datasheet_url") or bi.get("device_datasheet_url") or "",
        "datasheet_url_source": bi.get("datasheet_url_source", ""),
        "temperature": (sp.get("temperature") or {}).get("operating"),
        "verified_rows": sum(1 for e in (sp.get("electrical") or [])
                             if isinstance(e, dict) and e.get("verification")),
        "normalize": {k: v for k, v in norm.items() if k != "pdf"},
        "core_validation": core["recomputed"],
        "core_validation_at_parse": core["at_parse"],
        "quarantine_count": core["quarantine_count"],
        "langs": have_langs,
        "alts": alt_note,
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="装配交付验收根")
    ap.add_argument("--src", required=True, help="本次解析输出目录")
    ap.add_argument("--out", required=True, help="验收根输出目录（必须干净或加 --force）")
    ap.add_argument("--carry", default="", help="缺件时沿用的旧 parsed 目录")
    ap.add_argument("--alts-from", default="", help="替代料侧车来源目录（不填则不产出 alts）")
    ap.add_argument("--langs", default=",".join(LANGS))
    ap.add_argument("--pdf-dir", default="data/pdfs", help="源 PDF 目录（归一读温度用）")
    ap.add_argument("--normalize", action="store_true",
                    help="落盘前跑确定性归一（温度单位/应力归位/核验状态/区间）")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--keep-out", action="store_true",
                    help="不清空输出目录（第二趟重渲染用：事实表结论已在 out/ 里）")
    ap.add_argument("--mpns", default="",
                    help="逗号分隔的型号清单（按 JSON 的 basic_info.mpn 匹配）；"
                         "留空 = 沿用写死的客户五件。规模化灰度必须显式给，"
                         "否则永远只装配那五件。")
    a = ap.parse_args(argv)

    src, out = Path(a.src), Path(a.out)
    if not src.is_dir():
        print(f"源目录不存在：{src}", file=sys.stderr)
        return 2
    if out.exists():
        if not (a.force or a.keep_out):
            print(f"{out} 已存在；加 --force 覆盖（或 --keep-out 原地重渲染）",
                  file=sys.stderr)
            return 2
        if not a.keep_out:
            shutil.rmtree(out)

    fresh = _index(src)
    carry_dir = Path(a.carry) if a.carry else None
    carried = _index(carry_dir) if carry_dir and carry_dir.is_dir() else {}
    alts_from = Path(a.alts_from) if a.alts_from else None
    pdf_dir = Path(a.pdf_dir) if a.pdf_dir else None
    langs = tuple(x.strip() for x in a.langs.split(",") if x.strip())

    records, missing = [], []
    wanted = tuple(x.strip() for x in a.mpns.split(",") if x.strip()) or MPNS
    for mpn in wanted:
        if mpn in fresh:
            rec = stage_one(mpn, fresh[mpn], out, alts_from, langs, "fresh",
                            pdf_dir=pdf_dir, normalize=a.normalize)
        elif mpn in carried:
            rec = stage_one(mpn, carried[mpn], out, alts_from, langs, "carry",
                            reason="本次解析判为 User Guide / Quick Start，跳过 LLM；"
                                   "沿用指定旧目录产物",
                            pdf_dir=pdf_dir, normalize=a.normalize)
        else:
            missing.append(mpn)
            continue
        records.append(rec)
        print(f"{mpn:<18} {rec['source']:<6} elec={rec['electrical']:<3} "
              f"pins={rec['pins']:<4} thermal={rec['thermal']} esd={rec['esd']} "
              f"verif={rec['verified_rows']:<3} temp={rec['temperature']!r:<20} "
              f"url={rec['datasheet_url_source']:<10} langs={len(rec['langs'])}")

    (out / "_stage_report.json").write_text(json.dumps({
        "generated": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "src": str(src), "carry": str(carry_dir) if carry_dir else "",
        "alts_from": str(alts_from) if alts_from else "",
        "records": records, "missing": missing,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"\n{len(records)} 件 -> {out}")
    if missing:
        print(f"缺件（不在包内）：{', '.join(missing)}")
    return 0 if not missing else 1


if __name__ == "__main__":
    raise SystemExit(main())
