#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立哈希复核：从**全新 clone 的发布仓库**取 ZIP，重算成员原始字节哈希，与签核对账。

为什么不复用包内自检
--------------------
`包校验报告.json` 与 `signoff.json` 里的哈希，都是打包器自己算出来又自己写进去的。
复核方有权问一句：「你怎么证明这不是打包器跟自己核对了一遍？」
所以这里换一条**完全独立**的路径取证：

    git clone 发布仓库（拿的是仓库里的字节，不碰打包工作区、不碰内存缓存）
      → 定位 part-0001-of-0001.zip
      → 解压到独立目录
      → 对解压出来的文件算 sha256（与系统 `sha256sum` 同口径）
      → 与 signoff.final.json::binding 的 **raw** 值逐项比对

三点口径说明（不写清就会各说各话）
----------------------------------
1. **只核 raw**。解压出来的就是原始字节，所以这里对的是 `*_sha256_raw`。
   `*_sha256_normalized` 是给「`git clone` 后直接读外层文本」的场景用的
   （Windows 会把 LF 写成 CRLF），两者自 V3 起分别命名，不互相冒充。
2. **不记录 ZIP 自身的哈希**。本脚本的输出会被打进 ZIP 当作随包附件；
   往 ZIP 里写自己的哈希就是自指死循环。ZIP 的哈希在 `包校验报告.json::zip_sha256`
   与 `signoff.final.json::package_sha256` 里，由复核方在包外重算。
3. **被核成员不随打包变化**。`facts_audit.json` / `risk_queue.csv` 是验收根的输入，
   加一个附件重新打包不会改动它们的字节 —— 所以本记录的结论对最终 ZIP 同样成立，
   复核方解压最终 ZIP 重跑一遍会得到同一组值。

用法
----
    python qc/verify_hash_record.py --repo data/_hashcheck_clone \
                                    --pkg delivery-batch20-eval-V3-RELEASE-V3.1 \
                                    --out 独立哈希复核记录.txt
    # `--repo` 必须是 git clone 出来的目录，不是打包工作区；脚本会拒绝非仓库路径。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

#: 要核的成员：包内路径 → `signoff.final.json::binding` 里的键前缀。
TARGETS = (("facts_audit.json", "facts_audit"),
           ("risk_queue.csv", "risk_queue"))


def _sha(p: Path) -> str:
    """原始字节 sha256 —— 与 `sha256sum` 逐字节同口径。"""
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _git(repo: Path, *args: str) -> str:
    out = subprocess.run(["git", "-C", str(repo), *args],
                         capture_output=True, text=True, check=False)
    if out.returncode != 0:
        raise SystemExit(f"git {' '.join(args)} 失败：{out.stderr.strip()[:300]}")
    return out.stdout.strip()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="独立哈希复核记录生成")
    ap.add_argument("--repo", required=True, help="git clone 出来的发布仓库目录")
    ap.add_argument("--pkg", required=True, help="包目录名，如 delivery-...-V3.1")
    ap.add_argument("--out", required=True, help="记录 txt 的输出路径")
    ap.add_argument("--public-url", default="",
                    help="发布仓库的公开 URL。取证时若从本地克隆，这里补上公开地址，" 
                         "否则记录里只有本机路径，复核方无从追溯。")
    a = ap.parse_args(argv)

    repo = Path(a.repo).resolve()
    if not (repo / ".git").exists():
        raise SystemExit(f"{repo} 不是 git 仓库 —— 本脚本只接受 clone 出来的副本，"
                         "不接受打包工作区（在工作区里算等于自证）。")

    log: list[str] = []

    def say(s: str = "") -> None:
        log.append(s)
        print(s)

    pkg = repo / a.pkg
    z = pkg / "part-0001-of-0001.zip"
    fin = pkg / "signoff.final.json"
    for need in (z, fin):
        if not need.is_file():
            raise SystemExit(f"缺文件：{need}")

    say("独立哈希复核记录")
    say("=" * 72)
    say(f"生成时间   : {datetime.now().astimezone().isoformat(timespec='seconds')}")
    say(f"复核方法   : 全新 git clone → 解压 ZIP → 对解压出的文件算原始字节 SHA-256")
    _origin = _git(repo, "remote", "get-url", "origin")
    say(f"取证 clone  : {_origin}")
    if a.public_url:
        say(f"发布仓库 URL : {a.public_url}")
    elif _origin.startswith(("http://", "https://", "git@")):
        say(f"发布仓库 URL : {_origin}")
    else:
        say("发布仓库 URL : （未提供；取证从本机路径克隆，复核方以包所在的公开仓库为准）")
    say(f"clone commit: {_git(repo, 'rev-parse', 'HEAD')}")
    say(f"包名       : {a.pkg}")
    # 不写 ZIP 字节数：重打包会让它变化，而本记录核对的是**成员**哈希。
    # 写进去就成了一个必然过期的数字，比不写更坏。
    say("ZIP        : part-0001-of-0001.zip（本记录加入包内之前的那一版）")
    say("")
    say("口径声明")
    say("-" * 72)
    say("· 本记录只核 **raw（原始字节）** —— 解压出来的就是原始字节，与 sha256sum 同口径。")
    say("· 本记录**不**记录 ZIP 自身的 SHA-256：本文件会被打进 ZIP，写进去即自指。")
    say("  ZIP 的哈希见 包校验报告.json::zip_sha256 与 signoff.final.json::package_sha256，")
    say("  由复核方在包外重算。")
    say("· facts_audit.json / risk_queue.csv 是验收根的输入，加附件重新打包不会改动")
    say("  它们的字节，故本结论对最终 ZIP 同样成立；复核方解压最终 ZIP 重跑会得到同一组值。")
    say("· 本记录生成于其被加入包内**之前**：加入本附件会使 ZIP 与提交号前进一次，")
    say("  但那一次提交不触碰被核的两个成员。此处记录的是取证时点的 clone commit，")
    say("  不是最终发布提交 —— 后者无法写进被它包含的文件里（同一条自指约束）。")
    say("")

    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        missing = [n for n, _ in TARGETS if n not in names]
        if missing:
            raise SystemExit(f"ZIP 内缺成员：{missing}")
        tmp = Path(tempfile.mkdtemp(prefix="hashrec_"))
        try:
            zf.extractall(tmp)
            binding = (json.loads(fin.read_text(encoding="utf-8")) or {}).get("binding") or {}
            say(f"ZIP 成员数 : {len(names)}（本记录尚未计入；最终包多 1 个成员，即本文件）")
            say("")
            say(f"{'成员':<20}{'解压实测 sha256（raw）':<66}{'signoff.final 记的':<20}{'结论'}")
            say("-" * 72)
            ok = True
            for member, stem in TARGETS:
                got = _sha(tmp / member)
                want = str(binding.get(f"{stem}_sha256_raw") or "")
                same = got == want
                ok = ok and same
                say(f"{member:<20}{got:<66}{want[:16] + '…':<20}"
                    f"{'一致' if same else '不一致'}")
                # 顺带把归一值也列出来：读者看到两组不同值时不至于误判为「绑错文件」
                norm_rec = str(binding.get(f"{stem}_sha256_normalized") or "")
                say(f"{'':<20}{'（归一 normalized 口径，非本记录核对项）':<66}"
                    f"{norm_rec[:16] + '…'}")
            say("")
            say("=" * 72)
            if ok:
                say("结论：PASS —— 从 clone 取出的 ZIP 内两个成员，其原始字节 SHA-256")
                say("      与 signoff.final.json::binding 记录的 raw 值逐字节一致。")
                say("      链式绑定（signoff → facts/risk → ZIP → 包校验报告）无断点。")
            else:
                say("结论：FAIL —— 存在不一致项，签名与包内容不可视为同一批产物。")
            say("")
            say("复核方可自行重跑（不使用本包任何脚本结果，仅用 git 与 sha256sum）：")
            say("  git clone <repo> && cd <repo>")
            say(f"  git checkout {_git(repo, 'rev-parse', 'HEAD')}   # 本记录取证的那次提交")
            say("  cd " + a.pkg)
            say("  unzip -o part-0001-of-0001.zip -d /tmp/x")
            say("  sha256sum /tmp/x/facts_audit.json /tmp/x/risk_queue.csv")
            say("  python -c \"import json;print(json.load(open('signoff.final.json'))['binding'])\"")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(log) + "\n", encoding="utf-8")
    print(f"\n记录已写入 {out}（{out.stat().st_size:,} 字节）")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
