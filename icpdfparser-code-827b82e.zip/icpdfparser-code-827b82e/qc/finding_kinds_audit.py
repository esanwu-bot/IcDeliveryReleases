#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫四处源码，列出实际产出的 kind/code，与 qc/finding_kinds.py 注册表比对。

提取方式全部来自 ``qc/finding_kinds.py::ENGINE_SOURCES``，与测试共用同一份
配置——避免「审计脚本扫 A、测试扫 B」两边口径漂移。

用法：
    python qc/finding_kinds_audit.py
    python qc/finding_kinds_audit.py --strict   # 有未注册即退出码 1
    python qc/finding_kinds_audit.py --json     # 机读
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import finding_kinds as FK            # noqa: E402


def _sample_of(expr: str) -> str:
    """把 ``'ART_%s_MISSING' % key.upper()`` 还原成可校验的样例串。"""
    m = __import__("re").match(r"""^['"](.+)['"]\s*%\s*(.+)$""", expr.strip())
    if not m:
        return ""
    body, arg = m.group(1), m.group(2)
    return body.replace("%s", "XX" if "upper" in arg else "X")


def _engine_report(engine: str, cfg: dict) -> dict:
    actual, dyn = FK.scan_engine(engine)
    registered = FK._KNOWN[engine]                    # noqa: SLF001
    allowed = FK.DYNAMIC_ALLOWED.get(engine, {})
    covered = {d for d in dyn if FK.is_auto_qc_code(_sample_of(d) or d)}
    unknown = sorted(actual - registered)
    stale = sorted(registered - actual)
    return {
        "engine": engine,
        "path": cfg["path"],
        "how": "%s:%s" % (cfg["how"], cfg.get("key") or cfg.get("func")),
        "actual": sorted(actual),
        "registered_count": len(registered),
        "unknown": unknown,
        "stale": stale,
        "dynamic": sorted(dyn),
        "dynamic_allowed": sorted(set(dyn) & set(allowed)),
        "dynamic_uncovered": sorted(set(dyn) - covered - set(allowed)),
        "lower_bound": FK.LOWER_BOUNDS.get(engine, 0),
    }


def _print_engine(r: dict) -> None:
    print("\n=== %s  (%s, %s) ===" % (r["engine"], r["path"], r["how"]))
    print("  源码实测：%d 个（下界 %d）" % (len(r["actual"]), r["lower_bound"]))
    print("  注册表：  %d 个" % r["registered_count"])
    if r["unknown"]:
        print("  [X] 未注册（需补）：%s" % r["unknown"])
    if r["stale"]:
        print("  [!] 已注册但源码未出现（可能废弃）：%s" % r["stale"])
    if r["dynamic"]:
        print("  [i] 动态产出点：")
        for d in r["dynamic"]:
            if d in r["dynamic_allowed"]:
                why = FK.DYNAMIC_ALLOWED.get(r["engine"], {}).get(d, "")
                print("      %s  (已登记：%s)" % (d, why[:60]))
            else:
                flag = "" if d not in r["dynamic_uncovered"] else "  <-- 未覆盖"
                print("      %s%s" % (d, flag))
    if not r["unknown"] and not r["stale"] and not r["dynamic_uncovered"]:
        print("  [OK] 完全一致")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="finding kind 注册表 vs 源码 盘点")
    ap.add_argument("--strict", action="store_true", help="有未注册即退出码 1")
    ap.add_argument("--json", action="store_true", help="机读输出")
    args = ap.parse_args(argv)

    reports = {e: _engine_report(e, cfg) for e, cfg in FK.ENGINE_SOURCES.items()}

    # 消费侧
    at_path, at_var = FK.ACTION_TEMPLATES_SOURCE
    at_keys = FK.scan_action_kinds(ROOT / at_path)
    at_unknown = sorted(at_keys - FK.PRODUCERS)
    reports["action_templates"] = {
        "engine": "action_templates",
        "path": at_path,
        "how": "dict_keys:%s" % at_var,
        "actual": sorted(at_keys),
        "unknown": at_unknown,
        "stale": [],
        "dynamic": [],
        "dynamic_uncovered": [],
    }

    # LLM 词表
    llm_keys = FK.scan_llm_prompt_kinds(ROOT / FK.LLM_PROMPT_SOURCE[0])
    reports["llm_prompt"] = {
        "engine": "llm_prompt",
        "path": FK.LLM_PROMPT_SOURCE[0],
        "how": "regex:RULES_TEXT",
        "actual": sorted(llm_keys),
        "unknown": sorted(llm_keys - FK.LLM_KINDS),
        "stale": sorted(FK.LLM_KINDS - llm_keys),
        "dynamic": [],
        "dynamic_uncovered": [],
    }

    bad = False
    if args.json:
        print(json.dumps(reports, ensure_ascii=False, indent=2))
    else:
        for eng in FK.ENGINE_SOURCES:
            _print_engine(reports[eng])
            bad |= bool(reports[eng]["unknown"]
                        or reports[eng]["dynamic_uncovered"])

        print("\n=== ACTION_TEMPLATES 键 ⊆ 生产侧 ===")
        print("  实测：%d 个键" % len(at_keys))
        if at_unknown:
            print("  [X] 有模板但没有生产侧（永远不会命中）：%s" % at_unknown)
            bad = True
        else:
            print("  [OK] 每个 action 模板都有对应生产侧")

        print("\n=== LLM 词表 ===")
        r = reports["llm_prompt"]
        print("  实测：%d 个" % len(r["actual"]))
        if r["unknown"]:
            print("  [X] 提示词里有未注册：%s" % r["unknown"])
            bad = True
        if r["stale"]:
            print("  [!] 注册表有但提示词未列：%s" % r["stale"])
        if not r["unknown"] and not r["stale"]:
            print("  [OK] 完全一致")

        print("\n=== 已登记分歧（%d 条，只登记不改行为）===" % len(FK.CONFLICTS))
        for c in FK.CONFLICTS:
            print("  - [%s] %s" % (c["kind"], c["id"]))
            print("      影响：%s" % c["impact"])
            print("      处置：%s" % c["fix"])

        print("\n结论：%s" % ("通过" if not bad else "有未注册/未覆盖项，见上方 [X]"))

    return 1 if (args.strict and bad) else 0


if __name__ == "__main__":
    sys.exit(main())
