"""高风险字段分类器（batch-verify 准入清单）。

口径（《人工核验落实手册》§3.1 + 执行计划 §4.2 对齐）：身份 / 封装 / 量纲(电流) /
电源范围 / 关键电气 / 脚注关联 / 电源脚 / 方向脚 / 极限供电 = 高风险；
其余（叙述类、非电源引脚、非关键电气）可批量确认。

纯函数：无 IO、无 stdout 副作用（server 进程安全，与 qc/goldset.py 同口径）。
规则化判定，**禁止逐型号硬编码**。
"""
from __future__ import annotations

import re

CUR_RE = re.compile(r"\b(current|icc|idd|ioff|ion|iavdd|idvdd|ioidd|iddq|ibias|ileak|"
                    r"leakage|quiescent|ios|iout|iin|io|ib|if)\b", re.I)
SUPPLY_RE = re.compile(r"\b(vcc|vdd|vss|vee|vin|vout|supply|vref|voltage)\b", re.I)
KEY_ELEC_RE = re.compile(r"\b(bandwidth|slew|resolution|inl|dnl|monotonic|gain|offset|"
                         r"settling|accuracy|fsr|noise|thd|drift|tempco|psrr)\b", re.I)
POWER_PIN_RE = re.compile(r"^(vdd|vcc|vee|vss|gnd|v\+|v-|v−|avdd|dvdd|iovdd|vref|vrefh|vrefl|"
                          r"vref\+|vref-|vssa|vdda|vccx|vddx)$", re.I)
# 方向/时序/接口脚：方向语义来自真值表或接口时序，错接即功能失效
DIR_PIN_RE = re.compile(r"\b(dir|direction|t/?r|oe|en|enable|ce|clk|sclk|scl|sda|din|dout|sync)\b",
                        re.I)
ARROW_RE = re.compile(r"(→|->|↔|<->)")
UNIT_CURRENT = {"µA", "uA", "mA", "A", "nA"}

REASON_TEXT = {
    "identity": "身份字段（mpn/manufacturer）：订购表 literal 为准，quote 必填",
    "package": "封装字段：Ordering 行 + 外形图互证，quote 必填",
    "current_dim": "电流量纲行（µA/mA 易混 mW）：单位列 quote 必填",
    "supply_range": "电源范围行：MIN/MAX 双列核对",
    "key_electrical": "关键电气（带宽/静态电流/分辨率/增益/失调等）",
    "footnote_link": "脚注关联行：证据必须带脚注原文",
    "power_pin": "电源脚名：引脚图 quote 必填",
    "direction_pin": "方向/使能/时钟脚：真值表回显核对",
    "abs_limit": "极限供电行：stress 注记核对",
}
HIGH_RISK_BATCH_POLICY = ("高风险字段禁止 batch-verify：走单字段 verify 且证据含原文 quote；"
                          "批量接口对高风险行返回 rejected(high_risk:*)")


def classify(field_path: str, param_name: str = "", unit: str = "",
             draft_name: str = "", draft_desc: str = "",
             columns: dict | None = None, footnotes: list | None = None) -> list[str]:
    """返回命中码列表（空 = 可批量确认）。

    兼容两代 field_path：`electrical[i].value`（线上）与 `specs.electrical[i].value`（旧）。
    """
    p = (field_path or "").strip()
    pn, dn, dd = (param_name or ""), (draft_name or ""), (draft_desc or "")
    r: list[str] = []
    if p in ("basic_info.mpn", "basic_info.manufacturer"):
        r.append("identity")
    if p.startswith("specs.package"):
        r.append("package")
    if re.match(r"^(specs\.)?electrical\[\d+\]", p):
        if unit in UNIT_CURRENT or CUR_RE.search(pn):
            r.append("current_dim")
        if SUPPLY_RE.search(pn):
            r.append("supply_range")
        if KEY_ELEC_RE.search(pn):
            r.append("key_electrical")
        if footnotes:
            r.append("footnote_link")
    if re.match(r"^(pin|pin_configuration)\[", p):
        # pin 字段的 field_name 恒为 "pin"，引脚名在草稿值（expected）里
        name = (dn or pn or "").strip()
        if POWER_PIN_RE.match(name):
            r.append("power_pin")
        if DIR_PIN_RE.search(pn) or DIR_PIN_RE.search(dn) or ARROW_RE.search(dd):
            r.append("direction_pin")
    if re.match(r"^specs\.(absolute_max|esd)\[\d+\]", p) and SUPPLY_RE.search(pn):
        r.append("abs_limit")
    return r


def is_high_risk(field_path: str, **kw) -> bool:
    return bool(classify(field_path, **kw))


def reason_text(codes) -> str:
    return "；".join(REASON_TEXT.get(c, c) for c in (codes or []))