"""review → fix 闭环的状态推导与批次物化。

为什么要单独一个模块
--------------------
review 与 fix 是两个任务、两处落盘（`data/qc/reviews/*.review.json`、
`data/qc/fix_plans/*.fix_plan.log.jsonl`）。对外状态**只看最近一次复审报告**
（`qc/review_status.py` 的纯函数推导）：

    P0 > 0          → REVIEWED_BLOCKED      阻断交付
    P0 = 0, P1 > 0  → REVIEWED_STILL_WARN   警告待人工
    P0 = 0, P1 = 0  → REVIEWED_QA_PASS      机器检查通过（仍待人工验收）
    证据不足/报告无效/旧格式无法识别 → INCOMPLETE / LEGACY_UNRESOLVED

修复动作**不再是**状态依据：`fix_applied` / `fixes` 只作旁证。旧口径
「修过 + 修后重审 PASS/WARN 就算已修复」会让「复审仍 FAIL」和「只剩 P1」都混进
同一个绿色标签，交付历史因此看不出哪件还被阻断——这正是要拆掉的东西。

`internal` 保留为内部诊断态（未审 / 待修 / 修了未验 / 跑满轮次未收敛），
不进列表筛选，只用于说明「为什么现在是这个状态」。

本模块只依赖标准库 + `qc.review_status`，不 import app.* / pymupdf，
常驻进程引用无副作用。
"""
from __future__ import annotations

import csv
import datetime
import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import Path

from qc import review_status as RS

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------- 状态口径
# 交付状态全部来自 review_status（唯一口径），这里只做转出，不另立常量。
STATUS_BLOCKED = RS.STATUS_BLOCKED
STATUS_STILL_WARN = RS.STATUS_STILL_WARN
STATUS_QA_PASS = RS.STATUS_QA_PASS
STATUS_INCOMPLETE = RS.STATUS_INCOMPLETE
STATUS_LEGACY_UNRESOLVED = RS.STATUS_LEGACY_UNRESOLVED
STATUS_LABELS = RS.STATUS_LABELS
DELIVERY_STATUSES = tuple(RS.STATUS_LABELS)

# 内部推导态（不外露为列表状态，仅用于汇总/排查）
NOT_REVIEWED = "NOT_REVIEWED"
REVIEWED_NEEDS_FIX = "REVIEWED_NEEDS_FIX"
FIXED_UNVERIFIED = "FIXED_UNVERIFIED"
FIXED_NOT_CONVERGED = "FIXED_NOT_CONVERGED"
FIXED_STILL_FAIL = "FIXED_STILL_FAIL"
REVIEWED_CLEAN = "REVIEWED_CLEAN"

_SAFE_RE = re.compile(r"[^A-Za-z0-9._-]")
_BATCH_PREFIX = "rf"
_INDEX_NAME = "review_fix_index.json"
ZIP_NAME = "review_fix.zip"


def label(code: str) -> str:
    return RS.label(code)


def safe_stem(mpn: str) -> str:
    """与 worker/tasks.py `_safe()`、review.py `_safe_stem()` 完全同口径。"""
    return _SAFE_RE.sub("_", str(mpn or "")).upper()


# ---------------------------------------------------------------- 路径/读取
def reviews_dir(base: Path | str) -> Path:
    return Path(base) / "reviews"


def plans_dir(base: Path | str) -> Path:
    return Path(base) / "fix_plans"


def index_path(base: Path | str) -> Path:
    return Path(base) / _INDEX_NAME


def read_review(base: Path | str, mpn: str) -> dict:
    p = reviews_dir(base) / ("%s.review.json" % safe_stem(mpn))
    if not p.is_file():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


def read_fix_log(base: Path | str, mpn: str) -> list[dict]:
    p = plans_dir(base) / ("%s.fix_plan.log.jsonl" % safe_stem(mpn))
    if not p.is_file():
        return []
    out = []
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(rec, dict):
                out.append(rec)
    except OSError:
        return []
    return out


def _ts(v) -> datetime.datetime | None:
    """ISO 时间串 → aware datetime；解析不了返回 None（退化为字符串比较由调用方兜）。"""
    s = str(v or "").strip()
    if not s:
        return None
    try:
        d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=datetime.timezone.utc)


def _newer(a: str, b: str) -> bool:
    """a 是否晚于 b（都用 ISO 串；解析失败退化为字符串比较）。"""
    da, dbb = _ts(a), _ts(b)
    if da and dbb:
        return da > dbb
    return str(a or "") > str(b or "")


# ---------------------------------------------------------------- 状态推导
def derive(base: Path | str, mpn: str) -> dict:
    """推导单型号状态：交付状态只看最近一次复审报告，修复时间线作旁证。

    字段（交付消费方只看 status_code / status_label / p0 / p1）：
      status_code   REVIEWED_BLOCKED / REVIEWED_STILL_WARN / REVIEWED_QA_PASS /
                    INCOMPLETE / LEGACY_UNRESOLVED（`status` 是同一值的旧名）
      p0 / p1 / p2 / advisory
                    有效计数；advisory（证据闸降级的参考项）与缺 severity 的条目
                    不进 P0/P1
      incomplete_checks
                    报告齐全性/自洽性未通过的检查数（>0 即证据不完整）
      fix_applied / fixes
                    是否**真的**改过（fix log `event=apply` 且 `changed` 非空）
      internal      NOT_REVIEWED / REVIEWED_NEEDS_FIX / REVIEWED_CLEAN /
                    FIXED_UNVERIFIED / FIXED_NOT_CONVERGED / FIXED_STILL_FAIL
      status_stale  最近一次复审早于最后一次修复（判定还没跟上改动）
      verdict_before / verdict_after / round / fixed_at / reviewed_at
    """
    base = Path(base)
    rv = read_review(base, mpn)
    log = read_fix_log(base, mpn)

    applies = [r for r in log if r.get("event") == "apply"]
    effective = [r for r in applies if isinstance(r.get("changed"), list) and r["changed"]]
    dispatches = [r for r in log if r.get("event") == "dispatch"]
    # 跑满轮次仍未收敛 → finalize 里带 promoted（转 customer_feedback_issue）
    promoted = ""
    for r in log:
        if r.get("event") != "finalize":
            continue
        p = r.get("promoted")
        if isinstance(p, dict) and p.get("ok"):
            promoted = str(p.get("issue_key") or "")

    reviewed_at = str(rv.get("generated_at") or "")
    verdict = str(rv.get("verdict") or "").upper()
    ana = RS.analyze(rv)
    out: dict = {
        "mpn": str(mpn),
        "safe": safe_stem(mpn),
        "reviewed": bool(rv),
        "reviewed_at": reviewed_at,
        "verdict": verdict,
        "verdict_before": "",
        "verdict_after": "",
        "findings": len(rv.get("rule_findings") or []) + len(rv.get("llm_findings") or []),
        "p0": ana["p0"],
        "p1": ana["p1"],
        "p2": ana["p2"],
        "advisory": ana["advisory"],
        "incomplete_checks": ana["incomplete_checks"],
        "checks": ana["checks"],
        "report_format": ana["format"],
        "status_reason": ana["reason"],
        "status_rule_version": ana["status_rule_version"],
        "rule_version": ana["rule_version"],
        "fix_applied": bool(effective),
        "fixes": 0,
        "round": 0,
        "fixed_at": "",
        "status": ana["status_code"],
        "status_code": ana["status_code"],
        "status_label": ana["status_label"],
        "status_stale": False,
        "internal": "",
        "promoted_issue": promoted,
    }
    if not rv:
        out["internal"] = NOT_REVIEWED
        return out

    fixed_at = str(effective[-1].get("ts") or "") if effective else ""
    out["fixes"] = sum(len(r.get("changed") or []) for r in effective)
    out["round"] = max([int(r.get("round") or 0) for r in log] or [0])
    out["fixed_at"] = fixed_at
    # 修前判定：最后一次「不晚于 fixed_at」的 dispatch 里记的 verdict
    before = ""
    for r in dispatches:
        if not fixed_at or not _newer(str(r.get("ts") or ""), fixed_at):
            before = str(r.get("verdict") or "").upper()
    out["verdict_before"] = before

    post = bool(reviewed_at and fixed_at and _newer(reviewed_at, fixed_at))
    if post:
        out["verdict_after"] = verdict

    if not effective:
        out["internal"] = (REVIEWED_CLEAN
                           if out["status_code"] == STATUS_QA_PASS
                           else REVIEWED_NEEDS_FIX)
        return out

    if not post:
        # 跑满轮次已转人工的，不能显示成「等待重审」——那会让人以为还会自动跑
        out["internal"] = FIXED_NOT_CONVERGED if promoted else FIXED_UNVERIFIED
        out["status_stale"] = True
        return out

    if out["status_code"] == STATUS_BLOCKED:
        out["internal"] = FIXED_STILL_FAIL
    return out


def _iter_mpns(base: Path) -> list[str]:
    """从 review 报告目录列出被审过的型号（报告内 mpn 优先，文件名退化）。"""
    d = reviews_dir(base)
    if not d.is_dir():
        return []
    out = []
    for f in sorted(d.glob("*.review.json")):
        try:
            d0 = json.loads(f.read_text(encoding="utf-8"))
            mpn = str(d0.get("mpn") or "").strip()
        except (OSError, json.JSONDecodeError):
            mpn = ""
        if not mpn:
            mpn = f.name[: -len(".review.json")]
        if mpn:
            out.append(mpn)
    return out


def scan(base: Path | str) -> list[dict]:
    base = Path(base)
    return [derive(base, m) for m in _iter_mpns(base)]


def summary(base: Path | str) -> dict:
    """按交付状态计数（阻断/警告/通过/证据不完整），并给出成批缺口。"""
    rows = scan(base)
    by: dict[str, int] = {}
    for r in rows:
        k = r["internal"] or r["status_code"]
        by[k] = by.get(k, 0) + 1
    idx = load_index(base)
    assigned = idx.get("assigned") or {}
    by_status = RS.counts(rows)
    return {
        "status_rule_version": RS.STATUS_RULE_VERSION,
        "reviewed": len(rows),
        "by_status": by_status,
        "blocked": by_status[STATUS_BLOCKED],
        "still_warn": by_status[STATUS_STILL_WARN],
        "qa_pass": by_status[STATUS_QA_PASS],
        "incomplete": by_status[STATUS_INCOMPLETE] +
                      by_status[STATUS_LEGACY_UNRESOLVED],
        "batched": sum(1 for r in rows if r["mpn"] in assigned),
        "pending": sum(1 for r in rows if r["mpn"] not in assigned),
        "batches": len(idx.get("batches") or {}),
        "by_state": by,
    }


# ---------------------------------------------------------------- 批次索引
def load_index(base: Path | str) -> dict:
    p = index_path(base)
    if not p.is_file():
        return {"version": 1, "batches": {}, "assigned": {}}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"version": 1, "batches": {}, "assigned": {}}
    if not isinstance(d, dict):
        return {"version": 1, "batches": {}, "assigned": {}}
    d.setdefault("version", 1)
    d.setdefault("batches", {})
    d.setdefault("assigned", {})
    return d


def save_index(base: Path | str, idx: dict) -> None:
    p = index_path(base)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(idx, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def next_batch_id(base: Path | str, idx: dict | None = None,
                  date: str = "") -> str:
    """生成 `rf-YYYYMMDD-NNN`（同日递增，跳过已存在的目录）。"""
    idx = idx if idx is not None else load_index(base)
    day = (date or datetime.date.today().strftime("%Y-%m-%d")).replace("-", "")
    used = set((idx.get("batches") or {}).keys())
    seq = 0
    for bid in used:
        m = re.fullmatch(r"%s-%s-(\d+)" % (_BATCH_PREFIX, day), bid)
        if m:
            seq = max(seq, int(m.group(1)))
    while True:
        seq += 1
        bid = "%s-%s-%03d" % (_BATCH_PREFIX, day, seq)
        if bid not in used and not (Path(base) / bid).exists():
            return bid


# ---------------------------------------------------------------- 分批
def chunk(items: list[dict], size: int = 30) -> list[list[dict]]:
    size = max(1, int(size or 30))
    return [items[i:i + size] for i in range(0, len(items), size)]


def pending(base: Path | str, idx: dict | None = None) -> list[dict]:
    """还没进任何批次的**已 review** 型号，按修复/复审时间升序。

    不再只挑「已修复」：未收敛件也要能进批次（V1 如实标阻断，修好后再出 V2），
    否则阻断件永远进不了交付历史，也就无从展示收敛曲线。
    """
    idx = idx if idx is not None else load_index(base)
    assigned = idx.get("assigned") or {}
    rows = [r for r in scan(base)
            if r["reviewed"] and r["mpn"] not in assigned]
    rows.sort(key=lambda r: (r["fixed_at"] or r["reviewed_at"], r["mpn"]))
    return rows


# ---------------------------------------------------------------- 产物收集
# 单型号交付口径：每型号一个目录，目录名用清洗后的 stem，型号里的 `/` 归一成 `_`。
# 与 `pack_batch_dirs.py`（人工按批出包）保持同一套文件清单与同一份 provenance。
_ITEM_SPEC = (
    ("pdf", "pdfs", ("%s.pdf",), ".pdf"),
    ("json", "parsed", ("%s.json",), ".json"),
    ("txt", "txt", ("%s.txt",), ".txt"),
    ("alt_json", "alts", ("%s.json",), ".alts.json"),
    ("alt_html", "alts", ("%s.html",), ".alts.html"),
    ("symbol", "symbols", ("%s.html",), ".symbols.html"),
    ("seo", "seo", ("%s.json",), ".seo.json"),
)
LANGS = ("ja", "ko", "de", "es")


def _item_files(data_dir: Path, mpn: str) -> list[tuple[str, Path, str]]:
    """单型号可交付产物：[(目标后缀, 源文件, zip 内相对路径)]。缺哪个跳哪个。

    型号里带 `/`（`ADC128D818EB/NOPB`、`DS80PCI402EVK/NOPB`）时，产物文件名用的是
    清洗后的 stem，不是原始 MPN。只按原始 MPN 拼路径会整件漏产物——实测
    `ADC128D818EB/NOPB` 就报 missing_artifacts。所以原始名与清洗名都要试。
    """
    data_dir = Path(data_dir)
    stem = safe_stem(mpn)
    raw = str(mpn or "")
    stems = [s for i, s in enumerate([raw, stem]) if s and s not in [raw, stem][:i]]

    def first(sub: str, pats: tuple[str, ...]) -> Path | None:
        for s in stems:
            for pat in pats:
                f = data_dir / sub / (pat % s)
                if f.is_file():
                    return f
        return None

    def glob_one(sub: str, pat: str) -> Path | None:
        d = data_dir / sub
        if not d.is_dir():
            return None
        for s in stems:
            cands = sorted(d.glob(pat % s))
            if cands:
                return cands[0]
        return None

    out: list[tuple[str, Path, str]] = []
    for key, sub, pats, suffix in _ITEM_SPEC:
        f = first(sub, pats)
        # PDF 落盘名带厂商 slug（`NE555__ne555.pdf`）；解析 JSON 带内容哈希
        if f is None and key == "pdf":
            f = glob_one("pdfs", "%s__*.pdf")
        if f is None and key == "json":
            f = glob_one("parsed", "%s_*.json")
        if f is None:
            continue
        out.append((suffix, f, "%s/%s%s" % (stem, stem, suffix)))

    # 语言变体：与英文正文同目录的 `<stem>.<lang>.txt`
    base = next((f for s, f, _r in out if s == ".txt"), None)
    if base is not None:
        head = base.name[:-len(".txt")]
        for lg in LANGS:
            cand = base.with_name("%s.%s.txt" % (head, lg))
            if cand.is_file():
                out.append((".%s.txt" % lg, cand, "%s/%s.%s.txt" % (stem, stem, lg)))
    return out


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build_provenance(mpn: str, batch: str, meta: dict,
                     files: dict[str, Path]) -> dict:
    """合成 provenance：说清「这份产物怎么来的、修过什么、验到哪一步」。

    `files` 按**目标后缀**做键（`.pdf` / `.json` / `.ja.txt` …），值是落盘文件。
    刻意不写 `human_accepted: true` / `release_approved: true`——自动修复到 PASS
    只代表机器复审通过，值级正确性仍需证据卡与人工验收，发布门禁恒为未批准。
    """
    pdf = files.get(".pdf")
    return {
        "mpn": mpn,
        "generated_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "source": "review-fix batch %s" % (batch or "manual"),
        "pipeline": "auto review → auto fix (worker/fixers.py)",
        "status_code": meta.get("status_code") or "",
        "status_label": meta.get("status_label") or "",
        "status_rule_version": meta.get("status_rule_version") or "",
        "review": {
            "verdict_before": meta.get("verdict_before") or "",
            "verdict_after": meta.get("verdict_after") or "",
            "p0": int(meta.get("p0") or 0),
            "p1": int(meta.get("p1") or 0),
            "incomplete_checks": int(meta.get("incomplete_checks") or 0),
            "rule_version": meta.get("rule_version") or "",
            "reviewed_at": meta.get("reviewed_at") or "",
            "report": meta.get("review_file") or "",
        },
        "fix": {
            "applied": bool(meta.get("fix_applied")),
            "round": int(meta.get("round") or 0),
            "changes": int(meta.get("fixes") or 0),
            "fixed_at": meta.get("fixed_at") or "",
        },
        "pdf": ({"file": pdf.name, "bytes": pdf.stat().st_size,
                 "sha256": _sha256(pdf)} if pdf else {}),
        "files": sorted(p.name for p in files.values()),
        "auto_qc_stage": "post_fix",
        "auto_qc_post_fix": meta.get("verdict_after") or "",
        "human_accepted": False,
        "release_approved": False,
        "note": ("状态按最近一次复审的 P0/P1 推导（阻断 > 警告 > 通过）；即使为"
                 "机器检查通过，也不等于发布批准，值级正确性仍需证据卡与人工验收。"
                 "human_accepted=false 时不应直接上线。"),
    }


def _leaf_count(node, depth: int = 0) -> int:
    """产物 JSON 的叶子字段数（仅作规模参考，不参与门禁）。"""
    if depth > 8:
        return 0
    if isinstance(node, dict):
        return sum(_leaf_count(v, depth + 1) for v in node.values())
    if isinstance(node, list):
        return sum(_leaf_count(v, depth + 1) for v in node)
    return 1


def _manifest_csv(rows: list[dict]) -> str:
    """清单列：状态 + P0/P1 计数 + 证据检查数（都进交付包，便于逐行复核）。"""
    cols = ("mpn", "status_code", "status_label", "p0", "p1", "p2",
            "incomplete_checks", "fix_applied", "fixes", "round",
            "verdict_before", "verdict_after", "fixed_at", "reviewed_at",
            "status_rule_version", "review_file")
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(cols), extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in cols})
    return buf.getvalue()


def _int(v, default: int = 0) -> int:
    """CSV 读回来的计数列是字符串，报告里 `%d` 需要真整数。"""
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def read_batch(batch_dir: Path | str) -> tuple[str, list[dict]]:
    """读批次 manifest.csv → (批次号, 行列表)。重打（rebuild）用。"""
    d = Path(batch_dir)
    f = d / "manifest.csv"
    if not f.is_file():
        raise SystemExit("批次目录里没有 manifest.csv：%s" % d)
    with f.open(encoding="utf-8-sig", newline="") as fh:
        rows = [r for r in csv.DictReader(fh) if (r.get("mpn") or "").strip()]
    return d.name, rows


def _report_md(batch: str, rows: list[dict], meta: dict) -> str:
    cnt = meta.get("status_counts") or {}
    cnt_txt = " / ".join("%s %d" % (label(c), cnt.get(c, 0))
                         for c in RS.ROLLUP_ORDER if cnt.get(c)) or "—"
    lines = [
        "# 自动 review + 自动修复 批次核验报告",
        "",
        "- 批次：`%s`" % batch,
        "- 状态：**%s**（`%s`）" % (meta.get("status_label")
                                   or label(meta.get("status_code") or ""),
                                   meta.get("status_code") or ""),
        "- 型号数：%d（%s）" % (len(rows), cnt_txt),
        "- P0 / P1 合计：%d / %d" % (meta.get("p0_total") or 0,
                                    meta.get("p1_total") or 0),
        "- 生成时间：%s" % meta.get("generated_at", ""),
        "- 推导口径：`%s`" % (meta.get("status_rule_version")
                             or RS.STATUS_RULE_VERSION),
        "",
        "## 口径说明",
        "",
        "单型号状态**只看最近一次复审报告**的有效 findings：P0>0 → `%s`；"
        "P0=0 且 P1>0 → `%s`；P0=0 且 P1=0 → `%s`。advisory（证据闸降级的 LLM"
        "参考项）与 P2 不计；缺 severity、verdict 与计数不自洽、报告缺失/截断的，"
        "一律标 `%s` / `%s`，不默认标绿。修复动作（`fix_applied`/改动处数）只是旁证，"
        "不参与状态判定。"
        % (STATUS_BLOCKED, STATUS_STILL_WARN, STATUS_QA_PASS,
           STATUS_INCOMPLETE, STATUS_LEGACY_UNRESOLVED),
        "",
        "批次状态取最严重的一件：阻断 > 证据缺口 > 警告 > 通过。任何一件证据不完整"
        "都不会让整批变成「通过」。所有状态都**不**等于发布批准：值级正确性仍需"
        "证据卡与人工验收；本批次不走 L1–L4 四层门禁，`RELEASE_APPROVED` 恒为"
        " NOT_CHECKED。",
        "",
        "## 型号清单",
        "",
        "| # | 型号 | 状态 | P0 | P1 | 证据检查 | 修前 | 复审 | 改动 | 轮次 | 修复时间 |",
        "|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for i, r in enumerate(rows, 1):
        inc = _int(r.get("incomplete_checks"))
        lines.append("| %d | `%s` | %s | %d | %d | %s | %s | %s | %d | %d | %s |" % (
            i, r["mpn"],
            r.get("status_label") or label(r.get("status_code"))
            or r.get("status_code") or "—",
            _int(r.get("p0")), _int(r.get("p1")),
            ("OK" if not inc else "%d 项未过" % inc),
            r.get("verdict_before") or "—",
            r.get("verdict_after") or "—", _int(r.get("fixes")),
            _int(r.get("round")), r.get("fixed_at") or "—"))
    lines += ["", "## 附件", "",
              "- `<型号>/`：**每型号一个目录**，内含该型号的全部可交付产物："
              "`<型号>.pdf` 原件、`<型号>.json` 解析结果、`<型号>.txt` 详情页正文"
              "（英 + ja/ko/de/es）、`<型号>.html`（`.txt` 字节同源副本，直接预览用）、"
              "`<型号>.alts.json` / `.alts.html` 替代型号、"
              "`<型号>.symbols.html` 三视图、`<型号>.seo.json` 图片清单、"
              "`<型号>.provenance.json` 来源与修复留痕",
              "- `review/`：每个型号的 review 报告（JSON 原文）",
              "- `%s`：以上全部打包" % ZIP_NAME, ""]
    return "\n".join(lines)


def build_batch(base: Path | str, rows: list[dict], *, batch: str = "",
                data_dir: Path | str | None = None,
                date: str = "", force: bool = False) -> dict:
    """把一个分片物化成交付批次目录（幂等：已存在且非 force 直接跳过）。"""
    base = Path(base)
    data_dir = Path(data_dir) if data_dir else ROOT / "data"
    idx = load_index(base)
    batch = batch or next_batch_id(base, idx, date=date)
    d = base / batch
    if d.exists() and not force:
        return {"batch": batch, "skipped": True, "mpns": len(rows), "path": str(d)}

    d.mkdir(parents=True, exist_ok=True)
    (d / "review").mkdir(exist_ok=True)

    now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    packed: list[tuple[Path, str]] = []
    missing: list[str] = []
    no_pdf: list[str] = []
    landed: dict[str, dict[str, Path]] = {}
    for r in rows:
        safe = safe_stem(r["mpn"])
        rj = reviews_dir(base) / ("%s.review.json" % safe)
        if rj.is_file():
            packed.append((rj, "review/" + rj.name))
        files = _item_files(data_dir, r["mpn"])
        by_suffix = {s: src for s, src, _rel in files}
        if not files:
            missing.append(r["mpn"])
        if ".pdf" not in by_suffix:
            no_pdf.append(r["mpn"])
        packed.extend((src, rel) for _s, src, rel in files)
        # 规模参考：解析 JSON 叶子数
        jf = by_suffix.get(".json")
        if jf:
            try:
                r["fields_total"] = _leaf_count(json.loads(jf.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                r["fields_total"] = 0
        landed[r["mpn"]] = {s: d / rel for s, _src, rel in files}

    for r in rows:
        # 状态只能来自复审推导：调用方没给就按「证据不完整」处理，绝不默认变绿。
        r["status_code"] = RS.normalize(r.get("status_code"))
        r["status_label"] = label(r["status_code"])
        r["status_rule_version"] = RS.STATUS_RULE_VERSION
        r["review_file"] = "review/%s.review.json" % safe_stem(r["mpn"])

    counts = RS.counts(rows)
    batch_code = RS.rollup([r["status_code"] for r in rows])
    open_mpns = [r["mpn"] for r in rows if r["status_code"] != STATUS_QA_PASS]

    meta = {
        "audit_version": 3,
        "delivery_kind": "review_fix",
        "package": "review-fix 批次 %s（%d 型号）" % (batch, len(rows)),
        "generated_at": now,
        "status_code": batch_code,
        "status_label": label(batch_code),
        "status_rule_version": RS.STATUS_RULE_VERSION,
        "status_counts": counts,
        "p0_total": sum(_int(r.get("p0")) for r in rows),
        "p1_total": sum(_int(r.get("p1")) for r in rows),
        "layout": "per_mpn_dir",
        "layers": {},
        "release_approved": False,
        "release_gates": {"RELEASE_APPROVED": {"status": "NOT_CHECKED",
                                              "approved": False}},
        "review_fix": {
            "size": len(rows),
            "fixes_total": sum(int(r.get("fixes") or 0) for r in rows),
            "verdicts_after": _tally(r.get("verdict_after") for r in rows),
            "verdicts_before": _tally(r.get("verdict_before") for r in rows),
            "missing_artifacts": missing[:20],
            "missing_pdf": no_pdf[:20],
            "open_mpns": open_mpns,
            "blocked_mpns": [r["mpn"] for r in rows
                             if r["status_code"] == STATUS_BLOCKED],
            "incomplete_mpns": [r["mpn"] for r in rows
                                if r["status_code"] in (STATUS_INCOMPLETE,
                                                        STATUS_LEGACY_UNRESOLVED)],
        },
    }

    (d / "manifest.csv").write_text(_manifest_csv(rows), encoding="utf-8-sig",
                                    newline="")
    (d / "rf_quality_audit.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    (d / "核验报告.md").write_text(_report_md(batch, rows, meta), encoding="utf-8")

    # 产物落到批次目录（同名覆盖，保证与本次 manifest 一致）
    for src, rel in packed:
        dest = d / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(src, dest)
        except OSError:
            continue

    # provenance 每型号一份，落在自己的目录里（sha256 取落盘后的真实文件）
    for r in rows:
        stem = safe_stem(r["mpn"])
        by_suffix = {s: p for s, p in (landed.get(r["mpn"]) or {}).items() if p.is_file()}
        prov = build_provenance(r["mpn"], batch, r, by_suffix)
        pdir = d / stem
        pdir.mkdir(parents=True, exist_ok=True)
        (pdir / (stem + ".provenance.json")).write_text(
            json.dumps(prov, ensure_ascii=False, indent=2), encoding="utf-8")

    # 旧版按产物类型分的 artifacts/ 目录，重打时清掉，避免两种结构并存
    stale = d / "artifacts"
    if stale.is_dir():
        shutil.rmtree(stale, ignore_errors=True)

    # ZIP：目录内除自身以外的全部文件（先写盘再压缩，保证内容一致）
    # PDF 本身已压缩，用 STORED（与单型号交付包同口径），文本类用 deflate。
    zp = d / ZIP_NAME
    with zipfile.ZipFile(zp, "w") as zf:
        for f in sorted(d.rglob("*")):
            if not f.is_file() or f == zp:
                continue
            comp = zipfile.ZIP_STORED if f.suffix.lower() == ".pdf" \
                else zipfile.ZIP_DEFLATED
            zf.write(f, str(f.relative_to(d)), compress_type=comp)

    idx["batches"][batch] = {
        "size": len(rows),
        "mpns": [r["mpn"] for r in rows],
        "generated_at": now,
        "zip": ZIP_NAME,
        "layout": "per_mpn_dir",
        "bytes": zp.stat().st_size,
        "status_code": batch_code,
        "status_rule_version": RS.STATUS_RULE_VERSION,
        "p0_total": meta["p0_total"],
        "p1_total": meta["p1_total"],
    }
    for r in rows:
        idx["assigned"][r["mpn"]] = batch
    save_index(base, idx)

    return {"batch": batch, "skipped": False, "mpns": len(rows),
            "path": str(d), "zip": zp.name, "bytes": zp.stat().st_size,
            "status_code": batch_code, "status_counts": counts,
            "p0_total": meta["p0_total"], "p1_total": meta["p1_total"],
            "missing_artifacts": missing, "missing_pdf": no_pdf}


def _tally(vals) -> dict:
    out: dict[str, int] = {}
    for v in vals:
        k = str(v or "—")
        out[k] = out.get(k, 0) + 1
    return out


def build_next(base: Path | str, *, size: int = 30, max_batches: int = 1,
               data_dir: Path | str | None = None, date: str = "",
               dry_run: bool = False, force: bool = False) -> dict:
    """把「已 review、还没进批次」的型号，按 `size` 一批物化。

    一次最多 `max_batches` 批，避免一口气铺满磁盘；返回 manifest 供 CLI/接口回显。
    未收敛件也进批次：V1 如实标阻断，修好后再出 V2，便于看收敛曲线。
    """
    base = Path(base)
    idx = load_index(base)
    rows = pending(base, idx)
    groups = chunk(rows, size)[:max(0, int(max_batches))]
    out = {"candidates": len(rows), "size": int(size),
           "planned_batches": len(chunk(rows, size)) if rows else 0,
           "built": [], "skipped_reason": ""}
    if not groups:
        out["skipped_reason"] = "no_pending_reviewed"
        return out
    if dry_run:
        # dry-run 报**全部**待物化分片（不受 max_batches 限制），便于先看总量
        out["dry_run"] = True
        out["plan"] = [{"size": len(g),
                        "mpns": [r["mpn"] for r in g]}
                       for g in chunk(rows, size)]
        return out
    for g in groups:
        out["built"].append(build_batch(base, g, data_dir=data_dir,
                                        date=date, force=force))
    out["remaining"] = len(pending(base, load_index(base)))
    return out
