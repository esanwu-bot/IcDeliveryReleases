#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HANDOFF 2026-10-26 | qc/qc_regression.py 回归与抽样 harness（agent-Qwen 原版落地 + 项目适配）
行为：
  - 默认对 11 件缺陷型号跑 table_audit（dry）+ 渲染层 lint，逐条断言；
  - --write：先落补丁再断言（生产回归用）；默认 dry 断言 patched 内存副本；
  - --post：修补落盘后的复验模式 —— 夹具 findings 应已消失（缺陷已修复），
    结构断言（pin_eq/package_contains 等）仍在磁盘态成立（ADAPT A7）；
  - --sample N：随机抽 N 件新型号，输出 audit/lint flag 率（before/after），不进人工；
  - lint 覆盖图一 4~7 类：双转义、重复单位、导语/Overview 重复、图片复用/缺失、多语言残英/缺语言。
项目适配（相对 agent-Qwen 原版，均标 ADAPT）：
  A7 --post 模式（修补后复验：expected findings 必须消失，结构断言仍须成立）；
  A8 txt 产物名走 safe_name 归一化（{sn}.txt / {sn}.{lang}.txt）；
  A9 Windows 控制台 utf-8 输出。
退出码：0=断言全绿；1=有断言失败；3=缺件
用法：
  python qc/qc_regression.py            # 修补前：断言审计器能在现状里发现缺陷并正确打补丁
  python qc/qc_regression.py --write
  python qc/qc_regression.py --post      # 修补后：断言缺陷已消失、结构真值成立
  python qc/qc_regression.py --sample 60
  python qc/qc_regression.py --lint-only ADC3910S065IRSMT
"""
from __future__ import annotations
import argparse, datetime, difflib, json, random, re, sys, io
from pathlib import Path
if __package__:                                  # 工作台/worker 作为 qc 包导入
    from . import table_audit as TA
else:                                            # 直接脚本运行
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import table_audit as TA

# A9 utf-8 输出：table_audit 导入时已包装并打标 _qc_utf8，这里幂等跳过，
# 双重包装会让旧 wrapper 被 GC 连底关闭共享 buffer，print 直接 ValueError
if not getattr(sys.stdout, "_qc_utf8", False):
    _w = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    _w._qc_utf8 = True
    sys.stdout = _w
ROOT, PARSED, TXT = TA.ROOT, TA.PARSED, TA.TXT
LANGS = ("ja", "ko", "de", "es")

# ── 11 件回归夹具（断言只写"规则期望"，不写逐型号补丁逻辑）──
# findings = 修补前审计必须能看到的缺陷类（subset 语义：期望 ⊆ 实际发现）；
# asserts  = 打补丁后（内存态或 --post 磁盘态）必须成立的结构真值。
FIXTURES = [
 {"mpn": "5962-9053801PA",   "findings": ["range_collapse"],
  "asserts": [["value_roles_marker"], ["cols_roles_any2"], ["no_finding", "unit_dimension"]]},
 {"mpn": "74LVC1G132DCKTG4", "findings": ["condition_leak"],
  "asserts": [["mpn_eq", "74LVC1G132DCKTG4"], ["value_not", "ioff", 0.0], ["condition_has", "ioff", "vcc=0"]]},
 {"mpn": "ADC3910S065IRSMT", "findings": ["unit_dimension"],
  "asserts": [["entry_unit", 24.0, "mA"], ["unit_dim_ok"]]},
 {"mpn": "ADS7812B/1K",      "findings": ["identity_unverified"],
  "asserts": [["verification", "identity", "unverified"]]},
 {"mpn": "AM26C32IDG4",      "findings": ["pin_mismatch"],
  "asserts": [["pin_eq", 8, "GND"]]},
 {"mpn": "BQ24300DSGR",      "findings": ["qualifier_loss"],
  "asserts": [["value_roles_marker"], ["cols_roles_any2"]]},
 {"mpn": "BUF634PG4",        "findings": ["package_mismatch"],
  "asserts": [["package_contains", "PDIP"]]},
 {"mpn": "CD74FCT244SM96",   "findings": ["package_mismatch", "pin_mismatch"],
  "asserts": [["package_contains", "SSOP"], ["pin_eq", 20, "VCC"]]},
 {"mpn": "CDC421106RGER",    "findings": ["option_conflation"],
  "asserts": [["bound_option", "106.25"]]},
 {"mpn": "CY74FCT245ATSOCT", "findings": ["pin_mismatch", "direction_reversal"],
  "asserts": [["pin_eq", 1, "T/R"]]},
 {"mpn": "DAC8555IPWG4",     "findings": ["row_mispair"],
  "asserts": [["not_pair", 10.0, 0.65], ["entry_unit", 10.0, "µA"]]},
]

def entries(doc): return (doc.get("specs", {}) or {}).get("electrical") or []
def match(e, key):
    if not key: return True
    k = TA.nsym(key); return k and (k in TA.nsym(e.get("symbol")) or k in TA.nsym(e.get("name")))
def nums_of(e):
    out = [v for v in (e.get("columns") or {}).values() if v is not None]
    n = TA.to_num(str(e.get("value", "")))
    return out + ([n] if n is not None else [])

def eval_assert(a, res):
    t = a[0]; doc = res["patched_doc"]; kinds = {f["kind"] for f in res["findings"]}
    if t == "finding":        return a[1] in kinds
    if t == "no_finding":     return a[1] not in kinds
    if t == "mpn_eq":         return TA.nsym(doc.get("basic_info", {}).get("mpn")) == TA.nsym(a[1])
    if t == "verification":   return (doc.get("metadata", {}).get("verification") or {}).get(a[1]) == a[2]
    if t == "value_roles_marker":
        # 断言 A（抽取链路必须能过）：每行 value 非空，且至少一行的 value/condition
        # 里带 MIN/TYP/MAX 归属标识。占位符行要求 value="not_specified"，不许留空。
        es = entries(doc)
        if not es:
            return False
        if any(not str(e.get("value") or "").strip() for e in es):
            return False
        blob = " ".join(f"{e.get('value','')} {e.get('condition','')}" for e in es).lower()
        return any(k in blob for k in ("min", "typ", "max"))
    if t == "cols_roles_any2":
        # 断言 B（依赖 table_audit --write）：columns 里含 ≥2 个 MIN/TYP/MAX。
        # 该字段只有 qc/table_audit.py --write 会写，LLM 抽取链路从不产出
        # （抽样 1500 件命中 0）。整件都没有 columns 时返回 None = NOT_CHECKED，
        # 否则这条断言结构性地永远失败，把真缺陷（缺行/缺值）淹掉。
        if not any((e.get("columns") or {}) for e in entries(doc)):
            return None
        return any(len([r for r in ("MIN", "TYP", "MAX") if r in (e.get("columns") or {})]) >= 2
                   for e in entries(doc))
    if t == "entry_unit":
        for e in entries(doc):
            if a[1] in nums_of(e): return TA.u_norm(e.get("unit")) == TA.u_norm(a[2])
        return False
    if t == "unit_dim_ok":
        return all(not (TA.dim_unit(e.get("unit")) and TA.dim_symbol(e.get("symbol"), e.get("name"))
                        and TA.dim_unit(e.get("unit")) != TA.dim_symbol(e.get("symbol"), e.get("name"))) for e in entries(doc))
    if t == "value_not":
        for e in entries(doc):
            if match(e, a[1]): return TA.to_num(str(e.get("value", ""))) != a[2]
        return False
    if t == "condition_has":
        for e in entries(doc):
            if match(e, a[1]): return a[2] in re.sub(r"\s+", "", (e.get("condition") or "").lower())
        return False
    if t == "pin_eq":
        for pe in doc.get("pin_configuration") or []:
            if pe.get("pin") == a[1]: return TA.nsym(a[2]) in TA.nsym(f"{pe.get('name')} {pe.get('function')}")
        return False
    if t == "package_contains": return TA.nsym(a[1]) in TA.nsym((doc.get("specs", {}).get("package") or {}).get("type"))
    if t == "bound_option":     return str(a[1]) in json.dumps(doc.get("bound_options", {}))
    if t == "not_pair":
        return all(not ({a[1], a[2]} <= set(nums_of(e))) for e in entries(doc))
    return False

# ── 渲染层 lint（图一 4~7 类，纯产物检查，不重解 PDF）──
def lint_txt(mpn):
    sn = TA.safe_name(mpn)                                   # ADAPT A8
    out = []; base = TXT / f"{sn}.txt"
    if not base.exists(): return [{"kind": "txt_missing"}]
    txt = base.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"&amp;(lt|gt|amp|quot|#39);", txt): out.append({"kind": "escape_double"})
    if re.search(r"\b(mA|mW|V|MHz|kHz|°C)\s+\1\b", txt): out.append({"kind": "dup_unit"})
    blocks = [b.strip() for b in re.split(r"\n{2,}", txt) if len(b.strip()) > 40]
    if len(blocks) >= 2 and difflib.SequenceMatcher(None, blocks[0], blocks[1]).ratio() > 0.6:
        out.append({"kind": "dup_lead_overview", "ratio": round(difflib.SequenceMatcher(None, blocks[0], blocks[1]).ratio(), 2)})
    srcs = re.findall(r'src="([^"]+)"', txt); seen = {}
    for s in srcs: seen[s] = seen.get(s, 0) + 1
    for s, c in seen.items():
        if c >= 3: out.append({"kind": "image_reuse", "src": s, "n": c})
        if not s.startswith("http"):
            p = Path(s) if Path(s).is_absolute() else (TXT / s)
            if not p.exists(): out.append({"kind": "image_missing", "src": s})
    for lang in LANGS:
        vp = TXT / f"{sn}.{lang}.txt"
        if not vp.exists(): out.append({"kind": "i18n_missing", "lang": lang}); continue
        lines = [l for l in vp.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip()]
        en = [l for l in lines if len(re.findall(r"\b[a-zA-Z]{4,}\b", l)) >= 4]
        if lines and len(en) / len(lines) > 0.15:
            out.append({"kind": "i18n_residual", "lang": lang, "ratio": round(len(en) / len(lines), 2)})
    return out

def run_one(mpn, write=False):
    loc = TA.locate_paths(mpn)
    if not loc: return None
    doc = json.loads(Path(loc["json"]).read_text(encoding="utf-8"))
    res = TA.audit_json(doc, loc["pdf"], write=write, requested=loc["requested"], src_json=loc["json"])
    res["lint"] = lint_txt(loc["requested"])
    return res

def load_extra(path):
    """反馈闭环导出的附加回归夹具（格式与 FIXTURES 兼容：mpn/findings/asserts）。

    人工确认的新错误 → qc/goldset.py export_fixture → data/qc/regression_fixtures.json。
    JSON 坏/缺文件只警告不 fatal：基础 11 件夹具照常跑。
    """
    p = Path(path)
    if not p.exists():
        print(f"[extra] 附加夹具文件不存在（忽略）：{path}")
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"[extra] 附加夹具 JSON 解析失败（忽略）：{e}")
        return []
    out = []
    for d in data if isinstance(data, list) else []:
        if isinstance(d, dict) and d.get("mpn"):
            out.append({"mpn": d["mpn"],
                        "findings": [str(k) for k in (d.get("findings") or [])],
                        "asserts": [list(x) for x in (d.get("asserts") or []) if isinstance(x, list)],
                        "code": d.get("code", "")})
    print(f"[extra] 附加回归夹具 {len(out)} 件（{path}）")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true"); ap.add_argument("--post", action="store_true")  # ADAPT A7
    ap.add_argument("--sample", type=int, default=0)
    ap.add_argument("--extra", default="", help="附加回归夹具 JSON（反馈闭环导出）")
    ap.add_argument("--lint-only", nargs="*"); ap.add_argument("--report-dir", default=str(ROOT / "data" / "qc"))
    a = ap.parse_args()
    ts = datetime.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    rd = Path(a.report_dir); rd.mkdir(parents=True, exist_ok=True)

    if a.lint_only:
        rep = [{"mpn": m, "lint": lint_txt(m)} for m in a.lint_only]
        print(json.dumps(rep, ensure_ascii=False, indent=1))
        (rd / f"lint-{ts}.json").write_text(json.dumps(rep, ensure_ascii=False), encoding="utf-8")
        sys.exit(0)

    if a.sample:
        stems = [TA.HASH_SUFFIX.sub("", p.stem) for p in sorted(PARSED.glob("*.json"))
                 if not p.name.endswith((".alts.json", ".seo.json", ".pre_audit"))]
        stems = [s for s in stems if s not in {f["mpn"] for f in FIXTURES}]
        random.Random(7).shuffle(stems); pick = stems[:a.sample]
        kc, lc, unres = {}, {}, 0
        for m in pick:
            r = run_one(m)
            if not r: continue
            for f in r["findings"]: kc[f["kind"]] = kc.get(f["kind"], 0) + 1
            for l in r["lint"]:     lc[l["kind"]] = lc.get(l["kind"], 0) + 1
            unres += len(r["unresolved"])
        n = max(1, len(pick))
        print(f"抽样 {len(pick)} 件 | audit flag 率 " + ", ".join(f"{k}:{v/n:.0%}" for k, v in sorted(kc.items(), key=lambda x: -x[1])))
        print("lint flag 率 " + (", ".join(f"{k}:{v/n:.0%}" for k, v in sorted(lc.items(), key=lambda x: -x[1])) or "无"))
        print(f"补丁后残留 unresolved {unres} 件（应≈0，>0 说明表格定位失败需查 MAX_PAGES）")
        (rd / f"sample-{ts}.json").write_text(json.dumps({"n": len(pick), "audit": kc, "lint": lc, "unresolved": unres}, ensure_ascii=False), encoding="utf-8")
        sys.exit(0)

    fails, missing, rows, skipped_all = 0, [], [], {}
    fixtures = list(FIXTURES) + (load_extra(a.extra) if a.extra else [])
    for fx in fixtures:
        r = run_one(fx["mpn"], write=a.write)
        if not r: missing.append(fx["mpn"]); rows.append((fx["mpn"], "MISSING", "-", "-", "-")); continue
        kinds = {f["kind"] for f in r["findings"]}
        # 三态：True=通过、False=失败、None=NOT_CHECKED（依赖的层没跑，如 table_audit --write）
        vals = [(a2, eval_assert(a2, r)) for a2 in fx["asserts"]]
        bad = [a2 for a2, v in vals if v is False]
        skipped = [a2 for a2, v in vals if v is None]
        if skipped:
            skipped_all[fx["mpn"]] = skipped
        if a.post:
            # ADAPT A7: 修补后复验 —— 夹具期望的缺陷类必须已消失；结构断言仍须成立
            miss_f = []                       # 修补后不再要求"发现缺陷"
            bad = [k for k in fx["findings"] if k in kinds] + bad
        else:
            miss_f = [k for k in fx["findings"] if k not in kinds]
        ok = not miss_f and not bad
        fails += (not ok)
        rows.append((fx["mpn"], "PASS" if ok else "FAIL",
                     ",".join(sorted(kinds)) or "-", ",".join(miss_f) or "-",
                     ",".join(json.dumps(x, ensure_ascii=False) for x in bad) or "-"))
        print(f"[{fx['mpn']}] {'PASS' if ok else 'FAIL'} findings={sorted(kinds)} 缺发现={miss_f or '-'} "
              f"断言败={bad or '-'}"
              + (f" 未检={[x[0] for x in skipped]}" if skipped else "")
              + f" lint={[l['kind'] for l in r['lint']]}")
    print("\n型号 | 结论 | 发现 | 缺发现 | 断言败")
    for r_ in rows: print(" | ".join(map(str, r_)))
    if skipped_all:
        # 未检断言必须显式列出：静默跳过等于把「columns 字段缺失」的契约问题藏起来
        print("\n未检（依赖层未跑，需先 qc/table_audit.py --write）：")
        for m, sk in skipped_all.items():
            print(f"  {m}: {[x[0] for x in sk]}")
    rep = {"at": ts, "mode": "post" if a.post else ("write" if a.write else "dry"),
           "extra": a.extra, "n_fixtures": len(fixtures), "rows": rows, "missing": missing,
           "fails": fails, "not_checked": skipped_all}
    (rd / f"regression-{ts}.json").write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    sys.exit(3 if missing and fails == 0 and not rows else (1 if fails else 0))

if __name__ == "__main__":
    main()
