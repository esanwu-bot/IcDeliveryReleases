"""V4 dry-run 退化候选的页级溯源归因。

为什么需要这一层
----------------
门禁（`qc/v4_gate.py`）只回答「哪一件退化」，不回答「为什么退化」。
没有归因就无法决定修哪里：如果是选页截断，改 `select_pages()` 有效；
如果是模型/下游抽取波动，改选页完全无效，而且会误导后续所有调参。

做法
----
把退化拆到**签名级**，再对每条签名在 PDF 全文里定位它出现在哪些页，
与旧/新两版选页集合对照，落入四类之一：

  A 选页截断      —— 参数所在页旧版选了、新版没选（改选页能救）
  B 已入选未抽出  —— 页在新选页里，但新版没输出该参数（下游/模型波动，改选页救不了）
  C 页外命中      —— 两版都没选该页，旧值却存在（旧值来源存疑）
  D 全文无命中    —— PDF 里找不到该参数名（旧值来源存疑，可能是人工补或原件错配）

替代型号（`--mode alt`）走同样的溯源，但型号串是精确 token，
另加一层「是否只是写法归一化的重复」判定，避免把 `SN74LVC1G3157DRYR`
与 `SN74LVC1G3157DRYRG4` 当成两个型号。

只读：不写 parsed / backup / 数据库，只写 --out-dir 下的报告。

用法（容器内）
--------------
    python qc/v4_attrib.py --out-dir /tmp/v4_attrib
    python qc/v4_attrib.py --mode alt --out-dir /tmp/v4_attrib
    python qc/v4_attrib.py --mpn 74LVC1G3157DRYRG4,FCT162823CTPVCTG4
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                              # noqa: E402
from qc.diagnose_elec_loss import old_select               # noqa: E402
from qc.reparse_ordering import _safe                      # noqa: E402

# 旧版 MAX_PAGES 是 12，当前是 14 —— 复现旧选页必须显式传回旧值，
# 否则会把「新版多送了 2 页」误算成旧版能力。
OLD_MAX_PAGES = 12

DEFAULT_MPN = (
    "74LVC1G3157DRYRG4",    # P0：页全入选仍退化
    "FCT162823CTPVCTG4",    # P0：页全入选仍退化
    "6PAIC3254IRHBRQ1",     # P1
    "74LVC1G373DCKRE4",     # P1
    "74LVCH16T245DGGRE4",   # P1
    "TMDXSK437X",           # P2：296 页长文档
)

_CAUSE = {
    "A": "选页截断",
    "B": "已入选未抽出",
    "C": "页外命中",
    "D": "全文无命中",
}


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _norm(s: str) -> str:
    """归一化：小写 + 空白折叠，用于页文本与参数名的包含匹配。"""
    return re.sub(r"\s+", " ", str(s or "").strip().lower())


def _sig(e: dict) -> tuple:
    g = lambda k: str((e or {}).get(k) or "").strip().lower()
    return (g("name"), g("condition"), g("unit"))


def _sigs(doc: dict) -> dict:
    out: dict = {}
    for e in ((doc.get("specs") or {}).get("electrical") or []):
        if isinstance(e, dict) and _sig(e)[0]:
            out[_sig(e)] = out.get(_sig(e), 0) + 1
    return out


def _alt_values(doc: dict) -> list[str]:
    out = []
    for a in (doc.get("alternatives") or []):
        if isinstance(a, dict):
            v = str(a.get("mpn") or a.get("model") or a.get("part") or "").strip()
        else:
            v = str(a or "").strip()
        if v:
            out.append(v)
    return out


def _alt_key(v: str) -> str:
    """替代型号的归一化键：去掉大小写、连字符、空格后的差异。"""
    return re.sub(r"[^a-z0-9]", "", str(v or "").lower())


def _read_pages(pdf: Path) -> tuple[list[tuple[int, str]], list[str]]:
    """一次打开 PDF，返回 (原始逐页文本, 归一化逐页文本)。

    选页函数要吃原始文本，页级定位要吃归一化文本；开两次 PDF 对 296 页的
    长文档是纯浪费，所以合并成一次。
    """
    import fitz
    with fitz.open(str(pdf)) as doc:
        raw = [(i, doc[i].get_text("text") or "") for i in range(doc.page_count)]
    return raw, [_norm(t) for _, t in raw]


def _new_sel_pages(pages: list[tuple[int, str]]) -> set[int]:
    """当前 select_pages 的选中页号集合（1-based）。

    select_pages 只返回拼好的文本，页号藏在 `--- Page N ---` 标记里，
    直接解析标记比复制一份两阶段逻辑更不容易跟实现漂移。
    """
    text, _, _ = PD.select_pages(iter(pages))
    return {int(m) for m in re.findall(r"--- Page (\d+) ---", text)}


def _old_sel_pages(pages: list[tuple[int, str]]) -> set[int]:
    buf, _ = old_select(iter(pages), max_pages=OLD_MAX_PAGES, max_chars=PD.MAX_CHARS)
    return {i + 1 for i, _ in buf}


def _locate(ptexts: list[str], needle: str) -> tuple[list[int], str]:
    """在归一化页文本里定位 needle，返回 (1-based 页号, 命中的写法)。

    为什么要退避匹配
    ----------------
    TI 正文里常省略前缀：料号叫 `TMS320F2800133RGZR`，datasheet 里只写
    `F2800133RGZR`。全串匹配会判成「全文无命中」，把「旧值写法带了前缀」
    误报成「PDF 里根本没有这个型号」。所以从最长后缀开始逐位截短再匹配。
    """
    key = _norm(needle)
    if len(key) < 4:
        return [], ""
    # start 从 0 递增 = 后缀从长到短；第一个命中的就是最长可命中写法
    for start in range(0, len(key) - 5):
        k = key[start:]
        # 型号主干以字母开头。不加这条会拿 `-30-q1` 这种残片去匹配，
        # 命中十几页全是噪声（实测 TPS3820-30-Q1 就是这样被误判的）。
        if not k[0].isalpha():
            continue
        hits = [i + 1 for i, t in enumerate(ptexts) if k in t]
        if hits:
            return hits, needle if start == 0 else "%s（按 %s 命中）" % (needle, k)
    return [], ""


def _classify(hits: list[int], old_sel: set[int], new_sel: set[int]) -> str:
    if not hits:
        return "D"
    in_old = [p for p in hits if p in old_sel]
    in_new = [p for p in hits if p in new_sel]
    if in_old and not in_new:
        return "A"          # 旧版送了这一页，新版没送
    if in_new:
        return "B"          # 新版也送了这一页，却没抽出来
    return "C"              # 两版都没送


def attrib_elec(mpn: str, old: dict, new: dict, pdf: Path,
                old_sel: set[int], new_sel: set[int],
                ptexts: list[str], sign_rows: list) -> dict:
    o_s, n_s = _sigs(old), _sigs(new)
    lost = sorted(set(o_s) - set(n_s))
    gain = sorted(set(n_s) - set(o_s))
    both = sorted(set(o_s) & set(n_s))

    tally: dict[str, int] = {k: 0 for k in _CAUSE}
    for s in lost:
        hits, variant = _locate(ptexts, s[0])
        if not hits and s[1]:
            # 参数名在页上可能是整表标题，退一步拿条件串的前半段再定位一次
            hits, variant = _locate(ptexts, s[1][:40])
        c = _classify(hits, old_sel, new_sel)
        tally[c] += 1
        sign_rows.append({
            "mpn": mpn, "mode": "elec", "kind": "仅旧",
            "name": s[0], "condition": s[1], "unit": s[2],
            "matched": variant,
            "hits_pages": ",".join(map(str, hits[:12])),
            "in_old_sel": "是" if any(p in old_sel for p in hits) else "否",
            "in_new_sel": "是" if any(p in new_sel for p in hits) else "否",
            "cause": c, "cause_cn": _CAUSE[c],
        })
    for s in gain:
        hits, variant = _locate(ptexts, s[0])
        sign_rows.append({
            "mpn": mpn, "mode": "elec", "kind": "仅新",
            "name": s[0], "condition": s[1], "unit": s[2],
            "matched": variant,
            "hits_pages": ",".join(map(str, hits[:12])),
            "in_old_sel": "是" if any(p in old_sel for p in hits) else "否",
            "in_new_sel": "是" if any(p in new_sel for p in hits) else "否",
            "cause": _classify(hits, old_sel, new_sel) if hits else "D",
            "cause_cn": "-",
        })

    return {
        "mpn": mpn,
        "elec_old": len(o_s), "elec_new": len(n_s),
        "elec_lost": len(lost), "elec_gain": len(gain), "elec_both": len(both),
        "cause_A_选页截断": tally["A"],
        "cause_B_已入选未抽出": tally["B"],
        "cause_C_页外命中": tally["C"],
        "cause_D_全文无命中": tally["D"],
        "old_sel_pages": ",".join(map(str, sorted(old_sel))),
        "new_sel_pages": ",".join(map(str, sorted(new_sel))),
        "old_sel_n": len(old_sel), "new_sel_n": len(new_sel),
        "pages_total": len(ptexts),
    }


def attrib_alt(mpn: str, old: dict, new: dict, pdf: Path,
               old_sel: set[int], new_sel: set[int],
               ptexts: list[str], sign_rows: list) -> dict:
    o_alt, n_alt = _alt_values(old), _alt_values(new)
    n_keys = {_alt_key(x) for x in n_alt}
    removed = [x for x in o_alt if _alt_key(x) not in n_keys]
    added = [x for x in n_alt if _alt_key(x) not in {_alt_key(y) for y in o_alt}]
    # 写法归一化后其实还在，只是拼法不同
    merged = [x for x in o_alt
              if x.upper() not in {y.upper() for y in n_alt} and _alt_key(x) in n_keys]

    tally: dict[str, int] = {k: 0 for k in _CAUSE}
    for v in removed:
        hits, variant = _locate(ptexts, v)
        c = _classify(hits, old_sel, new_sel)
        tally[c] += 1
        sign_rows.append({
            "mpn": mpn, "mode": "alt", "kind": "仅旧",
            "name": v, "condition": "", "unit": "",
            "matched": variant,
            "hits_pages": ",".join(map(str, hits[:12])),
            "in_old_sel": "是" if any(p in old_sel for p in hits) else "否",
            "in_new_sel": "是" if any(p in new_sel for p in hits) else "否",
            "cause": c, "cause_cn": _CAUSE[c],
        })
    for v in added:
        hits, variant = _locate(ptexts, v)
        sign_rows.append({
            "mpn": mpn, "mode": "alt", "kind": "仅新",
            "name": v, "condition": "", "unit": "",
            "matched": variant,
            "hits_pages": ",".join(map(str, hits[:12])),
            "in_old_sel": "是" if any(p in old_sel for p in hits) else "否",
            "in_new_sel": "是" if any(p in new_sel for p in hits) else "否",
            "cause": _classify(hits, old_sel, new_sel) if hits else "D",
            "cause_cn": "-",
        })

    return {
        "mpn": mpn,
        "alt_old": len(o_alt), "alt_new": len(n_alt),
        "alt_removed": len(removed), "alt_added": len(added),
        "alt_写法归一化后仍在": len(merged),
        "cause_A_选页截断": tally["A"],
        "cause_B_已入选未抽出": tally["B"],
        "cause_C_页外命中": tally["C"],
        "cause_D_全文无命中": tally["D"],
        "old_sel_pages": ",".join(map(str, sorted(old_sel))),
        "new_sel_pages": ",".join(map(str, sorted(new_sel))),
        "old_sel_n": len(old_sel), "new_sel_n": len(new_sel),
        "pages_total": len(ptexts),
        "old_values": " ; ".join(o_alt[:40]),
        "new_values": " ; ".join(n_alt[:40]),
        "removed_values": " ; ".join(removed[:40]),
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V4 退化候选页级溯源归因")
    ap.add_argument("--mpn", default=",".join(DEFAULT_MPN),
                    help="逗号分隔；留空则用 6 件退化候选")
    ap.add_argument("--mode", default="elec", choices=["elec", "alt", "both"])
    ap.add_argument("--tmp-parsed", default="/tmp/v4_dryrun/parsed")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--out-dir", default="/tmp/v4_attrib")
    a = ap.parse_args(argv)

    tmp, backup = Path(a.tmp_parsed), Path(a.backup)
    data_root, out_dir = Path(a.data_root), Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    pdfs = data_root / "pdfs"

    mpns = [x.strip() for x in a.mpn.split(",") if x.strip()]
    db = sqlite3.connect(data_root / "workbench.sqlite3")

    sign_rows: list = []
    sum_rows: list = []
    for mpn in mpns:
        row = db.execute("SELECT pdf_path, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        db_pdf = Path(row[0].replace("\\", "/")).name if row and row[0] else ""
        db_json = Path(row[1].replace("\\", "/")).name if row and row[1] else ""

        old_name = db_json if db_json and (backup / db_json).exists() else ""
        if not old_name:
            hits = sorted(p.name for p in backup.glob(_safe(mpn) + "_*.json"))
            old_name = hits[0] if hits else ""
        if not old_name:
            print("  [!] 无备份基线，跳过：%s" % mpn)
            continue

        new_hits = sorted(tmp.glob(_safe(mpn) + "_*.json"))
        if not new_hits:
            print("  [!] 无 dry-run 产物，跳过：%s" % mpn)
            continue
        old, new = _load(backup / old_name), _load(new_hits[0])

        pdf = pdfs / db_pdf if db_pdf else None
        if not pdf or not pdf.exists():
            from qc.reparse_ordering import _pdf_for
            pdf = _pdf_for(mpn, pdfs)
        if not pdf or not pdf.exists():
            print("  [!] 无 PDF，跳过：%s" % mpn)
            continue

        raw, ptexts = _read_pages(pdf)
        old_sel, new_sel = _old_sel_pages(raw), _new_sel_pages(raw)

        print("  %-22s 页 %d / 旧选 %d / 新选 %d" % (mpn, len(ptexts), len(old_sel), len(new_sel)))

        if a.mode in ("elec", "both"):
            sum_rows.append(attrib_elec(mpn, old, new, pdf, old_sel, new_sel,
                                        ptexts, sign_rows))
        if a.mode in ("alt", "both"):
            sum_rows.append(attrib_alt(mpn, old, new, pdf, old_sel, new_sel,
                                       ptexts, sign_rows))

    def dump(name: str, rows: list) -> None:
        if not rows:
            return
        p = out_dir / name
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("  写入 %s（%d 行）" % (p, len(rows)))

    dump("v4_attrib_signs.csv", sign_rows)
    dump("v4_attrib_summary.csv", sum_rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
