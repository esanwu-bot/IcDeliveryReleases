"""指定页、限时、磁盘缓存的 PDF 原文取证。

调用方必须给出 1-based 页码。禁止为核对一行参数扫描整份 PDF。
缓存键 = PDF SHA-256 + 页码 + 提取器版本。命中且 status=ok 时不再打开 PDF。
超时或越页只记录状态，空结果不得当作证据。
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "data" / "evidence_cache"
EXTRACTOR = "pymupdf-words-v1"
DEFAULT_TIMEOUT = 8.0


def pdf_sha256(path: Path) -> str:
    """流式哈希。同一路径+大小+mtime 命中 sidecar，避免重复读大文件。"""
    path = Path(path)
    st = path.stat()
    index_path = CACHE_DIR / "sha_index.json"
    key = f"{path.resolve()}|{st.st_size}|{st.st_mtime_ns}"
    index = {}
    if index_path.exists():
        try:
            index = json.loads(index_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            index = {}
    if key in index:
        return index[key]
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    sha = digest.hexdigest()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    index[key] = sha
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    return sha


def cache_file(sha: str, pages: list[int], kind: str = "words") -> Path:
    tag = "-".join(str(p) for p in pages)
    return CACHE_DIR / f"{sha[:16]}_p{tag}_{kind}_{EXTRACTOR}.json"


def load_cache(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def group_rows(words, y_tol: float = 1.6) -> list[dict]:
    """按 y 聚成阅读行，保留每个词的 x，供表头列锚点切分。"""
    rows: list[dict] = []
    for word in sorted(words, key=lambda item: (round(item[1], 1), item[0])):
        x0, y0, x1, _y1, text = word[:5]
        text = str(text).strip()
        if not text:
            continue
        cell = {"x0": round(float(x0), 2), "x1": round(float(x1), 2), "text": text}
        if rows and abs(float(y0) - rows[-1]["y"]) <= y_tol:
            rows[-1]["words"].append(cell)
        else:
            rows.append({"y": round(float(y0), 2), "words": [cell]})
    for row in rows:
        row["text"] = " ".join(item["text"] for item in row["words"])
    return rows


def _extract_sync(pdf_path: Path, pages: list[int], out: dict, deadline: float) -> None:
    import pymupdf

    doc = pymupdf.open(str(pdf_path))
    try:
        out["page_count"] = len(doc)
        page_data = []
        for pno in pages:
            if time.monotonic() > deadline:
                out["status"] = "timeout"
                out["error"] = f"deadline before page {pno}"
                out["pages_data"] = page_data
                return
            if pno < 1 or pno > len(doc):
                page_data.append({"page": pno, "status": "out_of_range", "rows": []})
                continue
            page = doc[pno - 1]
            page_data.append({
                "page": pno,
                "status": "ok",
                "width": round(page.rect.width, 2),
                "height": round(page.rect.height, 2),
                "rows": group_rows(page.get_text("words")),
            })
        out["pages_data"] = page_data
        out["status"] = "ok"
    finally:
        doc.close()


def extract_pages(
    pdf_path,
    pages,
    timeout_s: float = DEFAULT_TIMEOUT,
    refresh: bool = False,
) -> dict:
    """只读指定页。超时后放弃线程，不把半截结果标成 ok。"""
    pdf_path = Path(pdf_path)
    pages = [int(p) for p in pages]
    if not pages:
        raise ValueError("pages required; refusing to scan the whole PDF")
    sha = pdf_sha256(pdf_path)
    dest = cache_file(sha, pages)
    if not refresh:
        hit = load_cache(dest)
        if hit and hit.get("status") == "ok" and hit.get("extractor") == EXTRACTOR:
            hit["cache"] = "hit"
            hit["cache_path"] = str(dest)
            return hit
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    out = {
        "pdf": str(pdf_path),
        "pdf_name": pdf_path.name,
        "pdf_sha256": sha,
        "pages": pages,
        "extractor": EXTRACTOR,
        "timeout_s": timeout_s,
        "status": "running",
    }
    deadline = time.monotonic() + float(timeout_s)
    worker = threading.Thread(
        target=_extract_sync, args=(pdf_path, pages, out, deadline), daemon=True)
    started = time.monotonic()
    worker.start()
    worker.join(float(timeout_s) + 0.4)
    out["elapsed_s"] = round(time.monotonic() - started, 3)
    if worker.is_alive() or out.get("status") != "ok":
        out["status"] = "timeout" if worker.is_alive() else out.get("status", "error")
        out.setdefault("error", "join timeout; abandoned thread is not evidence")
        failed = cache_file(sha, pages, "timeout")
        failed.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        out["cache"] = "timeout"
        out["cache_path"] = str(failed)
        return out
    dest.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    out["cache"] = "miss"
    out["cache_path"] = str(dest)
    return out


def column_anchors(rows: list[dict], names=("MIN", "TYP", "MAX", "UNITS")) -> dict:
    """从表头行取列中心 x。找不到表头返回空字典，调用方不得猜列。"""
    wanted = {name.upper(): name for name in names}
    for row in rows:
        found = {}
        for word in row.get("words") or []:
            token = word["text"].upper().rstrip(":")
            if token in wanted and token not in found:
                found[token] = round((word["x0"] + word["x1"]) / 2, 2)
        if {"MIN", "TYP", "MAX"} <= set(found):
            return found
    return {}


def assign_columns(row: dict, anchors: dict, x_min: float = 180) -> dict:
    """把参数行右侧的词按最近表头列归位。没有锚点时不归列。"""
    if not anchors:
        return {}
    assigned = {name: [] for name in anchors}
    for word in row.get("words") or []:
        center = (word["x0"] + word["x1"]) / 2
        if center < x_min:
            continue
        name = min(anchors, key=lambda key: abs(anchors[key] - center))
        if abs(anchors[name] - center) <= 42:
            assigned[name].append(word["text"])
    return {name: " ".join(parts).strip() for name, parts in assigned.items() if parts}
