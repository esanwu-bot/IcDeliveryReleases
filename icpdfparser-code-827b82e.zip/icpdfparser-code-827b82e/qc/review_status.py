"""review 报告 → 交付状态 的**纯函数**推导（P0/P1 门禁）。

为什么要单独一个模块
--------------------
旧口径只有一个合并状态 `REVIEWED_FIXED`，判定依据是「修过 + 修后重审 PASS/WARN」。
WARN 里可能还剩 P1，于是「复审仍 FAIL 但跑满轮次」和「真修好了」会混在一起，
交付历史看不出哪件还被阻断。这里改成**只看最近一次复审报告的实际 findings**：

    P0 > 0                 → REVIEWED_BLOCKED      阻断交付
    P0 = 0 且 P1 > 0       → REVIEWED_STILL_WARN   警告待人工
    P0 = 0 且 P1 = 0       → REVIEWED_QA_PASS      机器检查通过（仍待人工验收）
    证据不足/报告无效/无法识别 → INCOMPLETE / LEGACY_UNRESOLVED

刻意守住的三条边界（都是踩过的坑）
----------------------------------
1. **不是所有 finding 都算数**：`advisory=true` 的 LLM 结论是被证据闸降级的参考项
   （见 `app/services/review.py::_sanitize_llm_findings`），不计 P0/P1；P2 恒不计。
   缺 `severity` 的条目不是「默认 P1」，而是**报告不合规**，整件转 INCOMPLETE。
2. **空报告与缺字段要分开**：`rule_findings: []` + `llm_findings: []` + verdict PASS
   是「有效空报告」（QA_PASS）；两个键都不在、也没有旧版 `findings`，是
   「报告不完整」（LEGACY_UNRESOLVED），不能当成通过。
3. **verdict 与计数必须自洽**：FAIL 却数不出 P0、PASS 却数出 P0/P1，说明报告被
   截断或格式被改写，标 INCOMPLETE，不猜结论。

本模块不做任何 I/O，也不 import app.*，常驻进程引用无副作用；
`rule_version` 由调用方从报告里带出来，用于回溯「当时是哪版规则判的」。
"""
from __future__ import annotations

from collections.abc import Iterable

# ---------------------------------------------------------------- 状态口径
STATUS_BLOCKED = "REVIEWED_BLOCKED"
STATUS_STILL_WARN = "REVIEWED_STILL_WARN"
STATUS_QA_PASS = "REVIEWED_QA_PASS"
STATUS_INCOMPLETE = "INCOMPLETE"
STATUS_LEGACY_UNRESOLVED = "LEGACY_UNRESOLVED"

STATUS_LABELS = {
    STATUS_BLOCKED: "阻断（P0 未清）",
    STATUS_STILL_WARN: "警告（P1 未清）",
    STATUS_QA_PASS: "机器检查通过（待人工验收）",
    STATUS_INCOMPLETE: "证据不完整",
    STATUS_LEGACY_UNRESOLVED: "旧格式无法判定",
}

# 推导逻辑版本：口径一改就递增，回填报告里逐行记录，便于日后解释差异
STATUS_RULE_VERSION = "rs-1"

VALID_SEVERITIES = ("P0", "P1")
_VERDICTS = ("PASS", "WARN", "FAIL")

# 批次 rollup 的优先级：阻断 > 证据缺口 > 已知警告 > 通过。
# 证据缺口排在 STILL_WARN 之前是刻意的：缺报告/无法判定属于数据问题，不允许被
# 「已知的 P1」盖住，否则 30 件里有 1 件没审也会显示成「只是有点警告」。
ROLLUP_ORDER = (STATUS_BLOCKED, STATUS_INCOMPLETE, STATUS_LEGACY_UNRESOLVED,
                STATUS_STILL_WARN, STATUS_QA_PASS)


def label(code: str) -> str:
    return STATUS_LABELS.get(code, code or "")


def is_green(code: str) -> bool:
    return code == STATUS_QA_PASS


def _sev(f: dict) -> str:
    return str(f.get("severity") or "").strip().upper()


def analyze(review) -> dict:
    """把一份 review 报告规范成计数与证据状态。

    返回 dict：
      status_code / status_label   推导结论
      p0 / p1 / p2                 有效计数（advisory 与非法条目不进 P0/P1）
      advisory                     advisory=true 的参考条目数
      verdict                      报告自带的 verdict（大写；无效则为 ""）
      format                       rule_llm / legacy_findings / unresolved
      checks                       {"report": .., "findings_schema": .., "verdict_consistency": ..}
      incomplete_checks            未通过的检查数
      reason                       结论依据/失败原因（给人看的短句）
      rule_version / review_version 报告里带的规则与报告版本（可能为空）
    """
    out: dict = {
        "status_code": STATUS_INCOMPLETE,
        "status_label": label(STATUS_INCOMPLETE),
        "p0": 0, "p1": 0, "p2": 0, "advisory": 0,
        "verdict": "",
        "format": "",
        "checks": {},
        "incomplete_checks": 0,
        "reason": "",
        "rule_version": "",
        "review_version": "",
        "status_rule_version": STATUS_RULE_VERSION,
    }
    if not isinstance(review, dict) or not review:
        out["checks"] = {"report": "MISSING"}
        out["incomplete_checks"] = 1
        out["reason"] = "缺少 review 报告"
        return out

    out["verdict"] = str(review.get("verdict") or "").strip().upper()
    out["rule_version"] = str(review.get("rule_version") or "")
    out["review_version"] = str(review.get("review_version") or "")

    has_rule = isinstance(review.get("rule_findings"), list)
    has_llm = isinstance(review.get("llm_findings"), list)
    if has_rule and has_llm:
        items = [f for f in review["rule_findings"]] + [f for f in review["llm_findings"]]
        out["format"] = "rule_llm"
    elif isinstance(review.get("findings"), list):
        # 旧格式：单一 findings 数组（review.py 早期版本）
        items = list(review["findings"])
        out["format"] = "legacy_findings"
    else:
        out["format"] = "unresolved"
        out["status_code"] = STATUS_LEGACY_UNRESOLVED
        out["status_label"] = label(STATUS_LEGACY_UNRESOLVED)
        out["checks"] = {"report": "OK", "findings_schema": "UNRESOLVED"}
        out["incomplete_checks"] = 1
        out["reason"] = "报告既无 rule_findings/llm_findings，也无旧版 findings"
        return out

    bad_items = 0
    for f in items:
        if not isinstance(f, dict):
            bad_items += 1
            continue
        sev = _sev(f)
        if f.get("advisory") is True:
            # 证据闸降级的参考项：始终是 P2，不参与门禁
            out["advisory"] += 1
            continue
        if sev == "P0":
            out["p0"] += 1
        elif sev == "P1":
            out["p1"] += 1
        elif sev == "P2":
            out["p2"] += 1
        else:
            bad_items += 1

    checks: dict[str, str] = {}
    checks["report"] = "OK" if out["verdict"] in _VERDICTS else "BAD_VERDICT"
    checks["findings_schema"] = ("OK" if not bad_items
                                 else "BAD_ITEMS(%d)" % bad_items)
    if out["verdict"] == "FAIL" and out["p0"] == 0:
        checks["verdict_consistency"] = "MISMATCH(FAIL 但无 P0)"
    elif out["verdict"] == "PASS" and (out["p0"] or out["p1"]):
        checks["verdict_consistency"] = "MISMATCH(PASS 但有 P0/P1)"
    elif out["verdict"] == "WARN" and out["p0"]:
        checks["verdict_consistency"] = "MISMATCH(WARN 但有 P0)"
    else:
        checks["verdict_consistency"] = "OK"

    out["checks"] = checks
    out["incomplete_checks"] = sum(1 for v in checks.values() if v != "OK")

    if out["incomplete_checks"]:
        out["status_code"] = STATUS_INCOMPLETE
        out["status_label"] = label(STATUS_INCOMPLETE)
        out["reason"] = "；".join("%s=%s" % (k, v) for k, v in checks.items()
                                  if v != "OK")
        return out

    if out["p0"]:
        out["status_code"] = STATUS_BLOCKED
        out["status_label"] = label(STATUS_BLOCKED)
        out["reason"] = "%d 个 P0 未清" % out["p0"]
    elif out["p1"]:
        out["status_code"] = STATUS_STILL_WARN
        out["status_label"] = label(STATUS_STILL_WARN)
        out["reason"] = "%d 个 P1 未清" % out["p1"]
    else:
        out["status_code"] = STATUS_QA_PASS
        out["status_label"] = label(STATUS_QA_PASS)
        out["reason"] = ("机器检查无 P0/P1" +
                         ("（%d 条 P2 参考）" % out["p2"] if out["p2"] else ""))
    return out


def normalize(code: str) -> str:
    """把历史/外部编码收敛到本模块的五个状态；无法识别一律 INCOMPLETE。"""
    c = str(code or "").strip().upper()
    if c in STATUS_LABELS:
        return c
    if c in ("REVIEWED_PARTIAL", "PARTIAL"):
        return STATUS_INCOMPLETE
    return STATUS_INCOMPLETE


def rollup(codes: Iterable[str]) -> str:
    """批次状态：取最严重的一件（见 ROLLUP_ORDER）。空批次=INCOMPLETE。"""
    seen = {normalize(c) for c in codes}
    if not seen:
        return STATUS_INCOMPLETE
    for c in ROLLUP_ORDER:
        if c in seen:
            return c
    return STATUS_INCOMPLETE


def counts(rows: Iterable[dict]) -> dict:
    """按状态计数，未识别的归到 INCOMPLETE。"""
    out = {c: 0 for c in STATUS_LABELS}
    for r in rows:
        out[normalize((r or {}).get("status_code"))] += 1
    return out
