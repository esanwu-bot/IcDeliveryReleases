#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 V3-FINAL 的 7 件内容审批清单（全部数字来自本包实测）。

用法:
  python qc/gen_v3f_checklist.py [staging_root] [out_md]
"""
from __future__ import annotations

import csv
import json
import sys
from collections import Counter
from pathlib import Path

STAGING = Path(sys.argv[1] if len(sys.argv) > 1 else "data/staging_batch20_v3_final")
OUT = Path(sys.argv[2] if len(sys.argv) > 2
           else "docs/qc/phase171/V3_FINAL_CONTENT_REVIEW_CHECKLIST_20261104.md")

MPNS = ["ADS1675REF", "ADS42JB49SEK", "CDC6CE025000ADLET",
        "CDC6CE025000ADLFR", "LM317", "LM358", "NE555"]

#: 容器 → 清单里的中文维度名
CONTAINERS = [("electrical", "Electrical"), ("absolute_max", "AbsMax"),
              ("thermal", "Thermal"), ("esd", "ESD")]

#: 结论分档：verdict → 清单里的三色
OK = {"audited", "audited_manual", "audited_deterministic", "audited_row_anchored",
      "audited_paragraph", "audited_coord", "audited_container", "verified",
      "pass", "ok", "deterministic"}
BAD = {"unresolved", "column_roles_not_verified", "row_ambiguous", "row_not_located",
       "not_found", "column_collapse"}


def _cls(status: str) -> str:
    s = (status or "").strip()
    if not s:
        return "none"
    if s in OK or s.startswith("audited"):
        return "ok"
    if s in BAD or "unresolved" in s or "not_verified" in s or "not_found" in s:
        return "bad"
    return "warn"


def _dist(rows: list) -> tuple[Counter, str, str]:
    """返回 `(分布, 描述串, 最弱档图标)`。

    **图标必须取最弱的一档**：只取第一条会出反向误报 —— ADS1675REF 的电气
    68 条 ✅ + 1 条 ❌ 曾显示成「✅」，等于把一条未解决的行藏在一堆好行后面。
    这与 `_FACTS_RANK`「多条候选取最弱」是同一条纪律。
    """
    c: Counter = Counter()
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        st = str((r.get("verification") or {}).get("status") or "").strip()
        c[st or "(无 status)"] += 1
    parts = []
    worst = "ok"
    order = {"ok": 0, "warn": 1, "bad": 2, "none": 0}
    for st, n in c.most_common():
        k = _cls(st)
        if k == "none":
            k = "warn"            # 没有 status 本身就是「未核验」，不能算 ok
        if order[k] > order[worst]:
            worst = k
        mark = {"ok": "✅", "bad": "❌", "warn": "⚠️"}[k]
        parts.append(f"{mark}{n} `{st}`")
    icon = {"ok": "✅", "warn": "⚠️", "bad": "❌"}[worst]
    return c, " · ".join(parts), icon


def _advice(pv: dict, n_blocked: int, n_risk: int) -> str:
    """机器建议（规则化，不手写）。**是建议不是裁决** —— 签核由人做。

    规则只编码三条已定契约，不掺主观：
      1. `failed` → 必须先整改或明确豁免，不能直接签；
      2. `passed` 但 `det_count / model_count < 0.6` → 加一条「确定性覆盖不足」条件；
      3. `unverified` → 条件签核，条件是人工确认按哪个封装口径对账。
    """
    st = str(pv.get("status") or "missing")
    det = pv.get("det_count")
    model = pv.get("model_count")
    thin = (isinstance(det, int) and isinstance(model, int)
            and model > 0 and det / model < 0.6)
    if st == "failed":
        why = str(pv.get("reason") or "")
        if why == "duplicate_pin_name" and pv.get("dup_names"):
            return ("**退回整改**（引脚重名：" + "/".join(pv["dup_names"][:4])
                    + "）—— 逐脚对照 PDF 修正后可重审；若确认原厂就是合并写法，"
                      "须在签核页写明豁免依据")
        return f"**退回整改**（`{why}`）"
    if st == "passed":
        s = "**可条件批准**（引脚硬闸 passed）"
        if thin:
            s += f"；条件：确定性只覆盖 {det}/{model} 脚，其余脚名需人工对照"
        if n_blocked:
            s += f"；条件：{n_blocked} 条未达门槛行 + 风险队列 {n_risk} 行逐行裁决"
        return s
    if st == "unverified":
        _ec = pv.get("expected_counts") or {}
        # dict repr 在 Markdown 里是 `{'DCY': 4, ...}`，读起来像代码不像参数表。
        _ecs = "/".join(f"{k}={v}" for k, v in _ec.items()) or "无可信脚数"
        return (f"**条件签核**（多封装脚数不唯一：`{_ecs}`，"
                "需人工指定按哪个封装对账）"
                f"；另需裁决 {n_blocked} 条未达门槛行")
    return "**退回**（`pin_validation` 缺失 —— 装配期重放没跑）"


def main() -> int:
    parsed = STAGING / "parsed"
    fa = json.loads((STAGING / "facts_audit.json").read_text(encoding="utf-8"))
    fv = json.loads((STAGING / "facts_verdicts.json").read_text(encoding="utf-8"))
    risk = Counter()
    with (STAGING / "risk_queue.csv").open(encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            risk[row.get("mpn", "")] += 1

    docs = {}
    for m in MPNS:
        docs[m] = json.loads((parsed / f"{m}.json").read_text(encoding="utf-8"))

    lines: list[str] = []
    A = lines.append

    # ── 头 ────────────────────────────────────────────────────────────
    gates = {m: (fa["mpns"].get(m) or {}).get("anchor_gate", "?") for m in MPNS}
    n_pass = sum(1 for v in gates.values() if v == "pass")
    A("# 7 件 V3-FINAL · 内容审批清单（CONTENT REVIEW，2026-11-04 重跑版）")
    A("")
    A("**候选包**：`delivery-batch20-eval-V3-FINAL`")
    A("**装配根**：`data/staging_batch20_v3_final`（本清单所有数字取自该根实测）")
    A("**代码版本**：`4e9e31e` —— D4 硬闸装配期重放 + 电源/参考族白名单 + 缺失即 BLOCKED")
    A("**包内状态**：7 件全部 `release_status=not_approved`，未申请人工签核")
    A(f"**anchor_gate**：{n_pass} 件 `pass` / {len(MPNS) - n_pass} 件 `blocked`")
    A("")
    A("> 与 11-04 早版清单的**根本差异**：那一版 7 件的 `metadata.pin_validation` 全为空"
      "（产物冻结于 `948c2c2`，早于硬闸上线）。本版用 `4e9e31e` 在装配期重放了"
      "`apply_pin_gate`，引脚状态是**这一趟算出来的**，不是历史遗留的空字段。")
    A("")
    A("状态标记：**✅ verified**（证据链完整）· **⚠️ unverified**（数据在但未逐格核验）"
      "· **❌ failed**（已知问题行，签核前须整改或明确豁免）")
    A("")
    A("---")
    A("")

    # ── 通用前提 ──────────────────────────────────────────────────────
    A("## 0. 通用裁决要点")
    A("")
    A("| # | 通用事实 | 对签核的含义 |")
    A("|---|---|---|")
    A("| 1 | **Pins 维度本版已有 `pin_validation`**（装配期重放落盘），状态逐件不同 | "
      "只有 `passed` 的件可标 verified；`unverified` / `failed` 必须人工对照 PDF 或退回 |")
    A("| 2 | **Evidence 精度闸**：`anchor_gate=blocked` 表示存在未达门槛的行，不是整件否决 | "
      "按各件风险队列逐行裁决；达标行可签 |")
    A("| 3 | **Identity / Scope**：7 件均 `identity=chip`、`scope=device`、`scope_contract_findings=0` | "
      "两维度整体达标（ADS1675REF 有一处人工确认项） |")
    A("| 4 | **Provenance**：每件 PDF SHA-256 记录且随包一致；`datasheet_url` 均为 TI 官方域 | 可签 |")
    A("| 5 | **Package 字段是模型抽取**，未过确定性核验 | 只在 Pins 维度作参考，不单独算 verified |")
    A("")
    A("---")
    A("")

    # ── 总览 ──────────────────────────────────────────────────────────
    A("## 1. 总览矩阵")
    A("")
    A("| 件 | PDF SHA（前12） | Identity | Electrical | AbsMax | Thermal/ESD | **Pins（硬闸）** | Evidence | 风险队列 |")
    A("|---|---|---|---|---|---|---|---|---|")
    for m in MPNS:
        d = docs[m]
        bi = d.get("basic_info") or {}
        sp = d.get("specs") or {}
        meta = d.get("metadata") or {}
        sha = str(meta.get("pdf_hash") or "")[:12]
        pv = meta.get("pin_validation") or {}
        st = str(pv.get("status") or "missing")
        icon = {"passed": "✅", "failed": "❌", "unverified": "⚠️"}.get(st, "❌")
        fa_m = fa["mpns"].get(m) or {}
        _idc = str(bi.get("identity_confidence") or "")
        A(f"| {m} | `{sha}` | {'✅' if _idc in ('high', '') else '⚠️ ' + _idc} | "
          f"{_dist(sp.get('electrical'))[1]} | "
          f"{_dist(sp.get('absolute_max'))[1]} | "
          f"{len(sp.get('thermal') or [])}T/{len(sp.get('esd') or [])}E | "
          f"{icon} `{st}` | {fa_m.get('coord')}/{fa_m.get('n_rows')} · "
          f"{fa_m.get('anchor_gate')} | {risk.get(m, 0)} |")
    A("")
    A("---")
    A("")

    # ── 逐件 ──────────────────────────────────────────────────────────
    A("## 2. 逐件明细")
    A("")
    for i, m in enumerate(MPNS, 1):
        d = docs[m]
        bi = d.get("basic_info") or {}
        sp = d.get("specs") or {}
        meta = d.get("metadata") or {}
        fa_m = fa["mpns"].get(m) or {}
        pv = meta.get("pin_validation") or {}
        pins = d.get("pin_configuration") or []
        norm = meta.get("normalize") or {}
        A(f"### 2.{i} {m}")
        A("")
        A("| 维度 | 实况 | 状态 |")
        A("|---|---|---|")
        _ic = str(bi.get("identity_confidence") or "")
        A(f"| Identity | `{bi.get('identity')}` / `{bi.get('identity_state')}` / "
          f"confidence={_ic or meta.get('confidence')} / "
          f"requested==mpn：{bi.get('mpn') == m} | "
          f"{'✅' if (_ic in ('high', '') and bi.get('identity_state') in ('IDENTITY_SUPPORTED', 'BOARD_CONFIRMED')) else '⚠️'} |")
        A(f"| Scope | `{sp.get('scope')}` / findings="
          f"{len(meta.get('scope_contract_findings') or [])} | ✅ |")
        for key, label in CONTAINERS:
            rows = sp.get(key) or []
            if not rows:
                A(f"| {label} | 0 行（源文档无此表，或已被列塌缩隔离） | · |")
                continue
            _, desc, icon = _dist(rows)
            if key in ("thermal", "esd"):
                # 确定性容器：行级没有 `verification` 是设计，不是缺口。
                # 但「容器级确定性复现」也不等于「逐行审过」，措辞要留分寸。
                A(f"| {label} | {len(rows)} 行 · **确定性抽取**（按参数名+条件+数值复现，"
                  f"行级无 `verification` 是设计） | ✅ |")
                continue
            A(f"| {label} | {len(rows)} 行：{desc} | {icon} |")
        if pv:
            A(f"| Pins | {len(pins)} 脚 · `pin_validation.status={pv.get('status')}` / "
              f"`reason={pv.get('reason')}` · actual={pv.get('actual_count')} · "
              f"det={pv.get('det_count')} · model={pv.get('model_count')} · "
              f"expected={pv.get('expected_count') or pv.get('expected_counts') or '—'}"
              + (f" · dup={pv.get('dup_names')}" if pv.get("dup_names") else "")
              + f" | {'✅' if pv.get('status') == 'passed' else ('❌' if pv.get('status') == 'failed' else '⚠️')} |")
        else:
            A(f"| Pins | {len(pins)} 脚 · **`pin_validation` 缺失** | ❌ |")
        A(f"| Evidence | row {fa_m.get('grades', {}).get('row_anchor')}/"
          f"{fa_m.get('grades_denominator')}（分母=可判行，总行 {fa_m.get('n_rows')}） · paragraph "
          f"{fa_m.get('grades', {}).get('paragraph_anchor')} · container "
          f"{fa_m.get('grades', {}).get('container_verified')} · weak "
          f"{fa_m.get('grades', {}).get('weak')} · `{fa_m.get('anchor_gate')}` | "
          f"{'✅' if fa_m.get('anchor_gate') == 'pass' else '⚠️'} |")
        A(f"| Provenance | `{meta.get('model_version')}` / `{meta.get('prompt_version')}` / "
          f"core=`{meta.get('core_validation')}` / ac=`{meta.get('ac_data_state')}` / "
          f"quarantine={meta.get('quarantine_count', 0)} / "
          f"normalize={'yes' if norm else 'no'} | ✅ |")
        A("")
        blocked = fa_m.get("blocked") or []
        if blocked:
            A("**未达门槛的行（前 6 条）**：")
            A("")
            for b in blocked[:6]:
                A(f"- `{b}`")
            if len(blocked) > 6:
                A(f"- …另 {len(blocked) - 6} 条，见 `risk_queue.csv`")
            A("")
        A("**人工裁决项**：")
        A("")
        if pv.get("status") == "passed":
            A(f"- [ ] Pins：`passed`（{pv.get('reason')}）—— 复核 `det_count={pv.get('det_count')}` "
              f"是否覆盖到每个脚名（`passed` 只对账**总数**，不等于每脚都有 PDF 证据）")
        elif pv.get("status") == "failed":
            A(f"- [ ] Pins ❌ `{pv.get('reason')}`"
              + (f"，重名 `{pv.get('dup_names')}`" if pv.get("dup_names") else "")
              + " —— 逐脚对照 PDF 整改或明确豁免")
        else:
            A(f"- [ ] Pins ⚠️ `{pv.get('reason')}` —— "
              + ("多封装脚数不唯一，需人工确认按哪个封装签核"
                 if pv.get("reason") == "count_unverified" else "需人工确认"))
        A(f"- [ ] Evidence：{len(blocked)} 条未达门槛行 + 风险队列 {risk.get(m, 0)} 行逐行裁决")
        A("")

    # ── 签核页 ────────────────────────────────────────────────────────
    A("---")
    A("")
    A("## 3. 签核汇总页（CONTENT_APPROVED 由人工填写）")
    A("")
    A("> 规则：逐件逐字段；`pin_validation` 非 `passed` 不得标 verified；"
      "❌ 行未经整改或明确豁免不得签；未验证字段继续标未验证。")
    A("")
    A("| 件 | Pins 硬闸 | 建议口径 | CONTENT_APPROVED（人工勾选） |")
    A("|---|---|---|---|")
    for m in MPNS:
        pv = (docs[m].get("metadata") or {}).get("pin_validation") or {}
        st = pv.get("status") or "missing"
        _fam = fa["mpns"].get(m) or {}
        A(f"| {m} | `{st}` | {_advice(pv, len(_fam.get('blocked') or []), risk.get(m, 0))} | "
          f"- [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |")
    A("")
    A("**数据来源**：`data/staging_batch20_v3_final/` 的 `parsed/*.json`、`facts_audit.json`、"
      "`facts_verdicts.json`、`risk_queue.csv`。本文件由 `qc/gen_v3f_checklist.py` 生成，"
      "所有数字为机器实测，未手工填写。")
    A("")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"写入 {OUT}（{len(lines)} 行）")
    for m in MPNS:
        pv = (docs[m].get("metadata") or {}).get("pin_validation") or {}
        print(f"  {m:<20} pin={pv.get('status')}/{pv.get('reason')} "
              f"det={pv.get('det_count')} model={pv.get('model_count')} "
              f"gate={(fa['mpns'].get(m) or {}).get('anchor_gate')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
