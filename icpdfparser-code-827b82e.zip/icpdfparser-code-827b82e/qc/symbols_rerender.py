#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""存量 symbols 页批量重渲染：沙箱优先，`--apply` 才写生产。

为什么要单独一个工具
--------------------
`qc/symbols_render_diff.py` 证明的是「五件上只有该变的变了」，它比的是**渲染器前后
两个版本**。存量 7725 页是另一件事：输入是 `data/parsed` 的磁盘快照、比的是**磁盘上的
旧页面**与**现在重渲染的结果**，中间隔着若干代渲染器改动。两者不是同一把尺子。

判据（只测量，不猜）
--------------------
逐件渲染后按四件事分类：

1. `symbol_same`：``aria-label="… schematic symbol"`` 的 `<svg>` 块**逐字节相同**。
   这是本轮唯一的硬承诺 —— 状态分层只动文案，不动图形。旧页面没有该块时记 `no_anchor`
   （旧版页面格式，不判红但要计数）。
2. `boundary_ok`：新页面的「工程模型边界」小节逐条 == ``render_notes(state)``。
3. `findings == 0`：``engineering_model.check`` 对新页面零 findings（A1–A5 自证）。
4. 可见文本的增删**只允许**落在状态派生文案的允许集内（旧两段重复文案被删、状态短标签
   被加）。超出允许集的增删不直接判红，但逐条计数并留样本 —— 那是「别的改动漏进来了」
   的信号，由人看，不由脚本自动放行。

安全阀
------
- 默认只写 `--out`（`.sandbox/symbols_rerender/`），**不碰** `data/symbols`；
- `--apply` **只覆盖 `ok` 子集**（符号 SVG 逐字节相同 + 边界小节正确 + 门禁零 findings
  + mpn 一致 + 未降级），其余分类逐类报数并留在原地；
- 硬闸只留「渲染异常」——流程本身坏了就不能写生产；
- `--apply` 前先把 `data/symbols` 压成 zip，并写 `manifest.json`（逐件 before/after 字节数
  与来源 JSON），事后可逐件回滚；
- `--only <清单>` 只覆盖清单里的件，且只能在 `ok` ∪ allowlist 里**做交集**（越界件拒绝写盘）。
  分批覆盖让爆炸半径等于本批件数，而不是全库。

用法
----
    python qc/symbols_rerender.py                 # 全量沙箱 + 报告
    python qc/symbols_rerender.py --limit 20      # 冒烟 20 件
    python qc/symbols_rerender.py --apply         # 闸门全绿才真正覆盖生产
    python qc/symbols_rerender.py --apply --only batch.txt   # 只覆盖本批
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import time
import traceback
import zipfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc.symbols_overbar_scan import classify_pair   # noqa: E402
from qc.symbols_render_diff import (       # noqa: E402
    NEW_CAPTIONS, OLD_CAPTIONS, _strip_boundary, _symbol_block, _visible,
    _without_symbol, text_is_allowed,
)

_HASH_LEN = 8

#: 塌缩门槛（与 `symbols_rerender_audit` 同口径，改这里要同步那边的 `STRATA` 注释）。
#: 这两个数字挡的是 2026-10-31 那次事故：第一版判据只看「符号逐字节相同 + 边界小节对」，
#: 于是 361 件页面被换成「三张卡 + 边界小节」的瘦版都没被拦住（`F28P650DK9PTP` 74 KB→2.8 KB，
#: 整张引脚表消失）。现在它是一条**独立的类**，不是 `not_ok` 里的一个计数。
COLLAPSE_BYTE_RATIO = 3
COLLAPSE_TEXT_LOSS = 10

#: 这些状态**永不**进 allowlist：它们不是「文案差异」，是内容消失或主语换了。
HARD_BLOCK = ("collapse", "downgrade", "mpn_mismatch", "empty_render", "error")


#: 这五种符号判据**可以**放行剩下的事（边界/门禁/文本/塌缩）由 `decide` 各自再判一次。
#: `overbar_only` / `label_only` / `dash_only` 在这里而不是在 allowlist 里：它们是规则，
#: 不是特批 —— 有测试、可回滚、对新解析的件同样生效；allowlist 是一条没人复核的旁路。
RELEASABLE_SYMBOL = ("same", "no_anchor", "overbar_only", "label_only", "dash_only")


#: 符号块的三种「妆容级」差异 —— 都要求归一化后**逐字节相同**，不是相似度。
#: 归一化只做减法（删掉/折叠某个确定的东西），绝不替换成近似值。
_ARIA_RE = re.compile(r'\saria-label="[^"]*"')
_DASH_MAP = str.maketrans({"\u2013": "-", "\u2014": "-", "\u2212": "-"})


def fold_dash(s: str) -> str:
    """把三种破折号（en-dash / em-dash / 减号）归一成 ASCII hyphen。"""
    return s.translate(_DASH_MAP)


def dash_only_of(old_sym: str, new_sym: str) -> bool:
    """符号块**只**是破折号写法不同（`V–` → `V-`）。

    旧页是更早的渲染器画的，引脚名里留着 en-dash(U+2013)；新渲染器统一用 ASCII
    hyphen。语义不变（都表示 "V minus"），ASCII 才是正确写法 —— 所以这是修正，
    不是差异。破折号之外的任何改动都会让折叠后仍然不相等，于是判 False。
    """
    if not old_sym or not new_sym:
        return False
    return fold_dash(old_sym) == fold_dash(new_sym)


def _aria_mpn(block: str) -> str:
    """符号块 `aria-label` 里的型号名（`<mpn> schematic symbol` 的前半段）。"""
    m = re.search(r'aria-label="([^"]*?)\s+schematic symbol"', block)
    return m.group(1).strip() if m else ""


def label_only_of(old_sym: str, new_sym: str, mpn: str) -> bool:
    """符号块**只**是 `aria-label` 里的型号名不同，且新名字就是本件 mpn。

    三条全成立才算：

    1. 两侧都有符号块（缺一侧是 `no_anchor` / `downgrade` 的活，不归这里）；
    2. 剥掉 `aria-label` 后两块**逐字节相同** —— 几何、引脚名、线数全一致；
    3. 新 aria-label 里的型号名 == 本件 mpn。

    第 3 条防的是「旧页 A、新页 B、都不是文件名 C」的脏数据被当成改名放行：
    只有新名字**就是这一页的主语**时，才叫修正。

    不在这里折叠破折号：`label_only` 要的是剥标签后逐字节相同，折叠会让
    「标签换了 + 破折号也换了」的件混进来。
    """
    if not old_sym or not new_sym:
        return False
    if _ARIA_RE.sub("", old_sym) != _ARIA_RE.sub("", new_sym):
        return False
    return _aria_mpn(new_sym) == mpn


def fold_mpn(texts: list[str], old_mpn: str, mpn: str) -> list[str]:
    """`label_only` 成立时，把旧侧文本里的旧型号名换成本件 mpn 再比差集。

    不这么做的话这 5 件永远过不去：`<h1>` 与副标题里的型号名变了，
    `removed_extra` / `added_extra` 非空，`decide` 照样判 `not_ok` —— 判据
    写了等于没写。型号名之外的任何一条差异不会被折掉，仍然照拦。
    """
    if not old_mpn:
        return list(texts)
    return [t.replace(old_mpn, mpn) for t in texts]


#: 「BGA 球位待核」说明页的稳定标记：`_bga_unverified_page` 的 `<title>`。
#: 它是渲染器的 fail-closed 产物 —— 一页只剩五句话，三视图全没了。
BGA_NOTE_TITLE = "· BGA 球位待核</title>"


def is_downgrade(old_page: str, new_page: str) -> bool:
    """三视图退化成「BGA 球位待核」说明页。

    两条路，任何一条成立都算降级：

    1. 旧页有原理图符号块、新页没有（原判据）；
    2. **旧页不是说明页、新页是**（补上的一条）。

    第 2 条挡的是实测 46 件：旧页是 PDF 无引脚表的三视图（有封装图与 3D，但没有
    `schematic symbol` 块），新页因为 `data/parsed` 缺球位映射被渲染成说明页。
    原判据看 `old_sym and not new_sym`，旧页没有符号块时它**根本不触发**，
    于是整页内容消失却被记成 `not_ok` —— 而 `not_ok` 是**可以**被 allowlist 放行的类。
    一次人工特批就会让 46 页静默变空；`downgrade` 在 `HARD_BLOCK` 里，永不放行。
    """
    if BGA_NOTE_TITLE in new_page and BGA_NOTE_TITLE not in old_page:
        return True
    return bool(_symbol_block(old_page)) and not _symbol_block(new_page)


def symbol_ok_of(status: str) -> bool:
    """符号判据是否放行。反悔成本 = 改这一行 + 改对应测试，不用清理清单。"""
    return status in RELEASABLE_SYMBOL


def symbol_status(symbol_same: bool, no_anchor: bool,
                  overbar_only: bool = False,
                  label_only: bool = False,
                  dash_only: bool = False) -> str:
    """符号块判据：``same`` / ``no_anchor`` / 三种妆容级 / ``diff``。

    为什么不能只留布尔值：``symbol_same=False`` 曾同时代表「图真的变了」和
    「这页本来就没有原理图符号块」，读 JSON 的人要靠 ``no_anchor`` 二次推断，
    漏看一次就把 414 件说明页当成「图坏了」，或者反过来把真差异当成空真放过去。

    ``overbar_only`` = 符号块**只多了低有效引脚的上划线**，且把新增的 `<line>`
    删掉后与旧块逐字节相同（判据在 `qc/symbols_overbar_scan.classify_pair`）。
    它是正确性修复（`active_low_of` 从 PDF 的 "Active Low" 描述推出），
    但终究是图形变化，所以单独记一档，不放进 `same`。

    `symbol_same` 保持原语义不动，避免下游解析被破坏。
    """
    if no_anchor:
        return "no_anchor"
    if symbol_same:
        return "same"
    if overbar_only:
        return "overbar_only"
    if label_only:
        return "label_only"
    return "dash_only" if dash_only else "diff"


def decide(*, symbol_ok: bool, boundary_ok: bool, findings: list,
           removed_extra: list, added_extra: list,
           collapse: bool) -> str:
    """单件的分类判决（纯函数，便于红先测试）。

    顺序有意义：`collapse` 优先于一切 —— 页面塌缩了就不是「文案越界」，
    更不能因为符号块恰好一样就放行。
    """
    if collapse:
        return "collapse"
    if symbol_ok and boundary_ok and not findings and not removed_extra and not added_extra:
        return "ok"
    return "not_ok"



def index_parsed(parsed_dir: Path) -> dict[str, Path]:
    """mpn → parsed JSON。文件名是 ``<mpn>_<hash>.json``，同名多版本取 mtime 最新。"""
    out: dict[str, Path] = {}
    for p in parsed_dir.glob("*.json"):
        stem = p.stem
        if (len(stem) > _HASH_LEN
                and stem[-_HASH_LEN - 1] == "_"
                and all(c in "0123456789abcdef" for c in stem[-_HASH_LEN:])):
            mpn = stem[:-_HASH_LEN - 1]
        else:
            mpn = stem
        prev = out.get(mpn)
        if prev is None or p.stat().st_mtime >= prev.stat().st_mtime:
            out[mpn] = p
    return out


def _norm(s: str) -> str:
    """mpn 比对用：只留字母数字，忽略大小写与分隔符。"""
    return "".join(ch for ch in str(s or "").lower() if ch.isalnum())


def _one(job: tuple) -> dict:
    """渲染一件 + 分类 + 落沙箱。子进程里跑，异常一律收敛成 status=error。"""
    name, html_path, json_path, pkgs_dir, out_dir = job
    try:
        import symbol_svg as S
        from qc import engineering_model as EM

        old = Path(html_path).read_text(encoding="utf-8", errors="replace")
        doc = json.loads(Path(json_path).read_text(encoding="utf-8"))

        # 闸 1：JSON 里的 mpn 必须就是这一页的主语。
        # 实测 25BR400DVI-EVK 的 parsed JSON 里 `basic_info.mpn` 是 `DS25BR400`
        # （板卡页对应的是板载芯片），照着重渲染会把页面标题改成别家型号 —— 比不改更糟。
        doc_mpn = (doc.get("basic_info") or {}).get("mpn") or ""
        if doc_mpn and _norm(doc_mpn) != _norm(name):
            return {"mpn": name, "status": "mpn_mismatch", "doc_mpn": str(doc_mpn),
                    "old_bytes": len(old.encode("utf-8"))}

        new = S.render_page(json.loads(json.dumps(doc)), pkg_dir=Path(pkgs_dir))
        if not new:
            return {"mpn": name, "status": "empty_render", "old_bytes": len(old)}

        old_sym, new_sym = _symbol_block(old), _symbol_block(new)
        # 闸 2：降级。`is_downgrade` 认两条路：旧页有符号块而新页没有；以及
        # 旧页不是「BGA 球位待核」说明页而新页是（旧页无符号块时也要认出来，
        # 否则这 46 件会被记成 `not_ok`，而 `not_ok` 是能被 allowlist 放行的类）。
        if is_downgrade(old, new):
            return {"mpn": name, "status": "downgrade", "old_bytes": len(old.encode("utf-8")),
                    "new_bytes": len(new.encode("utf-8"))}

        Path(out_dir, Path(html_path).name).write_text(new, encoding="utf-8")

        symbol_same = bool(old_sym) and old_sym == new_sym
        no_anchor = not old_sym
        # 符号块不同时再判一次「是不是只多了上划线」：判据复用扫描器，
        # 不在两处各写一份 —— 两份判据迟早会漂。
        overbar_only = (not symbol_same) and not no_anchor and bool(new_sym) and (
            classify_pair(old, new)[0] == "overbar_only")
        # 另外两种妆容级差异：`label_only`（只换了 aria-label 里的型号名）与
        # `dash_only`（只换了破折号写法）。判据与 `overbar_only` 同构：归一化后
        # **逐字节相同**才算，不是相似度。顺序有意义 —— `label_only` 更严格，先判它。
        label_only = (not symbol_same) and not no_anchor and bool(new_sym) and (
            not overbar_only) and label_only_of(old_sym, new_sym, name)
        dash_only = (not symbol_same) and not no_anchor and bool(new_sym) and (
            not overbar_only) and (not label_only) and dash_only_of(old_sym, new_sym)
        sym_status = symbol_status(symbol_same, no_anchor, overbar_only,
                                   label_only, dash_only)

        state = EM.derive_state_for_page(doc, Path(pkgs_dir), new)
        notes = EM.render_notes(state)
        boundary_ok = (EM._boundary_items(new) or []) == notes      # noqa: SLF001
        findings = [f["kind"] for f in EM.check(doc, new, state)]

        # 文本判据只看**符号块以外、边界小节以外**的文案：
        #   ① 符号块里的引脚名由 `symbol_same` 逐字节断言，两边都算就是同一处变化算两次；
        #   ② 边界小节由 `boundary_ok` 断言，且**两侧都要剥** —— 旧页若是已覆盖过的页面，
        #      它已经带着边界小节，只剥新页会让那几条凭空变成「被删文本」（实测 3 条/件）。
        old_text = _visible(_strip_boundary(_without_symbol(old)))
        new_text = _visible(_strip_boundary(_without_symbol(new)))
        # 妆容级符号差异要连带折叠文本侧，否则判据写了等于没写：
        # 型号名在 `<h1>`/副标题里也出现一次，不折叠的话 `removed_extra` 永远非空。
        # 折叠只动那一处已知的东西，其它差异一个都不会被抹掉。
        if label_only:
            old_text = fold_mpn(old_text, _aria_mpn(old_sym), name)
        if dash_only:
            old_text = [fold_dash(t) for t in old_text]
            new_text = [fold_dash(t) for t in new_text]
        new_set, old_set = set(new_text), set(old_text)
        removed = [t for t in old_text if t not in new_set]
        added = [t for t in new_text if t not in old_set]
        removed_extra = [t for t in removed if not text_is_allowed(t, OLD_CAPTIONS, name)]
        added_extra = [t for t in added if not text_is_allowed(t, NEW_CAPTIONS, name)]

        # 塌缩：内容消失了。这条**先于** ok 判，因为它可能满足所有其它判据
        # （符号块恰好一样、边界小节也对），却把整张引脚表弄没了。
        old_b, new_b = len(old.encode("utf-8")), len(new.encode("utf-8"))
        text_lost = len(old_text) - len(new_text)
        collapse = bool((old_b and new_b and new_b * COLLAPSE_BYTE_RATIO <= old_b)
                        or text_lost >= COLLAPSE_TEXT_LOSS)

        status = decide(symbol_ok=symbol_ok_of(sym_status), boundary_ok=boundary_ok,
                        findings=findings, removed_extra=removed_extra,
                        added_extra=added_extra, collapse=collapse)
        return {
            "mpn": name, "status": status,
            "old_bytes": old_b, "new_bytes": new_b,
            "text_lost": text_lost,
            "symbol_same": symbol_same, "no_anchor": no_anchor,
            "overbar_only": overbar_only,
            "label_only": label_only,
            "dash_only": dash_only,
            "symbol_status": sym_status,
            "boundary_ok": boundary_ok, "findings": findings,
            "n_removed_extra": len(removed_extra), "n_added_extra": len(added_extra),
            "removed_extra": removed_extra[:6], "added_extra": added_extra[:6],
            "state": state,
        }
    except Exception as e:                                       # noqa: BLE001
        return {"mpn": name, "status": "error",
                "error": f"{type(e).__name__}: {e}"[:200],
                "tb": traceback.format_exc()[-500:]}



def _backup(symbols_dir: Path, dest: Path) -> int:
    dest.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(symbols_dir.glob("*.html")):
            z.write(p, arcname=p.name)
            n += 1
    return n


def _summarize(rows: list[dict], pages: int, missing: list[str], t0: float) -> dict:
    agg: dict[str, int] = {}
    for r in rows:
        agg[r["status"]] = agg.get(r["status"], 0) + 1
    #: 口径跟 `symbol_status` 对齐：只有 `diff` 才算符号漂移。
    #: 别再写 `not (symbol_same or no_anchor)` —— `overbar_only` 放行之后，
    #: 那个式子会把「有 findings 的纯上划线件」也算成漂移（实测 21 vs 20）。
    bad_symbol = [r["mpn"] for r in rows if r.get("symbol_status") == "diff"]
    bad_boundary = [r["mpn"] for r in rows if r.get("boundary_ok") is False]
    with_findings = [r["mpn"] for r in rows if r.get("findings")]
    extra = [r for r in rows if r.get("n_removed_extra") or r.get("n_added_extra")]
    errors = [r for r in rows if r["status"] == "error"]
    no_anchor = [r["mpn"] for r in rows if r.get("no_anchor")]
    mismatch = [r for r in rows if r["status"] == "mpn_mismatch"]
    downgrade = [r["mpn"] for r in rows if r["status"] == "downgrade"]
    collapse = [r for r in rows if r["status"] == "collapse"]
    #: 三态只统计**真比过符号块**的行。`downgrade` / `mpn_mismatch` / `empty_render`
    #: 在比较之前就 return 了，没有这个字段 —— 不能兜底算成 `diff`：那会把 898 件
    #: 没测过的件谎报成「图变了」，比不统计更糟。
    sym = {"same": 0, "no_anchor": 0, "overbar_only": 0, "label_only": 0,
           "dash_only": 0, "diff": 0, "not_measured": 0}
    for r in rows:
        s = r.get("symbol_status")
        sym[s if s in sym else "not_measured"] += 1
    return {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "pages": pages, "rendered": len(rows), "missing_json": len(missing),
        "missing_json_sample": missing[:10],
        "status": agg,
        "symbol_status": sym,
        "symbol_drift": len(bad_symbol), "boundary_drift": len(bad_boundary),
        "with_findings": len(with_findings), "with_extra_text": len(extra),
        "errors": len(errors), "no_anchor": len(no_anchor),
        "mpn_mismatch": len(mismatch), "downgrade": len(downgrade),
        "collapse": len(collapse),
        "examples": {
            "symbol_drift": bad_symbol[:10],
            "boundary_drift": bad_boundary[:10],
            "with_findings": with_findings[:10],
            "errors": [[r["mpn"], r["error"]] for r in errors[:10]],
            "extra_text": [[r["mpn"], r["added_extra"], r["removed_extra"]] for r in extra[:10]],
            "no_anchor": no_anchor[:10],
            "mpn_mismatch": [[r["mpn"], r.get("doc_mpn")] for r in mismatch[:10]],
            "downgrade": downgrade[:10],
            "collapse": [[r["mpn"], r["old_bytes"], r["new_bytes"], r["text_lost"]]
                         for r in collapse[:10]],
        },
        "seconds": round(time.time() - t0, 1),
    }


def load_allowlist(path) -> tuple[set[str], dict[str, dict], list[str]]:
    """读人工裁决白名单：返回（放行 mpn 集合、逐条裁决、问题清单）。

    格式（JSON，数组或 `{"allow": [...]}` 都吃）::

        [{"mpn": "1A1G04QDBVRG4Q1", "stratum": "mpn_renamed",
          "by": "wang", "why": "旧页标题是旧 mpn，新页跟当前 JSON 一致"}]

    `by` / `why` 必填：没有裁决人和理由的白名单条目，三个月后没人能复核。
    记录是**证据**，不是开关 —— 缺字段一律当问题报出来，不静默接受。
    """
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    items = raw.get("allow") if isinstance(raw, dict) else raw
    allow: set[str] = set()
    meta: dict[str, dict] = {}
    problems: list[str] = []
    for i, it in enumerate(items or []):
        if not isinstance(it, dict):
            problems.append(f"第 {i} 条不是对象")
            continue
        mpn = str(it.get("mpn") or "").strip()
        if not mpn:
            problems.append(f"第 {i} 条缺 mpn")
            continue
        missing = [k for k in ("by", "why") if not str(it.get(k) or "").strip()]
        if missing:
            problems.append(f"{mpn} 缺 {'/'.join(missing)}")
            continue
        allow.add(mpn)
        meta[mpn] = it
    return allow, meta, problems


def load_only(path) -> set[str]:
    """读「本次只覆盖这些 mpn」清单（一行一件，或 JSON 数组 / `{"only": [...]}`）。

    这是**收窄**闸门的口子，不是放行的口子：它只能在 `ok` ∪ allowlist 里做交集，
    永远不会把非 `ok` 的件拉进来（交集在 `main` 里做，能拉进来才叫漏洞）。

    存在的理由：全量 4503 件 `ok` 里 4406 件早就是当前渲染器的产物，为了 97 件新绿的
    页面把整库 4503 件重写一遍，爆炸半径从 97 放大到 4503，回滚成本同比放大。
    分批覆盖 + 每批一份 manifest，才是可回滚的形态。
    """
    text = Path(path).read_text(encoding="utf-8").strip()
    if text.startswith(("[", "{")):                 # JSON：数组或 {"only": [...]}
        raw = json.loads(text)
        items = raw.get("only") if isinstance(raw, dict) else raw
    else:                                          # 纯文本：一行一件，# 注释
        items = [ln.strip() for ln in text.splitlines()
                 if ln.strip() and not ln.lstrip().startswith("#")]
    return {str(x).strip() for x in (items or []) if str(x).strip()}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="存量 symbols 页批量重渲染（沙箱优先）")
    ap.add_argument("--symbols", default=str(ROOT / "data" / "symbols"))
    ap.add_argument("--parsed", default=str(ROOT / "data" / "parsed"))
    ap.add_argument("--pkg-lib", default=str(ROOT / "data" / "pkgs"))
    ap.add_argument("--out", default=str(ROOT / ".sandbox" / "symbols_rerender"))
    ap.add_argument("--json", default="")
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 件（冒烟）")
    ap.add_argument("--apply", action="store_true", help="闸门全绿后覆盖生产页面")
    ap.add_argument("--backup", default="", help="apply 前的备份 zip 路径")
    ap.add_argument("--allowlist", default="",
                    help="人工裁决白名单 JSON（每条须带 by/why）；只影响 --apply")
    ap.add_argument("--only", default="",
                    help="只覆盖这个清单里的 mpn（一行一件或 JSON）；只能在 ok∪allowlist 里收窄")
    a = ap.parse_args(argv)

    symbols_dir, parsed_dir = Path(a.symbols), Path(a.parsed)
    pkgs_dir, out = Path(a.pkg_lib), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    pages = sorted(symbols_dir.glob("*.html"))
    if a.limit:
        pages = pages[: a.limit]
    idx = index_parsed(parsed_dir)
    jobs, missing = [], []
    for p in pages:
        j = idx.get(p.stem)
        if j is None:
            missing.append(p.stem)
        else:
            jobs.append((p.stem, str(p), str(j), str(pkgs_dir), str(out)))
    print(f"页面 {len(pages)} 件；有对应 parsed JSON {len(jobs)} 件；缺 JSON {len(missing)} 件")

    t0 = time.time()
    rows: list[dict] = []
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        for i, r in enumerate(ex.map(_one, jobs, chunksize=20), 1):
            rows.append(r)
            if i % 1000 == 0:
                print(f"  … {i}/{len(jobs)}  {time.time() - t0:.0f}s", flush=True)

    summary = _summarize(rows, len(pages), missing, t0)
    if a.json:
        Path(a.json).write_text(json.dumps({"summary": summary, "rows": rows},
                                          ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    if not a.apply:
        ok_n = sum(1 for r in rows if r["status"] == "ok")
        print(f"\n沙箱已写 {ok_n} 件 → {out}（生产未动）")
        return 0 if not summary["errors"] and not summary["symbol_drift"] else 1

    # ── apply 闸门 ──
    # 默认只覆盖 `ok`：符号逐字节相同 + 边界小节 == render_notes + 门禁零 findings
    # + mpn 一致 + 未降级 + 未塌缩 + 文本不越界。其余分类**一律留在原地**并逐类报数。
    # 人工裁决过的件可以经 `--allowlist` 放行，但 `HARD_BLOCK` 里的类**永不**放行：
    #   collapse     = 内容消失（不是文案差异）
    #   downgrade    = 三视图退化成「球位待核」说明页
    #   mpn_mismatch = JSON 的主语不是这一页（改了会换标题）
    # 硬闸只留「渲染异常」——流程本身坏了就不能写生产。
    if summary["errors"]:
        print(f'\n拒绝覆盖生产：{summary["errors"]} 件渲染异常'
              f'（沙箱结果仍保留在 --out）', file=sys.stderr)
        return 1

    status_of = {r["mpn"]: r["status"] for r in rows}
    row_of = {r["mpn"]: r for r in rows}
    allow, allow_meta = set(), {}
    if a.allowlist:
        allow, allow_meta, problems = load_allowlist(a.allowlist)
        if problems:
            print(f"\n拒绝覆盖生产：白名单有 {len(problems)} 条不合格"
                  f"（每条须带 mpn/by/why）：{problems[:5]}", file=sys.stderr)
            return 1
        blocked = sorted(m for m in allow if status_of.get(m) in HARD_BLOCK)
        if blocked:
            print(f"\n拒绝覆盖生产：{len(blocked)} 件白名单落在硬阻断类"
                  f"（{'/'.join(HARD_BLOCK)}），不许放行：{blocked[:5]}", file=sys.stderr)
            return 1
        unknown = sorted(m for m in allow if m not in status_of)
        if unknown:
            print(f"注意：白名单 {len(unknown)} 件不在本次页面集合，已跳过：{unknown[:5]}",
                  file=sys.stderr)

    ok_set = {m for m, s in status_of.items() if s == "ok"}
    target = ok_set | (allow & set(status_of))      # 不在本次页面集合的白名单条目上面已报过
    if a.only:
        only = load_only(a.only)
        outside = sorted(only - target)
        if outside:
            # 整批拒绝，不是「跳过那几件」：跳过会让操作者以为「清单里的都覆盖了」，
            # 实际漏掉几件还返回成功 —— 分批覆盖最怕的就是这种静默缩水。
            print(f"\n拒绝覆盖生产：--only 清单有 {len(outside)} 件不在放行集合"
                  f"（ok ∪ 白名单），整批不执行：{outside[:5]}", file=sys.stderr)
            return 1
        target &= only
        if not target:
            print("\n拒绝覆盖生产：--only 与放行集合交集为空（没有可写的东西）", file=sys.stderr)
            return 1
    skipped = {k: v for k, v in summary["status"].items() if k != "ok"}
    print(f"\n将覆盖 {len(target)} 件（ok {len(ok_set)} + 白名单新增 {len(target - ok_set)}）；"
          f"跳过 {len(status_of) - len(target)} 件：{skipped}")

    backup = Path(a.backup) if a.backup else (
        ROOT / ".sandbox" / f"symbols_backup_{time.strftime('%Y%m%d_%H%M%S')}.zip")
    print(f"已备份 {_backup(symbols_dir, backup)} 件 → {backup}")

    manifest, written = [], 0
    for p in pages:
        if p.stem not in target:
            continue
        src = out / p.name
        if not src.is_file():
            continue
        before = p.stat().st_size
        shutil.copyfile(src, p)
        row = {"mpn": p.stem, "before_bytes": before,
               "after_bytes": p.stat().st_size, "parsed": idx[p.stem].name,
               "via": "allowlist" if p.stem in allow else "ok",
               "status_before": status_of.get(p.stem),
               "symbol_status": row_of[p.stem].get("symbol_status")}
        if p.stem in allow_meta:                    # 裁决记录随页面一起留证
            meta = allow_meta[p.stem]
            row.update({"stratum": meta.get("stratum"), "by": meta.get("by"),
                        "why": meta.get("why")})
        manifest.append(row)
        written += 1
    mpath = out / "manifest.json"
    mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已覆盖 {written} 件；清单 {mpath}；备份 {backup}")
    if written != len(target):
        print(f"注意：目标 {len(target)} 件但只覆盖 {written} 件（沙箱缺文件）", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
