#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""确定性抽取：pins / thermal / esd / VCMI / VID 不依赖 LLM。

为什么必须这么做（2026-10-31 取证）
----------------------------------
`qwen-flash` 同一份 prompt、同一份 PDF，两次运行差异巨大：

| 运行 | electrical | VCMI | pins | ESD |
|---|---|---|---|---|
| v4 | 19 | 全缺 | 64（纯序号） | `+2000` |
| v5 | 23 | 3 条 `0 to 0.55` | 144（球位号） | `±2000` |

在「客户会用 Codex 复跑」的场景下，**不可复现比算错更致命**。所以凡是结构确定
（表格边界清楚、列语义明确）的字段，一律改为代码抽取；LLM 只负责电气表里那些
真正难结构化的行。

两个数据源，各有各的坑
----------------------
* **引脚表用 `find_tables`**：它是 `NAME | NO. | I/O | DESCRIPTION` 四列，
  69 行里有 10 行是**成组**的（`AGND` 一行覆盖 39 个球位），必须展开。
  实测展开后 144 个球位、144 唯一、0 重复 —— 与 FCBGA-144 封装吻合。
  文本层反而不可用：多行单元格会交错，分不清哪行是脚号。
* **热阻 / ESD / ROC 用文本层**：`find_tables` 在这些表上会**融合小数位**
  （`0.23` 读成 `023.`、`0.8` 读成 `08.`），而融合后的字符串**无法反推小数点位置**
  （`239.` 既可能是 23.9 也可能是 2.39）。文本层是干净的：`RθJA | … | 23.9 | °C/W`。
  这正是 Reviewer 判为系统性缺陷的 `column_roles_not_verified` 的根因。
"""
from __future__ import annotations

import hashlib
import re

try:
    from qc.safe_access import dict_rows, safe_dict, safe_list
except ImportError:                                     # 脚本直跑（sys.path[0] = qc/）
    from safe_access import dict_rows, safe_dict, safe_list    # noqa: F401

BALL_RE = re.compile(r"\b([A-Z]\d{1,2})\b")
NUM_RE = re.compile(r"^[+-]?\d+(?:\.\d+)?$")
# 单位/列名不算条件文本，遇到要跳过，否则会被当成「条件行」
UNITISH = {"V", "mV", "mA", "µA", "uA", "A", "GHz", "MHz", "kHz", "Hz", "%", "pF", "nF",
           "Ω", "kΩ", "°C", "°C/W", "dBm", "dBFS/Hz", "dB", "Bits", "GSPS", "MSPS",
           "VPP-DIFF", "mVPP-DIFF", "tCLK cycles", "fs", "s", "ns", "ps", "W", "mW"}
THERMAL_KEYS = ("RθJA", "RθJC(top)", "RθJC(bot)", "RθJB", "ψJT", "ψJB")

#: 热阻参数名的**归一化键**（2026-11-03 V1 列塌缩）。
#: 原文写法不统一：TI 新手册印 `Rθ(JA)`、老手册印 `RθJA`。旧实现拿 `line in
#: THERMAL_KEYS` 直接比字符串，于是 LM317 的 `Rθ(JA)` **一条都匹配不上**，
#: 页面上根本没有 RθJA —— 这不是「源文档没有」，是键写死了。
#: 归一化只去空白与圆括号再大写，`θ`/`ψ` 两侧同口径，不引入任何猜测。
def _thermal_norm(s: str) -> str:
    return re.sub(r"[\s()]", "", (s or "")).upper()


_THERMAL_CANON = {_thermal_norm(k): k for k in THERMAL_KEYS}
#: 最长键优先。`RθJC(top)` / `RθJC(bot)` 归一后都以 `RΘJC` 开头，短键先命中
#: 就会张冠李戴，所以按长度倒序比对。
_CANON_BY_LEN = sorted(_THERMAL_CANON, key=len, reverse=True)


def _thermal_canon(s: str) -> str | None:
    """一行文本 → 规范参数名；支持「参数名与描述挤在同一行」。

    CDC6C（`SNAS843D` p6）把 `RθJC(top) Junction-to-case (top) thermal resistance`
    印成**一行**，而其余参数都是「名字一行、描述一行」。旧实现整串归一后查表
    查不到，于是整条 RθJC(top) 被静默漏掉 —— 工单里「热阻表缺少 RθJC(top)」
    的真实原因不是源文档没有，是匹配写死了整行相等。
    """
    n = _thermal_norm(s)
    hit = _THERMAL_CANON.get(n)
    if hit:
        return hit
    for k in _CANON_BY_LEN:
        if n.startswith(k):
            return _THERMAL_CANON[k]
    return None

#: 热阻表里的「占位符」值。**必须占一列**：LM317 Legacy 的 `RθJC(bot)` 在
#: DCY 列印的是 `NA`，旧实现用 `_is_num` 判据跳过它，于是 0.1（KCS 列）被
#: 当成 DCY 的值写进 JSON —— 静默错列，比缺行更难查。
_PLACEHOLDERS = {"NA", "N/A", "N.A.", "—", "–", "-", "--", "N A"}

#: 封装列单元格：`DCY (SOT-223)` / `KCS(TO-220)` / `KTT (TO-263)`。
#: A22（2026-11-03）：**一行里可能并排多个封装**（`DCY (SOT-223)  KCS (TO-220)
#: KCT (TO-220)  KTT (TO-263)`），必须 findall 而不是 match —— 旧实现只 match 到
#: 第一个，这正是「多列塌缩」的机械根因。NE555 还有单字母封装码（`D (SOIC)`、
#: `P (PDIP)`），所以码长放宽到 1~4。
#:
#: 码放宽之后冒出一个更隐蔽的错列（Issue #23 / LM358 p5）：器件名的**脚注标记**
#: `LM2904V(2)` 与封装列同形，findall 会把 `V (2)` 当成第 1 个封装列 ——
#: 于是八列整体左移一位、`JG (CDIP)` 被挤出窗口，引脚数也跟着错位
#: （`DDF (SOT-23)` 拿到 `20 PINS`，那是 `FK (LCCC)` 的）。
#: 两条约束同时生效才安全：
#:   1. 码左边不能紧邻字母/数字 —— `LM2904V(2)` 的 `V` 左边是 `4`，命中即否；
#:      `THERMAL METRIC(1)` 的 `TRIC` 左边是 `E`，同样否掉；
#:   2. 括号里必须**以字母开头**并且**不是纯数字** —— 脚注只有 `(1)` `(2)`。
#: 单字母真封装码（`D`、`P`）不受影响：它们要么独立成行，要么前面是空白。
_PKG_CELL_RE = re.compile(r"(?<![A-Za-z0-9])([A-Z]{1,4})\s*\(\s*([A-Za-z][A-Za-z0-9\-\s]*?)\s*\)")
#: 引脚数单元格：`4 PINS` / `3 PINS` / `4PIN`（同样可能一行多个）。
_PINS_CELL_RE = re.compile(r"(\d+)\s*PINS?", re.I)

#: 热阻表头行。**必须锚在行首**：脚注
#: `For more information about traditional and new thermal metrics, …`
#: 里也含 "thermal metric"，用 `in` 判会把它当表头，于是同一张表被重复抽两遍
#: （实测 LM317 多出 12 行无表名的 New Chip 行）。
_THERMAL_HEAD_RE = re.compile(r"^thermal\s*metric", re.I)

PIN_PAGE_KEYS = ("pin functions", "terminal functions")


# ---------------------------------------------------------------- 基础工具
def _lines(page) -> list[str]:
    return [x.strip() for x in page.get_text().splitlines() if x.strip()]


def _is_num(s: str) -> bool:
    return bool(NUM_RE.match(s or ""))


def _is_unit(s: str) -> bool:
    return (s or "").strip() in UNITISH


# ---------------------------------------------------------------- 引脚 / 球位
def _pin_pages(fitz_doc, cap: int = 6) -> list[int]:
    """引脚表所在页：首个**真实表头**页 + 其后连续的 `(continued)` 续页。

    只认 `(continued)` 是关键：TI 的引脚表常跨 4-5 页，但中间也会夹别的
    `(continued)` 表（如 EC 续表），不加这个判据会把无关页当引脚页。

    2026-11-03 G2：旧判据只看正文里有没有 `pin functions`，于是 ADS42 的
    **目录页**（`Pin Configuration and Functions.........5`）被当成首张引脚表，
    真正的表在 p6，p4 没有 `(continued)` 就 break —— 引脚数直接掉到 0。
    现在只认**能解析出表头结构**的页（`_pin_header_end` / `_wide_header_start`），
    目录页里没有 `PIN I/O … NAME` 的列头，不会再误启动。
    """
    pages: list[int] = []
    started = False
    last_pin = False
    for i, page in enumerate(fitz_doc):
        raw = page.get_text()
        head = raw[:200].lower()
        ls = _lines(page)
        has_header = (_pin_header_end(ls) >= 0 or _wide_header_start(ls) >= 0)
        if has_header:
            started = True
            last_pin = True
            pages.append(i)
            continue
        if started and last_pin and "(continued)" in head:
            pages.append(i)                       # 续页：表头可能只印一次
            continue
        if started:
            break
    return pages[:cap]


def _pick_no_col(rows: list[list]) -> int:
    """挑「脚号/球位号」那一列：按列统计命中率，取最高的。

    不写死第 2 列 —— ADI/Infineon 的表列序不同。命中率并列时取靠左的。
    """
    if not rows:
        return 1
    ncol = max(len(r) for r in rows)
    best, best_hit = 1, -1
    for c in range(ncol):
        hit = 0
        for r in rows:
            cell = (r[c] or "") if c < len(r) else ""
            if BALL_RE.search(cell) or NUM_RE.match(cell.strip()):
                hit += 1
        if hit > best_hit:
            best, best_hit = c, hit
    return best


def extract_pins(fitz_doc) -> list[dict]:
    """确定性抽引脚表，成组行按球位展开成一条一球。

    走**文本层**而不是 `find_tables`：后者虽然结构更规整，但会把描述列的
    空格整片吃掉（`Analog supply ground` → `Analogsupplyground`），
    页面直接不可读。文本层的行序是稳定的：

        NAME            ← 引脚名
        A1, A2, A3,     ← 球位/脚号，可跨多行、一行多个
        …
        —               ← I/O 列
        Analog supply ground. Tie AGND and DGND …   ← 描述，可跨多行
        BG              ← 下一个引脚名

    返回 `[{"pin","name","description","page"}]`；无引脚表时返回 []。
    """
    out: list[dict] = []
    seen: set[str] = set()
    for pi in _pin_pages(fitz_doc):
        before = len(out)
        ls = _lines(fitz_doc[pi])
        start = _pin_header_end(ls)
        if start < 0:
            # D4：`PIN | I/O | DESCRIPTION | NAME | <N 个封装列>` 布局
            # （LM317 这类 3 脚稳压器的表头顺序是 NAME 在最右，而非 NAME/NO.）。
            wide = _wide_header_start(ls)
            if wide < 0:
                _table_augment(out, before, fitz_doc[pi], pi + 1, seen)
                continue
            for p in _extract_pins_wide(ls, wide, pi):
                pin = p.get("pin") or ""
                if not pin or pin in seen:
                    continue
                seen.add(pin)
                out.append(p)
            _table_augment(out, before, fitz_doc[pi], pi + 1, seen)
            continue
        i = start
        while i < len(ls):
            name = ls[i]
            if _ballish(name) or name in IO_MARKS or name in HEADER_WORDS:
                i += 1
                continue
            j = i + 1
            balls: list[str] = []
            while j < len(ls) and _ballish(ls[j]):
                balls += BALL_RE.findall(ls[j])
                j += 1
            if not balls:
                i += 1
                continue
            if j < len(ls) and ls[j].strip() in IO_MARKS:
                j += 1
            desc: list[str] = []
            while j < len(ls):
                if _is_row_start(ls, j):
                    break
                if re.match(r"^\(\d+\)", ls[j]):      # 表脚注，不属本行
                    break
                if FOOTER_RE.search(ls[j]):           # 页脚（料号 + 文档号 + 日期）
                    break
                desc.append(ls[j])
                j += 1
            d = re.sub(r"\s+", " ", " ".join(desc)).strip()
            # 页脚第一段是裸料号（`ADC12DJ5200SE`），单独一行、不带空格，
            # 会被当成描述的最后一句。只在句末已完整时剥掉。
            d = re.sub(r"(?<=\.)\s+[A-Z]{2,}\d[A-Z0-9\-]{2,}$", "", d).strip()
            for b in balls:
                if b in seen:
                    continue
                seen.add(b)
                out.append({"pin": b, "name": name, "description": d, "page": pi + 1})
            i = j
        _table_augment(out, before, fitz_doc[pi], pi + 1, seen)
    return out


IO_MARKS = {"I", "O", "I/O", "—", "-", "P", "PWR", "G", "AI", "AO", "DIO"}
HEADER_WORDS = {"PIN", "NAME", "NO.", "NO", "I/O", "DESCRIPTION", "SYMBOL", "TYPE"}
# 页脚：料号 + 文档号（SLVS/SBAS/SLAU…）+ 日期，或 TI 固定尾巴。
# 不加这道，最后一行引脚的描述会把页脚整段吃进去。
FOOTER_RE = re.compile(
    r"^(?:www\.ti\.com|Submit Document Feedback|Copyright ©|Product Folder Links)"
    r"|\b(?:SLVS|SBAS|SLAU|SLAA|SLVA|SLVU)[A-Z]?\d{3,4}[A-Z]?\b"
    r"|\b(?:JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|"
    r"OCTOBER|NOVEMBER|DECEMBER)\s+\d{4}\b", re.I)


def _ballish(s: str) -> bool:
    """整行是否只由球位号/脚号组成（`A1, A2, A3,` / `C3` / `12`）。"""
    s = (s or "").strip().rstrip(",")
    if not s:
        return False
    parts = [p.strip() for p in s.split(",") if p.strip()]
    return bool(parts) and all(BALL_RE.fullmatch(p) or NUM_RE.match(p) for p in parts)


def _is_row_start(ls: list[str], j: int) -> bool:
    """`ls[j]` 是引脚名、`ls[j+1]` 是球位行 → 新的一行开始了。"""
    if j + 1 >= len(ls):
        return False
    cur, nxt = ls[j], ls[j + 1]
    return (not _ballish(cur) and cur not in IO_MARKS and cur not in HEADER_WORDS
            and _ballish(nxt))


def _pin_header_end(ls: list[str]) -> int:
    """表头结束位置：`NAME` 之后紧跟 `NO.`（TI 表头顺序就是 NAME / NO.）。"""
    for k in range(len(ls) - 1):
        if ls[k] == "NAME" and ls[k + 1].startswith("NO"):
            return k + 2
    return -1


# ---------------------------------------------------------------- D4：PIN | FUNCTION 布局
#: 引脚单元格：`1` / `3` / `2, TAB` / `A1` / `—`（封装列里没有该脚时的占位）。
#: `2, TAB` 是 SOT-223 的「2 脚 + 散热片」，取前导数字 `2` 作为 pin 值；
#: 原始单元格另存进 `pins_by_package`（仅当各封装列不同时）。
_PIN_CELL_RE = re.compile(
    r"^(?:\d+(?:\s*,\s*(?:TAB|EP|PAD|THERMAL|NC))?|[A-Z]\d{1,2})$", re.I)
#: 引脚名只允许**短大写符号**（`ADJUST` / `CS/FS` / `VOUT`）。
#: 功能描述一定含小写与句末标点 —— 这是「描述绝不能被当成引脚名」的硬闸。
#: 2026-11-03 G2：LM358 的差分输入写作 `IN1–` / `IN2+` / `V–` / `V+`，
#: 旧字符集不含 `– — − + ~ #`，导致这几行整行被跳过（8 脚只剩 OUT1/OUT2）。
_PIN_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_/\-+–—−~#± ]{0,30}$")
#: 封装列表头：`TO-220` / `TO-263` / `SOT-223` / `SOIC` / `VQFN` …
_PKG_HEAD_RE = re.compile(
    r"^(?:TO-\d+|SOT-\d+|SOIC|PDIP|TSSOP|SSOP|VQFN|QFN|LCCC|CDIP|"
    r"[A-Z]{2,5}-\d+|[A-Z]{3})$")


def _pin_cellish(s: str) -> bool:
    return bool(_PIN_CELL_RE.match((s or "").strip()))


def _pin_nameish(s: str) -> bool:
    s = (s or "").strip()
    return (bool(s) and bool(_PIN_NAME_RE.match(s))
            and s not in IO_MARKS and s not in HEADER_WORDS)


def _pin_cells(ls: list[str], i: int, cap: int = 8) -> tuple[list[str], int]:
    """从 `ls[i]` 起读连续的引脚单元格（每个封装列一格）。"""
    j, cells = i, []
    while j < len(ls) and len(cells) < cap and _pin_cellish(ls[j]):
        cells.append(ls[j].strip())
        j += 1
    return cells, j


def _pin_value(cell: str) -> str:
    """单元格 → pin 值：`2, TAB` → `2`；`A1` → `A1`；`—` → 空。"""
    m = re.match(r"^([A-Z]\d{1,2}|\d+)", (cell or "").strip())
    return m.group(1) if m else ""


def _wide_header_start(ls: list[str]) -> int:
    """`PIN … NAME … DESCRIPTION/FUNCTION` 表头之后的扫描起点。

    只认**同一段**里同时出现 `PIN` / `NAME` / `DESCRIPTION`（或 `FUNCTION`）：
    封装俯视图里也有 ADJUST/OUTPUT，但它们没有这个表头。
    """
    for k, s in enumerate(ls):
        if s.strip().upper() != "PIN":
            continue
        win = [x.strip().upper() for x in ls[k:k + 10]]
        if "NAME" in win and ("DESCRIPTION" in win or "FUNCTION" in win):
            return k + 1
    return -1


def _package_names(ls: list[str], a: int, b: int) -> list[str]:
    """表头到首行之间的封装列名（`TO-220 (Legacy Chip)` 合并成一项）。"""
    out: list[str] = []
    for s in ls[a:b]:
        s = s.strip()
        if not s:
            continue
        if s.startswith("(") and out:
            out[-1] = f"{out[-1]} {s}"
            continue
        if "(" in s or _PKG_HEAD_RE.match(s):
            if s.upper() not in ("PIN", "NAME", "DESCRIPTION", "FUNCTION", "I/O"):
                out.append(s)
    return out


def _wide_row_start(ls: list[str], i: int, n: int) -> bool:
    """`ls[i]` 是「名字 + n 个封装脚号」的一行起点。

    描述行一定不满足：名字闸（短大写）先挡掉，其次要求紧跟 n 个单元格，
    且第 n+1 行是 I/O 标记或描述（不是又一个脚号）。
    """
    if not _pin_nameish(ls[i]):
        return False
    cells, j = _pin_cells(ls, i + 1, n)
    if len(cells) != n:
        return False
    nxt = ls[j].strip() if j < len(ls) else ""
    if nxt in IO_MARKS:
        return True
    return bool(nxt) and not _pin_cellish(nxt) and not _pin_nameish(nxt)


def _extract_pins_wide(ls: list[str], start: int, page_no: int) -> list[dict]:
    """解析 `PIN | I/O | DESCRIPTION | NAME | <N 个封装列>` 布局。

    LM317 的真实排版（p5）::

        PIN  I/O  DESCRIPTION  NAME  TO-220  TO-263  SOT-223
        ADJUST                  1       1       1       —   Output voltage adjustment pin…
        INPUT                   3       3       3       I   Input voltage pin…
        OUTPUT                  2, TAB  2, TAB  2, TAB  O   Output voltage pin…

    多封装列的脚号可能不同：pin 取第一列的号，其余写进 `pins_by_package`，
    **不猜、不丢**。
    """
    out: list[dict] = []
    n, first = 0, -1
    for i in range(start, len(ls) - 1):
        if not _pin_nameish(ls[i]):
            continue
        cells, j = _pin_cells(ls, i + 1, 8)
        if not cells:
            continue
        nxt = ls[j].strip() if j < len(ls) else ""
        if nxt in IO_MARKS or (nxt and not _pin_cellish(nxt) and not _pin_nameish(nxt)):
            n, first = len(cells), i
            break
    if n == 0 or first < 0:
        return out
    pkgs = _package_names(ls, start, first)

    i = first
    raw: list[tuple[str, list[str], str]] = []
    while i < len(ls):
        if not _wide_row_start(ls, i, n):
            i += 1
            continue
        name = ls[i].strip()
        cells, j = _pin_cells(ls, i + 1, n)
        if j < len(ls) and ls[j].strip() in IO_MARKS:
            j += 1
        desc: list[str] = []
        while j < len(ls):
            if _wide_row_start(ls, j, n):
                break
            # 某些行（如 NC 的多脚号合并单元格 "1, 3, 4, 6, …"）不算可解析行，
            # 但它们确实是**下一行引脚名**：不在这里断开，上一行的描述会把
            # NC 整段吞进来（LM358 实测 V– 描述尾部混入 "NC 1, 3, 4, …"）。
            if (_pin_nameish(ls[j]) and j + 1 < len(ls)
                    and re.fullmatch(r"[\d, ]+|—|–|-", ls[j + 1].strip() or "")):
                break
            if re.match(r"^\(\d+\)", ls[j]):          # 表脚注
                break
            if FOOTER_RE.search(ls[j]):               # 页脚
                break
            d = ls[j].strip()
            if d and d.upper() not in HEADER_WORDS:
                desc.append(d)
            j += 1
        text = re.sub(r"\s+", " ", " ".join(desc)).strip()
        raw.append((name, [_pin_value(c) for c in cells], text))
        i = j

    # 多封装列时按**封装脚数**选集：取「该列最大脚号最小」的那一列
    # （LM358 的第 1 列是 20 脚 LCCC、第 2 列才是 8 脚 SOIC）。
    # 并列时取靠左，保持 LM317（三列都是 3 脚）原行为。
    def _col_max(c: int) -> int:
        nums = [int(v[c]) for _, v, _ in raw if c < len(v) and v[c].isdigit()]
        return max(nums) if nums else 9999
    pc = min(range(n), key=lambda c: (_col_max(c), c)) if n else 0

    for name, vals, text in raw:
        pin = (vals[pc] if pc < len(vals) else "") or next((v for v in vals if v), "")
        rec = {"pin": pin, "name": name, "description": text, "page": page_no + 1}
        if len({v for v in vals if v}) > 1 and len(pkgs) == n:
            rec["pins_by_package"] = {p: v for p, v in zip(pkgs, vals) if v}
        out.append(rec)
    return out


# ---------------------------------------------------------------- G2：结构化表格兜底
#: 文本层顺序把多列合并成一条时（ADS42 的 `NO. | NAME | I/O | FUNCTION`、
#: LM358 的 `NAME | LCCC | SOIC | I/O | DESCRIPTION`），D4 的行序假设不成立。
#: `find_tables()` 能拿到行列关系；本兜底只在**它比文本层抽到的引脚更多**时启用，
#: 避免改坏已经抽对的常见布局。
_TABLE_HEADER_SKIP = {
    "PIN", "PI N", "NAME", "NO.", "NO", "I/O", "DESCRIPTION", "SYMBOL",
    "TYPE", "FUNCTION", "PI", "N", "",
}
_TABLE_NONPIN_NAMES = {"NC", "THERMAL PAD", "THERMALPAD", "GND"}
_TABLE_PIN_TOKEN = re.compile(r"[A-Z]\d{1,2}|\d+")


def _table_clean(v) -> str:
    return re.sub(r"\s+", " ", str(v or "").replace("\n", " ")).strip()


def _table_pin_name(v) -> str:
    """`IN1 –` → `IN1–`；`PDN GBL _` → `PDN_GBL`。"""
    s = _table_clean(v)
    s = re.sub(r"\s*_\s*", "_", s)
    s = re.sub(r"\s*([–—−+~±])\s*", r"\1", s)
    return s


def _table_desc(v) -> str:
    """表格抽出的描述会丢空格：`Analogground` → `Analog ground`。"""
    s = _table_clean(v)
    s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s)
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _table_pin_tokens(cell) -> list[str]:
    """单元格 → 引脚号列表；修复逗号丢失的 `5251` / `5657` / `5859`。

    `find_tables()` 对 `52,51` 有时会把逗号吃掉成一串 4 位数字。
    只有「整串是 4 位数字且切两半都在 1..99」才拆；BGA 的 `A1234` 不受影响。
    """
    out: list[str] = []
    for t in _TABLE_PIN_TOKEN.findall(_table_clean(cell)):
        if t.isdigit() and len(t) == 4 and int(t) > 99:
            a, b = int(t[:2]), int(t[2:])
            if 1 <= a <= 99 and 1 <= b <= 99:
                out += [str(a), str(b)]
                continue
        out.append(t)
    return out


def _extract_pins_from_table(page, page_no: int) -> list[dict]:
    """从 `find_tables()` 的行列结构抽引脚（仅在文本层不足时兜底）。

    支持两种 TI 常见布局：
      * `PIN | DESCRIPTION | NAME | NO. | I/O | FUNCTION`（ADS42）
      * `NAME | <封装列…> | I/O | DESCRIPTION`（LM358）
    """
    try:
        tabs = page.find_tables()
    except Exception:                                          # noqa: BLE001
        return []
    out: list[dict] = []
    for t in (getattr(tabs, "tables", []) or []):
        try:
            data = t.extract()
        except Exception:                                      # noqa: BLE001
            continue
        if not data or len(data) < 3 or not data[0]:
            continue
        cols = len(data[0])
        io_col, io_hits = -1, 0
        for c in range(1, cols):
            n = sum(1 for r in data if c < len(r) and _table_clean(r[c]) in IO_MARKS)
            if n > io_hits:
                io_col, io_hits = c, n
        if io_col < 0 or io_hits < 3:
            continue
        pin_cols = list(range(1, io_col))
        if not pin_cols:
            continue
        pkg_names: dict[int, str] = {}
        for r in data[:3]:
            for c in pin_cols:
                if c < len(r):
                    v = _table_clean(r[c])
                    if v.upper() not in _TABLE_HEADER_SKIP:
                        pkg_names.setdefault(c, v)

        def _max_pin(c: int) -> int:
            nums = []
            for r in data:
                if c < len(r):
                    nums += [int(x) for x in _table_pin_tokens(r[c]) if x.isdigit()]
            return max(nums) if nums else 0

        primary = min(pin_cols, key=lambda c: (_max_pin(c) or 9999))
        for r in data:
            if len(r) <= io_col:
                continue
            name = _table_pin_name(r[0])
            io = _table_clean(r[io_col])
            if not name or name.upper() in _TABLE_HEADER_SKIP:
                continue
            if name.upper() in _TABLE_NONPIN_NAMES:
                continue
            if io not in IO_MARKS:
                continue
            cells = {c: _table_pin_tokens(r[c]) for c in pin_cols if c < len(r)}
            vals = cells.get(primary) or []
            if not vals:
                continue
            base = {"name": name, "description": _table_desc(r[-1]), "page": page_no}
            if len(pin_cols) > 1 and len(pkg_names) >= len(pin_cols):
                base["pins_by_package"] = {
                    pkg_names.get(c, str(c)): v[0] for c, v in cells.items() if v}
            for p in vals:
                out.append({**base, "pin": p})
    return out


def _table_augment(out: list[dict], before: int, page, page_no: int,
                   seen: set[str]) -> None:
    """表格抽到的引脚数**多于**文本层时，用表格结果替换这一页的文本结果。"""
    try:
        tab = _extract_pins_from_table(page, page_no)
    except Exception:                                          # noqa: BLE001
        return
    if len(tab) <= len(out) - before:
        return
    for r in out[before:]:
        seen.discard(r.get("pin"))
    del out[before:]
    for r in tab:
        pin = r.get("pin") or ""
        if not pin or pin in seen:
            continue
        seen.add(pin)
        out.append(r)


def _cell(row: list, i: int) -> str:
    if i < 0 or i >= len(row):
        return ""
    # 单元格内的换行是排版换行，拼回一行再压空白
    return re.sub(r"\s+", " ", (row[i] or "").replace("\n", " ")).strip()


#: 各容器的「源文档存在证据」关键词（文本层）。与 `extract_thermal` / `extract_esd`
#: 的触发词保持一致 —— 「抽不到」必须能区分「源文档没有」与「抽到了却丢了」。
_CONTAINER_HEADERS = {
    "thermal": ("thermal information", "rθja", "rθjc", "°c/w", "thermal resistance"),
    "esd": ("esd ratings", "electrostatic discharge", "hbm", "cdm", "v(esd)"),
}


def source_has_container(fitz_doc, key: str) -> bool:
    """源 PDF 文本层里有没有该容器的表（`thermal` / `esd`）。

    为什么需要它：batch20 实测 `ADS1286U`（13 页 23k 字符）与 `BQ48SH-28X6NSH`
    **通篇没有任何 thermal/ESD 表**。这类件 `specs.thermal=[]` 是**正确结果**，
    把它判成 `UNRESOLVED`（或要求「必须长出 1 行」）等于逼系统编造数据。
    判据只认文本层原词，不认模型自述、不认 JSON。
    """
    kws = _CONTAINER_HEADERS.get(key, ())
    if not kws:
        return False
    for page in fitz_doc:
        t = page.get_text().lower()
        if any(k in t for k in kws):
            return True
    return False


# ---------------------------------------------------------------- 热阻
def thermal_package_columns(ls: list[str], start: int) -> tuple[list[dict], int]:
    """从 `THERMAL METRIC` 表头行之后读出**封装列定义**。

    返回 ``(columns, 数据起始下标)``，``columns`` 形如
    ``[{"code":"DCY","package":"SOT-223","pins":4,"col":0}, …]``。

    为什么单独立一个函数：`table_audit` 的列塌缩红线要复用它 —— 判据必须是
    **同一份实现**，否则审计说「有 4 列」而抽取器只认 1 列，两边永远对不上。

    LM317 的真实排版（p7，文本层）::

        THERMAL METRIC(1)
        LM317
        UNIT
        DCY (SOT-223)  KCS (TO-220)  KCT (TO-220)  KTT (TO-263)
        4 PINS         3 PINS       3 PINS       3 PINS

    封装码与括号名可能分两行（`DCY` / `(SOT-223)`），也可能同一行
    （`DCY (SOT-223)`）；引脚数总在封装码之后的单独一行里。
    """
    cols: list[dict] = []
    pins: list[int] = []
    #: 「只有封装码、没有括号封装名」的列（CDC6C 系列）。先收集，最后才决定用不用。
    bare: list[str] = []
    bare_pins: list[int] = []
    i = start + 1
    # 只看表头之后的一段：封装定义不会隔很远。
    # 2026-11-03（A22 复核）：原来限死 `start + 16` 行 —— NE555 的封装定义是
    # `D` / `(SOIC)` / `FK` / `(LCCC)` … 一码一行共 12 行，加上前面的
    # `THERMAL METRIC` 与 `NA556, NE556, …` 器件名，FK/JG 之后就被窗口切掉，
    # 于是六列只剩两列。窗口放宽到 40 行，仍以「第一条参数行」为硬停点。
    while i < len(ls) and i < start + 40:
        s = ls[i]
        if _thermal_canon(s):                       # 已经到第一条参数了
            break
        found = _PKG_CELL_RE.findall(s)
        if found:
            # 一行多个封装（A22 核心修复）：逐个入列，保持文本出现的先后顺序。
            for code, pkg in found:
                cols.append({"code": code.strip(),
                             "package": re.sub(r"\s+", " ", pkg).strip(),
                             "pins": 0, "col": len(cols)})
        elif re.fullmatch(r"[A-Z]{1,4}", s) and s not in ("UNIT", "PINS"):
            # 裸封装码：名字可能在下一行的括号里（NE555 有单字母码 `D` / `P`），
            # 也可能**根本没有名字**（CDC6C 只印 `DLE` / `DLF` / `DLX` / `DLY`）。
            nxt = ls[i + 1] if i + 1 < len(ls) else ""
            m2 = re.match(r"^\(\s*([A-Za-z0-9][A-Za-z0-9\-\s]*?)\s*\)$", nxt)
            if m2:
                cols.append({"code": s,
                             "package": re.sub(r"\s+", " ", m2.group(1)).strip(),
                             "pins": 0, "col": len(cols)})
                i += 1
            else:
                bare.append(s)
        elif re.fullmatch(r"\d{1,3}", s):
            # 裸引脚数（CDC6C 印 `4` / `4` / `4` / `4`，不带 `PINS`）。
            bare_pins.append(int(s))
        else:
            pins.extend(int(n) for n in _PINS_CELL_RE.findall(s))
        i += 1
    # CDC6C（`SNAS843D` p6）：四列全是「裸码 + 裸引脚数」，没有任何括号封装名，
    # 旧实现逐行 match 括号，四列全被跳过 → 塌缩成 1 列且 condition 为空。
    #
    # 启用条件刻意收紧（三个都满足）：
    #   1. 一列都还没认出来；
    #   2. 至少 2 个裸码，且码长 ≥2、不是 `NA` 这类占位词；
    #   3. **引脚数存在且数量与码数相等**。
    # 第 3 条是防线：单列表头里常混着 `TI` / `NA` / 脚注标记这类零散大写词，
    # 只按「≥2 个裸码」判会把它们编成封装列 —— 值被按列切分，每一行都变成错的，
    # 而且看着「有封装条件」，复核方反而不容易发现。造出假列比塌缩更糟。
    codes_bare = [c for c in bare
                  if len(c) >= 2 and c.upper() not in _PLACEHOLDERS
                  and c not in ("TI", "NO", "MAX", "MIN", "TYP")]
    if (not cols and len(codes_bare) >= 2 and bare_pins
            and len(bare_pins) == len(codes_bare)):
        for c in codes_bare:
            cols.append({"code": c, "package": "", "pins": 0, "col": len(cols)})
        for k, n in enumerate(bare_pins):
            if k < len(cols):
                cols[k]["pins"] = n
    for k, n in enumerate(pins):
        if k < len(cols):
            cols[k]["pins"] = n
    return cols, i


def expected_pin_counts(fitz_doc) -> dict[str, int]:
    """热阻信息表的封装列 → ``{封装码: 引脚数}``（可信的 datasheet 证据）。

    D4 硬闸（Reviewer 2026-11-04 契约）的 `expected_count` **只认原厂 PDF 证据**：
    不拿模型自抽数量、不拿历史冻结 JSON 当真值。`thermal_package_columns`
    就是这份证据的解析器（表审计与抽取共用同一实现），这里只负责把
    「哪一封装几脚」汇成一张表。

    同码跨表冲突（同一封装码两次读出不同脚数）直接**丢弃该码**：
    冲突说明解析不可信，宁缺勿错。LM317 p7 两张表都读到 `DCY:4` 不冲突；
    真冲突时少一个可信键只会导致 `count_unverified`，不会造错账。
    """
    out: dict[str, int] = {}
    dropped: set[str] = set()
    for page in fitz_doc:
        ls = _lines(page)
        if not any("thermal information" in x.lower() for x in ls):
            continue
        for h in (i for i, x in enumerate(ls) if _THERMAL_HEAD_RE.match(x)):
            cols, _ = thermal_package_columns(ls, h)
            for c in cols:
                n = int(c.get("pins") or 0)
                key = str(c.get("code") or c.get("package") or "").strip()
                if n <= 0 or not key or key in dropped:
                    continue
                if key in out and out[key] != n:
                    del out[key]
                    dropped.add(key)
                    continue
                out[key] = n
    return out


def _thermal_variant(ls: list[str], header_at: int) -> str:
    """表头所在块的表名（`Legacy Chip` / `New Chip`）。

    LM317 有**两张**热阻表：6.4 Legacy Chip（4 封装）与 6.5 New Chip（2 封装），
    同一个 DCY 封装在两张表里 RθJA 分别是 66.8 与 59.6。不记表名，两行会变成
    「同名同封装却两个值」，复核方只能判我们数据错。
    """
    for j in range(header_at, max(header_at - 4, -1), -1):
        s = ls[j]
        if "thermal information" in s.lower():
            m = re.search(r"\(([^)]+)\)", s)
            return m.group(1).strip() if m else ""
    return ""


def _thermal_condition(variant: str, col: dict) -> str:
    """一行热阻的 `condition`：`表名; 封装码 (封装名) 引脚数`。

    `variant` 与封装段任一为空就省略，不留尾随的 `; `。表名必须写在最前面：
    LM317 的 Legacy / New 两张表里同一个 DCY 的 RθJA 是 66.8 与 59.6，
    只写封装码会让两行变成「同名同封装却两个值」。
    """
    code, pkg = (col.get("code") or "").strip(), (col.get("package") or "").strip()
    # 只有封装码、没有封装名时（CDC6C 系列原表就只印 `DLE`），
    # 不要写出 `DLE ()` 这种空括号 —— 复核方会以为我们漏读了封装名。
    if code and pkg:
        seg = f"{code} ({pkg})"
    else:
        seg = code or pkg
    if seg and col.get("pins"):
        seg += f" {col['pins']} PINS"
    return "; ".join(x for x in (variant.strip(), seg) if x)


#: 上一次 `extract_thermal` 被拒绝落行的条目（数量对不上，可能错列）。
#: 用模块级而不是返回值：`extract_thermal` 的返回类型被两个调用方（装配 /
#: 事实表重做）当成 `list[dict]` 用，改成元组会波及渲染链路；而这里要的只是
#: 「复核方能看到扣了什么」。调用方想拿就在之后调 `unresolved_rows()`。
_LAST_UNRESOLVED: list[dict] = []


def unresolved_rows() -> list[dict]:
    """上一次热阻抽取里因**数量对不上**被拒的行（空列表 = 全部对齐）。"""
    return list(_LAST_UNRESOLVED)


def extract_thermal(fitz_doc) -> list[dict]:
    """从文本层抽 Thermal Information 表，**按封装列逐列展开**。

    2026-11-03 V1 列塌缩修复。旧实现是「遇到 metric 名后向下找第一个纯数值行」，
    等于**只取第一列**：LM317 的 4 个封装列只留 DCY、New Chip 整张表被
    `if out: return` 截断、`Rθ(JA)` 因键写死为 `RθJA` 而全丢、`RθJC(bot)` 的
    `NA` 被跳过导致 KCS 的 0.1 冒充 DCY。页面上只剩 5 行无条件的热阻，
    复核方判「客户不可用」是对的。

    现在的口径：
      * 每张热阻表按封装列展开，一条参数出 N 行（N = 该表封装列数）；
      * `condition` 写清 `表名; 封装码 (封装名) 引脚数` —— 同封装不同表不再混淆；
      * 占位符（`NA` / `—`）**占列但不落行**：宁可缺，不许错列。
    """
    _LAST_UNRESOLVED.clear()
    out: list[dict] = []
    for page in fitz_doc:
        ls = _lines(page)
        if not any("thermal information" in x.lower() for x in ls):
            continue
        # 一页可能有多张热阻表（LM317 p7 就是两张），逐张处理。
        heads = [i for i, x in enumerate(ls) if _THERMAL_HEAD_RE.match(x)]
        for h in heads:
            cols, data_at = thermal_package_columns(ls, h)
            if not cols:
                # 单封装表没有封装列定义（`RθJA` 直接对着一个数值）。
                # **不能 continue**：那会把整张热阻表丢成 0 行。退化成单列，
                # `condition` 只写表名；若原表其实有多个封装列而被漏认，
                # `table_audit.audit_column_collapse` 会按 find_tables 结构判出来。
                cols = [{"code": "", "package": "", "pins": 0, "col": 0}]
            variant = _thermal_variant(ls, h)
            j = data_at
            while j < len(ls):
                s = ls[j]
                if _THERMAL_HEAD_RE.match(s):
                    break                      # 下一张表开始
                if "thermal information" in s.lower():
                    break                      # 下一张表的标题
                canon = _thermal_canon(s)
                if not canon:
                    j += 1
                    continue
                # 参数名之后是描述行（纯文字），跳过它再取 N 个值。
                k = j + 1
                while k < len(ls) and not (
                        _is_num(ls[k]) or ls[k].strip().upper() in _PLACEHOLDERS):
                    if _thermal_canon(ls[k]) or \
                            _THERMAL_HEAD_RE.match(ls[k]):
                        break
                    k += 1
                vals: list[str] = []
                while k < len(ls) and len(vals) < len(cols):
                    tok = ls[k].strip()
                    if _is_num(tok) or tok.upper() in _PLACEHOLDERS:
                        vals.append(tok)
                        k += 1
                    else:
                        break
                unit = "°C/W"
                if k < len(ls) and _is_unit(ls[k]):
                    unit = ls[k].strip()
                # ---- 数量对齐校验（2026-11-03，静默错列）----
                # 文本层是「一个单元格一行」，某个格子完全空白时那一行**根本不存在**，
                # 于是 `zip(cols, vals)` 会把后面的值整体左移一格：KCS 的 0.1 被贴到
                # DCY 名下，页面上看不出任何异常，客户拿它算结温就是错的。
                # 位置式配对**没有任何办法**证明对齐（空格子已经消失），所以这里只做
                # 数量校验：数不出来就整行不落，记进 `unresolved`，绝不静默错位。
                # 宁可缺一条，也不许把数值安到错误的封装上。
                if len(vals) != len(cols):
                    _LAST_UNRESOLVED.append({
                        "container": "thermal",
                        "name": canon,
                        "table_variant": variant,
                        "page": getattr(page, "number", None),
                        "expected": len(cols),
                        "got": len(vals),
                        "values": list(vals),
                        "reason": ("抽到的数值个数与封装列数不一致 —— 中间有空单元格时"
                                   "位置式配对会整体左移，拒绝落行以免把数值安错封装"),
                    })
                    j = max(k, j + 1)
                    continue
                for col, val in zip(cols, vals):
                    if val.upper() in _PLACEHOLDERS:
                        continue               # 占列但不落行：宁可缺，不许错列
                    cond = _thermal_condition(variant, col)
                    out.append({"name": canon, "value": val, "unit": unit,
                                "condition": cond})
                j = max(k, j + 1)
        if out:
            return out
    return out


# ---------------------------------------------------------------- ESD
def extract_esd(fitz_doc) -> list[dict]:
    """从文本层抽 ESD Ratings 表：`V(ESD) | Electrostatic discharge | <项> | 值 | 单位`。

    值保留原文 `±` 号 —— LLM 曾把 `±2000` 写成 `+2000`，把双向耐压读成单向上限。
    """
    out: list[dict] = []
    for page in fitz_doc:
        ls = _lines(page)
        start = next((i for i, x in enumerate(ls) if "esd ratings" in x.lower()), -1)
        if start < 0:
            continue
        for k in range(start, min(start + 16, len(ls))):
            m = re.search(r"human-?body|\bhbm\b|charged device|\bcdm\b", ls[k], re.I)
            if not m:
                continue
            name = "HBM" if re.search(r"human|hbm", m.group(0), re.I) else "CDM"
            val = ""
            for j in range(k + 1, min(k + 4, len(ls))):
                if re.match(r"^[±+-]?\d", ls[j]):
                    val = ls[j]
                    break
            if not val:
                continue
            if not any(x["name"] == name for x in out):
                out.append({"name": name, "value": val, "unit": "V"})
        if out:
            return out
    return out


# ---------------------------------------------------------------- 工作温度
#: TI 手册里数字前的破折号是 **en-dash**（`–40`，U+2013），不是 ASCII 连字符。
#: `NUM_RE` 只认 `+` / `-`，不归一化就永远匹配不上 —— 这一层没做，
#: 温度行就抽不到，字段只能留给模型，模型又时写时不写 `°C`（V4 实测丢单位）。
_DASHES = str.maketrans({"\u2013": "-", "\u2014": "-", "\u2212": "-",
                          "\u2012": "-", "\ufe63": "-"})


def _num_norm(s: str) -> str:
    return (s or "").strip().translate(_DASHES)


#: 工作温度行/表头的两种形态（锚定行首，`search` 会先撞上表标题）。
_TEMP_ROW_RE = re.compile(r"operating\s+free[- ]air\s+temperature\b", re.I)
_TEMP_RANGE_RE = re.compile(r"temperature\s+range\b", re.I)


def extract_temperature(fitz_doc) -> dict:
    """抽工作温度：`TA | Operating free-air temperature | –40 | 85 | °C`。

    为什么必须走代码：这个字段在 V4 掉了单位（`-40 to 85`），页面就写成
    "an operating range of -40 to 85" —— **没有量纲的温度是错的数据**，
    而模型三次解析里两次带 `°C`、一次不带，靠它不如靠表。

    两种表头形态，按可信度排序，命中即返回：

    1. `Operating free-air temperature` —— TI 新手册的 ROC 行（ADC12DJ5200SE）。
    2. `TEMPERATURE RANGE` —— 老手册的表头行，下一行是 `Specified Performance`
       之类的子标签，再往下才是 MIN/MAX（ADS1201 实测）。这条要求**必须读到
       `°C`** 才认，否则表头下挂的可能是别的数值列。

    返回 `{"operating": "-40°C to 85°C", "page": 10}`；抽不到返回 `{}`。
    """
    for pi, page in enumerate(fitz_doc):
        ls = _lines(page)
        for label, need_unit in ((_TEMP_ROW_RE, False), (_TEMP_RANGE_RE, True)):
            # **必须锚在行首**：每张规格表的标题也含这几个词
            # （"over operating free-air temperature range (unless otherwise noted)"），
            # 用 `search` 会先撞上标题，再从标题往下读 MIN/MAX/UNIT 这几个表头词，
            # 一个数字都读不到（实测就是这样返回空的）。
            k = next((i for i, x in enumerate(ls)
                      if label.match(x.strip())), -1)
            if k < 0:
                continue
            lo = hi = ""
            for j in range(k + 1, min(k + 5, len(ls))):
                v = _num_norm(ls[j])
                if not NUM_RE.match(v):
                    continue
                if not lo:
                    lo = v
                elif not hi:
                    hi = v
                else:
                    break
            unit = ""
            for j in range(k + 1, min(k + 7, len(ls))):
                if re.fullmatch(r"°?\s*C", ls[j].strip()):
                    unit = "°C"
                    break
            if need_unit and not unit:
                continue
            if lo and hi:
                return {"operating": f"{lo}{unit} to {hi}{unit}", "page": pi + 1}
    return {}


def fill_temperature(doc: dict, fitz_doc) -> dict:
    """只补 `specs.temperature`，不碰其它容器。

    单独成一个函数，是因为它有「不重解析也要能用」的场景：V4 的 JSON 已经落盘，
    温度单位是那次模型输出的锅，重跑一次确定性抽取就能补齐，不必重跑模型。
    """
    got = extract_temperature(fitz_doc)
    if not got:
        return {}
    temp = (doc.setdefault("specs", {}) or {}).setdefault("temperature", {})
    old = temp.get("operating")
    if old == got["operating"]:
        return {"changed": False, "operating": old}
    temp["operating"] = got["operating"]
    return {"changed": True, "from": old, "to": got["operating"],
            "page": got["page"], "method": "deterministic"}


# ---------------------------------------------------- 文档号 / 修订号（页脚）
#: TI 文档号：`S` + 2~5 个字母 + 2~4 位数字 + 可选修订字母。
#: 实例：`SBAS543`（3 字母）/ `SLVSGH5C`（5 字母 + 修订 C）/ `SLVU967A` / `SPRUHH9`。
#: 早先写成 `S[A-Z]{2,4}\d{3,4}`，`SLVSGH5C` 因为字母 5 位、数字 1 位**匹配不上**，
#: 修订号整条抽空（实测 doc_revision 返回 None）。
_DOCNUM_RE = re.compile(r"\b(S[A-Z]{2,5}\d{1,4}[A-Z]?)\b\s*[–\-—]\s*"
                        r"([A-Z][A-Za-z]+\s+\d{4})"
                        r"(?:\s*[–\-—]\s*REVISED\s+([A-Z][A-Za-z]+\s+\d{4}))?")
_DOCNUM_SPLIT_RE = re.compile(r"^(S[A-Z]{2,5}\d{1,4})([A-Z])?$")


def extract_doc_revision(fitz_doc) -> dict:
    """从页脚抽文档号与修订字母：`{"doc_number": "SLVSGH5", "revision": "C", ...}`。

    Reviewer P1 指出页面没显示 `Rev. C / SLVSGH5C`。这个信息**确定性地**印在每页页脚，
    不必猜：`SLVSGH5C` 拆成文档号 `SLVSGH5` + 修订字母 `C`。

    只读前 6 页页脚：修订信息每页重复，扫全本没有收益（180 页）。
    """
    pat = re.compile(r"^(S[A-Z]{2,5}\d{1,4})([A-Z])?$")
    for pi in range(min(6, fitz_doc.page_count)):
        txt = fitz_doc[pi].get_text() or ""
        m = _DOCNUM_RE.search(txt)
        if not m:
            continue
        full, issued, revised = m.group(1), m.group(2), m.group(3)
        # `SLVSGH5C` → 文档号 `SLVSGH5` + 修订 `C`；无尾字母则视为初版 A。
        parts = pat.match(full)
        doc_no, rev = (parts.group(1), parts.group(2) or "") if parts else (full, "")
        # **没有尾字母就留空，不要默认成 A**：`SPRUHH9` 的原文就是 `SPRUHH9`，
        # 页面写成 "Rev. A" 等于替原厂编了个修订级。空值由渲染层省略该括号。
        return {"doc_number": doc_no, "revision": rev,
                "doc_id": full, "issued": issued.strip(),
                "revised": (revised or "").strip(), "page": pi + 1}
    return {}


def fill_doc_revision(doc: dict, fitz_doc) -> dict:
    """把文档号/修订号写进 `basic_info`，供页面显示来源版本。"""
    got = extract_doc_revision(fitz_doc)
    if not got:
        return {}
    bi = doc.setdefault("basic_info", {})
    old = bi.get("doc_revision")
    if old == got:
        return {"changed": False, "doc_revision": old}
    bi["doc_revision"] = got
    return {"changed": True, "from": old, "to": got}


# ---------------------------------------------------------------- AC 指标
#: 只抽这四个。Reviewer 明确点名 SNR / SFDR / NSD / IMD3；把整张 AC 表都搬过来
#: 会引入 SINAD/ENOB/NF 等未经验收的行，反而扩大未核验面积。
_AC_SYMBOLS = frozenset({"SNR", "SFDR", "NSD", "IMD3"})
_AC_TITLE_RE = re.compile(r"Electrical Characteristics:\s*AC Specifications"
                          r"(?:\s*\(([A-Za-z\- ]+?)\s*Mode\))?", re.I)
#: 视觉行聚类容差（pt）。斜体下标（fIN 的 IN）中心 y 与正文差 ~2pt，
#: 3.0 能把它们并到同一行；再大就会把相邻两行值并起来。
_AC_LINE_TOL = 3.0


def _ac_join(words: list[tuple]) -> str:
    """把 (x, y, 词) 还原成文本：先按 y 聚成行，行内按 x 排。

    不能直接按 (y, x) 排：`fIN` 是斜体，词框比正文高，中心 y 差 2pt 就会
    被排到行首，读出 `= 2397 MHz fIN` 这种倒序（实测）。
    """
    if not words:
        return ""
    ws = sorted(words, key=lambda t: (t[1], t[0]))
    lines, cur = [], [ws[0]]
    for it in ws[1:]:
        if abs(it[1] - cur[-1][1]) <= _AC_LINE_TOL:
            cur.append(it)
        else:
            lines.append(cur)
            cur = [it]
    lines.append(cur)
    out = []
    for ln in lines:
        ln.sort(key=lambda t: t[0])
        out.append(" ".join(w for _, _, w in ln))
    return re.sub(r"\s+", " ", " ".join(out)).strip()


def _ac_bands(table) -> list[tuple[float, float]]:
    """列带 = 所有单元格 x 边界的排序并集。

    不能用「单元格 (x0,x1) 对」当列：合并单元格的 x 范围各不相同，
    会裂出 11 个假列，值被塞进同一格（实测 `50 53.5 53.9 …` 串成一条）。
    并集恰好给出真实网格线（本表 9 条边界 = 8 列）。
    """
    xs: set[float] = set()
    for r in table.rows:
        for c in r.cells:
            if c:
                xs.add(round(c[0], 1))
                xs.add(round(c[2], 1))
    b = sorted(xs)
    return [(b[i], b[i + 1]) for i in range(len(b) - 1)]


def _ac_cell_text(words, rect) -> str:
    if not rect:
        return ""
    x0, y0, x1, y1 = rect
    return _ac_join([(x, y, w) for x, y, w in words
                     if x0 - 0.6 <= x <= x1 + 0.6 and y0 - 0.6 <= y <= y1 + 0.6])


def _ac_single_value(text: str) -> bool:
    """单元格文本是不是**单个数值**。

    只有单值才代表「纵向合并 = 该值适用于整个跨度」（如 SNR 的 MIN=50）。
    TYP 列被 find_tables 判成一整格却堆了 12 个值 —— 那不是语义合并，
    按单值传播会把 12 行全写成同一个数。
    """
    toks = _num_norm(text).split()
    return len(toks) == 1 and bool(NUM_RE.match(toks[0]))


def _ac_smallest_cell(table, lo: float, hi: float, y: float):
    """覆盖该列带、纵向包含 y 的**最小**单元格。

    必须取最小的那个：合并父行（如 SFDR 整块 y295-431）与子行
    （y295-308）都"包含 y"，取第一个会拿到父格，读出一整段串行文本
    （实测 `= 2397 MHz fIN = 4197 MHz fIN = 5997 MHz fIN`）。
    """
    best = None
    for r in table.rows:
        for c in r.cells:
            if not c:
                continue
            if c[0] - 0.6 <= lo and c[2] + 0.6 >= hi and c[1] - 0.6 <= y <= c[3] + 0.6:
                h = c[3] - c[1]
                if best is None or h < best[1]:
                    best = (tuple(c), h)
    return best[0] if best else None


#: 数据行锚点的最大高度（pt）。本表单行 ~13pt，条件折成两行时 ~22pt；
#: 纵向合并成两行以上就会超过这个值，那种格子不是"一条数据行"。
_AC_ROW_MAX_H = 24.0


def _ac_rows(table) -> list[tuple[float, float]]:
    """数据行 = **所有单元格 y 边界的排序并集**的相邻对。

    与 `_ac_bands` 同一路数（那边切列、这边切行）：网格线是单元格的边，
    并集恰好给出真实行线，相邻对就是行，且**不会重叠**。

    两个失败过的做法，别再回去：

    1. **按文本 y 聚类**：条件列是合并单元格，里面有多行文本
       （`AIN = –1 dBFS` / `AIN = –3 dBFS` / `fIN = 2397 MHz`），
       聚类会把一条逻辑行拆成 3~4 条，叠上"单值纵向传播"就变成
       4 条一模一样的记录 —— 1102 的 82 行里 18 条重复就是这么来的。
    2. **按值区单元格当锚点**：p14 下半段的网格线缺了，`find_tables`
       根本没切出值单元格，整块 SNR 行会凭空消失（实测少 30 行）。

    `table.rows` 也不能直接用：父行（整块 y295-431）与子行（y295-308）**重叠**，
    两者都会产出记录。
    """
    ys: set[float] = set()
    for r in table.rows:
        for c in r.cells:
            if c:
                ys.add(round(c[1], 1))
                ys.add(round(c[3], 1))
    b = sorted(ys)
    return [(b[i], b[i + 1]) for i in range(len(b) - 1)]


def _ac_spans(cell, row_bands) -> int:
    """单元格纵向覆盖了几条数据行。>1 就是纵向合并格。

    纵向合并的含义是「这一段内容适用于跨过的所有行」，所以整格读才对。
    按行带过滤只能取到落在这条带里的那半句 —— 实测 p16 的 IMD3 把
    `f1 = 2393 MHz, f2 = 2403 MHz` 读成 `f1 = 2393 MHz,`，f2 整段丢失。
    """
    if not cell:
        return 0
    n = 0
    for lo, hi in row_bands:
        if cell[1] - 0.6 <= hi and cell[3] + 0.6 >= lo:
            n += 1
    return n


def _ac_row_fingerprint(page: int, title: str, rect, sym: str,
                        vals: dict, unit: str) -> str:
    """一行数据的几何指纹：同页同位置同值 → 同一条原始行。"""
    raw = "|".join([
        str(page), title, "%.1f,%.1f" % (rect[0], rect[1]),
        sym, vals.get("min", ""), vals.get("typ", ""), vals.get("max", ""), unit,
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def extract_ac_performance(fitz_doc) -> list[dict]:
    """确定性抽取 AC 规格（SNR / SFDR / NSD / IMD3）含测试条件。

    Reviewer P1：ADC 页面的 SNR/SFDR/NSD/IMD3 是 0 行，而"参数事实正确性"只有 5/10。

    为什么不能用 `find_tables().extract()`：这张表的单元格文本会串行 ——
    实测 `50 535|.|539|.|548|.`（TYP 列 12 个值被并成一格）、
    条件列读成 `M 0xa Fx Fim FFum Afu INll - =s c –a 2le v d`（乱序）。
    所以**几何用表格、文本用词**：

    1. 列带取自单元格 x 边界并集（真实网格线）。
    2. 值按视觉行取（同一 y 带内的词），一个视觉行 = 一条测试条件。
    3. 符号 / 分组 / 单位这类纵向合并的标签，按单元格纵向传播。

    返回每条一行；抽不到返回 `[]`（不猜、不补）。
    """
    out: list[dict] = []
    # **先文本预筛，再对候选页做 find_tables**：`find_tables` 单页就要几百毫秒，
    # 180 页全扫会把进程拖死（实测 SIGTERM）。这是本项目的老坑，`qc/page_evidence.py`
    # 的"禁止为核对一行扫整份 PDF"说的就是这件事。
    cand: list[tuple[int, object, str, str]] = []
    mode = ""
    for pi, page in enumerate(fitz_doc):
        txt = page.get_text() or ""
        m = _AC_TITLE_RE.search(txt)
        if m:
            mode = (m.group(1) or "").strip()
        # 续页（`(continued)` 页与无标题的续页）也要收：单通道的 SFDR/IMD3
        # 就在没有标题的续页上，只认标题会整块漏掉。
        if not any(s in txt for s in ("SNR", "SFDR", "NSD", "IMD3")):
            continue
        if "MIN" not in txt or "TYP" not in txt:
            continue
        cand.append((pi, page, m.group(0).strip() if m else "AC Specifications (continued)",
                     mode))
        if len(cand) >= 16:
            break

    for pi, page, title, page_mode in cand:
        try:
            tabs = page.find_tables().tables
        except Exception:                                      # noqa: BLE001
            continue
        if not tabs:
            continue
        mode = page_mode
        for table in tabs:
            bands = _ac_bands(table)
            if len(bands) < 7:
                continue
            words = [((x0 + x1) / 2, (y0 + y1) / 2, w)
                     for x0, y0, x1, y1, w, *_ in page.get_text("words")]
            top, bot = table.rows[0].bbox[1], table.rows[-1].bbox[3]
            inside = [w for w in words if top - 2 <= w[1] <= bot + 2]
            if not inside:
                continue
            row_bands = _ac_rows(table)
            for ri, (ry0, ry1) in enumerate(row_bands):
                yc = (ry0 + ry1) / 2

                def cell_text(idx: int) -> str:
                    """该行在某一列带里的文本（只在行 y 区间内取词）。"""
                    if idx >= len(bands):
                        return ""
                    lo, hi = bands[idx]
                    return _ac_join([(x, y, w) for x, y, w in inside
                                     if lo - _COL_XPAD <= x <= hi + _COL_XPAD
                                     and ry0 - 0.6 <= y <= ry1 + 0.6])

                # 符号 / 参数 / 分组 / 单位是纵向合并的标签：取覆盖本行的
                # **最小**单元格，不能取行内词（子行里这些列本来就是空的）。
                sym = (cell_text(0) or
                       _ac_cell_text(inside, _ac_smallest_cell(table, *bands[0], yc))).strip()
                if sym not in _AC_SYMBOLS:
                    continue
                vals = {}
                for key, idx in (("min", 4), ("typ", 5), ("max", 6)):
                    vals[key] = _num_norm(cell_text(idx)) if idx < len(bands) else ""
                if not any(vals.values()):
                    continue
                grp_rect = _ac_smallest_cell(table, *bands[2], yc)
                cond_rect = _ac_smallest_cell(table, *bands[3], yc)
                # 有些页没有 fIN 子列（单通道表就是），band2/band3 落在**同一个**
                # 合并单元格里。这时拆成两段再拼会串词：
                # `Maximum full-scale voltage (…), AIN = –20 dBFS` 被读成
                # `Maximum full-scale dBFS; voltage (…), AIN = –20`（实测 p17）。
                if grp_rect and cond_rect and tuple(grp_rect) == tuple(cond_rect):
                    grp, cond = "", _ac_cell_text(inside, grp_rect)
                else:
                    # 分组列（f1/f2 那一列）同样会被纵向合并。合并了就必须
                    # 整格读，否则 f2 会整段丢（实测 p16/p19 的 IMD3 中间那行）。
                    grp = (_ac_cell_text(inside, grp_rect)
                           if _ac_spans(grp_rect, row_bands) > 1
                           else (cell_text(2) or _ac_cell_text(inside, grp_rect)))
                    cond = (cell_text(3) or _ac_cell_text(inside, cond_rect))
                unit = _ac_cell_text(inside, _ac_smallest_cell(table, *bands[7], yc)) \
                    if len(bands) > 7 else ""
                unit = re.sub(r"\s+", "", unit)
                conds = "; ".join(x for x in (grp, cond) if x)
                bbox = [round(bands[0][0], 1), round(ry0, 1),
                        round(bands[-1][1], 1), round(ry1, 1)]
                # 参数列**必须整格读**，不能按行带取词：同一参数跨两行时
                # TI 把它纵向合并成一格，格里有 2 行文本。按行带过滤只会取到
                # 落在这条带里的那半句（实测 p14 NSD 两行读成
                # `Noise spectral density, excludes fixed interleaving` /
                # `excludes fixed interleaving spur (fS / 2 spur)`，
                # SNR 两行读成 `… HD2 to` / `HD9, fS / 2, fS / 2 – fIN,`）。
                # 纵向合并 = 该参数适用于整段跨度，整格读才是对的。
                # 条件列**不能**这样改：合并条件格跨 4 行时整格读会把 4 条子条件
                # 塞进每一行，正是 1102 那 18 条重复的成因。
                param = _ac_cell_text(inside, _ac_smallest_cell(table, *bands[1], yc))
                # 原表这一行到底填了哪几列 —— 落盘，闸门才有判据。
                # `min == typ == max` 只有在这一行原表本来就是三列同值时才算合法；
                # 靠事后看 JSON 分不出来，所以这里记下来。
                # 字母取 L/T/H（low/typ/high）：min 与 max 的首字母都是 m，
                # 用首字母会撞成 "mm"，分不清是 MIN+MAX 还是别的。
                shape = "".join(c for c, k in (("L", "min"), ("T", "typ"), ("H", "max"))
                                if vals[k])
                out.append({
                    "symbol": sym,
                    "parameter": param,
                    "conditions": conds,
                    "min": vals["min"], "typ": vals["typ"], "max": vals["max"],
                    "unit": unit,
                    "value_shape": shape,
                    "mode": mode.lower().replace(" ", "_").replace("-", "_") if mode else "",
                    "table": title, "page": pi + 1,
                    # 行级溯源：复核方要能翻到这一页、这一行、这一块
                    "row_idx": ri,
                    "bbox": bbox,
                    "row_sha256": _ac_row_fingerprint(pi + 1, title, (bbox[1], bbox[3]),
                                                      sym, vals, unit),
                    "verification": {"status": "audited_deterministic",
                                     "method": "ac_row_anchor_v2",
                                     "page": pi + 1,
                                     "bbox": bbox},
                })
    # 同一 (页, 表, 位置, 值) 只留一条：几何相同就是同一条原始行被抽了两次。
    # 反过来，内容相同但位置不同（如 SFDR 的 fIN=2397/AIN=–3 与
    # FS_RANGE 两行都是 67）会保留两条 —— 那是原表真的有两行。
    seen: set[str] = set()
    uniq: list[dict] = []
    for rec in out:
        fp = rec["row_sha256"]
        if fp in seen:
            continue
        seen.add(fp)
        uniq.append(rec)
    return uniq


#: 通用规格表的列角色关键词（表头文本 → 角色）。大小写不敏感。
_SPEC_ROLE_HINTS = (
    ("min", ("MIN", "MINIMUM")),
    ("typ", ("TYP", "TYPICAL")),
    ("max", ("MAX", "MAXIMUM")),
    ("unit", ("UNIT", "UNITS")),
    ("cond", ("CONDITION", "CONDITIONS", "TEST CONDITIONS")),
    ("param", ("PARAMETER", "PARAMETERS")),
)


#: 列带 x 容差。`find_tables` 的列边界与词中心会差 1~2pt（p12 的 MAX 值
#: 4.5 中心 508.96，列带右边界 508.1），按 0.6 判会把它推进 UNIT 列。
_COL_XPAD = 2.0


def _clean_unit(unit: str) -> str:
    """从被合并单元格污染的单位串里取真正的单位。

    p12 的 `find_tables` 会把下一行的值并进单位格：`mW0.6` /
    `4.54.43.62.6mA`。不清理，`_unit_ok` 与页面单位都会带脏数字。
    只在原串**含数字**时动手，正常单位一个字不改。
    """
    u = re.sub(r"\s+", "", unit or "")
    if not u or not re.search(r"\d", u):
        return u
    toks = re.findall(r"[A-Za-zµΩ°%/\-]+", u)
    return toks[-1] if toks else ""


def extract_spec_rows(page, table=None) -> list[dict]:
    """把一页规格表按「值行 × 列角色」确定性拆开。

    列角色由**表头文本**判定（MIN / TYP / MAX / UNIT / CONDITION / PARAMETER），
    不写死列号：ADS1201 是六列，ADC 的绝对最大表只有 MIN/MAX 甚至只有 MAX。

    行锚点用**值行**（MIN/TYP/MAX 列里每一行数值），不用 y 边界并集：
    ADS1201 这张表只有块级横线（ANALOG INPUT / SYSTEM PERFORMANCE …），
    子行之间靠留白分隔，y 边界并集只能切出 7 个大块，
    整块的值会被并成一串（`min=0 -10 -5 -20`）。

    为什么必须做到子行：ADS1201 的 ANALOG INPUT 是

        Absolute Input Voltage Range          0        +5     V
        (同参数，条件另起一行) With VBIAS(1)  –10      +10    V

    按「数值 + 参数名同页」只能得到 `0 to +5`，再把下一行的 `With VBIAS(1)`
    挂上去 —— 值和条件就错配了（1102 复审点名的正是这一条）。

    返回每条一行：`param/cond/min/typ/max/unit/page/row_idx/bbox/row_sha256`。
    参数名为空时按纵向合并向上继承。
    """
    tabs = page.find_tables().tables if table is None else [table]
    if not tabs:
        return []
    table = max(tabs, key=lambda t: (t.bbox[2] - t.bbox[0]) * (t.bbox[3] - t.bbox[1]))
    bands = _ac_bands(table)
    if len(bands) < 3:
        return []
    words = [((x0 + x1) / 2, (y0 + y1) / 2, w)
             for x0, y0, x1, y1, w, *_ in page.get_text("words")]
    inside = [w for w in words if table.bbox[1] - 2 <= w[1] <= table.bbox[3] + 2]
    if not inside:
        return []

    def band_words(idx: int, y: float, tol: float = 5.0) -> str:
        if idx is None or idx >= len(bands):
            return ""
        lo, hi = bands[idx]
        return _ac_join([(x, yy, w) for x, yy, w in inside
                         if lo - _COL_XPAD <= x <= hi + _COL_XPAD
                         and abs(yy - y) <= tol])

    # 1) 表头：前 3 个"行"里第一个能认出 MIN/TYP/MAX 的
    header_y = None
    roles: dict[str, int] = {}
    for probe in sorted({round(w[1], 1) for w in inside})[:40]:
        for bi in range(len(bands)):
            txt = band_words(bi, probe, 3.0).upper()
            if not txt:
                continue
            for role, keys in _SPEC_ROLE_HINTS:
                if role in roles:
                    continue
                if any(k in txt for k in keys):
                    roles[role] = bi
                    break
        if "min" in roles or "max" in roles or "typ" in roles:
            header_y = probe
            break
    if not roles or header_y is None:
        return []
    # 表头被单元格边界切断时（p12 实测 `MA` + `X`），单列文本永远认不出
    # `MAX`；把相邻两列拼起来、去掉空格再认一次。只补缺失角色，不覆盖。
    for _role, _keys in _SPEC_ROLE_HINTS:
        if _role in roles:
            continue
        for _bi in range(len(bands)):
            _txt = " ".join(band_words(_b, header_y, 3.0)
                            for _b in (_bi, _bi + 1) if _b < len(bands))
            _flat = _txt.replace(" ", "").upper()
            if any(_k in _flat for _k in _keys):
                roles[_role] = _bi
                break
    # 表头不一定写全：ADC 的绝对最大表第一格是空的，只有 `MIN MAX UNIT`。
    # 这时按位置回退 —— 条件列 = 最左值列的左邻，参数列 = 最左的有字列。
    # （该表实际是 `符号 | 描述 | 条件 | MIN | MAX | UNIT`，描述列不参与取值。）
    if "cond" not in roles:
        vcols = [roles[k] for k in ("min", "typ", "max") if k in roles]
        if vcols and min(vcols) > 0:
            roles["cond"] = min(vcols) - 1
    if "param" not in roles:
        roles["param"] = 0
    if "unit" not in roles:
        roles["unit"] = len(bands) - 1

    # 2) 行锚点 = 值列里**每个单元格**（一格一行）。用单元格而不是词：
    #    值会被折行（`VD11 +` / `0.5(5)`），按词 y 聚类会把一行拆成两条。
    vbands = [roles[k] for k in ("min", "typ", "max") if k in roles]
    anchors: set[tuple[float, float]] = set()
    for r in table.rows:
        for c in r.cells:
            if not c:
                continue
            if any(bands[b][0] - 1 <= c[0] <= bands[b][1] + 1 for b in vbands):
                if c[1] > header_y + 2:
                    anchors.add((round(c[1], 1), round(c[3], 1)))

    # MIN 与 MAX 单元格的 y 不一定完全对齐（折行高度不同），同一行会出两个锚点
    # → 同一条记录被抽两次（实测 VA11 / BG 各多一条）。
    # 按**中心距**聚类，不能按区间重叠：相邻行是边界相接的（y1 == 下一行 y0），
    # 一旦按重叠合并，整张表会塌成几行（实测 15 行塌成 8 行）。
    # 行锚点两套，按表的形态自动选：
    #
    # ① **格子锚点**：值列里每个"叶子单元格"是一行。适合 ADC 的绝对最大表
    #    （每格一个值，但 MIN 列有跨行合并的容器格，必须先丢掉容器）。
    # ② **值词锚点**：按值列里的词 y 聚行。适合 ADS1201（MIN/TYP/MAX 三列
    #    合成一个大格，整块只有一个格子，用格子锚点会塌成 8 行）。
    #
    # 判据是叶子格数量：合并严重的表叶子极少，此时用词更准。
    ordered = sorted(anchors)
    leaf = [a for a in ordered
            if not any(b != a and a[0] <= b[0] + 0.6 and b[1] <= a[1] - 0.6
                       for b in ordered)]
    heights = sorted(b - a for a, b in leaf)
    med_h = heights[len(heights) // 2] if heights else 0.0
    # 合并严重的表叶子格本身很高（ADS1201 的值区一格跨整块，~100pt），
    # 那种"叶子"不是一行，必须回退到值词锚点。
    if len(leaf) >= 3 and med_h <= 25.0:
        rows_: list[list[float]] = []
        for y0, y1 in leaf:
            if rows_ and abs((y0 + y1) - (rows_[-1][0] + rows_[-1][1])) / 2 <= 3.0:
                rows_[-1] = [min(rows_[-1][0], y0), max(rows_[-1][1], y1)]
                continue
            rows_.append([y0, y1])
        anchors = [(a, b) for a, b in rows_]
        use_cells = True
    else:
        vys = sorted({round(w[1], 1) for w in inside
                      if any(bands[b][0] - _COL_XPAD <= w[0]
                             <= bands[b][1] + _COL_XPAD
                             for b in vbands)
                      and w[1] > header_y + 4})
        grp: list[list[float]] = []
        for y in vys:
            if grp and y - grp[-1][-1] <= _AC_LINE_TOL:
                grp[-1].append(y)
            else:
                grp.append([y])
        anchors = [(g[0] - 5.0, g[-1] + 5.0) for g in grp]
        use_cells = False

    def cell_band_text(idx: int, y: float) -> str:
        """取该列带里覆盖 y 的**最小单元格**文本，x 限定在本列带内。

        用单元格的 y 跨度而不是固定 ±5：值会折行，参数名是下标
        （`V_DD` 的 `DD` 比 `V` 低几个点），按同 y 取词会漏或取错行。
        """
        if idx is None or idx >= len(bands):
            return ""
        rect = _ac_smallest_cell(table, *bands[idx], y)
        if not rect:
            return band_words(idx, y)
        lo, hi = bands[idx]
        return _ac_join([(x, yy, w) for x, yy, w in inside
                         if lo - _COL_XPAD <= x <= hi + _COL_XPAD
                         and rect[1] - 0.6 <= yy <= rect[3] + 0.6])

    # 取文本必须跟着锚点走：用值词锚点时**不能**再按单元格 y 跨度取，
    # 否则会把整块合并格的值串成一条（ADS1201 实测 `min=0 -10 -5 -20`）。
    def get_text(idx: int, y: float) -> str:
        return cell_band_text(idx, y) if use_cells else band_words(idx, y)

    out: list[dict] = []
    last_param = ""
    for ri, (ry0, ry1) in enumerate(sorted(anchors)):
        y = (ry0 + ry1) / 2
        param = get_text(roles.get("param"), y).strip()
        if param:
            last_param = param
        vals = {k: _num_norm(get_text(roles.get(k), y))
                for k in ("min", "typ", "max")}
        if not any(vals.values()) or not last_param:
            continue
        # 值区被合并成一格时（p12 `IHVSS`/`Power dissipation`），按列带的
        # `get_text` 会把两个数都塞进 TYP、MAX 留空。用同一视觉行里的**纯数词**
        # 按 x 就近落回 MIN/TYP/MAX 列；只在 MAX 为空、且每个落点唯一时才改，
        # 不碰本来就分对列的行（p11 `IAVDD` 的 max 非空，直接跳过）。
        if not vals["max"] and vals["typ"]:
            role_of = {roles[k]: k for k in ("min", "typ", "max") if k in roles}
            picks: dict[str, list[str]] = {"min": [], "typ": [], "max": []}
            # 合并格会跨过列带边界：用整个值区（最左 MIN 到最右 MAX）收词，
            # 再按 x 就近落列；只按单列 x 过滤会把格里的第二个数漏掉。
            vlo = min(bands[b][0] for b in role_of)
            vhi = max(bands[b][1] for b in role_of)
            for x, yy, w in inside:
                if not (ry0 - 0.6 <= yy <= ry1 + 0.6):
                    continue
                if not (vlo - 2.0 <= x <= vhi + 2.0):
                    continue
                if not _NUM_ONLY.match(w.strip()):
                    continue
                bi = min(role_of, key=lambda b: abs(
                    (bands[b][0] + bands[b][1]) / 2 - x))
                picks[role_of[bi]].append(w.strip())
            if (picks["min"] and picks["max"]
                    and all(len(v) == 1 for v in picks.values() if v)):
                vals = {k: (picks[k][0] if picks[k] else "") for k in vals}
        cond = get_text(roles.get("cond"), y).strip()
        unit = _clean_unit(get_text(roles.get("unit"), y))
        # 未分配角色的列通常就是「描述」列：`tACQ` 左边是符号、右边是
        # `Acquisition time`。不带到匹配文本里，`Acquisition Time` /
        # `Clock Cycles per Conversion` 这类 JSON 名永远对不上符号。
        _assigned = {v for v in roles.values() if v is not None}
        desc = " ".join(
            t for t in (get_text(i, y).strip() for i in range(len(bands))
                        if i not in _assigned) if t)
        rec = {
            "param": last_param, "cond": cond, "desc": desc,
            "min": vals["min"], "typ": vals["typ"], "max": vals["max"],
            "unit": unit, "page": page.number + 1, "row_idx": ri,
            "bbox": [round(bands[0][0], 1), round(ry0, 1),
                     round(bands[-1][1], 1), round(ry1, 1)],
        }
        rec["row_sha256"] = _ac_row_fingerprint(
            rec["page"], last_param, (rec["bbox"][1], rec["bbox"][3]),
            cond, vals, unit)
        out.append(rec)
    return out


def _norm_pages(fitz_doc, pages: list[int]) -> list[tuple[int, str]]:
    """取指定页的归一化文本：行尾连字符接回 + 折成单行。

    `common-mode` 被排到行尾时读成 `common-\\nmode`，不接回来锚点永远匹配不上。
    """
    out = []
    for pi in pages:
        t = _num_norm(fitz_doc[pi].get_text() or "")
        t = re.sub(r"-\s*\n\s*", "-", t)
        out.append((pi + 1, re.sub(r"\s+", " ", t)))
    return out


#: 参数名切词：`Input Common-Mode Voltage (CLK±)` → `Input` / `Common-Mode` / `Voltage` / `CLK±`。
#: 取最长实词做锚（与 `fact_acceptance._label_pages` 同口径）。
#:
#: **这两个常量曾经漏定义**（V4 只写了用法没写定义）：`fill_row_sources()` 在
#: 参数名里带括号的型号上抛 `NameError: _SRC_SPLIT_RE`，而 `normalize()` 那时是
#: 整段 try —— 一个 NameError 把后面 3 个确定性步骤（input_ranges /
#: absolute_max_roles）全部跳过了。ADS1201 的输入范围在 V4 里始终没被重切、
#: `facts_audit` 0 verified，根因就在这里，不是"表格太乱"。
_SRC_SPLIT_RE = re.compile(r"[^A-Za-z0-9+±/-]+")
_SRC_NUM_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")


def _anchor(label: str) -> str:
    words = [w for w in _SRC_SPLIT_RE.split(label or "") if len(w) >= 4]
    return max(words, key=len).lower() if words else ""


def fill_row_sources(doc: dict, fitz_doc, max_pages: int = 40) -> dict:
    """给电气行补逐行溯源：`source.page` + `source.quote`（Reviewer V7 第 2 条）。

    22 条电气行此前 `source` 全空 —— 球位侧 144/144 都带 bbox 与页码，
    电气侧却一条都没有，客户没法验证任何一行。这里补的是**能确定性补的部分**：
    参数名与它的数值**出现在同一页**时，记下页码和原文片段。

    只认「同页共现」，不做模糊匹配：数值在别的页出现不算（那是另一种归属猜测）。
    补不上的行保持原样，`source` 留空 —— 空着比填一个猜的页码诚实。
    """
    specs = doc.setdefault("specs", {})
    if not isinstance(specs, dict):
        specs = doc["specs"] = {}
    elec = dict_rows(specs, "electrical")
    if not elec:
        return {}

    pages = _norm_pages(fitz_doc, list(range(min(fitz_doc.page_count, max_pages))))
    added = 0
    for row in elec:
        if isinstance(row.get("source"), dict) and row["source"].get("page"):
            continue
        label = str(row.get("name") or "")
        anchor = _anchor(label)
        if not anchor:
            continue
        nums = []
        for k in ("min", "typ", "max", "value"):
            nums.extend(_SRC_NUM_RE.findall(_num_norm(str(row.get(k) or ""))))
        if not nums:
            continue
        apat = re.compile(r"(?<![a-z])" + re.escape(anchor) + r"(?![a-z])")
        npat = [re.compile(r"(?<![\d.])" + re.escape(t) + r"(?![\d.])")
                for t in dict.fromkeys(nums)]
        for pno, txt in pages:
            low = txt.lower()
            m = apat.search(low)
            if not m:
                continue
            if not all(p.search(txt) for p in npat):
                continue
            lo = max(0, m.start() - 70)
            row["source"] = {
                "page": pno,
                "quote": txt[lo:m.end() + 110].strip(),
                "method": "label_value_colocation",
            }
            ver = row.setdefault("verification", {})
            ver.setdefault("page", pno)
            added += 1
            break
    return {"added": added, "rows": len(elec)} if added else {}


_AMAX_TITLE_RE = re.compile(r"Absolute Maximum Ratings", re.I)
_FOOTNOTE_RE = re.compile(r"\(\d+\)")


def _amax_key(lo: str, hi: str, unit: str) -> tuple[str, str, str]:
    """比较用键：去掉脚注标号、统一破折号、压空白。

    `VD11 + 0.5(5)` 与 `VD11 + 0.5` 是同一条，不归一就永远匹配不上。
    """
    def n(s: str) -> str:
        s = _FOOTNOTE_RE.sub("", str(s or ""))
        s = _num_norm(s)
        return re.sub(r"\s+", " ", s).strip()
    return n(lo), n(hi), n(unit)


def _split_value_range(value: str) -> tuple[str, str]:
    """把 `-0.3 to 2.35` / `26.5` / `-0.5 to VD11 + 0.5` 拆成 (MIN, MAX)。

    单值不是"范围"，它只能是**上限**（amax 表里单值行全是上限：
    Tj = 150、PMAX = 26.5、IMAX(ALL) = 100）。这里返回 ("", v)，
    绝不把单值同时填进 MIN —— 那正是 Reviewer 抓到的伪造形态。
    """
    s = _num_norm(str(value or "")).strip()
    if not s:
        return "", ""
    m = re.match(r"^(.*?)\s+to\s+(.*)$", s, re.I)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return "", s


#: amax 表里参数名（JSON）与表内 `param/cond` 的对照用词。
#: 只取「大写字母开头的编号类词」，`VA19` / `VD11` / `TMSTP` / `DA[7:0]` 都在内，
#: 而 `Peak`、`Junction` 这类自然语言词不进 —— 它们靠数值匹配。
_AMAX_TOKEN_RE = re.compile(r"[A-Z][A-Z0-9_]{1,}(?:\[[^\]]+\])?")


def _amax_tokens(text: str) -> set[str]:
    return set(_AMAX_TOKEN_RE.findall(str(text or "")))


def _amax_match(item: dict, rows: list[dict],
                by_value: dict) -> tuple[dict | None, str]:
    """给一条 amax 行找原表对应的行，返回 `(hit, 匹配方式)`。

    两条路，先名字后数值：

    1. **参数名**：JSON 名里的大写编号词（`VA19` / `TMSTP` / `DA[7:0]`）与
       表内 `param + cond` 的同类词求交，覆盖率 ≥ 0.5 且唯一最优才认。
    2. **数值**：名字对不上时（`Peak Total Input Current` 这种纯自然语言名），
       退回按 (MIN, MAX, 单位) 全等匹配，唯一命中才认。

    抽成函数是为了让 `fill_absolute_max()` 能**先试算再决定用哪张表**：
    同一页有几张表时，选「能匹配最多条」的那张，而不是面积最大的那张。
    """
    name = str(item.get("name") or "") if isinstance(item, dict) else ""
    unit = str(item.get("unit") or "") if isinstance(item, dict) else ""
    rng = item.get("range") if isinstance(item, dict) else None
    if not isinstance(rng, dict):
        rng = {}
    lo, hi = rng.get("min", ""), rng.get("max", "")
    if not (lo or hi):
        lo, hi = _split_value_range(item.get("value", "") if isinstance(item, dict) else "")

    hit, how = None, ""
    want = _amax_tokens(name)
    if want:
        scored: list[tuple[float, int, dict]] = []
        for r in rows:
            if r.get("from_dot") and not r.get("parsed"):
                continue          # 值没解析出来，第一轮不许拿它覆盖
            if _amax_key("", "", r["unit"])[2] != _amax_key("", "", unit)[2]:
                continue
            have = _amax_tokens(r["param"]) | _amax_tokens(r["cond"])
            hit_n = len(want & have)
            score = hit_n / len(want)
            # 只命中一个词不算定位。`REFIN Voltage to AGND` 与
            # `AVDD to AGND` 都含 `AGND`，0.5 分就会把前者认到后者那一行上，
            # 于是 `-0.3V to AVDD +0.3V` 被改写成 `-0.3 to 6` —— 这是**伪造**
            # （实测 ADS1201U 点线表接入后立刻踩到）。
            # 点线行要求更高：至少要撞上**两个**编号词。`Digital Input Voltage
            # to DGND` 只有一个 `DGND`，会认到 `DVDD to DGND` 那一行上，
            # 而它自己的值（`–0.3V to DVDD +0.3V`）是符号值、没被解析。
            need = 2 if r.get("from_dot") else 1
            if hit_n < need:
                continue
            if score >= 0.5 and (score >= 1.0 or hit_n >= 2):
                scored.append((score, len(r["cond"]), r))
        if scored:
            top = max(s for s, _, _ in scored)
            best = [r for s, _, r in scored if s == top]
            if len(best) == 1:
                hit, how = best[0], "param_name"
            else:
                # 平局时取条件最短的那条：`VA11(2)` 比
                # `Voltage between VD11 and VA11` 更可能就是 VA11 本行。
                shortest = min(len(r["cond"]) for r in best)
                pick = [r for r in best if len(r["cond"]) == shortest]
                if len(pick) == 1:
                    hit, how = pick[0], "param_name_shortest"
    if hit is None:
        cands = by_value.get(_amax_key(lo, hi, unit)) or []
        if len(cands) == 1:
            hit, how = cands[0], "value_exact"
    return hit, how


#: 点线行：`AVDD to DVDD ..................... –0.3V to 6V`
_DOT_LEADER_RE = re.compile(r"^(?P<name>.*?)[\s.]*\.{4,}[\s.]*(?P<val>.+)$")


def para_input(page: int, text: str) -> str:
    """正文条目指纹的输入串：`page|归一化文本`。

    与事实表 `qc/fact_acceptance._para_input()` 同一口径；唯一事实源放这里，
    抽取器写 `source.paragraph_sha256` 与审计器重算必须逐字节一致。
    """
    norm = re.sub(r"\s+", " ", _num_norm(text)).strip().lower()
    return str(page) + "|" + norm


def para_fingerprint(page: int, text: str) -> str:
    """正文条目指纹（`sha256(page|归一化文本)`）。"""
    return hashlib.sha256(para_input(page, text).encode("utf-8")).hexdigest()
#: 只认**无歧义**的值形态：`A to B` 或单个数字，可带常见单位。
#: `±100, Momentary; ±10, Continuous` 这种复合值一律不认 —— 拆错了就是把
#: 两个不同的限值焊成一条，比留在 unresolved 更糟。
_AMAX_PLAIN_RE = re.compile(
    r"^(?P<lo>[+-]?\d+(?:\.\d+)?)\s*(?:V|mV|A|mA|W|mW|C)?\s+to\s+"
    r"(?P<hi>[+-]?\d+(?:\.\d+)?)\s*(?P<unit>V|mV|A|mA|W|mW|C)?$", re.I)
_AMAX_ONE_RE = re.compile(
    r"^(?P<hi>[+-]?\d+(?:\.\d+)?)\s*(?P<unit>V|mV|A|mA|W|mW|C)?$", re.I)


#: 点线行下面的续行（没有参数名、也没有点线）：`±10mA, Continuous`。
#: 数值开头是判据；`NOTE:` / `ABSOLUTE MAXIMUM RATINGS` 这类标题不会误收。
_DOT_CONT_RE = re.compile(r"^(?:[+\-\u2212]?\d|\u00b1)")


def _amax_dot_lines(lines: list[tuple[str, list[float]]]) -> list[dict]:
    """把「点线行 + 续行」拼成行（纯函数，不依赖 PDF 对象，便于复现测试）。

    两个真实排版陷阱（ADS1201U p3 实测）：

    * `Analog Input: Current ............ ±100mA, Momentary` 的复合值分两行印，
      第二行 `±10mA, Continuous` 没有点线。只读点线行会丢一半值，逐字核对
      （`_num_keys`）因此永远对不上。
    * `Analog Input: Current` 下一行只印 `Voltage ............ AGND –0.3V ...`，
      参数名前缀 `Analog Input:` 被纵向合并、只出现在上一行。不继承前缀，
      第二行会变成一个叫 `Voltage` 的陌生参数，永远锚不上。
    """
    out: list[dict] = []
    for t, box in lines:
        t = re.sub(r"\s+", " ", _num_norm(t)).strip()
        if not t:
            continue
        m = _DOT_LEADER_RE.match(t)
        if m:
            name = m.group("name").strip(" .")
            # 共享前缀：上一行是 `Xxx Yyy: Name`，本行只有 `Name` 且缩进。
            if (out and ":" in out[-1]["param"] and ":" not in name
                    and len(name.split()) == 1 and not any(ch.isdigit() for ch in name)
                    and box and out[-1]["bbox"] and box[0] > out[-1]["bbox"][0] + 8):
                name = out[-1]["param"].split(":", 1)[0].strip() + ": " + name
            if not name:
                continue
            out.append({
                "param": name, "cond": "", "min": "", "max": "",
                "unit": "", "page": 0, "bbox": [round(float(v), 1) for v in box],
                "row_sha256": "", "from_dot": True, "parsed": False,
                "val_raw": _FOOTNOTE_RE.sub("", m.group("val")).strip(),
                "quote": t,
            })
            continue
        # 续行：接在上一条点线行后面（同列、纵向相邻）。
        if not out or not _DOT_CONT_RE.match(t) or len(box) != 4:
            continue
        prev = out[-1]
        prev_box = prev["bbox"]
        if not prev_box or box[0] < prev_box[0] - 2 or box[1] - prev_box[3] > 14:
            continue
        prev["val_raw"] = (prev["val_raw"] + "; " + t).strip("; ")
        prev["quote"] = (prev["quote"] + " " + t).strip()
        prev["bbox"] = [min(prev_box[0], round(float(box[0]), 1)),
                        min(prev_box[1], round(float(box[1]), 1)),
                        max(prev_box[2], round(float(box[2]), 1)),
                        max(prev_box[3], round(float(box[3]), 1))]
    return out


def _amax_dot_rows(page, page_no: int) -> list[dict]:
    """把点线排版的绝对最大额定值表读成行。

    为什么要单独一支：`find_tables()` 认的是**有框线的表**。ADS1201U 的
    绝对最大额定值表是「参数名 + 点线 + 值」的排版，一页只识别出一个 2 行的
    小表，于是 `fill_absolute_max()` 一条也匹配不上（复核方 V5 复审 新-5）。

    只解析无歧义的形态，其余一律跳过：

    * `–0.3V to 6V` → MIN/MAX 由 **`to` 这个词**决定，不是猜列角色；
    * `300` → 单值只能是上限（与 `_split_value_range()` 同一条规矩）；
    * `±100, Momentary; ±10, Continuous`、`AGND –0.3V to AVDD +0.3V`
      这类复合 / 符号值**不解析** —— 拆错等于伪造一条限值。

    行拼接（续行 / 共享前缀）交给纯函数 `_amax_dot_lines()`。
    """
    raw: list[tuple[str, list[float]]] = []
    try:
        blocks = page.get_text("dict").get("blocks") or []
    except Exception:                                          # noqa: BLE001
        return []
    for b in blocks:
        if b.get("type") != 0:
            continue
        for ln in b.get("lines") or []:
            t = "".join(s.get("text") or "" for s in ln.get("spans") or [])
            box = [round(float(v), 1) for v in ln.get("bbox") or []]
            if not t.strip() or len(box) != 4:
                continue
            raw.append((t, box))
    # 点线/续行按阅读顺序（y 然后 x）合并；多列页也不会把左右栏交错。
    raw.sort(key=lambda x: (round(x[1][1], 1), x[1][0]))
    out = _amax_dot_lines(raw)
    for rec in out:
        rec["page"] = page_no
        val = rec["val_raw"]
        mm = _AMAX_PLAIN_RE.match(val)
        if mm:
            rec["min"], rec["max"] = mm.group("lo"), mm.group("hi")
            rec["unit"] = mm.group("unit") or ""
            rec["parsed"] = True
        else:
            mo = _AMAX_ONE_RE.match(val)
            if mo:
                rec["max"] = mo.group("hi")
                rec["unit"] = mo.group("unit") or ""
                rec["parsed"] = True
    return out


def fill_absolute_max(doc: dict, fitz_doc, max_pages: int = 12) -> dict:
    """用列角色已核的确定性抽取**重建**绝对最大额定值的 MIN/MAX。

    Reviewer 7.5 分复审 P0-3 / 元宝 V9 任务二：15 条 amax 行的
    `range` 是 `derived_from_value`（从 `-0.3 to 2.35` 这个字符串里切出来的），
    状态 `column_roles_not_verified` —— 也就是说"哪一列是 MIN"从来没被证明过。

    这里拿 `extract_spec_rows()`（MIN/MAX 由**表头文本**判定，带 bbox）逐条比对，
    按两条路找对应行：

    1. **参数名匹配**：JSON 名里的大写编号词（`VA19`/`TMSTP`/`DA[7:0]`）与
       表内 `param + cond` 的同类词求交，覆盖率 ≥ 0.5 且唯一最优才认。
    2. **数值匹配**：名字对不上时（`Peak Total Input Current` 这种纯自然语言名），
       退回按 (MIN, MAX, 单位) 全等匹配，唯一命中才认。

    命中后：

    * 值一致 → `audited_deterministic`；
    * 值不一致 → **用 PDF 的值覆盖**，并在 `verification.note` 里留原值
      （实测 `Pin Voltage Range - DA[7:0]…` 的 JSON 写 `-0.5 to VS11 + 0.5`，
      而 p9 该行印的是 `VD11 + 0.5` —— LLM 把 VS11 编出来了）；
    * 找不到 → 保持 `unresolved`，记进 `unmatched`，**不静默**。

    返回 `{"checked": n, "upgraded": n, "replaced": n, "unmatched": [...]}`。
    """
    cand_sets: list[list[dict]] = []
    for pi, page in enumerate(fitz_doc):
        if pi >= max_pages:
            break
        try:
            txt = page.get_text() or ""
        except Exception:                                      # noqa: BLE001
            continue
        if not _AMAX_TITLE_RE.search(txt):
            continue
        # 这一页可能有好几张表。`extract_spec_rows()` 默认只取**面积最大**的那张，
        # 在 ADS1201U 上恰好是引脚功能表 —— 于是 11 条 amax 全部 unmatched
        # （复核方 V5 复审 新-5）。这里把每张表都试一遍，按能匹配上的条数选，
        # 而不是按面积选：面积与「是不是绝对最大额定值表」没有关系。
        tabs = sorted(page.find_tables().tables or [],
                      key=lambda t: (t.bbox[2] - t.bbox[0]) * (t.bbox[3] - t.bbox[1]),
                      reverse=True)
        for t in tabs:
            try:
                got = extract_spec_rows(page, table=t)
            except Exception:                                  # noqa: BLE001
                got = []
            if got:
                cand_sets.append(got)
        if cand_sets:
            break

    if not cand_sets:
        # 没有可识别的表格 → 退回点线排版（见 `_amax_dot_rows`）。
        for pi, page in enumerate(fitz_doc):
            if pi >= max_pages:
                break
            try:
                txt = page.get_text() or ""
            except Exception:                                  # noqa: BLE001
                continue
            if not _AMAX_TITLE_RE.search(txt):
                continue
            got = _amax_dot_rows(page, pi + 1)
            if got:
                cand_sets.append(got)
            break

    specs = doc.setdefault("specs", {})
    if not isinstance(specs, dict):
        specs = doc["specs"] = {}
    amax = safe_list(specs, "absolute_max")
    if not cand_sets or not amax:
        return {}
    amax = [x for x in amax if isinstance(x, dict)]   # 脏元素不参与匹配，也不许崩
    if not amax:
        return {}

    def _index(rows: list[dict]) -> dict[tuple[str, str, str], list[dict]]:
        idx: dict[tuple[str, str, str], list[dict]] = {}
        for r in rows:
            idx.setdefault(_amax_key(r["min"], r["max"], r["unit"]), []).append(r)
        return idx

    # 选「能匹配最多条」的那张表。平手时保留面积大的（先出现的）。
    best, best_n = cand_sets[0], -1
    for rows in cand_sets:
        by_value = _index(rows)
        n = sum(1 for it in amax if _amax_match(it, rows, by_value)[0] is not None)
        if n > best_n:
            best, best_n = rows, n
    rows = best
    by_value = _index(rows)

    upgraded, replaced, unmatched = 0, 0, []
    for item in amax:
        name = str(item.get("name") or "")
        unit = str(item.get("unit") or "")
        rng = item.get("range") or {}
        lo = rng.get("min", "")
        hi = rng.get("max", "")
        if not (lo or hi):
            lo, hi = _split_value_range(item.get("value", ""))

        hit, how = _amax_match(item, rows, by_value)
        if hit is None:
            unmatched.append(name[:60])
            continue

        new_lo, new_hi = hit["min"], hit["max"]
        # 展示用值去掉脚注标号（`VD11 + 0.5(5)` → `VD11 + 0.5`）：`(5)` 是脚注
        # 序号，印到商品页上会被当成数值的一部分。原文照旧留在 `source.quote`。
        disp_lo = _FOOTNOTE_RE.sub("", new_lo).strip()
        disp_hi = _FOOTNOTE_RE.sub("", new_hi).strip()
        # 单值行只印了上限，`value` 就不能写成 `to 26.25` —— 页面上会出现
        # 一句读不通的 `to 26.25`（实测）。
        old_txt = f"{lo} to {hi}" if (lo and hi) else (lo or hi)
        new_txt = (f"{disp_lo} to {disp_hi}" if (disp_lo and disp_hi)
                   else (disp_lo or disp_hi))
        note = ""
        if _amax_key(lo, hi, unit) != _amax_key(new_lo, new_hi, unit):
            replaced += 1
            note = f"列角色回验覆盖：原值 {old_txt!r} → {new_txt!r}"
        item["range"] = {"min": disp_lo, "max": disp_hi}
        item["value"] = new_txt or item.get("value", "")
        item["range_origin"] = "column_roles_verified"
        _src = {"page": hit["page"], "bbox": hit["bbox"],
                "quote": hit.get("quote") or " | ".join(
                    x for x in (hit["param"], hit["cond"], new_lo, new_hi,
                                hit["unit"]) if x)}
        # 点线行没有几何指纹（它不是表的一行），只给页码 + bbox + 原文：
        # 写一个重放不出来的 `row_sha256` 会正好造出 V5 被判的那种矛盾行。
        if hit.get("row_sha256"):
            _src["row_sha256"] = hit["row_sha256"]
        item["source"] = _src
        item["verification"] = {"status": "audited_deterministic",
                                "method": "spec_row_v2", "matched_by": how,
                                "page": hit["page"], "bbox": hit["bbox"]}
        if note:
            item["verification"]["note"] = note
        upgraded += 1
    specs["absolute_max"] = amax

    # 第二轮（仅点线表）：符号值不解析列角色，但可以**逐字核对**。
    # `–0.3V to AVDD +0.3V` 这种值里 MIN/MAX 不是两个数，硬拆就是把 `AVDD`
    # 当成上限（比不拆更糟）。能做的只有一件事：确认原文这一行印的就是这个值，
    # 于是状态记 `audited_paragraph` —— 坐标级证据，但不主张列角色。
    if rows and rows[0].get("from_dot"):
        for item in amax:
            if str((item.get("verification") or {}).get("status") or "") == \
                    "audited_deterministic":
                continue
            name = str(item.get("name") or "")
            val = _num_norm(str(item.get("value") or ""))
            for r in rows:
                if r.get("parsed"):
                    continue          # 已解析的行在第一轮处理，这里只管符号值
                if _name_score(name, r["param"]) < 0.9:
                    continue
                if _num_keys([val]) != _num_keys([r.get("val_raw") or ""]):
                    continue
                text_for_sha = r["quote"]
                item["source"] = {
                    "page": r["page"], "bbox": r["bbox"],
                    "quote": text_for_sha,
                    "paragraph_sha256": para_fingerprint(r["page"], text_for_sha),
                    "sha_input": para_input(r["page"], text_for_sha),
                }
                item["verification"] = {
                    "status": "audited_paragraph",
                    "method": "dot_leader_verbatim",
                    "page": r["page"], "bbox": r["bbox"],
                    "note": "原文逐字一致；值为符号量，MIN/MAX 列角色未解析",
                }
                break
    return {"checked": len(amax), "upgraded": upgraded, "replaced": replaced,
            "unmatched": unmatched}


#: 输入范围类参数：这些行在 TI 表里是**子行**结构，必须按列角色逐格取。
_INPUT_RANGE_NAMES = ("Absolute Input Voltage Range",
                      "Differential Input Voltage Range")


def extract_input_range_rows(fitz_doc, max_pages: int = 8) -> list[dict]:
    """抽 `Absolute/Differential Input Voltage Range` 的**逐子行**版本。

    Reviewer 7.5 分复审的 P0-2：ADS1201 的 JSON 是 `0 to +5 V` + 条件
    `With VBIAS(1)`，而原表是两行 ——

        Absolute Input Voltage Range          0        +5     V
        With VBIAS(1)                        –10      +10    V

    条件和值被错配（`With VBIAS(1)` 是**第二行**的条件）。同页文本里还有
    `-10` `+10` `-20` `+20`，所以「数值 + 参数名同页」永远证不出列角色。

    只扫前 `max_pages` 页：这类表都在手册前几页，全扫会踩 SIGTERM 老坑。
    """
    for pi, page in enumerate(fitz_doc):
        if pi >= max_pages:
            break
        try:
            txt = page.get_text() or ""
        except Exception:                                      # noqa: BLE001
            continue
        if not any(n in txt for n in _INPUT_RANGE_NAMES):
            continue
        rows = [r for r in extract_spec_rows(page)
                if any(r["param"].startswith(n) for n in _INPUT_RANGE_NAMES)]
        if rows:
            return rows
    return []


def _range_text(lo: str, hi: str, typ: str) -> str:
    if lo and hi:
        return f"{lo} to {hi}"
    if typ and hi:
        return f"{typ} to {hi}"
    return lo or hi or typ


_NUM_ONLY = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")


def _num_cell(s) -> bool:
    """这一格是不是一个纯数（`-20` / `+0.3` / `1e-3`），不是 `See Note 2`。"""
    return bool(_NUM_ONLY.match(str(s or "").strip().replace(" ", "")))


def _input_range_row(name: str, r: dict, unit: str) -> dict:
    """一条输入范围子行。

    V9 P0-1：`TYP` 格是脚注/文字（`See Note 2`）时，MIN/MAX 是从「剩下的两格」
    推出来的，**没有独立核验过列角色**。以前照写
    `range={"min","max"} + range_origin="column_roles_verified"`，事实表却把这一行
    降成 `verified_value` 且 `missing_cols=min,max` —— 同一件事两种状态，
    下游读 `range` 就拿到一个「看起来已核验」的区间。宁可不给结构，
    也不给一个会被当真的 `{min,max}`（见 `qc/range_guard.py`）。
    """
    lo, hi = str(r.get("min") or ""), str(r.get("max") or "")
    typ = str(r.get("typ") or "")
    cols_ok = _num_cell(lo) and _num_cell(hi) and not (typ and not _num_cell(typ))
    row = {
        "name": name,
        "value": _range_text(lo, hi, typ),
        "unit": r.get("unit") or unit or "V",
        "condition": r["cond"],
        **({"typ": typ} if typ else {}),
        "source": {"page": r["page"], "bbox": r["bbox"],
                   "row_sha256": r["row_sha256"],
                   "quote": " | ".join(x for x in (name, r["cond"], lo, typ,
                                                   hi, r["unit"]) if x)},
        "verification": {"status": "audited_deterministic",
                         "method": "spec_row_v2",
                         "page": r["page"], "bbox": r["bbox"]},
    }
    # MIN/MAX 是**列位证据**：只要两格都是纯数，就按抽取器判定的列角色留档。
    # TYP 是脚注（`See Note 2`）时旧实现连 min/max 一起丢掉，事实表于是
    # 记 `missing_cols=min,max` 并把本来可重放的行指纹降成坐标级
    # （ADS1201U `Differential Input Voltage Range | With VBIAS`，1102-V3）。
    # 正式 `range` 仍然只发给列角色完全可信的行 —— 留证据 ≠ 发区间。
    if _num_cell(lo):
        row["min"] = lo
    if _num_cell(hi):
        row["max"] = hi
    if cols_ok:
        row["range"] = {"min": lo, "max": hi}
        row["range_origin"] = "column_roles_verified"
    else:
        row["range_origin"] = "column_roles_unverified"
        row["range_note"] = ("TYP 列是脚注/文字，MIN/MAX 列角色未独立核验；"
                             "不给 range 结构，避免下游当已核验区间读")
    return row


def fill_input_ranges(doc: dict, fitz_doc) -> dict:
    """把输入范围行改写成逐子行、列角色已核的形态。

    改写后每条子行自带 `source.bbox` 与 `row_sha256`，复核方可以翻到原页
    对那一个格子。状态给 `audited_deterministic` —— 这是确定性复现，不是
    「同页命中」。
    """
    rows = extract_input_range_rows(fitz_doc)
    if not rows:
        return {}
    specs = doc.setdefault("specs", {})
    elec = specs.get("electrical")
    if not isinstance(elec, list):
        return {}

    by_name: dict[str, list[dict]] = {}
    for r in rows:
        name = next(n for n in _INPUT_RANGE_NAMES if r["param"].startswith(n))
        by_name.setdefault(name, []).append(r)

    replaced = 0
    out: list[dict] = []
    emitted: set[str] = set()
    for item in elec:
        name = str(item.get("name") or "").strip()
        if name not in by_name:
            out.append(item)
            continue
        if name in emitted:                    # 同名旧行只保留一组，避免重复
            replaced += 1
            continue
        emitted.add(name)
        for r in by_name[name]:
            out.append(_input_range_row(name, r, item.get("unit") or "V"))
        replaced += 1

    # 抽到了、但模型整条漏掉的名字也要补上：`Differential Input Voltage Range`
    # 在 ADS1201 里是原表实有的一行，模型漏了就等于页面少一条规格。补的位置
    # 紧跟在同类行之后，读起来仍是一组。
    added: list[str] = []
    for name, rs in by_name.items():
        if name in emitted:
            continue
        idx = len(out)
        for i, it in enumerate(out):
            if str(it.get("name") or "").strip() in by_name:
                idx = i + 1
        block = [_input_range_row(name, r, "V") for r in rs]
        out[idx:idx] = block
        added.append(name)

    if not replaced and not added:
        return {}
    specs["electrical"] = out
    return {"replaced": replaced, "added": added,
            "rows": sum(len(v) for v in by_name.values()),
            "params": sorted(by_name)}


def fill_ac_performance(doc: dict, fitz_doc) -> dict:
    """把 AC 指标写进 `specs.ac_performance`（幂等，只补不覆盖已核验行）。

    少于 4 行不写：板卡 User's Guide 里偶尔也会出现 `MIN`/`TYP` 与某个符号字样，
    一两行"命中"更可能是误匹配。宁可这条型号没有 AC 表，也不要塞进噪声。
    """
    rows = extract_ac_performance(fitz_doc)
    if len(rows) < 4:
        return {}
    specs = doc.setdefault("specs", {})
    old = specs.get("ac_performance") or []
    if old == rows:
        return {"changed": False, "rows": len(rows)}
    specs["ac_performance"] = rows
    return {"changed": True, "rows": len(rows),
            "before": len(old), "method": "deterministic"}



# ---------------------------------------------------------------- 行级锚定
#: 常见缩写 → 原文全称。**只用于打分**，不改任何输出文本。
#: 没有这张表时 `ENOB` 与原文 `Effective number of bits` 的 token 交集为 0，
#: 明明是同一张表格行也会被判「无法锚定」，白丢一批本可升级的行。
_NAME_ALIASES = {
    "enob": "effective number of bits",
    "snr": "signal-to-noise ratio",
    "sfdr": "spurious free dynamic range",
    "nsd": "noise spectral density",
    "imd3": "third order intermodulation distortion",
    "thd": "total harmonic distortion",
    "vcm": "input common mode voltage",
    "psrr": "power supply rejection ratio",
    "cmrr": "common mode rejection ratio",
}

#: 可以被行级锚定**升级**的状态。`audited_*` 一律不动：那些行已经是确定性
#: 抽取的产物（VCMI/VID 由 `_merge_input_limits` 写入），拿「同页」去覆盖
#: 它等于把强证据换成弱证据。
_UPGRADABLE = frozenset({"model_unverified", "unresolved", "not_checked", ""})


def _word_lines(page) -> list[dict]:
    """把一页切成**视觉行**：`{y, w: [(x0,y0,x1,y1,word), ...]}`。

    为什么要自己切：`page.get_text()` 按块输出，ROC 表里 `1.8 / 1.9 / 2.0 / V`
    四个格子会被拆成四行文本（每格一块），按文本行读根本凑不出「一行三个数」。
    按词框的 y 中心聚类才是**视觉行** —— 同一行 y 相同，格子边界不影响。
    """
    ws = [(x0, y0, x1, y1, w) for x0, y0, x1, y1, w, *_ in page.get_text("words")]
    ws.sort(key=lambda t: ((t[1] + t[3]) / 2, t[0]))
    lines: list[dict] = []
    for x0, y0, x1, y1, w in ws:
        yc = (y0 + y1) / 2
        if lines and abs(yc - lines[-1]["y"]) <= 3.0:
            lines[-1]["w"].append((x0, y0, x1, y1, w))
        else:
            lines.append({"y": yc, "w": [(x0, y0, x1, y1, w)]})
    for it in lines:
        it["w"].sort(key=lambda t: t[0])
    return lines


_ROC_TITLE_RE = re.compile(r"Recommended Operating Conditions", re.I)
_ROC_COLS = ("MIN", "NOM", "MAX", "UNIT")


def extract_roc_rows(page) -> list[dict]:
    """按视觉行抽 Recommended Operating Conditions 表（ROC）。

    为什么单开一条路：这张表 `find_tables()` 给不出可用网格 —— ADC 的 p10
    实测把三行电源并成一格（`min=1.8 / max="2.0 1.15"`），列角色彻底错位，
    而 `Supply Voltage - VA19/VA11/VD11` 恰恰只在这张表里。文本层是干净的：

        VA19, analog 1.9-V supply(2)   1.8   1.9   2.0
        VA11, analog 1.1-V supply(2)   1.05  1.1   1.15

    列角色由**表头词的 x 中心**判定（`MIN NOM MAX UNIT` 各自的位置），
    不按数值个数猜：个数只能说明「填了几个」，不能说明「填的是哪一列」。
    数值个数与列位置不一致时整行丢弃 —— 宁可少一条，不要错一列。

    返回 `param/cond/min/typ/max/unit/page/bbox/row_sha256`，与
    `extract_spec_rows()` 同构，锚定器可以混用两路结果。
    """
    txt = page.get_text() or ""
    if not _ROC_TITLE_RE.search(txt):
        return []
    lines = _word_lines(page)
    hdr_i, cols = -1, {}
    for i, ln in enumerate(lines):
        up = [w[4].upper() for w in ln["w"]]
        if "MIN" in up and ("NOM" in up or "MAX" in up):
            for j, t in enumerate(up):
                if t in _ROC_COLS:
                    cols[t] = (ln["w"][j][0] + ln["w"][j][2]) / 2
            hdr_i = i
            break
    if hdr_i < 0 or "MIN" not in cols or "MAX" not in cols:
        return []

    # 列中心的合法区间：数值必须落在两个相邻列中心之间才谈得上"这一列"
    order = [c for c in _ROC_COLS if c in cols]
    centers = [cols[c] for c in order]
    left_edge = cols["MIN"] - 10.0

    # 左半部分（符号 | 描述 | 条件）**没有网格线**，只能靠「同一列的起始 x
    # 相同」还原：每行按 x 间隙切成 run，取每个 run 首词的 x0 聚类。
    # 这一步不做的话，`VDD` 那三个纵向合并的行会把
    # `VDD Supply voltage range VA11, analog 1.1-V supply` 连成一串 ——
    # VA11 与 VD11 两行的文本变得一模一样，锚定时只能判平局（实测）。
    #
    # 只统计**表体**的行：表注 `(1) Prolonged use…` 与下一张表的标题也在这页，
    # 它们的缩进会凭空多出 4 个假列（实测 left_cols 从 3 个涨到 7 个，
    # 条件列被指到 x=403 的数值区，抽出来的 cond 全是 `=`）。
    body: list[list] = []
    for ln in lines[hdr_i + 1:]:
        toks = ln["w"]
        if not toks:
            continue
        if re.match(r"^\(\d+\)", toks[0][4]):
            break
        head_txt = " ".join(w[4] for w in toks)
        if re.match(r"^\d+(\.\d+)*\s", head_txt) or re.search(
                r"Thermal Information|Absolute Maximum", head_txt, re.I):
            break
        body.append(toks)

    starts: list[float] = []
    for toks in body:
        prev_x1 = None
        for w in toks:
            if w[0] >= left_edge:
                prev_x1 = None
                continue
            if prev_x1 is None or w[0] - prev_x1 > 6.0:
                starts.append(round(w[0], 1))
            prev_x1 = w[2]
    left_cols: list[float] = []
    for x in sorted(starts):
        if left_cols and x - left_cols[-1] <= 8.0:
            continue
        left_cols.append(x)
    if not left_cols:
        return []
    # 列角色：最右一列是条件，最左一列是符号，中间（若有）是描述
    if len(left_cols) >= 3:
        sym_i, desc_i, cond_i = 0, 1, len(left_cols) - 1
    elif len(left_cols) == 2:
        sym_i, desc_i, cond_i = 0, None, 1
    else:
        sym_i, desc_i, cond_i = None, None, 0

    def left_buckets(toks) -> dict[int, str]:
        """左半部分按 **run**（x 间隙 ≤6pt 的连续词）归列，不按单词归列。

        按单词归列会把描述列最后一个词甩到条件列：`Temperature diode input
        current` 的 `current` 在 x=177，离条件列 228 比离描述列 100 更近，
        于是条件列读成 `current TDIODE+ to TDIODE–`（实测）。run 是排版上
        不可分割的单位，整段一起归列才对。
        """
        runs: list[list] = []
        for w in toks:
            if w[0] >= left_edge:
                continue
            if runs and w[0] - runs[-1][-1][2] <= 6.0:
                runs[-1].append(w)
            else:
                runs.append([w])
        acc: dict[int, list] = {}
        for r in runs:
            k = min(range(len(left_cols)), key=lambda i: abs(r[0][0] - left_cols[i]))
            acc.setdefault(k, []).extend(r)
        return {k: " ".join(x[4] for x in sorted(v, key=lambda t: t[0]))
                for k, v in acc.items()}

    out: list[dict] = []
    last_sym = last_desc = last_cond = ""
    for toks in body:
        buck = left_buckets(toks)
        raw_sym = buck.get(sym_i, "") if sym_i is not None else ""
        raw_desc = buck.get(desc_i, "") if desc_i is not None else ""
        raw_cond = buck.get(cond_i, "")
        if raw_sym and _looks_like_symbol(raw_sym.split()[0]):
            last_sym = raw_sym.split()[0]
        if raw_desc:
            last_desc = raw_desc
        if raw_cond:
            last_cond = raw_cond
        # 纵向合并：符号/描述本行没写就继承上一行（`VDD` 那三行共用一格）。
        # **条件不这样继承** —— 它只有在本行左半部分整段为空时才算"延续"，
        # 否则 `TA Operating free-air temperature` 会背上上一行的条件（实测）。
        sym = raw_sym or last_sym
        desc = raw_desc or last_desc
        cond = raw_cond if (raw_sym or raw_desc) else (raw_cond or last_cond)

        vals: dict[str, str] = {}
        unit = ""
        num_idx: list[tuple[float, str]] = []
        for x0, y0, x1, y1, w in toks:
            if _is_num(_num_norm(w)):
                num_idx.append(((x0 + x1) / 2, _num_norm(w)))
            elif _is_unit(w):
                unit = w
        if not num_idx:
            continue
        # 数值按 x 归到最近的列中心；不单调或超距 → 这一行不可信，丢弃
        picks: list[tuple[int, str]] = []
        for xc, val in num_idx:
            d = [abs(xc - c) for c in centers]
            k = d.index(min(d))
            if min(d) > 60.0:
                picks = []
                break
            picks.append((k, val))
        ks = [k for k, _ in picks]
        if not picks or ks != sorted(ks) or len(set(ks)) != len(ks):
            continue
        for k, val in picks:
            vals[order[k]] = val
        # 只有 NOM 一列有值的行：TI 把「单个限值」印在中间列（实测
        # `IC_TD 100 µA` 与 `PIN -1.5 dBm` 都落在 NOM 位置）。这种行不能
        # 用来证明列角色，但**行身份**仍然是确定的 —— 标成 `nom_only`
        # 让锚定器只做「单值对单值」的匹配，不主张 MIN/MAX。
        roles = ("nom_only" if ("MIN" not in vals and "MAX" not in vals)
                 else "min_max")
        param = f"{sym} {desc}".strip()
        if not param:
            param = cond
        if not param:
            continue
        y0 = min(w[1] for w in toks)
        y1 = max(w[3] for w in toks)
        rec = {
            "param": param, "cond": cond if cond != param else "",
            "min": vals.get("MIN", ""), "typ": vals.get("NOM", ""),
            "max": vals.get("MAX", ""), "unit": unit, "roles": roles,
            "page": page.number + 1,
            "bbox": [round(min(left_cols[0], toks[0][0]), 1), round(y0, 1),
                     round(max(toks[-1][2], centers[-1]), 1), round(y1, 1)],
        }
        rec["row_sha256"] = _ac_row_fingerprint(
            rec["page"], "ROC", (rec["bbox"][0], rec["bbox"][1]),
            param, {k.lower(): rec[k] for k in ("min", "typ", "max")}, unit)
        out.append(rec)
    return out


def _num_keys(values) -> set[str]:
    """数值比较键：`2` / `2.0` / `+2` 必须相等，`250(4)` 要取到 `250`。

    字符串直接比会在 ADS1201 上全线失败：JSON 写 `2.0`，表里印 `2`；
    JSON 写 `+5`，表里印 `5`。这条比较只认数，不认写法。
    """
    out: set[str] = set()
    for v in values:
        if v is None:
            continue
        for t in _SRC_NUM_RE.findall(_num_norm(str(v))):
            try:
                out.add(f"{float(t):.6g}")
            except ValueError:
                continue
    return out


def _tokens(text: str) -> set[str]:
    """打分用 token：小写实词（≥3 字符），缩写先展开成全称。"""
    out: set[str] = set()
    for w in re.split(r"[^A-Za-z0-9]+", (text or "").lower()):
        if len(w) < 3:
            continue
        out.add(w)
        alias = _NAME_ALIASES.get(w)
        if alias:
            out.update(a for a in alias.split() if len(a) >= 3)
    return out


def _label_core(label: str) -> str:
    """标签的「参数名部分」：`ENOB - Dual Channel Mode` → `ENOB`。

    模型爱把表名拼进参数名（`- Dual Channel Mode` / `- Single Channel Mode`），
    而原表的参数列只有 `ENOB`。不剥掉这截，7 个 token 里只有 3 个能对上，
    永远过不了 0.6 的线。
    """
    return re.split(r"\s+[-\u2013\u2014]\s+", label or "", maxsplit=1)[0]


def _name_score(label: str, cand: str, param: str | None = None) -> float:
    """参数名覆盖度。

    分母取**两边较短的那个**，不是标签长度。原表的参数名常常是标签的后半截：
    JSON 写 `Additional Analog Current: REFOUT Enabled`，表里只印
    `REFOUT Enabled` —— 按标签长度算只有 2/5 = 0.4，明明同一条行却被判不匹配
    （实测 ADS1201 白丢 2 行）。

    但放宽带价是误匹配，所以加两条闸：撞上的词少于 2 个且标签本身多于 1 个词时
    直接判 0（只共用一个 `Current` 不能定位一行）。

    `param` 单独传时，**分母用参数列的 token 数**而不是参数+条件：条件里
    `= FS_RANGE_B = 0xA000` 这种词会把分母撑大，`Full-Scale Input Power`
    对 `Fullscale Input Power` 只有 2/5 = 0.4（实测）。

    整串标签与剥掉表名的核心名各算一次取大：`ENOB - Dual Channel Mode`
    整串只有 3/7，核心名 `ENOB` 是 3/4。
    """
    if not cand:
        return 0.0
    b_all = _tokens(cand)
    b_par = _tokens(param) if param else b_all
    if not b_all:
        return 0.0
    best = 0.0
    for a in (_tokens(label), _tokens(_label_core(label))):
        if not a:
            continue
        hits = len(a & b_all)
        if hits < 2 and len(a) > 1:
            continue
        best = max(best, hits / min(len(a), len(b_par) or len(a)))
    return best


def _cond_score(a: str, b: str) -> float:
    """条件行覆盖度。同分裁决用 —— `±0.0015` 在 60Hz / 1kHz 两行都印，
    只有条件能分开它们。条件为空时不参与（返回 0，不影响比较）。"""
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta)


def _unit_key(s: str) -> str:
    """单位归一：大小写、微符号、空白，并丢掉抽取器串进来的散数。

    `find_tables` 在 p12 把下一行的 `0.6` 并进单位格，得到 `mW0.6`；不丢散数
    会让 `Power Dissipation` 永远单位不兼容。只丢数字，不丢字母 —— `mA` 与
    `A`、`MHz` 与 `Hz` 仍然不同。
    """
    s = (s or "").strip().lower().replace("μ", "µ").replace(" ", "")
    return re.sub(r"[\d.]+", "", s)


def _unit_ok(a: str, b: str) -> bool:
    """单位兼容。空的一方不参与判定 —— 空是"没说"，不是"不同"。"""
    x, y = _unit_key(a), _unit_key(b)
    if not x or not y:
        return True
    return x == y


def _row_value_nums(row: dict) -> set[str]:
    vals = [row.get(k) for k in ("min", "typ", "max", "value")]
    rng = row.get("range")
    if isinstance(rng, dict):
        vals.extend(rng.get(k) for k in ("min", "max"))
    return _num_keys(vals)


def _cand_param(c: dict) -> str:
    """候选行的**参数列**文本（不含条件）。三路候选的键名不统一，见 `_cand_text`。

    `desc` 是抽取器未分配角色列（通常是描述列）。把它并入分母，才能让
    `Acquisition Time` 对上原表的符号 `tACQ` + 描述 `Acquisition time`。
    """
    p = str(c.get("param") or c.get("parameter") or c.get("name") or "")
    d = str(c.get("desc") or "")
    return " ".join(x for x in (p, d) if x)


def _cand_text(c: dict) -> str:
    """候选行的可比较文本。

    三路候选的键名不统一：`extract_spec_rows` / `extract_roc_rows` 用
    `param`+`cond`，而 `specs.ac_performance` 用 `parameter`+`conditions`。
    只读前一对会让 AC 那一路的文本恒为空、分数恒为 0 —— 等于白加了候选。
    """
    parts = (c.get("param") or c.get("parameter") or c.get("name") or "",
             c.get("desc") or "",
             c.get("cond") or c.get("conditions") or "")
    return " ".join(x for x in parts if x)


#: 改名判据里的通用词：只靠这些词定位不了一行。`power` 刻意**不**进来 ——
#: `Power Consumption` 与 `Power Dissipation` 共享的 `power` 是具体名词，
#: 共享它说明是同义改写，不该自动改名。
_LABEL_GENERIC = frozenset({
    "input", "output", "voltage", "current", "range", "supply", "rate",
    "level", "mode", "value", "values", "minimum", "maximum", "typical",
    "and", "the", "with", "for", "from", "per", "single", "dual", "channel",
    "channels", "pin", "pins",
})


def _title_param(text: str) -> str:
    """原表参数名的展示形态：`Bipolar full-scale range` → `Bipolar Full-Scale Range`。"""
    def cap(word: str) -> str:
        return "-".join(p[:1].upper() + p[1:] for p in word.split("-"))
    return " ".join(cap(w) for w in re.split(r"\s+", text.strip()) if w)


def _rename_candidate(label: str, row: dict, c: dict) -> str | None:
    """条件唯一、数值/单位一致、辨识词不重叠时，返回原表参数名（含旧后缀）。

    这是**语义错名**的确定性收口，不是同义词润色：

    * 条件行必须高度一致（`RANGE pin, RANGE bit = 0`）；
    * 名字覆盖率必须低（`< 0.6`，否则本来就是同一个名字）；
    * 两边去掉通用词后的辨识词必须**不相交**（`Input Common-Mode Voltage`
      vs `Bipolar full-scale range` 不相交，才改名；`Power Consumption`
      vs `Power Dissipation` 共享 `power`，不改）；
    * 原表参数名带数字/型号时不动（大写缩写不可靠，宁可不改）。
    """
    cond = str(row.get("condition") or "")
    if not cond or _cond_score(cond, str(c.get("cond") or "")) < 0.9:
        return None
    if _name_score(label, _cand_text(c), _cand_param(c)) >= 0.6:
        return None
    param = str(c.get("param") or "").strip()
    if not param or any(ch.isdigit() for ch in param):
        return None
    la = {w for w in _tokens(label) if w not in _LABEL_GENERIC}
    pa = {w for w in _tokens(param) if w not in _LABEL_GENERIC}
    if not la or not pa or (la & pa):
        return None
    m = re.search(r"\(([^()]*)\)\s*$", label)
    suffix = m.group(1).strip() if m else ""
    base = _title_param(param)
    new_label = f"{base} ({suffix})" if suffix else base
    return new_label if new_label.lower() != label.lower() else None


def _group_hit(label: str, want: set[str], cands: list[dict],
               row: dict) -> dict | None:
    """同一参数的**连续子行**合起来才覆盖全部数值时的锚定。

    `Input bandwidth -3dB range` 在原表是两行（`Low frequency 2.0` /
    `High frequency 6.3`），JSON 写成 `2 to 6.3`。单行永远凑不齐两个数，
    但「这个参数就印在这两行」是可以证明的。

    代价是**不能主张列角色**：两个值都在 TYP 列，JSON 的 `2 to 6.3` 是一个
    由两个典型值拼出来的范围，不是 MIN/MAX 规格。所以 `note` 里必须写清楚，
    页面侧才不会把它当成上下限。
    """
    groups: dict[tuple, list[dict]] = {}
    for c in cands:
        pname = str(c.get("param") or c.get("parameter") or "").strip().lower()
        if not pname:
            continue
        groups.setdefault((c.get("page"), re.sub(r"\s+", " ", pname)),
                          []).append(c)
    best: tuple[float, list[dict]] | None = None
    for members in groups.values():
        if not 2 <= len(members) <= 4:
            continue
        have: set[str] = set()
        for m in members:
            have |= _num_keys([m.get("min"), m.get("typ"), m.get("max")])
        if not want <= have:
            continue
        if not _unit_ok(str(row.get("unit") or ""),
                        str(members[0].get("unit") or "")):
            continue
        sc = _name_score(label, " ".join(_cand_text(m) for m in members),
                         " ".join(_cand_param(m) for m in members))
        if sc < 0.6:
            continue
        if best is None or sc > best[0]:
            best = (sc, members)
    if not best:
        return None
    members = best[1]
    shas = sorted(str(m.get("row_sha256") or "") for m in members)
    kinds = sorted({str(m.get("_kind") or "") for m in members})
    return {
        "_kind": "param_group",
        "param": str(members[0].get("param") or members[0].get("parameter") or ""),
        "cond": " / ".join(x for x in (str(m.get("cond") or m.get("conditions") or "")
                                       for m in members) if x),
        "min": "", "typ": "", "max": "",
        "unit": str(members[0].get("unit") or ""),
        "page": members[0].get("page"),
        "bbox": [min(m["bbox"][0] for m in members),
                 min(m["bbox"][1] for m in members),
                 max(m["bbox"][2] for m in members),
                 max(m["bbox"][3] for m in members)],
        "rows": shas,
        "row_sha256": hashlib.sha256("|".join(shas).encode("utf-8")).hexdigest(),
        "note": (f"同一参数的 {len(members)} 个子行合起来才覆盖全部数值"
                 f"（{'+'.join(kinds)}）；列角色未主张 —— 范围可能由多个 TYP 值拼成"),
    }


def fill_row_anchors(doc: dict, fitz_doc, max_pages: int = 40,
                     extra: list[dict] | None = None) -> dict:
    """给电气行做**行级锚定**：证明「这个值填在原表的这一行」。

    为什么不能停在「同页」：`facts_audit` 里 ADC 的 108 行只有 16 行
    `verified`，其余 92 行是 `value_on_label_page` —— 而 `Resolution` 这种
    参数名在 11 页里出现，`Supply` 在 48 页里出现，**同页几乎是必然的**，
    它证明不了任何事。ChatGPT 8.0 复审因此把「同页命中」判为无效证据。

    锚定要同时满足三条（缺一条就留在风险队列，不猜）：

    1. **数值全中**：JSON 行的每个数都能在候选行里找到（`2` 与 `2.0` 视为同值）。
    2. **参数名对得上**：标签实词在候选行文本里的覆盖率 ≥ 0.5（缩写按
       `_NAME_ALIASES` 展开，`ENOB` 能对上 `Effective number of bits`）。
    3. **单位不冲突**：两边都写了单位时必须一致。

    三路候选：`extract_spec_rows()`（有网格线的规格表）、`extract_roc_rows()`
    （ROC 的视觉行）、以及调用方传进来的 `extra`（通常是已经算好的
    `specs.ac_performance`）。第三路不是冗余：AC 续页的表格用 `find_tables()`
    会把 `Input bandwidth -3dB range` 的 MIN/MAX 拆成两条 TYP 行，
    单条永远凑不齐 `2 to 6.3`，而 AC 抽取器按列带重切后是对的。

    同分不裁决 —— 记进 `ambiguous`，保持原状。唯一的例外是候选之间
    **取值完全相同**（同一行在同一页被两张表各列一次），此时取先出现的那条，
    记 `tie_identical`：没有数值或文本差异，选哪条证据都等价。

    命中后写 `source.bbox` / `source.row_sha256`（复核方可翻到那一格），
    状态升 `audited_row_anchored`。找不到行但**同页共现**的行降为
    `label_value_same_page`：页面打 † 并悬浮说明「同页出现，行/列对应待人工确认」。
    """
    specs = doc.setdefault("specs", {})
    # 页面上会出现的正式容器：主表 + 两个隔离桶。板卡件的电气/绝对最大行
    # 被合同层整锅搬进 `onboard_device_specs` 后，旧实现只看主表，18 条
    # 行（ADS8568EVM-PDK）永远拿不到锚定机会（1102-V3 实测）。
    rows: list[dict] = []
    for _c in ("electrical", "absolute_max"):
        for _r in specs.get(_c) or []:
            if isinstance(_r, dict):
                rows.append(_r)
    for _b in ("onboard_device_specs", "unresolved_specs"):
        _box = specs.get(_b)
        if not isinstance(_box, dict):
            continue
        for _c in ("electrical", "absolute_max"):
            for _r in _box.get(_c) or []:
                if isinstance(_r, dict):
                    rows.append(_r)
    if not rows:
        return {}

    # 1) 候选页：参数名的**任一实词**与数值同页出现。只在这些页跑表格识别 ——
    #    `find_tables()` 一页约 1.4 秒，40 页全跑会把五件拖到 SIGTERM。
    #
    #    为什么是"任一实词"而不是最长词：原表用词与 JSON 标签经常不同，
    #    `Analog Input Frequency Range (-3dB)` 在原页印的是
    #    `Input bandwidth -3dB range` —— 一个 `Frequency` 都没有。按最长词
    #    收窄会把这一页直接排除，那 2 to 6.3 GHz 永远锚不上（实测）。
    #    放宽只是多花几秒，错杀是永久丢一条证据。
    pages = _norm_pages(fitz_doc, list(range(min(fitz_doc.page_count, max_pages))))
    want_pages: set[int] = set()
    for row in rows:
        nums = _row_value_nums(row)
        words = [w.lower() for w in re.split(r"[^A-Za-z0-9]+",
                                             str(row.get("name") or ""))
                 if len(w) >= 4]
        if not nums or not words:
            continue
        wpat = [re.compile(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])")
                for w in words]
        # `_num_keys()` 已把 `2.0` 归一成 `2`，所以这里直接按数边界找即可：
        # `(?<![\d.])2(?![\d])` 能命中 `2.0`（小数点不是数字），不会命中 `20`。
        npat = [re.compile(r"(?<![\d.])" + re.escape(t) + r"(?![\d])") for t in nums]
        for pno, txt in pages:
            low = txt.lower()
            if all(p.search(txt) for p in npat) and any(p.search(low) for p in wpat):
                want_pages.add(pno)

    cands: list[dict] = []
    used: list[int] = []
    for pno in sorted(want_pages):
        page = fitz_doc[pno - 1]
        # 引脚表页不可能是规格表，跳过能省 ~1.4 秒/页（ADC 有 5 页这种）
        try:
            ptxt = (page.get_text() or "")[:4000].lower()
        except Exception:                                      # noqa: BLE001
            ptxt = ""
        if any(k in ptxt for k in PIN_PAGE_KEYS) and "MIN" not in ptxt:
            continue
        got: list[dict] = []
        try:
            got = extract_spec_rows(page)
        except Exception:                                      # noqa: BLE001
            got = []
        try:
            roc = extract_roc_rows(page)
        except Exception:                                      # noqa: BLE001
            roc = []
        for r in got:
            r["_kind"] = "spec_row"
        for r in roc:
            r["_kind"] = "roc_row"
        if got or roc:
            used.append(pno)
        cands.extend(got)
        cands.extend(roc)
    for r in extra or []:
        if isinstance(r, dict) and r.get("min") is not None:
            cands.append({**r, "_kind": "ac_row"})
    if not cands:
        return {}

    anchored = ambiguous = same_page = 0
    ambiguous_rows: list[str] = []
    for row in rows:
        label = str(row.get("name") or "")
        ver = row.get("verification") or {}
        status = str(ver.get("status") or "").strip().lower()
        if status.startswith("audited"):
            anchored += 1
            continue
        want = _row_value_nums(row)
        hit = None
        tied = False
        rename_to = ""
        if want:
            scored: list[tuple[float, int, float, dict]] = []
            renamed: list[tuple[float, str, dict]] = []
            for c in cands:
                have = _num_keys([c.get("min"), c.get("typ"), c.get("max")])
                if not want <= have:
                    continue
                # ROC 里「只有中间列有值」的行只认单值对单值：那种行的
                # MIN/MAX 从未被证明，拿它去证一个范围是拿假设当证据。
                if c.get("roles") == "nom_only" and not (len(want) == 1
                                                         and len(have) == 1):
                    continue
                if not _unit_ok(str(row.get("unit") or ""), str(c.get("unit") or "")):
                    continue
                sc = _name_score(label, _cand_text(c), _cand_param(c))
                if sc < 0.6:
                    # 名字对不上时，只剩一条合法出路：条件+数值+单位唯一，
                    # 且辨识词与原表参数名不重叠 —— 按原表改名，不猜同义词。
                    _new = _rename_candidate(label, row, c)
                    if _new:
                        renamed.append((_cond_score(
                            str(row.get("condition") or ""),
                            str(c.get("cond") or "")), _new, c))
                    continue
                # 数值恰好相等（不多不少）优先于超集：`5 to 50 pA` 不该被
                # `5 / 50 / 1 nA` 那种合并行抢走。同分再比条件行。
                exact = 1 if have == want else 0
                scored.append((sc, exact, _cond_score(
                    str(row.get("condition") or ""), str(c.get("cond") or "")), c))
            if scored:
                top = max((s, e, cs) for s, e, cs, _ in scored)
                best = [c for s, e, cs, c in scored if (s, e, cs) == top]
                if len(best) == 1:
                    hit = best[0]
                else:
                    # 同分且**取值完全一样**（同一行在同一页出现两次，
                    # 如 DC/AC 两张表都列了 `Resolution 12 Bits`）：
                    # 取先出现的那条，记 `tie_identical`。这不是猜 ——
                    # 候选之间没有任何数值或文本差异，选哪条证据都等价。
                    # 比较键要归一：`Bits` 与 `bits`、`12` 与 `12.0` 是同一个值。
                    keys = {(frozenset(_num_keys([c.get("min"), c.get("typ"),
                                                  c.get("max")])),
                             str(c.get("unit") or "").strip().lower())
                            for c in best}
                    if len(keys) == 1:
                        hit = sorted(best, key=lambda c: (c["page"],
                                                          c.get("bbox")[1]))[0]
                        tied = "identical"
                    else:
                        tied = True
                        ambiguous_rows.append(label[:50])
            if hit is None and not tied and len(want) >= 2:
                # 单行覆盖不了全部数值时，退一步看**同一参数的连续子行**：
                # `Input bandwidth -3dB range` 在 p17 是两行
                # （Low frequency 2.0 / High frequency 6.3），JSON 写成
                # `2 to 6.3`。两行合起来才是这一个参数，行身份仍然确定 ——
                # 但**列角色不成立**（两个值都在 TYP 列），所以要记下来。
                hit = _group_hit(label, want, cands, row)
            if hit is None and not tied and renamed:
                _top = max(r[0] for r in renamed)
                _best = [(nl, c) for cs, nl, c in renamed if cs == _top]
                if len(_best) == 1 and _top >= 0.9:
                    rename_to, hit = _best[0]
        if hit is not None:
            if rename_to:
                row["name"] = rename_to
            row["source"] = {
                "page": hit["page"], "bbox": hit["bbox"],
                "row_sha256": hit["row_sha256"],
                "quote": " | ".join(x for x in (hit.get("param"), hit.get("cond"),
                                                hit.get("min"), hit.get("typ"),
                                                hit.get("max"), hit.get("unit")) if x),
            }
            if hit.get("rows"):
                # 多子行锚定：把成员指纹也写下来，复核方可以逐行翻
                row["source"]["rows"] = hit["rows"]
            if rename_to:
                row["source"]["label_original"] = label
            ver = row.setdefault("verification", {})
            ver.update({"status": "audited_row_anchored",
                        "method": hit["_kind"], "page": hit["page"],
                        "bbox": hit["bbox"],
                        "matched_by": f"name+value({hit['_kind']})"
                                      + ("+tie_identical" if tied == "identical" else "")})
            if rename_to:
                ver["label_note"] = f"按原表参数名改名：{label} → {rename_to}"
            if hit.get("note"):
                ver["note"] = hit["note"]
            ver.pop("reason", None)
            anchored += 1
            continue
        if tied:
            ambiguous += 1
            continue
        # 找不到行：如果参数名与数值**同页**共现，降级为显式的弱证据，
        # 让页面能打出带说明的 †，而不是继续挂着 `unresolved` 冒充"没查"。
        if status in _UPGRADABLE and (row.get("source") or {}).get("page"):
            ver = row.setdefault("verification", {})
            ver["status"] = "label_value_same_page"
            ver["reason"] = "same_page_only"
            same_page += 1

    return {"pages": used, "candidates": len(cands), "anchored": anchored,
            "ambiguous": ambiguous, "same_page": same_page,
            "ambiguous_rows": ambiguous_rows[:8], "rows": len(rows)}


# ---------------------------------------------------------------- VCMI / VID
def extract_input_limits(fitz_doc) -> list[dict]:
    """从 ROC 文本层抽 `Input common-mode voltage` / `Input voltage, peak-to-peak differential`。

    Reviewer 的 P0-1：VCMI 被写成 `0.3 to 0.55`（下限被抬高）、VID 写成 `1.0 to 2.0`。
    真值在 Rev. C §5.3 ROC 里是逐格明确的（MIN 0 / NOM 0.3 / MAX 0.55），
    属**已知确定值**，不必依赖模型重解析。

    做法：定位参数名行 → 在后续行里找「条件行 + 连续 3 个数值」的三元组。
    ROC 的每个子条件都是 `条件文本 … MIN NOM MAX`，所以三元组边界是可靠的。
    """
    out: list[dict] = []
    for page in fitz_doc:
        ls = _lines(page)
        for key, disp in (("input common-mode voltage", "Input Common-Mode Voltage"),
                          ("input voltage, peak-to-peak differential", "Input Differential Voltage")):
            k = next((i for i, x in enumerate(ls) if x.lower().startswith(key)), -1)
            if k < 0:
                continue
            unit = "VPP-DIFF" if "differential" in key else "V"
            cond: list[str] = []
            nums: list[str] = []
            for j in range(k + 1, min(k + 16, len(ls))):
                s = ls[j]
                if _is_num(s):
                    nums.append(s)
                    if len(nums) == 3:
                        out.extend(_rows_for(disp, cond, nums, unit,
                                             split=("common-mode" in key)))
                        cond, nums = [], []
                    continue
                if nums:                       # 数值被打断 → 这一组不完整，丢弃重来
                    cond, nums = [], []
                if _is_unit(s):
                    continue
                if _looks_like_symbol(s) and cond:
                    break                      # 到下一个参数了
                # 换了一个引脚组就重置条件：`INA, INB / ac coupled` 这一段在
                # ROC 里是**空格子**（没有 MIN/NOM/MAX），不能把它和后面
                # CLK/SYSREF 那一行的条件拼在一起。
                # 但 `CLK+ to CLK–, SYSREF+ to SYSREF–,` 以逗号结尾，说明同一
                # 条件还没写完（VID 就是这种跨行写法），不能重置。
                if (FAM_RE.search(s) and any(FAM_RE.search(c) for c in cond)
                        and not cond[-1].rstrip().endswith(",")):
                    cond = []
                cond.append(s)
    return out


FAM_RE = re.compile(r"\b(CLK|SYSREF|TMSTP|INA|INB)\b")


def _rows_for(disp: str, cond: list[str], nums: list[str], unit: str,
              split: bool) -> list[dict]:
    """一个数值三元组 → 一或多条 electrical 行。

    `split=True`（只用于 VCMI）：TI 把 `CLK+, CLK–, SYSREF+, SYSREF–` 写在
    同一个格子里、共用一组 MIN/NOM/MAX。页面上按引脚族各出一条更好读，
    而且**不会改变任何数值** —— 是同一组值的确定性展开，不是推测。
    """
    cond_txt = re.sub(r",\s*,+", ",", ", ".join(c for c in cond if not _is_unit(c))).strip(" ,")
    base = {"value": f"{nums[0]} to {nums[2]}", "unit": unit,
            "min": nums[0], "typ": nums[1], "max": nums[2]}
    fams = _families(cond) if split else []
    if len(fams) <= 1:
        name = f"{disp} ({_pin_group(cond)})" if _pin_group(cond) else disp
        return [{**base, "name": name, "condition": cond_txt}]
    rows = []
    for fam in fams:
        label = fam if fam in ("INA", "INB") else f"{fam}±"
        rows.append({**base, "name": f"{disp} ({label})",
                     "condition": f"{cond_txt}, {label}"})
    return rows


def _families(cond: list[str]) -> list[str]:
    """条件里出现的引脚族（去重保序）：`CLK+, CLK–, SYSREF+, SYSREF–` → CLK, SYSREF。"""
    seen: list[str] = []
    for c in cond:
        for m in FAM_RE.finditer(c):
            if m.group(1) not in seen:
                seen.append(m.group(1))
    return seen


def _pin_group(cond: list[str]) -> str:
    """从条件行里挑出引脚组名。

    单一引脚族 → 归一成 `CLK±` / `SYSREF±` / `TMSTP±`（与页面上其它行的写法一致）；
    多族或识别不出时退回原文片段。
    """
    fams = _families(cond)
    if len(fams) == 1:
        return fams[0] if fams[0] in ("INA", "INB") else f"{fams[0]}±"
    for c in cond:
        if FAM_RE.search(c):
            return re.sub(r"\(\d\)|,", "", c).strip()[:40]
    return ""


def _looks_like_symbol(s: str) -> bool:
    """ROC 的参数符号列：`VID` / `VDD` / `TA` / `PIN` 这类全大写短串。"""
    return bool(re.fullmatch(r"[A-Z][A-Z0-9_()]{1,9}", s or ""))


# ---------------------------------------------------------------- 汇总 + 校验
def is_bga_doc(doc: dict) -> bool:
    """封装是不是球阵列。判据只取 `specs.package.type`，与 symbol_svg 同源。"""
    try:
        from qc.pin_repair import is_bga                            # noqa: PLC0415
    except Exception:                                               # noqa: BLE001
        return False
    pkg = (doc.get("specs") or {}).get("package") or {}
    return bool(is_bga(str(pkg.get("type") or "")))


# ---------------------------------------------------------------- 角色列（MIN/TYP/MAX）
#: `a to b` 形态。**只认 `to`**：单格区间值（`VS = 3 to 36 V`）也是这形态，
#: 所以命中后必须回原文核对（原文原样印着这段就豁免，不是塌缩）。
_ROLE_RANGE_RE = re.compile(r"^([±+\-]?\d+(?:\.\d+)?)\s+to\s+([±+\-]?\d+(?:\.\d+)?)$", re.I)

_ROLE_LABEL = {"min": "MIN", "typ": "TYP", "max": "MAX"}

#: 纯数值单元格（`8.8` / `±10` / `–40`）。**必须整串匹配**：`0.7AVDD`、
#: `See Table 1` 这类公式/引用不是「这一列的值」，按数字截取会造出假规格。
_ROLE_NUM_RE = re.compile(r"^[±+\-]?\d+(?:\.\d+)?$")


def _role_num(s) -> float | None:
    t = str(s or "").strip().translate(_DASHES).replace("±", "+")
    if not _ROLE_NUM_RE.match(t):
        return None
    try:
        return float(t)
    except ValueError:
        return None


def _range_pair(value) -> tuple[float, float] | None:
    m = _ROLE_RANGE_RE.match(str(value or "").strip())
    if not m:
        return None
    a, b = _role_num(m.group(1)), _role_num(m.group(2))
    if a is None or b is None:
        return None
    return float(a), float(b)


def role_index(fitz_doc, max_pages: int = 40) -> tuple[dict, str]:
    """按单位索引表头角色值：``{unit: [{page, min, typ, max}]}`` + 归一化全文。

    只借 `extract_spec_rows()` 的**行分组与单位**，角色归属则用**表头词的 x 坐标**
    重判一遍：抽取器按列带（find_tables 的 bands）认角色，列带与表头文字错位时
    会把 `MIN` 列的值判成 `TYP`（NE555 p5 的 `THRES current` 实测：30 落在
    x=431，表头 MIN 在 428，却被判成 TYP）。按值词到表头词中心的最近距离判，
    不依赖网格线，错位时也不会跟着错。
    """
    idx: dict[str, list[dict]] = {}
    texts: list[str] = []
    for i in range(min(max_pages, len(fitz_doc))):
        page = fitz_doc[i]
        texts.append(re.sub(r"\s+", " ", page.get_text()))
        role_x = _page_role_x(page)
        try:
            rows = extract_spec_rows(page)
        except Exception:                                   # noqa: BLE001
            rows = []
        for r in rows:
            unit = _clean_unit(str(r.get("unit") or ""))
            vals = {}
            for role in ("min", "typ", "max"):
                n = _role_num(r.get(role))
                if n is not None:
                    vals[role] = float(n)
            if not unit or not vals:
                continue
            if role_x:
                vals = _relabel_by_x(page, r, vals, role_x) or vals
            idx.setdefault(unit, []).append({"page": i + 1, **vals})
    return idx, " ".join(texts)


def _page_role_x(page) -> list[tuple[str, float]]:
    """表头行里各角色词的 x 中心：``[("MIN", 431.0), ("TYP", 464.0), …]``。

    判据：同一 y 行上至少出现两个角色词（MIN/TYP/MAX），才认作表头。
    表头可能被列边界劈开（`MA` + `X`），此时拼同 y 的词再认。
    """
    by_y: dict[float, list] = {}
    for w in page.get_text("words"):
        by_y.setdefault(round(w[1], 1), []).append(w)
    for _y, ws in sorted(by_y.items()):
        labels: dict[str, float] = {}
        for w in ws:
            t = str(w[4]).strip().upper()
            for role in ("MIN", "TYP", "MAX", "UNIT"):
                if t == role:
                    labels.setdefault(role, (w[0] + w[2]) / 2.0)
        # 被劈开的 `MA` + `X`：把相邻两个词拼起来再认一次
        for a, b in zip(ws, ws[1:]):
            joined = (str(a[4]) + str(b[4])).upper()
            for role in ("MIN", "TYP", "MAX"):
                if joined == role and role not in labels:
                    labels[role] = (a[0] + b[2]) / 2.0
        if sum(1 for k in ("MIN", "TYP", "MAX") if k in labels) >= 2:
            return sorted(((k.lower(), v) for k, v in labels.items() if k != "UNIT"),
                          key=lambda kv: kv[1])
    return []


def _relabel_by_x(page, row: dict, vals: dict, role_x) -> dict:
    """按值词 x 到表头角色中心的距离重判角色；判不出就原样返回。"""
    bbox = row.get("bbox") or []
    if len(bbox) != 4:
        return vals
    y0, y1 = bbox[1] - 2, bbox[3] + 2
    words = [w for w in page.get_text("words")
             if y0 <= (w[1] + w[3]) / 2 <= y1]
    out: dict[str, float] = {}
    for role, v in vals.items():
        best = None
        for w in words:
            if _role_num(w[4]) != v:
                continue
            xc = (w[0] + w[2]) / 2.0
            for r2, x2 in role_x:
                d = abs(xc - x2)
                if best is None or d < best[0]:
                    best = (d, r2)
        if best is None or best[0] > 30:
            return vals
        if best[1] in out:
            return vals                       # 两个值判到同一列 → 不可信
        out[best[1]] = v
    return out


def _role_row_for(idx: dict, unit: str, a: float, b: float) -> dict | None:
    """找出同时含 ``a`` 与 ``b``、且两者落在**不同角色**的那一行。"""
    best = None
    for row in idx.get(unit) or []:
        roles = {k: v for k, v in row.items() if k in _ROLE_LABEL}
        ra = [k for k, v in roles.items() if abs(v - a) < 1e-9]
        rb = [k for k, v in roles.items() if abs(v - b) < 1e-9]
        if ra and rb and ra[0] != rb[0] and (best is None or len(roles) > len(best)):
            best = row
    return best


def _has_role(cond: str) -> bool:
    return any(re.search(rf"(?<![A-Z]){lab}(?![A-Z])", str(cond or ""))
               for lab in ("MIN", "TYP", "MAX"))


def _with_role(cond: str, role: str) -> str:
    lab = _ROLE_LABEL[role]
    if re.search(rf"(?<![A-Z]){lab}(?![A-Z])", str(cond or "")):
        return str(cond or "")
    return "; ".join(x for x in (str(cond or "").strip(), lab) if x)


def _num_text(v: float) -> str:
    return "%d" % int(v) if abs(v - int(v)) < 1e-9 else "%g" % v


def _single_role_label(idx: dict, unit: str, v: float) -> str | None:
    """单值行该标哪个角色：原文里所有含该值的行**必须指向同一角色**。

    只有一条值时，模型常把 `TYP` 列的值写成无角色（GH-18 的 2.5 V）。
    这里按原文反查：把「含这个值、且该值只落在一列」的行全找出来，
    角色必须唯一 —— 同一数值在不同行分属不同列时（如 2.5 既是 MIN 又是 TYP），
    不猜，返回 ``None``。宁可缺标注，也不给错标注。
    """
    roles = set()
    hits = 0
    for row in idx.get(unit) or []:
        where = [k for k in _ROLE_LABEL if abs(row.get(k, 1e18) - v) < 1e-9]
        if len(where) == 1:
            hits += 1
            roles.add(where[0])
    if hits and hits <= 3 and len(roles) == 1:
        return roles.pop()
    return None


def split_role_rows(doc: dict, fitz_doc, max_pages: int = 40) -> dict:
    """把 `MIN to MAX` 连写的电气行按原表角色拆成多行。

    为什么必须做：`8.8 to 11.2 V` 会被读成「区间内任意值都合规」，而原文
    8.8 是 MIN、11.2 是 MAX（中间值根本不是原厂保证的规格）。GH-15 的
    THRES voltage level、GH-18 的 Dynamic range / Common-mode 都是这个形态。

    判据与 `table_audit.audit_role_collapse()` 同源，但这里是**修**：
      * 值形如 `a to b`；
      * PDF 里能找到一个行，`a` 与 `b` 落在**不同**角色列；
      * 原文**没有**原样印着这段区间（单格区间值豁免，不许拆）。
    命中就按 `min/typ/max` 逐个出条，`condition` 末尾补角色词。
    """
    sp = doc.get("specs") or {}
    rows = sp.get("electrical") or []
    if not any(_range_pair(r.get("value")) for r in rows):
        return {}
    try:
        idx, blob = role_index(fitz_doc, max_pages)
    except Exception:                                       # noqa: BLE001
        return {}
    out: list[dict] = []
    split = 0
    labeled = 0
    for r in rows:
        rp = _range_pair(r.get("value"))
        unit = _clean_unit(str(r.get("unit") or ""))
        base = str(r.get("condition") or "")
        if not rp:
            # 单值行：模型常把 TYP 列的值写成无角色（GH-18 的 2.5 V）。
            # 原文反查唯一的角色时才、且仅当角色唯一时补上 —— 不猜。
            n = _role_num(r.get("value"))
            if n is not None and not _has_role(base):
                role = _single_role_label(idx, unit, n)
                if role:
                    out.append({**r, "condition": _with_role(base, role)})
                    labeled += 1
                    continue
            out.append(r)
            continue
        a, b = rp
        if a == b:
            # `120 to 120`：区间退化成单值（模型把同一格的 TYP 抄了两遍）。
            # 只在这一值在原文里只出现过**一个角色**时收成一行，否则不动。
            roles = {k for row in idx.get(unit) or []
                     for k, v in row.items() if k in _ROLE_LABEL and abs(v - a) < 1e-9}
            if len(roles) == 1:
                out.append({**r, "value": _num_text(a),
                            "condition": _with_role(base, roles.pop())})
                split += 1
            else:
                out.append(r)
            continue
        cand = _role_row_for(idx, unit, a, b)
        if not cand or str(r.get("value") or "").strip() in blob:
            out.append(r)
            continue
        emitted = 0
        for role in ("min", "typ", "max"):
            if role not in cand:
                continue
            out.append({**r, "value": _num_text(cand[role]),
                        "condition": _with_role(base, role)})
            emitted += 1
        if emitted:
            split += 1
        else:
            out.append(r)
    if not split and not labeled:
        return {}
    sp["electrical"] = out
    rep = {}
    if split:
        rep["role_split"] = split
        rep["role_split_rows"] = len(out)
    if labeled:
        rep["role_labeled"] = labeled
    return rep


#: 这些脚名在真实器件上**天然允许多脚同名**（多 GND / 多 NC / 裸焊盘），
#: 出现重复不构成「模型多编了一脚」的证据。LM317 的 `OUTPUT` 出现两次
#: 不在这个集合里 —— 那才是 D4 要抓的东西。
_REPEATABLE_PIN_NAMES = frozenset({
    "GND", "AGND", "DGND", "PGND", "SGND", "VSS", "AVSS", "DVSS", "VCC", "AVCC",
    "DVCC", "VDD", "AVDD", "DVDD", "PVDD", "VDDA", "VSSA", "NC", "N.C.", "N/C",
    "DNC", "D.N.C", "EP", "PAD", "EPAD", "THERMAL", "THERMALPAD", "THERMAL PAD",
    "SUB", "SUBSTRATE", "VREF", "REFIN", "REFOUT", "VBIAS", "BIAS",
})

#: 电源/地**族**：`AVDD3V` / `DRVDD` / `IOVDD` / `VSSA` / `DGND` …
#:
#: 为什么不能只枚举（2026-11-04 V3 重审计实测）：ADS42JB49SEK 的 `DRVDD`
#: 有 4 个球、`AVDD3V` 有 2 个球，ADS1675REF 的 `VREFP`/`VREFN` 各 2 个球 ——
#: 全是原厂布法。按名字逐个枚举永远漏，漏一次就把正常芯片判成 `failed`。
#: 前缀限 0-3 个字母（`A`/`D`/`DR`/`IO`/`PV`），后缀限 `[0-9A-Z]*`（`3V`/`A`/`Q`）。
_RAIL_NAME_RE = re.compile(r"^[A-Z]{0,3}(?:VDD|VCC|VSS|VEE|GND)[0-9A-Z]*$")

#: 参考电压族：`VREFP` / `VREFN` / `REFIN` / `REFOUT` / `VREFH` / `VREFL`。
_VREF_NAME_RE = re.compile(r"^V?REF(?:IN|OUT|P|N|H|L)?[0-9A-Z]*$")

#: 未连接 / 保留脚：原厂常把多个球都标成同一个 `NC`。
_NC_NAME_RE = re.compile(r"^(?:NC|DNC|DNU|N\.C\.|N/C|NU|RESERVED|RSVD)$")


def _is_repeatable_pin_name(key: str) -> bool:
    """这个脚名出现多次是否**硬件上说得通**（= 不构成「模型多编」的证据）。

    刻意**不放行**的（放行就等于把抽取错误洗成合法重复）：

    * 差分对合并名 `DA1P/M`：ADS42JB49SEK 的 51/52 两脚都叫这个名字，真实
      应为 `DA1P` / `DA1M` —— 这是模型把两脚写成一行的缺陷，必须判 failed；
    * 单组 SPI 的 `SCLK` / `DOUT` / `DRDY` 重复：单通道器件不该有两根时钟，
      重复即多编。多通道器件的同名脚归人工裁决，不靠白名单自动放行。
    """
    if key in _REPEATABLE_PIN_NAMES:
        return True
    return bool(_RAIL_NAME_RE.match(key) or _VREF_NAME_RE.match(key)
                or _NC_NAME_RE.match(key))


def _pin_name_key(v) -> str:
    """脚名的重复判定键：大写、去空白、各种破折号统一成 `-`。"""
    s = re.sub(r"\s+", "", str(v or "")).upper()
    return (s.replace("–", "-").replace("—", "-").replace("−", "-")
             .replace("‒", "-").replace("_", "-"))


def _pins_complete(rows: list) -> bool:
    """脚号是否为完整连续的 1..N（D4 前它就是唯一判据，现在只是三分之一）。"""
    nums = []
    for r in rows:
        s = str((r or {}).get("pin") or "").strip()
        if not s.isdigit():
            return False
        v = int(s)
        if v > 0:
            nums.append(v)
    return bool(nums) and sorted(nums) == list(range(1, max(nums) + 1))


def _pin_gate(existing: list, det_pins: list) -> dict:
    """D4：模型稿引脚要不要被确定性结果整体替换的判据（纯函数，好测）。

    旧判据 `_pins_complete` 只回答「编号有没有缺」，于是模型**多编**的脚
    （编号照旧连续）能原样入库 —— LM317 服务器复跑实测：模型给了
    `1 ADJUST / 2 OUTPUT / 3 INPUT / 4 OUTPUT`，四条全过，`kept=4`。

    现在要同时过三关：

    1. **编号连续**（旧判据，保留）；
    2. **重名**：同一封装下，`GND/NC/EP…` 之外的名字出现两次即有多编嫌疑；
    3. **总数**：确定性侧抽到的脚数（`det_pins`）与模型侧不同即记
       `count_mismatch`（只留痕，不单独作为替换理由 —— 确定性抽取同样可能
       漏抽，G2 就是这么炸出来的；总数谁对谁错，编号与重名证据说了算）。

    **替换**的条件：确定性侧非空、编号完整、存在「重名嫌疑脚」，且它的数量
    足以解释模型侧多出来的行（`len(det) >= len(existing) - dup_extra`）——
    即「模型比 PDF 多出来的每一行，恰好都能由重复名背书」。缺这一条，
    确定性侧自己漏抽时也会整体覆盖干净数据（G2 修的是漏脚方向，别把两头修串）。
    """
    existing = [r for r in (existing or []) if isinstance(r, dict)]
    det_pins = [p for p in (det_pins or []) if isinstance(p, dict)]
    n_model, n_det = len(existing), len(det_pins)
    counts: dict[str, int] = {}
    for r in existing:
        k = _pin_name_key(r.get("name"))
        if k:
            counts[k] = counts.get(k, 0) + 1
    dup_names = sorted({k for k, c in counts.items()
                        if c > 1 and not _is_repeatable_pin_name(k)})
    dup_extra = sum(counts[k] - 1 for k in dup_names)
    complete = _pins_complete(existing)
    count_mismatch = bool(n_model and n_det and n_model != n_det)
    info = {
        "replace": False,
        "reason": "model_pins_complete",
        "dup_names": dup_names,
        "count_mismatch": count_mismatch,
        "model_n": n_model,
        "det_n": n_det,
    }
    if not existing:
        return info
    if not complete:
        info["reason"] = "model_pins_incomplete_numbering"
        info["replace"] = bool(det_pins)         # 乱号/缺号，确定性结果非空即替换
        return info
    if dup_names and det_pins and _pins_complete(det_pins) \
            and n_det >= n_model - dup_extra:
        # 编号连续但重名：多出来的行有重复名背书，且确定性侧能对上账。
        info["reason"] = "model_pins_duplicate_name"
        info["replace"] = True
        return info
    if count_mismatch:
        # 编号连续、无重名、只是总数对不上：不换数据（G2 的教训是确定性侧
        # 也会漏），但必须留痕，不能让「数量可疑」静默通过。
        info["reason"] = "model_pins_count_mismatch"
    return info


#: D4 硬闸的可信脚数来源名（Reviewer 契约的 `source` 字段固定值）。
PIN_COUNT_SOURCE = "datasheet_package_pin_table"


def pin_field_validation(rows: list, expected_counts: dict | None = None) -> dict:
    """D4 硬闸（Reviewer 2026-11-04 裁决契约）：PIN **字段级**验证状态。

    与 `_pin_gate` 的分工：`_pin_gate` 回答「模型稿要不要被确定性结果替换」
    （数据层，修错）；本函数回答「最终入库的引脚集能不能冒称已验证」（状态层，
    签核）。判定顺序按裁决表，先查结构性错误，再对账脚数：

    1. 脚号重复 → failed / `duplicate_pin_number`；
    2. 脚号不连续（缺号/跳号/非数字）→ failed / `incomplete_numbering`
       （本项目没有「原厂编号规则证据」的通道，一律 fail-closed）；
    3. 脚名重复且不在 `_REPEATABLE_PIN_NAMES` 白名单 → failed /
       `duplicate_pin_name`；
    4. 可信封装脚数**唯一**且对不上 → failed / `count_mismatch`
       （契约原例：expected 3 / actual 4）；
    5. 无可信预期脚数（没有热阻封装表），或**多封装脚数不唯一**
       （LM317 的 DCY=4 / KCS=3，LM358 的 8 脚群里混着 FK(LCCC)=20）→
       unverified / `count_unverified` —— 不猜是哪个封装，绝不冒称通过；
    6. 多封装脚数不唯一且一个都对不上 → failed / `count_mismatch`
       （expected_count 留空、expected_counts 全量留证，不挑一个冒充）；
    7. 球位编号（A1/M12）走另一套编号规则，核验属于 `pin_repair` 的
       球位映射，这里只隔离不判死 → unverified / `ball_numbering`。

    状态域固定 ``passed / failed / unverified``（Review 契约原文）；
    消费端（`engineering_model` 符号页、`delivery_bundle` 打包闸门）同时兼容
    BGA 老契约的 ``pass / fail / unresolved``。**failed 不阻断整份 JSON**：
    调用方保留原始数据，只把 PIN 字段隔离出「已验证」。
    """
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    pv: dict = {"status": "unverified", "actual_count": len(rows)}
    if not rows:
        pv["reason"] = "no_pins"
        return pv
    if any(BALL_RE.fullmatch(str(r.get("pin") or "")) for r in rows):
        pv["reason"] = "ball_numbering"
        return pv
    nums = [str(r.get("pin") or "").strip() for r in rows]
    if len(set(nums)) != len(nums):
        pv.update(status="failed", reason="duplicate_pin_number")
        return pv
    if not _pins_complete(rows):
        pv.update(status="failed", reason="incomplete_numbering")
        return pv
    counts: dict[str, int] = {}
    for r in rows:
        k = _pin_name_key(r.get("name"))
        if k:
            counts[k] = counts.get(k, 0) + 1
    dup = sorted({k for k, c in counts.items()
                  if c > 1 and not _is_repeatable_pin_name(k)})
    if dup:
        pv.update(status="failed", reason="duplicate_pin_name", dup_names=dup)
        return pv
    ex = {}
    for k, v in (expected_counts or {}).items():
        try:
            n = int(v)
        except (TypeError, ValueError):
            continue
        if n > 0:
            ex[str(k)] = n
    if not ex:
        # 没有可信预期脚数：不许冒称通过（裁决表第 5 行）。
        pv["reason"] = "count_unverified"
        return pv
    vals = set(ex.values())
    if len(vals) == 1:
        expected = vals.pop()
        pv["expected_count"] = expected
        pv["source"] = PIN_COUNT_SOURCE
        if expected != len(rows):
            pv.update(status="failed", reason="count_mismatch")
            return pv
        pv.update(status="passed", reason="all_checks_passed")
        return pv
    # 多封装脚数不唯一：能否对上任何一个，都只能说「无法唯一确认」。
    pv["expected_counts"] = ex
    if len(rows) in vals:
        pv["reason"] = "count_unverified"
        return pv
    # 一个都对不上：expected_count 无唯一可信值，显式置 None（键不缺席），
    # expected_counts 全量留证供人工复核。
    pv["expected_count"] = None
    pv.update(status="failed", reason="count_mismatch")
    return pv


def apply_pin_gate(doc: dict, fitz_doc) -> dict:
    """D4 引脚硬闸：确定性补全/纠错 + 写 `metadata.pin_validation`（**幂等**）。

    为什么单独成函数（2026-11-04）：装配期必须能重放这道闸。V3-CANDIDATE 的
    7 件冻结于闸门上线之前，包内 `metadata.pin_validation` **全部为空** ——
    只要这段逻辑只活在 `apply_deterministic`（解析期）里，补状态就只能靠
    「重新调一次 LLM」，而模型采样本身不稳定（§5.1），等于用不确定性去修
    确定性问题。`qc/stage_release.py` 在装配期调用本函数，包内状态才是真的。

    幂等：输入只有「PDF + 当前引脚集」。已被确定性结果替换过的文档再跑一次，
    `_pin_gate` 看到的是确定性稿（编号连续、无重名、总数一致）→ 不替换、
    只重算 `pin_validation`，结论与首次相同。

    BGA 不走这里（`is_bga_doc` 分支）：球位的权威是
    `qc/pin_repair.ball_pins_from_pdf()`，两套契约互不覆盖。
    """
    rep: dict = {}
    if is_bga_doc(doc):
        # BGA 球位的**唯一权威**是 `qc/pin_repair.ball_pins_from_pdf()`：它逐球带
        # `pdf_sha256 / page / page_base / table / row / bbox / scope /
        # subject_mpn / package_ball_count`，符号页的 `bga_pin_validation()`
        # 正是按这套契约 fail-closed 的。
        #
        # 本模块的 `extract_pins()` 走文本层，只数得出球号与描述，**没有 bbox、
        # 没有 subject_mpn**。写进去会让符号页判 `incomplete_pdf_source` +
        # `pdf_subject_mismatch` + `pdf_mapping_changed`，整页退化成「BGA 球位待核」
        # 占位页（V4 实测 59,789 B → 1,294 B，Reviewer 新-2）。
        # 宁可不碰 —— 球位交给 pin_repair，它同样是纯代码、同样可复现。
        rep = {"skipped": "bga_owned_by_pin_repair",
               "kept": len(doc.get("pin_configuration") or [])}
        return rep

    existing = list(doc.get("pin_configuration") or [])
    model_rows = [r for r in existing if isinstance(r, dict)]
    replaced = False

    pins = extract_pins(fitz_doc)
    # PDF 若是球位表（A1/M12…），无论模型给的序号多完整都要整体替换。
    ball_det = any(BALL_RE.fullmatch(str(p.get("pin") or "")) for p in pins)
    # G2：模型给的是连续序号也可能**少脚**（ADS42 33/64、LM358 2/8）。
    # 只要确定性结果比模型多，就必须补全；否则「连续序号完整」会把漏脚洗白。
    #
    # D4（2026-11-03）：「连续序号」洗白的还有**多脚**那一侧。
    # 服务器复跑 LM317 实测：模型给了 1..4，其中 4 是重复的 `OUTPUT`
    # （真实脚表是 3 脚），`_pins_complete` 判通过 → `kept=4`。
    # 只查编号连续，等于只查「有没有缺号」，不查「有没有多出来」。
    # 所以补全之外还要查**重名**与**总数**，判据统一收进 `_pin_gate()`。
    gate = _pin_gate(existing, pins)
    if pins and (ball_det or not existing or gate["replace"]
                 or len(pins) > len(existing)):
        old = len(existing)
        doc["pin_configuration"] = [
            {"pin": p["pin"], "name": p["name"], "description": p["description"],
             "source": {"page": p["page"], "method": "deterministic"}}
            for p in pins]
        replaced = True
        rep = {"from": old, "to": len(pins), "method": "deterministic",
               "why": gate["reason"]}
    elif existing:
        rep = {"skipped": gate["reason"], "kept": len(existing),
               "det_pins": len(pins),
               "dup_names": gate["dup_names"],
               "count_mismatch": gate["count_mismatch"]}

    def _pin_s(r: dict) -> str:
        v = r.get("pin")
        return "" if v is None else str(v).strip()

    # 脚号必须升序（下游 `pin[i].name` 以 i 为脚号，1 起）。
    # 只在**全部脚号都是数字**时排序，球位表（A1/M12）保持原序。
    rows = doc.get("pin_configuration") or []
    if rows and all(_pin_s(r).isdigit() for r in rows):
        ordered = sorted(enumerate(rows),
                         key=lambda kv: (0 if int(_pin_s(kv[1])) > 0 else 1,
                                         int(_pin_s(kv[1])), kv[0]))
        doc["pin_configuration"] = [r for _, r in ordered]
        rep["ordered"] = "numeric_asc"

    # D4 硬闸（Reviewer 2026-11-04 契约）：给**最终入库**的引脚集写
    # `metadata.pin_validation`。三红线：
    #   * expected 只认 datasheet 封装表（`expected_pin_counts`），
    #     不拿模型自抽数量对账；
    #   * failed / unverified 都不冒称通过，但**不清空数据**（字段级隔离，
    #     其他字段照常落盘）；
    #   * failed 时保留被替换前的模型原稿（`model_pins`）供人工复核。
    # BGA 文档不走这里（`is_bga_doc` 分支）：球位的 pin_validation 归
    # `pin_repair.repair_bga_pins`，两套契约互不覆盖。
    pv = pin_field_validation(doc.get("pin_configuration") or [],
                              expected_pin_counts(fitz_doc))
    pv["gate_reason"] = gate["reason"]
    pv["model_count"] = len(model_rows)
    # 确定性侧到底覆盖了多少脚：`passed` 只对账**总数**，不等于每个脚名都有
    # PDF 证据。CDC6C 实测 det=2 / model=4 仍判 passed（封装表四列全 4 脚），
    # 把这个差异显式落盘，签核人才能看见「过的是哪一道闸」。
    pv["det_count"] = len(pins)
    if pv["status"] == "failed" and replaced:
        pv["model_pins"] = [dict(r) for r in model_rows]
    doc.setdefault("metadata", {})["pin_validation"] = pv
    rep["pin_validation"] = {"status": pv["status"], "reason": pv.get("reason")}
    return rep


def apply_deterministic(doc: dict, fitz_doc) -> dict:
    """用确定性结果覆盖 LLM 的同名字段，返回改动摘要（写进 metadata 备查）。"""
    sp = doc.setdefault("specs", {})
    rep: dict = {}

    rep["pins"] = apply_pin_gate(doc, fitz_doc)

    for key, fn in (("thermal", extract_thermal), ("esd", extract_esd)):
        rows = fn(fitz_doc)
        if rows:
            old = len(sp.get(key) or [])
            sp[key] = rows
            rep[key] = {"from": old, "to": len(rows), "method": "deterministic"}

    # 角色列修复（GH-15 / GH-18）：LLM 会把 MIN 与 MAX 连写成 `a to b`
    # （qwen-flash 实测不遵守 Prompt 4h），这里按 PDF 表头角色拆回多行。
    rep.update(split_role_rows(doc, fitz_doc))

    limits = extract_input_limits(fitz_doc)
    if limits:
        rep["input_limits"] = _merge_input_limits(sp, limits)
    temp = fill_temperature(doc, fitz_doc)
    if temp:
        rep["temperature"] = temp
    rep["model_unverified"] = stamp_model_unverified(doc)
    return rep


#: 这两个容器里的行才需要逐行核验状态；`package` / `temperature` 是单值字段。
_VERIFY_CONTAINERS = ("electrical", "absolute_max")


def stamp_model_unverified(doc: dict) -> dict:
    """给**没有** `verification` 的电气/绝对最大行补 `model_unverified`。

    Reviewer V4 新-3 的要害不是"状态标错了"，而是"34 行根本没状态"：
    覆盖 23/23 → 4/38，页面 † 从有变无。而这 34 行恰恰是**模型抽的**、
    正是 §5.1 自曝"两次运行仍会漂"（`Power Consumption` 4.01 W ↔ 4 W）的那部分。
    最不稳定的部分核验状态最稀薄，是这轮最该修的一处倒挂。

    为什么不能靠重跑 `table_audit`：旧审计在融合列上定位不到行，会把确定性抽出的
    干净 VCMI 三条又标回 `condition_unverified` —— 用坏尺子量好布。

    所以这里只陈述一个**事实**：这一行不是确定性抽取产出的，是模型产出的。
    它不主张值错，只主张来源；把"该不该信"交回给读者。宁可比实际保守，也不静默。
    """
    n = 0
    sp = safe_dict(doc, "specs")
    # 主表 + 两个隔离桶都要打标（板卡件的电气行被合同层搬进隔离桶后，旧实现
    # 只看主表 → 那批行永远没有来源状态，渲染层只能留白）。
    # 注意 `_safe_dict` 只能调**一次**再引用：调两次会得到两个不同的空 dict，
    # 打标就打到临时对象上了。
    onboard = safe_dict(sp, "onboard_device_specs")
    unresolved = safe_dict(sp, "unresolved_specs")
    targets = [(sp, k) for k in _VERIFY_CONTAINERS] + \
              [(onboard, k) for k in _VERIFY_CONTAINERS] + \
              [(unresolved, k) for k in _VERIFY_CONTAINERS]
    for container, key in targets:
        for row in safe_list(container, key):
            if not isinstance(row, dict) or row.get("verification"):
                continue
            row["verification"] = {
                "status": "model_unverified",
                "reason": "模型抽取；未经过确定性抽取或逐格核验（见页面 † 说明）",
            }
            n += 1
    return {"stamped": n}


def _merge_input_limits(sp: dict, limits: list[dict]) -> dict:
    """把确定性 VCMI/VID 写回 electrical：先删掉同名旧行，再按引脚组插入。"""
    if not isinstance(sp, dict):
        return {"removed": 0, "added": 0, "method": "deterministic",
                "skipped": "specs_not_dict"}
    elec = safe_list(sp, "electrical")
    sp["electrical"] = elec
    removed = 0
    kept = []
    for e in elec:
        if not isinstance(e, dict):
            # 脏元素（模型把说明文字/布尔塞进数组）：下游 `e.get(...)` 会崩。
            # 这里**丢掉**它，而不是让它把确定性 VCMI/VID 写回一起拖死。
            continue
        nm = str(e.get("name") or "").lower()
        # 名字口径各家模型不一样（`Input Differential Voltage` /
        # `Input voltage, peak-to-peak differential`），按语义特征匹配，
        # 否则会留下一条旧行 + 一条新行并存。
        if ("common-mode voltage" in nm
                or ("differential" in nm and ("voltage" in nm or "peak-to-peak" in nm))):
            removed += 1
            continue
        kept.append(e)
    for x in limits:
        kept.append({
            "name": x["name"], "value": x["value"], "unit": x["unit"],
            "condition": x["condition"],
            "columns": {"min": x["min"], "typ": x["typ"], "max": x["max"]},
            "verification": {"status": "audited_deterministic",
                             "reason": "文本层逐格读取 MIN/NOM/MAX，未经模型"},
        })
    sp["electrical"] = kept
    return {"removed": removed, "added": len(limits), "method": "deterministic"}


def core_digest(doc: dict) -> dict:
    """核心字段指纹：客户复跑后可以直接比这几个 sha256，不必装本仓库的工具。

    口径与 `qc/determinism_check.py` 完全一致（同一套 `_canon` 规范序列化），
    否则「产物自带的指纹」和「闸门算的指纹」会互相打架。

    只有**代码抽出来的**四类进指纹：pins / thermal / esd / VCMI+VID。
    其余电气行是模型抽的，两次运行本就允许措辞不同，把它们算进去会让指纹
    永远对不上，反而失去意义。
    """
    import hashlib
    import json

    def dg(obj) -> str:
        s = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    # A20.1（2026-11-02）：**只加守卫，payload 结构一个字不动**。
    # 把 onboard/unresolved 行并进指纹会是行为变更，会让 V3.1 包的所有
    # `core_sha256`、`determinism_check`、HANDOFF 的「三次解析四个指纹全等」
    # 全部失效 —— 指纹只认「代码抽出来的四类」，模型行本来就不该进来。
    sp = safe_dict(doc, "specs")
    elec = dict_rows(sp, "electrical")
    core_elec = [e for e in elec
                 if "common-mode voltage" in str(e.get("name") or "").lower()
                 or ("differential" in str(e.get("name") or "").lower()
                     and "voltage" in str(e.get("name") or "").lower())]
    pins = safe_list(doc, "pin_configuration")
    out = {
        "pins": {"count": len(pins), "sha256": dg(pins)},
        "thermal": {"sha256": dg(sp.get("thermal"))},
        "esd": {"sha256": dg(sp.get("esd"))},
        "vcmi_vid": {"count": len(core_elec), "sha256": dg(core_elec)},
    }
    out["method"] = "qc/deterministic_extract.py::core_digest"
    return out


def check_core(doc: dict, extracted: dict | None = None,
               source_absent: frozenset | tuple = (),
               withheld: frozenset | tuple = ()) -> list[str]:
    """**通用**核心校验：与具体型号无关，只看结构完整性。

    这里刻意不再判 VCMI / VID 的具体数值。上一版把 ADC12DJ5200SE 的四条验收点
    写进了通用校验（`0 to 0.55` / `0.4 to 2.0` 硬编码），结果另外两件被误判失败：
    `ADS1201U-1/1K` 根本没有 VCMI/VID 行、`ADS8568EVM-PDK` 的 VCMI 是
    `-4 VREF to 4 VREF` 且属评估板。**型号级的验收点见 :func:`check_acceptance`。**

    `extracted` 传 `apply_deterministic()` 的返回（`metadata.deterministic_extract`）。
    有了它才能区分两件性质完全不同的事：

    * 「源文档里就没有热阻表」→ 不该判失败（`ADS1201` 实测：全篇只有 ESD 免责
      声明，没有任何 HBM/CDM 数值，也没有 thermal 表）；
    * 「抽到了却丢了」→ 必须判失败（V3 的真形态：schema 里没有容器）。

    不传 `extracted` 时退回严格口径（缺就报），供单元测试与老调用方使用。
    """
    errs: list[str] = []
    # 读的时候只用安全访问器；**不加类型校验**（那是 sanitize_doc 的职责，
    # 混进来会让「值对但容器脏」的件被误判成 core fail）。
    sp = safe_dict(doc, "specs")
    bi = safe_dict(doc, "basic_info")
    pins = dict_rows(doc, "pin_configuration")

    # 溯源链：页面必须能一键回到权威源。这条**先于**板卡豁免判 —— 板卡件正是
    # V4 丢链接的那两件（`identity_scope` 把 `datasheet_url` 搬到了
    # `device_datasheet_url`），豁免掉就等于放过 Reviewer 新-1。
    # 放在通用校验而不是 `ACCEPTANCE_SPECS`：它跟型号无关，五个件都得有；
    # 只登记 ADC12DJ5200SE 的话，另外四件仍能带着空链接出包。
    if not (str(bi.get("datasheet_url") or "").strip()
            or str(bi.get("device_datasheet_url") or "").strip()):
        errs.append("basic_info.datasheet_url 为空（溯源链断开，不得出包）")

    # 评估板/模块页本就没有本型号的引脚表与芯片级参数，不按芯片判
    is_board = str(bi.get("identity") or "") in ("evaluation_board", "reference_design",
                                                 "module", "board")
    if is_board:
        # 豁免的只是「本型号引脚表 / thermal / ESD」这几项，**不豁免 AC 列角色闸门**。
        # V9 实测：`ADS8568EVM-PDK`（identity=evaluation_board）的 SNR 行是
        # `min="73.9" / typ="" / max="dB"`（原表为 73 / 73.9 / dB，单位串占了 MAX 格），
        # 就因为这个 return 落在 2396 行之前，AC 闸门一次都没跑，脏数据直接流进渲染层。
        # 板卡的 AC 表恰恰是板载器件的芯片级参数 —— 最该过这道闸的正是它。
        errs.extend(check_ac_integrity(sp.get("ac_performance") or []))
        return errs

    if not pins:
        errs.append("pin_configuration 为空")
    else:
        ball = [p for p in pins if BALL_RE.fullmatch(str(p.get("pin") or ""))]
        if ball and len(ball) != len(pins):
            errs.append(f"pin 字段混用球位号与序号（球位 {len(ball)} / 共 {len(pins)}）")

    for key in ("thermal", "esd"):
        if sp.get(key):
            continue
        # 主动扣下（2026-11-03 列塌缩隔离）：容器空是**我们的决定**，不是
        # 「源文档没有」也不是「抽到了却丢了」。三种情况的处置完全不同 ——
        # 源没有 = 不该判失败；抽丢 = 必须判失败；主动扣下 = 记 quarantine，
        # 让下游按 `pass_with_quarantine` 走，而不是逼着人把脏数据放回去。
        if key in (withheld or ()):
            continue
        # 文本层证据表明「源文档就没有这张表」→ not_applicable，不判失败。
        # 这是 1102-V3.2 起的判定：源无表 ≠ 抽取失败 ≠ 可以编造。
        if extracted is None and key in (source_absent or ()):
            continue
        found = 0
        if isinstance(extracted, dict):
            found = int(((extracted.get(key) or {}) or {}).get("to") or 0)
        if extracted is None or found:
            errs.append(f"specs.{key} 为空" if not found
                        else f"specs.{key} 为空（确定性抽取抽到 {found} 条却丢失）")
        # 抽不到且明确传了 extracted → 源文档无此表，不判失败
    if not (sp.get("electrical") or []):
        errs.append("specs.electrical 为空")
    errs.extend(check_ac_integrity(sp.get("ac_performance") or []))
    return errs


#: AC 数值格的合法形态：纯数字（允许 ± / − / 小数 / 科学计数）。
#: 单位串（`dB`）与脚注（`See Note 2`）都不是数值 —— 占了数值格就是列角色错位。
_AC_NUM_RE = re.compile(r"^[±+\-−]?\d+(?:\.\d+)?(?:\s?[eE][±+\-]?\d+)?$")


def ac_num_cell(v: str) -> bool:
    """这一格填的是不是数值。空串 = 原表没填，合法。

    `value_shape` 只记录「哪几格被填了」，不判断填的是什么 —— V9 的
    `max="dB"`（单位串占了 MAX 格）因此与 `value_shape="LH"` 自洽、被判合法放行。
    单看 shape 不够，必须再验一次「填的是不是数」。

    公开名给 `qc/ac_quarantine.py` 复用：隔离判据与 AC 列角色闸门必须是
    同一套口径（§5.14），各写一份正则早晚会分叉。
    """
    v = str(v or "").strip()
    return (not v) or bool(_AC_NUM_RE.match(v))


#: 向后兼容：既有测试/调用方仍按私有名引用。
_ac_num_cell = ac_num_cell


def check_ac_integrity(ac: list) -> list[str]:
    """AC 表的**列角色闸门**：禁止伪造 MIN/MAX、禁止同一原始行出现两次。

    Reviewer 7.5/元宝 7.5 两轮复审各抓到一个 P0，都落在这里：

    * 1102 的 82 行里有 48 行 `min == typ == max` —— TYP 被横向复制进 MIN/MAX。
      TI 的 AC 表绝大多数行**只有 TYP 一格**，三列同值在物理上几乎不成立。
      判据不能只看「三个值相等」（真有三列同值的表），要结合
      `value_shape`（原表这一行填了哪几列）。`value_shape` 缺失即老数据，
      按严格口径判 —— 宁可拦下让重抽，也不要放过。
    * 同一 `row_sha256` 出现两次 = 同一条原始行被抽了两遍（82 行里 18 条重复）。

    纯函数，不依赖 PDF，便于单测。
    """
    errs: list[str] = []
    seen: dict[str, int] = {}
    for i, r in enumerate(ac):
        if not isinstance(r, dict):
            continue
        sym = str(r.get("symbol") or "?")
        cond = str(r.get("conditions") or "")[:48]
        mn, tp, mx = (str(r.get(k) or "").strip() for k in ("min", "typ", "max"))
        shape = str(r.get("value_shape") or "")
        # 数值格必须真的是数。V9 的 `min="73.9"/typ=""/max="dB"` 就是在这里漏过去的：
        # 三列互不相等等价于「没横向复制」，但单位串占着 MAX 格本身就是列角色错位，
        # 而 `value_shape="LH"` 与实填自洽，光靠 shape 比对判不出来。
        for _k, _v in (("MIN", mn), ("TYP", tp), ("MAX", mx)):
            if _v and not _ac_num_cell(_v):
                errs.append(f"AC 第 {i} 行 {_k}={_v!r} 不是数值（单位/脚注占了数值格，"
                            f"列角色错位）（{sym} / {cond}）")
        filled = "".join(c for c, v in (("L", mn), ("T", tp), ("H", mx)) if v)
        if shape and shape != filled:
            errs.append(f"AC 第 {i} 行 value_shape={shape!r} 与实填 {filled!r} 不符"
                        f"（{sym} / {cond}）")
        if mn and mn == tp == mx:
            errs.append(f"AC 第 {i} 行 MIN=TYP=MAX={mn!r}，疑似把 TYP 横向复制进"
                        f" MIN/MAX（{sym} / {cond}）")
        if not shape and mn and mx and mn == mx:
            errs.append(f"AC 第 {i} 行 MIN=MAX={mn!r} 且无 value_shape 佐证"
                        f"（{sym} / {cond}）")
        fp = str(r.get("row_sha256") or "")
        if fp:
            seen[fp] = seen.get(fp, 0) + 1
    dup = sum(v - 1 for v in seen.values() if v > 1)
    if dup:
        errs.append(f"AC 表有 {dup} 条重复原始行（row_sha256 撞车，"
                    f"{len([v for v in seen.values() if v > 1])} 组）")
    return errs


#: 型号级验收点：**可执行**的断言，不是文档里的一句话。
#: 客户/复审看到「四验收点通过」时，应当能对上这里的每一条。
ACCEPTANCE_SPECS: dict[str, dict] = {
    "ADC12DJ5200SE": {
        "pins": 144,
        "thermal": {"RθJA": "23.9", "RθJC(top)": "0.8", "RθJB": "8.4",
                    "ψJT": "0.23", "ψJB": "8.4"},
        "esd": {"HBM": "±2000", "CDM": "±500"},
        "vcmi_value": "0 to 0.55",
        "vcmi_rows": 3,
        "vid_value": "0.4 to 2.0",
        # Reviewer P1：ADC 的 SNR / SFDR / NSD / IMD3 此前页面上 0 行。
        # 只登记「每个符号至少几条 + 必须带条件」，不登记具体数值 ——
        # 数值锁死在验收表里，换一版手册（Rev. D）就会全线误报。
        "ac_symbols": {"SNR": 20, "SFDR": 20, "NSD": 4, "IMD3": 20},
        "ac_requires_conditions": True,
    },
}


def check_acceptance(doc: dict, mpn: str) -> list[str]:
    """型号级验收点。没有登记该型号时返回空 —— 不猜、不套用别人的指标。"""
    spec = ACCEPTANCE_SPECS.get(mpn)
    if not spec:
        return []
    errs: list[str] = []
    sp = safe_dict(doc, "specs")
    pins = dict_rows(doc, "pin_configuration")
    if "pins" in spec and len(pins) != spec["pins"]:
        errs.append(f"pins {len(pins)} != {spec['pins']}")

    for key, want in (("thermal", spec.get("thermal") or {}), ("esd", spec.get("esd") or {})):
        got = {str(r.get("name") or "").strip(): str(r.get("value") or "").strip()
               for r in safe_list(sp, key) if isinstance(r, dict)}
        for name, val in want.items():
            if name not in got:
                errs.append(f"{key} 缺 {name}")
            elif got[name] != val:
                errs.append(f"{key}.{name} = {got[name]!r} != {val!r}")

    elec = dict_rows(sp, "electrical")
    if "vcmi_value" in spec:
        vcmi = [e for e in elec if "common-mode voltage" in str(e.get("name") or "").lower()]
        if "vcmi_rows" in spec and len(vcmi) != spec["vcmi_rows"]:
            errs.append(f"VCMI 行数 {len(vcmi)} != {spec['vcmi_rows']}（未按引脚组拆条）")
        bad = [e for e in vcmi if str(e.get("value") or "").strip() != spec["vcmi_value"]]
        if vcmi and bad:
            errs.append(f"VCMI 值 {bad[0].get('value')!r} != {spec['vcmi_value']!r}")
    if "vid_value" in spec:
        vid = [e for e in elec
               if "differential" in str(e.get("name") or "").lower()
               and "voltage" in str(e.get("name") or "").lower()]
        if not vid:
            errs.append("缺 Input voltage, peak-to-peak differential（VID）")
        elif not str(vid[0].get("value") or "").startswith(spec["vid_value"]):
            errs.append(f"VID {vid[0].get('value')!r} 不是 {spec['vid_value']!r}")

    want_ac = spec.get("ac_symbols") or {}
    if want_ac:
        ac = dict_rows(sp, "ac_performance")
        if not ac:
            errs.append("specs.ac_performance 为空（SNR/SFDR/NSD/IMD3 未落盘）")
        else:
            for sym, least in want_ac.items():
                n = sum(1 for r in ac if str(r.get("symbol") or "") == sym)
                if n < least:
                    errs.append(f"AC {sym} 仅 {n} 行 < {least}")
            if spec.get("ac_requires_conditions"):
                # 同一个 SNR 在不同 fIN / AIN 下是十几个不同的数。丢了条件，
                # 表就变成「随便挑一个用」—— 那比不显示更危险。
                bare = [r for r in ac if not str(r.get("conditions") or "").strip()]
                if bare:
                    errs.append(f"AC 有 {len(bare)} 行缺测试条件")
            for r in ac:
                if not str(r.get("unit") or "").strip():
                    errs.append(f"AC {r.get('symbol')} 缺单位")
                    break
    return errs

