# -*- coding: utf-8 -*-
"""选页/取证共用的文本判据（1102-V3.5）。

**为什么单独成模块**：`select_pages`（生产）与 `probe_electrical_pages`（取证）
必须用**同一份**目录页排除规则；各藏一份词表时，探针会误报 `model_gap`、
生产会漏保电气页，两边都"看起来对"却对不上账（AGENT.md §5 同类错误）。
"""
from __future__ import annotations

import re

_TOC_PHRASES = ("table of contents", "contents of this document")


def is_toc_page(text: str) -> bool:
    """目录页：含 TOC 标题，或出现成串点线（`Electrical Characteristics .... 11`）。"""
    low = (text or "").lower()
    if any(p in low for p in _TOC_PHRASES):
        return True
    raw = text or ""
    return raw.count("....") >= 2 or "......." in raw


def normalize_ws(text: str) -> str:
    """归一空白：排版拆行的标题（`ELECTRICAL\\nCHARACTERISTICS`）才能被子串命中。"""
    return re.sub(r"\s+", " ", (text or "").lower())
