"""持平件只读核查：判定「1→1 持平」背后有没有别的真实变化，以及原件是否被换过。

背景
----
重解析批次的回滚判据是 `new_rows < old_rows`，只挡「变差」不挡「持平」，
39 件 1→1 的记录被无条件覆盖。但订货行数持平不等于整个 JSON 没有有效变化，
也不能直接按「无收益」批量还原——已发现 `_pdf_for` 会把同族 PDF（Q1 / EVM /
REEL）当成本料号的原件，原件一旦换过，行数的可比性就不成立。

本脚本对每一件核对六个维度（只读，不写 parsed / backup / 数据库）：
  1. 数据库 `item.pdf_path` 当前指向哪个原件、它的真实 SHA256
  2. 备份 JSON 与当前 JSON 各自记录的 `metadata.pdf_hash`
  3. 当前 JSON 的原件哈希是否等于 `item.pdf_path` 对应文件的 SHA256
  4. 旧哈希在磁盘上是否还能找到（判断「重下载漂移」还是「挑错设备」）
  5. 同族 PDF 候选（前缀命中几份）
  6. 排除 ordering_info 之后的字段差异 + 订货行内容是否变了

输出建议分类：
  A 原件一致、无其他有效变化  -> 可从备份精确还原
  B 原件已变更且当前内容与目标原件一致 -> 保留当前内容，记录哈希不一致
  C 原件归属或内容无法确认 -> 暂不修改，列入人工复核

用法（容器内）
--------------
    python qc/audit_ties.py --mpns-file /tmp/ties.txt --out /tmp/ties_audit.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.reparse_ordering import _safe                       # noqa: E402

# metadata 里的 parse_timestamp / model_version 每次解析必然变化，
# 不能算「有效变化」；ordering_info 单独比较。
SKIP_TOP = ("ordering_info", "metadata")
_NAME_HASH = re.compile(r"^(.*)_([0-9a-f]{8})$")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _diff(old, new, path="", out=None, depth=0):
    """返回排除 ordering_info 之后的变更路径列表。"""
    if out is None:
        out = []
    if path.split(".")[0] in SKIP_TOP:
        return out
    if depth > 3 or len(out) > 60:
        return out
    if isinstance(old, dict) and isinstance(new, dict):
        for k in sorted(set(old) | set(new)):
            if k in SKIP_TOP:
                continue
            _diff(old.get(k), new.get(k), f"{path}.{k}" if path else k, out, depth + 1)
    elif isinstance(old, list) and isinstance(new, list):
        if len(old) != len(new):
            out.append(f"{path}: 条数 {len(old)}->{len(new)}")
        for i in range(min(len(old), len(new))):
            _diff(old[i], new[i], f"{path}[{i}]", out, depth + 1)
    elif old != new:
        a, b = str(old)[:40], str(new)[:40]
        out.append(f"{path}: {a} => {b}")
    return out


def _rows(doc: dict) -> list[str]:
    return [str((o or {}).get("mpn") or "") for o in (doc.get("ordering_info") or [])
            if isinstance(o, dict)]


def _resolve(p: str, kind_dir: Path) -> Path | None:
    """数据库里的路径可能是 Windows 路径（E:\\...）或容器路径，取文件名落到本地。"""
    if not p:
        return None
    cand = kind_dir / Path(p.replace("\\", "/")).name
    return cand if cand.exists() else None


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="持平件只读核查")
    ap.add_argument("--mpns-file", default="", help="每行一个 MPN")
    ap.add_argument("--mpn", action="append", default=[])
    ap.add_argument("--data-dir", default=str(ROOT / "data" / "parsed"), dest="data_dir")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--pdfs", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--db", default=str(ROOT / "data" / "workbench.sqlite3"))
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)

    data_dir, backup, pdfs = Path(a.data_dir), Path(a.backup), Path(a.pdfs)
    mpns = list(a.mpn)
    if a.mpns_file and Path(a.mpns_file).exists():
        mpns += [x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()]
    mpns = list(dict.fromkeys(mpns))
    if not mpns:
        print("没有指定 MPN")
        return 2

    db = sqlite3.connect(a.db) if Path(a.db).exists() else None
    print("核查 %d 件（DB %s）" % (len(mpns), "已连接" if db else "不可用"))

    # PDF 索引一次建好，避免逐件 glob
    pdf_index = {p.name: p for p in pdfs.glob("*.pdf")}
    cur_index = {p.name: p for p in data_dir.glob("*.json")}
    bak_index = {p.name: p for p in backup.glob("*.json")}

    rows = []
    for mpn in mpns:
        key = _safe(mpn)
        # 数据库引用
        db_pdf = db_json = db_sha = ""
        if db:
            r = db.execute("SELECT pdf_path, json_path, pdf_sha256 FROM item WHERE mpn=?",
                           (mpn,)).fetchone()
            if r:
                db_pdf, db_json, db_sha = r[0] or "", r[1] or "", r[2] or ""

        # 现文件优先取数据库引用的那个
        want = Path(db_json.replace("\\", "/")).name if db_json else ""
        fname = want if want in cur_index else ""
        if not fname:
            hits = sorted(n for n in cur_index if n.startswith(key + "_"))
            fname = hits[0] if hits else ""
        cur_p = cur_index.get(fname)
        bak_p = bak_index.get(fname)

        cur, old = (_load(cur_p) if cur_p else {}), (_load(bak_p) if bak_p else {})
        old_h = str((old.get("metadata") or {}).get("pdf_hash") or "")
        new_h = str((cur.get("metadata") or {}).get("pdf_hash") or "")

        # 数据库指向的原件
        pdf_p = _resolve(db_pdf, pdfs)
        pdf_sha = _sha(pdf_p) if pdf_p else ""

        # 同族候选 + 旧哈希是否还在磁盘上
        cands = sorted(n for n in pdf_index if n.startswith(key))
        old_on_disk = ""
        for n in cands:
            if _sha(pdf_index[n])[:16] == old_h[:16]:
                old_on_disk = n
                break

        diff = _diff(old, cur)
        o_rows, n_rows = _rows(old), _rows(cur)

        # 质量指标：电气参数条数、替代型号条数、是否命中请求料号
        def _n(doc, *path):
            v = doc
            for k in path:
                v = (v or {}).get(k) if isinstance(v, dict) else None
            return len(v) if isinstance(v, list) else 0

        o_elec = _n(old, "specs", "electrical")
        n_elec = _n(cur, "specs", "electrical")
        o_alt = len(old.get("alternatives") or [])
        n_alt = len(cur.get("alternatives") or [])
        o_feat = len(old.get("features") or [])
        n_feat = len(cur.get("features") or [])
        req = (mpn or "").strip().upper()
        o_hit = req in [x.upper() for x in o_rows]
        n_hit = req in [x.upper() for x in n_rows]
        order_gain = "是" if (n_hit and not o_hit) else "否"
        regression = []
        if n_alt < o_alt:
            regression.append("替代型号 %d->%d" % (o_alt, n_alt))
        if n_elec < o_elec:
            regression.append("电气参数 %d->%d" % (o_elec, n_elec))
        if n_feat < o_feat:
            regression.append("特性 %d->%d" % (o_feat, n_feat))
        if o_hit and not n_hit:
            regression.append("订货行丢失请求料号")
        if not n_rows:
            regression.append("订货行为空")

        flags = []
        if old_h and new_h and old_h[:16] != new_h[:16]:
            flags.append("原件哈希已变")
        if pdf_sha and new_h and pdf_sha[:16] != new_h[:16]:
            flags.append("当前内容与item.pdf_path不一致")
        if not pdf_p:
            flags.append("item.pdf_path 在磁盘上不存在")
        if old_h and not old_on_disk:
            flags.append("旧原件已不在磁盘(疑似重下载/漂移)")
        if len(cands) > 1:
            flags.append("同族PDF %d 份" % len(cands))
        if sorted(o_rows) != sorted(n_rows):
            flags.append("订货行内容变了")
        if diff:
            flags.append("非订货字段变更 %d 处" % len(diff))
        if want and fname and want != fname:
            flags.append("DB引用文件名与现文件不一致")

        # 分类（原件一致时才谈「还原」；原件换了先判断与 item.pdf_path 是否一致）
        if not cur_p or not bak_p:
            cls = "C"
        elif old_h[:16] != new_h[:16]:
            cls = "B" if pdf_sha[:16] == new_h[:16] else "C"
        elif order_gain == "是":
            cls = "B"          # 订货行命中了请求料号，是身份层面的实质改善
        elif not diff and sorted(o_rows) == sorted(n_rows):
            cls = "A"          # 原件一致、排除 metadata 后无变化 -> 无收益
        else:
            cls = "C"          # 有实质字段变化但订货行无改善，需人工看

        rows.append({
            "mpn": mpn, "class": cls,
            "order_hits_request": order_gain,
            "elec_n": "%d->%d" % (o_elec, n_elec),
            "alt_n": "%d->%d" % (o_alt, n_alt),
            "feat_n": "%d->%d" % (o_feat, n_feat),
            "regression": "，".join(regression) or "-",
            "cur_file": fname, "backup_file": fname if bak_p else "",
            "db_json_path": db_json, "db_ref_ok": "是" if (db_json and want and want == fname) else "否",
            "item_pdf_path": Path(db_pdf.replace("\\", "/")).name if db_pdf else "",
            "db_pdf_sha256": (db_sha or "")[:16],
            "disk_pdf_sha256": pdf_sha[:16],
            "old_pdf_hash": old_h[:16], "new_pdf_hash": new_h[:16],
            "src_same": "是" if old_h[:16] == new_h[:16] else "否",
            "cur_matches_item_pdf": "是" if (pdf_sha and new_h and pdf_sha[:16] == new_h[:16]) else "否",
            "old_pdf_on_disk": old_on_disk or "-",
            "family_pdf_n": len(cands),
            "family_pdf_names": " | ".join(cands[:6]),
            "old_order_rows": ",".join(o_rows), "new_order_rows": ",".join(n_rows),
            "order_changed": "是" if sorted(o_rows) != sorted(n_rows) else "否",
            "diff_n": len(diff), "diff_sample": " ; ".join(diff[:8]),
            "flags": "，".join(flags) or "-",
        })

    # 汇总
    from collections import Counter
    cc = Counter(r["class"] for r in rows)
    print("\n=== 分类汇总 ===")
    print("A 原件一致且无有效变化（建议还原）：%d" % cc.get("A", 0))
    print("B 原件已变但与 item.pdf_path 一致（建议保留）：%d" % cc.get("B", 0))
    print("C 无法确认（建议人工复核）：%d" % cc.get("C", 0))
    for cls in ("B", "C"):
        for r in rows:
            if r["class"] == cls:
                print("  [%s] %-22s %s" % (cls, r["mpn"], r["flags"]))
    bad = [r for r in rows if r["db_ref_ok"] == "否"]
    if bad:
        print("\n[!] DB 引用文件名与现文件不一致 %d 件：" % len(bad))
        for r in bad:
            print("    %s db=%s 现=%s" % (r["mpn"], r["db_json_path"], r["cur_file"]))

    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("\n明细已写 %s（%d 行）" % (out, len(rows)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
