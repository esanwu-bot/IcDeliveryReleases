#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把事实验收表的结论回写进 `<型号>.json` 的 `verification.status`。

为什么要有这一步
----------------
V6 复审【新-2】：页面已经跟事实表走了（`†` 只认 `facts_verdicts.json`），
但 **JSON 自述还停在旧值** —— ADC `electrical` 有 9 行写着 `label_value_same_page`
（只到同页），事实表给的是 `verified_paragraph`（坐标 + 条目指纹，更强）。
直接读 `<型号>.json` 的下游（选型、下单、二次渲染）拿到的仍是更弱的那一个。

口径：**只升不降，且不洗白出处**
--------------------------------
* 升级只发生在「当前状态是过程性描述、而事实表给出了更强结论」时，
  例如 `label_value_same_page` → `audited_paragraph`。
* `model_unverified` / `unresolved` **永远不升**：它们说的是「这个值是模型抽的、
  或列角色没定」，事实表只能证明「这几个数在原文里出现过」，不能把出处变成
  确定性抽取。把它们改成 `audited_*` 就是伪造出处 —— 复审最不能接受的那种。
* 状态为空（`None` / 缺失）时，弱结论也如实补写（`value_on_label_page` →
  `label_value_same_page` 等）：空着并不等于「已核验」，下游与页面都会看错。
  已有状态一律不降级 —— 补写与降级是两件事。
* 无论升不升，都写入 `verification.fact_verdict` / `fact_grade` / `fact_source`，
  下游想知道「事实表怎么判的」不必再去 join CSV。

范围（1102-V2 P1）
------------------
不仅扫 `specs.electrical` 等五个主容器，也扫 `specs.onboard_device_specs` /
`specs.unresolved_specs` 两个隔离桶 —— 板卡件的电气行被合同层整锅搬进
`onboard_device_specs.electrical` 后，V11 的同步一条都没走到，页面上
`†` 按事实表打、JSON 的 `verification` 却还是 `None`。

用法：
    python qc/fact_status_sync.py --staging data/staging_20261101_v7 \\
        --facts data/staging_20261101_v7/facts_audit.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import ac_quarantine  # noqa: E402
from qc import core_validation as CV  # noqa: E402
from qc import range_guard  # noqa: E402

#: 事实表结论 → JSON 里对得上的状态名。三处（JSON / facts / 页面）同名，
#: 复审就不用再猜「这两个词是不是一回事」。
#:
#: 强结论走**升级**路线（`_RANK`）；弱结论只用来填**空状态** —— 已经有
#: `model_unverified` / `unresolved` 的行不许被弱证据「同步」成更可信的样子，
#: 那是洗白出处（V6 复审最不能接受的那种）。
STATUS_OF = {
    "verified_row": "audited_row_anchored",
    "verified_paragraph": "audited_paragraph",
    "verified_value": "audited_coord",
    "verified": "audited_container",
    # 弱结论：只填空状态，不覆盖任何已有状态。
    "value_on_label_page": "label_value_same_page",
    "value_in_pdf": "value_in_pdf",
    "partial": "partial",
    "not_found": "not_found",
    "unchecked": "not_checked",
}

#: 弱结论落成的状态：只允许在状态**为空**时补写，绝不覆盖已有状态。
_WEAK_TARGETS = frozenset({"label_value_same_page", "value_in_pdf",
                           "partial", "not_found", "not_checked"})

#: 允许被升级的旧状态。**不在表里的一律不动** —— 尤其是 `model_unverified`
#: 与 `unresolved`：它们是「出处不可信」的标记，不能被更强的定位洗掉。
_UPGRADABLE = frozenset({
    "", "label_value_same_page", "audited_deterministic",
    "audited_row_anchored", "audited_paragraph", "audited_coord",
    "audited_container",
})

#: 状态强弱（只许往上走）。弱状态与事实表弱结论同名（见 `STATUS_OF`），
#: 渲染层必须认得这些名字，否则 JSON 与页面又分叉。
_RANK = {"": 0, "not_checked": 0, "not_found": 0, "partial": 1,
         "value_in_pdf": 1, "label_value_same_page": 1,
         "audited_deterministic": 2, "audited_container": 2,
         "audited_coord": 3, "audited_paragraph": 4,
         "audited_row_anchored": 5}

#: 参与同步的容器。顺序即报告顺序。
CONTAINERS = ("electrical", "absolute_max", "ac_performance", "thermal", "esd")

#: 板卡件的隔离桶：合同层把板载器件参数搬进这里，页面照常渲染，事实表也审，
#: 所以同步必须走进去（1102-V2 P1：V11 只扫主表，板载桶的 verification 一直是 None）。
#: 与 `qc/fact_acceptance.BUCKETS` 同口径。
BUCKETS = ("onboard_device_specs", "unresolved_specs")


def _label(row: dict) -> str:
    return str(row.get("name") or row.get("parameter") or row.get("symbol") or "").strip()


def _cond(row: dict) -> str:
    return str(row.get("condition") or row.get("conditions") or "")


def iter_rows(specs: dict):
    """遍历**页面上会出现、事实表也审计过**的每一行：主表 + 两个隔离桶。

    范围与 `qc/fact_acceptance.iter_container_rows()` 保持一致：事实表没审到的
    行（`onboard_device_specs.devices.<MPN>` 子桶）这里也不凭空给状态 ——
    「同步」只能搬事实表已经有的结论。
    """
    if not isinstance(specs, dict):
        return
    for c in CONTAINERS:
        for row in specs.get(c) or []:
            if isinstance(row, dict):
                yield row
    for b in BUCKETS:
        box = specs.get(b)
        if not isinstance(box, dict):
            continue
        for c in CONTAINERS:
            for row in box.get(c) or []:
                if isinstance(row, dict):
                    yield row


def load_facts(csv_path: Path) -> dict[str, dict[tuple[str, str], str]]:
    """`mpn → {(参数名, 条件): verdict}`。键与 `facts_verdicts.json` 同构。"""
    out: dict[str, dict[tuple[str, str], str]] = {}
    with csv_path.open(encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            out.setdefault(str(r.get("mpn") or ""), {})[
                (str(r.get("label") or ""), str(r.get("cond") or ""))] = \
                str(r.get("verdict") or "")
    return out


def load_evidence(csv_path: Path) -> dict[str, dict[tuple[str, str], dict]]:
    """`mpn → {(参数名, 条件): {verdict, bbox, row_sha256, paragraph_sha256}}`。

    为什么单列一个函数：`load_facts()` 只留结论字符串，坐标被丢掉了。而 AC
    逃逸行的平反判据**正是坐标**（`ac_quarantine.has_independent_provenance`）。
    只喂结论不喂坐标，平反永远判成「没有独立溯源」—— 1102-V3 的 THD/SNR 就是
    这么一直躺在隔离桶里的：函数支持 evidence，调用方却从没传过。
    """
    out: dict[str, dict[tuple[str, str], dict]] = {}
    with csv_path.open(encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            bbox: list[float] = []
            raw = str(r.get("bbox") or "").strip()
            if raw:
                try:
                    vals = json.loads(raw) if raw.startswith("[") else \
                        [x for x in re.split(r"[,\s]+", raw) if x]
                    bbox = [float(v) for v in vals]
                except (ValueError, TypeError):
                    bbox = []
            out.setdefault(str(r.get("mpn") or ""), {})[
                (str(r.get("label") or ""), str(r.get("cond") or ""))] = {
                    "verdict": str(r.get("verdict") or ""),
                    "bbox": bbox if len(bbox) == 4 else [],
                    "row_sha256": str(r.get("row_sha256") or ""),
                    "paragraph_sha256": str(r.get("paragraph_sha256") or ""),
                }
    return out


def _sync_row(row: dict, verdicts: dict[tuple[str, str], str]) -> tuple[int, int, int, int]:
    """同步一行，返回 `(升级, 补写, 保持, 已一致)` 四个计数。"""
    v = verdicts.get((_label(row), _cond(row)))
    if not v:
        return (0, 0, 0, 0)
    ver = row.get("verification")
    if not isinstance(ver, dict):
        ver = {}
        row["verification"] = ver
    ver["fact_verdict"] = v
    ver["fact_source"] = "facts_audit/v4"
    want = STATUS_OF.get(v)
    if not want:
        return (0, 0, 0, 0)          # 未知结论：只留 fact_verdict，不猜状态
    cur = str(ver.get("status") or "")
    if cur == want:
        ver["fact_grade"] = v
        return (0, 0, 0, 1)
    if cur and (cur not in _UPGRADABLE or want in _WEAK_TARGETS
                or _RANK.get(want, 0) <= _RANK.get(cur, 0)):
        # 已有状态：弱结论一律不覆盖；强结论只许在可升级且确实更强时替换。
        # `model_unverified` / `unresolved` 因此永远不会被定位证据洗白。
        return (0, 0, 1, 0)
    ver["status"] = want
    # 原值原样保留（可能是空串）。写 "(空)" 会让下游把它当成一个
    # 新的状态名 —— 风险队列因此凭空少 15 行（实测踩到）。
    ver["status_prev"] = cur
    ver["status_prev_note"] = cur or "(空)"
    ver["status_source"] = "qc/fact_status_sync.py"
    ver["fact_grade"] = v
    if want in _WEAK_TARGETS:
        return (0, 1, 0, 0)          # 空状态 + 弱结论 = 如实补写，不叫升级
    return (1, 0, 0, 0)


def sync_doc(doc: dict, verdicts: dict[tuple[str, str], str],
             evidence: dict[tuple[str, str], dict] | None = None) -> dict:
    """就地改 `doc`，返回计数。

    主体**只动 `verification`，不碰值**；另外先做一次 V11 P0-1 的 AC 脏行隔离
    （搬行不改值），以及 V9/V11 的 `range` 物理抹除。

    `evidence` 是同一份事实表的坐标列。**必须传**：AC 逃逸行的隔离/平反判据
    是「这一行有没有自己的 bbox + 行/段落指纹」，只给结论字符串就永远判成
    「没有独立溯源」。不传时行为与旧版一致（只隔离、不平反），保留给调用方
    确实只有结论的场景。
    """
    # V11 P0-1：事实表按 `specs.ac_performance` 取行，脏 AC 行必须先搬走，
    # 否则隔离区外的容器口径和事实表还会各算各的。
    # 1102-V3.1：带上 evidence —— 证据到坐标级的逃逸行会被平反回正式容器。
    ac = ac_quarantine.quarantine(doc, evidence)
    n_up = n_fill = n_keep = n_same = 0
    for row in iter_rows((doc.get("specs") or {})):
        u, f, k, s = _sync_row(row, verdicts)
        n_up += u
        n_fill += f
        n_keep += k
        n_same += s
    # 1102-V2 P1：同步阶段又搬走脏行时，metadata 不能停在装配时的 "pass"。
    # 只在**已有** core_validation 的文档上重算 —— 没有这一步的旧 JSON 不凭空造状态。
    meta = doc.get("metadata")
    if isinstance(meta, dict) and meta.get("core_validation") is not None:
        meta["core_validation"] = CV.stamp(meta, doc,
                                          meta.get("core_validation"))
    # V9 P0-1：`fact_verdict` 刚落进 JSON，正好在这里做一次物理抹除 ——
    # 声称「列角色已核验」却只拿到 `verified_value` / `value_on_label_page`
    # 的行，其 `range` 结构当场删掉（见 `qc/range_guard.py`）。
    # 放在这里而不是渲染前：JSON 是交付物，下游（选型、下单、二次渲染）
    # 直接读它，渲染层再干净也拦不住。
    guard = range_guard.enforce(doc)
    meta = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    return {"upgraded": n_up, "filled": n_fill, "kept": n_keep,
            "same": n_same,
            "range_stripped": guard["n_stripped"],
            "ac_quarantined": ac["n_quarantined"],
            "ac_restored": ac.get("n_restored", 0),
            "core_validation": meta.get("core_validation"),
            "quarantine_count": meta.get("quarantine_count", 0)}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="事实表 → JSON 状态同步")
    ap.add_argument("--staging", required=True)
    ap.add_argument("--facts", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    staging, facts = Path(a.staging), Path(a.facts)
    parsed = staging / "parsed"
    if not parsed.is_dir():
        print(f"缺 parsed/：{parsed}", file=sys.stderr)
        return 2
    vm = load_facts(facts)
    ev = load_evidence(facts)
    total = {"upgraded": 0, "filled": 0, "kept": 0, "same": 0,
             "range_stripped": 0, "ac_quarantined": 0, "ac_restored": 0}
    for jp in sorted(parsed.glob("*.json")):
        doc = json.loads(jp.read_text(encoding="utf-8"))
        res = sync_doc(doc, vm.get(jp.stem) or {}, ev.get(jp.stem) or {})
        for k in total:
            total[k] += res[k]
        print(f"{jp.stem:18} 升级 {res['upgraded']:3} 补写 {res['filled']:3} "
              f"保持 {res['kept']:3} 已一致 {res['same']:3} "
              f"抹除 range {res['range_stripped']:2} "
              f"隔离 AC {res['ac_quarantined']:2} "
              f"平反 {res['ac_restored']:2}")
        if not a.dry_run:
            jp.write_text(json.dumps(doc, ensure_ascii=False, indent=2),
                          encoding="utf-8")
            # 流水线凭证（2026-11-03 外审 P0-1）：同步跑过的证据。
            # 打包器会核 `fact_status_sync` 这一行，并重新数一遍
            # electrical/absolute_max 里缺 status 的行 —— 两件事都过才放行。
            try:
                from qc import pipeline_stamp as PS               # noqa: PLC0415
                PS.record(staging, "fact_status_sync", jp.stem, doc, jp)
            except Exception as e:                                # noqa: BLE001
                print(f"  凭证写入失败：{type(e).__name__}: {e}", file=sys.stderr)
    print(f"\n合计：升级 {total['upgraded']} / 补写 {total['filled']} / "
          f"保持 {total['kept']} / 已一致 {total['same']} / "
          f"抹除 range {total['range_stripped']} / "
          f"隔离 AC {total['ac_quarantined']} / 平反 {total['ac_restored']}"
          f"{'（dry-run 未写盘）' if a.dry_run else ''}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
