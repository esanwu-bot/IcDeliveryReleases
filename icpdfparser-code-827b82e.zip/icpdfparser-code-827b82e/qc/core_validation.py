#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`metadata.core_validation` 的生成口径 —— `pass` 不等于「什么都没扣下」。

为什么单独一层
--------------
`check_core()` 只看结构错误与列角色错误。AC 脏行被 `qc/ac_quarantine.py`
搬进 `specs.unresolved_ac_rows` 之后，错误清单归零，于是状态又写回 `"pass"`。
下游（API、选型、二次渲染、打包闸门）读到的是：

    core_validation = "pass"
    specs.ac_performance = []

两句话合起来会被读成「这份手册没有 AC 参数」—— 而事实是**有 6 条，
只是列角色没核验、被我们主动扣下了**。这正是 1102-V2 复审的 P1：
状态不是不准确，而是会主动误导。

三态（不是布尔）
----------------
* `"pass"`                 —— 没有核心错误，也没有隔离行；
* `"pass_with_quarantine"` —— 没有核心错误，但 `unresolved_ac_rows` 非空，
  `metadata.quarantine_count` 给出被扣下的条数；
* `[...]`                  —— 有核心错误，原样保留清单（不允许被隔离状态洗成 pass）。

为什么错误清单优先：隔离解决的是「这一行数据不可信」，不是「文档结构坏了」。
把真错误折叠成 `pass_with_quarantine` 等于用治理记录掩盖缺陷。

调用点
------
* `parse_datasheets.py` —— 解析落盘时；
* `qc/stage_release.py::_revalidate` —— 交付装配时用当前口径重算；
* `qc/fact_status_sync.py` —— 同步阶段又搬走脏行时保持 metadata 不落后。
"""
from __future__ import annotations

PASS = "pass"
PASS_WITH_QUARANTINE = "pass_with_quarantine"

#: 隔离容器在 `specs` 下的键名。由 `qc/ac_quarantine.py` 写入。
#: 这里不 import 对方模块：本模块被解析脚本与装配脚本共用，保持零依赖。
ISOLATION = "unresolved_ac_rows"

#: 列塌缩隔离桶（`qc/collapse_quarantine.py`）。**必须一起计数** ——
#: 只数 AC 桶的话，热阻被整容器扣下的件会被写成 `pass`，「扣了 34 行」
#: 这件事在 `core_validation` 里一个字都不体现。
ISOLATION_COLLAPSE = "unresolved_column_collapse"


def quarantine_count(doc: dict) -> int:
    """被主动扣下的总行数（AC 隔离桶 + 列塌缩隔离桶）；容器缺失/非法时计 0。"""
    specs = (doc or {}).get("specs")
    if not isinstance(specs, dict):
        return 0
    n = 0
    for key in (ISOLATION, ISOLATION_COLLAPSE):
        rows = specs.get(key)
        if isinstance(rows, list):
            n += len(rows)
    return n


def stamp(meta: dict, doc: dict, base) -> object:
    """把 `base` 落成三态值并同步 `quarantine_count`，返回最终值。

    `meta` 就地修改：有隔离行时写计数，隔离清零时**删掉陈旧计数**——
    留着一个 6 而实际 0 条，是另一种误导。
    """
    n = quarantine_count(doc)
    if n:
        meta["quarantine_count"] = n
    else:
        meta.pop("quarantine_count", None)
    if base == PASS and n:
        return PASS_WITH_QUARANTINE
    return base


def is_clean_pass(value) -> bool:
    """是否「干净通过」—— 打包侧判断能否进入已验证状态时用。"""
    return value == PASS


def is_pass(value) -> bool:
    """是否「没有核心校验错误」。`pass_with_quarantine` 也算没有错误。"""
    return value in (PASS, PASS_WITH_QUARANTINE)
