"""30 件/批的自动化 r1–r6 QC 流水线（只读数据库，产出可进交付历史的批次目录）。

设计口径（与 r6 人工验收报告区分）：
  * 全自动、机器可判；**不修改** facts / Gold / item，不做人工语义裁决。
  * r1 身份与来源：MPN、PDF 文件/SHA、JSON 身份、品牌。
  * r2 结构与产物：JSON 架构、电气/封装/引脚、必需/可选产物、五语、SEO/替代料。
  * r3 字段语义（机器）：电气行完整性、单位、封装/引脚结构、文本含型号。
  * r4 facts 与 Gold 对照：有 Gold 才对照；无 Gold 记 NOT_APPLICABLE，不猜真值。
  * r5 包回归：ZIP 条目/大小/清单/JSON 回读，确认打包后仍可解析。
  * r6 交付打包：ZIP + manifest + README + 核验报告 + audit JSON，目录名按 30 件/批。

交付历史约定：`data/qc/<batch>/` 内要有 ZIP、`核验报告.md`、`*quality_audit.json`。
本模块写 ZIP 后计算 SHA/大小并写进 audit `details`，交付历史列表直接复用，避免每次
API 请求重算 400+ 个 ZIP 的 SHA。

CLI::

    python qc/auto_qc.py --data-dir /app/data --out-dir /app/data/qc \\
        --run-id 20261028 --batch-size 30 --limit 2
    # 全量（后台）：去掉 --limit

产物：
  data/qc/qc30-<run>-0001/   ... ZIP + 报告 + audit + manifest
  data/qc/_staging/plan-<run>.json / progress-<run>.json / auto_qc-<run>.log
"""
from __future__ import annotations

import argparse
import csv
import datetime
import difflib
import hashlib
import io
import json
import os
import re
import shutil
import sqlite3
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = Path("/app/data") if Path("/app/data").is_dir() else ROOT / "data"
BATCH_SIZE = 30
LANGS = ("ja", "ko", "de", "es")
IMG_MAGIC = b"%PDF"
STAGE_NAMES = {
    "r1": "身份与来源",
    "r2": "结构与产物",
    "r3": "字段语义（机器）",
    "r4": "facts 与 Gold 对照",
    "r5": "包回归/读回",
    "r6": "交付打包与报告",
}
SEV_FAIL = "FAIL"
SEV_WARN = "WARN"


# ---------------------------------------------------------------- 基础工具
def _now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _safe_name(mpn: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", mpn or "").strip("_") or "unknown"


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _norm_mpn(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", (text or "").upper())


def _base(raw: str) -> str:
    return (raw or "").replace("\\", "/").rsplit("/", 1)[-1]


def _resolve(raw: str, data_dir: Path, sub: str) -> Path | None:
    s = (raw or "").strip()
    if not s:
        return None
    p = Path(s)
    if p.is_file():
        return p
    name = _base(s)
    if not name:
        return None
    q = Path(data_dir) / sub / name
    return q if q.is_file() else None


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json(path: Path | None):
    if not path:
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                                        # noqa: BLE001
        return None


_TOK_RE = re.compile(r"([^\.\[\]]+)|\[([^\]]*)\]")


def _resolve_path(obj, path: str):
    cur = obj
    for name, idx in _TOK_RE.findall(path or ""):
        if name:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(name)
        else:
            if not isinstance(cur, (list, tuple)):
                return None
            try:
                cur = cur[int(idx)]
            except (ValueError, IndexError):
                return None
        if cur is None:
            return None
    return cur


def _resolve_facts(facts, path: str):
    v = _resolve_path(facts, path)
    if v is None and not (path or "").startswith("specs."):
        v = _resolve_path(facts, "specs." + path)
    return v


def _common_substr(a: str, b: str) -> str:
    m = difflib.SequenceMatcher(None, a, b, autojunk=False).find_longest_match(
        0, len(a), 0, len(b))
    return a[m.a:m.a + m.size]


def _family_inherited(item_mpn: str, json_mpn: str) -> bool:
    """EVM/评估板等变体允许继承基础型号身份（与项目 identity=family_inherited 口径一致）。

    只放行有明确前缀/型号片段关系的变体；无关型号仍判 MPN_MISMATCH。
    """
    a, b = _norm_mpn(item_mpn), _norm_mpn(json_mpn)
    if not a or not b:
        return False
    if a.startswith(b) or b.startswith(a):
        return min(len(a), len(b)) >= 4
    if not re.search(r"(EVM|EVK|PDK|DEMO|BOARD|KIT|CVAL)", a):
        return False
    return len(_common_substr(a, b)) >= 6


def _add(findings, severity, stage, code, detail):
    findings.append({"severity": severity, "stage": stage, "code": code,
                     "detail": str(detail)[:800]})


# ---------------------------------------------------------------- 数据库
class ReadOnlyDB:
    def __init__(self, path: Path):
        uri = "file:%s?mode=ro" % Path(path).as_posix()
        self.c = sqlite3.connect(uri, uri=True)
        self.c.row_factory = sqlite3.Row

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args)]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None


def _done_items(db: ReadOnlyDB) -> list:
    return db.q("SELECT * FROM item WHERE status='done' ORDER BY id")


def _gold_map(db: ReadOnlyDB) -> dict:
    out = {}
    for g in db.q("SELECT id,version,mpn,manufacturer,pdf_name,pdf_sha256,doc_rev,status "
                  "FROM gold_set ORDER BY id"):
        prev = out.get(g["mpn"])
        if prev and prev["status"] == "frozen":
            continue
        g["fields"] = db.q("SELECT id,field_path,field_name,expected,unit,cond,page_no,"
                           "evidence,status FROM gold_field WHERE gold_id=? ORDER BY id",
                           (g["id"],))
        out[g["mpn"]] = g
    return out


# ---------------------------------------------------------------- 单项检查
def _artifacts(item: dict, data_dir: Path) -> dict:
    return {
        "pdf": _resolve(item.get("pdf_path"), data_dir, "pdfs"),
        "json": _resolve(item.get("json_path"), data_dir, "parsed"),
        "txt": _resolve(item.get("txt_path"), data_dir, "txt"),
        "symbol": _resolve(item.get("symbol_path"), data_dir, "symbols"),
        "seo": _resolve(item.get("seo_path"), data_dir, "seo"),
        "alt_json": _resolve(item.get("alt_json_path"), data_dir, "alts"),
        "alt_html": _resolve(item.get("alt_html_path"), data_dir, "alts"),
    }


def _lang_files(txt: Path | None) -> dict:
    out = {}
    if not txt:
        return out
    stem = txt.name[:-4] if txt.name.lower().endswith(".txt") else txt.stem
    for lang in LANGS:
        p = txt.with_name("%s.%s.txt" % (stem, lang))
        out[lang] = p if p.is_file() else None
    return out


def _pdf_probe(path: Path) -> tuple[bool | None, str]:
    try:
        try:
            import pymupdf
        except Exception:                                    # noqa: BLE001
            import fitz as pymupdf                       # type: ignore
        doc = pymupdf.open(str(path))
        txt = doc[0].get_text() if doc.page_count else ""
        doc.close()
        return True, txt
    except Exception as e:                                   # noqa: BLE001
        return None, "pdf_probe_error: %s" % e


def check_item(item: dict, data_dir: Path, gold: dict | None,
               hash_pdf: bool = True, probe_pdf: bool = False) -> dict:
    arts = _artifacts(item, data_dir)
    findings = []
    vals = {}
    json_doc = _read_json(arts["json"])
    vals["json"] = json_doc or {}
    electrical = ((json_doc or {}).get("specs") or {}).get("electrical") or []
    package = ((json_doc or {}).get("specs") or {}).get("package") or {}
    pins = (json_doc or {}).get("pin_configuration") or []

    # ---------------- r1 身份与来源
    if not arts["pdf"]:
        _add(findings, SEV_FAIL, "r1", "PDF_MISSING", "pdf_path 无法解析到文件")
    else:
        try:
            with arts["pdf"].open("rb") as f:
                head = f.read(5)
        except Exception:                                    # noqa: BLE001
            head = b""
        if not head.startswith(IMG_MAGIC):
            _add(findings, SEV_FAIL, "r1", "PDF_MAGIC", "PDF 文件头不是 %PDF")
        if hash_pdf:
            actual = _sha256(arts["pdf"])
            expected = (item.get("pdf_sha256") or "").lower()
            vals["pdf_sha256_actual"] = actual
            if expected and actual != expected:
                _add(findings, SEV_FAIL, "r1", "PDF_SHA_MISMATCH",
                     "item.pdf_sha256=%s，实际=%s" % (expected[:12], actual[:12]))
            elif not expected:
                _add(findings, SEV_WARN, "r1", "PDF_SHA_MISSING", "item 未记录 pdf_sha256")
    if not arts["json"]:
        _add(findings, SEV_FAIL, "r1", "JSON_MISSING", "json_path 无法解析到文件")
    if json_doc is None:
        _add(findings, SEV_FAIL, "r1", "JSON_PARSE", "JSON 无法解析")
    elif json_doc:
        jmpn = str(((json_doc.get("basic_info") or {}).get("mpn")) or "")
        if not jmpn:
            _add(findings, SEV_FAIL, "r1", "MPN_MISSING", "basic_info.mpn 为空")
        elif _norm_mpn(jmpn) != _norm_mpn(item["mpn"]):
            if _family_inherited(item["mpn"], jmpn):
                _add(findings, SEV_WARN, "r1", "MPN_FAMILY_INHERITED",
                     "EVM/变体继承 JSON mpn=%s；item mpn=%s" % (jmpn, item["mpn"]))
            else:
                _add(findings, SEV_FAIL, "r1", "MPN_MISMATCH",
                     "JSON mpn=%s，item mpn=%s" % (jmpn, item["mpn"]))
    if not (item.get("brand") or "").strip():
        _add(findings, SEV_WARN, "r1", "BRAND_MISSING", "品牌为空")
    if probe_pdf and arts["pdf"]:
        ok, txt = _pdf_probe(arts["pdf"])
        if ok is None:
            _add(findings, SEV_WARN, "r1", "PDF_PROBE_ERROR", txt)
        else:
            needle = _norm_mpn(str(item["mpn"]).split("/")[0])
            if needle and needle not in _norm_mpn(txt):
                _add(findings, SEV_WARN, "r1", "PDF_TEXT_MPN_NOT_FOUND",
                     "PDF 首页文本未出现型号 %s（可能为家族/系列手册）" % item["mpn"])

    # ---------------- r2 结构与产物
    for key, label in (("txt", "英文详情页"), ("seo", "SEO")):
        if not arts[key]:
            _add(findings, SEV_FAIL, "r2", "ART_%s_MISSING" % key.upper(),
                 "%s 产物缺失" % label)
    for key, label in (("symbol", "三视图"), ("alt_json", "替代料 JSON"),
                       ("alt_html", "替代料 HTML")):
        if not arts[key]:
            _add(findings, SEV_WARN, "r2", "ART_%s_MISSING" % key.upper(),
                 "%s 为可选产物，缺失" % label)
    langs = _lang_files(arts["txt"])
    for lang, p in langs.items():
        if not p:
            _add(findings, SEV_WARN, "r2", "LANG_%s_MISSING" % lang.upper(),
                 "%s 语言产物缺失" % lang)
    if not isinstance(json_doc, dict) or not json_doc:
        pass
    else:
        if not isinstance(json_doc.get("specs"), dict):
            _add(findings, SEV_FAIL, "r2", "SPECS_MISSING", "specs 不是对象")
        if not electrical:
            _add(findings, SEV_FAIL, "r2", "ELECTRICAL_EMPTY", "specs.electrical 为空")
        if not (package.get("type") or "").strip():
            _add(findings, SEV_WARN, "r2", "PACKAGE_TYPE_MISSING", "package.type 为空")
        try:
            pin_count = int(package.get("pins") or 0)
        except (TypeError, ValueError):
            pin_count = 0
        if pin_count <= 0:
            _add(findings, SEV_WARN, "r2", "PACKAGE_PINS_MISSING", "package.pins 非正数")
        if not pins:
            _add(findings, SEV_WARN, "r2", "PIN_CONFIG_EMPTY", "pin_configuration 为空")
        elif pin_count and len(pins) != pin_count:
            _add(findings, SEV_WARN, "r2", "PIN_COUNT_MISMATCH",
                 "pin_configuration=%d，package.pins=%d" % (len(pins), pin_count))
        ml = json_doc.get("multi_language") or {}
        missing_ml = [x for x in LANGS if not ml.get(x)]
        if missing_ml:
            _add(findings, SEV_WARN, "r2", "MULTILANG_IN_JSON_MISSING",
                 "JSON multi_language 缺 %s" % ",".join(missing_ml))
        if not (json_doc.get("seo") or {}):
            _add(findings, SEV_WARN, "r2", "SEO_IN_JSON_EMPTY", "JSON seo 为空")

    # ---------------- r3 字段语义（机器）
    # 哨兵口径统一走 `qc/sentinels.py`（单一事实源）；独立脚本场景下导入失败
    # 时退回内联等价定义，避免整件 QC 因为少个模块直接崩。
    try:
        from qc import sentinels as _SENT                     # noqa: PLC0415
    except Exception:                                        # noqa: BLE001
        class _SENT:                                         # type: ignore[no-redef]
            @staticmethod
            def is_blank(v):
                return str(v or "").strip().lower() in {
                    "not_specified", "unspecified", "unknown", "n/a", "na",
                    "none", "null", "-", "—", "--", ""}

    # 「Features 误入 electrical」检测：按可测量特征判，不用关键词
    # （关键词版在 `Chip enable access time | 5 | ns` 上必假阳）。
    try:
        from qc import electrical_classify as _CLS           # noqa: PLC0415
    except Exception:                                        # noqa: BLE001
        class _CLS:                                          # type: ignore[no-redef]
            ALARM_CLASSES = ()

            @staticmethod
            def classify_electrical_row(row):
                return "INSUFFICIENT_EVIDENCE"

    bad_rows = 0
    unit_missing = 0
    not_spec_rows = 0
    feature_rows = 0
    feature_examples: list[str] = []
    for e in electrical:
        if not isinstance(e, dict):
            bad_rows += 1
            continue
        val = str(e.get("value") or "").strip()
        # `not_specified` 是「原表无此格」的明确降级（fix_elec_shape 也在生产它），
        # 不是缺值：不计坏行，否则下游会反复重试、把净改善吃回去。
        if _SENT.is_blank(val):
            if val.lower() == "not_specified":
                not_spec_rows += 1
            continue
        if not (str(e.get("name") or "").strip() and val):
            bad_rows += 1
        cls = _CLS.classify_electrical_row(e)
        if cls in _CLS.ALARM_CLASSES:
            feature_rows += 1
            if len(feature_examples) < 3:
                feature_examples.append(f"{str(e.get('name') or '')[:26]}（{cls}）")
        if not (e.get("unit") or "").strip():
            unit_missing += 1
    if unit_missing:
        _add(findings, SEV_WARN, "r3", "UNIT_MISSING",
             "%d/%d 行未填单位" % (unit_missing, len(electrical)))
    if bad_rows:
        _add(findings, SEV_FAIL if bad_rows > max(2, len(electrical) // 5) else SEV_WARN,
             "r3", "ELECTRICAL_ROW_BAD", "%d/%d 行缺 name/value" % (bad_rows, len(electrical)))
    if not_spec_rows:
        # 单独计数留证据，不算坏行
        _add(findings, SEV_WARN, "r3", "ELECTRICAL_NOT_SPECIFIED",
             "%d/%d 行原表无值（not_specified，非缺陷）"
             % (not_spec_rows, len(electrical)))
    if feature_rows:
        # v2 dry-run 实证：DAC37J84IAAV 有 10 处 Features 条目被误当电气行
        _add(findings, SEV_WARN if feature_rows <= 2 else SEV_FAIL,
             "r3", "ELECTRICAL_LIKE_FEATURE",
             "%d/%d 行疑似来自 Features/描述性章节：%s"
             % (feature_rows, len(electrical), "；".join(feature_examples)))
    if arts["txt"]:
        try:
            txt_en = arts["txt"].read_text(encoding="utf-8", errors="replace")
        except Exception:                                    # noqa: BLE001
            txt_en = ""
        if _norm_mpn(item["mpn"]) not in _norm_mpn(txt_en):
            _add(findings, SEV_WARN, "r3", "TXT_MPN_MISSING", "英文详情页未出现型号")
        for lang, p in langs.items():
            if p:
                try:
                    t = p.read_text(encoding="utf-8", errors="replace")
                except Exception:                            # noqa: BLE001
                    t = ""
                if _norm_mpn(item["mpn"]) not in _norm_mpn(t):
                    _add(findings, SEV_WARN, "r3", "LANG_MPN_MISSING_%s" % lang.upper(),
                         "%s 语言页未出现型号" % lang)
    for key in ("seo", "alt_json"):
        if arts[key] and _read_json(arts[key]) is None:
            _add(findings, SEV_FAIL, "r3", "JSON_BAD_%s" % key.upper(),
                 "%s 无法解析" % key)
    if arts["symbol"] and arts["symbol"].stat().st_size == 0:
        _add(findings, SEV_FAIL, "r3", "SYMBOL_EMPTY", "三视图文件为空")

    # ---------------- r4 facts vs Gold（只读）
    if gold:
        gstatus = gold.get("status") or ""
        for f in gold.get("fields") or []:
            exp = str(f.get("expected") or "")
            if exp.strip().lower() == "not_specified":
                continue
            got = _resolve_facts(json_doc or {}, f["field_path"])
            if got is None:
                _add(findings, SEV_WARN, "r4", "GOLD_FIELD_MISSING",
                     "%s 在 facts 中缺失" % f["field_path"])
            elif str(got).strip() != exp.strip():
                sev = SEV_FAIL if gstatus == "frozen" else SEV_WARN
                _add(findings, sev, "r4", "GOLD_FIELD_MISMATCH",
                     "%s facts=%r Gold=%r" % (f["field_path"], str(got), exp))
    else:
        _add(findings, "INFO", "r4", "GOLD_NOT_APPLICABLE", "该型号无 Gold，不做真值对照")

    fail = [f for f in findings if f["severity"] == SEV_FAIL]
    warn = [f for f in findings if f["severity"] == SEV_WARN]
    status = "FAIL" if fail else ("WARN" if warn else "PASS")
    return {
        "item_id": item["id"],
        "mpn": item["mpn"],
        "brand": item.get("brand") or "",
        "status": status,
        "fields_total": len(electrical) + 2,
        "electrical": len(electrical),
        "findings": findings,
        "fail_count": len(fail),
        "warn_count": len(warn),
        "pdf_sha256": vals.get("pdf_sha256_actual") or item.get("pdf_sha256") or "",
        "gold_id": gold["id"] if gold else 0,
        "gold_status": gold.get("status") if gold else "",
        "artifacts": {k: (str(v) if v else "") for k, v in arts.items()},
        "langs": {k: (str(v) if v else "") for k, v in langs.items()},
    }


# ---------------------------------------------------------------- 批次聚合
def _stage_status(items: list, stage: str) -> dict:
    fails = sum(1 for it in items for f in it["findings"]
                if f["stage"] == stage and f["severity"] == SEV_FAIL)
    warns = sum(1 for it in items for f in it["findings"]
                if f["stage"] == stage and f["severity"] == SEV_WARN)
    applicable = sum(1 for it in items
                     if any(f["stage"] == stage and f["code"] != "GOLD_NOT_APPLICABLE"
                            for f in it["findings"]))
    if stage == "r4":
        applicable = sum(1 for it in items if it["gold_id"])
    if stage == "r4" and not any(it["gold_id"] for it in items):
        status = "NOT_APPLICABLE"
    elif fails:
        status = "FAIL"
    elif stage == "r4" and not any(it["gold_status"] == "frozen" for it in items):
        status = "NOT_CHECKED"
    else:
        status = "PASS"
    return {"id": stage, "name": STAGE_NAMES[stage], "status": status,
            "fail": fails, "warn": warns, "applicable_items": applicable}


def _layers(items: list, zip_ok: bool) -> dict:
    l1 = "PASS" if all(it["status"] != "FAIL" for it in items) and zip_ok else "FAIL"
    l2_fail = any(f["stage"] in ("r1", "r2", "r4") and f["severity"] == SEV_FAIL
                  for it in items for f in it["findings"])
    l2 = "FAIL" if l2_fail else "PASS"
    l4 = "PASS" if zip_ok else "FAIL"
    return {
        "L1": {"status": l1, "check": "ZIP/产物完整性",
               "evidence": "items=%d zip_ok=%s" % (len(items), zip_ok)},
        "L2": {"status": l2, "check": "身份/结构/证据（机器）",
               "evidence": "r1/r2/r4 机器检查；无人工/无 Gold 时不外推"},
        "L3": {"status": "NOT_CHECKED", "check": "业务语义（人工）",
               "evidence": "自动 r3 结构检查完成；人工语义/母语/视觉未执行"},
        "L4": {"status": l4, "check": "包读回/回归（机器）",
               "evidence": "ZIP 清单/大小/JSON 回读；全量业务回归未做"},
    }


def _gates(layers: dict) -> dict:
    return {
        "PACKAGE_PASS": {"status": layers["L1"]["status"],
                         "basis": "ZIP/产物完整性（机器）"},
        "PROVENANCE_PASS": {"status": layers["L2"]["status"],
                            "basis": "MPN/PDF/SHA/JSON 身份与结构（机器）"},
        "DATA_SEMANTICS_PASS": {"status": "NOT_CHECKED",
                                "basis": "人工业务语义/母语/视觉未执行"},
        "DOWNSTREAM_PASS": {"status": layers["L4"]["status"],
                            "basis": "包读回/JSON 解析/清单（机器）"},
        "RELEASE_APPROVED": {"status": "FAIL", "approved": False,
                             "basis": "自动 QC 不等于发布批准；无人工签字"},
    }


def _manifest_csv(items: list) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["mpn", "item_id", "auto_qc", "fields_total", "electrical",
                "findings", "warnings", "gold_id", "gold_status", "pdf_sha256",
                "quality_warning"])
    for it in items:
        w.writerow([it["mpn"], it["item_id"], it["status"], it["fields_total"],
                    it["electrical"], it["fail_count"], it["warn_count"],
                    it["gold_id"], it["gold_status"], it["pdf_sha256"],
                    "" if not it["fail_count"] else "auto_qc_fail"])
    return buf.getvalue()


def _public_items(items: list) -> list:
    """交付包/audit 中不暴露服务器绝对路径。"""
    out = []
    for it in items:
        x = dict(it)
        x["artifacts"] = {k: (Path(v).name if v else "")
                           for k, v in (it.get("artifacts") or {}).items()}
        x["langs"] = {k: (Path(v).name if v else "")
                      for k, v in (it.get("langs") or {}).items()}
        out.append(x)
    return out


def _zip_assets(tmp: Path, batch_id: str, items: list, include_pdf: bool) -> tuple[Path, dict]:
    zip_path = tmp / (batch_id + ".zip")
    expected = []
    with zipfile.ZipFile(zip_path, "w", allowZip64=True) as z:
        z.writestr("manifest.csv", _manifest_csv(items), zipfile.ZIP_DEFLATED)
        z.writestr("README.md", _readme(batch_id, items), zipfile.ZIP_DEFLATED)
        z.writestr("qc_items.json",
                   json.dumps(_public_items(items), ensure_ascii=False, indent=2),
                   zipfile.ZIP_DEFLATED)
        for it in items:
            safe = _safe_name(it["mpn"])
            a = it["artifacts"]
            mapping = [
                ("json", safe + "/" + safe + ".json", zipfile.ZIP_DEFLATED),
                ("txt", safe + "/" + safe + ".txt", zipfile.ZIP_DEFLATED),
                ("seo", safe + "/" + safe + ".seo.json", zipfile.ZIP_DEFLATED),
                ("alt_json", safe + "/" + safe + ".alts.json", zipfile.ZIP_DEFLATED),
                ("alt_html", safe + "/" + safe + ".alts.html", zipfile.ZIP_DEFLATED),
                ("symbol", safe + "/" + safe + ".symbols.html", zipfile.ZIP_DEFLATED),
            ]
            if include_pdf:
                mapping.insert(0, ("pdf", safe + "/" + safe + ".pdf",
                                   zipfile.ZIP_STORED))
            for key, arc, comp in mapping:
                src = a.get(key)
                if not src:
                    continue
                z.write(src, arc, compress_type=comp)
                expected.append((arc, Path(src).stat().st_size))
            for lang, lp in (it.get("langs") or {}).items():
                if not lp:
                    continue
                arc = safe + "/" + safe + "." + lang + ".txt"
                z.write(lp, arc, compress_type=zipfile.ZIP_DEFLATED)
                expected.append((arc, Path(lp).stat().st_size))
            prov = {
                "mpn": it["mpn"], "item_id": it["item_id"],
                "pdf_sha256": it["pdf_sha256"], "gold_id": it["gold_id"],
                "gold_status": it["gold_status"], "auto_qc": it["status"],
                "batch_id": batch_id, "generated_at": _now(),
                "note": "自动 QC 留痕；非 Gold/人工发布批准",
            }
            z.writestr(safe + "/" + safe + ".provenance.json",
                       json.dumps(prov, ensure_ascii=False, indent=2),
                       zipfile.ZIP_DEFLATED)
            expected.append((safe + "/" + safe + ".provenance.json", None))
    return zip_path, {"expected": expected}


def _verify_zip(zip_path: Path, items: list, expected: dict) -> dict:
    problems = []
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = set(z.namelist())
            for arc, size in expected.get("expected") or []:
                if arc not in names:
                    problems.append("missing:%s" % arc)
                elif size is not None and z.getinfo(arc).file_size != size:
                    problems.append("size:%s" % arc)
            for n in names:
                if n.endswith(".json"):
                    try:
                        json.loads(z.read(n).decode("utf-8"))
                    except Exception:                        # noqa: BLE001
                        problems.append("bad_json:%s" % n)
            rows = z.read("manifest.csv").decode("utf-8").splitlines()
            if len(rows) != len(items) + 1:
                problems.append("manifest_rows:%d" % (len(rows) - 1))
            if "README.md" not in names:
                problems.append("missing:README.md")
    except Exception as e:                                   # noqa: BLE001
        problems.append("zip_error:%s" % e)
    return {"ok": not problems, "problems": problems[:50],
            "entry_count": len(names) if 'names' in locals() else 0}


def _readme(batch_id: str, items: list) -> str:
    return """# %s · 自动 QC 交付包

本包由 `qc/auto_qc.py` 按 **30 件/批** 自动生成，包含 JSON、英文/日/韩/德/西详情页、
SEO、替代料、三视图与 PDF（可选）。每件附带 `provenance.json`。

- 机器 QC 结果见批次目录的 `核验报告.md` 与 `qc_quality_audit.json`。
- **自动 QC ≠ 发布批准**：未做人工业务语义、母语审校与视觉验收；
  无 Gold frozen 的型号不做真值外推。
- 清单：`manifest.csv`（%d 行），逐件状态 `PASS/WARN/FAIL`。
""" % (batch_id, len(items))


def _render_report(batch_id: str, items: list, stages: list, layers: dict,
                   gates: dict, auto: dict, zip_info: dict) -> str:
    lines = ["# %s · 自动 QC 核验报告（r1–r6）" % batch_id, "",
             "生成时间：%s  " % _now(),
             "范围：**%d 件**，机器自动 QC；不含人工语义裁决/母语审校/视觉验收。  "
             % len(items),
             "边界：自动 QC PASS **不等于**发布批准；`RELEASE_APPROVED=false`。", "",
             "## 0. 结论", "",
             "| 项 | 值 |", "|---|---|",
             "| 自动 QC | **%s** |" % auto["status"],
             "| 逐件 | PASS %d / WARN %d / FAIL %d |"
             % (auto["pass_items"], auto["warn_items"], auto["fail_items"]),
             "| ZIP | `%s`（%d B，SHA `%s`） |"
             % (zip_info.get("name", ""), zip_info.get("size", 0),
                (zip_info.get("sha256") or "")[:16]),
             "| r5 读回 | %s |" % ("PASS" if zip_info.get("verify_ok") else "FAIL"),
             "| 发布批准 | **否** |", "",
             "## 1. r1–r6 分阶段", "",
             "| 阶段 | 名称 | 状态 | FAIL | WARN | 可判件 |",
             "|---|---|---|---:|---:|---:|"]
    for st in stages:
        lines.append("| %s | %s | **%s** | %d | %d | %d |"
                     % (st["id"], st["name"], st["status"], st["fail"],
                        st["warn"], st["applicable_items"]))
    lines += ["", "## 2. L1–L4 与发布门禁", "",
              "| 层/门禁 | 状态 | 依据 |", "|---|---|---|"]
    for k in ("L1", "L2", "L3", "L4"):
        v = layers[k]
        lines.append("| %s | **%s** | %s |" % (k, v["status"], v["check"]))
    for k in ("PACKAGE_PASS", "PROVENANCE_PASS", "DATA_SEMANTICS_PASS",
              "DOWNSTREAM_PASS", "RELEASE_APPROVED"):
        v = gates[k]
        lines.append("| %s | **%s** | %s |" % (k, v["status"], v["basis"]))
    lines += ["", "## 3. 逐件结果", "",
              "| MPN | 状态 | 字段 | FAIL | WARN | Gold |", "|---|---|---:|---:|---:|---|"]
    for it in items:
        lines.append("| %s | %s | %d | %d | %d | %s |"
                     % (it["mpn"], it["status"], it["fields_total"],
                        it["fail_count"], it["warn_count"],
                        ("#%s/%s" % (it["gold_id"], it["gold_status"]))
                        if it["gold_id"] else "—"))
    bad = [it for it in items if it["status"] != "PASS"]
    lines += ["", "### 3.1 需要关注的件（%d）" % len(bad), ""]
    if not bad:
        lines.append("无。")
    else:
        lines += ["| MPN | 状态 | 代码 | 说明 |", "|---|---|---|---|"]
        for it in bad:
            for f in it["findings"]:
                if f["severity"] == "INFO":
                    continue
                lines.append("| %s | %s | `%s` | %s |"
                             % (it["mpn"], f["severity"], f["code"],
                                f["detail"].replace("|", "\\|")))
    lines += ["", "## 4. 复现", "",
              "```bash", "python qc/auto_qc.py --data-dir /app/data --out-dir /app/data/qc \\",
              "  --run-id %s --batch-size 30"
              % (batch_id.split("-")[1] if "-" in batch_id else ""),
              "```", "",
              "自动 QC 只读生成；不修改 facts / Gold / item。", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------- 批次执行
def _batch_id(run_id: str, idx: int) -> str:
    return "qc30-%s-%04d" % (run_id, idx)


def _plan(items: list, run_id: str, batch_size: int) -> dict:
    batches = []
    for i in range(0, len(items), batch_size):
        chunk = items[i:i + batch_size]
        batches.append({"batch_id": _batch_id(run_id, len(batches) + 1),
                        "item_ids": [x["id"] for x in chunk]})
    return {"run_id": run_id, "created_at": _now(), "batch_size": batch_size,
            "total_items": len(items), "batches": batches}


def _write_atomic(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def run_batch(batch: dict, items: list, data_dir: Path, out_dir: Path,
              gold_map: dict, include_pdf: bool, hash_pdf: bool,
              pdf_probe: str) -> dict:
    batch_id = batch["batch_id"]
    staging = out_dir / "_staging"
    staging.mkdir(parents=True, exist_ok=True)
    tmp = staging / (batch_id + ".tmp")
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    final = out_dir / batch_id
    if final.exists():
        shutil.rmtree(final, ignore_errors=True)

    checked = []
    for n, it in enumerate(items):
        probe = pdf_probe == "all" or (pdf_probe == "sample" and n < 2)
        checked.append(check_item(it, data_dir, gold_map.get(it["mpn"]),
                                  hash_pdf=hash_pdf, probe_pdf=probe))

    stages = [_stage_status(checked, s) for s in ("r1", "r2", "r3", "r4")]
    zip_path, expected = _zip_assets(tmp, batch_id, checked, include_pdf)
    verify = _verify_zip(zip_path, checked, expected)
    stages.append({"id": "r5", "name": STAGE_NAMES["r5"],
                   "status": "PASS" if verify["ok"] else "FAIL",
                   "fail": 0 if verify["ok"] else len(verify["problems"]),
                   "warn": 0, "applicable_items": len(checked)})
    stages.append({"id": "r6", "name": STAGE_NAMES["r6"],
                   "status": "PASS" if verify["ok"] else "FAIL",
                   "fail": 0 if verify["ok"] else 1, "warn": 0,
                   "applicable_items": len(checked)})

    zip_sha = _sha256(zip_path)
    zip_size = zip_path.stat().st_size
    layers = _layers(checked, verify["ok"])
    gates = _gates(layers)
    pass_items = sum(1 for x in checked if x["status"] == "PASS")
    warn_items = sum(1 for x in checked if x["status"] == "WARN")
    fail_items = sum(1 for x in checked if x["status"] == "FAIL")
    auto = {"status": "PASS" if fail_items == 0 and verify["ok"] else "FAIL",
            "mode": "machine-only", "total": len(checked),
            "pass_items": pass_items, "warn_items": warn_items,
            "fail_items": fail_items,
            "stages": {s["id"]: s["status"] for s in stages}}
    zip_info = {"name": zip_path.name, "size": zip_size, "sha256": zip_sha,
                "verify_ok": verify["ok"], "problems": verify["problems"],
                "entry_count": verify["entry_count"]}
    audit = {
        "generated_at": _now(),
        "package": "%s · 自动 QC 30 件/批" % batch_id,
        "batch_id": batch_id,
        "audit_version": 1,
        "auto_qc": auto,
        "summary": {"total": len(checked), "PASS": pass_items,
                    "WARN": warn_items, "FAIL": fail_items},
        "layers": layers,
        "release_gates": gates,
        "release_approved": False,
        "checks": stages,
        "items": _public_items(checked),
        "details": {"zip": zip_path.name, "zip_size": zip_size,
                    "zip_sha256": zip_sha, "verify": verify,
                    "item_count": len(checked), "include_pdf": include_pdf,
                    "scope": [x["mpn"] for x in checked]},
    }
    report = _render_report(batch_id, checked, stages, layers, gates, auto,
                            zip_info)
    (tmp / "manifest.csv").write_text(_manifest_csv(checked), encoding="utf-8")
    (tmp / "qc_quality_audit.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (tmp / "核验报告.md").write_text(report, encoding="utf-8")
    shutil.move(str(tmp), str(final))
    return {"batch_id": batch_id, "auto": auto, "zip": zip_info,
            "dir": str(final)}


def _progress(out_dir: Path, run_id: str, total: int, done: int,
              last: str, errors: list) -> None:
    p = out_dir / "_staging" / ("progress-%s.json" % run_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    _write_atomic(p, json.dumps({
        "run_id": run_id, "total_batches": total, "done_batches": done,
        "last_batch": last, "updated_at": _now(), "errors": errors[-20:],
    }, ensure_ascii=False, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="30 件/批自动 r1–r6 QC")
    ap.add_argument("--db", default=str(DEFAULT_DATA / "workbench.sqlite3"))
    ap.add_argument("--data-dir", default=str(DEFAULT_DATA))
    ap.add_argument("--out-dir", default=str(DEFAULT_DATA / "qc"))
    ap.add_argument("--run-id", default=datetime.date.today().strftime("%Y%m%d"))
    ap.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 个待处理批次")
    ap.add_argument("--start", type=int, default=1, help="从第 N 批开始")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--no-pdf", action="store_true", help="交付 ZIP 不含 PDF（冒烟用）")
    ap.add_argument("--no-hash-pdf", action="store_true")
    ap.add_argument("--pdf-probe", choices=("all", "sample", "none"), default="sample")
    args = ap.parse_args(argv)
    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    staging = out_dir / "_staging"
    staging.mkdir(parents=True, exist_ok=True)
    db = ReadOnlyDB(Path(args.db))
    items = _done_items(db)
    plan_path = staging / ("plan-%s.json" % args.run_id)
    if plan_path.is_file():
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
    else:
        plan = _plan(items, args.run_id, args.batch_size)
        _write_atomic(plan_path, json.dumps(plan, ensure_ascii=False, indent=2))
    by_id = {it["id"]: it for it in items}
    gold_map = _gold_map(db)
    batches = plan["batches"]
    total = len(batches)
    todo = [b for b in batches if args.start <= int(b["batch_id"].rsplit("-", 1)[-1])]
    if args.limit:
        todo = todo[:args.limit]
    errors = []
    done = 0
    started = time.time()
    print("auto_qc start run=%s items=%d batches=%d pending=%d" % (
        args.run_id, plan["total_items"], total, len(todo)), flush=True)
    for b in todo:
        final = out_dir / b["batch_id"]
        if final.is_dir() and not args.force:
            if ((final / "manifest.csv").is_file()
                    and (final / "核验报告.md").is_file()
                    and (final / "qc_quality_audit.json").is_file()
                    and list(final.glob("*.zip"))):
                done += 1
                continue
        try:
            items_b = [by_id[i] for i in b["item_ids"] if i in by_id]
            if not items_b:
                raise RuntimeError("批次内没有可读 item")
            res = run_batch(b, items_b, data_dir, out_dir, gold_map,
                            include_pdf=not args.no_pdf,
                            hash_pdf=not args.no_hash_pdf,
                            pdf_probe=args.pdf_probe)
            done += 1
            print("[%d/%d] %s auto=%s zip=%.2fMB verify=%s" % (
                done, len(todo), res["batch_id"], res["auto"]["status"],
                res["zip"]["size"] / 1048576.0,
                "OK" if res["zip"]["verify_ok"] else "FAIL"), flush=True)
        except Exception as e:                               # noqa: BLE001
            errors.append({"batch_id": b["batch_id"], "error": str(e)[:500]})
            print("[ERR] %s %s" % (b["batch_id"], e), flush=True)
        _progress(out_dir, args.run_id, len(todo), done,
                  b["batch_id"], errors)
    _progress(out_dir, args.run_id, len(todo), done,
              todo[-1]["batch_id"] if todo else "", errors)
    print("auto_qc done=%d/%d errors=%d elapsed=%.1fs" % (
        done, len(todo), len(errors), time.time() - started), flush=True)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
