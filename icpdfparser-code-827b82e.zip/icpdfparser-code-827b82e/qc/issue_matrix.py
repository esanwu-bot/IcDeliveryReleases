"""全量自动 QC 问题交叉矩阵与根因分组（只读；不修改生产 facts/Gold/item）。

输入：`data/qc/qc30-<run>-*/qc_quality_audit.json`（auto_qc 产物）+ 只读 SQLite + facts JSON。
输出：
  * `auto_qc_issue_matrix.csv`  逐 MPN 一行（全量 13,504）
  * `auto_qc_issue_matrix.json` 汇总 + 行数据 + 交叉矩阵
  * `auto_qc_issue_matrix.md`   人读报告（回答 P0/P1 问题与修复顺序）

根因分组是**建议分类**，不是自动改库结论；生产 facts 保持不动。
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import io
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = Path("/app/data") if Path("/app/data").is_dir() else ROOT / "data"

# EC 标题判据统一到 app/services/pdf_signals.py（唯一实现）。历史问题：本模块的
# `_pdf_has_ec` 只认 "electrical characteristics"，而 pdf_signals 还认
# "electrical specifications"，于是同一件在矩阵里是 NO、在分析包里是 YES
# （CC1070 三件就是这个差），两个数字永远对不上。
# 开关默认 1；置 0 可回退到旧词表，便于出问题时比对。
_USE_UNIFIED_EC = os.getenv("ICPDF_ISSUE_MATRIX_USE_UNIFIED_KEYWORD", "1") == "1"

# 评估板 EC 表口径不适用：EVAL 系列（ADC...EVAL/SQEVAL）与 `...-1.8EV` 这类后缀
# 都是评估板，其用户指南本来就没有 Electrical Characteristics 表，
# 落在 I 组（解析缺陷）是错的。
# 开关默认 1；置 0 可回退成「所有电气缺陷一律判 I/J」。
_EXCLUDE_BOARD_EC = os.getenv("ICPDF_ISSUE_MATRIX_BOARD_EXCLUDE_EC", "1") == "1"

try:
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from app.services.pdf_signals import signals as _unified_signals
except Exception:                                            # noqa: BLE001
    _unified_signals = None

CODES = ("MPN_MISMATCH", "PDF_SHA_MISMATCH", "ELECTRICAL_ROW_BAD", "ELECTRICAL_EMPTY")
FLAG = {
    "MPN_MISMATCH": "mpn_mismatch",
    "PDF_SHA_MISMATCH": "pdf_sha_mismatch",
    "ELECTRICAL_ROW_BAD": "electrical_row_bad",
    "ELECTRICAL_EMPTY": "electrical_empty",
}
BOARD_RE = re.compile(
    r"(EVM|EVK|PDK|DEMO|DEM-|EKK|EKT|EMK|ISK|BOOST|KIT|BOARD|CVAL|DYNO|PGMA|"
    r"REF|TIDA|XDS|LAUNCH|ADAPTER|SOCKET|CHRONOS|COMBOLED|FLINK|TESTER|ABP|"
    r"MSPAUD|SN1FLN|^DV\d|^\d{6,})", re.I)
REV_RE = re.compile(r"(?i)rev[._-]?([A-Za-z0-9]+)")


def _common_prefix_len(a: str, b: str) -> int:
    n = 0
    for x, y in zip(a or "", b or ""):
        if x != y:
            break
        n += 1
    return n


def _now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _base(raw: str) -> str:
    return (raw or "").replace("\\", "/").rsplit("/", 1)[-1]


def _norm(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", (s or "").upper())


def _resolve(raw: str, data_dir: Path, sub: str) -> Path | None:
    s = (raw or "").strip()
    if not s:
        return None
    p = Path(s)
    if p.is_file():
        return p
    q = Path(data_dir) / sub / _base(s)
    return q if q.is_file() else None


def _read_json(path: Path | None):
    if not path:
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                                        # noqa: BLE001
        return None


def _family(mpn: str) -> str:
    m = re.match(r"([A-Za-z]+)", mpn or "")
    if m and len(m.group(1)) >= 2:
        return m.group(1).upper()[:12]
    n = _norm(mpn)
    return n[:4] or "—"


def _classify(row: dict) -> tuple[str, str, str]:
    """返回 (primary_group, all_groups, fix_class/needs_rerun suggestion)。"""
    codes = set(row.get("fail_codes") or [])
    groups = []
    if "MPN_MISMATCH" in codes:
        itemn = _norm(row.get("mpn"))
        jsonn = _norm(row.get("json_mpn"))
        pdfn = _norm(row.get("pdf_name"))
        if _board_by_name(row.get("mpn") or ""):
            groups.append("A1_板卡/模块映射到组件 PDF（源关联/业务口径）")
        elif _common_prefix_len(itemn, jsonn) >= 6:
            groups.append("A2_可订购型号/封装变体（JSON 用基础型号）")
        elif jsonn and jsonn in pdfn and itemn and itemn not in pdfn:
            groups.append("A3_源 PDF 关联到其他型号")
        else:
            groups.append("A3_型号错配（可能 PDF/关联错误）")
    if "PDF_SHA_MISMATCH" in codes:
        fh = (row.get("facts_pdf_hash") or "").lower()
        db = (row.get("pdf_sha256_item") or "").lower()
        ac = (row.get("pdf_sha256_file") or "").lower()
        if fh and db and fh == db and db != ac:
            groups.append("E_PDF 文件被替换/版本漂移")
        elif fh and ac and fh == ac and db != ac:
            groups.append("F_DB SHA 元数据陈旧（文件/facts 一致）")
        elif fh and fh != db and fh != ac:
            groups.append("G_SHA 三方不一致")
        else:
            groups.append("H_facts 无来源哈希")
    # 电气表缺陷：评估板另有口径（用户指南本就没有 EC 表），不能算解析缺陷。
    # 判据必须「板 + 无 EC 表」两条同时成立：
    #   LM27402SQEVAL/NOPB、LM20145EVAL、LM10500SQ-1.0EV/NOPB —— 板且无 EC → K_（移出 I）；
    #   LM3671TL-1.8EV —— 名字像板，但 PDF 里确实有 EC 表（has_ec=YES），仍按解析缺陷处理。
    # 只按名字移出会把真缺陷藏起来，所以 has_ec 这一条不能省。
    board_ec = (_EXCLUDE_BOARD_EC and _board_by_name(row.get("mpn") or "")
                and not row.get("pdf_has_ec_text"))
    if "ELECTRICAL_ROW_BAD" in codes:
        groups.append("K_评估板（EC 表口径不适用）" if board_ec
                      else "I_解析结构缺陷（电气表行）")
    if "ELECTRICAL_EMPTY" in codes:
        if board_ec:
            groups.append("K_评估板（EC 表口径不适用）")
        else:
            groups.append("I_解析结构缺陷（电气表行）" if row.get("pdf_has_ec_text")
                          else "J_电气表缺失/解析未命中")
    if not groups:
        return "—", "", ""
    primary = sorted(groups)[0]
    if primary.startswith("A1_"):
        fix = "source_mapping_business_review"
    elif primary.startswith("A2_"):
        fix = "identity_normalization_or_source_review"
    elif primary.startswith("A3_"):
        fix = "source_pdf_recovery_or_human"
    elif primary.startswith(("I_", "J_")):
        fix = "parser_fix_then_rerun_item_batch"
    elif primary.startswith("K_"):
        fix = "board_scope_no_ec_requirement"
    elif primary.startswith("F_"):
        fix = "deterministic_metadata_fix_after_review"
    elif primary.startswith("E_"):
        fix = "source_pdf_replacement_verify"
    else:
        fix = "human_evidence_review"
    return primary, ";".join(groups), fix


def _pdf_has_ec(path: Path | None) -> bool | None:
    """PDF 是否含 EC 表标题。真值 = pdf_signals.signals()["pdf_has_ec_text"]。

    统一到一处实现是硬要求：两套词表并存时，矩阵的 pdf_has_ec_text 与分析包的
    pdf_signal 会对同一件给出相反的答案（CC1070 三件：NO vs YES）。
    """
    if not path or not path.is_file():
        return None
    if _USE_UNIFIED_EC and _unified_signals is not None:
        sig = _unified_signals(path)
        if not sig:
            return None
        v = str(sig.get("pdf_has_ec_text") or "").upper()
        if v == "YES":
            return True
        if v == "NO":
            return False
        return None                                          # PDF_TOO_LARGE / 不可读
    try:
        try:
            import pymupdf
        except Exception:                                    # noqa: BLE001
            import fitz as pymupdf                       # type: ignore
        doc = pymupdf.open(str(path))
        txt = "\n".join(doc[i].get_text() for i in range(doc.page_count)).lower()
        doc.close()
        return "electrical characteristics" in txt
    except Exception:                                        # noqa: BLE001
        return None


_BOARD_EV_RE = re.compile(r"(EVAL|(?<=\d)EV(?=/|$))", re.I)


def _board_by_name(mpn: str) -> bool:
    """按型号名判评估板/套件。

    BOARD_RE 覆盖 EVM/EVK/PDK/…；这里补两类 TI 常见写法：
      * `LM27402SQEVAL/NOPB`、`ADC128S102EVAL` —— EVAL 后缀；
      * `LM10500SQ-1.0EV/NOPB` —— `-1.8EV` 这类电压后缀（EV 前面是数字、后面是 / 或结尾）。
    """
    s = mpn or ""
    return bool(BOARD_RE.search(s) or _BOARD_EV_RE.search(s))


class DB:
    def __init__(self, path: Path):
        self.c = sqlite3.connect("file:%s?mode=ro" % Path(path).as_posix(), uri=True)
        self.c.row_factory = sqlite3.Row

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args)]


def _load_audits(qc_dir: Path, run_id: str) -> list:
    out = []
    for f in sorted(qc_dir.glob("qc30-%s-*/qc_quality_audit.json" % run_id)):
        try:
            out.append(json.loads(f.read_text(encoding="utf-8")))
        except Exception:                                    # noqa: BLE001
            continue
    return out


def build_matrix(audits: list, items: dict, gold: dict, data_dir: Path,
                 probe_pdf: bool = True) -> dict:
    rows = []
    for audit in audits:
        batch = audit.get("batch_id") or ""
        for it in audit.get("items") or []:
            iid = it.get("item_id")
            m = items.get(iid) or {}
            fail_codes = [x["code"] for x in it.get("findings") or []
                          if x["severity"] == "FAIL"]
            warn_codes = [x["code"] for x in it.get("findings") or []
                          if x["severity"] == "WARN"]
            json_mpn = ""
            for x in it.get("findings") or []:
                if x.get("code") == "MPN_MISMATCH":
                    mt = re.search(r"JSON mpn=(.+?)，item mpn=", x.get("detail") or "")
                    if mt:
                        json_mpn = mt.group(1).strip()
                        break
            facts_path = _resolve(m.get("json_path"), data_dir, "parsed")
            facts = _read_json(facts_path) or {}
            fmeta = facts.get("metadata") or {}
            pdf_path = _resolve(m.get("pdf_path"), data_dir, "pdfs")
            pdf_name = _base(m.get("pdf_path")) or (it.get("artifacts") or {}).get("pdf") or ""
            rev = ""
            mt = REV_RE.search(pdf_name or "")
            if mt:
                rev = mt.group(1)
            row = {
                "mpn": it.get("mpn") or m.get("mpn") or "",
                "item_id": iid,
                "batch_id": batch,
                "brand": it.get("brand") or m.get("brand") or "",
                "provider": m.get("provider") or "",
                "status": it.get("status") or "",
                "fail_count": it.get("fail_count") or 0,
                "warn_count": it.get("warn_count") or 0,
                "fail_codes": sorted(set(fail_codes)),
                "warn_codes": sorted(set(warn_codes)),
                "json_mpn": json_mpn,
                "pdf_name": pdf_name,
                "pdf_rev": rev,
                "pdf_sha256_item": (m.get("pdf_sha256") or "").lower(),
                "pdf_sha256_file": (it.get("pdf_sha256") or "").lower(),
                "facts_pdf_hash": (fmeta.get("pdf_hash") or "").lower(),
                "facts_parse_timestamp": fmeta.get("parse_timestamp") or "",
                "facts_model": fmeta.get("model_version") or "",
                "facts_r4_patch": bool(fmeta.get("r4_patch")),
                "gold_id": it.get("gold_id") or 0,
                "gold_status": it.get("gold_status") or "",
                "pdf_has_ec_text": None,
            }
            for c in CODES:
                row[FLAG[c]] = c in fail_codes
            if (row["electrical_empty"] or row["electrical_row_bad"]) and probe_pdf:
                row["pdf_has_ec_text"] = _pdf_has_ec(pdf_path)
            primary, allg, fix = _classify(row)
            row["root_cause_group"] = primary
            row["root_cause_groups"] = allg
            row["fix_class"] = fix
            rows.append(row)
    return summarize(rows, audits)


def summarize(rows: list, audits: list) -> dict:
    code_counts = {c: sum(1 for r in rows if r[FLAG[c]]) for c in CODES}
    pair = {}
    for i, a in enumerate(CODES):
        for b in CODES[i + 1:]:
            pair["%s+%s" % (a, b)] = sum(
                1 for r in rows if r[FLAG[a]] and r[FLAG[b]])
    groups = collections.Counter(r["root_cause_group"] for r in rows
                                 if r["root_cause_group"] != "—")
    fixes = collections.Counter(r["fix_class"] for r in rows
                                if r["fix_class"])
    brands = collections.Counter(r["brand"] or "—" for r in rows
                                 if r["status"] == "FAIL")
    families = collections.Counter(_family(r["mpn"]) for r in rows
                                   if r["status"] == "FAIL")
    revisions = collections.Counter((r["pdf_rev"] or "—") for r in rows
                                    if r["status"] == "FAIL")
    batch_fail = collections.Counter(r["batch_id"] for r in rows
                                     if r["status"] == "FAIL")
    status = collections.Counter(r["status"] for r in rows)
    issue_items = [r for r in rows if r["status"] == "FAIL"]
    combined = collections.Counter(
        "+".join(r["fail_codes"]) if r["fail_codes"] else "—" for r in issue_items)
    return {
        "generated_at": _now(),
        "scope": {"batches": len(audits), "items": len(rows),
                  "issue_items": len(issue_items)},
        "status": dict(status),
        "code_counts": code_counts,
        "pairwise": pair,
        "group_counts": dict(groups.most_common()),
        "fix_class_counts": dict(fixes.most_common()),
        "brand_top": dict(brands.most_common(15)),
        "family_top": dict(families.most_common(15)),
        "revision_top": dict(revisions.most_common(10)),
        "batch_fail_top": dict(batch_fail.most_common(20)),
        "batches_with_fail": len(batch_fail),
        "fail_combinations": dict(combined.most_common()),
        "rows": rows,
    }


def _csv_text(rows: list) -> str:
    cols = ["mpn", "item_id", "batch_id", "brand", "status", "fail_count", "warn_count",
            "fail_codes", "warn_codes", "mpn_mismatch", "pdf_sha_mismatch",
            "electrical_row_bad", "electrical_empty", "json_mpn", "pdf_name",
            "pdf_rev", "pdf_sha256_item", "pdf_sha256_file", "facts_pdf_hash",
            "facts_parse_timestamp", "facts_model", "gold_status",
            "root_cause_group", "root_cause_groups", "fix_class",
            "pdf_has_ec_text"]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(cols)
    for r in rows:
        w.writerow([";".join(r[c]) if isinstance(r[c], list) else r[c] for c in cols])
    return buf.getvalue()


def _md(led: dict) -> str:
    s = led
    lines = ["# 全量自动 QC 问题交叉矩阵与根因分组", "",
             "生成时间：%s  " % s["generated_at"],
             "范围：**%d 批 / %d 件**；逐件 FAIL **%d**。  "
             % (s["scope"]["batches"], s["scope"]["items"], s["scope"]["issue_items"]),
             "边界：只读分析，**未修改生产 facts / Gold / item**；根因分组是建议分类，"
             "最终修复需证据卡与人工确认。", "",
             "## 1. 结论摘要", "",
             "| 项 | 值 |", "|---|---|",
             "| 逐件状态 | PASS %d / WARN %d / FAIL %d |"
             % (s["status"].get("PASS", 0), s["status"].get("WARN", 0),
                s["status"].get("FAIL", 0)),
             "| 有 FAIL 的批次 | %d / %d |" % (s["batches_with_fail"], s["scope"]["batches"]),
             "| 唯一 FAIL 器件 | %d |" % s["scope"]["issue_items"], "",
             "### 1.1 你关心的交叉问题（按唯一器件计）", "",
             "| 问题 | 结果 |", "|---|---|"]
    p = s["pairwise"]
    lines += [
        "| MPN 不一致同时 SHA 不一致 | **%d** |" % p.get("MPN_MISMATCH+PDF_SHA_MISMATCH", 0),
        "| MPN 不一致单独 | **%d** |" % (s["code_counts"]["MPN_MISMATCH"]
                                          - p.get("MPN_MISMATCH+PDF_SHA_MISMATCH", 0)),
        "| SHA 不一致单独 | **%d** |" % (s["code_counts"]["PDF_SHA_MISMATCH"]
                                          - p.get("MPN_MISMATCH+PDF_SHA_MISMATCH", 0)),
        "| 电气行/空表同时存在 | **%d** |"
        % p.get("ELECTRICAL_ROW_BAD+ELECTRICAL_EMPTY", 0),
        "",
        "## 2. 错误码与复合组合", "",
        "| 错误码 | 唯一器件 |", "|---|---:|"]
    for c in CODES:
        lines.append("| `%s` | %d |" % (c, s["code_counts"][c]))
    lines += ["", "| 复合组合 | 器件 |", "|---|---:|"]
    for k, n in s["fail_combinations"].items():
        lines.append("| `%s` | %d |" % (k, n))
    lines += ["", "**本轮无复合错误**：所有 FAIL 器件都只命中 1 个错误码；"
                  "`MPN_MISMATCH+PDF_SHA_MISMATCH = 0`，因此 476 + 97 + 46 + 10 = 629 "
                  "就是唯一 FAIL 器件数，可直接相加。"]
    lines += ["", "## 3. 根因分组（建议分类）", "",
              "| 分组 | 器件 | 建议处理类 |", "|---|---:|---|"]
    fix_map = {
        "A1_": "source_mapping_business_review",
        "A2_": "identity_normalization_or_source_review",
        "A3_": "source_pdf_recovery_or_human",
        "I_": "parser_fix_then_rerun_item_batch",
        "J_": "parser_fix_then_rerun_item_batch",
        "F_": "deterministic_metadata_fix_after_review",
        "E_": "source_pdf_replacement_verify",
    }
    for g, n in s["group_counts"].items():
        fix = next((v for k, v in fix_map.items() if g.startswith(k)),
                   "human_evidence_review")
        lines.append("| %s | %d | %s |" % (g, n, fix))
    samples = collections.defaultdict(list)
    for r in s.get("rows") or []:
        if r["root_cause_group"] != "—":
            samples[r["root_cause_group"]].append(r)
    lines += ["", "### 3.1 分组样例（每类前 5，完整见 CSV）", "",
              "| 分组 | 样例：item -> JSON / PDF |", "|---|---|"]
    for g, rs in samples.items():
        ex = ["%s -> %s / %s" % (r["mpn"], r.get("json_mpn") or "—", r["pdf_name"])
              for r in rs[:5]]
        lines.append("| %s | %s |" % (g, "<br>".join(ex)))
    lines += ["", "| 修复类（建议） | 器件 |", "|---|---:|"]
    for k, n in s["fix_class_counts"].items():
        lines.append("| `%s` | %d |" % (k, n))
    lines += ["", "## 4. 集中度（FAIL 器件）", "",
              "| 维度 | Top |", "|---|---|",
              "| 品牌 | %s |" % "；".join("%s×%d" % (k, v)
                                         for k, v in list(s["brand_top"].items())[:8]),
              "| 型号家族 | %s |" % "；".join("%s×%d" % (k, v)
                                           for k, v in list(s["family_top"].items())[:8]),
              "| PDF 修订标记 | %s |" % "；".join("%s×%d" % (k, v)
                                               for k, v in list(s["revision_top"].items())[:6]),
              "| 批次 | %s |" % "；".join("%s×%d" % (k, v)
                                        for k, v in list(s["batch_fail_top"].items())[:6]),
              "", "## 5. 建议执行顺序（未改生产数据）", "",
              "1. **P0 先做证据卡（全部 629 件）**：逐项记录数据库型号、PDF 文件名/原文型号、"
              "PDF SHA、facts 源 SHA、来源版本、错误类型、建议动作；先只读生成，不批量改库。",
              "2. **P0-A2 可订购/封装变体（129）**：如 Q1/封装/速度档与基础型号差异；"
              "先确认型号归一化规则或业务口径，再重跑单件 + 受影响批次。",
              "3. **P0-A3 源 PDF/关联错配（266）**：先抽家族/厂商确认正确 PDF 或 item-PDF 关联；"
              "不得用通用规则批量覆盖。",
              "4. **P0-E PDF 文件版本漂移（97）**：核对原件与 facts 版本，确认后修正 "
              "`item.pdf_sha256/pdf_bytes` 或更换 PDF；不改变 facts 真值。",
              "5. **P1-A1 板卡/模块映射组件 PDF（81）**：确认是否按 family_inherited/组件型号"
              "发布；属于业务口径，必须人工/业务签字。",
              "6. **P1-I/J 电气结构（56）**：修解析规则或补源证据；重跑单件 + 受影响批次。",
              "7. **回归范围**：规则修复 → 受影响批次；元数据修复 → 单件 + 该批次；"
              "不得用一次全量重跑掩盖问题。", "",
              "> 本轮未发现 `F_DB SHA 元数据陈旧` 类（0 件）；不要预置“可以安全批量改库”的结论。", "",
              "## 6. 产物", "",
              "- `auto_qc_issue_matrix.csv`：逐 MPN 全量矩阵（含 PASS/WARN/FAIL）",
              "- `auto_qc_issue_matrix.json`：同上 + 汇总/交叉/根因分组",
              "- 本文件：人读结论与执行顺序", ""]
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="全量自动 QC 问题交叉矩阵（只读）")
    ap.add_argument("--db", default=str(DEFAULT_DATA / "workbench.sqlite3"))
    ap.add_argument("--data-dir", default=str(DEFAULT_DATA))
    ap.add_argument("--qc-dir", default=str(DEFAULT_DATA / "qc"))
    ap.add_argument("--run-id", default="20261028")
    ap.add_argument("--out-dir", default=str(DEFAULT_DATA / "qc" / "_staging"))
    ap.add_argument("--no-pdf-probe", action="store_true")
    args = ap.parse_args(argv)
    data_dir = Path(args.data_dir)
    db = DB(Path(args.db))
    items = {r["id"]: r for r in db.q(
        "SELECT id,mpn,brand,pdf_path,pdf_sha256,json_path,provider FROM item")}
    gold = {r["mpn"]: r for r in db.q(
        "SELECT id,mpn,status FROM gold_set ORDER BY id")}
    audits = _load_audits(Path(args.qc_dir), args.run_id)
    led = build_matrix(audits, items, gold, data_dir,
                       probe_pdf=not args.no_pdf_probe)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "auto_qc_issue_matrix.csv").write_text(_csv_text(led["rows"]),
                                                  encoding="utf-8")
    (out / "auto_qc_issue_matrix.json").write_text(
        json.dumps(led, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "auto_qc_issue_matrix.md").write_text(_md(led), encoding="utf-8")
    print("written %s" % (out / "auto_qc_issue_matrix.csv"))
    print("written %s" % (out / "auto_qc_issue_matrix.json"))
    print("written %s" % (out / "auto_qc_issue_matrix.md"))
    print(json.dumps({k: v for k, v in led.items() if k != "rows"},
                     ensure_ascii=False)[:1200])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
