#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""逐行 PDF 事实验收表 —— 「JSON 里的这个数，原文里到底有没有」。

为什么要有这一层
----------------
1101 包被判「不能视为重新核验」的根因不是数据错，而是**证据链断了**：
包内只有 JSON 和哈希记录，复核方拿到手无法独立重算，也无法逐行对照。
于是只能二选一：相信发布说明，或者不信。两种都不是验收。

这一层做的是能自动化的那部分：把每条参数的值拿回原厂 PDF 里回打（quote replay），
记录「在不在原文、在第几页、原文是什么」。它证明的是**值有出处**，
不证明「这个值被正确归到了这一行」—— 后者仍要人工裁决，所以结论列分四级，
不把回打成功说成参数正确。

四级结论
--------
* `verified`      —— 确定性抽取器能**逐字复现**同一行（最强，可重放）。
* `value_in_pdf` —— 行里每个数值都能在原文某页找到（有出处，但归属未证）。
* `partial`       —— 只有部分数值能找到，其余需人工。
* `not_found`     —— 一个数值都找不到 —— 可能是模型编的，必须人工处理。
* `unchecked`     —— 行里没有可回打的数值（纯文本行）。

用法
----
    python qc/fact_acceptance.py --staging data/staging_20261102 \\
        --pdf-dir data/pdfs --out data/staging_20261102
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                     # noqa: E402
from qc.stage_release import _pdf_for                          # noqa: E402

_DASHES = str.maketrans({"\u2013": "-", "\u2014": "-", "\u2212": "-",
                         "\u2012": "-", "\ufe63": "-"})
#: 数值 token：允许前导 ±、小数、科学计数。**不吃范围里的 "to"**。
_TOKEN_RE = re.compile(r"[+-]?\d+(?:\.\d+)?")

#: 参与回打的容器。顺序即报告顺序。
CONTAINERS = ("electrical", "absolute_max", "ac_performance", "thermal", "esd")

#: 板卡件的**隔离桶**（`qc/board_scope.py` 把板载器件参数挪到这里）。
#: 渲染层会把它们并回页面（`json_to_txt._spec_rows`），所以事实表也必须看：
#: 否则页面上 11 条绝对最大值、24 条板载电气行**根本不在分母里**，
#: 闸门算的是一张缺行的表 —— ADS8568EVM-PDK 实测就是这个洞。
BUCKETS = ("onboard_device_specs", "unresolved_specs")


def iter_container_rows(specs: dict):
    """遍历**页面上会出现**的每一行：主表 + 隔离桶。

    产出 `(bucket, container, row)`。`bucket="."` 表示主表。
    """
    for c in CONTAINERS:
        for r in specs.get(c) or []:
            if isinstance(r, dict):
                yield ".", c, r
    for b in BUCKETS:
        bucket = specs.get(b)
        if not isinstance(bucket, dict):
            continue
        for c in CONTAINERS:
            for r in bucket.get(c) or []:
                if isinstance(r, dict):
                    yield b, c, r

#: 结论阶梯。**V6 起由 `_derive()` 一处推导，别再在循环里写 if/elif**。
#:
#: 复核方 8.6 分复审的 P0-1 原话是「同样的特征（有 bbox、有 row_sha256），
#: 有的被判为 verified_row，有的却被判为 value_on_label_page。这会让客户
#: 觉得你们的审计系统是『人工手填』的」。根因有两条，都在旧实现里：
#:
#: 1. `verified`（容器级复现）排在 `verified_value` 之前 —— 能拿到坐标的行
#:    被降级成「无坐标」，结论不再单调。
#: 2. `row_sha256` / `bbox` 两个输出列取自 **JSON 的自述**，与最终结论无关 ——
#:    于是 74 行出现「带指纹却只到同页」。
#:
#: 现在的口径：**证据字段决定结论，结论决定输出字段**，两个方向都不许越界。
#:
#: * `verified_row`       —— 坐标 + 行指纹，指纹能从 PDF 重算且数值一致（最强）。
#: * `verified_paragraph` —— 坐标 + 正文条目指纹（`paragraph_sha256`）。表格行
#:   之外的参数（Features 条目、板卡规格正文）只能锚到这一级。
#: * `verified_value`     —— 坐标 + 数值，但该行没有可重放的行指纹。
#: * `verified`           —— 容器级确定性复现（参数名+数值全等），无坐标。
#: * `value_on_label_page` —— 数值与参数名同页，**行/列对应未证**（弱证据）。
VERDICT_RANK = {"verified_row": 5, "verified_paragraph": 4, "verified_value": 4,
                "verified": 4, "value_on_label_page": 3, "value_in_pdf": 2,
                "partial": 1, "unchecked": 0, "not_found": -1,
                # 列塌缩（2026-11-03 外审 V1）：值确实在 PDF 里，但**取的是哪一列
                # 没有证据**。与 `unchecked` 同级：都不构成可用结论。它不能低于
                # `not_found` —— 「原文没有」是可判定的结论，「不知道是哪一列」
                # 只是我们没测出来。
                "column_collapse": 0}

#: 拿到**坐标级**证据的结论集合（`release_state` 的门槛用它）。
COORD_VERDICTS = frozenset({"verified_row", "verified_paragraph", "verified_value"})

#: ── V7 P0-1：证据**等级**拆表 ─────────────────────────────────────────
#:
#: 复审 8.9 分的原话：「`verified` 是容器级确定性复现，表示参数名和数值能在
#: PDF 中复现，但没有行坐标」，「不能让 `verified` 直接被计入 `data_anchor`，
#: 再用 `data_anchor=100%` 宣称全部工程参数已锚定」。
#:
#: 结论（verdict）说的是「回打到了什么」，等级（grade）说的是「这份证据有多硬」。
#: 以前两者混在一个数字里，于是 ADS8568EVM-PDK 14 行全是容器级、
#: 一条坐标都没有，也能写出 `14/14` 满分并进 `DATA_VALIDATED`。
GRADE_OF = {
    "verified_row":        "row_anchor",            # 坐标 + 可重放行指纹
    "verified_paragraph":  "paragraph_anchor",      # 坐标 + 正文条目指纹
    "verified_value":      "coord_no_fingerprint",  # 有坐标，指纹不可重放
    "verified":            "container_verified",    # 名字+数值可复现，无坐标
    "value_on_label_page": "weak",
    "value_in_pdf":        "weak",
    "partial":             "weak",
    "not_found":           "weak",
    "unchecked":           "no_value",              # 行内无数值，不参与分母
}

#: 等级从硬到软。**门槛比较只看这张表**，不许再按 verdict 现算。
GRADE_RANK = {"row_anchor": 4, "paragraph_anchor": 3,
              "coord_no_fingerprint": 2, "container_verified": 1,
              "weak": 0, "no_value": -1}

#: 参数载体 → 达标所需的最低等级。这是本轮唯一的口径来源：
#: * 表格参数（Electrical / Absolute Maximum / AC / Thermal / ESD 表）
#:   必须拿到**可重放的行指纹**；
#: * 正文参数（板卡用户指南的 bullet、Features 条目）允许正文条目指纹 ——
#:   它本来就只存在于句子里，要求行指纹等于要求一个不存在的东西。
REQUIREMENT = {"table": "row_anchor", "prose": "paragraph_anchor"}

#: 判定「这个参数本来就活在正文里」的依据。只认 JSON 的**载体声明**，
#: 不认结论 —— 用结论反推载体，等于让弱证据自己给自己定门槛。
_PROSE_SCOPES = frozenset({"board", "board_level", "evm", "module", "kit"})
_PROSE_METHODS = frozenset({"label_value_colocation", "page_bullet",
                            "guide_bullet", "guide_prose", "bullet"})
#: 明确声明「出处是正文条目」的状态。ADS1201U 的绝对最大值是**点线列表**
#: （`名称 ....... 值`），PDF 里根本没有表格，`audited_paragraph` 是它能拿到的
#: 最强证据 —— 把它按 table 要求等于要求一个不存在的表。
_PROSE_STATUS = frozenset({"audited_paragraph"})


def grade_of(verdict: str) -> str:
    """结论 → 证据等级。未知结论一律按最弱处理，不默认通过。"""
    return GRADE_OF.get(str(verdict or ""), "weak")


def param_kind(row: dict, prose_containers: frozenset | set = frozenset()) -> str:
    """`table` / `prose` —— 这一行**应该**有什么级别的证据。

    只读 JSON 的载体声明（`scope` / `subject_kind` / `source.method` /
    `verification.status`）。板卡级参数（BOOST 两块板的 `scope=board`）来自
    用户指南正文与 bullet，属于 `prose`；其余全部按 `table` 要求 ——
    宁可错杀，不许放水：表格参数被当成正文参数，就是复审说的
    「弱证据冒充强证据」。
    """
    if row.get("_container") in prose_containers:
        return "prose"
    if str(row.get("scope") or "").lower() in _PROSE_SCOPES:
        return "prose"
    if str(row.get("subject_kind") or "").lower().startswith("board"):
        return "prose"
    src = row.get("source") or {}
    if str(src.get("scope") or "").lower() in _PROSE_SCOPES:
        return "prose"
    if str(src.get("method") or "").lower() in _PROSE_METHODS:
        return "prose"
    # 只认**原始**状态：`qc/fact_status_sync.py` 回写的状态是我们自己升级的，
    # 再拿它判载体就成了「用结论反推门槛」—— 弱证据自己给自己降要求。
    ver = row.get("verification") or {}
    if str(ver.get("status_source") or "") != "qc/fact_status_sync.py" and \
            str(ver.get("status") or "").lower() in _PROSE_STATUS:
        return "prose"
    return "table"


def _effective_grade(row: dict) -> tuple[str, str]:
    """行声明的等级，以及它与字段是否自洽。不自洽就**降级**，不修字段。

    「带 `verified_row` 但没有 bbox / 行指纹」这种行在 V6 里会被
    `_check_consistency()` 拦下；这里是同一判据的第二道闸：即便绕过 CSV
    直接算闸门，也不许把它算成强证据。
    """
    g = grade_of(row.get("verdict"))
    if g == "row_anchor" and not (row.get("bbox") and row.get("row_sha256")):
        return "weak", f"{row.get('verdict')} 缺坐标或行指纹"
    if g == "paragraph_anchor" and not (row.get("bbox")
                                       and row.get("paragraph_sha256")):
        return "weak", f"{row.get('verdict')} 缺坐标或条目指纹"
    if g == "coord_no_fingerprint" and not row.get("bbox"):
        return "weak", f"{row.get('verdict')} 缺坐标"
    return g, ""


def gate_summary(rows: list[dict]) -> dict:
    """精度闸：按等级计数，并逐行判「这份证据够不够它自己的门槛」。

    返回值就是下游唯一可用的结论：
    * `anchor_gate` —— `pass` / `blocked`；
    * `counts`     —— 各等级行数（`data_anchor` 的替代品，分维度看）；
    * `by_kind`    —— 表格 / 正文各自的达标情况；
    * `blocked`    —— 不达标行，带 `have` / `need`，可直接进风险队列。
    """
    counts = {g: 0 for g in GRADE_RANK}
    by_kind = {k: {"required": v, "ok": 0, "total": 0} for k, v in REQUIREMENT.items()}
    blocked: list[dict] = []
    inconsistent: list[str] = []
    denominator = 0
    for r in rows:
        g, why = _effective_grade(r)
        counts[g] += 1
        if why:
            inconsistent.append(f"{r.get('mpn')}/{r.get('label')}: {why}")
        if g == "no_value":
            continue          # 行里没有可回打的数：既不达标也不欠账
        denominator += 1
        kind = str(r.get("kind") or "table")
        need = REQUIREMENT.get(kind, "row_anchor")
        cell = by_kind[kind]
        cell["total"] += 1
        if GRADE_RANK[g] >= GRADE_RANK[need]:
            cell["ok"] += 1
        else:
            blocked.append({"mpn": r.get("mpn"), "label": r.get("label"),
                            "kind": kind, "have": g, "need": need,
                            "verdict": r.get("verdict")})
    return {
        "anchor_gate": "blocked" if blocked or inconsistent else "pass",
        "counts": counts,
        "denominator": denominator,
        "by_kind": by_kind,
        "blocked": blocked,
        "inconsistent": inconsistent,
    }


def missing_columns(json_row: dict, pdf_row: dict) -> list[str]:
    """原表印了、JSON 没存下来的列（复审 P1：MIN/TYP/MAX 不许丢列）。

    `VA19 = 1.8/1.9/2.0` 只存成 `1.8 to 2.0` 时，缺的就是 `typ`。
    这一列不补，页面上那句 `1.8–2.0 V` 看起来像原厂给的范围，
    实际是把三个 TYP 值压成了区间。
    """
    out: list[str] = []
    for k in ("min", "typ", "max", "value"):
        if str(pdf_row.get(k) or "").strip() and not str(json_row.get(k) or "").strip():
            out.append(k)
    return out


def range_semantics(row: dict, pdf_row: dict | None = None) -> str:
    """这个「范围」是原厂给的工作范围，还是多个 TYP 值拼出来的。

    `Analog Input Frequency Range (-3dB) = 2.0 to 6.3 GHz` 属于后者：
    两个子行各印一个 TYP，JSON 把它们连成区间。保留这个表达式可以，
    但不能把它说成「已验证的 MIN/MAX 工作范围」。
    """
    shape = str((pdf_row or {}).get("value_shape")
                or row.get("value_shape") or "").lower()
    if shape in ("range_typ_span", "typ_span"):
        return "typ_span"
    has_min = bool(str(row.get("min") or "").strip())
    has_max = bool(str(row.get("max") or "").strip())
    if has_min and has_max:
        return "min_max"
    if " to " in str(row.get("value") or ""):
        return "typ_span"
    return "single"

#: 结论 → 允许出现的坐标/指纹字段。这是「不许错配」的机器判据，
#: `_check_consistency()` 逐行核，`main()` 里违反直接抛错。
_EMIT_RULES = {
    "verified_row":       frozenset({"bbox", "row_sha256"}),
    "verified_paragraph": frozenset({"bbox", "paragraph_sha256"}),
    "verified_value":     frozenset({"bbox"}),
}


def _label_pages(idx: list[str], label: str) -> set[int]:
    """含该参数名的页码集合（1-based）。

    取标签里**最长的实词**做锚：`Input Common-Mode Voltage (CLK±)` 用
    `Common-Mode`，`SNR` 这种短符号退回全词。用整串去比会因换行、连字符
    与原文对不上。
    """
    words = [w for w in re.split(r"[^A-Za-z0-9+±/-]+", label) if len(w) >= 4]
    if not words:
        return set()
    anchor = max(words, key=len).lower()
    pat = re.compile(r"(?<![a-z])" + re.escape(anchor) + r"(?![a-z])")
    return {i for i, txt in enumerate(idx, 1) if pat.search(txt.lower())}


def _norm(s: str) -> str:
    return (s or "").translate(_DASHES)


def _row_numbers(row: dict) -> list[str]:
    """一行里所有可回打的数值（去重保序）。

    V11 P0-2：`verification.status=unresolved` 的行不许把 `range` 当可回打证据 ——
    正式区间已经不可信，事实表再拿它去 PDF 里「找到数」只会制造另一种口径。
    这类行的候选值在 `unverified_range_candidate`，不参与回打。
    """
    parts: list[str] = []
    for k in ("min", "typ", "max", "value"):
        v = _norm(str(row.get(k) or "")).strip()
        if v:
            parts.extend(_TOKEN_RE.findall(v))
    ver = row.get("verification")
    unresolved = (isinstance(ver, dict)
                  and str(ver.get("status") or "").strip().lower() == "unresolved")
    rng = row.get("range") or {}
    if isinstance(rng, dict) and not unresolved:
        for k in ("min", "max"):
            v = _norm(str(rng.get(k) or "")).strip()
            if v:
                parts.extend(_TOKEN_RE.findall(v))
    seen, out = set(), []
    for t in parts:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _row_label(row: dict) -> str:
    return str(row.get("name") or row.get("parameter") or row.get("symbol") or "").strip()


def _nums_eq(a: dict, b: dict) -> bool:
    """两行的数值集合是否相同（`2` 与 `2.0` 同值，`+5` 与 `5` 同值）。"""
    return _num_keys(a) == _num_keys(b)


def _num_keys(row: dict) -> set[str]:
    """数值归一键。字符串直接比会在 ADS1201 上全线失败（JSON 写 `2.0`、
    原表印 `2`；JSON 写 `+5`、原表印 `5`）。"""
    out: set[str] = set()
    for t in _row_numbers(row):
        try:
            out.add(f"{float(t):.6g}")
        except ValueError:
            continue
    return out


def _page_index(fitz_doc) -> list[str]:
    """每页的归一化文本（一次构建，多次回打）。

    两处必须归一，否则「同页」判据会误判为不通过（实测）：

    1. **断词连字符**：PDF 把 `common-mode` 排在行尾时读成 `common-\\nmode`，
       参数名锚点就永远匹配不上。
    2. **换行**：整页折成一行，跨行的参数名才能被当作连续文本匹配。
    """
    out = []
    for p in fitz_doc:
        t = _norm(p.get_text() or "")
        t = re.sub(r"-\s*\n\s*", "-", t)      # 行尾连字符接回
        out.append(re.sub(r"\s+", " ", t))
    return out


def _num_forms(token: str) -> list[str]:
    """一个数值在原文里可能出现的等价写法（去重保序）。

    实测来源（V7 复审【新-1】）：JSON 的 `-16.5 to -5.0` 经 `_num_keys` 收成
    `-5`（尾零被吃掉），而原文印的是 `–5.0`。拿 `-5` 去跑
    `(?<![\\d.])-5(?![\\d.])` 永远匹配不上 —— `5` 后面跟着 `.`，被后向断言挡掉。
    结果是「两个数找到一个、另一个找不到」，随后又被 `_derive` 判成
    `not_found`（一个数都没找到）—— **既漏了值，又给错误的处置建议**。

    所以补上尾零等价形式：`-5` ↔ `-5.0` / `-5.00`；反向也补 `-5.0` → `-5`。
    `-5` 与 `-5.25` 依然不互通（尾零才算等价，非零小数不算）。
    """
    forms = [token]
    plain = token.lstrip("+")
    if plain != token:
        forms.append(plain)
    m = re.fullmatch(r"([+-]?)(\d+)(?:\.(\d+))?", plain)
    if m:
        sign, ip, fp = m.groups()
        if fp is None:
            forms.extend([f"{sign}{ip}.0", f"{sign}{ip}.00"])
        elif set(fp) == {"0"}:
            forms.append(f"{sign}{ip}")
    seen: list[str] = []
    for f in forms:
        if f and f not in seen:
            seen.append(f)
    return seen


def _token_pages(idx: list[str], token: str) -> set[int]:
    """token 出现的**全部**页码（1-based）。

    早先只取首次出现页，`0.55` 在第 3 页也出现过，就被判成「不在第 10 页」，
    同页结论整体失真。要的是「出现在哪些页」，不是「最先在哪页」。

    原文把 `+5` 写成 `5`（正号单独占一列）时，退一步按无符号形式再找一次；
    尾零差异（`-5` vs `-5.0`）走 `_num_forms()`。**只要有一种等价写法命中就算命中**
    —— 页码是全集的并集，不是"第一种写法找到了就返回"。
    """
    hits: set[int] = set()
    for cand in _num_forms(token):
        pat = re.compile(r"(?<![\d.])" + re.escape(cand) + r"(?![\d.])")
        hits |= {i for i, txt in enumerate(idx, 1) if pat.search(txt)}
    return hits


#: 数字之间的破折号是**范围分隔符**，不是负号。
#: `8.2–52 V` 不归一会读成 `-52`，于是 JSON 的 `52` 永远匹配不上
#: （BOOST-DRV8711 实测：整条 `Voltage Range` 因此掉到同页命中）。
_RANGE_DASH_RE = re.compile(r"(?<=\d)\s*[-\u2013\u2014]\s*(?=\d)")


def _prose_nums(values) -> set[str]:
    """正文/表格单元里的数值集。两处必须归一：

    1. **脚注标号**：`VD11 + 0.5(5)` 的 `(5)` 是脚注序号，不是值。
       不剥掉，重放行会比 JSON 多出 `5`，`==` 判据全线失败（实测 74 行）。
    2. **范围破折号**：见 `_RANGE_DASH_RE`。
    """
    parts = []
    for v in values:
        if v is None:
            continue
        s = DE._FOOTNOTE_RE.sub("", str(v))
        parts.append(_RANGE_DASH_RE.sub(" ", s))
    return DE._num_keys(parts)


def _row_evidence_nums(row: dict) -> set[str]:
    """JSON 一行的数值集（含 `range` 子表）。"""
    vals = [row.get(k) for k in ("min", "typ", "max", "value")]
    rng = row.get("range")
    if isinstance(rng, dict):
        vals.extend(rng.get(k) for k in ("min", "max"))
    return _prose_nums(vals)


def _replay_nums(rows: list[dict]) -> set[str]:
    """重放行的数值集。"""
    vals = []
    for r in rows:
        vals.extend(r.get(k) for k in ("min", "typ", "max", "value"))
    return _prose_nums(vals)


def _page_lines(page) -> list[dict]:
    """正文条目：每行文本 + bbox；另加 2~3 行的**连读窗口**。

    为什么要有窗口：PDF 里「主条目 + 缩进子条目」是两行，语义上却是一条。
    ADC 的 `Noiseless Aperture Delay Step = 19 fs` 就是这样 ——

        • Noiseless aperture delay (tAD) adjustment:
          –Precise sampling control: 19fs Step

    参数名在上一行、数值在下一行，单行永远匹配不上，只能落到「同页」。
    窗口把这两行连起来读，bbox 取并集，指纹按连起来的文本算。

    窗口只在前一行**没有句末标点**时才生成（说明它没说完）；并且单独计数，
    不参与「数值是否具区分性」的判定 —— 否则同一个数值会因为出现在
    「行 + 窗口」里被算两次，把精度闸（`needs_words`）整个推翻。
    """
    out: list[dict] = []
    for b in page.get_text("dict").get("blocks") or []:
        if b.get("type") != 0:
            continue
        lines: list[dict] = []
        for ln in b.get("lines") or []:
            t = "".join(s.get("text") or "" for s in ln.get("spans") or [])
            t = re.sub(r"\s+", " ", _norm(t)).strip()
            if len(t) < 6:
                continue
            try:
                box = [round(float(v), 1) for v in ln.get("bbox") or []]
            except (TypeError, ValueError):
                continue
            if len(box) != 4:
                continue
            lines.append({"bbox": box, "text": t, "win": 1})
        out.extend(lines)
        for i, head in enumerate(lines):
            if head["text"].endswith((".", "。", "!", "?")):
                continue       # 这一行已经说完了，不往后连；后面的行照常试
            for n in (2, 3):
                if i + n > len(lines):
                    break
                seg = lines[i:i + n]
                txt = " ".join(x["text"] for x in seg)
                if len(txt) > 260:
                    break
                out.append({
                    "bbox": [min(x["bbox"][0] for x in seg),
                             min(x["bbox"][1] for x in seg),
                             max(x["bbox"][2] for x in seg),
                             max(x["bbox"][3] for x in seg)],
                    "text": txt, "win": n,
                })
    return out


def _para_index(fd, pages) -> dict[int, list[dict]]:
    """只解析这些页的正文条目（`_declared_pages()` 给出，通常 1~12 页）。"""
    out: dict[int, list[dict]] = {}
    for p in pages:
        if 0 < p <= fd.page_count:
            try:
                out[p] = _page_lines(fd[p - 1])
            except Exception:                                  # noqa: BLE001
                out[p] = []
    return out


def _para_input(page: int, text: str) -> str:
    """段落指纹的输入串；唯一实现在 `deterministic_extract.para_input()`。"""
    return DE.para_input(page, text)


def _para_fingerprint(page: int, text: str) -> str:
    """正文条目指纹；唯一实现在 `deterministic_extract.para_fingerprint()`。"""
    return DE.para_fingerprint(page, text)


#: 通用词：靠它们定位不了一行。`voltage` 在 180 页里出现几百次。
_GENERIC_WORDS = frozenset({
    "voltage", "current", "range", "input", "output", "minimum", "maximum",
    "typical", "value", "values", "mode", "modes", "channel", "channels",
    "single", "dual", "per", "and", "the", "with", "for", "from", "supply",
    "rate", "level", "limit", "limits",
})

#: 正文条目锚定的覆盖度门槛（名字与条件各算一次，取大）。
_PARA_THR = 0.6


def _anchor_word(label: str) -> str:
    """标签里最具辨识度的词，给 `_name_score` 兜底。

    正文句子常把参数名改写掉：`Power Consumption` → `Power consumption: 4W`，
    `Decimation Options` → `4x, 8x, 16x and 32x complex decimation`。
    这两种 2 词门槛过不去（只命中 1 个词），但 `consumption` / `decimation`
    本身足够定位 —— 用它做兜底，仍要求**全页唯一**才认。
    """
    words = [w for w in DE._tokens(label)
             if len(w) >= 6 and w not in _GENERIC_WORDS]
    return max(words, key=len) if words else ""


def _cond_match(cond: str, text: str, nums: set[str]) -> float:
    """条件串与该行文本的覆盖度。

    `_cond_score` 只比词，遇到纯数字条件就归零：`@ 1.2A` 切出来的 token
    是 `1` / `2a`，两个都不够 3 字符 —— 于是 `Power Input Voltage Minimum`
    在 `6 V minimum @ 1.2A` 上拿到 0 分，而同页另一行 `6 V minimum @ 400 mA`
    的兄弟行却能命中（实测 BOOSTXL-C2KLED 只锚上 4/5）。

    兜底：条件里的数字若**不出现在本行数值里**、却出现在这一行文本里，
    那就是一个有效的区分符，给满分。同页并列仍由调用方的唯一性判据挡掉。
    """
    sc = DE._cond_score(cond, text)
    if sc > 0:
        return sc
    cn = _prose_nums([cond])
    if cn and not (cn & nums) and cn <= _prose_nums([text]):
        return 1.0
    return 0.0


def _distinctive_tokens(label: str) -> set[str]:
    """标签里**有辨识度**的实词（去掉 `voltage` / `input` / `mode` 这类通用词）。"""
    return {w for w in DE._tokens(label) if w not in _GENERIC_WORDS}


def _find_paragraph(pages: dict[int, list[dict]], label: str, nums: set[str],
                    cond: str, page: int = 0) -> dict | None:
    """在正文条目里找承载该参数的那一行，返回 `{"page","bbox","text"}`。

    四条判据，**精度优先**：

    1. **数值全在**：这一行必须包含该行声明的每一个数值（子集即可 ——
       正文常比 JSON 多写 typ 或脚注，多出来的不算矛盾）。
    2. **数值是不是判别符**：同页含全部数值的行 ≤ 3 条时，数值本身就够定位；
       超过 3 条就说明这组数字在这一页到处都是（ADS1201U 的 `-0.3/0.3`
       出现在 5 行里），此时**必须**靠标签里的有辨识度的词定位。
       没有这条闸，`Analog Input: Voltage` 会锚到
       `Digital Input Voltage to DGND` 上 —— 两个词 `input` / `voltage`
       碰巧对上，但那是一条**完全不同**的参数（实测踩到）。
    3. **名字或条件对得上**：`_name_score ≥ 0.6`，或条件串覆盖度 ≥ 0.6。
       板卡正文几乎只靠条件定位：`Voltage Range` + `External power supply input`
       在 `Powered by an external power supply (8.2–52 V)` 里只有条件能命中。
    4. **唯一最优**：并列就返回 None。宁可留在弱证据里，也不猜 ——
       「同页命中」这个老毛病不能靠换一种猜法绕过去。
       排序键第三项是「这一行比本行多印了几个数」，取最少的那条：
       `Sampling Rate` 的 `10.4` 在标题行、bullet、正文各出现一次，
       只有 `Up to 10.4GSPS in single-channel mode` 是**恰好一个数**的。
    """
    if not nums:
        return None
    anchor = _anchor_word(label)
    dist = _distinctive_tokens(label)
    scope = [page] if page in pages else sorted(pages)

    pool: list[tuple[int, dict]] = []
    for p in scope:
        for ln in pages.get(p) or []:
            ln_nums = _prose_nums([ln["text"]])
            if nums <= ln_nums:
                pool.append((p, {**ln, "page": p, "nums": ln_nums}))
    if not pool:
        return None
    # 数值本身能不能区分？只看**单行**：窗口是同一批文字的重排，算进来会把
    # 同一个数值数两遍，精度闸就形同虚设。
    needs_words = sum(1 for _, x in pool if x.get("win") == 1) > 3

    def _pick(sub: list[tuple[int, dict]]) -> dict | None:
        cands: list[tuple[tuple[int, float, int], dict]] = []
        for p, ln in sub:
            toks = DE._tokens(ln["text"])
            hit_anchor = bool(anchor) and anchor in toks
            hit_dist = bool(dist) and dist <= toks
            sc = DE._name_score(label, ln["text"])
            if cond:
                sc = max(sc, _cond_match(cond, ln["text"], nums))
            if needs_words and not (hit_dist or hit_anchor):
                continue
            if sc < _PARA_THR and not (hit_anchor or hit_dist):
                continue
            extra = len(ln["nums"] - nums)
            # 末位再比窗口长度：能锚 2 行就不锚 3 行，bbox 越紧越好。
            cands.append(((1 if (hit_dist or hit_anchor) else 0, round(sc, 4),
                           -extra, -int(ln.get("win") or 1)), ln))
        if not cands:
            return None
        cands.sort(key=lambda x: x[0], reverse=True)
        if len(cands) > 1 and cands[0][0] == cands[1][0]:
            return None          # 并列 → 不猜
        return cands[0][1]

    # 单行优先，窗口只做兜底：能锚到一行就不该锚到两行 —— bbox 越紧，
    # 复核方翻过去越快。ADC 的 `Noiseless Aperture Delay Step` 属于
    # 「主条目 + 缩进子条目」，单行匹配不到，才会走到窗口。
    out = _pick([x for x in pool if x[1].get("win") == 1])
    if out is None:
        out = _pick([x for x in pool if x[1].get("win", 1) > 1])
    if out is None:
        return None
    res = dict(out)
    res.pop("nums", None)
    return res


def _locate_row(cands: list[dict], label: str, nums: set[str],
                cond: str) -> dict | None:
    """在原页的确定性行里找同一条表格行，要求**唯一最优**。

    旧实现是「数值集合全等 + 第一个分数 ≥0.6 的候选」，两个毛病：

    * 数值全等太严：原表多印一个 typ 就判不匹配，行被降级成「同页」。
    * 「第一个」太松：三条 `Input Common-Mode Voltage`（CLK± / SYSREF± /
      TMSTP±）数值完全一样，会全部认领同一行 —— 等于给三个不同参数盖同一个
      坐标。这比不给坐标更糟，因为它在页面上看起来是已核验的。

    现在按 `(名字分, 条件分)` 排序，并列第一直接返回 None。
    """
    scored: list[tuple[float, float, dict]] = []
    for c in cands:
        if not nums <= _prose_nums([c.get(k) for k in
                                    ("min", "typ", "max", "value")]):
            continue
        sc = DE._name_score(label, DE._cand_text(c), DE._cand_param(c))
        if sc < 0.6:
            continue
        cs = (DE._cond_score(cond, str(c.get("cond") or c.get("conditions") or ""))
              if cond else 0.0)
        scored.append((round(sc, 4), round(cs, 4), c))
    if not scored:
        return None
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    if len(scored) > 1 and scored[0][:2] == scored[1][:2]:
        return None
    return scored[0][2]


#: 需要人工处理的行（风险队列）判据。
#: Reviewer：`model_unverified` 不能无限期留在交付数据里，必须有处理结果 ——
#: 人工复核 / 迁到确定性抽取 / 明确排除，三者之一。
_NEEDS_ACTION_SOURCES = ("model_unverified", "unresolved", "not_checked", "")


def _downgrade_for_missing_cols(verdict: str, miss_cols: list[str]) -> tuple[str, str]:
    """列位没定时不许给「行级」结论（V8 / 复审【新-3】）。

    `ADS1201U` 的 Differential Input Voltage Range 把脚注 "See Note 2" 里的 `2`
    当成了 MIN，`missing_cols=min,max`，却因为「整行文本指纹重放一致」拿到
    `verified_row`。指纹是整行文本算的，把脚注吃进去照样一致 ——
    **指纹一致 ≠ 值解析正确**。列位没定最多给坐标（`verified_value`），
    指纹字段一律不发。
    """
    if not miss_cols or verdict != "verified_row":
        return verdict, ""
    return ("verified_value",
            f"原表列位未定（缺 {'/'.join(miss_cols)} 列），"
            "指纹只能证明整行文本一致、不能证明值落在哪一列；降为坐标级，待人工定列")


def _suggest_action(row: dict) -> str:
    """给风险行一个明确的下一步，不留「待办」这种空话。

    **`not_found` 不再直接建议排除**（V8 / 复审【新-1】）。误判 `not_found` 的代价
    是让人删掉一条**正确**参数（实测：HVSS 那条值就在 p9，因为 `-5` 与 `-5.0`
    的写法差异被判成「原文没有」）。排除是不可逆动作，必须先由人翻页确认，
    所以默认给 `human_review`；`exclude` 只留给人工在
    `data/manual_review*.csv` 里显式签字后由人执行。
    """
    if row["verdict"] == "not_found":
        return "human_review"           # 可疑但不能自动排除 —— 先翻页
    if row.get("missing_cols"):
        return "fill_missing_columns"   # 原表印了、JSON 丢了列（V7）
    if row["verdict"] == "value_on_label_page":
        # V5 已经试过行级锚定但没命中 —— 再写 promote_to_deterministic
        # 就是把同一件事再派一遍。这类只能人工翻页确认。
        return "human_review"
    if row["verdict"] in ("partial", "value_in_pdf"):
        return "human_review"           # 值有出处但归属未证
    if row.get("source") in _NEEDS_ACTION_SOURCES:
        return "promote_to_deterministic"
    return ""


def _risk_rows(all_rows: list[dict]) -> list[dict]:
    out = []
    for r in all_rows:
        act = _suggest_action(r)
        if not act:
            continue
        out.append({**r, "suggested_action": act})
    return out


def _declared_pages(doc: dict, page_count: int) -> set[int]:
    """这些行自己声明的页码（`source.page` / `verification.page`）。"""
    pages: set[int] = set()
    for _b, _c, r in iter_container_rows(doc.get("specs") or {}):
        if True:
            for src in (r.get("source") or {}, r.get("verification") or {}):
                try:
                    p = int(src.get("page") or 0)
                except (TypeError, ValueError):
                    p = 0
                if 0 < p <= page_count:
                    pages.add(p)
    return pages


def _replay_rows(fd, doc: dict) -> tuple[dict[str, dict], dict[int, list[dict]]]:
    """重跑确定性抽取器，返回 `(row_sha256 → 行, 页码 → 行列表)`。

    只跑**这些行自己声明的页**，不整份扫：`find_tables()` 一页约 1.4 秒，
    180 页手册全跑会把进程拖死（踩过 SIGTERM）。声明了页码的行本来就该在
    那一页，跳过其他页不会漏。

    这张表是 `verified_row` 的全部依据 —— 复核方不该相信 JSON 里那句
    `source.row_sha256` 的自述，而要看到它**能从 PDF 重算出来**。
    """
    by_sha: dict[str, dict] = {}
    by_page: dict[int, list[dict]] = {}
    for p in sorted(_declared_pages(doc, fd.page_count)):
        page = fd[p - 1]
        got: list[dict] = []
        for fn in (DE.extract_spec_rows, DE.extract_roc_rows):
            try:
                got.extend(fn(page))
            except Exception:                                  # noqa: BLE001
                continue
        by_page[p] = got
        for r in got:
            sha = str(r.get("row_sha256") or "")
            if sha:
                by_sha.setdefault(sha, r)
    # 跨页容器（AC / 输入范围）自己找页，单独跑一次
    for fn in (DE.extract_ac_performance, DE.extract_input_range_rows):
        try:
            got = fn(fd)
        except Exception:                                      # noqa: BLE001
            got = []
        for r in got:
            sha = str(r.get("row_sha256") or "")
            if sha:
                by_sha.setdefault(sha, r)
            pg = int(r.get("page") or 0)
            if pg:
                by_page.setdefault(pg, []).append(r)
    return by_sha, by_page


def _row_shas(row: dict) -> list[str]:
    """行声明的指纹：单行一个，多子行锚定（`source.rows`）一组。

    另认**行级**的 `row_sha256`：AC 表是 `{parameter, row_sha256, bbox, page}`
    平铺结构（`source` 只放出处元信息），只读 `source.row_sha256` 会让这些行
    全部退到容器级 —— ADS8568EVM-PDK 的 6 条 AC 行就是这么丢的坐标（实测）。
    """
    src = row.get("source") or {}
    multi = [str(x) for x in (src.get("rows") or []) if x]
    if multi:
        return multi
    one = str(src.get("row_sha256") or row.get("row_sha256") or "")
    return [one] if one else []


def _raw_lines(page) -> list[dict]:
    """**不设长度阈值**的文本行（行带定位专用）。

    `_page_lines()` 会丢掉 <6 字符的行 —— 那对正文条目是对的（`Notes:` 这种
    噪声），但热阻表的名字格就是 `RθJA`（4 字符）、数值格就是 `23.9`，
    用带阈值的版本永远找不到它们（实测 0 命中）。
    """
    out: list[dict] = []
    for b in page.get_text("dict").get("blocks") or []:
        if b.get("type") != 0:
            continue
        for ln in b.get("lines") or []:
            t = "".join(sp.get("text") or "" for sp in ln.get("spans") or [])
            t = re.sub(r"\s+", " ", _norm(t)).strip()
            box = ln.get("bbox") or []
            if not t or len(box) != 4:
                continue
            try:
                out.append({"bbox": [round(float(v), 1) for v in box],
                            "text": t, "win": 1})
            except (TypeError, ValueError):
                continue
    return out


#: 数值格：整格只有一个数（可带 ± 与单位）。热阻 `23.9`、ESD `±2000` 都是这种。
_VALUE_CELL_RE = re.compile(r"^[±+-]?\d+(?:\.\d+)?\s*[A-Za-zΩ℃°%/]*$")


def _band_input(label_text: str, value_text: str) -> str:
    """行带指纹的输入串（名称格 + 数值格，已归一化）。"""
    def _n(s: str) -> str:
        return re.sub(r"\s+", " ", _norm(s or "")).strip().lower()

    return "|".join([_n(label_text), _n(value_text)])


def _band_fingerprint(page: int, label_text: str, value_text: str) -> str:
    """**行带指纹**：`sha256(page | 名称格 | 数值格)`（归一化口径见 README）。

    热阻表 / ESD 表是「名称一格、数值一格」的横向排列，PyMuPDF 把它们读成
    两个独立文本行（ADC p10 实测：`RθJA` 在 y=476.2，`23.9` 在右侧另一格）。
    `find_tables()` 在这两张表上抽不出行（`extract_spec_rows` 返回 name=None），
    所以 V4~V6 一直停在「容器级复现」。这里按同页同一 y 带组行：
    坐标取两格并集，指纹按两行归一化文本算 —— 复核方翻到那一页就能重算。
    """
    raw = str(page) + "|" + _band_input(label_text, value_text)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _label_needles(label: str) -> list[str]:
    """参数名在正文里可能的写法（长 → 短）。

    实测来源（V8）：JSON 写 `Input Negative Supply Voltage (HVSS)`，PDF 表里
    符号另占一格，名称格只有 `Input negative supply voltage` ——
    整串 `in` 判断永远不成立，行带因此一条也命中不了。
    依次退：整串 → 去掉括号说明 → 最长实词。**长的先试，命中就停**。
    """
    raw = (label or "").strip().lower()
    if not raw:
        return []
    out = [raw]
    noparen = re.sub(r"\([^)]*\)", " ", raw).strip()
    if noparen and noparen != raw:
        out.append(noparen)
    words = [w for w in re.split(r"[^a-z0-9]+", noparen or raw) if len(w) >= 4]
    if words:
        out.append(max(words, key=len))
    seen: list[str] = []
    for s in out:
        if s and s not in seen:
            seen.append(s)
    return seen


def _band_row(pages: dict[int, list[dict]], label: str, nums: set[str],
              page: int = 0) -> dict | None:
    """在文本行里找「名称格 + 数值格」组成的表行，返回 `page/bbox/指纹`。

    为什么按**几何**而不是按行序：这两张表是横向两格 —— 名称一列、数值一列，
    PyMuPDF 常常「先读完名称列、再读数值列」，按行序往后找会把数值列的第一个数
    当成第一条参数的数（就是错的）。判据是「同一 y 带、位于名称右侧」。

    精度优先，不猜：
    1. 名称行**含**该参数名（`RθJA` / `HBM` 这类短名也要能命中）；
    2. 同一 y 带（±6 pt）、x 在名称右侧的纯数值格，**这些格子合起来的数值
       必须覆盖 JSON 的数值**（不是每格都得覆盖 —— 表格一列一个数，
       `–16.5 –15.0 –5.0` 必然分散在三格里，V7 要求"单格全覆盖"因此
       把整张 ABS MAX 表全漏掉，复审【新-1】的 HVSS 就是这么掉的）；
    3. 全文只允许一个候选 —— 多页/多行都能命中就返回 None。
       这条**按写法分别判**：先用整串找，整串没命中才退到去括号版、最长实词版；
       一旦某个写法命中，就以它的候选数定生死（命中 1 条=锚定，命中多条=不猜）。
       早期版本把所有写法混在一起收集，`Conversion Time` 因为最长实词
       `conversion` 命中多行而被判「歧义」，白丢了两条已锚定的行（实测）。
    """
    if not nums or not label:
        return None
    scope = [page] if page in pages else sorted(pages)

    def _scan(needle: str) -> list[dict]:
        found: list[dict] = []
        for p in scope:
            lines = pages.get(p) or []
            for ln in lines:
                lbox = ln.get("bbox") or []
                if len(lbox) != 4 or needle not in (ln.get("text") or "").lower():
                    continue
                cy = (lbox[1] + lbox[3]) / 2.0
                vcells: list[dict] = []
                for cand in lines:
                    cbox = cand.get("bbox") or []
                    if len(cbox) != 4:
                        continue
                    ccy = (cbox[1] + cbox[3]) / 2.0
                    if abs(ccy - cy) > 6 or cbox[0] < lbox[2] - 2:
                        continue
                    vtxt = (cand.get("text") or "").strip()
                    if not _VALUE_CELL_RE.match(vtxt):
                        continue
                    vcells.append({"text": vtxt, "bbox": cbox})
                if not vcells:
                    continue
                if not (nums <= _prose_nums([c["text"] for c in vcells])):
                    continue
                xs = [c for c in sorted(vcells, key=lambda c: c["bbox"][0])]
                found.append({
                    "page": p,
                    "bbox": [round(min([lbox[0]] + [c["bbox"][0] for c in xs]), 1),
                             round(min([lbox[1]] + [c["bbox"][1] for c in xs]), 1),
                             round(max([lbox[2]] + [c["bbox"][2] for c in xs]), 1),
                             round(max([lbox[3]] + [c["bbox"][3] for c in xs]), 1)],
                    "row_sha256": _band_fingerprint(
                        p, ln["text"], " ".join(c["text"] for c in xs)),
                    "sha_input": str(p) + "|" + _band_input(
                        ln["text"], " ".join(c["text"] for c in xs)),
                    "text": f"{ln['text']} {' '.join(c['text'] for c in xs)}".strip(),
                    "needle": needle,
                })
        return found

    for needle in _label_needles(label):
        hits = _scan(needle)
        if len(hits) == 1:
            return hits[0]
        if len(hits) > 1:
            return None        # 这种写法能命中多行 —— 不猜，也不退到更弱的写法
    return None


def _union_nums(rows: list[dict]) -> set[str]:
    vals = {"min": "", "typ": "", "max": "", "value": ""}
    for r in rows:
        for k in vals:
            vals[k] += " " + str(r.get(k) or "")
    return _num_keys(vals)


@dataclass
class _Evidence:
    """一行的全部可用证据。**只放能从 PDF 重算出来的东西**。

    这是 V6 的核心约束：`row_sha256` / `bbox` 字段不接受 JSON 的自述值，
    只接受审计器自己重放出来的值。JSON 说「我在第 9 页这块、指纹是 X」，
    而审计器重放不出 X —— 那就一个字段都不给，结论随之降级。
    """
    pdf_sha256: str = ""
    page: int = 0
    bbox: list = field(default_factory=list)
    row_sha256: str = ""
    paragraph_sha256: str = ""
    nums: set = field(default_factory=set)
    nums_found: bool = False
    #: 至少有一个数在原文里找得到（不要求全中）。
    #: 只用来区分 `partial` 与 `not_found` —— 一个数都没找到才是「原文没有」，
    #: 找到一个、差一个是「部分可回打」，处置建议完全不同（后者绝不能建议排除）。
    nums_any: bool = False
    same_page: bool = False
    same_page_pages: list = field(default_factory=list)
    container_ok: bool = False
    multi: int = 1
    declared_sha: str = ""
    extra: str = ""
    #: 指纹口径：`row`（表格行，抽取器算）/ `band`（名称格+数值格）/ `paragraph`
    sha_scheme: str = ""
    #: 算指纹时用的**归一化输入串**（`<page>|<归一化文本>` 的右半边）。
    #: 复核方拿它可以直接 `sha256(f"{page}|{sha_input}")` 重算，
    #: 不必猜「行文本」是按 bbox 取的还是按阅读顺序取的（复审【新-6】）。
    sha_input: str = ""
    #: 列塌缩原因（非空 = 该行所在容器被判 `column_collapse`）。
    #: 一旦有值，`_derive()` **在坐标证据之前**就返回 —— 行指纹能重放只证明
    #: 「这个值在表里」，不证明「它属于这一列」。这正是 LM317 热阻表栽的地方：
    #: 66.8 确实是 DCY 列的值，但另外三个封装列整列消失，页面给出的裸数字
    #: 对 TO-263 用户是错的。
    column_collapse: str = ""
    #: 条件串是否**被同一段落证据支持**（`None` = 这一行没有条件，或载体不是正文）。
    #: 元宝 V3.1 终审：`SNR 91.5 dB` 的 `At fIN = 10 kHz` 来自 p15 表格，
    #: 而它锚到的 p1 摘要段落里根本没有这句 —— 段落锚定只证明「值在这段里」，
    #: 不证明「条件也在这段里」。不支持就如实标 False，渲染层据此不印该条件。
    cond_supported: bool | None = None


def _derive(ev: _Evidence) -> tuple[str, str]:
    """**唯一状态推导机** —— 结论只由证据字段决定，不看调用顺序。

    复核方 8.6 分复审要求「同样字段特征必须输出同样的状态标签」。所以这里
    是一条严格单调的阶梯，从上往下第一个成立的就是结论；循环里不许再写
    第二个 if 去改判。
    """
    if not ev.nums:
        return "unchecked", "行内无数值，无可回打"
    if not ev.pdf_sha256:
        return "unchecked", "未取得源 PDF"

    # ⓪ 列塌缩：**排在坐标证据之前**。这是全表唯一一条「证据越强也不能翻案」
    #    的规则 —— 行指纹只能证明「这个数值出现在这张表里」，不能证明「它属于
    #    被写进 JSON 的那一列」。LM317 的 `RθJA 66.8` 行指纹完全可重放，
    #    但另外三个封装列整列没抽，客户拿它算 TO-263 结温就是错的。
    if ev.column_collapse:
        return "column_collapse", ev.column_collapse

    # ① 坐标 + 行指纹：最强。指纹必须由审计器重放得出。
    if ev.row_sha256 and ev.page and ev.bbox:
        if ev.sha_scheme == "band":
            note = "行带指纹可从 PDF 重算（名称格 + 数值格，同页同一 y 带）"
        else:
            note = (f"行指纹从 PDF 重放一致（{ev.multi} 条子行）"
                    if ev.multi > 1 else "行指纹从 PDF 重放一致")
        if ev.declared_sha and ev.multi == 1 and ev.declared_sha != ev.row_sha256:
            note += "；JSON 声明的指纹与重算不符，以重算为准"
        if ev.extra:
            note += f"；{ev.extra}"
        return "verified_row", note

    # ② 坐标 + 正文条目指纹：表格之外只有这一级。
    if ev.paragraph_sha256 and ev.page and ev.bbox:
        note = "正文条目级锚定（坐标 + 条目指纹），非表格行"
        if ev.extra:
            note += f"；{ev.extra}"
        return "verified_paragraph", note

    # ③ 坐标 + 数值：审计器在原页定位到了这一行，但没有可重放的指纹。
    if ev.bbox and ev.page and ev.nums_found:
        return "verified_value", "审计器在原页定位到该行（坐标），无行指纹"

    # ④ 容器级确定性复现：值有出处、参数名全等，但没有坐标。
    if ev.container_ok:
        return "verified", "确定性抽取器逐字复现（容器级，无行坐标）"

    # ⑤ 以下全是文本层弱证据，一律不带坐标与指纹。
    if ev.same_page:
        pgs = ev.same_page_pages
        return ("value_on_label_page",
                f"数值与参数名同页（第 {pgs} 页），但行/列对应关系未证 —— 需人工确认")
    if ev.nums_found:
        return "value_in_pdf", "数值在原文出现，但不在参数名所在页 —— 归属未证"
    # 部分命中：找到了几个、还差几个。这条必须在 `not_found` **之前** ——
    # V7 把「找到一个、差一个」也写成 `not_found`，并给了 `exclude_or_verify`
    # 建议，等于让人去删一条正确参数（复审【新-1】）。
    if ev.nums_any:
        return "partial", (ev.extra or "部分数值在原文可检索，其余未出现")
    return "not_found", "数值在原文均未出现"


def _emit_fields(verdict: str, ev: _Evidence) -> dict:
    """结论 → 输出字段。**反方向也不许越界**。

    旧实现里 `row_sha256` 一开始就从 JSON 抄下来，弱证据分支忘了清空，
    于是 74 行出现「带指纹却只到同页」。这里改成按结论白名单发字段：
    `verified_row` 之外的行，`row_sha256` 一定是空串。
    """
    allow = _EMIT_RULES.get(verdict, frozenset())
    return {
        "page": ev.page or "",
        "bbox": (json.dumps(ev.bbox, ensure_ascii=False)
                 if "bbox" in allow and ev.bbox else ""),
        "row_sha256": ev.row_sha256 if "row_sha256" in allow else "",
        "paragraph_sha256": (ev.paragraph_sha256
                             if "paragraph_sha256" in allow else ""),
    }


def _check_consistency(rows: list[dict]) -> list[str]:
    """逐行核「字段 ↔ 结论」不许错配。返回违规描述（空 = 通过）。"""
    bad: list[str] = []
    for r in rows:
        v = str(r.get("verdict") or "")
        allow = _EMIT_RULES.get(v, frozenset())
        for k in ("bbox", "row_sha256", "paragraph_sha256"):
            if str(r.get(k) or "") and k not in allow:
                bad.append(f"{r.get('mpn')}/{r.get('label')}: "
                           f"{v} 不该带 {k}")
        if v == "verified_row" and not (r.get("bbox") and r.get("row_sha256")):
            bad.append(f"{r.get('mpn')}/{r.get('label')}: verified_row 缺坐标或指纹")
        if v == "verified_paragraph" and not (r.get("bbox")
                                             and r.get("paragraph_sha256")):
            bad.append(f"{r.get('mpn')}/{r.get('label')}: verified_paragraph 缺坐标或指纹")
    return bad


def _origin_status(row: dict) -> str:
    """这一行的**原始**出处状态。

    同步会写 `status_prev`，**即使原值是空串** —— 热阻/ESD 在 V6 里就是没有
    `verification.status`（空串本身也是「待处理」）。用 `or` 兜底会把空串
    当成「没有 prev」，于是「同步一下」就让风险队列凭空少 15 行。
    """
    ver = row.get("verification") or {}
    if "status_prev" in ver:
        return str(ver.get("status_prev") or "")
    return str(ver.get("status") or "")


def _page_of(row: dict) -> int:
    try:
        return int((row.get("verification") or {}).get("page")
                   or row.get("page") or (row.get("source") or {}).get("page") or 0)
    except (TypeError, ValueError):
        return 0


def audit_one(mpn: str, doc: dict, pdf_path: Path | None) -> dict:
    """单型号逐行审计，返回 `{"rows": [...], "verdict": str, ...}`。"""
    specs = doc.get("specs") or {}
    meta = doc.get("metadata") or {}
    sha = str(meta.get("pdf_hash") or "")
    # ── 列塌缩（2026-11-03 外审 V1）────────────────────────────────────
    # 审计器把结论落在 `metadata.column_collapse`（容器级）。这里摊成
    # `{容器: 原因}`，行循环里逐行挂到 `_Evidence.column_collapse`。
    # 挂的是**整个容器**而不是「抽到的那几行」：列语义一旦丢了，这张表里
    # 每一行的「值属于哪个封装」都没有证据；只标部分行会让人以为其余行没事。
    _cc = meta.get("column_collapse") or {}
    _cc_reason = ""
    if _cc.get("detected"):
        _tbls = _cc.get("tables") or []
        _pkg = sorted({c for t in _tbls for c in (t.get("packages") or [])})
        _cc_reason = (
            f"多封装表列塌缩：表头有 {len(_pkg)} 个封装列（{'/'.join(_pkg)}），"
            f"抽取只用了第一列且未写封装条件 —— 值属于哪个封装没有证据")
    _collapse = {c: _cc_reason for c in (_cc.get("containers") or []) if _cc_reason}
    rows: list[dict] = []
    idx: list[str] = []
    by_sha: dict[str, dict] = {}
    by_page: dict[int, list[dict]] = {}
    # 没有声明页的行（热阻 / ESD：JSON 里只有 name+value）没法按页重放，
    # 只能按参数名在正文索引里找候选页 —— 这一步纯文本，很便宜。
    band_labels = {_row_label(r) for _b, _c, r in iter_container_rows(specs)
                   if not _page_of(r) and _row_label(r)}
    # 有声明页的行也要能走行带（V8）：ABS MAX / 推荐工作条件这种表
    # `find_tables()` 抽不出行，行带是唯一能拿到坐标的路；
    # V7 只给「无声明页」的行建索引，HVSS 这种「有页但表行重放失败」的直接掉队。
    band_extra_pages: set[int] = set()
    band_pages: dict[int, list[dict]] = {}
    #: 声明的段落证据（page+bbox+paragraph_sha256）。必须在 with 内把文本取出，
    #: 循环在 with 之外（fd 已关闭）。键用 id(row)，与 iter_container_rows 同一对象。
    decl_para: dict[int, dict] = {}

    if pdf_path and pdf_path.is_file():
        try:
            import pymupdf                                     # noqa: PLC0415
            with pymupdf.open(str(pdf_path)) as fd:
                idx = _page_index(fd)
                # 确定性容器：重跑抽取器，能逐字复现的给 verified（容器级）
                redo: dict[str, list] = {}
                try:
                    redo["ac_performance"] = DE.extract_ac_performance(fd)
                except Exception:                              # noqa: BLE001
                    redo["ac_performance"] = []
                try:
                    redo["thermal"] = DE.extract_thermal(fd)
                    redo["esd"] = DE.extract_esd(fd)
                except Exception:                              # noqa: BLE001
                    redo["thermal"] = redo["esd"] = []
                # 行指纹重放表：verified_row 的唯一依据
                try:
                    by_sha, by_page = _replay_rows(fd, doc)
                except Exception:                              # noqa: BLE001
                    by_sha, by_page = {}, {}
                # 正文条目索引：verified_paragraph 的唯一依据。
                # 除行自己声明的页，另补前 8 页 —— 没有 `source.page` 的行
                # （ADS1201U 的 11 条 amax 就是这种）声明页为 0，正文索引
                # 若只有声明页，它们连搜的地方都没有。
                try:
                    _pgs = sorted(_declared_pages(doc, fd.page_count)
                                  | set(range(1, min(fd.page_count, 8) + 1)))
                    para = _para_index(fd, _pgs)
                except Exception:                              # noqa: BLE001
                    para = {}
                # 声明的段落指纹：在 with 内取文本并算好，循环里只做比对。
                for _b, _c, _row in iter_container_rows(specs):
                    _src = _row.get("source") or {}
                    if not str(_src.get("paragraph_sha256") or ""):
                        continue
                    try:
                        _pg = int(_src.get("page") or 0)
                        _bb = [round(float(v), 1) for v in _src.get("bbox") or []]
                    except (TypeError, ValueError):
                        continue
                    if not (0 < _pg <= fd.page_count and len(_bb) == 4):
                        continue
                    try:
                        _txt = fd[_pg - 1].get_text("text",
                                                    clip=pymupdf.Rect(_bb))
                    except Exception:                      # noqa: BLE001
                        continue
                    if _txt.strip():
                        decl_para[id(_row)] = {"page": _pg, "bbox": _bb,
                                               "text": _txt}
                # 行带候选页：参数名在正文里出现过的页（短名 `HBM` 也走这里，
                # `_label_pages()` 要求 ≥4 字符的实词，对它无能为力）。
                # 另补所有行**声明过的页**：有页但表行抽不出来的行（ABS MAX）
                # 同样需要行带兜底，否则只能停在「同页」。
                try:
                    for _lab in band_labels:
                        for _i, _t in enumerate(idx, 1):
                            if _lab.lower() in _t.lower():
                                band_pages.setdefault(_i, [])
                    band_extra_pages = set(_declared_pages(doc, fd.page_count))
                    for _i in band_extra_pages:
                        band_pages.setdefault(_i, [])
                    for _i in list(band_pages):
                        band_pages[_i] = _raw_lines(fd[_i - 1])
                except Exception:                              # noqa: BLE001
                    band_pages = {}
        except Exception as e:                                 # noqa: BLE001
            redo = {}
            rows.append({"mpn": mpn, "container": "-", "label": "PDF 打开失败",
                         "value": "", "verdict": "unchecked",
                         "note": f"{type(e).__name__}: {e}"[:120]})
    else:
        redo, para = {}, {}

    # 整块是**点线排版**（`名称 ....... 值`）的容器：PDF 里根本没有表格，
    # `verified_paragraph` 是它拿得到的最强证据。判据来自抽取器自己记的
    # `method=dot_leader_verbatim`，复核方翻到那页就能看到这种排版。
    prose_containers = {
        c for _b, c, r in iter_container_rows(specs)
        if str((r.get("verification") or {}).get("method") or "") == "dot_leader_verbatim"}

    # 确定性抽取器给出的同 label 行。**必须是列表**：AC 表里同一个
    # `SNR Signal-to-noise ratio` 会有三行（不同测试条件），用
    # `{label: row}` 会把前两行覆盖掉，于是它们被判成「只到同页」。
    _ref_cache: dict[str, dict[str, list[dict]]] = {}
    for _bucket, container, item in iter_container_rows(specs):
        items = [item]
        if container not in _ref_cache:
            _r: dict[str, list[dict]] = {}
            for r in redo.get(container) or []:
                _r.setdefault(_row_label(r), []).append(r)
            _ref_cache[container] = _r
        ref = _ref_cache[container]
        for row in items:
            label = _row_label(row)
            nums = _row_evidence_nums(row)
            page = _page_of(row)
            kind = param_kind({**row, "_container": container}, prose_containers)
            declared = str((row.get("source") or {}).get("row_sha256") or "")
            ev = _Evidence(pdf_sha256=sha, page=page, nums=nums,
                           declared_sha=declared,
                           column_collapse=_collapse.get(container, ""))

            # ① 行指纹重放：多子行锚定（`source.rows`）要求每个成员都能重放。
            #    数值判据用**子集**而不是相等 —— 重放行常比 JSON 多写 typ 或
            #    脚注标号（`VA19 1.8/1.9/2.0` 对 JSON 的 `1.8 to 2.0`），
            #    相等判据会把这些行误降成「只到同页」（实测 74 行）。
            want_shas = _row_shas(row)
            replay = [by_sha[s] for s in want_shas if s in by_sha]
            if want_shas and len(replay) == len(want_shas) and \
                    nums <= _replay_nums(replay):
                ev.row_sha256 = ",".join(want_shas)
                ev.multi = len(replay)
                box = replay[0].get("bbox") or []
                if len(box) == 4:
                    ev.bbox = [round(float(v), 1) for v in box]
                ev.page = int(replay[0].get("page") or page)
                ev.nums_found = True
                ev.sha_scheme = "row"
                extra = sorted(_replay_nums(replay) - nums)
                if extra:
                    ev.extra = f"原表另印 {'/'.join(extra)} 未录入"

            # ①b 段落指纹重放：点线表 / 共享前缀行没有表格行指纹，但有 bbox +
            #     段落指纹。声明值不算数 —— 必须从 PDF 的同一 bbox 重算一致，
            #     且该 bbox 文本覆盖本行全部数值，才升 `verified_paragraph`。
            #     ADS1201U 的 `Analog Input: Current`（两行复合值）与
            #     `Analog Input: Voltage`（`Analog Input:` 前缀来自上一行）走这里。
            _src = row.get("source") or {}
            _decl_para = str(_src.get("paragraph_sha256") or "")
            _dp = decl_para.get(id(row)) if _decl_para else None
            if not ev.bbox and _dp:
                _txt, _pg, _bb = _dp["text"], _dp["page"], _dp["bbox"]
                if (nums <= _prose_nums([_txt])
                        and DE.para_fingerprint(_pg, _txt) == _decl_para):
                    ev.bbox = _bb
                    ev.page = _pg
                    ev.paragraph_sha256 = _decl_para
                    ev.sha_input = DE.para_input(_pg, _txt)
                    ev.sha_scheme = "paragraph"
                    ev.nums_found = True

            # ② 容器级复现（无坐标）：thermal / esd 这类没有 bbox 的表靠它。
            for h in ref.get(label) or []:
                if _prose_nums([h.get(k) for k in
                                ("min", "typ", "max", "value")]) == nums:
                    ev.container_ok = True
                    if not ev.page:
                        ev.page = int(h.get("page") or page)
                    break

            # ③ 坐标 + 数值：审计器自己在原页找同一表格行（要求全页唯一最优）。
            #    命中就同时拿到该行的指纹 —— 于是结论是 `verified_row`，
            #    不是「只有坐标」的 `verified_value`。这正是 8.6 分复审要的
            #    「有 bbox + row_sha256 就必须是 verified_row」。
            if not ev.bbox and page:
                ev2 = _locate_row(by_page.get(page) or [], label, nums,
                                  str(row.get("condition") or row.get("conditions") or ""))
                if ev2 is not None:
                    box = ev2.get("bbox") or []
                    if len(box) == 4:
                        ev.bbox = [round(float(v), 1) for v in box]
                    ev.page = int(ev2.get("page") or page)
                    ev.nums_found = True
                    ev.row_sha256 = str(ev2.get("row_sha256") or "")
                    ev.multi = 1
                    ev.sha_scheme = "row"

            # ③c 行带锚定：名称格 + 数值格同页同一 y 带（热阻 / ESD 是这种横向两格表）。
            #     这两张表 `find_tables()` 抽不出行，V4~V6 只能停在容器级；
            #     复审【新-7】因此说「14 条热阻/ESD 从未拿到 bbox + 行指纹」。
            if not ev.bbox and not ev.row_sha256 and band_pages and nums:
                # 有声明页就只在该页找（精度优先）；没有才放开全页搜。
                band = _band_row(band_pages, label, nums,
                                 page if page in band_pages else 0)
                if band is not None:
                    ev.bbox = band["bbox"]
                    ev.page = band["page"]
                    ev.nums_found = True
                    ev.row_sha256 = band["row_sha256"]
                    ev.sha_input = str(band.get("sha_input") or "")
                    ev.sha_scheme = "band"

            # ④ 正文条目：表格之外唯一能拿到坐标的路。
            if not ev.bbox:
                cond = str(row.get("condition") or row.get("conditions") or "")
                ln = _find_paragraph(para, label, nums, cond, page)
                if ln is not None:
                    ev.bbox = ln["bbox"]
                    ev.page = ln["page"]
                    ev.nums_found = True
                    ev.paragraph_sha256 = _para_fingerprint(ln["page"], ln["text"])
                    ev.sha_input = _para_input(ln["page"], ln["text"])
                    ev.sha_scheme = "paragraph"

            # ⑤ 文本层兜底：值在不在、是否与参数名同页。
            if not ev.nums_found and idx and nums:
                hits = {t: _token_pages(idx, t) for t in nums}
                ok = {t: p for t, p in hits.items() if p}
                ev.nums_found = len(ok) == len(hits)
                lpages = _label_pages(idx, label)
                on_label = {t: (p & lpages) for t, p in ok.items()
                            if lpages and (p & lpages)}
                if ev.nums_found and lpages and len(on_label) == len(hits):
                    ev.same_page = True
                    ev.same_page_pages = sorted({q for p in on_label.values() for q in p})
                    ev.page = ev.page or ev.same_page_pages[0]
                elif ok:
                    ev.page = ev.page or min(min(p) for p in ok.values())
                if not ev.nums_found and ok:
                    miss = ",".join(t for t, p in hits.items() if not p)
                    ev.extra = f"未在原文找到：{miss}"
                    ev.nums_any = True

            # 原表印了 min/typ/max、JSON 只留其中几列 —— 只在 JSON 已经分列的
            # 行上查（`value` 单列的行是另一种建模，不算丢列）。
            miss_cols: list[str] = []
            if replay and any(str(row.get(k) or "").strip()
                              for k in ("min", "typ", "max")):
                miss_cols = missing_columns(row, replay[0])

            verdict, note = _derive(ev)
            verdict, downgrade_note = _downgrade_for_missing_cols(verdict, miss_cols)
            if downgrade_note:
                note = downgrade_note
            out = _emit_fields(verdict, ev)
            rows.append({
                "mpn": mpn, "bucket": _bucket, "container": container, "label": label,
                "value": " / ".join(_row_numbers(row)),
                "unit": str(row.get("unit") or ""),
                "pdf_sha256": sha, "verdict": verdict, "note": note,
                # 指纹的归一化输入串：复核方直接 sha256(sha_input) 就能对上
                # 对应的 row_sha256 / paragraph_sha256，不必猜行文本怎么取的。
                "sha_input": ev.sha_input,
                # 条件串进 key：AC 表里同一个 `parameter` 会因测试条件不同
                # 出现十几次（ADC 的 SFDR 就有 10 条），只用 label 做键会把
                # 它们并成一条，于是「一条弱证据」把十条全打成 †（实测）。
                "cond": str(row.get("condition") or row.get("conditions") or ""),
                # 出处取**同步前**的状态：`qc/fact_status_sync.py` 会把
                # `label_value_same_page` 升成 `audited_paragraph`，若直接读
                # 现行状态，风险队列会在「同步一下」之后凭空少 15 行 ——
                # 那是把出处洗白，不是把风险消掉。
                "source": _origin_status(row),
                # V7 精度闸：载体 + 等级 + 该载体要求的最低等级 + 指纹口径
                "kind": kind, "grade": grade_of(verdict),
                "required_grade": REQUIREMENT[kind],
                "sha_scheme": ev.sha_scheme,
                "missing_cols": ",".join(miss_cols),
                "range_semantics": range_semantics(row, replay[0] if replay else None),
                **out,
            })

    worst = min((VERDICT_RANK[r["verdict"]] for r in rows), default=0)
    n = {k: sum(1 for r in rows if r["verdict"] == k) for k in VERDICT_RANK}
    # `pass` 的门槛：没有 not_found（疑似编造），**且**没有 value_in_pdf
    # （数值只在别处出现，归属未证）。后者很容易被凑成"有出处"，不能算通过。
    # `unchecked` 不阻断（它表示"这行没有可回打的数"），但单独计数，
    # 免得"查不了"被当成"查过了"。
    # `value_on_label_page` 同样不阻断 `pass` —— 它已经被显式标成弱证据、
    # 进风险队列、页面打带说明的 †。`pass` 说的是"没有编造"，不是"全对"。
    if not rows:
        verdict = "empty"
    elif n["not_found"]:
        verdict = "fail"
    elif n["value_in_pdf"]:
        verdict = "partial"
    else:
        verdict = "pass"
    return {
        "mpn": mpn, "pdf_sha256": sha, "rows": rows, "n_rows": len(rows),
        "counts": n, "verdict": verdict, "worst": worst,
        "coord": sum(n[k] for k in COORD_VERDICTS),
        "gate": gate_summary(rows),
        "pdf": str(pdf_path) if pdf_path else "",
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="逐行 PDF 事实验收表")
    ap.add_argument("--staging", required=True, help="装配根（含 parsed/）")
    ap.add_argument("--pdf-dir", default="data/pdfs")
    ap.add_argument("--out", default="", help="报告输出目录（默认同 staging）")
    ap.add_argument("--mpns", default="", help="逗号分隔；默认扫 parsed/ 全部")
    a = ap.parse_args(argv)

    staging = Path(a.staging)
    out = Path(a.out) if a.out else staging
    pdf_dir = Path(a.pdf_dir)
    parsed = staging / "parsed"
    if not parsed.is_dir():
        print(f"缺 parsed/：{parsed}", file=sys.stderr)
        return 2
    names = ([x.strip() for x in a.mpns.split(",") if x.strip()]
             if a.mpns else sorted(p.stem for p in parsed.glob("*.json")))

    all_rows: list[dict] = []
    summary: dict = {}
    for mpn in names:
        jp = parsed / f"{mpn}.json"
        if not jp.is_file():
            # 显式点名要审却找不到文件，必须吭声。静默 `continue` 会让
            # 「20 件批次只出 19 条结论」这种缺口完全不可观测 —— 实测
            # `--mpns DS38EP100SD/NOPB`（`basic_info.mpn` 原文）对不上
            # 文件名主干 `DS38EP100SD_NOPB`，就整件消失了。
            print(f"跳过：{mpn} —— 没有 parsed/{mpn}.json"
                  f"（--mpns 用的是**文件名主干**，不是 basic_info.mpn）",
                  file=sys.stderr)
            continue
        doc = json.loads(jp.read_text(encoding="utf-8"))
        sha = str((doc.get("metadata") or {}).get("pdf_hash") or "")
        pdf = _pdf_for(mpn, pdf_dir, sha)
        res = audit_one(mpn, doc, pdf)
        summary[mpn] = {k: res[k] for k in
                        ("pdf_sha256", "n_rows", "counts", "verdict", "coord", "pdf")}
        g = res["gate"]
        summary[mpn].update({
            "anchor_gate": g["anchor_gate"],
            "grades": g["counts"],
            "grades_denominator": g["denominator"],
            "by_kind": g["by_kind"],
            "blocked": [f'{b["label"]} (have={b["have"]}, need={b["need"]})'
                        for b in g["blocked"]],
        })
        all_rows.extend(res["rows"])
        print(f"{mpn:18} {res['verdict']:5} rows={res['n_rows']:3} "
              f"row={res['counts']['verified_row']:3} "
              f"para={res['counts']['verified_paragraph']:3} "
              f"val={res['counts']['verified_value']:3} "
              f"cont={res['counts']['verified']:3} "
              f"same_page={res['counts']['value_on_label_page']:3} "
              f"in_pdf={res['counts']['value_in_pdf']:3} "
              f"partial={res['counts']['partial']:2} "
              f"not_found={res['counts']['not_found']:2} "
              f"unchecked={res['counts']['unchecked']:2}")
        print(f"{'':18} 精度闸 {g['anchor_gate'].upper():8} "
              f"row_anchor={g['counts']['row_anchor']:3} "
              f"paragraph_anchor={g['counts']['paragraph_anchor']:3} "
              f"container={g['counts']['container_verified']:3} "
              f"weak={g['counts']['weak']:2} denom={g['denominator']:3} "
              f"不达标={len(g['blocked'])}")

    # 字段 ↔ 结论不许错配。这是 8.6 分复审 P0-1 的机器判据：
    # 同一份 CSV 里不允许出现「带 bbox/row_sha256 却是弱证据」的行。
    bad = _check_consistency(all_rows)
    if bad:
        for line in bad[:20]:
            print(f"口径不一致: {line}", file=sys.stderr)
        print(f"口径不一致 {len(bad)} 处 —— 拒绝写出报告", file=sys.stderr)
        return 3

    out.mkdir(parents=True, exist_ok=True)
    # `cond` 必须在列里：`qc/fact_status_sync.py` 拿 `(label, cond)` 去和 JSON 的
    # `(parameter, conditions)` 对键，缺了它所有 AC 行（ADC 64 条）都对不上，
    # 同步就会"看起来做了、其实一条没改"（复审【新-2】的 70/108 就是这么来的）。
    # `sha_input` 是算指纹时的**归一化输入串**，复核方可以逐字节对，
    # 不必猜"行文本"是怎么取的（复审【新-6】）。
    cols = ("mpn", "bucket", "container", "label", "cond", "value", "unit", "page",
            "pdf_sha256", "row_sha256", "paragraph_sha256", "sha_input", "bbox",
            "verdict", "kind", "grade", "required_grade", "sha_scheme",
            "missing_cols", "range_semantics", "note", "source")
    with (out / "facts_audit.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in all_rows:
            w.writerow({k: r.get(k, "") for k in cols})
    (out / "facts_audit.json").write_text(json.dumps({
        "schema": "facts-audit/v4",
        "derivation": "qc/fact_acceptance.py::_derive —— 结论只由证据字段推导，"
                      "输出字段只由结论发放（_emit_fields）；"
                      "row_sha256 非空 <=> verified_row，bbox 非空 <=> 坐标级结论。",
        "note": "逐行回打原厂 PDF。verified_row=坐标 + 行指纹（row_sha256）能从 PDF 重算且数值一致（最强）；"
                "verified_paragraph=坐标 + 正文条目指纹（paragraph_sha256），表格之外的参数只能到这一级；"
                "verified_value=有坐标但该行没有可重放的指纹；"
                "verified=容器级确定性复现（按参数名+数值，无行坐标）；"
                "value_on_label_page=数值与参数名同页但行/列对应未证（弱证据，进风险队列，页面打带说明的 †）；"
                "value_in_pdf=只在别处出现（归属未证）；partial/not_found=需人工；"
                "unchecked=无可回打数值。"
                "注意：facts_verdict=pass 只表示「没有编造的数值」，不表示「参数全对」——"
                "核心工程参数要 reach verified_row 才谈得上已验证。",
        "grade_note": "V7 起 `data_anchor` 废止，改为四个互不冒充的计数："
                      "row_anchor（坐标+可重放行指纹）/ paragraph_anchor（坐标+正文条目指纹）"
                      "/ container_verified（名字+数值可复现但无坐标）/ weak（弱证据）。"
                      "达标门槛按载体分流：表格参数须 row_anchor，正文参数须 paragraph_anchor"
                      "（qc/fact_acceptance.py::REQUIREMENT）。anchor_gate=blocked 表示存在"
                      "未达门槛的行，此时 release_state 不得进入 DATA_VALIDATED。",
        "sha_scheme": "row=表格行指纹（page|表标题|左上坐标|符号|min|typ|max|unit）；"
                      "band=行带指纹（page|名称格归一化文本|数值格归一化文本）；"
                      "paragraph=正文条目指纹（page|归一化行文本）。"
                      "归一化 = 破折号统一 + 空白折叠 + 小写，详见包内 README。",
        "coord_verified": sum(m.get("coord", 0) for m in summary.values()),
        "total_rows": len(all_rows),
        "anchor_gate": ("pass" if all(m.get("anchor_gate") == "pass"
                                      for m in summary.values()) else "blocked"),
        "mpns": summary,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    # 页面 † 的唯一来源。渲染层把这份 map 挂到 `doc.metadata.facts_verdicts`，
    # `json_to_txt._is_unverified()` 有它就只按它判 —— V5 复审 新-3 要的
    # 「页面 † 跟事实表走」就是这一步。
    # 键是 `label \x1f 条件`：AC 表同一个 parameter 会因测试条件不同出现十几条，
    # 只用 label 会把它们并成一条。同名同条件撞车时取**更弱**的结论 ——
    # † 宁可多打，不可漏打。
    fv: dict[str, dict] = {}
    for r in all_rows:
        d = fv.setdefault(r["mpn"], {})
        k = f'{r["label"]}\x1f{r.get("cond") or ""}'
        old = d.get(k)
        if old is None or VERDICT_RANK.get(r["verdict"], -9) < VERDICT_RANK.get(old, 99):
            d[k] = r["verdict"]
    (out / "facts_verdicts.json").write_text(json.dumps({
        "schema": "facts-verdicts/v1",
        "note": "label → verdict。渲染层用它决定页面 † 角标；"
                "有这份文件时 JSON 的 verification.status 不再参与打标。",
        "mpns": fv,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    # 风险队列：把「还没被确定性抽取接管、也没人工结论」的行单独拉出来，
    # 每一行都带一个明确的下一步，不允许它无期限地留在交付数据里。
    risk = _risk_rows(all_rows)
    rcols = ("mpn", "container", "label", "value", "unit", "source",
             "verdict", "suggested_action", "note", "page")
    with (out / "risk_queue.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rcols)
        w.writeheader()
        for r in risk:
            w.writerow({k: r.get(k, "") for k in rcols})
    by_act: dict[str, int] = {}
    for r in risk:
        by_act[r["suggested_action"]] = by_act.get(r["suggested_action"], 0) + 1
    print(f"风险队列 {len(risk)} 行 → {out/'risk_queue.csv'}")
    for k, v in sorted(by_act.items(), key=lambda x: -x[1]):
        print(f"  {k:26} {v}")

    print(f"\n已写 {out/'facts_audit.csv'}（{len(all_rows)} 行）与 facts_audit.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
