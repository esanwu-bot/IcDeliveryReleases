"""修正 staging 中 C2K 指南证据和 ADC 器件身份，并重渲染。不扫描新页。"""
from __future__ import annotations

import json
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import json_to_txt as J
import symbol_svg as S
from qc.identity_scope import find_pdf
from qc.page_evidence import extract_pages
from qc import pin_repair as PR

OUT = ROOT / "data" / "staging_20261030_fixed"
C2K_SHA = "82e79558ba39"


def _load(mpn: str) -> dict:
    return json.loads((OUT / "parsed" / f"{mpn}.json").read_text(encoding="utf-8"))


def _save_render(mpn: str, doc: dict) -> None:
    path = OUT / "parsed" / f"{mpn}.json"
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    fresh = json.loads(path.read_text(encoding="utf-8"))
    (OUT / "txt" / f"{mpn}.txt").write_text(J.render(fresh, "en"), encoding="utf-8")
    (OUT / "symbols" / f"{mpn}.html").write_text(
        S.render_page(fresh, pkg_dir=ROOT / "data" / "pkgs"), encoding="utf-8")


def fix_c2k() -> None:
    doc = _load("BOOSTXL-C2KLED")
    specs = doc.setdefault("specs", {})
    urs = specs.get("unresolved_specs") or {}
    elec = urs.get("electrical") or []
    if len(elec) != 5:
        raise SystemExit(f"C2K unresolved electrical={len(elec)}")
    pdf = find_pdf("BOOSTXL-C2KLED", ROOT / "data" / "pdfs")
    cached = extract_pages(pdf, [1, 3, 5], timeout_s=8)
    if cached.get("status") != "ok":
        raise SystemExit(f"C2K cache {cached.get('status')}")
    text = "\n".join(row["text"] for page in cached["pages_data"] for row in page["rows"])
    if "User's Guide" not in text and "User’s Guide" not in text:
        raise SystemExit("C2K page 1 has no user guide title")
    if "BOOSTXL-C2KLED" not in text:
        raise SystemExit("C2K cached pages do not name the request")
    if "24 V nominal @ 100 mA" not in text:
        raise SystemExit("C2K page 5 kit spec missing")
    sha = cached["pdf_sha256"]
    notes = {
        "Power Input Voltage Minimum": (233.3, "6 V minimum @ 1.2A"),
        "Power Input Voltage Maximum": (247.9, "20 V maximum @ 360 mA"),
        "Boost Stage Input Voltage Minimum": (291.8, "6 V minimum @ 400 mA"),
        "Boost Stage Input Voltage Maximum": (306.4, "20 V maximum @ 120 mA"),
        "Boost Stage Output Voltage": (335.6, "24 V nominal @ 100 mA"),
    }
    for row in elec:
        y, note = notes[row["name"]]
        row["scope"] = "board"
        row["subject_mpn"] = "BOOSTXL-C2KLED"
        row["subject_kind"] = "board"
        row["source"] = {
            "pdf_sha256": sha, "page": 5, "page_base": 1, "y": y,
            "extractor": "pymupdf-words-v1", "scope": "board", "note": note,
        }
        row["verification"] = {"status": "audited", "method": "cached-pages-1-3-5"}
    specs["electrical"] = elec
    specs["scope"] = "board"
    urs.pop("electrical", None)
    bi = doc.setdefault("basic_info", {})
    bi["document_scope"] = "board_user_guide"
    bi["document_evidence"] = [{
        "kind": "cached_specified_pages",
        "pages": [1, 3, 5],
        "pdf_sha256": sha,
        "note": "第1页 User's Guide；第3页目录点名 BOOSTXL-C2KLED；第5页 Kit Specifications 与五行一致",
    }]
    _save_render("BOOSTXL-C2KLED", doc)
    print("C2K promoted", sha[:12])


def refresh_contract_findings(doc: dict) -> list[dict]:
    """身份或作用域修正后，丢掉会回放的旧阻断，只保留对当前文档重算的发现。"""
    from qc.scope_contract import validate_contract

    meta = doc.setdefault("metadata", {})
    stale = meta.pop("scope_contract_findings", None)
    if stale:
        meta["scope_contract_findings_before_refresh"] = stale
    findings = validate_contract(doc)
    meta["scope_contract_findings"] = findings
    meta["scope_contract_refresh"] = {
        "method": "drop_replayed_findings_then_validate_contract",
        "fresh_finding_count": len(findings),
        "note": "旧 unknown_identity 只归档，不作为当前阻断；电气行 not_checked 不因此变成已审计",
    }
    return findings


def fix_adc() -> None:
    pdf = find_pdf("ADC12DJ5200SE", ROOT / "data" / "pdfs")
    page1 = extract_pages(pdf, [1], timeout_s=8)
    if page1.get("status") != "ok":
        raise SystemExit(f"ADC page1 {page1.get('status')}")
    text = "\n".join(row["text"] for row in page1["pages_data"][0]["rows"])
    if "ADC12DJ5200" not in text:
        raise SystemExit("ADC page 1 does not name the device; refusing to promote")
    doc = _load("ADC12DJ5200SE")
    specs = doc.setdefault("specs", {})
    urs = specs.get("unresolved_specs") or {}
    specs["electrical"] = urs.get("electrical") or []
    specs["absolute_max"] = urs.get("absolute_max") or []
    pkg = urs.get("package") if isinstance(urs.get("package"), dict) else {}
    pkg.setdefault("type", "FCBGA (144)")
    specs["package"] = pkg
    specs["scope"] = "device"
    for key in ("electrical", "absolute_max", "package", "pin_configuration"):
        urs.pop(key, None)
    for row in specs["electrical"] + specs["absolute_max"]:
        row.setdefault("verification", {
            "status": "not_checked",
            "reason": "device_datasheet_rows_not_rechecked_this_run",
        })
        row["scope"] = "device"
        row["subject_mpn"] = "ADC12DJ5200SE"
    bi = doc.setdefault("basic_info", {})
    bi["identity"] = "chip"
    bi["identity_state"] = "IDENTITY_REVIEW"
    bi["document_scope"] = "device_datasheet"
    bi["document_evidence"] = [{
        "kind": "cached_page",
        "page": 1,
        "pdf_sha256": page1["pdf_sha256"],
        "note": "第1页点名 ADC12DJ5200；订购表里的 EVM 已分离，不据此把器件判为未知",
    }]
    for row in doc.get("related_evaluation_boards") or []:
        row.pop("package", None)
        row["scope"] = "board"
        row["subject_kind"] = "evaluation_board"
    box = {}

    def run() -> None:
        box["result"] = PR.repair_bga_pins(doc, pdf, max_pages=8)

    worker = threading.Thread(target=run, daemon=True)
    worker.start()
    worker.join(20)
    if worker.is_alive() or "result" not in box:
        doc["pin_configuration"] = []
        doc["pin_scope"] = "unresolved"
        action = "timeout_unresolved"
    else:
        action = box["result"].get("action")
    findings = refresh_contract_findings(doc)
    _save_render("ADC12DJ5200SE", doc)
    print("ADC", action, "pins", len(doc.get("pin_configuration") or []),
          "findings", len(findings),
          "sym", (OUT / "symbols" / "ADC12DJ5200SE.html").stat().st_size)


def fix_ads_symbols() -> None:
    doc = _load("ADS8568EVM-PDK")
    _save_render("ADS8568EVM-PDK", doc)
    text = (OUT / "symbols" / "ADS8568EVM-PDK.html").read_text(encoding="utf-8")
    print("ADS8568 symbols confirmed", "未确认实际焊装" in text, "64-VQFN" in text)


if __name__ == "__main__":
    fix_c2k()
    fix_adc()
    fix_ads_symbols()
