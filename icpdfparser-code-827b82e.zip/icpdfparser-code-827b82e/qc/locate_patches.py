#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定位 11 个 JSON 内全部需修补的文本点（grep 上下文）"""
import io, json, re, sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
D = Path(__file__).parent / "json"

PATTERNS = {
    "5962-9053801PA_6f82dd51": ["0.9", "1.2", "0.01", "Leakage", "Forward"],
    "74LVC1G132DCKTG4_fae33d78": ["SN74", "Ioff", "VCC = 0", "0 µA", "SN74LVC1G132"],
    "ADC3910S065IRSMT_7af659e2": ["24mW", "24 mW", "58", "24mA", "24 mA", "power consumption"],
    "ADS7812B_1K_59798d0a": ["ADS7812B", "ADS7812U", "Pin-compatible", "DATACLK"],
    "AM26C32IDG4_3aad0953": ["pin"],
    "BQ24300DSGR_05d2b0aa": ["2.5", "10.2", "4.30", "200 mV", "5.5V"],
    "BUF634PG4_176bed1f": ["SOIC", "SOIC-8", "PDIP", "BUF634A", "BUF634P"],
    "CD74FCT244SM96_8eff426e": ["SOIC", "DW", "SSOP", "SM", "VCC"],
    "CDC421106RGER_9fcd7ef8": ["100 MHz", "312.5", "106.25", "100MHz", "312.5 MHz"],
    "CY74FCT245ATSOCT_bb7c5082": ["A to B", "B to A", "A→B", "B→A", "transmit", "Transmit", "direction", "T/R"],
    "DAC8555IPWG4_f63797db": ["IOIDD", "0.65", "10 µA", "IDD"],
}

def walk(obj, path, hits, pats):
    if isinstance(obj, dict):
        for k, v in obj.items():
            walk(v, f"{path}.{k}", hits, pats)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk(v, f"{path}[{i}]", hits, pats)
    elif isinstance(obj, str):
        for p in pats:
            if p.lower() in obj.lower():
                hits.append((path, p, obj[:200]))
                break

for stem, pats in PATTERNS.items():
    d = json.loads((D / f"{stem}.json").read_text(encoding="utf-8"))
    hits = []
    walk(d, "$", hits, pats)
    print("=" * 88)
    print(f"### {stem}  ({len(hits)} hits)")
    for path, p, txt in hits:
        print(f"  [{p}] {path}")
        print(f"      {txt!r}")
