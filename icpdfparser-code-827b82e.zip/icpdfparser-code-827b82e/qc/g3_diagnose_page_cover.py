"""选页覆盖只读诊断（零模型调用）：回答「新选页方案是否覆盖了电气真值页」。

背景
----
6a 只重解了 AFE4490 / AM6421 两件，其余 9 件 v2 与 v2_pre6a_backup 字节级
相同——所以「11 件全 PASS」里有 9 件是空转，不携带信息。回归夹具（FIXTURES）
又与这批样本**零交集**，三件关键件（AFE4490 / AM6421 / AM5746）都不在夹具里。

于是 T3（>100 页）长文档的方案安全性，目前只有 AM6421 一件有效证据。
本脚本用于在不付费重解析的前提下，先拿到风险画像。

回答的五个问题
--------------
1. 选页差异：旧方案与当前（V4）各选了哪些页，新增/移除哪些；
2. 电气覆盖：PDF 里电气特性相关页有多少，当前选中多少；
3. 预算风险：电气章节跨页分布、表格被截断、关键条件页未选中的迹象；
4. 历史证据：旧 JSON 的电气参数能否定位到原 PDF 页，还是仅存在于旧结果；
5. 诊断边界：严格区分三类——
     (a) 页面未选中  → 选页方案的锅
     (b) 页面已选中但未提取 → 抽取/prompt 的锅
     (c) 旧值来源不可靠     → 旧 JSON 有值但 PDF 里找不到出处

关键纪律（本会话已犯四次的同一根因）
----------------------------------
**取证源必须是「模型实际看到的输入」**，即 `select_pages()` 挑出来的页，
不能用 PDF 全文去判定「有没有覆盖」。用全文取證会奖惩颠倒：
惩罚诚实（V4 没把垃圾行写进去）、奖励幻觉（旧 JSON 编了个数）。

本脚本同时给出全文取证与选页取证，但**结论只采信选页取证**，
全文取证仅用于回答问题 4（旧值是否有出处）与问题 3（分布画像）。

只读保证
--------
- PDF 用 pymupdf **只读打开**，用完即关；
- 生产 JSON 只 `read_text`；
- 唯一的写入是 `--json-out` 显式指定的报告路径（不指定则不写任何文件）；
- 不 import `worker`、不连 SQLite、不触发任何模型调用。

用法
----
    python qc/g3_diagnose_page_cover.py --mpn AM5746ABZXEA
    python qc/g3_diagnose_page_cover.py --mpn AM5746ABZXEA \
        --json-out data/qc/gates/am5746_cover.json
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                                # noqa: E402

# 旧选页方案的基线提交：165cabc 引入「电气档字符保底 + 分档配额」，
# 其父提交 8b50dc3 即「尾部保底前」的选页逻辑。
OLD_SELECT_REV = "8b50dc3"

# 电气特性章节的判据（用于统计「PDF 里有多少电气相关页」）
ELEC_CHAPTER_PATS = [
    re.compile(r"electrical\s+characteristic", re.I),
    re.compile(r"absolute\s+maximum\s+rating", re.I),
    re.compile(r"recommended\s+operating\s+condition", re.I),
    re.compile(r"operating\s+condition", re.I),
    re.compile(r"specification", re.I),
]

# 「关键条件页」判据：表格里的测试条件（VDD=xx、TA=xx 等）
CONDITION_PAT = re.compile(
    r"(?:\bV\s*(?:DD|CC|IO|CORE)\b\s*[=:]|\bT\s*[AJ]\b\s*[=:]|"
    r"\b(?:over\s+recommended|test\s+conditions?)\b)", re.I)


# ---------------------------------------------------------------- PDF 全文

def _read_pdf_full(pdf: Path, report: dict) -> list[tuple[int, str]]:
    """pymupdf 直读全文。

    不用 `PD._iter_pages`：它到 `MAX_PAGES` 就 break，拿它搜 474 页
    只能搜到前 14 页，会让诊断自己制造假阴性。
    """
    try:
        import fitz                                          # noqa: PLC0415
        with fitz.open(str(pdf)) as doc:
            return [(i + 1, doc[i].get_text("text") or "")
                    for i in range(doc.page_count)]
    except Exception as e:                                   # noqa: BLE001
        report["warnings"].append(
            f"pymupdf 读取失败：{type(e).__name__}: {e}；fallback 到 _iter_pages"
            f"（到 MAX_PAGES 会 break，全文统计可能被截断）")
    out: list[tuple[int, str]] = []
    for pn, text in PD._iter_pages(str(pdf)):
        if isinstance(pn, int) and pn < 1:
            pn += 1
        out.append((pn, text or ""))
    return out


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        # 逐块读，避免大 PDF 一次性载入
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------- 旧选页方案

def _extract_consts_and_fn(src: str, fn_name: str) -> list[ast.stmt]:
    """从旧版源码里挑出「模块级常量赋值」+ 指定函数，避免执行 import 副作用。"""
    tree = ast.parse(src)
    keep: list[ast.stmt] = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
            if names and all(n.isupper() for n in names):
                keep.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name == fn_name:
            keep.append(node)
    return keep


def select_pages_old(pages, max_pages: int, max_chars: int):
    """旧选页逻辑（`165cabc` 之前）：head 打底 + 按 (档位, 页号) 升序填充。

    与当前 V4 的差别正是本诊断要测的两点：
      1. **无电气档字符保底**（`ELEC_FLOOR_CHARS`）；
      2. **无「首尾各半」重排**（`_ec_pick_order`），电气档按页号升序取，
         于是电气章节一旦靠后，就会被前面的档挤光预算。

    常量取**当前值**：`165cabc` 只改了算法，未改 `MAX_PAGES` / `MAX_CHARS` /
    `PAGE_PRIORITY` / `RANK_QUOTA`（见 HANDOFF §步 4 的「磁盘实际参数」备注）。
    """
    head: list[tuple[int, int, str]] = []
    ranked: list[tuple[int, int, str]] = []
    for i, text in pages:
        if i >= PD.PAGE_SCAN_CAP:
            break
        if not (text or "").strip():
            continue
        if i < 3:
            head.append((0, i, text))
            continue
        low = (text or "").lower()
        rank = len(PD.PAGE_PRIORITY) + 1
        for n, keys in enumerate(PD.PAGE_PRIORITY, start=1):
            if any(k in low for k in keys):
                rank = n
                break
        ranked.append((rank, i, text))

    chosen: list[tuple[int, str]] = []
    chars, dropped, taken = 0, False, {}
    for rank, i, text in head + sorted(ranked, key=lambda x: (x[0], x[1])):
        quota = (PD.RANK_QUOTA[rank - 1]
                 if 1 <= rank <= len(PD.RANK_QUOTA) else 99)
        if taken.get(rank, 0) >= quota:
            continue
        if len(chosen) >= max_pages or chars + len(text) > max_chars:
            dropped = True
            continue
        chosen.append((i, text))
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)

    chosen.sort()
    out = "".join(f"\n--- Page {i + 1} ---\n{t}" for i, t in chosen)
    return out, len(chosen), dropped


def load_old_select_pages(report: dict):
    """优先从 git 提取旧版 select_pages；容器无 git 时回退到内联实现。"""
    try:
        r = subprocess.run(["git", "show", f"{OLD_SELECT_REV}:parse_datasheets.py"],
                           cwd=str(ROOT), capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            report["notes"].append(
                f"无 git（{r.stderr.strip()[:60]}）→ 旧选页用内联回退实现")
            return select_pages_old
        ns: dict = {}
        exec(compile(ast.Module(body=_extract_consts_and_fn(r.stdout, "select_pages"),
                                type_ignores=[]), "<old_select>", "exec"), ns)
        return ns.get("select_pages") or select_pages_old
    except Exception as e:                                   # noqa: BLE001
        report["notes"].append(
            f"旧版选页提取失败（{type(e).__name__}: {e}）→ 用内联回退实现")
        return select_pages_old


# ---------------------------------------------------------------- 取证

def _hit_pages(pages_text, pat: re.Pattern) -> list[int]:
    return [pn for pn, text in pages_text if pat.search(text)]


def _snippet(text: str, pat: re.Pattern, before: int = 200,
             after: int = 260) -> str:
    m = pat.search(text)
    if not m:
        return ""
    i = m.start()
    return re.sub(r"\s+", " ", text[max(0, i - before):i + after]).strip()


def _has_number_near(text: str, pat: re.Pattern, window: int = 120) -> bool:
    """参数名后 `window` 字符内是否紧跟数值（判断「有没有真值」）。"""
    for m in pat.finditer(text):
        seg = text[m.end():m.end() + window]
        if re.search(r"\d", seg):
            return True
    return False


def _classify(in_sel: list[int], in_pdf: list[int], has_val: bool) -> str:
    """三类边界：不可混为一谈。"""
    if not in_pdf:
        return "PDF_UNLOCATABLE"          # (c) 旧值来源不可靠
    if not in_sel:
        return "PAGE_NOT_SELECTED"        # (a) 页面未选中 → 选页方案
    if in_sel and not has_val:
        return "SELECTED_NOT_EXTRACTED"   # (b) 已选中但未提取
    return "COVERED"


# ---------------------------------------------------------------- 主流程

def diagnose(mpn: str, data_dir: Path, ctx_pages: list[int] | None = None) -> dict:
    report: dict = {"mpn": mpn, "warnings": [], "notes": []}
    pdf_dir = data_dir / "pdfs"
    hits = (sorted(pdf_dir.glob(f"{mpn}__*.pdf"))
            or sorted(pdf_dir.glob(f"{mpn}*.pdf")))
    if not hits:
        report["error"] = f"PDF 未找到：{pdf_dir}/{mpn}*.pdf"
        return report
    pdf = hits[0]
    report["pdf"] = str(pdf)
    try:
        report["pdf_sha256"] = sha256_of(pdf)
    except Exception as e:                                   # noqa: BLE001
        report["warnings"].append(f"SHA256 计算失败：{type(e).__name__}: {e}")

    pages_text = _read_pdf_full(pdf, report)
    report["page_count"] = len(pages_text)

    # ① 选页差异：当前 V4 vs 旧方案
    try:
        text_v4, used_v4, trunc_v4 = PD.select_pages(
            iter(pages_text), PD.MAX_PAGES, PD.MAX_CHARS)
        sel_v4 = sorted({int(n) for n in
                         re.findall(r"^---\s*Page\s+(\d+)\s*---", text_v4, re.M)})
    except Exception as e:                                   # noqa: BLE001
        report["warnings"].append(f"V4 选页失败：{type(e).__name__}: {e}")
        sel_v4, used_v4, trunc_v4 = [], -1, False

    old_fn = load_old_select_pages(report)
    sel_old: list[int] = []
    used_old = -1
    if old_fn is not None:
        try:
            text_old, used_old, _tr = old_fn(
                iter(pages_text), PD.MAX_PAGES, PD.MAX_CHARS)
            sel_old = sorted({int(n) for n in
                              re.findall(r"^---\s*Page\s+(\d+)\s*---", text_old, re.M)})
        except Exception as e:                               # noqa: BLE001
            report["warnings"].append(f"旧方案选页失败：{type(e).__name__}: {e}")

    report["page_diff"] = {
        "current_v4": sel_v4, "used": used_v4, "truncated": bool(trunc_v4),
        "old_rev": OLD_SELECT_REV, "old": sel_old, "old_used": used_old,
        "added": sorted(set(sel_v4) - set(sel_old)),
        "removed": sorted(set(sel_old) - set(sel_v4)),
    }

    # ② 电气覆盖：PDF 全文里的电气相关页 vs 当前选中
    elec_pages = sorted({p for pat in ELEC_CHAPTER_PATS
                         for p in _hit_pages(pages_text, pat)})
    report["elec_coverage"] = {
        "elec_pages_in_pdf": len(elec_pages),
        "elec_pages_sample": elec_pages[:30],
        "elec_pages_selected": sorted(set(elec_pages) & set(sel_v4)),
        "n_selected": len(set(elec_pages) & set(sel_v4)),
        "note": "全文统计仅用于分布画像；判定覆盖必须看 ③ 的选页取证",
    }

    # ③ 预算风险：电气章节跨页分布 + 选中页连续性 + 条件页
    consec: list[list[int]] = []
    for p in elec_pages:
        if consec and p == consec[-1][-1] + 1:
            consec[-1].append(p)
        else:
            consec.append([p])
    runs = [c for c in consec if len(c) >= 2]
    truncated_chapters = [
        {"pages": c, "selected": sorted(set(c) & set(sel_v4))}
        for c in runs if len(set(c) & set(sel_v4)) not in (0, len(c))
    ]
    cond_pages = _hit_pages(pages_text, CONDITION_PAT)
    report["budget_risk"] = {
        "MAX_PAGES": PD.MAX_PAGES, "MAX_CHARS": PD.MAX_CHARS,
        "used": used_v4, "truncated": bool(trunc_v4),
        "elec_chapter_runs": [c for c in runs],
        "partially_selected_runs": truncated_chapters,
        "condition_pages_in_pdf": len(cond_pages),
        "condition_pages_selected": sorted(set(cond_pages) & set(sel_v4)),
    }

    # ④ 历史证据：旧 JSON 电气参数能否定位到原 PDF 页
    prod = sorted((data_dir / "parsed").glob(f"{mpn}_*.json"))
    legacy: list[dict] = []
    if prod:
        try:
            doc = json.loads(prod[0].read_text(encoding="utf-8"))
            es = (doc.get("specs") or {}).get("electrical") or []
            for e in es:
                name = str(e.get("name") or "").strip()
                val = str(e.get("value") or "").strip()
                if not name:
                    continue
                pat = re.compile(re.escape(name), re.I)
                hp = _hit_pages(pages_text, pat)
                # 名字太特殊时回退到「首个单词 + 数字」的宽松判据
                loose = None
                if not hp:
                    w = re.split(r"[\s(]", name)[0]
                    if len(w) >= 3:
                        loose = re.compile(re.escape(w), re.I)
                        hp = _hit_pages(pages_text, loose)
                legacy.append({
                    "name": name,
                    "v1_value": val,
                    "v1_blank": (val == "" or val.lower() == "not_specified"),
                    "located_by": "exact" if loose is None else "loose",
                    "pages_in_pdf": hp[:12],
                    "pages_in_pdf_total": len(hp),
                    "in_current_sel": sorted(set(hp) & set(sel_v4)),
                    "value_traceable": _has_number_near(
                        " ".join(t for pn, t in pages_text if pn in (hp or [])), pat)
                    if hp else False,
                })
        except Exception as e:                               # noqa: BLE001
            report["warnings"].append(
                f"生产基线解析失败：{type(e).__name__}: {e}")
        report["prod_json"] = str(prod[0])
    else:
        report["warnings"].append("生产基线 JSON 未找到")
    report["legacy_evidence"] = legacy

    # ⑤ 边界分类汇总
    cats = {"COVERED": [], "PAGE_NOT_SELECTED": [],
            "SELECTED_NOT_EXTRACTED": [], "PDF_UNLOCATABLE": []}
    for r in legacy:
        c = _classify(r["in_current_sel"] if r["in_current_sel"] else [],
                      r["pages_in_pdf"], r["value_traceable"])
        cats[c].append({"name": r["name"], "v1_value": r["v1_value"],
                        "pages": r["pages_in_pdf"][:6]})
    report["boundary_classification"] = cats
    report["notes"].append(
        "旧 JSON 有、V4 没有 ≠ V4 退化：还需旧值有 PDF 出处 + 来源页被选中")
    return report


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="选页覆盖只读诊断（零模型调用）")
    ap.add_argument("--mpn", default="AM5746ABZXEA")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--json-out", default=None,
                    help="报告写入路径（不指定则不写任何文件）")
    a = ap.parse_args(argv)

    rep = diagnose(a.mpn, Path(a.data_dir))
    text = json.dumps(rep, ensure_ascii=False, indent=2)
    print(text)
    if a.json_out:
        out = Path(a.json_out)
        if out.parent and str(out.parent) not in ("", "."):
            out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        print(f"\n[written] {out}", file=sys.stderr)
    return 0 if not rep.get("error") else 1


if __name__ == "__main__":
    raise SystemExit(main())
