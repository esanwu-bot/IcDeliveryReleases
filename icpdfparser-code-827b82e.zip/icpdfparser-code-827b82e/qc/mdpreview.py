"""极简 Markdown → HTML 预览渲染（自包含，无第三方依赖；server 进程安全）。

为什么需要：浏览器对 `text/markdown` **不渲染**（Edge/Chrome 都只显示源码），
而核验单/对照表是给人看的，需要可读排版与打印。

支持子集（够本项目用，且**先转义再套标签**，不做危险 HTML 透传）：
  # / ## / ### 标题、`|` 表格、`- ` 列表、`> ` 引用、`---` 分隔线、
  ``` 代码块、**粗体**、`行内代码`、[文本](链接)、自动换行段落。
安全：所有原文先做 HTML 转义，再到生成的标签；表格内的 `\\|` 还原为 `|` 显示。
"""
from __future__ import annotations

import re

_ESC = (("&", "&amp;"), ("<", "&lt;"), (">", "&gt;"))
_INLINE_CODE = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*(.+?)\*\*")
_LINK = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")
_CODE_FENCE = re.compile(r"^```")
_HR = re.compile(r"^-{3,}\s*$")
_UL = re.compile(r"^\s*[-*]\s+(.*)$")
_OL = re.compile(r"^\s*\d+[.)]\s+(.*)$")
_TABLE_SEP = re.compile(r"^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def esc(s: str) -> str:
    for a, b in _ESC:
        s = s.replace(a, b)
    return s


def inline(s: str) -> str:
    """行内格式（输入已转义）。"""
    s = _INLINE_CODE.sub(r"<code>\1</code>", s)
    s = _BOLD.sub(r"<strong>\1</strong>", s)
    s = _LINK.sub(r'<a href="\2" target="_blank" rel="noopener">\1</a>', s)
    return s


_CELL_SPLIT = re.compile(r"(?<!\\)\|")
_TASK = re.compile(r"^\[( |x|X)\]\s+(.*)$")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")   # NUL 等控制符（PDF 文本里真实存在）


def _cells(line: str) -> list:
    """拆表格行：`\\|` 视为单元格内的字面竖线（字段值里常见 `a\\|b`）。"""
    body = line.strip()
    if body.startswith("|"):
        body = body[1:]
    if body.endswith("|") and not body.endswith("\\|"):
        body = body[:-1]
    return [c.strip().replace("\\|", "|") for c in _CELL_SPLIT.split(body)]


def _li(text: str) -> str:
    """列表项：支持 GFM 任务清单 `- [ ] 未核 / - [x] 已核`（核验单主体就是清单）。"""
    m = _TASK.match(text.strip())
    if not m:
        return f"<li>{inline(esc(text))}</li>"
    box = '<input type="checkbox" disabled' + (" checked" if m.group(1) in "xX" else "") + ">"
    return f'<li class="task">{box} {inline(esc(m.group(2)))}</li>'


def to_html(md: str, title: str = "", subtitle: str = "") -> str:
    # 控制符（尤其 PDF 文本里的 NUL）会让浏览器把页面当二进制/吞字符，先清掉
    lines = _CTRL.sub("", (md or "")).replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out: list[str] = []
    i, n = 0, len(lines)
    while i < n:
        raw = lines[i]
        line = esc(raw.rstrip())
        s = raw.strip()

        if not s:
            i += 1
            continue

        if _CODE_FENCE.match(s):
            i += 1
            buf = []
            while i < n and not _CODE_FENCE.match(lines[i].strip()):
                buf.append(esc(lines[i]))
                i += 1
            i += 1
            out.append("<pre><code>" + "\n".join(buf) + "</code></pre>")
            continue

        if _HR.match(s):
            out.append("<hr>")
            i += 1
            continue

        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            lvl = len(m.group(1))
            out.append(f"<h{lvl}>{inline(esc(m.group(2)))}</h{lvl}>")
            i += 1
            continue

        if s.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(inline(esc(lines[i].strip()[1:].strip())))
                i += 1
            out.append("<blockquote>" + "<br>".join(buf) + "</blockquote>")
            continue

        # 表格：当前行以 | 开头，下一行是分隔行
        if s.startswith("|") and i + 1 < n and _TABLE_SEP.match(lines[i + 1].strip()):
            head = _cells(s)
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append(_cells(lines[i]))
                i += 1
            t = ["<table><thead><tr>"]
            t += [f"<th>{inline(esc(c))}</th>" for c in head]
            t.append("</tr></thead><tbody>")
            for r in rows:
                t.append("<tr>" + "".join(f"<td>{inline(esc(c))}</td>" for c in r) + "</tr>")
            t.append("</tbody></table>")
            out.append("".join(t))
            continue

        if _UL.match(raw):
            buf = []
            while i < n and _UL.match(lines[i]):
                buf.append(_UL.match(lines[i]).group(1))
                i += 1
            out.append("<ul>" + "".join(_li(x) for x in buf) + "</ul>")
            continue

        if _OL.match(raw):
            buf = []
            while i < n and _OL.match(lines[i]):
                buf.append(inline(esc(_OL.match(lines[i]).group(1))))
                i += 1
            out.append("<ol>" + "".join(f"<li>{x}</li>" for x in buf) + "</ol>")
            continue

        # 段落：合并连续普通行
        buf = [inline(line)]
        i += 1
        while i < n:
            nxt = lines[i]
            ns = nxt.strip()
            if (not ns or ns.startswith(("#", ">", "|", "-", "*")) or _CODE_FENCE.match(ns)
                    or _HR.match(ns) or _UL.match(nxt) or _OL.match(nxt)):
                break
            buf.append(inline(esc(ns)))
            i += 1
        out.append("<p>" + "<br>".join(buf) + "</p>")

    css = """
:root{--fg:#1f2937;--mut:#6b7280;--bd:#d8dee7;--bg:#fff;--accent:#2563eb}
*{box-sizing:border-box}
body{margin:0;padding:28px 20px 60px;background:#f6f7f9;color:var(--fg);
 font:14px/1.65 -apple-system,"Segoe UI","Microsoft YaHei",Roboto,sans-serif}
main{max-width:1120px;margin:0 auto;background:var(--bg);border:1px solid var(--bd);
 border-radius:10px;padding:28px 34px 40px;box-shadow:0 1px 3px rgba(16,24,40,.06)}
h1{font-size:22px;margin:0 0 6px;letter-spacing:.2px}
h2{font-size:16px;margin:26px 0 8px;padding-bottom:6px;border-bottom:2px solid #eef1f5;
 color:#111827}
h3,h4{font-size:14px;margin:16px 0 6px}
p{margin:8px 0;color:var(--fg)}
ul,ol{margin:8px 0 8px 22px;padding:0}
li{margin:3px 0}
li.task{list-style:none;margin-left:-16px}
li.task input{margin:0 6px 0 0;vertical-align:-1px}
code{background:#f3f5f8;border:1px solid #e6eaf0;border-radius:4px;padding:1px 5px;
 font:12.5px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;color:#0f172a}
pre{background:#0f172a;color:#e5e7eb;border-radius:8px;padding:12px 14px;overflow:auto;
 font:12.5px/1.6 ui-monospace,Consolas,monospace}
pre code{background:none;border:0;color:inherit;padding:0}
blockquote{margin:10px 0;padding:8px 12px;background:#fffbeb;border-left:3px solid #f59e0b;
 border-radius:0 6px 6px 0;color:#78350f}
hr{border:0;border-top:1px dashed var(--bd);margin:22px 0}
table{border-collapse:collapse;width:100%;margin:10px 0 16px;font-size:13px}
th,td{border:1px solid var(--bd);padding:6px 9px;text-align:left;vertical-align:top}
th{background:#f1f5f9;font-weight:600;white-space:nowrap}
tbody tr:nth-child(even){background:#fafbfc}
td code{white-space:nowrap}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
.sub{color:var(--mut);font-size:12.5px;margin:0 0 18px}
.bar{position:sticky;top:0;z-index:9;display:flex;gap:10px;align-items:center;
 margin:-28px -34px 18px;padding:10px 34px;background:#fff;border-bottom:1px solid var(--bd);
 border-radius:10px 10px 0 0}
.bar .sp{margin-left:auto}
@media print{body{background:#fff;padding:0}main{border:0;box-shadow:none;padding:0}
 .bar{display:none}table{font-size:11.5px}th,td{padding:4px 6px}}
"""
    head_title = esc(title or "IcPdfParser 文档")
    sub = f'<p class="sub">{esc(subtitle)}</p>' if subtitle else ""
    return (
        "<!DOCTYPE html>\n<html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        f"<title>{head_title}</title><style>{css}</style></head><body><main>"
        f"<div class=\"bar\"><strong>{head_title}</strong>"
        "<span class=\"sp\"></span>"
        "<button onclick=\"window.print()\">打印 / 另存 PDF</button></div>"
        f"{sub}{''.join(out)}</main></body></html>")


if __name__ == "__main__":                                       # pragma: no cover
    import sys as _sys
    from pathlib import Path as _P
    if len(_sys.argv) < 2:
        print("usage: python qc/mdpreview.py <file.md> [out.html]")
        raise SystemExit(2)
    src = _P(_sys.argv[1])
    html = to_html(src.read_text(encoding="utf-8"), title=src.stem)
    dst = _P(_sys.argv[2]) if len(_sys.argv) > 2 else src.with_suffix(".html")
    dst.write_text(html, encoding="utf-8")
    print(f"written {dst}")