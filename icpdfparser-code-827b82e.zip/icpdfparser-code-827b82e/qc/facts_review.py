"""r6 facts 语义裁决与人工验收清单生成器（只读）。

设计边界（与《r6 核验报告》的整改方案一致）：
  * Gold 的 ``not_specified`` **不等于** facts 旧值一定错误，更不等于可以把旧值直接删成
    ``not_specified``；本模块只做来源追溯、状态标注与待审台账，不修改 facts / Gold / DB。
  * 对 6 个 ``not_specified`` 字段输出：facts 值、Gold 期望、来源类型、是否能作为
    canonical 原厂规格发布、建议动作（待人工裁决）。
  * 生成独立人工抽查清单（机器预检只做 quote 回打与数字回显，不替代人工判定）。
  * 生成五语/视觉验收清单（机器只查文件存在与型号出现，母语审校/视觉仍为人工）。
  * 发布门禁沿用 PACKAGE_PASS / PROVENANCE_PASS / DATA_SEMANTICS_PASS /
    DOWNSTREAM_PASS / RELEASE_APPROVED；本模块不自动批准发布。

CLI（在服务器容器内运行，DB 以只读模式打开）::

    python qc/facts_review.py --db /app/data/workbench.sqlite3 \\
        --parsed-dir /app/data/parsed --txt-dir /app/data/txt \\
        --pdf-dir /app/data/pdfs --out-dir /app/data/qc/r6-20261028

import 时零 stdout，供 server 进程安全使用。
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = Path("/app/data") if Path("/app/data").is_dir() else ROOT / "data"
DEFAULT_MPNS = ("BUF634PG4", "DAC8555IPWG4")
NOT_SPECIFIED = "not_specified"

# 人工抽查范围：高风险字段（身份/封装/引脚/电源与电气关键项）。
SPOTCHECK = (
    ("BUF634PG4", "specs.package.type", "封装类型"),
    ("BUF634PG4", "specs.package.pins", "引脚数"),
    ("BUF634PG4", "electrical[13].value", "静态电流 IQ"),
    ("BUF634PG4", "electrical[15].value", "输入失调电压"),
    ("DAC8555IPWG4", "specs.package.type", "封装类型"),
    ("DAC8555IPWG4", "specs.package.pins", "引脚数"),
    ("DAC8555IPWG4", "electrical[8].value", "PSRR"),
    ("DAC8555IPWG4", "electrical[29].value", "VIL（逻辑输入低电平）"),
    ("DAC8555IPWG4", "electrical[30].value", "VIH（逻辑输入高电平）"),
)

LANGS = (("en", ""), ("ja", ".ja"), ("ko", ".ko"), ("de", ".de"), ("es", ".es"))

# canonical PDF 对旧值的支持情况（agent 已逐页回打；不是人工复核结论）。
TRACE = {
    ("BUF634PG4", "basic_info.category"): {
        "source_type": "distributor_taxonomy",
        "canonical_support": False,
        "trace": ("facts 值为分销类目；Rev B（canonical）与 Rev C 全文检索均无 "
                  "'Integrated Circuits'，'Amplifiers' 亦未作为类目出现 → 非数据手册规格。"),
        "options": ["retain_with_source_label", "set_not_specified"],
        "default_publish": False,
        "suggested_action": "retain_with_source_label（业务/分销分类，需明确标注非原厂规格）",
    },
    ("BUF634PG4", "electrical[18].value"): {
        "source_type": "legacy_revision_other_package",
        "canonical_support": False,
        "trace": ("facts JSON 的 pdf_hash=176bed1f…（Rev C，40 页）；64 dB 位于 Rev C "
                  "p7 'Electrical Characteristics: Wide-Bandwidth Mode for SOIC Package' "
                  "PSRR TYP；canonical Rev B 仅在 p8 Figure 8 给出典型曲线，无数值规格行。"),
        "options": ["remove_from_canonical_facts", "retain_with_source_label",
                    "set_not_specified"],
        "default_publish": False,
        "suggested_action": "quarantine_or_replace（不得作为 Rev B PDIP 的已核验规格发布）",
    },
    ("BUF634PG4", "electrical[20].value"): {
        "source_type": "legacy_revision_other_package",
        "canonical_support": False,
        "trace": ("Rev C p7 'Output headroom to supplies' IO=±10 mA TYP=1.6 V（MAX=1.8 V）；"
                  "canonical Rev B EC 表无 headroom 行，仅有 Voltage Output。"),
        "options": ["remove_from_canonical_facts", "retain_with_source_label",
                    "set_not_specified"],
        "default_publish": False,
        "suggested_action": "quarantine_or_replace（不得作为 Rev B PDIP 的已核验规格发布）",
    },
    ("BUF634PG4", "electrical[21].value"): {
        "source_type": "legacy_revision_other_package",
        "canonical_support": False,
        "trace": ("Rev C p7 'Output headroom to supplies' IO=±100 mA TYP=2.0 V（MAX=2.2 V）；"
                  "canonical Rev B EC 表无 headroom 行。"),
        "options": ["remove_from_canonical_facts", "retain_with_source_label",
                    "set_not_specified"],
        "default_publish": False,
        "suggested_action": "quarantine_or_replace（不得作为 Rev B PDIP 的已核验规格发布）",
    },
    ("BUF634PG4", "electrical[22].value"): {
        "source_type": "legacy_revision_other_package",
        "canonical_support": False,
        "trace": ("Rev C p7 'Output headroom to supplies' IO=±150 mA TYP=2.2 V（MAX=2.5 V）；"
                  "canonical Rev B EC 表无 headroom 行。"),
        "options": ["remove_from_canonical_facts", "retain_with_source_label",
                    "set_not_specified"],
        "default_publish": False,
        "suggested_action": "quarantine_or_replace（不得作为 Rev B PDIP 的已核验规格发布）",
    },
    ("DAC8555IPWG4", "basic_info.category"): {
        "source_type": "distributor_taxonomy",
        "canonical_support": False,
        "trace": ("facts 值为分销类目；DAC8555 canonical PDF 全文无 'Integrated Circuits'，"
                  "'Analog' 仅出现在一般描述，未作为 category 字段出现。"),
        "options": ["retain_with_source_label", "set_not_specified"],
        "default_publish": False,
        "suggested_action": "retain_with_source_label（业务/分销分类，需明确标注非原厂规格）",
    },
}

_NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")
_TOK_RE = re.compile(r"([^\.\[\]]+)|\[([^\]]*)\]")


def _now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _numbers(text: str) -> set:
    return {m.replace(",", ".") for m in _NUM_RE.findall(text or "")}


def resolve_path(obj, path: str):
    """按 data 路径取值：basic_info.category / electrical[18].value。"""
    cur = obj
    for name, idx in _TOK_RE.findall(path or ""):
        if name:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(name)
        else:
            if not isinstance(cur, (list, tuple)):
                return None
            try:
                cur = cur[int(idx)]
            except (ValueError, IndexError):
                return None
        if cur is None:
            return None
    return cur


def resolve_facts(facts: dict, path: str):
    """兼容 Gold 字段路径约定：`electrical[18].value` 实际位于 `specs.electrical[18]`。"""
    value = resolve_path(facts, path)
    if value is None and not (path or "").startswith("specs."):
        value = resolve_path(facts, "specs." + path)
    return value


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _find_facts(mpn: str, json_path: str, parsed_dir: Path) -> Path | None:
    p = Path(json_path or "")
    if p.is_file():
        return p
    if p.name:
        cand = Path(parsed_dir) / p.name
        if cand.is_file():
            return cand
    cands = [c for c in sorted(Path(parsed_dir).glob(mpn + "_*.json"))
             if not c.name.endswith(".pre_audit")]
    return cands[-1] if cands else None


def _find_pdf(mpn: str, item: dict, gold: dict, pdf_dir: Path) -> Path | None:
    for raw in (item.get("pdf_path") or "", str(Path(pdf_dir) / (gold.get("pdf_name") or ""))):
        if raw and Path(raw).is_file():
            return Path(raw)
    cands = sorted(Path(pdf_dir).glob(mpn + "__*.pdf"))
    return cands[0] if cands else None


def _norm_sql_args(mpns) -> tuple:
    return tuple(mpns)


def _canonical(db, mpns) -> list:
    ph = ",".join("?" * len(mpns))
    return db.q("SELECT id,version,mpn,manufacturer,pdf_name,pdf_sha256,doc_rev,status,note "
                "FROM gold_set WHERE mpn IN (%s) ORDER BY id" % ph, _norm_sql_args(mpns))


def _item(db, mpn: str) -> dict:
    return db.q1("SELECT id,mpn,pdf_path,pdf_sha256,pdf_bytes,json_path,meta "
                 "FROM item WHERE mpn=?", (mpn,)) or {}


def _fields(db, gid: int) -> list:
    return db.q("SELECT id,field_path,field_name,expected,unit,cond,page_no,evidence,status,"
                "verified_by,verified_at FROM gold_field WHERE gold_id=? ORDER BY id", (gid,))


def _evidence(db, fid: int) -> dict:
    return db.q1("SELECT id,evidence_id,document_id,gold_field_id,field_path,page_number,"
                 "table_name,row_key,column_key,cell_value,evidence_quote,verification_status,"
                 "reviewer,verified_at,notes,engine FROM source_field_evidence "
                 "WHERE gold_field_id=? ORDER BY CASE WHEN verification_status='verified' "
                 "THEN 0 ELSE 1 END, id LIMIT 1", (fid,)) or {}


def _pdf_pages(path: Path | None) -> list | None:
    if not path or not path.is_file():
        return None
    try:
        import pymupdf
    except Exception:                                        # noqa: BLE001
        try:
            import fitz as pymupdf                         # type: ignore
        except Exception:                                    # noqa: BLE001
            return None
    try:
        doc = pymupdf.open(str(path))
        pages = [doc[i].get_text() for i in range(doc.page_count)]
        doc.close()
        return pages
    except Exception:                                        # noqa: BLE001
        return None


def _quote_on_page(pages, page_no: int, quote: str) -> bool | None:
    if pages is None:
        return None
    if not quote or not page_no or page_no < 1 or page_no > len(pages):
        return False
    return _norm(quote) in _norm(pages[page_no - 1])


def collect_adjudication(db, mpns, parsed_dir: Path, pdf_dir: Path) -> tuple[list, list, dict]:
    """返回 (6 字段裁决行, 诊断, 各 MPN 的 canonical/facts 元信息)。"""
    fields_out, diagnostics, canon_info = [], [], {}
    for g in _canonical(db, mpns):
        mpn = g["mpn"]
        item = _item(db, mpn)
        facts_path = _find_facts(mpn, item.get("json_path") or "", parsed_dir)
        facts = {}
        if facts_path:
            try:
                facts = json.loads(facts_path.read_text(encoding="utf-8"))
            except Exception:                                # noqa: BLE001
                facts = {}
        meta = facts.get("metadata") or {}
        patch = meta.get("r4_patch") or {}
        facts_sha = (meta.get("pdf_hash") or "").strip()
        canon_sha = (g.get("pdf_sha256") or "").strip()
        canon_info[mpn] = {
            "gold_id": g["id"], "gold_version": g["version"], "gold_status": g["status"],
            "canonical_pdf": g["pdf_name"], "canonical_sha256": canon_sha,
            "doc_rev": g["doc_rev"],
            "facts_file": str(facts_path) if facts_path else "",
            "facts_pdf_hash": facts_sha,
            "facts_parse_timestamp": meta.get("parse_timestamp") or "",
            "facts_source_matches_canonical": bool(facts_sha) and facts_sha == canon_sha,
            "r4_patch_at": patch.get("at") or "",
            "r4_patch_sha256": patch.get("sha256") or "",
            "item_json_path": item.get("json_path") or "",
            "item_pdf_path": item.get("pdf_path") or "",
            "item_pdf_sha256": item.get("pdf_sha256") or "",
            "item_pdf_bytes": item.get("pdf_bytes") or 0,
        }
        for f in _fields(db, g["id"]):
            if (f.get("expected") or "").strip().lower() != NOT_SPECIFIED:
                continue
            value = resolve_facts(facts, f["field_path"])
            if value is None or str(value).strip() == "":
                continue
            value = str(value).strip()
            tr = TRACE.get((mpn, f["field_path"]), {})
            source_type = tr.get("source_type") or (
                "legacy_revision_or_other_document"
                if facts_sha and facts_sha != canon_sha else "canonical_pdf_extra")
            r4_changed = any((c.get("path") or "") == f["field_path"]
                             for c in (patch.get("changes") or []))
            fields_out.append({
                "mpn": mpn,
                "gold_id": g["id"],
                "gold_field_id": f["id"],
                "field_path": f["field_path"],
                "field_name": f["field_name"],
                "facts_value": value,
                "facts_value_with_unit": (value + (" " + f["unit"] if f["unit"] else "")),
                "unit": f["unit"],
                "gold_expected": f["expected"],
                "gold_status": f["status"],
                "gold_page_no": f["page_no"],
                "gold_evidence": f["evidence"],
                "gold_cond": f["cond"],
                "source_type": source_type,
                "source_trace": tr.get("trace") or (
                    "facts metadata 与 canonical PDF SHA 不一致" if facts_sha != canon_sha
                    else "facts 与 canonical PDF 同源，但 Gold 未给出可确认值"),
                "canonical_support": bool(tr.get("canonical_support")),
                "facts_source_sha256": facts_sha,
                "canonical_sha256": canon_sha,
                "r4_patch_at": patch.get("at") or "",
                "r4_patch_sha256": patch.get("sha256") or "",
                "r4_patch_touched_field": r4_changed,
                "canonical_pdf_verified": False,
                "publish_as_canonical": False,
                "verification_status": "pending_review",
                "options": tr.get("options") or ["retain_with_source_label", "set_not_specified"],
                "suggested_action": tr.get("suggested_action") or "pending_review",
                "reviewer": "",
                "reviewed_at": "",
                "decision": "",
            })
        diag = []
        if facts_sha and facts_sha != canon_sha:
            diag.append({
                "mpn": mpn, "code": "FACTS_SOURCE_NOT_CANONICAL",
                "status": "OPEN",
                "detail": "facts JSON 派生自 %s，canonical 为 %s；facts 未按 canonical 重新生成"
                          % (facts_sha[:12], canon_sha[:12]),
                "action": "裁决 6 字段前先确认是否需要按 Rev B 重渲染；不得把旧 facts 当作已核验 canonical 规格",
            })
        pdf = _find_pdf(mpn, item, g, Path(pdf_dir))
        if pdf:
            try:
                actual_sha, actual_bytes = _sha256(pdf), pdf.stat().st_size
            except Exception:                                # noqa: BLE001
                actual_sha, actual_bytes = "", 0
            if item and (item.get("pdf_sha256") or "") != actual_sha:
                diag.append({
                    "mpn": mpn, "code": "ITEM_PDF_SHA_MISMATCH",
                    "status": "OPEN",
                    "detail": "item.pdf_path=%s，文件 SHA=%s（%s B），但 item.pdf_sha256=%s（%s B）"
                              % (item.get("pdf_path") or "", actual_sha[:12], actual_bytes,
                                 (item.get("pdf_sha256") or "")[:12],
                                 item.get("pdf_bytes") or 0),
                    "action": "修正 item.pdf_sha256 / pdf_bytes 使其描述当前 pdf_path；"
                              "facts 来源另记 metadata.pdf_hash，不能混同",
                })
        diagnostics.extend(diag)
    return fields_out, diagnostics, canon_info


def collect_spotcheck(db, mpns, pdf_dir: Path) -> list:
    out, pages_cache = [], {}
    for mpn, path, label in SPOTCHECK:
        g = db.q1("SELECT id,mpn,pdf_name,pdf_sha256 FROM gold_set WHERE mpn=? "
                  "ORDER BY id DESC LIMIT 1", (mpn,))
        if not g:
            continue
        f = db.q1("SELECT id,field_path,field_name,expected,unit,cond,page_no,evidence,status,"
                  "verified_by FROM gold_field WHERE gold_id=? AND field_path=?",
                  (g["id"], path))
        if not f:
            continue
        ev = _evidence(db, f["id"])
        item = _item(db, mpn)
        pdf = _find_pdf(mpn, item, g, Path(pdf_dir))
        if mpn not in pages_cache:
            pages_cache[mpn] = _pdf_pages(pdf)
        pages = pages_cache[mpn]
        quote = ev.get("evidence_quote") or ""
        page = ev.get("page_number") or f["page_no"] or 0
        quote_ok = _quote_on_page(pages, page, quote)
        qnums = _numbers(quote)
        enums = _numbers(f["expected"])
        cnums = _numbers(ev.get("cell_value") or "")
        expected_ok = None if quote_ok is None else (not enums or enums <= qnums)
        cell_ok = None if quote_ok is None else (not cnums or cnums <= qnums)
        flags = []
        if quote_ok is False:
            flags.append("QUOTE_NOT_ON_PAGE")
        if expected_ok is False:
            flags.append("EXPECTED_NUMBER_NOT_IN_QUOTE")
        if cell_ok is False:
            flags.append("CELL_VALUE_NOT_ECHOED")
        if ev and not (ev.get("cell_value") or "").strip():
            flags.append("NO_CELL_VALUE")
        if quote_ok is None:
            machine = "NOT_CHECKED"
        elif quote_ok and expected_ok in (True, None) and cell_ok in (True, None):
            machine = "PASS"
        else:
            machine = "FAIL"
        out.append({
            "mpn": mpn, "label": label, "field_path": path,
            "field_name": f["field_name"], "expected": f["expected"], "unit": f["unit"],
            "gold_page_no": f["page_no"], "gold_evidence": f["evidence"],
            "evidence_id": ev.get("id") or 0,
            "evidence_page": page,
            "evidence_table": ev.get("table_name") or "",
            "evidence_row": ev.get("row_key") or "",
            "evidence_column": ev.get("column_key") or "",
            "cell_value": ev.get("cell_value") or "",
            "evidence_quote": quote,
            "evidence_status": ev.get("verification_status") or "",
            "evidence_reviewer": ev.get("reviewer") or "",
            "machine_precheck": {
                "status": machine,
                "quote_on_page": quote_ok,
                "expected_number_in_quote": expected_ok,
                "cell_value_numbers_in_quote": cell_ok,
                "flags": flags,
                "pdf": str(pdf) if pdf else "",
            },
            "human_review": {
                "status": "NOT_CHECKED", "reviewer": "", "reviewed_at": "",
                "result": "", "note": "机器预检不替代独立人工判定",
            },
        })
    return out


def collect_translation(txt_dir: Path, mpns) -> dict:
    out = {"files": [], "summary": {}, "human_review": {
        "status": "NOT_CHECKED", "reviewer": "", "reviewed_at": "",
        "note": "母语审校独立记录；机器只检查文件存在/型号出现"}}
    ok = total = 0
    for mpn in mpns:
        for code, suffix in LANGS:
            name = "%s%s.txt" % (mpn, suffix)
            p = Path(txt_dir) / name
            total += 1
            exists = p.is_file()
            text = ""
            if exists:
                try:
                    text = p.read_text(encoding="utf-8", errors="replace")
                except Exception:                            # noqa: BLE001
                    text = ""
            has_mpn = mpn in text
            status = "PASS" if exists and has_mpn else "FAIL"
            ok += 1 if status == "PASS" else 0
            out["files"].append({
                "mpn": mpn, "lang": code, "name": name, "exists": exists,
                "bytes": p.stat().st_size if exists else 0,
                "contains_mpn": has_mpn, "machine_status": status,
                "human_status": "NOT_CHECKED", "reviewer": "", "reviewed_at": "",
            })
    out["summary"] = {"total": total, "PASS": ok, "FAIL": total - ok,
                      "human_status": "NOT_CHECKED"}
    return out


def collect_visual(data_dir: Path, mpns) -> dict:
    out = {"artifacts": [], "human_review": {
        "status": "NOT_CHECKED", "reviewer": "", "reviewed_at": "",
        "note": "浏览器实际渲染（详情页/符号图/替代料/SEO）未验收"}}
    for mpn in mpns:
        for rel in ("symbols/%s.html" % mpn, "seo/%s.json" % mpn,
                    "alts/%s.html" % mpn):
            p = Path(data_dir) / rel
            out["artifacts"].append({
                "mpn": mpn, "path": rel, "exists": p.is_file(),
                "bytes": p.stat().st_size if p.is_file() else 0,
                "human_status": "NOT_CHECKED",
            })
    return out


def release_gates() -> dict:
    """当前发布门禁（不自动批准）。"""
    return {
        "PACKAGE_PASS": {
            "status": "PASS",
            "basis": "L1 13/13；ZIP SHA/CRC/26 条目/解压逐字节一致",
        },
        "PROVENANCE_PASS": {
            "status": "NOT_CHECKED",
            "basis": "canonical PDF / Gold / 证据链一致；但 facts 仍派生自 Rev C，"
                     "且 BUF item.pdf_sha256 与 pdf_path 不一致（见诊断）",
        },
        "DATA_SEMANTICS_PASS": {
            "status": "NOT_CHECKED",
            "basis": "6 个 not_specified 字段待裁决；独立人工抽查未执行",
        },
        "DOWNSTREAM_PASS": {
            "status": "FAIL",
            "basis": "全量 11 件回归 2 PASS / 9 FAIL；浏览器视觉未验收",
        },
        "RELEASE_APPROVED": {
            "status": "FAIL", "approved": False,
            "basis": "以上门禁未全部通过，且无正式发布批准记录",
        },
    }


def build_ledger(db, mpns=DEFAULT_MPNS, parsed_dir: Path | None = None,
                 txt_dir: Path | None = None, pdf_dir: Path | None = None) -> dict:
    parsed_dir = Path(parsed_dir or DEFAULT_DATA / "parsed")
    txt_dir = Path(txt_dir or DEFAULT_DATA / "txt")
    pdf_dir = Path(pdf_dir or DEFAULT_DATA / "pdfs")
    fields, diagnostics, canon = collect_adjudication(db, mpns, parsed_dir, pdf_dir)
    spot = collect_spotcheck(db, mpns, pdf_dir)
    trans = collect_translation(txt_dir, mpns)
    visual = collect_visual(parsed_dir.parent, mpns)
    by_source = {}
    for f in fields:
        by_source[f["source_type"]] = by_source.get(f["source_type"], 0) + 1
    return {
        "ledger_version": 1,
        "generated_at": _now(),
        "scope": list(mpns),
        "principle": ("Gold not_specified 不代表 facts 旧值必错，也不代表旧值可作为已核验"
                      "原厂规格发布；先追溯来源与字段语义，再由人工裁决。本台账不修改 "
                      "facts 值、不修改 Gold。"),
        "canonical": canon,
        "adjudication": {
            "summary": {
                "fields": len(fields),
                "pending_review": sum(1 for f in fields
                                      if f["verification_status"] == "pending_review"),
                "resolved": 0,
                "facts_modified": False,
                "gold_modified": False,
                "by_source_type": by_source,
            },
            "fields": fields,
        },
        "diagnostics": diagnostics,
        "spotcheck": {
            "note": "机器预检 = quote 回打 + 数字回显；独立人工抽查仍未执行",
            "items": spot,
            "summary": {
                "total": len(spot),
                "machine_pass": sum(1 for s in spot
                                    if s["machine_precheck"]["status"] == "PASS"),
                "machine_fail": sum(1 for s in spot
                                    if s["machine_precheck"]["status"] == "FAIL"),
                "machine_not_checked": sum(1 for s in spot
                                           if s["machine_precheck"]["status"] == "NOT_CHECKED"),
                "human_checked": 0,
            },
        },
        "translation": trans,
        "visual": visual,
        "release_gates": release_gates(),
        "release_approved": False,
    }


def render_markdown(led: dict) -> str:
    lines = []
    add = lines.append
    add("# r6 facts 语义裁决与待审清单")
    add("")
    add("生成时间：%s  " % led["generated_at"])
    add("范围：**%s**（两件 frozen 样本）  " % " + ".join(led["scope"]))
    add("台账版本：v%s" % led["ledger_version"])
    add("")
    add("> %s" % led["principle"])
    add("")
    add("## 0. 发布门禁（不自动批准）")
    add("")
    add("| 门禁 | 状态 | 依据 |")
    add("|---|---|---|")
    for k in ("PACKAGE_PASS", "PROVENANCE_PASS", "DATA_SEMANTICS_PASS",
              "DOWNSTREAM_PASS", "RELEASE_APPROVED"):
        g = led["release_gates"][k]
        add("| `%s` | **%s** | %s |" % (k, g["status"], g["basis"]))
    add("")
    add("**结论**：交付包完整性通过；facts 语义、人工抽查与下游范围门禁未闭环，"
        "`RELEASE_APPROVED = false`。")
    add("")
    add("## 1. 6 个 `not_specified` 字段（facts 旧值 vs Gold）")
    add("")
    add("| MPN | 字段 | facts 值 | Gold | 来源判定 | canonical 支持 | 可作 canonical 发布 | 建议动作 | 裁决 |")
    add("|---|---|---|---|---|---|---|---|---|")
    for f in led["adjudication"]["fields"]:
        add("| %s | `%s` | %s | `%s` | `%s` | %s | %s | %s | %s |" % (
            f["mpn"], f["field_path"], f["facts_value_with_unit"], f["gold_expected"],
            f["source_type"], "是" if f["canonical_support"] else "否",
            "是" if f["publish_as_canonical"] else "否",
            f["suggested_action"], "待人工（%s）" % f["verification_status"]))
    add("")
    add("说明：`not_specified` 是当前 canonical 证据边界，不等于旧值为假；本台账不删值、不改值。")
    add("")
    add("### 1.1 来源追溯")
    add("")
    for f in led["adjudication"]["fields"]:
        add("- **%s `%s`**：%s  " % (f["mpn"], f["field_path"], f["source_trace"]))
        add("  Gold 证据：p%s / %s；Gold cond：%s  " %
            (f["gold_page_no"], f["gold_evidence"], f["gold_cond"] or "—"))
        add("  facts 源 SHA：`%s`；canonical SHA：`%s`；r4 是否覆盖该字段：%s" % (
            (f["facts_source_sha256"] or "—")[:12], f["canonical_sha256"][:12],
            "是" if f["r4_patch_touched_field"] else "否"))
    add("")
    add("## 2. 来源诊断（不自动修复）")
    add("")
    if led["diagnostics"]:
        add("| MPN | 代码 | 状态 | 详情 | 建议动作 |")
        add("|---|---|---|---|---|")
        for d in led["diagnostics"]:
            add("| %s | `%s` | %s | %s | %s |" % (
                d["mpn"], d["code"], d["status"], d["detail"], d["action"]))
    else:
        add("无。")
    add("")
    add("## 3. 独立人工抽查清单（机器预检 ≠ 人工判定）")
    add("")
    add("| MPN | 字段 | 页码 | 原文 quote | 期望 | 机器预检 | 人工结果 | 审核人 |")
    add("|---|---|---|---|---|---|---|---|")
    for s in led["spotcheck"]["items"]:
        m = s["machine_precheck"]
        flags = ("；" + ", ".join(m["flags"])) if m["flags"] else ""
        add("| %s | `%s` | p%s | %s | %s | %s%s | 未执行 | — |" % (
            s["mpn"], s["field_path"], s["evidence_page"],
            (s["evidence_quote"] or "—").replace("|", "\\|"), s["expected"],
            m["status"], flags))
    add("")
    add("机器预检：%s" % json.dumps(led["spotcheck"]["summary"], ensure_ascii=False))
    add("")
    add("人工复核必须逐项记录：PDF 页码、原文、预期值、实际值、审核人、结果；"
        "机器 quote 回打不能替代独立判定。")
    add("")
    add("## 4. 五语与视觉验收")
    add("")
    add("五语文件机器检查：%s" % json.dumps(led["translation"]["summary"],
                                          ensure_ascii=False))
    add("")
    add("| MPN | 语言 | 文件 | 存在 | 型号出现 | 母语审校 |")
    add("|---|---|---|---|---|---|")
    for t in led["translation"]["files"]:
        add("| %s | %s | `%s` | %s | %s | 未执行 |" % (
            t["mpn"], t["lang"], t["name"], "是" if t["exists"] else "否",
            "是" if t["contains_mpn"] else "否"))
    add("")
    add("视觉验收：未在浏览器实际渲染验收（详情页/符号图/替代料/SEO）；"
        "建议 BUF、DAC 各抽 1 组页面。")
    add("")
    add("## 5. 复现")
    add("")
    add("```bash")
    add("cd /app && python qc/facts_review.py \\")
    add("  --db /app/data/workbench.sqlite3 --parsed-dir /app/data/parsed \\")
    add("  --txt-dir /app/data/txt --pdf-dir /app/data/pdfs \\")
    add("  --out-dir /app/data/qc/r6-20261028")
    add("```")
    add("")
    add("本台账只读生成：不修改 `gold_set` / `gold_field` / `source_field_evidence` / facts JSON。")
    add("")
    return "\n".join(lines)


class ReadOnlyDB:
    """对 sqlite 文件以只读 URI 打开，供 CLI 使用。"""

    def __init__(self, path: Path):
        uri = "file:%s?mode=ro" % Path(path).as_posix()
        self.c = sqlite3.connect(uri, uri=True)
        self.c.row_factory = sqlite3.Row

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args)]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None


def write_outputs(led: dict, out_dir: Path) -> tuple[Path, Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    jp = out_dir / "facts_adjudication.json"
    mp = out_dir / "facts_adjudication.md"
    jp.write_text(json.dumps(led, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    mp.write_text(render_markdown(led), encoding="utf-8")
    return jp, mp


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="r6 facts 语义裁决与人工验收清单（只读）")
    ap.add_argument("--db", default=str(DEFAULT_DATA / "workbench.sqlite3"))
    ap.add_argument("--parsed-dir", default=str(DEFAULT_DATA / "parsed"))
    ap.add_argument("--txt-dir", default=str(DEFAULT_DATA / "txt"))
    ap.add_argument("--pdf-dir", default=str(DEFAULT_DATA / "pdfs"))
    ap.add_argument("--out-dir", default=str(DEFAULT_DATA / "qc" / "r6-20261028"))
    ap.add_argument("--mpns", nargs="*", default=list(DEFAULT_MPNS))
    args = ap.parse_args(argv)
    db = ReadOnlyDB(Path(args.db))
    led = build_ledger(db, args.mpns, Path(args.parsed_dir), Path(args.txt_dir),
                       Path(args.pdf_dir))
    jp, mp = write_outputs(led, Path(args.out_dir))
    print("written %s" % jp)
    print("written %s" % mp)
    print(json.dumps(led["adjudication"]["summary"], ensure_ascii=False))
    print(json.dumps(led["release_gates"], ensure_ascii=False)[:600])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
