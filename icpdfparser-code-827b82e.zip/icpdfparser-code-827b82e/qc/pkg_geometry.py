#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从原厂数据手册的 PACKAGE OUTLINE 页抽取封装机械尺寸（确定性，不用模型）。

为什么值得做
------------
BGA / 网格族此前一律出占位图，理由是「无球列、无几何来源，不猜」。这条红线本身没错，
但把「没有来源」和「没去找」混成了一件事 —— TI 数据手册末几页的 **PACKAGE OUTLINE**
就是一张带尺寸标注的机械图：body、总高、standoff、pitch、球径、球数全都写着。
按坐标把这些标注读出来，几何来源就从「没有」变成「原厂机械图第 N 页，图纸号 xxx」。
这不是猜，这是**换一个地方取证**。

不猜的三条硬约束
----------------
1. **只认能互证的组合。** 抽出来的 pitch / span / 球数必须同时满足
   ``|span - (n-1)·pitch| < 0.06`` 与 ``rows × cols == ball_count``；
   body 名义尺寸必须大于 span；总高必须不小于 standoff；球径必须小于 pitch。
   任一条不成立 → 整份返回 ``None``，页面继续出占位图。**宁可没有图，不可有错图。**
2. **每个值都带出处。** 页码、span 原文、bbox 全部落进 ``evidence``，
   复核方可以按 bbox 回 PDF 回读原文；``source_sha256`` 由「取值 + 页码 + PDF 哈希
   + 图纸号」规范化算出，页面引用它作可信来源哈希。
3. **缺项不退让。** 没有默认值、没有典型值兜底。少一个必需字段就整份返回 ``None``。
   body 尺寸还必须**两条标注线互证**（同一对 min/max 在图上出现两次）才采信 ——
   单条标注意味着可能是别的对象（比如托盘尺寸）。

只覆盖 BGA / 网格族
-------------------
非网格封装（双列 / 四边 / 板卡）本来就有既有画法，本轮不动，避免一次改动面过大把
已经通过验收的页面牵连进去。

用法
----
    python qc/pkg_geometry.py --pdf data/pdfs/ADC12DJ5200SEAAV__adc12dj5200se.pdf
    python qc/pkg_geometry.py --pdf <pdf> --json data/parsed/XXX.json   # 打印派生状态
    python qc/pkg_geometry.py --pdf <pdf> --apply data/parsed/XXX.json  # 写入并回显
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

SCHEMA = "package-geometry/v1"

#: 数值等价判定的容差（mm）。机械图标注到两位小数，0.06 足够吸收舍入。
TOL_MM = 0.06

#: 一条尺寸线最多两行（min/max 叠排），行间距落在这个区间。
_PAIR_DY = (4.0, 14.0)
#: 两行数字要纵向对齐（同一 x 起点）才认为是同一条尺寸线。
_PAIR_DX = 1.2
#: 「TYP」标注与数值的相邻判定：横向或纵向缝隙不超过这个值。
_ADJ_GAP = 8.0

_PURE_NUM = re.compile(r"^\d+(?:\.\d+)?$")
_TYP_TAIL = re.compile(r"^(\d+(?:\.\d+)?)\s+TYP$")
_BALL_COUNT = re.compile(r"^(\d+)X$")
_HEIGHT_TITLE = re.compile(
    r"^(?P<fam>[A-Z][A-Z0-9 /.-]*?)\s*-\s*(?P<h>\d+(?:\.\d+)?)\s*mm\s+max\s+height$", re.I)
_DRAWING_CODE = re.compile(r"^[A-Z]{2,4}\d{4}[A-Z]$")
_DRAWING_NO = re.compile(r"^(?P<no>\d{6,8})\s*/\s*(?P<rev>[A-Z])\b")
_NOTE_MM = re.compile(r"dimensions?\s+are\s+in\s+millimeters", re.I)


# ─────────────────────────────────────────────────────────────────────
# 1. 页面取证
# ─────────────────────────────────────────────────────────────────────

def _spans(page) -> list[dict]:
    """页面上的文本 span：文字 + bbox + 字号。保持 PDF 内部顺序（不做重排）。"""
    out: list[dict] = []
    for block in page.get_text("dict").get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            for sp in line.get("spans", []):
                text = (sp.get("text") or "").strip()
                if not text:
                    continue
                x0, y0, x1, y1 = sp["bbox"]
                out.append({"text": text,
                            "bbox": [round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2)],
                            "size": round(float(sp.get("size") or 0), 2)})
    return out


def _find_outline_page(doc) -> tuple[int, list[dict]] | None:
    """找 PACKAGE OUTLINE 页。标题是页面里字号最大的那几个 span 之一。"""
    for i, page in enumerate(doc):
        spans = _spans(page)
        for sp in spans:
            if sp["text"].upper() == "PACKAGE OUTLINE" and sp["size"] >= 11:
                return i + 1, spans
    return None


def _adjacent(a: dict, b: dict) -> bool:
    """两个 bbox 是否紧邻（横向贴边同一带，或纵向贴边同一列）。"""
    ax0, ay0, ax1, ay1 = a["bbox"]
    bx0, by0, bx1, by1 = b["bbox"]
    h_gap = max(bx0 - ax1, ax0 - bx1)
    v_gap = max(by0 - ay1, ay0 - by1)
    h_overlap = min(ax1, bx1) - max(ax0, bx0)
    v_overlap = min(ay1, by1) - max(ay0, by0)
    if h_gap <= _ADJ_GAP and v_overlap > 0:
        return True
    return v_gap <= _ADJ_GAP and h_overlap > 0


def _tolerance_pairs(spans: list[dict]) -> list[dict]:
    """把「上下两行、左端对齐」的纯数值 span 收成一条尺寸线（min/max）。"""
    nums = [s for s in spans if _PURE_NUM.match(s["text"])]
    pairs: list[dict] = []
    used: set[int] = set()
    for i, a in enumerate(nums):
        if i in used:
            continue
        for j, b in enumerate(nums):
            if j <= i or j in used:
                continue
            if abs(a["bbox"][0] - b["bbox"][0]) > _PAIR_DX:
                continue
            dy = b["bbox"][1] - a["bbox"][1]
            if not (_PAIR_DY[0] <= dy <= _PAIR_DY[1]):
                continue
            hi, lo = (a, b) if float(a["text"]) >= float(b["text"]) else (b, a)
            pairs.append({"hi": float(hi["text"]), "lo": float(lo["text"]),
                          "spans": [hi, lo]})
            used.add(i)
            used.add(j)
            break
    return pairs


def _typ_values(spans: list[dict]) -> list[tuple[float, dict]]:
    """带 TYP 标注的数值（TYP = 该值无公差，图上一律画成标称值）。

    两种写法都要收：同一个 span 里写着 `0.8   TYP`，以及数字与 `TYP` 分成两个 span
    上下/左右相邻（TI 的纵向尺寸线常见后者）。
    """
    typ_spans = [s for s in spans if s["text"].upper() == "TYP"]
    out: list[tuple[float, dict]] = []
    for sp in spans:
        m = _TYP_TAIL.match(sp["text"])
        if m:
            out.append((float(m.group(1)), sp))
            continue
        if not _PURE_NUM.match(sp["text"]):
            continue
        if any(_adjacent(sp, t) for t in typ_spans):
            out.append((float(sp["text"]), sp))
    return out


def _pick_body(pairs: list[dict]) -> dict | None:
    """body 长宽：同一对 min/max 必须在图上出现**两次**（横竖两条标注线互证）。"""
    buckets: dict[tuple[float, float], list[dict]] = {}
    for p in pairs:
        buckets.setdefault((p["lo"], p["hi"]), []).append(p)
    multi = [(k, v) for k, v in buckets.items() if len(v) >= 2]
    if not multi:
        return None
    # 若有多组都出现两次，取尺寸最大的那组（body 一定是图里最大的那个量）
    multi.sort(key=lambda kv: kv[0][1], reverse=True)
    key, group = multi[0]
    return {"lo": key[0], "hi": key[1], "count": len(group),
            "spans": [s for p in group for s in p["spans"]]}


def _pick_standoff(pairs: list[dict], taken: list[dict],
                   typ_spans: list[dict]) -> dict | None:
    """standoff（A1）：带 TYP 标注、且没被 height / 球径 / body 占用，且必须唯一。"""
    used = {id(s) for p in taken for s in p["spans"]}
    cands = [p for p in pairs
             if not (id(p["spans"][0]) in used or id(p["spans"][1]) in used)
             and any(_adjacent(s, t) for s in p["spans"] for t in typ_spans)]
    if len(cands) != 1:
        return None
    return cands[0]


# ─────────────────────────────────────────────────────────────────────
# 2. 抽取主流程
# ─────────────────────────────────────────────────────────────────────

def _canonical(values: dict) -> str:
    return json.dumps(values, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))


def _round(v: float) -> float:
    return round(float(v), 4)


def extract(pdf_path: str | Path, *, expected_pins: int = 0) -> dict | None:
    """从一个 PDF 抽取封装几何。抽不出**自洽**的一组就返回 None（调用方继续占位图）。

    返回结构见模块 docstring；``checks`` 里逐条列出互证结果，``ok`` 全 True 才会返回。
    """
    import fitz                                             # noqa: PLC0415

    path = Path(pdf_path)
    if not path.is_file():
        return None
    pdf_sha = hashlib.sha256(path.read_bytes()).hexdigest()

    doc = fitz.open(str(path))
    try:
        found = _find_outline_page(doc)
        if not found:
            return None
        page_no, spans = found
        page_text = doc[page_no - 1].get_text()
    finally:
        doc.close()

    # ---- 标题行：族名 + 总高上限 -------------------------------------
    title = None
    for sp in spans:
        m = _HEIGHT_TITLE.match(sp["text"])
        if m:
            title = {"text": sp["text"], "family": m.group("fam").strip(),
                     "height_max": float(m.group("h")), "bbox": sp["bbox"]}
            break
    if not title:
        return None

    pairs = _tolerance_pairs(spans)
    if not pairs:
        return None

    # ---- 总高：装得下标题那句 max height 的那条尺寸线 -------------------
    height = next((p for p in pairs
                   if abs(p["hi"] - title["height_max"]) < 1e-9), None)
    if not height:
        return None                      # 图上的数与标题对不上 → 不采信

    # ---- 球数与球径：`144X` 右侧的两行数字 ------------------------------
    ball_count = 0
    ball_dia = None
    for sp in spans:
        m = _BALL_COUNT.match(sp["text"])
        if not m:
            continue
        ball_count = int(m.group(1))
        right = [p for p in pairs
                 if all(s["bbox"][0] >= sp["bbox"][2] - 1 for s in p["spans"])
                 and abs((p["spans"][0]["bbox"][1] + p["spans"][1]["bbox"][3]) / 2
                         - (sp["bbox"][1] + sp["bbox"][3]) / 2) <= 12]
        if len(right) == 1:
            ball_dia = right[0]
        break
    if not ball_count or not ball_dia:
        return None

    body = _pick_body(pairs)
    if not body:
        return None

    # ---- standoff：带 TYP、且不与上面几条重叠 ---------------------------
    typ_spans = [s for s in spans if s["text"].upper() == "TYP"]
    standoff = _pick_standoff(pairs, [height, ball_dia], typ_spans)
    if not standoff:
        return None

    # ---- pitch 与 span：带 TYP 的值里找一对能自证的 ---------------------
    typ_vals = _typ_values(spans)
    counts: dict[float, int] = {}
    for v, _ in typ_vals:
        counts[v] = counts.get(v, 0) + 1
    repeated = [v for v, c in counts.items() if c >= 2]
    body_nom = (body["lo"] + body["hi"]) / 2
    # pitch 一定小于 body 的一半（再大的就不是球间距了）；
    # span 是比 pitch 大、但仍小于 body 的那个带 TYP 的重复值。
    pitches = sorted(v for v in repeated if v < body_nom / 2)
    if not pitches:
        return None
    span_vals = sorted((v for v in repeated
                        if pitches[-1] < v < body_nom), reverse=True)
    if not span_vals:
        return None

    pick = None
    for pitch in pitches:
        for span_v in span_vals:
            steps = span_v / pitch
            n = round(steps) + 1
            if n < 2 or abs(steps - round(steps)) > TOL_MM / pitch:
                continue
            if n * n != ball_count:
                continue
            pick = {"pitch": pitch, "span": span_v, "n": n}
            break
        if pick:
            break
    if not pick:
        return None

    pitch, span_v, n = pick["pitch"], pick["span"], pick["n"]
    rows = cols = n

    # ---- 互证 ---------------------------------------------------------
    body_x = {"min": _round(body["lo"]), "max": _round(body["hi"]),
              "nominal": _round(body_nom)}
    body_y = dict(body_x)                    # 两条标注线同值，横竖无法区分也无需区分
    checks = [
        {"name": "unit_mm", "ok": bool(_NOTE_MM.search(page_text)) or "mm" in title["text"],
         "detail": "图上注明线性尺寸单位为毫米"},
        {"name": "height_matches_title",
         "ok": abs(height["hi"] - title["height_max"]) < 1e-9,
         "detail": f"标题 {title['height_max']} = 图上 {height['hi']}"},
        {"name": "pitch_span_rows",
         "ok": abs(span_v - (n - 1) * pitch) <= TOL_MM,
         "detail": f"{span_v} ≈ ({n}-1)×{pitch}"},
        {"name": "ball_count_grid",
         "ok": rows * cols == ball_count,
         "detail": f"{rows}×{cols} = {ball_count}"},
        {"name": "body_gt_span",
         "ok": body_nom > span_v,
         "detail": f"body {body_nom} > span {span_v}"},
        {"name": "height_ge_standoff",
         "ok": height["hi"] >= standoff["hi"],
         "detail": f"A {height['hi']} ≥ A1 {standoff['hi']}"},
        {"name": "ball_dia_lt_pitch",
         "ok": ball_dia["hi"] < pitch,
         "detail": f"b {ball_dia['hi']} < e {pitch}"},
        {"name": "body_corroborated",
         "ok": body["count"] >= 2,
         "detail": f"同一对 min/max 出现 {body['count']} 次（横竖互证）"},
    ]
    if expected_pins:
        checks.append({"name": "pins_match_ball_count",
                       "ok": int(expected_pins) == ball_count,
                       "detail": f"封装声明 {expected_pins} 球 / 图上 {ball_count}X"})
    if not all(c["ok"] for c in checks):
        return None

    drawing_code = next((sp["text"] for sp in spans
                         if _DRAWING_CODE.match(sp["text"])), "")
    drawing_no = ""
    for sp in spans:
        m = _DRAWING_NO.match(sp["text"])
        if m:
            drawing_no = f"{m.group('no')}/{m.group('rev')}"
            break

    values = {
        "family": title["family"],
        "body_x": body_x, "body_y": body_y,
        "height": {"min": _round(height["lo"]), "max": _round(height["hi"])},
        "standoff": {"min": _round(standoff["lo"]), "max": _round(standoff["hi"])},
        "pitch": _round(pitch),
        "span": {"x": _round(span_v), "y": _round(span_v)},
        "ball_diameter": {"min": _round(ball_dia["lo"]), "max": _round(ball_dia["hi"])},
        "ball_count": ball_count,
        "rows": rows, "cols": cols,
        "drawing_code": drawing_code,
        "drawing_no": drawing_no,
    }
    source_sha = hashlib.sha256(
        _canonical(dict(values, page=page_no, pdf_sha256=pdf_sha)).encode("utf-8")
    ).hexdigest()

    used_spans = [{"text": sp["text"], "bbox": sp["bbox"]}
                  for sp in ([title] + height["spans"] + ball_dia["spans"]
                             + standoff["spans"])]
    return {
        "schema": SCHEMA,
        "status": "extracted",
        **values,
        "checks": checks,
        "evidence": {
            "pdf_sha256": pdf_sha,
            "page": page_no,
            "title": title["text"],
            "drawing_code": drawing_code,
            "drawing_no": drawing_no,
            "spans": used_spans,
        },
        "source_sha256": source_sha,
    }


# ─────────────────────────────────────────────────────────────────────
# 3. 写进解析 JSON（渲染器与状态机都只读这里，不各自重解析 PDF）
# ─────────────────────────────────────────────────────────────────────

def attach(doc: dict, geometry: dict | None) -> dict:
    """把几何挂到 ``specs.package.geometry``。清空时删键，不写 null 占位。"""
    specs = doc.setdefault("specs", {})
    pkg = specs.get("package")
    if not isinstance(pkg, dict):
        pkg = {}
        specs["package"] = pkg
    if geometry:
        pkg["geometry"] = geometry
    else:
        pkg.pop("geometry", None)
    return doc


def geometry_of(doc: dict) -> dict | None:
    """读回几何；结构不完整一律当没有（渲染与状态共用这一个入口）。"""
    if not isinstance(doc, dict):
        return None
    pkg = ((doc.get("specs") or {}).get("package") or {})
    g = pkg.get("geometry") if isinstance(pkg, dict) else None
    if not isinstance(g, dict) or g.get("schema") != SCHEMA:
        return None
    need = ("body_x", "body_y", "height", "pitch", "ball_diameter",
            "ball_count", "rows", "cols", "source_sha256")
    if any(k not in g for k in need):
        return None
    if not all((c or {}).get("ok") for c in (g.get("checks") or [])):
        return None
    try:
        if int(g["rows"]) < 2 or int(g["cols"]) < 2 or float(g["pitch"]) <= 0:
            return None
    except (TypeError, ValueError):
        return None
    return g


def _find_pdf(pdf_dir: Path, doc: dict) -> Path | None:
    """按型号名找源 PDF。文件名是 `<MPN>__<slug>.pdf`，`/` 会被换成 `_`。"""
    bi = doc.get("basic_info") or {}
    names = [str(bi.get("mpn") or ""), str(bi.get("safe_name") or "")]
    names += [re.sub(r"[^A-Za-z0-9._-]+", "_", n) for n in list(names) if n]
    for name in dict.fromkeys(n for n in names if n):
        for pat in (f"{name}__*.pdf", f"{name}.pdf"):
            hits = sorted(pdf_dir.glob(pat))
            if len(hits) == 1:
                return hits[0]
            if len(hits) > 1:
                return None            # 多个候选 → 不猜，跳过
    return None


def apply_dir(parsed_dir: Path, pdf_dir: Path, *, write: bool = False) -> list[dict]:
    """对整个目录：能抽到几何就挂上，抽不到就**清掉旧键**（避免残留上一版结论）。"""
    rows: list[dict] = []
    for path in sorted(parsed_dir.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        mpn = (doc.get("basic_info") or {}).get("mpn") or path.stem
        pdf = _find_pdf(pdf_dir, doc)
        if not pdf:
            rows.append({"file": path.name, "mpn": mpn, "status": "no_pdf", "geometry": None})
            continue
        pins = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
        geom = extract(pdf, expected_pins=pins)
        attach(doc, geom)
        if write:
            path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8")
        rows.append({"file": path.name, "mpn": mpn,
                     "status": "extracted" if geom else "no_geometry",
                     "pdf": pdf.name, "geometry": geom})
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(description="从 PACKAGE OUTLINE 页抽取封装机械尺寸")
    ap.add_argument("--pdf", default="")
    ap.add_argument("--pins", type=int, default=0, help="封装声明的球数（用于互证）")
    ap.add_argument("--json", default="", help="解析 JSON：打印派生状态")
    ap.add_argument("--apply", default="", help="解析 JSON：写入 specs.package.geometry")
    ap.add_argument("--dir", default="", help="批量：解析 JSON 目录")
    ap.add_argument("--pdf-dir", default="", help="批量：PDF 目录")
    ap.add_argument("--write", action="store_true", help="批量：真正写回 JSON")
    a = ap.parse_args()

    if a.dir:
        rows = apply_dir(Path(a.dir), Path(a.pdf_dir or "data/pdfs"), write=a.write)
        for r in rows:
            if r["geometry"]:
                g = r["geometry"]
                print(f"OK   {r['mpn']:<18} {g['rows']}×{g['cols']}={g['ball_count']} "
                      f"e={g['pitch']} p.{g['evidence']['page']} {g['drawing_code']}")
            else:
                print(f"--   {r['mpn']:<18} {r['status']}（继续出占位图）")
        hit = sum(1 for r in rows if r["geometry"])
        print(f"\n{hit}/{len(rows)} 抽到几何" + ("，已写回" if a.write else "（未写回，加 --write）"))
        return

    if not a.pdf:
        ap.error("需要 --pdf 或 --dir")

    geom = extract(a.pdf, expected_pins=a.pins)
    if not geom:
        print("未抽取到自洽的封装几何（继续出占位图）")
        raise SystemExit(2)

    print(f"图纸 {geom['drawing_code']} {geom['drawing_no']} · 第 {geom['evidence']['page']} 页")
    print(f"body  {geom['body_x']['nominal']} × {geom['body_y']['nominal']} mm "
          f"({geom['body_x']['min']}~{geom['body_x']['max']})")
    print(f"高度  {geom['height']['min']}~{geom['height']['max']} mm  "
          f"standoff {geom['standoff']['min']}~{geom['standoff']['max']} mm")
    print(f"球阵  {geom['rows']}×{geom['cols']} = {geom['ball_count']} 球 · "
          f"pitch {geom['pitch']} mm · 球径 {geom['ball_diameter']['min']}~"
          f"{geom['ball_diameter']['max']} mm")
    for c in geom["checks"]:
        print(f"  {'OK ' if c['ok'] else 'BAD'} {c['name']}: {c['detail']}")
    print(f"source_sha256 {geom['source_sha256']}")

    if a.json or a.apply:
        target = Path(a.apply or a.json)
        doc = json.loads(target.read_text(encoding="utf-8"))
        attach(doc, geom)
        if a.apply:
            target.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n",
                              encoding="utf-8")
            print(f"已写入 {target}")
        else:
            sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
            import engineering_model as EM                     # noqa: PLC0415
            print(json.dumps(EM.derive_state(doc), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
