"""料号身份规则注册表的运维 CLI：自检 / 导入 / 离线回放。

用法
----
    python qc/identity_rules.py selftest            # 跑注册表里的 test_cases
    python qc/identity_rules.py import --actor me   # 校验 + 落 log（全绿才收）
    python qc/identity_rules.py replay --data-dir data/parsed [--limit N] [--out x.csv]
    python qc/identity_rules.py list

设计
----
* 注册表 JSON 是唯一事实来源，本 CLI 只做校验、日志与回放，不改判定逻辑；
* `import` 先跑 selftest，任一 case 不符就拒绝导入并回显差异（防止拍脑袋加规则）；
* 导入/修改都追加到 `qc/mpn_identity_rules.log.jsonl`（append-only，可追溯谁改了什么）；
* `replay` 用线上真实解析结果跑一遍新规则，输出各状态分布——
  这是「新规则会不会引发大面积假阳性」的最后一道防线。

零依赖（只用标准库），不 import app.*。
"""
from __future__ import annotations

import argparse
import csv
import datetime
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import board_identity as BI                       # noqa: E402

LOG_PATH = Path(__file__).resolve().parent / "mpn_identity_rules.log.jsonl"

# test_cases.expected 允许的取值 -> 判定口径
_EXPECT_HELP = {
    "BOARD": "规则命中，候选身份是板卡类",
    "BOARD_REVIEW": "规则命中但缺原厂证据（IDENTITY_REVIEW）",
    "BOARD_CONFIRMED": "规则命中且有板卡证据（BOARD_CONFIRMED）",
    "CHIP": "订货表命中（IDENTITY_SUPPORTED）",
    "PKG_VARIANT": "只是包装/等级变体写法，订货表证据推翻词表（SUPPORTED medium）",
    "CONFLICT": "只由正面矛盾证据触发（IDENTITY_CONFLICT）",
    "INCOMPLETE": "订货表没抽到（EVIDENCE_INCOMPLETE）",
}


def _synth_doc(mpn: str, case: dict) -> dict:
    """为 test_case 造一份最小 datasheet 快照。

    `case["orderables"]` 显式给了就用它（写反例时必需，否则造不出想要的表）；
    否则按 `expected` 推导：
      CHIP            -> 表里包含请求料号
      PKG_VARIANT     -> 表里是剥掉包装后缀的根号
      INCOMPLETE      -> 空表
      其余（板卡类）  -> 同族订货号（模拟「芯片 datasheet 被套在板卡料号上」）
    """
    exp = str(case.get("expected") or "").upper()
    fam = BI.family_root(mpn)
    explicit = case.get("orderables")
    if explicit:
        rows = [{"mpn": str(o)} for o in explicit]
    elif exp == "CHIP":
        rows = [{"mpn": mpn}]
    elif exp == "PKG_VARIANT":
        rows = [{"mpn": fam}]
    elif exp == "INCOMPLETE":
        rows = []
    else:
        # 同族芯片订货号（有 NOPB 与无铅两种，贴近真实 Package Option Addendum）
        rows = [{"mpn": fam + s} for s in ("CIMT/NOPB", "CIMTX/NOPB", "CIMT/NO.A")]
    return {"ordering_info": rows,
            "basic_info": {"mpn": mpn, "manufacturer": "Texas Instruments"}}


def _expect_ok(case: dict, info: dict) -> tuple[bool, str]:
    exp = str(case.get("expected") or "").upper()
    got_state = info.get("state")
    if exp == "BOARD":
        ok = got_state in (BI.CONFIRMED, BI.REVIEW) and BI.is_board(info)
    elif exp == "BOARD_REVIEW":
        ok = got_state == BI.REVIEW and BI.is_board(info)
    elif exp == "BOARD_CONFIRMED":
        ok = got_state == BI.CONFIRMED
    elif exp == "CHIP":
        ok = got_state == BI.SUPPORTED and info.get("identity") == "chip"
    elif exp == "PKG_VARIANT":
        # 反例用：词表命中了，但订货表证明它只是包装/等级变体 -> 必须是芯片
        ok = (got_state == BI.SUPPORTED and info.get("identity") == "chip"
              and info.get("confidence") == "medium")
    elif exp == "CONFLICT":
        ok = got_state == BI.CONFLICT
    elif exp == "INCOMPLETE":
        ok = got_state == BI.INCOMPLETE
    else:
        return False, "未知 expected=%r（可选：%s）" % (exp, "/".join(_EXPECT_HELP))
    return ok, "" if ok else "期望 %s，实得 %s（identity=%s，confidence=%s）" % (
        exp, got_state, info.get("identity"), info.get("confidence"))


def selftest(verbose: bool = True) -> tuple[int, int]:
    """跑全部 test_cases。返回 (通过数, 总数)。"""
    ok_n = bad_n = 0
    for r in BI.rules():
        for case in (r.get("test_cases") or []):
            mpn = str(case.get("mpn") or "")
            if not mpn:
                continue
            doc = _synth_doc(mpn, case)
            info = BI.classify(mpn, doc,
                               manufacturer=str(r.get("manufacturer") or ""))
            ok, why = _expect_ok(case, info)
            if ok:
                ok_n += 1
                if verbose:
                    print("  ✓ %-26s %-18s %s" % (mpn, info["state"], r["id"]))
            else:
                bad_n += 1
                print("  ✗ %-26s %-18s %s：%s" % (mpn, info["state"], r["id"], why))
    return ok_n, bad_n


def cmd_selftest(a) -> int:
    ok_n, bad_n = selftest()
    print("\n%d 通过 / %d 失败" % (ok_n, bad_n))
    return 0 if bad_n == 0 else 2


def cmd_list(a) -> int:
    rows = BI.rules()
    print("%-24s %-10s %-12s %-8s %-10s %s"
          % ("id", "厂商", "pattern", "置信度", "状态", "动作"))
    for r in rows:
        print("%-24s %-10s %-12s %-8s %-10s %s" % (
            r.get("id", ""), (r.get("manufacturer") or "*")[:10],
            r.get("pattern") or r.get("token") or "", r.get("confidence", ""),
            r.get("status", ""), r.get("action", "")))
    print("\n共 %d 条规则；候选（candidate）只提示，不参与冲突判决" % len(rows))
    return 0


def cmd_import(a) -> int:
    src = Path(a.file) if a.file else BI.RULES_PATH
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print("读不了规则文件：%s" % e)
        return 2
    if not isinstance(data.get("rules"), list) or not data["rules"]:
        print("规则文件缺 rules 数组")
        return 2
    for i, r in enumerate(data["rules"]):
        if not r.get("id"):
            print("第 %d 条缺 id" % (i + 1))
            return 2
    BI.reload_rules()
    ok_n, bad_n = selftest()
    if bad_n:
        print("\n拒绝导入：%d 条 test_case 未通过（先修规则或补证据）" % bad_n)
        return 2
    digest = hashlib.sha256(src.read_bytes()).hexdigest()[:16]
    rec = {"at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
           "actor": a.actor or "unknown", "action": "import",
           "file": str(src), "sha256_16": digest,
           "version": data.get("version"), "rules": len(data["rules"]),
           "selftest": {"ok": ok_n, "bad": bad_n}}
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print("导入校验通过：%d 条规则 / %d 个 case 全绿，已记 log %s"
          % (len(data["rules"]), ok_n, LOG_PATH.name))
    return 0


def cmd_replay(a) -> int:
    """离线回放：用真实 parsed JSON 跑一遍当前规则，看各状态分布。"""
    data_dir = Path(a.data_dir)
    files = sorted(data_dir.glob("*.json"))[:a.limit or None]
    if not files:
        print("没有可回放的解析结果：%s" % data_dir)
        return 2
    tally: dict[str, int] = {}
    by_id: dict[str, int] = {}
    samples: dict[str, list[str]] = {}
    rows: list[dict] = []
    for f in files:
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        bi = doc.get("basic_info") or {}
        mpn = str(bi.get("mpn") or f.stem)
        info = BI.classify(mpn, doc,
                           str(((doc.get("specs") or {}).get("package") or {}).get("type") or ""),
                           str(bi.get("manufacturer") or ""))
        st = info["state"]
        tally[st] = tally.get(st, 0) + 1
        if info.get("rule_id"):
            by_id[info["rule_id"]] = by_id.get(info["rule_id"], 0) + 1
        samples.setdefault(st, [])
        if len(samples[st]) < 5:
            samples[st].append(mpn)
        orders = BI.orderables(doc)
        rows.append({
            "file": f.name, "mpn": mpn, "manufacturer": str(bi.get("manufacturer") or ""),
            "state": st, "identity": info.get("identity"),
            "confidence": info.get("confidence"), "verdict": info.get("verdict"),
            "blocks_release": int(bool(info.get("blocks_release"))),
            "advisory": int(bool(info.get("advisory"))), "rule_id": info.get("rule_id") or "",
            "orderables": len(orders),
            "same_family_n": len(BI._same_family(mpn, orders)) if len(orders) >= 2 else 0,
            "head_orderables": "|".join(orders[:6]),
            "evidence": " | ".join(info.get("evidence") or [])[:300],
        })
    total = sum(tally.values())
    print("回放 %d 件（数据源 %s）" % (total, data_dir))
    for st in (BI.SUPPORTED, BI.CONFIRMED, BI.REVIEW, BI.CONFLICT, BI.INCOMPLETE):
        n = tally.get(st, 0)
        if not n:
            continue
        print("  %-22s %5d 件（%.1f%%）  例：%s"
              % (st, n, n * 100.0 / max(total, 1), "、".join(samples.get(st, [])[:3])))
    if by_id:
        print("  规则命中分布：%s"
              % "、".join("%s=%d" % (k, v) for k, v in sorted(by_id.items())))
    blocking = sum(1 for r in rows if r["blocks_release"])
    advisory = sum(1 for r in rows if r["advisory"])
    print("  阻断发布（blocks_release）：%d 件；其中只提示不阻断的 advisory：%d 件"
          % (blocking, advisory))
    gate = tally.get(BI.REVIEW, 0)
    print("\n新增阻断（IDENTITY_REVIEW）：%d 件。上生产前这个数应是几十件量级；"
          "几百件说明规则过宽，回退调 pattern/confidence。\n"
          "注意：这个数字要看**假阳性**，不是看真板卡有几件 —— 用 --out 导出明细，"
          "按 rule_id 抽 10 条人工核对再决定。" % gate)
    if a.out:
        out_path = Path(a.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        # utf-8-sig：Excel 直接双击打开不乱码
        with out_path.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("明细已写 %s" % out_path)
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="料号身份规则注册表：自检 / 导入 / 回放")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("selftest", help="跑 test_cases").set_defaults(fn=cmd_selftest)
    sub.add_parser("list", help="列出规则").set_defaults(fn=cmd_list)

    ip = sub.add_parser("import", help="校验并记录规则文件")
    ip.add_argument("--file", default="")
    ip.add_argument("--actor", default="")
    ip.set_defaults(fn=cmd_import)

    rp = sub.add_parser("replay", help="离线回放真实解析结果")
    rp.add_argument("--data-dir", default="data/parsed", dest="data_dir")
    rp.add_argument("--limit", type=int, default=0)
    rp.add_argument("--out", default="", help="明细 CSV 输出路径（utf-8-sig）")
    rp.set_defaults(fn=cmd_replay)

    a = ap.parse_args(argv)
    if not getattr(a, "fn", None):
        a = ap.parse_args((argv or []) + ["selftest"])
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
