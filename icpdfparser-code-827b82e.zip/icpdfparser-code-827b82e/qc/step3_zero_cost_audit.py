#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""步骤 3：零成本摸底审计（Qwen 3.8 脚本，路径按本库实际情况调整）。

1. 全库 empty 分层（chip/board × 电气页是否在上下文）
2. plus 救回行覆盖对照（MIN/TYP/MAX 角色 / condition 真实性 / 电源地脚）
3. R_effective 点估计

不调 LLM、不写生产；只读 JSON + PDF 文本层。
"""
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

try:
    import pymupdf as fitz
except ImportError:                                  # noqa: N813
    import fitz                                       # type: ignore

ELEC_KEYWORDS = ["electrical characteristics", "recommended operating",
                 "absolute maximum", "dc operating", "ac characteristics"]
PIN_POWER_GND = ["vcc", "vdd", "gnd", "avdd", "avss", "vbat", "vbus", "pvdd"]
VALID_COND_RE = re.compile(
    r"^[\x20-\x7E\u4e00-\u9fa5\s\-\+\=\*\/\(\)\[\]\{\}\<\>\%\°\μ\Ω\℃\≈\≤\≥\±]{3,}$")


def is_board(doc: dict) -> bool:
    bi = doc.get("basic_info") or {}
    cat = str(bi.get("category") or "").lower()
    ident = str(bi.get("identity") or "").lower()
    mpn = str(bi.get("mpn") or "").upper()
    if "board" in cat or "evaluation" in cat or "evm" in mpn or "kit" in mpn:
        return True
    return ident in ("evaluation_board", "board")


def has_elec_context(pdf_path: Path | None) -> bool:
    if not pdf_path or not pdf_path.exists():
        return False
    try:
        with fitz.open(str(pdf_path)) as doc:
            n = len(doc)
            pages = list(range(min(20, n)))
            if n > 20:
                pages += list(range(max(20, n - 5), n))
            for i in set(pages):
                if any(k in (doc[i].get_text("text") or "").lower() for k in ELEC_KEYWORDS):
                    return True
    except Exception:                                 # noqa: BLE001
        return False
    return False


def audit_plus_rescued(json_path: Path) -> dict:
    if not json_path.exists():
        return {"error": "File not found"}
    doc = json.loads(json_path.read_text(encoding="utf-8"))
    elecs = (doc.get("specs") or {}).get("electrical") or []
    pins = doc.get("pin_configuration") or []
    total, has_roles, valid_cond = len(elecs), 0, 0
    for e in elecs:
        if not isinstance(e, dict):
            continue
        cols = e.get("columns") or e.get("columns_raw") or {}
        val = str(e.get("value", "")).upper()
        if cols or any(r in val for r in ("MIN", "TYP", "MAX")):
            has_roles += 1
        cond = str(e.get("condition", "")).strip()
        if VALID_COND_RE.match(cond):
            valid_cond += 1
    power = sorted({str(p.get("name", "")).lower() for p in pins
                    if any(k in str(p.get("name", "")).lower() for k in PIN_POWER_GND)})
    return {"total_rows": total, "with_roles": has_roles, "valid_conditions": valid_cond,
            "has_power_gnd_pins": bool(power), "power_gnd_names": power[:6],
            "pins_total": len(pins)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gray-dirs", nargs="+", required=True)
    ap.add_argument("--pdf-dir", required=True)
    ap.add_argument("--plus-json", required=True)
    a = ap.parse_args()
    pdf_dir = Path(a.pdf_dir)

    matrix = defaultdict(lambda: defaultdict(int))
    total = {"chip": 0, "board": 0}
    empty_ctx = empty_noctx = 0

    for d in [Path(x) for x in a.gray_dirs]:
        if not d.exists():
            continue
        for jf in d.glob("*.json"):
            if jf.name.startswith("_") or jf.name.endswith((".pre_pp.json",)):
                continue
            try:
                doc = json.loads(jf.read_text(encoding="utf-8"))
            except Exception:                          # noqa: BLE001
                continue
            kind = "board" if is_board(doc) else "chip"
            total[kind] += 1
            elecs = (doc.get("specs") or {}).get("electrical") or []
            if len(elecs) >= 3:
                matrix[kind]["非 empty"] += 1
                continue
            mpn = str((doc.get("basic_info") or {}).get("mpn") or jf.stem)
            cands = sorted(pdf_dir.glob(f"{mpn}*.pdf"))
            ctx = has_elec_context(cands[0] if cands else None)
            matrix[kind]["empty∧电气页在" if ctx else "empty∧电气页不在"] += 1
            if kind == "chip":
                empty_ctx += int(ctx)
                empty_noctx += int(not ctx)

    print("[1] empty 分层")
    for kind in ("chip", "board"):
        print(f"  {kind}: total={total[kind]}")
        for k, v in matrix[kind].items():
            print(f"    - {k}: {v}")

    if total["chip"]:
        chip_empty = (empty_ctx + empty_noctx) / total["chip"]
        ctx_share = empty_ctx / (empty_ctx + empty_noctx) if (empty_ctx + empty_noctx) else 0
        print(f"[2] R_effective: chip_empty={chip_empty:.2%} "
              f"ctx_share={ctx_share:.2%} R={chip_empty * ctx_share:.2%}")

    print("[3] plus 救回行覆盖", audit_plus_rescued(Path(a.plus_json)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
