#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""符号页重渲染 diff：基线（改造前提交）渲染器 vs 当前工作区。

用途
----
改造符号页文案 / 状态时，必须证明「只有该变的变了」：符号 SVG 主体零漂移、
可见文本变化只限状态派生的副标题与「工程模型边界」小节。

做法
----
1. `git show <base>:symbol_svg.py` 取出改造前渲染器，以独立模块名加载；
   改动一旦提交，`HEAD` 就等于工作区，比较会退化成「自己跟自己比」，
   所以要用 `--base <改造前提交>`，脚本检测到两者无差异时直接判红（退出码 2）；
2. 同一份 JSON、同一 `pkg_dir` 渲染两遍；
3. 逐件断言：
   - `aria-label="… schematic symbol"` 的 `<svg>` 块**逐字节相同**；
   - 边界小节逐条 == `render_notes(state)`；
   - 去掉边界小节后的可见文本，删除只允许是旧两段重复文案，
     新增只允许是状态派生短标签；
   - `engineering_model.check` 零 findings。

只读生产产物，输出写 `--out`（默认 `.sandbox/symbols_diff`），**不写** `data/symbols`。

用法
----
    python qc/symbols_render_diff.py --base b623249
    python qc/symbols_render_diff.py --base b623249 --out /tmp/sym_diff --json /tmp/sym_diff/diff.json
"""
from __future__ import annotations

import argparse
import difflib
import importlib.util
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import symbol_svg as S                     # noqa: E402
from qc import engineering_model as EM     # noqa: E402

#: 五件：BGA 正例 / 板卡两件 / 模板臂两件（数据取自 staging 与 parsed，均只读）
CASES = (
    ("ADC12DJ5200SE", "data/staging_20261030_fixed/parsed/ADC12DJ5200SE.json"),
    ("BOOST-DRV8711", "data/staging_20261030_fixed/parsed/BOOST-DRV8711.json"),
    ("ADS8568EVM-PDK", "data/staging_20261030_fixed/parsed/ADS8568EVM-PDK.json"),
    ("BUF634PG4", "data/parsed/BUF634PG4_176bed1f.json"),
    ("DAC8555IPWG4", "data/parsed/DAC8555IPWG4_f63797db.json"),
)

#: 旧版两段重复硬编码文案（本次唯一允许被删除的可见文本）
OLD_CAPTIONS = {"封装 · 几何与视角未核验，不生成工程模型",
                "3D 模型 · 几何与视角未核验，不生成工程模型",
                # 示意图臂的旧副标题：读起来像「已经有 3D 模型」，与边界小节打架
                "3D 模型 · 按封装类型程序化绘制",
                # 封装卡的旧副标题：把「按封装类型 + 脚数生成」写成了既成事实，
                # 与实际是否绘制无关；2026-10-31 换成状态派生短标签（封装 · 轮廓未绘制 等）
                "封装 · 按封装类型 + 脚数生成",
                # BGA 两卡的旧占位图文字（两卡同图同一句话，2026-10-31 换成按卡分工的占位图）
                "{pkg} · 封装几何未核验",
                "球位功能表不提供可信封装尺寸与视角。",
                "不生成猜测球阵列或工程用 3D 模型。"}
#: 状态派生短标签（唯一允许新增的可见文本）
NEW_CAPTIONS = {"封装 · 轮廓未绘制", "3D 模型 · 未生成",
                "封装 · 不适用", "3D 模型 · 不适用",
                # 示意图臂：明确写成「示意」，不再冒充工程模型
                "3D 模型 · 示意（按封装类型程序化绘制）",
                # BGA 占位图：每张卡只说自己的对象，理由指向边界小节（不复述断言）
                "{pkg} · 封装占位图", "{pkg} · 3D 占位图",
                "此格不绘制图形，理由见下方「工程模型边界」。",
                "此格无立体模型，理由见下方「工程模型边界」。"}


def text_is_allowed(text: str, allowed: set[str] | frozenset[str], mpn: str = "") -> bool:
    """``text`` 是否在白名单里。

    两个占位符，精度不同，别混：

    - ``{mpn}``：替换成本件型号后**逐字**比对（型号写错会被抓）；
    - ``{pkg}``：封装标签位，允许任意非空值 —— 卡内文字前缀是封装 key 而不是型号
      （实测 ``FCBGA (144) · …``），而封装 key 的变更由标题行与状态派生另行断言。
      句式与结论部分仍然必须逐字命中白名单，这才是这个白名单要守的东西。
    """
    if text in allowed:
        return True
    for a in allowed:
        if "{mpn}" in a and a.replace("{mpn}", mpn) == text:
            return True
        if "{pkg}" in a:
            head, _, tail = a.partition("{pkg}")
            if (text.startswith(head) and text.endswith(tail)
                    and len(text) > len(head) + len(tail)):
                mid = text[len(head):len(text) - len(tail)] if tail else text[len(head):]
                if mid.strip() and "·" not in mid:
                    return True
    return False


SYMBOL_SVG_RE = re.compile(
    r'<svg[^>]*aria-label="[^"]*schematic symbol[^"]*".*?</svg>', re.S)
VISIBLE_RE = re.compile(r">([^<>]+)<")
#: `<style>` / `<script>` 的内容是 CSS/JS，不是页面上人能看到的东西。
#: 不剥掉，旧页的 `body{margin:0;…}` 会混进「可见文本」：既让文本条数失真，
#: 也让越界清单里出现一串 CSS（实测 3530ECUSAGRM / 66AK2E02ABDA4 都是这样）。
_EMBEDDED_RE = re.compile(r"<(style|script)\b[^>]*>.*?</\1>", re.S | re.I)


def _load_head(tmpdir: Path, base: str = "HEAD"):
    """把基线版本（默认 HEAD）的 symbol_svg.py 落成独立模块（与当前工作区互不影响）。

    ``base`` 必须指向**本次改造之前**的提交。默认 ``HEAD`` 只在改动尚未提交时才对；
    一旦改动进了 HEAD，``HEAD`` 就等于工作区，比较退化成自己跟自己比 —— 永远是绿的
    假证据。所以 :func:`main` 会先查 ``git diff {base} -- symbol_svg.py``，
    没有差异就直接判红（除非显式 ``--allow-same``）。
    """
    src = subprocess.run(["git", "show", f"{base}:symbol_svg.py"], cwd=str(ROOT),
                         capture_output=True, text=True, check=True).stdout
    path = tmpdir / "symbol_svg_head.py"
    path.write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location("symbol_svg_head", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["symbol_svg_head"] = mod
    spec.loader.exec_module(mod)
    return mod


def _baseline_differs(base: str) -> bool:
    """基线里的 ``symbol_svg.py`` 是否与工作区不同（不同才有可比的「改造前」）。"""
    r = subprocess.run(["git", "diff", "--quiet", base, "--", "symbol_svg.py"],
                       cwd=str(ROOT))
    return r.returncode == 1



def _symbol_block(page: str) -> str:
    m = SYMBOL_SVG_RE.search(page)
    return m.group(0) if m else ""


#: 剥符号块时的占位：必须保留一个标签边界（见 `_without_symbol`）。
_SYMBOL_STUB = "<i></i>"


def _without_symbol(page: str) -> str:
    """去掉原理图符号块。

    为什么必须去：符号块里也有文本（引脚名 `V–`、`NC` 等），它们是**图形的一部分**，
    已经由 `symbol_same` 逐字节断言过。把它们同时算进「可见文本越界」，同一个变化会被
    两条判据重复计数 —— 实测 2418 件 `not_ok` 里有 14 件就是这么被误标成「文本越界」的
    （引脚名 en-dash 归一 `V–`→`V-`，图变了，文案没变）。
    剥掉之后两条判据正交：`symbol_same` 管图，文本判据管图以外的文案。

    替换**不能**用空串：那会把前后两段文本粘成一段（`>A<svg/>` + `>B<` → `>AB<`），
    可见文本集合整体错位 —— 实测这么干会让 4406 件 `ok` 全部翻成 `not_ok`。
    """
    return SYMBOL_SVG_RE.sub(_SYMBOL_STUB, page)


def _visible(page: str) -> list[str]:
    """页面上真正的可见文本：先剥 `<style>`/`<script>`，再按标签切。"""
    import html as _html
    return [_html.unescape(m).strip()
            for m in VISIBLE_RE.findall(_EMBEDDED_RE.sub("", page)) if m.strip()]


def _strip_boundary(page: str) -> str:
    """去掉「工程模型边界」小节（它本身就是本次新增的产物）。"""
    i = page.find("data-em-boundary=")
    if i < 0:
        return page
    j = page.find("</section>", i)
    return page[:i] + (page[j + len("</section>"):] if j >= 0 else "")


def _report_one(name: str, src: Path, head, pkgs: Path, out: Path) -> dict:
    doc = json.loads(src.read_text(encoding="utf-8"))
    before = head.render_page(json.loads(json.dumps(doc)), pkg_dir=pkgs)
    after = S.render_page(json.loads(json.dumps(doc)), pkg_dir=pkgs)
    (out / name).mkdir(parents=True, exist_ok=True)
    (out / name / "before.html").write_text(before, encoding="utf-8")
    (out / name / "after.html").write_text(after, encoding="utf-8")

    state = EM.derive_state(json.loads(json.dumps(doc)), pkgs)
    items = EM._boundary_items(after) or []          # noqa: SLF001
    # 两侧都剥符号块与边界小节，比较才对称：
    # 符号块由 `symbol_same` 断言，边界小节由 `boundary_ok` 断言，都不该再进文本差集。
    before_text = _visible(_strip_boundary(_without_symbol(before)))
    after_text = _visible(_strip_boundary(_without_symbol(after)))
    removed = [t for t in before_text if t not in after_text]
    added = [t for t in after_text if t not in before_text]
    changed = [ln for ln in difflib.unified_diff(
        before.splitlines(), after.splitlines(), "before", "after", n=0, lineterm="")
        if ln.startswith(("+", "-")) and not ln.startswith(("+++", "---"))]

    return {
        "mpn": name,
        "source": str(src.relative_to(ROOT)),
        "before_bytes": len(before), "after_bytes": len(after),
        "symbol_identical": _symbol_block(before) == _symbol_block(after),
        "symbol_bytes": len(_symbol_block(after)),
        "state": {k: (v.get("status") if isinstance(v, dict) else v)
                  for k, v in state.items()},
        "caps_before": re.findall(r'class="cap">([^<]*)', before),
        "caps_after": re.findall(r'class="cap">([^<]*)', after),
        "boundary_items": items,
        "boundary_matches_notes": items == EM.render_notes(state),
        "changed_lines": len(changed),
        "text_removed": removed,
        "text_added": added,
        "changes_limited_to_captions": (
            all(text_is_allowed(t, OLD_CAPTIONS, name) for t in removed)
            and all(text_is_allowed(t, NEW_CAPTIONS, name) for t in added)),
        "findings": EM.check(doc, after, state),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="符号页重渲染 diff（基线 vs 工作区）")
    ap.add_argument("--out", default=str(ROOT / ".sandbox" / "symbols_diff"))
    ap.add_argument("--pkg-lib", default=str(ROOT / "data" / "pkgs"))
    ap.add_argument("--json", default="")
    ap.add_argument("--base", default="HEAD",
                    help="基线提交（必须是改造**之前**的提交，例：--base b623249）")
    ap.add_argument("--allow-same", action="store_true",
                    help="允许基线与工作区完全相同（结果必然全绿，仅用于自查脚本可用性）")
    a = ap.parse_args(argv)

    if not a.allow_same and not _baseline_differs(a.base):
        print(f"基线无效：`git diff {a.base} -- symbol_svg.py` 为空，"
              f"说明 {a.base} 已包含当前改动，比较退化成「自己跟自己比」。\n"
              f"请用改造前的提交重跑，例：--base b623249", file=sys.stderr)
        return 2

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    pkgs = Path(a.pkg_lib)
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        head = _load_head(Path(tmp), a.base)

        for name, rel in CASES:
            src = ROOT / rel
            if not src.is_file():
                print(f"SKIP {name}: 缺 {rel}")
                continue
            rows.append(_report_one(name, src, head, pkgs, out))

    bad = []
    for r in rows:
        ok = (r["symbol_identical"] and r["boundary_matches_notes"]
              and r["changes_limited_to_captions"] and not r["findings"])
        if not ok:
            bad.append(r["mpn"])
        print(f'{r["mpn"]:<16} {r["before_bytes"]:>6}->{r["after_bytes"]:<6} '
              f'symbol_same={r["symbol_identical"]} boundary_ok={r["boundary_matches_notes"]} '
              f'text_ok={r["changes_limited_to_captions"]} findings={len(r["findings"])} '
              f'{"OK" if ok else "!!"}')
    if a.json:
        Path(a.json).write_text(json.dumps(rows, ensure_ascii=False, indent=2),
                                encoding="utf-8")
    print(f"\n{len(rows) - len(bad)}/{len(rows)} 通过" + (f"；未通过：{bad}" if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
