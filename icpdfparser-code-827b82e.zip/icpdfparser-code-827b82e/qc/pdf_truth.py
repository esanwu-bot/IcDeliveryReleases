#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qc/pdf_truth.py — PDF 原文真值提取（通用，任意 datasheet 可复用）

从受检 PDF 确定性提取文本/表格，作为修补 parsed JSON 的事实依据（D1/D2/D3 类缺陷取真值）。

用法:
  python qc/pdf_truth.py --pdf qc/pdfs/AM26C32IDG4__am26c32.pdf --kw "Pin Functions"      # 定位关键词并打印所在页上下文
  python qc/pdf_truth.py --pdf <pdf> --kw "Ioff" --ctx 6                                 # 关键词前后 6 行
  python qc/pdf_truth.py --pdf <pdf> --pages 7 --tables                                  # 指定页 dump 表格行
  python qc/pdf_truth.py --pdf <pdf> --kw "Ordering Information" --tables               # 关键词所在页的表格
  python qc/pdf_truth.py --pdf <pdf> --pages 3,4                                         # dump 整页文本

说明:
  - 文本行用 PyMuPDF 排序输出（保持阅读顺序）；表格用 page.find_tables()。
  - 关键词大小写不敏感；--kw 与 --pages 可组合（--pages 限定搜索范围）。
  - 多处命中会全部列出并标注页码，便于人工比对（qc/pdfs/ 下有原件）。
"""
import argparse
import io
import sys
from pathlib import Path

import pymupdf

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")


def dump_tables(page, pno):
    try:
        tabs = page.find_tables()
    except Exception as e:
        print(f"  [page {pno}] find_tables 失败: {e}")
        return
    for ti, t in enumerate(tabs.tables):
        print(f"  [page {pno}] 表#{ti}  bbox={tuple(round(x) for x in t.bbox)}")
        for row in t.extract():
            cells = [(c or "").replace("\n", " ").strip() for c in row]
            if any(cells):
                print("    " + " | ".join(cells))


def dump_lines(page, pno, kw, ctx):
    lines = [ln.strip() for ln in page.get_text("text").splitlines() if ln.strip()]
    if not kw:
        print(f"  [page {pno}] 共 {len(lines)} 行")
        for ln in lines:
            print("    " + ln)
        return
    hit = [i for i, ln in enumerate(lines) if kw.lower() in ln.lower()]
    if not hit:
        return
    print(f"  [page {pno}] 命中 {len(hit)} 处")
    shown = set()
    for i in hit:
        lo, hi = max(0, i - ctx), min(len(lines), i + ctx + 1)
        key = (pno, lo)
        if key in shown:
            continue
        shown.add(key)
        for j in range(lo, hi):
            mark = ">>" if j == i else "  "
            print(f"    {mark} {lines[j]}")


def main():
    ap = argparse.ArgumentParser(description="PDF 原文真值提取")
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--kw", default="", help="大小写不敏感关键词，定位段落/表格")
    ap.add_argument("--ctx", type=int, default=8, help="关键词上下文行数（默认 8）")
    ap.add_argument("--pages", default="", help="页码（1 起算）逗号分隔，可 a-b 区间；限定/直接 dump")
    ap.add_argument("--tables", action="store_true", help="dump find_tables 表格行")
    args = ap.parse_args()

    pdf = Path(args.pdf)
    if not pdf.exists():
        sys.exit(f"PDF 不存在: {pdf}")
    doc = pymupdf.open(str(pdf))
    print(f"# {pdf.name}  共 {len(doc)} 页  kw={args.kw!r} pages={args.pages or '全部'}")

    want = set()
    if args.pages:
        for part in args.pages.split(","):
            if "-" in part:
                a, b = part.split("-")
                want.update(range(int(a), int(b) + 1))
            elif part:
                want.add(int(part))
    pages = [p for p in range(len(doc)) if (p + 1) in want] if want else range(len(doc))

    for pno0 in pages:
        page = doc[pno0]
        pno = pno0 + 1
        if args.tables:
            if args.kw and args.kw.lower() not in page.get_text("text").lower():
                continue
            dump_tables(page, pno)
        else:
            if args.kw and args.kw.lower() not in page.get_text("text").lower():
                continue
            dump_lines(page, pno, args.kw, args.ctx)
    doc.close()


if __name__ == "__main__":
    main()
