"""A 组高风险字段对照表：按「字段类型 → 该翻哪张表」分组，输出 Markdown 核验单。

定位：核验员打开 PDF 时不必逐条判断"这条该看哪页"，本模块把 63 条高风险（三件试点）
按**原厂数据手册的标准章节**归类，每条给出：期望值 / 草稿定位 / 草稿 quote / 核验要点。

分组顺序（按出错代价从高到低）：身份 → 封装 → 电源脚 → 方向脚 → 电流量纲 →
关键电气 → 电源范围 → 极限 → 脚注关联；另单列 `冲突(F)` 与 `未定位(C)`。

红线：本模块**只读**、只出「该看哪张表 + 怎么核」，不给答案；答案必须回原厂 PDF。
`import` 零 stdout（server 安全）。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

# code → (分组标题, 该翻哪张表, 核验要点)
GUIDE = {
    "identity": (
        "身份（型号/厂商）",
        "Ordering Information（订购表）/ Package Option Addendum；首页标题",
        "订购表整行 literal（含后缀与封装列）；首页标题须与订购表一致，不能只看文件名"),
    "package": (
        "封装（类型/脚数）",
        "Ordering Information 封装列 + Package/Mechanical 图 + Pin Configuration 顶部标注",
        "后缀 ↔ 封装族 ↔ 脚数 三者互证；多封装列时只认本后缀那一列"),
    "power_pin": (
        "电源/基准引脚名",
        "Pin Functions 表 + Pin Configuration 图",
        "脚号 → 脚名一一对应；模拟/数字电源（AVDD/DVDD）与地（GND/AGND）不可混；多个脚号原样保留"),
    "direction_pin": (
        "方向/使能/时钟脚",
        "Pin Functions 表 + Function Table / Truth Table",
        "方向与有效电平来自真值表，不是脚名字面；OE 低有效/高有效必须看真值表"),
    "current_dim": (
        "电流量纲行（µA/mA/mW）",
        "Electrical Characteristics 表的 Ixx 行（IDD/IOIDD/ICC…）+ 单位列 + MAX 列",
        "最易错三类：µA↔mA 量纲、行错配（相邻行值串位）、范围塌缩（MIN/TYP/MAX 合并成一个）"),
    "key_electrical": (
        "关键电气（带宽/分辨率/增益/失调…）",
        "Electrical Characteristics 或 Recommended Operating Conditions 对应行",
        "先确认列角色（MIN/TYP/MAX/UNIT），再对数值；带脚注的必须连脚注一起读"),
    "supply_range": (
        "电源范围",
        "Recommended Operating Conditions（VDD/VCC 行）；必要时 Absolute Maximum Ratings",
        "MIN 与 MAX 分列，不要取中间值；注意测试条件列（如 TA=25°C、VDD=5V）"),
    "abs_limit": (
        "极限供电",
        "Absolute Maximum Ratings + 表下 stress 注记",
        "极限值不是工作值；注意「Stresses beyond…」注记与脚注编号"),
    "footnote_link": (
        "脚注关联行",
        "Electrical Characteristics 表下脚注 (1)(2)(3) 原文",
        "证据必须带脚注原文（如 FSR 定义、测试条件），否则不算核验通过"),
}
ORDER = ["identity", "package", "power_pin", "direction_pin", "current_dim",
         "key_electrical", "supply_range", "abs_limit", "footnote_link"]


def _db(dbm=None):
    if dbm is not None:
        return dbm
    from app import db as _dbm
    return _dbm


def build(db, mpn: str | None = None, ev_id: int | None = None) -> dict | None:
    """汇总一件的高风险分组（复用 verify_worklist 的 A/F/C 口径，避免两套判定）。"""
    from qc import cheatsheet as CS
    from qc import verify_worklist as VW

    w = VW.build(db, mpn=mpn, ev_id=ev_id)
    if not w:
        return None
    mpn = w["mpn"]
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (mpn,))
    gf = {}
    if gold:
        for g in db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold["id"],)):
            gf[g["field_path"]] = g
    groups: dict[str, list] = {c: [] for c in ORDER}
    for it in w["groups"]["A"]:
        g = gf.get(it["path"]) or {}
        L = CS.locate({"field_path": it["path"], "field_name": g.get("field_name") or "",
                       "expected": g.get("expected"), "unit": g.get("unit") or ""}, mpn)
        codes = it.get("reasons") or []
        key = codes[0] if codes and codes[0] in groups else "key_electrical"
        groups[key].append({
            "path": it["path"], "expected": g.get("expected") or "",
            "unit": g.get("unit") or "", "page": it.get("page") or 0,
            "quote": it.get("quote") or "",
            "locator": f"{L['sec']} · {L['row']} / {L['col']}",
            "codes": codes, "risk": it.get("risk") or ""})
    return {"mpn": mpn, "evidence_id": w["evidence_id"], "gold_id": gold["id"] if gold else None,
            "a_total": w["counts"]["A"], "clicks_est": w["clicks_est"],
            "groups": {k: v for k, v in groups.items() if v},
            "counts": {k: len(v) for k, v in groups.items() if v},
            "conflicts": w["groups"]["F"], "unlocated": w["groups"]["C"],
            "batch": w["counts"]["B"], "ocr": w["counts"]["E"]}


def render_md(d: dict) -> str:
    g = lambda k: d["groups"].get(k) or []          # noqa: E731
    lines = [f"# 高风险字段对照表 · {d['mpn']}", "",
             f"- 证据卡：`evidence#{d['evidence_id']}` · Gold：`gold#{d['gold_id']}`",
             f"- A 组高风险 **{d['a_total']}** 条（须逐条核验，不可批量）；"
             f"B 组可批量 **{d['batch']}** 条；F 冲突 **{len(d['conflicts'])}** 条；"
             f"C 待判定 **{len(d['unlocated'])}** 条；E OCR **{d['ocr']}** 条",
             f"- 剩余必须点击：**{d['clicks_est']}** 次", "",
             "> 页码口径 = PDF **物理页**（1 起）。核验时把「草稿页」当线索，"
             "以原厂 PDF 目视为准；空白字段判 `not_specified`，**绝不补 0**。", ""]
    for code in ORDER:
        rows = g(code)
        if not rows:
            continue
        title, where, tip = GUIDE.get(code, (code, "—", "—"))
        lines += [f"## {title}（{len(rows)} 条）", "",
                  f"**该翻哪张表**：{where}", "",
                  f"**核验要点**：{tip}", "",
                  "| # | 字段 | 期望值 | 草稿定位 | 草稿页·quote | 其他命中 |",
                  "|---|---|---|---|---|---|"]
        for i, r in enumerate(rows, 1):
            exp = (r["expected"] or "—") + ((" " + r["unit"]) if r["unit"] else "")
            others = "、".join(c for c in (r["codes"] or [])[1:]) or "—"
            q = (r["quote"] or "—").replace("|", "\\|")[:52]
            lines.append(f"| {i} | `{r['path']}` | {exp} | {r['locator']} | p{r['page']}「{q}」 | {others} |")
        lines.append("")
    if d["conflicts"]:
        lines += ["## 冲突待裁决（F 组）", "",
                  "机器值与 Gold 期望不一致：**裁决后才可核验**（改 expected=原厂值 或保留+写理由）。", "",
                  "| # | 字段 | 草稿页·quote | 风险 |", "|---|---|---|---|"]
        for i, c in enumerate(d["conflicts"], 1):
            lines.append(f"| {i} | `{c['path']}` | p{c.get('page') or 0}"
                         f"「{(c.get('quote') or '—')[:46]}」 | {c.get('risk') or '—'} |")
        lines.append("")
    if d["unlocated"]:
        lines += ["## 未定位（C 组，需人工找证据或判 not_specified）", "",
                  "| # | 字段 | 状态 |", "|---|---|---|"]
        for i, c in enumerate(d["unlocated"], 1):
            lines.append(f"| {i} | `{c['path']}` | {c.get('status') or '—'} |")
        lines.append("")
    lines += ["---", "",
              "核验顺序建议：先「身份/封装」（1–2 条决定整件可信），再「电源脚/方向脚」，",
              "然后「电流量纲 / 关键电气」（错误代价最高），最后「范围/极限/脚注」。", ""]
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mpn")
    ap.add_argument("--evidence-id", type=int)
    ap.add_argument("--all", action="store_true", help="三件（或全部证据卡）批量出表")
    ap.add_argument("--out", help="输出目录（每件一个 .md）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    db = _db(None)
    if a.all:
        mpns = [r["mpn"] for r in db.q("SELECT DISTINCT mpn FROM source_evidence ORDER BY mpn")]
        outs = []
        for m in mpns:
            d = build(db, mpn=m)
            if not d:
                continue
            md = render_md(d)
            if a.out:
                p = Path(a.out) / f"risk_guide_{m}.md"
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(md, encoding="utf-8")
                outs.append((m, str(p), d["a_total"]))
            elif not a.json:
                print(md)
        if a.json:
            print(json.dumps([build(db, mpn=m) for m in mpns], ensure_ascii=False, indent=1))
        else:
            for m, p, n in outs:
                print(f"{m:<18} A 组 {n:>3} 条 → {p}")
        return 0
    if not (a.mpn or a.evidence_id):
        ap.error("需要 --mpn / --evidence-id / --all")
    d = build(db, mpn=a.mpn, ev_id=a.evidence_id)
    if not d:
        print("找不到证据卡", file=sys.stderr)
        return 3
    md = render_md(d)
    if a.out:
        p = Path(a.out) / f"risk_guide_{d['mpn']}.md"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(md, encoding="utf-8")
        print(f"written {p}（A 组 {d['a_total']} 条）")
    elif a.json:
        print(json.dumps(d, ensure_ascii=False, indent=1))
    else:
        print(md)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())