#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qwen 产物后处理：把「一条 PDF 规格行被拆成多条」的重复条目合并回一条。

为什么需要（BQ2003PNG4 实测）
----------------------------
qwen-flash 实跑得 30 条 ``specs.electrical``，而 PDF 第 10 页
`Recommended DC Operating Conditions` 那张表只有 20 行。差在哪：

    Supply Voltage  4.5  / 5.0  / 5.5    condition 全是 "TA = 0 to +70°C"

模型的 MIN/TYP/MAX 三列被当成三条独立参数写了出来。下游
``qc/table_audit.py::audit_electrical`` 有「冲突消解」：同一 (表, 行) 被多个条目
认领时 **全部判 ambiguous_collision，谁都不写**。于是这 30 条跑出来的结果是
``findings=32 / unresolved=30 / patched=0`` —— 一条都没修上。

合并之后每条对应一个 PDF 行，冲突消解不再触发，``patch_cols`` 才能用 PDF 的
MIN/TYP/MAX 列回填 ``columns``，value 变成 ``"4.5 MIN / 5.0 TYP / 5.5 MAX"``
（数值来源是 PDF，不是我们猜的）。实测 BQ2003PNG4：``patched`` 从 0 升到 2，
但仍有 23 条 unresolved —— 主因是符号（``VCC``）在 value/condition 里反复出现
（``0.2 ∗VCC``、``VCC - 1.0``），``locate_candidates`` 的「符号命中 100 分」在多行上
同时成立。那条要动打分函数（``MATCH_RULE`` 版本升级），不是后处理能解决的。

不做什么（重要，别走回头路）
--------------------------
**不拆 symbol。** 原设想是「把 name 拆成 symbol + name」，前提是符号藏在 name 里。
三个语料实测：

    生产 data/parsed 300 件 / 10536 条：纯符号 22.8% / 符号+描述 3.7% / 纯描述 73.5%
    交付包         400 件 /  4228 条：纯符号 18.4% / 符号+描述 0.8% / 纯描述 80.8%
    新 qwen 探针          30 条      ：纯描述 100%

即「符号+描述」这种可拆形态只占 0.8%~3.7%，对 qwen 新产物是 0/30 —— 正则跑一遍
产出 0 条。更糟的是那 22.8% 的纯符号条目（``VIH``）会被拆成
``symbol=VIH, name=""``，把 name 拆空，而 ``audit_electrical`` 的 param 正是取
``name``。**符号的真实来源是 PDF 表格的独立 Symbol 列**：

    Symbol | Parameter | Minimum | Typical | Maximum | Unit | Notes
    VCC    | Supply voltage | 4.5 | 5.0 | 5.5 | V

要取符号只能靠表格定位，不是靠字符串正则。那是 ``qc/table_audit.py`` 的活。

合并键的取法
------------
``(symbol, name, condition, unit)`` 归一化后相同即一组。``condition`` 必须进键：
同一张表里 `Logic input low` 会出现两次（CCMD/DCMD/DVEN 与 TM1/TM2 不同脚），
条件不同就是两行，不能合。组内 2~3 条才参与合并；>3 条说明模型把别的列也拆了，
判 ``SKIP_TOO_MANY`` 交人工，不猜。

**归一只折叠同形异码 + 去空白 + 折大小写，不删其它字符。** 用
``[^a-z0-9]`` 那种「全删」会把 Ω 与 ℃ 一起删成空串、把 A 与 µA 都变成 "a"
（误合并），又会把 µ(U+00B5) 与 μ(U+03BC)、°C 与 ℃(U+2103) 判成不同（漏合并）。
这两个码位在真实语料里同时存在（1408 次 / 510 次）。

**合并不是靠键就算数。** 每条先用 ``qc/table_audit.py::locate_candidates`` 落到 PDF 的
``(page, table, row)``，组内全部落到同一行才合。这是唯一可靠判据：
``DAC0800LCMX_NOPB__snas538c.pdf`` 第 3 页有两行同名同条件的独立参数
（``I+ 2.3 / I− -4.3``，靠 Symbol 列区分），qwen 把 symbol 丢了之后两行在键上完全一样，
光看键会造出 ``-4.3 ~ 2.3`` 的假区间；而 ``Integral linearity`` 的 ``-6 / +6`` 是
同一条规格行的 MIN/MAX，落到同一行 → 该合。
「数值是否同号」不能当判据 —— 实测会误伤 50 组跨零的合法 MIN/MAX。

用法
----
    python qc/postprocess_qwen.py data/parsed_probe_ds/*.json          # 只读，PDF 验证
    python qc/postprocess_qwen.py --dir data/parsed_probe_ds --write   # 写盘
    python qc/postprocess_qwen.py --dir ... --no-verify                # 不读 PDF（仅摸底，生产禁用）

写盘前把原文件备份成 ``{原名}.pre_pp.json``（同目录）。找不到 PDF 时自动降级为按键合并，
并在报告里标 ``verified=False``。
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import shutil
import sys
from pathlib import Path

# 本脚本在 qc/ 下，要 import 兄弟模块 qc.table_audit，得把项目根放进 sys.path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Windows 控制台 utf-8 输出。幂等：被其它模块再 import 时不得重复包一层
# （旧 wrapper 失去引用后被 GC 会连带关掉共享 buffer，后续 print 全报 closed file）。
if not getattr(sys.stdout, "_qc_utf8", False):
    _w = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    _w._qc_utf8 = True
    sys.stdout = _w

RULE = "merge_same_row/v2"   # v1=按键合并（含假阳性，见下），v2=外加 PDF 同一行验证
MAX_GROUP = 3          # 组内最多合并几条；超过就是「模型把别的列也拆了」，交人工
BACKUP_SUFFIX = ".pre_pp.json"

#: 条件串钳制是否**真的删除**条件。默认关（只标记待核）。
#:
#: 关的理由是实测出来的，不是保守惯性：这 5 件的 PDF 表格抽取精度撑不起
#: 「证明数值不在原表」这个判断（详见 `clamp_conditions` docstring）。
#: 需要强制删时显式开：`ICPDF_CLAMP_DELETE=1`，并逐条复核报告里的证据字段。
CLAMP_DELETE = os.environ.get("ICPDF_CLAMP_DELETE", "0") == "1"

#: 同形异码折叠表。只折叠「在本域里确实是同一个东西」的字符，其余一律保留。
#: 不折叠会在两个方向上出错（实测生产语料 300 件 / 10536 条）：
#:   漏合并：µ(U+00B5，1408 次) 与 μ(U+03BC，510 次) 是同一个微符号的两个码位；
#:           °C(U+00B0+C) 与 ℃(U+2103，164 次) 是同一个单位。
#:   误合并：`[^a-z0-9]` 把 Ω 和 ℃ 都删成空串，A 与 µA 都变成 "a"，
#:           于是「同 symbol + 同 name + 同 condition，只是单位不同」的两群会被并成一群。
#: 所以归一化只做三件事：折叠同形异码 → 去空白 → 折大小写。Ω ° ± ≤ → Δ ℃ 中文全部原样保留。
_FOLD = str.maketrans({
    "µ": "μ",           # MICRO SIGN → GREEK SMALL LETTER MU
    "∆": "Δ",           # INCREMENT → GREEK CAPITAL DELTA
    "℃": "°C",          # DEGREE CELSIUS → DEGREE SIGN + C
    "∗": "*", "＊": "*",  # ASTERISK OPERATOR / FULLWIDTH  → ASCII *
    "–": "-", "—": "-", "−": "-",  # EN/EM DASH、MINUS SIGN → 连字符
})


def norm_key_part(s) -> str:
    """键归一化。**不删非英数字符**——见 _FOLD 上方的实测理由。"""
    return re.sub(r"\s+", "", (s or "").translate(_FOLD)).casefold()


def merge_key(e: dict) -> tuple:
    return (norm_key_part(e.get("symbol")), norm_key_part(e.get("name")),
            norm_key_part(e.get("condition")), norm_key_part(e.get("unit")))


_NUM_RE = re.compile(r"[±+-]?\d+(?:[.,]\d+)?(?:\s?[eE][+-]?\d+)?")


def to_num(s):
    """取字符串里第一个数。口径与 qc/table_audit.py::to_num 一致（含 ± 前缀容忍）。"""
    m = _NUM_RE.search((s or "").strip())
    if not m:
        return None
    try:
        return float(m.group(0).replace(",", "").replace("±", "+"))
    except ValueError:
        return None


# ---------------------------------------------------------------- range 规范化
#: 唯一的「区间分隔符」：两边必须有空白，避免把 `-40°C` 的负号、`8.2–52V` 的
#: 无空格连字符当成区间。`to` 只认整词。
_RANGE_SEP = re.compile(r"\s+(?:-|–|—|~|to)\s+", re.I)
#: 整格就是一个数（可带符号/科学计数），才允许进 `columns`（float 语义）。
_NUM_ONLY = re.compile(r"^[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:\s?[eE][+-]?\d+)?$")

#: 库内「原文没这一格」的哨兵，口径同 `qc/cheatsheet.py`（绝不自造值）。
_BLANK_SENTINELS = {"not_specified", "not specified", "unspecified", "unknown",
                    "n/a", "na", "-", "—", "–", ""}

#: 工作环境温度行：只认 free-air / ambient / TA。
#: **刻意不认 junction** —— Tj 125°C 不是环境温度，拿它顶 TA 会把 -40~85 写成 125。
_OPERATING_TEMP_RE = re.compile(r"free[- ]?air|ambient|^\s*TA\s*$|operating temperature", re.I)
_STORAGE_TEMP_RE = re.compile(r"storage", re.I)


def range_parts(val) -> tuple[str, str] | None:
    """把 ``-4 VREF - 4 VREF`` / ``4.5 - 5.5`` / ``2 to 6.3`` 拆成 (min, max)。

    只在**恰好一个**区间分隔符、且两侧都含数字时拆。公式串
    （``HVSS - 0.3 - HVDD + 0.3``）有两个以上分隔符 → 不动，避免造出假区间。
    """
    s = str(val or "").strip()
    if not s:
        return None
    seps = list(_RANGE_SEP.finditer(s))
    if len(seps) != 1:
        return None
    left, right = s[:seps[0].start()].strip(), s[seps[0].end():].strip()
    if not left or not right:
        return None
    if not re.search(r"\d", left) or not re.search(r"\d", right):
        return None
    return left, right


def _columns_marked_unverified(e: dict) -> bool:
    """这一行是否已经明确「列角色未核验」。

    两种写法都要认：`_input_range_row()` 写 `range_origin=column_roles_unverified`，
    历史数据也可能只在 `range_note` 里写「列角色未独立核验」。
    """
    if str(e.get("range_origin") or "").strip() == "column_roles_unverified":
        return True
    return "列角色未独立核验" in str(e.get("range_note") or "")


def normalize_ranges(entries: list) -> int:
    """把用连字符拼出来的区间改成 ``min to max``；正式 ``range`` 只给可信行。

    这是**渲染语义**修复，不改写已经由 PDF 回填的 ``columns``（那是审计的事实源）。
    只处理 ``value`` 仍是裸字符串、且没有 columns/range 的条目。

    V11 P0-2：`unresolved` 行不许生成正式 ``range.min/max`` —— 否则会出现
    「页面打 † 说列角色未核验，API/JSON 却吐出一个正式区间」的契约分裂。
    这类行只落到 ``unverified_range_candidate``，下游只能拿它做候选展示，
    不能当 MIN/MAX 读。唯一例外是 `condition_unverified`：那是**条件**证据丢失，
    不是列角色结论，区间本身仍可保留（旧回归见 `tests/test_condition_clamp.py`）。

    ``-4 VREF - 4 VREF`` → ``value = "-4 VREF to 4 VREF"``；
    区间可信时同时写 ``range = {"min": "-4 VREF", "max": "4 VREF"}``。
    """
    n = 0
    for e in entries or []:
        if not isinstance(e, dict):
            continue
        if (e.get("range") or e.get("columns") or e.get("columns_raw")
                or e.get("unverified_range_candidate")):
            continue
        val = e.get("value")
        if not isinstance(val, str) or "/" in val or "MIN" in val.upper():
            continue
        parts = range_parts(val)
        if not parts:
            continue
        left, right = parts
        candidate = {"min": left, "max": right}
        e["value"] = f"{left} to {right}"
        # 2026-10-31：**不得覆盖条件钳制写下的证据**。本函数跑在
        # `clamp_conditions` 之后，旧实现无条件覆写 `verification`，实测把
        # `condition_unverified / value_only_in_prose / dropped_condition`
        # 三条全抹成 `column_roles_not_verified` —— 条件已经丢了、证据却没了，
        # 事后完全看不出这条为什么没有测试条件。
        prev = dict(e.get("verification") or {})
        if prev.get("status") == "condition_unverified":
            e["range"] = candidate
            # 展示候选不是 PDF 列证据；MIN/TYP/MAX 只允许原表审计回填。
            e["range_origin"] = "derived_from_value"
            prev.setdefault("range_origin", "derived_from_value")
            prev.setdefault("secondary_reason", "column_roles_not_verified")
            e["verification"] = prev
            n += 1
            continue

        # V11 P0-2：其余路径一律只给候选，绝不落正式 `range`。
        e["unverified_range_candidate"] = candidate
        if _columns_marked_unverified(e):
            # 确定性抽取已经写明了「列角色未核验」：保留它的出处与证据，
            # 只把候选区间补在旁边，别用 `unresolved` 把出处洗成另一件事。
            e["verification"] = prev or {"status": "unresolved",
                                         "reason": "column_roles_not_verified"}
            if not str(e.get("range_origin") or "").strip():
                e["range_origin"] = "column_roles_unverified"
        else:
            e["range_origin"] = "column_roles_unverified"
            e["verification"] = {"status": "unresolved",
                                 "reason": "column_roles_not_verified"}
        n += 1
    return n


#: 整数形态的区间端点（`2` / `-4`）—— 只有这种才需要「补回原文小数位」。
_INT_ENDPOINT = re.compile(r"^[+-]?\d+$")
#: 原文里的小数字面量（`2.0` / `-0.3`）。刻意不含 `2.` 与 `.5`：
#: 数据手册几乎只印前者，放开会把行尾句号吃进数字。
_DEC_LITERAL = re.compile(r"[+-]?\d+\.\d+")


def align_decimal_form(entries: list, pdf, max_rows: int = 200) -> list[dict]:
    """把区间端点的「整数形态」还原成原文的小数形态（``2`` → ``2.0``）。

    为什么需要（ADC12DJ5200SE 第 17 页实测）
    ---------------------------------------
    `BW-3dB` 两行原文印的是 ``2.0`` 与 ``6.3``，模型摘出来写成 ``2 - 6.3``，
    `normalize_ranges` 忠实地拆成 ``min=2, max=6.3``。**数值没变**，但页面上
    读成 ``2 to 6.3``，与数据手册并排看就是「两个数不同源」——Reviewer 会按
    外观判「摘抄不忠实」，而我们的自证链又证明不了它其实是同一个数。

    判据（宁可不改，也不猜）
    ----------------------
    只在**该行已锚定到 PDF 页**（``verification.page`` + ``bbox``）时动手，且在那一
    小块区域里找**唯一**一个浮点值相等的带小数点字面量。找不到、或找到多个不同
    写法，一律不动。

    **这条只做形态对齐，不承担「补一个原文没有的数」。** 区域里没有 ``2.0`` 就
    保持 ``2`` —— 那种情况下 ``2`` 本来就是原文。

    V11 起同时接受 `unverified_range_candidate`：候选区间没有正式 `range`，
    但页面仍会展示 `value`，小数位形态同样要与原文一致。
    """
    out: list[dict] = []
    if pdf is None:
        return out
    import pymupdf

    # `process()` 传进来的是 PDF **路径**（`resolve_pdf` 的返回值），不是已打开的文档；
    # 直接下标会抛 TypeError 并被下面的 except 吞掉 —— 那就变成「永远 0 条」的哑弹。
    if not hasattr(pdf, "__getitem__"):
        try:
            _doc = pymupdf.open(str(pdf))
        except Exception:
            return out
        try:
            return align_decimal_form(entries, _doc, max_rows)
        finally:
            _doc.close()

    cache: dict[tuple[int, tuple], list[str]] = {}
    for e in (entries or [])[:max_rows]:
        if not isinstance(e, dict):
            continue
        rng = e.get("range")
        if not isinstance(rng, dict) or not rng:
            # V11 P0-2：`unresolved` 行没有正式 `range`，但候选区间同样需要
            # 与原文对齐小数位 —— 否则 `2 to 6.3` 会在页面上看起来像另一个数。
            rng = e.get("unverified_range_candidate")
        if not isinstance(rng, dict) or not rng:
            continue
        ver = e.get("verification") or {}
        page_no, bbox = ver.get("page"), ver.get("bbox")
        if not page_no or not bbox or len(bbox) != 4:
            continue
        key = (int(page_no), tuple(round(float(x), 1) for x in bbox))
        if key not in cache:
            try:
                txt = pdf[key[0] - 1].get_text(clip=pymupdf.Rect(*key[1]))
            except Exception:
                txt = ""
            cache[key] = _DEC_LITERAL.findall(txt or "")
        lits = cache[key]
        if not lits:
            continue
        changed = {}
        for col in ("min", "max"):
            s = str(rng.get(col) or "").strip()
            if not _INT_ENDPOINT.match(s):
                continue
            target = float(s)
            hits = {t for t in lits if abs(float(t) - target) < 1e-12}
            if len(hits) != 1:
                continue
            hit = hits.pop()
            if hit.lstrip("+") != s:
                rng[col] = hit
                changed[col] = hit
        if not changed:
            continue
        e["value"] = f"{rng.get('min')} to {rng.get('max')}"
        out.append({"name": e.get("name") or "", "unit": e.get("unit") or "",
                    "before": dict(changed), "page": int(page_no)})
    return out


def resolve_rowrefs(entries: list, tables: list) -> list:
    """把每条 electrical 落到 PDF 的 ``(page, table, row)``；落不到唯一行给 ``None``。

    表选择走 ``qc/table_audit.py::decide_table`` 这一个入口 —— 和审计同一份实现。
    原来这里自己写了一遍"按表序取第一张"，与 `_decide_match` 平行；
    2026-11-03 的 ADS42 勘查证明那条规则会选到修订历史表/引脚表（VID 明明
    p11 得分更高，却输给更靠前的 p3），两份平行实现只会把同一个错误修两遍。
    """
    from qc import table_audit as T

    refs = []
    for e in entries:
        sym, param = e.get("symbol") or "", e.get("name") or ""
        status, info = T.decide_table(tables, sym, param,
                                      e.get("condition") or "", str(e.get("value", "")))
        ref = None
        if status == "matched":
            tbl = info["table"]
            ref = (tbl["page"], tbl["ti"], info["ri"])
        refs.append(ref)
    return refs


def resolve_pdf(pdf_dir: Path, json_path: Path, doc: dict | None = None):
    """料号 → PDF，返回 ``(path, how)``；``how`` ∈ exact / hash / prefix / none。

    实现**委托给** `qc/table_audit.py::find_pdf_tolerant` —— 闸门（`locate_paths`）
    和后处理必须用同一套匹配口径，否则会出现「闸门认为找不到 PDF 而跳过、后处理
    认为找到了而核验」这种自相矛盾。这里只负责从 JSON 里取 `pdf_hash` 与路径拆名。

    为什么不能只用 `_find_pdf_in`：那个口径是**精确文件名前缀**，而线上 PDF 是按
    **可订购号**命名的（`ADC12DJ5200SEAAV__adc12dj5200se.pdf`），交付 JSON 的主键
    却是**请求型号**（`ADC12DJ5200SE`）。实测该件因此匹配失败、后处理静默降级成
    「未验证按键合并」，条件钳制一次都没跑（见
    `qc/evidence_20261031/postprocess_after_fix.json` 的 `verified=false`）。
    """
    from qc import table_audit as T

    mpn = json_path.stem.rsplit("_", 1)[0]
    want = str(((doc or {}).get("metadata") or {}).get("pdf_hash") or "")
    return T.find_pdf_tolerant(pdf_dir, mpn, want)


def find_pdf(pdf_dir: Path, json_path: Path, doc: dict | None = None):
    """兼容旧签名：只要路径的调用方走这里。"""
    return resolve_pdf(pdf_dir, json_path, doc)[0]


def _row_at(tables: list, ref) -> list:
    """``(page, ti, row)`` → 该行原始单元格列表；找不到给空列表。"""
    page, ti, ri = ref
    for tbl in tables:
        if tbl["page"] == page and tbl["ti"] == ti:
            return tbl["rows"][ri] if ri < len(tbl["rows"]) else []
    return []


def row_cell_nums(tables: list, ref) -> set:
    """``(page, ti, row)`` → 该行所有**干净数值格**的数值集合。

    '0.7 × IOVDD' / '10 20' 这类格子返回不了数（见 ``T.cell_num``），
    所以「合并后的值能不能被这一行解释」这件事本身就会把它们暴露出来。

    注意：这是**合并去重**用的严格口径（宁可判「解释不了」交人工），
    不是条件钳制用的口径 —— 钳制要比「这个数在原表里存在吗」，用 :func:`_row_tokens`。
    """
    from qc import table_audit as T
    return {v for v in (T.cell_num(c) for c in _row_at(tables, ref)) if v is not None}


def _bare_name(s) -> str:
    """参数名主干：去掉括注与标点。

    `Peak RF Input Power (INA, INB)` -> `peak rf input power`
    `Input Common-Mode Voltage (CLK±)` -> `input common mode voltage`
    """
    t = re.sub(r"\([^)]*\)", " ", str(s or ""))
    return re.sub(r"[^a-z0-9]+", " ", t.lower()).strip()


def _val_key(s) -> str:
    return re.sub(r"\s+", "", str(s or "")).lower()


def demote_stress_rows(elec: list, absmax: list) -> list[dict]:
    """把「与 Abs Max 行同名同值」的电气行归位到 `absolute_max`。

    Reviewer 的 P0 之一：`Peak RF Input Power 26.25 dBm` 是 Abs Max 里的**应力
    额定值**，却被写进了 `electrical` —— 页面上就成了「推荐工作条件：输入功率
    26.25 dBm」，工程师照着做会烧器件。PROMPT 3d 明令禁止，但 qwen-flash 仍会犯
    （2026-10-31 v5 实测：`absolute_max` 里已有该行，`electrical` 里又出现一次）。

    判据刻意收得很窄：**名字主干相同 + value 相同 + unit 相同**三条全中才算重复。
    只看名字会误杀 —— `Supply Voltage (VA19)` 在 ROC 里是 `1.8 to 2.0`、在 Abs Max
    里是 `-0.3 to 2.35`，是同名的**两个不同行**，都必须留。

    这里删的不是数据，是**位置**：值已经在 `absolute_max` 里正确存在，
    `electrical` 这份是错误归类。删除同时写 `verification` 留痕，可审计。
    """
    if not elec or not absmax:
        return []
    sig = {(_bare_name(a.get("name")), _val_key(a.get("value")), _val_key(a.get("unit")))
           for a in absmax}
    acts: list[dict] = []
    keep: list[dict] = []
    for e in elec:
        key = (_bare_name(e.get("name")), _val_key(e.get("value")), _val_key(e.get("unit")))
        if key in sig:
            e["verification"] = {**(e.get("verification") or {}),
                                 "status": "moved_to_absolute_max",
                                 "reason": "与 Abs Max 行同名同值：属应力额定值，不属工作参数"}
            acts.append({"action": "MOVE_TO_ABSMAX", "name": e.get("name"),
                         "value": e.get("value"), "unit": e.get("unit")})
            continue
        keep.append(e)
    if acts:
        elec[:] = keep
    return acts


def _num_tokens(s) -> set:
    """字符串里的全部数值（保留符号），用于「数值是否落在这一行」的比对。"""
    out = set()
    for m in re.findall(r"[+-]?\d+(?:\.\d+)?", str(s or "")):
        try:
            out.add(round(float(m), 4))
        except ValueError:
            continue
    return out


def _row_tokens(row) -> set:
    """一行的**容差**数值集：任何格子里出现过的数都算，不要求是干净单值。

    这是钳制判定的关键口径差异，别改回 `T.cell_num`：

      * **回填**（`patch_cols`）必须严：融合格 `'0 03 0'` 读不出列，写进去就是错；
      * **证明缺失** 必须宽：`'4.75 5.25'` 这种两格并一格里，两个数**确实在表里**，
        用严格口径会把它们判成「表里没有」→ 误删正确条件。

    2026-10-31 实跑踩过：ADS1201U 的 `4.75 to 5.25` 因融合格被判 `value_only_in_prose`，
    `BOOSTXL-C2KLED` 5 条条件全被误删。证据不足不能当证据。
    """
    out: set = set()
    for c in row or []:
        out |= _num_tokens(c)
    return out


def _rows_by_condition(tables: list, sym: str, param: str, cond: str):
    """按**条件串**回找它所属的行，返回 ``(rows, state)``。

    ``state`` ∈ ``unique`` / ``ambiguous`` / ``none``：
      * ``unique``    —— **恰好一张表**给出**恰好一行**候选，这行才算证据；
      * ``ambiguous`` —— 多表命中或表内并列，行不是唯一身份，不能拿来判缺失；
      * ``none``      —— 一行都没命中。

    为什么要卡「唯一」：`locate_candidates` 每张表只返回**最高分并列**的行，
    两张表都命中、或表内并列时，被选中的那一行只是「最像」，不是「就是它」。
    拿「最像的行」证明数值缺失，等于用弱证据删数据 —— 实跑已经吃过一次亏：
    ADC12DJ5200SE 的 `Input voltage, peak-to-peak differential` 条件
    `CLK, SYSREF, TMSTP` 被多行共享，按「最像行」判会误删正确条件。

    用 condition 而不是 value 去定位，是因为 condition 是行的身份
    （`fIN = 4.5GHz` 只可能属于那一行），value 是行内容，高频值几十行都有。
    """
    from qc import table_audit as T

    hits = []                                  # [(tbl, [ri, ...])]
    for tbl in tables:
        if not tbl.get("header"):
            continue
        ties, _ = T.locate_candidates(tbl, sym, param, cond, "")
        if ties:
            hits.append((tbl, list(ties)))
    if not hits:
        return [], "none"
    if len(hits) > 1 or len(hits[0][1]) != 1:
        return [], "ambiguous"
    tbl, ris = hits[0]
    toks = _row_tokens(tbl["rows"][ris[0]])
    return ([toks] if toks else []), ("unique" if toks else "none")


def clamp_conditions(entries: list, rowrefs: list | None,
                     tables: list | None) -> tuple[list, list]:
    """条件串必须与数值**同源**：数值不在该行，就丢掉条件并标 ``condition_unverified``。

    为什么需要这一道（2026-10-31 Reviewer #5 取证）：
    ADC12DJ5200SE 交付成 ``value=-1.25 dBm`` + ``condition=fIN=4.5GHz,
    FS_RANGE=0xA000``，而原表里那个条件对应的数值是 **-1.5 dBm**，``-1.25`` 只在
    Features 段落。两个不同定义被缝成一行，**单看 JSON 完全合法**，只能回原表比数
    才能发现——这正是「闸门看起来在跑、其实什么都没拦」的典型。

    **默认只标记、不删数据**（2026-10-31 两次实跑修正，结论是硬的）：

    第一次跑「全文档没这个数就判 Features」，5 件误删 12 条正确条件；
    改成「按条件回找唯一行」后，ADC12DJ5200SE 又有 5 条参数同时命中
    **同一行 p4 t0 r6**（row_nums `[0,1,100]`，明显是表头/注释行），
    ADS1201U 的 `4.75 to 5.25` 行里数字被抽成 `525`（小数点丢失）。
    也就是说：**这几份 PDF 的表格抽取精度，撑不起「证明数值缺失」这个判断**。

    所以默认口径是「检测 + 标记」，删除要人显式开：

      * 默认（``ICPDF_CLAMP_DELETE`` 未设）→ 只把 `verification` 标成
        `condition_unverified`，写清 `reason` 与证据（`value_nums` / `row_nums`），
        条件原文一个字不动；
      * ``ICPDF_CLAMP_DELETE=1`` → 证据达到 `condition_value_mismatch` 的条目
        才真正丢弃条件（``CLAMP_CONDITION``）。

    处置口径仍是：**只动 condition，不改 value**。改数值需要原表逐格证据，属于另一类修复；
    条件串丢了最多是「少一个测试条件」，数值被改错则是直接烧板子。
    """
    if not entries or rowrefs is None or tables is None:
        return entries, []

    actions: list[dict] = []
    for i, e in enumerate(entries):
        cond = str(e.get("condition") or "").strip()
        if not cond:
            continue
        vnums = _num_tokens(e.get("value"))
        if not vnums:
            continue

        ref = rowrefs[i] if i < len(rowrefs) else None
        if ref is not None:
            row_nums = _row_tokens(_row_at(tables, ref))
            if not row_nums or vnums <= row_nums:
                continue                      # 同源 / 该行读不出数 → 不动
            reason, detail = "condition_value_mismatch", {
                "value_nums": sorted(vnums), "row_nums": sorted(row_nums),
                "row": f"p{ref[0]} t{ref[1]} r{ref[2]}"}
        else:
            rows, state = _rows_by_condition(tables, str(e.get("symbol") or ""),
                                            str(e.get("name") or ""), cond)
            if state != "unique":
                # 弱证据：行不是唯一身份（没找到 / 多表命中 / 表内并列）→
                # 无法判定同源与否，**只标记不删数据**。
                v = dict(e.get("verification") or {})
                reason = "row_ambiguous" if state == "ambiguous" else "row_not_located"
                if v.get("reason") != reason:
                    v.update({"status": "condition_unverified", "reason": reason})
                    e["verification"] = v
                    actions.append({"action": "MARK_CONDITION", "path": f"specs.electrical[{i}]",
                                    "name": e.get("name", ""), "value": e.get("value", ""),
                                    "condition": cond, "reason": reason,
                                    "value_nums": sorted(vnums)})
                continue
            if vnums <= rows[0]:
                continue                      # 该行能完整解释这组数 → 同源，放行
            reason, detail = "condition_value_mismatch", {
                "value_nums": sorted(vnums),
                "row_nums": sorted(rows[0]),
                "row": "condition_located"}

        dropped = e.get("condition")
        v = dict(e.get("verification") or {})
        if not CLAMP_DELETE:
            # 默认：证据写进 verification，条件原文保留 —— 由人工决定是否删除。
            v.update({"status": "condition_unverified", "reason": reason,
                      "condition_pending_drop": dropped,
                      "evidence": {"value_nums": detail.get("value_nums"),
                                   "row_nums": detail.get("row_nums"),
                                   "row": detail.get("row")}})
            e["verification"] = v
            actions.append({"action": "MARK_CONDITION", "path": f"specs.electrical[{i}]",
                            "name": e.get("name", ""), "value": e.get("value", ""),
                            "condition": cond, "reason": reason, **detail})
            continue
        e["condition"] = ""
        v.update({"status": "condition_unverified", "reason": reason,
                  "dropped_condition": dropped})
        e["verification"] = v
        actions.append({"action": "CLAMP_CONDITION", "path": f"specs.electrical[{i}]",
                        "name": e.get("name", ""), "value": e.get("value", ""),
                        "dropped_condition": dropped, "reason": reason, **detail})
    return entries, actions


def normalize_temperature(doc: dict) -> list[dict]:
    """把 `specs.temperature` / `unresolved_specs.temperature` 对齐到电气表那一行。

    为什么以**电气表行**为准（2026-10-31 Reviewer A5 取证）：
    同一件 JSON 里同一事实有三条记录互不同步 ——

        specs.temperature.operating = "not_specified"
        specs.unresolved_specs.temperature = {"operating": "-40°C to 85°C"}
        specs.electrical[i] Operating free-air temperature = "-40 to 85 °C"

    页面渲染取第三条（`json_to_txt.py` 对 `unresolved_specs` 引用数为 0），
    所以「字段没落位、页面照样出数」。电气行带单位、带条件，且已过 table_audit
    的行级核对，是最可信的那一份。

    严格边界：
      * 只认 `free-air` / `ambient` / `TA`，**绝不认 `junction`**（Tj 125°C 不是
        环境温度，拿它顶 TA 会把 -40~85 直接写成 125，比原来更糟）；
      * 电气行是 `not_specified` / 占位符 → 不覆盖（宁可缺，不可错）；
      * 没有这一行 → 一个字都不动。
    """
    specs = doc.get("specs") or {}
    temp = specs.get("temperature")
    if not isinstance(temp, dict):
        return []

    def _fmt(e):
        v = str(e.get("value") or "").strip()
        u = str(e.get("unit") or "").strip()
        if not v or v.lower() in _BLANK_SENTINELS:
            return ""
        if not u:
            return v
        parts = _RANGE_SEP.split(v)
        if len(parts) == 2:                      # "-40 to 85" → "-40°C to 85°C"
            return f"{parts[0].strip()}{u} to {parts[1].strip()}{u}"
        return v if u in v else f"{v}{u}"

    def _pick(rows, pattern):
        for e in rows or []:
            name = str(e.get("name") or e.get("parameter") or "")
            if pattern.search(name):
                return _fmt(e)
        return ""

    op = _pick(specs.get("electrical"), _OPERATING_TEMP_RE)
    st = _pick(specs.get("absolute_max"), _STORAGE_TEMP_RE)

    changes = []
    fixed = set()
    for field, val in (("operating", op), ("storage", st)):
        if not val or temp.get(field) == val:
            continue
        changes.append({"field": f"temperature.{field}",
                        "before": temp.get(field), "after": val})
        temp[field] = val
        fixed.add(field)

    # 清掉 unresolved 里**刚刚被真值覆盖**的同名字段：留着就是第二条互相矛盾的口径。
    # 只清 `fixed` 里的：没抽到真值就动 unresolved，等于把唯一的证据也删了。
    unres = specs.get("unresolved_specs")
    if fixed and isinstance(unres, dict):
        ut = unres.get("temperature")
        if isinstance(ut, dict):
            for field in sorted(fixed):
                if field in ut:
                    ut.pop(field, None)
                    changes.append({"field": f"unresolved_specs.temperature.{field}",
                                    "before": "cleared", "after": ""})
            if not ut:
                unres.pop("temperature", None)
            if not {k: v for k, v in unres.items() if k != "scope"}:
                specs.pop("unresolved_specs", None)
    return changes


def _jev_same_spec(group: list) -> bool:
    """百炼 JEV 判断这组「未落到同一行」的条目是否语义上属于同一条规格。

    默认关（``ICPDF_JEV_MERGE=1`` 才启用）。**调用方只能用它打标签，不能用它删条目**：
    语义判定没通过物理验证，就没有对数据的处置权。JEV 一旦幻觉（把 I+ 和 I− 判成
    同规格），drop 掉的条目会从 JSON 里永久消失，人工复核也看不到。
    """
    if os.getenv("ICPDF_JEV_MERGE", "0").strip() != "1":
        return False
    try:
        from qc.jev_client import decide_choice
    except Exception:
        return False

    lines = ["Entries extracted from the same datasheet, located to different table rows:"]
    for e in group:
        lines.append(f"- value={e.get('value')}, unit={e.get('unit') or ''}, "
                     f"condition={e.get('condition') or 'None'}")
    got = decide_choice(
        state="\n".join(lines),
        instructions=("Do these entries describe ONE specification (MIN/TYP/MAX or "
                      "multi-condition variants of the same parameter), or DIFFERENT "
                      "parameters that must stay separate?"),
        criteria={"merge": "Same specification; they belong to one row.",
                  "keep": "Different specifications; keep separate."},
        threshold=float(os.getenv("ICPDF_JEV_MERGE_CONF", "0.8")),
    )
    return bool(got) and got[0] == "merge"


def merge_duplicate_rows(entries: list, rowrefs: list | None = None,
                         tables: list | None = None) -> tuple[list, list]:
    """按 (symbol, name, condition, unit) 归组，组内多条 → 一条。

    ``rowrefs`` 是每条在 PDF 里落到的 ``(page, table, row)``，由
    :func:`resolve_rowrefs` 用 ``qc/table_audit.py::locate_candidates`` 算出来。
    **给了 rowrefs 就要求组内全部落到同一行才合并** —— 这是唯一可靠的判据，理由见
    ``SKIP_ROW_MISMATCH`` 那段注释。

    ``tables`` 给了就再加一道 ``SKIP_VALUES_NOT_IN_ROW``：合并只会保留组内**第一条**
    的 value，其余值降级进 ``postprocess.merged_values``。如果下游 ``table_audit``
    没能把这一行写成 ``columns``（比如表头没有 MIN/TYP/MAX），那些值就**只活在溯源字段里**，
    主线 value 变成 180 而真值是 180/250 —— 等于静默丢数据。所以合并前先确认
    「组内每个数值都能在这一行找到」。实测 DAC8555 有 7 组里 6 组过不了这道闸门。

    返回 ``(新条目列表, 动作记录)``。顺序保持首次出现的位置，不重排 ——
    重排会打乱「模型按表格行序输出」这个有用的隐含信息。
    """
    groups: dict[tuple, list[int]] = {}
    for i, e in enumerate(entries):
        groups.setdefault(merge_key(e), []).append(i)

    drop: set[int] = set()
    actions = []
    for key, idxs in groups.items():
        if len(idxs) < 2:
            continue
        head = entries[idxs[0]]
        if len(idxs) > MAX_GROUP:
            actions.append({"path": head.get("name"), "action": "SKIP_TOO_MANY",
                            "group": len(idxs),
                            "values": [entries[i].get("value") for i in idxs]})
            continue

        if rowrefs is not None:
            # 有 PDF 就用 PDF 裁决。DAC0800LCM 第 3 页有两行同名同条件的独立参数：
            #     I+   2.3   3.8  mA   Power Supply Current   VS = ±5V, IREF = 1 mA
            #     I−  -4.3  -5.8  mA   Power Supply Current   VS = ±5V, IREF = 1 mA
            # 区分它们的是 Symbol 列（I+/I−），而 qwen 把 symbol 丢了 → 键上完全一样。
            # 光看键会造出「-4.3 ~ 2.3」这种不存在的假区间。而这两条在 PDF 里落到**两行**，
            # locate_candidates 对「Power Supply Current」返回并列候选 → 天然拦住。
            # 反过来 INL 的 -6 / +6 是同一条规格行的 MIN/MAX，落到同一行 → 该合。
            # 所以「是否同一行」才是判据，「数值是否同号」不是（那个会误伤 -6|6）。
            refs = {rowrefs[i] for i in idxs}
            if len(refs) != 1 or None in refs:
                bad = [entries[i].get("value") for i in idxs]
                # ADAPT JEV：跨行语义组（默认关）。**只打标签，绝不 drop** ——
                # 语义判定没过物理验证，就没有删除权。删了就是永久丢数据，
                # 而且下游 table_audit 和人工复核都再也看不到这几条。
                if _jev_same_spec([entries[i] for i in idxs]):
                    gid = f"sem_{head.get('name')}_{idxs[0]}"
                    for i in idxs:
                        pp = entries[i].setdefault("postprocess", {})
                        pp["semantic_group"] = gid
                        pp["semantic_merge_reason"] = "JEV cross-row match"
                    actions.append({"path": head.get("name"), "action": "SOFT_MERGE_SEMANTIC",
                                    "group": len(idxs), "values": bad,
                                    "group_id": gid,
                                    "note": "JEV 判为同规格但未过同行验证：保留全部条目，仅打标签"})
                    continue
                actions.append({"path": head.get("name"), "action": "SKIP_ROW_MISMATCH",
                                "group": len(idxs), "values": bad,
                                "rows": ["未唯一命中" if rowrefs[i] is None
                                         else f"p{rowrefs[i][0]}/t{rowrefs[i][1]}/r{rowrefs[i][2]}"
                                         for i in idxs]})
                continue
        else:
            # 无 PDF 的降级模式：只能靠键，风险自负。condition 全空就没法区分行 → 不合。
            if not norm_key_part(head.get("condition")):
                actions.append({"path": head.get("name"), "action": "SKIP_NO_CONDITION",
                                "group": len(idxs),
                                "values": [entries[i].get("value") for i in idxs]})
                continue

        vals = [entries[i].get("value") for i in idxs]
        # ADAPT A12：合并只保留第一条的 value，其余降级进 merged_values。若这一行
        # 无法把组内所有数值都变成 columns（表头没有 MIN/TYP/MAX、格子是公式或两格并一格），
        # 那条「180/250 合成 180」就是**静默丢数据**。所以先验证再合并。
        if tables is not None and rowrefs is not None:
            from qc import table_audit as T
            cells = row_cell_nums(tables, rowrefs[idxs[0]])
            lost = [v for v in vals if (T.to_num(v) is not None and
                                        all(abs(T.to_num(v) - c) > 1e-9 for c in cells))]
            if lost:
                actions.append({"path": head.get("name"), "action": "SKIP_VALUES_NOT_IN_ROW",
                                "group": len(idxs), "values": vals, "unexplained": lost,
                                "row": f"p{rowrefs[idxs[0]][0]}/t{rowrefs[idxs[0]][1]}/r{rowrefs[idxs[0]][2]}",
                                "row_cells": sorted(cells)})
                continue
        # value 取组内第一条。这里**不做 MIN/TYP/MAX 归属判断**，理由是下游不按数组下标取列：
        # qc/table_audit.py::patch_cols 的 cols 全部来自 PDF 那一行 MIN/TYP/MAX 三个单元格的
        # 列角色（role_map），与我们的数组顺序无关。所以顺序错了不会「张冠李戴」，
        # 但会决定 D1b(qualifier_loss) 要不要触发 —— 它要求本条的 value 数值落在 PDF 的
        # 列值里。取第一条的实测依据：4 组真实重复（Supply Voltage 4.5/5.0/5.5、
        # MCV 0.2/0.4∗VCC、VTCO 0.2/0.4∗VCC、ICC 0.75/2.2）首值都命中 PDF 列值。
        # 万一以后不命中，表现是「静默不修」而不是「改错值」，并在报告里留 value_pick 可追。
        head["value"] = vals[0]
        head["postprocess"] = {"rule": RULE, "merged_from": len(idxs),
                               "value_pick": "first",
                               "merged_values": vals,
                               "merged_conditions": [entries[i].get("condition") for i in idxs]}
        drop.update(idxs[1:])
        actions.append({"path": head.get("name"), "action": "MERGED", "group": len(idxs),
                        "values": vals, "kept": vals[0],
                        "condition": head.get("condition"),
                        "row": (f"p{rowrefs[idxs[0]][0]}/t{rowrefs[idxs[0]][1]}/r{rowrefs[idxs[0]][2]}"
                                if rowrefs is not None else ""),
                        "conditions": [entries[i].get("condition") for i in idxs]})
    kept = [e for i, e in enumerate(entries) if i not in drop]
    return kept, actions


def process(path: Path, write: bool, pdf_dir: Path | None = None) -> dict | None:
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"  [跳过] {path.name}: {exc}")
        return None
    specs = doc.get("specs") or {}
    entries = specs.get("electrical") or []
    # 模型偶发把纯文本塞进对象数组：这里再兜一层，脏元素只降级不崩
    # （上游 parse_datasheets.sanitize_doc 已经清过一次，历史 JSON 仍可能有残留）。
    dropped = [e for e in entries if not isinstance(e, dict)]
    if dropped:
        print(f"  [清洗] {path.name}: 剔除 {len(dropped)} 条非对象电气条目")
        entries = [e for e in entries if isinstance(e, dict)]
        specs["electrical"] = entries
    if not entries:
        print(f"  [跳过] {path.name}: 无 specs.electrical")
        return None

    # 有 PDF 就走「同一行」硬判据；没有就退化为按键合（--no-verify），并在报告里标 verified=False
    rowrefs, pdf, tables = None, None, None
    pdf_how = "none"
    if pdf_dir is not None:
        pdf, pdf_how = resolve_pdf(pdf_dir, path, doc)
        if pdf is not None:
            import pymupdf
            from qc import table_audit as T
            d = pymupdf.open(str(pdf))
            try:
                tables = T.scan_tables(d)
                rowrefs = resolve_rowrefs(entries, tables)
            finally:
                d.close()

    kept, actions = merge_duplicate_rows(entries, rowrefs, tables)
    # 应力值归位（Reviewer P0「Peak RF Input Power 归类错误」）：必须在合并之后、
    # 钳制之前 —— 先归位，后面的钳制/回填就只面对工作参数，不会拿 Abs Max 的
    # 行去给电气行作证。
    stress_acts = demote_stress_rows(kept, specs.get("absolute_max") or [])
    # 条件串同源钳制（Reviewer #5）：**必须在合并之后**——合并靠 condition 区分
    # 行，先丢条件会把两行独立参数误并成一组（SKIP_NO_CONDITION 就是防这个）。
    clamp_acts = []
    if tables is not None and any(str(e.get("condition") or "").strip() for e in kept):
        clamp_acts = clamp_conditions(kept, resolve_rowrefs(kept, tables), tables)[1]
    # A2 渲染侧修复：`-4 VREF - 4 VREF` / `4.5 - 5.5` 这类用连字符拼的区间，
    # 必须变成 `min to max` + range 结构；否则页面上会读成「减去」。
    range_n = normalize_ranges(kept) + normalize_ranges(specs.get("absolute_max") or [])
    # 值形态对齐原文：`2 to 6.3` 里那个 `2`，原文印的是 `2.0`。数值不变，只把
    # 小数位补回去 —— 否则页面与数据手册并排看像两个不同的数。
    # 必须在 `normalize_ranges` 之后：它才刚把 range 结构造出来。
    dec_acts = align_decimal_form(kept, pdf)
    merged = sum(a["group"] for a in actions if a["action"] == "MERGED")
    rec = {"file": path.name,
           "mpn": (doc.get("basic_info") or {}).get("mpn", ""),
           "pdf": pdf.name if pdf else "",
           "pdf_match": pdf_how,
           "verified": rowrefs is not None,
           "before": len(entries), "after": len(kept),
           "merged_rows": sum(1 for a in actions if a["action"] == "MERGED"),
           "merged_entries": merged,
           "range_normalized": range_n,
           "decimal_aligned": len(dec_acts),
           "decimal_actions": dec_acts,
           "skip_too_many": sum(1 for a in actions if a["action"] == "SKIP_TOO_MANY"),
           "skip_no_condition": sum(1 for a in actions if a["action"] == "SKIP_NO_CONDITION"),
           "skip_row_mismatch": sum(1 for a in actions if a["action"] == "SKIP_ROW_MISMATCH"),
           "skip_values_not_in_row": sum(1 for a in actions if a["action"] == "SKIP_VALUES_NOT_IN_ROW"),
           "skipped": sum(1 for a in actions if a["action"].startswith("SKIP")),
           "condition_clamped": sum(1 for a in clamp_acts if a["action"] == "CLAMP_CONDITION"),
           "condition_marked": sum(1 for a in clamp_acts if a["action"] == "MARK_CONDITION"),
           "clamp_actions": clamp_acts,
           "moved_to_absmax": len(stress_acts),
           "stress_actions": stress_acts,
           "actions": actions}

    tag = ("" if rec["verified"]
           else ("  ⚠ --no-verify：未做 PDF 验证" if pdf_dir is None
                 else "  ⚠ 未找到 PDF，降级为按键合并（未验证）"))
    # 前缀匹配是「猜」的，哈希核验不是 —— 前者必须显式暴露，别混在干净输出里。
    if rec["verified"] and pdf_how == "prefix":
        tag = "  ⚠ PDF 按可订购号前缀匹配（无 pdf_hash 可核验，请人工确认同一份文档）"
    elif rec["verified"] and pdf_how == "hash":
        tag = "  · PDF 由 pdf_hash 核验"
    print(f"[{rec['mpn'] or path.stem}] electrical {rec['before']} → {rec['after']}"
          f"（合并 {rec['merged_rows']} 组 / {rec['merged_entries']} 条"
          + (f"，区间规范化 {rec['range_normalized']} 条" if rec["range_normalized"] else "")
          + (f"，小数位对齐 {rec['decimal_aligned']} 条" if rec["decimal_aligned"] else "")
          + (f"，条件串钳制 {rec['condition_clamped']} 条" if rec["condition_clamped"] else "")
          + (f"，条件待核标记 {rec['condition_marked']} 条" if rec["condition_marked"] else "")
          + (f"，留人工 {rec['skipped']} 组" if rec['skipped'] else "") + "）" + tag)
    for a in clamp_acts:
        if a["action"] == "MARK_CONDITION":
            print(f"    MARK    {a['path']} {a['name']}={a['value']}: "
                  f"条件「{a['condition']}」行未定位，保留原文只标待核")
            continue
        print(f"    CLAMP   {a['path']} {a['name']}={a['value']}: "
              f"丢弃条件「{a['dropped_condition']}」（{a['reason']}）")
    for a in actions:
        if a["action"] == "MERGED":
            print(f"    MERGED  {a['path']}: {' | '.join(map(str, a['values']))} → {a['kept']}"
                  f"   [{a['condition']}]  {a.get('row','')}")
        elif a["action"] == "SKIP_TOO_MANY":
            print(f"    SKIP    {a['path']}: {a['group']} 条同键，超过 {MAX_GROUP} 上限，交人工")
        elif a["action"] == "SKIP_VALUES_NOT_IN_ROW":
            print(f"    SKIP    {a['path']}: {' | '.join(map(str, a['values']))}"
                  f"  该行解释不了 {a['unexplained']}（行内干净数值 {a['row_cells']}），"
                  f"合并会丢值  {a.get('row','')}")
        elif a["action"] == "SKIP_ROW_MISMATCH":
            print(f"    SKIP    {a['path']}: {' | '.join(map(str, a['values']))}"
                  f" 未落到同一行（{', '.join(a['rows'])}），是两行独立参数，不合")
        else:
            print(f"    SKIP    {a['path']}: {a['group']} 条同键但 condition 全空，无法区分行，交人工")

    # 温度三处口径对齐（Reviewer A5）：以电气表那一行为唯一事实源。
    # 必须在 `specs["electrical"] = kept` 之后跑 —— 它读的就是这份 kept。
    specs["electrical"] = kept
    temp_changes = normalize_temperature(doc)
    rec["temperature_normalized"] = temp_changes
    if temp_changes:
        print(f"    TEMP    {rec['mpn'] or path.stem}: "
              + "；".join(f"{c['field']} {c['before']} → {c['after']}" for c in temp_changes))

    if write and (rec["merged_rows"] or rec["range_normalized"] or dec_acts
                  or rec["condition_clamped"] or rec["condition_marked"] or temp_changes):
        bak = path.with_name(path.stem + BACKUP_SUFFIX)
        if not bak.exists():
            shutil.copy2(path, bak)
        doc["specs"] = specs
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
    return rec


def main() -> int:
    ap = argparse.ArgumentParser(description="qwen 产物后处理：合并同键的 MIN/TYP/MAX 拆分条目")
    ap.add_argument("paths", nargs="*", help="JSON 文件路径")
    ap.add_argument("--dir", default="", help="目录（处理目录下全部 *.json，跳过 .pre_pp/.alts/.seo）")
    ap.add_argument("--pdf-dir", default="data/pdfs", help="PDF 目录（默认 data/pdfs）")
    ap.add_argument("--no-verify", action="store_true",
                    help="不读 PDF，只按键合并（未验证，仅用于快速摸底；生产禁用）")
    ap.add_argument("--write", action="store_true", help="写盘（默认只读）")
    ap.add_argument("--report", default="", help="把逐件动作写成 JSON 报告")
    a = ap.parse_args()

    files = [Path(p) for p in a.paths]
    if a.dir:
        files += [p for p in sorted(Path(a.dir).glob("*.json"))
                  if not p.name.endswith((".pre_pp.json", ".alts.json", ".seo.json"))]
    files = [p for p in files if p.exists()]
    if not files:
        ap.error("没有可处理的 JSON")

    pdf_dir = None if a.no_verify else Path(a.pdf_dir)
    print(f"模式：{'写盘' if a.write else '只读'}；"
          f"{'按键合并（未验证）' if pdf_dir is None else '按 PDF 同一行合并'}；{len(files)} 件\n")
    recs = [r for r in (process(p, a.write, pdf_dir) for p in files) if r]
    if not recs:
        print("无可处理件")
        return 0

    tb = sum(r["before"] for r in recs)
    ta = sum(r["after"] for r in recs)
    nv = sum(1 for r in recs if not r["verified"])
    print(f"\n合计 {len(recs)} 件：electrical {tb} → {ta}（-{tb - ta}，"
          f"{(tb - ta) / tb * 100:.1f}% 是重复行）；留人工 {sum(r['skipped'] for r in recs)} 组"
          + (f"；{nv} 件未验证（无 PDF 或 --no-verify）" if nv else ""))
    if a.report:
        Path(a.report).parent.mkdir(parents=True, exist_ok=True)
        Path(a.report).write_text(
            json.dumps({"rule": RULE, "write": a.write, "verified": pdf_dir is not None,
                        "summary": {"files": len(recs), "before": tb, "after": ta,
                                    "unverified": nv}, "records": recs},
                       ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"报告 -> {a.report}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
