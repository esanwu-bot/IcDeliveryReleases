"""「条件页优先」选页策略离线模拟（零模型调用、只读）。

目的
----
AM5746 只读诊断暴露：474 页文档里电气章节是 **p156~377 连续 222 页**，
电气档只有 6 页配额；含测试条件（`VDD=` / `TA=` / `over operating`）的页
在 PDF 中有 20 页，**V4 只选中 1 页**。

于是「数值表格」与「适用条件」几乎总无法同时进入上下文——参数抽出来了
也不知道适用于什么条件，等于半个废参数。

本脚本**不改生产选页逻辑**，只在内存里跑一个候选策略做对照：

  基线（V4）  : head 打底 + 阶段一电气保底 + 阶段二按 (档位, 电气档内顺序)
  候选（本脚本）: 同上，但电气档内部 **先取含测试条件的页**，再取其余页

两组只差「电气档内部顺序」这一个变量，其余（head、配额、字符预算、
整页取舍）完全一致。

对照指标
--------
1. `elec_cover` 电气表页覆盖率
2. `cond_cover` 测试条件页覆盖率
3. `pair_rate`  电气表页与其条件页**同时**进入上下文的比例
4. `unit_keep`  UNIT / MIN / NOM / MAX 表头保留率
5. 副作用：`order_keep` 订货信息、`pkg_keep` 封装信息、`pin_keep` 引脚信息

> 判定原则（见 HANDOFF §门槛判定）：**不追求「选中电气关键词页更多」**，
> 而是提升「数值 + 条件 + 单位」三者能同时进入上下文的比例。
> 增加错误条件下的参数，可能比漏掉参数更危险。

只读保证
--------
- PDF 用 pymupdf 只读打开，用完即关；
- 生产 JSON 只 `read_text`；
- 唯一写入是 `--json-out` 显式指定的报告路径；
- 不调用模型、不连数据库、不改生产代码。

用法
----
    python qc/sim_condition_first.py --mpn AM5746ABZXEA
    python qc/sim_condition_first.py --all \
        --json-out docs/qc/regression/condition_first_sim.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                                # noqa: E402


# ---------------------------------------------------------------- 页面分类

ELEC_TABLE_PATS = (
    re.compile(r"electrical\s+characteristic", re.I),
    re.compile(r"absolute\s+maximum\s+rating", re.I),
    re.compile(r"recommended\s+operating", re.I),
    re.compile(r"switching\s+characteristic", re.I),
    re.compile(r"dc\s+characteristic", re.I),
    re.compile(r"thermal\s+information", re.I),
)

# 测试条件：表格里限定参数适用范围的说明
CONDITION_PATS = (
    re.compile(r"\bV\s*(?:DD|CC|IO|CORE|PP)\b\s*[=:]", re.I),
    re.compile(r"\bT\s*[AJ]\b\s*[=:]", re.I),
    re.compile(r"\bover\s+(?:recommended|operating)\b", re.I),
    re.compile(r"\btest\s+conditions?\b", re.I),
    re.compile(r"\bunless\s+otherwise\s+noted\b", re.I),
)

ORDERING_PATS = (
    re.compile(r"ordering\s+information", re.I),
    re.compile(r"orderable", re.I),
    re.compile(r"package\s+option\s+addendum", re.I),
)

PACKAGE_PATS = (
    re.compile(r"package\s+(?:type|drawing|outline)", re.I),
    re.compile(r"mechanical\s+data", re.I),
    re.compile(r"dimension", re.I),
)

PIN_PATS = (
    re.compile(r"pin\s+(?:functions?|configuration)", re.I),
    re.compile(r"terminal\s+(?:functions?|configuration)", re.I),
    re.compile(r"signal\s+descriptions", re.I),
)

UNIT_PATS = (
    re.compile(r"\bUNIT\b", re.I),
    re.compile(r"\b(?:MIN|NOM|TYP|MAX)\b", re.I),
)

CLASSES = (("elec_table", ELEC_TABLE_PATS),
           ("condition", CONDITION_PATS),
           ("ordering", ORDERING_PATS),
           ("package", PACKAGE_PATS),
           ("pin", PIN_PATS))


def _pages_of(pages_text, pats) -> set[int]:
    """命中任一条判据的页号集合。"""
    return {pn for pn, text in pages_text
            if any(p.search(text) for p in pats)}


def classify_pages(pages_text) -> dict[str, set[int]]:
    """给每页打类别标签（一页可多标签）。"""
    out: dict[str, set[int]] = {}
    for name, pats in CLASSES:
        out[name] = _pages_of(pages_text, pats)
    return out


# ---------------------------------------------------------------- PDF 全文

def _read_pdf_full(pdf: Path, report: dict) -> list[tuple[int, str]]:
    """pymupdf 直读全文（不经 `PD._iter_pages`，避免 MAX_PAGES 截断）。"""
    try:
        import fitz                                          # noqa: PLC0415
        with fitz.open(str(pdf)) as doc:
            return [(i + 1, doc[i].get_text("text") or "")
                    for i in range(doc.page_count)]
    except Exception as e:                                   # noqa: BLE001
        report["warnings"].append(f"pymupdf 读取失败：{type(e).__name__}: {e}")
    out: list[tuple[int, str]] = []
    for pn, text in PD._iter_pages(str(pdf)):
        if isinstance(pn, int) and pn < 1:
            pn += 1
        out.append((pn, text or ""))
    return out


# ---------------------------------------------------------------- 两版选页

def _sel_of(text: str) -> list[int]:
    return sorted({int(n) for n in
                   re.findall(r"^---\s*Page\s+(\d+)\s*---", text, re.M)})


def select_pages_cond_first(pages, max_pages: int, max_chars: int):
    """候选策略：电气档内部 **条件页优先**，其余与当前 V4 逐字一致。"""
    head: list[tuple[int, int, str]] = []
    ranked: list[tuple[int, int, str]] = []
    for i, text in pages:
        if i >= PD.PAGE_SCAN_CAP:
            break
        if not (text or "").strip():
            continue
        if i < 3:
            head.append((0, i, text))
            continue
        low = (text or "").lower()
        rank = len(PD.PAGE_PRIORITY) + 1
        for n, keys in enumerate(PD.PAGE_PRIORITY, start=1):
            if any(k in low for k in keys):
                rank = n
                break
        ranked.append((rank, i, text))

    # 条件页：全文范围，不只电气档
    cond_pages = {i for _r, i, t in ranked
                  if any(p.search(t) for p in CONDITION_PATS)}

    ec_seq: dict[int, int] = {}
    if len(PD.RANK_QUOTA) >= 3:
        ec_cands = [r for r in ranked if r[0] == 3]
        for pos, r in enumerate(PD._ec_pick_order(ec_cands, PD.RANK_QUOTA[2])):
            ec_seq[r[1]] = pos

    def _rank_key(x: tuple) -> tuple:
        # 档位优先 → 档内条件页优先 → 电气档原顺序
        return (x[0], 0 if x[1] in cond_pages else 1,
                ec_seq.get(x[1], x[1]))

    chosen: list[tuple[int, str]] = []
    chars, dropped, taken = 0, False, {}
    pages_left = max_pages

    def _take(rank: int, i: int, text: str) -> None:
        nonlocal chars, pages_left
        chosen.append((i, text))
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)
        pages_left -= 1

    # ---- 阶段一：电气档字符保底（条件页优先）----
    if len(PD.RANK_QUOTA) >= 3:
        floor_got = 0
        for rank, i, text in sorted([r for r in ranked if r[0] == 3],
                              key=_rank_key):
            if floor_got >= PD.ELEC_FLOOR_CHARS or \
                    taken.get(3, 0) >= PD.RANK_QUOTA[2]:
                break
            if pages_left <= 0 or chars + len(text) > max_chars:
                break
            floor_got += len(text)
            _take(rank, i, text)

    # ---- 阶段二：head 打底 + 按档补充 ----
    for rank, i, text in head + sorted(ranked, key=_rank_key):
        if any(i == ci for ci, _ in chosen):
            continue
        quota = (PD.RANK_QUOTA[rank - 1]
                 if 1 <= rank <= len(PD.RANK_QUOTA) else 99)
        if taken.get(rank, 0) >= quota:
            continue
        if pages_left <= 0 or chars + len(text) > max_chars:
            dropped = True
            continue
        _take(rank, i, text)

    chosen.sort()
    out = "".join(f"\n--- Page {i + 1} ---\n{t}" for i, t in chosen)
    return out, len(chosen), dropped


# ---------------------------------------------------------------- 单件对照

def compare(mpn: str, data_dir: Path) -> dict:
    rep: dict = {"mpn": mpn, "warnings": []}
    pdf_dir = data_dir / "pdfs"
    hits = (sorted(pdf_dir.glob(f"{mpn}__*.pdf"))
            or sorted(pdf_dir.glob(f"{mpn}*.pdf")))
    if not hits:
        rep["error"] = f"PDF 未找到：{pdf_dir}/{mpn}*.pdf"
        return rep
    pdf = hits[0]
    rep["pdf"] = str(pdf)

    pages_text = _read_pdf_full(pdf, rep)
    rep["page_count"] = len(pages_text)

    cls = classify_pages(pages_text)
    elec_all, cond_all = cls["elec_table"], cls["condition"]

    # 基线 V4
    t_v4, used_v4, trunc_v4 = PD.select_pages(
        iter(pages_text), PD.MAX_PAGES, PD.MAX_CHARS)
    sel_v4 = _sel_of(t_v4)

    # 候选：条件页优先
    t_cf, used_cf, trunc_cf = select_pages_cond_first(
        iter(pages_text), PD.MAX_PAGES, PD.MAX_CHARS)
    sel_cf = _sel_of(t_cf)

    def cov(sel, allp):
        s = set(sel) & allp
        return {"hit": len(s), "total": len(allp),
                "rate": round(len(s) / len(allp), 3) if allp else 0.0}

    rep["compare"] = {
        "sel_v4": sel_v4, "used_v4": used_v4, "trunc_v4": bool(trunc_v4),
        "sel_cf": sel_cf, "used_cf": used_cf, "trunc_cf": bool(trunc_cf),
        "added": sorted(set(sel_cf) - set(sel_v4)),
        "removed": sorted(set(sel_v4) - set(sel_cf)),
        "elec_cover": {"v4": cov(sel_v4, elec_all), "cf": cov(sel_cf, elec_all)},
        "cond_cover": {"v4": cov(sel_v4, cond_all), "cf": cov(sel_cf, cond_all)},
        "unit_keep": {"v4": cov(sel_v4, _pages_of(pages_text, UNIT_PATS)),
                      "cf": cov(sel_cf, _pages_of(pages_text, UNIT_PATS))},
        "side_effect": {
            "ordering": {"v4": cov(sel_v4, cls["ordering"]),
                         "cf": cov(sel_cf, cls["ordering"])},
            "package": {"v4": cov(sel_v4, cls["package"]),
                        "cf": cov(sel_cf, cls["package"])},
            "pin": {"v4": cov(sel_v4, cls["pin"]),
                    "cf": cov(sel_cf, cls["pin"])},
        },
    }
    return rep


def main(argv=None) -> int:
    from qc import prompt_dryrun as PG
    ap = argparse.ArgumentParser(
        description="「条件页优先」选页策略离线模拟（只读、零模型调用）")
    ap.add_argument("--mpn", action="append", default=[])
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--json-out", default=None)
    a = ap.parse_args(argv)

    v2 = PG.OUT / "v2"
    items = a.mpn or (sorted(p.stem for p in v2.glob("*.json"))
                       if a.all else [])
    if not items:
        ap.error("需要 --mpn 或 --all")

    out = [compare(m, Path(a.data_dir)) for m in items]
    text = json.dumps(out, ensure_ascii=False, indent=2)
    print(text)
    if a.json_out:
        p = Path(a.json_out)
        if p.parent and str(p.parent) not in ("", "."):
            p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        print(f"\n[written] {p}", file=sys.stderr)
    return 0 if not any(o.get("error") for o in out) else 1


if __name__ == "__main__":
    raise SystemExit(main())
