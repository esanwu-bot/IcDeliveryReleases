"""文件身份与路径一致性审计（只读，不删文件、不改路径）。

为什么单独做这一轮
------------------
上一轮核账时发现三类不一致，它们不解决就没法谈「安全写回」：

  1. `item.json_path` 混着两种形态：容器路径 `/app/data/parsed/..` 与
     Windows 本地路径 `E:\\workspace\\IcPdfParser\\data\\parsed\\..`。
     容器里按原样读一定失败，只能按 basename 反查——这是个隐患，不是正常设计。
  2. 同一 MPN 在 parsed 目录下有多份 JSON（孤儿文件），DB 只引用其中一份，
     而孤儿文件的内容往往与被引用的那份不同（少了人工回带字段）。
  3. 个别件的 PDF 与料号错配（`ADS1254E` 拿到 EVM 指南、`D9LVRA2DEMR`
     拿到 Q1 文档），旧值的参数其实来自另一份文档。

本脚本只做审计与分级，**不删任何文件、不改任何路径、不改数据库**。

用法（容器内）
--------------
    python qc/v4_identity_audit.py --out-dir /tmp/v4_ident
    python qc/v4_identity_audit.py --hash-scope 228 --out-dir /tmp/v4_ident
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.reparse_ordering import _safe                      # noqa: E402

WIN_RE = re.compile(r"^[A-Za-z]:[\\/]")
HASH8_RE = re.compile(r"_([0-9a-f]{8,})\.json$", re.I)


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _name(p: str) -> str:
    """DB 里两种路径形态都要能取到末段：Windows 的反斜杠在 Linux 上不是分隔符。"""
    return Path(p.replace("\\", "/")).name if p else ""


def classify_path(p: str) -> str:
    if not p:
        return "空"
    if WIN_RE.match(p):
        return "Windows本地路径"
    if p.startswith("/"):
        return "容器绝对路径"
    return "相对路径/裸文件名"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="文件身份与路径一致性审计")
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--hash-scope", default="228",
                    help="对哪些件做 PDF 哈希实测：228 | all | none")
    ap.add_argument("--mpns-file", default="", help="额外指定件（每行一个 MPN）")
    ap.add_argument("--out-dir", default="/tmp/v4_ident")
    a = ap.parse_args(argv)

    data_root = Path(a.data_root)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    parsed, pdfs = data_root / "parsed", data_root / "pdfs"

    db = sqlite3.connect(data_root / "workbench.sqlite3")
    rows = db.execute("SELECT mpn, pdf_path, json_path FROM item").fetchall()
    print("item 总数 %d" % len(rows))

    pdf_index = {p.name: p for p in pdfs.glob("*.pdf")}
    json_index = {p.name: p for p in parsed.glob("*.json")}
    print("PDF %d 份 / JSON %d 份" % (len(pdf_index), len(json_index)))

    # ---- JSON 按 MPN 归组，找同 MPN 多份（孤儿） ----
    by_mpn: dict[str, list[str]] = defaultdict(list)
    for name in json_index:
        stem = name.rsplit("_", 1)[0]
        by_mpn[stem].append(name)

    # ---- 逐件审计 ----
    out: list[dict] = []
    path_kind = Counter()
    issues = Counter()
    for mpn, pdf_path, json_path in rows:
        jn, pn = _name(json_path), _name(pdf_path)
        jk, pk = classify_path(json_path), classify_path(pdf_path)
        path_kind["json:" + jk] += 1
        path_kind["pdf:" + pk] += 1

        j_exists = jn in json_index
        p_exists = pn in pdf_index
        # 「两个路径都空」= 还没解析过的料号，是待办不是缺陷，单独归类
        not_parsed = not jn and not pn
        # DB 引用的 JSON 文件名里的 hash8 与 PDF 实际 hash8 是否同源
        m = HASH8_RE.search(jn or "")
        j_hash8 = m.group(1) if m else ""
        pdf_sha = ""
        meta_hash = ""

        # 同 MPN 下的其它 JSON（孤儿候选）
        sibs = sorted(by_mpn.get(mpn, []))
        orphan = [s for s in sibs if s != jn]

        r = {
            "mpn": mpn,
            "json_path_kind": jk, "pdf_path_kind": pk,
            "json_name": jn, "pdf_name": pn,
            "state": "未解析" if not_parsed else "已解析",
            "json_exists": ("是" if j_exists else "否") if jn else "",
            "pdf_exists": ("是" if p_exists else "否") if pn else "",
            "json_hash8": j_hash8,
            "pdf_sha256_16": "", "meta_pdf_hash_16": "",
            "hash_match": "", "sibling_json_n": len(sibs),
            "sibling_json": "|".join(orphan[:4]),
            "level": "-", "issue": "-",
        }
        bad = []
        if not_parsed:
            r["level"] = "-"
        else:
            if jn and not j_exists:
                bad.append("DB 引用的 JSON 不存在")
            if pn and not p_exists:
                bad.append("DB 引用的 PDF 不存在")
            if jn and pn and jk != pk:
                bad.append("json/pdf 路径形态不一致")
            if len(sibs) >= 2:
                bad.append("同 MPN 多份 JSON")
            elif len(sibs) == 1 and sibs[0] != jn:
                bad.append("DB 引用的 JSON 名与实际文件名不同")
        for b in bad:
            issues[b] += 1
        if bad:
            r["issue"] = "；".join(bad)
            r["level"] = "P0" if any("不存在" in b for b in bad) else "P2"
        out.append(r)

    # ---- 哈希实测：只对指定范围做，避免全库 13k 次 SHA256 ----
    scope: set[str] = set()
    if a.hash_scope == "all":
        scope = {r["mpn"] for r in out}
    elif a.hash_scope == "228":
        diff = Path("/tmp/v4_dryrun/v4_quality_diff.csv")
        if diff.exists():
            scope = {x["mpn"] for x in csv.DictReader(diff.open(encoding="utf-8-sig"))}
        print("哈希实测范围：228 件（取自 dry-run diff）")
    if a.mpns_file and Path(a.mpns_file).exists():
        scope |= {x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()}
    if a.hash_scope != "none" and scope:
        print("哈希实测 %d 件" % len(scope))
        for r in out:
            if r["mpn"] not in scope:
                continue
            p = pdf_index.get(r["pdf_name"])
            if not p:
                continue
            sha = _sha(p)
            r["pdf_sha256_16"] = sha[:16]
            j = json_index.get(r["json_name"])
            if j:
                meta_hash = str((_load(j).get("metadata") or {}).get("pdf_hash") or "")
                r["meta_pdf_hash_16"] = meta_hash[:16]
            ok = (not meta_hash) or meta_hash.startswith(sha[:16])
            # 文件名里的 hash8 是 PDF SHA256 的前 8 位，两边都取 8 位再比
            r["hash_match"] = "是" if sha[:8] == (r["json_hash8"] or "").lower() else "否"
            if not ok:
                issues["metadata.pdf_hash 与 PDF 不一致"] += 1
                r["issue"] = "；".join(
                    x for x in (r["issue"], "metadata.pdf_hash 与 PDF 不一致")
                    if x and x != "-")
                r["level"] = "P1"
            if r["hash_match"] == "否":
                issues["JSON 文件名 hash8 与 PDF 不符"] += 1
                r["issue"] = "；".join(
                    x for x in (r["issue"], "JSON 文件名 hash8 与 PDF 不符")
                    if x and x != "-")
                if r["level"] == "-":
                    r["level"] = "P2"

    # ---- 输出 ----
    cols = list(out[0].keys())
    with (out_dir / "v4_identity_audit.csv").open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(out)

    lv = Counter(r["level"] for r in out)
    print("\n=== 路径形态分布 ===")
    for k, v in path_kind.most_common():
        print("   %-28s %d" % (k, v))
    print("\n=== 问题计数 ===")
    for k, v in issues.most_common():
        print("   %-28s %d 件" % (k, v))
    print("\n=== 分级 ===")
    for k in ("P0", "P1", "P2", "-"):
        print("   %-3s %d 件" % (k, lv.get(k, 0)))

    # 同 MPN 多份 JSON 的明细，单独出一份便于人工判断
    dup = [r for r in out if r["sibling_json_n"] > 1]
    with (out_dir / "v4_identity_dup_json.csv").open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(dup)
    print("\n同 MPN 多份 JSON：%d 件 -> v4_identity_dup_json.csv" % len(dup))
    for r in dup[:12]:
        print("   %-22s 引用 %s ；同族 %s" % (r["mpn"], r["json_name"], r["sibling_json"][:90]))

    print("\n写 %s（%d 行）" % (out_dir / "v4_identity_audit.csv", len(out)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
