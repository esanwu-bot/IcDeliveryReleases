"""原厂证据登记与核验（Source Evidence Registry）——阶段 A/B。

核心原则：**先确认 PDF 身份，再核验字段**。来源等级（P0–P4）只表示优先级，
不代表文档身份已通过核验；官方域名也不等于覆盖目标订购型号。

分层职责：
  * 本模块（纯函数）：PDF 指纹、可读性、官方域名判定、身份确认规则、冻结守卫
  * `gold_field` 继续承载字段真值；证据卡只承载「来源 + 文档身份 + 字段证据定位」
  * 机器只做可复现检查；`identity_status=verified` 与字段核验必须由人工触发

自包含约束（与 qc/goldset.py 同口径）：会被工作台 server 进程 import，
不得有模块级 stdout 包装副作用，不 import qc.table_audit / qc.qc_regression。
DB 访问通过 `db_mod` 注入（None 时延迟 import app.db），便于离线单测。

CLI：
    python qc/source_evidence.py inspect <pdf> [--url=... --maker=...]
    python qc/source_evidence.py stats
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

# 容器内直接 `python /app/qc/source_evidence.py` 时 sys.path[0] 是 /app/qc，
# 需要把仓库根加进来才能 `from app import db`（无 stdout 副作用）。
import sys as _sys
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_ROOT))

TIERS = ("P0", "P1", "P2", "P3", "P4")
TIER_RULES = {
    "P0": "原厂官网发布的数据手册 PDF（首选；记录官方 URL、版本与日期）",
    "P1": "原厂产品页 / 勘误表 / 官方封装图（补充订购信息、封装与修订）",
    "P2": "原厂应用说明或技术文档（仅在其明确支持待核验结论时使用）",
    "P3": "授权分销商 / 器件聚合库（辅助交叉检查，不覆盖原厂冲突）",
    "P4": "OCR / LLM / 现有解析 JSON（只作待核验对象，不作标准答案来源）",
}
EVIDENCE_STATUS = ("pending", "identity_review", "field_review", "verified",
                   "source_unresolved", "conflict", "frozen")
IDENTITY_STATUS = ("pending", "verified", "mismatch", "unresolved")
FIELD_STATUS = ("pending", "verified", "rejected", "conflict")

# 官方域名白名单：按注册域后缀匹配，绝不因为 URL 里出现品牌名就认定官方
OFFICIAL_DOMAINS = {
    "TI": {"ti.com", "ti.com.cn"},
    "Texas Instruments": {"ti.com", "ti.com.cn"},
    "ST": {"st.com"},
    "STMicroelectronics": {"st.com"},
    "Microchip": {"microchip.com"},
    "ADI": {"analog.com"},
    "Analog Devices": {"analog.com"},
    "Maxim": {"analog.com"},            # Maxim 已并入 ADI
    "onsemi": {"onsemi.com"},
    "ON Semiconductor": {"onsemi.com"},
    "NXP": {"nxp.com"},
    "Diodes": {"diodes.com"},
    "Silicon Labs": {"silabs.com"},
    "Espressif": {"espressif.com"},
    "Renesas": {"renesas.com"},
    "Infineon": {"infineon.com"},
}

# 4 张表：app/db.py 直接拼接进 DDL（单一来源，避免两处维护）
SOURCE_DDL = """
-- ================= 原厂证据登记（Source Evidence Registry） =================
-- 来源等级只表示优先级；身份与字段核验必须人工确认，机器不得自动 verified。
CREATE TABLE IF NOT EXISTS source_document (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    source_tier        TEXT NOT NULL DEFAULT 'P0',   -- P0|P1|P2|P3|P4
    source_type        TEXT NOT NULL DEFAULT 'datasheet_pdf',
    source_url         TEXT NOT NULL DEFAULT '',
    final_url          TEXT NOT NULL DEFAULT '',
    is_official        INTEGER NOT NULL DEFAULT 0,   -- 仅官方域名白名单命中
    local_path         TEXT NOT NULL DEFAULT '',
    pdf_sha256         TEXT NOT NULL DEFAULT '',
    page_count         INTEGER NOT NULL DEFAULT 0,
    document_revision  TEXT NOT NULL DEFAULT '',
    document_date      TEXT NOT NULL DEFAULT '',
    covered_mpn_json   TEXT NOT NULL DEFAULT '[]',   -- 人工确认覆盖的型号
    identity_status    TEXT NOT NULL DEFAULT 'pending',
    identity_notes     TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_srcdoc_sha      ON source_document(pdf_sha256);
CREATE INDEX IF NOT EXISTS idx_srcdoc_identity ON source_document(identity_status);

CREATE TABLE IF NOT EXISTS source_evidence (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    mpn                TEXT NOT NULL,
    manufacturer       TEXT NOT NULL DEFAULT '',
    target_fields_json TEXT NOT NULL DEFAULT '[]',
    document_id        INTEGER NOT NULL DEFAULT 0,   -- → source_document.id
    status             TEXT NOT NULL DEFAULT 'pending',
    identity_status    TEXT NOT NULL DEFAULT 'pending',
    precheck_json      TEXT NOT NULL DEFAULT '',     -- E2 身份预检报告（机器起草）
    verified_by        TEXT NOT NULL DEFAULT '',
    verified_at        TEXT NOT NULL DEFAULT '',
    notes              TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_srcev_mpn    ON source_evidence(mpn);
CREATE INDEX IF NOT EXISTS idx_srcev_status ON source_evidence(status);

CREATE TABLE IF NOT EXISTS source_field_evidence (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    evidence_id         INTEGER NOT NULL DEFAULT 0,  -- → source_evidence.id
    document_id         INTEGER NOT NULL DEFAULT 0,  -- → source_document.id
    gold_field_id       INTEGER NOT NULL DEFAULT 0,  -- → gold_field.id（0=未绑定）
    field_path          TEXT NOT NULL,
    page_number         INTEGER NOT NULL DEFAULT 0,  -- 必须 >0 才能核验
    table_name          TEXT NOT NULL DEFAULT '',
    row_key             TEXT NOT NULL DEFAULT '',
    column_key          TEXT NOT NULL DEFAULT '',
    cell_value          TEXT NOT NULL DEFAULT '',
    evidence_quote      TEXT NOT NULL DEFAULT '',
    verification_status TEXT NOT NULL DEFAULT 'pending',
    candidates_json     TEXT NOT NULL DEFAULT '',    -- E3 候选位置（不自动取舍）
    engine              TEXT NOT NULL DEFAULT 'pymupdf',
    reviewer            TEXT NOT NULL DEFAULT '',
    verified_at         TEXT NOT NULL DEFAULT '',
    notes               TEXT NOT NULL DEFAULT '',
    created_at          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_srcfield_path ON source_field_evidence(evidence_id, field_path);

CREATE TABLE IF NOT EXISTS source_verification_log (   -- append-only
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    evidence_id  INTEGER NOT NULL DEFAULT 0,
    document_id  INTEGER NOT NULL DEFAULT 0,
    action       TEXT NOT NULL,
    actor        TEXT NOT NULL DEFAULT '',
    old_status   TEXT NOT NULL DEFAULT '',
    new_status   TEXT NOT NULL DEFAULT '',
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_srclog_evidence ON source_verification_log(evidence_id, id);
"""


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- 纯判定层
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def host_of(url: str) -> str:
    return (urlparse(url or "").hostname or "").lower()


def domain_ok(host: str, manufacturer: str) -> bool:
    """注册域后缀匹配：ti.com / www.ti.com 命中；ti.com.evil.com 不命中。"""
    h = (host or "").lower().strip(".")
    if not h:
        return False
    allowed = OFFICIAL_DOMAINS.get((manufacturer or "").strip(), set())
    return any(h == d or h.endswith("." + d) for d in allowed)


def is_official_url(url: str, manufacturer: str) -> bool:
    return domain_ok(host_of(url), manufacturer)


def inspect_pdf(path: Path, source_url: str = "", manufacturer: str = "") -> dict:
    """可复现检查：存在性、可读性、页数、SHA-256、官方域名。

    **不**自动给 identity_status=verified —— 官方来源只是必要条件，
    型号/后缀/版本覆盖必须人工核对（见 confirm_identity）。
    """
    p = Path(path)
    out = {"path": str(p), "ok": False, "pdf_sha256": "", "page_count": 0,
           "is_official": False, "identity_status": "pending",
           "identity_notes": "", "error": ""}
    if not p.is_file():
        out["identity_status"] = "unresolved"
        out["identity_notes"] = "PDF 文件不存在"
        out["error"] = out["identity_notes"]
        return out
    try:
        import fitz
        with fitz.open(p) as pdf:
            if pdf.is_encrypted and pdf.needs_pass:
                raise ValueError("PDF 需要密码")
            out["page_count"] = pdf.page_count
            if pdf.page_count <= 0:
                raise ValueError("PDF 没有页面")
    except Exception as exc:                                # noqa: BLE001
        out["identity_status"] = "unresolved"
        out["identity_notes"] = f"PDF 无法读取：{exc}"
        out["error"] = out["identity_notes"]
        return out
    out["ok"] = True
    out["pdf_sha256"] = sha256_file(p)
    out["is_official"] = is_official_url(source_url, manufacturer)
    out["identity_notes"] = ("已通过 PDF 可读取性检查；"
                             "需人工核对 PDF 型号、后缀、封装和修订版本。")
    if source_url and not out["is_official"]:
        out["identity_notes"] += f"（来源域名 {host_of(source_url) or '未知'} 不在官方白名单）"
    return out


def normalize_mpns(values) -> list[str]:
    seen, out = set(), []
    for v in (values or []):
        s = str(v or "").strip().upper()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def confirm_identity(target_mpn: str, covered_mpns, is_official: bool,
                     reviewer: str, notes: str = "") -> dict:
    """人工确认文档身份（不写库，由调用方落库）。

    通过条件（缺一不可）：有核验人 / 官方来源已确认 / 人工确认的覆盖型号含目标 MPN。
    """
    if not str(reviewer or "").strip():
        raise ValueError("必须记录核验人")
    if not is_official:
        raise ValueError("来源尚未确认是制造商官方域名")
    cov = normalize_mpns(covered_mpns)
    if not cov:
        raise ValueError("必须至少确认一个覆盖型号（来自人工检查原厂 PDF）")
    if str(target_mpn or "").strip().upper() not in cov:
        return {"identity_status": "unresolved", "covered_mpn_json": json.dumps(cov, ensure_ascii=False),
                "identity_notes": ("人工未能确认目标 MPN 被此文档覆盖；" + (notes or "")).strip(),
                "reviewer": reviewer}
    return {"identity_status": "verified", "covered_mpn_json": json.dumps(cov, ensure_ascii=False),
            "identity_notes": (notes or "人工确认型号/后缀/封装/版本覆盖").strip(),
            "reviewer": reviewer}


def can_freeze(evidence: dict, document: dict, field_evidence: list,
               gold_fields: list | None = None) -> tuple[bool, str]:
    """冻结前守卫（对应方案 §7）。gold_fields 非空时要求每个待冻结字段都有已核验证据。"""
    st = (evidence.get("status") or "")
    if st == "source_unresolved":
        return False, "来源未解决（source_unresolved），不能冻结 Gold Set"
    if st == "conflict":
        return False, "存在来源冲突，需先解决冲突"
    if (document.get("identity_status") or "") != "verified":
        return False, "PDF 身份尚未人工确认"
    if not document.get("is_official"):
        return False, "当前文档未确认来自原厂官方来源"
    cov = normalize_mpns(json.loads(document.get("covered_mpn_json") or "[]"))
    target = (evidence.get("mpn") or "").strip().upper()
    if target not in cov:
        return False, f"目标 MPN {target} 不在文档已确认覆盖范围内"
    if not field_evidence:
        return False, "缺少字段级证据"
    # 同一字段允许多条候选证据（如旧登记被新证据替代）：只要求「至少一条已核验」，
    # 但任何未解决的 conflict 都必须先处置。
    verified: dict[str, dict] = {}
    for item in field_evidence:
        st = (item.get("verification_status") or "")
        if "conflict" in st:                       # conflict / conflict_draft 一律先裁决
            return False, f"字段 {item.get('field_path')} 存在未解决的证据冲突（{st}）"
        if st != "verified":
            continue
        if not int(item.get("page_number") or 0):
            return False, f"字段 {item.get('field_path')} 缺少 PDF 页码"
        if not str(item.get("reviewer") or "").strip():
            return False, f"字段 {item.get('field_path')} 缺少核验人"
        verified.setdefault(item.get("field_path"), item)
    if not verified:
        return False, "没有已人工核验的字段证据"
    if gold_fields:
        missing = [f.get("field_path") for f in gold_fields
                   if f.get("field_path") not in verified]
        if missing:
            return False, f"{len(missing)} 个 Gold 字段缺少已核验证据：{', '.join(missing[:5])}"
    want = (document.get("pdf_sha256") or "").strip()
    got = (evidence.get("gold_pdf_sha256") or "").strip()
    if want and got and want != got:
        return False, "Gold 登记的 PDF 哈希与证据卡文档不一致（疑似换了文档版本）"
    return True, "基础证据校验通过"


# ---------------------------------------------------------------- DB 编排层
def _d(dbm):
    if dbm is not None:
        return dbm
    from app import db as _db                            # 延迟导入，避免 app↔qc 循环
    return _db


def _log(d, evidence_id: int, document_id: int, action: str, actor: str,
         old: str = "", new: str = "", details: dict | None = None) -> None:
    d.x("INSERT INTO source_verification_log(evidence_id,document_id,action,actor,"
        "old_status,new_status,details_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
        (evidence_id, document_id, action, actor or "cli", old or "", new or "",
         json.dumps(details or {}, ensure_ascii=False), now()))


def _risk(d, mpn: str, kind: str, reason: str, operator: str) -> int:
    """来源类风险入库（mpn+kind 去重，避免重复排队）。"""
    dup = d.q1("SELECT id FROM risk_case WHERE mpn=? AND kind=? "
               "AND status IN ('open','confirming','to_regression') LIMIT 1", (mpn, kind))
    if dup:
        return 0
    pri, score = ("P0", 72) if kind in ("identity_unverified", "mpn_conflict") else ("P1", 55)
    ts = now()
    d.x("INSERT INTO risk_case(mpn,kind,finding_id,priority,reason,score,status,"
        "operator,created_at,updated_at) VALUES(?,?,0,?,?,?, 'open',?,?,?)",
        (mpn, kind, pri, reason[:300], score, operator or "cli", ts, ts))
    return 1


def create_evidence(mpn: str, manufacturer: str = "", target_fields=None,
                    operator: str = "cli", db_mod=None) -> int:
    d = _d(db_mod)
    mpn = str(mpn or "").strip()
    if not mpn:
        raise ValueError("mpn 必填")
    exist = d.q1("SELECT id FROM source_evidence WHERE mpn=? AND status NOT IN ('frozen') "
                 "ORDER BY id DESC LIMIT 1", (mpn,))
    if exist:
        return exist["id"]
    ts = now()
    eid = d.x("INSERT INTO source_evidence(mpn,manufacturer,target_fields_json,status,"
              "identity_status,created_at,updated_at) VALUES(?,?,?, 'pending','pending',?,?)",
              (mpn, manufacturer or "", json.dumps(target_fields or [], ensure_ascii=False),
               ts, ts))
    _log(d, eid, 0, "evidence_created", operator,
         details={"mpn": mpn, "manufacturer": manufacturer})
    return eid


def add_document(evidence_id: int, source_tier: str, source_url: str = "",
                 local_path: str = "", source_type: str = "datasheet_pdf",
                 operator: str = "cli", db_mod=None) -> dict:
    """登记候选文档并做可复现检查（SHA/页数/官方域名）。

    SHA-256 相同的文档在**同一证据卡内**复用记录，但不同证据卡各自保留核验历史。
    """
    d = _d(db_mod)
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise ValueError(f"证据卡 #{evidence_id} 不存在")
    tier = str(source_tier or "P0").upper()
    if tier not in TIERS:
        raise ValueError(f"source_tier 仅支持 {'/'.join(TIERS)}")
    insp = inspect_pdf(Path(local_path), source_url, ev["manufacturer"]) if local_path else {
        "ok": False, "pdf_sha256": "", "page_count": 0,
        "is_official": is_official_url(source_url, ev["manufacturer"]),
        "identity_notes": "未提供本地 PDF 路径，仅登记来源", "error": ""}
    sha = insp.get("pdf_sha256") or ""
    if sha:
        same = d.q1("SELECT * FROM source_document WHERE pdf_sha256=? AND source_tier=? "
                    "ORDER BY id LIMIT 1", (sha, tier))
        if same:
            d.x("UPDATE source_evidence SET document_id=?, updated_at=? WHERE id=?",
                (same["id"], now(), evidence_id))
            _log(d, evidence_id, same["id"], "document_reused", operator,
                 details={"sha256": sha, "tier": tier})
            return {"document_id": same["id"], "reused": True, "inspection": insp}
    ts = now()
    did = d.x("INSERT INTO source_document(source_tier,source_type,source_url,final_url,"
              "is_official,local_path,pdf_sha256,page_count,identity_status,identity_notes,"
              "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              (tier, source_type or "datasheet_pdf", source_url or "", source_url or "",
               1 if insp.get("is_official") else 0, local_path or "", sha,
               int(insp.get("page_count") or 0), insp.get("identity_status") or "pending",
               insp.get("identity_notes") or "", ts, ts))
    d.x("UPDATE source_evidence SET document_id=?, identity_status=?, updated_at=? WHERE id=?",
        (did, insp.get("identity_status") or "pending", ts, evidence_id))
    if sha:
        d.x("UPDATE gold_set SET pdf_sha256=?, pdf_name=? WHERE mpn=? AND (pdf_sha256='' OR pdf_sha256=?)",
            (sha, Path(local_path).name if local_path else "", ev["mpn"], sha))
    _log(d, evidence_id, did, "document_discovered", operator,
         old="", new=insp.get("identity_status") or "",
         details={"tier": tier, "url": source_url, "sha256": sha,
                  "pages": insp.get("page_count"), "is_official": insp.get("is_official")})
    return {"document_id": did, "reused": False, "inspection": insp}


def verify_identity(evidence_id: int, reviewer: str, covered_mpns,
                    notes: str = "", operator: str = "cli", db_mod=None) -> dict:
    """人工确认文档身份。不通过 → identity_status=unresolved + evidence=source_unresolved + 风险。"""
    d = _d(db_mod)
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise ValueError(f"证据卡 #{evidence_id} 不存在")
    doc = d.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],))
    if not doc:
        raise ValueError("证据卡尚未登记文档")
    res = confirm_identity(ev["mpn"], covered_mpns, bool(doc["is_official"]), reviewer, notes)
    ts = now()
    d.x("UPDATE source_document SET identity_status=?, covered_mpn_json=?, identity_notes=?,"
        "updated_at=? WHERE id=?",
        (res["identity_status"], res["covered_mpn_json"], res["identity_notes"], ts, doc["id"]))
    if res["identity_status"] == "verified":
        d.x("UPDATE source_evidence SET identity_status='verified', status='field_review',"
            "verified_by=?, verified_at=?, updated_at=? WHERE id=?",
            (reviewer, ts, ts, evidence_id))
        _log(d, evidence_id, doc["id"], "pdf_identity_verified", reviewer,
             old=ev["status"], new="field_review",
             details={"covered": json.loads(res["covered_mpn_json"]), "notes": notes})
        return {"identity_status": "verified", "status": "field_review", "risk_added": 0}
    extra = 0
    if res["identity_status"] == "unresolved":
        d.x("UPDATE source_evidence SET identity_status='unresolved', status='source_unresolved',"
            "notes=?, updated_at=? WHERE id=?", (res["identity_notes"], ts, evidence_id))
        _log(d, evidence_id, doc["id"], "source_unresolved", reviewer,
             old=ev["status"], new="source_unresolved", details={"notes": res["identity_notes"]})
        extra = _risk(d, ev["mpn"], "identity_unverified",
                      "原厂文档身份未确认（未覆盖目标 MPN 或来源非官方）", operator)
    return {"identity_status": res["identity_status"], "status": "source_unresolved",
            "risk_added": extra}


def set_evidence_status(evidence_id: int, status: str, reason: str,
                        operator: str = "cli", db_mod=None) -> dict:
    """人工处置 source_unresolved / conflict；恢复必须有新证据并留审计。"""
    d = _d(db_mod)
    if status not in ("pending", "identity_review", "field_review", "verified",
                      "source_unresolved", "conflict"):
        raise ValueError("不支持的证据卡状态")
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise ValueError(f"证据卡 #{evidence_id} 不存在")
    if not str(reason or "").strip():
        raise ValueError("状态变更必须填写原因（审计要求）")
    ts = now()
    d.x("UPDATE source_evidence SET status=?, notes=?, updated_at=? WHERE id=?",
        (status, reason[:500], ts, evidence_id))
    _log(d, evidence_id, ev["document_id"], "verification_revoked" if status in
         ("source_unresolved", "conflict") else "status_changed", operator,
         old=ev["status"], new=status, details={"reason": reason})
    added = 0
    if status == "conflict":
        added = _risk(d, ev["mpn"], "source_conflict", f"来源冲突：{reason}", operator)
    return {"ok": True, "status": status, "risk_added": added}


def add_field_evidence(evidence_id: int, field_path: str, page_number: int,
                       table_name: str = "", row_key: str = "", column_key: str = "",
                       cell_value: str = "", evidence_quote: str = "",
                       gold_field_id: int = 0, operator: str = "cli",
                       db_mod=None) -> int:
    d = _d(db_mod)
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise ValueError(f"证据卡 #{evidence_id} 不存在")
    if not str(field_path or "").strip():
        raise ValueError("field_path 必填")
    fid = d.x("INSERT INTO source_field_evidence(evidence_id,document_id,gold_field_id,"
              "field_path,page_number,table_name,row_key,column_key,cell_value,"
              "evidence_quote,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (evidence_id, ev["document_id"], int(gold_field_id or 0), field_path,
               int(page_number or 0), table_name or "", row_key or "", column_key or "",
               cell_value or "", evidence_quote or "", now()))
    _log(d, evidence_id, ev["document_id"], "field_evidence_added", operator,
         details={"field_path": field_path, "page": page_number, "field_evidence_id": fid})
    return fid


def verify_field(field_evidence_id: int, reviewer: str, db_mod=None) -> dict:
    """字段级证据核验：必须有页码与核验人，否则不得 verified。"""
    d = _d(db_mod)
    fe = d.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    if not fe:
        raise ValueError(f"字段证据 #{field_evidence_id} 不存在")
    if not int(fe["page_number"] or 0):
        raise ValueError(f"字段 {fe['field_path']} 缺少 PDF 页码，不能核验")
    if not str(reviewer or "").strip():
        raise ValueError("必须记录核验人")
    ts = now()
    d.x("UPDATE source_field_evidence SET verification_status='verified', reviewer=?,"
        "verified_at=? WHERE id=?", (reviewer, ts, field_evidence_id))
    if int(fe["gold_field_id"] or 0):
        d.x("UPDATE gold_field SET status='verified', page_no=?, evidence=?, verified_by=?,"
            "verified_at=? WHERE id=? AND status<>'conflict'",
            (int(fe["page_number"]), f"{fe['table_name']} / {fe['row_key']} / "
             f"{fe['column_key']}".strip(" /"), reviewer, ts, int(fe["gold_field_id"])))
    _log(d, int(fe["evidence_id"]), int(fe["document_id"]), "field_verified", reviewer,
         details={"field_path": fe["field_path"], "page": fe["page_number"],
                  "gold_field_id": fe["gold_field_id"]})
    return {"ok": True, "field_path": fe["field_path"]}


def freeze(evidence_id: int, gold_id: int, reviewer: str, db_mod=None) -> dict:
    """冻结 Gold：全部守卫通过才允许；写审计日志。"""
    d = _d(db_mod)
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise ValueError(f"证据卡 #{evidence_id} 不存在")
    doc = d.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],))
    if not doc:
        raise ValueError("证据卡尚未登记文档")
    g = d.q1("SELECT * FROM gold_set WHERE id=?", (gold_id,))
    if not g:
        raise ValueError(f"Gold #{gold_id} 不存在")
    ev = dict(ev)
    ev["gold_pdf_sha256"] = g["pdf_sha256"]
    fields = d.q("SELECT * FROM source_field_evidence WHERE evidence_id=?", (evidence_id,))
    gold_fields = d.q("SELECT * FROM gold_field WHERE gold_id=?", (gold_id,))
    # 冻结的是整件 Gold：证据卡若声明了 target_fields，必须覆盖该件全部字段，
    # 否则等于"只核验了部分字段却冻结整件"（方案 §7 明确禁止）。
    target = set(json.loads(ev["target_fields_json"] or "[]"))
    all_paths = {f["field_path"] for f in gold_fields}
    missing_target = sorted(all_paths - target) if target else []
    if missing_target:
        raise ValueError(
            f"证据卡目标字段未覆盖整件 Gold（缺 {len(missing_target)} 个，"
            f"如 {', '.join(missing_target[:3])}）；请补全 target_fields 后再冻结")
    ok, why = can_freeze(ev, doc, fields, gold_fields)
    if not ok:
        raise ValueError(why)
    ts = now()
    d.x("UPDATE gold_set SET status='frozen', updated_at=? WHERE id=?", (ts, gold_id))
    d.x("UPDATE source_evidence SET status='frozen', verified_by=?, verified_at=?,"
        "updated_at=? WHERE id=?", (reviewer, ts, ts, evidence_id))
    d.x("INSERT INTO gold_review_log(gold_id,field_id,action,detail,operator,created_at) "
        "VALUES(?,0,'freeze',?,?,?)",
        (gold_id, f"证据卡 #{evidence_id} 守卫通过：{why}", reviewer, ts))
    _log(d, evidence_id, doc["id"], "gold_frozen", reviewer,
         old=ev["status"], new="frozen",
         details={"gold_id": gold_id, "mpn": ev["mpn"], "sha256": doc["pdf_sha256"]})
    return {"ok": True, "gold_id": gold_id, "mpn": ev["mpn"], "message": why}


def detail(evidence_id: int, db_mod=None) -> dict:
    d = _d(db_mod)
    ev = d.q1("SELECT * FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        return {}
    doc = d.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],)) or {}
    fields = d.q("SELECT * FROM source_field_evidence WHERE evidence_id=? ORDER BY id",
                 (evidence_id,))
    logs = d.q("SELECT * FROM source_verification_log WHERE evidence_id=? ORDER BY id DESC "
               "LIMIT 100", (evidence_id,))
    return {"evidence": ev, "document": doc, "fields": fields, "logs": logs,
            "tiers": TIER_RULES}


def stats(db_mod=None) -> dict:
    d = _d(db_mod)
    n = d.q1("SELECT count(*) n FROM source_evidence")["n"]
    frozen = d.q1("SELECT count(*) n FROM source_evidence WHERE status='frozen'")["n"]
    unresolved = d.q1("SELECT count(*) n FROM source_evidence "
                      "WHERE status='source_unresolved'")["n"]
    ident = d.q1("SELECT count(*) n FROM source_document "
                 "WHERE identity_status='verified'")["n"]
    official = d.q1("SELECT count(*) n FROM source_document WHERE is_official=1")["n"]
    docs = d.q1("SELECT count(*) n FROM source_document")["n"]
    fe = d.q1("SELECT count(*) n FROM source_field_evidence")["n"]
    fev = d.q1("SELECT count(*) n FROM source_field_evidence "
               "WHERE verification_status='verified'")["n"]
    return {"evidence": n, "frozen": frozen, "source_unresolved": unresolved,
            "documents": docs, "official": official, "identity_verified": ident,
            "field_evidence": fe, "field_verified": fev}


def main(argv: list[str] | None = None) -> int:
    import sys
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        print("用法：inspect <pdf> [--url=... --maker=...] | stats", file=sys.stderr)
        return 2
    cmd = args[0]
    if cmd == "inspect" and len(args) >= 2:
        opts = {a.split("=", 1)[0]: a.split("=", 1)[1] for a in args[2:] if "=" in a}
        res = inspect_pdf(Path(args[1]), opts.get("--url", ""), opts.get("--maker", ""))
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if cmd == "stats":
        print(json.dumps(stats(), ensure_ascii=False, indent=2))
        return 0
    print(f"未知命令：{cmd}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
