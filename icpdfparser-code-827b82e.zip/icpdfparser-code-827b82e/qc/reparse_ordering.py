"""把「PDF 里明明有订货表、ordering_info 却只有 0~1 行」的件重解析一遍。

为什么会有这事
--------------
`extract_pdf_text` 旧实现是「只读前 12 页」（`if i >= max_pages: break`），而
TI/ADI 的订货表几乎总在文档末尾（实测 284 页的 F280037CSPTR 在第 246 页）。
前 12 页里唯一的「表」是封面那张 Device Information 小表，只有 1 行，
于是 ordering_info 只抽到 1 条，料号身份永远定不下来。

`parse_datasheets.select_pages` 已改成「前 3 页 + 全文按优先级补关键页、
订货表排最前、整页取舍不半页截断」。本脚本用它重跑受影响的那批件。

安全边界
--------
* 只挑 `len(ordering_info) < 2` **且 PDF 里确实找得到订货表页**的件；
* 重解析前把旧 JSON 备份到 `data/parsed_backup_ordering/`；
* 新结果比旧的还差（订货行变少）就自动回滚，不留半截结果；
* 模型不负责的字段（`identity` / `datasheet_scope` / 板卡封装 / 请求料号）
  从旧 doc 带回来，不让人工修正被一次重解析冲掉；
* 新结果丢了旧 doc 有的顶层键（如 `multi_language`）就判定失败并回滚——
  2026-10-28 那次 235 件丢多语言就是这么丢的。

用法（容器内）
--------------
    python qc/reparse_ordering.py --dry-run          # 只列名单，不调模型
    python qc/reparse_ordering.py --limit 3 --apply  # 先试 3 件
    python qc/reparse_ordering.py --apply            # 全量
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import board_identity as BI                       # noqa: E402

# 重解析不该覆盖的字段：这些是人工/板卡修正的产物，模型给不出来
KEEP_BASIC = ("identity", "datasheet_scope", "requested_mpn", "datasheet_url")
KEEP_PKG = ("onboard_device", "form_factor")

# 模型不会重新生成的顶层键，必须从旧 doc 整块带回。
# `multi_language` 由 `ICPDF_LANGS` 控制是否生成，生产四个容器都没设该变量
# （见 parse_datasheets.LANG_RULE：未设时 prompt 明确要求「不要输出」），
# 所以新解析永远没有它——不显式带回，就是每重解析一件丢一件多语言。
KEEP_TOP = ("multi_language",)

# 新解析结果必须齐备的顶层键。少任何一个都判定「顶层键丢失」并整件回滚，
# 不做「少几个也算成功」的宽容判定。
REQUIRED_TOP = ("basic_info", "specs", "features", "applications",
                "pin_configuration", "ordering_info", "alternatives",
                "seo", "metadata")


def _safe(name: str) -> str:
    return (
        (name or "").replace("/", "_").replace("\\", "_").replace(":", "_")
        .replace("*", "_").replace("?", "_").replace('"', "_")
        .replace("<", "_").replace(">", "_").replace("|", "_").strip() or "unnamed"
    )


def _pdf_for(pdfs_dir: Path, mpn: str) -> Path | None:
    """按「精确名 → `MPN__xxx.pdf` 严格匹配」找 PDF，找不到就返回 None。

    为什么不能用前缀兜底
    --------------------
    旧实现是 `sorted(glob(f"{mpn}*.pdf"))[0]`。PDF 统一命名为 `MPN__文档.pdf`，
    前缀会命中同族的别的文件，而且排序把它们排到了正确文件前面（'Q'、'V' 都
    小于 '_'）。实测踩坏两件：
      * `ADS1254E`    命中 `ADS1254EVM__ADS1254-Rev2006.pdf`——评估板用户指南，
                      不是芯片手册，订货行 0→4 抽的全是板卡料号；
      * `D9LVRA2DEMR` 命中 `D9LVRA2DEMRQ1__ds90lvra2-q1.pdf`——另一个可订购型号
                      （车规 Q1 版）的文档，订货行 1→2 看着像改善，其实是别家的料号。
    前缀只能用来生成候选，不能当原件选择的依据。严格匹配不到就跳过：
    全库 14,181 份 PDF 里因此少解析 57 件，远好过解析成错的产品。
    """
    if not pdfs_dir.is_dir():
        return None
    safe = _safe(mpn)
    exact = pdfs_dir / f"{safe}.pdf"
    if exact.exists():
        return exact
    hits = [p for p in pdfs_dir.glob(f"{safe}__*.pdf") if p.name.split("__")[0] == safe]
    return sorted(hits)[0] if hits else None


def is_worth_writing(old_rows: int, new_rows: int) -> bool:
    """新结果是否值得落盘。持平也算没收益——不写。

    为什么不能用 `<`：旧判据 `new_rows < old_rows` 只挡「变差」，228 件里
    39 件 1→1 被无条件覆盖。重解析的目的是补订货行，行数没增加的改写没有收益，
    却会用一次新的模型输出替换掉整个 doc（features/specs 全换），
    属「无收益改写」。解析失败由 `_one()` 单独负责恢复原文。
    """
    return new_rows > old_rows


def _drop_new_named(data_dir: Path, new: dict, mpn: str, old_name: str,
                    do_delete: bool) -> str:
    """处理 `pipeline.parse_pdf` 按新哈希另写的那份文件，返回其文件名。

    `parse_pdf` 写的是 `{mpn}_{新pdf_hash[:8]}.json`。若磁盘上的 PDF 与原始解析时
    不是同一份（被重下过），它会另起一个文件名，而我们随后又把内容写回了旧名文件
    ——于是同一个 MPN 出现两份 JSON：旧名那份是数据库 `item.json_path` 引用着的、
    且含 `_carry_over` 回带的字段；新名那份没人引用，也没回带字段。
    本轮 228 件里因此多出 5 组重复。

    默认只报告不删除（删文件要单独确认）；`do_delete` 为真时才删，
    且只删「名字≠旧名、确实存在」的那份，绝不碰旧名文件。
    """
    meta = new.get("metadata") or {}
    h = str(meta.get("pdf_hash") or "")
    if len(h) < 8:
        return ""
    new_name = f"{_safe(mpn)}_{h[:8]}.json"
    if new_name == old_name:
        return ""
    p = data_dir / new_name
    if not p.exists():
        return ""
    if do_delete:
        try:
            p.unlink()
        except OSError:
            return new_name
    return new_name


def _order_pages(pdf: Path) -> list[int]:
    """PDF 里第一处订货表的页码（1 基）；用与判定层同一套「标题后跟料号」判据。

    命中即停：这里只需要「有没有表、在哪一页」，不需要把所有表页都列出来。
    全量扫 13,511 件时逐页读完 284 页文档太慢，早停能把扫描量砍掉一大半。
    """
    try:
        import fitz
    except Exception:                                        # noqa: BLE001
        return []
    try:
        with fitz.open(str(pdf)) as doc:
            for i in range(doc.page_count):
                if BI.has_ordering_section(doc[i].get_text("text")):
                    return [i + 1]
    except Exception:                                        # noqa: BLE001
        return []
    return []


def _carry_over(old: dict, new: dict) -> list[str]:
    """把模型不负责的字段从旧 doc 带回来。返回实际保留的字段名。"""
    kept: list[str] = []
    obi = old.get("basic_info") or {}
    nbi = new.setdefault("basic_info", {})
    for k in KEEP_BASIC:
        v = obi.get(k)
        if v and not nbi.get(k):
            nbi[k] = v
            kept.append("basic_info." + k)
    opkg = (old.get("specs") or {}).get("package") or {}
    npkg = ((new.get("specs") or {}).get("package")) or {}
    for k in KEEP_PKG:
        v = opkg.get(k)
        if v and not npkg.get(k):
            npkg[k] = v
            kept.append("specs.package." + k)
    if kept:
        new.setdefault("specs", {})["package"] = npkg

    # 整块带回的顶层键。new 完全没有就整块复制；new 有一部分（如
    # ICPDF_LANGS 只开了 ja,ko）就按语种补齐，绝不因为新解析少写语言而丢旧语言。
    for k in KEEP_TOP:
        oldv, newv = old.get(k), new.get(k)
        if not oldv:
            continue
        if not newv:
            new[k] = copy.deepcopy(oldv)
            kept.append(k)
        elif isinstance(oldv, dict) and isinstance(newv, dict):
            added = [sub for sub in oldv if sub not in newv]
            for sub in added:
                newv[sub] = copy.deepcopy(oldv[sub])
            if added:
                kept.append("%s(%s)" % (k, ",".join(added)))
    return kept


def top_key_loss(old: dict, new: dict) -> list[str]:
    """新 doc 相对旧 doc 丢失的顶层键。只查「必须齐备」和「必须带回」两组，
    旧 doc 本来就没有的键不算丢失（不要求凭空补造）。"""
    must = REQUIRED_TOP + KEEP_TOP
    return [k for k in must if k in old and k not in new]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="重解析「有订货表却抽不到」的件")
    ap.add_argument("--data-dir", default=str(ROOT / "data" / "parsed"), dest="data_dir")
    ap.add_argument("--pdfs", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--apply", action="store_true", help="真的调模型重解析")
    ap.add_argument("--dry-run", action="store_true", dest="dry", help="只列名单")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--workers", type=int, default=4, help="并发重解析数")
    ap.add_argument("--mpn", action="append", default=[],
                    help="只处理指定料号（可重复），跳过全库扫描")
    ap.add_argument("--out", default="")
    ap.add_argument("--drop-orphan", action="store_true", dest="drop_orphan",
                    help="删除 parse_pdf 按新哈希另写的那份重复 JSON"
                         "（数据库引用的是旧名文件，默认只报告不删）")
    a = ap.parse_args(argv)
    if not a.apply:
        a.dry = True

    data_dir, pdfs_dir = Path(a.data_dir), Path(a.pdfs)
    files = sorted(data_dir.glob("*.json"))
    if not files:
        print("没有解析结果：%s" % data_dir)
        return 2
    print("扫描 %d 个解析结果…" % len(files), file=sys.stderr, flush=True)

    todo: list[dict] = []
    skipped = {"rows_ok": 0, "no_pdf": 0, "no_table": 0, "name_mismatch": 0}
    thin: list[tuple[Path, dict, str, Path]] = []
    for f in files:
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        mpn = str((doc.get("basic_info") or {}).get("mpn") or "")
        if not mpn:
            continue
        # 只挑身份定不下来的：行数够多的（含「1 行且精确命中」那批）不用动
        if len(BI.orderables(doc)) >= 2:
            skipped["rows_ok"] += 1
            continue
        if BI.classify(mpn, doc)["state"] != BI.INCOMPLETE:
            skipped["rows_ok"] += 1
            continue
        pdf = _pdf_for(pdfs_dir, mpn)
        if pdf is None:
            skipped["no_pdf"] += 1
            continue
        if not f.name.startswith(_safe(mpn) + "_"):
            # 文件名与料号对不上（如 DP83849IDVS-EVK 的 mpn 是 DP83849ID）：
            # 重解析会另写一份 json，造成重复条目，跳过
            skipped["name_mismatch"] += 1
            continue
        thin.append((f, doc, mpn, pdf))

    print("订货行 <2 且文件名对得上的：%d 件" % len(thin), file=sys.stderr, flush=True)

    if a.mpn:
        want = {m.strip().upper() for m in a.mpn}
        thin = [x for x in thin if x[2].upper() in want]
        print("按 --mpn 过滤后：%d 件" % len(thin), file=sys.stderr, flush=True)

    # PDF 逐页扫文本占大头：8 路并行 + 命中即停
    from concurrent.futures import ThreadPoolExecutor
    print("待扫 PDF：%d 份（8 路并行，命中即停）" % len(thin), file=sys.stderr, flush=True)
    done = [0]

    def _scan(item):
        r = _order_pages(item[3])
        done[0] += 1
        if done[0] % 50 == 0:
            print("  已扫 %d/%d" % (done[0], len(thin)), file=sys.stderr, flush=True)
        return r

    with ThreadPoolExecutor(max_workers=8) as pool:
        pages_list = list(pool.map(_scan, thin))
    for (f, doc, mpn, pdf), pages in zip(thin, pages_list):
        if not pages:
            skipped["no_table"] += 1
            continue
        todo.append({"file": f, "mpn": mpn, "pdf": pdf,
                     "old_rows": len(BI.orderables(doc)), "table_pages": pages})

    if a.limit:
        todo = todo[: a.limit]
    print("候选 %d 件（跳过：订货行已够 %d / 无 PDF %d / PDF 无订货表 %d / 文件名不符 %d）"
          % (len(todo), skipped["rows_ok"], skipped["no_pdf"],
             skipped["no_table"], skipped["name_mismatch"]))
    for t in todo[:40]:
        print("  %-26s 旧行数=%d 订货表页=%s  %s"
              % (t["mpn"], t["old_rows"], t["table_pages"][:5], t["file"].name))
    if len(todo) > 40:
        print("  ... 共 %d 件" % len(todo))
    if a.dry:
        print("\n（dry-run，未调模型。加 --apply 执行）")
        return 0

    from app.services import pipeline

    backup = Path(a.backup)
    backup.mkdir(parents=True, exist_ok=True)

    def _one(t: dict) -> dict:
        f, mpn = t["file"], t["mpn"]
        old_text = f.read_text(encoding="utf-8")
        old = json.loads(old_text)
        shutil.copy2(f, backup / f.name)          # 先备份，再动文件
        t0 = time.time()
        try:
            rec = pipeline.parse_pdf(t["pdf"], mpn)
        except Exception as e:                               # noqa: BLE001
            rec = {"status": "failed", "error": f"{type(e).__name__}: {e}"[:160]}
        dt = int((time.time() - t0) * 1000)
        row = {"mpn": mpn, "file": f.name, "status": rec.get("status"),
               "old_rows": t["old_rows"], "new_rows": 0, "orphan": "", "kept": "",
               "ms": dt, "error": (rec.get("error") or "")[:160]}
        new = rec.get("doc") or {}
        if rec.get("status") != "ok" or not new:
            # 失败也要把文件恢复成旧内容（parse_pdf 可能已写半截）
            f.write_text(old_text, encoding="utf-8")
            return row
        row["new_rows"] = len(BI.orderables(new))
        if not is_worth_writing(row["old_rows"], row["new_rows"]):
            # 持平或变差都回滚，不留半截结果
            row["status"] = "rolled_back"
            f.write_text(old_text, encoding="utf-8")
            _drop_new_named(data_dir, new, mpn, f.name, a.drop_orphan)
            return row
        row["kept"] = ",".join(_carry_over(old, new))
        lost = top_key_loss(old, new)
        if lost:
            # 带回来之后还缺顶层键，说明不是「模型没生成」而是结构性丢失。
            # 这种情况整件回滚：宁可保留旧 doc，也不留一份少字段的新 doc。
            row["status"] = "key_loss"
            row["error"] = "顶层键丢失 %s，已回滚" % ",".join(lost)
            f.write_text(old_text, encoding="utf-8")
            _drop_new_named(data_dir, new, mpn, f.name, a.drop_orphan)
            return row
        # parse_pdf 已经把新 doc 写到同一个文件名；带回来的字段再落一次
        (data_dir / f.name).write_text(
            json.dumps(new, ensure_ascii=False, indent=2), encoding="utf-8")
        row["orphan"] = _drop_new_named(data_dir, new, mpn, f.name, a.drop_orphan)
        return row

    rows: list[dict] = []
    ok_n = worse_n = fail_n = loss_n = 0
    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futs = {pool.submit(_one, t): t for t in todo}
        for n, fut in enumerate(as_completed(futs), 1):
            row = fut.result()
            rows.append(row)
            if row["status"] == "ok":
                ok_n += 1
                print("[%d/%d] %-24s 订货行 %d -> %d（%.1fs）%s"
                      % (n, len(todo), row["mpn"], row["old_rows"],
                         row["new_rows"], row["ms"] / 1000,
                         " 保留 " + row["kept"] if row["kept"] else ""), flush=True)
            elif row["status"] == "rolled_back":
                worse_n += 1
                print("[%d/%d] %-24s 变差 %d -> %d，已回滚"
                      % (n, len(todo), row["mpn"], row["old_rows"],
                         row["new_rows"]), flush=True)
            elif row["status"] == "key_loss":
                loss_n += 1
                print("[%d/%d] %-24s %s"
                      % (n, len(todo), row["mpn"], row["error"]), flush=True)
            else:
                fail_n += 1
                print("[%d/%d] %-24s 解析失败：%s"
                      % (n, len(todo), row["mpn"], row["error"]), flush=True)

    print("\n完成：改善 %d / 变差回滚 %d / 顶层键丢失回滚 %d / 失败 %d（共 %d）"
          % (ok_n, worse_n, loss_n, fail_n, len(todo)))
    after = {"still_thin": 0}
    for r in rows:
        if r["status"] == "ok" and r["new_rows"] < 2:
            after["still_thin"] += 1
    if after["still_thin"]:
        print("其中重解析后仍 <2 行的：%d 件（多为扫描件/表格是图片）" % after["still_thin"])

    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        import csv
        with out.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("明细已写 %s" % out)
    # 顶层键丢失不是「个别件不理想」，而是解析结构出了问题：整批判失败，
    # 让调用方（人或 cron）看得见，不要混在 0 里面。
    return 1 if loss_n else 0


if __name__ == "__main__":
    raise SystemExit(main())
