#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
质量工程核心服务（Gold Set / 风险分流 / 随机抽样 / 引擎对比 / 反馈夹具导出）。

约束（与 app/api/qc.py 同口径）：
  * 本模块会被工作台 server 进程 import —— 自包含、无模块级 stdout 包装副作用，
    不 import qc.table_audit / qc.qc_regression（它们会接管进程 stdout）；
  * Gold Set 是人工标准答案：机器只允许 seed 草稿与读比对，不允许改标准值；
  * 风险评分只用于排队，不替代字段级硬阻断（P0 由 kind 白名单决定）；
  * 随机审计抽样种子 + 总体快照必须留档可复现。

CLI（不依赖工作台，供 docker/终端链路复用）：
    python qc/goldset.py seed 74ACT16245DGGR            # 从 parsed JSON 生成 Gold 草稿
    python qc/goldset.py reg2gold 1                     # 回归记录 → Gold 草稿 + 风险核验任务
    python qc/goldset.py risk-sync                      # 从 qc_finding 同步风险队列
    python qc/goldset.py sample 30                      # 抽 30 件自动通过器件（打印清单）
    python qc/goldset.py compare                        # Gold(frozen) × 引擎目录对比
"""
from __future__ import annotations

import ast
import hashlib
import json
import random
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PARSED = ROOT / "data" / "parsed"
PDFS = ROOT / "data" / "pdfs"
QC_JSON = ROOT / "qc" / "json"          # qc 基线回退（与 table_audit 同口径）
QC_PDFS = ROOT / "qc" / "pdfs"
DATA = ROOT / "data"
DB_PATH = DATA / "workbench.sqlite3"
# 引擎对比产物目录（parse_datasheets --pdf-backend --out-dir 三引擎各一份）
ENGINE_DIRS = {
    "pymupdf": ["data/ab_odl/pymupdf", "data/parsed"],   # 无 A/B 产物时回退生产目录
    "opendataloader": ["data/ab_odl/odl"],
    "docstrange": ["data/ab_odl/docstrange"],
}
HASH_SUFFIX = re.compile(r"_[0-9a-f]{8}$")

# ---------------------------------------------------------------- 风险分级
# P0 硬阻断（技术安全风险：关键电气参数/引脚/封装/型号错误 → 阻断发布）
P0_KINDS = {"identity_unverified", "pin_mismatch", "package_mismatch",
            "unit_dimension", "mpn_conflict", "identity_family"}
# P1 高风险（关键资料缺失/归属歧义 → 补抽）
P1_KINDS = {"row_mispair", "range_collapse", "condition_leak", "qualifier_loss",
            "option_conflation", "direction_reversal"}
# 其余（footnote_missing / lint 类 / *_unresolved 未解决类）→ P2
SEVERITY = {  # kind → 严重度（0-10）：与客户影响面挂钩
    "pin_mismatch": 9, "unit_dimension": 9, "package_mismatch": 8,
    "mpn_conflict": 10, "identity_unverified": 7, "identity_family": 6,
    "row_mispair": 7, "range_collapse": 7, "condition_leak": 6,
    "qualifier_loss": 5, "option_conflation": 6, "direction_reversal": 7,
    "footnote_missing": 3,
}
FIELD_IMPACT = {  # 字段重要性（0-1）：乘进风险分
    "electrical": 1.0, "pin": 0.9, "package": 0.8, "mpn": 1.0,
    "category": 0.5, "default": 0.4,
}
UNCERTAINTY = {  # QC 不确定性（处置越保守越要人工看）
    "unresolved": 1.0, "badge": 0.7, "debt(render)": 0.4, "patched": 0.2, "": 0.5,
}


def safe_name(mpn: str) -> str:
    return re.sub(r"[/#\s]+", "_", (mpn or "").strip())


def nsym(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def to_num(s) -> float | None:
    m = re.search(r"[±+-]?\d+(?:[.,]\d+)?", str(s or ""))
    if not m:
        return None
    try:
        return float(m.group(0).replace(",", "").replace("±", "+"))
    except ValueError:
        return None


def u_norm(u: str) -> str:
    return (u or "").replace("uA", "µA").replace("uF", "µF").strip()


def now() -> str:
    import datetime
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _open() -> sqlite3.Connection:
    c = sqlite3.connect(str(DB_PATH), timeout=30)
    c.row_factory = sqlite3.Row
    return c


def q(sql: str, args=()) -> list[dict]:
    c = _open()
    try:
        return [dict(r) for r in c.execute(sql, tuple(args)).fetchall()]
    finally:
        c.close()


def q1(sql: str, args=()) -> dict | None:
    rows = q(sql, args)
    return rows[0] if rows else None


def x(sql: str, args=()) -> int:
    c = _open()
    try:
        cur = c.execute(sql, tuple(args))
        c.commit()
        return cur.lastrowid or cur.rowcount
    finally:
        c.close()


# ---------------------------------------------------------------- 产物定位
def locate(mpn: str) -> dict | None:
    """{json, pdf, requested}：data/ 主目录优先，回退 qc/ 基线（与 table_audit 同口径）。"""
    sn = safe_name(mpn)
    jp = None
    for base in (PARSED, QC_JSON):
        if not base.exists():
            continue
        cands = sorted(p for p in base.glob(f"{sn}*.json")
                       if not p.name.endswith((".alts.json", ".seo.json",
                                               ".pre_audit.json", ".pre_audit")))
        if cands:
            jp = cands[-1]
            break
    if not jp:
        return None
    pdf = None
    for base in (PDFS, QC_PDFS):
        if not base.exists():
            continue
        cands = sorted(base.glob(f"{sn}*.pdf"))
        if cands:
            pdf = cands[-1]
            break
    if not pdf:
        return None
    return {"json": jp, "pdf": pdf, "requested": HASH_SUFFIX.sub("", jp.stem)}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------- Gold Set
def seed_gold(mpn: str, operator: str = "cli", version: str = "v1",
              db_mod=None) -> dict:
    """从生产 parsed JSON 生成 Gold 草稿：机器只出草稿，标准答案必须人工核验后冻结。

    草稿字段 = mpn/manufacturer/category + package(type,pins) + 电气参数全量（值待核验）
    + 逐引脚名。pdf_sha256 登记时即计算（原厂 PDF 哈希与文档版本是证据链起点）。
    """
    dbm = db_mod
    loc = locate(mpn)
    if not loc:
        return {"error": f"未找到 {mpn} 的 parsed JSON/PDF（先跑解析）"}
    doc = json.loads(Path(loc["json"]).read_text(encoding="utf-8"))
    bi = doc.get("basic_info") or {}
    sha = sha256_file(loc["pdf"])
    meta = doc.get("metadata") or {}
    if meta.get("pdf_hash") and meta["pdf_hash"] != sha:
        # 解析后 PDF 被换过：哈希以当前登记文件为准，但要在 note 里留痕
        note = f"注意：PDF 与解析时哈希不一致（解析时 {meta['pdf_hash'][:12]}…）"
    else:
        note = ""
    ts = now()
    _x = dbm.x if dbm else x
    _q1 = dbm.q1 if dbm else q1
    old = _q1("SELECT id FROM gold_set WHERE version=? AND mpn=? LIMIT 1",
              (version, loc["requested"]))
    if old:                                   # 已登记：不覆盖，只刷 updated_at
        _x("UPDATE gold_set SET updated_at=? WHERE id=?", (ts, old["id"]))
        existed = _q1("SELECT id FROM gold_field WHERE gold_id=? LIMIT 1", (old["id"],))
        if existed:                           # 重复 seed 不覆盖人工核验结果
            return {"gold_id": old["id"], "mpn": loc["requested"], "reseed": True}
        gold_id = old["id"]
    else:
        gold_id = _x(
            "INSERT INTO gold_set(version,mpn,manufacturer,pdf_name,pdf_sha256,doc_rev,"
            "status,risk_tags,note,created_by,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (version, loc["requested"], bi.get("manufacturer", ""), loc["pdf"].name,
             sha, "", "draft", "", note, operator, ts, ts))
    fields: list[tuple] = []
    fields.append((gold_id, "basic_info.mpn", "mpn", bi.get("mpn", ""), "", "", 0, ""))
    fields.append((gold_id, "basic_info.manufacturer", "manufacturer",
                   bi.get("manufacturer", ""), "", "", 0, ""))
    fields.append((gold_id, "basic_info.category", "category",
                   bi.get("category", ""), "", "", 0, ""))
    pkg = (doc.get("specs") or {}).get("package") or {}
    fields.append((gold_id, "specs.package.type", "package.type",
                   pkg.get("type", ""), "", "", 0, ""))
    if pkg.get("pins"):
        fields.append((gold_id, "specs.package.pins", "package.pins",
                       str(pkg["pins"]), "", "", 0, ""))
    for i, e in enumerate((doc.get("specs") or {}).get("electrical") or []):
        fields.append((gold_id, f"electrical[{i}].value", e.get("name", ""),
                       str(e.get("value", "")), e.get("unit", ""), e.get("condition", ""), 0, ""))
    for pe in doc.get("pin_configuration") or []:
        fields.append((gold_id, f"pin[{pe.get('pin')}].name", "pin",
                       str(pe.get("name", "")), "", "", 0, ""))
    sql = ("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,cond,"
           "page_no,evidence) VALUES(?,?,?,?,?,?,?,?)")
    for row in fields:
        _x(sql, row)
    _x("INSERT INTO gold_review_log(gold_id,field_id,action,detail,operator,created_at) "
       "VALUES(?,0,'seed',?,'',?)",
       (gold_id, f"机器草稿：{len(fields)} 字段（PDF sha256={sha[:12]}…，待人工核验）", ts))
    return {"gold_id": gold_id, "mpn": loc["requested"], "fields": len(fields),
            "pdf_sha256": sha, "note": note}


def gold_stats() -> dict:
    rows = q("SELECT g.id, g.status, g.version, g.manufacturer,"
             " (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id) total,"
             " (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id"
             "  AND f.status='verified') verified,"
             " (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id"
             "  AND f.status='conflict') conflict"
             " FROM gold_set g ORDER BY g.id")
    return {
        "items": rows,
        "n": len(rows),
        "frozen": sum(1 for r in rows if r["status"] == "frozen"),
        "manufacturers": len({r["manufacturer"] for r in rows if r["manufacturer"]}),
        "fields_total": sum(r["total"] for r in rows),
        "fields_verified": sum(r["verified"] for r in rows),
        "fields_pending": sum(r["total"] - r["verified"] - r["conflict"] for r in rows),
        "sha_ok": q1("SELECT count(*) n FROM gold_set WHERE pdf_sha256<>''")["n"],
    }


# ---------------------------------------------------------------- 风险分流
def risk_priority(kind: str) -> str:
    if kind in P0_KINDS:
        return "P0"
    if kind in P1_KINDS:
        return "P1"
    return "P2"


def risk_score(kind: str, action: str = "", n_findings_same_mpn: int = 1) -> float:
    """严重度 × 字段重要性 × QC 不确定性 × 客户影响（同类发现累积 +10%/件）。

    非单一平均分：同件多种缺陷按各 kind 独立计分再排，累积惩罚只小幅放大，
    避免"一件十个 P2 盖过一个 P0"。
    """
    sev = SEVERITY.get(kind, 3)
    impact = FIELD_IMPACT.get("default", 0.4)
    if kind in ("pin_mismatch", "direction_reversal"):
        impact = FIELD_IMPACT["pin"]
    elif kind in ("unit_dimension", "row_mispair", "range_collapse",
                  "condition_leak", "qualifier_loss", "option_conflation"):
        impact = FIELD_IMPACT["electrical"]
    elif kind == "package_mismatch":
        impact = FIELD_IMPACT["package"]
    elif kind in ("mpn_conflict", "identity_unverified", "identity_family"):
        impact = FIELD_IMPACT["mpn"]
    unc = UNCERTAINTY.get(action, 0.5)
    cum = 1.0 + 0.1 * max(0, n_findings_same_mpn - 1)
    return round(sev * impact * unc * cum, 2)


def sync_risk_queue(operator: str = "cli", db_mod=None) -> dict:
    """从 qc_finding 最近一轮（每 mpn+kind 取最新一条）拉入风险队列。

    去重：同 mpn+kind 已有 open/confirming/to_regression 的 case 不重复建。
    closed/rejected 后同一 finding 再次出现会重新建 case（问题复现即重新排队）。
    """
    dbm = db_mod
    rows = q("SELECT f.id, f.mpn, f.kind, f.action, f.tool, f.created_at FROM qc_finding f "
             "WHERE f.id=(SELECT max(f2.id) FROM qc_finding f2 "
             "           WHERE f2.mpn=f.mpn AND f2.kind=f.kind) "
             "ORDER BY f.id DESC LIMIT 2000")
    added, skipped = 0, 0
    for r in rows:
        if r["tool"] == "qc_regression":
            continue                                  # 回归断言行不进风险队列
        dup = (dbm.q1 if dbm else q1)(
            "SELECT id FROM risk_case WHERE mpn=? AND kind=? "
            "AND status IN ('open','confirming','to_regression') LIMIT 1",
            (r["mpn"], r["kind"]))
        if dup:
            skipped += 1
            continue
        n_same = len([x for x in rows if x["mpn"] == r["mpn"]])
        pri = risk_priority(r["kind"])
        score = risk_score(r["kind"], r["action"], n_same)
        reason = _risk_reason(r["kind"], r["action"])
        ts = now()
        (dbm.x if dbm else x)(
            "INSERT INTO risk_case(mpn,kind,finding_id,priority,reason,score,status,"
            "operator,created_at,updated_at) VALUES(?,?,?,?,?,?, 'open',?,?,?)",
            (r["mpn"], r["kind"], r["id"], pri, reason, score, operator, ts, ts))
        added += 1
    return {"added": added, "skipped": skipped, "scanned": len(rows)}


def _risk_reason(kind: str, action: str) -> str:
    base = {
        "pin_mismatch": "引脚映射与原厂表冲突", "unit_dimension": "单位量纲可疑（mA/mW 类）",
        "package_mismatch": "封装与文档声明不符", "identity_unverified": "型号身份未验证",
        "identity_family": "型号按同族继承", "row_mispair": "跨列表格行列配对可疑",
        "range_collapse": "MIN/TYP/MAX 归属可能丢失", "condition_leak": "测试条件串行泄漏",
        "qualifier_loss": "脚注限定条件丢失", "option_conflation": "多型号选项混淆",
        "direction_reversal": "信号方向疑似反转", "footnote_missing": "脚注缺失",
    }.get(kind, kind)
    if action == "unresolved":
        return base + "（审计器定位失败，须人工判）"
    return base


# ---------------------------------------------------------------- 回归转核验
# GPT 评审：回归记录的四种信号不能都当真实错误，须转成人工核验任务——
# findings=检测到的潜在问题 / 缺发现=漏检信号（该报未报，最危险）
# / 断言败=断言未满足（数据错、断言错或前提错，须人工判）/ lint=交付质量问题。
# 断言类型 → 16 类 finding 命名映射（风险分流复用同一套 P0/P1/P2 分级）
ASSERT_KIND = {
    "pin_eq": "pin_mismatch", "package_contains": "package_mismatch",
    "entry_unit": "unit_dimension", "not_pair": "row_mispair",
    "value_not": "condition_leak", "condition_has": "condition_leak",
    "cols_roles_any2": "row_mispair", "bound_option": "option_conflation",
    "mpn_eq": "mpn_conflict", "verification": "identity_unverified",
}
_SIG_ANCHOR = re.compile(r"(findings|缺发现|断言败|lint)=")


def _parse_signals(text: str) -> dict:
    """qc_audit_log.regression 行的信号串 → 四类结构化。

    形如 `findings=['a'] 缺发现=['b'] 断言败=[['entry_unit', 24.0, 'mA']] lint=['x']`，
    `-` 表示该类为空；600 字截断保护下解析失败按空类处理，不 fatal。
    """
    out = {"findings": [], "missed": [], "asserts": [], "lint": []}
    if not text:
        return out
    starts, ends = {}, {}
    for m in _SIG_ANCHOR.finditer(text):
        starts[m.group(1)] = m.start()
        ends[m.group(1)] = m.end()
    order = [("findings", "findings"), ("缺发现", "missed"),
             ("断言败", "asserts"), ("lint", "lint")]
    for i, (key, field) in enumerate(order):
        if key not in ends:
            continue
        start = ends[key]                       # 本段值从 "=" 之后开始
        end = (starts[order[i + 1][0]]          # 到下一锚点开头（含其前空格，strip 掉）
               if i + 1 < len(order) and order[i + 1][0] in starts else len(text))
        seg = text[start:end].strip()
        if seg.rstrip(",") in ("-", "", "''"):
            continue
        try:
            val = ast.literal_eval(seg)
            if isinstance(val, list):
                out[field] = val
        except (ValueError, SyntaxError):
            continue                                  # 截断的半行：宁可漏读不误读
    return out


def seed_from_run(run_id: int, operator: str = "cli", version: str = "v1",
                  db_mod=None) -> dict:
    """回归运行记录 → 人工核验任务（工作台「转人工核验」入口的服务端）。

    每件动作：
      * seed_gold 建 Gold 草稿 = 核验任务本体（已存在则不覆盖人工结果）；
      * 四类信号保真写入 gold_review_log(action='import')，gold_set.risk_tags
        追加 `runN[:fail][:sigX]` 标记（append 式，不覆盖已有标记）；
      * 断言败（按 ASSERT_KIND 映射）与缺发现（原 kind）各建一条 risk_case
        ——这两种是"机器自己都拿不准"的信号，必须人工判；
      * findings 里的常规类不重复建 case（sync_risk_queue 已从 qc_finding 覆盖）。
    红线：不自动建反馈用例、不写 expected 真值——未经人工确认的 QC 信号
    不当标准答案（feedback_case 仍走风险 case「确认→转回归」的人工路径）。
    """
    dbm = db_mod
    rows = q("SELECT id, mpn, json_val, action FROM qc_audit_log "
             "WHERE run_id=? AND kind='regression' ORDER BY id", (run_id,))
    if not rows:
        return {"error": f"run#{run_id} 无 regression 逐件记录（先跑一轮回归）"}
    seeded, existed, risks, mpns, skipped = 0, 0, 0, [], 0
    for r in rows:
        sig = _parse_signals(r["json_val"])
        g = seed_gold(r["mpn"], operator, version, db_mod)
        if g.get("error"):
            skipped += 1
            continue
        mpns.append(r["mpn"])
        reseed = bool(g.get("reseed"))
        if reseed:
            existed += 1
        else:
            seeded += 1
        tag = f"run{run_id}" + (":fail" if r["action"] == "fail" else "")
        n_hard = len(sig["missed"]) + len(sig["asserts"])
        if n_hard:
            tag += f":sig{n_hard}"
        _xx = dbm.x if dbm else x
        _qq = dbm.q1 if dbm else q1
        _xx("UPDATE gold_set SET risk_tags=trim(risk_tags||','||?,','), updated_at=? "
            "WHERE id=?", (tag, now(), g["gold_id"]))
        detail = (f"run#{run_id} {r['action']} | findings={sig['findings']} "
                  f"缺发现={sig['missed']} 断言败={sig['asserts']} lint={sig['lint']}")
        _xx("INSERT INTO gold_review_log(gold_id,field_id,action,detail,operator,created_at) "
            "VALUES(?,0,'import',?,?,?)", (g["gold_id"], detail, operator, now()))
        pend = []
        for a in sig["asserts"]:
            k = ASSERT_KIND.get(str(a[0]) if a and a[0] else "", "row_mispair")
            pend.append((k, f"断言败 {a}（run#{run_id}，须人工判数据错/断言错/前提错）"))
        for k in sig["missed"]:
            pend.append((k, f"缺发现：审计器未报 {k}（run#{run_id}，漏检信号，最危险）"))
        for k, why in pend:
            if _qq("SELECT id FROM risk_case WHERE mpn=? AND kind=? "
                   "AND status IN ('open','confirming','to_regression') LIMIT 1",
                   (r["mpn"], k)):
                continue
            pri = risk_priority(k)
            score = risk_score(k, "unresolved" if r["action"] == "fail" else "badge",
                               len(sig["findings"]) or 1)
            ts = now()
            _xx("INSERT INTO risk_case(mpn,kind,finding_id,priority,reason,score,status,"
                "operator,created_at,updated_at) VALUES(?,?,?,?,?,?, 'open',?,?,?)",
                (r["mpn"], k, 0, pri, why, score, operator, ts, ts))
            risks += 1
    return {"run_id": run_id, "mpns": mpns, "gold_seeded": seeded,
            "gold_existed": existed, "risk_added": risks, "skipped": skipped}


# ---------------------------------------------------------------- 随机抽样
def _auto_pass_population(days: int = 30) -> list[dict]:
    """自动 QC 通过总体：已解析件 −（近 N 天有 finding 或有未处置风险 case 的件）。

    保守口径：从未跑过审计的件不算"自动通过"，不进抽样总体。
    """
    mpns = q("SELECT mpn FROM item WHERE last_parsed_at<>'' AND json_path<>''")
    audited = {r["mpn"] for r in q("SELECT DISTINCT mpn FROM qc_audit_log "
                                   "WHERE tool IN ('table_audit','lint')")}
    flagged = {r["mpn"] for r in q(
        f"SELECT DISTINCT mpn FROM qc_audit_log WHERE tool='table_audit' "
        f"AND created_at >= datetime('now','localtime','-{int(days)} day') "
        f"AND action IN ('unresolved','badge','missing')")}
    open_risk = {r["mpn"] for r in q(
        "SELECT DISTINCT mpn FROM risk_case WHERE status IN ('open','confirming')")}
    out = []
    for r in mpns:
        m = r["mpn"]
        if m in audited and m not in flagged and m not in open_risk:
            out.append({"mpn": m})
    return out


def stratified_sample(n: int, days: int = 30, method: str = "random",
                      seed: str = "") -> dict:
    """从自动通过总体抽样。种子与总体快照一并返回（调用方留档）。"""
    pop = _auto_pass_population(days)
    seed = seed or f"{now()}"
    rng = random.Random(seed)
    if method == "stratified_vendor":
        # 按制造商配额分层：各层按占比取整，余数给最大层
        mfr: dict[str, list[str]] = {}
        for r in pop:
            mfr.setdefault(r.get("manufacturer") or "?", []).append(r["mpn"])
        pick: list[str] = []
        total = sum(len(v) for v in mfr.values()) or 1
        for k, v in mfr.items():
            quota = round(n * len(v) / total)
            rng.shuffle(v)
            pick.extend(v[:quota])
        rng.shuffle(pick)
        pick = pick[:n]
    else:
        pool = [r["mpn"] for r in pop]
        pick = rng.sample(pool, min(n, len(pool))) if pool else []
    return {"pick": pick, "population_n": len(pop), "seed": seed,
            "snapshot": json.dumps([r["mpn"] for r in pop], ensure_ascii=False)}


# ---------------------------------------------------------------- 引擎对比
def _engine_docs(engine: str) -> dict[str, Path]:
    """{mpn: json 路径}：各引擎产物目录，同型号取最新；无目录=引擎未跑。"""
    out: dict[str, Path] = {}
    for rel in ENGINE_DIRS.get(engine, []):
        d = ROOT / rel
        if not d.exists():
            continue
        for p in sorted(d.glob("*.json")):
            if p.name.endswith((".alts.json", ".seo.json", ".pre_audit",
                                ".pre_audit.json")) or p.name.startswith("_"):
                continue
            out.setdefault(HASH_SUFFIX.sub("", p.stem), p)
    return out


def _load_doc(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:                                    # noqa: BLE001
        return {}


def _field_match(gf: dict, doc: dict) -> dict:
    """gold 字段 → 引擎产物匹配：captured（抽到）/correct（值+单位对）。

    电气参数按参数名（nsym 归一化子串）匹配；结构字段按路径直接定位。
    只做确定性比对，不猜。
    """
    path = gf["field_path"]
    name = gf["field_name"]
    exp_v, exp_u = gf["expected"], gf["unit"]
    if path.startswith("electrical["):
        for e in (doc.get("specs") or {}).get("electrical") or []:
            if name and nsym(name) and nsym(name) in nsym(e.get("name", "")):
                ok_v = _value_eq(e.get("value"), exp_v)
                ok_u = u_norm(e.get("unit", "")) == u_norm(exp_u)
                return {"captured": True, "correct": bool(ok_v and ok_u),
                        "value": e.get("value", ""), "unit": e.get("unit", ""),
                        "cond_kept": bool((e.get("condition") or "").strip())}
        return {"captured": False, "correct": False}
    if path == "basic_info.mpn":
        got = (doc.get("basic_info") or {}).get("mpn", "")
    elif path == "basic_info.manufacturer":
        got = (doc.get("basic_info") or {}).get("manufacturer", "")
    elif path == "basic_info.category":
        got = (doc.get("basic_info") or {}).get("category", "")
    elif path == "specs.package.type":
        got = ((doc.get("specs") or {}).get("package") or {}).get("type", "")
    elif path == "specs.package.pins":
        got = str(((doc.get("specs") or {}).get("package") or {}).get("pins") or "")
    elif path.startswith("pin["):
        m = re.match(r"pin\[(\d+)\]", path)
        if not m:
            return {"captured": False, "correct": False}
        n = int(m.group(1))
        for pe in doc.get("pin_configuration") or []:
            if pe.get("pin") == n:
                return {"captured": True, "correct": nsym(pe.get("name", "")) == nsym(exp_v)}
        return {"captured": False, "correct": False}
    else:
        return {"captured": False, "correct": False}
    return {"captured": True, "correct": nsym(got) == nsym(exp_v)}


def _value_eq(a, b) -> bool:
    na, nb = to_num(a), to_num(b)
    if na is not None and nb is not None:
        return abs(na - nb) < 1e-9
    return nsym(str(a or "")) == nsym(str(b or ""))


def compare_engines(version: str = "v1") -> dict:
    """Gold(frozen × verified 字段) × 引擎产物：完整度/字段准确率/证据覆盖/成本负担。

    成本口径说明：产物 JSON 未记录逐件耗时/token，成本维度当前用 QC 负担
    （row_mispair 等需人工复核的 findings 类）+ 抽取量表达；延迟/外部 API 成本
    需实验时单独记录（对比实验页有提示）。
    """
    golds = q("SELECT id, mpn FROM gold_set WHERE status='frozen' AND version=?", (version,))
    result = {"version": version, "n_gold": len(golds), "engines": {}}
    for engine in ENGINE_DIRS:
        docs = _engine_docs(engine)
        agg = {"docs": 0, "fields": 0, "captured": 0, "correct": 0,
               "evidence": 0, "rows": 0, "mpns": []}
        for g in golds:
            p = docs.get(safe_name(g["mpn"])) or docs.get(g["mpn"])
            if not p:
                continue
            doc = _load_doc(p)
            if not doc:
                continue
            agg["docs"] += 1
            agg["mpns"].append(g["mpn"])
            elec = (doc.get("specs") or {}).get("electrical") or []
            agg["rows"] += len(elec)
            agg["evidence"] += sum(1 for e in elec
                                   if (e.get("condition") or "").strip() or e.get("source"))
            for gf in q("SELECT field_path,field_name,expected,unit FROM gold_field "
                        "WHERE gold_id=? AND status='verified'", (g["id"],)):
                agg["fields"] += 1
                m = _field_match(gf, doc)
                agg["captured"] += 1 if m["captured"] else 0
                agg["correct"] += 1 if m["correct"] else 0
        n = agg["docs"] or 1
        agg["avg_rows"] = round(agg["rows"] / n, 1)
        agg["completeness"] = round(agg["captured"] / agg["fields"], 4) if agg["fields"] else None
        agg["accuracy"] = round(agg["correct"] / agg["captured"], 4) if agg["captured"] else None
        agg["evidence_cov"] = round(agg["evidence"] / agg["rows"], 4) if agg["rows"] else None
        agg["mpns"] = agg["mpns"][:12]
        result["engines"][engine] = agg
    result["at"] = now()
    return result


# ---------------------------------------------------------------- 反馈夹具
FIXTURE_PATH = DATA / "qc" / "regression_fixtures.json"


def export_fixture(case: dict, db_mod=None) -> dict:
    """反馈用例 → 回归夹具（qc/qc_regression.py --extra 消费）。

    断言自动生成口径（对齐 qc_regression.eval_assert）：
      electrical 字段 → entry_unit(值, 单位)；pin → pin_eq(脚号, 名)；package → package_contains
    """
    dbm = db_mod
    gold = q1("SELECT id FROM gold_set WHERE mpn=? AND status='frozen' "
              "ORDER BY id DESC LIMIT 1", (case["mpn"],))
    asserts: list[list] = []
    findings: list[str] = [case["kind"]] if case.get("kind") else []
    if gold:
        for gf in q("SELECT field_path,field_name,expected,unit FROM gold_field "
                    "WHERE gold_id=? AND status='verified'", (gold["id"],)):
            path, exp, unit = gf["field_path"], gf["expected"], gf["unit"]
            if path.startswith("electrical["):
                num = to_num(exp)
                if num is not None and unit:
                    asserts.append(["entry_unit", num, unit])
            elif path.startswith("pin["):
                m = re.match(r"pin\[(\d+)\]", path)
                if m:
                    asserts.append(["pin_eq", int(m.group(1)), exp])
            elif path == "specs.package.type" and exp:
                asserts.append(["package_contains", exp.split()[0]])
    fixture = {"mpn": case["mpn"], "code": case.get("code", ""),
               "findings": findings, "asserts": asserts,
               "source": case.get("source", "manual"), "exported_at": now()}
    data = []
    if FIXTURE_PATH.exists():
        try:
            data = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = []
    data = [d for d in data if not (d.get("mpn") == fixture["mpn"]
                                    and d.get("code") == fixture["code"])]
    data.append(fixture)
    FIXTURE_PATH.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    (dbm.x if dbm else x)(
        "INSERT INTO gold_review_log(gold_id,field_id,action,detail,operator,created_at) "
        "VALUES(0,0,'fixture_export',?,'',?)",
        (json.dumps({"mpn": case["mpn"], "code": case.get("code", ""),
                     "asserts": len(asserts)}, ensure_ascii=False), now()))
    return {"fixture": fixture, "path": str(FIXTURE_PATH), "asserts": len(asserts)}


# ---------------------------------------------------------------- CLI
def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 0
    cmd = sys.argv[1]
    if cmd == "seed":
        for mpn in sys.argv[2:]:
            print(json.dumps(seed_gold(mpn), ensure_ascii=False))
        return 0
    if cmd == "reg2gold":
        if len(sys.argv) < 3:
            print("用法：reg2gold <run_id>   # 回归记录 → Gold 草稿 + 风险核验任务")
            return 1
        print(json.dumps(seed_from_run(int(sys.argv[2])), ensure_ascii=False))
        return 0
    if cmd == "risk-sync":
        print(json.dumps(sync_risk_queue(), ensure_ascii=False))
        return 0
    if cmd == "sample":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 30
        r = stratified_sample(n)
        print(json.dumps({"pick": r["pick"], "population_n": r["population_n"]},
                         ensure_ascii=False))
        return 0
    if cmd == "compare":
        print(json.dumps(compare_engines(), ensure_ascii=False, indent=1))
        return 0
    print(f"未知命令：{cmd}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
