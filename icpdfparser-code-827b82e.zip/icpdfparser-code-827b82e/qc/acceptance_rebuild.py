#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""重生成验收交付物：从 `data/rebuilt` 原件走完整「后处理 → 身份剥离 → 渲染」。

为什么不能直接在 `data/acceptance_20261029/parsed` 上改
----------------------------------------------------------
验收目录里的 JSON 是**上一轮产物**（已回填 identity、已渲染），在它上面再跑
一次 `identity_scope` 只能验证幂等，无法验证「从原件到成品」这条链是否真的
修好了。所以本脚本从 `data/rebuilt/*.json` 重新走一遍：

    rebuilt JSON
      → postprocess_qwen（合并同键 + 区间规范化）
      → identity_scope（证据驱动剥离）
      → pin_repair（BGA 球号：有真值用真值，抽不出就丢）
      → json_to_txt / symbol_svg（重渲染）

产出目录默认 `data/acceptance_20261030`，不覆盖旧目录（旧的是客户反馈证据）。

用法：
  python qc/acceptance_rebuild.py
  python qc/acceptance_rebuild.py --out data/acceptance_20261030 --force
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import json_to_txt as J                                      # noqa: E402
import symbol_svg as S                                       # noqa: E402
from qc import identity_scope as IS                          # noqa: E402
from qc import pin_repair as PR                              # noqa: E402
from qc import postprocess_qwen as PQ                        # noqa: E402
from qc import table_audit as T                              # noqa: E402

MPNS = ["ADS8568EVM-PDK", "BOOST-DRV8711", "BOOSTXL-C2KLED",
        "ADC12DJ5200SE", "ADS1201U-1_1K"]


def _scan(pdf: Path):
    import pymupdf
    with pymupdf.open(str(pdf)) as d:
        return T.scan_tables(d)


def rebuild(src: Path, pdf: Path, out_json: Path) -> dict:
    doc = json.loads(src.read_text(encoding="utf-8"))
    tables = _scan(pdf)
    els = (doc.get("specs") or {}).get("electrical") or []
    refs = PQ.resolve_rowrefs(els, tables) if els else []
    kept, actions = PQ.merge_duplicate_rows(els, refs, tables)
    doc.setdefault("specs", {})["electrical"] = kept
    rng = PQ.normalize_ranges(kept) + PQ.normalize_ranges(
        (doc.get("specs") or {}).get("absolute_max") or [])
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")

    rep = IS.apply_file(out_json, pdf, dry_run=False)
    doc = json.loads(out_json.read_text(encoding="utf-8"))
    pin = PR.repair_bga_pins(doc, pdf)
    out_json.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"mpn": doc["basic_info"].get("mpn"), "pdf": pdf.name,
            "identity": rep["identity"], "state": rep["state"],
            "scope": (doc.get("specs") or {}).get("scope"),
            "electrical": len((doc.get("specs") or {}).get("electrical") or []),
            "onboard_specs": bool((doc.get("specs") or {}).get("onboard_device_specs")),
            "features": (doc.get("features") or [])[:1],
            "applications": doc.get("applications") or [],
            "pins": len(doc.get("pin_configuration") or []),
            "pin_action": pin["action"],
            "range_normalized": rng,
            "merged_rows": sum(1 for a in actions if a["action"] == "MERGED")}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="data/rebuilt")
    ap.add_argument("--pdf-dir", default="data/pdfs")
    ap.add_argument("--out", default="data/acceptance_20261030")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()

    src, out = Path(a.src), Path(a.out)
    pdf_dir = Path(a.pdf_dir)
    if out.exists():
        if not a.force:
            raise SystemExit(f"{out} 已存在；加 --force 覆盖（旧目录是客户反馈证据，默认不碰）")
        shutil.rmtree(out)
    for sub in ("parsed", "txt", "symbols"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    manifest = []
    for mpn in MPNS:
        s = src / f"{mpn}.json"
        if not s.exists():
            print(f"[跳过] {mpn}: 缺 {s}")
            continue
        pdf = IS.find_pdf(mpn, pdf_dir)
        if not pdf:
            print(f"[跳过] {mpn}: 缺 PDF")
            continue
        j = out / "parsed" / f"{mpn}.json"
        rec = rebuild(s, pdf, j)
        doc = json.loads(j.read_text(encoding="utf-8"))
        (out / "txt" / f"{mpn}.txt").write_text(J.render(doc, "en"), encoding="utf-8")
        (out / "symbols" / f"{mpn}.html").write_text(
            S.render_page(doc, pkg_dir=ROOT / "data" / "pkgs"), encoding="utf-8")
        manifest.append(rec)
        print(f"{mpn:<20} {str(rec['state']):<16} scope={str(rec['scope']):<15} "
              f"elec={rec['electrical']:<3} pins={rec['pins']:<4} {rec['pin_action']}")

    (out / "manifest.json").write_text(
        json.dumps({"generated": "2026-10-30", "records": manifest},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n{len(manifest)} 件 -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
