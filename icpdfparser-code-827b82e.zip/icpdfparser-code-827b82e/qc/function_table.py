"""74 系列标准功能表：校验 / 哈希 / 签核状态 / 功能判定（阶段 ① 的门禁实现）。

设计边界（对应 docs/qc/alts_validation_v1.md v1.2 §2.2）：
  * 本模块**只**回答「这个功能码在官方 datasheet 里的功能是什么」，不判电气/引脚/寿命；
  * **未签核**（或哈希不匹配、Owner==Reviewer、审计字段缺失）的版本，一律不得用于 P0 判定，
    一律返回 `NO_EVIDENCE`——自动阻断权限不随编辑扩大；
  * 判定只用表内**已证实的核心属性**（function / inputs / schmitt），
    字符位差异、前缀差异、缺表项、映射歧义都只能给 `NO_EVIDENCE`；
  * 「表可用」只表示这份证据表具备使用资格，**不**表示任意候选已经功能等价；
    候选等价仍须走五层证据卡（§3.2），本模块不提供 PASS。

CLI
---
    python qc/function_table.py validate        # 结构/枚举/重复/来源/哈希自检
    python qc/function_table.py hash            # 打印规范化 content_hash（不写盘）
    python qc/function_table.py show            # 打印各条目摘要与证据页码
    python qc/function_table.py review-packet   # 生成待复核包（不签核）
    python qc/function_table.py sign --reviewer <name> --at <ISO> --hash <sha256> --confirm
        # 只能由 Reviewer 本人执行；Owner 与 Reviewer 同名会被拒绝

字段契约见 `TABLE_SCHEMA` 与 docs/qc/alts_validation_v1.md。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DEFAULT_TABLE = Path(__file__).resolve().parent / "74_function_codes.json"

# 允许的枚举（新增值必须同时改这里与文档，否则校验失败）
FUNCTIONS = {
    "NAND", "AND", "NOR", "OR", "XOR", "XNOR", "INVERTER", "BUFFER",
    "BUFFER_3STATE", "OR_AND", "DECODER_2TO4", "LATCH_D", "FLIPFLOP_D",
    "MONOSTABLE", "ANALOG_SWITCH", "ANALOG_SWITCH_FET", "ANALOG_SWITCH_SPDT",
    "UNRESOLVED",
}
OUTPUT_TYPES = {"PUSH_PULL", "OPEN_DRAIN", "THREE_STATE", "ANALOG", "UNKNOWN"}
OE_POLARITY = {"HIGH", "LOW", "NONE", "UNKNOWN"}
ENTRY_STATUS = {"EVIDENCE_BACKED", "CONFLICT", "UNRESOLVED"}
TABLE_STATUS = {"PENDING_REVIEW", "SIGNED"}

# 参与 content_hash 的字段（不含签核字段：签核本身不能改变内容哈希）
HASH_FIELDS = ("version", "functions", "family_overrides", "unresolved", "sources")

REQUIRED_TOP = ("version", "status", "owner", "sources", "change_reason")
REQUIRED_ENTRY = ("function", "inputs", "schmitt", "output_type",
                  "oe_polarity", "family_scope", "status", "sources")
REQUIRED_SOURCE = ("mpn", "pdf_sha256", "page", "quote")


# ---------------------------------------------------------------- 载入 / 哈希
def load(path: Path | str = DEFAULT_TABLE) -> dict:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"功能表不存在：{p}")
    return json.loads(p.read_text(encoding="utf-8"))


def canonical_payload(table: dict) -> dict:
    """参与哈希的规范化内容：排序键 + 只保留 HASH_FIELDS。"""
    return {k: table.get(k) for k in HASH_FIELDS}


def content_hash(table: dict) -> str:
    raw = json.dumps(canonical_payload(table), ensure_ascii=False,
                     sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


# ---------------------------------------------------------------- 校验
def validate(table: dict, pdf_root: Path | None = None,
             check_pdf_sha: bool = False) -> list[str]:
    """返回问题列表（空 = 通过）。不修改任何字段，不写盘。"""
    issues: list[str] = []
    for k in REQUIRED_TOP:
        if not table.get(k):
            issues.append(f"缺少顶层必填字段：{k}")
    if table.get("status") not in TABLE_STATUS:
        issues.append(f"非法 status：{table.get('status')!r}")
    if str(table.get("owner") or "").strip() == "":
        issues.append("owner 为空")
    rb = table.get("reviewed_by")
    if table.get("status") == "SIGNED":
        if isinstance(rb, str) and rb.strip() == "":
            issues.append("SIGNED 但 reviewed_by 为空")
        if isinstance(rb, list) and not [x for x in rb if str(x).strip()]:
            issues.append("SIGNED 但 reviewed_by 为空")
        if not table.get("reviewed_at"):
            issues.append("SIGNED 但 reviewed_at 为空")
        if table.get("signed_via") == "agent-delegation" \
                and not str(table.get("authorization_note") or "").strip():
            issues.append("授权代理签核但缺 authorization_note（无法审计）")
        if str(rb).strip() == str(table.get("owner") or "").strip():
            issues.append("Owner 与 Reviewer 同名：签核无效")
        if not table.get("content_hash"):
            issues.append("SIGNED 但 content_hash 为空")
        elif table["content_hash"] != content_hash(table):
            issues.append("content_hash 与当前内容不匹配（内容已变，需重新复核）")

    funcs = table.get("functions")
    if not isinstance(funcs, dict) or not funcs:
        issues.append("functions 缺失或为空")
        funcs = {}
    seen = set()
    for code, e in funcs.items():
        if code in seen:
            issues.append(f"重复功能码：{code}")
        seen.add(code)
        if not str(code).isdigit():
            issues.append(f"功能码非数字：{code!r}")
        if not isinstance(e, dict):
            issues.append(f"{code}: 条目不是对象")
            continue
        for k in REQUIRED_ENTRY:
            if k not in e:
                issues.append(f"{code}: 缺字段 {k}")
        if e.get("function") not in FUNCTIONS:
            issues.append(f"{code}: 非法 function {e.get('function')!r}")
        if e.get("output_type") not in OUTPUT_TYPES:
            issues.append(f"{code}: 非法 output_type {e.get('output_type')!r}")
        if e.get("oe_polarity") not in OE_POLARITY:
            issues.append(f"{code}: 非法 oe_polarity {e.get('oe_polarity')!r}")
        if e.get("status") not in ENTRY_STATUS:
            issues.append(f"{code}: 非法 status {e.get('status')!r}")
        if not isinstance(e.get("family_scope"), list) or not e["family_scope"]:
            issues.append(f"{code}: family_scope 为空")
        if e.get("inputs") is not None and not isinstance(e["inputs"], int):
            issues.append(f"{code}: inputs 应为 int 或 null")
        if not isinstance(e.get("schmitt"), bool) and e.get("schmitt") != "UNKNOWN":
            issues.append(f"{code}: schmitt 应为 bool 或 'UNKNOWN'")
        srcs = e.get("sources")
        if not isinstance(srcs, list) or not srcs:
            issues.append(f"{code}: sources 为空（缺证条目不允许签核）")
            continue
        for s in srcs:
            for k in REQUIRED_SOURCE:
                if not s.get(k):
                    issues.append(f"{code}: source 缺 {k}")
            if check_pdf_sha and pdf_root:
                pp = Path(pdf_root) / str(s.get("pdf_name") or "")
                if s.get("pdf_name") and pp.is_file() \
                        and _sha256_file(pp) != s.get("pdf_sha256"):
                    issues.append(f"{code}: pdf_sha256 与文件不符（{s.get('pdf_name')}）")
        if e.get("status") == "CONFLICT" and not e.get("conflicts"):
            issues.append(f"{code}: status=CONFLICT 但未声明 conflicts")
        # 冲突条目不得带确定性的功能判据
        if e.get("status") == "CONFLICT" and e.get("function") != "UNRESOLVED" \
                and "function" in (e.get("conflicts") or []):
            issues.append(f"{code}: function 冲突却仍给了确定 function")
    # family_overrides 里不得与主表重复定义同一 code
    for key in (table.get("family_overrides") or {}):
        if ":" not in str(key):
            issues.append(f"family_overrides 键应为 'FAMILY:CODE'：{key!r}")
    for u in table.get("unresolved") or []:
        if not u.get("code") or not u.get("reason"):
            issues.append(f"unresolved 条目缺 code/reason：{u!r}")
    return issues


def is_usable_for_p0(table: dict) -> tuple[bool, str]:
    """能否用于 P0 判定。只有「已签核 + 哈希匹配 + 审计字段齐全 + 双人不同」才算。"""
    if table.get("status") != "SIGNED":
        return False, "table_not_signed"
    rb = table.get("reviewed_by")
    rb_name = rb[0] if isinstance(rb, list) and rb else rb
    if not str(rb_name or "").strip():
        return False, "reviewer_missing"
    if str(rb_name).strip() == str(table.get("owner") or "").strip():
        return False, "owner_equals_reviewer"
    if not table.get("reviewed_at"):
        return False, "reviewed_at_missing"
    if table.get("content_hash") != content_hash(table):
        return False, "content_hash_mismatch"
    if validate(table):
        return False, "table_invalid"
    return True, "ok"


# ---------------------------------------------------------------- 证据复核
_FUNCTION_KEYWORD = {
    "NAND": r"NAND", "AND": r"\bAND\b", "NOR": r"NOR", "OR": r"\bOR\b",
    "XOR": r"XOR|exclusive-OR", "XNOR": r"XNOR",
    "INVERTER": r"inverter", "BUFFER": r"buffer", "BUFFER_3STATE": r"buffer",
    "DECODER_2TO4": r"decoder", "LATCH_D": r"latch", "FLIPFLOP_D": r"flip-flop",
    "MONOSTABLE": r"multivibrator|monostable",
    "ANALOG_SWITCH": r"analog switch|switch", "ANALOG_SWITCH_FET": r"switch",
    "ANALOG_SWITCH_SPDT": r"switch", "OR_AND": r"OR-AND",
}


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def _page_text(pdf: Path, page: int) -> str:
    import fitz
    with fitz.open(str(pdf)) as doc:
        if page < 1 or page > doc.page_count:
            return ""
        return _norm(doc[page - 1].get_text())


def verify_evidence(table: dict, pdf_root: Path | str,
                    min_prefix: int = 60) -> list[dict]:
    """把每条证据回读到 PDF 原件：sha / 页码 / 原文引用 / 功能声明 四项核对。

    返回问题列表（每条 {"level": ERROR|WARN, "code", "issue", "detail"}）。
    ERROR 表示「证据与声明对不上」，签核前必须修；WARN 表示需出记录但不阻断。
    """
    root = Path(pdf_root)
    out: list[dict] = []

    def add(level, code, issue, detail=""):
        out.append({"level": level, "code": code, "issue": issue, "detail": detail})

    targets = [(c, e.get("sources") or [], e) for c, e in
               (table.get("functions") or {}).items()]
    for key, ov in (table.get("family_overrides") or {}).items():
        targets.append((key, ov.get("sources") or [], ov))

    for code, srcs, entry in targets:
        if not srcs:
            add("ERROR", code, "no_sources")
            continue
        for s in srcs:
            name = s.get("pdf_name") or ""
            pdf = root / name
            if not name or not pdf.is_file():
                add("ERROR", code, "pdf_missing", name)
                continue
            if s.get("pdf_sha256") != _sha256_file(pdf):
                add("ERROR", code, "sha_mismatch", name)
            page = int(s.get("page") or 0)
            text = _page_text(pdf, page)
            if not text:
                add("ERROR", code, "page_out_of_range", f"{name} p.{page}")
                continue
            q = _norm(s.get("quote") or "")
            probe = q[:min_prefix]
            if not probe or probe not in text:
                add("ERROR", code, "quote_not_verbatim", f"{name} p.{page} :: {q[:80]}")
            kw = _FUNCTION_KEYWORD.get(str(entry.get("function") or ""))
            if kw and not re.search(kw, q, re.I):
                add("ERROR", code, "quote_missing_function_word",
                    f"{entry.get('function')} :: {q[:90]}")
            if entry.get("inputs") is not None:
                n = entry["inputs"]
                if n == 1:
                    # 单门器件官方标题多写 "Single … Gate"，不写 "1-input"
                    ok = re.search(r"\bsingle\b|1\s*-\s*input|1\s+input", q, re.I)
                elif entry.get("function") == "DECODER_2TO4":
                    ok = re.search(r"2\s*-\s*to\s*-\s*4|2-to-4", q, re.I)
                else:
                    ok = re.search(rf"{n}\s*-\s*input", q, re.I)
                if not ok:
                    add("WARN", code, "inputs_word_not_in_quote",
                        f"inputs={n} :: {q[:90]}")
            if entry.get("schmitt") is True and not re.search(r"schmitt", q, re.I):
                add("ERROR", code, "schmitt_claimed_but_not_quoted", q[:90])
            if entry.get("schmitt") is False and re.search(r"schmitt", q, re.I):
                add("WARN", code, "schmitt_flag_false_but_quote_mentions",
                    q[:90])
    return out


def verify_evidence_summary(issues: list[dict]) -> dict:
    return {"total": len(issues),
            "error": sum(1 for i in issues if i["level"] == "ERROR"),
            "warn": sum(1 for i in issues if i["level"] == "WARN")}


# ---------------------------------------------------------------- 判定
def lookup(table: dict, code: str, family: str = "") -> dict:
    """按功能码（可带 family）查表；返回 {kind, entry?, reason?}。"""
    code = str(code or "").strip()
    fam = str(family or "").strip().upper()
    overrides = table.get("family_overrides") or {}
    if fam:
        ov = overrides.get(f"{fam}:{code}")
        if isinstance(ov, dict):
            return {"kind": "ENTRY", "entry": ov, "scope": f"{fam}:{code}"}
    e = (table.get("functions") or {}).get(code)
    if not isinstance(e, dict):
        return {"kind": "NO_EVIDENCE", "reason": "code_not_in_table"}
    scope = [str(x).upper() for x in (e.get("family_scope") or [])]
    if fam and scope and fam not in scope:
        return {"kind": "NO_EVIDENCE", "reason": f"family_not_in_scope({fam}∉{scope})"}
    if e.get("status") == "CONFLICT":
        return {"kind": "NO_EVIDENCE", "reason": "mapping_conflict",
                "conflicts": e.get("conflicts") or []}
    if e.get("status") == "UNRESOLVED":
        return {"kind": "NO_EVIDENCE", "reason": "unresolved"}
    return {"kind": "ENTRY", "entry": e, "scope": code}


def judge(table: dict, target: str, candidate: str, *,
          target_family: str = "", candidate_family: str = "",
          char_only_diff: bool = False) -> dict:
    """功能等价判定（只返回 INCOMPATIBLE / NO_EVIDENCE / NO_CONFLICT_EVIDENCE）。

    永远不返回 PASS：功能码一致只说明「没有证据表明冲突」，
    是否可替换仍须五层证据卡（§3.2）。
    """
    usable, why = is_usable_for_p0(table)
    out = {"target": target, "candidate": candidate,
           "table_version": table.get("version"),
           "content_hash": table.get("content_hash"),
           "verdict": "NO_EVIDENCE", "reasons": [], "evidence": None}
    if not usable:
        out["reasons"].append(f"table_unusable:{why}")
        return out
    if char_only_diff:
        out["reasons"].append("char_only_diff")
        return out
    t = lookup(table, target, target_family)
    c = lookup(table, candidate, candidate_family)
    for tag, r in (("target", t), ("candidate", c)):
        if r["kind"] != "ENTRY":
            out["reasons"].append(f"{tag}:{r['reason']}")
            return out
    te, ce = t["entry"], c["entry"]
    checks = {
        "function": (te.get("function"), ce.get("function")),
        "inputs": (te.get("inputs"), ce.get("inputs")),
        "schmitt": (te.get("schmitt"), ce.get("schmitt")),
    }
    conflicts = []
    for field, (a, b) in checks.items():
        if a is None or b is None or a == "UNKNOWN" or b == "UNKNOWN":
            continue            # 任一方缺证据：不判冲突（避免把「不知道」当「错」）
        if a != b:
            conflicts.append({"field": field, "target": a, "candidate": b})
    out["evidence"] = {"target_entry": t["scope"], "candidate_entry": c["scope"],
                       "compared": list(checks)}
    if conflicts:
        out["verdict"] = "INCOMPATIBLE"
        out["reasons"] = [f"{x['field']}:{x['target']}≠{x['candidate']}" for x in conflicts]
    else:
        out["verdict"] = "NO_CONFLICT_EVIDENCE"
        out["reasons"].append("core_attributes_equal; layers §3.2 still required")
    return out


# ---------------------------------------------------------------- 签核（须 Reviewer 本人执行）
def sign(path: Path | str, reviewer: str, reviewed_at: str, expected_hash: str,
         allow_non_iso: bool = False, delegation: str = "") -> dict:
    p = Path(path)
    table = load(p)
    if str(reviewer).strip() == str(table.get("owner") or "").strip():
        raise SystemExit("拒绝签核：Owner 与 Reviewer 不能是同一人")
    if not str(reviewer).strip():
        raise SystemExit("拒绝签核：reviewer 为空")
    issues = validate(table)
    if issues:
        raise SystemExit("拒绝签核：功能表校验未通过\n- " + "\n- ".join(issues))
    actual = content_hash(table)
    if expected_hash != actual:
        raise SystemExit(f"拒绝签核：哈希不匹配（传入 {expected_hash}，当前 {actual}）")
    table["status"] = "SIGNED"
    table["reviewed_by"] = reviewer
    table["reviewed_at"] = reviewed_at
    table["content_hash"] = actual
    if delegation:
        table["signed_via"] = "agent-delegation"
        table["authorization_note"] = delegation
    p.write_text(json.dumps(table, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"status": table["status"], "reviewed_by": reviewer,
            "reviewed_at": reviewed_at, "content_hash": actual,
            "signed_via": table.get("signed_via", "reviewer-in-person")}


# ---------------------------------------------------------------- CLI
def _packet(table: dict) -> str:
    lines = ["# 74 功能表 · 待复核包（阶段 ①）", "",
             f"- 版本：`{table.get('version')}`",
             f"- 状态：`{table.get('status')}`",
             f"- Owner：`{table.get('owner')}`",
             f"- Reviewer：{table.get('reviewed_by') or '（未签核）'}",
             f"- 内容哈希：`{content_hash(table)}`",
             f"- 变更原因：{table.get('change_reason')}",
             f"- 来源：{table.get('sources')}", "",
             "> 签核必须绑定上面这个 `content_hash`；任何内容变化都会让它失效，需重新复核。", "",
             "## 条目", "", "| 功能码 | 功能 | 输入 | Schmitt | 输出 | OE | 族范围 | 状态 |",
             "|---|---|---|---|---|---|---|---|"]
    for code in sorted(table.get("functions") or {}, key=lambda c: int(c)):
        e = table["functions"][code]
        lines.append("| `%s` | %s | %s | %s | %s | %s | %s | %s |" % (
            code, e.get("function"), e.get("inputs") if e.get("inputs") is not None else "—",
            e.get("schmitt"), e.get("output_type"), e.get("oe_polarity"),
            "/".join(e.get("family_scope") or []), e.get("status")))
    lines += ["", "## 证据（每条的 PDF 页与原文）", ""]
    for code in sorted(table.get("functions") or {}, key=lambda c: int(c)):
        e = table["functions"][code]
        lines.append(f"### `{code}` — {e.get('function')} "
                     f"（{e.get('status')}）")
        for s in e.get("sources") or []:
            lines.append(f"- `{s.get('mpn')}` · p.{s.get('page')} · "
                         f"sha `{str(s.get('pdf_sha256'))[:16]}`")
            lines.append(f"  - 「{str(s.get('quote'))[:200]}」")
        if e.get("conflicts"):
            lines.append(f"- **冲突项**：{e['conflicts']}（已降级为不可用于 P0）")
        lines.append("")
    lines += ["## 未解决（缺证据，不得用于 P0）", ""]
    for u in table.get("unresolved") or []:
        lines.append(f"- `{u.get('code')}`：{u.get('reason')}")
    lines += ["", "## 复核要点（Reviewer）", "",
              "1. 每条功能码的 `function / inputs / schmitt` 是否与所引 PDF 页原文一致；",
              "2. 标 `CONFLICT` 的条目是否确实存在证据冲突（不得把「不知道」写成冲突）；",
              "3. `family_scope` 是否覆盖了该码在逻辑族中的适用家族（CBT/CBTD 等开关族见 overrides）；",
              "4. `unresolved` 条目是否确无可靠来源；",
              "5. 签核前重算 `content_hash`，并与本文件顶部一致。", ""]
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="74 功能表校验/签核")
    ap.add_argument("cmd", choices=["validate", "hash", "show", "review-packet",
                                    "sign", "verify-evidence"])
    ap.add_argument("--table", default=str(DEFAULT_TABLE))
    ap.add_argument("--pdf-root", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--out", default=str(ROOT / "docs" / "qc"
                                       / "74_function_table_review_packet.md"))
    ap.add_argument("--reviewer", default="")
    ap.add_argument("--at", default="", help="ISO 时间；传 now 自动取当前本地时间")
    ap.add_argument("--hash", default="")
    ap.add_argument("--confirm", action="store_true")
    ap.add_argument("--delegation", default="",
                    help="授权代理签核的说明（写入 authorization_note，供审计）")
    a = ap.parse_args(argv)
    if a.at.strip().lower() == "now":
        a.at = datetime.now().astimezone().isoformat(timespec="seconds")
    table = load(a.table)

    if a.cmd == "verify-evidence":
        issues = verify_evidence(table, Path(a.pdf_root))
        s = verify_evidence_summary(issues)
        print(f"evidence: total={s['total']} error={s['error']} warn={s['warn']}")
        for i in issues:
            print(f"  [{i['level']}] {i['code']} {i['issue']} :: {i['detail'][:110]}")
        return 0 if s["error"] == 0 else 1

    if a.cmd == "validate":
        issues = validate(table)
        print(f"version={table.get('version')} status={table.get('status')} "
              f"hash={content_hash(table)}")
        if issues:
            print("FAIL:")
            for i in issues:
                print("  -", i)
            return 1
        print("OK: 校验通过（注意：通过不代表已签核）")
        return 0
    if a.cmd == "hash":
        print(content_hash(table))
        return 0
    if a.cmd == "show":
        usable, why = is_usable_for_p0(table)
        print(f"status={table.get('status')} usable_for_p0={usable} ({why})")
        for code in sorted(table.get("functions") or {}, key=lambda c: int(c)):
            e = table["functions"][code]
            print("%-5s %-22s inputs=%-4s schmitt=%-8s %-14s %s" % (
                code, e.get("function"), e.get("inputs"), e.get("schmitt"),
                e.get("status"), "/".join(e.get("family_scope") or [])))
        return 0
    if a.cmd == "review-packet":
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(_packet(table), encoding="utf-8")
        print("written", a.out, "hash=", content_hash(table))
        return 0
    # sign
    if not a.confirm:
        print("拒绝：sign 需要 --confirm，且只能由 Reviewer 本人在复核后执行")
        return 2
    if not a.reviewer or not a.at or not a.hash:
        print("拒绝：需要 --reviewer --at --hash（hash 取自 review-packet 顶部）")
        return 2
    out = sign(a.table, a.reviewer, a.at, a.hash)
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
