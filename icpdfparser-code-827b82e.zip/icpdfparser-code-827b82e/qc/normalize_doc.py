#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""落盘后还能做的**确定性**归一 —— 不重跑模型，只重跑代码。

为什么单独一层
--------------
`postprocess_qwen` 的整套 `process()` 需要 PDF 表格与 rowrefs，只在
`acceptance_rebuild` 里跑。于是 V4 出了个怪现象：**同一份 JSON，走了
`parse_datasheets` 就没归位，走了 `acceptance_rebuild` 才归位**。V4 的
`Peak RF Input Power` 留在电气表、温度掉了 `°C`，都是因为 1101 之前
`parse_datasheets` 这条路径根本不调后处理。

这一层只收「有就改、没有就跳过」的确定性动作，全部可重放：

1. `fill_temperature` —— 从 PDF 的 ROC 表补工作温度（带 `°C`）。
   V4 的 `-40 to 85` 是模型漏了单位，页面就写成「没有量纲的温度」。
2. `normalize_temperature` —— 从绝对最大表补 storage，对齐两条记录。
3. `demote_stress_rows` —— 应力额定值（`Peak RF Input Power`）从电气表归位到
   绝对最大表。判据是「名字主干 + 值 + 单位」三条全中，只看名字会误杀
   `Supply Voltage (VA19)`（ROC 与 AbsMax 同名不同值）。
4. `normalize_ranges` —— 区间分隔符统一（`0.3~0.55` → `0.3 to 0.55`）。
5. `stamp_model_unverified` —— 给模型抽的行补核验状态，页面 † 才能亮。

顺序有依赖：先补温度（要读电气表），再归位（会删电气行），再规范区间
（改的是留下的行），最后盖章（要覆盖归位后剩下的全部行）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                     # noqa: E402
from qc import board_scope as BS                               # noqa: E402
from qc import ac_quarantine as ACQ                            # noqa: E402
from qc import postprocess_qwen as PQ                          # noqa: E402
from qc import range_guard as RG                               # noqa: E402
from qc import source_url as SU                                # noqa: E402
from qc import taxonomy as TX                                  # noqa: E402

#: 板卡身份。板卡件的 `datasheet_url` 被 `identity_scope` 主动清空并搬到
#: `device_datasheet_url`（那份 PDF 讲的是板上器件，不是这块板），这里**不回填** ——
#: 页面侧 `json_to_txt._source_pdf_url()` 会兜底取 `device_datasheet_url`，
#: 既保住链接，又不把板级主体说成芯片主体。
_BOARD_IDENTITIES = ("evaluation_board", "reference_design", "module", "board")


def _fill_url(doc: dict, pdf_path: Path | str, url_map: dict[str, str] | None,
              text: str | None = None) -> dict:
    """补 `datasheet_url`（只对非板卡件）。`text` 可由调用方传入，避免重复开文件。"""
    bi = doc.get("basic_info") or {}
    if str(bi.get("identity") or "") in _BOARD_IDENTITIES:
        return {"action": "skipped_board",
                "device_datasheet_url": bi.get("device_datasheet_url", "")}
    if not url_map:
        return {"action": "skipped_no_manifest"}
    if text is None:
        try:
            import pymupdf                                     # noqa: PLC0415
            with pymupdf.open(str(pdf_path)) as fd:
                # 文档号在每页页脚，前 8 页足够；不扫全篇（§14.1 不整份扫）
                text = "\n".join(fd[i].get_text() for i in range(min(fd.page_count, 8)))
        except Exception as e:                                 # noqa: BLE001
            return {"action": "error", "error": f"{type(e).__name__}: {e}"[:160]}
    return SU.fill(doc, Path(str(pdf_path)).name, url_map, text)


def _step(acts: dict, name: str, fn, *a, **kw):
    """跑一个确定性步骤，**失败只影响自己**。

    为什么必须隔离：V4 里 `fill_row_sources()` 抛了一个 `NameError`，
    而整段 PDF 步骤共用一个 try —— 一个拼写错误把后面的 `input_ranges`
    与 `absolute_max_roles` 全部跳过了，`metadata.normalize` 里只留一句
    `pdf_extract_error`。结果是 ADS1201 的输入范围在 V4 里从未被重切，
    `facts_audit` 里 0 verified，看起来像"表格太乱"，其实是异常被吞掉。
    步骤之间没有依赖的地方就该各管各的。
    """
    try:
        got = fn(*a, **kw)
    except Exception as e:                                     # noqa: BLE001
        acts[f"{name}_error"] = f"{type(e).__name__}: {e}"[:200]
        return None
    if got:
        acts[name] = got
    return got


def _ac_evidence(doc: dict, pdf_path: Path | str | None) -> dict | None:
    """给 AC 隔离层提供事实表证据（只对「有逃逸 AC 行」的文档）。

    隔离发生在 `fact_acceptance` 之前，但 THD 的行指纹 / SNR 的段落指纹
    本来就能从 PDF 重算。不先算一遍就会把正确数据误扣（元宝终审 1102-V3）。
    只对确实存在「AC 逃逸 + 无行内溯源」的文档跑，避免给每件都加一次审计。
    """
    if not pdf_path:
        return None
    try:
        if not ACQ.needs_evidence(doc):
            return None
        from qc import fact_acceptance as FA                  # noqa: PLC0415
        mpn = str((doc.get("basic_info") or {}).get("mpn") or "")
        rep = FA.audit_one(mpn, doc, Path(str(pdf_path)))
        return {(str(r.get("label") or ""), str(r.get("cond") or "")): r
                for r in (rep.get("rows") or [])}
    except Exception:                                          # noqa: BLE001
        return None


def _apply_ac_evidence(doc: dict, evidence: dict | None) -> int:
    """把事实表已重放的坐标证据写回保留下来的 AC 行（THD / SNR）。

    隔离层用这份证据避免误杀；写回 JSON 后，事实表再跑时 `param_kind()`
    也能读到真实载体：THD 是表格行（`audited_row_anchored`），SNR 的来源是
    第 1 页汇总段落（`audited_paragraph` → prose，段落指纹达标）。不写回，
    SNR 会被当成表格行、明明有段落指纹却卡在 row_anchor 门槛。
    """
    if not evidence:
        return 0
    specs = doc.get("specs") if isinstance(doc, dict) else None
    if not isinstance(specs, dict):
        return 0
    n = 0
    for _source, container in ACQ._electrical_containers(
            specs, board=ACQ._is_board(doc)):
        for row in container.get("electrical") or []:
            if not isinstance(row, dict) or ACQ.has_independent_provenance(row):
                continue
            ev = evidence.get(ACQ._fact_key(row)) or {}
            if not ACQ._evidence_has_coords(ev):
                continue
            verdict = str(ev.get("verdict") or "")
            src = row.setdefault("source", {})
            src["page"] = int(ev.get("page") or 0)
            _bb = ev.get("bbox")
            if isinstance(_bb, str):
                try:
                    _bb = json.loads(_bb)
                except ValueError:
                    _bb = []
            src["bbox"] = [round(float(v), 1) for v in _bb or []]
            if ev.get("row_sha256"):
                src["row_sha256"] = str(ev["row_sha256"])
            if ev.get("paragraph_sha256"):
                src["paragraph_sha256"] = str(ev["paragraph_sha256"])
            ver = row.setdefault("verification", {})
            ver["status"] = ("audited_row_anchored" if verdict == "verified_row"
                             else "audited_paragraph")
            ver["method"] = "facts_replay"
            ver["page"] = src["page"]
            ver["bbox"] = src["bbox"]
            n += 1
    return n


def normalize(doc: dict, pdf_path: Path | str | None = None,
              url_map: dict[str, str] | None = None) -> dict:
    """就地归一，返回动作摘要（写进 `metadata.normalize` 备查）。"""
    acts: dict = {}

    if pdf_path:
        # 0) BGA 球位：重建带完整溯源的映射。
        #    符号页的 `bga_pin_validation()` 按 fail-closed 判据要 `bbox` /
        #    `subject_mpn` / `package_ball_count` / `mapping_sha256`，确定性抽取
        #    给不出这些（它只数球号），页面就退化成「BGA 球位待核」占位页
        #    —— V4 实测 59,789 B → 1,294 B（Reviewer 新-2）。
        #    `repair_bga_pins` 是纯代码、逐球带 bbox，跑一次约 11 秒。
        try:
            from qc import pin_repair as PR                    # noqa: PLC0415
            rep = PR.repair_bga_pins(doc, pdf_path)
            if rep.get("action") != "not_bga":
                acts["pin_repair"] = {k: rep.get(k) for k in
                                      ("action", "status", "pins", "reasons")}
        except Exception as e:                                 # noqa: BLE001
            acts["pin_repair_error"] = f"{type(e).__name__}: {e}"[:200]

        # 1) 溯源链：页面要能一键回到权威源（Reviewer V4 新-1）
        #    温度 / 修订号 / AC 指标都要读同一份 PDF —— **只开一次**。
        try:
            import pymupdf                                     # noqa: PLC0415
            with pymupdf.open(str(pdf_path)) as fd:
                head = "\n".join(fd[i].get_text()
                                 for i in range(min(fd.page_count, 8)))
                acts["datasheet_url"] = _fill_url(doc, pdf_path, url_map, head)
                # 文档类型：板卡挂的是 User's Guide 时，页面不能再称它 datasheet
                # （Reviewer P1：BOOSTXL-C2KLED 的源文件是 SPRUHH9 用户指南）。
                _step(acts, "doc_type", SU.fill_doc_type, doc,
                      Path(str(pdf_path)).name)
                # 2) 温度 + 修订号（Reviewer P1：页面要显示 Rev. C / SLVSGH5C）
                _step(acts, "temperature", DE.fill_temperature, doc, fd)
                _step(acts, "doc_revision", DE.fill_doc_revision, doc, fd)
                # 3) AC 指标（Reviewer P1：ADC 的 SNR/SFDR/NSD/IMD3 此前 0 行）
                _step(acts, "ac_performance", DE.fill_ac_performance, doc, fd)
                # 3b) AC 数值格污染（V11 P0-1）：`max="dB"` 这类单位/脚注占了
                #     数值格的行，从正式容器搬进 `specs.unresolved_ac_rows`。
                #     必须在 row_anchors 之前跑：锚定候选里不该混进脏行。
                _ac_ev = _ac_evidence(doc, pdf_path)
                if _ac_ev:
                    acts["ac_evidence"] = len(_ac_ev)
                _step(acts, "ac_quarantine", ACQ.quarantine, doc,
                      evidence=_ac_ev)
                if _ac_ev:
                    _step(acts, "ac_evidence_applied",
                          _apply_ac_evidence, doc, _ac_ev)
                # 4) 电气行逐行溯源（Reviewer V7 第 2 条）：只补「参数名与数值
                #    同页」的，作为后面行级锚定的**兜底**页码。
                _step(acts, "row_sources", DE.fill_row_sources, doc, fd)
                # 5) 输入范围的列角色（Reviewer 7.5 分 P0-2）：ADS1201 的
                #    `0 to +5 V` 与 `With VBIAS(1)` 是两行，同页匹配会把条件错配。
                _step(acts, "input_ranges", DE.fill_input_ranges, doc, fd)
                # 6) 绝对最大额定值的列角色（Reviewer 7.5 分 P0-3 / 元宝 V9 任务二）：
                #    15 条 amax 的 range 原本是 `derived_from_value`（从
                #    `-0.3 to 2.35` 字符串里切的），"哪一列是 MIN"从未被证明。
                _step(acts, "absolute_max_roles", DE.fill_absolute_max, doc, fd)
                # 7) 电气行的**行级锚定**（ChatGPT 8.0 复审 P0-2）：
                #    92/108 行此前只到「同页」，而同页在 180 页手册里几乎是必然的，
                #    证明不了归属。能锚到具体表格行的升 `audited_row_anchored`
                #    （带 bbox + row_sha256）；锚不到但同页共现的降
                #    `label_value_same_page`，页面打 † 并说明"行/列对应待人工确认"。
                #    必须排在 input_ranges / absolute_max 之后：那两步写入的
                #    `audited_*` 行不再参与锚定，否则强证据会被弱证据覆盖。
                _step(acts, "row_anchors", DE.fill_row_anchors, doc, fd,
                      extra=doc.get("specs", {}).get("ac_performance") or [])
        except Exception as e:                                 # noqa: BLE001
            acts["pdf_open_error"] = f"{type(e).__name__}: {e}"[:200]

    # 没有 PDF 的旧 JSON 也可能带着脏 AC 行；这一层不依赖 PDF，永远跑。
    if "ac_quarantine" not in acts:
        _step(acts, "ac_quarantine", ACQ.quarantine, doc)

    ch = PQ.normalize_temperature(doc)
    if ch:
        acts["temperature_align"] = ch

    # 空串温度写成显式哨兵（Reviewer V7 新-4）：`storage: ""` 会被页面渲染成
    # 空括号。渲染层的 `_is_blank_sentinel()` 认 `not_specified`，既不印空括号，
    # JSON 里也明确「原厂没给这个值」，而不是「我们忘了填」。
    _temp = (doc.get("specs") or {}).get("temperature") or {}
    _blank = [k for k in ("operating", "storage")
              if k in _temp and not str(_temp.get(k) or "").strip()]
    for k in _blank:
        _temp[k] = "not_specified"
    if _blank:
        acts["temperature_blank_filled"] = _blank

    sp = doc.setdefault("specs", {})
    elec = sp.get("electrical") or []
    amax = sp.get("absolute_max") or []

    moved = PQ.demote_stress_rows(elec, amax)
    if moved:
        acts["stress_demoted"] = moved

    n = PQ.normalize_ranges(elec) + PQ.normalize_ranges(amax)
    if n:
        acts["ranges_normalized"] = n

    # V11 P0-2：`unresolved` 行只许留 `unverified_range_candidate`。
    # `normalize_ranges` 已按新口径生成；这里再跑一次下游物理抹除，
    # 清掉旧 JSON 里「状态 unresolved 却带正式 range」的残留。
    guard = RG.enforce(doc)
    if guard["n_stripped"]:
        acts["range_stripped"] = guard["n_stripped"]

    acts["verification"] = DE.stamp_model_unverified(doc)

    # 受控分类表（1102 复审 P2-7）：模型的 `subcategory` 是自由文本，
    # `Data Converters` / `Data Acquisition Converters` / `ADC` 三种写法会
    # 在站内裂成三个类目，ADC 永远落不到 `Data Acquisition / ADCs`。
    # 只写 `category_path`，**不动** `subcategory` —— 它已进 H1 句子，
    # 改词性会把 `{mpn} is a {subcategory} from {mfr}` 写坏。
    tx = TX.apply_taxonomy(doc)
    if tx:
        acts["category_path"] = tx

    # 板卡类参数的归属三态（ChatGPT 8.0 复审 P1）：`specs.scope` 只能给一个值，
    # 而用户指南里同时有整板参数（外部电源输入）与板载器件参数（H 桥电流）。
    # 一个值盖不住，页面就会把器件限值印成整板能力。
    bs = BS.apply_board_scope(doc)
    if bs:
        acts["board_scope"] = bs
    return acts
