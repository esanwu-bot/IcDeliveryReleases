#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qc/diagnose.py — 型号 JSON 缺陷诊断（通用，任意型号可复用）

对 parsed JSON 做定向 dump + 基础 lint，用于客户抽检/回归前的人工核对定位。

用法:
  python qc/diagnose.py --models "AM26C32IDG4,CY74FCT245ATSOCT"        # 按型号名（safe_name 归一化匹配文件）
  python qc/diagnose.py --models @qc/fixtures/fix11_models.txt         # 从清单文件读型号
  python qc/diagnose.py --models "DAC8555IPWG4" --keys "idd,ioidd"      # 只看指定电气参数
  python qc/diagnose.py --models "AM26C32IDG4" --lang-check             # 检查五语完整性
  python qc/diagnose.py --models "ADS7812B_1K" --json-dir data/parsed  # 直接指服务器同步目录

目录约定（qc/ 自成一体，供客户抽检型号长期保留与人工核查）:
  qc/diagnose.py            诊断脚本（通用，任意型号）
  qc/fixtures/              型号清单 / 断言夹具
  qc/json/                  受检型号的 parsed JSON 快照（本次 11 件，修补前基线）
  qc/pdfs/                  受检型号的原始 PDF（人工核对真值的权威依据，不入 git）

输出分区: 身份(mpn vs requested) / 封装 / 描述 / ordering / alternatives /
          electrical(可过滤) / absolute_max / 引脚表 / 多语言完整性。
"""
import argparse
import io
import json
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent.parent

HASH_SUFFIX = re.compile(r"_[0-9a-f]{8}$")


def safe_name(mpn: str) -> str:
    """与项目 safe_name() 口径一致：/ # 空格 → _"""
    return re.sub(r"[/#\s]+", "_", mpn.strip())


def find_json(json_dir: Path, mpn: str):
    """按文件名前缀（safe_name 归一化）匹配解析 JSON"""
    target = safe_name(mpn).lower()
    for p in sorted(json_dir.glob("*.json")):
        if p.name.endswith((".alts.json", ".seo.json")):
            continue
        stem = HASH_SUFFIX.sub("", p.stem).lower()
        if stem == target or stem.startswith(target + "_"):
            return p
    return None


def load_models(args) -> list:
    if args.models.startswith("@"):
        txt = Path(args.models[1:])
        return [ln.strip() for ln in txt.read_text(encoding="utf-8").splitlines() if ln.strip()]
    return [m.strip() for m in args.models.split(",") if m.strip()]


def dump(mpn: str, path: Path, keys: list | None, lang_check: bool):
    d = json.loads(path.read_text(encoding="utf-8"))
    bi = d.get("basic_info", {})
    req = d.get("metadata", {}).get("requested_mpn", "")
    print("=" * 96)
    print(f"### {mpn}   [{path.name}]")
    identity = "OK" if bi.get("mpn", "") == req or not req else f"!! mpn字段={bi.get('mpn')!r} != requested={req!r}"
    print(f"  身份: {identity}")
    pkg = d.get("specs", {}).get("package", {})
    print(f"  封装: {pkg.get('type')!r}  pins={pkg.get('pins')}")
    desc = bi.get("description", "")
    print(f"  描述[{len(desc)}字]: {desc[:260]}{'...' if len(desc) > 260 else ''}")
    print(f"  ordering_info: {json.dumps(d.get('ordering_info', []), ensure_ascii=False)[:400]}")
    print(f"  alternatives : {json.dumps(d.get('alternatives', []), ensure_ascii=False)[:600]}")

    def match(e):
        if not keys:
            return True
        hay = (e.get("name", "") + " " + e.get("condition", "")).lower()
        return any(k.lower() in hay for k in keys)

    el = d.get("specs", {}).get("electrical", [])
    print(f"  electrical[{len(el)}]:")
    for e in el:
        if match(e):
            print(f"    {e.get('name')}={e.get('value')} {e.get('unit', '')}  [{e.get('condition', '')}]")
    am = d.get("specs", {}).get("absolute_max", [])
    if am:
        print(f"  absolute_max[{len(am)}]: " + "; ".join(
            f"{e.get('name')}={e.get('value')}{e.get('unit', '')}" for e in am))

    pins = d.get("pin_configuration", [])
    if pins:
        # lint: 引脚号连续性 + 同名异常堆积
        nums = [p["pin"] for p in pins]
        cont = nums == list(range(1, len(pins) + 1))
        dup_nc = sum(1 for p in pins if p["name"].upper() == "NC")
        print(f"  引脚[{len(pins)}个, 连续={cont}, NC数={dup_nc}]:")
        print("    " + " | ".join(f"{p['pin']}={p['name']}" for p in pins))
        for line_no in range(0, len(pins), 10):
            pass
    else:
        print("  引脚: (空)")

    ml = d.get("multi_language", {})
    have = [k for k in ("ja", "ko", "de", "es") if ml.get(k, {}).get("title")]
    missing = [k for k in ("ja", "ko", "de", "es") if k not in have]
    if lang_check:
        detail = {k: sorted(ml.get(k, {}).keys()) for k in ("ja", "ko", "de", "es")}
        print(f"  多语言: 有={have} 缺={missing}  字段明细={detail}")
    else:
        print(f"  多语言: 有={have} 缺={missing}")


def main():
    ap = argparse.ArgumentParser(description="型号 JSON 缺陷诊断")
    ap.add_argument("--models", required=True, help="逗号分隔型号名，或 @清单文件")
    ap.add_argument("--json-dir", default=str(ROOT / "qc" / "json"),
                    help="parsed JSON 目录（可指 data/parsed 或 qc/json）")
    ap.add_argument("--keys", default="", help="电气参数过滤词，逗号分隔（默认全部）")
    ap.add_argument("--lang-check", action="store_true", help="详查多语言字段完整性")
    args = ap.parse_args()

    json_dir = Path(args.json_dir)
    keys = [k for k in args.keys.split(",") if k.strip()] or None
    for mpn in load_models(args):
        p = find_json(json_dir, mpn)
        if not p:
            print(f"### {mpn}  !! 未找到 JSON（目录 {json_dir}）")
            continue
        dump(mpn, p, keys, args.lang_check)


if __name__ == "__main__":
    main()
