#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按「选页瓶颈类型」给器件分类（不调 LLM，纯本地解析，零成本）。

为什么需要这个工具：重解 21 件之前必须知道每件**为什么**没抽到电气表，
否则只能「统一重解一遍碰运气」。实测瓶颈不止一种：

  MAX_PAGES_CAP    — 页数顶格（used == MAX_PAGES），后面还有电气页没进来
  QUOTA_OR_CHARS   — 页数没到顶，但电气页被 RANK_QUOTA / MAX_CHARS 挡住
  COUPLED          — 只放宽单个上限无效，必须三项联动（AFE4490 是这种）
  PAGE_SELECT_OK   — 电气页基本都进来了，问题不在选页（要去查 prompt/抽取）

AFE4490RHAT 实测：rank=3 候选页 11 个、配额 6 页且按页号升序，
POWER DISSIPATION 表所在的 p14 是第 9 个 → 必然落选；
且只提 MAX_PAGES / 只提 MAX_CHARS / 只提配额**都救不回来**，三项全提才可以。

用法：
  python qc/page_bottleneck.py --mpn A,B,C
  python qc/page_bottleneck.py --csv data/qc/ec56_triage_20261028.csv \
      --sub-group G1-真ROW_BAD --json-out data/qc/page_bottleneck.json
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                                # noqa: E402
from qc.diagnose_elec_loss import ELEC_KEYS                  # noqa: E402

PDFS = ROOT / "data" / "pdfs"

CAP = "MAX_PAGES_CAP"
QUOTA = "QUOTA_OR_CHARS"
COUPLED = "COUPLED"
OK = "PAGE_SELECT_OK"
NO_PDF = "NO_PDF"


def find_pdf(mpn: str):
    base = mpn.replace("/", "_")
    hits = [p for p in PDFS.glob(base + "*") if p.suffix.lower() == ".pdf"]
    return hits[0] if hits else None


def _rank_of(text: str) -> int:
    low = (text or "").lower()
    for n, keys in enumerate(PD.PAGE_PRIORITY, start=1):
        if any(k in low for k in keys):
            return n
    return len(PD.PAGE_PRIORITY) + 1


def _elec_pages(pages: list) -> list[int]:
    """全本里带电气表特征的页码（1-based）。"""
    out = []
    for i, t in pages:
        if i >= PD.PAGE_SCAN_CAP:
            break
        low = (t or "").lower()
        if any(k in low for k in ELEC_KEYS):
            out.append(i + 1)
    return out


def _selected_pages(pages: list, text: str) -> set[int]:
    """从拼接后的正文反查选中了哪些页（用页内中段做指纹，页眉会重复）。"""
    flat = (text or "").replace("\n", " ")
    sel = set()
    for i, t in pages:
        body = (t or "").replace("\n", " ")
        seg = body[300:420].strip()
        if len(seg) > 20 and seg in flat:
            sel.add(i + 1)
    return sel


def diagnose(mpn: str) -> dict:
    pdf = find_pdf(mpn)
    if not pdf:
        return {"mpn": mpn, "kind": NO_PDF, "note": "本地无 PDF"}

    total, gen = PD._iter_pages(pdf)
    pages = list(gen)
    elec_all = _elec_pages(pages)

    # ---- 基线 ----
    text, used, _tr = PD.select_pages(iter(pages))
    sel = _selected_pages(pages, text)
    got = [p for p in elec_all if p in sel]
    miss = [p for p in elec_all if p not in sel]

    rec = {
        "mpn": mpn, "pdf": pdf.name, "pages_total": total,
        "elec_pages": len(elec_all), "elec_selected": len(got),
        "elec_missing": miss[:12], "used": used,
        "chars": len(text),
    }
    if not miss:
        rec["kind"] = OK
        rec["note"] = "电气页全部入选，问题不在选页"
        return rec

    # ---- 分离瓶颈：逐个放宽单个上限，看能否补上缺失的电气页 ----
    base_q = PD.RANK_QUOTA
    tries = {
        "pages": PD.select_pages(iter(pages), 40, PD.MAX_CHARS),
        "chars": PD.select_pages(iter(pages), PD.MAX_PAGES, 90_000),
    }
    PD.RANK_QUOTA = (3, 2, max(12, len(elec_all) + 2))
    try:
        tries["quota"] = PD.select_pages(iter(pages), PD.MAX_PAGES, PD.MAX_CHARS)
    finally:
        PD.RANK_QUOTA = base_q

    helped = []
    for tag, (t2, _u2, _d2) in tries.items():
        sel2 = _selected_pages(pages, t2)
        if all(p in sel2 for p in miss):
            helped.append(tag)

    if used >= PD.MAX_PAGES:
        rec["kind"] = CAP
        rec["note"] = f"页数顶格（used={used}=MAX_PAGES）"
    elif not helped:
        rec["kind"] = COUPLED
        rec["note"] = "单因素放宽均无效，需三项联动"
    else:
        rec["kind"] = QUOTA
        rec["note"] = f"放宽 {'/'.join(helped)} 即可补回"
    rec["single_fix_works"] = helped
    return rec


def tier_of(pages_total: int) -> tuple[str, int | None, int | None]:
    """按体量分档，返回 `(档位, 建议 MAX_PAGES, 建议 MAX_CHARS)`；None = 不提。

    分档依据（不是拍脑袋，来自 AFE4490 / AM5746 实测）：
      ≤30 页     — 整本都进得来，放宽到整本体量即可，成本几乎不变；
      30~100 页  — EC 表多在中后段，放宽到 60 页 / 5 万字符能覆盖；
      >100 页    — **不提上限**。AM5746ABZXEA 474 页、EC 真值区在 p183~194，
                   MAX_PAGES 提到 200 也未必覆盖得到，等于白花十几倍 token。
                   正解是分段重解后合并，或直接标 `EVIDENCE_INCOMPLETE` 转人工。
    """
    if pages_total <= 30:
        return "T1_SMALL", max(24, pages_total), 48_000
    if pages_total <= 100:
        return "T2_MID", min(60, pages_total), 50_000
    return "T3_HUGE", None, None


def tier_report(items: list) -> int:
    """输出分档清单 + 可直接粘贴的覆盖环境变量（**不执行**）。"""
    caps = [r for r in items if r.get("kind") == CAP]
    print(f"MAX_PAGES_CAP 共 {len(caps)} 件，按体量分档（**只出清单，不执行**）\n")
    print(f"{'MPN':<26}{'页数':>6}  档位      建议pages  建议chars")
    env_p, env_c = [], []
    tally: dict[str, int] = {}
    for r in sorted(caps, key=lambda x: x.get("pages_total", 0)):
        n = r.get("pages_total", 0)
        tier, mp, mc = tier_of(n)
        tally[tier] = tally.get(tier, 0) + 1
        print(f"{r['mpn'][:25]:<26}{n:>6}  {tier:<10}"
              f"{('—' if mp is None else mp):>10}  {('—' if mc is None else mc):>10}")
        if mp is not None:
            env_p.append(f"{r['mpn']}={mp}")
            env_c.append(f"{r['mpn']}={mc}")
    print("\n档位统计：")
    for t, c in sorted(tally.items()):
        print(f"  {t:<12}{c:>4}")
    if env_p:
        print("\n建议覆盖（粘贴前请先复核，T3 档不在内）：")
        print("export ICPDF_MAX_PAGES_OVERRIDE=\"" + ",".join(env_p) + "\"")
        print("export ICPDF_MAX_CHARS_OVERRIDE=\"" + ",".join(env_c) + "\"")
    else:
        print("\n无 T1/T2 档器件：本批全部落入 T3，提上限无效，"
              "应标 EVIDENCE_INCOMPLETE 转人工或分段重解。")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="选页瓶颈分类")
    ap.add_argument("--mpn", default="", help="逗号分隔的型号")
    ap.add_argument("--csv", default="", help="triage CSV")
    ap.add_argument("--sub-group", default="", help="只取该 sub_group")
    ap.add_argument("--json-out", default="")
    ap.add_argument("--tier", action="store_true",
                    help="对 MAX_PAGES_CAP 的件按体量分档，只出清单不执行")
    args = ap.parse_args(argv)

    mpns = [m.strip() for m in args.mpn.split(",") if m.strip()]
    if args.csv:
        rows = list(csv.DictReader(open(args.csv, encoding="utf-8-sig")))
        for r in rows:
            if args.sub_group and r.get("sub_group") != args.sub_group:
                continue
            if not (r.get("local_rows") or "").strip():
                continue
            mpns.append(r["mpn"])

    out = [diagnose(m) for m in mpns]
    tally: dict[str, int] = {}
    for r in out:
        tally[r["kind"]] = tally.get(r["kind"], 0) + 1

    print(f"{'MPN':<26}{'总页':>5}{'电页':>5}{'选中':>5}{'used':>6}  瓶颈")
    for r in out:
        print(f"{r['mpn'][:25]:<26}{r.get('pages_total', 0):>5}"
              f"{r.get('elec_pages', 0):>5}{r.get('elec_selected', 0):>5}"
              f"{r.get('used', 0):>6}  {r['kind']}")
    print("\n分类统计：")
    for k, v in sorted(tally.items(), key=lambda x: -x[1]):
        print(f"  {k:<18}{v:>4}")

    if args.json_out:
        p = ROOT / args.json_out
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"items": out, "tally": tally},
                                ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"\n写入 {args.json_out}")
    if args.tier:
        print()
        return tier_report(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
