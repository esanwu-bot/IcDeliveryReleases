"""五件修复 staging：只消费指定页缓存，不扫描整份 PDF，不覆盖旧验收目录。

产出 data/staging_20261030_fixed/{parsed,txt,symbols}，供 delivery_bundle 验收模式装配。
"""
from __future__ import annotations

import json
import shutil
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import json_to_txt as J
import symbol_svg as S
from qc.identity_scope import apply, find_pdf
from qc.column_origins import DEFAULT_ORIGIN
from qc.page_evidence import extract_pages
from qc import pin_repair as PR

PY_STAMP = "2026-10-30-page-evidence-v1"
MPNS = (
    "ADS8568EVM-PDK", "BOOST-DRV8711", "BOOSTXL-C2KLED",
    "ADC12DJ5200SE", "ADS1201U-1_1K",
)
OUT = ROOT / "data" / "staging_20261030_fixed"
ADS_SHA = "0805d18743ce9c51721783c2d9083654570b5ed3fbbf1181cf410597ba64d1ec"


def _source(sha: str, page: int, y: float, scope: str, note: str) -> dict:
    return {
        "pdf_sha256": sha, "page": page, "page_base": 1, "y": y,
        "extractor": "pymupdf-words-v1", "scope": scope, "note": note,
    }


def _remember(row: dict) -> None:
    hist = row.setdefault("value_history", [])
    snap = {"value": row.get("value"), "columns_raw": row.get("columns_raw"),
            "range": row.get("range")}
    if snap not in hist:
        hist.append(snap)


def _set_columns(row: dict, cols: dict, source: dict) -> None:
    _remember(row)
    row.pop("columns", None)
    row.pop("range", None)
    row["columns_raw"] = cols
    row["column_origin"] = DEFAULT_ORIGIN
    order = [k for k in ("MIN", "TYP", "MAX") if k in cols]
    if order == ["MIN", "MAX"]:
        row["value"] = f"{cols['MIN']} to {cols['MAX']}"
        row["range"] = {"min": cols["MIN"], "max": cols["MAX"]}
        row["range_origin"] = "pdf_columns"
    else:
        row["value"] = " / ".join(f"{cols[k]} {k}" for k in order)
        row["range_origin"] = "pdf_columns_with_role"
    row["source"] = source
    row["verification"] = {"status": "audited", "method": PY_STAMP}


def _set_formula(row: dict, value: str, source: dict) -> None:
    _remember(row)
    row.pop("columns", None)
    row.pop("columns_raw", None)
    row["value"] = value
    row["range"] = None
    row["range_origin"] = "pdf_prose_formula"
    row["source"] = source
    row["verification"] = {"status": "audited", "method": PY_STAMP}


def _find(rows: list, name: str) -> dict | None:
    for row in rows:
        if str(row.get("name") or "") == name:
            return row
    return None


def _page_text(pdf: Path, pages: list[int]) -> str:
    doc = extract_pages(pdf, pages, timeout_s=8)
    if doc.get("status") != "ok":
        raise RuntimeError(f"page evidence {pdf.name} {pages}: {doc.get('status')} {doc.get('error')}")
    chunks = []
    for page in doc["pages_data"]:
        chunks.append(f"--- page {page['page']} ---")
        chunks.extend(row["text"] for row in page.get("rows") or [])
    return "\n".join(chunks), doc["pdf_sha256"]


def _patch_ads(doc: dict) -> None:
    specs = doc.setdefault("specs", {})
    elec = specs.setdefault("electrical", [])
    am = specs.setdefault("absolute_max", [])
    audited = {
        "Absolute Input Voltage Range": ({"MIN": "0", "MAX": "+5"}, 2, 115.95),
        "Differential Input Voltage Range": ({"MIN": "–5", "MAX": "+5"}, 2, 133.95),
        "Input Impedance": ({"TYP": "250(4)"}, 2, 151.95),
        "Input Capacitance": ({"TYP": "8"}, 2, 160.95),
        "Common-Mode Rejection": ({"MIN": "80", "TYP": "100"}, 2, 282.03),
        "Power Supply Rejection": ({"TYP": "80"}, 2, 291.03),
        "Internal Reference (REF OUT)": ({"MIN": "2.4", "TYP": "2.5", "MAX": "2.6"}, 2, 312.99),
        "External Reference (REF IN)": ({"MIN": "2.0", "MAX": "3.0"}, 2, 357.99),
        "VBIAS Output": ({"MIN": "3.15", "TYP": "3.3", "MAX": "3.45"}, 2, 375.99),
        "VIH (MCLK)": ({"MIN": "2.0", "MAX": "DVDD +0.3"}, 2, 433.95),
        "VIL (MCLK)": ({"MIN": "–0.3", "MAX": "0.8"}, 2, 442.95),
        "MCLK Frequency": ({"MIN": "0.02", "MAX": "1"}, 2, 469.95),
        "Power Supply Voltage": ({"MIN": "4.75", "MAX": "5.25"}, 2, 491.91),
        "Analog Current": ({"TYP": "4.6"}, 2, 509.91),
        "Total Power Dissipation": ({"TYP": "25", "MAX": "40"}, 2, 554.91),
    }
    for name, (cols, page, y) in audited.items():
        row = _find(elec, name)
        if not row:
            raise RuntimeError(f"ADS1201 missing electrical row {name}")
        _set_columns(row, cols, _source(ADS_SHA, page, y, "device", "header anchors MIN/TYP/MAX"))
    analog = _find(am, "Analog Input Voltage")
    if not analog:
        raise RuntimeError("ADS1201 missing analog absolute max")
    _set_formula(analog, "AGND -0.3 V to AVDD +0.3 V",
                 _source(ADS_SHA, 3, 70.47, "device", "absolute maximum prose; not the adjacent 6 V rail"))
    supply = _find(am, "AVDD to DVDD")
    if supply:
        _set_formula(supply, "-0.3 V to 6 V",
                     _source(ADS_SHA, 3, 79.47, "device", "supply difference, separate from analog input"))
    extras = [
        ("Analog Input Current", "±100 mA, momentary", 52.47),
        ("AVDD to AGND", "-0.3 V to 6 V", 88.47),
        ("DVDD to DGND", "-0.3 V to 6 V", 97.47),
        ("AGND to DGND", "±0.3 V", 106.47),
        ("REFIN Voltage to AGND", "AGND -0.3 V to AVDD +0.3 V", 115.47),
        ("Digital Input Voltage to DGND", "DGND -0.3 V to DVDD +0.3 V", 124.47),
        ("Digital Output Voltage to DGND", "DGND -0.3 V to DVDD +0.3 V", 133.47),
    ]
    for name, value, y in extras:
        if _find(am, name):
            continue
        am.append({
            "name": name, "value": value, "unit": "",
            "condition": "Absolute Maximum Ratings",
            "range_origin": "pdf_prose_formula",
            "source": _source(ADS_SHA, 3, y, "device", "absolute maximum prose"),
            "verification": {"status": "audited", "method": PY_STAMP},
        })


def _patch_drv(doc: dict, sha: str) -> None:
    elec = (doc.get("specs") or {}).get("electrical") or []
    board_rows = {
        "Voltage Range": (3, 172.02, "guide bullet: Supports 8.2–52 V"),
        "Continuous Current per H-Bridge": (3, 172.02, "guide bullet: 4.5 A continuous each H-Bridge"),
    }
    for name, (page, y, note) in board_rows.items():
        row = _find(elec, name)
        if not row:
            continue
        row["scope"] = "board"
        row["subject_mpn"] = "BOOST-DRV8711"
        row["subject_kind"] = "board"
        row["source"] = _source(sha, page, y, "board", note)
        row["verification"] = {"status": "audited", "method": PY_STAMP}
    mos = _find(elec, "MOSFET On-Resistance")
    if mos:
        mos["scope"] = "onboard_device"
        mos["subject_mpn"] = "CSD88537ND"
        mos["subject_kind"] = "onboard_device"
        mos["source"] = _source(sha, 3, 186.62, "onboard_device",
                                "12.5 mΩ belongs to named MOSFET, not the board")
        mos["verification"] = {"status": "audited", "method": PY_STAMP}


def _patch_c2k(doc: dict, sha: str) -> None:
    notes = {
        "Power Input Voltage Minimum": (233.3, "6 V minimum @ 1.2A"),
        "Power Input Voltage Maximum": (247.9, "20 V maximum @ 360 mA"),
        "Boost Stage Input Voltage Minimum": (291.8, "6 V minimum @ 400 mA"),
        "Boost Stage Input Voltage Maximum": (306.4, "20 V maximum @ 120 mA"),
        "Boost Stage Output Voltage": (335.6, "24 V nominal @ 100 mA"),
    }
    for row in (doc.get("specs") or {}).get("electrical") or []:
        name = row.get("name")
        if name not in notes:
            continue
        y, note = notes[name]
        row["scope"] = "board"
        row["subject_mpn"] = "BOOSTXL-C2KLED"
        row["subject_kind"] = "board"
        row["source"] = _source(sha, 5, y, "board", note)
        row["verification"] = {"status": "audited", "method": PY_STAMP}


def _guide_text(mpn: str, pdf: Path) -> tuple[str, str]:
    if mpn == "BOOST-DRV8711":
        return _page_text(pdf, [1, 3])
    if mpn == "BOOSTXL-C2KLED":
        return _page_text(pdf, [1, 5])
    return _page_text(pdf, [1])


def _repair_pins(doc: dict, pdf: Path) -> dict:
    box = {}

    def run() -> None:
        box["result"] = PR.repair_bga_pins(doc, pdf, max_pages=8)

    worker = threading.Thread(target=run, daemon=True)
    worker.start()
    worker.join(20)
    if worker.is_alive() or "result" not in box:
        old = doc.get("pin_configuration") or []
        doc.setdefault("metadata", {}).setdefault("pin_repair_history", []).append({
            "reason": "timeout_20s_max_pages_8", "previous_count": len(old)})
        doc["pin_configuration"] = []
        doc["pin_scope"] = "unresolved"
        return {"action": "timeout_unresolved", "previous_count": len(old)}
    return box["result"]


def stage() -> dict:
    if OUT.exists():
        raise SystemExit(f"staging 已存在，拒绝覆盖：{OUT}")
    for sub in ("parsed", "txt", "symbols"):
        (OUT / sub).mkdir(parents=True)
    plan = ROOT / "data" / "acceptance_20261030" / "修复方案.md"
    if plan.is_file():
        shutil.copyfile(plan, OUT / "修复方案.md")
    report = []
    for mpn in MPNS:
        t0 = time.monotonic()
        src = ROOT / "data" / "rebuilt" / f"{mpn}.json"
        pdf = find_pdf(mpn, ROOT / "data" / "pdfs")
        if not src.is_file() or not pdf:
            raise SystemExit(f"缺源：{mpn} json={src.is_file()} pdf={pdf}")
        doc = json.loads(src.read_text(encoding="utf-8"))
        doc.setdefault("basic_info", {})["mpn"] = {
            "ADS1201U-1_1K": "ADS1201U-1/1K",
        }.get(mpn, mpn)
        doc.setdefault("metadata", {})["requested_mpn"] = doc["basic_info"]["mpn"]
        text, sha = _guide_text(mpn, pdf)
        # 身份函数只看文本前 4000 字。把已缓存标题和请求号放在一起，避免整本抽取。
        head = text[:4000]
        rep = apply(doc, doc["basic_info"]["mpn"], pdf_text=head, pdf_path=pdf)
        if mpn == "ADS1201U-1_1K":
            _patch_ads(doc)
        elif mpn == "BOOST-DRV8711":
            _patch_drv(doc, sha)
        elif mpn == "BOOSTXL-C2KLED":
            _patch_c2k(doc, sha)
        pin = {"action": "not_bga"}
        pkg = str((doc.get("specs") or {}).get("package", {}).get("type") or "")
        if mpn == "ADC12DJ5200SE" or "BGA" in pkg.upper():
            pin = _repair_pins(doc, pdf)
        doc.setdefault("metadata", {})["five_stage"] = PY_STAMP
        out_json = OUT / "parsed" / f"{mpn}.json"
        out_json.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
        fresh = json.loads(out_json.read_text(encoding="utf-8"))
        (OUT / "txt" / f"{mpn}.txt").write_text(J.render(fresh, "en"), encoding="utf-8")
        (OUT / "symbols" / f"{mpn}.html").write_text(
            S.render_page(fresh, pkg_dir=ROOT / "data" / "pkgs"), encoding="utf-8")
        report.append({
            "mpn": mpn, "identity": rep.get("identity"), "state": rep.get("state"),
            "scope": (fresh.get("specs") or {}).get("scope"),
            "document_scope": (fresh.get("basic_info") or {}).get("document_scope"),
            "electrical": len((fresh.get("specs") or {}).get("electrical") or []),
            "pins": len(fresh.get("pin_configuration") or []),
            "pin_action": pin.get("action"),
            "elapsed_s": round(time.monotonic() - t0, 2),
        })
        print(f"{mpn} identity={rep.get('identity')} scope={(fresh.get('specs') or {}).get('scope')} "
              f"pins={len(fresh.get('pin_configuration') or [])} pin={pin.get('action')} "
              f"{report[-1]['elapsed_s']}s")
    (OUT / "stage_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"out": str(OUT), "records": report}


if __name__ == "__main__":
    stage()
