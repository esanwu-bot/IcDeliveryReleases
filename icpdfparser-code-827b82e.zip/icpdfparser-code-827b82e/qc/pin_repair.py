# -*- coding: utf-8 -*-
"""BGA 球位修复：原 PDF 映射、逐球来源与完整性校验，失败时禁止猜号。

repair_bga_pins 只修改传入的内存字典，不写文件。调用方负责持久化授权。
来源 page 明确为 1-based；table / row 为 PyMuPDF 的 0-based 索引。
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path

_BGA = re.compile(r"(?<![A-Z])(?:[A-Z]{0,3}BGA|WLCSP)(?![A-Z])", re.I)
_BALL = re.compile(r"\b([A-Z]{1,2}[1-9][0-9]?)\b")
_HEAD = {"PIN", "NAME", "NO", "NO.", "I/O", "DESCRIPTION"}
# 已知器件的封装球集，仅用于查缺/查多，绝不用来补造 PDF 中没有的球位。
_ADC_BALLS = {f"{row}{col}" for row in "ABCDEFGHJKLM" for col in range(1, 13)}


def is_bga(pkg_type) -> bool:
    return bool(_BGA.search(str(pkg_type or "")))


def _clean(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _norm_name(s) -> str:
    t = _clean(s).replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", "", t)


def _cell_text(page, rect) -> str:
    if not rect:
        return ""
    x0, y0, x1, y1 = rect
    ws = [w for w in page.get_text("words")
          if w[0] >= x0 - 1 and w[2] <= x1 + 1
          and w[1] >= y0 - 1 and w[3] <= y1 + 1]
    ws.sort(key=lambda w: (round(w[1], 1), w[0]))
    lines, cur, last = [], [], None
    for w in ws:
        if last is not None and abs(w[1] - last) > 3:
            lines.append(" ".join(cur))
            cur = []
        cur.append(w[4])
        last = w[1]
    if cur:
        lines.append(" ".join(cur))
    return " ".join(lines)


def _ball_key(ball):
    m = re.fullmatch(r"([A-Z]{1,2})([1-9][0-9]?)", str(ball))
    return (len(m[1]), m[1], int(m[2])) if m else (9, str(ball), 0)


def _balls(values):
    return sorted(set(values), key=_ball_key)


def _valid_source(source) -> bool:
    if not isinstance(source, dict):
        return False
    bbox = source.get("bbox")
    return (source.get("scope") == "device"
            and bool(re.fullmatch(r"[0-9a-f]{64}", str(source.get("pdf_sha256") or "")))
            and type(source.get("page")) is int and source["page"] >= 1
            and source.get("page_base") == 1
            and type(source.get("table")) is int and source["table"] >= 0
            and type(source.get("row")) is int and source["row"] >= 0
            and isinstance(bbox, (list, tuple)) and len(bbox) == 4
            and all(isinstance(v, (int, float)) and math.isfinite(v) for v in bbox)
            and bbox[0] < bbox[2] and bbox[1] < bbox[3])


def _mapping_hash(pins) -> str:
    payload = [{k: p.get(k) for k in ("pin", "name", "function", "description", "source")}
               for p in sorted(pins, key=lambda p: _ball_key(p.get("pin")))]
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def ball_pins_from_pdf(pdf_path, max_pages: int | None = 12) -> list[dict]:
    """抽取原表功能行（多球号保持逗号分组），含 I/O 与逐行来源。

    不存在的 PDF 返回空列表；读取失败抛出异常，由 repair API 记录 unresolved。
    为避免把其它器件的表当真值，来源同时记录 PDF 页眉中的器件型号。
    """
    p = Path(str(pdf_path))
    if not p.is_file():
        return []
    import pymupdf

    sha = hashlib.sha256(p.read_bytes()).hexdigest()
    out = []
    with pymupdf.open(str(p)) as doc:
        texts = [doc[i].get_text() for i in range(min(doc.page_count, max_pages)
                                                if max_pages is not None else doc.page_count)]
        counts = set()
        subjects = set()
        for text in texts:
            counts.update(int(n) for n in re.findall(r"\b(\d+)[ -]+Ball\b[^\n]*BGA", text, re.I))
            subjects.update(re.findall(r"Product Folder Links:\s*([A-Z0-9_-]+)", text))
        for pno, text in enumerate(texts):
            if not re.search(r"\bPin\s+Functions\b", text, re.I):
                continue
            page = doc[pno]
            for ti, t in enumerate(page.find_tables().tables):
                rows = t.extract()
                if not rows:
                    continue
                head = " ".join(_clean(c).upper() for r in rows[:2] for c in r)
                if not all(k in head for k in ("NAME", "NO", "I/O", "DESCRIPTION")):
                    continue
                trows = list(t.rows)
                caption = re.search(r"Table\s+([\d.-]+)\.?\s+Pin\s+Functions", text, re.I)
                for ri, r in enumerate(rows):
                    if len(r) != 4 or ri >= len(trows):
                        continue
                    cells = trows[ri].cells
                    values = [_cell_text(page, cells[i]) if cells[i] else _clean(r[i])
                              for i in range(4)]
                    name = _norm_name(values[0])
                    balls = _BALL.findall(values[1].upper())
                    if not name or name.upper() in _HEAD or not balls:
                        continue
                    rects = [c for c in cells if c]
                    bbox = [min(c[0] for c in rects), min(c[1] for c in rects),
                            max(c[2] for c in rects), max(c[3] for c in rects)]
                    source = {"pdf_sha256": sha, "page": pno + 1, "page_base": 1,
                              "table": ti, "table_index": ti, "row": ri, "index_base": 0,
                              "bbox": bbox, "table_bbox": list(t.bbox), "scope": "device",
                              "table_name": f"Table {caption[1].rstrip('.')}" if caption else "",
                              "subject_mpn": next(iter(subjects)) if len(subjects) == 1 else "",
                              "package_ball_count": next(iter(counts)) if len(counts) == 1 else None}
                    out.append({"pin": ",".join(balls), "name": name,
                                "function": _clean(values[2]), "description": _clean(values[3]),
                                "source": source})
    return out


def bga_pin_validation(doc: dict) -> dict:
    """绘图入口校验已修映射，拒绝缺来源、重复球及修复后被篡改的旧签核。"""
    pins = doc.get("pin_configuration") or []
    report = (doc.get("metadata") or {}).get("pin_validation") or {}
    reasons = []
    info = doc.get("basic_info") or {}
    if info.get("identity") not in ("chip", "device"):
        reasons.append("subject_is_not_verified_device")
    if any(f.get("kind") in ("alias_conflict", "unknown_identity", "pins_quarantined", "scope_conflict")
           for f in (doc.get("metadata") or {}).get("scope_contract_findings", []) if isinstance(f, dict)):
        reasons.append("scope_contract_conflict")
    if doc.get("pin_scope") != "device":
        reasons.append("pin_scope_unverified")
    if not isinstance(report, dict) or report.get("status") != "pass":
        reasons.append("pdf_mapping_unverified")
        report = report if isinstance(report, dict) else {}
    if not isinstance(pins, list) or not pins or any(not isinstance(p, dict) for p in pins):
        return {"status": "unresolved", "reasons": reasons + ["missing_ball_mapping"]}
    nums = [str(p.get("pin") or "") for p in pins]
    if any(not _BALL.fullmatch(b) for b in nums):
        reasons.append("invalid_ball_number")
    if len(set(nums)) != len(nums):
        reasons.append("duplicate_ball")
    if any(not _valid_source(p.get("source")) or not _clean(p.get("name"))
           or not _clean(p.get("function")) or not _clean(p.get("description")) for p in pins):
        reasons.append("incomplete_pdf_source")
    expected = set(report.get("expected_balls") or [])
    covered = set(report.get("covered_balls") or [])
    declared = (doc.get("specs") or {}).get("package") or {}
    if not expected or set(nums) != expected or covered != expected \
            or report.get("expected_count") != len(nums) \
            or str(declared.get("pins")) != str(len(nums)):
        reasons.append("ball_coverage_mismatch")
    mpn = _clean(info.get("mpn")).upper()
    if any(not p.get("source", {}).get("subject_mpn")
           or not mpn.startswith(str(p["source"]["subject_mpn"]).upper())
           for p in pins if isinstance(p.get("source"), dict)):
        reasons.append("pdf_subject_mismatch")
    if report.get("mapping_sha256") != _mapping_hash(pins):
        reasons.append("pdf_mapping_changed")
    return {"status": "unresolved" if reasons else "pass", "reasons": reasons}


def repair_bga_pins(doc: dict, pdf_path, *, expected_balls=None,
                    max_pages: int | None = 12) -> dict:
    """就地修复内存字典，返回 expected/actual/covered 球集和前后验证报告。

    字母球号也必须重新核对 PDF；完整且无冲突才 rebuilt/pass。旧值仅进入
    metadata.pin_repair_history，不作为发布真值。失败清空发布引脚并置 unresolved。
    expected_balls 可提供已核验封装球集；未知封装至少要求 PDF 总球数声明。
    """
    pkg = (doc.get("specs") or {}).get("package") or {}
    if not is_bga(pkg.get("type")):
        return {"action": "not_bga", "pins": len(doc.get("pin_configuration") or []),
                "status": "not_applicable"}
    raw_old = copy.deepcopy(doc.get("pin_configuration") or [])
    old = [p for p in raw_old if isinstance(p, dict)]
    mpn = _clean((doc.get("basic_info") or {}).get("mpn")).upper()
    expected = set(str(b).upper() for b in expected_balls) if expected_balls is not None else (
        set(_ADC_BALLS) if mpn.startswith("ADC12DJ5200SE") and "EVM" not in mpn else set())
    expected_origin = "caller_verified_package" if expected_balls is not None else (
        "verified_device_package" if expected else "pdf_table")
    reasons = []
    if (doc.get("basic_info") or {}).get("identity") not in ("chip", "device"):
        reasons.append("subject_is_not_verified_device")
    try:
        got = ball_pins_from_pdf(pdf_path, max_pages=max_pages)
    except Exception as exc:
        got = []
        reasons.append(f"pdf_extract_error:{type(exc).__name__}")
    if not got:
        reasons.append("pdf_missing" if not Path(str(pdf_path)).is_file() else "pdf_mapping_missing")
    flat = []
    for entry in got:
        for ball in str(entry.get("pin") or "").split(","):
            flat.append({"pin": ball.strip().upper(), "name": _norm_name(entry.get("name")),
                         "function": _clean(entry.get("function")),
                         "description": _clean(entry.get("description")),
                         "source": copy.deepcopy(entry.get("source") or {})})
    flat.sort(key=lambda p: _ball_key(p["pin"]))
    counts = Counter(p["pin"] for p in flat)
    duplicates = _balls(b for b, n in counts.items() if n > 1)
    actual = set(counts)
    if duplicates:
        reasons.append("pdf_duplicate_ball")
    if any(not _BALL.fullmatch(b) for b in actual):
        reasons.append("pdf_invalid_ball")
    if any(not _valid_source(p["source"]) or not p["name"] or not p["function"]
           or not p["description"] for p in flat):
        reasons.append("pdf_row_incomplete")
    subjects = {p["source"].get("subject_mpn") for p in flat}
    subject = next(iter(subjects)) if len(subjects) == 1 else ""
    subject_valid = bool(subject and mpn.startswith(str(subject).upper()))
    if flat and not subject_valid:
        reasons.append("pdf_subject_mismatch")
    pdf_counts = {p["source"].get("package_ball_count") for p in flat}
    pdf_count = next(iter(pdf_counts)) if len(pdf_counts) == 1 else None
    if type(pdf_count) is not int or pdf_count < 1:
        reasons.append("pdf_ball_count_unverified")
        pdf_count = None
    if not expected and pdf_count:
        expected = set(actual)
    expected_count = len(expected) if expected_origin != "pdf_table" else pdf_count
    if expected_count is None or len(actual) != expected_count or actual != expected:
        reasons.append("pdf_ball_set_incomplete")
    if pdf_count and (len(actual) != pdf_count or expected_count != pdf_count):
        reasons.append("pdf_ball_count_mismatch")
    if len({p["source"].get("pdf_sha256") for p in flat}) > 1:
        reasons.append("pdf_source_conflict")
    covered = {p["pin"] for p in flat if counts[p["pin"]] == 1 and p["pin"] in expected
               and subject_valid and _valid_source(p["source"])
               and p["name"] and p["function"] and p["description"]}
    old_nums = [str(p.get("pin") or "").strip().upper() for p in old]
    old_counts = Counter(old_nums)
    mapping = {p["pin"]: p for p in flat if counts[p["pin"]] == 1}
    mismatches = []
    for i, p in enumerate(old):
        reference = mapping.get(old_nums[i])
        if reference:
            fields = [k for k in ("name", "function", "description")
                      if (_norm_name(p.get(k)) if k == "name" else _clean(p.get(k))) != reference[k]]
            if fields:
                mismatches.append({"row": i, "pin": old_nums[i], "fields": fields})
    input_status = "pass" if (not reasons and len(raw_old) == len(old) == expected_count
                                      and set(old_nums) == expected and not mismatches
                                      and all(n == 1 for n in old_counts.values())
                                      and all(_valid_source(p.get("source")) for p in old)
                                      and _mapping_hash(old) == _mapping_hash(flat)) else "fail"
    report = {"action": "unresolved" if reasons else "rebuilt", "status": "unresolved" if reasons else "pass",
              "pins": 0 if reasons else len(flat), "balls": len(actual), "functions": len(got),
              "expected_count": expected_count, "expected_origin": expected_origin,
              "actual_count": len(actual), "actual_entries": len(flat), "covered_count": len(covered),
              "expected_balls": _balls(expected), "actual_balls": _balls(actual), "covered_balls": _balls(covered),
              "missing_balls": _balls(expected - actual), "extra_balls": _balls(actual - expected),
              "duplicate_balls": duplicates, "reasons": reasons,
              "input_validation": {"status": input_status if got else "unresolved", "count": len(old),
                                   "actual_balls": _balls(old_nums),
                                   "missing_balls": _balls(expected - set(old_nums)),
                                   "extra_balls": _balls(set(old_nums) - expected),
                                   "duplicate_balls": _balls(b for b, n in old_counts.items() if n > 1),
                                   "mapping_mismatches": mismatches,
                                   "source_unverified_count": sum(not _valid_source(p.get("source")) for p in old)}}
    metadata = doc.setdefault("metadata", {})
    history = metadata.setdefault("pin_repair_history", [])
    snapshot = {"old_pin_configuration": raw_old, "old_pin_scope": doc.get("pin_scope"),
                "old_package_pins": pkg.get("pins"), "old_pin_repair": copy.deepcopy(metadata.get("pin_repair")),
                "old_pin_validation": copy.deepcopy(metadata.get("pin_validation")),
                "input_validation": copy.deepcopy(report["input_validation"])}
    if reasons:
        snapshot["pdf_candidates"] = flat
        doc["pin_configuration"] = []
        doc["pin_scope"] = "unresolved"
        metadata["pin_repair"] = "PDF 球位映射不完整或冲突；发布引脚已隔离，禁止猜号。"
    else:
        doc["pin_configuration"] = flat
        doc["pin_scope"] = "device"
        pkg["pins"] = pdf_count
        report["mapping_sha256"] = _mapping_hash(flat)
        report["pdf_sha256"] = flat[0]["source"]["pdf_sha256"]
        metadata["pin_repair"] = f"PDF 原表逐球映射核验：{len(flat)} 球；名称、I/O、描述均取自原 PDF。"
    if raw_old != doc["pin_configuration"] or snapshot["old_package_pins"] != pkg.get("pins") \
            or reasons and flat:
        history.append(snapshot)
    metadata["pin_validation"] = copy.deepcopy(report)
    return report
