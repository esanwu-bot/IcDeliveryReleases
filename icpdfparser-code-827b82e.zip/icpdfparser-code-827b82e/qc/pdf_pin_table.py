"""从 PDF 抽引脚表（Pin Functions）：**网格几何取 find_tables、单元格文本取 span**。

为什么不能用现成手段（DS80PCI402EVK/NOPB 事故根因）
----------------------------------------------------
TI 的引脚表把同一单元格里的多个文本对象叠着放，于是：

  * `table.extract()` 返回**字符交错**串。实测 Table 5-1：
        '05 275\\n– . .'                 ← 本该是 2.375 / 2.5 / 2.625
        'Supply Voltage (VDD 2 .5 V)\\n-'  ← 本该是 Supply Voltage (VDD = 2.5 V)
    照这个顺序建表，同一通道的 P/N 会被排成「先全部 +、再全部 -」，
    值域看着合理、断言也全绿（断言真值取了同一份错数据 = 自证），实则整组错位。
  * `page.get_text("text")` 把一行压成字符串，多列并排时脚号与名字跨列串行，
    行正则（`^\\d+\\s+NAME\\s+desc`）根本对不齐。

正确解法是**两样东西各取所长**：
  * 列边界 / 行切分 → 用 `find_tables()` 的**几何**（bbox 网格实测准确，不受文本叠放影响）；
  * 单元格文本 → 用 `page.get_text("dict")` 的 span，按「中心点落在格内」收集，
    再按 (y, x) 排序拼接——span 本身没有交错问题。

输出顺序 == PDF 视觉顺序，不做任何按极性/按前缀的分组排序。

对外入口：
  extract(pdf_path, ...)   → {"ok","rows","pages","tables","rejected"}
  assert_interleaved(rows)  → 结构断言（差分对必须交错，不能先 P 后 N）
"""
from __future__ import annotations

import re
from pathlib import Path

# 引脚表标题（英文/中文手册）
HEADING = re.compile(
    r"pin\s*(?:functions?|descriptions?|configurations?|assignments?|outs?)"
    r"|terminal\s+functions?"
    r"|signal\s+descriptions?"
    r"|引脚(?:功能|定义|说明|描述|分配)"
    r"|端子功能", re.I)

# 反例标题：电气/限值表也有数字列，看见这些表头就别当引脚表
NOT_PIN = re.compile(r"MIN\b.*MAX\b|MAX\b.*UNIT\b|NOM\b|TYP\b.*MAX\b", re.I)
# 正例：引脚表的表头一定出现这些词之一（SMBus 地址表之类也带数字列，
# 只有表头能把它们区分开——实测放过会串进 AD0-AD3 这种非脚名）
PIN_HEADER = re.compile(r"\bNAME\b|\bPIN\b|\bSIGNAL\b|\bTERMINAL\b|\bBALL\b"
                        r"|引脚|名称|端子", re.I)

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_/+\-.]{0,30}$")
DASHES = str.maketrans({"–": "-", "—": "-", "−": "-", "﹢": "+", "﹣": "-"})
MAX_PIN = 2048
# 区间写法（AD0-AD3 / DQ0-DQ7）：代表多个不同名字，不能当单个名字广播
_RANGE_LIKE = re.compile(r"[A-Za-z0-9]-[A-Za-z0-9]")


def _norm(s) -> str:
    return str(s or "").translate(DASHES).strip()


def _num(t: str) -> int | None:
    s = _norm(t).rstrip(".")
    if not s.isdigit():
        return None
    n = int(s)
    return n if 1 <= n <= MAX_PIN else None


def _open():
    """优先 pymupdf 新名，退回 fitz（老版本），都不行返回 None。"""
    try:
        import pymupdf
        return pymupdf
    except ImportError:
        pass
    try:
        import fitz
        return fitz
    except ImportError:
        return None


# ---------------------------------------------------------------- span 取文本
def _page_spans(page) -> list[tuple[float, float, float, float, str]]:
    """[(x0, y0, x1, y1, text)]"""
    out = []
    d = page.get_text("dict")
    for blk in d.get("blocks") or []:
        for line in blk.get("lines") or []:
            for sp in line.get("spans") or []:
                t = _norm(sp.get("text"))
                if not t:
                    continue
                x0, y0, x1, y1 = sp.get("bbox") or (0, 0, 0, 0)
                out.append((float(x0), float(y0), float(x1), float(y1), t))
    return out


def _cell_text(spans, bbox) -> str:
    """收集中心点落在 bbox 内的 span，按 (y, x) 排好拼起来。"""
    x0, y0, x1, y1 = bbox
    hit = []
    for sx0, sy0, sx1, sy1, t in spans:
        cx, cy = (sx0 + sx1) / 2.0, (sy0 + sy1) / 2.0
        if x0 - 0.6 <= cx <= x1 + 0.6 and y0 - 0.6 <= cy <= y1 + 0.6:
            hit.append((round(cy, 1), sx0, t))
    hit.sort()
    # 同一 y 的多个 span 直接拼（名字被拆成 `OUTB_0` + `+` 时正好合成 OUTB_0+）；
    # 换行（y 差 > 3）之间补空格，避免把两段描述粘成一串
    out, last_y = "", None
    for cy, _x, t in hit:
        if last_y is not None and abs(cy - last_y) > 3.0:
            out += " "
        out += t
        last_y = cy
    return out.strip()


# ---------------------------------------------------------------- 列角色判定
def _col_texts(rows: list[list[str | None]], ci: int) -> list[str]:
    return [(_norm(r[ci]) if ci < len(r) and r[ci] else "") for r in rows]


def _parts(v: str) -> list[str]:
    """逗号并列 → 列表（TI 引脚表把一组脚的 名字/脚号 各写成一个单元格）。"""
    return [p.strip() for p in str(v or "").split(",") if p.strip()]


def _name_ok(s: str) -> bool:
    """是不是一个引脚名。

    引脚名只有一种形态：全大写（或全小写）的标识符，没有内部空格。
    这一条顺手挡掉电气表里的 "Supply Voltage"——去掉空格后它是合法标识符形态，
    只是大小写混杂，而真实的脚名从不这样写。
    """
    t = _norm(s).replace(" ", "")
    if not NAME_RE.match(t):
        return False
    letters = [c for c in t if c.isalpha()]
    if not letters:
        return False
    up = sum(1 for c in letters if c.isupper())
    return up == len(letters) or up == 0


def _is_num_list(v: str) -> bool:
    parts = _parts(v)
    return bool(parts) and all(_num(p) is not None for p in parts)


def _is_name_list(v: str) -> bool:
    parts = _parts(v)
    return bool(parts) and all(_name_ok(p) for p in parts)


def _is_num_col(rows, ci: int) -> tuple[bool, int]:
    vals = [v for v in _col_texts(rows, ci) if v]
    if len(vals) < 4:
        return False, 0
    ok = sum(len(_parts(v)) for v in vals if _is_num_list(v))
    return (sum(1 for v in vals if _is_num_list(v)) / len(vals)) >= 0.5, ok


def _is_name_col(rows, ci: int) -> bool:
    vals = [v for v in _col_texts(rows, ci) if v]
    if len(vals) < 4:
        return False
    ok = sum(1 for v in vals if _is_name_list(v))
    return (ok / len(vals)) >= 0.5


def _table_rows(t, spans) -> tuple[list[list[str | None]], list[float]]:
    """把一个 find_tables 表填成文本矩阵；返回 (矩阵, 列边界)。"""
    edges: set[float] = set()
    for row in t.rows:
        for c in row.cells:
            if c:
                edges.add(round(float(c[0]), 1))
                edges.add(round(float(c[2]), 1))
    cols = sorted(edges)
    mat: list[list[str | None]] = []
    for row in t.rows:
        cells = list(row.cells)
        line: list[str | None] = []
        for c in cells:
            line.append(_cell_text(spans, c) if c else "")
        # 列数可能因合并单元格与 edges 不一致：按 bbox 宽度归位
        if len(line) != len(cols) - 1:
            line2: list[str | None] = [""] * (len(cols) - 1)
            for c, txt in zip(cells, line):
                if not c:
                    continue
                ci = _edge_index(cols, float(c[0]))
                if ci is not None:
                    line2[ci] = ((line2[ci] or "") + " " + (txt or "")).strip()
            line = line2
        mat.append(line)
    return mat, cols


def _edge_index(cols: list[float], x: float) -> int | None:
    for i, v in enumerate(cols[:-1]):
        if abs(v - x) <= 2.5:
            return i
    # 落在某一列内部（合并单元格）
    for i in range(len(cols) - 1):
        if cols[i] - 2.5 <= x < cols[i + 1] - 2.5:
            return i
    return None


def _rows_from_table(mat: list[list[str | None]]) -> list[dict]:
    """从文本矩阵认列角色，按「并列列表」配对取 (pin, name, description)。

    TI 引脚表的一行常是：NAME=`OUTB_0+, OUTB_0-, …`、NUMBER=`1, 2, …`，
    两个单元格的**顺序一一对应**（不是并行子表）。所以配对规则是
    「按逗号切分后 zip」，长度不等就跳过该行——绝不按极性重排去凑。
    """
    if not mat:
        return []
    width = max(len(r) for r in mat)
    mat = [r + [""] * (width - len(r)) for r in mat]
    head = " ".join((c or "") for r in mat[:2] for c in r)
    if NOT_PIN.search(head) or not PIN_HEADER.search(head):
        return []
    num_cols = [ci for ci in range(width) if _is_num_col(mat, ci)[0]]
    if not num_cols:
        return []
    name_cols = [ci for ci in range(width) if _is_name_col(mat, ci)]
    if not name_cols:
        return []
    out: list[dict] = []
    for nci in num_cols:
        # 名字列取最靠近脚号列左侧的那一列（TI 版式：PIN NAME | PIN NUMBER）
        lefts = [c for c in name_cols if c < nci]
        nci_name = max(lefts) if lefts else min(name_cols)
        # 描述列取脚号列右侧最宽的一列（通常是最后一列）
        descs = [c for c in range(nci + 1, width) if c not in num_cols]
        nci_desc = descs[-1] if descs else None
        for r in mat:
            nums = _parts(r[nci])
            names = [_norm(p).replace(" ", "") for p in _parts(r[nci_name])]
            if not nums or not names:
                continue
            pins = [_num(n) for n in nums]
            if any(p is None for p in pins):
                continue
            if len(pins) != len(names):
                # 一个名字挂多个脚是合法版式（VDD → 9,14,36,41,51），可以广播；
                # 但 `AD0-AD3` 这种**区间写法**不行：它代表 4 个不同名字，
                # 而脚号列是倒序（54,53,47,46），扩展开就是凭猜定顺序——直接跳过。
                if len(names) == 1 and not _RANGE_LIKE.search(names[0]):
                    names = names * len(pins)
                else:
                    continue
            if not all(_name_ok(n) for n in names):
                continue
            desc = _norm(r[nci_desc]) if nci_desc is not None else ""
            for pin, name in zip(pins, names):
                out.append({"pin": int(pin), "name": name,
                            "description": desc[:200]})
    return out


# ---------------------------------------------------------------- 入口
def extract(pdf_path: str | Path, *, max_pages: int = 60,
            max_table_pages: int = 4) -> dict:
    """抽引脚表，返回视觉顺序的 rows。

    `rejected` 说明拒绝原因，调用方据此决定交人工还是重试：
      pdf_missing / no_pymupdf / no_heading / no_table / too_few_rows
    """
    p = Path(str(pdf_path or ""))
    if not p.is_file():
        return {"ok": False, "rows": [], "rejected": "pdf_missing"}
    mod = _open()
    if mod is None:
        return {"ok": False, "rows": [], "rejected": "no_pymupdf"}

    pages_hit: list[int] = []
    all_rows: list[dict] = []
    tables = 0
    try:
        with mod.open(str(p)) as doc:
            n = min(len(doc), max_pages)
            idx = []
            for i in range(n):
                try:
                    if HEADING.search(doc[i].get_text("text") or ""):
                        idx.append(i)
                except Exception:                                # noqa: BLE001
                    continue
            if not idx:
                return {"ok": False, "rows": [], "rejected": "no_heading"}
            # 标题页起，往后连续抽（表常跨页）；连续 2 页没有表就停
            start = idx[0]
            empty = 0
            for i in range(start, min(n, start + max_table_pages + 2)):
                if len(pages_hit) >= max_table_pages:
                    break
                try:
                    tf = doc[i].find_tables()
                    tabs = list(tf.tables)
                except Exception:                                # noqa: BLE001
                    tabs = []
                if not tabs:
                    empty += 1
                    if empty >= 2 and pages_hit:
                        break
                    continue
                spans = _page_spans(doc[i])
                got: list[dict] = []
                for t in tabs:
                    tables += 1
                    mat, _cols = _table_rows(t, spans)
                    got.extend(_rows_from_table(mat))
                if len(got) < 6:
                    empty += 1
                    if empty >= 2 and pages_hit:
                        break
                    continue
                empty = 0
                pages_hit.append(i)
                all_rows.extend(got)
    except Exception as e:                                       # noqa: BLE001
        if not all_rows:
            return {"ok": False, "rows": [], "rejected": f"open_failed:{type(e).__name__}"}

    if not all_rows:
        return {"ok": False, "rows": [], "rejected": "no_table"}
    # 跨页去重：同脚号只留第一次（后续页是续表重叠）
    seen: dict[int, dict] = {}
    for r in all_rows:
        seen.setdefault(r["pin"], r)
    rows = [seen[k] for k in sorted(seen)]
    if len(rows) < 8:
        return {"ok": False, "rows": rows, "rejected": "too_few_rows:%d" % len(rows)}
    return {"ok": True, "rows": rows, "pages": [i + 1 for i in pages_hit],
            "tables": tables, "rejected": ""}


# ---------------------------------------------------------------- 结构断言
PAIR_NAME = re.compile(r"^([A-Za-z]{2,6})_?(\d{1,2})([+-])$")


def assert_interleaved(rows: list[dict]) -> list[str]:
    """差分对结构断言：同 bank 的 P/N 在表里必须**交错**，不能先 P 后 N。

    这不是判「值对不对」（那要证据卡），而是判**顺序合理性**：
    厂商表按脚号排，同一通道 P/N 要么同号相邻（Δ=1），要么对称分布；
    「所有 + 都在前半、所有 - 都在后半」只可能来自按极性重排，直接判不可信。

    返回违规说明，空列表表示通过。
    """
    if not rows:
        return ["empty"]
    banks: dict[str, list[tuple[int, int, str]]] = {}
    for i, r in enumerate(rows):
        m = PAIR_NAME.match(_norm(r.get("name")))
        pin = r.get("pin")
        if m and isinstance(pin, int):
            banks.setdefault(m.group(1).upper(), []).append((pin, i, m.group(3)))
    bad: list[str] = []
    for bank, lst in banks.items():
        if len(lst) < 4 or len({s for _p, _i, s in lst}) < 2:
            continue
        pos = [i for _p, i, s in lst if s == "+"]
        neg = [i for _p, i, s in lst if s == "-"]
        if not pos or not neg:
            continue
        if max(pos) < min(neg):
            bad.append("%s: 视觉顺序先 + 后 -（疑似按极性重排）" % bank)
        elif max(neg) < min(pos):
            bad.append("%s: 视觉顺序先 - 后 +（疑似按极性重排）" % bank)
    return bad
