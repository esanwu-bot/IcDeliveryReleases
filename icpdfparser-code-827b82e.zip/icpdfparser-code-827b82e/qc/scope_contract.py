"""JSON 与 facts 共用的对象作用域契约；只归一显式字段，不推测商品身份。"""
from __future__ import annotations

import copy
import re
from typing import Any

BOARD_TYPES = ("evaluation_board", "development_kit")
SCOPE_TYPES = ("device", "board", "onboard_device", "subcircuit", "unresolved")
CONTRACT_VERSION = "1.0"
_BOARD_PACKAGE = re.compile(
    r"boosterpack|evaluation\s*(board|module|kit)|development\s*(board|kit)|"
    r"^module$|^board$|printed\s*circuit", re.I)
_NAMED_DEVICE = re.compile(r"\b[A-Z]{2,}[0-9]{3,}[A-Z0-9]*\b")
_EMPTY_TEMPERATURE = {"operating": "not_specified", "storage": "not_specified"}


def normalize_scope(value: Any) -> str:
    """返回规范 scope；旧 chip 映射为 device，缺失或非法值一律 unresolved。"""
    value = str(value or "").strip().lower()
    if value == "chip":
        value = "device"
    return value if value in SCOPE_TYPES else "unresolved"


def merge_quarantined(target: dict, key: str, value: Any) -> None:
    """合并隔离事实；完全相同的事实去重，标量冲突保留到 <key>_history。"""
    if value is None or value == "" or value == [] or value == {}:
        return
    if key not in target or target[key] in (None, "", [], {}):
        target[key] = copy.deepcopy(value)
    elif isinstance(target[key], list) and isinstance(value, list):
        for item in value:
            if item not in target[key]:
                target[key].append(copy.deepcopy(item))
    elif isinstance(target[key], dict) and isinstance(value, dict):
        for child, item in value.items():
            merge_quarantined(target[key], child, item)
    elif target[key] != value:
        history = target.setdefault(key + "_history", [])
        for item in (target[key], value):
            if item not in history:
                history.append(copy.deepcopy(item))


def _basic(doc: dict) -> dict:
    value = doc.get("basic_info", doc.get("basic"))
    return value if isinstance(value, dict) else {}


def _scope_values(doc: dict, bi: dict, specs: dict) -> list[tuple[str, Any]]:
    values = []
    for owner, prefix, keys in (
        (specs, "specs", ("scope", "device_scope")),
        (bi, "basic_info", ("datasheet_scope", "device_scope")),
        (doc, "", ("datasheet_scope", "device_scope")),
    ):
        for key in keys:
            if key in owner:
                values.append((f"{prefix}.{key}".lstrip("."), owner[key]))
    return values


def _has_temperature(value: Any) -> bool:
    if isinstance(value, dict):
        return any(v not in (None, "", "not_specified", "unresolved") for v in value.values())
    return value not in (None, "", "not_specified", "unresolved")


def _row_scope(row: dict, default: str, requested: str) -> tuple[str, str, bool]:
    source = row.get("source") if isinstance(row.get("source"), dict) else {}
    scopes = [row[k] for k in ("scope", "device_scope") if k in row]
    if "scope" in source:
        scopes.append(source["scope"])
    # Phase 1.7.1 D3：`identity_scope` 给 thermal/esd 行标的 `subject` 是**行级
    # 主体证据**（onboard_device / board / ambiguous）。契约必须认它 —— 否则
    # 标注只写进 JSON、发布视图照样把芯片热阻当板级规格渲染（consumers 读的是
    # canonical_view，不是原 doc）。`ambiguous` 经 normalize_scope 落 unresolved。
    subj = str(row.get("subject") or "").strip()
    if subj:
        scopes.append(subj)
    normalized = {normalize_scope(v) for v in scopes}
    conflict = len(normalized) > 1
    scope = next(iter(normalized)) if len(normalized) == 1 else (
        "unresolved" if conflict else default)
    subject = str(row.get("subject_mpn") or source.get("subject_mpn") or "").strip()
    kind = str(row.get("subject_kind") or source.get("subject_kind") or "").lower()
    if not subject:
        match = _NAMED_DEVICE.search(str(row.get("condition") or ""))
        if match and match.group() != requested:
            subject = match.group()
    if subject and subject != requested and scope == "board":
        # 指南中具名器件的参数也不是整板限值。
        conflict = bool(scopes)
        scope = "onboard_device"
    if kind in ("chip", "device", "onboard_device") and scope == "board":
        scope, conflict = "onboard_device", True
    return scope, subject, conflict


def validate_contract(doc: dict) -> list[dict]:
    """只读校验，返回 [{path, kind, message}, ...]，包括已记录的迁移问题。"""
    findings: list[dict] = []

    def add(path: str, kind: str, message: str) -> None:
        item = {"path": path, "kind": kind, "message": message}
        if item not in findings:
            findings.append(item)

    if not isinstance(doc, dict):
        add("", "invalid_document", "输入必须是 JSON/facts 对象")
        return findings
    bi = _basic(doc)
    specs = doc.get("specs") if isinstance(doc.get("specs"), dict) else {}
    identity = bi.get("identity")
    if identity not in (*BOARD_TYPES, "chip", "device"):
        add("basic_info.identity", "unknown_identity", "商品身份缺失或未知，禁止裸工程表和引脚")
    if "basic_info" in doc and not isinstance(doc["basic_info"], dict):
        add("basic_info", "invalid_field", "basic_info 必须是对象")
    if "specs" not in doc or not isinstance(doc["specs"], dict):
        add("specs", "invalid_field", "specs 必须是对象")
    if isinstance(doc.get("basic"), dict) and isinstance(doc.get("basic_info"), dict):
        for key, value in doc["basic"].items():
            if key in bi and bi[key] != value:
                add("basic_info." + key, "alias_conflict", "basic 与权威 basic_info 冲突")
    values = _scope_values(doc, bi, specs)
    if not values or "scope" not in specs:
        add("specs.scope", "missing_scope", "规格 scope 缺失；旧别名仅可作为迁移输入")
    for path, value in values:
        if str(value or "").strip().lower() not in (*SCOPE_TYPES, "chip"):
            add(path, "invalid_scope", "非法 scope，必须进入 unresolved 隔离区")
    if len({normalize_scope(value) for _, value in values}) > 1:
        add("specs.scope", "scope_conflict", "规格 scope 与旧别名冲突，禁止主工程表")
    scope = normalize_scope(specs.get("scope"))
    if identity in BOARD_TYPES and scope == "board" and bi.get("document_scope") == "onboard_device_datasheet":
        add("specs.scope", "scope_conflict", "器件数据手册不能授予整板规格作用域")
    pkg = specs.get("package") if isinstance(specs.get("package"), dict) else {}
    device = str(bi.get("device_mpn") or "").strip()
    legacy_device = str(pkg.get("onboard_device") or "").strip()
    if device and legacy_device and device != legacy_device:
        add("specs.package.onboard_device", "device_conflict", "板载器件名与权威 basic_info.device_mpn 冲突")
    if identity in BOARD_TYPES and pkg.get("onboard_package"):
        if _BOARD_PACKAGE.search(str(pkg["onboard_package"])):
            add("specs.package.onboard_package", "package_conflict", "板卡形态不能作为板载芯片封装")
        if pkg.get("onboard_package_status") != "not_confirmed_as_mounted":
            add("specs.package.onboard_package_status", "unverified_mounting", "芯片封装选项未确认实际焊装")
    blocked = not ((identity in BOARD_TYPES and scope == "board") or (
        identity in ("chip", "device") and scope == "device"))
    if any(f["kind"] in ("scope_conflict", "alias_conflict") for f in findings):
        blocked = True
    for key in ("electrical", "absolute_max", "temperature"):
        value = specs.get(key)
        present = _has_temperature(value) if key == "temperature" else bool(value)
        if present and blocked:
            count = len(value) if isinstance(value, (list, dict)) else 1
            add("specs." + key, "quarantined_residual", f"{count} 项残留禁止作为主规格消费，保留到隔离区")
        if key != "temperature" and isinstance(value, list):
            for index, row in enumerate(value):
                if not isinstance(row, dict):
                    add(f"specs.{key}[{index}]", "invalid_row", "参数行必须是对象；保留为待核事实")
                    continue
                row_scope, subject, conflict = _row_scope(row, scope, str(bi.get("mpn") or ""))
                if conflict:
                    add(f"specs.{key}[{index}].scope", "row_scope_conflict", "逐行作用域/具名对象与表作用域冲突")
                if identity in BOARD_TYPES and (row_scope != "board" or subject and subject != bi.get("mpn")):
                    add(f"specs.{key}[{index}]", "row_quarantined", "非整板参数进入具名器件或待核隔离区")
    pins = doc.get("pin_configuration")
    pin_scope = doc.get("pin_scope")
    if pins and pin_scope is None:
        add("pin_scope", "missing_scope", "引脚归属缺失，禁止工程符号")
    elif pin_scope is not None and pin_scope not in (*SCOPE_TYPES, "chip", "board_no_pins", "unverified_dropped"):
        add("pin_scope", "invalid_scope", "引脚归属非法，必须隔离")
    if pins and (identity in BOARD_TYPES or identity not in ("chip", "device") or normalize_scope(pin_scope) != "device"):
        add("pin_configuration", "pins_quarantined", "引脚不属于已确认的主器件，引脚事实保留但不发布")
    metadata = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    for item in metadata.get("scope_contract_findings", []):
        if isinstance(item, dict) and all(k in item for k in ("path", "kind", "message")):
            add(item["path"], item["kind"], item["message"])
    return findings


def canonical_view(doc: dict) -> dict:
    """返回深拷贝发布视图；统一 basic_info/specs/pin_scope，隔离不洁主字段。

    主器件旁证保留在 specs.onboard_device_specs；具名次级器件位于其
    devices[MPN]；未知事实位于 specs.unresolved_specs。问题记录在
    metadata.scope_contract_findings。调用者不得再从原 doc 读取工程声明。
    """
    findings = validate_contract(doc)
    view = copy.deepcopy(doc) if isinstance(doc, dict) else {}
    bi = view.get("basic_info")
    if not isinstance(bi, dict):
        bi = copy.deepcopy(view.get("basic")) if isinstance(view.get("basic"), dict) else {}
        view["basic_info"] = bi
    elif isinstance(view.get("basic"), dict):
        for key, value in view["basic"].items():
            bi.setdefault(key, copy.deepcopy(value))
    if "basic" in view:
        if view["basic"] != bi:
            view.setdefault("contract_legacy", {})["basic"] = copy.deepcopy(view["basic"])
        view.pop("basic")
    specs = view.get("specs")
    if not isinstance(specs, dict):
        specs = view["specs"] = {}
    pkg = specs.get("package")
    if not isinstance(pkg, dict):
        pkg = specs["package"] = {}
    values = _scope_values(view, bi, specs)
    scopes = {normalize_scope(value) for _, value in values}
    scope = next(iter(scopes)) if len(scopes) == 1 else "unresolved"
    if any(f["path"] == "specs.scope" and f["kind"] == "scope_conflict" for f in findings):
        scope = "unresolved"
    identity = bi.get("identity")
    known = identity in (*BOARD_TYPES, "chip", "device")
    if not known or any(f["kind"] == "alias_conflict" for f in findings):
        scope = "unresolved"
    # 旧 scope 只作为一次迁移输入；保留原值，不让别名与发布值在二次调用时再冲突。
    legacy_scopes = [{"path": path, "value": value} for path, value in values
                     if path != "specs.scope" or value != scope]
    if legacy_scopes:
        merge_quarantined(view.setdefault("contract_legacy", {}), "scope_values", legacy_scopes)
    for owner, keys in ((specs, ("device_scope",)),
                        (bi, ("datasheet_scope", "device_scope")),
                        (view, ("datasheet_scope", "device_scope"))):
        for key in keys:
            owner.pop(key, None)
    specs["scope"] = scope
    device = str(bi.get("device_mpn") or pkg.get("onboard_device") or "").strip()
    if device and known:
        bi["device_mpn"] = device
        if pkg.get("onboard_device") and pkg["onboard_device"] != device:
            merge_quarantined(pkg, "onboard_device_history", [pkg["onboard_device"]])
        pkg["onboard_device"] = device

    def archive(key: str, value: Any, target_scope: str, subject: str = "") -> None:
        target_key = "onboard_device_specs" if target_scope in ("device", "onboard_device") and identity in BOARD_TYPES else "unresolved_specs"
        target = specs.setdefault(target_key, {})
        if not isinstance(target, dict):
            target = specs[target_key] = {"legacy": copy.deepcopy(target)}
        if target_key == "onboard_device_specs":
            if subject and subject != device:
                target = target.setdefault("devices", {}).setdefault(subject, {})
            target.setdefault("device_mpn", subject or device)
            target.setdefault("scope", "onboard_device")
        else:
            target.setdefault("scope", "unresolved")
        merge_quarantined(target, key, value)

    main_allowed = known and ((identity in BOARD_TYPES and scope == "board") or (identity in ("chip", "device") and scope == "device"))
    # `thermal` / `esd` 与 `electrical` / `absolute_max` 同口径：板卡件里
    # 判成 onboard_device 的行不能留在主容器（Phase 1.7.1 D3 的消费端闭环）。
    for key in ("electrical", "absolute_max", "thermal", "esd"):
        rows = specs.get(key) or []
        keep = []
        if not isinstance(rows, list):
            archive(key, rows, "unresolved")
        else:
            for row in rows:
                row_scope, subject, conflict = _row_scope(row, scope, str(bi.get("mpn") or "")) if isinstance(row, dict) else ("unresolved", "", True)
                allowed = main_allowed and not conflict and row_scope == scope and not (identity in BOARD_TYPES and subject and subject != bi.get("mpn"))
                if allowed:
                    keep.append(row)
                else:
                    if isinstance(row, dict) and subject:
                        row.setdefault("subject_mpn", subject)
                        if row_scope in ("device", "onboard_device"):
                            row.setdefault("subject_kind", "device")
                    archive(key, [row], row_scope, subject)
        specs[key] = keep
    if not main_allowed and _has_temperature(specs.get("temperature")):
        archive("temperature", specs["temperature"], scope)
    if not main_allowed:
        specs["temperature"] = copy.deepcopy(_EMPTY_TEMPERATURE)
    pins = view.get("pin_configuration") or []
    pin_scope = normalize_scope(view.get("pin_scope"))
    if pins and (identity in BOARD_TYPES or not known or pin_scope != "device"):
        archive("pin_configuration", pins, "onboard_device" if identity in BOARD_TYPES else "unresolved", device)
        view["pin_configuration"] = []
    # 归属由发布后剩余引脚决定，不由进入函数时的残留引脚决定。
    view["pin_scope"] = "board" if identity in BOARD_TYPES else (
        pin_scope if known else "unresolved")
    if identity in BOARD_TYPES:
        pkg["pins"] = 0
        if pkg.get("onboard_package"):
            if _BOARD_PACKAGE.search(str(pkg["onboard_package"])):
                archive("package", pkg.pop("onboard_package"), "unresolved")
            else:
                pkg["onboard_package_status"] = "not_confirmed_as_mounted"
        if pkg.get("onboard_dimensions"):
            pkg["onboard_dimensions_status"] = "not_confirmed_as_mounted"
    elif not known:
        empty_package = {"type": "", "pins": 0, "dimensions": ""}
        if pkg != empty_package:
            archive("package", pkg, "unresolved")
        specs["package"] = empty_package
    metadata = view.setdefault("metadata", {})
    metadata["scope_contract_version"] = CONTRACT_VERSION
    metadata["scope_contract_findings"] = findings
    return view
