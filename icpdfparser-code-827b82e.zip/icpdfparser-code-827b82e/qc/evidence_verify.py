"""batch-verify 服务端重校验（十项），单字段 verify 复用同一套检查。

逐行独立判定，允许部分成功。检查顺序：
  1 归属：行必须属于该证据卡
  2 状态：`ready`/`pending` 可批量（`verified`→already 幂等；conflict*/ambiguous/ocr_pending → 单件处置）
  3 reviewer 必须为空（机器草稿未经人工）
  4 page_number > 0
  5 evidence_quote 非空（≥2 字符）
  6 高风险（qc/high_risk）拒绝批量 → 原因码 `high_risk:*`
  7 SHA 一致：证据卡文档 pdf_sha256 与 gold_set.pdf_sha256 一致（有 Gold 时）
  8 **quote 回打**：归一化后必须命中原厂 PDF 指定页文本（PyMuPDF 字节级，防错页/防编造）
  9 数值三向：quote 数值与 Gold expected 数值无交集 → 转 conflict 单件流，不放行
 10 批量上限 BATCH_CAP

写库只写 `verification_status='verified' / reviewer / verified_at`；
台账 `source_verification_log` append-only（逐行一条 + 批次汇总一条）。

红线：批量**永不**碰高风险字段；quote 必须能在原厂 PDF 指定页命中（无 LLM/OCR）。

自包含：不 import qc.table_audit（它有 stdout 包装副作用），用 qc/goldset.py 的 locate。
import 零 stdout 副作用；dry=True 只出报告不写库。
"""
from __future__ import annotations

import datetime
import json
import re
import sys
import uuid
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

BATCH_CAP = 200
ALLOWED_BATCH_STATUS = {"pending", "ready", "ready_for_confirm"}
FIELD_COLS = ("candidates_json", "engine")          # 迁移用（幂等）


def _now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _norm(s) -> str:
    return re.sub(r"\s+", "", str(s or "")).lower()


def _nums(s) -> set:
    return {t.replace(",", "") for t in re.findall(r"\d+(?:[.,]\d+)?", str(s or ""))}


# ---------------------------------------------------------------- 迁移
def ensure_cols(dbm=None) -> None:
    """补 source_evidence.precheck_json / source_field_evidence.candidates_json、engine（幂等）。"""
    d = _db(dbm)
    for tbl, col, typ in (("source_evidence", "precheck_json", "TEXT NOT NULL DEFAULT ''"),
                          ("source_field_evidence", "candidates_json", "TEXT NOT NULL DEFAULT ''"),
                          ("source_field_evidence", "engine",
                           "TEXT NOT NULL DEFAULT 'pymupdf'")):
        cols = {r["name"] for r in d.q(f"PRAGMA table_info({tbl})")}
        if col not in cols:
            d.x(f"ALTER TABLE {tbl} ADD COLUMN {col} {typ}")


def _db(dbm=None):
    if dbm is not None:
        return dbm
    from app import db as _dbm
    return _dbm


def _pdf_path(mpn: str):
    """证据 PDF 路径解析（可被测试 monkeypatch）。"""
    try:
        from qc import goldset
        loc = goldset.locate(mpn)
        return (loc or {}).get("pdf")
    except Exception:                                            # noqa: BLE001
        return None


# ---------------------------------------------------------------- 单项检查
def quote_on_page(pdf_path, page_no, quote) -> tuple[bool, str]:
    """quote 归一化后是否命中该页文本（PyMuPDF，字节级；无 OCR/LLM 参与）。"""
    import fitz
    with fitz.open(pdf_path) as dz:
        if not isinstance(page_no, int) or page_no < 1 or page_no > dz.page_count:
            return False, "page_out_of_range"
        ok = _norm(quote) in _norm(dz[page_no - 1].get_text())
    return ok, "quote_not_on_page"


def _card_ctx(db, ev_id: int) -> dict | None:
    ev = db.q1("SELECT * FROM source_evidence WHERE id=?", (ev_id,))
    if not ev:
        return None
    doc = db.q1("SELECT * FROM source_document WHERE id=?", (ev["document_id"],)) or {}
    gold = db.q1("SELECT id, pdf_sha256 FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1",
                 (ev["mpn"],)) or {}
    gsha = (gold.get("pdf_sha256") or "").strip()
    dsha = (doc.get("pdf_sha256") or "").strip()
    gold_fields = {}
    if gold.get("id"):
        for r in db.q("SELECT * FROM gold_field WHERE gold_id=?", (gold["id"],)):
            gold_fields[r["field_path"]] = r
    return {"ev": ev, "doc": doc, "sha_ok": (not gsha) or (dsha == gsha),
            "pdf": _pdf_path(ev["mpn"]), "gold_fields": gold_fields, "gold": gold}


def _check_row(row: dict, ctx: dict, allow_high_risk: bool = False) -> str | None:
    """返回 None=通过；否则原因码。"""
    from qc import high_risk as HR
    st = row.get("verification_status") or "pending"
    if st == "verified":
        return "already_verified"
    if allow_high_risk:
        if st not in ALLOWED_BATCH_STATUS | {"conflict"}:
            return f"status_{st}_blocked"
    elif st not in ALLOWED_BATCH_STATUS:
        return f"status_{st}_individual"
    if (row.get("reviewer") or "").strip():
        return "already_human_acted"
    pg = row.get("page_number") or 0
    if int(pg) <= 0:
        return "page_missing"
    quote = (row.get("evidence_quote") or "").strip()
    if len(quote) < 2:
        return "quote_missing"
    gf = ctx["gold_fields"].get(row.get("field_path")) or {}
    codes = HR.classify(row.get("field_path", ""), gf.get("field_name") or "",
                        gf.get("unit") or "", draft_name=gf.get("expected") or "",
                        draft_desc=gf.get("cond") or "")
    if codes and not allow_high_risk:
        return "high_risk:" + ",".join(codes)
    if allow_high_risk and codes and not re.search(r"[^\W\d_]", quote):
        # 高风险证据必须是原文摘录；裸数字（"8"/"±4"）无法证明行归属，不得当 quote
        return "quote_numeric_only"
    if not ctx["sha_ok"]:
        return "sha_mismatch_gold"
    pdf = ctx.get("pdf")
    if not pdf or not Path(pdf).exists():
        return "pdf_missing"
    ok, why = quote_on_page(pdf, int(pg), quote)
    if not ok:
        return why
    exp = (gf.get("expected") or "").strip()
    if exp and exp.lower() != "not_specified":
        en, qn = _nums(exp), _nums(quote)
        if en and qn and not (en & qn):
            return "quote_vs_expected_mismatch"
    return None


# ---------------------------------------------------------------- 批量 / 单件
def batch_verify(db, ev_id: int, field_ids, reviewer: str, dry: bool = False) -> dict:
    ensure_cols(db)
    ctx = _card_ctx(db, ev_id)
    if not ctx:
        return {"error": "evidence_not_found"}
    batch_id = uuid.uuid4().hex[:8]
    rep = {"ev_id": ev_id, "batch_id": batch_id, "reviewer": reviewer, "dry": bool(dry),
           "verified": [], "already": [], "rejected": []}
    ids = list(dict.fromkeys(int(i) for i in (field_ids or [])))
    if not ids:
        return {**rep, "error": "field_ids_empty"}
    if len(ids) > BATCH_CAP:
        rep["rejected"] = [{"id": i, "field_path": None,
                            "reason": "batch_cap_exceeded"} for i in ids]
        return rep
    ph = ",".join("?" * len(ids))
    rows = {r["id"]: r for r in db.q(
        f"SELECT * FROM source_field_evidence WHERE evidence_id=? AND id IN ({ph})",
        (ev_id, *ids))}
    for rid in ids:
        row = rows.get(rid)
        if row is None:
            rep["rejected"].append({"id": rid, "field_path": None,
                                    "reason": "not_in_this_card"})
            continue
        why = _check_row(row, ctx, allow_high_risk=False)
        if why == "already_verified":
            rep["already"].append({"id": rid, "field_path": row["field_path"]})
            continue
        if why:
            rep["rejected"].append({"id": rid, "field_path": row["field_path"], "reason": why})
            continue
        if not dry:
            db.x("UPDATE source_field_evidence SET verification_status='verified', reviewer=?,"
                 "verified_at=? WHERE id=?", (reviewer, _now(), rid))
            _sync_gold(db, row, reviewer)
            _log(db, ev_id, reviewer, "field_verify_batch",
                 f"batch={batch_id} field={row['field_path']} page={row['page_number']}")
        rep["verified"].append({"id": rid, "field_path": row["field_path"]})
    if not dry:
        _log(db, ev_id, reviewer, "batch_verify",
             f"batch={batch_id} verified={len(rep['verified'])} "
             f"rejected={len(rep['rejected'])} already={len(rep['already'])}")
    return rep


def verify_one(db, field_evidence_id: int, reviewer: str, dry: bool = False,
               page_number: int | None = None, evidence_quote: str | None = None) -> dict:
    """单字段核验：**放行高风险**（quote 必填），其余检查同批量。

    `page_number` / `evidence_quote` 非空时先更新该行（**人工填证据**，属人工动作），
    再走同一套十项校验——这样 A 组弹窗可以「预填 E3 候选 → 人工确认/微调 → 核验」。
    """
    ensure_cols(db)
    row = db.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    if not row:
        return {"error": "field_not_found"}
    if not dry and (page_number or evidence_quote):
        sets, args = [], []
        if page_number:
            sets.append("page_number=?"); args.append(int(page_number))
        if evidence_quote is not None:
            sets.append("evidence_quote=?"); args.append(str(evidence_quote))
        args.append(field_evidence_id)
        db.x(f"UPDATE source_field_evidence SET {', '.join(sets)} WHERE id=?", args)
        row = db.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    ctx = _card_ctx(db, row["evidence_id"])
    if not ctx:
        return {"error": "evidence_not_found"}
    why = _check_row(row, ctx, allow_high_risk=True)
    if why == "already_verified":
        return {"already": True, "field_path": row["field_path"]}
    if why:
        return {"rejected": True, "field_path": row["field_path"], "reason": why,
                "page_number": row.get("page_number"),
                "evidence_quote": (row.get("evidence_quote") or "")[:80]}
    if not dry:
        db.x("UPDATE source_field_evidence SET verification_status='verified', reviewer=?,"
             "verified_at=? WHERE id=?", (reviewer, _now(), field_evidence_id))
        _sync_gold(db, row, reviewer)
        _log(db, row["evidence_id"], reviewer, "field_verify",
             f"field={row['field_path']} page={row['page_number']} high_risk=allowed")
    return {"verified": True, "field_path": row["field_path"]}


def field_candidates(db, field_evidence_id: int) -> dict | None:
    """E3 候选（top-1 预填用）：返回当前值 + 候选列表，供 A 组核验弹窗。"""
    row = db.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    if not row:
        return None
    ev = db.q1("SELECT mpn FROM source_evidence WHERE id=?", (row["evidence_id"],))
    if not ev:
        return None
    try:
        cands = json.loads(row.get("candidates_json") or "[]")
    except Exception:                                            # noqa: BLE001
        cands = []
    gold = db.q1("SELECT id FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (ev["mpn"],))
    gf = (db.q1("SELECT expected, unit, field_name FROM gold_field WHERE gold_id=? "
                "AND field_path=?", (gold["id"], row["field_path"]))
          if gold else None) or {}
    return {"field_id": field_evidence_id, "evidence_id": row["evidence_id"],
            "field_path": row["field_path"],
            "status": row.get("verification_status"),
            "current_page": row.get("page_number") or 0,
            "current_quote": row.get("evidence_quote") or "",
            "notes": row.get("notes") or "",
            "expected": gf.get("expected") or "", "unit": gf.get("unit") or "",
            "candidates": cands[:5], "top": cands[0] if cands else None,
            "engine": row.get("engine") or "pymupdf", "mpn": ev["mpn"]}


def mark_conflict(db, field_evidence_id: int, reason: str, reviewer: str) -> dict:
    """人工裁决：把该字段证据标为 `conflict` 并写明原因（append-only 留痕）。

    conflict ≠ verified：冻结守卫会因 `conflict*` 直接阻断，直到裁决完（改值/改状态）。
    """
    ensure_cols(db)
    if not str(reason or "").strip():
        raise ValueError("标记冲突必须写原因（审计要求）")
    row = db.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    if not row:
        return {"error": "field_not_found"}
    db.x("UPDATE source_field_evidence SET verification_status='conflict', notes=? WHERE id=?",
         (str(reason)[:500], field_evidence_id))
    _log(db, row["evidence_id"], reviewer, "field_conflict",
         f"field={row['field_path']} reason={str(reason)[:120]}")
    return {"ok": True, "field_path": row["field_path"], "status": "conflict"}


def resolve_conflict(db, field_evidence_id: int, action: str, reviewer: str,
                     expected: str | None = None, page_number: int | None = None,
                     evidence_quote: str | None = None, reason: str = "",
                     dry: bool = False) -> dict:
    """人工裁决 `conflict_draft`/`conflict`：把机器冲突落成明确结论，转 `ready` 后再核验。

    - `use_pdf`   ：Gold 草稿 expected 改成 PDF 真值，并先把页码/quote 写回证据行；
                    quote 必须先通过**原厂 PDF 回打**（防错页/防编造）；
    - `keep_gold` ：保留 Gold 值，只解除冲突（quote 原样留档，核验时仍走数值三向）。

    红线：**已冻结样本不改值**；裁决不写 reviewer（核验仍需单独动作，避免“裁决=通过”）；
    台账 `source_verification_log` append-only 记 old/new expected 与理由。
    """
    ensure_cols(db)
    if action not in ("use_pdf", "keep_gold"):
        raise ValueError("action 必须是 use_pdf 或 keep_gold")
    if not str(reason or "").strip():
        raise ValueError("裁决必须写理由（审计要求）")
    row = db.q1("SELECT * FROM source_field_evidence WHERE id=?", (field_evidence_id,))
    if not row:
        return {"error": "field_not_found"}
    st = row.get("verification_status") or ""
    if st not in ("conflict_draft", "conflict"):
        return {"error": "not_conflict", "status": st}
    ev = db.q1("SELECT * FROM source_evidence WHERE id=?", (row["evidence_id"],))
    if not ev:
        return {"error": "evidence_not_found"}
    gold = db.q1("SELECT * FROM gold_set WHERE mpn=? ORDER BY id DESC LIMIT 1", (ev["mpn"],))
    if gold and (gold.get("status") or "") == "frozen":
        return {"error": "gold_frozen"}
    if not gold:
        return {"error": "gold_missing"}
    gf = db.q1("SELECT * FROM gold_field WHERE gold_id=? AND field_path=?",
               (gold["id"], row["field_path"]))
    old_exp = (gf or {}).get("expected") or ""
    new_exp = old_exp
    if action == "use_pdf":
        new_exp = str(expected or "").strip()
        if not new_exp:
            raise ValueError("use_pdf 必须给出 PDF 真值（expected）")
        pg = int(page_number or 0)
        if pg <= 0:
            raise ValueError("use_pdf 必须给出 PDF 物理页码（>0）")
        q = str(evidence_quote or "").strip()
        if len(q) < 2:
            raise ValueError("use_pdf 必须给出原文 quote（≥2 字符）")
        pdf = _pdf_path(ev["mpn"])
        if not pdf or not Path(pdf).exists():
            return {"error": "pdf_missing"}
        ok, why = quote_on_page(pdf, pg, q)
        if not ok:
            return {"error": why}
    else:
        pg = int(row.get("page_number") or 0)
        q = (row.get("evidence_quote") or "").strip()
    rep = {"ok": True, "field_path": row["field_path"], "action": action,
           "old_expected": old_exp, "expected": new_exp, "status": "ready",
           "page_number": pg, "evidence_quote": q, "dry": bool(dry)}
    if dry:
        return rep
    if action == "use_pdf":
        if gf:
            db.x("UPDATE gold_field SET expected=? WHERE id=? AND status<>'frozen'",
                 (new_exp, gf["id"]))
        db.x("UPDATE source_field_evidence SET verification_status='ready', page_number=?,"
             "evidence_quote=?, notes=? WHERE id=?",
             (pg, q, str(reason)[:500], field_evidence_id))
    else:
        db.x("UPDATE source_field_evidence SET verification_status='ready', notes=? WHERE id=?",
             (str(reason)[:500], field_evidence_id))
    _log(db, row["evidence_id"], reviewer, f"field_resolve_{action}",
         f"field={row['field_path']} old={old_exp} new={new_exp} "
         f"page={pg} reason={str(reason)[:120]}")
    return rep


def _sync_gold(db, row: dict, reviewer: str) -> None:
    """绑定 Gold 字段时同步 verified（人工动作触发，非机器）。"""
    gid = int(row.get("gold_field_id") or 0)
    if not gid:
        return
    ev = " / ".join(x for x in (row.get("table_name"), row.get("row_key"),
                                row.get("column_key")) if x)
    db.x("UPDATE gold_field SET status='verified', page_no=?, evidence=?, verified_by=?,"
         "verified_at=? WHERE id=? AND status<>'conflict'",
         (int(row.get("page_number") or 0), ev, reviewer, _now(), gid))


def _log(db, ev_id: int, actor: str, action: str, detail: str) -> None:
    db.x("INSERT INTO source_verification_log(evidence_id,document_id,action,actor,"
         "old_status,new_status,details_json,created_at) VALUES(?,0,?,?,'','',?,?)",
         (ev_id, action, actor, detail[:500], _now()))


def list_high_risk(db, ev_id: int) -> list:
    ctx = _card_ctx(db, ev_id)
    if not ctx:
        return []
    from qc import high_risk as HR
    out = []
    for r in db.q("SELECT id, field_path, verification_status FROM source_field_evidence "
                  "WHERE evidence_id=?", (ev_id,)):
        gf = ctx["gold_fields"].get(r["field_path"]) or {}
        codes = HR.classify(r["field_path"], gf.get("field_name") or "", gf.get("unit") or "",
                            draft_name=gf.get("expected") or "", draft_desc=gf.get("cond") or "")
        if codes:
            out.append({"id": r["id"], "field_path": r["field_path"], "reasons": codes,
                        "text": HR.reason_text(codes),
                        "status": r["verification_status"]})
    return out


def batchable(db, ev_id: int) -> list:
    """可批量的行（非高风险且状态允许）——前端勾选默认集。"""
    ctx = _card_ctx(db, ev_id)
    if not ctx:
        return []
    hr_ids = {x["id"] for x in list_high_risk(db, ev_id)}
    return [r["id"] for r in db.q(
        "SELECT id, verification_status FROM source_field_evidence WHERE evidence_id=? "
        "AND verification_status IN ('pending','ready','ready_for_confirm')", (ev_id,))
        if r["id"] not in hr_ids]