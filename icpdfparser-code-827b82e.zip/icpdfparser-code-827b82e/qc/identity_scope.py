"""身份落库与保守的对象归一化；就地更新候选 JSON，不覆盖交付产物。

商品身份与文档证据分别判定。板卡尺寸留在主机械字段，芯片封装只记为
未确认焊装的选项；引脚、器件参数及新增残留合并到隔离区而非丢弃。
发布消费者应统一调用 qc.scope_contract.canonical_view。
"""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path
from typing import Any

from . import board_identity as BI
from .scope_contract import BOARD_TYPES, canonical_view, merge_quarantined, validate_contract

# 板卡形态的包装/封装词：出现在订货行里就当「这是板卡自己的订购行」。
# 只收**板卡专属**的说法；tray / bulk / bag / reel 是芯片的常见包装，
# 收进来会把 `ADS8568IPAG (64-LQFP, Tray)` 当成板卡行留在页面上。
_BOARD_PACK = re.compile(
    r"kit|box|board|module|boosterpack|evaluation|\beval\b",
    re.I)
# 板卡料号 token：出现在订货行 mpn 里，说明那一行是板卡而不是裸芯片
_BOARD_MPN_TOK = re.compile(
    r"(EVM|EVAL|EVK|EMK|EVB|BOOST|KIT|BOARD|MODULE|DONGLE|PDK|DEMO)", re.I)
# 板卡形态的封装名：symbol_svg / json_to_txt 的兜底判据
_BOARD_PKG_NAME = re.compile(
    r"boosterpack|evaluation\s*(board|module|kit)|development\s*(board|kit)|"
    r"^module$|^board$|printed\s*circuit", re.I)

FORM_TYPE = {"evaluation_board": "Evaluation Board",
             "development_kit": "Development Kit"}

# 板卡不能挂在 IC 分类下：`LMK04131EVAL/NOPB` 曾落在
# `Integrated Circuits (ICs) / Oscillators`，整页 SEO 与面包屑都跟着错。
_IC_CATEGORY = re.compile(r"integrated\s*circuit|semiconductor|discrete", re.I)
BOARD_CATEGORY = "Evaluation Boards & Kits"
BOARD_SUBCATEGORY = {"evaluation_board": "Evaluation Boards",
                     "development_kit": "Development Kits"}

# 芯片封装字眼：描述里出现就说明这段文字讲的是**板载器件**，不是这块板。
# 只收强特征，避免把「board」这种泛词当证据误删正常描述。
_CHIP_PKG_WORD = re.compile(
    r"\b[WVLQ]?QFN\b|\bTQFP\b|\bLQFP\b|\bSOIC\b|\bTSSOP\b|\bBGA\b|\bSON\b|"
    r"\bSOT-?\d|\bPDIP\b|\bDSBGA\b|\d+-?\s*(lead|pin)\b", re.I)

#: 芯片语义词：出现在 features / 多语描述里就说明这段文字讲的是板载器件。
#: 只用于**证据不足的板卡**（源 PDF 是芯片 datasheet），不会误伤 BOOST 的板级文案。
_CHIP_TEXT = re.compile(
    r"\bSNR\b|\bTHD\b|\bENOB\b|\bINL\b|\bDNL\b|\bVREF\b|\bkSPS\b|\bGSPS\b|"
    r"\bdBFS\b|\bppm\b|JESD204|\bresolution\b|\bSAR\b|\bADC\b|\bDAC\b|"
    r"\bnoise\s+floor\b|\d+\s*-?\s*bit\b", re.I)


# ---------------------------------------------------------------- 小工具
def _clean(s: Any) -> str:
    return str(s or "").strip()


def _guess_device(mpn: str) -> str:
    """从板卡料号推板上器件：只认 EVM/EVAL/EVK/EMK/PDK 这类**后缀**形态。

    `ADS8568EVM-PDK` -> `ADS8568`；`BOOST-DRV8711` -> 空（BOOST 是前缀，
    去掉后剩下的可能是板名而不是器件名，宁可留空让模板说 "the onboard device"，
    也不要写错器件名——用户报的正是「把评估板当成芯片」这类张冠李戴）。
    """
    body = BI.stem(mpn)
    m = re.match(r"^([A-Za-z]{2,}[0-9][A-Za-z0-9]{2,})(?:EVM|EVAL|EVK|EMK|PDK)",
                 body, re.I)
    if m:
        return m.group(1).upper()
    # BOOST-<PART>：BoosterPack 包的就是 <PART>（BOOST-DRV8711 -> DRV8711）。
    # 只认「字母 + 至少 3 位数字」的器件形状；BOOSTXL-C2KLED 这类是板名不是器件名，
    # 宁可留空让模板说 "the onboard device"，也不要写错器件。
    m = re.match(r"^BOOST-([A-Za-z]{2,4}[0-9]{3,}[A-Za-z0-9]*)$", body, re.I)
    return m.group(1).upper() if m else ""


def board_seo(mpn: str, mfr: str, device: str) -> dict:
    """板卡级 SEO：不继承芯片的 SNR / 分辨率 / 封装关键词。"""
    title = f"{mpn} Evaluation Board" + (f" | {device}" if device else "")
    desc = (f"{mpn} is a {mfr or 'manufacturer'} evaluation board"
            + (f" built around the onboard {device}" if device else "")
            + ". Board-level specifications are not stated in the source document; "
            "refer to the evaluation board user guide.")
    return {
        "title_en": title,
        "title_zh": f"{mpn} 评估板" + (f" | {device}" if device else ""),
        "meta_description_en": desc,
        "meta_description_zh": (f"{mpn} 是 {mfr or '原厂'} 的评估板"
                                + (f"，板上搭载 {device}" if device else "")
                                + "。板级规格请以评估板用户指南为准。"),
        "keywords": [mpn] + ([mfr] if mfr else []) + (["Evaluation Board"]
                     + ([device] if device else [])),
    }


def _board_placeholder_features(device: str) -> list:
    """证据不足时，主表 features 只能是板卡事实，不能留芯片卖点。"""
    return [f"Evaluation board for {device}" if device else "Evaluation board"]


def _is_evaluation_board_order_row(o: dict) -> bool:
    """按订购对象识别板卡；芯片封装不能推翻 EVM 料号证据。"""
    if not isinstance(o, dict):
        return False
    mpn = _clean(o.get("mpn"))
    if not mpn:
        return False
    if _BOARD_MPN_TOK.search(mpn):
        return True
    return any(_BOARD_PACK.search(_clean(o.get(key)))
               for key in ("packaging", "package"))


def _is_board_order_row(o: dict, req: str) -> bool:
    """这一条订购行是不是板卡可订购号（含请求板卡自身）。"""
    return isinstance(o, dict) and (
        BI.norm(_clean(o.get("mpn"))) == req or _is_evaluation_board_order_row(o))


# ---------------------------------------------------------------- 芯片语义剥离
def _strip_device_semantics(doc: dict, bi: dict, specs: dict, mpn: str,
                            mfr: str, device: str, pkg: dict, rep: dict) -> int:
    """板卡 PDF 只是**芯片数据手册**时，把芯片语义整体搬到 onboard_device_*。

    为什么不能只清封装/引脚：实测 `ADS8568EVM-PDK` 的
    `specs.electrical`（SNR 91.5 dB / THD -94 dB / -40~125°C）、`features`
    （12/14/16-bit 系列、±12 V 输入）、`applications`（保护继电器）、
    `alternatives`（ADS8528/ADS8548）、SEO、四语描述**全部**是板上 ADS8568
    的参数。只改壳子会产出「这是一块评估板，它的工作温区是 -40~125°C，
    典型应用是保护继电器」这种幻觉。

    保留 `onboard_device_specs` 是为了不丢事实：人工/审计仍能看到芯片真值，
    只是不再把它当成整板规格渲染。幂等：二次回填不会把占位 features 再搬一遍。
    """
    n = 0
    key = "onboard_device_specs" if device else "unresolved_specs"
    ods = specs.setdefault(key, {})
    if not isinstance(ods, dict):
        ods = specs[key] = {"legacy": copy.deepcopy(ods)}
    ods.setdefault("device_mpn", device)
    ods.setdefault("scope", "onboard_device" if device else "unresolved")
    ods.setdefault("source", bi.get("document_scope", "unresolved"))
    before = copy.deepcopy(ods)
    for k in ("electrical", "absolute_max", "temperature"):
        value = specs.get(k)
        if k == "temperature" and value == {"operating": "not_specified", "storage": "not_specified"}:
            continue
        merge_quarantined(ods, k, value)
    if pkg.get("onboard_package"):
        merge_quarantined(ods, "package", pkg["onboard_package"])
        ods["package_status"] = "not_confirmed_as_mounted"
    if pkg.get("onboard_dimensions"):
        merge_quarantined(ods, "dimensions", pkg["onboard_dimensions"])
        ods["dimensions_status"] = "not_confirmed_as_mounted"
    n += int(ods != before)
    # 主表一律清空/置哨兵：板级规格在源文档里没有，不能在页面上冒充整板限值
    specs["electrical"] = []
    specs["absolute_max"] = []
    specs["temperature"] = {"operating": "not_specified",
                            "storage": "not_specified"}

    # features / applications：芯片卖点搬到备份字段，主表只留板卡事实。
    # 幂等：占位文案本身不能再被当成「芯片卖点」搬一次。
    _feat_ph = _board_placeholder_features(device)
    _apps_ph = (["Device evaluation"] if device else ["Board evaluation"])
    feats = doc.get("features") or []
    if feats and feats != _feat_ph:
        merge_quarantined(doc, "onboard_device_features", list(feats))
        n += 1
    doc["features"] = _feat_ph
    apps = doc.get("applications") or []
    if apps and apps != _apps_ph:
        merge_quarantined(doc, "onboard_device_applications", list(apps))
        n += 1
    doc["applications"] = _apps_ph

    # 芯片替代料不能挂在板卡下（ADS8568EVM 的 ADS8528/ADS8548 是板上芯片的变体）
    if doc.get("alternatives"):
        merge_quarantined(doc, "onboard_device_alternatives", doc["alternatives"])
        n += 1
    doc["alternatives"] = []

    # SEO：芯片关键词（SNR / JESD204C / 封装）不能继续当板卡页的 meta
    seo = doc.get("seo")
    if isinstance(seo, dict) and seo:
        _seo_txt = json.dumps(seo, ensure_ascii=False)
        # 已经重写成板卡口径的 SEO 不再搬（幂等）；只有仍含芯片语义的才留档
        if "evaluation board" not in str(seo.get("title_en") or "").lower() \
                and _CHIP_TEXT.search(_seo_txt):
            merge_quarantined(doc, "onboard_device_seo", seo)
            rep["seo_rewritten"] = True
            n += 1
    doc["seo"] = board_seo(mpn, mfr, device)

    # 四语描述同理：只搬**含芯片语义**的键，纯板级译文保留。
    # （ADS8568 的 de/es/ja/ko 都写着 16-bit SAR ADC → 搬；纯 "Evaluationsboard
    # für Laboruntersuchungen" 不动。）
    ml = doc.get("multi_language")
    if isinstance(ml, dict) and ml:
        backup = doc.get("onboard_device_multi_language")
        backup = copy.deepcopy(backup) if isinstance(backup, dict) else {}
        for lg, blk in ml.items():
            if not isinstance(blk, dict):
                continue
            moved = {k: v for k, v in blk.items()
                     if isinstance(v, str) and _CHIP_TEXT.search(v)}
            if not moved:
                continue
            merge_quarantined(backup, lg, moved)
            for k in moved:
                blk.pop(k, None)
            n += 1
        if backup:
            doc["onboard_device_multi_language"] = backup

    # 数据手册链接是**芯片**的，不是这块板的；搬到 device_datasheet_url 留档
    if bi.get("datasheet_url") and not bi.get("device_datasheet_url"):
        bi["device_datasheet_url"] = bi["datasheet_url"]
    bi["datasheet_url"] = ""
    doc.setdefault("metadata", {})["board_scope_reason"] = (
        "缺少与请求号绑定的板卡用户指南标题证据；电气/温区/卖点/"
        "替代料/SEO 保留在隔离区，主字段标记为板级未规定")
    return n


def _stamp_row_subjects(doc: dict, document_scope: str) -> int:
    """给板卡 doc 的 `thermal` / `esd` 每一行标主体（**不搬容器**）。

    证据口径（与裁决表一致，只认能落到这一行来源的事实）：

    | 来源证据 | 主体 |
    |---|---|
    | `onboard_device_datasheet`（这份 PDF 是器件手册）| `onboard_device` |
    | `board_user_guide`（与请求号绑定的板卡 UG）| `board` |
    | 无法确认 | `ambiguous`（保留行、标待人工，**不自动归属**）|

    为什么不按参数名猜：`RθJA` 在板卡 UG 里也可能引用器件值，
    `HBM` 也可能指整板接口保护 —— 单看名字无法区分主体。一个 item 只有一份
    PDF，所以「这份文档是什么」才是可复算的证据。
    """
    scope = str(document_scope or "")
    subject = ("onboard_device" if scope == "onboard_device_datasheet"
               else "board" if scope == "board_user_guide"
               else "ambiguous")
    counts: dict[str, dict[str, int]] = {}
    for key in ("thermal", "esd"):
        rows = (doc.get("specs") or {}).get(key) or []
        per = counts.setdefault(key, {})
        for row in rows:
            if not isinstance(row, dict):
                continue
            # 上游显式给过主体就尊重它（同一份 doc 幂等重跑不会翻转）
            row.setdefault("subject", subject)
            row.setdefault("subject_source", scope or "unresolved")
            if row["subject"] == "ambiguous":
                row.setdefault("subject_review", "needs_human")
            per[row["subject"]] = per.get(row["subject"], 0) + 1
    if counts:
        doc.setdefault("specs", {})["subject_summary"] = counts
    return sum(sum(v.values()) for v in counts.values())


def _document_evidence(mpn: str, text: str, device: str) -> tuple[str, list[dict]]:
    """只接受首页标题附近的请求号，不把订货匹配或引用指南当作指南证据。"""
    head = (text or "")[:4000]
    parts = re.findall(r"[A-Za-z0-9]+", mpn)
    request = re.compile(r"(?<![A-Za-z0-9])" + r"[\s/\-–—_]*".join(
        re.escape(p) for p in parts) + r"(?![A-Za-z0-9])", re.I) if parts else None
    for match in re.finditer(r"(?im)^[^\n]{0,100}\buser[’']?s?\s+guide[^\n]{0,60}$", head):
        title = match.group().strip()
        if re.search(r"\b(see|refer|consult|available|described)\b", title, re.I):
            continue
        start, end = max(0, match.start() - 180), min(len(head), match.end() + 350)
        excerpt = head[start:end]
        if request and request.search(excerpt):
            return "board_user_guide", [{"kind": "board_guide_title", "requested_mpn": mpn,
                "title": title, "excerpt": excerpt, "start": start, "end": end}]
    if device and re.search(r"\b" + re.escape(device) + r"\b", head, re.I):
        return "onboard_device_datasheet", [{"kind": "device_document", "device_mpn": device,
            "excerpt": head[:600]}]
    return "unresolved", []


# ---------------------------------------------------------------- 主入口
def apply(doc: dict, mpn: str, pdf_text: str = "",
          pdf_path: str | Path | None = None) -> dict:
    """把身份结论写回 doc 并做板卡口径归一。**就地修改并返回报告**。

    幂等：同一份 doc 跑两次结果一致（不会把 onboard_package 再套一层）。
    """
    doc = doc if isinstance(doc, dict) else {}
    bi = doc.setdefault("basic_info", {})
    specs = doc.setdefault("specs", {})
    pkg = specs.setdefault("package", {})
    mpn = _clean(mpn) or _clean(bi.get("mpn"))

    # 判定必须看到**全部**可订购号，包括上一轮已经切到 onboard_ordering_info 的那些。
    # 否则同一份 doc 跑第二遍时订货表变短，`classify` 会从 REVIEW 掉到 INCOMPLETE，
    # 身份状态跟着翻——回填不幂等比不判还糟。
    _cls_doc = dict(doc)
    orders_for_identity = (list(doc.get("ordering_info") or [])
                           + list(doc.get("onboard_ordering_info") or []))
    # 关联 EVM 不是芯片订购变体；切分前后都不让它影响芯片身份和证据计数。
    _cls_doc["ordering_info"] = [o for o in orders_for_identity
        if not _is_evaluation_board_order_row(o)
        or BI.norm(_clean(o.get("mpn"))) == BI.norm(mpn)]
    info = BI.classify(mpn, _cls_doc, _clean(pkg.get("type")),
                       _clean(bi.get("manufacturer")), pdf_text=pdf_text or "")
    is_board = info["identity"] in BOARD_TYPES

    rep: dict = {"mpn": mpn, "identity": info["identity"], "state": info["state"],
                 "rule_id": info["rule_id"], "confidence": info["confidence"],
                 "device_mpn": "", "package_moved": False, "category_fixed": False,
                 "description_rewritten": False, "multilang_desc_cleared": 0,
                 "ordering_split": 0, "pins_dropped": 0, "pins_scope": "",
                 "scope_state": "", "semantic_stripped": 0, "seo_rewritten": False}

    # ---- 1. 落身份（芯片也写，下游才能区分「判过」与「没判」）
    bi["identity"] = info["identity"]
    bi["identity_state"] = info["state"]
    bi["identity_rule"] = info["rule_id"]
    bi["identity_confidence"] = info["confidence"]
    bi["identity_evidence"] = list(info["evidence"])

    conflicts = [f for f in validate_contract(doc)
                 if f["kind"] in ("device_conflict", "scope_conflict", "alias_conflict")]
    if conflicts:
        merge_quarantined(doc.setdefault("metadata", {}), "scope_contract_findings", conflicts)
    if not is_board:
        keep = []
        related = []
        for row in doc.get("ordering_info") or []:
            if not _is_evaluation_board_order_row(row):
                keep.append(row)
                continue
            board = copy.deepcopy(row)
            board["original_ordering_row"] = copy.deepcopy(row)
            board.pop("package", None)
            board.pop("packaging", None)
            board["scope"] = "board"
            board["subject_kind"] = "evaluation_board"
            board["scope_reason"] = "评估板订购对象不是芯片封装/包装变体；原订购行保留供核验"
            if not board.get("source"):
                board["source"] = {"field": "ordering_info", "requested_mpn": mpn}
                if pdf_path:
                    board["source"]["pdf_path"] = str(pdf_path)
            related.append(board)
        if related:
            merge_quarantined(doc, "related_evaluation_boards", related)
            rep["ordering_split"] = len(related)
        doc["ordering_info"] = keep
        specs["scope"] = "device" if info["identity"] in ("chip", "device") else "unresolved"
        doc.setdefault("pin_scope", "device" if info["identity"] in ("chip", "device") else "unresolved")
        view = canonical_view(doc)
        doc.clear()
        doc.update(view)
        rep["pins_scope"] = doc["pin_scope"]
        rep["scope_state"] = doc["specs"]["scope"]
        rep["findings"] = validate_contract(doc)
        return rep

    # ---- 2. 板载器件：订货表反推 > 料号剥离 > 留空
    #
    # 订货表反推只有在「表里存在**别的**可订购号」时才可信。BOOSTXL-C2KLED 的
    # 订货表里唯一一行就是它自己，公共前缀 = 整个料号，family_root 会把
    # `BOOSTXLC2KLED` 截成 `BOOSTXLC2` 当器件名——这是纯噪声，必须挡掉。
    orders_norm = BI.orderables(doc)
    others = [o for o in orders_norm if o != BI.norm(mpn)]
    prev = _clean(bi.get("device_mpn"))
    device = (prev or _clean(pkg.get("onboard_device"))
              or (_clean(info.get("device_mpn")) if others else "")
              or _guess_device(mpn))
    if device:
        bi["device_mpn"] = device
        if pkg.get("onboard_device") and pkg["onboard_device"] != device:
            merge_quarantined(pkg, "onboard_device_history", [pkg["onboard_device"]])
        pkg["onboard_device"] = device
    rep["device_mpn"] = device

    # ---- 3. 机械字段按来源归属：板卡形态的尺寸留在 dimensions。
    cur = _clean(pkg.get("type"))
    if cur and not _BOARD_PKG_NAME.search(cur):
        merge_quarantined(pkg, "onboard_package", cur)
        if pkg.get("dimensions"):
            merge_quarantined(pkg, "onboard_dimensions", pkg["dimensions"])
        pkg["dimensions"] = ""
        rep["package_moved"] = True
    if pkg.get("onboard_package"):
        pkg["onboard_package_status"] = "not_confirmed_as_mounted"
    if pkg.get("onboard_dimensions"):
        pkg["onboard_dimensions_status"] = "not_confirmed_as_mounted"
    pkg["type"] = FORM_TYPE.get(info["identity"], "Evaluation Board")
    pkg["pins"] = 0
    pkg.setdefault("dimensions", "")

    # ---- 3a. 商品确认不授予指南身份；只信与请求号绑定的标题证据。
    document_scope, evidence = _document_evidence(mpn, pdf_text, device)
    guide = document_scope == "board_user_guide"
    bi["document_scope"] = document_scope
    bi["document_evidence"] = evidence
    mfr = _clean(bi.get("manufacturer")) or "the manufacturer"
    specs["scope"] = "board" if guide else "onboard_device" if device else "unresolved"
    rep["scope_state"] = document_scope
    if not guide:
        stripped = _strip_device_semantics(doc, bi, specs, mpn, mfr, device, pkg, rep)
        rep["semantic_stripped"] = stripped
    # ---- 3a-2. 字段级主体归属（Phase 1.7.1 D3）
    #
    # 只搬 `electrical / absolute_max` 是不够的：`thermal` / `esd` 仍留在主容器，
    # 消费者没法只凭容器位置判断一行属于板卡还是板载芯片。这里**不搬容器**，
    # 给每一行补最小的 provenance —— 主体 + 证据来源；判不出的标 ambiguous，
    # 保留行并交人工，绝不按参数名或数值猜。
    stamped = _stamp_row_subjects(doc, document_scope)
    rep["subject_stamped"] = stamped

    # ---- 3b. 分类归一：板卡不能挂在 IC 分类下
    cat = _clean(bi.get("category"))
    if cat and _IC_CATEGORY.search(cat):
        bi.setdefault("device_category", cat)
        bi.setdefault("device_subcategory", _clean(bi.get("subcategory")))
        bi["category"] = BOARD_CATEGORY
        bi["subcategory"] = BOARD_SUBCATEGORY.get(info["identity"], "Evaluation Boards")
        rep["category_fixed"] = True

    # ---- 3c. 描述归一：LLM 的 description 是照着**芯片**写的
    #
    # 实测 `ADS8568EVM-PDK`：描述原文「…is available in 64-pin VQFN and LQFP
    # packages」，页面 hero 第一句就说这块板是 64 脚 QFN 封装——正是用户报的
    # 「文档称该型号为 48-Lead WQFN 封装」。改成板卡口径，原文留在
    # `device_description` 供参考，不丢信息。
    desc = _clean(bi.get("description"))
    if not guide and desc and (not bi.get("device_description") or not desc.startswith(f"{mpn} is a ")):
        merge_quarantined(bi, "device_description", desc)
        mfr = _clean(bi.get("manufacturer")) or "the manufacturer"
        if device:
            # 不拼 subcategory：它的值五花八门（"Data Acquisition Converters" 是复数），
            # 拼进 "a {sub}" 会变成 "a data acquisition converters"。
            bi["description"] = (
                f"{mpn} is a {mfr} evaluation board assembled around the onboard {device}. "
                "It is intended for bench evaluation of that device; the board-level "
                "specifications are not stated in the source document, which describes "
                "the onboard device rather than the assembled board.")
        else:
            bi["description"] = (
                f"{mpn} is a {mfr} evaluation board. It is intended for bench evaluation of "
                "the devices assembled on it; refer to the board user guide for the schematic, "
                "the connector layout and the jumper defaults.")
        rep["description_rewritten"] = True

    # ---- 3d. 多语种描述同理：`multi_language.*.description` 会盖掉英文描述
    #
    # 渲染顺序是 `mle.get("description") or basic_info.description`，只改英文
    # 没用——日/德/西页面上照样印「64-pin VQFN 封装」。这里只搬**含芯片封装
    # 字眼**的那几条，没提到的（纯功能描述）保持原样。
    mle = doc.get("multi_language")
    if isinstance(mle, dict):
        for lang, blk in mle.items():
            if not isinstance(blk, dict):
                continue
            t = _clean(blk.get("description"))
            if t and _CHIP_PKG_WORD.search(t):
                blk.pop("description", None)
                merge_quarantined(bi, f"device_description_{lang}", t)
                rep["multilang_desc_cleared"] += 1

    # ---- 4. 订购表切分
    orders = doc.get("ordering_info") or []
    if orders:
        req = BI.norm(mpn)
        keep = [o for o in orders if _is_board_order_row(o, req)]
        drop = [o for o in orders if o not in keep]
        if drop:
            merge_quarantined(doc, "onboard_ordering_info", drop)
            rep["ordering_split"] = len(drop)
        doc["ordering_info"] = keep

    # ---- 5. 引脚闸门：板卡页**永远**不发布引脚表
    #
    # 引脚属于板上器件，不属于这块板。即便 PDF 里能定位到引脚表，把它放在
    # 板卡页上也会被当成「这块板的引脚」——客户反馈的「BGA 球号 1-15」就是
    # 这条链。引脚事实保留在 `specs.onboard_device_specs` / 原厂 PDF 里，
    # 板卡页只给封装与板载器件说明。
    pins = doc.get("pin_configuration") or []
    if pins:
        ods = specs.setdefault("onboard_device_specs", {})
        merge_quarantined(ods, "pin_configuration", pins)
        doc["pin_configuration"] = []
        doc["pin_scope"] = "unverified_dropped"
        doc.setdefault("metadata", {})["pin_scope_reason"] = (
            "板卡页不发布引脚表：引脚属于板载器件，不属于组装后的评估板；"
            "请以原厂用户指南/原理图为准")
        rep["pins_dropped"] = len(pins)
    else:
        doc.setdefault("pin_scope", "board_no_pins")
    # 指南里仍可能混有具名器件参数；按行裁决后再生成唯一发布契约。
    view = canonical_view(doc)
    doc.clear()
    doc.update(view)
    rep["pins_scope"] = doc["pin_scope"]
    rep["scope_state"] = doc["specs"]["scope"]
    rep["findings"] = validate_contract(doc)
    return rep


# ---------------------------------------------------------------- 回填 / CLI
def apply_file(json_path: str | Path, pdf_path: str | Path | None = None,
               dry_run: bool = False) -> dict:
    p = Path(json_path)
    doc = json.loads(p.read_text(encoding="utf-8"))
    text = ""
    if pdf_path and Path(str(pdf_path)).exists():
        try:
            import fitz                                        # noqa: PLC0415
            with fitz.open(str(pdf_path)) as dz:
                text = "\n".join(pg.get_text() for pg in dz)
        except Exception:                                      # noqa: BLE001
            text = ""
    rep = apply(doc, _clean((doc.get("basic_info") or {}).get("mpn")) or p.stem,
                pdf_text=text, pdf_path=pdf_path)
    if not dry_run:
        p.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return rep


def find_pdf(mpn: str, pdf_dir: str | Path = "data/pdfs") -> Path | None:
    d = Path(pdf_dir)
    if not d.is_dir():
        return None
    safe = mpn.replace("/", "_")
    for pat in (f"{safe}__*.pdf", f"{safe}.pdf", f"{safe}*.pdf"):
        hit = sorted(d.glob(pat))
        if hit:
            return hit[0]
    return None


def main() -> None:                                            # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser(description="回填 basic_info.identity 并归一板卡口径")
    ap.add_argument("--src", default="data/parsed")
    ap.add_argument("--pdf-dir", default="data/pdfs")
    ap.add_argument("--only", default="", help="型号子串过滤")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    files = sorted(Path(a.src).glob("*.json"))
    if a.only:
        files = [f for f in files if a.only.lower() in f.name.lower()]
    if not files:
        raise SystemExit(f"no json in {a.src}")

    agg = {"board": 0, "chip": 0, "other": 0, "pins_dropped": 0, "ordering_split": 0}
    for f in files:
        mpn = f.stem.split("__")[0].rsplit("_", 1)[0]
        try:
            rep = apply_file(f, find_pdf(mpn, a.pdf_dir), dry_run=a.dry_run)
        except Exception as e:                                 # noqa: BLE001
            print(f"{mpn:<30} ERROR {type(e).__name__}: {e}")
            continue
        k = "board" if rep["identity"] in BI.BOARD_TYPES else (
            "chip" if rep["identity"] == "chip" else "other")
        agg[k] += 1
        agg["pins_dropped"] += rep["pins_dropped"]
        agg["ordering_split"] += rep["ordering_split"]
        if k == "board" or rep["pins_dropped"]:
            print(f"{mpn:<30} {rep['identity']:<17} {rep['state']:<20} "
                  f"device={rep['device_mpn'] or '-':<14} "
                  f"pkg_moved={rep['package_moved']} ord_split={rep['ordering_split']} "
                  f"pins_dropped={rep['pins_dropped']}")
    print(f"\n合计 {len(files)} 件：板卡 {agg['board']} / 芯片 {agg['chip']} / 其它 {agg['other']}；"
          f"封装搬移 {agg['pins_dropped']} 件丢引脚、{agg['ordering_split']} 条订购行切到板载")
    print("（--dry-run 时不写盘）" if a.dry_run else "（已写盘）")


if __name__ == "__main__":                                     # pragma: no cover
    main()
