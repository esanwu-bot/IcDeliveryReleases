"""列塌缩隔离（2026-11-03 外审 V1，一票否决项）。

**为什么判了 `column_collapse` 还不够**：判据只影响**事实表结论**，
`specs.thermal` 里那批「只取第一列、没写封装条件」的行照样会被渲染到页面上。
外审的判词是「客户不可用」，不是「标注不足」—— 数据必须从正式容器里撤下来。

搬进 `specs.unresolved_column_collapse`：
  * 渲染层不认识这个桶，所以它**不会出现在页面上**；
  * 事实表按新桶去审，风险队列会逐行给出「列塌缩」原因；
  * 原始行（含 name / value / unit / source）原样保留，复核方翻包能看到
    我们扣下了什么、为什么扣 —— 删掉才是不可接受的。

宁可不印，也不印一个没有适用封装的裸数字：客户拿 `RθJA 66.8` 去算 TO-263
的结温，算出来是错的，而且页面上没有任何线索提示他错了。
"""
from __future__ import annotations

import json
from pathlib import Path

ISOLATION = "unresolved_column_collapse"


def detect(doc: dict, pdf_path: str | Path | None) -> list[dict]:
    """用审计器同一份判据（`table_audit.audit_column_collapse`）探测列塌缩。

    **不复用 `audit_json`**：那个函数会重写 `metadata.audit` / `metadata.verification`，
    在装配阶段调用会把解析期记录冲掉。这里只取它的一条结论。
    """
    if not pdf_path or not Path(str(pdf_path)).is_file():
        return []
    try:
        import pymupdf                                        # noqa: PLC0415
        from qc import table_audit as TA                      # noqa: PLC0415
    except ImportError:
        return []
    try:
        with pymupdf.open(str(pdf_path)) as fd:
            tables = TA.scan_tables(fd)
        return TA.audit_column_collapse(tables, doc.get("specs") or {})
    except Exception:                                          # noqa: BLE001
        # 探测失败不等于「没有塌缩」，但也不能因此阻断装配 —— 如实记一笔，
        # 由 `metadata.column_collapse.detect_error` 让复核方看见这个盲区。
        return [{"kind": "column_collapse_detect_error"}]


def quarantine(doc: dict) -> dict:
    """把 `metadata.column_collapse.containers` 里的行搬进隔离桶（就地修改）。

    幂等：桶里已经有行时只补 `metadata` 状态，不重复搬运。
    """
    meta = doc.setdefault("metadata", {})
    cc = meta.get("column_collapse") or {}
    if not cc.get("detected"):
        return {}
    specs = doc.setdefault("specs", {})
    bucket = specs.setdefault(ISOLATION, [])
    moved: list[dict] = []
    for container in cc.get("containers") or []:
        rows = specs.get(container) or []
        for r in rows:
            item = dict(r)
            item["quarantine_reason"] = (
                "column_collapse：源表有多个封装列，本条只取到第一列且未写封装条件 —— "
                "数值属于哪个封装无证据")
            item["quarantined_from"] = container
            bucket.append(item)
            moved.append(item)
        specs[container] = []
    state = {
        "detected": True,
        "isolation": ISOLATION,
        "containers": list(cc.get("containers") or []),
        "quarantined": len(moved),
        "tables": cc.get("tables") or [],
    }
    meta["column_collapse_state"] = state
    return state


def count(doc: dict) -> int:
    return len((doc.get("specs") or {}).get(ISOLATION) or [])


def main(argv: list[str] | None = None) -> int:
    """对单份 JSON 跑一遍探测 + 隔离，结果写回原文件（幂等）。"""
    import argparse
    ap = argparse.ArgumentParser(description="列塌缩探测与隔离")
    ap.add_argument("--json", required=True)
    ap.add_argument("--pdf", default="")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    p = Path(a.json)
    doc = json.loads(p.read_text(encoding="utf-8"))
    pdf = a.pdf or str((doc.get("metadata") or {}).get("pdf_path") or "")
    finds = detect(doc, pdf)
    real = [f for f in finds if f.get("kind") == "column_collapse"]
    if real:
        doc.setdefault("metadata", {})["column_collapse"] = {
            "detected": True,
            "containers": sorted({f["path"].split(".", 1)[-1] for f in real}),
            "tables": [f["table"] for f in real],
        }
    st = quarantine(doc)
    print(json.dumps({"finds": len(real), "state": st}, ensure_ascii=False, indent=2))
    if not a.dry_run and st:
        p.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
