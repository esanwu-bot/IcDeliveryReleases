#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qf_daily：按指定型号跑「review → 自动修复 → 复审 → 五语渲染 → 物化成批次」。

为什么需要它
------------
`worker/tasks.py` 的 review/fix 链是 Celery 投递（`dispatch.submit`），本地没有
Redis 时降级成后台线程池——顺序不可控，`fix_finalize` 投的重审会和 `render_item`
抢跑，复审读到旧 txt 就把「修好了」记成「修了仍不过」。这里把 submit 换成
**同进程 FIFO 队列并就地 drain**，一次跑完一条链：

    review(round1) → fix_dispatch → fix_apply → render → fix_finalize
                   → review(round2) → （必要时）fix_dispatch(round2) …

渲染只重生成详情页（en + ja/ko/de/es），**不重跑替代料/三视图**：
那些产物不在本次评审变量内，重跑还会触发目录 AI 排序（改 alts.json），
会让「修复前后」的对比混入无关差异。

用法
----
    python qc/rf_daily.py run --mpns LM317,AM26C32IDG4 [--batch rf-20261028-002]
    python qc/rf_daily.py run --mpns X --no-fix        # 只审不修
    python qc/rf_daily.py render --mpns X              # 只重渲染五语页面
    python qc/rf_daily.py package --mpns X --batch rf-20261028-002

产物：`data/qc/rf-YYYYMMDD-NNN/`（每型号一目录 + review/ + provenance + zip），
与 `d:\\...\\review_fix` 交付包同构；额外为每个型号补一份 `<stem>.html`
（`.txt` 的字节同源副本，便于直接双击预览）。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# 必须在 import worker.tasks 之前设置：避免跑满轮次后往 customer_feedback 建单
os.environ.setdefault("ICPDF_FIX_AUTO_PROMOTE", "0")

from app import config, db                       # noqa: E402
from qc import review_fix as RF                  # noqa: E402

BASE = ROOT / "data" / "qc"
LANGS = ("ja", "ko", "de", "es")

# 内部诊断态 → 面向交付的中文说明（**不是**状态标签，标签只看 P0/P1）
_OPEN_LABELS = {
    RF.FIXED_STILL_FAIL: "自动修复后复审仍阻断（P0 未清）",
    RF.FIXED_NOT_CONVERGED: "跑满轮次未收敛（已转人工）",
    RF.FIXED_UNVERIFIED: "修复后尚未重审（判定滞后）",
    RF.REVIEWED_NEEDS_FIX: "已 review，未自动修复",
    RF.REVIEWED_CLEAN: "已 review，无需修复",
    RF.NOT_REVIEWED: "未 review",
}


# ---------------------------------------------------------------- 渲染
def render_pages(mpn: str) -> dict:
    """按当天模板重渲染详情页：en（过 SEO 优化）+ ja/ko/de/es 变体。

    只重生成详情页文本，不碰 alts / symbols / seo.json——本次评审只关心
    文本层与多语言，替代料与三视图保持上一版，便于逐项对比。
    """
    import json_to_txt
    from app.services import parts, seo_image

    row = db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1",
                (mpn, mpn))
    if not row:
        return {"ok": False, "reason": "item_missing", "mpn": mpn}
    jp = config.resolve_artifact(row.get("json_path") or "", config.PARSED)
    if not jp.is_file():
        return {"ok": False, "reason": "json_missing", "mpn": mpn}
    doc = json.loads(jp.read_text(encoding="utf-8"))
    stem = parts.safe_name(row.get("mpn") or mpn)
    config.TXT.mkdir(parents=True, exist_ok=True)

    html = json_to_txt.render(doc)
    plan = seo_image.build(doc, row.get("mpn") or mpn)
    html = seo_image.optimize_html(html, plan)
    p = config.TXT / f"{stem}.txt"
    p.write_text(html, encoding="utf-8")

    written = {"en": str(p)}
    for lg in LANGS:
        out = config.TXT / f"{stem}.{lg}.txt"
        out.write_text(json_to_txt.render(doc, lg), encoding="utf-8")
        written[lg] = str(out)
    return {"ok": True, "mpn": mpn, "stem": stem, "pages": written,
            "bytes": {k: Path(v).stat().st_size for k, v in written.items()}}


# ---------------------------------------------------------------- 同步流水线
def _drain(queue: deque, max_steps: int = 200) -> list[dict]:
    """FIFO 就地 drain：保证 fix → render → 复审 的先后顺序。"""
    import worker.tasks as T

    done: list[dict] = []
    steps = 0
    while queue and steps < max_steps:
        steps += 1
        kind, args, kwargs = queue.popleft()
        fn = T.FUNCS.get(kind)
        if fn is None:
            done.append({"kind": kind, "error": "unknown_kind"})
            continue
        try:
            res = fn(*args, **kwargs)
            done.append({"kind": kind, "args": list(args), "result": res})
        except Exception as e:                                   # noqa: BLE001
            done.append({"kind": kind, "args": list(args),
                         "error": f"{type(e).__name__}: {e}"[:300]})
    if queue:
        done.append({"error": "queue_not_drained", "left": len(queue)})
    return done


def run_pipeline(mpns: list[str], auto_fix: bool = True) -> dict:
    """逐件跑 review → fix → 复审；渲染阶段用本模块的 render_pages 顶替。"""
    import worker.tasks as T
    from app.services import dispatch

    queue: deque = deque()
    real_submit = dispatch.submit

    def submit(kind, *args, **kwargs):
        queue.append((kind, args, kwargs))
        return {"mode": "sync", "task_id": "", "kind": kind}

    dispatch.submit = submit
    real_render = T.render_item

    def local_render(mpn_key: str) -> dict:
        out = render_pages(mpn_key)
        return {"ok": bool(out.get("ok")), "reason": out.get("reason", ""),
                "pages": list((out.get("pages") or {}).keys())}

    T.render_item = local_render
    T.FUNCS["render_item"] = local_render
    out = {}
    try:
        for mpn in mpns:
            queue.clear()
            first = render_pages(mpn)                 # 先出当天的页面，复审才有 5 语可查
            holder: dict = {"mpn": mpn, "render": first}
            if first.get("ok"):
                # 起点：round1 审查（内部会投 fix_dispatch）
                try:
                    holder["review1"] = T.review_item(mpn, 1, False, auto_fix=auto_fix)
                except Exception as e:                           # noqa: BLE001
                    holder["review1"] = {"ok": False,
                                         "error": f"{type(e).__name__}: {e}"[:300]}
                chain = _drain(queue)
                # 链跑完可能改了 JSON：页面必须与最终 JSON 对齐，再补一次渲染
                holder["render_final"] = render_pages(mpn)
                holder["chain"] = chain
            out[mpn] = holder
    finally:
        dispatch.submit = real_submit
        T.render_item = real_render
        T.FUNCS["render_item"] = real_render
    return out


def final_review(mpns: list[str]) -> dict:
    """链跑完后强制复算一次（写库 + 落报告），作为交付包里的权威判定。"""
    from app.services import review as RV

    out = {}
    for mpn in mpns:
        try:
            res = RV.run_review(db, mpn, data_dir=config.DATA,
                                out_dir=config.DATA / "qc" / "reviews",
                                write_db=True, operator="system:auto_fix",
                                force=True)
            out[mpn] = {"verdict": res.get("verdict"),
                        "rule": len(res.get("rule_findings") or []),
                        "llm": len(res.get("llm_findings") or []),
                        "kinds": sorted({f.get("kind") for f in
                                         (res.get("rule_findings") or []) +
                                         (res.get("llm_findings") or [])}),
                        "wall_s": res.get("wall_s"),
                        "tokens": (res.get("usage") or {}).get("total_tokens")}
        except RV.ReviewError as e:
            out[mpn] = {"error": f"{e.code}: {e.message}"}
    return out


# ---------------------------------------------------------------- 打包
def add_html_preview(batch_dir: Path) -> list[str]:
    """每型号目录补一份 `<stem>.html`（与 `.txt` 字节同源，便于直接预览）。

    同时把 html 记进该型号 provenance 的 files 清单——交付包里的
    「文件列表」必须与实际落盘一致，否则下游按清单核对会报缺件。
    """
    made = []
    for pdir in sorted(p for p in batch_dir.iterdir() if p.is_dir() and p.name != "review"):
        src = pdir / f"{pdir.name}.txt"
        if not src.is_file():
            continue
        dst = pdir / f"{pdir.name}.html"
        dst.write_bytes(src.read_bytes())
        made.append(dst.name)
        pv = pdir / f"{pdir.name}.provenance.json"
        if pv.is_file():
            try:
                d = json.loads(pv.read_text(encoding="utf-8"))
                files = set(d.get("files") or []) | {dst.name}
                d["files"] = sorted(files)
                d["note_html"] = ("`.html` 与 `.txt` 字节同源：`.txt` 沿用上一版命名，"
                                  "`.html` 便于浏览器直接打开")
                pv.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                              encoding="utf-8")
            except (OSError, json.JSONDecodeError):
                pass
    return made


def refresh_zip(batch_dir: Path) -> dict:
    """补完 `.html` 后重打 ZIP（否则包内缺文件，与目录对不上）。

    `_audit/` 下的 as-delivered 快照 zip 不再套进外层 zip：
    套娃会让包体积翻倍且解压后仍是 zip，审计时直接读目录里的原件即可。
    """
    import zipfile

    zp = batch_dir / RF.ZIP_NAME
    with zipfile.ZipFile(zp, "w") as zf:
        for f in sorted(batch_dir.rglob("*")):
            if not f.is_file() or f == zp:
                continue
            if f.suffix.lower() == ".zip" and f.parent.name == "_audit":
                continue
            comp = (zipfile.ZIP_STORED if f.suffix.lower() == ".pdf"
                    else zipfile.ZIP_DEFLATED)
            zf.write(f, str(f.relative_to(batch_dir)), compress_type=comp)
    return {"zip": zp.name, "bytes": zp.stat().st_size}


def package(mpns: list[str], batch: str = "") -> dict:
    """按真实复审推导打包：状态只来自 P0/P1，内部诊断态只作说明。"""
    rows = []
    for mpn in mpns:
        r = RF.derive(BASE, mpn)
        r["review_file"] = "review/%s.review.json" % RF.safe_stem(mpn)
        r["status_note"] = _OPEN_LABELS.get(r.get("internal") or "", "")
        rows.append(r)
    out = RF.build_batch(BASE, rows, batch=batch, data_dir=config.DATA, force=bool(batch))
    d = Path(out["path"])
    out["html_preview"] = add_html_preview(d) if d.is_dir() else []
    if d.is_dir():
        out.update(refresh_zip(d))                 # 补 html 后重打，保证包内与目录一致
    out["rows"] = [{k: r.get(k) for k in
                    ("mpn", "status_code", "status_label", "p0", "p1",
                     "incomplete_checks", "internal", "status_note",
                     "verdict_before", "verdict_after", "fixes", "round",
                     "fixed_at", "reviewed_at")}
                   for r in rows]
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="review→fix→复审→五语渲染→打包")
    ap.add_argument("cmd", choices=["run", "render", "review", "package"])
    ap.add_argument("--mpns", required=True, help="逗号分隔型号")
    ap.add_argument("--batch", default="")
    ap.add_argument("--no-fix", action="store_true", dest="no_fix")
    a = ap.parse_args(argv)
    mpns = [m.strip() for m in a.mpns.split(",") if m.strip()]

    if a.cmd == "render":
        for m in mpns:
            r = render_pages(m)
            print(m, "->", (r.get("bytes") if r.get("ok") else r.get("reason")))
        return 0
    if a.cmd == "review":
        print(json.dumps(final_review(mpns), ensure_ascii=False, indent=2))
        return 0
    if a.cmd == "package":
        out = package(mpns, a.batch)
        print(json.dumps({k: v for k, v in out.items() if k != "rows"},
                         ensure_ascii=False, indent=2))
        for r in out["rows"]:
            print("  ", r)
        return 0

    run = run_pipeline(mpns, auto_fix=not a.no_fix)
    for m, h in run.items():
        ch = h.get("chain") or []
        print("\n==", m, "| review1:", (h.get("review1") or {}).get("verdict"),
              "| chain steps:", len(ch))
        for step in ch:
            k = step.get("kind") or step.get("error")
            res = step.get("result") or {}
            brief = ""
            if isinstance(res, dict):
                for key in ("changed", "reason", "actions", "ready", "promoted",
                            "next", "verdict", "pages"):
                    if res.get(key):
                        brief = f"{key}={res[key]}"
                        break
            print("   -", k, brief, step.get("error") or "")
    print("\n== final review")
    fin = final_review(mpns)
    print(json.dumps(fin, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
