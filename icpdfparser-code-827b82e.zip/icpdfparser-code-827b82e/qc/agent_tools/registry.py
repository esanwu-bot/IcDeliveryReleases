"""QC Agent Tool 注册表。

设计要点：
1. 所有工具必须注册到 Registry，不允许任意代码执行
2. 每个工具有明确的权限（readonly/candidate_write/restricted_write/append_write）
3. 工具调用必须记录审计日志
4. 工具输入输出必须结构化，便于追踪和复现
"""
from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Callable

from app import db


class Permission(str, Enum):
    """工具权限等级。"""
    READONLY = "readonly"              # 只读，不改变任何数据
    CANDIDATE_WRITE = "candidate_write" # 生成候选补丁，不直接覆盖原数据
    RESTRICTED_WRITE = "restricted_write" # 受控写入，需要授权
    APPEND_WRITE = "append_write"      # 追加写入（审计日志等）


class ToolDefinition:
    """工具定义。"""
    
    def __init__(
        self,
        name: str,
        handler: Callable,
        permission: Permission,
        description: str = "",
        input_schema: dict = None,
        output_schema: dict = None,
        source: str = "",
    ):
        self.name = name
        self.handler = handler
        self.permission = permission
        self.description = description
        self.input_schema = input_schema or {}
        self.output_schema = output_schema or {}
        self.source = source
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "permission": self.permission.value,
            "description": self.description,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "source": self.source,
        }


class ToolRegistry:
    """工具注册表（单例）。"""
    
    _instance = None
    _tools: dict[str, ToolDefinition] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def register(self, tool: ToolDefinition):
        """注册工具。"""
        if tool.name in self._tools:
            raise ValueError(f"Tool {tool.name} already registered")
        self._tools[tool.name] = tool
    
    def get(self, name: str) -> ToolDefinition | None:
        """获取工具定义。"""
        return self._tools.get(name)
    
    def list_tools(self) -> list[dict]:
        """列出所有工具。"""
        return [tool.to_dict() for tool in self._tools.values()]
    
    def execute(
        self,
        tool_name: str,
        arguments: dict,
        task_id: str = None,
        user_id: str = "agent",
    ) -> dict:
        """执行工具，记录审计日志。"""
        tool = self.get(tool_name)
        if not tool:
            return {
                "status": "ERROR",
                "error": f"Unknown tool: {tool_name}",
            }
        
        # 生成工具调用 ID
        tool_call_id = str(uuid.uuid4())
        started_at = datetime.now()
        
        try:
            # 执行工具
            result = tool.handler(**arguments)
            
            # 记录审计日志
            finished_at = datetime.now()
            duration_ms = int((finished_at - started_at).total_seconds() * 1000)
            
            self._log_tool_event(
                tool_call_id=tool_call_id,
                task_id=task_id or "",
                step_no=0,  # 由调用方更新
                tool_name=tool_name,
                input_summary=arguments,
                output_summary=result,
                duration_ms=duration_ms,
                error="",
                user_id=user_id,
            )
            
            return result
            
        except Exception as e:
            # 记录错误
            finished_at = datetime.now()
            duration_ms = int((finished_at - started_at).total_seconds() * 1000)
            
            self._log_tool_event(
                tool_call_id=tool_call_id,
                task_id=task_id or "",
                step_no=0,
                tool_name=tool_name,
                input_summary=arguments,
                output_summary={},
                duration_ms=duration_ms,
                error=str(e),
                user_id=user_id,
            )
            
            return {
                "status": "ERROR",
                "error": str(e),
                "tool": tool_name,
            }
    
    def _log_tool_event(
        self,
        tool_call_id: str,
        task_id: str,
        step_no: int,
        tool_name: str,
        input_summary: dict,
        output_summary: dict,
        duration_ms: int,
        error: str,
        user_id: str,
    ):
        """记录工具调用事件到数据库。"""
        import json
        
        conn = db.conn()
        try:
            conn.execute(
                """
                INSERT INTO agent_tool_event
                (tool_call_id, task_id, step_no, tool_name, input_summary, output_summary,
                 duration_ms, error, idempotency_key, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    tool_call_id,
                    task_id,
                    step_no,
                    tool_name,
                    json.dumps(input_summary, ensure_ascii=False),
                    json.dumps(output_summary, ensure_ascii=False),
                    duration_ms,
                    error,
                    tool_call_id,  # 幂等键 = tool_call_id
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
        except Exception as e:
            print(f"[AgentLab] 记录工具事件失败: {e}")
        finally:
            pass


# 全局注册表实例
registry = ToolRegistry()


def register_tool(
    name: str,
    permission: Permission,
    description: str = "",
    input_schema: dict = None,
    output_schema: dict = None,
    source: str = "",
):
    """工具注册装饰器。"""
    def decorator(handler: Callable):
        tool = ToolDefinition(
            name=name,
            handler=handler,
            permission=permission,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
            source=source,
        )
        registry.register(tool)
        return handler
    return decorator
