"""qc.auto_qc - 运行既有自动检查（dry-run 模式）。

来源：qc/auto_qc.py
权限：只读
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from app import config
from qc.agent_tools.registry import register_tool, Permission


def _safe_key(mpn: str) -> str:
    """生成安全文件名。"""
    import re
    return re.sub(r'[^\w\-]', '_', mpn)


def _find_parsed_json(safe: str) -> Path | None:
    """查找解析 JSON 文件。"""
    data_dir = config.DATA
    parsed_dir = data_dir / "parsed"
    matches = list(parsed_dir.glob(f"{safe}_*.json"))
    return matches[0] if matches else None


@register_tool(
    name="qc.auto_qc",
    permission=Permission.READONLY,
    description="运行既有自动检查（dry-run 模式）",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "stages": {
                "type": "array",
                "items": {"type": "string"},
                "description": "检查阶段，默认全部",
            },
            "dry_run": {"type": "boolean", "default": True, "description": "是否只读模式"},
        },
        "required": ["mpn"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "findings": {"type": "array"},
            "total_findings": {"type": "integer"},
            "stages_run": {"type": "array"},
            "dry_run": {"type": "boolean"},
        },
    },
    source="qc/auto_qc.py",
)
def auto_qc(
    mpn: str,
    stages: list[str] = None,
    dry_run: bool = True,
) -> dict:
    """运行 auto_qc 检查，返回 findings（不写 ZIP）。"""
    from qc.auto_qc import check_item
    
    safe = _safe_key(mpn)
    json_file = _find_parsed_json(safe)
    
    if not json_file:
        return {
            "status": "NOT_FOUND",
            "mpn": mpn,
            "error": "Parsed JSON not found",
        }
    
    item = {
        "mpn": mpn,
        "safe_key": safe,
        "json_path": str(json_file),
        "pdf_sha256": "",
    }
    
    data_dir = config.DATA
    
    try:
        result = check_item(
            item=item,
            data_dir=data_dir,
            gold=None,
            hash_pdf=True,
            probe_pdf=False,
        )
        
        findings = result.get("findings", [])
        
        return {
            "status": "OK",
            "mpn": mpn,
            "findings": findings,
            "total_findings": len(findings),
            "stages_run": stages or ["r1", "r2", "r3", "r4", "r5", "r6"],
            "dry_run": dry_run,
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "mpn": mpn,
            "error": str(e),
            "findings": [],
            "total_findings": 0,
            "stages_run": [],
            "dry_run": dry_run,
        }
