"""qc.get_evidence - 查找问题字段对应的原始依据。

来源：qc/evidence_chain.py
权限：只读
"""
from __future__ import annotations

from datetime import datetime

from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.get_evidence",
    permission=Permission.READONLY,
    description="查找问题字段对应的原始依据",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "stages": {
                "type": "array",
                "items": {"type": "string", "enum": ["e1", "e2", "e3", "e4"]},
                "description": "证据链阶段，默认全部",
            },
            "dry": {"type": "boolean", "default": True, "description": "是否只读模式"},
        },
        "required": ["mpn"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "evidence": {"type": "object"},
            "dry": {"type": "boolean"},
        },
    },
    source="qc/evidence_chain.py",
)
def get_evidence(
    mpn: str,
    stages: list[str] = None,
    dry: bool = True,
) -> dict:
    """运行证据链查询（E1-E4），返回证据（默认 dry 模式不写表）。"""
    from qc.evidence_chain import run_all
    from app import db
    
    try:
        result = run_all(db=db, mpn=mpn, dry=dry)
        
        return {
            "status": "OK",
            "mpn": mpn,
            "evidence": result,
            "dry": dry,
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "mpn": mpn,
            "evidence": {},
            "dry": dry,
            "error": str(e),
        }
