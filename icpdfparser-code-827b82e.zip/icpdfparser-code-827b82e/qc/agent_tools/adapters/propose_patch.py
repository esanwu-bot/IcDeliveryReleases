"""qc.propose_patch - 生成字段级补丁，不直接覆盖原数据。

来源：worker/fixers.py
权限：候选写入
"""
from __future__ import annotations

import json
import uuid
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from app import config
from qc.agent_tools.registry import register_tool, Permission


def _safe_key(mpn: str) -> str:
    """生成安全文件名。"""
    import re
    return re.sub(r'[^\w\-]', '_', mpn)


def _find_parsed_json(safe: str) -> Path | None:
    """查找解析 JSON 文件。"""
    data_dir = config.DATA
    parsed_dir = data_dir / "parsed"
    matches = list(parsed_dir.glob(f"{safe}_*.json"))
    return matches[0] if matches else None


def _compute_json_hash(obj: dict) -> str:
    """计算 JSON 哈希。"""
    import hashlib
    content = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


@register_tool(
    name="qc.propose_patch",
    permission=Permission.CANDIDATE_WRITE,
    description="生成字段级补丁，不直接覆盖原数据",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "finding_id": {"type": "string", "description": "问题 ID"},
            "fixer_name": {"type": "string", "description": "修复器名称"},
            "target_fields": {
                "type": "array",
                "items": {"type": "string"},
                "description": "目标字段路径",
            },
            "mode": {"type": "string", "enum": ["dry_run", "apply"], "default": "dry_run"},
        },
        "required": ["mpn", "finding_id", "fixer_name", "target_fields"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "finding_id": {"type": "string"},
            "fixer_name": {"type": "string"},
            "patch": {"type": "object"},
            "candidate_snapshot_path": {"type": "string"},
            "validation": {"type": "object"},
            "requires_human_review": {"type": "boolean"},
            "mode": {"type": "string"},
        },
    },
    source="worker/fixers.py",
)
def propose_patch(
    mpn: str,
    finding_id: str,
    fixer_name: str,
    target_fields: list[str],
    mode: str = "dry_run",
) -> dict:
    """生成候选补丁（不直接覆盖原数据）。"""
    from worker.fixers import _FIXERS, preflight
    
    if fixer_name not in _FIXERS:
        return {
            "status": "ERROR",
            "error": f"Unknown fixer: {fixer_name}",
            "available_fixers": list(_FIXERS.keys()),
        }
    
    fixer_fn = _FIXERS[fixer_name]
    
    # 1. 预读：备份 + 载入
    ctx = preflight(mpn=mpn, data_dir=config.DATA)
    if not ctx["ok"]:
        return {
            "status": "ERROR",
            "error": ctx["error"],
        }
    
    # 2. 在隔离副本上运行 fixer
    candidate_doc = deepcopy(ctx["doc"])
    ctx["doc"] = candidate_doc
    ctx["allowed_paths"] = target_fields
    
    try:
        result = fixer_fn(ctx)
    except Exception as e:
        return {
            "status": "ERROR",
            "error": f"Fixer execution failed: {e}",
        }
    
    # 3. 保存候选快照
    data_dir = config.DATA
    candidate_dir = data_dir / "qc" / "agent_patches"
    candidate_dir.mkdir(parents=True, exist_ok=True)
    
    candidate_path = candidate_dir / f"{mpn}_{finding_id}_candidate.json"
    candidate_path.write_text(
        json.dumps(candidate_doc, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    
    # 4. 计算哈希
    previous_hash = _compute_json_hash(ctx["doc"])
    patch_hash = _compute_json_hash(candidate_doc)
    
    return {
        "status": "PATCH_PROPOSED",
        "mpn": mpn,
        "finding_id": finding_id,
        "fixer_name": fixer_name,
        "patch": {
            "changed_fields": result.get("changed", []),
            "note": result.get("note", ""),
            "previous_hash": previous_hash,
            "patch_hash": patch_hash,
        },
        "candidate_snapshot_path": str(candidate_path),
        "validation": {
            "schema": "PENDING",
            "electrical_semantics": "PENDING",
            "regression": "PENDING",
        },
        "requires_human_review": True,
        "mode": mode,
    }
