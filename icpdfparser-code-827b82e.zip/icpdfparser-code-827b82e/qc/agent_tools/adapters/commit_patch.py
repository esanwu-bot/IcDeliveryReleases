"""qc.commit_patch - 在授权后应用补丁并留存快照。

来源：受控数据写入流程
权限：受限写入
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from app import config, db
from qc.agent_tools.registry import register_tool, Permission


def _compute_json_hash(obj: dict) -> str:
    """计算 JSON 哈希。"""
    import hashlib
    content = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


def _get_current_json(mpn: str) -> dict:
    """获取当前解析 JSON。"""
    from qc.agent_tools.adapters.get_device_snapshot import _find_parsed_json, _safe_key
    
    safe = _safe_key(mpn)
    json_file = _find_parsed_json(safe)
    
    if not json_file:
        return {}
    
    return json.loads(json_file.read_text(encoding="utf-8"))


def _get_finding_by_id(finding_id: str) -> dict:
    """根据 finding_id 获取 finding。"""
    # 简化实现：从 agent_task 表中查找
    conn = db.conn()
    try:
        row = conn.execute(
            "SELECT context FROM agent_task WHERE task_id = ?",
            (finding_id,),
        ).fetchone()
        
        if row and row[0]:
            context = json.loads(row[0])
            return context.get("finding", {})
        
        return {}
    finally:
        pass


@register_tool(
    name="qc.commit_patch",
    permission=Permission.RESTRICTED_WRITE,
    description="在授权后应用补丁并留存快照",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "finding_id": {"type": "string", "description": "问题 ID"},
            "candidate_path": {"type": "string", "description": "候选补丁文件路径"},
            "authorization": {
                "type": "object",
                "properties": {
                    "authorized_by": {"type": "string"},
                    "authorization_reason": {"type": "string"},
                    "run_id": {"type": "string"},
                },
                "description": "授权信息",
            },
        },
        "required": ["mpn", "finding_id", "candidate_path", "authorization"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "finding_id": {"type": "string"},
            "backup_path": {"type": "string"},
            "applied_path": {"type": "string"},
            "patch_hash": {"type": "string"},
            "previous_hash": {"type": "string"},
            "audit_log_id": {"type": "integer"},
            "requires_recheck": {"type": "boolean"},
        },
    },
    source="受控数据写入流程",
)
def commit_patch(
    mpn: str,
    finding_id: str,
    candidate_path: str,
    authorization: dict,
) -> dict:
    """在授权后应用补丁并留存快照。"""
    from worker.fixers import preflight, commit
    
    # 1. 权限检查（P0 禁止自动解除阻断）
    finding = _get_finding_by_id(finding_id)
    severity = finding.get("severity", "P1")
    
    if severity == "P0":
        return {
            "status": "UNAUTHORIZED",
            "error": "P0 findings require human approval before patch application",
        }
    
    # 2. 载入候选补丁
    candidate_file = Path(candidate_path)
    if not candidate_file.exists():
        return {
            "status": "ERROR",
            "error": f"Candidate file not found: {candidate_path}",
        }
    
    try:
        candidate = json.loads(candidate_file.read_text(encoding="utf-8"))
    except Exception as e:
        return {
            "status": "ERROR",
            "error": f"Failed to read candidate file: {e}",
        }
    
    # 3. 计算哈希
    previous_hash = _compute_json_hash(_get_current_json(mpn))
    patch_hash = _compute_json_hash(candidate)
    
    # 4. 应用补丁（commit 会自动备份）
    data_dir = config.DATA
    ctx = preflight(mpn=mpn, data_dir=data_dir)
    
    if not ctx["ok"]:
        return {
            "status": "ERROR",
            "error": ctx["error"],
        }
    
    try:
        result = commit(ctx, candidate)
    except Exception as e:
        return {
            "status": "ERROR",
            "error": f"Commit failed: {e}",
        }
    
    if not result.get("ok"):
        return {
            "status": "ERROR",
            "error": result.get("error", "Unknown error"),
        }
    
    # 5. 记录审计日志
    audit_log_id = _audit_append(
        run_id=authorization.get("run_id", ""),
        mpn=mpn,
        kind="patch_applied",
        path=candidate_path,
        json_val={"finding_id": finding_id, "patch_hash": patch_hash},
        table_val=None,
        action="commit_patch",
        tool="qc.commit_patch",
        operator=authorization.get("authorized_by", "agent"),
    )
    
    return {
        "status": "PATCH_APPLIED",
        "mpn": mpn,
        "finding_id": finding_id,
        "backup_path": result.get("backup_path", ""),
        "applied_path": result.get("applied_path", ""),
        "patch_hash": patch_hash,
        "previous_hash": previous_hash,
        "audit_log_id": audit_log_id,
        "requires_recheck": True,
    }


def _audit_append(
    run_id: str,
    mpn: str,
    kind: str,
    path: str,
    json_val: dict,
    table_val: dict,
    action: str,
    tool: str,
    operator: str,
) -> int:
    """记录审计日志。"""
    conn = db.conn()
    try:
        cursor = conn.execute(
            """
            INSERT INTO qc_audit_log
            (run_id, mpn, kind, path, json_val, table_val, action, tool, operator, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                mpn,
                kind,
                path,
                json.dumps(json_val, ensure_ascii=False),
                json.dumps(table_val, ensure_ascii=False) if table_val else None,
                action,
                tool,
                operator,
                datetime.now().isoformat(),
            ),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        pass
