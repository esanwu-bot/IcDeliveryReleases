"""qc.get_device_snapshot - 查看当前字段、版本及来源。

来源：parsed JSON + item 表
权限：只读
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from app import config, db
from qc.agent_tools.registry import register_tool, Permission


def _safe_key(mpn: str) -> str:
    """生成安全文件名。"""
    import re
    return re.sub(r'[^\w\-]', '_', mpn)


def _find_parsed_json(safe: str) -> Path | None:
    """查找解析 JSON 文件。"""
    data_dir = config.DATA
    parsed_dir = data_dir / "parsed"
    
    # 查找匹配的 JSON 文件
    matches = list(parsed_dir.glob(f"{safe}_*.json"))
    return matches[0] if matches else None


def _get_pdf_sha256(mpn: str) -> str:
    """获取 PDF SHA256。"""
    conn = db.conn()
    try:
        row = conn.execute(
            "SELECT pdf_sha256 FROM item WHERE mpn_key = ?",
            (mpn,),
        ).fetchone()
        return row[0] if row else ""
    finally:
        pass


@register_tool(
    name="qc.get_device_snapshot",
    permission=Permission.READONLY,
    description="查看当前字段、版本及来源",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "include_metadata": {"type": "boolean", "default": True, "description": "是否包含元数据"},
            "include_paths": {"type": "boolean", "default": True, "description": "是否包含文件路径"},
        },
        "required": ["mpn"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "snapshot": {"type": "object"},
            "metadata": {"type": "object"},
            "paths": {"type": "object"},
        },
    },
    source="parsed JSON + item 表",
)
def get_device_snapshot(
    mpn: str,
    include_metadata: bool = True,
    include_paths: bool = True,
) -> dict:
    """读取解析 JSON 和器件元数据。"""
    safe = _safe_key(mpn)
    json_file = _find_parsed_json(safe)
    
    if not json_file:
        return {
            "status": "NOT_FOUND",
            "mpn": mpn,
            "error": "Parsed JSON not found",
        }
    
    try:
        snapshot = json.loads(json_file.read_text(encoding="utf-8"))
    except Exception as e:
        return {
            "status": "ERROR",
            "mpn": mpn,
            "error": f"Failed to read JSON: {e}",
        }
    
    result = {
        "status": "OK",
        "mpn": mpn,
        "snapshot": snapshot,
    }
    
    if include_metadata:
        conn = db.conn()
        try:
            item = conn.execute(
                """
                SELECT id, batch_id, status, pdf_sha256, last_parsed_at
                FROM item WHERE mpn_key = ?
                """,
                (mpn,),
            ).fetchone()
            
            if item:
                result["metadata"] = {
                    "json_path": str(json_file),
                    "pdf_sha256": item["pdf_sha256"] or "",
                    "last_parsed_at": item["last_parsed_at"] or "",
                    "item_id": item["id"],
                    "batch_id": item["batch_id"],
                    "status": item["status"],
                }
            else:
                result["metadata"] = {
                    "json_path": str(json_file),
                    "pdf_sha256": _get_pdf_sha256(mpn),
                    "last_parsed_at": "",
                    "item_id": None,
                    "batch_id": None,
                    "status": "not_in_db",
                }
        finally:
            pass
    
    if include_paths:
        data_data_dir = config.DATA
        result["paths"] = {
            "json": str(json_file.relative_to(data_dir)),
            "txt": str(Path(f"data/txt/{safe}.txt")),
            "alts": str(Path(f"data/alts/{safe}.json")),
            "seo": str(Path(f"data/seo/{safe}.json")),
        }
    
    return result
