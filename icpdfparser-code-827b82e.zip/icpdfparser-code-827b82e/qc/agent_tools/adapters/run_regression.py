"""qc.run_regression - 验证已知问题是否复发。

来源：qc/qc_regression.py
权限：只读
"""
from __future__ import annotations

from datetime import datetime

from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.run_regression",
    permission=Permission.READONLY,
    description="验证已知问题是否复发",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "write": {"type": "boolean", "default": False, "description": "是否写入补丁"},
            "post": {"type": "boolean", "default": False, "description": "是否后处理"},
        },
        "required": ["mpn"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "exit_code": {"type": "integer"},
            "result": {"type": "string"},
            "assertions": {"type": "object"},
            "write": {"type": "boolean"},
            "post": {"type": "boolean"},
        },
    },
    source="qc/qc_regression.py",
)
def run_regression(
    mpn: str,
    write: bool = False,
    post: bool = False,
) -> dict:
    """运行回归测试（默认 dry 模式不写盘）。"""
    from qc.qc_regression import run_one
    
    try:
        result = run_one(mpn, write=write)
        
        exit_code = result.get("exit_code", 1)
        total = result.get("total", 0)
        passed = result.get("passed", 0)
        failed = result.get("failed", 0)
        
        return {
            "status": "OK",
            "mpn": mpn,
            "exit_code": exit_code,
            "result": "PASS" if exit_code == 0 else "FAIL",
            "assertions": {
                "total": total,
                "passed": passed,
                "failed": failed,
            },
            "write": write,
            "post": post,
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "mpn": mpn,
            "exit_code": 1,
            "result": "ERROR",
            "assertions": {
                "total": 0,
                "passed": 0,
                "failed": 0,
            },
            "write": write,
            "post": post,
            "error": str(e),
        }
