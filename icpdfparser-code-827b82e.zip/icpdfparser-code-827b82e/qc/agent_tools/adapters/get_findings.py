"""qc.get_findings - 获取器件问题清单及 P0-Pn 等级。

来源：
  review       data/qc/reviews/<SAFE>.review.json 的 rule_findings + llm_findings
               —— 唯一带 severity 的来源，P0/P1/P2 都在这里
  auto_qc      qc_audit_log 里 tool='qc_regression' 且 action='fail' 的记录
  table_audit  qc_audit_log 里 tool in ('table_audit','lint') 的记录

mpn 传空 = 批次模式：扫最近若干份 review 报告，汇总当前批次的问题。

权限：只读
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

from app import config
from qc.agent_tools.registry import register_tool, Permission

REVIEW_DIR = config.DATA / "qc" / "reviews"
DEFAULT_BATCH_REPORTS = 50
SEVERITY_ORDER = {"P0": 0, "P1": 1, "P2": 2}


def _stable_id(*parts: str) -> str:
    """稳定 ID。

    原来用内置 hash()，但它每个进程加盐不同——重启后同一个 finding 的
    finding_id 就变了，propose_patch 生成的候选文件名、recheck_finding
    的查找全部对不上。改用 md5 截断，跨进程稳定。
    """
    h = hashlib.md5("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()
    return h[:12]


def _normalize_finding(f: dict, source: str, mpn: str = "") -> dict:
    """归一化 finding 格式。"""
    kind = f.get("kind") or f.get("code") or ""
    path = f.get("field_path") or f.get("path") or f.get("field") or ""
    if str(path).strip() in ("-", "—"):
        path = ""  # 台账里用 "-" 占位表示无字段，别原样显示成 [-]
    severity = str(f.get("severity") or "P2").upper()
    if severity not in SEVERITY_ORDER:
        severity = "P2"

    return {
        "finding_id": f.get("finding_id") or _stable_id(source, mpn, kind, path),
        "source": source,
        "mpn": mpn or f.get("mpn", ""),
        "kind": kind,
        "severity": severity,
        "message": f.get("message") or f.get("detail") or "",
        "field_path": path,
        "evidence": f.get("evidence") or {},
        "created_at": f.get("created_at") or datetime.now().isoformat(),
    }


# ---------------------------------------------------------------- review 来源

def _findings_from_report(report: dict, mpn: str = "") -> list[dict]:
    """从一份 review 报告里取 findings。"""
    out: list[dict] = []
    real_mpn = mpn or str(report.get("mpn") or "")
    for f in report.get("rule_findings") or []:
        if isinstance(f, dict):
            out.append(_normalize_finding(f, "review", real_mpn))
    for f in report.get("llm_findings") or []:
        if isinstance(f, dict):
            out.append(_normalize_finding(f, "review_llm", real_mpn))
    return out


def _review_single(mpn: str) -> tuple[list[dict], dict]:
    """单型号：读 <SAFE>.review.json。"""
    from app.services import review as RV

    safe = RV._safe_stem(mpn)
    report = RV.get_report(REVIEW_DIR, safe)
    if not report:
        return [], {"found": False, "safe": safe, "dir": str(REVIEW_DIR)}
    return _findings_from_report(report, mpn), {
        "found": True,
        "safe": safe,
        "verdict": report.get("verdict", ""),
        "generated_at": report.get("generated_at", ""),
        "model": report.get("model", ""),
        "dry_run": bool(report.get("dry_run")),
    }


def _review_batch(limit_reports: int) -> tuple[list[dict], dict]:
    """批次模式：扫最近 N 份报告。按 mtime 倒序，避免一次读几万份。"""
    if not REVIEW_DIR.is_dir():
        return [], {"reports": 0, "dir": str(REVIEW_DIR)}

    files = sorted(REVIEW_DIR.glob("*.review.json"),
                   key=lambda p: p.stat().st_mtime, reverse=True)[:limit_reports]
    findings: list[dict] = []
    verdicts: dict[str, int] = {}
    for p in files:
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(d, dict):
            continue
        verdicts[str(d.get("verdict") or "?")] = verdicts.get(str(d.get("verdict") or "?"), 0) + 1
        findings.extend(_findings_from_report(d))

    return findings, {"reports": len(files), "verdicts": verdicts, "dir": str(REVIEW_DIR)}


# ---------------------------------------------------------------- 台账来源

def _ledger_findings(mpn: str, tools: tuple[str, ...], action: str,
                     source: str, limit: int) -> list[dict]:
    """从 qc_audit_log 台账取记录。

    注意：qc_run 表只有批次级汇总（findings 计数），没有 result 列，
    也从不按型号存明细——明细只在这张台账和 review 报告里。
    """
    from app import db

    placeholders = ",".join("?" * len(tools))
    sql = (f"SELECT mpn, kind, path, action, tool, created_at FROM qc_audit_log "
           f"WHERE tool IN ({placeholders}) AND action = ?")
    args: list = list(tools) + [action]
    if mpn:
        sql += " AND mpn = ?"
        args.append(mpn)
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(limit)

    rows = db.q(sql, args)
    out = []
    for r in rows:
        out.append(_normalize_finding(
            {
                # 台账没有 severity 概念，回归 fail 视为 P1：它是"复检没过"，
                # 比 review 的 P2 提示更硬，但不是身份级 P0。
                "severity": "P1" if source == "auto_qc" else "P2",
                "kind": r.get("kind") or "",
                "message": f"{r.get('tool','')} 标记 {r.get('action','')}",
                "field_path": r.get("path") or "",
                "created_at": r.get("created_at") or "",
            },
            source, r.get("mpn") or "",
        ))
    return out


# ---------------------------------------------------------------- 工具定义

@register_tool(
    name="qc.get_findings",
    permission=Permission.READONLY,
    description="获取器件问题清单及 P0-Pn 等级；mpn 传空则汇总当前批次",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号；留空表示查当前批次"},
            "sources": {
                "type": "array",
                "items": {"type": "string", "enum": ["review", "auto_qc", "table_audit"]},
                "description": "问题来源，默认全部",
            },
            "severity_filter": {
                "type": "array",
                "items": {"type": "string", "enum": ["P0", "P1", "P2"]},
                "description": "严重等级过滤；不传返回全部",
            },
            "limit": {"type": "integer", "default": 50, "description": "返回数量上限"},
            "batch_reports": {
                "type": "integer", "default": DEFAULT_BATCH_REPORTS,
                "description": "批次模式下最多扫多少份 review 报告",
            },
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "scope": {"type": "string"},
            "mpn": {"type": "string"},
            "findings": {"type": "array"},
            "total": {"type": "integer"},
            "by_severity": {"type": "object"},
            "sources_detail": {"type": "object"},
            "generated_at": {"type": "string"},
        },
    },
    source="review + auto_qc + table_audit",
)
def get_findings(
    mpn: str = "",
    sources: list[str] = None,
    severity_filter: list[str] = None,
    limit: int = 50,
    batch_reports: int = DEFAULT_BATCH_REPORTS,
) -> dict:
    """聚合 review + auto_qc + table_audit 的 findings。"""
    mpn = str(mpn or "").strip()
    scope = "single" if mpn else "batch"
    want = set(sources or ["review", "auto_qc", "table_audit"])

    findings: list[dict] = []
    detail: dict = {}

    # 1. review —— 唯一带 severity 的来源
    if "review" in want:
        try:
            if mpn:
                items, info = _review_single(mpn)
            else:
                items, info = _review_batch(max(1, int(batch_reports)))
            findings.extend(items)
            detail["review"] = {**info, "count": len(items)}
        except Exception as e:  # noqa: BLE001
            detail["review"] = {"error": str(e)[:200]}
            print(f"[get_findings] review 查询失败: {e}")

    # 2. auto_qc —— 回归失败
    if "auto_qc" in want:
        try:
            items = _ledger_findings(mpn, ("qc_regression",), "fail", "auto_qc", limit * 4)
            findings.extend(items)
            detail["auto_qc"] = {"count": len(items)}
        except Exception as e:  # noqa: BLE001
            detail["auto_qc"] = {"error": str(e)[:200]}
            print(f"[get_findings] auto_qc 查询失败: {e}")

    # 3. table_audit —— 表级审计台账
    if "table_audit" in want:
        try:
            items = _ledger_findings(mpn, ("table_audit", "lint"), "fail", "table_audit", limit * 4)
            findings.extend(items)
            detail["table_audit"] = {"count": len(items)}
        except Exception as e:  # noqa: BLE001
            detail["table_audit"] = {"error": str(e)[:200]}
            print(f"[get_findings] table_audit 查询失败: {e}")

    # 过滤前的分档统计：P0/P1 为空时也要能告诉用户"另有 N 条 P2"，
    # 否则界面上只剩一句"没有问题"，是假阴性。
    by_severity: dict[str, int] = {}
    for f in findings:
        by_severity[f["severity"]] = by_severity.get(f["severity"], 0) + 1

    applied: list[str] = []
    if severity_filter:
        # 非法等级（模型可能吐 "PQ" 这种）不能当成"过滤条件"，否则一条都不命中，
        # 界面显示 0 条问题但 by_severity 明明有数，是最难查的那种假阴性。
        keep = {str(s).strip().upper() for s in severity_filter} & set(SEVERITY_ORDER)
        if keep:
            applied = sorted(keep, key=lambda s: SEVERITY_ORDER[s])
            findings = [f for f in findings if f["severity"] in keep]

    findings.sort(key=lambda f: (SEVERITY_ORDER.get(f["severity"], 9),
                                 f["mpn"], f["kind"], f["field_path"]))

    return {
        "status": "OK",
        "scope": scope,
        "mpn": mpn,
        "findings": findings[:limit],
        "total": len(findings),
        "by_severity": by_severity,
        "severity_filter": applied,
        "sources_detail": detail,
        "generated_at": datetime.now().isoformat(),
    }
