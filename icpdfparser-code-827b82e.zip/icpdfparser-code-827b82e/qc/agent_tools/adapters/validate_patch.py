"""qc.validate_patch - 验证补丁是否满足约束。

来源：确定性规则 + 数据校验器
权限：只读
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.validate_patch",
    permission=Permission.READONLY,
    description="验证补丁是否满足约束",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "candidate_path": {"type": "string", "description": "候选补丁文件路径"},
            "validation_rules": {
                "type": "array",
                "items": {"type": "string", "enum": ["schema", "electrical_semantics", "regression"]},
                "description": "验证规则，默认全部",
            },
        },
        "required": ["mpn", "candidate_path"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "validation_results": {"type": "object"},
            "all_passed": {"type": "boolean"},
            "requires_human_review": {"type": "boolean"},
        },
    },
    source="确定性规则 + 数据校验器",
)
def validate_patch(
    mpn: str,
    candidate_path: str,
    validation_rules: list[str] = None,
) -> dict:
    """验证候选补丁是否满足约束。"""
    from qc.table_audit import audit_electrical, audit_json
    
    candidate_file = Path(candidate_path)
    if not candidate_file.exists():
        return {
            "status": "ERROR",
            "error": f"Candidate file not found: {candidate_path}",
        }
    
    try:
        candidate = json.loads(candidate_file.read_text(encoding="utf-8"))
    except Exception as e:
        return {
            "status": "ERROR",
            "error": f"Failed to read candidate file: {e}",
        }
    
    rules = validation_rules or ["schema", "electrical_semantics", "regression"]
    results = {}
    
    # 1. Schema 校验
    if "schema" in rules:
        try:
            schema_errors = audit_json(candidate)
            results["schema"] = {
                "passed": len(schema_errors) == 0,
                "errors": schema_errors,
            }
        except Exception as e:
            results["schema"] = {
                "passed": False,
                "errors": [f"Schema validation failed: {e}"],
            }
    
    # 2. 电气语义校验
    if "electrical_semantics" in rules:
        try:
            elec_result = audit_electrical(candidate)
            results["electrical_semantics"] = {
                "passed": elec_result.get("ok", False),
                "warnings": elec_result.get("warnings", []),
                "errors": elec_result.get("errors", []),
            }
        except Exception as e:
            results["electrical_semantics"] = {
                "passed": False,
                "warnings": [],
                "errors": [f"Electrical semantics validation failed: {e}"],
            }
    
    # 3. 回归测试
    if "regression" in rules:
        try:
            from qc.qc_regression import run_one
            regression_result = run_one(mpn, write=False)
            results["regression"] = {
                "passed": regression_result.get("exit_code", 1) == 0,
                "failures": regression_result.get("failures", []),
            }
        except Exception as e:
            results["regression"] = {
                "passed": False,
                "failures": [f"Regression test failed: {e}"],
            }
    
    all_passed = all(r.get("passed", False) for r in results.values())
    
    return {
        "status": "VALIDATION_PASSED" if all_passed else "VALIDATION_FAILED",
        "mpn": mpn,
        "validation_results": results,
        "all_passed": all_passed,
        "requires_human_review": not all_passed,
    }
