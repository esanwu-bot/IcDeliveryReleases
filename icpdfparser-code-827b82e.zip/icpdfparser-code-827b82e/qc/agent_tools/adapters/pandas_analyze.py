"""qc.pandas_analyze - 聚合异常、统计分布、定位离群值。

来源：app/services/qc_analyzer.py
权限：只读
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from app import config
from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.pandas_analyze",
    permission=Permission.READONLY,
    description="聚合异常、统计分布、定位离群值",
    input_schema={
        "type": "object",
        "properties": {
            "filters": {
                "type": "object",
                "properties": {
                    "status": {"type": "string"},
                    "batch_id": {"type": "integer"},
                    "brand": {"type": "string"},
                },
                "description": "过滤条件",
            },
            "include_distributions": {"type": "boolean", "default": True},
            "include_root_cause": {"type": "boolean", "default": True},
            "persist": {"type": "boolean", "default": False, "description": "是否写入分析快照表"},
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "analysis": {"type": "object"},
            "persisted": {"type": "boolean"},
        },
    },
    source="app/services/qc_analyzer.py",
)
def pandas_analyze(
    filters: dict = None,
    include_distributions: bool = True,
    include_root_cause: bool = True,
    persist: bool = False,
) -> dict:
    """运行 Pandas QC 分析，返回结果（默认不写快照表）。"""
    from app.services.qc_analyzer import run_analysis
    from app import db
    
    data_dir = config.DATA
    
    try:
        result = run_analysis(
            db=db,
            filters=filters or {},
            matrix_path=data_dir / "qc" / "auto_qc_issue_matrix.csv",
            cards_path=data_dir / "qc" / "evidence_cards.csv",
            pdf_root=data_dir / "pdf",
            actor="agent",
            persist=persist,
        )
        
        return {
            "status": "OK",
            "analysis": result,
            "persisted": persist,
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "analysis": {},
            "persisted": False,
            "error": str(e),
        }
