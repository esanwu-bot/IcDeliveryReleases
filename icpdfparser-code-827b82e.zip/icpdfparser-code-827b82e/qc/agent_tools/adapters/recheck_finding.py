"""qc.recheck_finding - 重新检查原 Finding 是否真正解决。

来源：Review 重跑
权限：只读
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from app import config
from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.recheck_finding",
    permission=Permission.READONLY,
    description="重新检查原 Finding 是否真正解决",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "finding_id": {"type": "string", "description": "问题 ID"},
            "dry_run": {"type": "boolean", "default": True, "description": "是否只读模式"},
        },
        "required": ["mpn", "finding_id"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "finding_id": {"type": "string"},
            "recheck_result": {"type": "string"},
            "original_finding": {"type": "object"},
            "new_findings": {"type": "array"},
            "resolved": {"type": "boolean"},
            "dry_run": {"type": "boolean"},
        },
    },
    source="Review 重跑",
)
def recheck_finding(
    mpn: str,
    finding_id: str,
    dry_run: bool = True,
) -> dict:
    """重新检查原 Finding 是否真正解决。"""
    from app.services.review import run_review
    from app import db
    
    # 1. 获取原始 finding
    original_finding = _get_finding_by_id(finding_id)
    
    if not original_finding:
        return {
            "status": "ERROR",
            "error": f"Finding not found: {finding_id}",
        }
    
    # 2. 重新运行 review
    data_dir = config.DATA
    
    try:
        review_result = run_review(
            db=db,
            mpn=mpn,
            data_dir=data_dir,
            out_dir=data_dir / "qc" / "reviews",
            with_pdf_text=False,
            dry_run=dry_run,
            write_db=False,
            operator="agent",
            force=True,
        )
    except Exception as e:
        return {
            "status": "ERROR",
            "error": f"Review execution failed: {e}",
        }
    
    # 3. 检查原 finding 是否还在
    new_findings = review_result.get("rule_findings", []) + review_result.get("llm_findings", [])
    
    resolved = not any(
        f.get("kind") == original_finding.get("kind") and
        f.get("field_path") == original_finding.get("field_path")
        for f in new_findings
    )
    
    return {
        "status": "OK",
        "mpn": mpn,
        "finding_id": finding_id,
        "recheck_result": "RESOLVED" if resolved else "STILL_PRESENT",
        "original_finding": original_finding,
        "new_findings": new_findings,
        "resolved": resolved,
        "dry_run": dry_run,
    }


def _get_finding_by_id(finding_id: str) -> dict:
    """根据 finding_id 获取 finding。"""
    import json
    from app import db
    
    conn = db.conn()
    try:
        row = conn.execute(
            "SELECT context FROM agent_task WHERE task_id = ?",
            (finding_id,),
        ).fetchone()
        
        if row and row[0]:
            context = json.loads(row[0])
            return context.get("finding", {})
        
        return {}
    finally:
        pass
