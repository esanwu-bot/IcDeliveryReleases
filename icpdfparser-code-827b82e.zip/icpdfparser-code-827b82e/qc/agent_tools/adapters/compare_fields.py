"""qc.compare_fields - 计算修复前后差异。

来源：JSON diff 工具
权限：只读
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from qc.agent_tools.registry import register_tool, Permission


def _get_by_path(obj: dict, path: str):
    """按路径获取值（支持数组索引）。"""
    import re
    parts = re.split(r'\[|\].', path)
    parts = [p for p in parts if p]
    
    current = obj
    for part in parts:
        if part.isdigit():
            current = current[int(part)]
        else:
            current = current[part]
    
    return current


def _classify_diff(baseline_val, candidate_val) -> str:
    """分类差异类型。"""
    if type(baseline_val) != type(candidate_val):
        return "type_change"
    
    if isinstance(baseline_val, str):
        # 检查是否是 Unicode 归一化
        if baseline_val.replace('u', 'µ') == candidate_val:
            return "unicode_normalization"
        if baseline_val.replace(' ', '') == candidate_val.replace(' ', ''):
            return "whitespace_change"
    
    return "value_change"


@register_tool(
    name="qc.compare_fields",
    permission=Permission.READONLY,
    description="计算修复前后差异",
    input_schema={
        "type": "object",
        "properties": {
            "mpn": {"type": "string", "description": "器件型号"},
            "baseline_path": {"type": "string", "description": "基线 JSON 文件路径"},
            "candidate_path": {"type": "string", "description": "候选 JSON 文件路径"},
            "field_paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "要比较的字段路径，默认全部",
            },
        },
        "required": ["mpn", "baseline_path", "candidate_path"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "mpn": {"type": "string"},
            "comparisons": {"type": "array"},
            "total_changed": {"type": "integer"},
            "total_unchanged": {"type": "integer"},
        },
    },
    source="JSON diff 工具",
)
def compare_fields(
    mpn: str,
    baseline_path: str,
    candidate_path: str,
    field_paths: list[str] = None,
) -> dict:
    """比较两份 JSON 的指定字段差异。"""
    try:
        baseline = json.loads(Path(baseline_path).read_text(encoding="utf-8"))
        candidate = json.loads(Path(candidate_path).read_text(encoding="utf-8"))
    except Exception as e:
        return {
            "status": "ERROR",
            "mpn": mpn,
            "error": f"Failed to read JSON files: {e}",
            "comparisons": [],
            "total_changed": 0,
            "total_unchanged": 0,
        }
    
    comparisons = []
    
    # 如果没有指定字段路径，比较所有顶层字段
    if not field_paths:
        field_paths = list(set(list(baseline.keys()) + list(candidate.keys())))
    
    for path in field_paths:
        try:
            baseline_val = _get_by_path(baseline, path)
            candidate_val = _get_by_path(candidate, path)
            
            if baseline_val != candidate_val:
                comparisons.append({
                    "field_path": path,
                    "baseline": baseline_val,
                    "candidate": candidate_val,
                    "changed": True,
                    "diff_type": _classify_diff(baseline_val, candidate_val),
                })
        except (KeyError, IndexError, TypeError):
            # 字段不存在，跳过
            pass
    
    return {
        "status": "OK",
        "mpn": mpn,
        "comparisons": comparisons,
        "total_changed": len(comparisons),
        "total_unchanged": len(field_paths) - len(comparisons),
    }
