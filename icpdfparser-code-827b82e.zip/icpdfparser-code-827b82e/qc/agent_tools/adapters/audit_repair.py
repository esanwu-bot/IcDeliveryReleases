"""qc.audit_repair - 记录工具调用、输入输出、差异与验证结果。

来源：QC 审计日志
权限：追加写入
"""
from __future__ import annotations

import json
from datetime import datetime

from app import db
from qc.agent_tools.registry import register_tool, Permission


@register_tool(
    name="qc.audit_repair",
    permission=Permission.APPEND_WRITE,
    description="记录工具调用、输入输出、差异与验证结果",
    input_schema={
        "type": "object",
        "properties": {
            "run_id": {"type": "string", "description": "运行 ID"},
            "mpn": {"type": "string", "description": "器件型号"},
            "finding_id": {"type": "string", "description": "问题 ID"},
            "action": {"type": "string", "description": "操作类型"},
            "tool": {"type": "string", "description": "工具名称"},
            "input_data": {"type": "object", "description": "输入数据"},
            "output_data": {"type": "object", "description": "输出数据"},
            "operator": {"type": "string", "default": "agent", "description": "操作者"},
        },
        "required": ["run_id", "mpn", "finding_id", "action", "tool", "input_data", "output_data"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "audit_log_id": {"type": "integer"},
            "created_at": {"type": "string"},
        },
    },
    source="QC 审计日志",
)
def audit_repair(
    run_id: str,
    mpn: str,
    finding_id: str,
    action: str,
    tool: str,
    input_data: dict,
    output_data: dict,
    operator: str = "agent",
) -> dict:
    """记录工具调用、输入输出、差异与验证结果。"""
    conn = db.conn()
    try:
        cursor = conn.execute(
            """
            INSERT INTO qc_audit_log
            (run_id, mpn, kind, path, json_val, table_val, action, tool, operator, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                mpn,
                f"repair_{action}",
                None,
                json.dumps({
                    "finding_id": finding_id,
                    "input": input_data,
                    "output": output_data,
                }, ensure_ascii=False),
                None,
                action,
                tool,
                operator,
                datetime.now().isoformat(),
            ),
        )
        conn.commit()
        
        return {
            "status": "OK",
            "audit_log_id": cursor.lastrowid,
            "created_at": datetime.now().isoformat(),
        }
    except Exception as e:
        return {
            "status": "ERROR",
            "error": str(e),
        }
    finally:
        pass
