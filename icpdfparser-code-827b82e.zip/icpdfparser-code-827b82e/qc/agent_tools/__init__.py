"""QC Agent Tools 层。

提供 12 个结构化工具，封装现有 QC 能力：
- 6 个只读诊断工具：get_findings, get_device_snapshot, auto_qc, pandas_analyze, get_evidence, compare_fields
- 6 个受控修复工具：propose_patch, validate_patch, run_regression, commit_patch, recheck_finding, audit_repair

所有工具调用必须通过 ToolRegistry，记录审计日志，不允许绕过权限检查。
"""
from .registry import registry, Permission, ToolDefinition, register_tool

# 导入所有工具适配器，触发注册
from .adapters import (
    get_findings,
    get_device_snapshot,
    auto_qc,
    pandas_analyze,
    get_evidence,
    compare_fields,
    propose_patch,
    validate_patch,
    run_regression,
    commit_patch,
    recheck_finding,
    audit_repair,
)

__all__ = [
    "registry",
    "Permission",
    "ToolDefinition",
    "register_tool",
]
