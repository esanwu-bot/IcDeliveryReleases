"""V4 页预算修复的临时目录 dry-run：只产出临时解析结果与诊断报告。

为什么不是直接重跑
----------------
上一轮 228 件重解析把订货行补上了，但电气参数去重签名净减 769。修完页预算后
不能凭「选页指标变好了」就放行——必须看真正解析出来的数据。而生产数据目前
处于「未收口」状态（有 5 组重复文件、2 件被错误原件污染），所以这一轮只写
临时目录，不动 `data/parsed`。

写入隔离
--------
`pipeline.parse_pdf` 唯一的落盘是 `config.PARSED / {mpn}_{hash[:8]}.json`
（`app/services/pipeline.py` 171-173 行），数据库写入在更下游的 `run_one()`。
所以把 `config.PARSED` 指到临时目录即可隔离。本脚本仍会在开始前/结束后
对 `data/parsed`、`data/txt`、`data/alts`、`data/symbols`、`data/seo` 和
`workbench.sqlite3` 做快照比对，用事实确认「一个字节都没动」。

输入身份固定
------------
逐件记录 MPN、`item.pdf_path`、PDF SHA-256；严格匹配（`MPN__doc.pdf`）不到
PDF 的项目**跳过并记录**，绝不回退到前缀匹配——前缀匹配正是上轮踩坑的原因。

基线
----
旧数据取批次开始前的备份 `data/parsed_backup_ordering/`，不用已被覆盖的现文件。

产出
----
    v4_source_identity_audit.csv   输入层：原件身份、哈希、缺失
    v4_quality_diff.csv            数据层：订货行/电气去重签名/替代型号/特性
    v4_regression_candidates.csv   电气签名低于旧版 60% 的件 + 选页证据
    v4_dryrun_summary.json         汇总 + 隔离校验结果

用法（容器内）
--------------
    python qc/v4_dryrun.py --mpns-file /tmp/all228.txt \
        --out-dir /tmp/v4_dryrun --workers 6
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import config                                       # noqa: E402
from qc.reparse_ordering import _pdf_for, _safe, is_worth_writing  # noqa: E402

PROD_DIRS = ("parsed", "txt", "alts", "symbols", "seo")
PROD_DB = "workbench.sqlite3"


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def snapshot(data_root: Path) -> dict:
    """生产目录快照：文件名 -> (mtime_ns, size)。用于事后证明没有写入。"""
    snap = {}
    for d in PROD_DIRS:
        p = data_root / d
        if not p.exists():
            snap[d] = "missing"
            continue
        snap[d] = {f.name: (f.stat().st_mtime_ns, f.stat().st_size)
                   for f in p.iterdir() if f.is_file()}
    dbp = data_root / PROD_DB
    snap["__db__"] = ((dbp.stat().st_mtime_ns, dbp.stat().st_size)
                      if dbp.exists() else "missing")
    snap["__parsed_count__"] = len(snap.get("parsed") or {})
    return snap


def diff_snapshot(before: dict, after: dict) -> list[str]:
    out = []
    for d in PROD_DIRS:
        b, a = before.get(d), after.get(d)
        if b == "missing" and a == "missing":
            continue
        if b == "missing" or a == "missing":
            out.append("%s: 目录存在性变化" % d)
            continue
        added = set(a) - set(b)
        removed = set(b) - set(a)
        changed = {n for n in set(a) & set(b) if a[n] != b[n]}
        if added:
            out.append("%s: 新增 %d 个文件（例：%s）" % (d, len(added), sorted(added)[:3]))
        if removed:
            out.append("%s: 少了 %d 个文件（例：%s）" % (d, len(removed), sorted(removed)[:3]))
        if changed:
            out.append("%s: %d 个文件被改动（例：%s）" % (d, len(changed), sorted(changed)[:3]))
    if before.get("__db__") != after.get("__db__"):
        out.append("workbench.sqlite3: 被改动（%s -> %s）" % (before.get("__db__"),
                                                             after.get("__db__")))
    return out


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _rows(doc: dict) -> list[str]:
    return [str((o or {}).get("mpn") or "") for o in (doc.get("ordering_info") or [])
            if isinstance(o, dict)]


def _sig(e: dict) -> tuple:
    g = lambda k: str((e or {}).get(k) or "").strip().lower()
    return (g("name"), g("condition"), g("unit"))


def _sigs(doc: dict) -> dict:
    out = {}
    for e in ((doc.get("specs") or {}).get("electrical") or []):
        if isinstance(e, dict) and _sig(e)[0]:
            out[_sig(e)] = out.get(_sig(e), 0) + 1
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V4 页预算修复的临时目录 dry-run")
    ap.add_argument("--mpns-file", default="")
    ap.add_argument("--mpn", action="append", default=[])
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--out-dir", default="/tmp/v4_dryrun")
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--commit", default="", help="被测代码的提交号（记录进报告）")
    a = ap.parse_args(argv)

    data_root = Path(a.data_root)
    backup = Path(a.backup)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    mpns = list(a.mpn)
    if a.mpns_file and Path(a.mpns_file).exists():
        mpns += [x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()]
    mpns = list(dict.fromkeys(mpns))
    if a.limit:
        mpns = mpns[: a.limit]
    if not mpns:
        print("没有指定 MPN")
        return 2

    print("=== 步骤 0：代码版本与写入隔离前置校验 ===")
    commit = a.commit
    if not commit:
        try:
            import subprocess
            commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(ROOT),
                                    capture_output=True, text=True).stdout.strip()[:12]
        except Exception:                                    # noqa: BLE001
            commit = "unknown"
    import parse_datasheets as PD
    print("提交号 %s" % commit)
    print("MAX_PAGES=%d RANK_QUOTA=%s ELEC_FLOOR_CHARS=%d"
          % (PD.MAX_PAGES, PD.RANK_QUOTA, PD.ELEC_FLOOR_CHARS))

    before = snapshot(data_root)
    print("生产快照：data/parsed %d 个文件" % before["__parsed_count__"])

    # ---- 步骤 1：输入身份固定 ----
    db = sqlite3.connect(data_root / PROD_DB)
    pdfs = data_root / "pdfs"
    cur_index = {p.name: p for p in (data_root / "parsed").glob("*.json")}
    print("\n=== 步骤 1：输入身份固定（%d 件）===" % len(mpns))
    tasks, identity = [], []
    for mpn in mpns:
        r = db.execute("SELECT pdf_path, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        db_pdf = r[0] if r else ""
        db_json = r[1] if r else ""
        pdf = _pdf_for(pdfs, mpn)          # 严格匹配，无前缀回退
        if pdf is None:
            cands = sorted(p.name for p in pdfs.glob(_safe(mpn) + "*.pdf"))[:4]
            identity.append({"mpn": mpn, "status": "严格匹配失败，已跳过",
                             "item_pdf_path": Path(db_pdf.replace("\\", "/")).name if db_pdf else "",
                             "resolved_pdf": "", "pdf_sha256": "",
                             "prefix_would_match": "|".join(cands),
                             "db_json_path": db_json, "backup": ""})
            continue
        sha = _sha(pdf)
        fname = Path(db_json.replace("\\", "/")).name if db_json else ""
        if not fname or fname not in cur_index:
            hits = sorted(n for n in cur_index if n.startswith(_safe(mpn) + "_"))
            fname = hits[0] if hits else ""
        bak = backup / fname if fname else None
        if not fname or not bak or not bak.exists():
            identity.append({"mpn": mpn, "status": "无备份基线，已跳过",
                             "item_pdf_path": Path(db_pdf.replace("\\", "/")).name if db_pdf else "",
                             "resolved_pdf": pdf.name, "pdf_sha256": sha[:16],
                             "prefix_would_match": "", "db_json_path": db_json,
                             "backup": str(bak) if bak else ""})
            continue
        identity.append({"mpn": mpn, "status": "ok",
                         "item_pdf_path": Path(db_pdf.replace("\\", "/")).name if db_pdf else "",
                         "resolved_pdf": pdf.name, "pdf_sha256": sha[:16],
                         "prefix_would_match": "", "db_json_path": db_json,
                         "backup": fname,
                         "db_pdf_matches": "是" if Path(db_pdf.replace("\\", "/")).name == pdf.name
                         else "否"})
        tasks.append({"mpn": mpn, "pdf": pdf, "sha": sha, "bak": bak, "fname": fname})
    skipped = len(mpns) - len(tasks)
    print("可跑 %d 件，跳过 %d 件（严格匹配失败或无备份基线）" % (len(tasks), skipped))

    # ---- 步骤 2：临时目录解析 ----
    tmp_parsed = out_dir / "parsed"
    tmp_parsed.mkdir(parents=True, exist_ok=True)
    config.PARSED = tmp_parsed          # 写入隔离：唯一的落盘目标改成临时目录
    print("\n=== 步骤 2：临时目录解析 ===")
    print("输出目录：%s（config.PARSED 已重定向）" % tmp_parsed)

    from app.services import pipeline

    def _one(t):
        t0 = time.time()
        try:
            rec = pipeline.parse_pdf(t["pdf"], t["mpn"])
        except Exception as e:                               # noqa: BLE001
            return {**t, "status": "failed", "error": f"{type(e).__name__}: {e}"[:160],
                    "ms": int((time.time() - t0) * 1000), "new_doc": {},
                    "out_file": ""}
        doc = rec.get("doc") or {}
        h = str((doc.get("metadata") or {}).get("pdf_hash") or "")[:8]
        out_file = tmp_parsed / f"{_safe(t['mpn'])}_{h}.json" if h else None
        return {**t, "status": rec.get("status"), "error": (rec.get("error") or "")[:160],
                "ms": int((time.time() - t0) * 1000), "new_doc": doc,
                "out_file": str(out_file) if out_file and out_file.exists() else ""}

    results = []
    done = [0]
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futs = [pool.submit(_one, t) for t in tasks]
        for fut in as_completed(futs):
            r = fut.result()
            done[0] += 1
            results.append(r)
            if done[0] % 20 == 0 or done[0] == len(tasks):
                print("  已解析 %d/%d" % (done[0], len(tasks)), flush=True)

    # ---- 步骤 3：质量差异 ----
    print("\n=== 步骤 3：与备份基线比对 ===")
    diff_rows = []
    for r in sorted(results, key=lambda x: x["mpn"]):
        old = _load(r["bak"])
        new = r["new_doc"]
        o_s, n_s = _sigs(old), _sigs(new)
        lost = sorted(set(o_s) - set(n_s))
        gain = sorted(set(n_s) - set(o_s))
        o_rows, n_rows = _rows(old), _rows(new)
        req = r["mpn"].strip().upper()
        diff_rows.append({
            "mpn": r["mpn"], "status": r["status"],
            "resolved_pdf": r["pdf"].name, "pdf_sha256": r["sha"][:16],
            "new_pdf_hash": str((new.get("metadata") or {}).get("pdf_hash") or "")[:16],
            "src_same": ("是" if str((new.get("metadata") or {}).get("pdf_hash") or "")[:16]
                         == r["sha"][:16] else "否"),
            "order_old": len(o_rows), "order_new": len(n_rows),
            "order_hits_request": "是" if req in [x.upper() for x in n_rows]
                                  and req not in [x.upper() for x in o_rows] else "否",
            "worth_writing": "是" if is_worth_writing(len(o_rows), len(n_rows)) else "否",
            "elec_raw_old": len((old.get("specs") or {}).get("electrical") or []),
            "elec_raw_new": len((new.get("specs") or {}).get("electrical") or []),
            "elec_uniq_old": len(o_s), "elec_uniq_new": len(n_s),
            "elec_lost": len(lost), "elec_gain": len(gain),
            "elec_ratio": round(len(n_s) / len(o_s), 3) if o_s else "",
            "alt_old": len(old.get("alternatives") or []),
            "alt_new": len(new.get("alternatives") or []),
            "feat_old": len(old.get("features") or []),
            "feat_new": len(new.get("features") or []),
            "old_order_rows": ",".join(o_rows), "new_order_rows": ",".join(n_rows),
            "lost_sample": " ; ".join("|".join(s) for s in lost[:5]),
            "out_file": Path(r["out_file"]).name if r["out_file"] else "",
            "error": r["error"],
        })

    # ---- 步骤 4：退化候选 ----
    reg = [x for x in diff_rows
           if x["elec_uniq_old"] > 0 and x["elec_uniq_new"] < x["elec_uniq_old"] * 0.6]
    import re
    from qc.diagnose_elec_loss import ELEC_KEYS
    for x in reg:
        pdf = pdfs / x["resolved_pdf"]
        try:
            import fitz
            with fitz.open(str(pdf)) as d:
                pages = [(i, d[i].get_text("text") or "") for i in range(d.page_count)]
            text, used, dropped = PD.select_pages(pages)
            sel = [int(n) for n in re.findall(r"--- Page (\d+) ---", text)]
            elec = {i + 1 for i, t in pages if any(k in t.lower() for k in ELEC_KEYS)}
            x.update({"sel_pages": ",".join(map(str, sel[:14])),
                      "sel_n": used, "dropped": "是" if dropped else "否",
                      "elec_cand_n": len(elec),
                      "elec_sel_n": len([p for p in sel if p in elec]),
                      "elec_sel_pages": ",".join(map(str, [p for p in sel if p in elec][:8])),
                      "chars": len(text)})
        except Exception as e:                               # noqa: BLE001
            x.update({"sel_pages": "", "sel_n": "", "dropped": "",
                      "elec_cand_n": "", "elec_sel_n": "", "elec_sel_pages": "",
                      "chars": "", "sel_err": type(e).__name__})

    # ---- 步骤 5：隔离校验 ----
    after = snapshot(data_root)
    violations = diff_snapshot(before, after)

    summary = {
        "commit": commit,
        "run_at": time.strftime("%F %T"),
        "params": {"MAX_PAGES": PD.MAX_PAGES, "RANK_QUOTA": list(PD.RANK_QUOTA),
                   "ELEC_FLOOR_CHARS": PD.ELEC_FLOOR_CHARS},
        "input": {"requested": len(mpns), "parsed": len(results), "skipped": skipped},
        "out_dir": str(out_dir),
        "isolation": {"violations": violations, "clean": not violations,
                      "parsed_before": before["__parsed_count__"],
                      "parsed_after": after["__parsed_count__"]},
        "quality": {
            "order_rows_old": sum(x["order_old"] for x in diff_rows),
            "order_rows_new": sum(x["order_new"] for x in diff_rows),
            "elec_uniq_old": sum(x["elec_uniq_old"] for x in diff_rows),
            "elec_uniq_new": sum(x["elec_uniq_new"] for x in diff_rows),
            "elec_lost": sum(x["elec_lost"] for x in diff_rows),
            "elec_gain": sum(x["elec_gain"] for x in diff_rows),
            "alt_old": sum(x["alt_old"] for x in diff_rows),
            "alt_new": sum(x["alt_new"] for x in diff_rows),
            "feat_old": sum(x["feat_old"] for x in diff_rows),
            "feat_new": sum(x["feat_new"] for x in diff_rows),
            "order_hits_request": sum(1 for x in diff_rows
                                      if x["order_hits_request"] == "是"),
            "worth_writing": sum(1 for x in diff_rows if x["worth_writing"] == "是"),
            "failed": sum(1 for x in diff_rows if x["status"] != "ok"),
            "regression_below_60pct": len(reg),
            "src_mismatch": sum(1 for x in diff_rows if x["src_same"] == "否"),
        },
        "baseline_last_round": {
            "elec_raw_net": -817, "elec_uniq_net": -769,
            "order_rows_increased": 188, "regression_below_60pct": 37,
            "note": "上一轮（未修页预算）基线，用于对照",
        },
    }
    net = summary["quality"]["elec_uniq_new"] - summary["quality"]["elec_uniq_old"]
    summary["quality"]["elec_uniq_net"] = net

    def dump(name, rows, cols=None):
        p = out_dir / name
        if not rows:
            p.write_text("", encoding="utf-8")
            return
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=cols or list(rows[0].keys()),
                               extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        print("  写 %s（%d 行）" % (p, len(rows)))

    print("\n=== 产出 ===")
    dump("v4_source_identity_audit.csv", identity)
    dump("v4_quality_diff.csv", diff_rows)
    dump("v4_regression_candidates.csv", reg)
    (out_dir / "v4_dryrun_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("  写 v4_dryrun_summary.json")

    print("\n=== 汇总 ===")
    q = summary["quality"]
    print("订货行 %d -> %d；命中请求料号 %d 件；值得落盘 %d 件"
          % (q["order_rows_old"], q["order_rows_new"],
             q["order_hits_request"], q["worth_writing"]))
    print("电气去重签名 %d -> %d（净 %+d）；丢失 %d / 新增 %d"
          % (q["elec_uniq_old"], q["elec_uniq_new"], net, q["elec_lost"], q["elec_gain"]))
    print("替代型号 %d -> %d；特性 %d -> %d" % (q["alt_old"], q["alt_new"],
                                              q["feat_old"], q["feat_new"]))
    print("电气掉到 60%% 以下：%d 件；原件不一致：%d 件；失败：%d 件"
          % (len(reg), q["src_mismatch"], q["failed"]))
    print("写入隔离：%s" % ("通过，生产目录零改动" if not violations
                            else "【违规】" + "；".join(violations)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
