# -*- coding: utf-8 -*-
"""把 `qc/grey_readonly.py` 的 `result.jsonl` 汇总成交付报告（Markdown + 控制台摘要）。

只读 `result.jsonl`，不重跑任何审计 —— 500 件跑完可以反复出报告。

用法：
  python qc/grey_report.py --src data/qc/grey500/result.jsonl --out data/qc/grey500/报告.md
"""
import argparse
import json
from collections import Counter
from pathlib import Path


def pct(a, b) -> str:
    return f"{a / b * 100:.1f}%" if b else "-"


def bar(n, mx, width=28) -> str:
    k = 0 if not mx else round(n / mx * width)
    return "█" * k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="data/qc/grey500/result.jsonl")
    ap.add_argument("--out", default="")
    ap.add_argument("--top", type=int, default=15)
    a = ap.parse_args()

    src = Path(a.src)
    rows = [json.loads(l) for l in src.read_text(encoding="utf-8").splitlines() if l.strip()]
    ok = [r for r in rows if r.get("ok")]
    bad = [r for r in rows if not r.get("ok")]

    kinds = Counter()
    for r in ok:
        kinds.update(r.get("kinds") or {})
    total_find = sum(kinds.values())
    unres = sum(r.get("unresolved", 0) for r in ok)
    patched = sum(r.get("patched", 0) for r in ok)
    entries = sum(r.get("entries", 0) for r in ok)
    amb_tie = sum(r.get("amb_tie", 0) for r in ok)
    amb_coll = sum(r.get("amb_coll", 0) for r in ok)
    cell_bad = sum(r.get("cell_bad", 0) for r in ok)
    cell_fused = sum(r.get("cell_bad_fused", 0) for r in ok)
    fused_tbl = sum(r.get("fused_tables", 0) for r in ok)
    files_fused = sum(1 for r in ok if r.get("fused_tables", 0) > 0)
    files_blocked = sum(1 for r in ok if r.get("cell_bad", 0) > 0)
    files_clean = sum(1 for r in ok if not r.get("findings"))
    secs = sum(r.get("sec", 0) for r in ok)
    pages = sum(r.get("pages", 0) for r in ok)
    tables = sum(r.get("tables", 0) for r in ok)

    L = []
    add = L.append
    is_write = any("write_cols" in r for r in ok)
    add(f"# {'写盘' if is_write else '只读'}灰度报告（{len(rows)} 件抽样）\n")
    add(f"- 数据源：`{src}`")
    add(f"- 匹配规则：`locate_row/unique-v3`；页级预过滤开启；每份 PDF 最多 40 页")
    add(f"- 成功 {len(ok)} 件 / 失败 {len(bad)} 件；累计 {pages} 页、{tables} 张表、{entries} 条电气/绝对最大额定条目")
    add(f"- 单件平均 {secs / len(ok):.0f}s（串行口径），总 CPU {secs / 60:.0f} 分钟\n")

    add("## 一、总览\n")
    add("| 指标 | 数值 | 占比 |")
    add("|---|---|---|")
    add(f"| findings 总数 | {total_find} | — |")
    add(f"| unresolved（未落盘） | {unres} | {pct(unres, total_find)} |")
    add(f"| patched（会落盘） | {patched} | {pct(patched, total_find)} |")
    add(f"| 其中 ambiguous 并列 | {amb_tie} | {pct(amb_tie, unres)} 的 unresolved |")
    add(f"| 其中 ambiguous 抢同一行 | {amb_coll} | {pct(amb_coll, unres)} 的 unresolved |")
    add(f"| 脏格/融合列拦截 | {cell_bad}（融合列 {cell_fused}） | — |")
    add(f"| 含融合列表的件 | {files_fused} | {pct(files_fused, len(ok))} |")
    add(f"| 至少一条被拦截的件 | {files_blocked} | {pct(files_blocked, len(ok))} |")
    add(f"| 完全干净（0 findings） | {files_clean} | {pct(files_clean, len(ok))} |")
    add("")

    add("## 二、finding 种类分布\n")
    add("| kind | 次数 | 分布 |")
    add("|---|---|---|")
    mx = max(kinds.values()) if kinds else 1
    for k, v in kinds.most_common():
        add(f"| `{k}` | {v} | {bar(v, mx)} |")
    add("")

    add("## 三、按件的 unresolved 排名（人工优先处理）\n")
    add("| MPN | 条目 | 页 | 表 | unresolved | 并列 | 抢同行 | 脏格 | 融合表 |")
    add("|---|---|---|---|---|---|---|---|---|")
    for r in sorted(ok, key=lambda x: -x.get("unresolved", 0))[: a.top]:
        add(f"| {r['mpn']} | {r.get('entries', 0)} | {r.get('pages', 0)} | {r.get('tables', 0)} "
            f"| {r.get('unresolved', 0)} | {r.get('amb_tie', 0)} | {r.get('amb_coll', 0)} "
            f"| {r.get('cell_bad', 0)} | {r.get('fused_tables', 0)} |")
    add("")

    if is_write:
        writes = sum(r.get("write_cols", 0) for r in ok)
        garbled = sum(r.get("write_garbled", 0) for r in ok)
        wt = sorted(ok, key=lambda x: -x.get("write_cols", 0))
        add("## 四、写盘核对（`--write` 模式）\n")
        add(f"- 写 `columns` **{writes}** 条，分布在 {sum(1 for r in wt if r.get('write_cols'))} 件；"
            f"乱码 condition 被拦 **{garbled}** 条")
        add("- 写盘只落在沙箱副本，`data/parsed` 未变动；`FACTS` 目录也已被重定向进沙箱。\n")
        add("| MPN | 写列 | 乱码拦 | 样本（name → columns ｜ raw） |")
        add("|---|---|---|---|")
        for r in wt[: a.top]:
            if not r.get("write_cols"):
                continue
            s = "; ".join(
                f"{(x.get('name') or '')[:18]} → {x.get('columns')}" for x in (r.get("write_sample") or [])[:3])
            add(f"| {r['mpn']} | {r['write_cols']} | {r.get('write_garbled', 0)} | {s} |")
        add("")

    if bad:
        add("## 四、失败件\n")
        add("| MPN | 原因 |")
        add("|---|---|")
        for r in bad[:40]:
            add(f"| {r['mpn']} | {r.get('err', '')} |")
        add("")

    add("## 五、结论口径\n")
    add("- `patched` 为 0 或极低的件：不是「没问题」，是「问题落不到可写的单元格上」，"
        "看 `unresolved` 的构成决定人工成本。")
    add("- `抢同一行`（collision）高 → 该件的 PDF 表是**合并列 / 多条件列组**，属结构性问题，"
        "不在打分层面能解，见 `docs/qc/stage3_v3_and_write_gate_20261030.md` §1。")
    add("- `并列`（tie）高 → 条件不足以区分同名行，属 A1 类，需要更细的限定词解析。")
    add("- 本报告只读生成，`data/parsed` 一个字节都没动。")

    text = "\n".join(L)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text, encoding="utf-8")
        print(f"报告 -> {a.out}")
    print(text[:3000])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
