"""合并结果的独立校验：确认「历史字段没丢、解析改善真的进来了」。

演练只跑合并器是不够的——合并器自己报告「保留成功」不能当证据，得拿
合并产物跟旧/新两份原始 JSON 三方对照，逐条断言。

校验项
------
1. multi_language 与旧 JSON 完全一致（这是本轮要保的东西）
2. 旧 JSON 里白名单外的顶层字段，在合并结果里还在且值不变
3. 白名单字段确实取到了新解析的值（否则等于没更新）
4. 合并结果的顶层键集合覆盖旧 JSON 的全部顶层键（不能少字段）
5. metadata.pdf_hash 取新值（写回后要能对上新的解析身份）
6. 列表项里白名单外的键（如 pin_configuration[].device_scope）没被冲掉
7. JSON 可解析、不是空对象

只读：不写生产目录，只写 --out-dir 下的报告。

用法（容器内）
--------------
    python qc/v4_merge_verify.py --merged-dir /tmp/v4_merge/merged \
        --out-dir /tmp/v4_merge
"""
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.json_merge import PARSE_OWNED                      # noqa: E402
from qc.reparse_ordering import _safe                      # noqa: E402


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="合并结果三方校验")
    ap.add_argument("--merged-dir", default="/tmp/v4_merge/merged")
    ap.add_argument("--tmp-parsed", default="/tmp/v4_dryrun/parsed",
                    help="新解析结果目录")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--out-dir", default="/tmp/v4_merge")
    a = ap.parse_args(argv)

    merged_dir, tmp, backup = Path(a.merged_dir), Path(a.tmp_parsed), Path(a.backup)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect(Path(a.data_root) / "workbench.sqlite3")
    rows = []
    for p in sorted(merged_dir.glob("*.merged.json")):
        mpn = p.name.replace(".merged.json", "")
        # merged 文件名用的是 _safe(mpn)，反查原始 MPN 以便定位旧/新文件
        r = db.execute("SELECT mpn, json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        real_mpn = r[0] if r else mpn
        old_name = Path(r[1].replace("\\", "/")).name if r and r[1] else ""
        if not old_name or not (backup / old_name).exists():
            hits = sorted(x.name for x in backup.glob(_safe(real_mpn) + "_*.json"))
            old_name = hits[0] if hits else ""
        new_hits = sorted(tmp.glob(_safe(real_mpn) + "_*.json"))

        old = _load(backup / old_name) if old_name else {}
        new = _load(new_hits[0]) if new_hits else {}
        mg = _load(p)

        checks = {}

        # 1 多语言
        if old.get("multi_language"):
            checks["多语言与旧一致"] = mg.get("multi_language") == old["multi_language"]
        else:
            checks["多语言与旧一致"] = None

        # 2 白名单外顶层字段
        legacy = [k for k in old if k not in PARSE_OWNED]
        lost = [k for k in legacy if k not in mg or mg[k] != old[k]]
        checks["历史字段保留"] = not lost

        # 3 新解析的内容必须真的进来了。
        #   注意不能要求 merged == new：列表是「按主键合并 + 保留旧有项」，
        #   合并结果本就可能比新解析多。要断言的是「新解析的项一条不少」。
        def _sig(d):
            g = lambda k: str((d or {}).get(k) or "").strip().lower()
            return (g("name"), g("condition"), g("unit"))

        def _covers(mg_list, new_list):
            kn = {_sig(x) for x in new_list or [] if isinstance(x, dict)}
            km = {_sig(x) for x in mg_list or [] if isinstance(x, dict)}
            return kn <= km

        o_sp, n_sp, m_sp = old.get("specs") or {}, new.get("specs") or {}, mg.get("specs") or {}
        checks["电气含新解析全部项"] = _covers(m_sp.get("electrical"),
                                                n_sp.get("electrical"))
        checks["最大额定含新解析全部项"] = _covers(m_sp.get("absolute_max"),
                                                    n_sp.get("absolute_max"))
        checks["specs 标量取新值"] = all(
            m_sp.get(k) == n_sp.get(k) for k in ("package", "temperature"))
        checks["订货含新解析全部项"] = _covers(mg.get("ordering_info"),
                                                new.get("ordering_info"))

        # 4 顶层键覆盖
        missing_top = [k for k in old if k not in mg]
        checks["顶层键无缺失"] = not missing_top

        # 5 metadata 取新值
        checks["metadata 取新值"] = (
            (mg.get("metadata") or {}).get("pdf_hash")
            == (new.get("metadata") or {}).get("pdf_hash"))

        # 6 列表项白名单外键
        allowed = PARSE_OWNED.get("pin_configuration") or set()
        dropped = 0
        old_pins = {str(x.get("pin")): x for x in (old.get("pin_configuration") or [])
                    if isinstance(x, dict)}
        for it in (mg.get("pin_configuration") or []):
            if not isinstance(it, dict):
                continue
            src = old_pins.get(str(it.get("pin")))
            if src:
                for k2, v2 in src.items():
                    if k2 not in allowed and k2 not in it:
                        dropped += 1
        checks["引脚历史键保留"] = dropped == 0

        # 7 可解析
        checks["JSON 非空"] = bool(mg)

        ok = all(v is not False for v in checks.values())
        failed = [k for k, v in checks.items() if v is False]
        rows.append({
            "mpn": real_mpn,
            "verdict": "PASS" if ok else "FAIL",
            "failed_checks": ",".join(failed),
            **{k: ("-" if v is None else ("是" if v else "否"))
               for k, v in checks.items()},
            "legacy_top_fields": ",".join(legacy[:6]),
            "lost_legacy": ",".join(lost[:6]),
            "missing_top": ",".join(missing_top[:6]),
            "old_ml_langs": ",".join(sorted((old.get("multi_language") or {}).keys())),
            "mg_ml_langs": ",".join(sorted((mg.get("multi_language") or {}).keys())),
            "old_elec": len((old.get("specs") or {}).get("electrical") or []),
            "mg_elec": len((mg.get("specs") or {}).get("electrical") or []),
            "old_order": len(old.get("ordering_info") or []),
            "mg_order": len(mg.get("ordering_info") or []),
        })

    if rows:
        p = out_dir / "v4_merge_verify.csv"
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("写 %s（%d 行）" % (p, len(rows)))

    n_pass = sum(1 for r in rows if r["verdict"] == "PASS")
    print("\n校验通过 %d / %d 件" % (n_pass, len(rows)))
    for r in rows:
        if r["verdict"] != "PASS":
            print("   FAIL %s：未通过 [%s]；丢失历史字段 %s；顶层缺失 %s"
                  % (r["mpn"], r["failed_checks"], r["lost_legacy"], r["missing_top"]))
    for r in rows:
        print("   %-22s %s 多语言 %s->%s 电气 %s->%s 订货 %s->%s"
              % (r["mpn"], r["verdict"], r["old_ml_langs"], r["mg_ml_langs"],
                 r["old_elec"], r["mg_elec"], r["old_order"], r["mg_order"]))
    return 0 if n_pass == len(rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
