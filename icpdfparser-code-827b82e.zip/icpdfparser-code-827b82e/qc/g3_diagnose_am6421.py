"""诊断 6a 暴露的「预算置换」：AM6421BSEFHAALVR（273 页）。

问题
----
6a 重解后，生产基线里原本存在的 3 行（Supply Voltage / Operating Temperature /
Maximum Clock Frequency）消失了，产物只剩 2 行。要判断这是：

  - **置换**：p209 进来挤掉了这三行的来源页 —— 预算固定，换页必挤页；
  - **结构性不足**：三行来源页散布太广，`MAX_PAGES=14` 根本装不下；
  - **与选页无关**：三行来源页其实还在选页里，消失是 prompt/抽取问题。

设计决策：为什么不用 monkeypatch 模拟旧选页
------------------------------------------
初版打算 monkeypatch `_ec_pick_order` 来复现「尾部保底前」的选页。放弃，原因两条：

1. 不确定 `_ec_pick_order` 是在 `sorted()` 之前还是之后调用的；若在之后，
   identity 替换根本不产生「旧行为」；
2. `select_pages` 内部若用闭包/局部引用捕获，monkeypatch 会**静默失效**——
   而失效时结果看起来还是对的。这正是本次会话已犯三次的同一根因
   （取证源不准 → 奖惩颠倒）。

改为**只读诊断**：不模拟旧选页，只回答「三行来源页在 PDF 哪页 / 在不在当前
选页里」，并把「消失的旧值是否为空」单列——因为空值消失是收敛，不是退化。

另一个绕开的坑
--------------
`PD._iter_pages` 到 `MAX_PAGES` 会 break，拿它搜 273 页只能搜前 14 页，
会让诊断自己制造假阴性。所以这里 pymupdf 直读全文，`_iter_pages` 仅 fallback。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as PD                                # noqa: E402

# 生产基线里消失的三行（v1 有、v2 无）
VANISHED = [
    ("supply_voltage", "Supply Voltage",
     re.compile(r"supply\s*voltage|operating\s*voltage|\bV\s*DD\b", re.I)),
    ("operating_temperature", "Operating Temperature",
     re.compile(r"operating\s*temperature|ambient\s*temperature", re.I)),
    ("max_clock_frequency", "Maximum Clock Frequency",
     re.compile(r"max(?:imum)?\s*clock\s*freq|clock\s*frequency", re.I)),
]


# ---------------------------------------------------------------- PDF 全文

def _page_of(pages_text: list[tuple[int, str]], pat: re.Pattern,
             limit: int = 12) -> list[int]:
    """标签出现的页号（定位用）。

    页号可能非常多——"supply voltage" 在 273 页里能命中几百页——所以截断到
    `limit` 条，另由 `_page_hit_count` 给总数，避免输出淹没结论。
    """
    hits = [pn for pn, text in pages_text if pat.search(text)]
    return hits[:limit]


def _page_hit_count(pages_text: list[tuple[int, str]], pat: re.Pattern) -> int:
    return sum(1 for _pn, text in pages_text if pat.search(text))


def _read_pdf_full(pdf: Path, report: dict) -> list[tuple[int, str]]:
    """pymupdf 直读全文（不经过 `PD._iter_pages`，避免 MAX_PAGES 截断）。"""
    try:
        import fitz                                          # noqa: PLC0415
        with fitz.open(str(pdf)) as doc:
            return [(i + 1, doc[i].get_text("text") or "")
                    for i in range(doc.page_count)]
    except Exception as e:                                   # noqa: BLE001
        report["warnings"].append(f"pymupdf 读取失败：{type(e).__name__}: {e}")
    report["warnings"].append(
        "fallback 到 PD._iter_pages：该函数到 MAX_PAGES 会 break，"
        "全文搜索可能被截断（若来源页 > MAX_PAGES 会漏搜）。")
    out = []
    for pn, text in PD._iter_pages(str(pdf)):
        if isinstance(pn, int) and pn < 1:
            pn += 1
        out.append((pn, text or ""))
    return out


# ---------------------------------------------------------------- 当前选页

def _sel_pages(pdf: Path, pages_text) -> tuple[list[int], int, bool]:
    """当前 `select_pages` 的选中页号。

    不假设返回结构：先试 `(text, used, truncated)`，退化时从 `--- Page N ---`
    标记解析——标记是输出里唯一稳定的契约。
    """
    try:
        text, used, truncated = PD.select_pages(
            iter(pages_text), PD.MAX_PAGES, PD.MAX_CHARS)
    except Exception:                                        # noqa: BLE001
        return [], -1, False
    nums = sorted({int(n) for n in
                   re.findall(r"^---\s*Page\s+(\d+)\s*---", text, re.M)})
    return nums, used, bool(truncated)


def _elec_rows(doc: dict) -> list[dict]:
    sp = doc.get("specs") or {}
    return list(sp.get("electrical") or [])


# ---------------------------------------------------------------- 主流程

def diagnose(mpn: str, data_dir: Path) -> dict:
    report: dict = {"mpn": mpn, "warnings": []}
    pdf_dir = data_dir / "pdfs"
    hits = sorted(pdf_dir.glob(f"{mpn}__*.pdf")) or sorted(pdf_dir.glob(f"{mpn}*.pdf"))
    if not hits:
        report["error"] = f"PDF 未找到：{pdf_dir}/{mpn}*.pdf"
        return report
    pdf = hits[0]
    report["pdf"] = str(pdf)

    pages_text = _read_pdf_full(pdf, report)
    report["page_count"] = len(pages_text)

    cur, used, truncated = _sel_pages(pdf, pages_text)
    report["select_pages"] = {"used": used, "pages": cur,
                              "truncated": truncated}

    # 生产基线行
    prod = sorted((data_dir / "parsed").glob(f"{mpn}_*.json"))
    prod_rows: dict[str, dict] = {}
    if prod:
        try:
            for r in _elec_rows(json.loads(prod[0].read_text(encoding="utf-8"))):
                prod_rows[str(r.get("name") or "").strip()] = r
        except Exception as e:                               # noqa: BLE001
            report["warnings"].append(f"生产基线读取失败：{type(e).__name__}: {e}")

    # ① 逐行定位
    rows = []
    for key, desc, pat in VANISHED:
        hit_pages = _page_of(pages_text, pat)
        total = _page_hit_count(pages_text, pat)
        matched = [r for n, r in prod_rows.items() if pat.search(n)]
        for r in matched:
            val = str(r.get("value") or "").strip()
            rows.append({
                "key": key, "desc": desc,
                "name": str(r.get("name") or ""),
                "v1_value": val,
                "v1_blank": (val == "" or val.lower() == "not_specified"),
                "pages_in_pdf": hit_pages,
                "pages_in_pdf_total": total,
                "in_current_sel": [p for p in hit_pages if p in cur],
                "not_in_current_sel": [p for p in hit_pages if p not in cur],
            })
    report["vanished_rows"] = rows

    # ② 预算守恒
    src_all = sorted({p for r in rows for p in r["pages_in_pdf"]})
    body = max(0, used - 3)
    blank_lost = sum(1 for r in rows if r["v1_blank"])
    real_lost = len(rows) - blank_lost
    report["budget_analysis"] = {
        "src_pages_total": len(src_all),
        "sel_used": used,
        "head_reserved": 3,
        "body_slots": body,
        "fits_in_slots": len(src_all) <= body,
        "lost_rows": len(rows),
        "lost_blank_rows": blank_lost,
        "lost_real_value_rows": real_lost,
        "note": ("fits_in_slots=True 且 lost_real_value_rows>0 → 严格置换；"
                 "fits_in_slots=False → 结构性不足；"
                 "lost_real_value_rows=0 → 消失的全是空值，属正常收敛"),
    }

    # ③ 合成结论：区分「真退化」与「空值收敛」
    #    这是本诊断唯一的决策输出——其余都是取证。
    if not rows:
        report["verdict"] = "NO_VANISHED_ROWS"
        report["verdict_reason"] = "没有消失行 → 无从谈置换"
    elif real_lost == 0:
        report["verdict"] = "EMPTY_ROW_CONVERGENCE"
        report["verdict_reason"] = (
            f"消失的 {len(rows)} 行旧值**全为空/占位**，未丢失任何真值 → "
            f"属正常收敛，不是预算置换，也不是退化")
    else:
        report["verdict"] = "REAL_VALUE_LOST"
        report["verdict_reason"] = (
            f"消失的 {len(rows)} 行里有 {real_lost} 行带非空旧值 → 需人工复核；"
            f"若其来源页不在当前选页内，才是置换")

    return report


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="AM6421 预算置换诊断（只读，零 token）")
    ap.add_argument("--mpn", default="AM6421BSEFHAALVR")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--json-out", default=None)
    a = ap.parse_args(argv)

    rep = diagnose(a.mpn, Path(a.data_dir))
    text = json.dumps(rep, ensure_ascii=False, indent=2)
    print(text)
    if a.json_out:
        out = Path(a.json_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        print(f"\n[written] {out}", file=sys.stderr)
    return 0 if not rep.get("error") else 1


if __name__ == "__main__":
    raise SystemExit(main())
