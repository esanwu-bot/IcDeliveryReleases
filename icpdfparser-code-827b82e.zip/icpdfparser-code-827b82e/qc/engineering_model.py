#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""工程模型状态分层：符号页三产物的**单一事实源**。

为什么要有这个模块
------------------
符号页曾把「几何与视角未核验，不生成工程模型」硬编码在渲染器里，同一句话在
「封装」与「3D 模型」两张卡上各印一遍。它把三件性质完全不同的产物压成一个
笼统的「未核验」：

| 产物 | 真实状态 | 依据 |
| --- | --- | --- |
| 原理图符号 | 球位映射可能已核验 | `metadata.pin_validation` |
| 封装轮廓 2D | 可能命中共享模板；板卡件根本不适用 | `data/pkgs` 索引 + 模板文件 |
| 3D / 球阵几何 | 本轮无可信来源，不生成 | 无机械 CAD / 原厂球阵图 |

三件事混在一句话里，后果有两个：板卡页也印「未核验」，暗示「补核验就能出图」；
文案与状态不同源，门禁无法断言。

本模块只做三件事，**派生不落库**：

1. ``derive_state(doc, pkgs_dir)``：纯函数，输入只用既有事实，输出三产物各自状态；
2. ``render_notes(state)``：state → 文案的**唯一**映射表（渲染器不得手写这些字样）；
3. ``check(doc, symbols_html, state)``：门禁 A1–A5，供 `app/services/review.py` 规则层调用。

纪律
----
* 不给 parsed JSON 新增顶层键，函数内不写盘（AGENT.md §2.3 顶层键守卫）。
* 枚举固定，缺输入 / 非法输入一律 fail-closed 到 ``not_checked`` / ``not_generated``，**不猜**。
* 模板 sha256 在读取模板文件时现算，不依赖索引里的版本列（索引没有这一列）。

模板臂为什么排除网格族（BGA）
-----------------------------
`data/pkgs` 里确实有 `FCBGA-144.svg`，索引也命中，但它**不是签核过的轮廓模板**：
该文件由 `symbol_svg._grid_svg` 按 `ceil(sqrt(144))=12` 生成 12×12 个圆点，
间距与球径都是程序算出来的典型值。把它当模板引用 = 把「按平方根猜的球阵」当
工程几何发布，直接违反 AGENT.md §9.7（BGA 零容忍）与既有单测
`test_pin_repair.py::test_bga_functions_do_not_guess_geometry`（该测试断言 BGA 页
不得出现共享图 `<img>`）。因此模板臂只接受**非网格族**的共享轮廓；
BGA 要升级为 template，必须先有一份带球坐标签核的来源。

import 零 stdout（server 进程安全，AGENT.md §5.14）。
"""
from __future__ import annotations

import csv
import hashlib
import html as _html
import re
from pathlib import Path

from qc.pin_repair import is_bga
from qc.scope_contract import BOARD_TYPES

# ─────────────────────────────────────────────────────────────────────
# 1. 枚举与常量
# ─────────────────────────────────────────────────────────────────────

#: 原理图符号状态。BGA：球位映射是否已签核；非 BGA 只看有没有 pin_validation。
SYMBOL_STATUSES: tuple[str, ...] = ("pass", "fail", "not_checked")

#: 封装轮廓 2D 状态。
#:
#: ``extracted``：按原厂机械图（PACKAGE OUTLINE 页）抽出的尺寸程序化绘制。
#: 它不是「共享模板」——共享模板是预先签核的通用轮廓，与型号无关；这一档的尺寸
#: 来自**本型号自己那份数据手册**的标注，带页码与 bbox 证据，所以单独记一档，
#: 不许并进 ``template``（不是同一件事就不许并进一列，这是 V7 立的规矩）。
OUTLINE_STATUSES: tuple[str, ...] = ("extracted", "template", "not_checked",
                                     "not_applicable")

#: 3D / 球阵几何状态。
#:
#: 注意：``not_applicable`` 是任务书 §2 枚举里漏写、但 §3 文案与 §6 F2 夹具都要求
#: 的值（板卡页的 3D 与轮廓同样「不适用」，不能记成「未生成」——否则板卡页会印
#: 「无可信来源，不猜测」，把「本就不该有」说成「缺证据」）。
GEOMETRY_STATUSES: tuple[str, ...] = ("not_generated", "generated", "not_applicable")

#: 3D 升级为 ``generated`` 所需的可信来源（文案里逐字出现，改这里就是改文案）。
REQUIRED_SOURCE_3D = "机械 CAD（STEP/IBIS）或原厂球阵图"

#: 模板臂排除的封装族：网格族（BGA/LGA/CSP…）的共享图是程序化球阵，不是签核轮廓。
_TEMPLATE_EXCLUDED_FAMILIES: tuple[str, ...] = ("grid",)

#: 页面标记：只有带这个标记的页面（新渲染器产出）才参与 A1–A5 断言。
#: 存量页面是旧文案 + 旧状态的组合，重渲染后才受门禁约束（见 docs/qc/）。
PAGE_MARKER = 'data-em-page="symbols"'
BOUNDARY_MARKER = 'data-em-boundary="engineering-model"'

#: 页面自述「我是按哪个主体渲染的」。渲染器在三条会影响状态的分支上打标：
#: 板卡页（`board_subject=True`）、脚数按族名猜（`pins_unconfirmed=True`）。
#: 门禁/审查侧必须用同一组参数派生状态，否则同一份文档会算出两份状态
#: （实测：7725 页批量重渲染里 77 页 A5 假阳，全部来自板卡页）。
SUBJECT_BOARD_MARKER = 'data-em-subject="board"'
PINS_UNCONFIRMED_MARKER = 'data-em-pins="unconfirmed"'

#: 3D / 球阵几何 SVG 节点的标记（A2 用）。
#: 渲染器**本轮不产出**这些标记（`geometry_3d` 恒 not_generated）；它们的存在说明
#: 页面画了状态不允许的几何。新增几何渲染时必须同步加标记，否则 A2 抓不到。
GEOMETRY_MARKERS: tuple[str, ...] = (
    'data-em-geometry="3d"',
    'data-em-geometry="ball-grid"',
)

#: 注意：A2 **不做文案判定**。曾经试过用「页面出现 3D 模型 / 球阵字样」兜底，两次都错：
#: ① 芯片页 3D 卡里印的是 `… · 3D 示意`（插图，不是模型）→ 所有非模板臂恒报；
#: ② 模板臂的说明句 `封装轮廓按共享模板 … 不含球阵坐标` 也命中「球阵」。
#: 文本里区分「声称有」和「说明没有」需要语义理解，正则做不到；判据只留结构证据：
#: 几何标记 + 3D 图引用是否属于本件自己的封装。

#: A1 的几何关键词与单位（数值必须带单位才算「几何数值」，裸数字不算）。
_GEOMETRY_WORDS = ("pitch", "间距", "球径", "球直径", "焊球", "高度", "厚度", "视角", "仰角", "尺寸")
_GEOMETRY_UNITS = r"(?:mm|µm|μm|um|mil|毫米|°)"
_NUM_UNIT_RE = re.compile(r"\d+(?:\.\d+)?\s*" + _GEOMETRY_UNITS)

#: A3 的「未核验」字样与其作用对象。
_UNVERIFIED_RE = re.compile(r"未核验|未验证|待核")
_OUTLINE_WORD_RE = re.compile(r"封装|轮廓|外形")

#: A4 的芯片几何文案：板卡页出现即说明渲染器走了芯片分支。
_CHIP_PAGE_COPY: tuple[str, ...] = (
    "由 pin_configuration 生成",
    "按封装类型 + 脚数生成",
    "按封装类型程序化绘制",
    "封装轮廓按共享模板",
)

_INDEX_CACHE: dict[tuple[str, float], frozenset[str]] = {}


# ─────────────────────────────────────────────────────────────────────
# 2. 小工具
# ─────────────────────────────────────────────────────────────────────

def _as_int(value) -> int:
    """宽松取整数：``"144"`` / ``144`` 都吃，其它一律 0（不猜）。"""
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def _ball_set_complete(pv: dict, pins: list) -> bool:
    """球集合是否完整：expected / covered 同集合，且条数与声明脚数一致。

    只看 ``status=pass`` 不够 —— 状态是上一次修复写的，球表可能已被下游改动。
    """
    if not isinstance(pv, dict):
        return False
    expected = {str(b).strip().upper() for b in (pv.get("expected_balls") or []) if str(b).strip()}
    covered = {str(b).strip().upper() for b in (pv.get("covered_balls") or []) if str(b).strip()}
    if not expected or expected != covered:
        return False
    if _as_int(pv.get("expected_count")) != len(expected):
        return False
    actual = {str(p.get("pin") or "").strip().upper() for p in pins if isinstance(p, dict)}
    return actual == expected


def _pkgs_index(pkgs_dir) -> frozenset[str]:
    """读 ``data/pkgs/index.csv`` 的 key 集合；缺失/不可读返回空集（fail-closed）。

    索引按 (路径, mtime) 缓存：同一进程内渲染上千件不重复读盘，改了索引会自动失效。
    """
    if not pkgs_dir:
        return frozenset()
    path = Path(pkgs_dir) / "index.csv"
    try:
        stamp = path.stat().st_mtime
    except OSError:
        return frozenset()
    key = (str(path), stamp)
    hit = _INDEX_CACHE.get(key)
    if hit is not None:
        return hit
    keys: set[str] = set()
    try:
        with path.open(encoding="utf-8-sig", newline="") as fh:
            for row in csv.DictReader(fh):
                k = str(row.get("key") or "").strip()
                if k:
                    keys.add(k)
    except (OSError, csv.Error):
        return frozenset()
    frozen = frozenset(keys)
    _INDEX_CACHE[key] = frozen
    return frozen


def _template_sha256(path: Path) -> str:
    """模板文件内容哈希（现算，不依赖索引里的版本列——索引没有这一列）。"""
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return ""


def _canon(raw_pkg: str, pins: int) -> tuple[str, str]:
    """归一化封装 key 与族。延迟 import：避免 symbol_svg ↔ 本模块循环 import。"""
    import symbol_svg as S                                  # noqa: PLC0415

    # 走 `pkg_key` 而不是 `canon_pkg`：派生入口必须只有一个，
    # 否则渲染器与状态层各算一份 key（A2 的根因）。
    key = S.pkg_key(raw_pkg, pins)
    return key, S.pkg_family(key)


# ─────────────────────────────────────────────────────────────────────
# 3. 状态派生（纯函数，不写盘）
# ─────────────────────────────────────────────────────────────────────

def derive_state(doc: dict, pkgs_dir=None, *, source_hash: str = "",
                 board_subject: bool | None = None,
                 pins_unconfirmed: bool = False) -> dict:
    """由既有事实派生三产物状态。

    参数
    ----
    doc       解析后的 JSON（**只读**，不修改、不新增顶层键）
    pkgs_dir  共享封装图目录（含 ``index.csv`` 与 ``{KEY}.svg``）；None = 视为无模板库
    source_hash  仅 3D 预留：调用方传入可信来源哈希时才允许 ``generated``。
                 本轮无此类调用方（§2），传空串恒 ``not_generated``。
    board_subject  板卡主体判定。None（默认）= 只看 ``basic_info.identity``；
                 仅当调用方**已经**按既有 ``symbol_svg._is_board_name`` 规则进入
                 板卡页分支时传 True——那是记录页面已作出的决定，不是新增推断。
                 本函数不因封装名像板卡就自行改判（AGENT.md §9.2 维度不可互授）。
    pins_unconfirmed  脚数是按封装族典型值猜的（渲染器 `uncertain_pins` 分支）。
                 此时「封装 key」本身不可信（脚数参与归一），模板臂必须关闭，
                 否则文案会声称「按共享模板 X 绘制」而页面其实是内联画的。

    返回
    ----
    ``{"symbol": {...}, "package_outline": {...}, "geometry_3d": {...}}``
    """
    doc = doc if isinstance(doc, dict) else {}
    bi = doc.get("basic_info") if isinstance(doc.get("basic_info"), dict) else {}
    specs = doc.get("specs") if isinstance(doc.get("specs"), dict) else {}
    pkg = specs.get("package") if isinstance(specs.get("package"), dict) else {}
    meta = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    pins = doc.get("pin_configuration") if isinstance(doc.get("pin_configuration"), list) else []

    identity = str(bi.get("identity") or "").strip().lower()
    is_board = identity in BOARD_TYPES if board_subject is None else bool(board_subject)
    # 与渲染器共用同一个取值入口（`pkg_type_of`），不做 SEO 兜底猜测
    import symbol_svg as S                                  # noqa: PLC0415
    raw_pkg = S.pkg_type_of(doc)
    declared = _as_int(pkg.get("pins"))
    # 原厂机械图几何（可能没有）。没有 = 继续 fail-closed，不是「本次先不画」。
    geom = _geometry_of(doc)
    # 非网格族页面总会内联一张「按封装类型画的 3D 示意」（见 `model3d_svg`）：
    # 画了图就必须在状态里说清楚那是插图，否则边界小节会与页面对不上。
    illustration = (not is_board) and (not is_bga(raw_pkg))

    return {
        "symbol": _symbol_state(meta, pins, is_board, raw_pkg),
        "package_outline": _outline_state(is_board, raw_pkg, declared, pkgs_dir,
                                          pins_unconfirmed, geom),
        "geometry_3d": _geometry_state(is_board, source_hash, declared, geom, illustration),
    }


def _symbol_state(meta: dict, pins: list, is_board: bool, raw_pkg: str = "") -> dict:
    """原理图符号：只认 ``metadata.pin_validation``，缺失/非 pass 一律 not_checked。

    D4 硬闸（2026-11-04）后 pin_validation 有两套合法契约：
    BGA 老契约（`pass / fail / unresolved`，`pin_repair` 写）与 Reviewer 新契约
    （`passed / failed / unverified`，`deterministic_extract.pin_field_validation`
    写）。`passed` 与 `pass` 同义、`failed` 与 `fail` 同义；`unverified` 与缺失
    一样 fail-closed 为 not_checked —— **渲染页上绝不把未过闸的引脚标 verified**。
    """
    pv = meta.get("pin_validation")
    pv = pv if isinstance(pv, dict) else {}
    status = str(pv.get("status") or "").strip().lower()
    base = {"pin_validation": status or "missing", "balls": len(pins)}
    if is_board:
        # 板卡本就没有本型号的引脚表；不写 not_checked 之外的结论，也不冒充 pass。
        return {"status": "not_checked", "evidence": dict(base, reason="board_subject")}
    if status in ("fail", "failed"):
        reason = str(pv.get("reason") or "").strip() or "pdf_mapping_failed"
        return {"status": "fail", "evidence": dict(base, reason=reason)}
    if status not in ("pass", "passed"):
        reason = (str(pv.get("reason") or "").strip() or "pdf_mapping_unverified")
        return {"status": "not_checked", "evidence": dict(base, reason=reason)}
    if is_bga(raw_pkg) or pv.get("expected_balls"):
        # 球位映射：pass 还不够，球集合必须仍然完整（状态可能是上一轮写的）。
        if not _ball_set_complete(pv, pins):
            return {"status": "not_checked",
                    "evidence": dict(base, reason="ball_coverage_mismatch")}
    return {"status": "pass", "evidence": dict(base, reason="pdf_mapping_verified")}


def _geometry_of(doc: dict) -> dict | None:
    """读 ``specs.package.geometry``（原厂机械图抽出来的几何）。

    只认 ``qc.pkg_geometry.geometry_of`` 认可的那份：结构完整、且互证全过。
    取不到就返回 None —— 渲染与状态共用这一个入口，避免两处各读一套。
    """
    from qc import pkg_geometry                                  # noqa: PLC0415
    return pkg_geometry.geometry_of(doc)


def _outline_state(is_board: bool, raw_pkg: str, declared: int, pkgs_dir,
                   pins_unconfirmed: bool = False,
                   geom: dict | None = None) -> dict:
    """封装轮廓 2D：板卡不适用；有原厂机械图几何 → extracted；命中签核模板 → template。"""
    if is_board:
        return {"status": "not_applicable", "evidence": {"reason": "board_subject"}}
    if geom:
        ev = geom.get("evidence") or {}
        return {"status": "extracted",
                "template_id": "",                    # 刻意留空：它不是共享模板
                "source_sha256": geom.get("source_sha256", ""),
                "evidence": {"reason": "datasheet_package_outline",
                             "page": ev.get("page"),
                             "drawing_code": geom.get("drawing_code", ""),
                             "drawing_no": geom.get("drawing_no", "")}}
    if not raw_pkg:
        return {"status": "not_checked", "evidence": {"reason": "package_type_missing"}}
    if pins_unconfirmed:
        # 脚数是猜的 → key 也不可信，模板臂关闭（fail-closed）
        return {"status": "not_checked", "evidence": {"reason": "pin_count_unconfirmed"}}
    if not pkgs_dir:
        # CLI 未传 --pkg-lib：库存在但本次没加载，证据里要能区分这种情况
        return {"status": "not_checked",
                "evidence": {"reason": "template_library_not_provided"}}
    key, family = _canon(raw_pkg, declared)
    evidence = {"package_key": key, "family": family}
    if family in _TEMPLATE_EXCLUDED_FAMILIES or is_bga(raw_pkg):
        # 网格族的共享图是程序化球阵（见模块 docstring），不是签核轮廓。
        return {"status": "not_checked",
                "evidence": dict(evidence, reason="grid_geometry_not_signed")}
    if key not in _pkgs_index(pkgs_dir):
        return {"status": "not_checked", "evidence": dict(evidence, reason="template_not_indexed")}
    path = Path(pkgs_dir) / f"{key}.svg"
    sha = _template_sha256(path) if path.is_file() else ""
    if not sha:
        return {"status": "not_checked", "evidence": dict(evidence, reason="template_file_missing")}
    return {"status": "template", "template_id": key, "template_sha256": sha,
            "evidence": dict(evidence, reason="template_signed_outline")}


def _geometry_state(is_board: bool, source_hash: str, declared: int,
                    geom: dict | None = None, illustration: bool = False) -> dict:
    """3D / 球阵几何：有可信来源才 ``generated``。

    可信来源现在有两条：调用方显式传入的 ``source_hash``，以及 ``specs.package.geometry``
    ——后者由 ``qc.pkg_geometry`` 从原厂 PACKAGE OUTLINE 页抽出，且**互证全过**才会存在
    （pitch/span/球数自洽、body 大于 span、总高不小于 standoff、球径小于 pitch）。
    两条都没有 → ``not_generated``，页面继续出占位图。
    """
    if is_board:
        return {"status": "not_applicable", "evidence": {"reason": "board_subject"}}
    if isinstance(source_hash, str) and source_hash.strip():
        return {"status": "generated", "source_hash": source_hash.strip(),
                "evidence": {"reason": "trusted_source_hash"}}
    if geom:
        ev = geom.get("evidence") or {}
        return {"status": "generated",
                "source_hash": str(geom.get("source_sha256") or ""),
                "evidence": {"reason": "datasheet_package_outline",
                             "page": ev.get("page"),
                             "drawing_code": geom.get("drawing_code", ""),
                             "drawing_no": geom.get("drawing_no", ""),
                             "rows": geom.get("rows"), "cols": geom.get("cols"),
                             "ball_count": geom.get("ball_count"),
                             "pitch_mm": geom.get("pitch")}}
    ev = {"declared_pins": declared}
    if illustration:
        # 非网格族页面会内联一张「按封装类型画的 3D 示意」。它是插图，不是模型；
        # 这一点必须写进状态，否则边界小节会印「3D 未生成」而旁边就有张图，
        # 客户/复审第一眼就会当成自相矛盾（实测 ADS1201U 页就是这样）。
        ev["illustration"] = "programmatic_by_package_family"
    return {"status": "not_generated", "reason": "no_trusted_source",
            "required_source": REQUIRED_SOURCE_3D,
            "evidence": ev}


def flags_from_page(page: str) -> dict:
    """从页面自述标记读出派生状态时要带的参数（板卡主体 / 脚数未确认）。"""
    page = page if isinstance(page, str) else ""
    return {"board_subject": SUBJECT_BOARD_MARKER in page,
            "pins_unconfirmed": PINS_UNCONFIRMED_MARKER in page}


def derive_state_for_page(doc: dict, pkgs_dir=None, page: str = "") -> dict:
    """按**页面自述的主体**派生状态 —— 门禁/审查侧的唯一入口。

    为什么不能直接调 ``derive_state(doc, pkgs_dir)``：渲染器在板卡页用的是
    ``board_subject=True``、在脚数靠族名猜的页面用 ``pins_unconfirmed=True``。
    调用方看不到这两个决定，用默认参数派生就会算出**另一份**状态，
    于是「页面文案（按 A 派生）」对不上「审查状态（按 B 派生）」——A5 假阳。
    实测：7725 页批量重渲染里 77 页 A5 命中，全部是这一类，不是页面写错了。

    页面没有自述标记时退回默认派生（旧页面 / 说明页），行为与之前一致。
    """
    return derive_state(doc, pkgs_dir, **flags_from_page(page))


# ─────────────────────────────────────────────────────────────────────
# 4. 文案（唯一映射表）
# ─────────────────────────────────────────────────────────────────────

def render_notes(state: dict) -> list[str]:
    """state → 工程模型边界文案。**这是全仓库唯一允许出现这些字样的地方。**

    顺序固定：先轮廓、后 3D；同一句只出一次（板卡的 outline / 3d 都是
    not_applicable，但那是同一件事，不重复印）。
    """
    state = state if isinstance(state, dict) else {}
    outline = state.get("package_outline") or {}
    geom = state.get("geometry_3d") or {}
    notes: list[str] = []

    o_status = str(outline.get("status") or "").strip()
    if o_status == "extracted":
        ev = outline.get("evidence") or {}
        page = ev.get("page")
        ident = " ".join(x for x in (str(ev.get("drawing_code") or "").strip(),
                                     str(ev.get("drawing_no") or "").strip()) if x) or "—"
        loc = f"第 {page} 页" if page else "机械图页"
        # 这一句同时覆盖 2D 轮廓与 3D 球阵：两者出自同一张机械图，
        # 说的是同一件事，分成两句只是把「工程模型边界」撑长。
        notes.append(
            f"封装轮廓与 3D 球阵按原厂机械图绘制：{loc}（图纸 {ident}）；"
            "尺寸取自图上标注（本体 / 总高 / standoff / pitch / 球径 / 球数），"
            "非通用模板，不含推测值。球位与 3D 为示意，不替代 CAD 模型与焊盘设计文件。")
    elif o_status == "template":
        tid = str(outline.get("template_id") or "").strip() or "UNKNOWN"
        sha = str(outline.get("template_sha256") or "")
        notes.append(
            f"封装轮廓按共享模板 {tid} 绘制（内容哈希 {sha[:8] or '--------'}）；"
            "模板为共享轮廓，不含球阵坐标。")
    elif o_status == "not_checked":
        notes.append("封装轮廓未绘制：该封装在库中无签核共享模板。")
    elif o_status == "not_applicable":
        notes.append("板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。")

    g_status = str(geom.get("status") or "").strip()
    if g_status == "not_generated":
        tail = ""
        if (geom.get("evidence") or {}).get("illustration"):
            tail = "页面中的 3D 图为按封装类型绘制的示意，不是模型，也不含球阵坐标。"
        notes.append(
            f"3D 模型与球阵几何未生成：无可信来源（{REQUIRED_SOURCE_3D}），不猜测。{tail}")
    elif g_status == "not_applicable":
        notes.append("板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。")
    # generated：画出来了就没有「边界」要声明，不产文案。

    seen: set[str] = set()
    return [n for n in notes if not (n in seen or seen.add(n))]


def panel_captions(state: dict, *, renders_3d_illustration: bool = False) -> dict[str, str]:
    """卡片副标题（只给「非默认臂」；空 dict = 保留渲染器默认文案）。

    与 ``render_notes`` 同源：模板臂沿用既有默认副标题（字节不变），
    只有状态不再是「正常产出」时才换短标签，避免旧文案「未核验」与新状态打架。

    ``renders_3d_illustration``：页面是否真的画了共享 3D **示意**图
    （非 BGA 的共享图库产物）。那种情况 3D 卡片有图可看，副标题不该写「未生成」；
    示意图的 aria-label 已自带「3D 示意」，不冒充工程模型。
    """
    state = state if isinstance(state, dict) else {}
    outline = str((state.get("package_outline") or {}).get("status") or "")
    geom = str((state.get("geometry_3d") or {}).get("status") or "")
    out: dict[str, str] = {}
    if outline == "extracted":
        out["footprint"] = "按原厂机械图尺寸绘制"
    if outline == "not_checked":
        out["footprint"] = "轮廓未绘制"
    elif outline == "not_applicable":
        out["footprint"] = "不适用"
    if geom == "not_generated" and not renders_3d_illustration:
        out["model3d"] = "未生成"
    elif geom == "not_applicable":
        out["model3d"] = "不适用"
    elif geom == "not_generated" and renders_3d_illustration:
        # 有内联示意图可看，副标题不该写「未生成」；但也**不能**沿用
        # 「按封装类型程序化绘制」——那读起来像"已经有 3D 模型了"，
        # 与本页边界小节「3D 模型与球阵几何未生成：无可信来源」直接打架
        # （A2 就是这么把它抓出来的）。这里是插图，就把「示意」写进副标题。
        out["model3d"] = "示意（按封装类型程序化绘制）"
    elif geom == "generated":
        # 有真实几何：明确写清来源，避免与「示意」混淆，也不冒充 CAD 模型
        out["model3d"] = "按原厂机械图尺寸绘制"
    return out


# ─────────────────────────────────────────────────────────────────────
# 5. 门禁 A1–A5
# ─────────────────────────────────────────────────────────────────────

def _visible_text(page: str) -> list[str]:
    """标签之间的可见文本（不含属性值——SVG 坐标不是页面上的数值）。"""
    return [_html.unescape(m).strip()
            for m in re.findall(r">([^<>]+)<", page) if m.strip()]


def _boundary_items(page: str) -> list[str] | None:
    """取「工程模型边界」小节的逐条文案；页面没有该小节返回 None。"""
    start = page.find(BOUNDARY_MARKER)
    if start < 0:
        return None
    body = page[start:]
    end = body.find("</section>")
    if end >= 0:
        body = body[:end]
    return [_html.unescape(re.sub(r"<[^>]+>", "", m)).strip()
            for m in re.findall(r"<li[^>]*>(.*?)</li>", body, re.S)]


def _finding(kind: str, severity: str, message: str, field: str, quote: str) -> dict:
    return {"kind": kind, "severity": severity, "message": message,
            "evidence": {"field": field, "quote": quote[:400]}}


def check(doc: dict, symbols_html: str, state: dict) -> list[dict]:
    """A1–A5：页面断言。返回 review 规则层同形的 findings（零 token）。

    只在**带页面标记**的新产物上断言：存量页面是旧文案 + 旧状态，重渲染前
    逐条报没有意义（§「文案与状态不同源」本身就是这次要修的病）。

    检查器自身异常不抛出：规则层不能因一个页面断言把整件 review 打挂，
    但也不许静默——降级成一条可追溯的 P2（与 A5 同 kind，带 checker_error 证据）。
    """
    try:
        return _check(doc, symbols_html, state)
    except Exception as e:                                     # noqa: BLE001
        return [{"kind": "symbol_page_boundary_text_drift", "severity": "P2",
                 "message": f"工程模型边界检查器异常：{type(e).__name__}: {e}"[:200],
                 "evidence": {"field": "symbols_html", "quote": "checker_error"}}]


def _check(doc: dict, symbols_html: str, state: dict) -> list[dict]:
    page = symbols_html if isinstance(symbols_html, str) else ""
    if not page or PAGE_MARKER not in page or not isinstance(state, dict):
        return []

    doc = doc if isinstance(doc, dict) else {}
    bi = doc.get("basic_info") if isinstance(doc.get("basic_info"), dict) else {}
    identity = str(bi.get("identity") or "").strip().lower()
    is_board = identity in BOARD_TYPES

    outline = state.get("package_outline") or {}
    geom = state.get("geometry_3d") or {}
    o_status = str(outline.get("status") or "")
    g_status = str(geom.get("status") or "")
    runs = _visible_text(page)
    joined = " ".join(runs)
    out: list[dict] = []

    # A1：页面出现几何数值，但状态里没有任何几何来源
    if o_status != "template" and g_status != "generated":
        for run in runs:
            if not any(w in run.lower() for w in _GEOMETRY_WORDS):
                continue
            m = _NUM_UNIT_RE.search(run)
            if m:
                out.append(_finding(
                    "symbol_page_geometry_unsupported", "P1",
                    "页面出现几何数值，但封装轮廓非共享模板、3D 未生成——没有任何可信几何来源",
                    "symbols_html.geometry", f"{run}｜命中 {m.group(0)}"))
                break

    # A2：状态说没生成，页面却画了 3D / 球阵几何
    if g_status != "generated":
        hit = next((mk for mk in GEOMETRY_MARKERS if mk in page), "")
        if hit:
            out.append(_finding(
                "symbol_page_3d_node_without_state", "P1",
                "geometry_3d 未生成，页面却含打了几何标记的 3D/球阵节点",
                "symbols_html.geometry_3d", hit))
        else:
            # 共享图库里的 `.3d.svg` 是**示意插图**，用本件自己的封装 key 是合法的；
            # 引用**别人的** key（A 页挂着 B 封装的模型）才是越界，也才是这条能查的东西。
            # 同样不做文案判断：`封装轮廓按共享模板 … 不含球阵坐标` 这类说明句会误伤。
            keys = {str(outline.get("template_id") or ""),
                    str((outline.get("evidence") or {}).get("package_key") or "")}
            allowed = tuple(f"{k}.3d.svg" for k in keys if k)
            refs = re.findall(r'<img[^>]+src="([^"]*\.3d\.svg)"', page, re.I)
            bad = [r for r in refs if not (allowed and r.endswith(allowed))]
            if bad:
                out.append(_finding(
                    "symbol_page_3d_node_without_state", "P1",
                    "geometry_3d 未生成，页面却引用 3D 图（且不是本件自己封装 key 的示意图）",
                    "symbols_html.geometry_3d", bad[0]))

    # A3：状态说轮廓有模板，页面仍就轮廓印「未核验」
    if o_status == "template":
        for m in _UNVERIFIED_RE.finditer(joined):
            lo, hi = max(0, m.start() - 30), min(len(joined), m.end() + 30)
            window = joined[lo:hi]
            if _OUTLINE_WORD_RE.search(window):
                out.append(_finding(
                    "symbol_page_outline_text_conflict", "P1",
                    "package_outline=template，页面却仍就封装轮廓印「未核验」字样",
                    "symbols_html.outline", window.strip()))
                break

    # A4：板卡身份与状态/文案不一致（身份、页面、状态三方都算）
    # 「页面是不是板卡页」优先信页面自述标记，其次才是旧文案特征。
    page_is_board = (SUBJECT_BOARD_MARKER in page) or ("板卡 / 模块类" in page)
    if is_board:
        if o_status != "not_applicable" or g_status != "not_applicable":
            out.append(_finding(
                "symbol_page_board_state_mismatch", "P0",
                "identity=evaluation_board/development_kit，但工程模型状态不是 not_applicable",
                "package_outline.status",
                f"outline={o_status or '缺失'}; 3d={g_status or '缺失'}"))
        chip = next((c for c in _CHIP_PAGE_COPY if c in page), "")
        if chip:
            out.append(_finding(
                "symbol_page_board_state_mismatch", "P0",
                "板卡页印了芯片几何文案——渲染器走了芯片分支",
                "symbols_html.caption", chip))
    elif page_is_board:
        # 页面已按封装名走板卡分支（`symbol_svg._is_board_name`），状态必须同步；
        # 不同步就会出现「页说板卡、状态说芯片缺模板」的自相矛盾页。
        if o_status != "not_applicable" or g_status != "not_applicable":
            out.append(_finding(
                "symbol_page_board_state_mismatch", "P1",
                "页面是板卡说明页，但工程模型状态不是 not_applicable",
                "package_outline.status",
                f"identity={identity or '缺失'}; outline={o_status}; 3d={g_status}"))
    elif o_status == "not_applicable" or g_status == "not_applicable":
        out.append(_finding(
            "symbol_page_board_state_mismatch", "P1",
            "非板卡页却给出 not_applicable：状态派生与页面主体不一致",
            "basic_info.identity",
            f"identity={identity or '缺失'}; outline={o_status}; 3d={g_status}"))

    # A5：边界小节与 render_notes 逐字一致（防渲染器私加/漏印文案）
    items = _boundary_items(page)
    if items is None:
        out.append(_finding(
            "symbol_page_boundary_text_drift", "P1",
            "页面缺「工程模型边界」小节（新产物必须带，否则文案不可断言）",
            "symbols_html.boundary", PAGE_MARKER))
    else:
        want = render_notes(state)
        if items != want:
            out.append(_finding(
                "symbol_page_boundary_text_drift", "P1",
                "「工程模型边界」小节与 render_notes(state) 不一致",
                "symbols_html.boundary",
                f"页面={items}｜应为={want}"))

    return out


def page_has_marker(page: str) -> bool:
    """页面是否由新渲染器产出（A1–A5 的前提）。"""
    return isinstance(page, str) and PAGE_MARKER in page


def catalog() -> dict:
    """机器可读清单（文档/审计用）。"""
    return {
        "statuses": {"symbol": list(SYMBOL_STATUSES),
                     "package_outline": list(OUTLINE_STATUSES),
                     "geometry_3d": list(GEOMETRY_STATUSES)},
        "required_source_3d": REQUIRED_SOURCE_3D,
        "page_marker": PAGE_MARKER,
        "boundary_marker": BOUNDARY_MARKER,
        "geometry_markers": list(GEOMETRY_MARKERS),
    }
