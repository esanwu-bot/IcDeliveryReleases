"""只读核账：把重解析批次的「实际处理清单」与「备份 / 现文件 / 原件」逐件对平。

为什么不能凭总数推断
--------------------
备份目录同名即覆盖（`shutil.copy2(f, backup / f.name)`），而先前的单件验证
（`--mpn` 小批）也往同一个备份目录写。因此「备份份数」既不等于「本次处理件数」，
也不等于「可还原件数」：需要按文件名逐件判定。

本脚本只读三处，不写 parsed / backup：
  * 日志里的处理清单（进度、状态、旧/新订货行数）
  * data/parsed 现文件
  * data/parsed_backup_ordering 备份

逐件输出：是否找到文件、是否有备份、内容是否被改写、
文件名哈希与 metadata.pdf_hash 是否一致、备份与现文件的 SHA256。

用法（容器内）
--------------
    python qc/reconcile_batch.py --log /tmp/reparse_batch.log \
        --out /tmp/reconcile.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.reparse_ordering import _safe                       # noqa: E402

# [169/228] DDC118IRTCTG4            订货行 0 -> 2（51.1s） 保留 basic_info.datasheet_url
# [167/228] DDC118IRTCR              变差 1 -> 0，已回滚
# [168/228] XXX                      解析失败：PARSE_FAILED: ...
_LINE = re.compile(r"^\[(\d+)/(\d+)\]\s+(\S+)\s+(.*)$")
_ROWS = re.compile(r"订货行 (\d+) -> (\d+)")
_WORSE = re.compile(r"变差 (\d+) -> (\d+)")
_NAME_HASH = re.compile(r"^(.*)_([0-9a-f]{8})$")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_log(path: Path) -> tuple[list[dict], int]:
    """返回逐件记录与日志声明的总数。后出现的同 MPN 记录覆盖先出现的。"""
    rows: dict[str, dict] = {}
    order: list[str] = []
    total = 0
    for ln in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = _LINE.match(ln)
        if not m:
            continue
        n, tot, mpn, rest = int(m.group(1)), int(m.group(2)), m.group(3), m.group(4)
        total = max(total, tot)
        rec = rows.get(mpn)
        if rec is None:
            rec = rows[mpn] = {"seq": n, "mpn": mpn}
            order.append(mpn)
        rec["seq"] = n
        rw = _ROWS.search(rest)
        w = _WORSE.search(rest)
        if w:
            rec.update(status="rolled_back", old=int(w.group(1)), new=int(w.group(2)))
        elif rw:
            rec.update(status="ok", old=int(rw.group(1)), new=int(rw.group(2)))
        elif "解析失败" in rest:
            rec.update(status="failed", old=None, new=None,
                       error=rest.split("解析失败", 1)[1].lstrip("：:").strip()[:120])
        else:
            rec.setdefault("status", "unknown")
        # 「保留 xxx」记录被 _carry_over 带回来的字段
        if "保留 " in rest:
            rec["kept"] = rest.split("保留 ", 1)[1].strip()
    return [rows[k] for k in order], total


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="重解析批次只读核账")
    ap.add_argument("--log", default="/tmp/reparse_batch.log")
    ap.add_argument("--data-dir", default=str(ROOT / "data" / "parsed"), dest="data_dir")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"))
    ap.add_argument("--pdfs", default=str(ROOT / "data" / "pdfs"))
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)

    data_dir, backup = Path(a.data_dir), Path(a.backup)
    pdfs = Path(a.pdfs)
    t0 = time.strftime("%F %T")
    print("核账时间 %s" % t0)

    log = Path(a.log)
    if not log.exists():
        print("日志不存在：%s" % log)
        return 2
    recs, total = parse_log(log)
    print("日志声明总件数 %d，已出现记录 %d 件" % (total, len(recs)))

    # ---- 现文件索引：一次性扫目录，避免逐件 glob ----
    cur: dict[str, Path] = {p.name: p for p in data_dir.glob("*.json")}
    bak: dict[str, Path] = {p.name: p for p in backup.glob("*.json")}
    print("现文件 %d 个 / 备份 %d 个" % (len(cur), len(bak)))

    # 备份名 -> 主体（去掉 _hash8）
    def _stemkey(name: str) -> str:
        m = _NAME_HASH.match(name[:-5] if name.endswith(".json") else name)
        return m.group(1) if m else (name[:-5] if name.endswith(".json") else name)

    bak_by_key: dict[str, list[str]] = {}
    for n in bak:
        bak_by_key.setdefault(_stemkey(n), []).append(n)

    rows: list[dict] = []
    for r in recs:
        key = _safe(r["mpn"])
        cands = sorted(n for n in cur if _stemkey(n) == key)
        row = {
            "seq": r["seq"], "mpn": r["mpn"], "status": r.get("status", "unknown"),
            "old_rows": r.get("old"), "new_rows": r.get("new"),
            "files_found": len(cands), "fname": "|".join(cands),
            "backup_files": "|".join(sorted(bak_by_key.get(key, []))),
            "backup_count": len(bak_by_key.get(key, [])),
        }
        # 逐文件比对：现文件 vs 同名备份
        changed, hash_ok, note = [], [], []
        for n in cands:
            p = cur.get(n)
            b = bak.get(n)
            if b is None:
                note.append("无同名备份")
                continue
            same = _sha(p) == _sha(b) if p else False
            changed.append("未变" if same else "已改写")
            try:
                meta = (json.loads(p.read_text(encoding="utf-8")).get("metadata") or {})
            except (OSError, json.JSONDecodeError):
                meta = {}
            mh = str(meta.get("pdf_hash") or "")
            m = _NAME_HASH.match(n[:-5])
            want = m.group(2) if m else ""
            hit = bool(mh) and mh[:8] == want
            hash_ok.append("一致" if hit else "不一致")
            row["meta_pdf_hash"] = mh[:16]
            row["name_hash"] = want
        row["content"] = "|".join(changed) or "-"
        row["hash_name_vs_meta"] = "|".join(hash_ok) or "-"
        row["note"] = "|".join(note)
        # 原件是否被换掉：备份里记录的 pdf_hash vs 现文件记录的 pdf_hash
        old_h = new_h = ""
        if cands:
            b0 = bak.get(cands[0])
            if b0 is not None:
                try:
                    old_h = str((json.loads(b0.read_text(encoding="utf-8"))
                                 .get("metadata") or {}).get("pdf_hash") or "")
                except (OSError, json.JSONDecodeError):
                    old_h = ""
            new_h = str(row.get("meta_pdf_hash") or "")
        row["old_pdf_hash"] = old_h[:16]
        row["new_pdf_hash"] = new_h[:16]
        row["src_changed"] = ("换了原件" if old_h and new_h and old_h[:16] != new_h[:16]
                              else ("同原件" if old_h and new_h else "未知"))
        # 「改写」是实际落盘的判据
        row["rewritten"] = "是" if "已改写" in changed else "否"
        rows.append(row)

    # ---- 汇总 ----
    n = len(rows)
    has_bak = sum(1 for r in rows if r["backup_count"] > 0)
    rewritten = sum(1 for r in rows if r["rewritten"] == "是")
    no_bak = [r for r in rows if r["backup_count"] == 0]
    unchanged = [r for r in rows if r["rewritten"] == "否" and r["backup_count"] > 0]
    tie = [r for r in rows if r["old_rows"] is not None
           and r["new_rows"] is not None and r["new_rows"] == r["old_rows"]]
    imp = [r for r in rows if r["old_rows"] is not None
           and r["new_rows"] is not None and r["new_rows"] > r["old_rows"]]
    worse = [r for r in rows if r["status"] == "rolled_back"]
    failed = [r for r in rows if r["status"] == "failed"]
    multi = [r for r in rows if r["files_found"] > 1]
    mism = [r for r in rows if "不一致" in r["hash_name_vs_meta"]]

    print("\n=== 本次处理清单核对 ===")
    print("记录 %d 件：有备份 %d / 无备份 %d" % (n, has_bak, n - has_bak))
    print("实际改写落盘 %d 件 / 内容未变 %d 件" % (rewritten, len(unchanged)))
    print("改善 %d / 持平 %d / 变差回滚 %d / 失败 %d"
          % (len(imp), len(tie), len(worse), len(failed)))
    print("对应到多个现文件（重复）%d 件；文件名哈希与 metadata 不一致 %d 件"
          % (len(multi), len(mism)))

    if no_bak:
        print("\n[!] 无备份的件（%d）：" % len(no_bak))
        for r in no_bak:
            print("    %s seq=%s 状态=%s 现文件=%s"
                  % (r["mpn"], r["seq"], r["status"], r["fname"] or "无"))
    if unchanged:
        print("\n[!] 有备份但内容与备份相同（未被改写或改写结果一致）（%d）：" % len(unchanged))
        for r in unchanged[:20]:
            print("    %s seq=%s" % (r["mpn"], r["seq"]))
        if len(unchanged) > 20:
            print("    ... 共 %d 件" % len(unchanged))
    if multi:
        print("\n[!] 同一 MPN 对应多个现文件：")
        for r in multi:
            print("    %s -> %s" % (r["mpn"], r["fname"]))
    if mism:
        print("\n[!] 文件名哈希与 metadata.pdf_hash 不一致：")
        for r in mism:
            print("    %s 文件=%s name_hash=%s meta=%s"
                  % (r["mpn"], r["fname"], r["name_hash"], r.get("meta_pdf_hash")))

    # ---- 原件是否被换：这是「解析的到底是不是同一份文档」的判据 ----
    src_chg = [r for r in rows if r["src_changed"] == "换了原件"]
    print("\n=== 原件一致性 ===")
    print("同原件 %d / 换了原件 %d / 无法判定 %d"
          % (sum(1 for r in rows if r["src_changed"] == "同原件"),
             len(src_chg), sum(1 for r in rows if r["src_changed"] == "未知")))
    if src_chg:
        print("[!] 换了原件的件（新 doc 描述的可能不是同一份文档）：")
        for r in src_chg:
            print("    seq=%s %-22s 旧=%s 新=%s"
                  % (r["seq"], r["mpn"], r["old_pdf_hash"] or "-", r["new_pdf_hash"] or "-"))

    # ---- 备份侧：日志外的孤儿备份（先前单件验证留下的） ----
    log_keys = {_safe(r["mpn"]) for r in recs}
    orphan_keys = sorted(k for k in bak_by_key if k not in log_keys)
    print("\n=== 备份目录侧 ===")
    print("备份 %d 份，其中主体不在本次处理清单里的 %d 份（先前 --mpn 验证遗留）"
          % (len(bak), len(orphan_keys)))
    for k in orphan_keys[:20]:
        print("    孤儿备份：%s" % ", ".join(sorted(bak_by_key[k])))
    if len(orphan_keys) > 20:
        print("    ... 共 %d 组" % len(orphan_keys))
    # 备份有、现文件没有（被改名或删除）
    missing_cur = sorted(n for n in bak if n not in cur)
    print("备份存在但现文件已不存在：%d 份" % len(missing_cur))
    for nname in missing_cur[:20]:
        print("    仅存于备份：%s" % nname)

    # ---- ADS1254E 专项：哪个哈希对应磁盘上真实 PDF ----
    print("\n=== ADS1254E 原件关联 ===")
    for n in sorted(x for x in cur if _stemkey(x) == "ADS1254E"):
        p = cur[n]
        try:
            meta = json.loads(p.read_text(encoding="utf-8")).get("metadata") or {}
        except (OSError, json.JSONDecodeError):
            meta = {}
        m = _NAME_HASH.match(n[:-5])
        print("  文件 %s  名内哈希=%s  metadata.pdf_hash=%s  备份=%s"
              % (n, m.group(2) if m else "-", str(meta.get("pdf_hash"))[:16],
                 "有" if n in bak else "无"))
    for pdf in sorted(pdfs.glob("ADS1254E*.pdf")):
        print("  磁盘 PDF %s sha256=%s" % (pdf.name, _sha(pdf)[:16]))

    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        cols = ["seq", "mpn", "status", "old_rows", "new_rows", "files_found",
                "fname", "backup_count", "backup_files", "content",
                "hash_name_vs_meta", "name_hash", "meta_pdf_hash",
                "old_pdf_hash", "new_pdf_hash", "src_changed", "rewritten", "note"]
        with out.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for r in sorted(rows, key=lambda x: x["seq"]):
                w.writerow(r)
        print("\n明细已写 %s（%d 行）" % (out, len(rows)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
