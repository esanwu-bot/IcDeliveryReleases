"""料号身份判定（L2 + L3）：芯片 / 评估板 / 开发套件，还是判不出来。

三层分工（不要用同一个词库解决三件事）
--------------------------------------
    L1 封装名称归一化   `symbol_svg.canon_pkg` + 计划中的 qc/package_norm.py
                        （只做 名字 -> family/pins 映射，不判「这颗芯片有没有这个封装」）
    L2 料号身份识别     **本模块**（规则注册表 + 置信度，只给候选身份）
    L3 证据与状态机     **本模块**（四+1 状态；判决权在这层，不在词表）

状态机（对应 docs/规则库落地参考.md）
-------------------------------------
    IDENTITY_SUPPORTED   订货表精确匹配，或只是包装/等级变体写法     -> PASS
    BOARD_CONFIRMED      板卡规则命中且 datasheet 里有板卡表述        -> PASS，走 board 模板
    IDENTITY_REVIEW      板卡规则命中但缺原厂证据                     -> WARN + 阻断，进人工
    IDENTITY_CONFLICT    上游给出「这份 datasheet 不是这个料号」的正面矛盾 -> FAIL + 阻断
    EVIDENCE_INCOMPLETE  订货表没抽到 / 抽到了却对不上任何同族条目    -> WARN（多数仅提示）

判决顺序（证据强度从高到低，**先命中先返回**）
---------------------------------------------
    0. 上游传入 contradiction（正面矛盾）          -> CONFLICT
    1. 订货表精确匹配                              -> SUPPORTED(high)
    2. 只是某个可订购号的包装/等级变体             -> SUPPORTED(medium)
    3. 板卡规则命中（词表只在这里起作用）          -> CONFIRMED / REVIEW
    4. 同族可订购号（>=2 条）                      -> SUPPORTED(medium)
    5. 订货表 < 2 条                               -> INCOMPLETE
    6. 其它（抽到了但无同族）                      -> INCOMPLETE（advisory）

关键纪律
--------
* 词表命中**不等于**结论。`EB` 只作 identity_review 线索（confidence=low）：
  TI 的 `ADS7822EB`、`ADS8321EB` 里 `EB` 是**封装代号**，订货表里就有这个可订购号，
  这类必须靠订货表证据推翻词表（第 2 步先于第 3 步就是为了这个）。
* 缺匹配**不等于**冲突。13,511 件真实回放显示「请求料号不在订货表」**100% 是同族
  写法差异**（BOM 写族根 `INA117`、写旧封装 `74ACT11244NSR`、写军标
  `5962-9450901XA`），没有一件是真的拿错 datasheet。所以「不在表内」只降为
  提示，`CONFLICT` 必须有正面矛盾证据才可达。
* `IDENTITY_REVIEW` 不自动标 board、也不自动标 chip —— 这两者都是猜。

规则注册表
----------
`qc/mpn_identity_rules.json` 是唯一事实来源（JSON 便于 code review 与 diff）。
每条规则带 id / 厂商 / pattern / match_mode / 候选类型 / 置信度 / 动作 /
证据要求 / 来源 / 审核人 / 测试案例。`qc/identity_rules.py selftest` 会拿
test_cases 回归；`status=candidate` 的规则只提示，不参与冲突判决。

只依赖标准库，不 import app.*，常驻进程引用无副作用。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parent / "mpn_identity_rules.json"

# 兼容旧调用方（review.py 的 BOARD_TOKENS 常量仍在用）；真实词表以 JSON 为准。
BOARD_TOKENS = ("EVM", "EVK", "EVB", "EMK", "EVAL", "KIT", "BOARD",
                "MODULE", "DONGLE", "PDK", "DEMO", "EB")

# 信封/环保尾巴：判定前剥掉，否则 `...EB/NOPB` 永远以 NOPB 结尾
_TAIL = re.compile(r"(?:[/\-_ ](?:NOPB|NO\.?[A-Z]|NPB|PB|R[0-9]|T&R))+$", re.I)

# datasheet 里「这块板」的自述（有这句才算板卡证据）
_BOARD_TEXT = re.compile(
    r"evaluation\s+(board|module|kit)|eval(uation)?\s+board|"
    r"user'?s?\s+guide|EVM\b|评估板|开发板", re.I)

# 订货表章节标题（可能出现在目录、修订记录里，光命中不算数）
_ORDER_SECTION = re.compile(
    r"(orderable\s+part\s+number|package\s+option\s+addendum|ordering\s+information)",
    re.I)
_MPN_SHAPE = re.compile(r"\b[A-Z]{2,}[A-Z0-9]{3,}\b")

# 包装 / 等级 / 环保后缀：剥掉后不改变器件身份。
# 只收「一定不改身份」的 token —— 绝不能让 V/M/L/K 单独进来，
# 否则 EVAL / EVM / EVK / EMK 会被当成包装尾巴，把评估板误判成芯片。
_PKG_TOKEN = re.compile(
    r"^(?:(?:R|T|TR|REEL|TUBE|"                  # 卷带 / 管装
    r"G4|E4|PB|NOPB|NOA|NOB|NPB|"                # 环保 / 无铅
    r"Q1|EP|"                                     # 车规 / 散热焊盘
    r"E|A|B|X|S|"                                 # 单字母等级或封装代字
    r"\d+K\d*|\d+))*$",                           # 2K5 / 250 / 3000
    re.I)

# 封装/等级代字的形状：纯字母 ≤4 位（KU / HT / QKA / DR）
_PKG_CODE = re.compile(r"[A-Z]{1,4}")

SUPPORTED = "IDENTITY_SUPPORTED"
CONFIRMED = "BOARD_CONFIRMED"
REVIEW = "IDENTITY_REVIEW"
CONFLICT = "IDENTITY_CONFLICT"
INCOMPLETE = "EVIDENCE_INCOMPLETE"

BOARD_TYPES = ("evaluation_board", "development_kit")

# 状态 -> (自动 QC 判定, 是否阻断发布)
VERDICT = {
    SUPPORTED: ("PASS", False),
    CONFIRMED: ("PASS", False),
    REVIEW: ("WARN", True),
    CONFLICT: ("FAIL", True),
    INCOMPLETE: ("WARN", True),
}


# ---------------------------------------------------------------- 文本工具
def norm(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def stem(mpn: str) -> str:
    """剥掉包装/环保尾巴：ADC128D818EB/NOPB -> ADC128D818EB。"""
    s = re.sub(r"\s+", "", (mpn or "").strip())
    prev = None
    while prev != s:
        prev = s
        s = _TAIL.sub("", s)
    return s


def family_root(mpn: str) -> str:
    """家族根：ADC128D818CIMT/NOPB -> ADC128D818。"""
    b = norm(stem(mpn))
    m = re.match(r"^(.*\d)[A-Z]{1,6}$", b)
    return m.group(1) if m and len(m.group(1)) >= 4 else b


# ---------------------------------------------------------------- 规则注册表
_rules_cache: list[dict] | None = None


def rules() -> list[dict]:
    global _rules_cache
    if _rules_cache is None:
        try:
            data = json.loads(RULES_PATH.read_text(encoding="utf-8"))
            _rules_cache = list(data.get("rules") or [])
        except (OSError, json.JSONDecodeError):
            _rules_cache = []
    return _rules_cache


def reload_rules() -> None:
    """改完 JSON 不用重启进程。"""
    global _rules_cache
    _rules_cache = None


def _mfr_match(rule: dict, mfr: str) -> bool:
    want = str(rule.get("manufacturer") or "*").strip()
    if want in ("*", ""):
        return True
    return want.lower() in (mfr or "").lower() or (mfr or "").lower() in want.lower()


def _suffix_tail(tok: str) -> str:
    """后缀 token 之后允许的尾巴形态（按 token 长度分两种，别用一套通吃）。

    长 token（EVM/EVK/EMK/EVAL/KIT/BOOST/PDK）：
        `数字 + 可选分隔符尾巴` 都要收 —— `CC1111EMK868-915` 的 868 后面
        还跟着 `-915` 频段变体，只收 `\\d+` 会把整件漏成 chip/PASS。
    短 token（DK/EB，2 字符）：
        只收 >=3 位的数字（可再跟分隔符尾巴），即套件的频段码
        （`CC1020-CC1070DK868`、`CC1101DK868-915`）。
        拒绝 `DK6` / `DK7` 这类单数字后缀 —— `TMS320F28P650DK6` 的 DK 是
        **芯片封装代字**，收进来就会把芯片判成 development_kit。
        （频段码是 315/433/470/868/915，都是 3 位；封装代字后只跟 1 位。）

    两者共同点：仍然拒绝「数字 + 字母」（`DK6NMRR`、`EMK868AB`），
    那是芯片订货后缀的形态，不是套件尾巴。
    """
    if len(tok) <= 2:
        return r"(?:[-_/ ].*|\d{3,}(?:[-_/ ].*)?)?"
    return r"(?:[-_/ ].*|\d+(?:[-_/ ].*)?)?"


def match_rule(mpn: str, manufacturer: str = "") -> dict:
    """命中的板卡规则（token 长者优先）。没命中返回 {}。"""
    body = stem(mpn)
    best: dict = {}
    for r in rules():
        pat = str(r.get("pattern") or r.get("token") or "")
        mode = str(r.get("match_mode") or "suffix").lower()
        if not pat or not _mfr_match(r, manufacturer):
            continue
        hit = False
        if mode == "suffix":
            tok = pat.upper()
            # 后缀后面常跟套件编号/配置码：DRV2667EVM-CT、CC1020EMK-868、
            # CC1111EMK868-915。允许哪些形态由 _suffix_tail() 按 token 长度决定。
            m = re.search(r"%s%s$" % (re.escape(tok), _suffix_tail(tok)), body, re.I)
            if m:
                head = body[:m.start()]
                # 主体可以是 alnum 或以分隔符结尾（DAC8760EMC-EVM 的 head 末尾是 -）
                clean_head = re.sub(r"[^A-Z0-9]+$", "", head, flags=re.I)
                hit = bool(clean_head) and len(clean_head) >= 2 and not (
                    len(tok) <= 2 and len(norm(head)) < 4)
        elif mode == "regex":
            try:
                hit = bool(re.search(pat, mpn or "", re.I))
            except re.error:
                hit = False
        elif mode == "contains":
            try:
                hit = bool(re.search(pat, mpn or "", re.I))
            except re.error:
                hit = pat.upper() in (mpn or "").upper()
        elif mode == "prefix":
            hit = (mpn or "").upper().startswith(pat.upper())
        if hit and len(pat) > len(str(best.get("pattern") or "")):
            best = r
    return best


def orderables(doc: dict) -> list[str]:
    out = []
    for o in (doc.get("ordering_info") or []):
        if isinstance(o, dict):
            m = norm(o.get("mpn"))
            if m:
                out.append(m)
    return out


def _device_from_orderables(mpn: str, orders: list[str]) -> str:
    """用订货表反推板载器件：只认公共前缀，推不出就返回空（不硬取别的料号）。"""
    root = norm(stem(mpn))
    best = ""
    for o in orders:
        n = min(len(root), len(o))
        common = 0
        while common < n and root[common] == o[common]:
            common += 1
        if common >= 6 and common > len(best):
            best = root[:common]
    return family_root(best) if best else ""


def _common_prefix(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def _same_family(mpn: str, orders: list[str]) -> list[str]:
    """同族订货号。

    主判据：「前缀 + 后续不能紧跟数字」——
    LM358 -> LM358DR 是同族；LM35 -> LM358 是另一颗（后接数字），必须拒。

    退路：料号**以数字结尾**时 `family_root()` 会整体失效
    （`ADS6225IRGZ25`、`74LVC1G3208DBVRE4`、`AWR1843ARBSALPRQ1`），
    此时改用「最长公共前缀 >= 8 且断点不是两个数字」判同族。
    回放里这类有 188 件，全靠主判据会掉进「身份未知」。
    """
    fam = family_root(mpn)
    out = []
    if len(fam) >= 4:
        for o in orders:
            if not o.startswith(fam):
                continue
            rest = o[len(fam):]
            if rest and rest[0].isdigit():
                continue
            out.append(o)
    if out:
        return out

    req = norm(mpn)
    if len(req) < 8:
        return []
    for o in orders:
        n = _common_prefix(req, o)
        if n < 8:
            continue
        # 断点两边都是数字 -> 是不同型号（LM358 vs LM3501），不是同族
        a = req[n] if n < len(req) else ""
        b = o[n] if n < len(o) else ""
        if a.isdigit() and b.isdigit():
            continue
        out.append(o)
    return out


def pkg_variant(mpn: str, orders: list[str]) -> str:
    """请求料号是否只是某个可订购号的**包装/等级变体写法**；命中返回那条订货号。

    这是「凭证据」的那一支：订货表里确实有这颗器件的号，只是 BOM 写法不同。

        INA117            <- INA117KU        请求写族根（更短）
        ADS7822EB/250G4   <- ADS7822EB250    请求多一层包装后缀
        2N7001TDCKR       <- 2N7001TDCK      请求多一个卷带 R

    防过头的两条约束：
    * 请求更长时，多出来的部分必须**全是**包装 token（`_PKG_TOKEN`），
      于是 `ADS1254EVM` 减去 `ADS1254E` 剩 `VM` 会被拒 —— 那是块板，不是包装；
    * 请求更短时，订货号紧随其后的字符不能是数字，
      于是 `LM35` 不会被 `LM358` 认成同族（那是另一颗芯片）。
    """
    req = norm(mpn)
    if len(req) < 5:
        return ""
    for o in orders:
        if not o or o == req:
            continue
        if o.startswith(req):
            # 请求写得更短（BOM 写族根）：余量必须是**封装/等级代字**的形状，
            # 纯字母且不超过 4 位（KU / HT / QKA / DR）。
            # 这样 `CC1020EMK868` 不会被 `CC1020EMK868CIMTNO...` 吃掉。
            rest = o[len(req):]
            if _PKG_CODE.fullmatch(rest):
                return o
        elif req.startswith(o):
            if _PKG_TOKEN.match(req[len(o):]):
                return o
    return ""


def has_ordering_section(text: str) -> bool:
    """正文里**真的有**订货表章节（而不是目录/修订记录里提一句）。

    判据：章节标题之后 400 字内出现 >=2 个料号形状的 token。
    `DDC118IRTCT` 那种 "ordering information, see the Package Option Addendum
    located at the end of this data sheet" 只有一句话、没有料号，不算——
    否则「该抽到却没抽到」会被这类句子误判成阻断。
    """
    t = text or ""
    for m in _ORDER_SECTION.finditer(t):
        if len(_MPN_SHAPE.findall(t[m.end():m.end() + 400])) >= 2:
            return True
    return False


def board_evidence(text: str) -> str:
    """datasheet / 用户指南里是否自述为评估板；返回命中的原话片段。"""
    m = _BOARD_TEXT.search(text or "")
    if not m:
        return ""
    i = max(0, m.start() - 40)
    return re.sub(r"\s+", " ", (text or "")[i:m.end() + 60]).strip()


# ---------------------------------------------------------------- 判定
def classify(mpn: str, doc: dict, package_type: str = "",
             manufacturer: str = "", pdf_text: str = "",
             contradiction: str = "") -> dict:
    """L3 状态机。返回：

        identity         chip | evaluation_board | development_kit | unknown
        state            五态之一
        verdict          PASS | WARN | FAIL
        blocks_release   是否阻断发布
        confidence       high | medium | low
        rule_id          命中规则 id
        device_mpn       板载器件（BOARD_CONFIRMED 时才给）
        in_orderables    请求料号是否在订货表内
        orderable_count  订货表条数
        requires_human   是否需要人工核验
        advisory         仅提示、不阻断（INCOMPLETE 的多数分支）
        evidence         人话证据

    `contradiction` 是唯一能让状态落到 `IDENTITY_CONFLICT` 的入口：
    上游（PDF 首页标题比对、用户补录、原厂产品页）拿到「这份 datasheet
    描述的**不是**这个料号」的正面证据时传进来。**缺匹配永远不是矛盾。**
    """
    doc = doc or {}
    orders = orderables(doc)
    req = norm(mpn)
    in_orders = bool(req) and req in orders
    rule = match_rule(mpn, manufacturer)
    kind = str(rule.get("candidate_type") or "evaluation_board")
    tok = str(rule.get("pattern") or rule.get("token") or "")

    out = {"identity": "unknown", "state": INCOMPLETE, "verdict": "WARN",
           "blocks_release": True, "confidence": "low",
           "rule_id": str(rule.get("id") or ""), "device_mpn": "",
           "in_orderables": in_orders, "orderable_count": len(orders),
           "requires_human": True, "advisory": False, "evidence": []}

    # 0) 正面矛盾（上游给证据）：这是唯一进 CONFLICT 的路径
    if contradiction:
        out.update(state=CONFLICT, requires_human=True, confidence="high")
        out["evidence"].append("存在与料号身份矛盾的正面证据：%s"
                               % str(contradiction)[:160])
        out["verdict"], out["blocks_release"] = VERDICT[CONFLICT]
        return out

    # 1) 订货表精确匹配 -> 有原厂证据
    #
    # 注意：「在订货表内」证明的是**这个料号被这份 datasheet 收录**，不等于
    # 「它是芯片」—— TI 的 EVM 本身就有订购码（ADS122C04EVM、ADC12010EVAL/NOPB），
    # 板卡的订购码当然会出现在板上器件的文档或被单独收录。所以要不要按板卡处理，
    # 由规则注册表的 `when_orderable` 决定（EB 是封装代字，标 chip；其余标 board）。
    if in_orders:
        if rule and str(rule.get("when_orderable") or "") == "board":
            out.update(identity=kind, state=CONFIRMED, requires_human=True,
                       device_mpn=_device_from_orderables(mpn, orders))
            out["evidence"].append(
                "请求料号本身就在订货表内（共 %d 条），且以 `%s` 结尾 → "
                "这是可订购的板卡，不是裸芯片" % (len(orders), tok))
            out["verdict"], out["blocks_release"] = VERDICT[CONFIRMED]
            return out
        out.update(identity="chip", state=SUPPORTED, confidence="high",
                   requires_human=False)
        out["evidence"].append(
            "请求料号在 datasheet 订货表内（共 %d 条）→ 芯片，有原厂证据" % len(orders))
        out["verdict"], out["blocks_release"] = VERDICT[SUPPORTED]
        return out

    # 2) 只是某个可订购号的包装/等级变体写法 -> 仍是同一颗芯片
    #
    # 必须排在板卡规则之前：TI 的 `ADS7822EB`、`ADS8321EB` 里 `EB` 是**封装代号**，
    # 订货表里就列着 `ADS7822EB`，这时 `EB=评估板` 的词表判断是错的。
    var = pkg_variant(mpn, orders)
    if var:
        out.update(identity="chip", state=SUPPORTED, confidence="medium",
                   requires_human=False)
        out["evidence"].append(
            "请求料号不在订货表逐字列出，但是 `%s` 的包装/等级变体写法"
            "（订货表共 %d 条）→ 同一颗芯片" % (var, len(orders)))
        out["verdict"], out["blocks_release"] = VERDICT[SUPPORTED]
        return out

    # 3) 板卡规则命中：有板卡证据才算确认，否则只提示复核
    if rule:
        quote = board_evidence(pdf_text)
        dev = _device_from_orderables(mpn, orders)
        out.update(identity=kind, confidence=str(rule.get("confidence") or "low"),
                   device_mpn=dev)
        out["evidence"].append(
            "料号主体以 `%s` 结尾，命中规则 %s（候选身份 %s，置信度 %s）"
            % (tok, out["rule_id"], kind, out["confidence"]))
        if orders:
            out["evidence"].append(
                "请求料号不在 datasheet 订货表内（共 %d 条）" % len(orders))
        if quote:
            out.update(state=CONFIRMED, requires_human=True)
            out["evidence"].append("datasheet 有板卡表述：%s" % quote[:120])
            out["verdict"], out["blocks_release"] = VERDICT[CONFIRMED]
        else:
            out.update(state=REVIEW, requires_human=True)
            out["evidence"].append(
                "缺少原厂板卡证据（无 EVM 用户指南 / 产品页映射）→ 人工确认后再定身份")
            out["verdict"], out["blocks_release"] = VERDICT[REVIEW]
        return out

    # 4) 同族可订购号 -> 订货表讲的就是这一族，只是写法不同
    #
    # 13,511 件真实回放里，「请求料号不在订货表」的 641 件**全部**能在这里
    # 找到同族订货号（BOM 写族根 INA117、写旧封装 74ACT11244NSR、写军标
    # 5962-9450901XA）。它们不是冲突，是同一颗芯片的不同写法。
    same = _same_family(mpn, orders)
    if same:
        out.update(identity="chip", state=SUPPORTED, confidence="medium",
                   requires_human=False)
        out["evidence"].append(
            "请求料号未逐条列入订货表，但与 %d 条同族订货号同族（%s）"
            "→ 判为同一族器件的不同写法" % (len(same), "、".join(same[:3])))
        out["verdict"], out["blocks_release"] = VERDICT[SUPPORTED]
        return out

    # 5) 订货表没抽到 / 抽不全 -> 不猜
    if len(orders) < 2:
        # 区分「该有却没抽到」和「这份 datasheet 本来就没有订货表」：
        # 后者（NE555 这类老 datasheet）不该阻断发布，否则一次误报就是上万件。
        has_table = has_ordering_section(pdf_text or "")
        out["advisory"] = not has_table
        out["evidence"].append(
            "datasheet 未抽到有效订货表（%d 条）%s"
            % (len(orders), "，且正文无订货表章节 → 仅提示" if not has_table
               else "，但正文有订货表章节 → 先修提取"))
        out["verdict"], out["blocks_release"] = VERDICT[INCOMPLETE]
        if not has_table:
            out["blocks_release"] = False
        return out

    # 6) 抽到了订货表，但一条都对不上、也没有板卡线索
    #
    # 这是**提取/命名**问题的典型形态（TI 内部料号 2U3823-50QDBVRG4Q1 对应
    # TPS382350Q1、旧料号 1P1G126QYEPR 对应 SN74LVC1G126YEPR），不是身份冲突，
    # 所以只提示，不进 FAIL、也不阻断。
    out.update(state=INCOMPLETE, advisory=True)
    out["evidence"].append(
        "请求料号不在订货表内（共 %d 条），表里也没有同族条目 → "
        "多半是内部料号命名或提取不全，仅提示" % len(orders))
    out["verdict"], out["blocks_release"] = VERDICT[INCOMPLETE]
    out["blocks_release"] = False
    return out


def is_board(info: dict) -> bool:
    """候选身份是板卡类就走板卡渲染口径（与状态无关，状态只决定门禁）。"""
    return str((info or {}).get("identity") or "") in BOARD_TYPES


def datasheet_scope(info: dict) -> str:
    """评估板借用芯片 datasheet 时必须声明覆盖范围。"""
    return "onboard_device" if is_board(info) else ""
