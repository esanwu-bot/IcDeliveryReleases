#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HANDOFF 2026-10-26 | qc/table_audit.py 确定性表格复核审计（agent-Qwen 原版落地 + 项目适配）
背景：11 件缺陷回归（图二）+ 图一 8 类问题的事实层总闸。LLM 只给定位与回显，
数值/单位/MIN-TYP-MAX/封装/引脚一律以 PyMuPDF find_tables 的程序化抽取为准（确定性覆盖）。
行为：
  - 默认 dry：只出报告与 patched 内存副本，不写盘；
  - --write：备份原 JSON 为 {原文件名}.pre_audit.json 后写回补丁（写回读入的源路径），
    并落 data/facts/{safe_name}.facts.json（SSOT 侧车）；
  - 不逐型号硬编码：全部规则为列角色/维度本体/受控词表；找不到表或歧义 → *_unresolved，不猜。
项目适配（相对 agent-Qwen 原版的改动，均标 ADAPT）：
  A1 路径根 = 项目根（脚本位于 qc/ 下），data/{parsed,pdfs,txt,facts} 为权威运行时目录；
  A2 文件名匹配走 safe_name + 8 位哈希后缀（{sn}_{hash}.json / {sn}__{slug}.pdf），
     并回退 qc/json、qc/pdfs 基线（qc 工具箱自成一体，本地无 data 目录也可跑）；
  A3 --write 写回读入的源 JSON 路径（原版固定写 data/parsed/{mpn}.json，与本库命名不符）；
  A4 to_num 容忍 ± 前缀（±10 原版解析为 None，导致 Ioff 类行丢失）；
  A5 新增 D1f row_missing：主规格表（现有条目定位成功 ≥2 的 MIN/TYP/MAX 表）中
     未被任何 JSON 条目认领的参数行 → 追加为带 columns/source 的新条目（确定性，不猜）；
  A6 Windows 控制台 utf-8 输出。
环境变量：ICPDF_AUDIT_MAX_PAGES（默认 80）
退出码：0=无发现或已全部补丁；2=存在 unresolved；3=件/PDF 缺失
用法：
  python qc/table_audit.py ADC3910S065IRSMT
  python qc/table_audit.py --mpn-file qc/fixtures/fix11_models.txt
  python qc/table_audit.py --all --limit 200 --report data/qc/audit.json
"""
from __future__ import annotations
import argparse, contextvars, datetime, hashlib, json, os, re, sqlite3, sys, io
from pathlib import Path

# `columns_raw` 的来源词表单源（§11.5）：与 `qc/five_stage.py` 共用一份，
# 各写各的字面量会让 G0 的 origin 门禁在"字段有值、来源是错的"情况下静默放行。
# 双路 import：包内 import 走 `qc.`，`python qc/table_audit.py` 直跑时 sys.path[0] 是 `qc/`。
try:
    from qc.column_origins import COLUMN_ORIGINS, DEFAULT_ORIGIN
except ImportError:                                     # 脚本直跑
    from column_origins import COLUMN_ORIGINS, DEFAULT_ORIGIN

try:
    import pymupdf as fitz  # PyMuPDF >= 1.24
except ImportError:
    try:
        import fitz
    except ImportError:
        sys.stderr.write("需要 pymupdf>=1.24：pip install pymupdf\n"); sys.exit(3)

# ADAPT A9: Windows 控制台 utf-8 输出。幂等：被 qc_regression 等再 import 时不得重包一层
# （旧 wrapper 失去引用被 GC 时会连带关闭共享 buffer，后续 print 全报 closed file）
if not getattr(sys.stdout, "_qc_utf8", False):
    # `line_buffering=True` 不能省：TextIOWrapper 默认按块（8KB）缓冲，
    # 会把命令行 `python -u` 的效果一并吃掉 —— 于是重定向到日志文件的长任务
    # （灰度、批量重跑）在整个跑完之前，日志始终是 0 字节，看起来像"卡死了"。
    # 一行一刷的代价在批量写盘面前可以忽略，换来的是"进度可见"。
    _w = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace",
                           line_buffering=True)
    _w._qc_utf8 = True
    sys.stdout = _w

# ADAPT A1: 脚本在 qc/ 下，数据目录在项目根 data/
ROOT   = Path(__file__).resolve().parent.parent
PARSED = ROOT / "data" / "parsed"
PDFS   = ROOT / "data" / "pdfs"
TXT    = ROOT / "data" / "txt"
FACTS  = ROOT / "data" / "facts"
DB     = ROOT / "data" / "workbench.sqlite3"
QC_JSON = ROOT / "qc" / "json"     # ADAPT A2: qc 基线回退
QC_PDFS = ROOT / "qc" / "pdfs"
MAX_PAGES = int(os.getenv("ICPDF_AUDIT_MAX_PAGES", "80"))

HASH_SUFFIX = re.compile(r"_[0-9a-f]{8}$")

def safe_name(mpn: str) -> str:
    """与项目 safe_name() 口径一致：/ # 空格 → _"""
    return re.sub(r"[/#\s]+", "_", (mpn or "").strip())

# ── 单位维度本体 ──
UNIT_DIM = {
    "mA": "current", "A": "current", "µA": "current", "uA": "current", "nA": "current",
    "mW": "power", "W": "power", "µW": "power", "uW": "power",
    "V": "voltage", "mV": "voltage",
    "MHz": "frequency", "kHz": "frequency", "GHz": "frequency", "Hz": "frequency", "bps": "frequency",
    "°C": "temperature", "C": "temperature",
    "Ω": "resistance", "ohm": "resistance", "pF": "capacitance", "nF": "capacitance",
    "ns": "time", "µs": "time", "us": "time", "ms": "time", "s": "time",
    "%": "percent", "dB": "log", "V/us": "rate",
}
DIM_KW = [  # 顺序即优先级：power 先于 current，避免 PDIS 被电流词抢走
    ("power",       [r"\b(power|dissipation|pdis|pdiss|ptot|pavg|pmax|pd)\b"]),
    ("current",     [r"\b(current|icc|idd|ioff|ion|iavdd|idvdd|ioidd|iddq|ibias|ileak|leakage|iquiescent|quiescent|ios|iout|iin|ihl|ilh|izt|irk|io|ib|if)\b"]),
    ("voltage",     [r"\b(voltage|vcc|vdd|vss|vout|vin|vref|vtrip|vclamp|voh|vol|vih|vil|threshold|vf|vr|vo|vi|vt)\b"]),
    ("frequency",   [r"\b(frequency|freq|fmax|fclk|fout|fin|fosc|rate|speed|clock)\b", r"mhz|khz|ghz"]),
    ("temperature", [r"\b(temperature|temp|tj|ta|tstg|tcase)\b"]),
]
#: ADAPT A20：全部角色词都带词边界。旧写法 `\bmin\b|minimum` 会命中
#: `MinimumInputClockRate` / `MaximumInputClockRate` 这类**数据行参数名** ——
#: ADC08B200 的 p9 因此把第一行数据当成了表头（真表头 row0 被丢）。
#: `LIMITS` 是 TI 老式 `Limits (3)` 合并列（一列同时装 MIN 与 MAX，侧别写在 Units 列里）。
#: 它的正则**必须整格锚定**（只允许 `Limits` / `Limits (3)`）：
#:   ① `Units (Limits)` 的 `limits` 在括号里，不能被抢成数值列；
#:   ② 表头上方那段脚注 `Boldface limits apply for TJ = ...` 里有 `limits` 字样，
#:      宽匹配会让整段说明文字"像表头"（`header_like` 就是这么被骗的）。
ROLE_RES = [("MIN", re.compile(r"\bmin\b|\bminimum\b")), ("TYP", re.compile(r"\btyp\b|\btypical\b")),
            ("MAX", re.compile(r"\bmax\b|\bmaximum\b")), ("UNIT", re.compile(r"\bunit")),
            ("COND", re.compile(r"condition|test\b|notes|remarks")),
            ("LIMITS", re.compile(r"^\s*limit(s)?\s*(?:\([^)]*\))?\s*$"))]
NUM_RE  = re.compile(r"[±+-]?\d+(?:[.,]\d+)?(?:\s?[eE][+-]?\d+)?")
UTOK_RE = re.compile(r"(?:[±+-]?\s?\d+(?:[.,]\d+)?)\s*([a-zA-ZΩµ°/%]+)\s*$")

def now_iso(): return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
def clean(c):  return re.sub(r"\s+", " ", (c or "").replace("\n", " ")).strip()
def nsym(s):   return re.sub(r"[^a-z0-9]", "", (s or "").lower())

#: 数值单元格「文字被重排」的识别式（BQ2003 实测，见 repair_bad_number_cell）。
#: 判据只认三种无法原样当数字用的形态，不碰「0.2 ∗VCC」这类公式格：
#:   '45 .'      ← 4.5：小数点被拆成独立 token
#:   '20 .'      ← 2.0
#:   '20 - .'    ← -2.0：负号也被挪到数字后面
#:   'VCC 1 .0 -'← VCC - 1.0：符号整段被挪位
_RE_DECIMAL_TAIL = re.compile(r"^[±+\-−]?\d+[-−]?\.$")           # 去空白后，只剩数字 + 尾随号 + 点
_RE_SIGN_AFTER  = re.compile(r"\d[-−]")                          # 数字后面跟负号 = 符号挪位

#: 多值重排的尾巴：'18 55 . .' / '24 33 . .' / '079 116 . .'
#: find_tables 把**两个右对齐数值格**的小数点全挪到末尾，数字本体按列序留在前面。
#: 只认「≥2 个数字 + 末尾成串的点」，不碰 '0.2 ∗VCC' 这类公式格（它没有尾巴点）。
_RE_MULTI_TAIL = re.compile(r"^\d+(?:\s+\d+)+\s*(?:\.\s*){2,}$")


def bad_number_cell(s: str) -> bool:
    """单元格文本是否被 find_tables 的字符重排破坏到不能当数字用。"""
    raw = re.sub(r"\s+", " ", (s or "").strip())
    if _RE_MULTI_TAIL.match(raw):
        return True
    t = re.sub(r"\s+", "", s or "")
    if not t:
        return False
    if _RE_DECIMAL_TAIL.match(t):
        return True
    return bool(_RE_SIGN_AFTER.search(t)) and not t.startswith(("-", "−"))

def cell_text_from_words(page, bbox) -> str:
    """按 cell 的 bbox 从 ``get_text('words')`` 重建单元格文本。

    为什么不直接用 ``Table.extract()``：它对右对齐的数值列会改变字符分组顺序。
    BQ2003 第 10 页 IIZ 行实测：

        words 原始片段： x=267.0 '-2.0'   x=316.4 '-'   x=352.8 '2.0'   x=390.3 'µA'
        extract() 给出： '20\\n- .'  /  '-'  /  '20\\n.'        ← 负号与小数点被挪位

    按坐标重拼得回 ``-2.0``。只用于「已被判定重排」的格子，正常格子不动。
    """
    try:
        ws = page.get_text("words", clip=fitz.Rect(*bbox))
    except Exception:
        return ""
    if not ws:
        return ""
    ws.sort(key=lambda w: (round(w[1], 1), w[0]))
    return "\n".join(w[4] for w in ws)

def to_num(s):
    m = NUM_RE.search(clean(s))
    if not m: return None
    try: return float(m.group(0).replace(",", "").replace("±", "+"))  # ADAPT A4
    except ValueError: return None


#: 「整格就是一个数」的形态：可选正负号 + 数字 + 可选尾随单位。ADAPT A12
_RE_NUM_ONLY = re.compile(r"^[±+\-−−]?\d+(?:[.,]\d+)?$")


#: 占位符格：表示「这一列没有值」，不是「值不可解析」。
_BLANK_TOKENS = {"-", "--", "—", "–", "−", "/", ".", "n/a", "na", "n.a.", "tbd"}


def is_blank_cell(s) -> bool:
    """空串 / 占位符 = 「这一列没有值」。**不是脏** —— 否则只有 TYP 一列的表全判脏。"""
    t = clean(s).lower().strip()
    return (not t) or t in _BLANK_TOKENS


def cell_num(s):
    """单元格 → 干净数值；**不干净就不猜**，返回 ``None``。

    ``to_num`` 是「从任意文本里捞第一个数」，用在**诊断**上没问题（只用来比大小），
    但 ``patch_cols`` 是**写盘**，必须保证整格就是一个数。实测两个坏写盘：

        '0 .7 × IOVDD'  → to_num=0.0  → 写成 "0 MIN"（原文是 0.7×IOVDD 公式）
        '10 20'         → to_num=10.0 → 写成 "10 MIN"（两格被并成一格，真值是 20）

    判据三条都要过：① 去掉尾随单位后只剩一个数；② 原格里的数字 token 只有一个；
    ③ 不含 ``× ∗ - + /`` 这类运算符。任何一条不过就返回 None，
    让上游把这条记成 ``cell_unparsable_unresolved``，**宁可不写，也不写错**。
    """
    t = clean(s)
    if not t:
        return None
    if len(_COND_DIGITS.findall(t)) != 1:      # '10 20' / '-0.3 to +7.0'
        return None
    core = re.sub(r"\s*[a-zA-ZΩµμ°/%·]+\s*$", "", t)   # 去掉尾随单位
    core = re.sub(r"\s+", "", core).replace("−", "-").replace("–", "-")  # U+2212 / en dash 归一
    if not _RE_NUM_ONLY.match(core):           # '0.7×' / 'VCC-1.0'
        return None
    return to_num(core)
def cell_unit(s):
    m = UTOK_RE.search(clean(s)); return m.group(1) if m else None
def u_norm(u): return (u or "").replace("uA", "µA").strip()
def dim_unit(u): return UNIT_DIM.get(u_norm(u)) or UNIT_DIM.get((u or "").strip())
def dim_symbol(sym, param):
    t = f"{sym or ''} {param or ''}".lower()
    for dim, res in DIM_KW:
        if any(re.search(r, t) for r in res): return dim
    return None
#: 当前正在审计的表所在的页码。由 `audit_electrical` 拿到 tbl 后 set，
#: `finding()` 读它补 `page`。用 ContextVar 而不是给 `finding` 加第 5 个参数：
#: 全模块 15 处调用点逐个加参数既冗长又必漏；而**不能**把 `finding` 包成局部 helper
#: —— `finding_kinds_audit` 靠扫描 `finding(path, "kind", ...)` 的字面量登记 kind，
#: 包装一层会让扫描直接失明（那是曾经出过假绿的防线）。
_PAGE: contextvars.ContextVar = contextvars.ContextVar("table_audit_page", default=None)


def finding(path, kind, jv, tv):
    """构造一条 finding。``page`` 来自 `_PAGE`，取不到就不写（不猜页码）。

    `table` 字段保留各调用点的原有语义（多数是证据：``"FUSED_COLUMN"`` /
    ``{"row_values": [...]}``；`row_ambiguous_unresolved` 用它存表序号）。
    这个不一致是历史遗留，下游（`grey_readonly` 数融合列、`worker` 展示）
    已经按现状消费，本次只补 `page`，不动 `table`。
    """
    d = {"path": path, "kind": kind, "json": jv, "table": tv, "at": now_iso()}
    pg = _PAGE.get()
    if pg is not None:
        d["page"] = pg
    return d

# ── 表格扫描与列角色 ──
#: 角色正则的字典形式（``ROLE_RES`` 是给 ``role_map`` 顺序匹配用的 list）。
_ROLE_RX = dict(ROLE_RES)

#: 数值三角色。一列里同时出现两个以上 → 竖向网格线丢了，MIN/TYP/MAX 挤在一格。
_FUSED_ROLES = ("MIN", "TYP", "MAX")


#: 表头角色全表（`header_roles` 的识别范围）。比 `_FUSED_ROLES` 多一个 `LIMITS`：
#: 它代表「一列同时装 MIN 与 MAX」（TI 2013 版手册的 `Limits (3)`），**不直接落 columns**，
#: 写盘前由 :func:`limits_column_split` 按 Units 列的 `(min)`/`(max)` 拆开。
_HEADER_ROLES = ("MIN", "TYP", "MAX", "LIMITS")


#: 角色词的完整拼写 —— 用来识别「被劈到列边界上」的残片（`'MA'|'X'` ← `MAX`）。
_ROLE_FULL = ("minimum", "typical", "maximum", "min", "typ", "max")


#: 阻断类 finding：**不进入 `patched` 桶**，该件不得进 ok 列表。
#: 与 `*_unresolved` 的区别是语义强度：unresolved 是「没判」，blocking 是
#: 「判定条件根本不成立，谁也别想放行」。目前只有一种：
#:   fused_column_blocking —— 关键参数的 MIN/NOM/MAX 列融合，读不出列
BLOCKING_KINDS: frozenset[str] = frozenset({"fused_column_blocking",
                                           # 2026-11-03 外审 V1：多封装列只抽第一列，
                                           # 与融合列同级 —— 都是「列语义丢了」。
                                           "column_collapse",
                                           # 2026-11-03 GH-15/GH-18：MIN/TYP/MAX 两列
                                           # 被连写成 `a to b` —— 假的「区间内都合规」。
                                           "role_collapse"})

#: 命中这些参数名才算「关键参数」，融合列才升级为阻断。
#: 口径刻意保守：这些是**工程师真正会拿去算电路**的量，读错会烧板子；
#: 而 `Gain` / `THD` 这类描述性参数读不出列只是「这行没核到」，不值得全库阻断。
_BLOCKING_PARAM_RE = re.compile(
    r"resolution|volt(age)?|\bv(cmi|cm|dd|cc|ih|il|oh|ol|ref|in|out)\b|"
    r"temperature|current|power|frequency|\brate\b|clock",
    re.I,
)


def _is_blocking_param(param: str) -> bool:
    return bool(_BLOCKING_PARAM_RE.search(param or ""))


def _alpha(s: str) -> str:
    """只留字母，用于跨列拼词（``'NOM MA'`` → ``'nomma'``）。"""
    return re.sub(r"[^a-z]", "", (s or "").lower())


def _roles_split_across(header, i) -> set:
    """``header[i]`` 与 ``header[i+1]`` 之间是否劈开了一个角色词？返回涉及的列号。

    `find_tables` 按**表头文字的 bbox** 切列，一个词正好压在列边界上时会被劈成两半，
    各进一列。ADC3910 p12 t0 实测：PDF 上是 ``| MIN  NOM  MAX | UNIT |``
    （三词挤在一列），但切出来是::

        header[3] = 'MIN'      hx = (430.7, 458.4)
        header[4] = 'NOM MA'   hx = (458.4, 505.4)   ← 'MAX' 的 'MA' 落在这里
        header[5] = 'X UNIT'   hx = (505.4, 553.7)   ← 'MAX' 的 'X' 落在这里

    于是 ``role_map`` 一列都认不出 ``'NOM MA'``（``\\bmax\\b`` 匹配不上 ``ma``），
    值 ``'60'`` 被算在 index 3（MIN）名下，而它的 bbox 横跨到 index 4 ——
    最后靠 A16 的 ``SPANS_MULTIPLE_ROLES`` 兜底。拦是拦住了，但**理由是错的**：
    这不是「值跑出了列」，而是「表头一个词跨在列边界上，整段不可分」。

    判据只认「a 的后缀 == 某角色词的前缀」且「b 的前缀 == 同一角色词的余下部分」，
    并且**单独看 a 或 b 都不含完整角色词** —— 否则 ``UNIT`` + ``MIN`` 这种
    正常相邻列会被误伤（``'unitmin'`` 里能拼出 ``'min'``）。
    """
    a, b = _alpha(header[i]), _alpha(header[i + 1])
    if not a or not b:
        return set()
    for w in _ROLE_FULL:
        if w in a or w in b:
            continue                     # 完整词已由原判据处理，这里只管残片
        for k in range(1, len(w)):
            if a.endswith(w[:k]) and b.startswith(w[k:]):
                return {i, i + 1}
    return set()


def fused_cols(header) -> set:
    """表头里「一列装了多个数值角色」或「一个角色词被劈在两列边界上」的列号集合。

    DAC8555 第 3 页实测表头就是 ``['PARAMETER', 'TESTCONDITIONS', 'MIN TYP MAX', 'UNIT']``
    —— 表格竖线丢失，三列被读成一列，数据格长这样：``'180 250'``、``'18 55 . .'``。
    这种表**结构上就不该回填**：没有任何办法知道 180 是 MIN 还是 TYP。

    第二种形态见 ``_roles_split_across``：词是完整的，但被列边界劈开了
    （``'NOM MA'`` + ``'X UNIT'``）。两种都归到 fused，因为处置一样 —— 整表 abstain。

    为什么不直接把 ``role_map`` 改成返回 ``"FUSED"``：``role_map`` 有 5 个调用方
    （``patch_cols`` / ``_num_cells`` / ``pick_header`` / ``locate_candidates`` / 诊断），
    多出来的角色值会同时改变「哪几列算数值列」和「表头识别是否成立」——
    为了一个诊断字段去动匹配主干，收益远小于风险。所以单开一个只读判据。
    """
    out = set()
    for i, h in enumerate(header):
        hl = (h or "").lower()
        if sum(1 for r in _FUSED_ROLES if _ROLE_RX[r].search(hl)) > 1:
            out.add(i)
    for i in range(len(header) - 1):
        out |= _roles_split_across(header, i)
    return out


def grouped_num_roles(header) -> set:
    """同一数值角色出现在**两个不同列**里 → 双列组（两组 MIN/TYP/MAX）。

    实测形态：一张表里并排两组 ``MIN TYP MAX``（不同测试条件/不同通道），
    `role_map` 只取第一组，第二组被当成普通文本列 → 写盘会把第一组的值
    当成唯一真值，第二组彻底不可见。这是 `duplicate_num_roles` 止血补丁
    的判据：**不可分就不写**，交 VL/人工，而不是赌第一组。

    与 ``fused_cols`` 区分：fused 是**同一列**里装了多个角色（竖线丢失），
    这里是一个角色占了**多个列**（两组列并存）。
    """
    seen: dict[str, list[int]] = {}
    for i, h in enumerate(header):
        for r in header_roles(h):
            if r in _HEADER_ROLES:
                seen.setdefault(r, []).append(i)
    return {r for r, cols in seen.items() if len(cols) > 1}


def role_map(header):
    rm = {}
    for i, h in enumerate(header):
        hl = (h or "").lower()
        for role, rx in ROLE_RES:
            if rx.search(hl): rm[i] = role; break
    return rm


def table_has_value_roles(tbl, need: int = 2) -> bool:
    """表**资格**闸门：数值角色（MIN/TYP/MAX/LIMITS）≥ ``need`` 个。

    这是 ``audit_missing_rows`` 里那条 SSOT 判据（"MIN/TYP/MAX 角色 ≥2"）的**单点实现**，
    v4 起 ``decide_table`` 与补行路径共用它，杜绝两份阈值分岔。

    为什么用 ``header_roles``（一格可给多个角色）而不用 ``role_map``（一格只给一个）：
    `role_map` 会把 `'MIN TYP MAX'` 挤成一格的融合表头只数到 1 —— A19 刚修的
    ADS7945 表头会因此**重新失去资格**，等于把上次的修复原地推翻。
    ``LIMITS`` 必须计入：TI `Typ(3) | Limits (3)` 只有 2 个角色，少一个就误杀 A20。

    外族表（A18）一律无资格：它仍可作候选来源（``decide_table`` 的兜底轮），
    但不能单独决定写什么。
    """
    if tbl.get("foreign_part"):
        return False
    roles = set()
    for h in tbl.get("header") or []:
        roles.update(r for r in header_roles(h) if r in _HEADER_ROLES)
    return len(roles) >= need


# ── ADAPT A20：TI 老式 `Limits` 合并列拆分 ──
#: 单位格里的侧别标记：`LSB(max)` / `mV(min) mV(max)` / `MHz(min)`。
_LIMITS_SIDE_RX = re.compile(r"\(\s*(min|max)\s*\)", re.I)

#: 限值格里的数值 token。**先剥掉括号组**（脚注 `(3)` 不能当数），
#: 且前面不许贴字母数字（`VREF2.5` 里的 2.5 不是本格的值）。
_LIMIT_NUM_RX = re.compile(r"(?<![A-Za-z0-9])[±+\-−]?\d+(?:[.,]\d+)?")


def _limits_sides(*texts) -> set:
    got = set()
    for t in texts:
        for m in _LIMITS_SIDE_RX.finditer(t or ""):
            got.add(m.group(1).lower())
    return got


def limits_column_split(cell, unit="") -> tuple[dict, str]:
    """把 TI 的 `Limits` 合并列拆成 ``({"MIN": v|None, "MAX": v|None}, 判定标记)``。

    2013 版 ADC08B200 手册的电气表表头是::

        ['Parameter', '', 'TestConditions', 'Typ(3)', 'Limits (3)', 'Units (Limits)']

    `Limits` 一列同时装 MIN 与 MAX，**侧别不写在列名上，写在 Units 格里**：

        ['INL', ..., '±0.55', '±1.3', 'LSB(max)']            → TYP=0.55, MAX=1.3
        ['FSE', ..., '−3.9', '−8.0 0', 'mV(min) mV(max)']    → MIN=−8.0, MAX=0
        ['tCL', ..., '', '1.7', 'ns(min)']                   → MIN=1.7

    判据只有三条，每条都要求**侧别证据**（不许按顺序猜）：

    * 两个数 + `(min) (max)` → 第一个 MIN、第二个 MAX（``two_sided``）
    * 一个数 + `(min)` / `(max)` → 该侧（``side:min`` / ``side:max``）
    * 空 / `-` / `N/A` → 没有值，**不是脏**（``blank``）

    其余一律 ``unresolved:*``：侧别不明、多于两个数、公式格（`V RB`）、没有任何数。
    调用方据此报 ``cell_unparsable_unresolved (LIMITS_COLUMN)`` 并**整条不写**
    —— 与 A12「宁可不写，也不写错」同一条纪律。

    注意：PDF 文本层可能丢小数点（实测 p6 的 `−3.9` 抽出来是 `−39`、`5.5` 是 `55`）。
    本函数只做**结构**拆分、不修数值；数值可靠性由写盘闸门兜住
    （模型 value 必须与本格数值相等才会写）。
    """
    blank = {"MIN": None, "MAX": None}
    raw = clean(cell)
    if is_blank_cell(raw):
        return blank, "blank"
    body = re.sub(r"\([^)]*\)", " ", raw)          # 脚注 `(3)` 不是数值
    vals = []
    for tok in _LIMIT_NUM_RX.findall(body):
        v = cell_num(tok)
        if v is not None:
            vals.append(v)
    sides = _limits_sides(unit) or _limits_sides(raw)
    if not vals:
        return blank, "unresolved:no_value"
    if len(vals) > 2:
        return blank, "unresolved:multi_value"
    if len(vals) == 2:
        if sides == {"min", "max"}:
            return {"MIN": vals[0], "MAX": vals[1]}, "two_sided"
        return blank, "unresolved:side_unknown"
    if sides == {"min"}:
        return {"MIN": vals[0], "MAX": None}, "side:min"
    if sides == {"max"}:
        return {"MIN": None, "MAX": vals[0]}, "side:max"
    return blank, "unresolved:side_unknown"


# ── ADAPT A13：融合列按 x 坐标切分（默认关，ICPDF_SPLIT_FUSED=1 才启用）──
#: 为什么默认关：它会**改变表格结构**（列数变多、表头重写），是全链路最激进的改动。
#: 先在沙箱单件上验证「切出来的值确实对」，再谈默认开。
SPLIT_FUSED = os.getenv("ICPDF_SPLIT_FUSED", "0").strip() == "1"


def header_roles(cell) -> list:
    """表头格里出现了哪几个数值角色，按 MIN→TYP→MAX→LIMITS 顺序。

    `LIMITS` 是伪角色（TI `Limits (3)` 合并列）：认它只有一个目的 ——
    让 `pick_header` 把「Typ + Limits」算成**两个**角色，真表头才过得了 `>= 2` 的门槛。
    值不会直接写进 columns，见 :func:`limits_column_split`。
    """
    hl = (cell or "").lower()
    return [r for r in _HEADER_ROLES if _ROLE_RX[r].search(hl)]


def cell_words(page, bbox) -> list:
    """单元格 bbox 内的 words，按 x 升序（同一 x 再按 y）。"""
    if not bbox:
        return []
    ws = page.get_text("words", clip=fitz.Rect(*bbox))
    ws.sort(key=lambda w: (round(w[0], 1), w[1]))
    return ws


def _cluster_centers(xs, k):
    """一维坐标聚成 k 簇：按最大间隙切。返回 ``[(lo, hi), ...]``（升序，长度 k）。

    值在子列里通常是右对齐的，各子列的 x 中心不重合；跨行合并所有 word 中心后，
    子列之间会留下明显的大间隙，取最大的 k-1 个间隙就是子列边界。
    重复中心（同一子列里多个 word）会先合并，所以 k 大于实际簇数时会得到空簇。
    """
    xs = sorted(xs)
    if not xs:
        return []
    uniq = [xs[0]]
    for x in xs[1:]:
        if x - uniq[-1] > 0.5:      # 0.5pt 内视为同一位置
            uniq.append(x)
    if len(uniq) <= k:
        return [(x - 0.25, x + 0.25) for x in uniq] + [(0, 0)] * (k - len(uniq))
    gaps = sorted(((uniq[i + 1] - uniq[i], i) for i in range(len(uniq) - 1)),
                  reverse=True)[: k - 1]
    cuts = sorted(i for _, i in gaps)
    bounds, start = [], 0
    for c in cuts:
        bounds.append((uniq[start], uniq[c]))
        start = c + 1
    bounds.append((uniq[start], uniq[-1]))
    return bounds


def _band_dist(cx, lo, hi) -> float:
    """点到区间的距离：落在区间内为 0。

    **不能用区间中点算**：首尾区间是 ``(-inf, e1)`` / ``(e2, +inf)``，
    取中点会得到 ±5e8，于是所有值都「更接近中间那格」——
    实测表现就是 ``'180 250'`` 整串掉进 TYP，MIN/MAX 全空。
    """
    if cx < lo:
        return lo - cx
    if cx > hi:
        return cx - hi
    return 0.0


def _pick_band(w, bounds) -> int:
    """一个 word 归到哪一列：**优先看重叠长度**，没重叠才退回中心距离。

    为什么重叠优先：右对齐数值的「中心点」会随位数漂移，而它**压在哪个子列上**
    是物理事实。实测 DAC8555：``'180'`` 的 x 区间 448.9~460.6 完全落在 ``TYP``
    表头（446.9~460.5）里、与 ``MIN``（418.0~430.8）零重叠 —— 它就在 TYP 下面。
    """
    overlaps = [max(0.0, min(w[2], hi) - max(w[0], lo)) for lo, hi in bounds]
    best = max(overlaps)
    if best > 0:
        return overlaps.index(best)
    cx = (w[0] + w[2]) / 2
    dists = [_band_dist(cx, lo, hi) for lo, hi in bounds]
    return dists.index(min(dists))


def _assign(words, bounds):
    """把 words 归位，返回每列拼好的文本。"""
    parts = [""] * len(bounds)
    for w in words:
        bi = _pick_band(w, bounds)
        parts[bi] = (parts[bi] + " " + w[4]).strip()
    return parts


def split_fused_rows(page, trows, rows, header, ci, roles):
    """把一个融合列 ``ci`` 按 x 坐标拆成 ``len(roles)`` 列。

    返回 ``(new_rows, new_header)``；拆不动就返回 ``None``，调用方保持原样
    （原样 = 走 ``fused_cols`` 的 abstain，不写盘）。

    判据只有一条：**跨行合并后能分出恰好 len(roles) 个 x 簇**。
    分不出（比如整列只有一列数字）就不猜 —— 宁可交人工。
    """
    k = len(roles)
    if k < 2 or trows is None:
        return None
    body = []
    for ri, row in enumerate(rows):
        if ri >= len(trows):
            return None
        cells = getattr(trows[ri], "cells", None) or []
        if ci >= len(cells) or not cells[ci]:
            body.append(None)
            continue
        body.append(cell_words(page, cells[ci]))

    # ① 首选基准：**表头词的位置**。表头 "MIN TYP MAX" 三个词的 x 位置就是三个子列的
    #    坐标系原点，比聚类数据值可靠得多 —— 数值是右对齐的，位数不同中心就漂
    #    （实测按值中心聚：'180' 被分到 TYP、真值是 MIN）。
    bounds, anchors = None, None
    for ri, row in enumerate(rows):
        if len(row) <= ci:
            continue
        if len(header_roles(row[ci])) >= 2 and body[ri]:
            ws = body[ri]
            if len(ws) == k:
                centers = [(w[0] + w[2]) / 2 for w in ws]
                edges = [(centers[i] + centers[i + 1]) / 2 for i in range(k - 1)]
                cuts = [-1e9] + edges + [1e9]
                bounds = [(cuts[i], cuts[i + 1]) for i in range(k)]
                anchors = [w[2] for w in ws]        # 每列表头词的**右边缘**，用于自校验
                break
    # ② 兜底：表头词数量对不上（被拆词/粘连）时，退回按全部数值的 x 中心聚类
    if bounds is None:
        xs = []
        for ri, ws in enumerate(body):
            if ri > 0 and ws:
                xs.extend((w[0] + w[2]) / 2 for w in ws)
        bounds = _cluster_centers(xs, k)
        if len(bounds) != k or any(lo == 0 and hi == 0 for lo, hi in bounds):
            return None

    # 自校验：数值是右对齐的 → 每一列里数值的**右边缘**应当贴住该列表头词的右边缘。
    # DAC8555 实测：'180' 右边缘 460.6 vs TYP 表头 460.5（差 0.1pt），这才是「归位对不对」
    # 的硬证据；只靠 x 中心聚类会出现「180 明明在 MIN 却分给 TYP」的漂移。
    # 对齐率不到 80% 就不切 —— 宁可交人工，不猜。
    if anchors:
        hit = tot = 0
        for ri, ws in enumerate(body):
            if ri == 0 or not ws:
                continue
            for w in ws:
                idx = _pick_band(w, bounds)
                tot += 1
                if abs(w[2] - anchors[idx]) <= 2.5:
                    hit += 1
        if tot and hit / tot < 0.8:
            return None

    new_rows = []
    for ri, row in enumerate(rows):
        ws = body[ri]
        if ws is None:
            new_rows.append(list(row)[:ci] + [""] * k + list(row)[ci + 1:])
            continue
        parts = _assign(ws, bounds)
        new_rows.append(list(row)[:ci] + parts + list(row)[ci + 1:])

    new_header = list(header)[:ci] + list(roles) + list(header)[ci + 1:]
    return new_rows, new_header

#: `pick_header` 只在前几行找表头。窗口**刻意只有 3 行**：再往下就是数据，
#: `MIN`/`MAX` 作为数据里的字样出现时不该把整行升级成表头。
#: 这条界限有测试钉住（`test_header_beyond_the_window_is_not_guessed`）。
HEADER_WINDOW = 3


#: 「纯角色词格」允许出现的词。`header_roles` 只认 MIN/TYP/MAX，这里多收几个
#: 同义词，是因为 `'MIN/NOM/MAX'` 这种写法里的 `NOM` 会把"纯角色词"判断打掉。
_ROLE_WORDS_ONLY = {"min", "typ", "max", "nom",
                    "minimum", "typical", "maximum", "nominal"}


def roles_only_cell(cell) -> bool:
    """这个格子是不是「只由角色词组成」（``'MIN TYP MAX'`` / ``'MIN / TYP / MAX'``）。

    为什么必须有这道门：光数 :func:`header_roles` 的个数会误伤说明文字 ——
    ADS7945 表头上方那句 ``Minimum/maximum specifications at TA = ...``
    同时含 `minimum` 与 `maximum`，会被数成「一格两角色」，整行升级成表头。
    真融合格除了角色词什么都不剩，说明文字必然还剩别的词（`specifications`）。

    这条是红先用例 ``test_skips_note_rows_above_the_header`` 逼出来的：
    第一版只按角色个数数，那条用例当场红。
    """
    toks = [t for t in re.split(r"[^a-z]+", (cell or "").lower()) if t]
    return bool(toks) and all(t in _ROLE_WORDS_ONLY for t in toks)


def row_roles(row) -> dict:
    """一行里每个格子带了哪几个数值角色（一个格子可能带多个）。

    与 :func:`role_map` 的区别：`role_map` 一格只记**一个**角色，是给「取哪一列写
    MIN/TYP/MAX」用的；这里要的是「这一行有几个角色」，`'MIN TYP MAX'` 必须算 3 个。

    但「多个角色」只在 :func:`roles_only_cell` 成立时才算 —— 一格 `'MIN TYP MAX'`
    是表头，一格 `'Minimum/maximum specifications'` 是正文，两者字数一样、角色词一样。
    """
    out = {}
    for i, h in enumerate(row):
        rs = header_roles(h)
        if not rs:
            continue
        out[i] = rs if (len(rs) > 1 and roles_only_cell(h)) else rs[:1]
    return out


def pick_header(rows):
    """在表格前几行里找表头行，返回 ``(header, data)``；找不到返回 ``([], rows)``。

    ADAPT A19：原来用 ``role_map`` 数「有几个数值角色列」，而 ``role_map`` 一格只给
    一个角色 —— 竖线丢失、`'MIN TYP MAX'` 挤成一格时只数到 1，``>= 2`` 不成立，
    整张表被判成「没有表头」。ADS7945 的 p4/p5 两张电气特性表就是这样：
    表头明明在第 0 行，却被当成没有表头的数据表，后续 `locate_candidates`
    在没有数值列的表里找不到任何候选，最后报成「这是 ADS7946 的表」。

    现在按**角色个数**数（融合格里的每个词各算一个），判据仍是 ``>= 2`` 不变。
    """
    for i, r in enumerate(rows[:HEADER_WINDOW]):
        n = sum(len(rs) for rs in row_roles(r).values())
        if n >= 2:
            return r, rows[i + 1:]
    return [], rows


def header_like(texts) -> bool:
    """这一串「列名」像不像真的表头：至少**两个**格子各自带了表头角色词。

    ADAPT A19：`t.header.names` 不总是表头。ADS7945 p4/p5 的表头上方有一段说明文字
    （``Minimum/maximum specifications at TA = ...``），`extract()` 把它切成 4~5 个
    碎片，长度恰好等于列数 —— 于是「names 优先」让这段说明文字当了表头。

    为什么不能用「有没有角色词」这种弱判据：那段碎片里 ``'Typical specifications'``
    带着 `typical`，``role_map`` 非空。要求「两个格子各有角色」才过得去 ——
    真表头（`PARAMETER / TEST CONDITIONS / MIN TYP MAX / UNITS`）稳稳 3 个，
    说明文字只有 1 个。
    """
    return sum(1 for t in (texts or []) if role_map([t])) >= 2


#: A21 两级表头合并开关（默认开；`ICPDF_HEADER_MERGE=0` 关掉，用于红先演示与回滚）。
HEADER_MERGE = os.getenv("ICPDF_HEADER_MERGE", "1").strip() != "0"


def _merge_two_level_header(top, second):
    """A21：把紧邻的两行表头**按列**合并，返回合并后的表头。

    硬约束（用户裁决，2026-11-03）：
      * 只合并紧邻两行，不跨行推断；
      * **按列**合并（同一下标），MIN/TYP/MAX/UNIT 的列位置原样保留 ——
        绝不允许把一个角色"继承"到相邻列（那会把 A16 的跨列校验整片搞废）；
      * 两格都有文字时用空格拼接（`'V' + 'CC'` → `'V CC'`、
        `'–40°C to +85°C' + 'MIN'` → 带角色的列名），拼完仍按本列判定角色。
    """
    n = min(len(top), len(second))
    out = []
    for i in range(n):
        a = (top[i] or "").strip()
        b = (second[i] or "").strip()
        out.append((a + " " + b).strip() if (a and b) else (a or b))
    return out


def choose_header(names, rows):
    """决定这张表用哪一行当表头，返回 ``(header, data, from_names, meta)``。

    ADAPT A19：把「names 还是 pick_header」的判断收敛到一处 —— 原来这段逻辑散在
    ``scan_tables`` 里写了两遍（A13 的 ``base`` 一处、最终 header 一处），
    两处一旦对不齐，A13 就会拿着一张错表头去切列。

    规则：
    1. ``names`` 长度不等于列数 → 不可用。
    2. ``names`` 可用，但**不像表头**、而表里确实找得到表头行 → 用找到的那一行。
       只在后一条成立时才翻脸：``names`` 无角色词但表里也没有表头行时
       （``PRODUCT / RESOLUTION / INPUT`` 这类），维持原行为，不猜。
    3. 其余情况维持「names 优先」：``data`` 保留首行（历史语义，改它会影响
       全量写盘的列下标）。

    ADAPT A21（2026-11-03）：**两级表头**。TI 老手册常见
    `row0 = PARAMETER | TEST CONDITIONS | V | … | UNIT`、
    `row1 = CC | MIN | TYP | MAX | MIN | TYP | MAX` —— 角色全在第二行。
    旧行为取 names（row0）→ 角色数 0 → v4 资格闸门会把**真电气表**判无资格
    （74LVC1G132DCKTG4 的 p6/t0，171 分却出局）。
    触发条件**严格**：当前表头角色数 = 0 **且**下一行角色数 ≥ 2；只并紧邻两行。
    合并后 ``data`` 从第 2 行之后开始，并在 meta 里留
    ``header_source_rows=[0,1]`` / ``header_level_count=2`` 供审计。
    """
    picked, rest = pick_header(rows)
    ncol = len(rows[0]) if rows else 0
    use_names = bool(names) and len(names) == ncol
    if use_names and picked and not header_like(names):
        use_names = False

    meta = {"header_source_rows": [0], "header_level_count": 1}
    if use_names:
        top = list(names)
        cur_roles = sum(len(header_roles(c)) for c in top)
        if HEADER_MERGE and cur_roles == 0 and len(rows) >= 2 and len(rows[1]) == ncol:
            second = rows[1]
            nxt_roles = sum(len(header_roles(c)) for c in second)
            if nxt_roles >= 2:
                return (_merge_two_level_header(top, second), rows[2:], True,
                        {"header_source_rows": [0, 1], "header_level_count": 2})
        return top, rows, True, meta
    return picked, rest, False, meta

#: 页级预过滤（默认开）：`find_tables()` 是整条链路最贵的一步（C 层网格搜索），
#: 而 datasheet 里大量页面是封面 / 目录 / 曲线图，根本不会有表。
#: 词表刻意放宽 —— 只要求页面文本**出现任意一个**表头常用词，宁可多扫不可漏扫。
#: 关掉：``ICPDF_PAGE_FILTER=0``（A/B 用）。
PAGE_FILTER = os.getenv("ICPDF_PAGE_FILTER", "1").strip() != "0"
_TABLE_HINT_RE = re.compile(
    r"min|typ|max|minimum|maximum|typical|parameter|symbol|condition|unit|"
    r"pin|package|note|value|test|limit|rating", re.I)


def page_worth_scanning(page) -> bool:
    """这页值不值得跑 ``find_tables``。判据只否掉「文本极少」和「无任何表头词」的页。"""
    try:
        text = page.get_text("text")
    except Exception:
        return True
    if len(text.strip()) < 40:      # 封面 / 纯图页，连表头词都放不下
        return False
    return bool(_TABLE_HINT_RE.search(text))


def scan_tables(doc, max_pages=MAX_PAGES):
    out = []
    for pno in range(min(doc.page_count, max_pages)):
        page = doc[pno]
        if PAGE_FILTER and not page_worth_scanning(page):
            continue
        try: tf = page.find_tables()
        except Exception: continue
        for ti, t in enumerate(tf.tables):
            try: rows = t.extract()
            except Exception: continue
            # ADAPT（2026-10-30 晚）：这张表的列是怎么来的，要一路带到写盘处。
            # 否则 `patch_cols` 无法区分"表头锚点列"和"按坐标重拼/切出来的列"，
            # 只能一律标 `pdf_header_anchors` —— 标错来源的正确列会骗过 G0 门禁。
            words_fixed = False
            # ADAPT A10（2026-10-30）：find_tables 的 extract() 对右对齐数值列会**重排字符**，
            # '-2.0' 出来是 '20\n- .'、'4.5' 出来是 '45 .'，to_num 取到 20.0 / 45.0（差 10 倍），
            # 并被 patch_cols 写进 columns。用该行的 cell bbox 从 words 按坐标重拼。
            # 只修「被判定重排」的格子，正常格子一个字节都不动。
            try: trows = t.rows
            except Exception: trows = []
            for ri, r in enumerate(rows):
                if ri >= len(trows): break
                cells = getattr(trows[ri], "cells", None) or []
                for ci in range(min(len(r), len(cells))):
                    if cells[ci] and bad_number_cell(r[ci]):
                        fixed = cell_text_from_words(page, cells[ci])
                        if fixed and not bad_number_cell(fixed):
                            r[ci] = fixed
                            words_fixed = True      # 这一列的值不是 extract() 原值了
            # ADAPT A16：留下列的 x 区间，供写盘前判「这个数据格是不是横跨了两列」。
            # 实测 1A1G04QDBVRG4Q1 的 ICC 行：表头第二组是 MIN(424.5~468.6)/MAX(468.6~511.9)，
            # 而数据行那一格 bbox 是 424.5~511.9（PDF 里合并了两列），值 '20' 实际贴在 MAX 的右边缘。
            # 只按表头下标取列，就会把 MAX 的 20 写成 MIN —— 格子干净、匹配唯一、语义全错。
            xr = []
            for ri, r in enumerate(rows):
                cs = getattr(trows[ri], "cells", None) if ri < len(trows) else None
                xr.append([((round(c[0], 1), round(c[2], 1)) if c else None)
                           for c in (cs or [])])
            keep = [i for i, r in enumerate(rows) if r and any(clean(c) for c in r)]
            rows = [[clean(c) for c in rows[i]] for i in keep]
            xr = [xr[i] for i in keep]
            if len(rows) < 2: continue
            names = None
            try:
                if t.header and t.header.names: names = [clean(n) for n in t.header.names]
            except Exception: names = None
            hx = []
            try:
                hx = [((round(c[0], 1), round(c[2], 1)) if c else None)
                      for c in (t.header.cells or [])]
            except Exception:
                hx = []
            # ADAPT A13：融合列切分（默认关）。必须在 clean/过滤**之前**做 —— 那一步会丢空行，
            # 行号就和 `t.rows` 对不上了，bbox 会指到别人身上。
            # ADAPT A19：表头来源只判断一次，A13 与最终 header 共用同一个结果 ——
            # 原来这里和下面 `elif names and ...` 各判一遍，两处不一致时
            # A13 会拿着一张错表头去切列。
            hdr0, data0, from_names, hdr_meta = choose_header(names, rows)
            hdr_split = None
            if SPLIT_FUSED:
                base = list(hdr0)
                if base and len(base) == len(rows[0]):
                    # 从右往左切：切左边会把右边已切好的列号顶歪
                    for ci in sorted(fused_cols(base), reverse=True):
                        roles = header_roles(base[ci])
                        got = split_fused_rows(page, trows, rows, base, ci, roles)
                        if got:
                            rows, base = got
                    hdr_split = base
            xr_use = xr
            if hdr_split and len(hdr_split) == len(rows[0]):
                header, data = [clean(h) for h in hdr_split], rows
                hx = []          # 切分后列数已变，表头 bbox 与列下标不再一一对应
                xr_use = []      # 同理：切分改了行宽，A16 的跨列校验整体失效
            elif from_names:
                header, data = hdr0, data0
                # A21：两级表头合并后 `data` 从第 2 行之后开始，A16 的 bbox 要跟着下移，
                # 表头 bbox 取**第二行**（角色行）—— 与 `pick_header` 分支同源。
                # `off == 0`（普通 names 分支，没合并）必须保持原样：`xr_use = xr`、
                # `hx` 沿用 `t.header.cells`。曾经在这里无条件重置成 []，等于把 A16 的
                # 跨列校验整片关掉 —— ICC 的「20 横亘 MIN/MAX」当场漏过。
                off = len(rows) - len(data0)
                if off > 0:
                    if off <= len(xr):
                        xr_use = xr[off:]
                        hx = xr[off - 1]
                    else:
                        xr_use, hx = [], []
            else:
                header, data = hdr0, data0
                # ADAPT A20：`data` 比 `rows` 少了被当成表头的那些行（`pick_header`
                # 返回 `rows[i+1:]`），A16 的 bbox 必须同步下移 —— 否则拿表头那一行
                # 的格子去比数据行，`cell_spans_columns` 会把干净值判成"跨列"。
                # 表头 bbox 也改用**被选中的那一行**的格子（PyMuPDF 的 `t.header`
                # 是它自己认的表头，实测在 ADC08B200 上是一段脚注），两边同源才一致。
                off = len(rows) - len(data0)
                if 0 < off <= len(xr):
                    xr_use = xr[off:]
                    hx = xr[off - 1]
                else:
                    xr_use, hx = [], []
            # ADAPT A19：`data` 可能为空（表头认出来了但下面没有数据行 —— 融合表头
            # 现在能被识别，这种「只有表头的残表」从"不可能"变成了"可能"）。
            # 空表就整表不启用跨列校验，不要 `data[0]` 抛 IndexError。
            if not data or not (len(hx) == len(header) == len(data[0])):
                hx = []          # 列数对不上就整表不启用跨列校验（宁可不判，不误判）
            if data:
                # 表标题：表格 bbox 上方最近的文本块。用来给条目打 scope
                # （板卡 User Guide 的 "Board Specifications" vs 芯片 datasheet 的
                # "Electrical Characteristics"）。取不到就留空，不猜。
                title = ""
                try:
                    bbox = getattr(t, "bbox", None)
                    if bbox:
                        blocks = page.get_text("blocks")
                        above = [b for b in blocks if b and b[3] <= bbox[1] - 2]
                        if above:
                            best = max(above, key=lambda b: b[3])
                            if bbox[1] - best[3] < 90:
                                title = clean(best[4])[:160]
                except Exception:                              # noqa: BLE001
                    title = ""
                out.append({"page": pno + 1, "ti": ti, "header": header, "rows": data,
                            "hx": hx, "xr": xr_use, "title": title,
                            "split": bool(hdr_split), "words_fixed": words_fixed,
                            # A21 可审计输出：这张表的表头用了哪几行、几级。
                            "header_source_rows": hdr_meta["header_source_rows"],
                            "header_level_count": hdr_meta["header_level_count"]})
    return out

# `locate_row` / `locate_candidates` 定义在下方的「候选匹配（唯一性闸门）」段，
# 不在 `patch_cols` 之前——闸门是后加的，放在一起便于对照阅读；
# `patch_cols` 不依赖它们，所以顺序无影响。

def looks_garbled(text) -> bool:
    """单元格文本是否被 extract() 的字符交织搅乱（多行 TEST CONDITIONS 常见）。

    实测 DAC8555：
        'M (Ae Va Ds Du =re 5d b ,y li Rn Ee p =a 4s .s 9in 9g )t h ...'
        'T 0po ± 0 <. 0 C0 L3 <% F 0S 0pR F, 0200h to FD00h ...'
    都是**两行文字的字符互相穿插**。这种文本绝不能写进 `condition`
    —— 模型给的 condition 是干净的，覆盖上去等于用垃圾换掉正确值。

    判据看「长词（≥4 字符）在含字母 token 里的占比」：
    ``AVDD = 5V, VREF = 4.99V`` 里 VREF/4.99V/AVDD 都是长词（0.29~0.60），
    交织文本几乎全是 ``M Ae Va Ds`` 这种 2~3 字碎片（0.00~0.15），阈值取 0.2。

    为什么不用「单字符占比」：正常条件里 ``=``、``5V`` 之外还有大量 3~5 字真词，
    而交织文本的碎片长度集中在 2~3，两者在「单字符占比」上重叠严重，判不开。
    """
    toks = (text or "").split()
    if len(toks) < 8:
        return False
    letters = [t for t in toks if any(c.isalpha() for c in t)]
    if len(letters) < 4:
        return False                      # 纯数字条件（'0 to 70'）不判乱码
    # 正常条件里总有几个「长词」（VREF / 4.99V / AVDD），交织文本几乎全是 2~3 字的碎片。
    # 实测：正常 0.29~0.60；交织 0.00~0.15。
    long_ratio = sum(1 for t in letters if len(t) >= 4) / len(letters)
    return long_ratio < 0.2


def atomic_write(path, text: str) -> None:
    """同目录临时文件 + fsync + `os.replace()` 原子替换。

    写盘灰度要开多进程、也可能跑到一半被杀；直写 `write_text` 在那瞬间会留下
    半截 JSON —— 下次读入直接 `JSONDecodeError`，看上去像「数据坏了」，实际是
    「上次没写完」。原子替换保证只有两种终态：**旧内容**或**新内容**，没有中间态。
    """
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def cell_spans_columns(tbl, ri, ci, tol=8.0) -> bool:
    """这一格里装的值，是不是横跨了**多个表头列**（ADAPT A16）。

    1A1G04QDBVRG4Q1 的 ICC 行实测：

        表头第二组   MIN 424.5~468.6 ｜ MAX 468.6~511.9
        数据行 cell6 424.5~511.9              ← PDF 里合并成一格
        值 '20'      x 500.9~509.8            ← 实际贴在 MAX 的右边缘

    按表头下标取列，会把 MAX 的 20 写成 `MIN`：格子干净、唯一命中、语义全错。
    这种情况**不能修，只能拒** —— 判断"它到底属于哪一列"需要知道值在格内的
    水平位置，而 `extract()` 已经把这个信息抹平了（这正是 A10 的重拼场景，
    但重拼也只用于数值字符乱序，不用于列归属）。

    判据：数据格的 x 区间若超出表头该列的 x 区间（容差 ``tol``，吸收栅格线的
    1~3pt 抖动），就认定跨列。表头/数据列数对不上时（`hx` 为空）一律不判。
    """
    hx, xr = tbl.get("hx") or [], tbl.get("xr") or []
    if not (0 <= ri < len(xr)) or not (0 <= ci < len(hx)):
        return False
    row, h = xr[ri], hx[ci]
    if not h or ci >= len(row) or not row[ci]:
        return False
    d = row[ci]
    return d[0] < h[0] - tol or d[1] > h[1] + tol


def column_origin_of(tbl) -> str:
    """这张表的数值列是从哪来的 —— 决定 ``columns_raw`` 的 provenance。

    不能一律写 ``pdf_header_anchors``：那等于宣称"列下标与表头 bbox 一一对应、
    A16 的跨列校验守得住"。而实际有三条来源：

    - ``pdf_x_split``      A13 按 x 簇切开融合列。边界来自几何聚类，不是表头；
                           且切分后 ``hx`` 被清空，**A16 对这张表整体失效**。
    - ``pdf_words_repair`` A10 用 ``get_text("words")`` 按坐标重拼过格子，
                           值不是 ``extract()`` 原值。
    - ``pdf_header_anchors`` 默认，A16 守得住的那一类。

    优先级：切分 > 重拼 > 锚点。切分最根本（它重新定义了列），一旦切过，
    即便个别格又被重拼过，整张表的列边界也依然是几何聚类的结果。
    """
    if tbl.get("split"):
        return "pdf_x_split"
    if tbl.get("words_fixed"):
        return "pdf_words_repair"
    return DEFAULT_ORIGIN


def patch_cols(e, cols, roles, tbl, ri, tunit):
    # 幂等：**只有第一次**才记原值。调用方已经用 `_writable()` 保证一条只写一次，
    # 这道是兜底 —— 万一将来加了新的写盘分支忘了走闸门，原值也不会被二次覆盖
    # （被覆盖的表现是「回滚回一个已经修好的值」，等于把后悔药涂改了）。
    if "value_raw_original" not in e:
        e["value_raw_original"] = e.get("value")
    e["columns"] = {k: cols[k] for k in ("MIN", "TYP", "MAX") if cols.get(k) is not None}
    e["columns_raw"] = {k: roles.get(k) for k in e["columns"]}
    # AGENT §11.5 来源门禁：`columns_raw` 必须标 origin，否则 G0 不认它是 PDF 列证据。
    # 取值见 `qc/column_origins.py`（与 `qc/five_stage.py` 单源）。三条路径不同：
    # 表头锚点 / A13 切分 / A10 重拼，标错会让 G0 把"没有 A16 兜底的列"当成有保护的列。
    e["column_origin"] = column_origin_of(tbl)
    e["value"] = " / ".join(f"{v:g} {k}" for k, v in e["columns"].items())
    sd = dim_symbol(e.get("symbol"), e.get("name"))
    if tunit and dim_unit(tunit) and (not dim_unit(e.get("unit")) or dim_unit(tunit) == sd):
        e["unit"] = tunit
    cond = roles.get("COND") or ""
    if cond and looks_garbled(cond):
        # 交织乱码不覆盖：模型给的原文更可靠。
        # 但要**留痕** —— 否则日后回查「这一条为什么没跟单元格走」只能靠猜。
        e["condition_cell_garbled"] = True
    elif cond:
        e["condition"] = cond
    e.setdefault("source", {}).update({"page": tbl["page"], "table": tbl["ti"], "row": ri})

# ── 候选匹配（唯一性闸门）──
#: 匹配规则版本。写入 ambiguous finding 的 `match_rule` 字段，
#: 将来改判据（限定词解析等）时据此区分历史诊断来自哪一版。
#:   v1（2026-10 之前）：只按分数取最高分，并列时取第一个。
#:   v2（2026-10-30）：并列时先按 condition 词命中、再按 value 落在该行数值格做二级裁决。
#:   v3（2026-10-30，**当前默认**）：+合并单元格的行标签继承、+condition 里的**数值**参与打分。
#:   v4（2026-11-03，已实现、未默认）：跨表比较取代"按表序取第一张"；表资格闸门
#:       （MIN/TYP/MAX/LIMITS 角色 ≥2，见 :func:`table_has_value_roles`）；表级并列
#:       同内容取首张 / 内容不同用 value_supported 自证 / 仍分不出报 `table_tie`。
#:       **为什么没默认**：11 件夹具 A/B 里 74LVC1G132DCKTG4 的真电气表 p6/t0 被资格闸门
#:       判 False —— 它的表头是**两级**（row0 `PARAMETER|TESTCONDITIONS`、row1
#:       `MIN TYP(1) MAX ×2`），`choose_header` 走了 `t.header.names` 拿到 row0，
#:       角色却全在 row1。先修两级表头合并，再开 v4 默认（见 HANDOFF 2026-11-03）。
#: `ICPDF_MATCH_RULE=v1|v2|v3` 是回滚开关，也是 A/B 的对照臂；`v4` 是 experimental 臂。
_MATCH_VER = os.getenv("ICPDF_MATCH_RULE", "v3").strip().lower()
if _MATCH_VER not in ("v1", "v2", "v3", "v4"):
    _MATCH_VER = "v3"
MATCH_V2 = _MATCH_VER in ("v2", "v3", "v4")
MATCH_V3 = _MATCH_VER in ("v3", "v4")
MATCH_V4 = _MATCH_VER == "v4"
MATCH_RULE = f"locate_row/unique-{_MATCH_VER}"

#: ADAPT JEV：规则打分仍并列时，允许语义裁判（百炼 decision-model-preview）选行。
#: 默认关。仲裁结果照样要过 cell_num / fused / 跨列三道物理闸门 —— 见 `qc/jev_client.py`。
JEV_TIE = os.getenv("ICPDF_JEV_TIE", "0").strip() == "1"

#: 数值列角色。value 命中判据优先只看这三列，表头没识别出来时退回整行。
_NUM_ROLES = ("MIN", "TYP", "MAX")

#: 「可以当数值证据的格子」= 三个显式角色 + `LIMITS` 合并列。
#: 为什么不把 LIMITS 直接并进 `_NUM_ROLES`：那会同时改变「哪几列算数值列」的语义
#: （`_NUM_ROLES` 还被写盘路径按角色名引用）。这里只扩**诊断取格**的范围。
_NUM_CELL_ROLES = _NUM_ROLES + ("LIMITS",)


def _num_cells(row, rm):
    pick = [clean(c) for ci, c in enumerate(row)
            if ci in rm and rm[ci] in _NUM_CELL_ROLES]
    return pick or [clean(c) for c in row]


def _row_unit(row, rm) -> str:
    for ci, c in enumerate(row):
        if rm.get(ci) == "UNIT":
            return clean(c)
    return ""


def num_values(row, rm) -> list:
    """这一行能当**数值证据**的数（诊断口径，与写盘同源）。

    与 :func:`_num_cells` 的区别：那个给的是"格子的原始文本"（拿来做字符串包含），
    这里给的是**拆开的数**：

    * `MIN / TYP / MAX` → ``to_num``（诊断口径，容忍公式格的首数）；
    * `LIMITS`（TI 合并列）→ :func:`limits_column_split` 拆出的 MIN/MAX。
      **绝不能**对整格 ``to_num`` 取左半值：实测 ``'−8.0 0'`` 会变成 8.0
      —— 极性、数量都错，`value_supported` 会据此误判「这行支持这个值」。

    表头一个数值角色都没有时退回整行（与 ``_num_cells`` 的兜底同口径，
    否则没有表头的表会从"能匹配"退化成"永远不支持"）。
    """
    out, has_role = [], False
    unit = _row_unit(row, rm)
    for ci, c in enumerate(row):
        role = rm.get(ci)
        if role in _NUM_ROLES:
            has_role = True
            v = to_num(c)
            if v is not None:
                out.append(v)
        elif role == "LIMITS":
            has_role = True
            got, _flag = limits_column_split(c, unit)
            out.extend(v for v in (got["MIN"], got["MAX"]) if v is not None)
    if has_role:
        return out
    return [v for v in (to_num(c) for c in row) if v is not None]


def value_supported(row, rm, val) -> bool:
    """该行的数值格能不能解释这个 value（字符串归一后包含，或数值相等）。

    这是「这条 JSON 是否真属于这一行」的最强证据：`Logic Input High Voltage` 的
    `VCC - 1.0` 只出现在 VIH 行，同名同条件的 TM1/TM2 续行是 `VCC - 0.3`。

    A20 补充：`LIMITS` 合并列必须按拆分后的数比较（见 :func:`num_values`）。
    只把它当普通格子串比对会让 `'−8.0 0'` 这种格子的左半值冒充整格真值。
    """
    cells = _num_cells(row, rm)
    nv = nsym(val)
    if nv and any(nv in nsym(c) for c in cells if nsym(c)):
        return True
    jn = to_num(val)
    if jn is None:
        return False
    return any(abs(v - jn) < 1e-9 for v in num_values(row, rm))


def cond_overlap(row, cond) -> int:
    """condition 里的词命中该行几个。只用于并列裁决，不进总分。"""
    toks = tokens(cond)
    if not toks:
        return 0
    blob = " ".join(clean(c).lower() for c in row)
    return sum(1 for t in toks if t in blob)


# ── ADAPT A11：condition 里的**数值**参与打分（unique-v3）──
#: 数字 token。**不用** ``NUM_RE``（那个会吃正负号），因为这里只关心「数值本体在不在」。
_COND_DIGITS = re.compile(r"\d+(?:[.,]\d+)?")

#: 「≥3 字母的词」。原来在 `cond_overlap` / `locate_candidates` 的**双重循环里**现编译，
#: 500 件灰度实测是纯浪费：每件 average 30 条 × 16 张表 × 40 行 = 近 2 万次编译。
_TOKEN_RE = re.compile(r"[a-z]{3,}")


def tokens(s) -> set:
    return set(_TOKEN_RE.findall((s or "").lower()))


def num_tokens(s) -> set:
    """把文本里的数字拍成「去分隔符的数字串」集合：``'1.65V'``→``'165'``。

    为什么不用 float 比对：ADAPT A10 已证 ``find_tables().extract()`` 会把小数点挪位 ——
    ``'1.65 V'`` 出来是 ``'165V .'``、``'4.5'`` 出来是 ``'45 .'``、``'0.79 1.16'`` 出来是
    ``'079 116 . .'``。字符被重排但**数字顺序不变**，所以按「去掉 . , 之后的数字串」比对，
    两种形态自然等价；用 float 反而会取到 165 / 45 / 79 这种错位值。
    """
    return {re.sub(r"[.,]", "", t) for t in _COND_DIGITS.findall(clean(s) or "")}


def cond_num_hit(row_text, cond, table_nums) -> int:
    """condition 里的数值有几个能在该行找到，返回 0~100。

    分母只算「本表数据行里确实出现过的数值」：``-40°C to +85°C`` 这种温区落在**表头**，
    不落在任何行里，计入分母会让每条都永久扣分，把区分度抹平。
    """
    obs = num_tokens(cond) & (table_nums or set())
    if not obs:
        return 0
    return 100 * len(obs & num_tokens(row_text)) // len(obs)


#: 行视图缓存。键是 ``id(tbl)``，值里**同时持有 tbl 引用** —— 否则对象被回收后
#: 新的 dict 可能复用同一个 id，缓存就会串到别的表上去。
_ROWVIEW_CACHE: dict = {}


def row_labels(tbl, rm) -> list:
    """每行的「文本列」文本，**按列**继承上一行的非空格子（合并单元格）。

    74LVC1G132 第 6 页：``VT+`` 占 **5 行**（VCC = 1.65 / 2.3 / 3 / 4.5 / 5.5），
    PARAMETER 列只在第一行有字，第 3~6 行是合并单元格的空格。符号/参数名匹配
    只能命中第 2 行，于是 10 条 JSON 全抢同一行 —— 该件 42 条
    ``ambiguous_collision`` 的真正来源。

    **必须按列继承而不是整行继承**：第 3~6 行的 ``VCC`` 列是有字的（``23V .``），
    「整行非空就不继承」会让这 4 行永远拿不到 ``VT+`` 标签，等于没修。实测确认过：
    整行版判据在这张表上一次都不会触发。

    只继承**文本列**（``rm`` 里没有角色的列），MIN/TYP/MAX/UNIT 一律不继承 ——
    数值格必须各行自立，继承别人的数值比漏匹配严重得多。
    """
    key = id(tbl)
    hit = _ROWVIEW_CACHE.get(key)
    if hit is not None and hit[0] is tbl:
        return hit[1]
    text_cols = [ci for ci in range(len(tbl["header"])) if rm.get(ci) is None]
    last = {ci: "" for ci in text_cols}
    labels = []
    for row in tbl["rows"]:
        parts = []
        for ci in text_cols:
            cell = clean(row[ci]) if ci < len(row) else ""
            if cell:
                last[ci] = cell
            parts.append(last[ci])
        labels.append(" ".join(p for p in parts if p))
    if len(_ROWVIEW_CACHE) > 4096:
        _ROWVIEW_CACHE.clear()
    _ROWVIEW_CACHE[key] = (tbl, labels)
    return labels


def _break_tie(tbl, rm, ties, cond, val):
    """并列候选的二级裁决：condition 词命中多者胜，仍并列再比 value 命中。

    实测（11 件回归基线 + 74LVC1G132 + BQ2003，共 355 条）：
        基线          matched 278 / 恰并列 68 / value 命中本行 142
        只加 condition matched 301 / 恰并列 45 / 命中 150
        只加 value     matched 291 / 恰并列 55 / 命中 155
        两级都用       matched 307 / 恰并列 39 / 命中 156   ← 采用
    两个指标同时变好（不只是「匹配变多」，是「匹配更对」），所以取两级。

    另试过「某表所有候选都解释不了 value 就跳过这张表」→ matched 掉到 226、
    恰并列涨到 120（覆盖面塌了，因为公式型 value 本来就不在单元格里）。**否决。**
    """
    if len(ties) < 2:
        return ties
    if cond:
        if MATCH_V3:
            # 数值证据强于词证据：'VCC = 1.65V' 的区分力全在 1.65 上，
            # 而 cond_overlap 只数 ≥3 字母的词（'vcc'），VCC 不同的五行全打平。
            nums = table_meta(tbl)["nums"]
            scored = [(ri, cond_num_hit(" ".join(tbl["rows"][ri]), cond, nums)) for ri in ties]
            hi = max(s for _, s in scored)
            if hi > 0:
                keep = [ri for ri, s in scored if s == hi]
                if len(keep) == 1:
                    return keep
                ties = keep
        scored = [(ri, cond_overlap(tbl["rows"][ri], cond)) for ri in ties]
        hi = max(s for _, s in scored)
        if hi > 0:
            keep = [ri for ri, s in scored if s == hi]
            if len(keep) == 1:
                return keep
            ties = keep
    if val:
        keep = [ri for ri in ties if value_supported(tbl["rows"][ri], rm, val)]
        if len(keep) == 1:
            return keep
    # ADAPT JEV：规则打平后交给语义裁判（默认关，`ICPDF_JEV_TIE=1` 才启用）。
    # 它**只选行**，选完照样过 cell_num / 跨列 / fused 三道物理闸门。
    if len(ties) > 1 and JEV_TIE:
        # 硬约束（前置）：连一个候选行都解释不了这个值 → **不呼叫、不裁决**。
        # 实测 22 条 tie 里 18 条（81.8%）属于这种：模型抽的 63 在 83/85/85/82 里
        # 根本不存在。JEV 是选择题模型，喂给它它就必然选一个 —— 然后 patch_cols
        # 用那一行的数字顶掉 63。这种"强制替换"比留一条 unresolved 危险得多。
        if not any(value_supported(tbl["rows"][ri], rm, val) for ri in ties):
            return ties
        picked = _jev_pick_row(tbl, rm, ties, cond, val)
        if picked is not None:
            return [picked]
    return ties


def _jev_pick_row(tbl, rm, ties, cond, val):
    """用百炼 decision-model-preview 从并列候选里选一行；abstain 返回 ``None``。

    英文 prompt：System One 这套协议对 `MIN/TYP/MAX` 这类结构化概念的英文
    指令服从性更好，用中文时实测容易把「条件里的温度」当成行标识。
    """
    try:
        from qc.jev_client import decide_choice
    except Exception:
        return None

    criteria = {}
    lines = [f"Target JSON entry: value={val}, condition={cond or 'None'}",
             "Candidate table rows (choose the row that most likely produced this entry):"]
    for ri in ties:
        d = _row_digest(tbl, rm, ri)
        cid = f"row_{ri}"
        criteria[cid] = (f"Row {ri}: Param Name={d['param']}, "
                         f"Condition={d['condition'] or 'Empty'}, "
                         f"MIN={d['min'] or 'Empty'}, TYP={d['typ'] or 'Empty'}, "
                         f"MAX={d['max'] or 'Empty'}")
        lines.append(criteria[cid])

    got = decide_choice(
        state="\n".join(lines),
        instructions=("Which table row is the most likely source for this electrical "
                      "parameter? Decide strictly by Parameter Name and Test Conditions; "
                      "use MIN/TYP/MAX only to check consistency."),
        criteria=criteria,
    )
    if not got:
        return None
    cid, _conf = got
    try:
        ri = int(cid.split("_", 1)[1])
    except (IndexError, ValueError):
        return None
    if ri not in ties:
        return None
    # 硬约束：选中的行**必须**能解释这个值（值得真出现在那行的某个数值格里）。
    # 否则 patch_cols 会拿那一行的 MIN/TYP/MAX 顶掉模型给的 value ——
    # 实测 ADC3910 的 SFDR：模型给 63，并列候选是 83/85/85/82，一个都不等于 63。
    # 这种题语义裁判选中哪一行都是猜，写盘就是把 63 改成 85。
    if not value_supported(tbl["rows"][ri], rm, val):
        return None
    return ri


#: 表级派生缓存：键 ``id(tbl)``，值里**同时持有 tbl 引用**（防 id 复用串味）。
#: 这三样（角色映射、继承标签、全表数字）原来在「每条目 × 每张表」的循环里各算一遍，
#: 一次 40 页扫描能算上万次 —— 属于纯浪费，且不改变任何判断结果。
_TBL_CACHE: dict = {}


def table_meta(tbl) -> dict:
    key = id(tbl)
    hit = _TBL_CACHE.get(key)
    if hit is not None and hit[0] is tbl:
        return hit[1]
    rm = role_map(tbl["header"])
    meta = {
        "rm": rm,
        "labels": row_labels(tbl, rm) if MATCH_V3 else None,
        "nums": num_tokens(" ".join(" ".join(clean(c) for c in r) for r in tbl["rows"])),
    }
    if len(_TBL_CACHE) > 4096:
        _TBL_CACHE.clear()
    _TBL_CACHE[key] = (tbl, meta)
    return meta


def _score_table(tbl, sym, param, cond="", val=""):
    """本表的打分：返回 ``(best, ties, rm)``。``best < 50`` 表示没有候选行。

    v4 的跨表比较需要「分数」这个量，而原 `locate_candidates` 只返回并列行号；
    把打分抽出来单点实现，避免再写一份（两份阈值迟早漂移）。

    为什么不用「所有 ≥50 的行」：低于最高分的行是「次优」，
    把它们都算候选会让几乎每个参数都 ambiguous（实测 BQ24300 row[13]
    有 6 个 ≥50 的行），闸门就失去区分度。并列才是真正「无法判定」。
    """
    ns, npf = nsym(sym), nsym(param)
    meta = table_meta(tbl)
    rm, labels = meta["rm"], meta["labels"]
    toks = tokens(param)
    table_nums = meta["nums"] if (MATCH_V3 and cond) else None
    best, ties = -1, []
    for ri, row in enumerate(tbl["rows"]):
        if MATCH_V3:
            blob = nsym(labels[ri])
            ov_text = labels[ri]          # 共同词也走继承视图，否则首行靠自己的词白拿 75 分
        else:
            blob = "".join(nsym(c) for ci, c in enumerate(row) if rm.get(ci) in (None, "UNIT"))
            ov_text = " ".join(row)
        ov = len(toks & tokens(ov_text))
        score = (100 if ns and ns in blob else 0) + (80 if npf and npf[:12] and npf[:12] in blob else 0) + 25 * ov
        if score < 50:
            continue
        if table_nums is not None:
            # 只给「已经是候选」的行加分：分数不到门槛的行说明符号/参数名根本不像，
            # 靠一个数字翻盘等于用弱证据压过强证据。
            score += 50 * cond_num_hit(" ".join(row), cond, table_nums) // 100
        if score > best:
            best, ties = score, [ri]
        elif score == best:
            ties.append(ri)
    return best, ties, rm


def locate_candidates(tbl, sym, param, cond="", val=""):
    """返回 ``(候选行号列表, rm)``。

    **候选 = 得分达到本表最高分的所有行**（并列才算多候选），按行号升序。
    总分：符号命中 100 + 参数名前 12 位 80 + 共同词 25/个，门槛 50。
    unique-v3 起再加一项 **condition 数值命中，最高 +50**（见 :func:`cond_num_hit`）。

    为什么 condition 数值可以进总分、value 不行：
    condition 是**行的身份**（``VCC = 1.65 V`` 只可能属于 VCC=1.65 那一行），
    而 value 是**行的内容**，``0``/``30`` 这类高频值在几十行里都出现，
    进总分会把原本 unmatched（公式型 value）的条目变成大面积 ambiguous —— 实测负优化。

    ``val`` 与 ``cond`` 的词命中仍只在并列之后裁决（见 :func:`_break_tie`）。
    表级选择（跨表比较）不在本函数里 —— 见 :func:`decide_table`。
    """
    best, ties, rm = _score_table(tbl, sym, param, cond, val)
    if len(ties) > 1 and (cond or val) and MATCH_V2:
        ties = _break_tie(tbl, rm, ties, cond, val)
    return ties, rm

def locate_row(tbl, sym, param, cond="", val=""):
    """兼容入口：取候选中的第一个（无并列裁决时与原实现「首个最高分」等价）。

    需要区分「唯一 / 多候选」的调用方请直接用 :func:`locate_candidates`。
    """
    ties, rm = locate_candidates(tbl, sym, param, cond, val)
    return (ties[0] if ties else None), rm

#: 表标题里型号 token 的最小长度（`ADS7946` / `74FCT162H245T` 都在 7 以上）。
_PART_TOKEN = re.compile(r"[A-Z][A-Z0-9\-]{5,}")
#: 判定「同族」所需的公共前缀长度。常见器件族前缀（`74FCT162`、`ADS794`）都在 6 以上，
#: 而文档号（`SBAS258A`）与料号几乎不会共享 6 个连续字符 —— 这是**排除文档号**的闸。
_FAMILY_PREFIX = 6


def _alnum(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def part_tokens(text: str) -> list:
    """从表标题里提取型号形态的 token（大写）。

    要求**含至少一个数字** —— 否则 `OUTPUT` / `CHARACTERISTICS` 这类纯字母词
    也会被当成型号候选，虽然判据本身能滤掉，但没必要让它们进到日志里。
    """
    return [tok for tok in _PART_TOKEN.findall((text or "").upper())
            if any(ch.isdigit() for ch in tok)]


def _prefix_len(a: str, b: str) -> int:
    n = 0
    while n < len(a) and n < len(b) and a[n] == b[n]:
        n += 1
    return n


def claims_part(token: str, mpn: str) -> bool:
    """这个标题 token 说的是不是本品。

    判据：去掉厂商前缀（`CY` / `SN` / `TI`，最多 3 个字母）后，与料号有 >= 6 字符的
    公共前缀，且**余量只允许为空或 1~2 个纯字母**（`T` / `N` 这类温度/封装后缀）。

    余量里出现数字就说明它是**另一个产品号**而不是本品后缀 ——
    `CY74FCT162H245T` 对 `74FCT162H245CTPVCT` 余量是 `T`（算本品），
    `CY74FCT16245T` 余量是 `45T`（不算）。
    """
    tok = _alnum(token)
    core = _alnum(mpn)
    if not tok or not core:
        return False
    for k in range(0, 4):
        cut = tok[k:]
        n = _prefix_len(cut, core)
        if n < _FAMILY_PREFIX:
            continue
        rest = cut[n:]
        if not rest or (len(rest) <= 2 and rest.isalpha()):
            return True
    return False


def _same_family(token: str, mpn: str) -> bool:
    """同族但不是本品才值得怀疑（文档号 `SBAS258A` 不会与料号共享 6 字符前缀）。"""
    tok = _alnum(token)
    core = _alnum(mpn)
    if not tok or not core:
        return False
    return max(_prefix_len(tok[k:], core) for k in range(0, 4)) >= _FAMILY_PREFIX


def mark_foreign_tables(tables, mpn) -> int:
    """给「标题写的是同族另一颗料」的表打 ``foreign_part`` 标记，返回标记数量。

    只在**本 PDF 里确实存在声称本品的表**时才动手：一张都找不到，说明标题里没有
    可用型号信息，这时标记任何表都是猜 —— 保持旧行为，一个都不标。

    标记只是把该表降为「兜底」，不是直接拒写：``_decide_match`` 先在本品表里找，
    只有一个本品表都没有候选时，才因为只命中外族表而 abstain。
    """
    core = _alnum(mpn)
    # 先清上一次的标记：`scan_tables` 的结果在灰度里会被缓存复用，
    # 同一批表对象接连过两颗料时，上一个料的 `foreign_part` 会留着，
    # 把本该可用的表降成兜底 —— 那是无声的召回损失。
    for tbl in tables:
        tbl.pop("foreign_part", None)
    if not core:
        return 0
    tokens = {id(t): part_tokens(t.get("title")) for t in tables}
    if not any(claims_part(tok, core) for toks in tokens.values() for tok in toks):
        return 0
    marked = 0
    for tbl in tables:
        toks = tokens[id(tbl)]
        if any(claims_part(tok, core) for tok in toks):
            continue
        sib = [tok for tok in toks if _same_family(tok, core)]
        if sib:
            tbl["foreign_part"] = sib[0]
            marked += 1
    return marked


def decide_table(tables, sym, param, cond="", val=""):
    """对一条 JSON 条目做**表选择 + 行定位**决策，**不写任何字段**。

    `postprocess_qwen.resolve_rowrefs` 与 `audit_electrical` 共用这一个入口 ——
    原来两边各写一份"按表序取第一张"的循环，正是 v4 要消灭的平行实现。

    返回 ``(status, info)``，status ∈ ``matched`` / ``ambiguous_tie`` /
    ``unmatched`` / ``foreign_part``。

    v4 规则（``ICPDF_MATCH_RULE=v3`` 一键回滚）：
      1. **资格闸门**：只允许 `MIN/TYP/MAX/LIMITS` 角色 ≥2 的表进入打分池
         （见 :func:`table_has_value_roles`；引脚表/修订历史/寄存器表因此无资格）；
      2. **跨表取最高分**，取代旧的"按表序取第一张"（ADS42 的 VID：p11=105 却输给 p3=80）；
      3. 表级并列 → 用 `value_supported` 自证；仍并列 → `row_ambiguous_unresolved`
         + ``ambiguous_reason="table_tie"``（不造新的 finding kind）；
      4. 外族表（A18）仍只作兜底：没有本品候选时才 `foreign_part`。

    两轮（A18）依旧保留：先本品、后外族。

    历史：A18 之前 PDF 里并列同构表（`for CY74FCT16245T` / `for CY74FCT162H245T`）
    时，旧实现「按表顺序取第一张有候选的表」，会取到另一颗料的表 ——
    `74FCT162H245` 的 VOH 就写成了 16245T 的 `TYP 3.5`（应 3.3），
    且 MIN 恰好同为 2.4，三道数值闸门全看不出。
    """
    foreign = []
    home = []
    weak = []
    order = {id(tbl): i for i, tbl in enumerate(tables)}
    for tbl in tables:
        best, ties, rm = _score_table(tbl, sym, param, cond, val)
        if not ties:
            continue
        item = {"table": tbl, "score": best, "ties": ties, "rm": rm}
        if tbl.get("foreign_part"):
            foreign.append(item)
        elif table_has_value_roles(tbl):
            home.append(item)
        else:
            weak.append(item)

    if not MATCH_V4:
        # v3 等价：按表序取第一张有候选的本品表（`weak` 与 `home` 按原表序合并）。
        cand = home + weak
        cand.sort(key=lambda it: order[id(it["table"])])       # 恢复原表序（按 id，不按 dict 相等）
        if cand:
            it = cand[0]
            ties = it["ties"]
            if len(ties) > 1 and (cond or val) and MATCH_V2:
                ties = _break_tie(it["table"], it["rm"], ties, cond, val)
            if len(ties) > 1:
                return "ambiguous_tie", {"table": it["table"], "rm": it["rm"], "rows": ties}
            return "matched", {"table": it["table"], "rm": it["rm"], "ri": ties[0]}
        if foreign:
            it = foreign[0]
            return "foreign_part", {"table": it["table"], "rm": it["rm"], "rows": it["ties"]}
        return "unmatched", {}

    # v4：只让「有数值角色」的表进打分池；一张合格表都没有时才退回弱表
    #（防误杀逃生口：宁可回到旧行为，也不许整类表突然不可写）。
    pool = home or weak
    if not pool:
        if foreign:
            it = foreign[0]
            return "foreign_part", {"table": it["table"], "rm": it["rm"], "rows": it["ties"]}
        return "unmatched", {}

    top = max(it["score"] for it in pool)
    top_items = [it for it in pool if it["score"] == top]
    if len(top_items) > 1:
        # ① 同内容重复表：TI 常把同一张电气表在 p5/p6/p7/p8 重排一遍（BUF634 实测
        #    四张表都 130 分、行内容逐格相同）。选哪张写出来都一样 → 按表序取第一张，
        #    这不是"猜"，是**等价物**，没必要报 unresolved 去消耗人工。
        sig = [tuple(clean(c) for c in it["table"]["rows"][it["ties"][0]]) for it in top_items]
        if all(s == sig[0] for s in sig[1:]):
            top_items = [top_items[0]]
        else:
            # ② 内容不同的表并列：用「值能否被该表候选行解释」自证。
            supported = [it for it in top_items
                         if any(value_supported(it["table"]["rows"][ri], it["rm"], val)
                                for ri in it["ties"])]
            if len(supported) == 1:
                top_items = supported
            else:
                return "ambiguous_tie", {
                    "table": top_items[0]["table"], "rm": top_items[0]["rm"],
                    "rows": list(top_items[0]["ties"]),
                    "reason": "table_tie",
                    "tables": [{"page": it["table"].get("page"), "ti": it["table"].get("ti"),
                                "score": it["score"], "rows": list(it["ties"])}
                               for it in top_items],
                }

    it = top_items[0]
    ties = it["ties"]
    if len(ties) > 1:
        if (cond or val) and MATCH_V2:
            ties = _break_tie(it["table"], it["rm"], ties, cond, val)
        if len(ties) > 1:
            return "ambiguous_tie", {"table": it["table"], "rm": it["rm"], "rows": ties}
    return "matched", {"table": it["table"], "rm": it["rm"], "ri": ties[0]}


#: 兼容别名：历史调用点/测试都按 `_decide_match` 引用，实现只保留 `decide_table` 一处。
_decide_match = decide_table

def _row_digest(tbl, rm, ri):
    """把候选行压成可读诊断（符号 / 参数名 / 条件 / 三列 / 单位）。"""
    row = tbl["rows"][ri] if ri < len(tbl["rows"]) else []
    roles = {rm[ci]: clean(c) for ci, c in enumerate(row) if ci in rm}
    free = [clean(c) for ci, c in enumerate(row) if ci not in rm and clean(c)]
    return {
        "row": ri,
        "symbol": free[0] if free else "",
        "param": free[1] if len(free) > 1 else "",
        "condition": roles.get("COND") or "",
        "min": roles.get("MIN") or "",
        "typ": roles.get("TYP") or "",
        "max": roles.get("MAX") or "",
        "unit": roles.get("UNIT") or "",
    }

def _ambiguous_finding(path, jv, status, info, paths):
    """构造 ambiguous finding。字段是诊断契约，供人工裁决与后续限定词解析复用。"""
    tbl, rows = info["table"], info["rows"]
    f = finding(path, "row_ambiguous_unresolved", jv,
                "%s p%d/t%d rows=%s" % (status, tbl["page"], tbl["ti"], rows))
    f.update({
        "match_rule": MATCH_RULE,
        # status 仍是 `ambiguous_tie`（audit 的分支靠它），`table_tie` 只改 reason 文案：
        # 「表级并列」与「行级并列」是两种不同的人工裁决，必须在字段上分得开。
        "ambiguous_reason": info.get("reason") or status,
        "candidate_count": len(rows),
        "candidates": [_row_digest(tbl, info["rm"], ri) for ri in rows],
        "page": tbl["page"], "table": tbl["ti"],
    })
    if info.get("tables"):
        f["table_candidates"] = info["tables"]
    if info.get("claimants"):
        f["claimants"] = [{"path": paths[i] if i < len(paths) else str(i), "index": i}
                          for i in info["claimants"]]
    return f

# ── D1 规格语义审计 ──
def audit_electrical(entries, tables, scope):
    finds = []
    entries = list(entries or [])

    # ── 第一遍：只做匹配决策，一个字段都不写 ──
    decisions, paths, claims = [], [], {}
    for ei, e in enumerate(entries):
        sym, param = e.get("symbol") or "", e.get("name") or e.get("parameter") or ""
        paths.append(f"{scope}[{ei}].{sym or param}")
        # cond/val 只用于并列裁决（unique-v2），详见 _break_tie
        d = _decide_match(tables, sym, param,
                          e.get("condition") or "", str(e.get("value", "")))
        decisions.append(d)
        if d[0] == "matched":
            claims.setdefault((id(d[1]["table"]), d[1]["ri"]), []).append(ei)

    # ── 冲突消解：同一 (表, 行) 被多个条目认领 → 全部 ambiguous，谁都不写 ──
    # 只惩罚「后来者」会把先到先得变成隐式优先级，而先到的那条未必对
    # （ADC3910 row[5]/[6] 同时命中 row21，两条都是错的）。
    for ei, (status, info) in enumerate(decisions):
        if status != "matched":
            continue
        key = (id(info["table"]), info["ri"])
        if len(claims[key]) > 1:
            decisions[ei] = ("ambiguous_collision",
                             {"table": info["table"], "rm": info["rm"],
                              "rows": [info["ri"]], "claimants": claims[key]})

    # ── 第二遍：按决策执行原有逻辑（唯一命中才进入）──
    for ei, e in enumerate(entries):
        sym, param = e.get("symbol") or "", e.get("name") or e.get("parameter") or ""
        unit, val = e.get("unit") or "", str(e.get("value", ""))
        jnum = to_num(val)
        path = paths[ei]
        status, info = decisions[ei]

        if status == "unmatched":
            finds.append(finding(path, "table_unresolved", val, "-"))
            continue
        if status.startswith("ambiguous"):
            finds.append(_ambiguous_finding(path, val, status, info, paths))
            continue
        if status == "foreign_part":
            # 只命中了「标题写着同族另一颗料」的表 —— 这张表不是它的，不写。
            # 证据放在 findings 里（型号 token）而不是只写一句"没匹配到"，
            # 人工一眼能看出是表选错了还是参数根本不在 PDF 里。
            ftbl = info["table"]
            _PAGE.set(ftbl.get("page"))
            finds.append(finding(path, "table_foreign_part_unresolved", val,
                                 ftbl.get("foreign_part") or ""))
            continue

        tbl, ri, rm = info["table"], info["ri"], info["rm"]
        # 从这里往下产生的每一条 finding 都属于这张表 —— set 一次，后面
        # cell_unparsable / range_collapse / qualifier_loss / row_mispair /
        # unit_dimension / condition_leak / value_unsupported / footnote_missing
        # 全部自动带页码。`unmatched` 分支在上面（没匹配到表，本来就没有页码可言）。
        _PAGE.set(tbl.get("page"))
        row = tbl["rows"][ri]
        roles = {rm[ci]: clean(c) for ci, c in enumerate(row) if ci in rm}
        # ADAPT A20：TI 老式 `Limits` 合并列（`Typ(3) | Limits (3) | Units (Limits)`）。
        # 这一列同时装 MIN 与 MAX，侧别写在 Units 格里 —— 只有两侧都有证据才拆，
        # 判不出侧别就整条不写并留 `LIMITS_COLUMN`（不许按"第一个数就是 MIN"去猜）。
        derived, lim_raw = {}, ""
        if "LIMITS" in roles and not ({"MIN", "MAX"} & set(roles)):
            lim_raw = roles["LIMITS"]
            derived, lim_flag = limits_column_split(lim_raw, roles.get("UNIT") or "")
            if lim_flag.startswith("unresolved:"):
                finds.append(finding(path, "cell_unparsable_unresolved", val, "LIMITS_COLUMN"))
                continue
            if derived.get("MIN") is not None or derived.get("MAX") is not None:
                # 结构证据：这条的 MIN/MAX 来自同一格合并列。写进 JSON 便于回查。
                e["limits_column"] = {"cell": lim_raw,
                                      "unit": roles.get("UNIT") or "",
                                      "split": lim_flag}
        # ADAPT A12：写盘前先确认每个数值格是「干净单值」。任何一个格子不干净
        # （公式格、两格并一格、范围格）就整条不写 —— 实测旧实现会写出
        # "0 MIN"（原文 0.7×IOVDD）和 "10 MIN"（原文是 20）。
        cols, cells_ok = {}, True
        fused = fused_cols(tbl["header"])   # 竖线丢失 → 角色不可分，本行一律不回填
        grouped = grouped_num_roles(tbl["header"])  # 两组 MIN/TYP/MAX 并存 → 角色不可分
        spans = []                          # ADAPT A16：值横跨多个表头列的列名
        if fused or grouped:
            # 角色不可分时**整条跳过**：不跑 D1a~D1g、不写任何字段。
            # 旧实现要等某条规则调用 `_writable()` 才报，规则不触发就静默通过
            # （两组列并存、值又刚好落在第一组时，一条 finding 都不会有）。
            #
            # 2026-10-31：**融合列对关键参数要阻断**，不能只记 unresolved 就放行。
            # 取证：ADC12DJ5200SE 的 p10 ROC 表 header 是
            # `['', '', '', 'MIN', 'NOM', 'M', 'AX UNIT']`、数值格是 `'0 03 0\n. .'`
            # （0/0.3/0.55 挤成一格、小数点分离），18 条电气/绝对最大行全部走这条
            # 分支 → `spec_audit="unresolved"` → 闸门**全程零判定**，VCMI 写成
            # "0.3 to 0.55"（MIN 被丢掉）照样出包。读不出列 ≠ 读出来是对的。
            if fused and _is_blocking_param(param):
                finds.append(finding(path, "fused_column_blocking", val, "FUSED_COLUMN"))
            else:
                finds.append(finding(path, "cell_unparsable_unresolved", val,
                                     "FUSED_COLUMN" if fused else "GROUPED_COLUMNS"))
            continue
        cells_ok = True
        for r in ("MIN", "TYP", "MAX"):
            if r in derived:                # A20：`Limits` 合并列拆出来的值
                cols[r] = derived[r]
                continue
            raw = roles.get(r, "")
            if is_blank_cell(raw):          # '-' / '—' / 'N/A' 是「这列没有值」，不是脏
                cols[r] = None
                continue
            ci = next((i for i, k in rm.items() if k == r), None)
            if ci is not None and cell_spans_columns(tbl, ri, ci):
                # 值不在这一列的 x 区间内 —— 归错列比写错值更难查，直接拒
                spans.append(r)
                cells_ok = False
                continue
            cols[r] = cell_num(raw)
            if cols[r] is None:             # 有字但不是干净单值 → 脏
                cells_ok = False

        # ADAPT A17：值必须出现在**即将写入的那三列**里。
        # `value_supported` 只要求值出现在这一行的**某个**格；写盘却只写 MIN/TYP/MAX。
        # 两者不等价，实测两条假写盘：
        #   ADC3910 Add. Latency  value=4  行 ['', '', '4', '60', '', '']  → 写成 MIN=60
        #   BQ24300 High-level input current value=15  匹配到的是 VIH 行     → 写成 MIN=1.4
        # 前者是"值在行里但不在列里"，后者是"匹配到了隔壁参数"。两个都是拿别的数字顶掉模型的值。
        _jv = to_num(val)
        _wv = [v for v in cols.values() if v is not None]
        value_outside = bool(_jv is not None and _wv
                             and not any(abs(_jv - c) < 1e-9 for c in _wv))
        # 注意：`value_outside` 与「格子脏」是两件事。前者是**值不在列里**
        # （D1d/D1g 的猎物），后者是**单元格本身不是干净单值**（A12 闸门）。
        # 旧实现把它们一起塞进 cells_ok，导致 D1g 永远看不到自己该抓的形态。
        _cells_ok_raw = cells_ok
        if value_outside:
            cells_ok = False

        def _writable():
            """写盘前置闸门：格子不干净就改成 unresolved，绝不带着脏格子写。

            **返回值而不是在这里统一 append** —— ``finding(path, kind, ...)`` 的 kind
            必须是字面量，传变量会被 ``test_finding_kinds`` 判成「未登记的动态产出点」。
            那道扫描是真防线（曾经三处写法全扫出 0 个 → 假绿），不能为了方便把它关掉。
            """
            if e.get("columns"):
                # 同一轮里已经写过一次了。实测 ADC3910 的 Add. Latency：
                # row_mispair 和 condition_leak 同时成立 → patch_cols 跑两遍，
                # 第二次把 value_raw_original 覆盖成「已修好的值」，原始值 '4' 永久丢失，
                # 修过什么就再也说不清了。一条只准写一次。
                return False
            if cells_ok:
                return True
            # 只有 value_outside、格子本身干净 → **不在这里报**。
            # 这不是"格子脏"（A12 的猎物），而是"值不在这几列里"，由下方 D1g 的
            # `value_unsupported_unresolved` 报（带 row_values 证据）。同一缺陷只留一个 kind，
            # 否则每条 value 不落列的条目都会多出一条 cell_unparsable_unresolved 噪声。
            if _cells_ok_raw:
                return False
            finds.append(finding(path, "cell_unparsable_unresolved", val,
                                 ("FUSED_COLUMN" if fused else
                                  "GROUPED_COLUMNS" if grouped else
                                  "SPANS_MULTIPLE_ROLES" if spans else roles),
                                 ))
            return False

        tunit = next((u for u in [cell_unit(roles.get(r, "")) for r in ("MIN", "TYP", "MAX")]
                      if u), None) or clean(roles.get("UNIT")) or cell_unit(" ".join(row)) or None
        # 诊断用 to_num（能从任意文本捞数，够判「这一行有几个值」）；
        # 写盘用 cell_num（必须干净单值）。两者**故意不同**：
        # 用 cell_num 算 cvals 会让「格子脏」把该报的 range_collapse 一起吞掉，
        # 报告里就看不到「本该回填但被拦」这件事了。
        cvals = []
        for r in ("MIN", "TYP", "MAX"):
            v = derived[r] if r in derived else to_num(roles.get(r, ""))
            if v is not None:
                cvals.append(v)
        # A20：MIN/MAX 来自合并列的同一格 —— 写盘证据 `columns_raw` 两列都指向原格文本。
        roles_w = roles
        if derived:
            roles_w = dict(roles)
            roles_w["MIN"] = roles_w["MAX"] = lim_raw
        if re.search(r"\d\s*[~–—-]\s*\d", val) and len(cvals) >= 2:          # D1a 范围塌缩
            if _writable():
                finds.append(finding(path, "range_collapse", val, cols)); patch_cols(e, cols, roles_w, tbl, ri, tunit)
        elif len(cvals) >= 2 and not e.get("columns") and jnum is not None and jnum in cvals:  # D1b 限定语丢失
            if _writable():
                finds.append(finding(path, "qualifier_loss", val, cols)); patch_cols(e, cols, roles_w, tbl, ri, tunit)
        if jnum is not None and cvals and all(abs(jnum - v) > 1e-9 for v in cvals):  # D1d 行错配
            in_other = any(to_num(c) is not None and abs(to_num(c) - jnum) < 1e-9
                           for r2 in tbl["rows"] if r2 is not row for c in r2)
            if in_other and _writable():
                finds.append(finding(path, "row_mispair", val, cols)); patch_cols(e, cols, roles_w, tbl, ri, tunit)
        sd, ud = dim_symbol(sym, param), dim_unit(unit)                       # D1c 单位维度
        if sd and ud and ud != sd:
            if tunit and dim_unit(tunit) == sd:
                finds.append(finding(path, "unit_dimension", unit, tunit)); e["unit"] = tunit
            else:
                finds.append(finding(path, "unit_dimension_unresolved", unit, tunit or "-"))
        cnums = [to_num(x) for x in NUM_RE.findall(e.get("condition") or "")]  # D1e 条件泄漏
        if jnum is not None and jnum in [c for c in cnums if c is not None] and cvals and jnum not in cvals:
            if _writable():
                finds.append(finding(path, "condition_leak", val, cols)); patch_cols(e, cols, roles_w, tbl, ri, tunit)

        # ADAPT D1g：matched + 行内有干净列值 + 本条 value 不落任何列值 + D1a/b/d/e
        # 都没接管 → **静默错值洞**。实测 ADS1201 模拟输入上限抄错、既不构成范围、
        # 也不在别行，旧实现一个 finding 都不报，还写上 source 假装 matched。
        # 只在 `cells_ok` 且尚未回填时触发：脏格子/已由前面规则修好的不重复报。
        # 公式型 value（`0.2 ∗VCC` / `VCC - 1.0`）不会误伤 —— cvals 用 to_num 取首数，
        # 公式格的首数本来就在 cvals 里。
        if (_cells_ok_raw and not fused and not spans and not e.get("columns")
                and jnum is not None and cvals
                and all(abs(jnum - v) > 1e-9 for v in cvals)):
            finds.append(finding(path, "value_unsupported_unresolved", val,
                                 {"row_values": cvals}))

        fns = re.findall(r"\((\d{1,2})\)", " ".join(row))                      # 脚注绑定
        if fns and not e.get("footnotes"):
            finds.append(finding(path, "footnote_missing", "-", ",".join(fns)))
            e["footnotes"] = [int(x) for x in fns]
        e.setdefault("source", {}).update({"page": tbl["page"], "table": tbl["ti"], "row": ri})
        _title = clean(tbl.get("title") or "")
        if _title:
            # scope 本体：表标题/表头命中板级词 → board，否则 chip。
            # 渲染层据此分区；不要把板载芯片的电气表当成整板限值。
            # 标题为空时不写（合成表/无标题表保持旧的 source 三键形态）。
            e["source"]["table_title"] = _title[:120]
            e["source"]["scope"] = ("board" if _BOARD_TABLE_RX.search(
                _title + " " + " ".join(tbl.get("header") or [])) else "chip")
    return finds

# ── ADAPT A5: D1f 缺失行追加（主规格表内未被认领的参数行）──
def audit_missing_rows(doc, tables):
    finds = []
    doc.setdefault("specs", {})
    entries = doc["specs"].get("electrical") or []
    if not tables: return finds
    # 候选表：MIN/TYP/MAX 列角色 ≥2。外族表（A18）直接出局 —— 这条路径是
    # **绕过写盘闸门**直接塞新条目的，从别人的表里补行比写错一个值更糟：
    # 整片行都会进 facts，且没有任何 finding 指向它们。
    cand = [t for t in tables
            if not t.get("foreign_part") and table_has_value_roles(t)]
    # 主规格表 = 现有 electrical/absolute_max 条目定位成功 ≥2 的候选表
    claimed, placed_cnt = set(), {}
    all_entries = list(entries) + list(doc["specs"].get("absolute_max") or [])
    for e in all_entries:
        for tbl in cand:
            ri, _ = locate_row(tbl, e.get("symbol") or "", e.get("name") or "")
            if ri is not None:
                claimed.add((id(tbl), ri)); placed_cnt[id(tbl)] = placed_cnt.get(id(tbl), 0) + 1
                break
    main = [t for t in cand if placed_cnt.get(id(t), 0) >= 2]
    known = {nsym(str(e.get("symbol", "")) + str(e.get("name", ""))) for e in all_entries}
    for tbl in main:
        rm = role_map(tbl["header"])
        for ri, row in enumerate(tbl["rows"]):
            if (id(tbl), ri) in claimed: continue
            pi = next((ci for ci in range(len(row)) if ci not in rm), None)  # 参数列 = 第一个非角色列
            if pi is None: continue
            pname = clean(row[pi])
            if len(pname) < 4 or not re.search(r"[a-zA-Z]{3,}", pname): continue
            if nsym(pname) in known: continue
            roles = {rm[ci]: clean(row[ci]) for ci in range(len(row)) if ci in rm}
            cols = {r: to_num(roles.get(r, "")) for r in ("MIN", "TYP", "MAX")}
            raws = {r: roles.get(r, "").strip() for r in ("MIN", "TYP", "MAX") if roles.get(r, "").strip()}
            if not raws or not any(cols.get(r) is not None for r in raws): continue  # 无数值行不收
            e = {"name": pname,
                 "value": " / ".join(f"{raws[k]} {k}" for k in ("MIN", "TYP", "MAX") if k in raws),
                 "columns": {k: cols[k] for k in ("MIN", "TYP", "MAX") if cols.get(k) is not None}}
            unit = clean(roles.get("UNIT")) or next((u for u in [cell_unit(roles.get(r, "")) for r in ("MIN", "TYP", "MAX")] if u), "")
            if unit: e["unit"] = unit
            if roles.get("COND"): e["condition"] = roles["COND"]
            e["source"] = {"page": tbl["page"], "table": tbl["ti"], "row": ri}
            entries.append(e); known.add(nsym(pname))
            _PAGE.set(tbl.get("page"))          # 补的这条属于这张表
            finds.append(finding(f"specs.electrical[+].{pname[:48]}", "row_missing",
                                 "-", {k: cols[k] for k in ("MIN", "TYP", "MAX") if cols.get(k) is not None}))
    return finds

#: 板卡形态的封装名（`Evaluation Board` 被写进芯片的 package.type 就是 scope 冲突）
_BOARD_PKG_RX = re.compile(r"evaluation\s*(module|board)|development\s*(kit|board)|"
                           r"demo\s*board|boosterpack|printed\s*circuit", re.I)
#: 板级表格标题词。用于给 `source.scope` 打标（板卡 User Guide vs 芯片 datasheet）
_BOARD_TABLE_RX = re.compile(r"board\s+(spec|feature|input|power|connector|jumper|overview)|"
                             r"input\s+voltage|connector|jumper|evaluation\s+(module|board)|"
                             r"power\s+supply\s+input", re.I)


# ── 身份 / 封装 / 选项绑定（订购表为唯一事实源）──
def audit_ordering(doc, tables, requested):
    finds, ident, bound, pkg_val = [], "unverified", {}, None
    nr = nsym(requested)
    for tbl in tables:
        head = " ".join(tbl["header"]).lower()
        if not re.search(r"order|part\s*number|device\s*summary|selection|package", head): continue
        lit = next((r for r in tbl["rows"] if any(nsym(c) == nr for c in r)), None)
        if lit is None: continue
        ident = "verified"
        for ci, h in enumerate(tbl["header"]):
            hl = (h or "").lower(); cellv = clean(lit[ci]) if ci < len(lit) else ""
            if "package" in hl: pkg_val = cellv
            if re.search(r"freq|speed|rate|voltage|grade|temp", hl) and cellv: bound[hl.strip()] = cellv
        break
    if ident == "unverified":
        if any(nsym(c) == nr for tbl in tables for r in tbl["rows"] for c in r): ident = "verified"
        else: finds.append(finding("basic_info.mpn", "identity_unverified",
                                   doc.get("basic_info", {}).get("mpn"), requested))
    bi = doc.setdefault("basic_info", {})
    if nsym(bi.get("mpn", "")) != nr:                                             # 家族号≠请求号
        old_family = bi.get("mpn")
        finds.append(finding("basic_info.mpn", "identity_family", old_family, requested))
        bi["family"], bi["mpn"] = old_family, requested
        # ADAPT ②：身份修正必须**传播**。旧家族号若还留在 SEO / 替代料 /
        # 交叉参考 / 温区里，页面就会继续印芯片口径 —— ADS8568EVM 改板卡后
        # SEO 仍写 "16-bit SAR ADC" 正是这个形态。
        _old = nsym(old_family)
        if _old:
            for field in ("seo", "alternatives", "cross_reference"):
                txt = json.dumps(doc.get(field) or "", ensure_ascii=False).lower()
                if _old in txt:
                    finds.append(finding(field, "identity_stale_unresolved",
                                         old_family, requested))
            temp = json.dumps((doc.get("specs") or {}).get("temperature") or "",
                              ensure_ascii=False).lower()
            if _old in temp:
                finds.append(finding("specs.temperature", "identity_stale_unresolved",
                                     old_family, requested))
    pkg = (doc.get("specs", {}).get("package") or {}).get("type") or ""
    if pkg_val and nsym(pkg) != nsym(pkg_val):                                    # D3 封装来源
        finds.append(finding("specs.package.type", "package_mismatch", pkg, pkg_val))
        doc["specs"]["package"]["type"] = pkg_val
    # ADAPT ②：封装写成板卡形态（Evaluation Board），身份却不是板卡 → scope 归属冲突。
    # 这是「板载芯片 datasheet 的 package 被当成整板封装」最常见的 JSON 侧残留。
    if pkg and _BOARD_PKG_RX.search(pkg) \
            and str(bi.get("identity") or "").lower() not in ("evaluation_board",
                                                             "development_kit"):
        finds.append(finding("specs.package.type", "package_scope_unresolved",
                             pkg, bi.get("identity") or "-"))
    bfreq = [to_num(v) for k, v in bound.items() if re.search(r"freq|speed", k)]
    bfreq = [b for b in bfreq if b]
    if bfreq:
        doc_freqs = {to_num(str(e.get("value", ""))) for e in doc.get("specs", {}).get("electrical", [])
                     if dim_symbol(e.get("symbol"), e.get("name")) == "frequency" and to_num(str(e.get("value", "")))}
        wrong = sorted(f for f in doc_freqs if f and f not in bfreq)
        if wrong: finds.append(finding("specs.electrical[freq]", "option_conflation", wrong, bfreq))
        doc["bound_options"] = bound
    return finds, ident, bound

# ── D3 引脚/方向审计（引脚表与符号图共用同一审计结果）──
#: 引脚列的表头词。BGA 数据手册常用 `BALL / BALL NUMBER / BALL NAME / COORDINATE`，
#: 旧正则只认 `PIN`，导致 `rm["PIN"]=None` → tmap 空 → 整个 BGA 表被静默 skip，
#: 连 finding 都不报（ADC12DJ5200SE 的 1..15 伪球号就是这么活下来的）。
_PIN_HEAD_RX = re.compile(r"\bpin\b|pin\s*(no|number)|^no\.?|"
                          r"\bball\b|ball\s*(no|number|name)|\bcoordinate")
#: 引脚表必须同时有「编号列 + 名称/功能/描述列」。audit_pins 选表与 role_map 共用。
_PIN_NAME_HEAD_RX = re.compile(r"function|name|type|symbol|description|i/o")


def pin_role_map(header):
    rm = {"PIN": None, "NAME": None, "FUNC": None, "DESC": None}
    for i, h in enumerate(header):
        hl = (h or "").lower()
        if rm["PIN"]  is None and _PIN_HEAD_RX.search(hl):                         rm["PIN"] = i
        elif rm["NAME"] is None and re.search(r"\bname\b|symbol", hl):               rm["NAME"] = i
        elif rm["FUNC"] is None and re.search(r"function|type|i\s*/\s*o|mode", hl):  rm["FUNC"] = i
        elif rm["DESC"] is None and re.search(r"descrip|notes|remarks", hl):          rm["DESC"] = i
    return rm

ARROW = re.compile(r"([a-zA-Z0-9]+)\s*(→|->|↔|<->)\s*([a-zA-Z0-9]+)")
def audit_pins(doc, tables):
    finds = []
    pins = doc.get("pin_configuration") or []
    if not pins: return finds
    tbl = next((t for t in tables
                if any(_PIN_HEAD_RX.search((h or "").lower()) for h in t["header"])
                and any(_PIN_NAME_HEAD_RX.search((h or "").lower()) for h in t["header"])), None)
    if tbl is None:
        finds.append(finding("pin_configuration", "pin_table_unresolved", "-", "-")); return finds
    rm = pin_role_map(tbl["header"])
    tmap, tball = {}, {}
    for row in tbl["rows"]:
        raw = clean(row[rm["PIN"]]) if rm["PIN"] is not None and rm["PIN"] < len(row) else ""
        pn = to_num(raw)
        if pn is not None:
            tmap[int(pn)] = row
        # BGA：编号列是 `A1 / B2 / AA3`，不是数字；to_num 会把它当 None
        for b in re.findall(r"\b[A-Za-z]{1,2}\d{1,2}\b", raw):
            tball[b.upper()] = row
    def cell(row, k): return clean(row[rm[k]]) if rm.get(k) is not None and rm[k] < len(row) else ""
    for pe in pins:
        raw_pin = str(pe.get("pin") or "").strip()
        if raw_pin.isdigit():
            pn, row = int(raw_pin), tmap.get(int(raw_pin))
        elif re.fullmatch(r"[A-Za-z]{1,2}\d{1,2}", raw_pin):
            pn, row = raw_pin.upper(), tball.get(raw_pin.upper())
        else:
            pn, row = raw_pin, None
        if row is None: continue
        tname, tfunc, tdesc = cell(row, "NAME"), cell(row, "FUNC"), cell(row, "DESC")
        # 名称列存在时只比 NAME；把 FUNC（I/O/—）拼进去会把 `CLK+` 变成
        # `CLK+I`，再拿它和 JSON 的 `CLK+` 比包含关系 → 每条球号都误报 mismatch。
        _target = tname or tfunc
        tgt = nsym(_target)
        if tgt and nsym(pe.get("name")) not in (tgt, "") and tgt not in nsym(pe.get("name")):
            finds.append(finding(f"pin[{pn}]", "pin_mismatch", pe.get("name"),
                                 f"{tname} {tfunc}".strip()))
            pe["name"], pe["function"] = (tname or pe.get("name")), tfunc
        dar, jar = ARROW.search(tdesc + " " + tfunc), ARROW.search(pe.get("description") or "")
        if dar and jar and (jar.group(1).lower(), jar.group(3).lower()) != (dar.group(1).lower(), dar.group(3).lower()):
            finds.append(finding(f"pin[{pn}].description", "direction_reversal", jar.group(0), dar.group(0)))
            pe["description"] = ARROW.sub(dar.group(0), pe["description"], count=1)
    nums = sorted(tmap)
    if nums and nums != list(range(nums[0], nums[0] + len(nums))):
        finds.append(finding("pin_table", "pin_gap", nums[:3], "-"))
    # BGA 不走 pin_gap（球号本来就不是连续整数）：只校验 JSON 球号能在表里找到。
    # 找不到的球号不静默放行——它就是模型编出来的伪球号。
    missing = [str(p.get("pin")) for p in pins
               if re.fullmatch(r"[A-Za-z]{1,2}\d{1,2}", str(p.get("pin") or ""))
               and str(p.get("pin")).upper() not in tball]
    if missing:
        finds.append(finding("pin_configuration", "pin_table_unresolved",
                             missing[:3], "-"))
    return finds

# 差分对物理相邻性：零依赖实现已抽到 qc/pin_pairs.py（app 层红线审查也要用，
# 而本模块顶层 import pymupdf、缺库直接 sys.exit(3)，不适合被常驻进程引用）。
# 这里保留同名 re-export，既有调用方与单测不用改。
try:
    from qc.pin_pairs import audit_pin_pairs                     # 包模式
except ImportError:                                              # 脚本模式（qc/ 为根）
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from qc.pin_pairs import audit_pin_pairs


# ── 总入口 ──
# ── 列塌缩红线（2026-11-03 外审 V1，一票否决项）──────────────────────
#: 封装列单元格：`DCY (SOT-223)` / `KCS(TO-220)` / `KTT (TO-263)`。
#: 这是「多封装列」**唯一可靠的**结构信号 —— 只看表头角色词永远判不出来，
#: 热阻表根本没有 MIN/TYP/MAX。
#:
#: A22（2026-11-03，Issue #15）：码长放宽到 1~4。NE555 的封装码是单字母
#: （`D (SOIC)` / `P (PDIP)`），旧的 `{2,4}` 把这两列整个排除，于是 6 列的表
#: 只认出 4 列 —— **判据自己在同一张表上漏了两列**，再拿它去判塌缩必然失真。
#: 单字母之所以安全，是因为正则**要求紧跟 `(封装名)`**：裸字母（`A`/`B` 这类
#: 分值标记）与 `RθJC(top)`（括号前不是 A-Z 序列）都不会命中。
#: 仍用 `match` 锚定单元格开头：`search` 会把参数名 `RθJC(top)` 里读成
#: `JC (top)` 这个假封装列。
_PKG_COL_RE = re.compile(r"^([A-Z]{1,4})\s*\(\s*([A-Za-z0-9][A-Za-z0-9\-\s]*?)\s*\)")

#: 括号里是**单位/限定词**的行不是封装列。实测 LM317 / NE555 末页的封装尺寸表
#: 表头是 `L(mm) | W(mm) | B(mm)`：单字母码放宽后被读成 3 个"封装列"，
#: 再叠上「同名参数 + 第一列数值」就凭空报出一张塌缩表。
#: 判据只认**括号内容本身**，不看上下文 —— 上下文判据（比如"这张表是不是热阻表"）
#: 正是本函数刻意不用的（见 docstring）。
_NON_PACKAGE_PARENS = frozenset({
    "mm", "cm", "um", "µm", "in", "inch", "mil", "mils", "min", "max", "typ",
    "nom", "°c", "c", "v", "mv", "ma", "ua", "µa", "a", "w", "mw", "g", "oz",
    "%", "db", "s", "ns", "us", "µs", "ms", "hz", "khz", "mhz", "ghz",
})

#: 热阻参数名的归一化形态，只用于判断「这张表是不是热阻表」。
_THERMAL_LABELS = frozenset({"RθJA", "RθJCTOP", "RθJCBOT", "RθJB", "ΨJT", "ΨJB"})


def package_columns(tbl) -> list[dict]:
    """表里出现的封装列定义；不足 2 列返回 ``[]``（单封装表不算）。

    返回 ``[{"code":"DCY","package":"SOT-223","col":2}, …]``，``col`` 是列下标。
    判据只看**同一行里**是否出现 ≥2 个 `CODE (封装名)` 单元格 —— 跨行拼凑不算，
    否则一张普通表里零散出现两个封装名就会被误判成多封装表。
    """
    for row in tbl.get("rows") or []:
        cols = []
        for i, cell in enumerate(row):
            m = _PKG_COL_RE.match(clean(cell))
            if m and m.group(2).strip().lower() not in _NON_PACKAGE_PARENS:
                cols.append({"code": m.group(1).strip(),
                             "package": re.sub(r"\s+", " ", m.group(2)).strip(),
                             "col": i})
        if len(cols) >= 2:
            return cols
    return []


def _label_key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def audit_column_collapse(tables, specs) -> list[dict]:
    """**列塌缩红线**：多封装表里只抽了第一列 → 判 `column_collapse`，不许 pass。

    外审 6.7/10 一票否决的直接原因就是这条：LM317 的热阻表有 4 个封装列
    （DCY/KCS/KCT/KTT），交付的 JSON 只有第一列的数值，另外三个封装的热阻
    整个消失，页面上是一个**没有适用封装的裸数字**。客户拿它算结温会烧板子。

    判据（全部满足才判）：
      1. 该表在同一行里有 ≥2 个 `CODE (封装名)` 单元格；
      2. 至少 2 个数据行能在 JSON 的对应容器里找到同参数名的条目；
      3. 这些条目的数值**只落在第一列**，且 **`condition` 里没写封装名**。

    第 3 条的两个条件缺一不可。只看「值在不在第一列」会误杀一种**正确**做法：
    器件本体只做 DCY 封装时，抽取器只取 DCY 那一列是合理的 —— 只要它把
    `DCY (SOT-223)` 写进 `condition`，读者就知道这个 66.8 属于哪个封装。
    反过来说，一个**没有适用封装的裸数字**才是灾难：客户拿 66.8 去算 TO-263
    的结温，算出来是错的，而且页面上没有任何线索提示他错了。

    阈值取 60% 而不是 100%：LM317 的 Legacy 表 5 行里有 1 行（`RθJC(bot)`，
    DCY 列印 `NA`）会被抽成 KCS 的 0.1 —— 那是**错列**，不是「读了多列」。
    要求 100% 会让这张最典型的塌缩表因为「错得更离谱」而逃过判定。
    """
    out: list[dict] = []
    for ti, tbl in enumerate(tables or []):
        cols = package_columns(tbl)
        if len(cols) < 2:
            continue
        rows = tbl.get("rows") or []
        # 表头行 = 第一个含封装列的行；数据从它之后开始。
        hdr_at = -1
        for ri, row in enumerate(rows):
            if len([1 for c in cols if c["col"] < len(row)
                    and _PKG_COL_RE.match(clean(row[c["col"]]))]) >= 2:
                hdr_at = ri
                break
        codes = [c["code"].lower() for c in cols]
        checked = collapsed = 0
        for row in rows[hdr_at + 1:]:
            label = ""
            for ci, cell in enumerate(row):
                t = clean(cell)
                if t and not _PKG_COL_RE.match(t) and to_num(t) is None:
                    label = t
                    break
            if not label:
                continue
            vals = []
            for c in cols:
                v = clean(row[c["col"]]) if c["col"] < len(row) else ""
                vals.append(v)
            num_cols = [i for i, v in enumerate(vals) if to_num(v) is not None]
            if len(num_cols) < 2:
                continue                       # 这一行本来就只有一列有数
            # 在 JSON 里找同名条目（thermal 用规范化名，其余用字母数字归一）
            got = []
            for container in ("thermal", "electrical", "absolute_max"):
                for e in (specs.get(container) or []):
                    nm = _thermal_like_key(e.get("name"))
                    if nm and nm == _thermal_like_key(label):
                        got.append((container, clean(str(e.get("value") or "")),
                                    str(e.get("condition") or "")))
            if not got:
                continue
            checked += 1
            hit_cols = {i for i, v in enumerate(vals)
                        for _c, gv, _cd in got if _num_same(gv, v)}
            # 条件里点了封装名 → 这是**有意识的**单封装抽取，不算塌缩。
            # A22：必须按词边界比，不能用 `code in cd.lower()` —— NE555 的码是
            # 单字母（`D`/`P`），子串判会让 `PDIP`、`Legacy` 这种普通词把
            # 「根本没写封装」的塌缩行洗成合规。
            named = any(_names_package(cd, codes) for _c, _v, cd in got)
            if hit_cols and hit_cols <= {0} and not named:
                collapsed += 1
        if checked >= 2 and collapsed >= 2 and collapsed >= 0.6 * checked:
            out.append({
                "path": f"specs.{_container_guess(tbl, specs)}",
                "kind": "column_collapse",
                "json": (f"{collapsed}/{checked} 行只取到第 1 列且未写封装条件，"
                         f"另 {len(cols) - 1} 个封装列未取用"),
                "table": {"table_index": ti, "packages": [c["code"] for c in cols],
                          "columns": [c["package"] for c in cols],
                          "rows_checked": checked, "rows_collapsed": collapsed},
                "page": tbl.get("page"),
                "at": now_iso(),
            })
    return out


def _names_package(cond, codes) -> bool:
    """`condition` 里是否**按词**点了某个封装码。

    为什么不能用 `code in cond.lower()`：A22 之后 NE555 的封装码是单字母
    （`D` / `P`），子串判会把 `PDIP`、`Legacy chip`、`CDIP` 里任意一个字母
    当成「已写封装」，塌缩行就此洗白 —— 判据比数据还宽松，等于没有判据。
    词边界口径：码的左右都不能紧邻字母/数字（`D (SOIC)` 命中，`PDIP` 不命中）。
    """
    low = str(cond or "").lower()
    for code in codes:
        if not code:
            continue
        if re.search(rf"(?<![a-z0-9]){re.escape(str(code).lower())}(?![a-z0-9])", low):
            return True
    return False


def _thermal_like_key(s) -> str:
    """参数名归一化。`Rθ(JA)` 与 `RθJA` 视为同一项（原文写法不统一）。"""
    return re.sub(r"[\s()]", "", str(s or "")).upper()


def _num_same(a: str, b: str) -> bool:
    fa, fb = to_num(a), to_num(b)
    if fa is None or fb is None:
        return False
    return abs(float(fa) - float(fb)) < 1e-9


def _container_guess(tbl, specs) -> str:
    """这张表更像哪个容器。判据按可靠性排序，**不看 specs 里哪个非空** ——
    那等于「谁先有数据就说谁是」，一张电气表也会被判成 thermal。"""
    txt = " ".join(clean(c) for row in (tbl.get("rows") or []) for c in row)
    if "°c/w" in txt.lower():
        return "thermal"
    if any(_thermal_like_key(k) in _THERMAL_LABELS
           for row in (tbl.get("rows") or [])[:40] for k in row if k):
        return "thermal"
    return "electrical" if specs.get("electrical") else "unknown"


#: 「a to b」形态的值。**只认 `to`**：TI 表格里 MIN 与 MAX 两列被模型连写时
#: 一律是这个写法；而单格范围值（输入电压 `3 to 36`、温度 `–40 to 85`）也用它，
#: 所以命中之后必须再回原文核对（见 `audit_role_collapse` 的豁免条件）。
_RANGE_TO_RE = re.compile(r"^([±+\-]?\d+(?:\.\d+)?)\s+to\s+([±+\-]?\d+(?:\.\d+)?)$", re.I)

#: 角色塌缩扫描页数上限（词级规格表解析是 find_tables + 逐页取词，比 scan_tables 贵）。
_ROLE_MAX_PAGES = int(os.getenv("ICPDF_AUDIT_ROLE_PAGES", "40"))


def range_pair(value) -> tuple[float, float] | None:
    """`'8.8 to 11.2'` → ``(8.8, 11.2)``；不是这种形态返回 ``None``。"""
    m = _RANGE_TO_RE.match(clean(value))
    if not m:
        return None
    a, b = to_num(m.group(1)), to_num(m.group(2))
    if a is None or b is None:
        return None
    return float(a), float(b)


def _pdf_role_index(pdf_path) -> tuple[dict, list[str]]:
    """按单位索引 PDF 里**由表头角色决定**的数值：``{unit: [{page, role, value}]}``。

    数据来源是 `deterministic_extract.extract_spec_rows()` —— 它按表头文本判
    MIN/TYP/MAX，不写死列号。这里只借它的**角色归属**，不借参数名：
    多数规格页的参数列读不出（`parameter=None`），但角色与数值是可读的，
    而判「两个值是不是分属两列」只需要角色。
    """
    from qc import deterministic_extract as DE                          # noqa: PLC0415

    idx: dict[str, list[dict]] = {}
    texts: list[str] = []
    with fitz.open(str(pdf_path)) as dz:
        for i in range(min(_ROLE_MAX_PAGES, len(dz))):
            page = dz[i]
            texts.append(re.sub(r"\s+", " ", page.get_text()))
            try:
                rows = DE.extract_spec_rows(page)
            except Exception:                                           # noqa: BLE001
                rows = []
            for r in rows:
                unit = clean(r.get("unit") or "")
                if not unit:
                    continue
                for role in ("min", "typ", "max"):
                    n = to_num(clean(r.get(role) or ""))
                    if n is None:
                        continue
                    idx.setdefault(unit, []).append({
                        "page": i + 1, "role": role.upper(), "value": float(n),
                        "bbox": r.get("bbox")})
    return idx, texts


def audit_role_collapse(pdf_path, specs) -> list[dict]:
    """**角色塌缩红线**：把 MIN/TYP/MAX 两列连写成 `a to b` → 判 `role_collapse`。

    为什么这是阻断而不是提示：`8.8 to 11.2` 会被读者当成「区间内任意值都合规」，
    而原文 `8.8` 是 MIN、`11.2` 是 MAX —— 中间那些值（比如 9.0）根本不是原厂
    保证的规格。客户拿它选阈值就会误判。SH-15 / GH-18 的 P0 都是这一条。

    判据（全部满足才判）：
      1. JSON 的值形如 `a to b`；
      2. PDF 该单位下，`a` 与 `b` 分别出现在**不同角色列**的值里
         （`a` 落在 MIN/TYP/MAX 某一列，`b` 落在另一列）；
      3. 原文里**没有**原样印着这段 `a to b`（单格范围值合法，必须豁免）。

    第 3 条是防误杀的关键：`Recommended Operating Conditions` 的
    `VS = 3 to 36 V` 是同一格里的区间值，模型照抄是对的。
    """
    elec = (specs or {}).get("electrical") or []
    targets = [(i, e) for i, e in enumerate(elec) if range_pair(e.get("value"))]
    if not targets:
        return []
    try:
        idx, texts = _pdf_role_index(pdf_path)
    except Exception:                                                   # noqa: BLE001
        return []
    blob = " ".join(texts)
    out: list[dict] = []
    seen: set[tuple] = set()
    for ri, e in targets:
        rp = range_pair(e.get("value"))
        unit = clean(str(e.get("unit") or ""))
        rows = idx.get(unit) or []
        a, b = rp
        hit_a = [r for r in rows if abs(r["value"] - a) < 1e-9]
        hit_b = [r for r in rows if abs(r["value"] - b) < 1e-9]
        if not hit_a or not hit_b:
            continue
        role_a, role_b = hit_a[0]["role"], hit_b[0]["role"]
        if role_a == role_b:
            continue                        # 同一列里的两个值：可能真是区间
        if clean(str(e.get("value") or "")) in blob:
            continue                        # 原文原样印着这段区间 → 合法
        key = (a, b, unit)
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "path": f"specs.electrical[{ri}]",
            "kind": "role_collapse",
            "json": (f"{a:g} to {b:g} {unit} 把 MIN/TYP/MAX 两列连成一个区间；"
                     f"原文 {a:g} 属 {role_a} 列、{b:g} 属 {role_b} 列"),
            "table": {"page": hit_a[0]["page"], "roles": {role_a: a, role_b: b},
                      "unit": unit},
            "page": hit_a[0]["page"],
            "at": now_iso(),
        })
    return out


def audit_json(doc, pdf_path, write=False, requested=None, src_json=None):
    req = requested or doc.get("metadata", {}).get("requested_mpn") or doc.get("basic_info", {}).get("mpn", "")
    d = json.loads(json.dumps(doc))
    with fitz.open(pdf_path) as dz: tables = scan_tables(dz)
    # ADAPT A18：同一 PDF 里并列同构表（一颗料一张）时，先按标题型号把
    # 「同族另一颗料的表」降为兜底，否则 `_decide_match` 会按顺序取到别人的表。
    mark_foreign_tables(tables, req)
    f1 = audit_electrical(d.get("specs", {}).get("electrical"), tables, "specs.electrical")
    f2 = audit_electrical(d.get("specs", {}).get("absolute_max"), tables, "specs.absolute_max")
    f2b = audit_missing_rows(d, tables)                                             # ADAPT A5
    # 防「串页」：`audit_electrical` / `audit_missing_rows` 内部会 set `_PAGE`，
    # 退出时残留最后一个表的页码。后面两个是**装订/引脚**审计，压根不经过表 ——
    # 不在这里清掉的话，`package_mismatch` / `pin_mismatch` 会带上一个错误的页码，
    # 比没有页码更糟（人工会照着错页去翻）。
    _PAGE.set(None)
    f3, ident, bound = audit_ordering(d, tables, req)
    f4 = audit_pins(d, tables)
    f4b = audit_pin_pairs(d)                                                        # 差分对相邻性
    # 列塌缩红线：必须在 `_PAGE` 清空**之前**跑 —— 它要靠 `_PAGE` 记页码。
    _PAGE.set(None)
    f5 = audit_column_collapse(tables, d.get("specs", {}))
    # 角色塌缩（GH-15 / GH-18）：词级规格表按表头判 MIN/TYP/MAX，与 JSON 的
    # `a to b` 对不上就判阻断。它**不依赖** `_PAGE`，可以在清空之后跑。
    f6 = audit_role_collapse(pdf_path, d.get("specs", {}))
    finds = f1 + f2 + f2b + f3 + f4 + f4b + f5 + f6
    unresolved = [f for f in finds if f["kind"].endswith("unresolved")]
    blocked = [f for f in finds if f["kind"] in BLOCKING_KINDS]
    patched = sorted({f["kind"] for f in finds
                      if not f["kind"].endswith("unresolved") and f["kind"] not in BLOCKING_KINDS})

    def st(fs):
        # 阻断优先：只要有 blocking，就不能报 patched/pass —— 那会让该件进 ok 列表
        if any(f["kind"] in BLOCKING_KINDS for f in fs):
            return "blocked"
        return "patched" if any(not f["kind"].endswith("unresolved") for f in fs) else (
            "pass" if not fs else "unresolved")
    ver = {"spec_audit": st(f1 + f2 + f2b), "package_audit": st([f for f in f3 if f["kind"] == "package_mismatch"]),
           "pin_audit": st(f4), "identity": ident,
           "i18n_complete": None, "images_checked": None}   # 渲染层由 qc_regression lint 回填
    d.setdefault("metadata", {})["audit"] = {"tool": "table_audit", "at": now_iso(),
        "pdf": Path(pdf_path).name, "tables_scanned": len(tables), "findings": finds, "patched_kinds": patched}
    # 列塌缩单独落一份机器可读结论：下游 `fact_acceptance._derive()` 据此把
    # 受影响容器里的行判成 `column_collapse`（不许 pass），隔离器据此把它们
    # 搬进 `specs.unresolved_column_collapse`。**只写在 findings 里是不够的** ——
    # findings 是给人看的审计流水，没有「哪个容器受影响」这个维度。
    if f5:
        d["metadata"]["column_collapse"] = {
            "detected": True,
            "at": now_iso(),
            "containers": sorted({f["path"].split(".", 1)[-1] for f in f5}),
            "tables": [f["table"] for f in f5],
        }
    else:
        d["metadata"].pop("column_collapse", None)
    # 角色塌缩同样单独落一份：下游据此把受影响的行判成 `role_collapse`
    # （与列塌缩同级），而不是让「区间值看着像范围」混过去。
    if f6:
        d["metadata"]["role_collapse"] = {
            "detected": True,
            "at": now_iso(),
            "rows": [{"path": f["path"], "table": f["table"]} for f in f6],
        }
    else:
        d["metadata"].pop("role_collapse", None)
    d["metadata"]["verification"] = ver
    if write:
        # ADAPT A3: 写回读入的源 JSON 路径（非固定 data/parsed/{mpn}.json）
        jp = Path(src_json) if src_json else (PARSED / f"{safe_name(req)}.json")
        if jp.exists():
            bak = jp.with_name(jp.name + ".pre_audit")
            if not bak.exists(): bak.write_text(jp.read_text(encoding="utf-8"), encoding="utf-8")
        jp.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(jp, json.dumps(d, ensure_ascii=False, indent=1))
        FACTS.mkdir(parents=True, exist_ok=True)
        atomic_write(FACTS / f"{safe_name(req)}.facts.json", json.dumps(
            {"mpn": req, "basic": d.get("basic_info"), "specs": d.get("specs"),
             "pin_configuration": d.get("pin_configuration"), "bound_options": bound,
             "verification": ver, "audit_kinds": patched}, ensure_ascii=False, indent=1))
    return {"mpn": req, "pdf": Path(pdf_path).name, "findings": finds, "unresolved": unresolved,
            "blocked": blocked, "verification": ver, "patched_doc": d}

# ── ADAPT A2: 路径解析（DB 只读可选 + safe_name/哈希后缀 + qc 基线回退）──
def _find_json_in(d: Path, mpn: str):
    if not d.exists(): return None
    target = safe_name(mpn).lower()
    hits = []
    for p in sorted(d.glob("*.json")):
        if p.name.endswith((".alts.json", ".seo.json", ".pre_audit")): continue
        stem = HASH_SUFFIX.sub("", p.stem).lower()
        if stem == target or stem.startswith(target + "_"):
            hits.append(p)
    return hits[0] if hits else None

def _find_pdf_in(d: Path, mpn: str):
    if not d.exists(): return None
    sn = safe_name(mpn)
    for pat in (f"{sn}__*.pdf", f"{sn}.pdf", f"{sn}_*.pdf"):
        g = sorted(d.glob(pat))
        if g: return g[0]
    return None


#: 可订购号后缀里出现这些词 → 评估板/参考设计手册，不是器件本体规格。
#: 不加 `\b`：`…SEEVMPDK` 这种连写也是板子。
_BOARD_SUFFIX_RE = re.compile(r"(EVM|PDK|BOOST|DEMO|KIT|REF|DEV)", re.I)


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


def find_pdf_tolerant(d: Path, mpn: str, pdf_hash: str = ""):
    """料号 → PDF，返回 ``(path, how)``；``how`` ∈ exact / hash / prefix / none。

    为什么需要这一档（2026-10-31 实测）：
    `_find_pdf_in` 是**精确文件名前缀**，而线上 PDF 按**可订购号**命名
    （`ADC12DJ5200SEAAV__adc12dj5200se.pdf`），交付 JSON 的主键却是**请求型号**
    （`ADC12DJ5200SE`）。5 件验收里就有 1 件因此匹配失败：后处理静默降级成
    「未验证按键合并」、闸门 `locate_paths` 直接判「缺 PDF，跳过」—— 两种都是
    **看起来在跑、其实什么都没查**。这个失败模式和「融合列导致零判定」同一类，
    必须一起堵。

    降级顺序从强到弱，能用哈希就不用文件名：
      1. ``exact``  —— 原名精确命中（历史行为，不改变既有结论）；
      2. ``hash``   —— 用 ``metadata.pdf_hash`` 字节级核验候选；
      3. ``prefix`` —— 可订购号以请求型号开头（排掉 EVM/PDK 等板级手册），
                       取后缀最短者。**只有这一档是推测**，调用方应显式告警。

    红线：``ADS1201U`` 不得吞掉 ``ADS1201U-1``（`-1`/`1K` 是不同档位），
    所以多出来的后缀只允许纯字母数字。
    """
    hit = _find_pdf_in(d, mpn)
    if hit is not None:
        return hit, "exact"
    if not d or not d.exists():
        return None, "none"

    sn = safe_name(mpn).lower()
    want = (pdf_hash or "").strip().lower()
    cands = []
    for p in d.glob("*.pdf"):
        base = p.stem.split("__")[0]
        if not base.lower().startswith(sn):
            continue
        extra = base[len(safe_name(mpn)):]
        if not re.fullmatch(r"[A-Za-z0-9]*", extra):
            continue
        if _BOARD_SUFFIX_RE.search(extra):
            continue
        cands.append(p)
    if not cands:
        return None, "none"

    if want:
        same = [p for p in cands if _file_sha256(p) == want]
        if same:
            # 同一份手册按不同可订购号各存一份是常态，取最短名。
            return sorted(same, key=lambda p: (len(p.stem), p.name))[0], "hash"
    return sorted(cands, key=lambda p: (len(p.stem), p.name))[0], "prefix"

def _json_pdf_hash(jpath):
    """取 JSON 里记录的 ``metadata.pdf_hash``，用于核验「这份 PDF 是不是那一份」。

    读不到/没有就返回空串 —— 调用方据此退化成前缀推测（并应告警），不阻断。
    """
    if not jpath: return ""
    try:
        d = json.loads(Path(jpath).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    return str(((d.get("metadata") or {}).get("pdf_hash")) or "")


def _resolve(stored, base_dir, exts):
    if not stored: return None
    sp = Path(str(stored).replace("\\", "/"))
    if sp.exists(): return sp
    cand = base_dir / sp.name
    return cand if cand.exists() else None

def locate_paths(mpn):
    j = p = None; req = mpn
    if DB.exists():
        try:
            con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
            cols = [r[1] for r in con.execute("pragma table_info(item)")]
            mcol = next((c for c in ("requested_mpn", "mpn", "part_number") if c in cols), None)
            if mcol:
                row = con.execute(f"select json_path, pdf_path, {mcol} from item where {mcol}=? limit 1", (mpn,)).fetchone()
                if row:
                    j = _resolve(row[0], PARSED, (".json",))
                    p = _resolve(row[1], PDFS, (".pdf",))
                    req = row[2] or mpn
            con.close()
        except Exception: pass
    if j is None: j = _find_json_in(PARSED, mpn)      # 权威运行时目录优先
    if j is None: j = _find_json_in(QC_JSON, mpn)     # ADAPT A2: qc 基线回退
    if p is None or not p.exists(): p = _find_pdf_in(PDFS, mpn)
    if p is None or not p.exists():
        # 精确前缀找不到时不能直接判「缺 PDF，跳过」——那等于闸门静默失效。
        # 线上文件名是可订购号（`ADC12DJ5200SEAAV__…`），请求型号只是它的前缀。
        p, _how = find_pdf_tolerant(PDFS, mpn, _json_pdf_hash(j))
    if (p is None or not p.exists()): p = _find_pdf_in(QC_PDFS, mpn)
    if (p is None or not p.exists()):
        p, _how = find_pdf_tolerant(QC_PDFS, mpn, _json_pdf_hash(j))
    return {"json": j, "pdf": p, "requested": req} if (j and p and Path(p).exists()) else None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mpns", nargs="*")
    ap.add_argument("--mpn-file"); ap.add_argument("--all", action="store_true"); ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--write", action="store_true"); ap.add_argument("--report"); ap.add_argument("--pdf"); ap.add_argument("--json")
    a = ap.parse_args()
    mpns = list(a.mpns)
    if a.mpn_file: mpns += [l.strip() for l in Path(a.mpn_file).read_text(encoding="utf-8").splitlines() if l.strip()]
    if a.all:
        mpns += [HASH_SUFFIX.sub("", p.stem) for p in sorted(PARSED.glob("*.json"))
                 if not p.name.endswith((".alts.json", ".seo.json", ".pre_audit"))]
    if a.limit: mpns = mpns[:a.limit]
    if not mpns: ap.error("需要型号或 --all")
    results, missing, kinds = [], [], {}
    for m in mpns:
        loc = locate_paths(m)
        if a.json: loc = {"json": Path(a.json), "pdf": Path(a.pdf) if a.pdf else (loc or {}).get("pdf"), "requested": m}
        if not loc or not loc["pdf"]:
            missing.append(m); print(f"[{m}] 缺 JSON/PDF，跳过"); continue
        doc = json.loads(Path(loc["json"]).read_text(encoding="utf-8"))
        r = audit_json(doc, loc["pdf"], write=a.write, requested=loc["requested"], src_json=loc["json"])
        results.append({k: r[k] for k in ("mpn", "pdf", "findings", "unresolved", "blocked", "verification")})
        for f in r["findings"]: kinds[f["kind"]] = kinds.get(f["kind"], 0) + 1
        if r["blocked"]:
            tag = "BLOCKED"
        elif r["findings"] and not r["unresolved"]:
            tag = "PATCHED"
        else:
            tag = "UNRESOLVED" if r["unresolved"] else "CLEAN"
        print(f"[{r['mpn']}] {tag} findings={len(r['findings'])} " +
              "; ".join(f"{f['kind']}:{f['path']} json={f['json']}→table={f['table']}" for f in r["findings"][:6]))
    if a.report:
        Path(a.report).parent.mkdir(parents=True, exist_ok=True)
        Path(a.report).write_text(json.dumps({"at": now_iso(), "results": results, "kind_counts": kinds}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"合计 {len(results)} 件；发现分布 {kinds}；unresolved {sum(len(r['unresolved']) for r in results)}；"
          f"blocked {sum(len(r['blocked']) for r in results)}；缺失 {missing}")
    sys.exit(3 if missing and not results
             else (2 if any(r["unresolved"] or r["blocked"] for r in results) else 0))

if __name__ == "__main__":
    main()
