"""新旧解析 JSON 的合并器：旧字段保留、新字段受控更新。

为什么不是浅合并
----------------
`{**old, **new}` 会把新 JSON 里**缺失**的历史字段直接抹掉。典型例子是
`multi_language`：它由环境变量 `ICPDF_LANGS` 控制是否生成，当前生产与
dry-run 都没设该变量，所以新解析结果里一定没有这个字段。这**不代表**
多语言数据被确认为空，只是运行时没开。浅合并会静默删掉 13281 份文件里的
多语言内容。

反过来 `{**new, **old}` 也不行：那会让新解析的改善全部失效。

所以走「字段白名单」：白名单内的字段允许被新解析结果更新，白名单外的一律
保留旧值并登记。这样既拿到解析改善，又不丢历史维护内容。

合并规则（与需求一致）
----------------------
1. 新 JSON 没有 `multi_language` → 原样保留旧的，记录原因
2. 旧有、新旧内容不同 → 保留旧值并记录差异；不静默覆盖
3. 旧 JSON 没有 → 不凭空补造，标记待补充
4. 白名单内字段 → 用新值更新；白名单外（历史维护字段）→ 保留旧值
5. 结构不兼容（类型不同、语言体非 dict）→ 阻断该件自动写回，进人工复核

新 JSON 里出现了旧 JSON 没有的顶层字段：也算白名单外？不——新解析可能引入
新字段，这类字段按「白名单内才更新」的原则处理，非白名单的新字段**不写入**，
登记为 `new_field_skipped`，避免把未知内容带进生产。

只读：不碰生产 parsed / backup / 数据库，只写 --out-dir。

用法（容器内）
--------------
    python qc/json_merge.py --mpn A,B,C --out-dir /tmp/v4_merge
    python qc/json_merge.py --mpns-file mpns.txt --out-dir /tmp/v4_merge
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.reparse_ordering import _safe                      # noqa: E402

# ---------------------------------------------------------------- 字段白名单
# 只有这些字段允许被新解析结果更新。键是顶层字段，值是可更新的子字段集合；
# 值为 None 表示「整体替换」（纯字符串/标量列表，没有历史维护价值）。
PARSE_OWNED: dict[str, set | None] = {
    "basic_info": {"mpn", "manufacturer", "category", "subcategory",
                   "description", "datasheet_url"},
    "specs": {"electrical", "absolute_max", "package", "temperature"},
    "features": None,
    "applications": None,
    "pin_configuration": {"pin", "name", "description"},
    "ordering_info": {"mpn", "package", "marking", "moq", "packaging"},
    # package 是 run_one() 里 build_alternatives() 补的，不在模型 schema 里，
    # 但仍属「解析/交付链路产出」，允许更新
    "alternatives": {"mpn", "manufacturer", "reason", "package"},
    "seo": {"title_en", "title_zh", "meta_description_en",
            "meta_description_zh", "keywords"},
    # requested_mpn 是 parse 时写的，schema 里没有但每次都会输出
    "metadata": {"pdf_hash", "parse_timestamp", "model_version",
                 "confidence", "requested_mpn"},
}

# 列表项的主键：能对齐才逐项合并，对齐不了就整体替换
LIST_KEY = {
    "pin_configuration": lambda d: str(d.get("pin") or "").strip().lower(),
    "ordering_info": lambda d: str(d.get("mpn") or "").strip().lower(),
    "alternatives": lambda d: str(d.get("mpn") or "").strip().upper(),
}


def _sig(d: dict) -> tuple:
    g = lambda k: str((d or {}).get(k) or "").strip().lower()
    return (g("name"), g("condition"), g("unit"))


def _item_key(field: str, d: dict) -> str:
    if field in LIST_KEY:
        return LIST_KEY[field](d)
    if field in ("electrical", "absolute_max"):
        return "|".join(_sig(d))
    return ""


def _kind(v) -> str:
    return type(v).__name__


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


# ---------------------------------------------------------------- multi_language
def merge_multi_language(old_ml, new_ml, rows, mpn):
    """按规则合并 multi_language，返回最终值。

    rows 里登记每一条处置，供人工审计；阻断项写进 blocked。
    """
    def rec(action, note, path="multi_language"):
        rows.append({"mpn": mpn, "field": path, "action": action,
                     "old_kind": _kind(old_ml), "new_kind": _kind(new_ml),
                     "note": note})

    if old_ml is None and (new_ml is None or new_ml == {}):
        rec("todo_missing", "旧新均无该字段，不凭空补造，标记待补充")
        return None, []
    if old_ml is None:
        rec("added", "旧无、新有，采用新值")
        return new_ml, []
    if new_ml is None or new_ml == {}:
        # 关键边界：新解析没生成 ≠ 多语言数据为空。
        # 原因是运行时未设 ICPDF_LANGS，不是解析器确认无内容。
        rec("kept_legacy",
            "新解析未生成该字段（ICPDF_LANGS 未设置），原样保留旧值")
        return old_ml, []
    if type(old_ml) is not type(new_ml):
        rec("conflict_blocked", "新旧类型不同，结构不兼容，转人工复核")
        return old_ml, ["multi_language 类型不兼容（%s vs %s）"
                        % (_kind(old_ml), _kind(new_ml))]
    if not isinstance(old_ml, dict):
        rec("kept_legacy", "非 dict 结构，保留旧值")
        return old_ml, []

    blocked = []
    out = copy.deepcopy(old_ml)
    for lang, old_body in old_ml.items():
        if lang not in new_ml:
            rows.append({"mpn": mpn, "field": "multi_language.%s" % lang,
                         "action": "lang_kept", "old_kind": _kind(old_body),
                         "new_kind": "-", "note": "新解析无该语言，保留旧值"})
            continue
        new_body = new_ml[lang]
        if not isinstance(old_body, dict) or not isinstance(new_body, dict):
            rows.append({"mpn": mpn, "field": "multi_language.%s" % lang,
                         "action": "conflict_blocked",
                         "old_kind": _kind(old_body), "new_kind": _kind(new_body),
                         "note": "语言体类型不是 dict，转人工复核"})
            blocked.append("multi_language.%s 结构不兼容" % lang)
            continue
        same = old_body == new_body
        diff_keys = sorted(k for k in set(old_body) | set(new_body)
                           if old_body.get(k) != new_body.get(k))
        rows.append({"mpn": mpn, "field": "multi_language.%s" % lang,
                     "action": "lang_kept",
                     "old_kind": "dict(%d)" % len(old_body),
                     "new_kind": "dict(%d)" % len(new_body),
                     "note": ("内容一致，保留旧值" if same
                              else "内容不同，按规则保留旧值；差异键 %s"
                                   % ",".join(diff_keys[:8]))})
    for lang in new_ml:
        if lang not in old_ml:
            out[lang] = copy.deepcopy(new_ml[lang])
            rows.append({"mpn": mpn, "field": "multi_language.%s" % lang,
                         "action": "lang_added", "old_kind": "-",
                         "new_kind": _kind(new_ml[lang]),
                         "note": "旧无该语言，采用新值"})
    return out, blocked


# ---------------------------------------------------------------- 列表合并
def _merge_list(field: str, old_list, new_list, allowed, rows, mpn):
    """列表项按主键对齐合并；对齐不了的整段用新值。

    旧有的额外键（如 pin_configuration[].device_scope）属于历史维护内容，
    对齐后保留下来，不让它被解析结果冲掉。
    """
    if not isinstance(old_list, list) or not isinstance(new_list, list):
        return new_list, []
    blocked = []
    if not old_list or not new_list:
        return (new_list if new_list else old_list), blocked

    # 有主键才逐项对齐，否则整段替换（纯字符串列表没有合并意义）
    if not all(isinstance(x, dict) for x in old_list + new_list) or not _item_key(field, old_list[0]):
        rows.append({"mpn": mpn, "field": field, "action": "updated",
                     "old_kind": "list(%d)" % len(old_list),
                     "new_kind": "list(%d)" % len(new_list),
                     "note": "无主键，整段采用新值"})
        return new_list, blocked

    old_map = {}
    for it in old_list:
        k = _item_key(field, it)
        old_map.setdefault(k, []).append(it)
    out, used = [], set()
    for it in new_list:
        k = _item_key(field, it)
        pool = old_map.get(k) or []
        idx = len(used & {id(x) for x in pool})
        src = pool[idx] if idx < len(pool) else None
        if src is not None:
            used.add(id(src))
        merged = copy.deepcopy(it)
        if src is not None and allowed:
            for k2, v2 in src.items():
                if k2 not in allowed:
                    merged[k2] = copy.deepcopy(v2)
                    rows.append({"mpn": mpn, "field": "%s[].%s" % (field, k2),
                                 "action": "kept_legacy",
                                 "old_kind": _kind(v2), "new_kind": "-",
                                 "note": "白名单外的历史字段，保留旧值"})
        out.append(merged)
    left = [x for x in old_list if id(x) not in used]
    if left:
        out.extend(copy.deepcopy(left))
        rows.append({"mpn": mpn, "field": field, "action": "orphan_kept",
                     "old_kind": "list(%d)" % len(old_list),
                     "new_kind": "list(%d)" % len(new_list),
                     "note": "旧有而新无的 %d 项已保留" % len(left)})
    rows.append({"mpn": mpn, "field": field, "action": "updated",
                 "old_kind": "list(%d)" % len(old_list),
                 "new_kind": "list(%d)" % len(new_list),
                 "note": "按主键合并，白名单内用新值"})
    return out, blocked


# ---------------------------------------------------------------- 主合并
def merge_doc(old: dict, new: dict, mpn: str = "") -> tuple[dict, list, list]:
    """返回 (合并结果, 处置清单, 阻断原因)。"""
    rows: list = []
    blocked: list = []
    out = copy.deepcopy(old)

    # 1) 白名单内的顶层字段
    for field, allowed in PARSE_OWNED.items():
        if field not in new:
            continue
        nv = new[field]
        ov = old.get(field)
        if allowed is None:
            if ov != nv:
                rows.append({"mpn": mpn, "field": field, "action": "updated",
                             "old_kind": _kind(ov), "new_kind": _kind(nv),
                             "note": "白名单字段，采用新值"})
            out[field] = copy.deepcopy(nv)
            continue
        if ov is None:
            # 旧文档没有这个字段属「旧无新有」，直接采用新值。
            # 不能走到下面的类型比较，否则 NoneType vs dict 会被误判成结构冲突，
            # 结果是新解析的内容整个丢掉（单测 test_empty_old_doc 抓到的）。
            rows.append({"mpn": mpn, "field": field, "action": "added",
                         "old_kind": "-", "new_kind": _kind(nv),
                         "note": "旧无该字段，采用新值"})
            out[field] = copy.deepcopy(nv)
            continue
        if not isinstance(nv, dict) or not isinstance(ov, dict):
            if _kind(ov) != _kind(nv):
                rows.append({"mpn": mpn, "field": field,
                             "action": "conflict_blocked",
                             "old_kind": _kind(ov), "new_kind": _kind(nv),
                             "note": "结构不兼容，转人工复核"})
                blocked.append("%s 结构不兼容（%s vs %s）"
                               % (field, _kind(ov), _kind(nv)))
                continue
            out[field] = copy.deepcopy(nv)
            continue
        sub = copy.deepcopy(ov)
        for k2, v2 in nv.items():
            if k2 not in allowed:
                rows.append({"mpn": mpn, "field": "%s.%s" % (field, k2),
                             "action": "new_field_skipped",
                             "old_kind": "-", "new_kind": _kind(v2),
                             "note": "不在白名单内，不写入"})
                continue
            if isinstance(v2, list) and isinstance(sub.get(k2), list):
                merged_list, b = _merge_list(k2, sub.get(k2), v2, None, rows, mpn)
                blocked.extend(b)
                sub[k2] = merged_list
            else:
                if sub.get(k2) != v2:
                    rows.append({"mpn": mpn, "field": "%s.%s" % (field, k2),
                                 "action": "updated",
                                 "old_kind": _kind(sub.get(k2)),
                                 "new_kind": _kind(v2), "note": "白名单字段，采用新值"})
                sub[k2] = copy.deepcopy(v2)
        out[field] = sub

    # 2) 顶层列表（pin_configuration / ordering_info / alternatives 本身是列表）
    for field, keyfn in LIST_KEY.items():
        if field in new and isinstance(new[field], list):
            merged_list, b = _merge_list(field, old.get(field) or [], new[field],
                                         PARSE_OWNED.get(field), rows, mpn)
            blocked.extend(b)
            out[field] = merged_list

    # 3) 白名单外的顶层字段：保留旧值，登记
    for k, v in old.items():
        if k in PARSE_OWNED:
            continue
        if k == "multi_language":
            continue
        rows.append({"mpn": mpn, "field": k, "action": "kept_legacy",
                     "old_kind": _kind(v), "new_kind": "-",
                     "note": "白名单外的历史字段，保留旧值"})

    # 4) multi_language 专项
    ml, b = merge_multi_language(old.get("multi_language"),
                                 new.get("multi_language"), rows, mpn)
    blocked.extend(b)
    if ml is None:
        out.pop("multi_language", None)
    else:
        out["multi_language"] = ml

    # 5) 新 JSON 有、旧 JSON 没有的顶层字段：不在白名单就不写入
    for k in new:
        if k in old or k in PARSE_OWNED:
            continue
        rows.append({"mpn": mpn, "field": k, "action": "new_field_skipped",
                     "old_kind": "-", "new_kind": _kind(new[k]),
                     "note": "白名单外的新字段，不写入"})
    return out, rows, blocked


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="新旧解析 JSON 合并器（旧字段保留 + 白名单更新）")
    ap.add_argument("--mpn", default="", help="逗号分隔")
    ap.add_argument("--mpns-file", default="")
    ap.add_argument("--tmp-parsed", default="/tmp/v4_dryrun/parsed",
                    help="新解析结果目录（临时目录）")
    ap.add_argument("--backup", default=str(ROOT / "data" / "parsed_backup_ordering"),
                    help="旧 JSON 基线目录")
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--out-dir", default="/tmp/v4_merge")
    a = ap.parse_args(argv)

    tmp, backup = Path(a.tmp_parsed), Path(a.backup)
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "merged").mkdir(exist_ok=True)

    mpns = [x.strip() for x in a.mpn.split(",") if x.strip()]
    if a.mpns_file and Path(a.mpns_file).exists():
        mpns += [x.strip() for x in Path(a.mpns_file).read_text(
            encoding="utf-8").splitlines() if x.strip()]
    mpns = list(dict.fromkeys(mpns))
    if not mpns:
        print("未指定 MPN")
        return 2

    db = sqlite3.connect(Path(a.data_root) / "workbench.sqlite3")
    all_rows, summary = [], []
    for mpn in mpns:
        row = db.execute("SELECT json_path FROM item WHERE mpn=?", (mpn,)).fetchone()
        old_name = Path(row[0].replace("\\", "/")).name if row and row[0] else ""
        if not old_name or not (backup / old_name).exists():
            hits = sorted(p.name for p in backup.glob(_safe(mpn) + "_*.json"))
            old_name = hits[0] if hits else ""
        new_hits = sorted(tmp.glob(_safe(mpn) + "_*.json"))
        if not old_name or not new_hits:
            print("  [!] 缺旧/新文件，跳过：%s（旧 %s / 新 %d）"
                  % (mpn, old_name or "无", len(new_hits)))
            continue
        old, new = _load(backup / old_name), _load(new_hits[0])
        merged, rows, blocked = merge_doc(old, new, mpn)
        all_rows.extend(rows)

        dst = out_dir / "merged" / ("%s.merged.json" % _safe(mpn))
        dst.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")

        old_ml = old.get("multi_language") or {}
        new_ml = merged.get("multi_language") or {}
        summary.append({
            "mpn": mpn,
            "blocked": "是" if blocked else "否",
            "block_reason": "；".join(blocked),
            "old_ml_langs": ",".join(sorted(old_ml.keys())) if isinstance(old_ml, dict) else "",
            "merged_ml_langs": ",".join(sorted(new_ml.keys())) if isinstance(new_ml, dict) else "",
            "ml_kept": "是" if isinstance(new_ml, dict) and new_ml == old_ml else "否",
            "old_top_keys": len(old), "merged_top_keys": len(merged),
            "old_elec": len((old.get("specs") or {}).get("electrical") or []),
            "merged_elec": len((merged.get("specs") or {}).get("electrical") or []),
            "old_order": len(old.get("ordering_info") or []),
            "merged_order": len(merged.get("ordering_info") or []),
            "out_file": dst.name,
        })
        print("  %-22s 阻断=%s 语言 %s -> %s 电气 %d -> %d 订货 %d -> %d"
              % (mpn, "是" if blocked else "否",
                 summary[-1]["old_ml_langs"], summary[-1]["merged_ml_langs"],
                 summary[-1]["old_elec"], summary[-1]["merged_elec"],
                 summary[-1]["old_order"], summary[-1]["merged_order"]))

    def dump(name, rs):
        if not rs:
            return
        p = out_dir / name
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rs[0].keys()))
            w.writeheader()
            w.writerows(rs)
        print("  写 %s（%d 行）" % (p, len(rs)))

    dump("v4_merge_report.csv", all_rows)
    dump("v4_merge_summary.csv", summary)

    from collections import Counter
    print("\n处置统计：")
    for k, v in Counter(r["action"] for r in all_rows).most_common():
        print("   %-20s %d" % (k, v))
    print("阻断 %d 件" % sum(1 for s in summary if s["blocked"] == "是"))
    print("多语言原样保留 %d / %d 件"
          % (sum(1 for s in summary if s["ml_kept"] == "是"), len(summary)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
