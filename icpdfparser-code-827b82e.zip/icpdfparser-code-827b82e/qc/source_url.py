#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`basic_info.datasheet_url` 的**唯一**解析口径。

为什么单独成模块
----------------
V4 把这根链断在了最不该断的地方：主力件 `ADC12DJ5200SE` 的 `datasheet_url`
变成空串，页面里 `ti.com` 出现 0 次（Reviewer V4 新-1）。用户最初提的需求
就是「详情页里含原始 PDF 链接」，而这个包反复强调「请回原厂核实」——
链接没了，那句提示就成了空话。

根因不在渲染层（同包 `BOOST-DRV8711` 仍有 2 个 ti.com 链接），在于查表口径：
`url_map` 按 **PDF 文件名**建索引，而本地文件名是
`{请求订货号}__{抓取文件名}` —— 抓下来时挂的是 `ADC12DJ5200SEEVM`，
重解析时挂的是 `ADC12DJ5200SEAAV`，整名比对必然落空。

抽成模块是因为它有两个调用方（解析管线、装配管线），两边口径必须一致，
否则「解析时填对了、装配时又冲掉」这种事会反复发生。
"""
from __future__ import annotations

import csv
import re
from pathlib import Path

try:
    from qc.safe_access import safe_dict
except ImportError:                                      # 脚本直跑（sys.path[0] = qc/）
    from safe_access import safe_dict                          # noqa: F401

#: TI 文档号：`SLVSGH5C` / `SBAS543C` / `SLVU967A` / `SPRUHH9` 这一族。
#: 只用来判断「这份 PDF 是不是 TI 出的」，不用它拼 URL。
_TI_DOC_RE = re.compile(r"\bS[A-Z]{3}[A-Z0-9]{3,5}\b")

#: 是否 ti.com 官方域（含子域）。
_TI_HOST_RE = re.compile(r"^https?://([a-z0-9-]+\.)*ti\.com/", re.I)


def doc_key(name: str) -> str:
    """PDF 文件名 → 稳定的匹配键（小写、去掉请求号前缀）。

    本地文件名约定是 `{请求订货号}__{抓取时的文件名}`，manifest 的 `local_path`
    记的也是这个形状。**两边的订货号可能不同**，只有 `__` 之后的 PDF 本体
    文件名一致 —— 所以键取后半段。
    """
    base = Path(str(name)).name
    return (base.split("__", 1)[1] if "__" in base else base).lower()


def load_url_map(manifest: Path) -> dict[str, str]:
    """`data/manifest.csv` → `{PDF 文件名键: 抓取时的 final_url}`。"""
    if not Path(manifest).is_file():
        return {}
    m: dict[str, str] = {}
    with open(manifest, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            url = (row.get("final_url") or "").strip()
            if url:
                m[doc_key(row["local_path"])] = url
    return m


_MPN_SAFE_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{2,}$")


def _ti_rule_url(doc: dict, pdf_name: str = "") -> str:
    """TI 官方直链。**文件名是型号前缀时优先用它，否则用型号。**

    `ADS1201U-1/1K` 是订货号，拼成 `lit/ds/symlink/ads1201u-1/1k.pdf` 是无效 URL
    （带斜杠、且手册本体叫 `ads1201.pdf`）。本地文件名 `{订货号}__{抓取名}` 的后半段
    才是手册本名，`doc_key()` 已经把它剥出来并小写。

    但文件名不能无条件优先：抓取时存成 `whatever.pdf` 时，用它拼出来的链接是错的。
    所以只在「文件名是型号前缀」时才采信 —— 手册本名按定义是订货号的前缀
    （`ads1201` ⊂ `ADS1201U-1/1K`），两者不一致就说明文件名不可信。
    """
    stem = doc_key(pdf_name)
    if stem.endswith(".pdf"):
        stem = stem[:-4]
    mpn = str(safe_dict(doc, "basic_info").get("mpn") or "").strip().lower()
    mpn_key = re.sub(r"[^a-z0-9]", "", mpn)
    if _MPN_SAFE_RE.match(stem) and mpn_key.startswith(re.sub(r"[^a-z0-9]", "", stem)):
        return f"https://www.ti.com/lit/ds/symlink/{stem}.pdf"
    if _MPN_SAFE_RE.match(mpn):
        return f"https://www.ti.com/lit/ds/symlink/{mpn}.pdf"
    return ""


def _should_override(doc: dict, url: str, pdf_text: str, pdf_name: str = "") -> bool:
    """现有链接该不该被 TI 官方直链替换。

    三条全中才替换：TI 的件 + 身份已确认 + 原文带 TI 文档号。
    另外**只替换非 ti.com 的链接** —— 板卡的 `/lit/ug/` 是用户指南，
    硬改成 `/lit/ds/symlink/` 会指向一个不存在的 datasheet。
    """
    bi = safe_dict(doc, "basic_info")
    return bool(
        url and _TI_HOST_RE.match(url) is None
        and str(bi.get("manufacturer") or "").strip().lower() == "texas instruments"
        and str(bi.get("identity_state") or "") == "IDENTITY_SUPPORTED"
        and _ti_rule_url(doc, pdf_name)
        and _TI_DOC_RE.search(pdf_text or ""))


def resolve(doc: dict, pdf_name: str, url_map: dict[str, str],
            pdf_text: str = "") -> tuple[str, str]:
    """定 `datasheet_url`，返回 `(url, 来源)`；定不出来返回 `("", "unknown")`。

    三级，先可信后兜底：

    1. `manifest` —— 抓取时记下的 `final_url`，是**原始出处**，最可信。
       但第三方镜像会被 TI 官方直链替换（见 `_should_override`）。
    2. `mpn_rule` —— TI 手册固定直链 `lit/ds/symlink/{手册本名}.pdf`。
       只在 PDF 自带 TI 文档号时才拼（否则不知道是不是 TI 的件，凭料号前缀猜
       会把别家的型号指到 ti.com）。
    3. `unknown` —— 老实留空，由 `check_core()` 拦下，不编一个看起来像的链接。
    """
    hit = url_map.get(doc_key(pdf_name))
    if hit:
        if _should_override(doc, hit, pdf_text, pdf_name):
            return _ti_rule_url(doc, pdf_name), "mpn_rule_override"
        return hit, "manifest"
    if _ti_rule_url(doc, pdf_name) and _TI_DOC_RE.search(pdf_text or ""):
        return _ti_rule_url(doc, pdf_name), "mpn_rule"
    return "", "unknown"


def fill(doc: dict, pdf_name: str, url_map: dict[str, str],
         pdf_text: str = "") -> dict:
    """就地补 `basic_info.datasheet_url`，返回动作摘要。

    已有值**不覆盖**（除非它明显是空串）—— 上游写进来的通常更准。
    但板卡件被 `identity_scope` 清空后，这里会用 `device_datasheet_url` 回填，
    页面侧再由 `json_to_txt._source_pdf_url()` 兜一层。
    """
    bi = doc.get("basic_info")
    if not isinstance(bi, dict):
        bi = doc["basic_info"] = {}
    cur = str(bi.get("datasheet_url") or "").strip()
    if cur:
        # 已有值也要过一遍镜像检查：老产物里写死的是抓取时的第三方镜像，
        # 不检查就永远改不过来（ADS1201U 的 z2data 链接就是这么留下来的）。
        if _should_override(doc, cur, pdf_text, pdf_name):
            new = _ti_rule_url(doc, pdf_name)
            bi["datasheet_url"] = new
            bi["datasheet_url_source"] = "mpn_rule_override"
            return {"action": "overridden", "from": cur, "to": new,
                    "source": "mpn_rule_override"}
        # 上游已经写过（解析时命中 manifest，或沿用的旧产物）。只补来源标签，
        # 不动值 —— 老产物没有这个标签，缺了会让「链接是哪来的」查不出来。
        bi.setdefault("datasheet_url_source", "prefilled")
        return {"action": "kept", "url": cur}
    url, src = resolve(doc, pdf_name, url_map, pdf_text)
    if not url:
        return {"action": "unresolved"}
    bi["datasheet_url"] = url
    bi["datasheet_url_source"] = src
    return {"action": "filled", "url": url, "source": src}


# ---------------------------------------------------------------- 文档类型
#: TI 站点把文档类型编在路径里：`/lit/ds/` = datasheet，`/lit/ug/` = user's guide，
#: `/lit/an/` = application note，`/lit/wp/` = white paper。
#: **这不是猜**：同一份 PDF 在 `lit/ug/` 下就是用户指南，页面再称它 datasheet 是错的。
_URL_DOC_TYPE = (
    ("/lit/ds/", "datasheet"),
    ("/lit/ug/", "user_guide"),
    ("/lit/an/", "application_note"),
    ("/lit/wp/", "white_paper"),
    ("/lit/ml/", "manual"),
    ("/lit/ab/", "abstract"),
)

#: 文档号前缀兜底（URL 不是 ti.com 时用，例如 z2data 镜像）。
#: `SBAS/SLAS/SBOS` 是模拟/线性器件 datasheet，`SLAU/SBAU/SPRU/SLVU` 是用户指南，
#: `SBAA/SLVA/SPRA` 是应用报告。
_DOCNUM_DOC_TYPE = (
    ("sbas", "datasheet"), ("slas", "datasheet"), ("sbos", "datasheet"),
    ("sbaa", "application_note"), ("slva", "application_note"), ("spra", "application_note"),
    ("slau", "user_guide"), ("sbau", "user_guide"), ("spru", "user_guide"),
    ("slvu", "user_guide"),
)

DOC_TYPES = ("datasheet", "user_guide", "application_note", "white_paper", "manual")


def doc_type(url: str, pdf_name: str = "") -> str:
    """判文档类型，返回 `datasheet` / `user_guide` / … ；判不出返回 `""`。

    先看 URL 路径（最可靠：那是原厂自己分的类），再看 PDF 文件名里的文档号前缀。
    都判不出就返回空串 —— 页面用中性表述，不硬说成 datasheet。
    """
    u = (url or "").lower()
    for frag, kind in _URL_DOC_TYPE:
        if frag in u:
            return kind
    name = Path(str(pdf_name or "")).name.lower()
    m = re.match(r"^([a-z]{4})", name)
    if m:
        for pre, kind in _DOCNUM_DOC_TYPE:
            if m.group(1) == pre:
                return kind
    # URL 形如 `.../slvu967a/slvu967a.pdf` 时也能从路径段判出来
    m2 = re.search(r"/([a-z]{4})\d{3}[a-z]?/", u)
    if m2:
        for pre, kind in _DOCNUM_DOC_TYPE:
            if m2.group(1) == pre:
                return kind
    return ""


def fill_doc_type(doc: dict, pdf_name: str = "") -> dict:
    """把文档类型写进 `basic_info.doc_type`（幂等）。"""
    bi = doc.setdefault("basic_info", {})
    url = str(bi.get("datasheet_url") or bi.get("device_datasheet_url") or "")
    kind = doc_type(url, pdf_name)
    if not kind:
        return {}
    if bi.get("doc_type") == kind:
        return {"changed": False, "doc_type": kind}
    old = bi.get("doc_type")
    bi["doc_type"] = kind
    return {"changed": True, "from": old, "to": kind}
