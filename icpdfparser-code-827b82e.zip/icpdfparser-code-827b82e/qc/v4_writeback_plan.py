"""首批写回：清单生成 / 备份 / 写回 / 写回后校验。

为什么写回默认关闭
------------------
当前授权边界只到「准备清单、备份与校验」。写回生产必须显式给
`--do-write --i-understand`，两个开关缺一即不执行，避免误触。

路径结论（容器内实测，不是推断）
--------------------------------
`app/config.py:resolve_artifact` 会把库里的路径回退成「对应目录 + 文件名」，
Windows 路径 `E:\\...\\LM358_8277dff7.json` 实测能解析到
`/app/data/parsed/LM358_8277dff7.json`。服务读取链路（API 预览/下载、QC、打包）
全部走这个函数，所以**只写文件、不改数据库引用**是可行的——前提是
**文件名保持不变**。
例外：`app/cli.py:_rerender`（API `qc_rerender` 也调它）直接用
`Path(存储值).exists()`，Windows 路径 6/6 解析失败。需要重渲染详情页时必须先处理它。

准入条件
--------
1. `item.json_path` 是容器路径，或目标路径可由 MPN+DB 记录唯一确定
2. 源 PDF 身份与 `metadata.pdf_hash` 已核对一致
3. 电气签名无未解释退化、替代型号无未解释减少（门禁 PASS）
4. `multi_language` 与历史字段已通过合并校验
5. 目标文件名不与其他 MPN 冲突，且等于现有文件名（覆盖同名，不新增）

用法（容器内）
--------------
    python qc/v4_writeback_plan.py --out-dir /tmp/v4_batch1            # 只出清单
    python qc/v4_writeback_plan.py --do-backup                         # 备份原文件
    python qc/v4_writeback_plan.py --do-write --i-understand           # 写回（未授权勿用）
    python qc/v4_writeback_plan.py --do-verify                         # 写回后校验
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

BATCH_N = 10


def _sha(p: Path) -> str:
    if not p.exists():
        return ""
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _load(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _name(p: str) -> str:
    return Path(p.replace("\\", "/")).name if p else ""


def build_plan(a) -> list:
    """按准入条件筛选并排序，返回首批清单。"""
    safe = {}
    p = Path(a.safe_subset)
    if p.exists():
        for r in csv.DictReader(p.open(encoding="utf-8-sig")):
            safe[r["mpn"]] = r
    mrg = {}
    p = Path(a.merge_report)
    if p.exists():
        for r in csv.DictReader(p.open(encoding="utf-8-sig")):
            mrg[r["mpn"]] = r
    ident = {}
    p = Path(a.identity_csv)
    if p.exists():
        for r in csv.DictReader(p.open(encoding="utf-8-sig")):
            ident[r["mpn"]] = r

    db = sqlite3.connect("file:%s?mode=ro" % (Path(a.data_root) / "workbench.sqlite3"),
                         uri=True)
    hit = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='item'").fetchone()
    out = []
    for mpn, s in safe.items():
        m = mrg.get(mpn) or {}
        idr = ident.get(mpn) or {}
        kind = idr.get("json_path_kind") or m.get("db_json_kind") or ""
        tgt = m.get("target_name") or ""
        cur = idr.get("json_name") or m.get("old_name") or ""

        why = []
        if m.get("candidate") != "是":
            why.append("非合并候选")
        if m.get("hash_consistent") != "是":
            why.append("哈希未核对一致")
        if not tgt or not cur:
            why.append("目标路径无法确定")
        elif tgt != cur:
            why.append("目标名与现有文件名不同（会新增而非覆盖）")
        if m.get("target_dup") == "是":
            why.append("目标名冲突")
        # 目标名是否被别的 MPN 引用：MPN 里的 / 会被替换成 _，理论上可能撞名
        others = []
        if tgt:
            for m2, jp in db.execute(
                    "SELECT mpn, json_path FROM item WHERE json_path<>''").fetchall():
                if m2 != mpn and _name(jp) == tgt:
                    others.append(m2)
        if others:
            why.append("目标名被其他 MPN 引用(%s)" % ",".join(others[:2]))
        if m.get("ml_kept") not in ("是", "-"):
            why.append("多语言未保留")
        if m.get("merge_blocked") not in ("", "-"):
            why.append("合并冲突")
        if why:
            continue

        try:
            gain = int(s.get("elec_delta") or 0) + int(s.get("order_delta") or 0)
        except ValueError:
            gain = 0
        out.append({
            "mpn": mpn,
            "json_path_kind": kind,
            "容器路径优先": "是" if kind == "容器绝对路径" else "否",
            "target_name": tgt,
            "cur_basename": cur,
            "target_abs": str(Path(a.data_root) / "parsed" / tgt),
            "cur_sha256": "", "merged_sha256": m.get("merged_sha256", ""),
            "elec_delta": s.get("elec_delta", ""), "order_delta": s.get("order_delta", ""),
            "gate": s.get("gate", ""), "ml_kept": m.get("ml_kept", ""),
            "其他MPN引用同名的": ",".join(others[:3]),
            "gain": gain,
        })
    # 容器路径优先，其次按改善量降序，保证首批覆盖最稳的一批
    out.sort(key=lambda r: (r["容器路径优先"] != "是", -r["gain"], r["mpn"]))
    return out[:BATCH_N]


def do_backup(a, plan: list) -> int:
    """把生产现有 JSON 复制到备份目录。只新增备份文件，不改任何现有文件。

    六条硬约束（缺一即整批判定失败）
    --------------------------------
    1. 范围锁定：数量不等于 BATCH_N 直接终止
    2. 只新增：备份目录里已有同名文件就停止，绝不静默覆盖
    3. 证据完整：源路径、源 SHA-256、字节数、备份路径、备份 SHA-256 全部记录
    4. 完整性：源与备份 SHA-256 必须一致，任何一件失败整批不算成功
    5. 无写回：备份前后生产文件 SHA-256 必须一致
    6. 不碰数据库、不触发重渲染、不删任何文件
    """
    if len(plan) != BATCH_N:
        print("  [!] 范围异常：清单 %d 件，应为 %d 件，终止" % (len(plan), BATCH_N))
        return 2

    bdir = Path(a.backup_dir)
    bdir.mkdir(parents=True, exist_ok=True)
    parsed = Path(a.data_root) / "parsed"

    # 备份前：先记录生产文件指纹，用于事后证明「没动过生产」
    before = {}
    for r in plan:
        src = parsed / r["target_name"]
        before[r["mpn"]] = (_sha(src), src.stat().st_size if src.exists() else 0)

    rows, failed = [], []
    for r in plan:
        mpn = r["mpn"]
        src = parsed / r["target_name"]
        dst = bdir / r["target_name"]
        if not src.exists():
            failed.append((mpn, "生产文件不存在: %s" % src))
            continue
        if dst.exists() and not a.overwrite_backup:
            failed.append((mpn, "备份目录已有同名文件: %s" % dst))
            continue
        src_sha = before[mpn][0] or _sha(src)
        size = src.stat().st_size
        shutil.copy2(src, dst)
        bak_sha = _sha(dst)
        ok = bool(bak_sha) and bak_sha == src_sha and dst.stat().st_size == size
        rows.append({
            "mpn": mpn,
            "src": str(src), "src_sha256": src_sha, "size": size,
            "backup": str(dst), "backup_sha256": bak_sha,
            "sha_match": "是" if ok else "否",
        })
        print("  %-22s %s… %d B -> %s  %s"
              % (mpn, src_sha[:16], size, dst.name,
                 "一致" if ok else "不一致！"))
        if not ok:
            failed.append((mpn, "备份后 SHA-256 与源文件不一致"))

    # 备份后：再算一次生产指纹，确认没被备份动作改动
    after_fail = []
    for r in plan:
        src = parsed / r["target_name"]
        now = (_sha(src), src.stat().st_size if src.exists() else 0)
        if now != before[r["mpn"]]:
            after_fail.append(r["mpn"])

    p_dir = Path(a.out_dir)
    p_dir.mkdir(parents=True, exist_ok=True)
    if rows:
        p = p_dir / "v4_batch1_backup.csv"
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("  写 %s（%d 行）" % (p, len(rows)))

    print("\n  备份成功 %d / %d 件" % (sum(1 for r in rows if r["sha_match"] == "是"),
                                   len(plan)))
    if after_fail:
        print("  [!] 生产文件在备份前后指纹变化：%s" % ",".join(after_fail))
    else:
        print("  生产文件备份前后 SHA-256 全部一致（未发生写回）")
    if failed:
        print("  [!] 失败明细：")
        for mpn, why in failed:
            print("      %-22s %s" % (mpn, why))
        return 1
    if after_fail:
        return 1
    print("  整批备份判定：成功")
    return 0


def do_verify(a, plan: list) -> int:
    """写回后校验：结构、历史字段、多语言、电气订货、哈希、路径解析。只读。"""
    sys.path.insert(0, str(Path(a.data_root).parent))
    try:
        from app import config
        has_cfg = True
    except Exception:                                        # noqa: BLE001
        has_cfg = False
    parsed = Path(a.data_root) / "parsed"
    bdir = Path(a.backup_dir)
    merged = Path(a.merged_dir)
    db = sqlite3.connect("file:%s?mode=ro" % (Path(a.data_root) / "workbench.sqlite3"),
                         uri=True)
    rows = []
    for r in plan:
        tgt = parsed / r["target_name"]
        old = bdir / r["target_name"]
        mg = merged / ("%s.merged.json" % r["mpn"])
        d = db.execute("SELECT json_path FROM item WHERE mpn=?", (r["mpn"],)).fetchone()
        db_json = d[0] if d else ""
        cur, od, md = _load(tgt), _load(old), _load(mg)

        mpn = r["mpn"]
        checks = {
            "文件存在": tgt.exists(),
            "JSON 可解析": bool(cur),
            "多语言保留": (not od.get("multi_language"))
                          or cur.get("multi_language") == od.get("multi_language"),
            "与合并产物一致": bool(md) and cur == md,
            "metadata取新值": (cur.get("metadata") or {}).get("pdf_hash")
                              == (md.get("metadata") or {}).get("pdf_hash"),
            "电气未丢失": len((cur.get("specs") or {}).get("electrical") or [])
                          >= len((od.get("specs") or {}).get("electrical") or []),
            "订货未丢失": len(cur.get("ordering_info") or [])
                          >= len(od.get("ordering_info") or []),
            "DB引用可解析": bool(db_json) and (
                (Path(db_json).exists() if not db_json.startswith("\\\\") else False)
                or (has_cfg and config.resolve_artifact(
                    db_json, config.PARSED).exists())),
        }
        rows.append({
            "mpn": mpn,
            "verdict": "PASS" if all(checks.values()) else "FAIL",
            **{k: ("是" if v else "否") for k, v in checks.items()},
            "target": str(tgt),
            "old_sha256": _sha(old)[:16], "new_sha256": _sha(tgt)[:16],
            "db_json_path": db_json[:70],
            "resolved_to": str(config.resolve_artifact(db_json, config.PARSED))
                           if has_cfg and db_json else "",
        })
    p = Path(a.out_dir) / "v4_batch1_verify.csv"
    Path(a.out_dir).mkdir(parents=True, exist_ok=True)
    if rows:
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    n = sum(1 for r in rows if r["verdict"] == "PASS")
    print("写回后校验 %d / %d 件通过" % (n, len(rows)))
    for r in rows:
        if r["verdict"] != "PASS":
            bad = [k for k in r if r[k] == "否"]
            print("   FAIL %s：%s" % (r["mpn"], ",".join(bad)))
    print("  写 %s" % p)
    return 0 if n == len(rows) else 1


def _recent_writes(parsed: Path, minutes: int) -> list:
    """最近 N 分钟内被写过的 parsed JSON——判断有没有别的写入者在同一目录干活。"""
    import time
    cut = time.time() - minutes * 60
    out = []
    for p in parsed.glob("*.json"):
        try:
            if p.stat().st_mtime > cut:
                out.append(p.name)
        except OSError:
            continue
    return out


def _queue_len(url: str):
    """celery 待处理队列长度；查不到返回 None（只提示，不据此阻断）。"""
    try:
        import redis                                         # noqa: PLC0415
        return redis.Redis.from_url(url, socket_timeout=3).llen("celery")
    except Exception:                                        # noqa: BLE001
        return None


def do_precheck(a, plan: list) -> int:
    """写回前最终预检：范围、哈希、备份、合并产物、多语言、并发写入风险。只读。"""
    if len(plan) != BATCH_N:
        print("  [!] 范围异常：%d 件，应为 %d 件" % (len(plan), BATCH_N))
        return 2
    parsed = Path(a.data_root) / "parsed"
    bdir = Path(a.backup_dir)
    merged = Path(a.merged_dir)
    baks = {}
    p = Path(a.out_dir) / "v4_batch1_backup.csv"
    if p.exists():
        for r in csv.DictReader(p.open(encoding="utf-8-sig")):
            baks[r["mpn"]] = r

    rows, bad = [], 0
    for r in plan:
        mpn, tgt_name = r["mpn"], r["target_name"]
        src, bak = parsed / tgt_name, bdir / tgt_name
        mg = merged / ("%s.merged.json" % mpn)
        b = baks.get(mpn) or {}
        cur_sha, bak_sha = _sha(src), _sha(bak)
        mgd = _load(mg)
        cur = _load(src)
        c = {
            "生产文件存在": src.exists(),
            "备份存在": bak.exists(),
            "生产哈希==备份清单源哈希": bool(b) and cur_sha == (b.get("src_sha256") or ""),
            "备份哈希==备份清单备份哈希": bool(b) and bak_sha == (b.get("backup_sha256") or ""),
            "合并产物存在": mg.exists(),
            "合并产物含多语言": bool(mgd.get("multi_language")),
            "合并多语言==现网多语言": mgd.get("multi_language") == cur.get("multi_language"),
        }
        ok = all(c.values())
        if not ok:
            bad += 1
        rows.append({"mpn": mpn, "target": tgt_name,
                     "verdict": "PASS" if ok else "FAIL",
                     **{k: ("是" if v else "否") for k, v in c.items()},
                     "cur_sha256": cur_sha[:16], "bak_sha256": bak_sha[:16]})

    p = Path(a.out_dir) / "v4_batch1_precheck.csv"
    Path(a.out_dir).mkdir(parents=True, exist_ok=True)
    if rows:
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    recent = _recent_writes(parsed, a.quiet_minutes)
    qlen = _queue_len(a.redis_url)
    print("\n=== 并发写入风险 ===")
    print("  最近 %d 分钟内 parsed 被写过的文件数：%d" % (a.quiet_minutes, len(recent)))
    if recent:
        print("      %s" % ",".join(recent[:6]))
    print("  celery 待处理队列长度：%s" % (qlen if qlen is not None else "未取到"))
    print("  注：worker 运行在 icpdf-fetch / icpdf-render / icpdf-llm 三个容器，")
    print("      与 server 共享同一个 data 目录，不能只看本容器进程。")

    n = sum(1 for r in rows if r["verdict"] == "PASS")
    print("\n预检通过 %d / %d 件" % (n, len(rows)))
    for r in rows:
        if r["verdict"] != "FAIL":
            continue
        print("   FAIL %s：%s" % (r["mpn"],
                                 ",".join(k for k in r if r[k] == "否")))
    print("  写 %s" % p)
    if recent or (qlen or 0) > 0:
        print("  [!] 存在活跃写入或排队任务，建议改在静默窗口执行")
        return 1
    return 0 if n == len(rows) else 1


def do_write(a, plan: list) -> int:
    """写回生产 parsed。必须显式 --do-write --i-understand。"""
    if not a.i_understand:
        print("拒绝执行：写回生产需要同时给 --do-write --i-understand")
        return 2
    parsed = Path(a.data_root) / "parsed"
    bdir = Path(a.backup_dir)
    merged = Path(a.merged_dir)

    # 写前再看一眼有没有别的写入者。API 触发的解析随时可能发生，
    # 「进程列表里没有 worker」不等于没有并发写——worker 在其它容器。
    recent = _recent_writes(parsed, a.quiet_minutes)
    if recent and not a.force_write:
        print("  [!] 最近 %d 分钟内 parsed 有 %d 个文件被写过，拒绝写回"
              % (a.quiet_minutes, len(recent)))
        print("      %s" % ",".join(recent[:6]))
        print("      确认安全可加 --force-write")
        return 2

    done, failed = [], []
    for r in plan:
        mpn, tgt_name = r["mpn"], r["target_name"]
        src = merged / ("%s.merged.json" % mpn)
        dst = parsed / tgt_name
        bak = bdir / tgt_name
        if not src.exists() or not dst.exists() or not bak.exists():
            failed.append((mpn, "合并产物/目标/备份三者缺一"))
            break
        want = _sha(src)
        shutil.copy2(src, dst)
        # 逐件立即校验：写进去的不是我算的那个文件就立刻回滚
        if _sha(dst) != want:
            shutil.copy2(bak, dst)
            failed.append((mpn, "写回后哈希不符，已回滚"))
            break
        done.append(mpn)
        print("  写回 %-22s -> %s  %s…" % (mpn, dst.name, want[:16]))

    if failed:
        print("\n  [!] 写回中断，已回滚的件：%s" % ",".join(m for m, _ in failed))
        for mpn, why in failed:
            print("      %-22s %s" % (mpn, why))
        # 已成功的件一并还原，保持现场一致
        for mpn in done:
            r = next(x for x in plan if x["mpn"] == mpn)
            shutil.copy2(bdir / r["target_name"], parsed / r["target_name"])
        print("  已还原本次写回的 %d 件，现场回到写回前" % len(done))
        return 1
    print("\n写回 %d / %d 件" % (len(done), len(plan)))
    return 0 if len(done) == BATCH_N else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="首批写回：清单 / 备份 / 写回 / 校验")
    ap.add_argument("--data-root", default=str(ROOT / "data"), dest="data_root")
    ap.add_argument("--safe-subset", default="/tmp/v4_writeback2/v4_final_safe_subset.csv")
    ap.add_argument("--merge-report", default="/tmp/v4_writeback2/v4_merge_report_228.csv")
    ap.add_argument("--identity-csv", default="/tmp/v4_ident2/v4_identity_audit.csv")
    ap.add_argument("--merged-dir", default="/tmp/v4_writeback2/merged")
    ap.add_argument("--backup-dir", default=str(ROOT / "data" / "parsed_backup_batch1"))
    ap.add_argument("--out-dir", default="/tmp/v4_batch1")
    ap.add_argument("--plan-csv", default="",
                    help="已审阅的批次清单 CSV；给定时不再重新筛选，避免范围漂移")
    ap.add_argument("--overwrite-backup", action="store_true",
                    help="允许覆盖备份目录里的同名文件（默认禁止，遇到即停）")
    ap.add_argument("--do-backup", action="store_true")
    ap.add_argument("--do-precheck", action="store_true", help="写回前最终预检（只读）")
    ap.add_argument("--do-write", action="store_true")
    ap.add_argument("--do-verify", action="store_true")
    ap.add_argument("--i-understand", action="store_true")
    ap.add_argument("--force-write", action="store_true",
                    help="忽略「近期有写入」的静默检查（默认拒绝）")
    ap.add_argument("--quiet-minutes", type=int, default=30,
                    help="静默判定窗口：最近 N 分钟 parsed 无写入才算安全")
    ap.add_argument("--redis-url", default="redis://redis:6379/0")
    a = ap.parse_args(argv)

    Path(a.out_dir).mkdir(parents=True, exist_ok=True)
    if a.plan_csv:
        pp = Path(a.plan_csv)
        if not pp.exists():
            print("指定的批次清单不存在：%s" % pp)
            return 2
        plan = list(csv.DictReader(pp.open(encoding="utf-8-sig")))
        print("使用已审阅清单 %s（%d 件），不再重新筛选" % (pp, len(plan)))
    else:
        plan = build_plan(a)
    print("批次范围 %d 件" % len(plan))
    for r in plan:
        print("   %-22s %-12s 目标=%s 电气%+d 订货%+d"
              % (r["mpn"], r.get("json_path_kind", "-"), r["target_name"][:36],
                 int(r["elec_delta"] or 0), int(r["order_delta"] or 0)))
    # 范围锁定：写类动作只在恰好 BATCH_N 件时放行
    if (a.do_backup or a.do_write) and len(plan) != BATCH_N:
        print("\n[!] 范围不是 %d 件，拒绝执行备份/写回" % BATCH_N)
        return 2
    if not a.plan_csv and plan:
        p = Path(a.out_dir) / "v4_batch1_plan.csv"
        with p.open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=list(plan[0].keys()))
            w.writeheader()
            w.writerows(plan)
        print("  写 %s" % p)

    rc = 0
    if a.do_backup:
        print("\n=== 备份 ===")
        rc |= do_backup(a, plan)
    if a.do_precheck:
        print("\n=== 写回前预检 ===")
        rc |= do_precheck(a, plan)
    if a.do_write:
        print("\n=== 写回 ===")
        rc |= do_write(a, plan)
    if a.do_verify:
        print("\n=== 写回后校验 ===")
        rc |= do_verify(a, plan)
    if not (a.do_backup or a.do_write or a.do_verify or a.do_precheck):
        print("\n只生成/展示清单，未执行备份 / 预检 / 写回 / 校验。")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
