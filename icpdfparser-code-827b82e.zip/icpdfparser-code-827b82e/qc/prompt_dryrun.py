#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prompt v1 / v2 对照 dry-run（② 的上线门禁）。

为什么要有这个：v2 的 3b 规则会**改写 value 的形态**（三列塌缩），
一旦改错就是把已经抽对的参数改坏——尤其下限约束（VIH / 开环增益 / 带宽）
只有 MIN 列有值，按「一律取 MAX」会变空。所以上线前必须抽样对照，
不接受「有明确根因」就直接批量改。

门禁（三条全过才准上）：
  1. 修复率     = (v1 空值行 − v2 空值行) / v1 空值行 ≥ 80%
  2. 占位符误判 = v2 标成 not_specified、但 PDF 该行确实有数值的行 ≤ 1/10
  3. 下限参数   = v1 已有数值的下限约束行（VIH/VIL/Av/BW/CMRR/PSRR/SR），
                 v2 不得变空、不得改坏

只写 data/qc/prompt_dryrun/{version}/，不碰生产 facts / DB / 渲染。

用法：
  ICPDF_PROMPT_VERSION=v1 python qc/prompt_dryrun.py
  ICPDF_PROMPT_VERSION=v2 python qc/prompt_dryrun.py
  python qc/prompt_dryrun.py --compare          # 出对照表 + 门禁结论
  ICPDF_PROMPT_VERSION=v2 python qc/prompt_dryrun.py --dry-sweep 0.2   # 抽样限速（省钱）
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config                                       # noqa: E402  （顺带加载 .env.local）
import parse_datasheets as PD                                # noqa: E402

# 行级分类复用 qc/electrical_classify（可测量特征优先，不用关键词）。
# 导入失败时置 _CLS_OK=False，G3 只做行内判据，不指控编数——保持单一取证源。
try:
    from qc.electrical_classify import classify_electrical_row
    from qc.sentinels import is_blank, is_not_specified
    _CLS_OK = True
except Exception:                                            # noqa: BLE001
    def classify_electrical_row(row):
        return ""

    def is_blank(v):
        return str(v or "").strip().lower() in {"", "-", "—", "–", "−",
                                                "n/a", "na", "tbd",
                                                "not_specified"}

    def is_not_specified(v):
        return str(v or "").strip().lower() == "not_specified"
    _CLS_OK = False

OUT = ROOT / "data" / "qc" / "prompt_dryrun"

# 10 件样本：G1 里本地有 PDF 的 5 件 + 含下限约束（VIH/VIL/增益/带宽）的反例 4 件 + 对照 1 件
SAMPLES = [
    "AFE4490RHAT",        # G1，坏行 13/22
    "DAC37J84IAAV",       # G1，坏行 12/39
    "DP83TC814RRHARQ1",   # G1，坏行 4/14（含 prose 行）
    "BQ2201PNG4",         # G1，坏行 7/21
    "BQ4016YMC-70",       # G1，坏行 7/12；反例：VIH 2.2 / VIL 0.8
    "CY74FCT16646ATPVC",  # G1，坏行 5/20；反例：VIH 2.0 / VIL 0.8
    "DS90C365AMT",        # G1，坏行 10/30
    "DP8421AVX-20",       # G1，坏行 5/15
    "74FCT162841CTPACT",  # G1，坏行 6/23；反例：VIH/VIL
    "AM5746ABZXEA",       # G1，坏行 3/3（几乎全空，边界例）
]

# 下限约束：只有 MIN 列有值，按「一律取 MAX」会被改坏
LOWER_BOUND = re.compile(
    r"\b(VIH|VIL|AV|AVOL|AVOLT|GAIN|BW|GBW|CMRR|PSRR|SR|VOH|VTH|VIT|VUVLO)\b", re.I)
NUM = re.compile(r"[-+]?\d")


def _find_pdf(mpn: str):
    base = mpn.replace("/", "_")
    hits = [p for p in (ROOT / "data" / "pdfs").glob(base + "*")
            if p.suffix.lower() == ".pdf"]
    return hits[0] if hits else None


def run_one(mpn: str, version: str) -> dict:
    rec = {"mpn": mpn, "version": version, "status": "failed", "error": "",
           "rows": 0, "empty_value": 0, "not_specified": 0, "roles_marker": 0,
           "lower_bound_rows": 0, "lower_bound_empty": 0, "secs": 0.0,
           "out": "", "not_specified_rows": []}
    pdf = _find_pdf(mpn)
    if not pdf:
        rec["error"] = "PDF_NOT_FOUND"
        return rec
    t0 = time.time()
    try:
        text, total, used, has_text = PD.extract_pdf_text(pdf)
        if not has_text:
            rec["error"] = "PDF_UNREADABLE"
            return rec
        messages = [
            {"role": "system", "content": PD.SYSTEM_PROMPT},
            {"role": "user", "content": PD.USER_TMPL.format(
                mpn=mpn, fname=pdf.name, pages_used=used, pages_total=total, text=text)},
        ]
        content, usage = PD.chat(messages)
        doc = PD.parse_json_loose(content)
    except Exception as e:                                   # noqa: BLE001
        rec["error"] = f"{type(e).__name__}: {e}"[:200]
        return rec

    el = (doc.get("specs") or {}).get("electrical") or []
    for e in el:
        if not isinstance(e, dict):
            continue
        v = str(e.get("value") or "").strip()
        rec["rows"] += 1
        if not v:
            rec["empty_value"] += 1
        elif v.lower() == "not_specified":
            rec["not_specified"] += 1
            rec["not_specified_rows"].append(
                {"name": str(e.get("name"))[:40], "condition": str(e.get("condition"))[:60]})
        if re.search(r"\b(min|typ|max)\s*=", str(e.get("condition") or ""), re.I) \
                or NUM.search(v):
            rec["roles_marker"] += 1
        if LOWER_BOUND.search(str(e.get("symbol") or e.get("name") or "")):
            rec["lower_bound_rows"] += 1
            if not v or v.lower() == "not_specified":
                rec["lower_bound_empty"] += 1

    d = OUT / version
    d.mkdir(parents=True, exist_ok=True)
    out = d / f"{mpn.replace('/', '_')}.json"
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    rec.update(status="ok", out=str(out.relative_to(ROOT)), secs=round(time.time() - t0, 1),
               usage=usage)
    return rec


def _load(version: str) -> dict:
    d = OUT / version
    if not d.is_dir():
        return {}
    return {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in d.glob("*.json")}


_CTX_CACHE: dict[str, str] = {}


def _ctx_text(mpn: str) -> str:
    """取「真正送进模型的上下文」，不是 PDF 全文。

    这是本轮最关键的修正。上一版判据拿 PDF 全文取证，但模型只看到
    `select_pages()` 挑出来的几页——AFE4490RHAT 有 98 页、只送 9 页，
    第 14 页的 POWER DISSIPATION 表（2.84 mW）压根没进上下文。
    用全文取证会把「模型根本看不到」判成「模型漏抽」，系统性制造假阳性，
    而且方向是惩罚诚实（not_specified）、奖励幻觉（编数）。
    """
    if mpn in _CTX_CACHE:
        return _CTX_CACHE[mpn]
    text = ""
    pdf = _find_pdf(mpn)
    if pdf:
        try:
            _total, gen = PD._iter_pages(pdf)
            text, _used, _truncated = PD.select_pages(gen, PD.MAX_PAGES, PD.MAX_CHARS)
        except Exception:                                    # noqa: BLE001
            text = ""
    _CTX_CACHE[mpn] = text
    return text


def _ctx_lookup(mpn: str, name: str, window: int = 160) -> tuple[bool, bool]:
    """在上下文里查该参数名，返回 `(名字是否出现, 其后 window 内是否有数值)`。

    名字按 token 之间允许任意分隔（表格里常写成 `Power Dissipation` /
    `POWER-DISSIPATION`），不能用简单子串匹配。
    """
    return _lookup_in_text(_ctx_text(mpn), name, window)


def _lookup_in_text(text: str, name: str, window: int = 160) -> tuple[bool, bool]:
    """在给定文本里查参数名（与 `_ctx_lookup` 同口径，但文本由调用方给）。

    拆出来是为了让迁移统计能对**已落盘的上下文文本**取证，而不必重新
    按 mpn 走一遍 PDF 解析（零 token 且可缓存）。
    """
    if not text:
        return True, True                                    # 取不到上下文 → 不判坏，避免误伤
    toks = [t for t in re.split(r"[^A-Za-z0-9]+", (name or "")) if t]
    if not toks:
        return True, True
    pat = re.compile(r"\W*".join(re.escape(t) for t in toks[:4]), re.I)
    found = False
    for m in pat.finditer(text):
        seg = text[m.end(): m.end() + window]
        # 修订记录 / 目录点线里的参数名不算「表中有值」：
        # 那类文本形如 "Changed Power Dissipation ...... 14"，数字是页码不是数值
        if "..." in seg or re.search(r"\b(Changed|Added|Updated|Deleted)\b", seg):
            found = True                                     # 名字算出现过，但不作数值证据
            continue
        if NUM.search(seg):
            return True, True
        found = True
    return found, False


# ── 行分类：只对 BAD_* 计坏行 ──────────────────────────────────────────────
# 关键区分：`not_specified` 是「已知无值」的明确语义，≠ 空字符串 ≠ 坏行。
# 原表三列全占位符时标 not_specified 是净改善（下游应停止重试、渲染成 -），
# 不该和「有值没抽到」「凭空编数」混在一个计数里。
GOOD_VALUE = "GOOD_VALUE"                          # 上下文有值，抽到了
GOOD_NOT_SPECIFIED = "GOOD_NOT_SPECIFIED"          # 上下文确无值，明确标了 not_specified
GOOD_VALUE_IN_COND = "GOOD_VALUE_IN_COND"  # 值不在表内但数字在 condition 有出处
BAD_MISSING_VALUE = "BAD_MISSING_VALUE"            # 上下文有值，却留空/not_specified
BAD_MISSING_NOT_SPEC = "BAD_MISSING_NOT_SPEC"      # 上下文无值，却只留空（该标没标）
BAD_FABRICATED_VALUE = "BAD_FABRICATED_VALUE"      # 上下文无值，却给了数（编数，最严重）
BAD_ECHO_NAME = "BAD_ECHO_NAME"    # value 回灌了 name（DAC37J84 实证：
                                                   #   Features 条目被误当电气行，值就是标题本身）
VALUE_PROVIDED_BUT_NO_EXACT_MATCH = "VALUE_PROVIDED_BUT_NO_EXACT_MATCH"  # 给了值但对不上三列
UNKNOWN_ORIG = "UNKNOWN_ORIG"                      # 无法取证（上下文为空）
BAD_CLASSES = (BAD_MISSING_VALUE, BAD_MISSING_NOT_SPEC, BAD_FABRICATED_VALUE,
               BAD_ECHO_NAME)

# 表格里的占位符写法（含各种破折号）
PLACEHOLDERS = {"", "-", "—", "–", "−", "n/a", "na", "tbd", "not_specified"}


def _norm_text(s) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def _value_has_source(mpn: str, value, condition) -> bool:
    """value 里的数字能否在「上下文 + condition」里找到出处。

    加这条是因为 AFE4490RHAT 的 `Ambient Cancellation Stage, Gain` 被初版判据
    打成 BAD_FABRICATED_VALUE，人工核对发现判错了：它的 condition 明写
    "Programmable to 0 dB, 3.5 dB, 6 dB, 9.5 dB, and 12 dB"，`0 dB~12 dB`
    是从这串档位里取的首尾——**数字有出处**，不是编造。
    """
    nums = re.findall(r"\d+(?:\.\d+)?", str(value or ""))
    if not nums:
        return True                                          # 非数值型 value，不按编数判
    hay = _ctx_text(mpn) + " " + str(condition or "")
    return all(n in hay for n in nums)


def classify(mpn: str, name: str, value, cells: list | None = None,
             condition: str = "") -> str:
    """给单行定类。

    `cells` 是人工整理的原表三列 `[min, typ, max]`——给了就用它判（最准）；
    没给就退回「送进模型的上下文」自动取证。
    """
    v = str(value or "").strip()

    # ---- 模式 A：人工三列 ----
    if cells is not None:
        if all(str(c or "").strip().lower() in PLACEHOLDERS for c in cells):
            if v.lower() == "not_specified":
                return GOOD_NOT_SPECIFIED
            if not v:
                return BAD_MISSING_NOT_SPEC
            return BAD_FABRICATED_VALUE
        if v == "<MISSING_ROW>" or not v or v.lower() == "not_specified":
            return BAD_MISSING_VALUE
        for c in cells:
            c = str(c or "").strip()
            if c and c.lower() not in PLACEHOLDERS and c in v:
                return GOOD_VALUE
        return VALUE_PROVIDED_BUT_NO_EXACT_MATCH

    # ---- 模式 B：上下文自动取证 ----
    if v == "<MISSING_ROW>":
        return BAD_MISSING_VALUE
    # value 回灌 name：DAC37J84 实证，Features 条目被误当电气行、值就是标题本身
    nv, nn = _norm_text(v), _norm_text(name)
    if nv and len(nv) >= 8 and (nv == nn or nv.startswith(nn) or nn.startswith(nv)):
        return BAD_ECHO_NAME
    named, has_num = _ctx_lookup(mpn, name)
    if not _ctx_text(mpn):
        return UNKNOWN_ORIG
    if has_num:
        if v and v.lower() != "not_specified":
            return GOOD_VALUE
        return BAD_MISSING_VALUE                              # 有值没抽到
    if not named:
        return GOOD_VALUE if v else BAD_MISSING_NOT_SPEC      # 上下文无名：无法举证
    # 上下文有名无值（三列全占位符的典型形态）
    if v.lower() == "not_specified":
        return GOOD_NOT_SPECIFIED
    if not v:
        return BAD_MISSING_NOT_SPEC
    if _value_has_source(mpn, v, condition):
        return GOOD_VALUE_IN_COND                      # 数字在 condition 里有出处
    return BAD_FABRICATED_VALUE                               # 无出处才算编数


def _el(doc: dict) -> list:
    """取电气行；缺 specs 或解析异常时给空列表，不炸。"""
    try:
        return (doc.get("specs") or {}).get("electrical") or []
    except Exception:                                        # noqa: BLE001
        return []


def _row_key(r: dict) -> str:
    """行匹配键。行名会被模型改写（加前缀/缩写），只靠 name 会对不上。"""
    return (str(r.get("name") or "").strip().lower()[:32]
            + "|" + str(r.get("condition") or "").strip().lower()[:40])


def _all_rows(doc: dict) -> list:
    """电气类全部行 = electrical + absolute_max。

    门禁原来只数 `electrical`，会把「重新分类」误判成「丢表」：AM5746ABZXEA
    的 v1 把 Absolute Maximum Ratings 重复塞进 electrical（13 行），v2 正确
    归位到 absolute_max（20 行）、electrical 归 0——按单数组看像塌缩，合并看
    是 28 → 20 的收敛，且 v2 分类更准。
    """
    sp = doc.get("specs") or {}
    return list(sp.get("electrical") or []) + list(sp.get("absolute_max") or [])


# ── G3 迁移统计（v2 判据）──────────────────────────────────────────────
#
# 旧判据「v2 not_specified < v1 编数行数」有两个毛病，已作废（见
# data/qc/gates/g3_v2.json）：
#   1) 口径不可比——v1 那 7 行是**编造值**（v1 的 not_specified=0），
#      v2 那 7 行才是 not_specified，等于拿 A 字段比 B 字段；
#   2) 分母会飘——上下文一变，行集本身就变（AFE4490 15→20），总数字不可比。
#
# 新判据改为**按行名匹配同一批行，统计状态迁移**，不再比总数。
# 行名匹配必须去 section 前缀，否则 AFE4490 会 0 命中（见 _norm_name 注释）。

_SECTION_PREFIX = re.compile(
    r'^(performance|power\s+dissipation|electrical\s+characteristics|'
    r'absolute\s+maximum|recommended\s+operating|timing\s+requirements)[,\s]+',
    re.I)


def _norm_name(name) -> str:
    """归一化行名（默认形态：不去前缀，保留全名）。

    真正的匹配走 `_name_keys()`——单一形态会漏配，见那里的说明。
    """
    return re.sub(r'[^a-z0-9]', '', str(name or '').lower())


def _name_keys(name) -> set[str]:
    """行名 → **候选键集合**，跨版本匹配时用交集判相等。

    **为什么不能用单一形态**：v2 行名常被模型带上章节前缀——
    v1 写 `Total integrated noise current`，v2 写成
    `Performance, Total integrated noise current, ...`；
    v1 写 `Power Dissipation`，v2 写成 `Power Dissipation, PD(q)`。

    只保留「不去前缀」→ 带前缀的行永远配不上；
    只保留「去前缀」→ `Power Dissipation, PD(q)` 被剥成 `PD(q)`，
    与不带符号的 v1 全名依然配不上（实测 0 命中，全退化成「消失」）。

    所以两种形态都算，再加上「逗号前段」去掉 `PD(q)` / `VO(shield)`
    这类缩写符号，三者的并集取交集即可命中。
    """
    raw = str(name or '').strip()
    keys: set[str] = set()
    for s in (raw, _SECTION_PREFIX.sub('', raw)):
        for cand in (s, s.split(',')[0]):
            k = re.sub(r'[^a-z0-9]', '', cand.lower())
            if k:
                keys.add(k)
    return keys


def _match_electrical(v1_rows: list, v2_rows: list) -> tuple[list, list]:
    """三级匹配：精确归一化 → 双向包含 → 未匹配（消失 / 新增）。

    返回 `(pairs, new_v2)`：`pairs` 为 `(v1 索引, v2 索引|None)`，
    `None` 表示 v1 有而 v2 无；`new_v2` 是未被占用的 v2 索引。
    一个 v1 行只占一个 v2 行，避免多行重复计入迁移。
    """
    v2_by_norm: dict[str, list] = {}
    for j, r in enumerate(v2_rows):
        for k in _name_keys(r.get('name', '')):
            v2_by_norm.setdefault(k, []).append(j)
    pairs, used_v2 = [], set()
    for i, r in enumerate(v1_rows):
        ks = _name_keys(r.get('name', ''))
        hit = None
        for k in ks:                                         # 1) 精确
            for j in v2_by_norm.get(k, []):
                if j not in used_v2:
                    hit = j
                    break
            if hit is not None:
                break
        if hit is None:                                      # 2) 双向包含
            for j, r2 in enumerate(v2_rows):
                if j in used_v2:
                    continue
                k2 = _norm_name(r2.get('name', ''))
                if k2 and any(k2 in k or k in k2 for k in ks):
                    hit = j
                    break
        if hit is not None:
            pairs.append((i, hit))
            used_v2.add(hit)
        else:
            pairs.append((i, None))
    new_v2 = [j for j in range(len(v2_rows)) if j not in used_v2]
    return pairs, new_v2


def _value_has_value(ctx_text: str, name: str, value: str) -> bool:
    """value 里的数字能否在上下文里**跟在参数名后面**找到出处。

    与 `_value_has_source` 同口径，但只搜上下文（不掺 condition）——迁移统计里
    要把 condition 的影响单独看，否则「数字来自 condition」会掩盖
    「数字来自上下文」这个正是我们想测的选页效果。

    **为什么必须带名字**：32k 字符的上下文里 "50" / "200" 这类数字几乎必然
    出现，只按数字比对待于恒真，取证就没有意义了。
    """
    if not ctx_text:
        return True
    nums = re.findall(r"\d+(?:\.\d+)?", str(value or ""))
    if not nums:
        return True                                          # 非数值型 value，不按编数判
    _named, has_num = _lookup_in_text(ctx_text, name)
    return has_num


def _ctx_snippet(text: str, name: str, window: int = 110) -> str:
    """取参数名在上下文里的原文片段，供人工裁决「值到底来自表格还是 Features」。

    **为什么必须留原文**：`_value_has_value` 只能回答「数字在不在上下文里」，
    回答不了「数字是不是来自电气表」。实测 AFE4490 的 4 行消失值都命中了
    上下文里的数字，但那些数字出自 **Features 段落**——把它们判成「真值丢失」
    等于把 4c 要清的垃圾当成资产保护起来，是典型的奖惩颠倒。
    所以取证输出必须带原文，由人确认。
    """
    if not text or not name:
        return ""
    toks = [t for t in re.split(r"[^A-Za-z0-9]+", name) if t]
    if not toks:
        return ""
    pat = re.compile(r"\W*".join(re.escape(t) for t in toks[:4]), re.I)
    m = pat.search(text)
    if not m:
        return ""
    a = max(0, m.start() - 30)
    return re.sub(r"\s+", " ", text[a: m.end() + window]).strip()


def _row_state(row: dict, ctx_text: str = "") -> str:
    """给单行定状态（G3 迁移的基本单位）。

    `ctx_text` 为空时走**无上下文模式**：只做行内分类（回灌 / 空值），
    不判编数——没有取证源就不能指控编数，否则又会制造奖惩颠倒。
    """
    v = str((row or {}).get('value') or '').strip()
    if is_not_specified(v):
        return GOOD_NOT_SPECIFIED
    if not v:
        return 'BLANK'
    # 回灌判定统一走 electrical_classify，不在这里另起一套口径
    cls = classify_electrical_row(row) if _CLS_OK else ''
    if cls in ('ECHO_NAME', 'FEATURE_DESCRIPTION'):
        return BAD_ECHO_NAME
    if not ctx_text:                                 # 无取证源 → 不指控编数
        return GOOD_VALUE
    nums = re.findall(r"\d+(?:\.\d+)?", v)
    if not nums:                                     # 非数值型 value，不按编数判
        return GOOD_VALUE
    return GOOD_VALUE if all(n in ctx_text for n in nums) else BAD_FABRICATED_VALUE


def _row_states(rows: list, ctx_text: str = "") -> list[str]:
    return [_row_state(r, ctx_text) for r in rows or []]


def g3_migration(v1_doc: dict, v2_doc: dict, ctx_v2: str = "") -> dict:
    """按行名匹配，统计 v1 → v2 的状态迁移。"""
    v1_rows = _el(v1_doc)
    v2_rows = _el(v2_doc)
    pairs, new_v2 = _match_electrical(v1_rows, v2_rows)
    stats = {'improved': [], 'regressed': [], 'unchanged': [],
             'disappeared': [], 'new': []}
    for i, j in pairs:
        s1 = _row_state(v1_rows[i], '')
        if j is None:
            stats['disappeared'].append(
                {'v1_name': v1_rows[i].get('name'), 'v1_state': s1,
                 'v1_value': v1_rows[i].get('value')})
            continue
        s2 = _row_state(v2_rows[j], ctx_v2)
        rec = {'v1_name': v1_rows[i].get('name'),
               'v2_name': v2_rows[j].get('name'),
               'v1_state': s1, 'v2_state': s2,
               'v1_value': v1_rows[i].get('value'),
               'v2_value': v2_rows[j].get('value')}
        # 两种改善都算：
        #   1) 编造值 → 好值/诚实占位（幻觉修正）
        #   2) 诚实占位 → 真值（选页改善，正是尾部保底要测的）
        if s1.startswith('BAD_') and s2.startswith('GOOD_'):
            stats['improved'].append({**rec, 'kind': 'hallucination_fixed'})
        elif s1 == GOOD_NOT_SPECIFIED and s2 == GOOD_VALUE:
            stats['improved'].append({**rec, 'kind': 'notspec_to_value'})
        elif s1 == GOOD_VALUE and s2.startswith('BAD_'):
            stats['regressed'].append(rec)
        else:
            stats['unchanged'].append(rec)
    for j in new_v2:
        stats['new'].append({'v2_name': v2_rows[j].get('name'),
                             'v2_value': v2_rows[j].get('value'),
                             'v2_state': _row_state(v2_rows[j], ctx_v2)})
    return stats


def gate_g3(stats: dict, ctx_v2: str = "") -> dict:
    """G3 门禁：pass 只由 G3a（不许编数/回灌）+ G3c（不许真值退化）决定。

    G3b / G3d / G3e 均为 advisory（见返回的 `advisory` 字段）。

    G3b 只在「基线里确有 not_specified 行」时生效；基线无占位行（如 AM6421
    生产基线 3 行全空值）时该项不适用，改由 G3e 按「置换守恒」判定，
    不因缺基线而误报 FAIL。

    **G3d 已降级为 INFO**（不参与 pass）。原因：它无法被自动判定——
    基线的上下文比新上下文更窄，而 `_row_state` 在无上下文模式下只能按
    「有 unit + 有数值」放行，**识别不了编造**。实测 AFE4490 有 4 行
    消失值全部命中上下文数字，但核对原文发现它们出自 **Features 项目
    符号段落**，正是 4c 规则要清除的对象。若按「消失 GOOD_VALUE → FAIL」
    判，等于把要清的垃圾当资产保护起来——奖惩颠倒。

    **不放弃保护**：G3c 仍兜住「基线 GOOD_VALUE → v2 BAD_*」这类真退化，
    G3d 只放行「整行消失、无从取证」这一类情况，并附原文片段交人工裁决。
    """
    improved = len(stats.get('improved') or [])
    regressed = len(stats.get('regressed') or [])
    disappeared = list(stats.get('disappeared') or [])
    new_rows = list(stats.get('new') or [])

    # G3a：v2 里不允许残留任何编数 / 回灌
    bad_left = sum(1 for r in new_rows
                   if str(r.get('v2_state') or '').startswith('BAD_'))
    g3a = (bad_left == 0)

    # G3b：基线占位行 → 真值，至少 1 行（无基线占位行则不适用，不误报 FAIL）
    base_ns = sum(1 for d in disappeared
                  if d.get('v1_state') == GOOD_NOT_SPECIFIED)
    to_value = sum(1 for r in stats['improved']
                   if r.get('v2_state') == GOOD_VALUE)
    if base_ns > 0:
        g3b = to_value > 0
        g3b_note = "生效"
    else:
        g3b = True
        g3b_note = "不适用（基线无占位行）"

    # G3c：不允许真值退化
    g3c = (regressed == 0)

    # G3d：**advisory（INFO）**，不参与 pass。
    #      消失行的旧值再用新上下文取一次证：数字找得到出处 → 可能是真值丢失
    #      （人工复核）；找不到 → 原本就是编的，消失属清理。
    #      两者都只记录，不判 FAIL——自动判据分不开这两类。
    lost_good = [d for d in disappeared
                 if d.get('v1_state') == GOOD_VALUE]
    real_value_lost, fabricated_cleared, annotated = [], [], []
    for src in lost_good:
        d = {**src, "ctx_snippet": _ctx_snippet(
            ctx_v2, str(src.get('v1_name') or ''))}
        annotated.append(d)
        if ctx_v2 and _value_has_value(
                ctx_v2, str(d.get('v1_name') or ''),
                str(d.get('v1_value') or '')):
            real_value_lost.append(d)
        else:
            fabricated_cleared.append(d)
    g3d = {
        'status': 'INFO',
        'count': len(lost_good),
        'rows': annotated,
        'real_value_lost': len(real_value_lost),
        'fabricated_cleared': len(fabricated_cleared),
        'note': '消失行含旧值；已附原文片段供人工裁决（多为 Features 段落来源）',
    }

    # G3e：置换守恒——消失全为空值且新增里有真值 → 净改善
    new_has_value = sum(1 for r in new_rows
                        if r.get('v2_state') == GOOD_VALUE)
    if base_ns == 0 and disappeared:
        # G3d 降级后不再用它当闸，只看「消失的全是空值」这个更松的条件
        g3e = bool(not any(d.get('v1_state') == GOOD_VALUE
                           for d in disappeared)
                   and new_has_value > 0)
        g3e_note = ("置换型：消失 %d 行，新增 %d 行（含真值 %d）"
                    % (len(disappeared), len(new_rows), new_has_value))
    else:
        g3e = True
        g3e_note = "不适用"

    return {'G3a': g3a, 'G3b': g3b, 'G3c': g3c, 'G3d': g3d, 'G3e': g3e,
            'G3b_note': g3b_note, 'G3e_note': g3e_note,
            'improved': improved, 'regressed': regressed,
            'disappeared': len(disappeared), 'new': len(new_rows),
            'new_has_value': new_has_value, 'base_not_specified': base_ns,
            'real_value_lost': len(real_value_lost),
            'fabricated_cleared': len(fabricated_cleared),
            'lost_detail': [{"name": d.get("v1_name"),
                             "value": d.get("v1_value"),
                             "ctx_snippet": _ctx_snippet(
                                 ctx_v2, str(d.get("v1_name") or ""))}
                            for d in real_value_lost],
            # 硬闸只留两条：G3a（不许编数/回灌）+ G3c（不许真值退化）。
            #
            # G3b / G3d / G3e 全部 advisory，不参与 pass。理由：这三者的
            # 判定都依赖「基线行的状态」，而基线侧的行状态**无法可靠取证**——
            # `_row_state(row, '')` 只能按「有 unit + 有数值」放行，识别不了编造
            # （AFE4490 实测：4 行 Features 来源的值都被判成 GOOD_VALUE）。
            # 拿不可靠的量当闸，结果就是奖惩颠倒：保护了要清的垃圾，放过真退化。
            'pass': g3a and g3c,
            'advisory': {'G3b': g3b, 'G3b_note': g3b_note,
                         'G3d': g3d, 'G3e': g3e, 'G3e_note': g3e_note}}


def gate_v2_sample(mpn: str, v1_doc: dict, v2_doc: dict,
                   original_cells: dict | None = None) -> dict:
    """单件门禁：返回 counts + bad_total + verdict + reasons。

    verdict 规则写死，不许现场改：
      FAIL  = 出现 BAD_FABRICATED_VALUE（v2 编了原文没有的值，最严重）
      WARN  = bad_total > 0，但只有 BAD_MISSING_* （降级/漏抽，未编数）
      PASS  = bad_total == 0
    """
    cells_map = (original_cells or {}).get(mpn, {}) or {}
    e1, e2 = _el(v1_doc), _el(v2_doc)
    counts: dict[str, int] = {}
    reasons: list[str] = []
    detail: list[dict] = []

    for r2 in e2:
        name = str(r2.get("name") or "")
        val = r2.get("value")
        kind = classify(mpn, name, val, cells_map.get(name),
                        str(r2.get("condition") or ""))
        counts[kind] = counts.get(kind, 0) + 1
        detail.append({"name": name[:60], "value": str(val or "")[:40], "kind": kind})
        if kind in BAD_CLASSES and len([r for r in reasons if r.startswith(kind)]) < 3:
            reasons.append(f"{kind}: {name[:34]} value={str(val or '')[:22]}")

    # v1 有、v2 没有的行 = v2 丢行
    keys2 = {_row_key(r) for r in e2}
    dropped = [r for r in e1 if _row_key(r) not in keys2]
    if dropped:
        counts.setdefault("_DROPPED_ROWS", 0)
        counts["_DROPPED_ROWS"] = len(dropped)
        reasons.append(f"v2 丢行 {len(dropped)} 条，例：{str(dropped[0].get('name'))[:30]}")

    bad_total = sum(v for k, v in counts.items() if k in BAD_CLASSES)
    if counts.get(BAD_FABRICATED_VALUE, 0) > 0:
        verdict = "FAIL"
    elif bad_total > 0:
        verdict = "WARN"
    else:
        verdict = "PASS"

    # ---- 参考指标（不参与 verdict，留作回归观察）----
    n1, n2 = len(_all_rows(v1_doc)), len(_all_rows(v2_doc))
    empty1 = sum(1 for x in _el(v1_doc) if not str(x.get("value") or "").strip())
    empty2 = sum(1 for x in _el(v2_doc) if not str(x.get("value") or "").strip())
    lb1 = sum(1 for x in _el(v1_doc)
              if LOWER_BOUND.search(str(x.get("name") or ""))
              and not str(x.get("value") or "").strip())
    lb2 = sum(1 for x in _el(v2_doc)
              if LOWER_BOUND.search(str(x.get("name") or ""))
              and not str(x.get("value") or "").strip())
    return {
        "mpn": mpn,
        "rows_v1": len(e1), "rows_v2": len(e2),
        "all_rows_v1": n1, "all_rows_v2": n2,
        "empty_v1": empty1, "empty_v2": empty2,
        "lower_bound_empty_v1": lb1, "lower_bound_empty_v2": lb2,
        "counts": counts,
        "bad_total": bad_total,
        "verdict": verdict,
        "reasons": reasons,
        "detail": detail,
    }


def compare(cells_path: str = "") -> int:
    v1, v2 = _load("v1"), _load("v2")
    if not v1 or not v2:
        print("缺运行产物：先分别用 ICPDF_PROMPT_VERSION=v1 / v2 各跑一次", file=sys.stderr)
        return 2
    original_cells = {}
    if cells_path and Path(cells_path).is_file():
        original_cells = json.loads(Path(cells_path).read_text(encoding="utf-8"))

    keys = sorted(set(v1) & set(v2))
    print(f"对照样本 {len(keys)} 件"
          f"{'（人工三列：' + cells_path + '）' if original_cells else '（自动上下文取证）'}")
    print(f"{'MPN':<22}{'v1行':>5}{'v2行':>5}{'好值':>6}{'条件取值':>9}{'已知无值':>9}"
          f"{'回灌':>6}{'编数':>6}{'漏值':>6}{'未标':>6}  判定")

    gates: dict[str, dict] = {}
    tot: dict[str, int] = {}
    e1 = e2 = lb1 = lb2 = 0
    for k in keys:
        g = gate_v2_sample(k, v1[k], v2[k], original_cells or None)
        gates[k] = g
        # v1 也过同一套判据：回答「v2 是不是真比 v1 好」，
        # 否则只知道 v2 的绝对坏行数，看不出方向。
        c1: dict[str, int] = {}
        for r1 in _el(v1[k]):
            n1 = str(r1.get("name") or "")
            k1 = classify(k, n1, r1.get("value"),
                          (original_cells or {}).get(k, {}).get(n1),
                          str(r1.get("condition") or ""))
            c1[k1] = c1.get(k1, 0) + 1
        g["counts_v1"] = c1
        c = g["counts"]
        for kk, vv in c.items():
            tot[kk] = tot.get(kk, 0) + vv
        e1 += g["empty_v1"]; e2 += g["empty_v2"]
        lb1 += g["lower_bound_empty_v1"]; lb2 += g["lower_bound_empty_v2"]
        print(f"{k:<22}{g['rows_v1']:>5}{g['rows_v2']:>5}"
              f"{c.get(GOOD_VALUE, 0):>6}{c.get(GOOD_VALUE_IN_COND, 0):>9}"
              f"{c.get(GOOD_NOT_SPECIFIED, 0):>9}"
              f"{c.get(BAD_ECHO_NAME, 0):>6}{c.get(BAD_FABRICATED_VALUE, 0):>6}"
              f"{c.get(BAD_MISSING_VALUE, 0):>6}"
              f"{c.get(BAD_MISSING_NOT_SPEC, 0):>6}  {g['verdict']}")

    # ---- 汇总 ----
    tot1: dict[str, int] = {}
    for g in gates.values():
        for kk, vv in (g.get("counts_v1") or {}).items():
            tot1[kk] = tot1.get(kk, 0) + vv

    order = (GOOD_VALUE, GOOD_VALUE_IN_COND, GOOD_NOT_SPECIFIED,
             BAD_ECHO_NAME, BAD_FABRICATED_VALUE,
             BAD_MISSING_VALUE, BAD_MISSING_NOT_SPEC,
             VALUE_PROVIDED_BUT_NO_EXACT_MATCH, UNKNOWN_ORIG)
    print("\n分类汇总（全样本，v1 / v2 同一判据对照）：")
    print(f"  {'类别':<36}{'v1':>6}{'v2':>6}")
    for kk in order:
        if tot.get(kk) or tot1.get(kk):
            print(f"  {kk:<36}{tot1.get(kk, 0):>6}{tot.get(kk, 0):>6}")
    if tot.get("_DROPPED_ROWS"):
        print(f"  {'v2 相对 v1 丢行':<36}{'':>6}{tot['_DROPPED_ROWS']:>6}")

    fab = tot.get(BAD_FABRICATED_VALUE, 0) + tot.get(BAD_ECHO_NAME, 0)
    bad_total = sum(v for k2, v in tot.items() if k2 in BAD_CLASSES)
    lb_ok = lb2 <= lb1
    overall = "FAIL" if fab else ("PASS" if bad_total == 0 and lb_ok else "WARN")

    print("\n门禁：")
    print(f"  1. 编数+回灌（最严重）{fab} 处  要求 0       {'PASS' if fab == 0 else 'FAIL'}"
          f"   （编数 {tot.get(BAD_FABRICATED_VALUE, 0)}，回灌 "
          f"{tot.get(BAD_ECHO_NAME, 0)}；v1 同类 "
          f"{tot1.get(BAD_FABRICATED_VALUE, 0) + tot1.get(BAD_ECHO_NAME, 0)}）")
    print(f"  2. 坏行合计          {bad_total} 条  要求 0       "
          f"{'PASS' if bad_total == 0 else 'WARN'}"
          f"   （v1 同类 {sum(v for k2, v in tot1.items() if k2 in BAD_CLASSES)}）")
    rate = (e1 - e2) / e1 if e1 else 0.0
    print(f"  3. 修复率            {rate:.0%}（v1 空 {e1} → v2 空 {e2}）  要求 ≥80%  "
          f"{'PASS' if rate >= 0.8 else 'FAIL'}")
    print(f"  4. 下限参数空值      {lb1} → {lb2}  要求不得增加  "
          f"{'PASS' if lb_ok else 'FAIL'}")

    for k in keys:
        if gates[k]["reasons"]:
            print(f"\n  {k}:")
            for r in gates[k]["reasons"][:4]:
                print(f"    - {r}")

    # ---- 存档：下次改判据时唯一能回溯的事实源 ----
    gdir = ROOT / "data" / "qc" / "gates"
    gdir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    arc = gdir / f"v2_sample_{stamp}.json"
    arc.write_text(json.dumps(
        {"ts": stamp, "cells": cells_path, "overall": overall,
         "totals": tot, "gates": gates}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    print(f"\n门禁结论：{overall}"
          f"{'（v2 可上）' if overall == 'PASS' else '（v2 不得批量）'}")
    print(f"存档：{arc.relative_to(ROOT)}")
    return 0 if overall == "PASS" else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="prompt v1/v2 对照 dry-run")
    ap.add_argument("--mpn", action="append", default=[], help="覆盖默认样本（可多次）")
    ap.add_argument("--compare", action="store_true", help="只做对照与门禁判定")
    ap.add_argument("--dry-sweep", type=float, default=0.0,
                    help=">0 时按概率抽样跳件（省钱，如 0.2 表示跳 20%）")
    ap.add_argument("--original-cells-json", default="",
                    help="人工整理的原表三列 {mpn: {name: [min,typ,max]}}，"
                         "给了就用它分类（最准），不给则按上下文自动取证")
    args = ap.parse_args(argv)

    if args.compare:
        return compare(args.original_cells_json)

    version = PD.PROMPT_VERSION
    items = args.mpn or SAMPLES
    print(f"[dryrun] prompt_version={version} 样本 {len(items)} 件；"
          f"输出 {OUT / version}")
    for i, m in enumerate(items, 1):
        if args.dry_sweep > 0 and random.random() < args.dry_sweep:
            print(f"[{i}/{len(items)}] {m} SKIP（--dry-sweep）")
            continue
        r = run_one(m, version)
        if r["status"] != "ok":
            print(f"[{i}/{len(items)}] {m} ERROR: {r['error']}")
            continue
        print(f"[{i}/{len(items)}] {m} 行={r['rows']} 空值={r['empty_value']} "
              f"占位={r['not_specified']} 下限空={r['lower_bound_empty']} "
              f"{r['secs']}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
