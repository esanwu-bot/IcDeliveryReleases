#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全库数据资产体检：对生产库里每个 done 件跑一遍**逐行事实审计**。

只读生产库、只读 PDF、只读 JSON；不写 `data/parsed`、不渲染页面、不打包。
产物是「这件到底有多少参数能被原厂 PDF 回打出来」的账本，不是交付物。

为什么单独写一个入口，而不是复用 `qc/fact_acceptance.py --staging`
---------------------------------------------------------------
那个入口要求先把 13,000 件铺成 `staging/parsed/`（等于把生产库整份复制一遍），
而且是一次性全量、失败即中断。这里直接按库里的 `json_path`/`pdf_path` 读原件，
**断点续跑**（每件一行 JSONL，重跑自动跳过已完成的），单件失败只记一行错误，
不拖垮整轮。10 万件规模下，这两点比「代码复用」重要得多。

用法（服务器容器内）
--------------------
    # 全量
    python qc/asset_survey.py --db data/workbench.sqlite3 --data-root data \
        --out data/asset_survey_20261102 --workers 6

    # 冒烟 / 估时
    python qc/asset_survey.py ... --limit 50

    # 只重算报告（不重跑审计）
    python qc/asset_survey.py ... --report-only

口径
----
逐行结论、证据等级、闸门判据**全部复用** `qc/fact_acceptance.py`，本文件不另立
一套标准。行级锚定率的分母取 `gate_summary()["denominator"]`（不含 `no_value`
行），与 batch20 的 74.8% 同一口径，两个数才可比。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sqlite3
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: 产品族前缀（与 batch20 抽样口径一致，便于横向比较）。
FAMILIES = (
    ("转换器 ADC", r"^(ADS|ADC|AD7|AD9|AD6|AD5)"),
    ("转换器 DAC", r"^(DAC|DA\d)"),
    ("放大器/模拟", r"^(OPA|INA|PGA|VCA|THS|TLV|LM3|LM6|LM7)"),
    ("电源/电池", r"^(TPS|BQ|UCC|LP\d|LM2|LM5)"),
    ("逻辑", r"^(74|CD4|CY|SN74)"),
    ("驱动/接口", r"^(DRV|DS|SN6|SN7|MAX)"),
)
FAMILY_RE = [(name, re.compile(pat)) for name, pat in FAMILIES]
BOARD_RE = re.compile(r"(EVM|PDK|BOOST|KIT|DEMO|BRIDGE|DYNO)", re.I)


def family_of(mpn: str) -> str:
    up = (mpn or "").upper()
    for name, rx in FAMILY_RE:
        if rx.match(up):
            return name
    return "其他"


def resolve(raw: str, data_root: Path) -> Path | None:
    """库里存的是 Windows 绝对路径，按 `data/` 之后的部分重挂到当前机器。"""
    if not raw:
        return None
    p = Path(str(raw).replace("\\", "/"))
    if p.is_file():
        return p
    parts = p.parts
    if "data" in parts:
        i = len(parts) - 1 - parts[::-1].index("data")
        cand = data_root.joinpath(*parts[i + 1:])
        if cand.is_file():
            return cand
    cand = data_root / p.name
    return cand if cand.is_file() else None


def iter_items(db: Path, data_root: Path) -> list[dict]:
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    rows = con.execute(
        "SELECT mpn, mpn_key, brand, pdf_path, json_path, pdf_bytes "
        "FROM item WHERE status='done' AND json_path<>'' AND pdf_path<>'' "
        "ORDER BY mpn_key").fetchall()
    con.close()
    out, seen = [], set()
    for r in rows:
        mpn = str(r["mpn"] or "")
        key = str(r["mpn_key"] or mpn)
        if not mpn or key in seen:
            continue
        seen.add(key)
        out.append({"mpn": mpn, "mpn_key": key, "brand": str(r["brand"] or ""),
                    "json_path": str(r["json_path"] or ""),
                    "pdf_path": str(r["pdf_path"] or ""),
                    "pdf_bytes": int(r["pdf_bytes"] or 0)})
    return out


def audit_item(task: dict) -> dict:
    """子进程：单件审计。任何异常都收敛成一行错误，不往外抛。"""
    from qc import fact_acceptance as FA                        # noqa: PLC0415

    base = {"mpn": task["mpn"], "mpn_key": task["mpn_key"],
            "brand": task["brand"], "family": family_of(task["mpn"]),
            "is_board": bool(BOARD_RE.search(task["mpn"])),
            "pdf_bytes": task["pdf_bytes"]}
    t0 = time.time()
    try:
        data_root = Path(task["data_root"])
        jp = resolve(task["json_path"], data_root)
        pp = resolve(task["pdf_path"], data_root)
        if jp is None:
            return {**base, "status": "missing_json", "elapsed_s": 0.0}
        if pp is None:
            return {**base, "status": "missing_pdf", "elapsed_s": 0.0}
        try:
            doc = json.loads(jp.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            return {**base, "status": "bad_json",
                    "error": f"{type(e).__name__}: {e}"[:160],
                    "elapsed_s": round(time.time() - t0, 2)}
        res = FA.audit_one(task["mpn"], doc, pp)
        g = res["gate"]
        counts = g["counts"]
        return {**base,
                "status": "ok",
                "n_rows": res["n_rows"],
                "denominator": g["denominator"],
                "anchor_gate": g["anchor_gate"],
                "blocked_n": len(g["blocked"]),
                "row_anchor": counts["row_anchor"],
                "paragraph_anchor": counts["paragraph_anchor"],
                "container_verified": counts["container_verified"],
                "coord_no_fingerprint": counts["coord_no_fingerprint"],
                "weak": counts["weak"],
                "no_value": counts["no_value"],
                "blocked_labels": [b["label"] for b in g["blocked"]][:40],
                "elapsed_s": round(time.time() - t0, 2)}
    except Exception as e:                                       # noqa: BLE001
        return {**base, "status": "error",
                "error": f"{type(e).__name__}: {e}"[:200],
                "elapsed_s": round(time.time() - t0, 2)}


def load_done(jsonl: Path) -> dict[str, dict]:
    done: dict[str, dict] = {}
    if not jsonl.is_file():
        return done
    with jsonl.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue          # 半行（上一轮被 kill）：丢弃重跑
            if rec.get("mpn_key"):
                done[rec["mpn_key"]] = rec
    return done


# ── 报告 ────────────────────────────────────────────────────────────
def _rate(num: int, den: int) -> float:
    return (num / den) if den else 0.0


def build_report(recs: list[dict], out: Path, meta: dict) -> dict:
    ok = [r for r in recs if r.get("status") == "ok"]
    err = [r for r in recs if r.get("status") not in ("ok",)]
    total = len(recs)

    denom = sum(r["denominator"] for r in ok)
    n_rows_total = sum(r["n_rows"] for r in ok)
    strict = sum(r["row_anchor"] for r in ok)
    para = sum(r["paragraph_anchor"] for r in ok)
    cont = sum(r["container_verified"] for r in ok)
    strong = sum(r["row_anchor"] + r["paragraph_anchor"] + r["container_verified"]
                 for r in ok)
    weak = sum(r["weak"] for r in ok)
    coord = sum(r["coord_no_fingerprint"] for r in ok)
    no_value = sum(r["no_value"] for r in ok)

    gate_pass = [r for r in ok if r["anchor_gate"] == "pass"]
    gate_blocked = [r for r in ok if r["anchor_gate"] != "pass"]
    empty = [r for r in ok if r["denominator"] == 0]

    # 欠账分档：`anchor_gate` 是**零缺陷**闸门 —— 一行不达标就 blocked，
    # 所以「能过闸」的件数天然极低，光看它会把「只差 3 行」和「差 80 行」
    # 混成一类，对排产毫无用处。真正的可操作口径是「弱证据占分母的比例」，
    # 外加单独一张「差几行」的分布表。
    buckets = {"clean": [], "light": [], "medium": [], "heavy": []}
    for r in ok:
        if r["anchor_gate"] == "pass":
            buckets["clean"].append(r)
            continue
        ratio = _rate(r["weak"] + r["coord_no_fingerprint"], r["denominator"])
        if ratio <= 0.10:
            buckets["light"].append(r)
        elif ratio <= 0.30:
            buckets["medium"].append(r)
        else:
            buckets["heavy"].append(r)

    # 直方图封顶在 20：13,000 件的长尾会把表拉成上百行，读者反而看不到重点。
    blocked_hist = Counter(r["blocked_n"] if r["blocked_n"] <= 20 else "20+"
                           for r in ok)
    near = {f"<={k}": sum(1 for r in ok if r["blocked_n"] <= k) for k in (1, 3, 5, 10, 20)}

    fam: dict[str, dict] = defaultdict(
        lambda: {"n": 0, "pass": 0, "denom": 0, "strong": 0, "weak": 0})
    for r in ok:
        c = fam[r["family"]]
        c["n"] += 1
        c["pass"] += 1 if r["anchor_gate"] == "pass" else 0
        c["denom"] += r["denominator"]
        c["strong"] += r["row_anchor"] + r["paragraph_anchor"] + r["container_verified"]
        c["weak"] += r["weak"]

    label_ct = Counter()
    for r in gate_blocked:
        for lab in r.get("blocked_labels") or []:
            label_ct[lab] += 1

    elapsed = sum(r.get("elapsed_s") or 0 for r in recs)
    summary = {
        "generated_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "code": meta.get("code"),
        "db": meta.get("db"),
        "scope": {"items": total, "audited_ok": len(ok), "not_audited": len(err)},
        "row_level": {
            "n_rows_total": n_rows_total,
            "denominator": denom,
            "strict_row_anchor": strict,
            "strict_row_rate": round(_rate(strict, n_rows_total), 4),
            "paragraph_anchor": para,
            "container_verified": cont,
            "strong": strong,
            "strong_rate": round(_rate(strong, denom), 4),
            "weak": weak,
            "coord_no_fingerprint": coord,
            "no_value": no_value,
            "weak_ratio": round(_rate(weak + coord, denom), 4),
        },
        "gate": {
            "pass": len(gate_pass),
            "blocked": len(gate_blocked),
            "pass_ratio": round(_rate(len(gate_pass), len(ok)), 4),
        },
        "buckets": {k: len(v) for k, v in buckets.items()},
        "blocked_hist": {str(k): v for k, v in sorted(
            blocked_hist.items(),
            key=lambda kv: (1, 0) if isinstance(kv[0], str) else (0, kv[0]))},
        "near_pass": near,
        "empty_facts": len(empty),
        "families": {k: {**v, "row_anchor_rate": round(_rate(v["strong"], v["denom"]), 4)}
                     for k, v in sorted(fam.items(), key=lambda kv: -kv[1]["n"])},
        "top_blocked_labels": label_ct.most_common(30),
        "errors": [{"mpn": r["mpn"], "status": r["status"], "error": r.get("error", "")}
                   for r in err][:200],
        "elapsed_s_total": round(elapsed, 1),
    }
    (out / "survey.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    with (out / "summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        cols = ("mpn", "family", "is_board", "status", "anchor_gate", "n_rows",
                "denominator", "row_anchor", "paragraph_anchor", "container_verified",
                "coord_no_fingerprint", "weak", "blocked_n", "row_anchor_rate",
                "elapsed_s", "pdf_bytes")
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in sorted(recs, key=lambda x: x["mpn_key"]):
            row = dict(r)
            row["row_anchor_rate"] = round(
                _rate(r.get("row_anchor", 0) + r.get("paragraph_anchor", 0)
                      + r.get("container_verified", 0), r.get("denominator", 0)), 4)
            w.writerow(row)

    write_markdown(summary, buckets, out)
    return summary


def write_markdown(s: dict, buckets: dict, out: Path) -> None:
    rl = s["row_level"]
    g = s["gate"]
    sc = s["scope"]
    b = s["buckets"]
    lines = [
        "# 全库数据资产体检报告",
        "",
        f"> 生成时间：{s['generated_at']}　代码：`{s.get('code') or '—'}`",
        f"> 数据源：`{s.get('db') or '—'}`",
        "> 口径：`qc/fact_acceptance.py::gate_summary()`，与 batch20 的 74.8% 同源。",
        "",
        "## 一句话结论",
        "",
        f"全库 **{sc['items']:,}** 件可审计件中，**{g['pass']:,}** 件（"
        f"{g['pass_ratio']*100:.1f}%）能直接通过精度闸。行指纹复现率 "
        f"**{rl['strict_row_rate']*100:.1f}%**（{rl['strict_row_anchor']:,}/{rl['n_rows_total']:,}），"
        f"含段落/容器锚定的强证据率 **{rl['strong_rate']*100:.1f}%**"
        f"（{rl['strong']:,}/{rl['denominator']:,}）。",
        "",
        "> 两个率**不是同一个口径**，别混着引用：",
        "> - **行指纹复现率** = `row_anchor / 全部事实行`（含 no_value），"
        "这是 batch20 那个 74.8% 的算法；",
        "> - **强证据率** = `(row_anchor + paragraph_anchor + container_verified) / 分母`，"
        "分母不含 no_value。板卡件的正文参数本来就只存在于句子里，"
        "按行指纹要求它等于要求一个不存在的东西。",
        "",
        "## 1. 覆盖与分母",
        "",
        "| 项 | 值 |",
        "| --- | --- |",
        f"| 库内 done 件 | {sc['items']:,} |",
        f"| 成功审计 | {sc['audited_ok']:,} |",
        f"| 未能审计（缺文件/坏 JSON/异常） | {sc['not_audited']:,} |",
        f"| 事实行总数（含 no_value） | {rl['n_rows_total']:,} |",
        f"| 参与判定的行（分母，不含 no_value） | {rl['denominator']:,} |",
        f"| 其中无参数行、分母为 0 的件 | {s['empty_facts']:,} |",
        "",
        "## 2. 行级锚定",
        "",
        "| 证据等级 | 行数 | 占分母 |",
        "| --- | ---: | ---: |",
        f"| 行指纹可复现（row_anchor） | {rl['strict_row_anchor']:,} | {_rate(rl['strict_row_anchor'], rl['denominator'])*100:.1f}% |",
        f"| 正文段落锚定（paragraph_anchor） | {rl['paragraph_anchor']:,} | {_rate(rl['paragraph_anchor'], rl['denominator'])*100:.1f}% |",
        f"| 容器级锚定（container_verified） | {rl['container_verified']:,} | {_rate(rl['container_verified'], rl['denominator'])*100:.1f}% |",
        f"| 仅坐标、无行指纹 | {rl['coord_no_fingerprint']:,} | {_rate(rl['coord_no_fingerprint'], rl['denominator'])*100:.1f}% |",
        f"| 弱证据 | {rl['weak']:,} | {_rate(rl['weak'], rl['denominator'])*100:.1f}% |",
        f"| 无可回打数值（no_value） | {rl['no_value']:,} | 不计入分母 |",
        "",
        f"**行指纹复现率 {rl['strict_row_rate']*100:.1f}%**"
        f"（batch20 对照 74.8%，差 "
        f"{(rl['strict_row_rate']-0.748)*100:+.1f} 个百分点）；"
        f"**强证据率 {rl['strong_rate']*100:.1f}%**。",
        "",
        "## 3. 闸门分布",
        "",
        "`anchor_gate` 是**零缺陷**闸门：一行不达标就 blocked。所以「能过闸」的件数",
        "天然极低，真正能用来看排产的是下面两张表。",
        "",
        "| 档位（按弱证据占比） | 件数 | 占比 |",
        "| --- | ---: | ---: |",
        f"| A 可直接过闸（anchor_gate=pass） | {b['clean']:,} | {_rate(b['clean'], sc['audited_ok'])*100:.1f}% |",
        f"| B 轻度（弱证据 ≤10%） | {b['light']:,} | {_rate(b['light'], sc['audited_ok'])*100:.1f}% |",
        f"| C 中度（弱证据 ≤30%） | {b['medium']:,} | {_rate(b['medium'], sc['audited_ok'])*100:.1f}% |",
        f"| D 重度（弱证据 >30%） | {b['heavy']:,} | {_rate(b['heavy'], sc['audited_ok'])*100:.1f}% |",
        "",
        "### 3.1 距离过闸还差几行",
        "",
        "| 不达标行数 | 件数 | 占比 |",
        "| --- | ---: | ---: |",
        *[f"| {k} 行 | {v:,} | {_rate(v, sc['audited_ok'])*100:.1f}% |"
          for k, v in s["blocked_hist"].items()],
        "",
        "| 累计 | 件数 | 占比 |",
        "| --- | ---: | ---: |",
        *[f"| 不达标 {k} 行 | {v:,} | {_rate(v, sc['audited_ok'])*100:.1f}% |"
          for k, v in s["near_pass"].items()],
        "",
        "## 4. 按产品族",
        "",
        "| 族 | 件数 | 过闸 | 过闸率 | 强证据率 |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for name, v in s["families"].items():
        lines.append(f"| {name} | {v['n']:,} | {v['pass']:,} | "
                     f"{_rate(v['pass'], v['n'])*100:.1f}% | "
                     f"{v['row_anchor_rate']*100:.1f}% |")
    lines += ["", "## 5. 最常卡住闸门的参数", ""]
    if s["top_blocked_labels"]:
        lines += ["| 参数 | 出现在多少件 |", "| --- | ---: |"]
        lines += [f"| {lab} | {n:,} |" for lab, n in s["top_blocked_labels"]]
    else:
        lines.append("无。")
    lines += ["", "## 6. 未能审计的件", ""]
    if s["errors"]:
        lines += ["| 型号 | 状态 | 原因 |", "| --- | --- | --- |"]
        for e in s["errors"][:30]:
            lines.append(f"| {e['mpn']} | {e['status']} | {e['error'][:80]} |")
        if len(s["errors"]) > 30:
            lines.append(f"| … | 共 {len(s['errors'])} 件 | 见 survey.json |")
    else:
        lines.append("无。")
    lines += [
        "",
        "## 7. 这份报告不说什么",
        "",
        "- 行级锚定率证明「值有出处」，**不证明「值被归到了正确的行」**；后者仍需人工裁决。",
        "- `anchor_gate=pass` 只表示「这份证据够它自己的门槛」，不等于参数正确。",
        "- 本轮不打包、不渲染页面、不改 `data/parsed`；结论只用于排产决策。",
        "",
    ]
    (out / "全库数据资产体检报告.md").write_text("\n".join(lines), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="全库数据资产体检（逐行事实审计）")
    ap.add_argument("--db", default="data/workbench.sqlite3")
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--out", default="data/asset_survey")
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) // 2))
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 件（冒烟/估时）")
    ap.add_argument("--report-only", action="store_true")
    a = ap.parse_args(argv)

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    jsonl = out / "items.jsonl"

    import subprocess                                          # noqa: PLC0415
    try:
        code = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                              capture_output=True, text=True).stdout.strip()
    except Exception:                                          # noqa: BLE001
        code = ""
    meta = {"code": code, "db": str(a.db)}

    if a.report_only:
        recs = list(load_done(jsonl).values())
        s = build_report(recs, out, meta)
        print(f"报告已重算：{out}/全库数据资产体检报告.md（{len(recs)} 件）")
        return 0

    items = iter_items(Path(a.db), Path(a.data_root))
    done = load_done(jsonl)
    pending = [it for it in items if it["mpn_key"] not in done]
    if a.limit:
        pending = pending[:a.limit]
    print(f"库内可审计 {len(items):,} 件，已完成 {len(done):,}，"
          f"本轮待跑 {len(pending):,}，并发 {a.workers}", flush=True)

    if pending:
        t0 = time.time()
        n_ok = n_bad = 0
        with jsonl.open("a", encoding="utf-8") as f, \
                ProcessPoolExecutor(max_workers=a.workers) as ex:
            futs = {}
            for it in pending:
                task = {**it, "data_root": str(a.data_root)}
                futs[ex.submit(audit_item, task)] = it["mpn_key"]
            for i, fut in enumerate(as_completed(futs), 1):
                rec = fut.result()
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                f.flush()
                if rec["status"] == "ok":
                    n_ok += 1
                else:
                    n_bad += 1
                if i % 25 == 0 or i == len(pending):
                    el = time.time() - t0
                    rate = i / el if el else 0
                    eta = (len(pending) - i) / rate if rate else 0
                    print(f"  {i:,}/{len(pending):,} ok={n_ok:,} bad={n_bad:,} "
                          f"{rate:.2f} 件/秒 ETA {eta/60:.1f} 分钟", flush=True)

    recs = list(load_done(jsonl).values())
    s = build_report(recs, out, meta)
    print(f"完成：{s['scope']['audited_ok']:,} 件审计成功，"
          f"过闸 {s['gate']['pass']:,} 件，行指纹复现 "
          f"{s['row_level']['strict_row_rate']*100:.1f}%，强证据 "
          f"{s['row_level']['strong_rate']*100:.1f}%")
    print(f"报告：{out}/全库数据资产体检报告.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
