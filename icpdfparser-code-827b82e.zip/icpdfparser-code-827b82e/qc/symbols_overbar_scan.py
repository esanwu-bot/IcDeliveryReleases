#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读扫描：存量页的符号块差异里，有多少是「纯新增低有效引脚上划线」。

背景
----
`symbol_svg.py` 的画法从某一代起给低有效信号（`1OE` / `INT` / `CS#` …）加了
**上划线**（`<line stroke="#1f6f5c" stroke-width="1.4">`，贴在引脚名上方；
不用 `text-decoration="overline"`，因为老 Chromium 对 SVG 的这个属性支持不稳）。
于是存量页重渲染后「符号块逐字节相同」不成立 —— 图确实多了一笔，尽管这一笔是对的。

这类差异和「图被改坏」必须分开算：前者可以批量合入，后者一件都不能。
本脚本只回答一个问题：**全库有多少件属于前者**。

判据（三条同时成立，逐字节，不看相似度）
---------------------------------------
1. 新旧两侧都有 `schematic symbol` 块（`no_anchor` 的件不进这个统计）；
2. 旧块里的 `<line>` **一条都没少**（少一条就不是纯新增）；
3. 把新增的 `<line>` 从新块里删掉之后，新块与旧块**逐字节相同**。

第 3 条是关键：它同时排除了「上划线加了、别的地方也动了」的件。用 `difflib` 的
相似度会放过这种混合改动（0.98 的相似度里可能藏着一条坐标变化）。

只读：不写 `data/symbols`，不写 `--new` 沙箱，只写 `--out` 报告。

用法
----
    python qc/symbols_overbar_scan.py                       # 用默认沙箱快照
    python qc/symbols_overbar_scan.py --json .sandbox/rr_v6.json --out .sandbox/overbar.md
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: 上划线的唯一签名：墨绿、1.4 宽、水平线。`C_NAME` 就是 `#1f6f5c`。
OVERBAR_RE = re.compile(
    r'<line x1="[\d.]+" y1="[\d.]+" x2="[\d.]+" y2="[\d.]+" '
    r'stroke="#1f6f5c" stroke-width="1\.4"/>')
#: 任何 `<line>`（用来判「旧块里的线一条都没少」）
LINE_RE = re.compile(r'<line\b[^>]*/>')
#: 符号块（与 `symbols_rerender` / `symbols_render_diff` 同一把尺子）
SYMBOL_RE = re.compile(
    r'<svg[^>]*aria-label="[^"]*schematic symbol[^"]*".*?</svg>', re.S)


def classify_pair(old_page: str, new_page: str) -> tuple[str, int]:
    """返回（分类，新增上划线数）。纯函数，便于红先测试。"""
    mo, mn = SYMBOL_RE.search(old_page), SYMBOL_RE.search(new_page)
    if not mo or not mn:
        return "no_symbol_block", 0
    old, new = mo.group(0), mn.group(0)
    if old == new:
        return "identical", 0

    lost = Counter(LINE_RE.findall(old)) - Counter(LINE_RE.findall(new))
    added = Counter(LINE_RE.findall(new)) - Counter(LINE_RE.findall(old))
    if lost:
        return "line_removed", 0                    # 少了线 → 不是纯新增
    if not added:
        return "no_line_delta", 0                   # 差异不在线上（文字/坐标）
    if any(not OVERBAR_RE.match(x) for x in added):
        return "line_added_not_overbar", 0          # 加了线，但不是上划线

    # 关键一步：把新增的上划线删回原样，必须与旧块逐字节相同。
    # 注意连它独占的那一行换行一起删：渲染器每条图元后跟一个 `\n`，
    # 只删标签会留下空行，把「纯新增」误判成「还有别的差异」（实测 2030 件全栽在这）。
    stripped = new
    for line in added.elements():
        for cand in (line + "\n", "\n" + line, line):
            if cand in stripped:
                stripped = stripped.replace(cand, "", 1)
                break
    if stripped == old:
        return "overbar_only", sum(added.values())
    return "overbar_plus_other", 0


#: 图元序列（用于按文档顺序找上划线的归属文字）
EL_RE = re.compile(r'<(line|text)\b[^>]*?(?:/>|>([^<]*)</text>)')
OVERBAR_ATTR = '#1f6f5c" stroke-width="1.4'


def bars_are_owned_by_active_low(new_page: str, active_low: set) -> tuple:
    """新增的上划线是不是都画在低有效引脚上。返回（命中，未命中，未命中样例）。

    归属不靠「找它下方的文字」那种坐标启发式 —— 脚号（`<text>` 里就是 `1` `2`）
    画在引脚线上方、紧贴上划线，坐标启发式抓到的全是脚号，于是看起来像
    「上划线全画错了」。改用**文档顺序**：渲染器在 `draw()` 里先输出引脚名
    `<text>`、再输出上划线 `<line>`，所以上划线在序列里的前一个 `<text>`
    就是它的名字。
    """
    mo = SYMBOL_RE.search(new_page)
    if not mo:
        return 0, 0, []
    els = [(m.group(1), m.group(0), m.group(2)) for m in EL_RE.finditer(mo.group(0))]
    hit, miss = 0, []
    for i, (tag, raw, _txt) in enumerate(els):
        if tag != "line" or OVERBAR_ATTR not in raw:
            continue
        prev = [e for e in els[:i] if e[0] == "text"]
        name = (prev[-1][2] if prev else "").strip().upper().lstrip("~/").rstrip("#_")
        if name in active_low:
            hit += 1
        else:
            miss.append(name or "<无前驱文字>")
    return hit, len(miss), miss[:10]


def _one(job) -> dict:
    mpn, old_path, new_path = job
    old = Path(old_path).read_text(encoding="utf-8", errors="replace")
    p = Path(new_path)
    if not p.is_file():
        return {"mpn": mpn, "kind": "no_new_page", "bars": 0}
    new = p.read_text(encoding="utf-8", errors="replace")
    kind, bars = classify_pair(old, new)
    return {"mpn": mpn, "kind": kind, "bars": bars}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="只读扫描：纯新增低有效引脚上划线的存量页")
    ap.add_argument("--json", default=str(ROOT / ".sandbox" / "rr_v6.json"),
                    help="重渲染测量结果（要 --new 那一份同时代的）")
    ap.add_argument("--symbols", default=str(ROOT / "data" / "symbols"))
    ap.add_argument("--new", default=str(ROOT / ".sandbox" / "rr_v5"))
    ap.add_argument("--out", default="")
    ap.add_argument("--verify-active-low", action="store_true",
                    help="对判定为 overbar_only 的件，逐笔核对上划线是否画在低有效引脚上")
    ap.add_argument("--parsed", default=str(ROOT / "data" / "parsed"))
    ap.add_argument("--workers", type=int, default=6)
    a = ap.parse_args(argv)

    data = json.loads(Path(a.json).read_text(encoding="utf-8"))
    rows = data["rows"]
    # 只扫「符号块确实不同」的件；`ok` 那些的符号块本来就一样，问题等于已知
    drift = [r for r in rows if r.get("symbol_same") is False]
    jobs = [(r["mpn"], str(Path(a.symbols) / f'{r["mpn"]}.html'),
             str(Path(a.new) / f'{r["mpn"]}.html')) for r in drift]

    out_rows: list[dict] = []
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        for i, r in enumerate(ex.map(_one, jobs, chunksize=50), 1):
            out_rows.append(r)
            if i % 500 == 0:
                print(f"  … {i}/{len(jobs)}", flush=True)

    kinds = Counter(r["kind"] for r in out_rows)
    overbar = [r for r in out_rows if r["kind"] == "overbar_only"]
    bars = Counter(r["bars"] for r in overbar)
    res = {
        "source": a.json,
        "drift_rows": len(drift),
        "kinds": dict(kinds),
        "overbar_only": len(overbar),
        "overbar_counts": dict(sorted(bars.items())),
        "samples": [r["mpn"] for r in overbar[:10]],
        "not_overbar_samples": {k: [r["mpn"] for r in out_rows if r["kind"] == k][:5]
                                for k in kinds if k != "overbar_only"},
    }
    print(json.dumps(res, ensure_ascii=False, indent=1))

    if a.verify_active_low:
        import symbol_svg as S
        from qc.symbols_rerender import index_parsed
        idx = index_parsed(Path(a.parsed))
        hit = miss = 0
        misses: dict[str, list[str]] = {}
        for r in overbar:
            mpn = r["mpn"]
            j = idx.get(mpn)
            if j is None:
                continue
            low = S.active_low_of(json.loads(j.read_text(encoding="utf-8")))
            page = Path(a.new, f"{mpn}.html").read_text(encoding="utf-8", errors="replace")
            h, n, names = bars_are_owned_by_active_low(page, low)
            hit += h
            miss += n
            if n:
                misses[mpn] = names
        res["active_low_verify"] = {"bars_hit": hit, "bars_missed": miss,
                                    "pages_with_miss": len(misses),
                                    "samples": list(misses.items())[:10]}
        print(json.dumps(res["active_low_verify"], ensure_ascii=False, indent=1))

    if a.out:
        Path(a.out).write_text(json.dumps(
            {"summary": res, "rows": out_rows}, ensure_ascii=False, indent=1),
            encoding="utf-8")
        print(f"\n明细 {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
