"""受控分类表：把模型给的粗分类收敛成站内可用的类目路径。

背景（1102 复审 P2-7）：`basic_info.subcategory` 是模型自己写的自由文本，
同一类器件会写成 `Data Converters` / `Data Acquisition Converters` /
`Analog to Digital Converters` / `ADC` 四种。站点按它建类目就会裂成四条互不
相认的路径，ADC 也就永远落不到 `Data Acquisition / ADCs` 这个细粒度节点上。

这里做的是**收敛**，不是猜：

* 只在命中受控表的键时改写，命中不了就原样返回，绝不新造类目名；
* 输出同时给 `category_path`（站点导入用）与 `category_leaf`（页面/SEO 用），
  并且**不动** `subcategory` —— 它已经进了 H1 句子
  （`{mpn} is a {subcategory} from {mfr}`），改词性会把英文句子写坏。

`category_path` 的层级与站内类目树对齐：
`Integrated Circuits (ICs) / Data Acquisition / ADCs`。
"""

from __future__ import annotations

import re

#: 受控路径：键是归一化后的粗分类（小写、去标点、压空白）。
CONTROLLED_PATHS: dict[str, list[str]] = {
    # 数据转换器：模型最常写 "Data Converters"，必须按 ADC / DAC 拆开
    "data converters": ["Integrated Circuits (ICs)", "Data Acquisition", "Data Converters"],
    "data acquisition converters": ["Integrated Circuits (ICs)", "Data Acquisition", "Data Converters"],
    "data acquisition": ["Integrated Circuits (ICs)", "Data Acquisition", "Data Converters"],
    "analog to digital converters": ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"],
    "analog to digital converter": ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"],
    "adc": ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"],
    "adcs": ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"],
    "digital to analog converters": ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"],
    "digital to analog converter": ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"],
    "dac": ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"],
    "dacs": ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"],
    # 放大器 / 电源 / 接口 / 时钟：只登记已确认的粗分类，避免臆造
    "amplifiers": ["Integrated Circuits (ICs)", "Amplifiers"],
    "linear amplifiers": ["Integrated Circuits (ICs)", "Amplifiers"],
    "power management": ["Integrated Circuits (ICs)", "Power Management"],
    "pmic": ["Integrated Circuits (ICs)", "Power Management"],
    "interface": ["Integrated Circuits (ICs)", "Interface"],
    "logic": ["Integrated Circuits (ICs)", "Logic"],
    "clock and timing": ["Integrated Circuits (ICs)", "Clock and Timing"],
    "clock timing": ["Integrated Circuits (ICs)", "Clock and Timing"],
}

#: 粗分类落到 ADC/DAC 时的判据词。**只看器件自身证据**：
#: `subcategory` / `category` / `description` / 型号前缀。
_ADC_RE = re.compile(r"\b(a\/?d|adc|analog[- ]to[- ]digital)\b", re.I)
_DAC_RE = re.compile(r"\b(d\/?a|dac|digital[- ]to[- ]analog)\b", re.I)
_ADC_MPN_RE = re.compile(r"^(ADC|ADS|AD7|AD9|AD1[0-9]{3}|LTC2[0-9]{3}|MAX1[0-9]{3})", re.I)
_DAC_MPN_RE = re.compile(r"^(DAC|AD5[0-9]{3}|LTC1[0-9]{3}|MAX5[0-9]{3})", re.I)


def _norm(s: str) -> str:
    s = re.sub(r"[^a-z0-9]+", " ", str(s or "").lower())
    return re.sub(r"\s+", " ", s).strip()


def _evidence(doc: dict) -> str:
    bi = doc.get("basic_info") or {}
    parts = [bi.get("subcategory"), bi.get("category"), bi.get("description")]
    parts += list(doc.get("features") or [])[:4]
    return " ".join(str(p) for p in parts if p)


def canonical_path(doc: dict) -> list[str]:
    """返回受控类目路径；判不出来就返回 `[]`（不猜）。

    先按受控表查粗分类；查不到或落到笼统的 `Data Converters` 时，
    再用器件证据（型号前缀 + 描述词）细分到 ADC / DAC。
    """
    bi = doc.get("basic_info") or {}
    sub = _norm(bi.get("subcategory"))
    path = list(CONTROLLED_PATHS.get(sub) or [])
    leaf = path[-1] if path else ""

    if leaf == "Data Converters":
        ev = _evidence(doc)
        mpn = str(bi.get("mpn") or bi.get("requested_mpn") or "")
        is_adc = bool(_ADC_RE.search(ev) or _ADC_MPN_RE.match(mpn))
        is_dac = bool(_DAC_RE.search(ev) or _DAC_MPN_RE.match(mpn))
        # 两个都命中（描述里同时提到 ADC 和 DAC）时不做判断，保留笼统层
        if is_adc and not is_dac:
            path = ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"]
        elif is_dac and not is_adc:
            path = ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"]
    return path


def apply_taxonomy(doc: dict) -> dict:
    """把受控路径写进 `basic_info.category_path` / `category_leaf`。

    幂等；判不出来时什么都不写（保持原样，不产生半截路径）。
    """
    path = canonical_path(doc)
    if not path:
        return {}
    bi = doc.setdefault("basic_info", {})
    old = bi.get("category_path")
    bi["category_path"] = path
    bi["category_leaf"] = path[-1]
    return {"category_path": path, "changed": old != path}
