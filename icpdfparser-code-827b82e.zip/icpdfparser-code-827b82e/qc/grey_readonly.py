# -*- coding: utf-8 -*-
"""灰度抽样：抽样 N 件跑 `postprocess → table_audit` 诊断。

**默认只读**（`write=False`，不碰 `data/parsed`）；加 `--write` 才写盘，
且写盘**只写沙箱副本**（`--box`，默认 `<out>/box`），`data/parsed` 一个字节都不动。

为什么单独写一个脚本而不是 `table_audit.py --all --limit`：
1. `--all --limit` 是按文件名排序取前 N —— 同厂同族的件会挤在一起（`551013xxx`、
   `ADSxxxx`），样本严重偏斜。这里按**等距抽样**（每 k 件取 1），覆盖全语料。
2. 需要统计「融合列表格」这种 `audit_json` 不再返回的结构信息，得自己留一份 tables。
3. 需要增量落盘（`result.jsonl`），跑几个小时中途断了不用重来。

统计口径（每件一行）
--------------------
- `kinds`：finding 种类计数
- `amb_tie` / `amb_coll`：`row_ambiguous_unresolved` 里并列 / 抢同一行
- `cell_bad`：`cell_unparsable_unresolved`（其中 `fused` 为融合列导致）
- `fused_tables`：该 PDF 里表头一列装多个 MIN/TYP/MAX 的表数
- `matched`：唯一命中并被检查的条目数（electrical + absolute_max）
- `write_*`（仅 `--write`）：写盘条数、乱码 condition 被拦条数、写入样本（供人工核对）

用法：
  python qc/grey_readonly.py --n 500 --workers 6 --out data/qc/grey500
  python qc/grey_readonly.py --n 12  --workers 2 --out data/qc/grey_pilot   # 先估时间
  ICPDF_SPLIT_FUSED=1 python qc/grey_readonly.py --n 50 --workers 6 \
      --out data/qc/grey_write50 --write                                  # 写盘灰度（沙箱）
"""
import argparse
import json
import os
import shutil
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PARSED = ROOT / "data" / "parsed"
SKIP_SUFFIX = (".pre_audit", ".pre_pp.json", ".alts.json", ".seo.json")

_cache: dict = {}
_WRITE = False      # 只读 / 写盘（由 initializer 在每个子进程里置位）
_BOX: Path | None = None
_TAG = ""           # 代码版本标签：跨版本续跑时用于分段统计（空 = 老格式，不写该字段）


def _install_scan_cache(T):
    """同一份 PDF 只扫一次：fused 统计和 audit 共用，省一半时间。"""
    orig = T.scan_tables

    def cached(doc, max_pages=None):
        key = str(getattr(doc, "name", id(doc)))
        if key not in _cache:
            _cache[key] = orig(doc, max_pages) if max_pages else orig(doc)
        return _cache[key]

    T.scan_tables = cached


def discover(n: int) -> list:
    """等距抽样：全语料 8993 件里均匀取 n 件。"""
    files = [p for p in sorted(PARSED.glob("*.json"))
             if not p.name.endswith(SKIP_SUFFIX)]
    if n >= len(files):
        return files
    step = len(files) / n
    return [files[int(i * step)] for i in range(n)]


def mpn_of(path: Path) -> str:
    import re
    return re.sub(r"_[0-9a-f]{8}$", "", path.stem)


def pick_by_mpn(names: str) -> list:
    """按给定 mpn / json 文件名精确取件，顺序保持入参顺序。

    为什么需要它：``discover`` 是**等距抽样**，每次同一 N 抽到的都是同一批，
    但那是"语料代表"而不是"已知问题件"。做 A17 这类开关的 A/B 对照时，
    样本必须是**固定自选的夹具**（ADC3910 / BQ24300 / DAC8555…），
    用 ``--n 12`` 抽出来的 12 件与夹具 12 件完全不同，结论会直接错位。

    同名多件时取排序第一个；找不到的名单会打印出来，不静默丢弃。
    """
    want = [x.strip() for x in names.split(",") if x.strip()]
    by_file, by_mpn = {}, {}
    for p in sorted(PARSED.glob("*.json")):
        if p.name.endswith(SKIP_SUFFIX):
            continue
        by_file[p.name] = p
        by_mpn.setdefault(mpn_of(p), p)
    got, miss = [], []
    for w in want:
        p = by_file.get(w) or by_mpn.get(w)
        if p is not None:
            got.append(p)
        else:
            miss.append(w)
    if miss:
        print("未找到（跳过）：" + ", ".join(miss), flush=True)
    dup = len(got) - len({mpn_of(p) for p in got})
    if dup:
        print(f"注意：名单里有 {dup} 个 mpn 命中同一件（同名多版本取第一个）", flush=True)
    return got


def one(path_str: str) -> dict:
    """单件诊断。默认**只读**（write=False）；`_WRITE` 为真时在沙箱副本上走完整写盘管线。

    写盘模式下 JSON 路径已经是**沙箱副本**（main 负责 stage），PDF 也在沙箱里，
    所以 `postprocess` 与 `audit_json(write=True)` 都只动副本。
    """
    from qc import table_audit as T

    path = Path(path_str)
    t0 = time.time()
    mpn = mpn_of(path)
    rec = {"mpn": mpn, "json": path.name, "ok": False, "sec": 0.0}
    if _TAG:
        rec["tag"] = _TAG
    try:
        loc = T.locate_paths(mpn)
        if not loc or not loc.get("pdf"):
            rec["err"] = "缺 PDF"
            return rec
        pdf_path = (_BOX / Path(loc["pdf"]).name) if _WRITE else Path(loc["pdf"])
        if _WRITE and not pdf_path.exists():
            rec["err"] = "沙箱缺 PDF"
            return rec
        doc = json.loads(path.read_text(encoding="utf-8"))
        els = (doc.get("specs") or {}).get("electrical") or []
        abm = (doc.get("specs") or {}).get("absolute_max") or []
        # 先扫一次（进缓存），拿到融合列统计；audit_json 复用同一份
        import pymupdf
        with pymupdf.open(str(pdf_path)) as d:
            tables = T.scan_tables(d)
            pages = d.page_count
        rec["pages"] = pages
        rec["tables"] = len(tables)
        rec["fused_tables"] = sum(1 for t in tables if T.fused_cols(t["header"]))
        rec["entries"] = len(els) + len(abm)

        if _WRITE:
            # 真实管线顺序：先 qwen 后处理（同 name/cond 合并），再审计写盘
            from qc import postprocess_qwen as PQ
            PQ.process(path, write=True, pdf_dir=_BOX)
            doc = json.loads(path.read_text(encoding="utf-8"))

        res = T.audit_json(doc, pdf_path, write=_WRITE, requested=mpn,
                           src_json=str(path))
        finds = res["findings"]
        kinds = Counter(f["kind"] for f in finds)
        rec["kinds"] = dict(kinds)
        rec["findings"] = len(finds)
        rec["unresolved"] = len(res["unresolved"])
        rec["patched"] = len(finds) - len(res["unresolved"])
        rec["amb_tie"] = sum(1 for f in finds
                             if f.get("ambiguous_reason") == "ambiguous_tie")
        rec["amb_coll"] = sum(1 for f in finds
                              if f.get("ambiguous_reason") == "ambiguous_collision")
        rec["cell_bad"] = kinds.get("cell_unparsable_unresolved", 0)
        rec["cell_bad_fused"] = sum(
            1 for f in finds if f["kind"] == "cell_unparsable_unresolved"
            and f.get("table") == "FUSED_COLUMN")
        if _WRITE:
            _write_stats(rec, path)
        rec["ok"] = True
    except Exception as exc:                      # 单件崩了不能拖垮整批
        rec["err"] = f"{type(exc).__name__}: {exc}"
    finally:
        rec["sec"] = round(time.time() - t0, 1)
    return rec


def _write_stats(rec, path: Path) -> None:
    """写盘模式的核对口径：写了几条、写的是什么、护栏拦了几条。"""
    doc = json.loads(path.read_text(encoding="utf-8"))
    specs = doc.get("specs") or {}
    els = (specs.get("electrical") or []) + (specs.get("absolute_max") or [])
    written = [e for e in els if e.get("columns")]
    rec["write_cols"] = len(written)
    rec["write_garbled"] = sum(1 for e in els if e.get("condition_cell_garbled"))
    # 只留摘要（result.jsonl 要能整份读进内存）：名称 + 三列 + condition
    rec["write_sample"] = [
        {"name": (e.get("name") or "")[:60],
         "columns": e.get("columns"),
         "raw": e.get("columns_raw"),
         "cond": (e.get("condition") or "")[:70],
         "cond_garbled": bool(e.get("condition_cell_garbled"))}
        for e in written[:8]
    ]


def _init(write=False, box=None, tag=""):
    """子进程初始：装缓存 + 固定写盘模式 + 把 FACTS 目录也关进沙箱。

    `FACTS` 是 `table_audit` 的模块级常量，`audit_json(write=True)` 会往那里写
    `{mpn}.facts.json` —— 不改它，写盘灰度就会**从沙箱侧漏**到真 facts 目录。
    """
    from qc import table_audit as T
    _install_scan_cache(T)
    global _WRITE, _BOX, _TAG
    _WRITE, _BOX, _TAG = bool(write), (Path(box) if box else None), tag or ""
    if _WRITE and _BOX:
        T.FACTS = _BOX / "facts"


def stage(files, box: Path) -> list:
    """把 json + pdf 复制进沙箱，返回副本路径清单（顺序不变）。"""
    box.mkdir(parents=True, exist_ok=True)
    out = []
    for f in files:
        loc = None
        try:
            from qc import table_audit as T
            loc = T.locate_paths(mpn_of(f))
        except Exception:
            loc = None
        if not loc or not loc.get("pdf"):
            print(f"  [跳过] {mpn_of(f)} 缺 PDF", flush=True)
            continue
        shutil.copy2(f, box / f.name)
        p = Path(loc["pdf"])
        if not (box / p.name).exists():
            shutil.copy2(p, box / p.name)
        out.append(box / f.name)
    return out


def run_meta(a, box: Path, n: int) -> dict:
    """把「这批数字是哪个代码版本、哪组开关、写没写沙箱」钉在制品旁边。

    为什么必须有：`写盘 20→17` 那次的两份 `result.jsonl` 事后找不到，
    归因只能靠记忆，结果把 A16 的拦截记成了 A17 的功绩
    （见 `docs/qc/20261030_review_验真报告.md` §7）。
    数字可以错，但必须能追溯 —— 没有 RUN.json 的 run 不许进报告。
    """
    sha, dirty = "", []
    try:
        import subprocess
        sha = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"], cwd=str(ROOT),
            text=True, stderr=subprocess.DEVNULL).strip()
        dirty = [ln[3:] for ln in subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=str(ROOT),
            text=True, stderr=subprocess.DEVNULL).splitlines() if ln.strip()]
    except Exception:                                   # noqa: BLE001
        pass                                            # 无 git 也不阻塞跑批
    return {
        "sha": sha,
        # 工作区脏文件清单：并行线同时在改时，这份清单是"结果不能单独归因"的证据
        "dirty": dirty,
        "flags": {k: os.getenv(k, "") for k in (
            "ICPDF_MATCH_RULE", "ICPDF_SPLIT_FUSED", "ICPDF_PAGE_FILTER",
            "ICPDF_JEV_TIE", "ICPDF_JEV_MERGE", "ICPDF_AUDIT_MAX_PAGES")},
        "mode": "write" if a.write else "readonly",
        "box": str(box) if a.write else "",
        # FACTS 侧车必须落沙箱：只重定向 src_json 不够，模块级 FACTS 还指真目录
        "box_facts": str(box / "facts") if a.write else "",
        "n": n,
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--mpn", default="",
                    help="指定件名单（逗号分隔的 mpn 或 json 文件名），优先于 --n。"
                         "A/B 对照/夹具复跑必须用它，等距抽样抽不到已知问题件")
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--out", default="data/qc/grey500")
    ap.add_argument("--limit-pages", type=int, default=40,
                    help="每份 PDF 最多扫多少页（默认 40，与 13 件灰度一致）")
    ap.add_argument("--resume", action="store_true",
                    help="跳过 result.jsonl 里已完成的件（断点续跑，不丢已有进度）")
    ap.add_argument("--write", action="store_true",
                    help="开启写盘（先 postprocess 后 audit）。只写沙箱副本，不动 data/parsed")
    ap.add_argument("--box", default="",
                    help="写盘沙箱目录，默认 <out>/box")
    ap.add_argument("--tag", default="",
                    help="代码版本标签，写进每条记录（跨版本续跑时分段统计用；空则不加字段）")
    a = ap.parse_args()

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("ICPDF_AUDIT_MAX_PAGES", str(a.limit_pages))
    box = Path(a.box) if a.box else (out / "box")

    files = pick_by_mpn(a.mpn) if a.mpn else discover(a.n)
    print(f"抽样 {len(files)} 件 / 语料 {len(list(PARSED.glob('*.json')))} 件；"
          f"MATCH_RULE={os.getenv('ICPDF_MATCH_RULE', 'v3')}；"
          f"SPLIT_FUSED={os.getenv('ICPDF_SPLIT_FUSED', '0')}；"
          f"MAX_PAGES={os.getenv('ICPDF_AUDIT_MAX_PAGES')}；workers={a.workers}；"
          f"tag={a.tag or '-'}；"
          f"模式={'写盘(沙箱 '+str(box)+')' if a.write else '只读'}", flush=True)

    jsonl = out / "result.jsonl"
    meta_path = out / "RUN.json"
    meta_path.write_text(
        json.dumps(run_meta(a, box, len(files)), ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(f"记账 → {meta_path}", flush=True)
    if a.resume and jsonl.exists():
        seen = {json.loads(l)["mpn"] for l in jsonl.read_text(encoding="utf-8").splitlines() if l.strip()}
        before = len(files)
        files = [f for f in files if mpn_of(f) not in seen]
        print(f"续跑：已完成 {len(seen)} 件，本次补 {len(files)}/{before} 件", flush=True)
        mode = "a"
    else:
        mode = "w"

    if a.write:
        # 写盘必须先落沙箱：`data/parsed` 是唯一真源，灰度阶段绝不许就地改
        if PARSED.resolve() in box.resolve().parents or box.resolve() == PARSED.resolve():
            print(f"拒绝执行：沙箱 {box} 落在 data/parsed 内", flush=True)
            return 2
        print(f"沙箱 staging → {box}", flush=True)
        files = stage(files, box)
        if not files:
            print("没有可写的件", flush=True)
            return 1

    done = 0
    t0 = time.time()
    from multiprocessing import Pool
    with Pool(a.workers, initializer=_init,
              initargs=(a.write, str(box), a.tag)) as pool, jsonl.open(mode, encoding="utf-8") as fh:
        for rec in pool.imap_unordered(one, [str(p) for p in files]):
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            done += 1
            if done % 10 == 0 or done == len(files):
                el = time.time() - t0
                eta = el / done * (len(files) - done)
                print(f"  {done}/{len(files)}  已用 {el/60:.1f}min  预计剩余 {eta/60:.1f}min",
                      flush=True)

    print(f"完成：{jsonl}（{done} 行，{time.time()-t0:.0f}s）", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
