"""G3 迁移判据复算：只用**已有产物**重算，不重新调 LLM（零成本）。

背景
----
6a 跑完后发现旧判据「v2 not_specified < v1 编数行数」口径错误：
  - 拿 v1 的**编造值行数**比 v2 的 **not_specified 行数**，是两个字段在比；
  - 上下文一变，行集本身就变（AFE4490 15→20），总数字不可比。

本脚本改用 **按行名匹配 + 状态迁移统计**，对同一批行看 v1→v2 的状态如何变，
而不是比总数。

上下文文本
----------
`data/qc/prompt_dryrun/v2/_ctx/` 默认不存在（`prompt_dryrun._ctx_text` 是纯内存
缓存）。`--ctx` 未给时用 `PD._iter_pages` + `PD.select_pages` 本地重生成——
纯 PDF 解析，零 token。

用法
----
    python qc/g3_recompute.py --mpn AFE4490RHAT
    python qc/g3_recompute.py --mpn AFE4490RHAT --v1-baseline data/parsed/AFE4490RHAT_xxxx.json
    python qc/g3_recompute.py --all
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import prompt_dryrun as PG                           # noqa: E402
import parse_datasheets as PD                                 # noqa: E402

CTX_DIR = PG.OUT / "v2" / "_ctx"
RESULT_DIR = ROOT / "data" / "qc" / "gates"


def _find_pdf(mpn: str) -> Path | None:
    return PG._find_pdf(mpn)


def ctx_text(mpn: str) -> str:
    """优先读落盘上下文，否则本地解析重生成（零 token）。"""
    p = CTX_DIR / f"{mpn}.txt"
    if p.is_file():
        return p.read_text(encoding="utf-8", errors="replace")
    pdf = _find_pdf(mpn)
    if not pdf:
        return ""
    try:
        _total, gen = PD._iter_pages(pdf)
        text, _used, _truncated = PD.select_pages(
            gen, PD.MAX_PAGES, PD.MAX_CHARS)
    except Exception:                                         # noqa: BLE001
        return ""
    CTX_DIR.mkdir(parents=True, exist_ok=True)
    (CTX_DIR / f"{mpn}.txt").write_text(text, encoding="utf-8")
    return text


def _pick_baseline(mpn: str, prefer: str = "pre6a") -> Path | None:
    """选基线。

    **默认 `pre6a`**：`v2_pre6a_backup/{mpn}.json` 是「同一个 v2 prompt、
    旧上下文」的产物，与 6a 新产物只差选页一项，是**受控对照**——
    G3b 要测的正是选页修复本身的效果。
    用生产 `data/parsed`（v1 prompt + 旧上下文）当基线会混淆 prompt 与
    选页两个变量，那正是旧判据的毛病。
    """
    order = ((PG.OUT / "v2_pre6a_backup" / f"{mpn}.json"),
             (ROOT / "data" / "parsed" / f"{mpn}.json"))
    if prefer == "prod":
        order = tuple(reversed(order))
    for p in order:
        if p.is_file():
            return p
    hits = sorted((ROOT / "data" / "parsed").glob(f"{mpn}_*.json"))
    return hits[0] if hits else None


def run_one(mpn: str, v1_path: Path | None = None,
            ctx_path: Path | None = None,
            baseline: str = "pre6a") -> dict:
    v2_path = PG.OUT / "v2" / f"{mpn}.json"
    if not v2_path.is_file():
        return {"mpn": mpn, "ok": False, "error": "v2 产物缺失"}
    if v1_path is None:
        v1_path = _pick_baseline(mpn, baseline)
    if v1_path is None or not v1_path.is_file():
        return {"mpn": mpn, "ok": False, "error": "v1 基线缺失"}

    v1_doc = json.loads(v1_path.read_text(encoding="utf-8"))
    v2_doc = json.loads(v2_path.read_text(encoding="utf-8"))
    ctx = (Path(ctx_path).read_text(encoding="utf-8", errors="replace")
           if ctx_path and Path(ctx_path).is_file() else ctx_text(mpn))

    stats = PG.g3_migration(v1_doc, v2_doc, ctx)
    gate = PG.gate_g3(stats, ctx)
    return {"mpn": mpn, "ok": True, "stats": stats, "gate": gate,
            "v1": str(v1_path), "v2": str(v2_path), "ctx_chars": len(ctx),
            "baseline_src": ("v2_pre6a_backup" if "v2_pre6a_backup" in
                             str(v1_path) else "data/parsed")}


def _all_mpns() -> list[str]:
    """`--all` 的样本集：扫描 `v2/` 目录实际产物，不再依赖硬编码 SAMPLES。

    原因：6a 只重解了 AFE4490 / AM6421 两件，其中 AM6421 是 6a 新增、
    `SAMPLES` 里没有的。用硬编码清单会静默漏件——本次正是因此先后跑出
    两份互相覆盖、件数不一致的结果。扫目录则自动跟上后续扩样本（6c）。
    """
    v2dir = PG.OUT / "v2"
    if not v2dir.is_dir():
        return list(PG.SAMPLES)
    names = sorted(p.stem for p in v2dir.glob("*.json"))
    return names or list(PG.SAMPLES)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="G3 迁移判据复算（零 LLM 成本）")
    ap.add_argument("--mpn", action="append", default=[], help="型号（可多次）")
    ap.add_argument("--all", action="store_true", help="跑 SAMPLES 全部")
    ap.add_argument("--baseline", choices=("pre6a", "prod"), default="pre6a",
                    help="基线口径：pre6a=同 prompt 旧上下文（受控对照，默认）；"
                         "prod=生产 v1 产物")
    ap.add_argument("--v1-baseline", default="", help="v1 基线 json 路径")
    ap.add_argument("--ctx", default="", help="上下文文本路径")
    ap.add_argument("--out", default="", help="结果 json 路径")
    a = ap.parse_args(argv)

    items = a.mpn or (_all_mpns() if a.all else [])
    if not items:
        ap.error("需要 --mpn 或 --all")

    results = []
    for mpn in items:
        r = run_one(mpn, Path(a.v1_baseline) if a.v1_baseline else None,
                    a.ctx or None, a.baseline)
        results.append(r)
        if not r.get("ok"):
            print(f"[{mpn}] ERROR: {r.get('error')}")
            continue
        g = r["gate"]
        print(f"[{mpn}] 基线={r['baseline_src']}")
        print(f"   G3a={g['G3a']} G3b={g['G3b']}({g['G3b_note']}) "
              f"G3c={g['G3c']} G3d={g['G3d']} G3e={g['G3e']} -> "
              f"{'PASS' if g['pass'] else 'FAIL'}")
        print(f"   改善={g['improved']} 退化={g['regressed']} 消失={g['disappeared']}"
              f"(真值丢失{g['real_value_lost']}/编造清除{g['fabricated_cleared']}) "
              f"新增={g['new']}(含真值{g['new_has_value']}) "
              f"基线占位={g['base_not_specified']} ctx={r['ctx_chars']}字符")
        for rec in r["stats"]["improved"]:
            print(f"   [转真值] {str(rec['v1_name'])[:40]} | "
                  f"{rec['v1_value']!r} -> {rec['v2_value']!r}")
        for d in g.get("lost_detail") or []:
            print(f"   [!真值丢失] {str(d['name'])[:44]} v={d['value']!r}")

    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else RESULT_DIR / "g3_migration_result.json"
    out.write_text(json.dumps(results, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    print(f"\n结果：{out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
