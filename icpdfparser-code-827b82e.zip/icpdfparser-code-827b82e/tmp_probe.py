import sys, time, json
sys.path.insert(0, '.')
from app import db

def snap():
    rows = db.q("SELECT status, COUNT(*) c FROM item GROUP BY status")
    d = {r['status']: r['c'] for r in rows}
    lu = db.q("SELECT COUNT(*) n, SUM(CASE WHEN ok=0 THEN 1 ELSE 0 END) bad FROM llm_usage WHERE created_at >= datetime('now','-30 minutes')")
    ev = db.q("SELECT COUNT(*) n FROM event WHERE created_at >= datetime('now','-30 minutes')")
    return d, lu[0], ev[0]

a, lu, ev = snap()
print("T0", json.dumps(a, ensure_ascii=False), "llm30", lu, "ev30", ev)
