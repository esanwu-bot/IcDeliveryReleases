#!/usr/bin/env bash
# 重新导出 icpdf 库结构 -> sql/schema.sql
#
# 只导结构（--no-data），不含任何数据：
#   - 数据从 data/parsed/*.json 重灌（python json_to_db.py --load），
#     所以结构进 git、数据不进，仓库才不会被几十 GB 撑爆。
#   - 去掉 AUTO_INCREMENT=NN：那是数据状态不是结构，留着会让每次重导都产生 diff 噪音。
#
# 用法：
#   bash sql/dump.sh
#   MYSQLDUMP=/usr/bin/mysqldump bash sql/dump.sh
#   DB_HOST=127.0.0.1 DB_USER=root DB_PASS=root DB_NAME=icpdf bash sql/dump.sh
set -euo pipefail

cd "$(dirname "$0")/.."

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_USER="${DB_USER:-root}"
DB_PASS="${DB_PASS:-root}"
DB_NAME="${DB_NAME:-icpdf}"

# 本地 phpstudy 自带 MySQL 8.0.12；找不到就用 PATH 里的
if [ -z "${MYSQLDUMP:-}" ]; then
  for c in \
    "/d/phpstudy_pro/Extensions/MySQL8.0.12/bin/mysqldump.exe" \
    "/c/phpstudy_pro/Extensions/MySQL8.0.12/bin/mysqldump.exe"
  do
    [ -x "$c" ] && MYSQLDUMP="$c" && break
  done
fi
MYSQLDUMP="${MYSQLDUMP:-mysqldump}"

mkdir -p sql
"$MYSQLDUMP" \
  -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_PASS" \
  --no-data --routines --triggers \
  --set-gtid-purged=OFF --default-character-set=utf8mb4 \
  --databases "$DB_NAME" \
  2> >(grep -v "Using a password" >&2) \
  | sed -E 's/ AUTO_INCREMENT=[0-9]+//' \
  > sql/schema.sql

n_tbl=$(grep -c '^CREATE TABLE' sql/schema.sql || true)
n_view=$(grep -c '^/\*!50001 CREATE VIEW' sql/schema.sql || true)
echo "sql/schema.sql 已更新：${n_tbl} 张表 + ${n_view} 个视图，$(wc -l < sql/schema.sql) 行"
