# sql/

解析结果库（`icpdf`）的结构备份。

| 文件 | 说明 |
|---|---|
| `schema.sql` | 完整结构：9 张表 + 2 个视图。**不含任何数据** |
| `dump.sh` | 重新导出 `schema.sql`（从当前库） |

## 为什么只备份结构，不备份数据

数据从 `data/parsed/*.json` 重灌即可，一条命令的事：

```bash
python json_to_db.py --load
```

而数据本身是几十 GB 量级（60 万型号 × 每型号几十行明细），进 git 会把仓库撑爆。
**结构进版本库、数据靠 JSON 重灌**，这样表结构变更能 review、能回滚，仓库也不会失控。

## 导入

```bash
mysql -h127.0.0.1 -uroot -p --default-character-set=utf8mb4 < sql/schema.sql
```

⚠️ `schema.sql` 里每张表前都有 `DROP TABLE IF EXISTS`，**在已有数据的库上执行会清空这些表**。
它用于「干净重建」或「新环境初始化」，不是增量迁移。

只想建空库、不动现有数据：

```bash
# 建库 + 建表都在一个事务语义里，先确认目标库是空的
mysql -h127.0.0.1 -uroot -p -e "CREATE DATABASE IF NOT EXISTS icpdf DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci"
python json_to_db.py --init        # 走代码里的 DDL，CREATE TABLE IF NOT EXISTS，不会删表
```

日常建表用 `python json_to_db.py --init` 就够了——它和 `schema.sql` 是同一套结构，
只是 `--init` 幂等、不删表，`schema.sql` 是「推倒重建」。

## 重新导出

表结构改过之后（改了 `json_to_db.py` 里的 DDL 并重建过库），跑一次：

```bash
bash sql/dump.sh
```

脚本做了三件事：

1. `--no-data`：只要结构
2. `--routines --triggers`：存储过程/触发器一起带上（当前没有，以后加了不用改脚本）
3. `sed -E 's/ AUTO_INCREMENT=[0-9]+//'`：去掉自增值——那是数据状态不是结构，
   留着会让每次重导都产生无意义的 diff

MySQL 路径自动探测（phpstudy 的 `Extensions/MySQL8.0.12/bin/`），也可用环境变量覆盖：

```bash
MYSQLDUMP=/usr/bin/mysqldump DB_USER=root DB_PASS=xxx bash sql/dump.sh
```

## 表清单

| 表 | 内容 |
|---|---|
| `doc` | 型号主表，一型号一行（窄表，只放要筛选的列） |
| `doc_raw` | 模型原始输出（LONGTEXT），重修可回放 |
| `doc_spec` | 规格明细，长表 `section/name/value/unit/cond` |
| `doc_pin` | 引脚，带 `seq` 保留原始顺序 |
| `doc_ordering` | 订购信息 |
| `doc_alt` | 替代型号 |
| `doc_list` | feature / application / seo_keyword |
| `doc_i18n` | 多语言 title/description/meta |
| `doc_change` | 修订审计，字段级 old → new |
| `v_doc_gap` | 视图：每型号各段条数 |
| `v_spec_name` | 视图：规格项命名清单（做同义词归一用） |

字段含义、设计取舍、踩过的坑见 [`../HANDOFF.md`](../HANDOFF.md) 第 5.⑦ 节。
