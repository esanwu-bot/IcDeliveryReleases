-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: icpdf
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `icpdf`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `icpdf` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;

USE `icpdf`;

--
-- Table structure for table `doc`
--

DROP TABLE IF EXISTS `doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `requested_mpn` varchar(128) NOT NULL DEFAULT '' COMMENT '请求料号（manifest 来的，页面主键）',
  `mpn` varchar(128) NOT NULL COMMENT '解析出的型号，可能被模型改写',
  `brand` varchar(128) NOT NULL DEFAULT '',
  `category` varchar(128) NOT NULL DEFAULT '',
  `subcategory` varchar(128) NOT NULL DEFAULT '',
  `description` text,
  `datasheet_url` varchar(1024) NOT NULL DEFAULT '',
  `pkg_type` varchar(128) NOT NULL DEFAULT '',
  `pkg_pins` int(11) NOT NULL DEFAULT '0',
  `pkg_dimensions` varchar(128) NOT NULL DEFAULT '',
  `temp_operating` varchar(64) NOT NULL DEFAULT '',
  `temp_storage` varchar(64) NOT NULL DEFAULT '',
  `pdf_sha256` char(64) NOT NULL DEFAULT '',
  `pdf_path` varchar(512) NOT NULL DEFAULT '',
  `json_path` varchar(512) NOT NULL DEFAULT '',
  `model_version` varchar(64) NOT NULL DEFAULT '',
  `confidence` decimal(4,3) NOT NULL DEFAULT '0.000' COMMENT '模型自评置信度 0~1',
  `parsed_at` datetime DEFAULT NULL,
  `revision` int(11) NOT NULL DEFAULT '1' COMMENT '重修次数，改一次 +1',
  `status` varchar(16) NOT NULL DEFAULT 'parsed' COMMENT 'parsed/reviewed/verified/published/rejected',
  `note` text,
  `raw_sha256` char(64) NOT NULL DEFAULT '' COMMENT '原文指纹，判断是否变过',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mpn_pdf` (`mpn`,`pdf_sha256`),
  KEY `idx_requested` (`requested_mpn`),
  KEY `idx_brand` (`brand`),
  KEY `idx_status` (`status`),
  KEY `idx_conf` (`confidence`),
  KEY `idx_pkg` (`pkg_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='型号解析主表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_alt`
--

DROP TABLE IF EXISTS `doc_alt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_alt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `seq` smallint(6) NOT NULL DEFAULT '0',
  `mpn` varchar(128) NOT NULL DEFAULT '',
  `manufacturer` varchar(128) NOT NULL DEFAULT '',
  `reason` text,
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`),
  KEY `idx_mpn` (`mpn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='替代型号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_change`
--

DROP TABLE IF EXISTS `doc_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `rev` int(11) NOT NULL,
  `field` varchar(255) NOT NULL COMMENT '扁平路径，如 specs.electrical[3].value',
  `old_value` text,
  `new_value` text,
  `actor` varchar(64) NOT NULL DEFAULT '',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `changed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`,`rev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='修订审计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_i18n`
--

DROP TABLE IF EXISTS `doc_i18n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_i18n` (
  `doc_id` bigint(20) NOT NULL,
  `lang` char(5) NOT NULL,
  `title` varchar(512) NOT NULL DEFAULT '',
  `description` text,
  `meta` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`doc_id`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='多语言文案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_list`
--

DROP TABLE IF EXISTS `doc_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `kind` varchar(24) NOT NULL COMMENT 'feature/application/seo_keyword',
  `seq` smallint(6) NOT NULL DEFAULT '0',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`,`kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='列表类段落';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_ordering`
--

DROP TABLE IF EXISTS `doc_ordering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_ordering` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `seq` smallint(6) NOT NULL DEFAULT '0',
  `mpn` varchar(128) NOT NULL DEFAULT '',
  `package` varchar(128) NOT NULL DEFAULT '',
  `packaging` varchar(64) NOT NULL DEFAULT '',
  `moq` int(11) NOT NULL DEFAULT '0',
  `marking` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`),
  KEY `idx_mpn` (`mpn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订购信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_pin`
--

DROP TABLE IF EXISTS `doc_pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_pin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `seq` smallint(6) NOT NULL DEFAULT '0' COMMENT '原始数组下标；pin_no 会重复（板卡连接器 J1-1/J2-1），不能拿它排序',
  `pin_no` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='引脚定义';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_raw`
--

DROP TABLE IF EXISTS `doc_raw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_raw` (
  `doc_id` bigint(20) NOT NULL,
  `json` longtext NOT NULL COMMENT '模型原始输出，重修可回放',
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='原文留底';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_spec`
--

DROP TABLE IF EXISTS `doc_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doc_spec` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `section` varchar(32) NOT NULL COMMENT 'electrical/absolute_max/...',
  `seq` smallint(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` text,
  `unit` varchar(64) NOT NULL DEFAULT '',
  `cond` varchar(255) DEFAULT NULL COMMENT '测试条件；NULL=原文无此键，空串=原文有但为空。cond 避开保留字 condition',
  PRIMARY KEY (`id`),
  KEY `idx_doc` (`doc_id`,`section`),
  KEY `idx_name` (`name`(64)),
  KEY `idx_sec_name` (`section`,`name`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='规格明细（长表，字段名不固定）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `v_doc_gap`
--

DROP TABLE IF EXISTS `v_doc_gap`;
/*!50001 DROP VIEW IF EXISTS `v_doc_gap`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_doc_gap` AS SELECT 
 1 AS `id`,
 1 AS `requested_mpn`,
 1 AS `mpn`,
 1 AS `pkg_type`,
 1 AS `pkg_pins`,
 1 AS `confidence`,
 1 AS `status`,
 1 AS `revision`,
 1 AS `n_spec`,
 1 AS `n_pin`,
 1 AS `n_order`,
 1 AS `n_alt`,
 1 AS `n_feature`,
 1 AS `n_app`,
 1 AS `n_lang`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_spec_name`
--

DROP TABLE IF EXISTS `v_spec_name`;
/*!50001 DROP VIEW IF EXISTS `v_spec_name`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_spec_name` AS SELECT 
 1 AS `section`,
 1 AS `name`,
 1 AS `n`,
 1 AS `docs`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'icpdf'
--

--
-- Current Database: `icpdf`
--

USE `icpdf`;

--
-- Final view structure for view `v_doc_gap`
--

/*!50001 DROP VIEW IF EXISTS `v_doc_gap`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_doc_gap` AS select `d`.`id` AS `id`,`d`.`requested_mpn` AS `requested_mpn`,`d`.`mpn` AS `mpn`,`d`.`pkg_type` AS `pkg_type`,`d`.`pkg_pins` AS `pkg_pins`,`d`.`confidence` AS `confidence`,`d`.`status` AS `status`,`d`.`revision` AS `revision`,coalesce(`s`.`n`,0) AS `n_spec`,coalesce(`p`.`n`,0) AS `n_pin`,coalesce(`o`.`n`,0) AS `n_order`,coalesce(`a`.`n`,0) AS `n_alt`,coalesce(`f`.`n`,0) AS `n_feature`,coalesce(`ap`.`n`,0) AS `n_app`,coalesce(`i`.`n`,0) AS `n_lang` from (((((((`doc` `d` left join (select `doc_spec`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_spec` group by `doc_spec`.`doc_id`) `s` on((`s`.`doc_id` = `d`.`id`))) left join (select `doc_pin`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_pin` group by `doc_pin`.`doc_id`) `p` on((`p`.`doc_id` = `d`.`id`))) left join (select `doc_ordering`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_ordering` group by `doc_ordering`.`doc_id`) `o` on((`o`.`doc_id` = `d`.`id`))) left join (select `doc_alt`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_alt` group by `doc_alt`.`doc_id`) `a` on((`a`.`doc_id` = `d`.`id`))) left join (select `doc_list`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_list` where (`doc_list`.`kind` = 'feature') group by `doc_list`.`doc_id`) `f` on((`f`.`doc_id` = `d`.`id`))) left join (select `doc_list`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_list` where (`doc_list`.`kind` = 'application') group by `doc_list`.`doc_id`) `ap` on((`ap`.`doc_id` = `d`.`id`))) left join (select `doc_i18n`.`doc_id` AS `doc_id`,count(0) AS `n` from `doc_i18n` group by `doc_i18n`.`doc_id`) `i` on((`i`.`doc_id` = `d`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_spec_name`
--

/*!50001 DROP VIEW IF EXISTS `v_spec_name`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_spec_name` AS select `doc_spec`.`section` AS `section`,`doc_spec`.`name` AS `name`,count(0) AS `n`,count(distinct `doc_spec`.`doc_id`) AS `docs` from `doc_spec` group by `doc_spec`.`section`,`doc_spec`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-22 16:50:47
