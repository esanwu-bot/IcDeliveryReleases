﻿# 客户反馈闭环导入记录 · 2026-10-28

**来源**：用户提供的 QC 发现截图（11 个型号） + 既有 QC 核验记录。
**来源类型**：`INTERNAL_QC`；`customer_reference=QC-2026-10-28`。
**登记人**：`user:admin`；**状态**：已定位 `TRIAGED` 10 个，待复现 `NEEDS_REPRODUCTION` 1 个。
**边界**：只新增问题单与样本关联；未修改 facts / Gold / item；未登记原厂证据、
未登记回归、未做人工验收，全部为未关闭阻断项（P0/P1）。

| Issue | MPN | 批次 | 类型 | 严重度 | 状态 | 本轮发现 / 结论 |
|---|---|---|---|---|---|---|
| CF-QC28-001 | 5962-9053801PA | qc30-20261028-0016 | 电气表解析 | P1 | 已定位 | 0.9 TYP/1.2 MAX V 被写成 0.9~1.2V 范围；漏电流同样丢失角色 → 确认规格语义错误 |
| CF-QC28-002 | 74LVC1G132DCKTG4 | qc30-20261028-0293 | 电气表解析 | P1 | 已定位 | JSON 写 SN74LVC1G132；VCC=0V 条件误读 Ioff=0µA（原 ±10µA）→ 引用器件参数错误；库存别名未认证 |
| CF-QC28-003 | ADC3910S065IRSMT | qc30-20261028-0069 | 电气表解析 | P1 | 已定位 | 24mA 模拟电源电流 MAX 错写为 24mW 功耗（PDIS 58mW TYP）→ 确认错误 |
| CF-QC28-004 | ADS7812B/1K | qc30-20261028-0073 | 型号与封装 | P0 | 待复现 | 订购表未落实 literal 型号，不能猜 UB/1K；漏 DATACLK 输入例外脚注 → 身份待证，不签准确 SKU |
| CF-QC28-005 | AM26C32IDG4 | qc30-20261028-0199 | 引脚映射 | P0 | 已定位 | D/SOIC 应 pin8=GND，却写 pin5=GND 并混入另一封装 NC → 确认引脚错误 |
| CF-QC28-006 | BQ24300DSGR | qc30-20261028-0363 | 电气表解析 | P1 | 已定位 | 输出电压与保护阈值只保留最左数，丢失 MIN/TYP/MAX → 确认限定语丢失 |
| CF-QC28-007 | BUF634PG4 | qc30-20261028-0229 | 型号与封装 | P0 | 已定位 | 精确历史订购表为 PDIP/P/8 脚，页面及替代料写 SOIC-8 → 确认封装错误 |
| CF-QC28-008 | CD74FCT244SM96 | qc30-20261028-0239 | 型号与封装 | P0 | 已定位 | SSOP-SM 错成 SOIC-DW；pin20=VCC 错成 pin11=VCC → 确认封装及引脚错误 |
| CF-QC28-009 | CDC421106RGER | qc30-20261028-0039 | 内容一致性 | P1 | 已定位 | 本款 106.25MHz，正文却使用 100/312.5MHz 家族频点 → 确认型号参数混淆 |
| CF-QC28-010 | CY74FCT245ATSOCT | qc30-20261028-0239 | 引脚映射 | P0 | 已定位 | pin1 应 T/R；映射错位，T/R 高电平 A→B 被写反 → 确认引脚与逻辑错误 |
| CF-QC28-011 | DAC8555IPWG4 | qc30-20261028-0152 | 电气表解析 | P1 | 已定位 | IOIDD 10µA 与另一供电电流 0.65mA 错配 → 确认表内电流字段错配 |

**批次归属**：同一批次可含多个问题（如 `qc30-20261028-0239` 含 CD74 与 CY74FCT245 两个问题）；
交付历史行已显示对应「客户反馈 (N) · 阻断 N」。

**机器可读记录**：`customer_feedback_import_20261028.json`（11 条 issue_key/MPN/batch/状态/样本 ID）。

**当前进度**：11 个问题均为 `TRIAGED`/`NEEDS_REPRODUCTION`，证据/回归/验收为空；
下一步需要补原厂证据、修复记录与定向回归，不能仅凭本记录关闭问题。

---

## 来源更正（2026-10-28，用户确认）

- 11 条问题是 **2026-10-26（周一）客户对“未走 QC 流程的初始交付包”抽查反馈**，
  不是 auto QC 批次产生的问题；`qc30-20261028-*` 只是后续定位样本的批次。
- 生产 issue 的 `source` 已由 `INTERNAL_QC` 更正为 `CUSTOMER`，
  `customer_reference=CUSTOMER-SPOTCHECK-2026-10-26 (IMG-01)`；
  每条 `reproduction_steps` 追加来源说明，审计动作 `source_corrected`。
- 客户描述只作线索：未写 `root_cause_summary`（已证实根因），只写 V2 seed 的
  `root_cause_hypothesis / required_evidence / acceptance_criteria`。

## V2 回溯结果（生产库）

| 项 | 结果 |
|---|---|
| V2 seed MPN 命中 | **11 / 11**（`data/seed_feedback_11.csv`） |
| 严重度 | 保留现有 P0×5 / P1×6，**未把 P0 下调** |
| r5 回归 | **9 FAIL / 2 PASS**（BUF634PG4、DAC8555IPWG4 PASS） |
| 已核验原厂证据挂接 | **10 条**（BUF 3 / CD74 4 / DAC 3） |
| BUF634PG4 修复 | r4 facts 13 处；状态 `REGRESSION_PASSED`（未验收/未关闭） |
| 其余 8 条 | 仍缺证据；回归 FAIL 或待复现 |
| facts / Gold / item | **未改**；Gold 2 frozen / 9 draft；item 20,003 |

- 机器记录见 `customer_feedback_import_20261028.json` 的
  `source_correction / backfill / analyzer_run` 字段。
- pandas QC Analyzer 首次生产快照：`QCA-20261028-143130-2a394c-dc6c`
  （13,504 件 / FAIL 629 / I 组 56 / 候选任务 20）。
- 注意：反馈证据 `#11` 是空草稿（PENDING、无页码/原文），不计入已核验证据；
  可在详情页驳回或补全。
