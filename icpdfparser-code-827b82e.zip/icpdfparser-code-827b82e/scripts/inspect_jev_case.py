#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""离线标注辅助：把「JSON 条目 / JEV 候选行 / PDF 真实行（含 x 坐标）」并排打印，供裁决。

与 `jev_bailian_eval.py --collect` 产出的 cases.jsonl 字段对齐（扁平结构）：
  {mpn, path, value, candidate_count, candidates, page, table, answer, note}

三种用法
--------
  python scripts/inspect_jev_case.py --list
  python scripts/inspect_jev_case.py --show 0 --show 3          # 看题
  python scripts/inspect_jev_case.py --answer 0=1 --note "..."  # 记答案（候选下标）

`--answer` 写的是**候选下标**（与 eval 的 `answer` 语义一致），同时落
`answer_row`（PDF 行号）与 `evidence`（该行原文），供审计复核。

不猜：`--suggest` 只给打分与理由，人（或代理）最终决定；`answer=null` 表示「判不了」。
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PARSED = ROOT / "data" / "parsed"
PDFS = ROOT / "data" / "pdfs"


def load(p: Path) -> list:
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def dump(rows: list, p: Path) -> None:
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(tmp, p)


def find_json(mpn: str) -> Path | None:
    hit = sorted(h for h in PARSED.glob(mpn + "_*.json")
                 if not h.name.endswith(".pre_audit"))
    return hit[0] if hit else None


def find_pdf(mpn: str) -> Path | None:
    hit = sorted(PDFS.glob(mpn + "*.pdf"))
    return hit[0] if hit else None


def entry_of(doc: dict, path: str) -> dict:
    m = re.match(r"specs\.(\w+)\[(\d+)\]", path or "")
    if not m:
        return {}
    arr = (doc.get("specs") or {}).get(m.group(1)) or []
    i = int(m.group(2))
    return arr[i] if 0 <= i < len(arr) else {}


def norm(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()


def toks(s) -> set:
    """数值 + 带字母的条件词（VCC/IOVDD/TA/TJ…），全小写。"""
    s = str(s or "")
    out = {t.lower().lstrip("0") or "0" for t in re.findall(r"[+-]?\d+(?:\.\d+)?", s)}
    out |= {t.lower() for t in re.findall(r"[A-Za-z][A-Za-z0-9]{1,5}", s)}
    return out


def row_cells(row) -> list:
    return [norm(c) for c in row]


def value_in(row, value) -> bool:
    v = norm(value)
    if not v:
        return False
    for c in row_cells(row):
        if v == c:
            return True
    return False


def tables_of(pdf: Path):
    import pymupdf
    from qc import table_audit as T
    with pymupdf.open(str(pdf)) as d:
        return T.scan_tables(d)


def pick_table(tables, page, ti):
    for t in tables:
        if t.get("page") == page and t.get("ti") == ti:
            return t
    return None


def suggest(case: dict, tbl: dict, entry: dict) -> tuple:
    """打分：值在行 + 条件 token 重叠 + 参数名 token 重叠。只作提示，不作结论。"""
    cond_t = toks(entry.get("condition"))
    name_t = toks(entry.get("symbol") or "") | toks(entry.get("name"))
    rows = tbl.get("rows") or []
    scored = []
    for i, c in enumerate(case["candidates"]):
        ri = c.get("row")
        if not isinstance(ri, int) or ri >= len(rows):
            continue
        row = rows[ri]
        v = 1.0 if value_in(row, case["value"]) else 0.0
        cells_t = toks(" ".join(row_cells(row)))
        cond_ov = len(cond_t & cells_t) / len(cond_t) if cond_t else 0.0
        name_ov = len(name_t & cells_t) / len(name_t) if name_t else 0.0
        score = 0.5 * v + 0.3 * cond_ov + 0.2 * name_ov
        scored.append((round(score, 3), i, ri, v, round(cond_ov, 2), round(name_ov, 2)))
    scored.sort(reverse=True)
    return scored


def show(case: dict, idx: int, with_suggest: bool, verbose: bool):
    mpn = case.get("mpn") or ""
    print("=" * 104)
    print(f"[{idx}] {mpn}  page={case.get('page')} table={case.get('table')}  "
          f"path={case.get('path')}  value={case.get('value')!r}  "
          f"ncand={case.get('candidate_count')}  answer={case.get('answer')}")
    jp = find_json(mpn)
    entry = {}
    if jp:
        entry = entry_of(json.loads(jp.read_text(encoding="utf-8")), case.get("path"))
        print("  JSON 条目: " + json.dumps(
            {k: entry.get(k) for k in ("symbol", "name", "condition", "min", "typ", "max",
                                       "unit", "columns", "columns_raw", "value_raw_original")},
            ensure_ascii=False)[:520])
    else:
        print("  !! 找不到 JSON")
    print(f"  候选（JEV 看到的 {case.get('candidate_count')} 行）:")
    for i, c in enumerate(case.get("candidates") or []):
        print(f"    [{i}] row={c.get('row')} sym={c.get('symbol')!r} param={c.get('param')!r} "
              f"cond={c.get('condition')!r} MIN={c.get('min')!r} TYP={c.get('typ')!r} "
              f"MAX={c.get('max')!r} unit={c.get('unit')!r}")

    pdf = find_pdf(mpn)
    if not pdf:
        print("  !! 找不到 PDF")
        return
    tbl = pick_table(tables_of(pdf), case.get("page"), case.get("table"))
    if not tbl:
        print(f"  !! 该 (page,table)=({case.get('page')},{case.get('table')}) 不存在")
        return
    cand_rows = {c.get("row") for c in (case.get("candidates") or [])}
    print(f"  PDF {pdf.name}  P{tbl['page']}/T{tbl['ti']}  header={tbl.get('header')}")
    rows = tbl.get("rows") or []
    xr = tbl.get("xr") or []
    for ri, row in enumerate(rows):
        hit = value_in(row, case.get("value"))
        if not (verbose or hit or ri in cand_rows):
            continue
        mark = ">>>" if ri in cand_rows else "   "
        tag = "  <含值>" if hit else ""
        print(f"  {mark} r{ri:02d}: " + " | ".join(row_cells(row))[:200] + tag)
        if verbose and ri in cand_rows and ri < len(xr) and xr[ri]:
            print("        x: " + " | ".join(
                f"[{c[0]:.0f}-{c[1]:.0f}]" if c else "[空]" for c in xr[ri]))
    if with_suggest:
        sc = suggest(case, tbl, entry)
        print("  建议（仅提示，不自动写）:")
        for s in sc[:3]:
            print(f"    score={s[0]} cand#{s[1]} row={s[2]} 值在行={bool(s[3])} "
                  f"条件重叠={s[4]} 名称重叠={s[5]}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="data/qc/jev/cases.jsonl")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--show", type=int, action="append", default=[])
    ap.add_argument("--show-all", action="store_true")
    ap.add_argument("--suggest", action="store_true")
    ap.add_argument("--verbose", action="store_true", help="候选行也打印 x 坐标")
    ap.add_argument("--answer", action="append", default=[],
                    help="N=候选下标（N=-1 表示判不了，落 null）")
    ap.add_argument("--note", action="append", default=[],
                    help="与 --answer 一一对应的说明（证据/理由）")
    a = ap.parse_args()

    p = Path(a.cases)
    cases = load(p)

    if a.list:
        print(f"{len(cases)} 条 case -> {p}")
        for i, c in enumerate(cases):
            print(f"  [{i:02d}] {c.get('mpn'):<22} p{c.get('page')}/t{c.get('table')}  "
                  f"ncand={c.get('candidate_count')}  value={str(c.get('value'))[:14]:<14} "
                  f"answer={c.get('answer')}")

    ids = range(len(cases)) if a.show_all else a.show
    for i in ids:
        show(cases[i], i, a.suggest, a.verbose)

    if a.answer:
        notes = list(a.note)
        for k, spec in enumerate(a.answer):
            if "=" not in spec:
                print(f"  !! 忽略 {spec}（格式应为 N=下标）")
                continue
            i, v = spec.split("=", 1)
            i = int(i)
            v = int(v)
            if not (0 <= i < len(cases)):
                print(f"  !! 忽略 {spec}（下标越界）")
                continue
            note = notes[k] if k < len(notes) else ""
            if v < 0:
                cases[i]["answer"] = None
                cases[i]["answer_row"] = None
                cases[i]["evidence"] = ""
            else:
                cand = (cases[i].get("candidates") or [])[v]
                cases[i]["answer"] = v
                cases[i]["answer_row"] = cand.get("row")
                row_txt = ""
                pdf = find_pdf(cases[i].get("mpn") or "")
                if pdf:
                    tbl = pick_table(tables_of(pdf), cases[i].get("page"), cases[i].get("table"))
                    if tbl and isinstance(cand.get("row"), int) \
                            and cand["row"] < len(tbl.get("rows") or []):
                        row_txt = " | ".join(row_cells(tbl["rows"][cand["row"]]))
                cases[i]["evidence"] = row_txt[:300]
                if not value_in((row_txt,), cases[i].get("value")):
                    print(f"  [!] case {i} 候选 #{v} 行内没有该值，仍写入（复核时注意）")
            cases[i]["note"] = note
            print(f"  case[{i}] answer={cases[i]['answer']} "
                  f"row={cases[i]['answer_row']} note={note[:60]}")
        dump(cases, p)
        print(f"已写回 {p}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
