# -*- coding: utf-8 -*-
"""百炼 JEV 离线评估：从灰度结果里抽 ``ambiguous_tie``，量出「语义裁判能救多少」。

为什么要先离线：`ambiguous_tie` 的 ROI 全靠**准确率**。召回高但选错行，等于把
`unresolved`（人工兜底、安全）换成 `patched`（已写盘、可能错），是负收益。
所以必须先在已经有 ground truth 的样本上量 precision，再决定是否开
`ICPDF_JEV_TIE=1`。

三种模式
--------
1. ``--collect``：只从 result.jsonl 抽题，落 ``cases.jsonl``。**不需要网络/key**，
   可以先看清"到底有多少道题"。
2. ``--label``：给 ``cases.jsonl`` 里每条补 ``answer``（人工填候选行号），
   作为 ground truth。留空表示"人工也判不了"。
3. ``--run``：逐条问 JEV，与 ``answer`` 比对，落 ``eval.jsonl`` 并打印
   precision / coverage。

用法：
  python scripts/jev_bailian_eval.py --src data/qc/grey500/result.jsonl --collect
  python scripts/jev_bailian_eval.py --cases data/qc/jev/cases.jsonl --run --limit 50
  python scripts/jev_bailian_eval.py --src data/qc/grey500/result.jsonl --pilot --limit 20
"""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _load(path: Path) -> list:
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def _dump(rows: list, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")


def pick_cases(src: Path) -> list:
    """把 findings 里的 ambiguous_tie 摊平成「一题一行」。

    ``src`` 可直接给 `result.jsonl`（只有计数，抽不到题，返回空），也可以给
    **已审计的 JSON 目录**（`metadata.audit.findings` 里带 `candidates` 摘要）。
    后者才是常规用法：`--from-json data/_e2e13`。
    """
    recs = []
    if src.is_dir():
        for p in sorted(src.glob("*.json")):
            if p.name.endswith((".pre_audit", ".pre_pp.json")):
                continue
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            finds = ((d.get("metadata") or {}).get("audit") or {}).get("findings") or []
            recs.append({"mpn": p.stem.split("_")[0], "findings": finds})
    else:
        recs = _load(src)

    cases = []
    for rec in recs:
        for f in rec.get("findings") or []:
            if not isinstance(f, dict):
                continue
            if f.get("ambiguous_reason") != "ambiguous_tie":
                continue
            cands = f.get("candidates") or []
            if len(cands) < 2:
                continue
            cases.append({
                "mpn": rec.get("mpn"),
                "path": f.get("path"),
                "value": f.get("json"),
                "candidate_count": len(cands),
                "candidates": cands,
                "page": f.get("page"), "table": f.get("table"),
                "answer": None,        # 人工标注：候选下标（0-based）或 null=判不了
                "note": "",
            })
    return cases


def _state(case: dict) -> tuple[str, dict]:
    """构造给 JEV 的题面。候选行描述用英文，与线上 `_jev_pick_row` 保持一致。"""
    criteria = {}
    lines = [f"Target JSON entry: path={case['path']}, value={case['value']}"]
    lines.append("Candidate table rows (choose the row that most likely produced this entry):")
    for i, c in enumerate(case["candidates"]):
        cid = f"row_{i}"
        criteria[cid] = (f"Row {i}: Param Name={c.get('param')}, "
                         f"Condition={c.get('condition') or 'Empty'}, "
                         f"MIN={c.get('min') or 'Empty'}, TYP={c.get('typ') or 'Empty'}, "
                         f"MAX={c.get('max') or 'Empty'}")
        lines.append(criteria[cid])
    return "\n".join(lines), criteria


def run_cases(cases: list, limit: int, out: Path) -> dict:
    from qc.jev_client import available, decide_choice, summary

    if not available():
        print("环境未就绪：需要 ICPDF_BAILIAN_WORKSPACE + DASHSCOPE_API_KEY")
        print("（先用 --collect 抽题，配置好 key 再 --run）")

    rows, answered, correct, low = [], 0, 0, 0
    for i, case in enumerate(cases[:limit], 1):
        state, criteria = _state(case)
        got = decide_choice(
            state=state,
            instructions=("Which table row is the most likely source for this electrical "
                          "parameter? Decide strictly by Parameter Name and Test Conditions."),
            criteria=criteria,
        )
        pred = None if not got else int(got[0].split("_", 1)[1])
        conf = None if not got else round(got[1], 3)
        ok = None
        if case.get("answer") is not None:
            ok = (pred == case["answer"])
            if pred is not None:
                answered += 1
            if ok:
                correct += 1
        elif pred is not None:
            answered += 1
        if got is None:
            low += 1
        rows.append({**{k: case[k] for k in ("mpn", "path", "value", "page", "table")},
                     "candidate_count": case["candidate_count"],
                     "pred": pred, "conf": conf, "answer": case.get("answer"),
                     "hit": ok})
        if i % 10 == 0:
            print(f"  {i}/{min(limit, len(cases))}  {summary()}", flush=True)

    _dump(rows, out)
    labeled = sum(1 for r in rows if r["answer"] is not None)
    prec = correct / answered if answered else 0.0
    cov = answered / len(rows) if rows else 0.0
    print(f"\n题数 {len(rows)}｜已回答 {answered}（覆盖 {cov:.1%}）｜"
          f"有标注 {labeled}｜命中 {correct}｜precision {prec:.1%}")
    print(summary())
    print(f"明细 -> {out}")
    return {"n": len(rows), "answered": answered, "labeled": labeled,
            "correct": correct, "precision": prec, "coverage": cov}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="data/qc/grey500/result.jsonl")
    ap.add_argument("--cases", default="data/qc/jev/cases.jsonl")
    ap.add_argument("--out", default="data/qc/jev/eval.jsonl")
    ap.add_argument("--collect", action="store_true", help="只抽题，不调模型")
    ap.add_argument("--run", action="store_true", help="调模型跑 cases.jsonl")
    ap.add_argument("--limit", type=int, default=50)
    a = ap.parse_args()

    if a.collect:
        cases = pick_cases(Path(a.src))
        _dump(cases, Path(a.cases))
        by_n = {}
        for c in cases:
            by_n[c["candidate_count"]] = by_n.get(c["candidate_count"], 0) + 1
        print(f"抽到 ambiguous_tie {len(cases)} 条 -> {a.cases}")
        print("按候选数分布：", dict(sorted(by_n.items())))
        print("下一步：人工把 ground truth 填进 answer 字段，再 --run 量 precision")
        return 0

    if a.run:
        run_cases(_load(Path(a.cases)), a.limit, Path(a.out))
        return 0

    ap.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
