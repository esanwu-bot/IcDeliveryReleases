#!/usr/bin/env python
"""解析后的 JSON -> 网站详情页 HTML 片段（.txt，按型号命名）。

输出结构与 AD5522JSVUZ.txt 完全一致：
    pd-wrap > header.pd-hero + section.pd-sec × 10 + .sr-only

用法:
    python json_to_txt.py                      # 全部 data/parsed/*.json
    python json_to_txt.py --only CDC6C
    python json_to_txt.py --out data/txt --lang en
"""
from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path
from contextvars import ContextVar
from qc.scope_contract import BOARD_TYPES, canonical_view
from qc import ac_quarantine
from qc.range_guard import safe_range

_RENDER_DIAGNOSTICS = ContextVar("render_diagnostics", default=None)

#: 事实表（`qc/fact_acceptance.py`）对本型号逐行给出的结论，`label → verdict`。
#: 有它就**只**按它打 †，不再看 JSON 的 `verification.status` —— 两套尺子
#: 必然分叉，V5 复审就是被这一点咬住的。
_FACTS_VERDICTS = ContextVar("facts_verdicts", default=None)

#: 事实表结论里**不需要**打 † 的（坐标级 / 容器级证据）。
_FACTS_OK = frozenset({"verified_row", "verified_paragraph",
                       "verified_value", "verified"})

#: 多条候选时取最弱的那个（† 宁可多打）。
#: `column_collapse`（2026-11-03 外审 V1）必须显式列进来：取值处用的是
#: `_FACTS_RANK.get(x, 99)`，**不在表里的结论会被当成 99（最强）** ——
#: 漏加这一项，塌缩行的结论会被同名的「已锚定」行盖掉，† 一个都不打。
_FACTS_RANK = {"verified_row": 5, "verified_paragraph": 4, "verified_value": 4,
               "verified": 4, "value_on_label_page": 3, "value_in_pdf": 2,
               "partial": 1, "unchecked": 0, "column_collapse": 0,
               "not_found": -1}

ROOT = Path(__file__).resolve().parent
PARSED = ROOT / "data" / "parsed"
OUT = ROOT / "data" / "txt"

BADGE = {"intro": "P", "benefits": "K", "specs": "S", "package": "P",
         "pinout": "P", "equiv": "E", "mfr": "M", "app": "A", "faq": "Q", "notice": "D"}

# 应用图标：读 data/app_images.csv（运营维护的 16 类命名表），按关键词命中
APP_IMG_CSV = ROOT / "data" / "app_images.csv"
DEFAULT_ICON = "app-industrial-automation.png"

# 规则按「特异性从高到低」排序，先命中先用；key 与 app_images.csv 的 image 文件名主干一致
APP_RULES = [
    ("app-aerospace-defense", ("aerospace", "defense", "military", "avionics", "radar",
                              "electronic warfare", "sigint", "elint", "space-grade")),
    ("app-medical-electronics", ("medical", "patient", "diagnostic", "imaging", "ecg",
                                 "ultrasound", "healthcare", "clinical",
                                 "medical instrumentation")),
    ("app-security-surveillance", ("surveillance", "cctv", "access control", "biometric",
                                   "video doorbell", "security camera")),
    ("app-robotics", ("robot", "robotic", "drone", "uav", "lidar", "gimbal", "cobot")),
    ("app-electric-vehicles-ev", ("ev", "electric vehicle", "charging station", "charger",
                                  "traction", "onboard charger", "obc", "battery electric")),
    ("app-energy-storage", ("energy storage", "battery management", "bms", "supercapacitor",
                            "ups", "uninterruptible")),
    ("app-renewable-energy", ("solar", "photovoltaic", "pv", "wind turbine", "mppt",
                              "power optimizer", "inverter", "micro inverter")),
    ("app-data-center", ("data center", "server", "rack", "cloud", "ssd", "hdd",
                         "storage area network")),
    ("app-industrial-iot-iiot", ("iiot", "iot", "sensor node", "wireless sensor",
                                 "telemetry", "edge node", "smart meter")),
    ("app-communications-networking", ("communication", "network", "ethernet", "telecom",
                                       "optical", "line card", "satcom", "satellite",
                                       "sdr", "rf", "5g", "802.11", "base station",
                                       "transceiver", "radio")),
    ("app-test-measurement", ("test", "measurement", "instrument", "instrumentation",
                              "data acquisition", "oscilloscope", "dmm", "ate",
                              "signal monitoring", "source measure", "smu", "calibrat")),
    ("app-smart-home", ("smart home", "home appliance", "air conditioner", "thermostat",
                        "lighting", "hvac", "appliance", "smart plug", "refrigerator")),
    ("app-automotive-electronics", ("automotive", "vehicle", "adas", "ecu", "can bus",
                                    "lin bus", "infotainment", "powertrain", "obd")),
    ("app-power-management", ("power supply", "power supplies", "dc-dc", "dc/dc",
                              "regulator", "ldo", "buck", "boost", "converter", "pmic",
                              "smps", "voltage reference", "power management")),
    ("app-consumer-electronics", ("consumer", "portable", "wearable", "audio", "smartphone",
                                  "tablet", "set-top", "toy", "handheld", "a/v receiver",
                                  "av receiver", "soundbar")),
    ("app-industrial-automation", ("industrial", "automation", "plc", "ipc", "motor",
                                   "motor control", "motor drive", "servo", "stepper",
                                   "actuator", "process control", "weigh scale",
                                   "transducer", "relay", "factory")),
]


def _load_app_images() -> dict[str, str]:
    """image 文件名主干 -> 文件名（以运营的 CSV 为准，缺失的规则自动失效）。"""
    out: dict[str, str] = {}
    if not APP_IMG_CSV.exists():
        return out
    import csv
    with open(APP_IMG_CSV, encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            img = (row.get("image") or "").strip()
            if img:
                out[img.rsplit(".", 1)[0]] = {
                    "image": img,
                    "category": (row.get("category") or "").strip()
                                or img.rsplit(".", 1)[0].replace("app-", "").replace("-", " ").title(),
                }
    return out


APP_IMAGES = _load_app_images()


def _hit(text: str, kw: str) -> bool:
    """词边界匹配 + 复数容错，避免 'ups' 命中 'startups'、'ev' 命中 'level'。"""
    return re.search(rf"(?<![a-z0-9]){re.escape(kw)}s?(?![a-z0-9])", text) is not None


def _best(app: str) -> str | None:
    """按命中关键词长度加权打分（长词更具体），同分取规则表靠前的一条。"""
    low = (app or "").lower()
    best, best_score = None, 0
    for key, kws in APP_RULES:
        if key not in APP_IMAGES:
            continue
        score = sum(len(k) for k in kws if _hit(low, k))
        if score > best_score:
            best, best_score = key, score
    return best


def pick_icon(app: str) -> str:
    """应用一句话 -> 站内图片文件名。"""
    rec = APP_IMAGES.get(_best(app) or "app-industrial-automation")
    return rec["image"] if rec else DEFAULT_ICON


def pick_category(app: str) -> str:
    """同一套规则反查类别名（用于 img alt / 结构化数据）。"""
    rec = APP_IMAGES.get(_best(app) or "app-industrial-automation")
    return rec["category"] if rec else "Industrial Automation"


def esc(s) -> str:
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def clean(s) -> str:
    t = re.sub(r"\s+", " ", str(s or "")).strip()
    # 历史数据值层偶带单层 HTML 实体（&gt; / &amp;），esc() 再转一次就成了双层
    # （&amp;gt;，浏览器显示 "&gt;" 字面量）。这里统一解回裸字符，输出转义只由 esc() 负责。
    if "&" in t:
        t = html.unescape(t)
    return t


def first_sentence(s: str, max_words: int = 30) -> str:
    """首句截断：hero 与 overview 共用同一段 description 时，hero 只给第一句，
    避免「Hero 与 Overview 一字不差」的重复观感。中英日句末标点都认。"""
    s = clean(s)
    if not s:
        return s
    m = re.match(r"^(.{40,320}?[.!?。！？])(?:\s|$)", s)
    if m and len(m.group(1).split()) <= max_words + 10:
        return m.group(1)
    words = s.split()
    if len(words) <= max_words:
        return s
    return " ".join(words[:max_words]).rstrip(",;:") + "…"


# overview 段裁掉 hero 已用首句后，剩余文本常以代词开头（"It operates at…" /
# "Er ist in…" / "Se suministra…"）。代词失去先行语会变成病句，这里按语种把
# 代词换成型号名。只覆盖确定性高的短代词，长尾不猜。
_PRONOUN_HEADS = {
    "en": [("it also", "{m} also"), ("it", "{m}"), ("this device", "{m}"),
           ("the device", "{m}"), ("the part", "{m}"), ("these", "{m}"),
           ("they", "{m}"), ("this", "{m}")],
    "de": [("das gerät", "{m}"), ("es", "{m}"), ("er", "{m}"), ("sie", "{m}"),
           ("dieser", "{m}"), ("diese", "{m}")],
    "es": [("el dispositivo", "{m}"), ("se", "{m} se"), ("esta", "{m}"),
           ("este", "{m}"), ("estos", "{m}")],
}


def _lead_sentence(s: str, max_len: int = 320) -> str:
    """取描述的第一个**完整句**（含句末标点）。中英日句末标点都认。

    与 first_sentence 的区别：这里不按词数硬截，保证 hero 与 overview 共用
    同一个完整句，裁前缀时不会切在句子中间（CF-QC28-012）。
    """
    s = clean(s)
    m = re.match(r"^(.{15,%d}?[。！？.!?])(?=\s|$|[^\x00-\x7f])" % max_len, s)
    return m.group(1) if m else ""


def _strip_prefix(desc: str, hero: str) -> str | None:
    """从 desc 中去掉 hero 已用过的前缀，返回剩余部分（None = 不是前缀）。

    容忍两种现实差异：hero 被 first_sentence 加了省略号；译文在型号与助词
    之间插了空格（"DS80…/NOPBは" vs "DS80…/NOPB は"）。所以比较时忽略空白。
    """
    key = re.sub(r"\s+", "", re.sub(r"[….]+$", "", hero.strip())).lower()
    if len(key) < 20:
        return None
    d = desc.strip()
    cnt = 0
    for i, ch in enumerate(d):
        if ch.isspace():
            continue
        if cnt >= len(key):
            return d[i:]
        if ch.lower() != key[cnt]:
            return None
        cnt += 1
    return "" if cnt >= len(key) else None


def _depronoun(text: str, mpn: str, lang: str) -> str:
    """把段首代词换成型号名，避免 overview 段首句指代落空。"""
    low = text.lower()
    for pron, tpl in _PRONOUN_HEADS.get(lang, []):
        if not low.startswith(pron):
            continue
        tail = text[len(pron):]
        if tail[:1].isalpha():      # 只是词首巧合（"Itself"/"estimate"），不算代词
            continue
        return tpl.format(m=mpn) + tail
    return text


# ---------------------------------------------------------------- 多语言静态词条
# 模板级标题/表头/标签（有限集合，代码内置，零 API 成本）。
# 叙述性内容（hero/概述/特性/应用）来自 JSON 的 multi_language[lang]，
# 数据表（规格/绝对最大值/引脚）为全球通用符号数值，各语言页保持一致。
STATIC_I18N = {
    "en": {
        "overview_title": "{mpn} Overview", "key_benefits": "Key Benefits",
        "electrical_specs": "Electrical Specifications", "package": "Package",
        "scope_onboard": ("The values below describe the onboard {device} device; "
                          "they are not limits for the assembled board."),
        "scope_onboard_plain": ("The values below describe the device assembled on this "
                                "board; they are not limits for the assembled board."),
        "scope_onboard_plain_dev": "onboard device",
        "specs_onboard_elec_title": "On-board Device Electrical Specifications ({device})",

        "specs_verify_all_page": (
            "All {total} entries on this page are anchored to the source PDF "
            "({detail}). Anchoring proves each value is bound to a specific table row "
            "or text entry (page + bounding box + reproducible fingerprint); it does not "
            "by itself prove that column roles (MIN/TYP/MAX), test conditions or "
            "footnotes have been reviewed."),
        "specs_lbl_electrical": "electrical", "specs_lbl_absmax": "absolute maximum",
        "specs_lbl_thermal": "thermal", "specs_lbl_esd": "ESD", "specs_lbl_ac": "AC",
        "pinout": "Pinout", "equiv": "Orderable and Design Alternatives",
        "manufacturer": "Manufacturer", "applications": "Applications",
        "faq": "Frequently Asked Questions", "notice": "Important Notice",
        "insight": "Technical Insight",
        "th_param": "Parameter", "th_value": "Value", "th_cond": "Conditions and Context",
        "th_limit": "Limit", "th_notes": "Notes",
        "th_orderable": "Orderable Option", "th_order_diff": "Order-Code Difference",
        "th_packing": "Packing or Package", "th_selection": "Selection Check",
        "caps_prefix": "Key capabilities include {list}.",
        "used_prefix": "It is used in {list}.",
        "absmax_warn": "<strong>Absolute maximum ratings</strong> — never operate at or beyond these limits.",
        "specs_not_stated": "Electrical specifications are not stated in the source document.",
        "board_specs_not_stated": (
            "Board-level electrical specifications are not stated in the source document. "
            "The source PDF is the datasheet of the onboard {device}, not the evaluation "
            "board user guide; refer to the board user guide for rail limits, jumper "
            "defaults and connector ratings."),
        "board_source_no_guide": (
            "The source document for this page is the {mfr} datasheet of the onboard "
            "{device}, not the evaluation board user guide."),
        "board_values_from_guide": (
            "The board-level values on this page come from the evaluation board user guide."),
        "board_mfr_source": (
            "The document on file is the datasheet of the onboard {device}; the evaluation "
            "board user guide is the controlling record for board-level settings."),
        "typical_case": "Typical case:", "documented_orderable": "Documented orderable",
        "specs_cond_default": "Datasheet conditions apply.",
        # 核验状态披露（Reviewer V3 新-1）：角标 † 的含义必须写在表头上方，
        # 不能只藏在 JSON 里。占位 {n}=未核验条数 {total}=总条数。
        "specs_verify_note": (
            "{n} of {total} entries below are marked unverified (†) — the value was kept "
            "as extracted, but it came from the language model rather than deterministic "
            "parsing, or its test condition / column roles could not be matched back to a "
            "datasheet row. Confirm against the original datasheet before design use."),
        "specs_verify_note_amax": (
            "{n} of {total} absolute-maximum entries are marked unverified (†)."),

        "specs_verify_all": (
            "All {total} entries below are anchored to the source PDF — each value was replayed against a specific table row or text entry (page + bounding box + reproducible fingerprint). Anchoring proves the value is bound to that row; it does not by itself prove that column roles (MIN/TYP/MAX), test conditions or footnotes have been reviewed."),
        "specs_thermal_title": "Thermal resistance",
        "specs_esd_title": "ESD ratings",
        "specs_ac_withheld": (
            "{n} AC rows were extracted from the source datasheet but are withheld from this page: their MIN/TYP/MAX column roles or their provenance could not be validated (a unit or footnote occupied a value cell, or the row was copied from another container without its own bbox/row fingerprint). The raw rows are kept in `specs.unresolved_ac_rows` for manual review. AC performance is therefore empty here by design, not absent from the datasheet."
        ),
        "specs_ac_escape_withheld": (
            "{n} AC rows in the on-board device electrical table were withheld from this page: they were copied from another container without their own bbox/row fingerprint, so they cannot be replayed against the source PDF and may not belong to this device. The raw rows remain in the source JSON for manual review."
        ),
        "specs_ac_title": "AC performance",
        "specs_ac_note": (
            "Extracted deterministically from the AC characteristics table of the source "
            "datasheet, keeping the test conditions that select each row. Rows differ by "
            "input frequency, input amplitude and channel mode — compare like with like."),
        # 文档类型名词（Reviewer P1）：源文件是 User's Guide 时不能称 datasheet。
        "doc_datasheet": "datasheet", "doc_user_guide": "user guide",
        "doc_application_note": "application note", "doc_white_paper": "white paper",
        "doc_manual": "manual", "doc_generic": "document",
        "doc_revision_line": "Document revision: {doc_id}{rev_label}, revised {revised}.",
        "specs_cond_missing": (
            "{n} entries above carry no extracted test condition — the value is only valid "
            "under the conditions of the corresponding table in the source document; confirm "
            "them there before design use."),
        "values_source": "The values on this page come from the {mfr} {doc}",
        "source_pdf": "source PDF",
        "absmax_row": "Absolute maximum rating.",
        "alt_reason_default": "Alternative",
        "alt_row_note": "Confirm pin compatibility, ratings and lifecycle before substitution.",
        "mark_default": "Verify marking on the current datasheet.",
        "pinout_fallback": "See datasheet pin functions table.",
        "pinout_intro": "The {pkg} pin assignment groups {n} unique pin functions across {m} terminals.",
        "order_check": "<strong>Order-code check:</strong> These entries are documented in the {mfr} ordering information for {mpn}, but none is an automatic substitute. Recheck the complete order code, package, temperature range, packing, marking, lifecycle and current manufacturer documentation before a design or purchasing change.",
        "mfr_line1": "{mfr} manufactures {mpn} as a {pname}.",
        "mfr_line2_pre": "The controlling technical record is the manufacturer {doc}, available at",
        "mfr_line2_nolink": "The controlling technical record is the manufacturer {doc}.",
        "mfr_link": "this link",
        "mfr_line2_post": "Confirm the latest revision, lifecycle status, electrical limits, pin assignment and package drawing before release.",
        "app_example": "A design for {a} can use {mpn} after the supply rails, operating temperature ({op_temp}), interface timing and package thermal path are verified for the target system.",
        "board_app_example": "The {mpn} evaluation board is used for {a}; verify the rail, jumper and connector settings against the board user guide before connecting a target system.",
        "op_temp_default": "as specified",
        "notice_eng": "<strong>Engineering use:</strong> Technical values on this page are tied to the {mfr} datasheet for {mpn}",
        "notice_eng_board_no_guide": (
            "<strong>Engineering use:</strong> The source document on file is the {mfr} "
            "datasheet of the onboard {device}, not the evaluation board user guide for {mpn}"),
        "notice_eng_post": "Verify rails, temperature limits, timing, pinout and package in the final system.",
        "notice_eng_post_board": "Verify rails, temperature limits, timing and the board interfaces in the final system.",
        "board_device_unknown": "This board is populated with more than one device; refer to the official board schematic for the exact bill of materials.",
        "notice_order": "<strong>Order-code control:</strong> Other orderables and evaluation boards are comparison paths only. Verify the complete model, package, temperature range, packing, marking and lifecycle before substitution or purchase.",
        "insight_q": "What should be checked when designing with {mpn}?",
        "sr_only": "{mpn} overview with benefits, technical insight, electrical specifications, {pkg} details, pinout, applications, orderable alternatives and FAQs.",
        "sr_only_board": "{mpn} overview with benefits, technical insight, onboard device specifications, board details, applications, orderable options and FAQs.",
        "board_fact": "{mpn} is an evaluation module assembled as a printed circuit board, with the onboard <strong>{device}</strong> in a {pkg} package",
        "board_fact_plain": "{mpn} is an evaluation module assembled as a printed circuit board",
        "board_pkg_title": "<strong>{mpn}</strong> is an evaluation board (assembled PCB), not a packaged IC.",
        "board_onboard": "The board is assembled with the onboard device <strong>{device}</strong>, mounted in a {pkg} package.",
        "board_dims": "Board outline is approximately {dims}; confirm the mechanical drawing and connector placement in the evaluation board user guide before panel or enclosure design.",
        "board_pinout": "The pin assignment below documents the onboard {device} in its {pkg} package — {n} unique pin functions across {m} terminals.",
        "board_mfr": "{mfr} offers {mpn} as an evaluation platform built around the onboard {device}.",
        "sep": ", ",
    },
    "ja": {
        "overview_title": "{mpn} の概要", "key_benefits": "主な特長",
        "electrical_specs": "電気仕様", "package": "パッケージ",
        "scope_onboard": "以下の値は搭載デバイス {device} の仕様であり、組み立て基板全体の限界値ではありません。",
        "scope_onboard_plain": "以下の値は基板上に実装されたデバイスの仕様であり、組み立て基板全体の限界値ではありません。",
        "scope_onboard_plain_dev": "搭載デバイス",
        "specs_onboard_elec_title": "搭載デバイス {device} の電気仕様",

        "specs_verify_all_page": (
            "このページの全 {total} 項目が元 PDF にアンカーされています（{detail}）。"
            "アンカーは各値が特定の表の行・段落に結び付いていることの証明であり、"
            "列の役割（MIN/TYP/MAX）、試験条件、脚注まで確認済みであることを単独では意味しません。"),
        "specs_lbl_electrical": "電気仕様", "specs_lbl_absmax": "絶対最大定格",
        "specs_lbl_thermal": "熱抵抗", "specs_lbl_esd": "ESD", "specs_lbl_ac": "AC",
        "pinout": "ピン配置", "equiv": "発注可能品と代替設計",
        "manufacturer": "メーカー", "applications": "アプリケーション",
        "faq": "よくある質問", "notice": "重要な注意事項",
        "insight": "技術的インサイト",
        "th_param": "パラメータ", "th_value": "値", "th_cond": "条件・補足",
        "th_limit": "制限値", "th_notes": "備考",
        "th_orderable": "発注コード", "th_order_diff": "注文コードの違い",
        "th_packing": "梱包・パッケージ", "th_selection": "選定チェック",
        "caps_prefix": "主な特長：{list}。",
        "used_prefix": "用途：{list}。",
        "absmax_warn": "<strong>絶対最大定格</strong> — この制限値以上で動作させないでください。",
        "specs_not_stated": "電気仕様は元の資料に記載されていません。",
        "typical_case": "典型的な使用例：", "documented_orderable": "記載の発注可能品",
        "specs_cond_default": "データシートの条件に従います。",
        "specs_verify_note": (
            "下記 {total} 件のうち {n} 件に未検証の印（†）を付けています。値は抽出結果の"
            "まま保持していますが、言語モデルによる抽出であり、試験条件または列の役割を"
            "データシートの行に照合できていません。設計に使用する前に原典のデータシートで"
            "確認してください。"),
        "specs_verify_note_amax": (
            "絶対最大定格 {total} 件のうち {n} 件に未検証の印（†）を付けています。"),

        "specs_verify_all": (
            "下記 {total} 件はすべて原典 PDF に紐付け済みです。各値は特定の表行または本文項目（ページ・座標・再計算可能な指紋）に対して照合しています。これは値が当該行に結び付いていることの証明であり、列の役割（MIN/TYP/MAX）・試験条件・脚注まで確認済みという意味ではありません。"),
        "specs_thermal_title": "熱抵抗",
        "specs_esd_title": "ESD 定格",
        "specs_ac_withheld": (
            "{n} 件の AC 行はソースのデータシートから抽出されましたが、MIN/TYP/MAX の列役割またはデータの由来を検証できなかったため（単位や脚注が数値欄を占有した、または他のコンテナから独立した座標・行指紋なしで複製された）、このページには掲載していません。元の行は `specs.unresolved_ac_rows` に保持しており、列の再定義と由来の確認は人手で行う必要があります。AC 特性が空欄なのは「データシートに記載がない」からではなく、「未検証のため意図的に除外している」ためです。"
        ),
        "specs_ac_escape_withheld": (
            "オンボードデバイスの電気仕様表にある {n} 件の AC 行は、このページへの掲載を見送りました。独自の bbox/行指紋を持たずに別コンテナから複製されたため、元の PDF に対して再生できず、このデバイスの行であることも確認できません。元の行はソース JSON に残しており、人手で確認できます。"
        ),
        "specs_ac_title": "AC 特性",
        "specs_ac_note": (
            "原厂データシートの AC 特性表から決定的に抽出し、各行を選ぶ試験条件も併記しています。"
            "入力周波数・入力振幅・チャネルモードが行ごとに異なるため、同一条件どうしで比較してください。"),
        "doc_datasheet": "データシート", "doc_user_guide": "ユーザーガイド",
        "doc_application_note": "アプリケーションノート", "doc_white_paper": "ホワイトペーパー",
        "doc_manual": "マニュアル", "doc_generic": "ドキュメント",
        "doc_revision_line": "文書リビジョン：{doc_id}{rev_label}、{revised} 改訂。",
        "specs_cond_missing": (
            "上記のうち {n} 件は試験条件を抽出できていません。値は原典の対応表の条件でのみ"
            "成立するため、設計前に原典で確認してください。"),
        "values_source": "本ページの値は {mfr} の{doc}に基づきます",
        "source_pdf": "原本 PDF",
        "absmax_row": "絶対最大定格。",
        "alt_reason_default": "代替品",
        "alt_row_note": "代替の前にピン互換性・定格・ライフサイクルを確認してください。",
        "mark_default": "最新のデータシートでマーキングを確認してください。",
        "pinout_fallback": "データシートのピン機能表を参照してください。",
        "pinout_intro": "{pkg} のピン割り当ては、{m} 端子に {n} 種類のピン機能を割り当てたものです。",
        "order_check": "<strong>注文コード確認：</strong> これらの項目は {mfr} が {mpn} 向けに公表している発注情報に基づきますが、自動的な代替品ではありません。設計・購買変更の前に、完全な注文コード、パッケージ、温度範囲、梱包、マーキング、ライフサイクルおよび最新のメーカー文書を再確認してください。",
        "mfr_line1": "{mfr} は {mpn} を {pname} として製造しています。",
        "mfr_line2_pre": "技術的な一次情報はメーカーの{doc}で、次のリンクから参照できます：",
        "mfr_line2_nolink": "技術的な一次情報はメーカーの{doc}です。",
        "mfr_link": "このリンク",
        "mfr_line2_post": "リリース前に最新リビジョン、ライフサイクル状況、電気的制限、ピン割り当て、パッケージ図面を確認してください。",
        "app_example": "{a} の設計では、電源レール、動作温度（{op_temp}）、インターフェースのタイミング、パッケージの熱経路を対象システムで検証したうえで {mpn} を使用できます。",
        "op_temp_default": "仕様の範囲内",
        "notice_eng": "<strong>工学利用：</strong> 本ページの技術値は {mfr} の {mpn} データシートに基づきます",
        "notice_eng_post": "最終システムではレール、温度制限、タイミング、ピン配置、パッケージを検証してください。",
        "notice_eng_post_board": "最終システムではレール、温度制限、タイミング、ボードのインターフェースを検証してください。",
        "board_device_unknown": "本ボードには複数のデバイスが実装されています。正確な部品表は公式のボード回路図を参照してください。",
        "notice_order": "<strong>注文コード管理：</strong> 他の発注可能品および評価ボードは比較検討用の参考情報です。代替・購入の前に完全な型番、パッケージ、温度範囲、梱包、マーキング、ライフサイクルを確認してください。",
        "insight_q": "{mpn} を使った設計で確認すべき点は？",
        "sr_only": "{mpn} の概要：特長、技術的インサイト、電気仕様、{pkg} の詳細、ピン配置、アプリケーション、発注可能な代替品、よくある質問。",
        "sr_only_board": "{mpn} の概要：特長、技術的インサイト、オンボードデバイスの仕様、ボードの詳細、アプリケーション、発注可能な品目、よくある質問。",
        "board_fact": "{mpn} は印刷基板として実装された評価モジュールで、オンボードデバイス <strong>{device}</strong>（{pkg} パッケージ）を搭載しています",
        "board_fact_plain": "{mpn} は印刷基板として実装された評価モジュールです",
        "board_pkg_title": "<strong>{mpn}</strong> は実装済み評価ボード（PCB）であり、パッケージ IC ではありません。",
        "board_onboard": "本ボードはオンボードデバイス <strong>{device}</strong>（{pkg} パッケージ実装）を搭載しています。",
        "board_dims": "基板外形は約 {dims} です。パネルや筐体の設計前に、評価ボードユーザーガイドの機械図面とコネクタ配置を確認してください。",
        "board_pinout": "以下のピン割り当ては、オンボード {device}（{pkg} パッケージ）のものです。{m} 端子に {n} 種類のピン機能が割り当てられています。",
        "board_mfr": "{mfr} は、オンボード {device} を中核とする評価プラットフォームとして {mpn} を提供しています。",
        "sep": "、",
    },
    "ko": {
        "overview_title": "{mpn} 개요", "key_benefits": "주요 장점",
        "electrical_specs": "전기 사양", "package": "패키지",
        "scope_onboard": "아래 값은 온보드 {device} 소자의 규격이며, 조립된 보드 전체의 한계값이 아닙니다.",
        "scope_onboard_plain": "아래 값은 보드에 실장된 디바이스의 규격이며, 조립된 보드 전체의 한계값이 아닙니다.",
        "scope_onboard_plain_dev": "온보드 디바이스",
        "specs_onboard_elec_title": "온보드 {device} 전기 사양",

        "specs_verify_all_page": (
            "이 페이지의 {total}개 항목 모두 원본 PDF에 앵커되어 있습니다({detail}). "
            "앵커링은 각 값이 특정 표 행이나 문단에 결속되었음을 뜻하며, 열 역할"
            "(MIN/TYP/MAX)·시험 조건·각주까지 검토되었음을 단독으로 보증하지는 않습니다."),
        "specs_lbl_electrical": "전기 사양", "specs_lbl_absmax": "절대 최대 정격",
        "specs_lbl_thermal": "열저항", "specs_lbl_esd": "ESD", "specs_lbl_ac": "AC",
        "pinout": "핀 배열", "equiv": "주문 가능 품목 및 대체 설계",
        "manufacturer": "제조사", "applications": "애플리케이션",
        "faq": "자주 묻는 질문", "notice": "중요 공지",
        "insight": "기술 인사이트",
        "th_param": "파라미터", "th_value": "값", "th_cond": "조건 및 참고",
        "th_limit": "제한값", "th_notes": "참고",
        "th_orderable": "주문 코드", "th_order_diff": "주문 코드 차이",
        "th_packing": "포장/패키지", "th_selection": "선정 확인",
        "caps_prefix": "주요 기능: {list}.",
        "used_prefix": "용도: {list}.",
        "absmax_warn": "<strong>절대 최대 정격</strong> — 이 한계 이상으로 동작시키지 마십시오.",
        "specs_not_stated": "전기 사양은 원본 문서에 명시되어 있지 않습니다.",
        "typical_case": "일반적인 사례:", "documented_orderable": "문서화된 주문 가능 품목",
        "specs_cond_default": "데이터시트의 조건이 적용됩니다.",
        "specs_verify_note": (
            "아래 {total}개 항목 중 {n}개에 미검증 표시(†)가 붙어 있습니다. 값은 추출된 "
            "그대로 유지했지만 언어 모델이 추출한 값이며, 시험 조건이나 열 역할을 "
            "데이터시트 행과 대조하지 못했습니다. 설계에 사용하기 전에 원본 "
            "데이터시트에서 확인하십시오."),
        "specs_verify_note_amax": (
            "절대 최대 정격 {total}개 중 {n}개에 미검증 표시(†)가 붙어 있습니다."),

        "specs_verify_all": (
            "아래 {total}개 항목은 모두 원본 PDF에 연결되어 있습니다. 각 값은 특정 표 행 또는 본문 항목(페이지·좌표·재계산 가능한 지문)과 대조되었습니다. 이는 값이 해당 행에 연결되었다는 뜻이며, 열 역할(MIN/TYP/MAX)·시험 조건·각주까지 검토되었다는 의미는 아닙니다."),
        "specs_thermal_title": "열 저항",
        "specs_esd_title": "ESD 정격",
        "specs_ac_withheld": (
            "{n}개의 AC 행은 원본 데이터시트에서 추출되었지만 MIN/TYP/MAX 열 역할 또는 데이터 출처를 검증할 수 없어(단위나 각주가 값 칸을 차지했거나, 다른 컨테이너에서 독립 좌표·행 지문 없이 복제됨) 이 페이지에 게시하지 않았습니다. 원본 행은 `specs.unresolved_ac_rows` 에 보관되어 있으며 열 재정의와 출처 확인은 수작업으로 진행해야 합니다. AC 특성이 비어 있는 것은 데이터시트에 없어서가 아니라 미검증으로 의도적으로 제외했기 때문입니다."
        ),
        "specs_ac_escape_withheld": (
            "온보드 디바이스 전기 사양 표에 있던 {n}개의 AC 행은 이 페이지 게시를 보류했습니다. 자체 bbox/행 지문 없이 다른 컨테이너에서 복제되었기 때문에 원본 PDF로 재현할 수 없고 이 디바이스의 행인지도 확인할 수 없습니다. 원본 행은 소스 JSON에 남아 있어 수동으로 검토할 수 있습니다."
        ),
        "specs_ac_title": "AC 성능",
        "specs_ac_note": (
            "원본 데이터시트의 AC 특성 표에서 결정적으로 추출했으며, 각 행을 선택하는 "
            "시험 조건도 함께 표기합니다. 입력 주파수·입력 진폭·채널 모드가 행마다 다르므로 "
            "동일 조건끼리 비교하십시오."),
        "doc_datasheet": "데이터시트", "doc_user_guide": "사용 설명서",
        "doc_application_note": "애플리케이션 노트", "doc_white_paper": "백서",
        "doc_manual": "매뉴얼", "doc_generic": "문서",
        "doc_revision_line": "문서 개정: {doc_id}{rev_label}, {revised} 개정.",
        "specs_cond_missing": (
            "위 항목 중 {n}건은 시험 조건을 추출하지 못했습니다. 해당 값은 원본 문서의 해당 표 "
            "조건에서만 성립하므로 설계 전에 원본에서 확인하십시오."),
        "values_source": "이 페이지의 값은 {mfr}의 {doc}를 기반으로 합니다",
        "source_pdf": "원본 PDF",
        "absmax_row": "절대 최대 정격.",
        "alt_reason_default": "대체품",
        "alt_row_note": "대체 전에 핀 호환성, 정격, 라이프사이클을 확인하십시오.",
        "mark_default": "최신 데이터시트에서 마킹을 확인하십시오.",
        "pinout_fallback": "데이터시트의 핀 기능 표를 참조하십시오.",
        "pinout_intro": "{pkg} 핀 할당은 {m}개 단자에 {n}개의 고유 핀 기능을 그룹화합니다.",
        "order_check": "<strong>주문 코드 확인:</strong> 이 항목은 {mfr}가 {mpn}용으로 공개한 주문 정보에 기반하지만 자동 대체품이 아닙니다. 설계·구매 변경 전에 전체 주문 코드, 패키지, 온도 범위, 포장, 마킹, 라이프사이클 및 최신 제조사 문서를 다시 확인하십시오.",
        "mfr_line1": "{mfr}은(는) {mpn}을 {pname}(으)로 제조합니다.",
        "mfr_line2_pre": "기술적 기준 문서는 제조사 {doc}이며 다음 링크에서 확인할 수 있습니다:",
        "mfr_line2_nolink": "기술적 기준 문서는 제조사 {doc}입니다.",
        "mfr_link": "이 링크",
        "mfr_line2_post": "릴리스 전에 최신 개정판, 라이프사이클 상태, 전기적 한계, 핀 할당, 패키지 도면을 확인하십시오.",
        "app_example": "{a} 설계에는 전원 레일, 동작 온도({op_temp}), 인터페이스 타이밍, 패키지 열 경로를 대상 시스템에서 검증한 후 {mpn}을 사용할 수 있습니다.",
        "op_temp_default": "사양 범위 내",
        "notice_eng": "<strong>엔지니어링 용도:</strong> 이 페이지의 기술 값은 {mfr}의 {mpn} 데이터시트를 기반으로 합니다",
        "notice_eng_post": "최종 시스템에서 레일, 온도 한계, 타이밍, 핀 배열, 패키지를 검증하십시오.",
        "notice_eng_post_board": "최종 시스템에서 레일, 온도 한계, 타이밍, 보드 인터페이스를 검증하십시오.",
        "board_device_unknown": "이 보드에는 여러 디바이스가 실장되어 있습니다. 정확한 부품 목록은 공식 보드 회로도를 참조하십시오.",
        "notice_order": "<strong>주문 코드 관리:</strong> 기타 주문 가능 품목과 평가 보드는 비교 검토용 참고 자료입니다. 대체 또는 구매 전에 전체 모델, 패키지, 온도 범위, 포장, 마킹, 라이프사이클을 확인하십시오.",
        "insight_q": "{mpn}으로 설계할 때 확인해야 할 사항은?",
        "sr_only": "{mpn} 개요: 주요 장점, 기술 인사이트, 전기 사양, {pkg} 세부 사항, 핀 배열, 애플리케이션, 주문 가능한 대안, FAQ.",
        "sr_only_board": "{mpn} 개요: 주요 장점, 기술 인사이트, 온보드 디바이스 사양, 보드 세부 사항, 애플리케이션, 주문 가능한 품목, FAQ.",
        "board_fact": "{mpn}은(는) 인쇄 회로 기판으로 조립된 평가 모듈이며, 온보드 디바이스 <strong>{device}</strong>({pkg} 패키지)를 탑재합니다",
        "board_fact_plain": "{mpn}은(는) 인쇄 회로 기판으로 조립된 평가 모듈입니다",
        "board_pkg_title": "<strong>{mpn}</strong>은(는) 조립된 평가 보드(PCB)이며 패키지 IC가 아닙니다.",
        "board_onboard": "이 보드는 온보드 디바이스 <strong>{device}</strong>({pkg} 패키지 장착)를 탑재하고 있습니다.",
        "board_dims": "보드 외형은 약 {dims}입니다. 패널·인클로저 설계 전에 평가 보드 사용 설명서의 기계 도면과 커넥터 배치를 확인하십시오.",
        "board_pinout": "아래 핀 할당은 온보드 {device}({pkg} 패키지)의 것입니다. {m}개 단자에 {n}개의 고유 핀 기능이 할당되어 있습니다.",
        "board_mfr": "{mfr}은(는) 온보드 {device}를 중심으로 한 평가 플랫폼으로 {mpn}을(를) 제공합니다.",
        "sep": ", ",
    },
    "de": {
        "overview_title": "Überblick: {mpn}", "key_benefits": "Wichtigste Vorteile",
        "electrical_specs": "Elektrische Spezifikationen", "package": "Gehäuse",
        "scope_onboard": "Die folgenden Werte gelten für das bestückte Bauteil {device} und sind keine Grenzwerte der bestückten Baugruppe.",
        "scope_onboard_plain": "Die folgenden Werte beschreiben das auf dieser Baugruppe bestückte Bauteil und sind keine Grenzwerte der bestückten Baugruppe.",
        "scope_onboard_plain_dev": "bestücktes Bauteil",
        "specs_onboard_elec_title": "Elektrische Spezifikationen des bestückten Bauteils {device}",

        "specs_verify_all_page": (
            "Alle {total} Einträge dieser Seite sind an das Quell-PDF angebunden "
            "({detail}). Die Anbindung belegt, dass jeder Wert an eine bestimmte "
            "Tabellenzeile oder Textstelle gebunden ist; sie belegt nicht, dass "
            "Spaltenrollen (MIN/TYP/MAX), Prüfbedingungen oder Fußnoten geprüft wurden."),
        "specs_lbl_electrical": "elektrisch", "specs_lbl_absmax": "Grenzwerte",
        "specs_lbl_thermal": "Thermik", "specs_lbl_esd": "ESD", "specs_lbl_ac": "AC",
        "pinout": "Pinbelegung", "equiv": "Bestellbare und Design-Alternativen",
        "manufacturer": "Hersteller", "applications": "Anwendungen",
        "faq": "Häufig gestellte Fragen", "notice": "Wichtiger Hinweis",
        "insight": "Technische Insights",
        "th_param": "Parameter", "th_value": "Wert", "th_cond": "Bedingungen und Kontext",
        "th_limit": "Grenzwert", "th_notes": "Hinweise",
        "th_orderable": "Bestelloption", "th_order_diff": "Bestellcode-Unterschied",
        "th_packing": "Verpackung oder Gehäuse", "th_selection": "Auswahlprüfung",
        "caps_prefix": "Zu den wichtigsten Funktionen gehören {list}.",
        "used_prefix": "Es wird eingesetzt in {list}.",
        "absmax_warn": "<strong>Absolute Maximalwerte</strong> — niemals an oder über diese Grenzen hinaus betreiben.",
        "specs_not_stated": "Elektrische Spezifikationen sind im Quelldokument nicht angegeben.",
        "typical_case": "Typischer Anwendungsfall:", "documented_orderable": "Dokumentierte Bestelloption",
        "specs_cond_default": "Es gelten die Bedingungen des Datenblatts.",
        "specs_verify_note": (
            "{n} von {total} Einträgen unten sind als ungeprüft (†) markiert. Der Wert "
            "wurde wie extrahiert beibehalten, stammt jedoch aus dem Sprachmodell statt aus "
            "deterministischer Extraktion; Testbedingung bzw. Spaltenrolle ließen sich "
            "keiner Zeile im Datenblatt zuordnen. Vor der Verwendung im Design im "
            "Original-Datenblatt prüfen."),
        "specs_verify_note_amax": (
            "{n} von {total} Absolute-Maximum-Einträgen sind als ungeprüft (†) markiert."),

        "specs_verify_all": (
            "Alle {total} Einträge unten sind auf das Original-PDF zurückgeführt — jeder Wert wurde gegen eine bestimmte Tabellenzeile oder Textstelle (Seite, Koordinaten, reproduzierbarer Fingerabdruck) geprüft. Das belegt die Bindung an die Zeile — nicht, dass Spaltenrollen (MIN/TYP/MAX), Testbedingungen oder Fußnoten geprüft wurden."),
        "specs_thermal_title": "Wärmewiderstand",
        "specs_esd_title": "ESD-Belastbarkeit",
        "specs_ac_withheld": (
            "{n} AC-Zeilen wurden aus dem Quelldatenblatt extrahiert, werden hier aber zurückgehalten: Die Spaltenrollen MIN/TYP/MAX oder die Herkunft der Daten konnten nicht validiert werden (eine Einheit oder Fussnote belegte eine Wertezelle, oder die Zeile wurde ohne eigene Koordinaten/Zeilenfingerabdruck aus einem anderen Container kopiert). Die Rohzeilen liegen in `specs.unresolved_ac_rows`; Neuzuordnung der Spalten und Herkunftsprüfung erfolgen manuell. Die AC-Kennwerte sind hier also absichtlich leer, nicht im Datenblatt abwesend."
        ),
        "specs_ac_escape_withheld": (
            "{n} AC-Zeilen der elektrischen Tabelle des On-Board-Bauteils werden hier zurückgehalten: Sie wurden ohne eigene bbox/Zeilenfingerabdruck aus einem anderen Container kopiert, lassen sich daher nicht gegen das Quelldatenblatt nachspielen und gehören möglicherweise nicht zu diesem Bauteil. Die Rohzeilen bleiben in der Quell-JSON zur manuellen Prüfung erhalten."
        ),
        "specs_ac_title": "AC-Eigenschaften",
        "specs_ac_note": (
            "Deterministisch aus der AC-Kenndaten-Tabelle des Original-Datenblatts extrahiert, "
            "einschließlich der Testbedingungen, die jede Zeile auswählen. Die Zeilen "
            "unterscheiden sich nach Eingangsfrequenz, Eingangsamplitude und Kanalmodus — "
            "nur gleiche Bedingungen sind vergleichbar."),
        "doc_datasheet": "Datenblatt", "doc_user_guide": "Benutzerhandbuch",
        "doc_application_note": "Applikationsbericht", "doc_white_paper": "Whitepaper",
        "doc_manual": "Handbuch", "doc_generic": "Dokument",
        "doc_revision_line": "Dokumentrevision: {doc_id}{rev_label}, überarbeitet {revised}.",
        "specs_cond_missing": (
            "Bei {n} der obigen Einträge konnte keine Testbedingung extrahiert werden. Der Wert "
            "gilt nur unter den Bedingungen der entsprechenden Tabelle im Quelldokument; prüfen "
            "Sie dies dort vor der Designnutzung."),
        "values_source": "Die Werte auf dieser Seite stammen aus dem {mfr}-{doc}",
        "source_pdf": "Quell-PDF",
        "absmax_row": "Absoluter Maximalwert.",
        "alt_reason_default": "Alternative",
        "alt_row_note": "Vor einer Substitution Pin-Kompatibilität, Grenzwerte und Lebenszyklus bestätigen.",
        "mark_default": "Markierung im aktuellen Datenblatt überprüfen.",
        "pinout_fallback": "Siehe Pin-Funktionstabelle im Datenblatt.",
        "pinout_intro": "Die Pin-Belegung des {pkg} fasst {n} eindeutige Pin-Funktionen über {m} Anschlüsse.",
        "order_check": "<strong>Bestellcode-Prüfung:</strong> Diese Einträge sind in den Bestellinformationen von {mfr} für {mpn} dokumentiert, stellen aber keinen automatischen Ersatz dar. Prüfen Sie vor einer Design- oder Einkaufsänderung den vollständigen Bestellcode, das Gehäuse, den Temperaturbereich, die Verpackung, die Markierung, den Lebenszyklus und die aktuellen Herstellerunterlagen.",
        "mfr_line1": "{mfr} fertigt {mpn} als {pname}.",
        "mfr_line2_pre": "Die maßgebliche technische Referenz ist das Hersteller-{doc}, verfügbar unter",
        "mfr_line2_nolink": "Die maßgebliche technische Referenz ist das Hersteller-{doc}.",
        "mfr_link": "diesem Link",
        "mfr_line2_post": "Bestätigen Sie vor der Freigabe die neueste Revision, den Lebenszyklusstatus, die elektrischen Grenzwerte, die Pin-Belegung und die Gehäusezeichnung.",
        "app_example": "Ein Design für {a} kann {mpn} verwenden, nachdem die Versorgungsspannungen, die Betriebstemperatur ({op_temp}), das Interface-Timing und der thermische Pfad des Gehäuses für das Zielsystem verifiziert wurden.",
        "op_temp_default": "wie spezifiziert",
        "notice_eng": "<strong>Technische Nutzung:</strong> Die technischen Werte auf dieser Seite basieren auf dem {mfr}-Datenblatt für {mpn}",
        "notice_eng_post": "Überprüfen Sie im finalen System Spannungen, Temperaturgrenzen, Timing, Pinbelegung und Gehäuse.",
        "notice_eng_post_board": "Überprüfen Sie im finalen System Spannungen, Temperaturgrenzen, Timing und die Board-Schnittstellen.",
        "board_device_unknown": "Diese Baugruppe ist mit mehreren Bauteilen bestückt; die genaue Stückliste steht im offiziellen Schaltplan.",
        "notice_order": "<strong>Bestellcode-Kontrolle:</strong> Andere bestellbare Optionen und Evaluationsboards sind nur Vergleichswege. Überprüfen Sie vor Substitution oder Kauf das vollständige Modell, Gehäuse, Temperaturbereich, Verpackung, Markierung und den Lebenszyklus.",
        "insight_q": "Woran sollte beim Design mit {mpn} gedacht werden?",
        "sr_only": "{mpn}-Überblick mit Vorteilen, technischen Insights, elektrischen Spezifikationen, {pkg}-Details, Pinbelegung, Anwendungen, bestellbaren Alternativen und FAQs.",
        "sr_only_board": "{mpn}-Überblick mit Vorteilen, technischen Insights, Spezifikationen des Onboard-Bausteins, Board-Details, Anwendungen, bestellbaren Optionen und FAQs.",
        "board_fact": "{mpn} ist ein als Leiterplatte aufgebautes Evaluationsmodul mit dem Onboard-Baustein <strong>{device}</strong> im {pkg}-Gehäuse",
        "board_fact_plain": "{mpn} ist ein als Leiterplatte aufgebautes Evaluationsmodul",
        "board_pkg_title": "<strong>{mpn}</strong> ist ein bestücktes Evaluationsboard (PCB), kein gehäuster IC.",
        "board_onboard": "Das Board ist mit dem Onboard-Baustein <strong>{device}</strong> im {pkg}-Gehäuse bestückt.",
        "board_dims": "Die Platine ist etwa {dims} groß; bestätigen Sie die mechanische Zeichnung und die Steckerplatzierung im Benutzerhandbuch des Evaluationsboards vor dem Panel- oder Gehäusedesign.",
        "board_pinout": "Die folgende Pin-Belegung dokumentiert den Onboard-Baustein {device} im {pkg}-Gehäuse. {n} eindeutige Pin-Funktionen über {m} Anschlüsse.",
        "board_mfr": "{mfr} bietet {mpn} als Evaluationsplattform um den Onboard-Baustein {device} an.",
        "sep": ", ",
    },
    "es": {
        "overview_title": "Descripción general de {mpn}", "key_benefits": "Ventajas principales",
        "electrical_specs": "Especificaciones eléctricas", "package": "Paquete",
        "scope_onboard": "Los valores siguientes corresponden al dispositivo {device} montado en la placa y no son límites del conjunto ensamblado.",
        "scope_onboard_plain": "Los valores siguientes describen el dispositivo montado en esta placa y no son límites del conjunto ensamblado.",
        "scope_onboard_plain_dev": "dispositivo montado",
        "specs_onboard_elec_title": "Especificaciones eléctricas del dispositivo montado {device}",

        "specs_verify_all_page": (
            "Las {total} entradas de esta página están ancladas al PDF de origen "
            "({detail}). El anclaje demuestra que cada valor está vinculado a una fila o "
            "texto concreto; no demuestra por sí solo que se hayan revisado los roles de "
            "columna (MIN/TYP/MAX), las condiciones de prueba ni las notas."),
        "specs_lbl_electrical": "eléctricas", "specs_lbl_absmax": "máximos absolutos",
        "specs_lbl_thermal": "térmica", "specs_lbl_esd": "ESD", "specs_lbl_ac": "CA",
        "pinout": "Asignación de pines", "equiv": "Opciones pedibles y alternativas de diseño",
        "manufacturer": "Fabricante", "applications": "Aplicaciones",
        "faq": "Preguntas frecuentes", "notice": "Aviso importante",
        "insight": "Análisis técnico",
        "th_param": "Parámetro", "th_value": "Valor", "th_cond": "Condiciones y contexto",
        "th_limit": "Límite", "th_notes": "Notas",
        "th_orderable": "Opción de pedido", "th_order_diff": "Diferencia de código de pedido",
        "th_packing": "Embalaje o paquete", "th_selection": "Comprobación de selección",
        "caps_prefix": "Las capacidades clave incluyen {list}.",
        "used_prefix": "Se utiliza en {list}.",
        "absmax_warn": "<strong>Valores máximos absolutos</strong>: nunca opere a ni más allá de estos límites.",
        "specs_not_stated": "Las especificaciones eléctricas no se indican en el documento de origen.",
        "typical_case": "Caso típico:", "documented_orderable": "Opción pedible documentada",
        "specs_cond_default": "Se aplican las condiciones de la hoja de datos.",
        "specs_verify_note": (
            "{n} de {total} entradas a continuación están marcadas como no verificadas (†). "
            "El valor se mantuvo tal como se extrajo, pero proviene del modelo de lenguaje y "
            "no de una extracción determinista; su condición de prueba o el rol de la "
            "columna no se pudo cotejar con una fila de la hoja de datos. Confirme en la "
            "hoja de datos original antes de usarlo en el diseño."),
        "specs_verify_note_amax": (
            "{n} de {total} entradas de máximo absoluto están marcadas como no verificadas (†)."),

        "specs_verify_all": (
            "Las {total} entradas siguientes están ancladas al PDF original: cada valor se contrastó con una fila de tabla o una entrada de texto concreta (página, coordenadas y huella reproducible). Esto demuestra que el valor está vinculado a esa fila; no demuestra que se hayan revisado los roles de columna (MIN/TYP/MAX), las condiciones de prueba ni las notas al pie."),
        "specs_thermal_title": "Resistencia térmica",
        "specs_esd_title": "Valores ESD",
        "specs_ac_withheld": (
            "{n} filas de CA se extrajeron de la hoja de datos original, pero se retienen aqui: no se pudieron validar los roles de columna MIN/TYP/MAX ni el origen de los datos (una unidad o nota al pie ocupaba una celda de valor, o la fila se copio desde otro contenedor sin coordenadas/huella de fila propias). Las filas originales estan en `specs.unresolved_ac_rows`; la reasignacion de columnas y la verificacion del origen son manuales. Las caracteristicas de CA estan vacias aqui por decision propia, no ausentes en la hoja de datos."
        ),
        "specs_ac_escape_withheld": (
            "{n} filas de CA de la tabla electrica del dispositivo integrado se retienen en esta pagina: se copiaron desde otro contenedor sin sus propias bbox/huella de fila, por lo que no se pueden reproducir contra el PDF original y podrian no pertenecer a este dispositivo. Las filas originales permanecen en el JSON de origen para revision manual."
        ),
        "specs_ac_title": "Prestaciones en CA",
        "specs_ac_note": (
            "Extraído de forma determinista de la tabla de características en CA del datasheet "
            "original, conservando las condiciones de ensayo que seleccionan cada fila. Las "
            "filas difieren en frecuencia de entrada, amplitud de entrada y modo de canal: "
            "compare solo condiciones equivalentes."),
        "doc_datasheet": "hoja de datos", "doc_user_guide": "guía de usuario",
        "doc_application_note": "nota de aplicación", "doc_white_paper": "documento técnico",
        "doc_manual": "manual", "doc_generic": "documento",
        "doc_revision_line": "Revisión del documento: {doc_id}{rev_label}, revisado en {revised}.",
        "specs_cond_missing": (
            "{n} de las entradas anteriores no tienen condición de ensayo extraída; el valor "
            "solo es válido en las condiciones de la tabla correspondiente del documento "
            "original, compruébelo allí antes de usarlo en diseño."),
        "values_source": "Los valores de esta página provienen de la {doc} de {mfr}",
        "source_pdf": "PDF de origen",
        "absmax_row": "Valor máximo absoluto.",
        "alt_reason_default": "Alternativa",
        "alt_row_note": "Confirme compatibilidad de pines, valores límite y ciclo de vida antes de sustituir.",
        "mark_default": "Verifique el marcado en la hoja de datos actual.",
        "pinout_fallback": "Consulte la tabla de funciones de pines de la hoja de datos.",
        "pinout_intro": "La asignación de pines de {pkg} agrupa {n} funciones de pin únicas en {m} terminales.",
        "order_check": "<strong>Comprobación de código de pedido:</strong> Estas entradas están documentadas en la información de pedidos de {mfr} para {mpn}, pero ninguna es un sustituto automático. Verifique el código de pedido completo, el paquete, el rango de temperatura, el embalaje, el marcado, el ciclo de vida y la documentación actual del fabricante antes de un cambio de diseño o compra.",
        "mfr_line1": "{mfr} fabrica {mpn} como {pname}.",
        "mfr_line2_pre": "El registro técnico de referencia es la {doc} del fabricante, disponible en",
        "mfr_line2_nolink": "El registro técnico de referencia es la {doc} del fabricante.",
        "mfr_link": "este enlace",
        "mfr_line2_post": "Confirme la última revisión, el estado del ciclo de vida, los límites eléctricos, la asignación de pines y el dibujo del paquete antes de la liberación.",
        "app_example": "Un diseño para {a} puede usar {mpn} después de verificar los rieles de alimentación, la temperatura de operación ({op_temp}), el tiempo de la interfaz y la ruta térmica del paquete para el sistema de destino.",
        "op_temp_default": "según lo especificado",
        "notice_eng": "<strong>Uso de ingeniería:</strong> Los valores técnicos de esta página están vinculados a la hoja de datos de {mfr} para {mpn}",
        "notice_eng_post": "Verifique rieles, límites de temperatura, temporización, asignación de pines y paquete en el sistema final.",
        "notice_eng_post_board": "Verifique rieles, límites de temperatura, temporización e interfaces de la placa en el sistema final.",
        "board_device_unknown": "Esta placa incorpora varios dispositivos; consulte el esquema oficial de la placa para la lista de materiales exacta.",
        "notice_order": "<strong>Control de código de pedido:</strong> Otras opciones pedibles y placas de evaluación son solo rutas de comparación. Verifique el modelo completo, el paquete, el rango de temperatura, el embalaje, el marcado y el ciclo de vida antes de sustituir o comprar.",
        "insight_q": "¿Qué debe verificarse al diseñar con {mpn}?",
        "sr_only": "Descripción general de {mpn} con ventajas, análisis técnico, especificaciones eléctricas, detalles de {pkg}, asignación de pines, aplicaciones, alternativas pedibles y preguntas frecuentes.",
        "sr_only_board": "Descripción general de {mpn} con ventajas, análisis técnico, especificaciones del dispositivo a bordo, detalles de la placa, aplicaciones, opciones pedibles y preguntas frecuentes.",
        "board_fact": "{mpn} es un módulo de evaluación montado como placa de circuito impreso, con el dispositivo a bordo <strong>{device}</strong> en un paquete {pkg}",
        "board_fact_plain": "{mpn} es un módulo de evaluación montado como placa de circuito impreso",
        "board_pkg_title": "<strong>{mpn}</strong> es una placa de evaluación montada (PCB), no un IC encapsulado.",
        "board_onboard": "La placa viene montada con el dispositivo a bordo <strong>{device}</strong>, en un paquete {pkg}.",
        "board_dims": "El contorno de la placa es de aproximadamente {dims}; confirme el dibujo mecánico y la colocación de conectores en la guía del usuario de la placa de evaluación antes del diseño de panel o carcasa.",
        "board_pinout": "La asignación de pines siguiente documenta el dispositivo a bordo {device} en su paquete {pkg}. {n} funciones de pin únicas en {m} terminales.",
        "board_mfr": "{mfr} ofrece {mpn} como plataforma de evaluación construida alrededor del dispositivo a bordo {device}.",
        "sep": ", ",
    },
}


_BOARD_EXTRA = {
    "en": {
        "board_device_no_package": "The board uses {device}; its mounted package is not verified in the source document.",
        "board_faq_q": "Does this page list board-level specifications for {mpn}?",
        "board_faq_yes": "Yes. The board-level values listed here come from the board user guide; keep the stated rail and test conditions when using them.",
        "board_faq_no": "Board-level limits are not verified in the available source. Consult the board user guide before connecting supplies or signals.",
    },
    "ja": {
        "board_specs_not_stated": "基板全体の電気仕様は元資料に記載されていません。搭載デバイス {device} のデータシートではなく、基板のユーザーガイドで電源と接続条件を確認してください。",
        "board_source_no_guide": "元資料は {mfr} の搭載デバイス {device} のデータシートであり、基板のユーザーガイドではありません。",
        "board_values_from_guide": "本ページの基板仕様は評価基板のユーザーガイドに基づきます。",
        "board_mfr_source": "手元の資料は搭載デバイス {device} のデータシートです。基板の設定はユーザーガイドで確認してください。",
        "board_app_example": "{mpn} 評価基板は {a} に使用されます。接続前にユーザーガイドで電源、ジャンパー、コネクタ設定を確認してください。",
        "notice_eng_board_no_guide": "<strong>技術利用：</strong> 元資料は {mfr} の搭載デバイス {device} のデータシートであり、{mpn} 基板のユーザーガイドではありません",
        "board_device_no_package": "本基板は {device} を使用します。実装パッケージは元資料で確認されていません。",
        "board_faq_q": "このページに {mpn} の基板仕様は掲載されていますか？",
        "board_faq_yes": "はい。掲載した基板仕様はユーザーガイドに基づきます。電源および試験条件を守ってください。",
        "board_faq_no": "入手した資料では基板の限界値は確認されていません。電源や信号を接続する前にユーザーガイドを確認してください。",
    },
    "ko": {
        "board_specs_not_stated": "원본 문서에 보드 전체 전기 사양은 명시되지 않았습니다. 온보드 {device} 데이터시트 대신 보드 사용 설명서에서 전원과 연결 조건을 확인하십시오.",
        "board_source_no_guide": "원본은 {mfr}의 온보드 {device} 데이터시트이며 보드 사용 설명서가 아닙니다.",
        "board_values_from_guide": "이 페이지의 보드 사양은 평가 보드 사용 설명서에 근거합니다.",
        "board_mfr_source": "보유 문서는 온보드 {device} 데이터시트입니다. 보드 설정은 사용 설명서를 확인하십시오.",
        "board_app_example": "{mpn} 평가 보드는 {a}에 사용됩니다. 연결 전에 사용 설명서의 전원, 점퍼 및 커넥터 설정을 확인하십시오.",
        "notice_eng_board_no_guide": "<strong>기술 용도:</strong> 원본은 {mfr}의 온보드 {device} 데이터시트이며 {mpn} 보드 사용 설명서가 아닙니다",
        "board_device_no_package": "이 보드는 {device}를 사용합니다. 실제 실장 패키지는 원본에서 검증되지 않았습니다.",
        "board_faq_q": "이 페이지에 {mpn}의 보드 사양이 있습니까?",
        "board_faq_yes": "예. 기재된 보드 사양은 사용 설명서에 근거합니다. 전원과 시험 조건을 유지하십시오.",
        "board_faq_no": "보유 자료에서 보드 한계값은 검증되지 않았습니다. 전원이나 신호 연결 전에 사용 설명서를 확인하십시오.",
    },
    "de": {
        "board_specs_not_stated": "Elektrische Grenzwerte der Baugruppe sind in der Quelle nicht angegeben. Das Datenblatt gilt für {device}; prüfen Sie Spannungen und Anschlüsse im Board-Handbuch.",
        "board_source_no_guide": "Die Quelle ist das {mfr}-Datenblatt des bestückten {device}, nicht das Board-Handbuch.",
        "board_values_from_guide": "Die Board-Werte auf dieser Seite stammen aus dem Benutzerhandbuch der Evaluationsplatine.",
        "board_mfr_source": "Vorhanden ist das Datenblatt des bestückten {device}. Board-Einstellungen sind im Benutzerhandbuch zu prüfen.",
        "board_app_example": "Das Evaluationsboard {mpn} dient {a}; prüfen Sie vor dem Anschluss Spannungen, Jumper und Steckverbinder im Board-Handbuch.",
        "notice_eng_board_no_guide": "<strong>Technische Nutzung:</strong> Die Quelle ist das {mfr}-Datenblatt des bestückten {device}, nicht das Board-Handbuch für {mpn}",
        "board_device_no_package": "Das Board verwendet {device}; das tatsächlich bestückte Gehäuse ist in der Quelle nicht verifiziert.",
        "board_faq_q": "Enthält diese Seite Board-Spezifikationen für {mpn}?",
        "board_faq_yes": "Ja. Die Board-Werte stammen aus dem Benutzerhandbuch; beachten Sie die angegebenen Spannungs- und Prüfbedingungen.",
        "board_faq_no": "Board-Grenzwerte sind in der verfügbaren Quelle nicht verifiziert. Prüfen Sie das Benutzerhandbuch vor Anschluss von Versorgung oder Signalen.",
    },
    "es": {
        "board_specs_not_stated": "La fuente no indica límites eléctricos de la placa. La hoja de datos corresponde a {device}; consulte tensiones y conexiones en la guía de la placa.",
        "board_source_no_guide": "La fuente es la hoja de datos de {mfr} para el dispositivo {device}, no la guía de la placa.",
        "board_values_from_guide": "Los valores de la placa de esta página proceden de la guía de usuario de la placa de evaluación.",
        "board_mfr_source": "El documento disponible describe {device}. Consulte la guía de usuario para la configuración de la placa.",
        "board_app_example": "La placa {mpn} se utiliza para {a}; verifique alimentación, puentes y conectores en la guía antes de conectarla.",
        "notice_eng_board_no_guide": "<strong>Uso técnico:</strong> La fuente es la hoja de datos de {mfr} para {device}, no la guía de la placa {mpn}",
        "board_device_no_package": "La placa utiliza {device}; el encapsulado montado no está verificado en la fuente.",
        "board_faq_q": "¿Esta página incluye especificaciones de la placa {mpn}?",
        "board_faq_yes": "Sí. Los valores de la placa proceden de la guía; respete las condiciones de alimentación y ensayo indicadas.",
        "board_faq_no": "La fuente disponible no verifica límites de la placa. Consulte la guía antes de conectar alimentación o señales.",
    },
}
for _lang, _entries in _BOARD_EXTRA.items():
    STATIC_I18N[_lang].update(_entries)


#: V5 新增词条：弱证据悬浮说明、板卡参数归属分组标题、引脚描述语言豁免。
#:
#: 为什么必须进五语表而不是硬编码：1102 复审把「渲染器拼的叙述句是硬编码英文」
#: 列为 P1，韩语页 6 段纯英文 `<p>` 就是这么来的。这些句子同样是**模板**
#: （只带 {n} 这类占位），没有理由留在英文里。
_V5_I18N: dict[str, dict] = {
    "en": {
        "verify_tip_same_page": (
            "This parameter label and its value appear on the same page, but the "
            "row/column correspondence has not been established — confirm manually "
            "against the source PDF."),
        "verify_tip_unresolved": (
            "This row is marked unresolved by the extraction pipeline: the value was "
            "kept for traceability, but the row was not audited. Do not rely on it "
            "without checking the source PDF."),
        "scope_board_level": "Board-level parameters",
        "scope_onboard_device": "On-board device parameters",
        "scope_unresolved": "Attribution not determined",
        "scope_unresolved_note": (
            "The source document does not make clear whether these parameters describe "
            "the assembled board or the device mounted on it. They are listed separately "
            "so neither reading is implied."),
        "pin_desc_lang_note": (
            "Pin names and functions are reproduced in the source language (English) "
            "in line with hardware engineering convention; they are not untranslated "
            "leftovers."),
    },
    "ja": {
        "verify_tip_same_page": (
            "このパラメータ名と値は同じページに現れますが、行・列の対応関係は"
            "確認できていません。原典 PDF で人手による確認が必要です。"),
        "verify_tip_unresolved": (
            "この行は抽出パイプラインが未解決（unresolved）と判定したものです。"
            "追跡のために値を残していますが、監査は完了していません。"
            "原典 PDF で確認せずに使用しないでください。"),
        "scope_board_level": "基板レベルのパラメータ",
        "scope_onboard_device": "搭載デバイスのパラメータ",
        "scope_unresolved": "帰属が未確定のパラメータ",
        "scope_unresolved_note": (
            "これらの値が基板全体の仕様か、実装されているデバイスの仕様かを"
            "原典から判別できませんでした。どちらとも取られないよう別掲しています。"),
        "pin_desc_lang_note": (
            "ピン名と機能説明はハードウェア設計の慣例に従い原典の言語（英語）の"
            "まま記載しています。未翻訳の残りではありません。"),
    },
    "ko": {
        "verify_tip_same_page": (
            "이 파라미터 이름과 값이 같은 페이지에 있지만 행·열 대응 관계는 "
            "확인되지 않았습니다. 원본 PDF와 대조하여 직접 확인하십시오."),
        "verify_tip_unresolved": (
            "이 행은 추출 파이프라인이 미해결(unresolved)로 판정한 항목입니다. "
            "추적을 위해 값을 남겨 두었지만 감사는 완료되지 않았습니다. "
            "원본 PDF로 확인하지 않고 사용하지 마십시오."),
        "scope_board_level": "보드 수준 파라미터",
        "scope_onboard_device": "온보드 디바이스 파라미터",
        "scope_unresolved": "귀속 미확정 파라미터",
        "scope_unresolved_note": (
            "이 값이 조립된 보드의 사양인지 보드에 실장된 디바이스의 사양인지 "
            "원본 문서에서 판별하지 못했습니다. 어느 쪽으로도 읽히지 않도록 "
            "따로 표시합니다."),
        "pin_desc_lang_note": (
            "핀 이름과 기능 설명은 하드웨어 설계 관례에 따라 원문 언어(영어)로 "
            "표기합니다. 미번역 잔여 문구가 아닙니다."),
    },
    "de": {
        "verify_tip_same_page": (
            "Parametername und Wert stehen auf derselben Seite, die Zeilen- und "
            "Spaltenzuordnung ist jedoch nicht belegt — bitte im Quell-PDF manuell "
            "prüfen."),
        "verify_tip_unresolved": (
            "Diese Zeile wurde von der Extraktions-Pipeline als ungelöst (unresolved) "
            "eingestuft. Der Wert bleibt zur Nachvollziehbarkeit erhalten, die Zeile "
            "wurde jedoch nicht geprüft. Ohne Kontrolle im Quell-PDF nicht verwenden."),
        "scope_board_level": "Parameter der Baugruppe",
        "scope_onboard_device": "Parameter des bestückten Bauteils",
        "scope_unresolved": "Zuordnung nicht bestimmt",
        "scope_unresolved_note": (
            "Die Quelle lässt nicht erkennen, ob diese Werte die bestückte Baugruppe "
            "oder das darauf montierte Bauteil beschreiben. Sie sind getrennt "
            "aufgeführt, damit keine der beiden Lesarten unterstellt wird."),
        "pin_desc_lang_note": (
            "Pinbezeichnungen und -funktionen sind nach Konvention der "
            "Hardware-Entwicklung in der Originalsprache (Englisch) wiedergegeben; "
            "sie sind keine unübersetzten Reste."),
    },
    "es": {
        "verify_tip_same_page": (
            "La etiqueta del parámetro y su valor aparecen en la misma página, pero "
            "no se ha establecido la correspondencia fila/columna: verifíquelo "
            "manualmente en el PDF de origen."),
        "verify_tip_unresolved": (
            "Esta fila está marcada como no resuelta (unresolved) por el proceso de "
            "extracción: el valor se conserva para trazabilidad, pero la fila no fue "
            "auditada. No la utilice sin comprobarla en el PDF de origen."),
        "scope_board_level": "Parámetros de la placa",
        "scope_onboard_device": "Parámetros del dispositivo montado",
        "scope_unresolved": "Atribución no determinada",
        "scope_unresolved_note": (
            "El documento de origen no permite saber si estos valores describen la "
            "placa ensamblada o el dispositivo montado en ella. Se listan por separado "
            "para no sugerir ninguna de las dos lecturas."),
        "pin_desc_lang_note": (
            "Los nombres y funciones de los pines se reproducen en el idioma original "
            "(inglés) conforme a la convención de ingeniería de hardware; no son "
            "restos sin traducir."),
    },
}
#: 列表连接词（(分隔符, 末项连接词)）。`supplied` / `pkg_facts` / FAQ 的
#: 句子都由「若干短语 + 一个连接规则」构成，硬拼英文逗号在日语里会变成
#: 「FCBGA (144) パッケージ, 動作範囲, 発注可能品」—— 半角逗号在日文里是错排。
_LIST_JOIN: dict[str, tuple[str, str]] = {
    "en": (", ", ", and "),
    "ja": ("、", "、"),
    "ko": (", ", ", "),
    "de": (", ", " und "),
    "es": (", ", " y "),
}


def _join_list(lang: str, parts: list[str]) -> str:
    """按语言习惯连接短语列表。空项直接丢掉（缺封装/缺温度时不出现空档）。"""
    sep, last = _LIST_JOIN.get(lang, _LIST_JOIN["en"])
    items = [p for p in parts if p]
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return sep.join(items[:-1]) + last + items[-1]


#: 渲染器**拼出来的叙述句**五语模板（Reviewer V4 复审 新-1/新-2）。
#:
#: 这 8 组句子此前是硬编码英文：`{mpn} is supplied in …`、`uses the … package`、
#: `The device is specified with …`、以及 4 组 FAQ 问答。它们只带 `{mpn}` /
#: `{list}` 这类占位，本来就是模板 —— 韩语页 6 段纯英文 `<p>` 全部出自这里。
#: 补齐后 `tr()` 不再回退到英文，`i18n_complete` 才有意义。
_SENTENCE_I18N: dict[str, dict] = {
    "en": {
        "sup_pkg": "the {pkg} package",
        "sup_pkg_pins": "the {pkg} package with {n} pins",
        "sup_op": "an operating range of {op}",
        "sup_order1": "1 documented orderable option",
        "sup_orders": "{n} documented orderable options",
        "supplied_tpl": "{mpn} is supplied in {list}.",
        "pkg_uses_tpl": "<strong>{mpn}</strong> uses the <strong>{pkg}</strong> package.",
        "pkg_uses_pins_tpl": ("<strong>{mpn}</strong> uses the <strong>{pkg}</strong> "
                              "package with {n} pins."),
        "pkg_fact_dims": "body dimensions of {dims}",
        "pkg_fact_op": "an operating temperature range of {op}",
        "pkg_fact_st": "a storage range of {st}",
        "pkg_facts_tpl": ("The device is specified with {list}. Confirm the mechanical "
                          "drawing in the current datasheet revision before release to "
                          "production."),
        "faq_orders_q": "What distinguishes {mpn} from the other orderables?",
        "faq_orders_a": ("{mpn} is the option documented on this page{pkg}. Related order "
                         "codes listed by the manufacturer include {codes}; each differs "
                         "in packing, temperature grade or package option."),
        "faq_orders_pkg": " in the {pkg} package",
        "faq_elec_q": "Which electrical limits matter most for {mpn}?",
        "faq_elec_a": ("The headline specifications are {list}. Always read them together "
                       "with the stated test conditions."),
        "faq_layout_q": "What must be checked before laying out {mpn}?",
        "faq_layout_a": ("Use the current {pkg} drawing and pin assignment{pins}, keep the "
                         "operating range ({op}) inside the enclosure budget, and verify "
                         "the supply rails against the absolute maximum ratings."),
        "faq_layout_pins": " ({n} pins)",
        "faq_apps_q": "What is {mpn} typically used for?",
        "faq_apps_a": "Typical applications include {list}.",
    },
    "ja": {
        "sup_pkg": "{pkg} パッケージ",
        "sup_pkg_pins": "{pkg} パッケージ（{n} ピン）",
        "sup_op": "動作範囲 {op}",
        "sup_order1": "文書化された発注可能品 1 件",
        "sup_orders": "文書化された発注可能品 {n} 件",
        "supplied_tpl": "{mpn} は {list} で供給されています。",
        "pkg_uses_tpl": "<strong>{mpn}</strong> は <strong>{pkg}</strong> パッケージを使用します。",
        "pkg_uses_pins_tpl": ("<strong>{mpn}</strong> は <strong>{pkg}</strong> パッケージ"
                              "（{n} ピン）を使用します。"),
        "pkg_fact_dims": "本体寸法 {dims}",
        "pkg_fact_op": "動作温度範囲 {op}",
        "pkg_fact_st": "保存温度範囲 {st}",
        "pkg_facts_tpl": ("本デバイスは {list} で規定されています。量産移行前に、現行リビジョンの"
                          "データシートで機械図面を確認してください。"),
        "faq_orders_q": "{mpn} は他の発注品とどう違いますか？",
        "faq_orders_a": ("{mpn} は本ページに記載された{pkg}の発注品です。メーカーが記載する"
                         "関連注文コードには {codes} があり、梱包・温度グレード・パッケージ"
                         "のいずれかが異なります。"),
        "faq_orders_pkg": "{pkg} パッケージの",
        "faq_elec_q": "{mpn} で最も重要な電気的限界はどれですか？",
        "faq_elec_a": ("主要な仕様は {list} です。必ず記載された試験条件と併せて読んでください。"),
        "faq_layout_q": "{mpn} のレイアウト前に何を確認すべきですか？",
        "faq_layout_a": ("現行の {pkg} 図面とピン配置{pins}を使用し、動作範囲（{op}）を筐体の"
                         "熱設計内に収め、電源レールを絶対最大定格に対して確認してください。"),
        "faq_layout_pins": "（{n} ピン）",
        "faq_apps_q": "{mpn} は主に何に使われますか？",
        "faq_apps_a": "主な用途は {list} です。",
    },
    "ko": {
        "sup_pkg": "{pkg} 패키지",
        "sup_pkg_pins": "{pkg} 패키지({n}핀)",
        "sup_op": "동작 범위 {op}",
        "sup_order1": "문서화된 주문 가능 옵션 1개",
        "sup_orders": "문서화된 주문 가능 옵션 {n}개",
        "supplied_tpl": "{mpn}은(는) {list} 구성으로 공급됩니다.",
        "pkg_uses_tpl": "<strong>{mpn}</strong>은(는) <strong>{pkg}</strong> 패키지를 사용합니다.",
        "pkg_uses_pins_tpl": ("<strong>{mpn}</strong>은(는) <strong>{pkg}</strong> 패키지"
                              "({n}핀)를 사용합니다."),
        "pkg_fact_dims": "본체 치수 {dims}",
        "pkg_fact_op": "동작 온도 범위 {op}",
        "pkg_fact_st": "보관 온도 범위 {st}",
        "pkg_facts_tpl": ("이 디바이스는 {list} 사양으로 규정됩니다. 양산 이관 전에 현행 리비전 "
                          "데이터시트에서 기구 도면을 확인하십시오."),
        "faq_orders_q": "{mpn}은(는) 다른 주문 가능 품번과 무엇이 다릅니까?",
        "faq_orders_a": ("{mpn}은(는) 이 페이지에 기재된 {pkg} 주문 가능 옵션입니다. 제조사가 "
                         "기재한 관련 주문 코드로는 {codes}가 있으며, 포장·온도 등급·패키지 "
                         "옵션 중 하나가 다릅니다."),
        "faq_orders_pkg": "{pkg} 패키지의 ",
        "faq_elec_q": "{mpn}에서 가장 중요한 전기적 한계는 무엇입니까?",
        "faq_elec_a": ("주요 사양은 {list}입니다. 반드시 명시된 시험 조건과 함께 읽으십시오."),
        "faq_layout_q": "{mpn} 배치 전에 무엇을 확인해야 합니까?",
        "faq_layout_a": ("현행 {pkg} 도면과 핀 배열{pins}을 사용하고, 동작 범위({op})를 인클로저 "
                         "열 설계 안에 두며, 전원 레일을 절대 최대 정격과 대조하십시오."),
        "faq_layout_pins": "({n}핀)",
        "faq_apps_q": "{mpn}은(는) 주로 어디에 사용됩니까?",
        "faq_apps_a": "주요 용도는 {list}입니다.",
    },
    "de": {
        "sup_pkg": "das Gehäuse {pkg}",
        "sup_pkg_pins": "das Gehäuse {pkg} mit {n} Pins",
        "sup_op": "einen Betriebsbereich von {op}",
        "sup_order1": "1 dokumentierte Bestelloption",
        "sup_orders": "{n} dokumentierte Bestelloptionen",
        "supplied_tpl": "{mpn} wird mit {list} geliefert.",
        "pkg_uses_tpl": ("<strong>{mpn}</strong> verwendet das Gehäuse "
                         "<strong>{pkg}</strong>."),
        "pkg_uses_pins_tpl": ("<strong>{mpn}</strong> verwendet das Gehäuse "
                              "<strong>{pkg}</strong> mit {n} Pins."),
        "pkg_fact_dims": "Körpermaße von {dims}",
        "pkg_fact_op": "einen Betriebstemperaturbereich von {op}",
        "pkg_fact_st": "einen Lagerbereich von {st}",
        "pkg_facts_tpl": ("Das Bauteil ist mit {list} spezifiziert. Prüfen Sie vor der "
                          "Serienfreigabe die mechanische Zeichnung in der aktuellen "
                          "Datenblattrevision."),
        "faq_orders_q": "Wodurch unterscheidet sich {mpn} von den anderen Bestelloptionen?",
        "faq_orders_a": ("{mpn} ist die auf dieser Seite dokumentierte Option{pkg}. Zu den "
                         "vom Hersteller gelisteten Bestellcodes gehören {codes}; sie "
                         "unterscheiden sich in Verpackung, Temperaturklasse oder "
                         "Gehäusevariante."),
        "faq_orders_pkg": " im Gehäuse {pkg}",
        "faq_elec_q": "Welche elektrischen Grenzwerte sind für {mpn} am wichtigsten?",
        "faq_elec_a": ("Die maßgeblichen Spezifikationen sind {list}. Lesen Sie sie stets "
                       "zusammen mit den angegebenen Testbedingungen."),
        "faq_layout_q": "Was ist vor dem Layout von {mpn} zu prüfen?",
        "faq_layout_a": ("Verwenden Sie die aktuelle {pkg}-Zeichnung und Pinbelegung{pins}, "
                         "halten Sie den Betriebsbereich ({op}) im Budget des Gehäuses ein "
                         "und prüfen Sie die Versorgungsrails gegen die absoluten "
                         "Grenzwerte."),
        "faq_layout_pins": " ({n} Pins)",
        "faq_apps_q": "Wofür wird {mpn} typischerweise verwendet?",
        "faq_apps_a": "Typische Anwendungen sind {list}.",
    },
    "es": {
        "sup_pkg": "el encapsulado {pkg}",
        "sup_pkg_pins": "el encapsulado {pkg} con {n} pines",
        "sup_op": "un rango de funcionamiento de {op}",
        "sup_order1": "1 opción de pedido documentada",
        "sup_orders": "{n} opciones de pedido documentadas",
        "supplied_tpl": "{mpn} se suministra con {list}.",
        "pkg_uses_tpl": ("<strong>{mpn}</strong> utiliza el encapsulado "
                         "<strong>{pkg}</strong>."),
        "pkg_uses_pins_tpl": ("<strong>{mpn}</strong> utiliza el encapsulado "
                              "<strong>{pkg}</strong> con {n} pines."),
        "pkg_fact_dims": "unas dimensiones del cuerpo de {dims}",
        "pkg_fact_op": "un rango de temperatura de funcionamiento de {op}",
        "pkg_fact_st": "un rango de almacenamiento de {st}",
        "pkg_facts_tpl": ("El dispositivo se especifica con {list}. Confirme el plano "
                          "mecánico en la revisión vigente de la hoja de datos antes de "
                          "liberar a producción."),
        "faq_orders_q": "¿En qué se diferencia {mpn} de las demás opciones de pedido?",
        "faq_orders_a": ("{mpn} es la opción documentada en esta página{pkg}. Los códigos "
                         "de pedido relacionados que indica el fabricante incluyen {codes}; "
                         "difieren en embalaje, grado de temperatura o variante de "
                         "encapsulado."),
        "faq_orders_pkg": " en el encapsulado {pkg}",
        "faq_elec_q": "¿Qué límites eléctricos son los más importantes para {mpn}?",
        "faq_elec_a": ("Las especificaciones principales son {list}. Léalas siempre junto "
                       "con las condiciones de ensayo indicadas."),
        "faq_layout_q": "¿Qué debe comprobarse antes de diseñar el layout de {mpn}?",
        "faq_layout_a": ("Utilice el plano y la asignación de pines vigentes de {pkg}{pins}, "
                         "mantenga el rango de funcionamiento ({op}) dentro del presupuesto "
                         "térmico del cerramiento y verifique los raíles de alimentación "
                         "frente a los máximos absolutos."),
        "faq_layout_pins": " ({n} pines)",
        "faq_apps_q": "¿Para qué se utiliza normalmente {mpn}?",
        "faq_apps_a": "Las aplicaciones típicas incluyen {list}.",
    },
}
for _lang, _entries in _SENTENCE_I18N.items():
    STATIC_I18N[_lang].update(_entries)


for _lang, _entries in _V5_I18N.items():
    STATIC_I18N[_lang].update(_entries)


#: 技术洞察里的「设计检查点」文案。此前 9 组标题+正文是**硬编码英文**，
#: 韩语/日语/德语/西班牙语页面上整段显示英文（1102 复审 P1：韩语页仍有
#: 长段英文）。这些句子是模板（只带 {list}/{pkg} 这类占位），本来就该进词表。
#: 占位符一律用 `str.format` 风格，正文里没有裸 `{` `}`。
_CHECKS_I18N: dict[str, dict] = {
    "en": {
        "chk_rails_title": "Respect the Absolute Maximum Rails",
        "chk_rails_body": "Absolute maximum ratings limit {list}. Design the supply "
                          "sequence and transients inside these limits before selecting "
                          "surrounding components.",
        "chk_thermal_title": "Budget the Thermal Headroom",
        "chk_thermal_body": "Operating temperature is {op}{st}. Derating, self-heating and "
                            "airflow must be verified at the worst-case ambient of the enclosure.",
        "chk_package_title": "Lock the Package and Pinout Early",
        "chk_package_body": "The {pkg}{pins}{dims} defines the footprint, thermal path and pin "
                            "assignment; confirm it against the current revision before layout.",
        "chk_elec_title": "Verify the Critical Electrical Limits",
        "chk_elec_body": "The dominant specifications are {list}. Confirm each against the "
                         "actual test conditions rather than the headline number.",
        "chk_relief_title": "Review the Thermal Relief and Grounding",
        "chk_relief_body": "At maximum output load it is the board, not the device, that sets "
                           "the thermal limit. Provide adequate airflow and confirm the ground "
                           "reference at the connector shields before trusting any measured "
                           "performance figure.",
        "chk_board_title": "Verify the Board Power Rails and Jumper Settings",
        "chk_board_dev": "built around the onboard {device}",
        "chk_board_dev_pkg": "built around the onboard {device} in its {pkg} package",
        "chk_board_dev_multi": "assembled from more than one device",
        "chk_board_body": "This evaluation board is {dev}. Confirm the rail selection, the "
                          "current limit and the jumper positions against the board user guide "
                          "before connecting any signal source; a wrong jumper is the most "
                          "common cause of a board that appears dead.",
        "chk_motor_title": "Check the Motor Outputs and Current Setting",
        "chk_motor_body": "Verify the phase outputs, the current-setting network and the bulk "
                          "supply capacitance before a motor is connected. A current limit that "
                          "is set too high is the fastest way to damage the driver stage on the "
                          "first spin, and an unloaded supply will show a much lower current "
                          "than the application needs.",
        "chk_led_title": "Check the LED String Outputs and Current Setting",
        "chk_led_body": "Verify the string connections, the current-setting network and the "
                        "separate DC supply for each string. Confirm the forward voltage of the "
                        "string stays inside the converter output range before power is applied, "
                        "otherwise the channel either drops out of regulation or overdrives "
                        "the LEDs.",
        "chk_clock_title": "Check the Interface and Clocking Inputs",
        "chk_clock_body": "Check the documented clock input and its stated frequency and "
                          "termination requirements in the board user guide before connecting "
                          "a clock source.",
    },
    "ja": {
        "chk_rails_title": "絶対最大定格レールの遵守",
        "chk_rails_body": "絶対最大定格は{list}を制限します。周辺部品を選定する前に、"
                          "電源シーケンスと過渡変動がこの範囲に収まるよう設計してください。",
        "chk_thermal_title": "熱余裕の確保",
        "chk_thermal_body": "動作温度は{op}{st}です。筐体の最悪周囲温度において、"
                            "ディレーティング・自己発熱・風量を検証する必要があります。",
        "chk_package_title": "パッケージとピン配置の早期確定",
        "chk_package_body": "{pkg}{pins}{dims}がフットプリント、熱経路、ピン割り当てを規定します。"
                            "レイアウト前に最新リビジョンで確認してください。",
        "chk_elec_title": "重要な電気的限界の確認",
        "chk_elec_body": "主要な仕様は{list}です。見出しの数値ではなく、"
                         "実際の測定条件と併せて確認してください。",
        "chk_relief_title": "放熱とグラウンドの確認",
        "chk_relief_body": "最大出力負荷時、熱的限界を決めるのはデバイスではなく基板です。"
                           "十分な風量を確保し、測定性能を信用する前にコネクタシールドの"
                           "グラウンド基準を確認してください。",
        "chk_board_title": "ボードの電源レールとジャンパ設定の確認",
        "chk_board_dev": "オンボードの{device}を中心に構成されています",
        "chk_board_dev_pkg": "オンボードの{device}（{pkg} パッケージ）を中心に構成されています",
        "chk_board_dev_multi": "複数のデバイスで構成されています",
        "chk_board_body": "この評価ボードは{dev}。信号源を接続する前に、レール選択・"
                          "電流制限・ジャンパ位置をボードのユーザーガイドで確認してください。"
                          "ジャンパの誤設定はボードが無反応に見える最も一般的な原因です。",
        "chk_motor_title": "モータ出力と電流設定の確認",
        "chk_motor_body": "モータを接続する前に、相出力、電流設定回路、バルク電源容量を"
                          "確認してください。電流制限が高すぎると初回回転でドライバ段を"
                          "壊す最短経路になり、無負荷電源ではアプリケーションよりはるかに"
                          "低い電流しか流れません。",
        "chk_led_title": "LED ストリング出力と電流設定の確認",
        "chk_led_body": "ストリング配線、電流設定回路、各ストリング用の独立 DC 電源を"
                        "確認してください。通電前にストリングの順方向電圧がコンバータ"
                        "出力範囲に収まることを確認してください。収まらない場合、チャネルは"
                        "レギュレーションから外れるか LED を過駆動します。",
        "chk_clock_title": "インターフェースとクロック入力の確認",
        "chk_clock_body": "クロック源を接続する前に、ボードのユーザーガイドに記載された"
                          "クロック入力、その周波数と終端要件を確認してください。",
    },
    "ko": {
        "chk_rails_title": "절대 최대 정격 레일 준수",
        "chk_rails_body": "절대 최대 정격은 {list}을(를) 제한합니다. 주변 부품을 선정하기 전에 "
                          "전원 시퀀스와 과도 변동이 이 범위 안에 있도록 설계하십시오.",
        "chk_thermal_title": "열 여유 확보",
        "chk_thermal_body": "동작 온도는 {op}{st}입니다. 인클로저의 최악 주위 온도에서 "
                            "디레이팅, 자체 발열, 공기 흐름을 검증해야 합니다.",
        "chk_package_title": "패키지와 핀 배치 조기 확정",
        "chk_package_body": "{pkg}{pins}{dims}이(가) 풋프린트, 열 경로, 핀 할당을 규정합니다. "
                            "레이아웃 전에 최신 리비전과 대조해 확인하십시오.",
        "chk_elec_title": "핵심 전기적 한계 확인",
        "chk_elec_body": "주요 사양은 {list}입니다. 표제 수치가 아니라 실제 시험 조건과 함께 "
                         "확인하십시오.",
        "chk_relief_title": "방열과 접지 검토",
        "chk_relief_body": "최대 출력 부하에서 열 한계를 결정하는 것은 소자가 아니라 보드입니다. "
                           "충분한 공기 흐름을 확보하고, 측정 성능을 신뢰하기 전에 커넥터 실드의 "
                           "접지 기준을 확인하십시오.",
        "chk_board_title": "보드 전원 레일과 점퍼 설정 확인",
        "chk_board_dev": "온보드 {device}를 중심으로 구성되어 있습니다",
        "chk_board_dev_pkg": "온보드 {device}({pkg} 패키지)를 중심으로 구성되어 있습니다",
        "chk_board_dev_multi": "여러 소자로 구성되어 있습니다",
        "chk_board_body": "이 평가 보드는 {dev}. 신호원을 연결하기 전에 레일 선택, "
                          "전류 제한, 점퍼 위치를 보드 사용자 가이드와 대조하십시오. "
                          "점퍼 오설정은 보드가 무반응으로 보이는 가장 흔한 원인입니다.",
        "chk_motor_title": "모터 출력과 전류 설정 확인",
        "chk_motor_body": "모터를 연결하기 전에 상 출력, 전류 설정 회로, 벌크 전원 용량을 "
                          "확인하십시오. 전류 제한이 너무 높으면 첫 구동에서 드라이버 단을 "
                          "손상시키는 가장 빠른 경로가 되며, 무부하 전원은 애플리케이션보다 "
                          "훨씬 낮은 전류만 보여 줍니다.",
        "chk_led_title": "LED 스트링 출력과 전류 설정 확인",
        "chk_led_body": "스트링 배선, 전류 설정 회로, 스트링별 독립 DC 전원을 확인하십시오. "
                        "전원을 인가하기 전에 스트링 순방향 전압이 컨버터 출력 범위 안에 "
                        "있는지 확인하십시오. 그렇지 않으면 채널이 레귤레이션을 벗어나거나 "
                        "LED를 과구동합니다.",
        "chk_clock_title": "인터페이스와 클록 입력 확인",
        "chk_clock_body": "클록 소스를 연결하기 전에 보드 사용자 가이드에 기재된 클록 입력과 "
                          "그 주파수 및 종단 요건을 확인하십시오.",
    },
    "de": {
        "chk_rails_title": "Absolutmessgrenzen der Versorgungsrails beachten",
        "chk_rails_body": "Die Absolutmessgrenzen begrenzen {list}. Einschaltreihenfolge und "
                          "Transienten müssen innerhalb dieser Grenzen ausgelegt sein, bevor die "
                          "Peripherie ausgewählt wird.",
        "chk_thermal_title": "Thermische Reserve einplanen",
        "chk_thermal_body": "Die Betriebstemperatur beträgt {op}{st}. Derating, Eigenerwärmung "
                            "und Luftführung sind bei der ungünstigsten Umgebungstemperatur des "
                            "Gehäuses zu verifizieren.",
        "chk_package_title": "Gehäuse und Pinbelegung früh festlegen",
        "chk_package_body": "{pkg}{pins}{dims} bestimmen Footprint, Wärmepfad und Pinzuordnung; "
                            "vor dem Layout gegen die aktuelle Revision prüfen.",
        "chk_elec_title": "Kritische elektrische Grenzwerte prüfen",
        "chk_elec_body": "Die maßgeblichen Spezifikationen sind {list}. Jeden Wert zusammen mit "
                         "den tatsächlichen Testbedingungen prüfen, nicht nur die Kopfzahl.",
        "chk_relief_title": "Wärmeableitung und Masseführung prüfen",
        "chk_relief_body": "Bei maximaler Ausgangslast bestimmt die Platine und nicht das "
                           "Bauteil die thermische Grenze. Für ausreichende Luftführung sorgen "
                           "und den Massebezug an den Steckerschirmen prüfen, bevor Messwerten "
                           "vertraut wird.",
        "chk_board_title": "Versorgungsrails und Jumperstellung der Platine prüfen",
        "chk_board_dev": "um das onboard verbaute {device} aufgebaut",
        "chk_board_dev_pkg": "um das onboard verbaute {device} im {pkg}-Gehäuse aufgebaut",
        "chk_board_dev_multi": "aus mehr als einem Bauteil aufgebaut",
        "chk_board_body": "Dieses Evaluierungsboard ist {dev}. Vor dem Anschluss einer "
                          "Signalquelle Rail-Auswahl, Strombegrenzung und Jumperstellungen "
                          "gegen das Board-Handbuch prüfen; ein falscher Jumper ist die "
                          "häufigste Ursache für ein scheinbar totes Board.",
        "chk_motor_title": "Motorausgänge und Stromeinstellung prüfen",
        "chk_motor_body": "Vor dem Anschluss eines Motors Phasenausgänge, Stromeinstellnetzwerk "
                          "und Zwischenkreiskapazität prüfen. Eine zu hoch gesetzte "
                          "Strombegrenzung beschädigt die Treiberstufe beim ersten Lauf am "
                          "schnellsten, und eine unbelastete Versorgung zeigt einen viel "
                          "geringeren Strom als die Anwendung benötigt.",
        "chk_led_title": "LED-String-Ausgänge und Stromeinstellung prüfen",
        "chk_led_body": "String-Verdrahtung, Stromeinstellnetzwerk und die separate "
                        "DC-Versorgung je String prüfen. Vor dem Einschalten sicherstellen, dass "
                        "die Flussspannung des Strings im Ausgangsbereich des Wandlers liegt, "
                        "sonst fällt der Kanal aus der Regelung oder übersteuert die LEDs.",
        "chk_clock_title": "Schnittstelle und Takteingänge prüfen",
        "chk_clock_body": "Vor dem Anschluss einer Taktquelle den dokumentierten Takteingang "
                          "samt Frequenz- und Abschlussanforderungen im Board-Handbuch prüfen.",
    },
    "es": {
        "chk_rails_title": "Respete los raíles de máximos absolutos",
        "chk_rails_body": "Los máximos absolutos limitan {list}. Diseñe la secuencia de "
                          "alimentación y los transitorios dentro de estos límites antes de "
                          "elegir los componentes del entorno.",
        "chk_thermal_title": "Reserve margen térmico",
        "chk_thermal_body": "La temperatura de funcionamiento es {op}{st}. El derating, el "
                            "autocalentamiento y el flujo de aire deben verificarse en la "
                            "temperatura ambiente más desfavorable del recinto.",
        "chk_package_title": "Fije pronto el encapsulado y el pinout",
        "chk_package_body": "{pkg}{pins}{dims} define el footprint, la ruta térmica y la "
                            "asignación de pines; confírmelo con la revisión vigente antes del "
                            "layout.",
        "chk_elec_title": "Verifique los límites eléctricos críticos",
        "chk_elec_body": "Las especificaciones dominantes son {list}. Confirme cada una con sus "
                         "condiciones de ensayo reales, no solo con la cifra destacada.",
        "chk_relief_title": "Revise la disipación térmica y la masa",
        "chk_relief_body": "A plena carga de salida es la placa, no el dispositivo, la que fija "
                           "el límite térmico. Asegure flujo de aire suficiente y confirme la "
                           "referencia de masa en los blindajes de los conectores antes de "
                           "fiarse de cualquier medida.",
        "chk_board_title": "Verifique los raíles de alimentación y los jumpers de la placa",
        "chk_board_dev": "está construida en torno al {device} integrado en la placa",
        "chk_board_dev_pkg": "está construida en torno al {device} integrado en la placa, en encapsulado {pkg}",
        "chk_board_dev_multi": "está ensamblada a partir de más de un dispositivo",
        "chk_board_body": "Esta placa de evaluación {dev}. Confirme la selección de raíl, el "
                          "límite de corriente y la posición de los jumpers con la guía de la "
                          "placa antes de conectar cualquier fuente de señal; un jumper mal "
                          "puesto es la causa más común de una placa que parece muerta.",
        "chk_motor_title": "Compruebe las salidas de motor y el ajuste de corriente",
        "chk_motor_body": "Verifique las salidas de fase, la red de ajuste de corriente y la "
                          "capacidad de la alimentación antes de conectar un motor. Un límite de "
                          "corriente demasiado alto es la vía más rápida a dañar la etapa de "
                          "potencia en el primer giro, y una fuente sin carga mostrará mucha "
                          "menos corriente de la que necesita la aplicación.",
        "chk_led_title": "Compruebe las salidas de tiras LED y el ajuste de corriente",
        "chk_led_body": "Verifique el conexionado de las tiras, la red de ajuste de corriente y "
                        "la alimentación DC independiente de cada tira. Confirme que la tensión "
                        "directa de la tira queda dentro del rango de salida del convertidor "
                        "antes de aplicar tensión; de lo contrario el canal sale de regulación "
                        "o sobrexita los LED.",
        "chk_clock_title": "Compruebe la interfaz y las entradas de reloj",
        "chk_clock_body": "Revise la entrada de reloj documentada, su frecuencia y sus "
                          "requisitos de terminación en la guía de la placa antes de conectar "
                          "una fuente de reloj.",
    },
}
for _lang, _entries in _CHECKS_I18N.items():
    STATIC_I18N[_lang].update(_entries)


def tr(lang: str, key: str, **kw) -> str:
    """查静态词条；缺省回退英文；带 {kw} 占位则 format。

    顺带记两个计数（`i18n_keys_used` / `i18n_key_fallbacks`）—— 复核方要的是
    **实测覆盖率**，不是一句 `i18n_complete: true`。没有分母就只能自述。
    """
    diag = _RENDER_DIAGNOSTICS.get()
    if diag is not None and lang != "en":
        diag["i18n_keys_used"] = diag.get("i18n_keys_used", 0) + 1
    s = STATIC_I18N.get(lang, {}).get(key)
    if not s:
        if diag is not None and lang != "en":
            diag["i18n_key_fallbacks"] = diag.get("i18n_key_fallbacks", 0) + 1
            diag["fallback_events"].append({"key": key, "requested_lang": lang,
                                            "actual_lang": "en", "source": "static"})
        s = STATIC_I18N["en"][key]
    return s.format(**kw) if kw else s


class Doc:
    """缩进感知的行构造器（模板用 tab 缩进）。"""

    def __init__(self) -> None:
        self.lines: list[str] = []

    def __call__(self, level: int, text: str = "") -> None:
        self.lines.append("\t" * level + text if text else "")

    def text(self) -> str:
        return "\n".join(self.lines)


def section_head(d: Doc, lv: int, key: str, title: str, sec_id: str) -> None:
    d(lv, f'<section class="pd-sec" id="{sec_id}">')
    d(lv + 1, '<div class="pd-sec-head">')
    d(lv + 2, '<div class="pd-badge">')
    d(lv + 3, BADGE[key])
    d(lv + 2, "</div>")
    d(lv + 2, '<h2 class="pd-sec-title">')
    d(lv + 3, title)
    d(lv + 2, "</h2>")
    d(lv + 1, "</div>")
    d(lv + 1, '<div class="pd-sec-body">')


def section_end(d: Doc, lv: int) -> None:
    d(lv + 1, "</div>")
    d(lv, "</section>")


def para(d: Doc, lv: int, html: str) -> None:
    d(lv, "<p>")
    d(lv + 1, html)
    d(lv, "</p>")


def table(d: Doc, lv: int, headers: list[str], rows: list[list[str]], widths: list[int]) -> None:
    d(lv, '<table class="pd-table" style="width:100%;min-width:0;table-layout:fixed;'
         'overflow-wrap:break-word;word-break:normal;">')
    cols = "".join(f'<col style="width:{w}%;" />' for w in widths)
    d(lv + 1, f"<colgroup>{cols}</colgroup>")
    d(lv + 1, "<tbody>")
    d(lv + 2, "<tr>")
    for h in headers:
        d(lv + 3, "<th>")
        d(lv + 4, esc(h))
        d(lv + 3, "</th>")
    d(lv + 2, "</tr>")
    for row in rows:
        d(lv + 2, "<tr>")
        for cell in row:
            d(lv + 3, "<td>")
            # 允许调用方传 HTML 片段（<strong>…</strong>）；但 "< 3 ns" 这类
            # 以比较号开头的裸值不能误判（< 后必须紧跟标签名）
            d(lv + 4, cell if re.match(r"^<[a-zA-Z/][^<>]*>", cell) else esc(cell))
            d(lv + 3, "</td>")
        d(lv + 2, "</tr>")
    d(lv + 1, "</tbody>")
    d(lv, "</table>")


# ---------------------------------------------------------------- 内容推导
def product_name(doc: dict) -> str:
    sub = clean((doc.get("basic_info") or {}).get("subcategory"))
    if sub:
        return sub
    return clean((doc.get("basic_info") or {}).get("category")) or "Electronic Component"


# 「原文未规定」sentinel：库内沿用，渲染层必须吞掉，不能当文案输出
_BLANK_SENTINELS = {"not_specified", "not specified", "unspecified", "unknown",
                    "n/a", "na", "none", "null", "-", "—", "--"}


def _is_blank_sentinel(s: str) -> bool:
    return (s or "").strip().lower() in _BLANK_SENTINELS


def _range_text(entry: dict) -> str:
    """把 MIN/MAX 语义渲染成 `min to max`，绝不用连字符冒充区间。

    `-4 VREF - 4 VREF` 在页面上会被读成「减 4 VREF」，客户验收时正是抓住了
    这条（A2 类：模型把 PDF 的 MIN/MAX 两列拼成一个字符串）。优先用审计回填的
    `columns_raw`（PDF 真值），其次用 postprocess 落下的 `range`。
    """
    raws = entry.get("columns_raw") or entry.get("columns") or {}
    if raws:
        if raws.get("MIN") is not None and raws.get("MAX") is not None and "TYP" not in raws:
            return f"{clean(raws['MIN'])} to {clean(raws['MAX'])}"
        return " / ".join(f"{clean(raws[k])} {k}" for k in ("MIN", "TYP", "MAX")
                          if raws.get(k) is not None)
    rng = safe_range(entry)
    if isinstance(rng, dict) and rng.get("min") is not None and rng.get("max") is not None:
        return f"{clean(rng['min'])} to {clean(rng['max'])}"
    return ""


def spec_value(item: dict) -> str:
    """`value` + `unit` 合成一格。`unit` 是「原文未规定」sentinel 时不拼。

    解析层用 `not_specified` 表示「原文没这一格」（见 qc/cheatsheet.py，绝不自造值），
    但那是**库内口径**不是给人看的文案。直接拼会渲染成 `12-bit not_specified`，
    实测已随英文正文与 4 个语种一起发出去过。

    区间优先走 :func:`_range_text`：`-4 VREF - 4 VREF` → `-4 VREF to 4 VREF`。
    只有 MIN/TYP/MAX 三列齐全（table_audit 的 `"4.5 MIN / 5.0 TYP / 5.5 MAX"`）
    才保留 `/` 形式，那是三列语义，不是区间。
    """
    v = _range_text(item) or clean(item.get("value"))
    u = clean(item.get("unit"))
    if u and _is_blank_sentinel(u):
        u = ""
    if u and u.lower() not in v.lower():
        return f"{v} {u}".strip()
    return v


#: 页面打 † 的核验状态。**只列已判定有问题的**，通过态一律不列。
#: `condition_unverified` = 条件串与数值不同源（qc/postprocess_qwen.py）；
#: `column_roles_not_verified` = MIN/TYP/MAX 列角色没对上（qc/table_audit.py）；
#: `not_checked` = 管线自己写下的「本轮没复核」（qc/five_stage_fix.py），
#: V3 交付件 17 条电气行里 9 条是这个 —— 漏掉它就等于把「没核」伪装成「核过了」。
_UNVERIFIED_STATUSES = frozenset({
    "condition_unverified",
    "column_roles_not_verified",
    "unresolved",
    "row_not_located",
    "row_ambiguous",
    "not_checked",
    # 模型抽取的行（qc/deterministic_extract.stamp_model_unverified）。
    # 它不主张值错，只主张**来源**：这一行不是确定性抽取产出的。
    "model_unverified",
    # 行级锚定没命中、只能证明「参数名与数值同页」的行
    # （qc/deterministic_extract.fill_row_anchors 写入）。在 180 页手册里
    # 同页几乎是必然的，它证明不了归属 —— 所以既要打 †，也要在角标上
    # 悬浮说明，不能让读者以为这和已锚定的行一样可靠。
    "label_value_same_page",
    # 以下三个与事实表弱结论同名：`qc/fact_status_sync.py` 会把弱结论
    # （value_in_pdf / partial / not_found）如实写进 verification.status。
    # 不列进本表，页面在缺事实表注入时会把它们当「已核验」而不打 † ——
    # 那正是复审说的「JSON 说一套、页面说另一套」。
    "value_in_pdf", "partial", "not_found",
})

#: 已核验状态：命中即**绝不打标**。确定性抽取的 VCMI（audited_deterministic）
#: 必须落在这里，否则「代码抽出来的三条」会被自己的标记反咬成未核验。
_AUDITED_STATUSES = frozenset({
    "audited", "audited_manual", "audited_deterministic",
    # 行级锚定（bbox + row_sha256 + 可重放指纹）
    "audited_row_anchored",
    # 正文条目级锚定（bbox + 段落指纹）。V6 起用于**符号量**的绝对最大额定值：
    # `–0.3V to AVDD +0.3V` 这类值拆不出 MIN/MAX，但可以确认原文这一行印的就是
    # 这个值 —— 主张的是「有出处且逐字一致」，不是「列角色已解析」。
    "audited_paragraph",
    # 坐标级（bbox + 数值、无可重放行指纹）与容器级（名称+数值可复现、无坐标）。
    # 两者是 `qc/fact_status_sync.STATUS_OF` 的强结论目标，以前漏登记，
    # 同步词表与渲染词表因此对不上（1102-V2 P1 顺带补齐）。
    "audited_coord", "audited_container",
    "verified", "pass", "ok", "deterministic",
})


def _source_pdf_url(bi: dict) -> str:
    """页面「源 PDF」链接取哪个字段。

    板卡件的 `datasheet_url` 会被 `qc/identity_scope.py` 主动清空并搬到
    `device_datasheet_url`（理由：那份 PDF 讲的是板上器件，不是这块板）。
    但清空之后页面就没链接了 —— V4 的 `ADS8568EVM-PDK` / `BOOSTXL-C2KLED`
    两件实测 `ti.com` 出现 0 次（Reviewer 新-1 的另一半）。
    搬走的是链接、不是出处，页面仍应指过去；板卡口径的措辞由
    `board_source_no_guide` 那段负责，不靠藏链接来区分主体。
    """
    for k in ("datasheet_url", "device_datasheet_url"):
        v = str(bi.get(k) or "").strip()
        if v:
            return v
    return ""


def _doc_noun(lang: str, bi: dict) -> str:
    """源文档类型的**称谓**（datasheet / user guide / …）。

    Reviewer P1：`BOOSTXL-C2KLED` 的源文件是 SPRUHH9 用户指南，页面却写
    "manufacturer datasheet"。类型由 `basic_info.doc_type` 给出（装配期从
    URL 路径 `/lit/ug/` 与文档号前缀确定性判定），判不出就用中性词 `document`，
    不硬说成 datasheet。
    """
    dt = str(bi.get("doc_type") or "").strip()
    key = {"datasheet": "doc_datasheet", "user_guide": "doc_user_guide",
           "application_note": "doc_application_note",
           "white_paper": "doc_white_paper", "manual": "doc_manual"}.get(dt)
    return tr(lang, key or "doc_generic")


def _sentence(s: str) -> str:
    """补句号，但已有句末标点时不重复。

    五种语言的模板里有些自带句号（en/de/es）有些自带 `。`（ja/ko），
    调用点统一 `+ "."` 就会印出 `user guide..`（Reviewer P1 实测）。
    """
    t = (s or "").strip()
    return t if t.endswith((".", "。", "．", "!", "?", "！", "？")) else t + "."


def _verify_status(item: dict) -> str:
    v = item.get("verification")
    if isinstance(v, dict):
        return str(v.get("status") or "").strip().lower()
    return ""


def _facts_verdict(item: dict) -> str:
    """事实表给这一行的结论（`label → verdict`）；没有就返回空串。

    只有**事实表覆盖到的行**才走这条路：它逐行回打了 PDF，比 JSON 里那句
    自述更严。事实表没覆盖的行（不在五个容器里的）仍按 JSON 状态判，
    免得「没查」被当成「查过了」。
    """
    m = _FACTS_VERDICTS.get()
    if not m:
        return ""
    lab = str(item.get("name") or item.get("parameter")
              or item.get("symbol") or "").strip()
    if not lab:
        return ""
    cond = str(item.get("condition") or item.get("conditions") or "").strip()
    # 键是 `label \x1f 条件`：AC 表同一个 parameter 会因测试条件不同出现十几条，
    # 只按 label 查会让「一条弱证据」把同名的十条全部打成 †。
    v = m.get(f"{lab}\x1f{cond}")
    if v:
        return str(v)
    pre = lab + "\x1f"
    hits = [str(val) for k, val in m.items() if k.startswith(pre)]
    if hits:
        return min(hits, key=lambda x: _FACTS_RANK.get(x, 99))
    return ""


def _is_unverified(item: dict) -> bool:
    """该行是否需要在页面上标 †。

    Reviewer V3 新-1 的要点是**页面必须能看见核验状态**。V3 交付件里
    17 条电气行 = 9 条 `not_checked` + 5 条 `unresolved` + 3 条
    `condition_unverified`，页面实测这些字样出现 0 次 —— 读者看到的是一张
    「看起来都对」的规格表，内部治理不落到页面等于没有治理。

    判据刻意用「黑名单 + 字面兜底」而不是白名单：将来新增的未核验状态只要
    名字里带 `unverified` / `unresolved` / `not_verified` 就自动可见，不必回来
    改渲染层；而通过态显式列在 `_AUDITED_STATUSES`，不会被误标。

    **完全没写 `verification` 的行不打标**：那是「管线没表态」，不是「管线说
    没核过」。没表态的情况由 `metadata` 的来源链负责，页面上不臆断。
    数据侧由 `stamp_model_unverified()` 在落盘前统一补 `model_unverified`，
    所以走到这里还空着的行，只可能来自不经过解析管线的旧 JSON。
    """
    s = _verify_status(item)
    # 2026-11-03 P0（外审 7.7/10 的第 1 条）：**两把尺取更差的那把，不许互相覆盖**。
    # 旧实现是「事实表有结论就以它为准」，结果 LM317 的 11 条电气行里 8 条
    # `verification.status=unresolved`，而事实表把同一批行判成 `verified_row`
    # （只证明「值锚到了某一行」，不证明「这行审过了」）→ 页面一条 † 都没有，
    # 还印了绿色的「All 11 entries below are anchored」。这是**披露失真**：
    # 管线自己写下的 unresolved 被另一套口径悄悄洗白了。
    # 判据因此改成并集：任一把尺说「没审完」就打标。只会多打、不会少打 ——
    # 与 `_FACTS_RANK`「多条候选取最弱」同一条纪律。
    json_bad = False
    if s and s not in _AUDITED_STATUSES:
        json_bad = (s in _UNVERIFIED_STATUSES
                    or "unverified" in s or "unresolved" in s
                    or "not_verified" in s)
    fv = _facts_verdict(item)
    facts_bad = bool(fv) and fv not in _FACTS_OK
    return json_bad or facts_bad


def _verify_mark(item: dict) -> str:
    """行尾角标。**纯文本**，不带标签 —— `table()` 只对以标签开头的整格放行
    HTML，这里拼在数值后面，塞 `<span>` 会被转义成字面量（踩过双层实体）。
    角标含义由表头上方的说明条解释。"""
    return " †" if _is_unverified(item) else ""


def _verify_cell(item: dict, value: str, lang: str = "en") -> str:
    """数值格 + 核验角标；弱证据行额外挂一个**悬浮说明**。

    ChatGPT 8.0 复审的原话是「找不到行就老老实实留在风险队列里，并在 † 角标
    旁边加个悬浮提示」。说明条只能讲总数（`18 of 22 entries …`），讲不了
    「这一行为什么是弱证据」—— 而读者最需要的正是那一句。

    为什么要整格包 `<span>`：`table()` 只对**以标签开头**的整格放行 HTML，
    在 `spec_value(e) + " †"` 后面拼标签会被整体转义成字面量。所以这里
    返回完整的一格，并且自己 `esc()` 内层文本（`spec_value()` 给的是裸文本）。
    """
    if not _is_unverified(item):
        return value
    st = _verify_status(item)
    # `unresolved` 单独一档：外审要求「行内必须能看见，且要显眼」。
    # 除红色 † 外再挂 `data-verify-status` —— 机器读者（盲审模型、脚本）不必
    # 解析 CSS 就能取到这一行的核验状态，人读者看到的是红字 + 悬浮说明。
    if st == "unresolved" or st.startswith("unresolved"):
        tip = esc(tr(lang, "verify_tip_unresolved"))
        return (f'<span class="pd-verify-flag pd-verify-unresolved" '
                f'data-verify-status="{esc(st)}" title="{tip}" '
                f'style="color:#b3261e;font-weight:600;'
                f'border-bottom:1px dotted #b3261e;cursor:help;">'
                f'{esc(value)} †</span>')
    if _facts_verdict(item) == "value_on_label_page" or \
            _verify_status(item) == "label_value_same_page":
        tip = esc(tr(lang, "verify_tip_same_page"))
        return (f'<span title="{tip}" style="border-bottom:1px dotted #c98a00;'
                f'cursor:help;">{esc(value)} †</span>')
    return value + " †"


def _verify_note(text: str) -> str:
    """说明条。样式内联：`pd-verify-note` 是新类，站点 CSS 里还没有，
    只靠 class 会渲染成一段和正文无差别的斜体，等于没提示。"""
    return ('<em class="pd-verify-note" style="display:block;border-left:3px solid #c98a00;'
            'padding:2px 0 2px 8px;font-style:normal;font-size:.92em;opacity:.85;">'
            f'{esc(text)}</em>')


def _verify_ok_note(text: str) -> str:
    """正向提示条（V6 复审 新-5）。

    ADC 页 `†` = 0、`unverified` 出现 0 次 —— 这是 108/108 全锚定的结果，
    是好事，但**正面结论没有展示**：读者既不知道「全部已核验」，
    也失去了「这一页可信」的证据。没有告警和没有检查长得一模一样，
    所以全锚定时反过来把结论印出来。
    """
    return ('<em class="pd-verify-ok" style="display:block;border-left:3px solid #1f7a3f;'
            'padding:2px 0 2px 8px;font-style:normal;font-size:.92em;opacity:.85;">'
            f'{esc(text)}</em>')


#: 规格区里**所有**会落到事实表、也会印到页面上的容器。
#: 正向提示条要按这个全集统计口径，不能只数电气表和最大值表 ——
#: 漏掉的那三张（热阻 / ESD / AC）在页面上就成了「没告警也没说没问题」。
_FACT_CONTAINERS = ("electrical", "absolute_max", "thermal", "esd", "ac_performance")

_SPEC_LABEL = {"electrical": "specs_lbl_electrical",
               "absolute_max": "specs_lbl_absmax",
               "thermal": "specs_lbl_thermal",
               "esd": "specs_lbl_esd",
               "ac_performance": "specs_lbl_ac"}


#: 板卡参数归属的渲染顺序：整板 → 板载器件 → 未定。
#: 整板在前是有意的：读者先要知道「这块板能接什么」，再看板上那颗芯片的能力。
_BUCKET_ORDER = ("board_level", "onboard_device", "unresolved")

#: 合同层把「不属于整板」的行搬进这两个桶（`qc/scope_contract.canonical_view`）。
#: 只搬 `electrical` / `absolute_max` / `temperature` / `pin_configuration`，
#: `ac_performance` / `thermal` / `esd` **不在搬运范围** —— 所以 ADS8568EVM-PDK
#: （挂的是 SBAS543 器件手册）的 6 条 SNR/SFDR + 6 条热阻 + 2 条 ESD 仍然留在主表，
#: 读者会把芯片的 ±2000 V 当成整板 ESD 能力。渲染层必须自己按 `attribution` 收口。
_ISOLATED = {"onboard_device_specs": "onboard_device",
             "unresolved_specs": "unresolved"}


def _spec_rows(specs: dict, container: str, is_board: bool,
               dropped: list[dict] | None = None) -> list[dict]:
    """取某个容器的**全部**行：主表 + 合同层两个隔离桶。

    芯片页只取主表 —— 隔离桶是治理层，不是内容层，不该凭空回到页面上。

    V11 P0-1：AC 表在出口再筛一次。JSON 若还是旧的、脏行没被搬进
    `unresolved_ac_rows`，渲染层也必须自己拦住 `max="dB"` —— 否则客户会看到
    一个把单位当上限的规格表。物理隔离由 `qc/ac_quarantine.py` 负责，
    这里是最后一道防线。
    """
    out: list[dict] = []
    rows = specs.get(container)
    if isinstance(rows, list):
        out.extend(r for r in rows if isinstance(r, dict))
    if is_board:
        for key, default in _ISOLATED.items():
            bucket = specs.get(key)
            if not isinstance(bucket, dict):
                continue
            rows = bucket.get(container)
            if not isinstance(rows, list):
                continue
            for r in rows:
                if isinstance(r, dict):
                    r.setdefault("attribution", default)
                    out.append(r)
    if container == ac_quarantine.AC:
        out = ac_quarantine.filter_rows(out)
    # 1102V2 P0：合同层把整张电气表搬进板载器件桶时，会把 AC 参数一起复制
    # 过去（`ADS8568EVM-PDK` 实测 4 条 SNR/SFDR/THD/隔离度）。它们没有独立
    # bbox/row_sha256，物理隔离由 `qc/ac_quarantine.py` 负责；这里再拦一次，
    # 旧 JSON 还没跑隔离时也不许把「已声明扣押」的 AC 数印在电气表里。
    # 只对板卡件生效：芯片页主电气表的 AC 行是原表内容，不是逃逸。
    #
    # 扣下的行必须能被调用方拿到并披露（`dropped`）：隔离桶为空的老 JSON
    # 只走这条兜底时，页面上 `unresolved_ac_rows` 计数是 0、`specs_ac_withheld`
    # 不会触发，于是 4 行被无声抹掉 —— 这比印错更难发现（G0 无静默）。
    if container == "electrical" and is_board:
        kept = ac_quarantine.filter_electrical_rows(out, facts=_FACTS_VERDICTS.get())
        if dropped is not None and len(kept) != len(out):
            kept_ids = {id(r) for r in kept}
            dropped.extend(r for r in out if id(r) not in kept_ids)
        out = kept
    return out


def _bucket_groups(rows: list[dict]) -> list[tuple[str, list[dict]]]:
    """按行级 `attribution`（`qc/board_scope.py` 写入）分组。

    任何一行都没有 `attribution` 时返回单组 `("", rows)` —— 芯片页不该因为
    多了个分组标题而变形。个别行缺 attribution 时归到 `unresolved`：
    没分类就是没分类，不塞进任何一个已判定的组里。
    """
    if not any(isinstance(r, dict) and r.get("attribution") for r in rows):
        return [("", rows)]
    out: dict[str, list[dict]] = {}
    for r in rows:
        s = str((r or {}).get("attribution") or "")
        if s not in _BUCKET_ORDER:
            s = "unresolved"
        out.setdefault(s, []).append(r)
    return [(s, out[s]) for s in _BUCKET_ORDER if out.get(s)]


_BUCKET_TITLE = {"board_level": "scope_board_level",
                 "onboard_device": "scope_onboard_device",
                 "unresolved": "scope_unresolved"}


def _need_heads(groups: list[tuple[str, list[dict]]], is_board: bool) -> bool:
    """要不要印桶标题：**只有真的分了桶才印**。

    单桶 `onboard_device` 不在这里处理 —— 那种情况由规格段开头的
    `board_specs_not_stated` / `scope_onboard` 一句声明统一覆盖
    （「以下数值描述的是板载 ADS8568，不是整板限值」）。
    逐表再重复四遍「On-board device parameters」只会变成噪音。
    """
    return len(groups) > 1


def _sub_title(d, text: str) -> None:
    """规格区内的小节标题，与热阻 / ESD / AC 用同一套层级。"""
    d(2, '<h3 class="pd-sub-title" style="margin:18px 0 8px;font-size:1.05em;">')
    d(3, esc(text))
    d(2, "</h3>")


def _bucket_head(d, lang: str, bucket: str) -> None:
    """三个桶的小标题。只有真的分了组才印。"""
    d(2, '<h3 class="pd-sub-title" style="margin:18px 0 8px;font-size:1.02em;">')
    d(3, esc(tr(lang, _BUCKET_TITLE[bucket])))
    d(2, "</h3>")
    if bucket == "unresolved":
        para(d, 2, f"<em>{esc(tr(lang, 'scope_unresolved_note'))}</em>")


def _scope_note(d, lang: str, onboard: str) -> None:
    """板卡页的归属声明：「下面这些是板载器件的值，不是整板限值」。

    电气段、热阻、ESD、AC 四处都要印一遍 —— 复核方不会记得规格区开头那句话
    管到这里，而「芯片 ±2500 V 被读成整板 ESD 能力」是实打实会误导人的。
    器件名未知时走 `_plain` 版，否则模板自带的 "onboard" 会和兜底词叠成
    「onboard onboard device」。
    """
    _sk = "scope_onboard" if onboard else "scope_onboard_plain"
    para(d, 2, f"<em>{esc(tr(lang, _sk, device=esc(onboard)))}</em>")


def group_pins(pins: list[dict]) -> list[tuple[str, str, str]]:
    """同名引脚合并：[(pin_numbers, name, description), ...]"""
    order, acc = [], {}
    for p in pins:
        name = clean(p.get("name"))
        num = p.get("pin")
        key = name.lower()
        if key not in acc:
            acc[key] = {"nums": [], "name": name, "desc": clean(p.get("description"))}
            order.append(key)
        if num not in acc[key]["nums"]:
            acc[key]["nums"].append(num)
    out = []
    for k in order:
        it = acc[k]
        nums = ", ".join(str(n) for n in it["nums"] if n not in (None, ""))
        out.append((nums, it["name"], it["desc"]))
    return out


def _soft_lower(s: str) -> str:
    """'Supply voltage' -> 'supply voltage'，但不动 LVCMOS / ±25ppm 这类词。"""
    return s[0].lower() + s[1:] if re.match(r"^[A-Z][a-z]", s) else s


def split_feature(text: str) -> tuple[str, str]:
    """特性一句话 -> 卡片标题 + 说明。

    **绝不按连字符切断**。旧实现把冒号和连字符混在同一个字符集里，于是
    ``Supports 8.2–52 V and up to 4.5 A`` 被切成 ``Supports 8.2`` / ``52 V...``，
    客户验收时直接抓到（BOOST-DRV8711 的 8.2-52 V 被拆断）。

    规则：
    1. 有冒号且左半 6~52 字符 → 冒号是作者写的分隔符，可以切；
    2. 太长（>60）只在分句边界（``;`` / `` and `` / `` with `` / `` up to ``）切，
       且左半 20~55 字符；不按字符中点硬切，更不碰数字附近的空白；
    3. 其余整句作为标题、说明留空 —— 宁可不切，也不要造出半句。

    说明为空时渲染层不会输出 ``pd-card-desc``，也就不会出现
    ``12-bit resolution`` 标题下面再复读一句 ``12-bit resolution.``。
    """
    t = clean(text).rstrip(".")
    if not t:
        return "", ""
    if ":" in t:
        left, right = t.split(":", 1)
        left, right = left.strip(), right.strip()
        if 6 <= len(left) <= 52 and right:
            return left, right
    if len(t) > 60:
        for pat in (r";\s+", r"\s+(?=and\s)", r"\s+(?=with\s)",
                    r"\s+(?=up to\s)"):
            for m in re.finditer(pat, t):
                left, right = t[:m.start()].strip(), t[m.end():].strip()
                if 20 <= len(left) <= 55 and len(right) >= 15 \
                        and not re.match(r"^[\d.+-]", right):
                    return left, right
    return t, ""


def _pair_items(x) -> list[tuple[str, str]]:
    """json 里手写的卡片/问答列表 -> [(标题, 正文)]。
    兼容两种写法：[{"title"/"q": .., "body"/"a": ..}] 与 [["t", "b"], ...]。
    排版推导（split_feature / FAQ 模板拼接）只在 json 没给内容时兜底，
    避免「Benefits 拆两半」「FAQ 套话」这类凑数观感。"""
    out: list[tuple[str, str]] = []
    if isinstance(x, list):
        for it in x:
            if isinstance(it, dict):
                t = clean(it.get("title") or it.get("q") or it.get("question"))
                b = clean(it.get("body") or it.get("a") or it.get("answer"))
            elif isinstance(it, (list, tuple)) and len(it) >= 2:
                t, b = clean(it[0]), clean(it[1])
            else:
                continue
            if t and b:
                out.append((t, b))
    return out


def _insight_of(doc: dict, mle: dict) -> tuple[str, list[tuple[str, str]]]:
    """technical insight：json/mle 手写优先，返回 (问题句, [(标题, 正文)])。"""
    raw = mle.get("technical_insight") or doc.get("technical_insight")
    if isinstance(raw, dict):
        q = clean(raw.get("question"))
        checks = _pair_items(raw.get("checks"))
        if q and checks:
            return q, checks
    return "", []


#: 板卡 Expert Insight 的**受控话术词表**（evidence-gated rendering）。
#: 判据是「源数据里有没有支持这句话的证据词」，不是型号白名单——
#: 客户反馈③「板卡统一套 SMA/抖动说明」就是无证据话术：步进驱动板既没有
#: SMA 也没有时钟输入，却照样印了「Verify the SMA connectors … onboard
#: oscillator」。反过来，真带 SMA 的高速板只要 features / connectors /
#: 电气表的 symbol·condition 里出现这些词，该句照常渲染，不会误杀。
_CLOCK_SMA_EVIDENCE = ("sma", "jitter", "clock input", "clock source",
                       "external clock", "50ω", "50 ohm", "termination")
_MOTOR_EVIDENCE = ("stepper", "motor", "h-bridge", "h bridge", "actuator", "solenoid")
_LED_EVIDENCE = ("led", "lighting", "lamp", "string current")


def _board_evidence_blob(doc: dict) -> str:
    """板卡话术的证据面：features / applications / connectors / 电气表的符号与条件。

    电气表也要算进来：真 RF 板的 `fCLK`、`jitter` 通常落在电气表而不是散文里，
    只看 features 会漏证据、把该渲染的句子误杀。
    """
    sp = doc.get("specs") or {}
    parts = [str(x) for x in (doc.get("features") or [])]
    parts += [str(x) for x in (doc.get("applications") or [])]
    parts += [str(x) for x in (sp.get("connectors") or [])]
    for e in (sp.get("electrical") or []):
        parts.append("%s %s %s" % (e.get("symbol") or "", e.get("name") or "",
                                   e.get("condition") or ""))
    for e in ((sp.get("onboard_device_specs") or {}).get("electrical") or []):
        parts.append("%s %s %s" % (e.get("symbol") or "", e.get("name") or "",
                                   e.get("condition") or ""))
    return " ".join(parts).lower()


def _has_evidence(blob: str, tokens: tuple[str, ...]) -> bool:
    return any(re.search(r"(?<![a-z0-9])" + re.escape(t) + r"(?![a-z0-9])", blob, re.I)
               for t in tokens)


def board_evidence(doc: dict) -> dict:
    """单源能力门控。器件备份不授予板卡接口；否定/可选项不当装配事实。"""
    sp = doc.get("specs") or {}
    parts = [str(x) for x in (doc.get("features") or []) + (doc.get("applications") or [])]
    blob = " ".join(parts).lower()
    result = {"motor": _has_evidence(blob, _MOTOR_EVIDENCE),
              "led": _has_evidence(blob, _LED_EVIDENCE), "interface": False, "clock": False}
    if sp.get("scope") != "board":
        return result
    evidence = [str(x) for x in (sp.get("connectors") or [])]
    evidence += [" ".join(str(e.get(k) or "") for k in ("name", "symbol", "condition"))
                 for e in (sp.get("electrical") or [])
                 if (e.get("source") or {}).get("scope") == "board"]
    for text in evidence:
        if re.search(r"\b(no|without|not fitted|unpopulated|optional)\b", text, re.I):
            continue
        result["interface"] |= bool(re.search(r"\bSMA\b|\bconnector\b", text, re.I))
        result["clock"] |= bool(re.search(r"\b(clock input|clock source|external clock|fCLK)\b", text, re.I))
    return result


# ---------------------------------------------------------------- 渲染
def render(doc: dict, lang: str = "en", diagnostics: dict | None = None) -> str:
    diagnostics = diagnostics if diagnostics is not None else {}
    diagnostics.setdefault("fallback_events", [])
    _diag_token = _RENDER_DIAGNOSTICS.set(diagnostics)
    # 事实表结论注入：页面 † 从此由 `qc/fact_acceptance.py` 说了算。
    # 复核方 V5 复审 新-3 的原话是「同一个包里『哪些行已核验』有两种答案」——
    # JSON 的 `verification.status` 说已锚定，事实表说只到同页。两套尺子必然
    # 会分叉，所以只留一把：事实表更严，页面跟它走。
    _fv_token = _FACTS_VERDICTS.set(
        (doc.get("metadata") or {}).get("facts_verdicts") or None)
    doc = canonical_view(doc)
    bi = doc.get("basic_info") or {}
    specs = doc.get("specs") or {}
    elec = specs.get("electrical") or []
    amax = specs.get("absolute_max") or []
    pkg = specs.get("package") or {}
    temp = specs.get("temperature") or {}
    feats = [clean(x) for x in (doc.get("features") or []) if clean(x)]
    apps = [clean(x) for x in (doc.get("applications") or []) if clean(x)]
    pins = doc.get("pin_configuration") or []
    orders = doc.get("ordering_info") or []
    alts = doc.get("alternatives") or []
    meta = doc.get("metadata") or {}

    # 叙述性内容本地化：multi_language[lang] 优先，缺失回退英文
    ml = doc.get("multi_language") or {}
    mle = ml.get(lang) or {} if lang != "en" else {}
    feats_l = [clean(x) for x in (mle.get("features") or []) if clean(x)] or feats
    apps_l = [clean(x) for x in (mle.get("applications") or []) if clean(x)] or apps

    mpn = clean(bi.get("mpn")) or "Unknown"
    mfr = clean(bi.get("manufacturer")) or "the manufacturer"
    desc = clean(bi.get("description"))
    pkg_type = clean(pkg.get("type"))
    pins_n = pkg.get("pins") or 0
    # `not_specified` 是库内哨兵，不能当文案（"operating range of not specified"）
    op_temp = "" if _is_blank_sentinel(clean(temp.get("operating"))) \
        else clean(temp.get("operating"))
    st_temp = "" if _is_blank_sentinel(clean(temp.get("storage"))) \
        else clean(temp.get("storage"))
    dims = clean(pkg.get("dimensions"))
    sep = tr(lang, "sep")

    # 评估板 / 模块身份（EVK 请求号共用芯片 datasheet 时，解析侧容易把板当芯片）：
    # 只有 basic_info.identity 显式声明才走板卡口径，存量型号渲染不受影响。
    is_board = clean(bi.get("identity")) in BOARD_TYPES
    # 板卡的商品名是单数「Evaluation Board」，不能沿用 subcategory 的复数
    pname = "Evaluation Board" if is_board else product_name(doc)
    onboard = clean(pkg.get("onboard_device"))
    onboard_pkg = clean(pkg.get("onboard_package")) if pkg.get("onboard_package_status") == "mounted_verified" else ""
    pin_desc_l = mle.get("pin_desc") if isinstance(mle.get("pin_desc"), dict) else {}

    d = Doc()
    # en 页保持原样（与既有交付字节一致）；变体页标 lang 便于站点/爬虫识别
    if lang == "en":
        d(0, '<div class="pd-wrap">')
    else:
        d(0, f'<div class="pd-wrap" lang="{lang}">')

    # ---- hero
    d(0, '<header class="pd-hero">')
    d(1, '<div class="pd-hero-inner">')
    # 分类路径（Reviewer V4 复审 新-4）：JSON 里 `category_path` 已经是
    # `Integrated Circuits (ICs) / Data Acquisition / ADCs`，但页面只印
    # `category`（粗）与 `subcategory`（自由文本 `Data Converters`），
    # 实测 `Data Acquisition` 与 `ADCs` 在页面上命中 0 次 —— 需求方看到的
    # 分类粒度没有任何变化。路径是站内类目的**规范名**，不翻译（与 MIN/TYP/MAX 同理），
    # 译了反而和站点后台的类目树对不上。
    _path = [clean(x) for x in (bi.get("category_path") or []) if clean(x)]
    if len(_path) < 2:
        _path = [x for x in (clean(bi.get("category")),
                             clean(bi.get("subcategory"))) if x]
    if _path:
        d(2, '<nav class="pd-crumb" aria-label="category" '
             'style="font-size:.82em;letter-spacing:.02em;opacity:.72;'
             'margin:0 0 8px;line-height:1.5;">')
        d(3, esc(" \u203a ".join(_path)))
        d(2, "</nav>")
    d(2, '<h1 class="pd-hero-title">')
    # en 页 <h1> 用 seo.json 的 title_en（Reviewer V3 新-5）：
    # 交付说明写着「片段 <h1> 已使用 seo.json 对应语种标题」，实测只对
    # ja/ko/de/es 成立（那几个语种的 multi_language[lang].title 就是 seo 标题的
    # 译文），en 页仍是 `{mpn} {subcategory}`。声明与事实不符，要么改文案要么
    # 改渲染 —— 这里选后者：en 与四语种口径一致，h1 才真正承接 SEO 标题。
    _h1 = clean(mle.get("title"))
    if not _h1 and lang == "en":
        _h1 = clean((doc.get("seo") or {}).get("title_en"))
    d(3, esc(_h1 or f"{mpn} {pname}"))
    d(2, "</h1>")
    d(2, '<p class="pd-hero-desc">')
    # hero 只给首句，overview 段还会展开同一段描述：overview 侧必须剥掉这句前缀，
    # 否则页面上会出现两段一字不差的文字（CF-QC28-012）。
    _desc_src = clean(mle.get("description")) or desc or f"{mpn} from {mfr}."
    hero_txt = _lead_sentence(_desc_src) or first_sentence(_desc_src)
    d(3, esc(hero_txt))
    d(2, "</p>")
    d(1, "</div>")
    d(0, "</header>")

    # ---- 1. overview + technical insight
    section_head(d, 0, "intro", tr(lang, "overview_title", mpn=mpn), "product-introduction")
    desc_l = clean(mle.get("description")) or desc
    # 剥掉 hero 已经用掉的首句：overview 只讲 hero 没覆盖的部分
    _cropped = False
    # hero 若被 first_sentence 兜底截断（无句末标点），说明整句超长：此时裁剪必然
    # 切在句中，宁可保留完整描述（首句重复）也不产出半句。
    if desc_l and hero_txt and re.search(r"[.!?。！？]$", hero_txt.strip()):
        _rest = _strip_prefix(desc_l, hero_txt)
        if _rest:
            _rest = _rest.lstrip(" ，,;；.。:：-")
            # 切点落在助词/收尾标点上说明这句还没说完，宁可不裁也不要半句
            if _rest and not re.match(r"^[はがをにのへで、。，）)]", _rest):
                desc_l = _depronoun(_rest, mpn, lang)
                _cropped = True
                if desc_l and lang == "en" and not desc_l[0].isupper():
                    desc_l = desc_l[0].upper() + desc_l[1:]
    if lang != "en" and desc_l:
        # 译文是完整句（"Der SN74… ist…" / "SN74… は…"）：以型号开头则加粗，否则整句直出
        if desc_l.upper().startswith(mpn.upper()):
            para(d, 2, f"<strong>{esc(mpn)}</strong> {esc(desc_l[len(mpn):].lstrip(' ，,:：-').strip())}")
        else:
            para(d, 2, esc(desc_l))
    elif _cropped and desc_l:
        para(d, 2, esc(desc_l))
    elif desc:
        # 模型给的描述常以 "The <MPN> is ..." 开头，先剥冠词再判断，
        # 否则会渲染成 "NE555 is The NE555 is a precision timer"。
        lead = re.sub(r"^(?:the|a|an)\s+", "", desc.strip(), flags=re.I)
        if lead.lower().startswith(mpn.lower()):
            para(d, 2, f"<strong>{esc(mpn)}</strong> {esc(lead[len(mpn):].lstrip(' ,:-').strip())}")
        else:
            para(d, 2, f"<strong>{esc(mpn)}</strong> is {esc(desc)}")
    else:
        para(d, 2, f"<strong>{esc(mpn)}</strong> is a {esc(pname.lower())} from {esc(mfr)}.")
    if feats_l and not is_board:
        if lang != "en":
            para(d, 2, esc(tr(lang, "caps_prefix", list=sep.join(feats_l[:3]))))
        else:
            caps = [_soft_lower(f.rstrip(".")) for f in feats_l[:3]]
            para(d, 2, "Key capabilities include " + "; ".join(esc(c) for c in caps) + ".")
    if apps_l and not is_board:
        para(d, 2, esc(tr(lang, "used_prefix", list=sep.join(apps_l[:4]))))
    facts = []
    if is_board:
        # 评估板口径：不说「54-Pin WQFN 封装的芯片」，说「板载 {device}」
        # 板载封装未知时不要拼出「in a  package」这种半句（BOOST-DRV8711 会走到）
        if onboard_pkg:
            para(d, 2, tr(lang, "board_fact", mpn=esc(mpn), device=esc(onboard or "device"),
                          pkg=esc(onboard_pkg)) + ".")
        else:
            para(d, 2, tr(lang, "board_fact_plain", mpn=esc(mpn)) + ".")
    else:
        # 这三段以前是硬编码英文（`the … package` / `an operating range of …` /
        # `N documented orderable options`），韩语页整段显示英文（Reviewer
        # V4 复审 新-1）。改走五语模板 + 语言相关的列表连接词：日语用「、」，
        # 德语末项用「und」，英语「, and 」。
        if pkg_type:
            facts.append(tr(lang, "sup_pkg_pins" if pins_n else "sup_pkg",
                            pkg=esc(pkg_type), n=pins_n or ""))
        if op_temp:
            facts.append(tr(lang, "sup_op", op=esc(op_temp)))
        if orders:
            facts.append(tr(lang, "sup_order1") if len(orders) == 1
                         else tr(lang, "sup_orders", n=len(orders)))
        if facts:
            para(d, 2, tr(lang, "supplied_tpl", mpn=esc(mpn),
                          list=_join_list(lang, facts)))
    if is_board:
        if clean(specs.get("scope")) == "onboard_device":
            # 源 PDF 是板上器件的 datasheet，不是这块板的用户指南：不能再用
            # "values on this page come from the datasheet" 这种口径冒充板级规格
            para(d, 2, _sentence(esc(tr(lang, "board_source_no_guide", mfr=mfr,
                                        device=onboard or "onboard device"))))
        elif elec or amax:
            para(d, 2, _sentence(esc(tr(lang, "board_values_from_guide", mfr=mfr))))
        # 板卡也是原厂板卡，首屏同样必须给出 Manufacturer + 板载器件 + 溯源链接。
        # V9 实测：`ADS8568EVM-PDK` 全页只有一个 ti.com 链接，还藏在页脚的
        # Manufacturer 段 —— `identity_scope` 把 `datasheet_url` 搬到
        # `device_datasheet_url` 后，板卡分支又整段跳过了带链接的 `values_source`
        # （原 `elif facts:` 只对芯片件成立），读者在首屏既看不到品牌也拿不到出处。
        # `_source_pdf_url()` 会回退取 `device_datasheet_url`，所以这里一定能拿到链接。
        _src_url = _source_pdf_url(bi)
        para(d, 2, tr(lang, "board_mfr", mfr=f"<strong>{esc(mfr)}</strong>",
                      mpn=esc(mpn), device=esc(onboard or "device")))
        if _src_url:
            para(d, 2, esc(tr(lang, "mfr_line2_pre", doc=_doc_noun(lang, bi)))
                 + f' <a href="{esc(_src_url)}" rel="nofollow">{esc(tr(lang, "mfr_link"))}</a>. '
                 + tr(lang, "mfr_line2_post"))
        else:
            para(d, 2, tr(lang, "mfr_line2_nolink", doc=_doc_noun(lang, bi))
                 + " " + tr(lang, "mfr_line2_post"))
    elif facts:
        _src_url = _source_pdf_url(bi)
        para(d, 2, esc(tr(lang, "values_source", mfr=mfr,
                          doc=_doc_noun(lang, bi)))
             + (f' (<a href="{esc(_src_url)}" rel="nofollow">{esc(tr(lang, "source_pdf"))}</a>)'
                if _src_url else "") + ".")

    # technical insight：json / multi_language 手写内容优先（五语齐备）；
    # 缺省才从数据推导检查点（英文兜底，存量型号行为不变）
    d(2, '<div class="pd-expert-insight">')
    d(3, "<h3>")
    d(4, tr(lang, "insight"))
    d(3, "</h3>")
    ins_q, ins_checks = _insight_of(doc, mle)
    d(3, "<p>")
    d(4, f"<strong>{esc(ins_q or tr(lang, 'insight_q', mpn=mpn))}</strong>")
    d(3, "</p>")
    d(3, "<ul>")
    checks = list(ins_checks)
    if not checks and is_board:
        # 板卡兜底：买板子的人不画封装，关心的是电源、跳线、接口和散热。
        # 原来的「Lock the Package and Pinout Early」在这里是纯噪声——而且因为
        # 板卡的 pkg_type 恒为 "Evaluation Board"，`if pins or pkg_type` **每次都命中**。
        # 正文最终由 `esc(body)` 统一转义，所以这里传**裸值**：
        # 之前 `_dev` 先 esc 一次、渲染时再 esc 一次，含 & / < 的器件名会变
        # `&amp;amp;`（与电气表那处是同一个坑）。
        # `_dev` 本身也要走词表 —— 否则韩语页会出现
        # 「이 평가 보드는 built around the onboard ADS8568입니다」这种半英半韩。
        if not onboard:
            _dev = tr(lang, "chk_board_dev_multi")
        elif onboard_pkg:
            _dev = tr(lang, "chk_board_dev_pkg", device=onboard, pkg=onboard_pkg)
        else:
            _dev = tr(lang, "chk_board_dev", device=onboard)
        checks.append((
            tr(lang, "chk_board_title"),
            tr(lang, "chk_board_body", dev=_dev)))
        # 接口检查点走**证据门控**：源数据（features / applications /
        # connectors / 电气表 symbol·name·condition）里没有对应证据词，就
        # 不渲染这句话——既不按型号黑名单硬删，也不给所有板卡套同一句
        # 「Verify the SMA connectors … onboard oscillator」（客户反馈③）。
        _cap = board_evidence(doc)
        if _cap["motor"]:
            checks.append((tr(lang, "chk_motor_title"), tr(lang, "chk_motor_body")))
        elif _cap["led"]:
            checks.append((tr(lang, "chk_led_title"), tr(lang, "chk_led_body")))
        elif _cap["clock"]:
            checks.append((tr(lang, "chk_clock_title"), tr(lang, "chk_clock_body")))
        # 无证据 → 不渲染接口句。宁可少一条，也不产出无源陈述（G3 渲染侧化身）。
        checks.append((tr(lang, "chk_relief_title"), tr(lang, "chk_relief_body")))
    if not checks:
        rails = [x for x in (amax or []) if re.search(r"vdd|vcc|vin|voltage|supply", clean(x.get("name")), re.I)][:2]
        if rails:
            checks.append((tr(lang, "chk_rails_title"),
                           tr(lang, "chk_rails_body", list="; ".join(
                               f"{clean(r.get('name'))} to {spec_value(r)}" for r in rails))))
        if op_temp or st_temp:
            checks.append((tr(lang, "chk_thermal_title"),
                           tr(lang, "chk_thermal_body",
                              op=op_temp or "not stated",
                              st=(f", storage {st_temp}" if st_temp else ""))))
        if pins or pkg_type:
            checks.append((tr(lang, "chk_package_title"),
                           tr(lang, "chk_package_body",
                              pkg=pkg_type or "package",
                              pins=(f" ({pins_n} pins)" if pins_n else ""),
                              dims=(f", {dims}" if dims else ""))))
        if elec:
            checks.append((tr(lang, "chk_elec_title"),
                           tr(lang, "chk_elec_body", list="; ".join(
                               f"{clean(e.get('name'))} = {spec_value(e)}" for e in elec[:3]))))
    for title, body in checks[:3]:
        d(4, "<li>")
        d(5, f"<strong>{esc(title)}:</strong> {esc(body)}")
        d(4, "</li>")
    d(3, "</ul>")
    d(2, "</div>")
    section_end(d, 0)

    # ---- 2. key benefits（json / multi_language 手写卡片优先；缺省才劈 features 凑卡）
    bens = _pair_items(mle.get("benefits") or doc.get("benefits"))
    if bens or feats_l:
        section_head(d, 0, "benefits", tr(lang, "key_benefits"), "key-benefits")
        d(2, '<div class="pd-grid2">')
        cards = bens or [split_feature(f) for f in feats_l[:4]]
        for title, body in cards[:4]:
            # 复读机校验：`12-bit resolution` 标题 + 同文说明是最刺眼的模板病。
            # 归一化后相同就不再输出 desc（只留标题）。
            if body and re.sub(r"\s+", " ", body).strip().rstrip(".").lower() == \
                    re.sub(r"\s+", " ", title).strip().rstrip(".").lower():
                body = ""
            d(3, '<div class="pd-card">')
            d(4, '<div class="pd-card-title">')
            d(5, f'<span class="pd-pin"></span>{esc(title)}')
            d(4, "</div>")
            if body:
                d(4, '<p class="pd-card-desc">')
                d(5, esc(body if body.endswith(".") else body + "."))
                d(4, "</p>")
            d(3, "</div>")
        d(2, "</div>")
        section_end(d, 0)

    # ---- 3. specifications
    section_head(d, 0, "specs", tr(lang, "electrical_specs"), "specifications")
    # 评估板/模块的电气表是**板载器件**参数，不是板卡级限值：必须先声明 scope，
    # 否则读者会把它当成整板规格（CF-QC28-012 审核意见 P2）。
    _bscope = clean(specs.get("scope"))
    # 电气表必须和热阻/ESD/AC 走**同一个取数入口**（主表 + 合同层隔离桶）。
    # V8 复审 新-1 实测的 bug 就在这一行：guard 用的是未合并的 `elec`，
    # 表体用的却是合并后的 `_spec_rows(...)`。ADS8568EVM-PDK 的主表 electrical
    # 被合同层整锅搬进 `onboard_device_specs`（主表 0 条），guard 判空 → 24 条
    # 板载电气行一条没印；同一隔离桶里的 amax 走 `_spec_rows` 却照常印了 11 条，
    # 于是同一个桶里两张表一半在一半不在。事实表审了全部 49 行、13 条弱证据把
    # `anchor_gate` 卡成 blocked，读者却看不见被审的行 —— 治理可见、内容不可见，
    # 两头都不成立。
    _elec_dropped: list[dict] = []
    _elec_all = _spec_rows(specs, "electrical", is_board, dropped=_elec_dropped)
    if is_board and _bscope == "onboard_device":
        # 整板规格在源文档里没有 —— 但这**不等于没有电气表**：源文档是板载器件的
        # datasheet，表里每一行都是那颗芯片的值。所以两句都要印：先说「整板限值
        # 未给出、请查用户指南」，再声明「下表描述的是板载器件，不是整板限值」。
        # 只印前一句、表不印，页面就成了「一句声明 + 一片空白」（客户验收原话：
        # 「这不是产品没做完吗」）；只印表不印声明，则回到 -40~125°C 那个幻觉。
        para(d, 2, f"<em>{esc(tr(lang, 'board_specs_not_stated', device=onboard or 'onboard device'))}</em>")
        if _elec_all:
            _scope_note(d, lang, onboard)
    elif _bscope == "onboard_device":
        # 器件名必须来自数据，不能写死——原先五语模板里硬编码了 DS80PCI402，
        # 换一块板就会把别人的器件名印上去。器件名未知时走 plain 版，
        # 否则模板自带的 "onboard"/"搭載" 会和兜底词叠成「onboard onboard device」。
        _sk = "scope_onboard" if onboard else "scope_onboard_plain"
        para(d, 2, f"<em>{esc(tr(lang, _sk, device=esc(onboard)))}</em>")

    if _elec_dropped:
        # 兜底过滤扣下的行必须明说（G0 无静默）：隔离桶为空的老 JSON 只走这条
        # 路径，`_ac_iso` 是 0、`specs_ac_withheld` 不会触发，不补这句就是无声丢数据。
        para(d, 2, _verify_note(tr(lang, "specs_ac_escape_withheld",
                                   n=len(_elec_dropped))))

    # 正向提示条改成**按容器全页汇总**（V8 复审 新-3）。
    # 之前每张表各印一句 `All N entries below ...`，但只有电气表和最大值表有这个
    # 分支，热阻 / ESD / AC 三张压根没写 —— ADC 页 108 行里只有 37 行被正向确认，
    # 剩下 64 条 AC 参数 + 8 条热阻/ESD 落在「没告警，也没说没问题」的灰区，
    # 而这两种状态在页面上长得一模一样。现在全页全锚定时只印一句，覆盖所有容器；
    # 只有部分表干净时仍按表印，读者才知道干净的是哪一张。
    _spec_containers = [(k, rows) for k in _FACT_CONTAINERS
                        if (rows := _spec_rows(specs, k, is_board))]
    _n_all = sum(len(r) for _, r in _spec_containers)
    _n_unv_all = sum(1 for _, r in _spec_containers for e in r if _is_unverified(e))
    _page_all_ok = bool(_n_all and not _n_unv_all)
    if _page_all_ok:
        _detail = ", ".join(f"{tr(lang, _SPEC_LABEL[k])} {len(r)}"
                            for k, r in _spec_containers)
        para(d, 2, _verify_ok_note(tr(lang, "specs_verify_all_page",
                                      total=_n_all, detail=_detail)))
    if _elec_all:
        def _elec_block(sub: list[dict]) -> None:
            """一张电气表 + 它自己的核验说明与条件汇总。"""
            # 核验状态必须**页面可见**（Reviewer V3 新-1）：
            # V3 交付件 17 条电气行全是未核验态（9 not_checked + 5 unresolved +
            # 3 condition_unverified），但页面实测这些字样出现 0 次 —— 读者看到的
            # 仍是一张「看起来都对」的规格表。内部治理不落到页面，等于没有治理。
            n_unv = sum(1 for e in sub if _is_unverified(e))
            if n_unv:
                para(d, 2, _verify_note(tr(lang, "specs_verify_note",
                                           n=n_unv, total=len(sub))))
            elif len(sub) >= 3 and not _page_all_ok:
                # 全锚定也要说（V6 复审 新-5）：0 个 † 不等于「没检查」。
                # 全页都干净时这句由段首那条汇总说了，不再每张表重复一遍。
                para(d, 2, _verify_ok_note(tr(lang, "specs_verify_all",
                                              total=len(sub))))
            # cell 传裸值：table() 统一负责 esc（历史上这里预 esc 过一次、table() 又
            # esc 一次，值里的 & / > 被转成 &amp;amp; / &amp;gt; 双层实体）
            # 没有测试条件的行不再重复印 17 遍 "Datasheet conditions apply."：
            # 那既不提供信息，又让人以为条件「已确认无特殊」。破折号 + 一条汇总。
            n_nocond = sum(1 for e in sub if not clean(e.get("condition")))
            rows = [[clean(e.get("name")), _verify_cell(e, spec_value(e), lang),
                     clean(e.get("condition")) or "—"] for e in sub]
            table(d, 2, [tr(lang, "th_param"), tr(lang, "th_value"),
                         tr(lang, "th_cond")], rows, [26, 32, 42])
            if n_nocond:
                para(d, 2, esc(tr(lang, "specs_cond_missing", n=n_nocond)))

        # 板卡类：整板参数与板载器件参数**必须分开**（ChatGPT 8.0 复审 P1）。
        # `specs.scope` 只有一个值，盖不住「用户指南里两类参数都有」的情况，
        # 于是 DRV8711 的 `Continuous Current per H-Bridge = 4.5 A` 会和
        # `Voltage Range 8.2 to 52 V`（外部电源输入）印在同一张表里，
        # 读者会拿器件能力当整板能力。
        # 三桶来源见 `_spec_rows()`：主表 + 合同层两个隔离桶，
        # 行级 `attribution`（qc/board_scope.py）在同一桶内再细分。
        _grp = _bucket_groups(_elec_all)
        if _need_heads(_grp, is_board):
            for _b, sub in _grp:
                _bucket_head(d, lang, _b)
                _elec_block(sub)
        elif _grp[0][1]:
            # 单桶板载器件表：桶标题（`On-board device parameters`）太小太泛，
            # 而且 V8 之前这张表压根没印过，页面第一眼需要一句**带器件名**的
            # 显式小节名，读者才知道「这一坨数值是谁的」。
            # 芯片页/整板页不走这里，一个字都不变。
            if is_board and _bscope == "onboard_device":
                dev = onboard or tr(lang, "scope_onboard_plain_dev")
                _sub_title(d, tr(lang, "specs_onboard_elec_title", device=dev))
            _elec_block(_grp[0][1])
    _amax_all = _spec_rows(specs, "absolute_max", is_board)
    if _amax_all:
        para(d, 2, tr(lang, "absmax_warn"))
        _g = _bucket_groups(_amax_all)
        for _b, _sub in _g:
            if _need_heads(_g, is_board):
                _bucket_head(d, lang, _b)
            n_unv = sum(1 for e in _sub if _is_unverified(e))
            if n_unv:
                para(d, 2, _verify_note(tr(lang, "specs_verify_note_amax",
                                           n=n_unv, total=len(_sub))))
            elif len(_sub) >= 3 and not _page_all_ok:
                para(d, 2, _verify_ok_note(tr(lang, "specs_verify_all",
                                              total=len(_sub))))
            rows = [[clean(e.get("name")), _verify_cell(e, spec_value(e), lang),
                     tr(lang, "absmax_row")] for e in _sub]
            table(d, 2, [tr(lang, "th_param"), tr(lang, "th_limit"),
                         tr(lang, "th_notes")], rows, [26, 32, 42])

    # 热阻 / ESD 必须落到页面（Reviewer V3 P1-8）：
    # V3 的失败是「JSON 里没有」，V4 前半程修好了 JSON，但渲染层**从来就没输出过
    # 这两个容器** —— 页面实测 `23.9` / `±2000` 出现 0 次。JSON 有了页面看不见，
    # 和没有一样，客户拿到的仍是一张查不到结温与静电耐受的规格表。
    for key, title_key in (("thermal", "specs_thermal_title"),
                           ("esd", "specs_esd_title")):
        # 合同层**不搬** thermal / esd（只搬 electrical / absolute_max / 温度 / 引脚），
        # 所以板卡页上这两张表必须由渲染层自己按 attribution 收口，
        # 否则 ADS8568EVM-PDK 会把 ADS8568 芯片的 ±2000 V 印成整板 ESD 能力。
        _rows_src = _spec_rows(specs, key, is_board)
        if not _rows_src:
            continue
        _g = _bucket_groups(_rows_src)
        # 大标题一次。单桶时这就是原来的样子（芯片页一个字都不变）；
        # 多桶时大标题在上、桶标题在下，与电气表同一套层级。
        d(2, '<h3 class="pd-sub-title" style="margin:18px 0 8px;font-size:1.05em;">')
        d(3, esc(tr(lang, title_key)))
        d(2, "</h3>")
        _heads = _need_heads(_g, is_board)
        # 板卡页：热阻 / ESD 同样要声明归属（复核方 V5 复审 新-4）。
        # 电气段那句声明挂在规格区开头，隔着一整张表之后读者已经接不上了；
        # 实测 ADS8568EVM-PDK 的 `RθJA 22 °C/W` 与 `HBM ±2500 V` 就那样
        # 裸印在页面上，读者会把芯片的 ±2500 V 当成整板 ESD 能力。
        if is_board and _bscope == "onboard_device":
            _scope_note(d, lang, onboard)
        for _b, rows_src in _g:
            if _heads:
                _bucket_head(d, lang, _b)
            n_unv = sum(1 for e in rows_src if _is_unverified(e))
            if n_unv:
                para(d, 2, _verify_note(tr(lang, "specs_verify_note_amax",
                                           n=n_unv, total=len(rows_src))))
            elif rows_src and not _page_all_ok:
                # 热阻/ESD 以前只有「有 † 」分支，全锚定就一个字都不印 ——
                # 「没告警」和「没检查」在页面上无法区分（V8 复审 新-3 的灰区）。
                # 1102 复审：ESD 表只有 2 行，被「≥3 行才印」的门槛挡掉，
                # 整张表一处披露都没有。短表同样需要结论 —— 门槛改为「有行就印」。
                para(d, 2, _verify_ok_note(tr(lang, "specs_verify_all",
                                              total=len(rows_src))))
            # Reviewer P1（1102 复审）：热阻表 7 行、ESD 表 8 行的条件列全是同一句
            # 「Datasheet conditions apply.」，重复 15 遍既不提供信息，又让人以为
            # 条件「已确认无特殊」。与电气表统一：无条件就印破折号，末尾一条汇总。
            n_nocond = sum(1 for e in rows_src if not clean(e.get("condition")))
            rows = [[clean(e.get("name")), _verify_cell(e, spec_value(e), lang),
                     clean(e.get("condition")) or "—"] for e in rows_src]
            table(d, 2, [tr(lang, "th_param"), tr(lang, "th_value"),
                         tr(lang, "th_cond")], rows, [26, 32, 42])
            if n_nocond:
                para(d, 2, esc(tr(lang, "specs_cond_missing", n=n_nocond)))

    # AC 指标（Reviewer P1）：ADC 页面此前 SNR / SFDR / NSD / IMD3 出现 0 次。
    # 每条都必须带**选择它的测试条件**——同一个 SNR 在 fIN=2397/4197/5997 MHz 与
    # AIN=–1/–3/–12 dBFS 下是 12 个不同的数，去掉条件就成了误导。
    _ac_all = _spec_rows(specs, "ac_performance", is_board)
    # V11：脏行已被 qc/ac_quarantine.py 物理搬出正式容器。
    # ac_performance 变空**不是**说这个型号没有 AC 指标，而是说有若干行
    # 没过列角色闸门、先扣下了。页面不印这句，读者会把「我们主动扣下」
    # 读成「原厂没给」—— 这比印错更糟，因为错误不可见。
    _ac_iso = [r for r in (specs.get("unresolved_ac_rows") or [])
               if isinstance(r, dict)]
    if not _ac_all and _ac_iso:
        d(2, '<h3 class="pd-sub-title" style="margin:18px 0 8px;font-size:1.05em;">')
        d(3, esc(tr(lang, "specs_ac_title")))
        d(2, '</h3>')
        para(d, 2,
             _verify_note(tr(lang, "specs_ac_withheld", n=len(_ac_iso))))
    if _ac_all:
        _g = _bucket_groups(_ac_all)
        d(2, '<h3 class="pd-sub-title" style="margin:18px 0 8px;font-size:1.05em;">')
        d(3, esc(tr(lang, "specs_ac_title")))
        d(2, "</h3>")
        _heads = _need_heads(_g, is_board)
        if is_board and _bscope == "onboard_device":
            _scope_note(d, lang, onboard)
        for _b, ac in _g:
            if _heads:
                _bucket_head(d, lang, _b)
            # AC 表以前连**负向**提示都没有：`_verify_mark` 在 SYMBOL 上打了 †，
            # 却没有一句话解释 † 是什么（V8 复审 新-3）。64 条 AC 参数是 ADC 页
            # 最大的一块内容，角标无解释比不给角标更容易被误读成脚注编号。
            n_unv = sum(1 for e in ac if _is_unverified(e))
            if n_unv:
                para(d, 2, _verify_note(tr(lang, "specs_verify_note",
                                           n=n_unv, total=len(ac))))
            elif len(ac) >= 3 and not _page_all_ok:
                para(d, 2, _verify_ok_note(tr(lang, "specs_verify_all",
                                              total=len(ac))))
            para(d, 2, esc(tr(lang, "specs_ac_note")))
            rows = [[clean(e.get("symbol")) + _verify_mark(e),
                     clean(e.get("conditions")) or tr(lang, "specs_cond_default"),
                     clean(e.get("min")), clean(e.get("typ")), clean(e.get("max")),
                     clean(e.get("unit"))] for e in ac]
            # MIN / TYP / MAX / UNIT 沿用原厂表头写法，不翻译：它们是规格表通用记号，
            # 译成「最小/典型」反而与读者手上的 datasheet 对不上。
            table(d, 2, ["SYMBOL", tr(lang, "th_cond"), "MIN", "TYP", "MAX", "UNIT"],
                  rows, [14, 40, 10, 10, 10, 12])

    if not _elec_all and not _amax_all and not (is_board and _bscope == "onboard_device"):
        para(d, 2, esc(tr(lang, "specs_not_stated")))
    section_end(d, 0)

    # ---- 4. package
    section_head(d, 0, "package", tr(lang, "package"), "package")
    if is_board:
        # 评估板：不是「用了什么封装的芯片」，而是「板载什么器件、什么封装」
        para(d, 2, tr(lang, "board_pkg_title", mpn=esc(mpn)))
        if onboard and onboard_pkg:
            para(d, 2, tr(lang, "board_onboard", device=esc(onboard), pkg=esc(onboard_pkg)))
        elif onboard:
            para(d, 2, esc(tr(lang, "board_device_no_package", device=onboard)))
        else:
            # 板载器件未知：不要留空，也不要把芯片封装硬套上去。
            # 说清楚「板上不止一颗器件，请看原厂原理图」，比编一个器件名安全。
            para(d, 2, esc(tr(lang, "board_device_unknown")))
        if dims:
            para(d, 2, esc(tr(lang, "board_dims", dims=dims)))
    else:
        para(d, 2, tr(lang, "pkg_uses_pins_tpl" if pins_n else "pkg_uses_tpl",
                      mpn=esc(mpn), pkg=esc(pkg_type or "standard"),
                      n=pins_n or ""))
        pk_facts = []
        if dims:
            pk_facts.append(tr(lang, "pkg_fact_dims", dims=esc(dims)))
        if op_temp:
            pk_facts.append(tr(lang, "pkg_fact_op", op=esc(op_temp)))
        if st_temp:
            pk_facts.append(tr(lang, "pkg_fact_st", st=esc(st_temp)))
        if pk_facts:
            para(d, 2, tr(lang, "pkg_facts_tpl",
                          list=_join_list(lang, pk_facts)))
    section_end(d, 0)

    # ---- 5. pinout（评估板：口径改为「板载器件的引脚表」；描述可走 mle.pin_desc 译文）
    if pins:
        section_head(d, 0, "pinout", tr(lang, "pinout"), "pinout")
        gp = group_pins(pins)
        if is_board:
            para(d, 2, esc(tr(lang, "board_pinout", device=onboard or "device",
                              pkg=onboard_pkg or pkg_type or "package",
                              n=len(gp), m=pins_n or len(pins))))
        else:
            para(d, 2, esc(tr(lang, "pinout_intro", pkg=pkg_type or "package",
                              n=len(gp), m=pins_n or len(pins))))
        d(2, '<ul class="pd-list">')
        for nums, name, pdesc in gp:
            label = f"{nums} - {name}" if nums else name
            pdesc = clean(pin_desc_l.get(name)) or pdesc
            d(3, "<li>")
            d(4, f"<strong>{esc(label)}:</strong> {esc(pdesc or tr(lang, 'pinout_fallback'))}")
            d(3, "</li>")
        d(2, "</ul>")
        # 引脚描述的语言豁免（Reviewer V4 复审 新-2）：63/67 个 `<li>` 是逐字英文，
        # 因为管脚名与功能描述在硬件工程里保留原文是惯例 —— 译成韩文反而会
        # 和原理图/封装图对不上。但读者看到满屏英文会以为本地化没做完，
        # 所以**必须**在页面说一句。非英文页才印。
        if lang != "en" and gp:
            para(d, 2, f"<em>{esc(tr(lang, 'pin_desc_lang_note'))}</em>")
        section_end(d, 0)

    # ---- 6. orderable / alternatives
    if orders or alts:
        section_head(d, 0, "equiv", tr(lang, "equiv"), "equivalent")
        d(2, '<p class="pd-note pd-compat-note">')
        d(3, tr(lang, "order_check", mfr=esc(mfr), mpn=esc(mpn)))
        d(2, "</p>")
        rows = []
        for o in orders:
            rows.append([clean(o.get("mpn")), tr(lang, "documented_orderable"),
                         ", ".join(x for x in [clean(o.get("package")), clean(o.get("packaging"))] if x) or "-",
                         clean(o.get("marking")) or tr(lang, "mark_default")])
        for a in alts:
            # 列语义是「可订购号 / 订货差异 / 封装或包装 / 选型核对」，不是品牌表。
            # 之前把 manufacturer 塞进第三列（封装或包装），品牌被当成封装发出去过。
            brand = clean(a.get("manufacturer"))
            note = tr(lang, "alt_row_note")
            if brand:
                note = f"{brand} — {note}"
            rows.append([clean(a.get("mpn")),
                         clean(a.get("reason")) or tr(lang, "alt_reason_default"),
                         clean(a.get("package")) or "-",
                         note])
        table(d, 2, [tr(lang, "th_orderable"), tr(lang, "th_order_diff"), tr(lang, "th_packing"), tr(lang, "th_selection")],
              rows, [32, 14, 24, 30])
        section_end(d, 0)

    # ---- 7. manufacturer
    section_head(d, 0, "mfr", tr(lang, "manufacturer"), "manufacturer-information")
    if is_board:
        para(d, 2, tr(lang, "board_mfr", mfr=f"<strong>{esc(mfr)}</strong>",
                      mpn=esc(mpn), device=esc(onboard or "device")))
    else:
        para(d, 2, tr(lang, "mfr_line1", mfr=f"<strong>{esc(mfr)}</strong>",
                      mpn=esc(mpn), pname=esc(pname)))
    _mfr_url = _source_pdf_url(bi)
    if _mfr_url:
        para(d, 2, tr(lang, "mfr_line2_pre", doc=_doc_noun(lang, bi))
             + f' <a href="{esc(_mfr_url)}" rel="nofollow">{esc(tr(lang, "mfr_link"))}</a>. '
             + tr(lang, "mfr_line2_post"))
    elif is_board and _bscope == "onboard_device":
        para(d, 2, esc(tr(lang, "board_mfr_source", device=onboard or "onboard device"))
             + " " + tr(lang, "mfr_line2_post"))
    else:
        para(d, 2, tr(lang, "mfr_line2_nolink", doc=_doc_noun(lang, bi))
             + " " + tr(lang, "mfr_line2_post"))
    # 修订号（Reviewer P1）：页脚印着 `SLVSGH5C – REVISED APRIL 2025`，
    # 确定性抽取后写在这里 —— 读者据此判断手上的 PDF 与页面是否同一版。
    _rev = bi.get("doc_revision") or {}
    if _rev.get("doc_id"):
        _rv = _rev.get("revision") or ""
        para(d, 2, esc(tr(lang, "doc_revision_line", doc_id=_rev["doc_id"],
                          rev_label=f" (Rev. {_rv})" if _rv else "",
                          revised=_rev.get("revised") or _rev.get("issued") or "")))
    section_end(d, 0)

    # ---- 8. applications
    if apps_l:
        section_head(d, 0, "app", tr(lang, "applications"), "application")
        d(2, '<div class="pd-appgrid">')
        for idx, a in enumerate(apps_l[:4]):
            a_en = apps[idx] if idx < len(apps) else a  # 图标/分类按英文关键词匹配
            icon = pick_icon(a_en)
            cat = pick_category(a_en)
            d(3, '<div class="pd-app" style="display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:center;">')
            d(4, '<div class="pd-app-ico" style="flex:0 0 auto;">')
            d(5, f'<img src="/upload/img/{icon}" width="64" height="64" '
                 f'alt="{esc(cat)} application illustration: {esc(a)}" loading="lazy" decoding="async" />')
            d(4, "</div>")
            d(4, '<div class="pd-app-body" style="min-width:0;flex:1 1 260px;">')
            d(5, '<div class="pd-app-title">')
            d(6, esc(a))
            d(5, "</div>")
            d(5, '<div class="pd-app-example">')
            d(6, f"<strong>{esc(tr(lang, 'typical_case'))}</strong> "
                 + esc(tr(lang, "board_app_example" if is_board else "app_example",
                          a=a, mpn=mpn,
                          op_temp=op_temp or tr(lang, "op_temp_default"))))
            d(5, "</div>")
            d(4, "</div>")
            d(3, "</div>")
        d(2, "</div>")
        section_end(d, 0)

    # ---- 9. FAQ（json / multi_language 手写问答优先；缺省才从数据拼接模板问答）
    faqs = _pair_items(mle.get("faq") or doc.get("faq"))
    if not faqs:
        if orders:
            others = [clean(o.get("mpn")) for o in orders if clean(o.get("mpn")) and clean(o.get("mpn")) != mpn]
            if others:
                faqs.append((tr(lang, "faq_orders_q", mpn=mpn),
                             tr(lang, "faq_orders_a", mpn=mpn,
                                pkg=(tr(lang, "faq_orders_pkg", pkg=pkg_type)
                                     if pkg_type else ""),
                                codes=", ".join(others[:4]))))
        if elec:
            faqs.append((tr(lang, "faq_elec_q", mpn=mpn),
                         tr(lang, "faq_elec_a", list=_join_list(lang, [
                             f"{clean(e.get('name'))} = {spec_value(e)}"
                             for e in elec[:4]]))))
        if is_board:
            faqs.append((tr(lang, "board_faq_q", mpn=mpn),
                         tr(lang, "board_faq_yes" if _bscope == "board" and elec else "board_faq_no")))
        elif pins or pkg_type:
            faqs.append((tr(lang, "faq_layout_q", mpn=mpn),
                         tr(lang, "faq_layout_a",
                            pkg=pkg_type or "package",
                            pins=(tr(lang, "faq_layout_pins", n=pins_n)
                                  if pins_n else ""),
                            op=op_temp or tr(lang, "op_temp_default"))))
        if apps_l:
            faqs.append((tr(lang, "faq_apps_q", mpn=mpn),
                         tr(lang, "faq_apps_a",
                            list=_join_list(lang, apps_l[:4]))))
    if faqs:
        section_head(d, 0, "faq", tr(lang, "faq"), "faq")
        d(2, '<div class="pd-faq-list">')
        for q, a in faqs[:4]:
            d(3, '<div class="pd-faq-item">')
            d(4, '<h3 class="pd-faq-q">')
            d(5, esc(q))
            d(4, "</h3>")
            d(4, '<div class="pd-faq-a">')
            d(5, "<div>")
            d(6, "<p>")
            d(7, esc(a))
            d(6, "</p>")
            d(5, "</div>")
            d(4, "</div>")
            d(3, "</div>")
        d(2, "</div>")
        section_end(d, 0)

    # ---- 10. notice
    section_head(d, 0, "notice", tr(lang, "notice"), "disclaimer")
    d(2, '<div class="pd-alert">')
    if is_board and _bscope == "onboard_device":
        para(d, 3, tr(lang, "notice_eng_board_no_guide", mfr=esc(mfr), mpn=esc(mpn),
                      device=esc(onboard or "onboard device"))
             + (f" (parsed {esc(meta.get('parse_timestamp', '')[:10])})" if meta.get("parse_timestamp") else "")
             + ". " + tr(lang, "notice_eng_post_board"))
    else:
        para(d, 3, tr(lang, "notice_eng", mfr=esc(mfr), mpn=esc(mpn))
             + (f" (parsed {esc(meta.get('parse_timestamp', '')[:10])})" if meta.get("parse_timestamp") else "")
             + ". " + tr(lang, "notice_eng_post_board" if is_board else "notice_eng_post"))
    para(d, 3, tr(lang, "notice_order"))
    d(2, "</div>")
    section_end(d, 0)

    d(0, "</div>")
    d(0, '<div class="sr-only">')
    # 板卡没有引脚段，读屏摘要里也不能承诺「pinout」——否则无障碍文本与正文不一致
    d(1, esc(tr(lang, "sr_only_board" if is_board else "sr_only", mpn=mpn,
                pkg=("evaluation board" if is_board else (pkg_type or "package")))))
    d(0, "</div>")
    if lang != "en":
        # 叙述块只统计**真的从 `multi_language` 取文**的三块：features / applications /
        # description。缺了就是英文原文，记回退是对的。
        #
        # `technical_insight` 与 `faq` **不在这里统计**：它们由 `STATIC_I18N`
        # （`chk_*_title/body`）与 `_SENTENCE_I18N`（`faq_*_q/a`）拼出来，
        # 天然就是目标语言。V5 第一版按「`mle` 里有没有这个键」判，
        # 结果把一个**全韩语的 FAQ 记成英文回退** —— 度量误报，不是内容问题。
        # 这两块的词条级回退已经由 `tr()` 的 `i18n_key_fallbacks` 覆盖，不必重复计。
        _narr_blocks = (("features", bool(feats)), ("applications", bool(apps)),
                        ("description", bool(desc)))
        diagnostics["i18n_narrative_total"] = sum(1 for _, ok in _narr_blocks if ok)
        diagnostics["i18n_narrative_fallbacks"] = 0
        for key, value in _narr_blocks:
            if value and not mle.get(key):
                diagnostics["fallback_events"].append({"key": key, "requested_lang": lang,
                                                       "actual_lang": "en", "source": "narrative"})
                diagnostics["i18n_narrative_fallbacks"] += 1
    diagnostics["i18n_complete"] = not diagnostics["fallback_events"]
    # 实测覆盖率：分母 = 静态词条调用次数 + 叙述块数，分子 = 真的落到目标语言的。
    # 复核方要的是这个数，不是 `i18n_complete: true` 这句自述。
    if lang != "en":
        _used = diagnostics.get("i18n_keys_used", 0)
        _kfb = diagnostics.get("i18n_key_fallbacks", 0)
        _narr_total = diagnostics.get("i18n_narrative_total", 0)
        _narr_fb = diagnostics.get("i18n_narrative_fallbacks", 0)
        _den = _used + _narr_total
        diagnostics["i18n_coverage"] = {
            "keys_used": _used, "key_fallbacks": _kfb,
            "narrative_blocks": _narr_total, "narrative_fallbacks": _narr_fb,
            "ratio": round((_den - _kfb - _narr_fb) / _den, 4) if _den else None,
        }
    _RENDER_DIAGNOSTICS.reset(_diag_token)
    _FACTS_VERDICTS.reset(_fv_token)
    return d.text() + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=str(PARSED))
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--only", default="")
    ap.add_argument("--langs", default="en",
                    help="逗号分隔语言列表。en 输出 {mpn}.txt；其余输出 {mpn}.{lang}.txt 变体")
    a = ap.parse_args()

    langs = [x.strip() for x in a.langs.split(",") if x.strip()]
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = sorted(Path(a.src).glob("*.json"))
    if a.only:
        files = [f for f in files if a.only.lower() in f.name.lower()]
    if not files:
        raise SystemExit(f"no json in {a.src}")

    for f in files:
        doc = json.loads(f.read_text(encoding="utf-8"))
        mpn = clean((doc.get("basic_info") or {}).get("mpn")) or f.stem
        base = re.sub(r'[^A-Za-z0-9._-]+', '_', mpn)
        n_lang = 0
        diags: dict[str, dict] = {}
        for lang in langs:
            diag: dict = {}
            html = render(doc, lang, diag)
            dest = out_dir / (f"{base}.txt" if lang == "en" else f"{base}.{lang}.txt")
            dest.write_text(html, encoding="utf-8")
            diags[lang] = diag
            n_lang += 1
        # 侧车：交付清单里的 `i18n_complete` 只能从这里读 —— 打包器是
        # 「只装配已有物料」模式，不允许在打包时重渲染一遍来算覆盖率。
        sidecar = {
            "schema": "i18n-coverage/v1",
            "mpn": mpn,
            "languages": {lg: {"i18n_complete": d.get("i18n_complete"),
                               "i18n_coverage": d.get("i18n_coverage"),
                               "fallback_events": len(d.get("fallback_events") or [])}
                          for lg, d in diags.items()},
            # 引脚描述按硬件工程惯例保留英文原文（IEEE 器件手册口径），
            # 不算「未翻译残留」。页面上有对应小字说明。
            "pin_desc_exempt": bool(doc.get("pin_configuration")),
            "pin_desc_exempt_reason": (
                "pin_configuration descriptions are kept in the source language "
                "(IEEE device-datasheet convention); not an untranslated residue"),
        }
        (out_dir / f"{base}.i18n.json").write_text(
            json.dumps(sidecar, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"{base:<40} ×{n_lang}  <- {f.name}")


if __name__ == "__main__":
    main()
