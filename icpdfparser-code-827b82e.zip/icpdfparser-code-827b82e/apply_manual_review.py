# -*- coding: utf-8 -*-
import csv
import json
import argparse
import sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Apply manual review results to identity replay.")
    parser.add_argument("--input", default="data/manual_review_20261030.csv", help="人工复核填写的 CSV")
    parser.add_argument("--replay", default="data/identity_replay_20261030.csv", help="系统自动跑出的 baseline CSV")
    parser.add_argument("--out-csv", default="data/identity_replay_final.csv", help="合并后的最终 CSV")
    parser.add_argument("--out-json", default="data/identity_patch.json", help="合并后的增量 JSON 补丁")
    parser.add_argument("--do-write", action="store_true", help="真实写盘，不加此参数只做 dry-run")
    
    args = parser.parse_args()
    
    manual_path = Path(args.input)
    replay_path = Path(args.replay)
    
    if not manual_path.exists():
        print(f"找不到人工复核文件: {manual_path}")
        sys.exit(1)
    if not replay_path.exists():
        print(f"找不到 baseline 回放文件: {replay_path}")
        sys.exit(1)

    # 0. 表头守卫：列名不对会读不到任何结论，而"读到 0 件"与"人还没填"
    #    在输出上无法区分 —— 直接空转退出 0 是最危险的假绿形态。
    with open(manual_path, encoding="utf-8-sig") as f:
        header = next(csv.reader(f), [])
    required = ("mpn", "proposed_action")
    missing = [c for c in required if c not in header]
    if missing:
        print(f"复核表缺少必需列：{', '.join(missing)}")
        print(f"  当前表头：{', '.join(header)}")
        print("  提示：分桶原始表（*_raw.csv）不可直接填写；"
              "请用 data/manual_review_20261030.csv。")
        sys.exit(2)

    # 1. 读取人工复核结果
    manual_reviews = {}
    with open(manual_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            mpn = row.get("mpn", "").strip()
            action = row.get("proposed_action", "").strip()
            if mpn and action and action.lower() not in ("", "null", "none", "?"):
                manual_reviews[mpn] = {
                    "action": action,
                    "identity": row.get("proposed_identity", "").strip(),
                    "notes": row.get("notes", "").strip(),
                    "file": row.get("file", "").strip(),
                    "reviewer": row.get("reviewer", "").strip(),
                }

    if not manual_reviews:
        print("人工复核文件中没有填写任何有效 proposed_action，无需合并。")
        print("  这不是成功：说明 proposed_action 列整列为空，或填的值不在")
        print("  board_confirmed / chip / identity_review 之内。")
        sys.exit(2)

    print(f"读取到 {len(manual_reviews)} 件人工复核结论。")

    unsigned = [m for m, v in manual_reviews.items() if not v.get("reviewer")]
    if unsigned:
        print(f"提示：{len(unsigned)} 件有结论但 reviewer 为空（未签字）："
              f"{', '.join(unsigned[:5])}{' …' if len(unsigned) > 5 else ''}")

    # 2. 读取 baseline 回放结果，并准备合并
    final_rows = []
    patch_data = []
    
    blocks_before = 0
    blocks_after = 0
    applied_count = 0

    with open(replay_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        
        if "blocks_release" not in fieldnames:
            print("baseline CSV 缺少 'blocks_release' 列")
            sys.exit(1)

        for row in reader:
            mpn = row.get("mpn", "").strip()
            
            if row.get("blocks_release") == "1":
                blocks_before += 1
                
            if mpn in manual_reviews:
                review = manual_reviews[mpn]
                action = review["action"].lower()
                orig_state = row.get("state")
                orig_identity = row.get("identity")
                
                if action in ("board_confirmed", "board"):
                    row["state"] = "BOARD_CONFIRMED"
                    row["identity"] = review["identity"] or "evaluation_board"
                    row["blocks_release"] = "0"
                elif action in ("chip", "identity_supported"):
                    row["state"] = "IDENTITY_SUPPORTED"
                    row["identity"] = "chip"
                    row["blocks_release"] = "0"
                elif action in ("identity_review", "review"):
                    row["state"] = "IDENTITY_REVIEW"
                    row["blocks_release"] = "1"
                
                if row.get("blocks_release") == "0":
                    row["evidence"] = f"[人工修正] {review['notes']} | 原判: {orig_state}/{orig_identity}"
                    applied_count += 1
                    patch_data.append({
                        "mpn": mpn,
                        "file": review["file"] or row.get("file"),
                        "original_rule": row.get("rule_id"),
                        "manual_action": action,
                        "final_identity": row["identity"],
                        "notes": review["notes"]
                    })

            if row.get("blocks_release") == "1":
                blocks_after += 1
                
            final_rows.append(row)

    print(f"成功应用人工复核: {applied_count} 件")
    print(f"blocks_release 阻断件数: {blocks_before} -> {blocks_after}")
    
    if blocks_after > 0:
        print(f"警告：还有 {blocks_after} 件阻断未解除，请检查人工复核是否遗漏。")
    
    if not args.do_write:
        print("\n当前为 [Dry-Run] 预览模式。数据未写盘。")
        print("若要真实写入，请追加 `--do-write` 参数重跑。")
        return
        
    out_csv_path = Path(args.out_csv)
    out_json_path = Path(args.out_json)
    
    with open(out_csv_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_rows)
    print(f"最终回放结果已保存: {out_csv_path}")
    
    with open(out_json_path, "w", encoding="utf-8") as f:
        json.dump({"patches": patch_data}, f, ensure_ascii=False, indent=2)
    print(f"增量白名单补丁已保存: {out_json_path}")

if __name__ == "__main__":
    main()
