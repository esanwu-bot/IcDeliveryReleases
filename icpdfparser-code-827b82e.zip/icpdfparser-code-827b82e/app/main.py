"""FastAPI 应用入口。

    python run_server.py           # 开发/单机：http://127.0.0.1:8000
    celery -A worker.celery_app worker -Q icpdf -P threads -c 2 -l info

启动时会做两件幂等的事：
  1. 建/升级工作台库表；
  2. 如果图片命名表还没导入过、而 uploads/ 里有命名表 xlsx，就自动导入一次
     —— 保证「按最新上传的文档执行」开箱即用。
"""
from __future__ import annotations

import hashlib
import html
import logging
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from . import auth, config, db
from .api.qc import router as qc_router
from .api.qe import router as qe_router
from .api.feedback import router as feedback_router
from .api.i18n_qa import router as i18n_router
from .api.qc_analyzer import router as analyzer_router
from .api.review import router as review_router
from .api.agent import router as agent_router
from .api.routes import router
from .services import images

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("icpdf")

app = FastAPI(title="IcPdfParser 工作台", version="1.0.0",
              description="型号表 -> Datasheet 采集 -> LLM 解析 -> 详情页交付物料")
app.include_router(router)
app.include_router(qc_router)
app.include_router(qe_router)
app.include_router(feedback_router)
app.include_router(analyzer_router)
app.include_router(i18n_router)
app.include_router(review_router)
app.include_router(agent_router)


# ---------------------------------------------------------------- 登录
# 公网部署时（ICPDF_AUTH_* 三项配齐）全站拦截：API 返回 401，页面给登录页。
_LOGIN_HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>IcPdfParser 登录</title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
  font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
  background:linear-gradient(135deg,#0f172a,#1e293b);color:#e2e8f0}
.card{width:340px;padding:36px 32px;border-radius:16px;background:#1e293b;
  box-shadow:0 20px 60px rgba(0,0,0,.45);border:1px solid #334155}
.logo{display:flex;gap:12px;align-items:center;margin-bottom:28px}
.logo .ic{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;
  justify-content:center;font-weight:700;color:#0f172a;
  background:linear-gradient(135deg,#38bdf8,#818cf8)}
.logo h1{font-size:17px;margin:0;font-weight:600}
.logo small{display:block;color:#64748b;font-weight:400;margin-top:2px}
input{width:100%;box-sizing:border-box;margin-bottom:14px;padding:11px 14px;
  border-radius:9px;border:1px solid #334155;background:#0f172a;color:#e2e8f0;
  font-size:14px;outline:none;transition:border .15s}
input:focus{border-color:#38bdf8}
button{width:100%;padding:11px;border:none;border-radius:9px;cursor:pointer;
  font-size:14px;font-weight:600;color:#0f172a;
  background:linear-gradient(135deg,#38bdf8,#818cf8)}
button:hover{filter:brightness(1.08)}
.err{color:#f87171;font-size:13px;min-height:18px;margin:0 0 10px}
</style></head><body>
<div class="card">
  <div class="logo"><div class="ic">IC</div>
    <h1>IcPdfParser 工作台<small>Datasheet 解析流水线</small></h1></div>
  <p class="err" id="err"></p>
  <input id="u" placeholder="账号" autocomplete="username" autofocus>
  <input id="p" type="password" placeholder="密码" autocomplete="current-password">
  <button onclick="go()">登 录</button>
</div>
<script>
function go(){
  var u=document.getElementById('u').value.trim(),
      p=document.getElementById('p').value,
      e=document.getElementById('err');
  if(!u||!p){e.textContent='请输入账号和密码';return}
  fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({user:u,password:p})}).then(function(r){
    if(r.ok){location.href='/';return null}
    return r.json().then(function(d){throw new Error(d.detail||'登录失败')})
  }).catch(function(x){e.textContent=x.message||'登录失败'});
}
document.addEventListener('keydown',function(ev){if(ev.key==='Enter')go()});
</script></body></html>"""


_PUBLIC_PATHS = ("/api/auth/login", "/static/", "/favicon.ico")


@app.middleware("http")
async def auth_guard(request: Request, call_next):
    if not auth.enabled():
        return await call_next(request)
    path = request.url.path
    if path in _PUBLIC_PATHS or path.startswith(_PUBLIC_PATHS):
        return await call_next(request)
    if auth.verify(request.cookies.get(auth.COOKIE, "")):
        return await call_next(request)
    if path.startswith("/api/"):
        return JSONResponse({"detail": "未登录"}, status_code=401)
    return HTMLResponse(_LOGIN_HTML)


@app.post("/api/auth/login")
def auth_login(payload: dict = Body(...)):
    if not auth.check_login(str(payload.get("user", "")), str(payload.get("password", ""))):
        raise HTTPException(401, "账号或密码错误")
    resp = JSONResponse({"ok": True, "user": auth.user()})
    resp.set_cookie(auth.COOKIE, auth.make_token(auth.user()),
                    max_age=auth.TTL, httponly=True, samesite="lax")
    return resp


@app.post("/api/auth/logout")
def auth_logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE)
    return resp


@app.get("/api/auth/me")
def auth_me():
    return {"user": auth.user() if auth.enabled() else "", "enabled": auth.enabled()}


# ---------------------------------------------------------------- 静态资源
@app.get("/", include_in_schema=False)
def index() -> FileResponse:
    return FileResponse(config.STATIC / "index.html")


app.mount("/static", StaticFiles(directory=str(config.STATIC)), name="static")


def _placeholder_svg(name: str) -> str:
    """没有真实配图时生成一张占位图（同文件名永远同一配色）。"""
    stem = Path(name).stem.replace("app-", "").replace("-", " ").title() or "Application"
    digest = hashlib.md5(name.encode("utf-8")).hexdigest()
    hue = int(digest[:2], 16) * 360 // 256
    fg = f"hsl({hue},46%,38%)"
    bg = f"hsl({hue},58%,93%)"
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">'
        f'<rect width="64" height="64" rx="12" fill="{bg}"/>'
        f'<circle cx="32" cy="26" r="10" fill="none" stroke="{fg}" stroke-width="2.5"/>'
        f'<path d="M14 52c4-10 12-14 18-14s14 4 18 14" fill="none" stroke="{fg}" '
        'stroke-width="2.5" stroke-linecap="round"/>'
        f'<text x="32" y="61" font-size="7" text-anchor="middle" fill="{fg}" '
        f'font-family="Arial">{html.escape(stem[:18])}</text></svg>')


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> Response:
    return Response(_placeholder_svg("app-favicon.png"), media_type="image/svg+xml")


@app.get("/media/pkg/{name}", include_in_schema=False)
def media_pkg(name: str) -> Response:
    if "/" in name or "\\" in name or ".." in name:
        raise HTTPException(400, "非法文件名")
    p = config.PKGS / name
    if not p.exists():
        raise HTTPException(404, "封装图不存在")
    return FileResponse(p, media_type="image/svg+xml")


@app.get("/media/img/{name}", include_in_schema=False)
def media_img(name: str) -> Response:
    if "/" in name or "\\" in name or ".." in name:
        raise HTTPException(400, "非法文件名")
    for base in (config.IMG_DIR, config.UPLOADS, config.ROOT / "img", config.DATA / "img"):
        p = Path(base) / name
        if p.exists() and p.is_file():
            return FileResponse(p)
    return Response(_placeholder_svg(name), media_type="image/svg+xml")


# ---------------------------------------------------------------- 启动钩子
@app.on_event("startup")
def on_startup() -> None:
    db.conn()
    _auto_import_images()
    try:
        from .services import i18n_qa
        seed = i18n_qa.ensure_seed()
        log.info("多语言质量中心种子：术语 +%d / 禁用词 +%d", seed["glossary"], seed["banned"])
    except Exception as e:                                       # noqa: BLE001
        log.warning("多语言质量中心种子写入失败：%s", e)
    log.info("工作台就绪：db=%s redis=%s", config.DB_PATH, config.REDIS_URL)


def _auto_import_images() -> None:
    """图片命名表为空时，自动吃 uploads/ 里最新的命名表。"""
    try:
        if db.q1("SELECT 1 FROM app_image LIMIT 1"):
            images.refresh_renderer()
            return
        cands = [p for p in config.UPLOADS.glob("*")
                 if p.is_file() and p.suffix.lower() in (".xlsx", ".xls", ".csv")
                 and ("图片" in p.name or "image" in p.name.lower() or "app" in p.name.lower())]
        if not cands:
            return
        src = max(cands, key=lambda p: p.stat().st_mtime)
        info = images.import_table(src)
        log.info("自动导入图片命名表 %s：%d 类", src.name, info["categories"])
    except Exception as e:                                       # noqa: BLE001
        log.warning("自动导入图片命名表失败：%s", e)
