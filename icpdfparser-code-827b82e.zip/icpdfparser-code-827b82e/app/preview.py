"""交付物预览：把裸 HTML 片段包一层样式，直接在 iframe 里看效果。

线上站点的详情页样式不在本仓库，这里给一套与 `.pd-*` 类名对应的预览样式，
只用于内部审校，不代表线上最终外观。
"""
from __future__ import annotations

import html as _html
import json

PREVIEW_CSS = """
:root{--ink:#1b2430;--muted:#5b6673;--line:#e3e8ee;--bg:#fff;--soft:#f6f8fa;--accent:#0b6bcb;}
*{box-sizing:border-box}
body{margin:0;padding:20px 18px 48px;background:var(--bg);color:var(--ink);
 font-family:-apple-system,"Segoe UI","Microsoft YaHei",Arial,sans-serif;font-size:14px;line-height:1.65}
.pd-wrap{max-width:1080px;margin:0 auto}
.pd-hero{background:linear-gradient(135deg,#eef4fb 0%,#f7fafd 100%);border:1px solid var(--line);
 border-radius:10px;padding:22px 24px;margin-bottom:18px}
.pd-hero-title{margin:0 0 6px;font-size:24px;line-height:1.3;color:#10243b}
.pd-hero-desc{margin:0;color:var(--muted);font-size:14px}
.pd-sec{border-top:1px solid var(--line);padding:18px 0 6px}
.pd-sec-head{display:flex;align-items:center;margin-bottom:10px}
.pd-badge{flex:0 0 auto;width:26px;height:26px;border-radius:50%;background:#e8f0fb;color:var(--accent);
 font-size:13px;font-weight:700;text-align:center;line-height:26px;margin-right:10px}
.pd-sec-title{margin:0;font-size:18px;color:#10243b}
.pd-sec-body{margin:0}
.pd-sec-body p{margin:0 0 10px}
.pd-table{width:100%;border-collapse:collapse;margin:6px 0 12px;font-size:13px}
.pd-table th,.pd-table td{border:1px solid var(--line);padding:7px 9px;text-align:left;
 vertical-align:top;word-break:break-word}
.pd-table th{background:var(--soft);font-weight:600;color:#33414f}
.pd-table tr:nth-child(even) td{background:#fbfcfd}
.pd-list{margin:6px 0 12px;padding-left:20px}
.pd-list li{margin:4px 0}
.pd-note{font-size:12.5px;color:var(--muted);background:var(--soft);border-left:3px solid #cfdae6;
 padding:8px 12px;border-radius:0 6px 6px 0;margin:8px 0}
.pd-alert{border-left-color:#e0a800;background:#fffbea}
.pd-grid2{display:flex;flex-wrap:wrap;margin:0 -8px}
.pd-card{flex:1 1 320px;margin:0 8px 14px;border:1px solid var(--line);border-radius:8px;padding:12px 14px}
.pd-card-title{margin:0 0 4px;font-size:14px;font-weight:600}
.pd-card-desc{margin:0;font-size:13px;color:var(--muted)}
.pd-appgrid{display:flex;flex-wrap:wrap;margin:0 -8px}
.pd-app{flex:1 1 300px;margin:0 8px 12px;border:1px solid var(--line);border-radius:8px;padding:12px}
.pd-app-title{font-weight:600;margin-bottom:4px}
.pd-app-desc,.pd-app-example{font-size:13px;color:var(--muted);margin-bottom:6px}
.pd-app-ico img{display:block;border-radius:8px;background:#eef2f7}
.pd-pin{font-size:13px}
.pd-faq-list{margin:6px 0 0}
.pd-faq-item{border-bottom:1px solid var(--line);padding:8px 0}
.pd-faq-q{font-weight:600;margin:0 0 4px}
.pd-faq-a{margin:0;color:var(--muted)}
.pd-expert-insight{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:12px 14px}
.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}
"""

JSON_CSS = """
body{margin:0;padding:16px;background:#1e232b;color:#dfe6ee;
 font:12.5px/1.6 Consolas,"Courier New",monospace}
pre{margin:0;white-space:pre-wrap;word-break:break-word}
.k{color:#7ec7ff}.s{color:#a8e6a1}.n{color:#ffcc80}
"""


def _shell(title: str, body: str, css: str = PREVIEW_CSS) -> str:
    return (f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{_html.escape(title)}</title><style>{css}</style></head>"
            f"<body>{body}</body></html>")


def rewrite_assets(html: str) -> str:
    return (html.replace("/upload/pkg/", "/media/pkg/")
                .replace("/upload/img/", "/media/img/"))


def page_for(kind: str, title: str, raw: str) -> str:
    """kind: txt | alts | symbols | json"""
    if kind == "json":
        try:
            pretty = json.dumps(json.loads(raw), ensure_ascii=False, indent=2)
        except json.JSONDecodeError:
            pretty = raw
        return _shell(title, f"<pre>{_html.escape(pretty)}</pre>", JSON_CSS)
    if kind == "symbols":
        return rewrite_assets(raw)
    return _shell(title, rewrite_assets(raw))
