"""`.env.local` 读取（只读，不 export）。

质审模块需要两把钥匙：DashScope（评委）与 GitHub（工单）。
仓库的 `.env.local` 里两种写法都有（`KEY=value` 与 `KEY = value`），
且**不入库**（.gitignore）。这里只解析成 dict，不写 `os.environ` ——
质审进程不该因为读了一个配置文件就把密钥塞进子进程环境。
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read_env_file(path: str | Path | None = None) -> dict[str, str]:
    p = Path(path) if path else ROOT / ".env.local"
    out: dict[str, str] = {}
    if not p.is_file():
        return out
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, _, v = s.partition("=")
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k:
            out[k] = v
    return out


def get(key: str, default: str = "", env: dict[str, str] | None = None) -> str:
    """环境变量优先，其次 `.env.local`。"""
    v = os.getenv(key)
    if v:
        return v.strip()
    return (env if env is not None else read_env_file()).get(key, default).strip()
