"""GitHub Issue 工单生成 —— 质审流水线的**唯一出口**。

设计约束（来自外审与事故复盘）：

* **默认 dry-run。** 质审是自动流水线，自动建单会污染仓库；必须先看到
  「即将发送的 JSON」再由人决定是否 `--push`。
* **工单必须能独立复现。** 只写「参数错了」等于没写：复核方要能凭工单里的
  MPN + PDF SHA-256 + 页码 + bbox 回到原文那一格。所以这些字段是**必填**，
  缺一个就拒绝建单（`ValueError`），不允许用空字符串占位。
* **一件一单。** 同一份 JSON 上的 N 个缺陷合并成**一张**工单、正文里一个
  Markdown Checklist，而不是 N 张只讲一句话的单。理由：复核方是按「件」
  分派的，同件的三个毛病分散在三张单里，永远没人知道它们互相影响。
* **去重键 = MPN + PDF SHA-256。** 同一件、同一份原件重复跑不该刷出第二张单。
  `dedup_key` 以 HTML 注释形式埋在正文里，推送前先查 open issues。
  刻意**不含**问题类型 —— 含了就退化成「一个问题一张单」，与上一条冲突。
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable

from app.integrations.env import read_env_file

LABEL_BASE = ("qa-audit", "auto-generated")

#: 严重度 → 标签。P0 直接进「必须修」桶，P1 进「待评估」。
SEVERITY_LABEL = {"P0": "severity:P0", "P1": "severity:P1"}

#: 工单缺省落在发布仓库（AGENT.md §17）。**不再强依赖环境变量**：
#: 自动流水线里少配一个变量就整条链断掉，而这个仓库名是全项目唯一的常量事实，
#: 没有理由让调用方每次重复声明。环境变量仍然优先，用于换仓库做灰度。
DEFAULT_ISSUES_REPO = "esanwu-bot/IcDeliveryReleases"

#: 本地去重台账。**云端查不到时的最后一道**：token 缺 label 写权限时标签会被
#: 静默丢弃，按标签查重的 `_existing()` 就会永远查不到，于是每跑一次多一张单。
#: 台账只追加不改写，键是 dedup_key，值是 `{number, url, at}`。
LEDGER_ENV = "QA_ISSUE_LEDGER"
DEFAULT_LEDGER = "data/qc/qa_issue_ledger.json"

#: 单条工单正文上限（GitHub 硬上限 65536，留余量给后续追加）。
MAX_BODY = 60000

#: 标签的创建参数（颜色/说明）。**GitHub 不会因为 issue 里写了个不存在的标签就
#: 自动建它 —— 它是静默丢弃。** DSH 验收时的真实形态：发布仓库里有 `qa-audit`，
#: 但没有 `auto-trigger`，于是建单 201、返回体 labels 为空，按标签查重直接失效。
#: 所以建单前先补一道 ensure：缺什么建什么，建不了才退回告警（去重另有保障）。
LABEL_SPEC: dict[str, dict[str, str]] = {
    "qa-audit": {"color": "B60205", "description": "交付质审工单"},
    "auto-generated": {"color": "EDEDED", "description": "自动生成，勿手工关闭"},
    "auto-trigger": {"color": "0E8A16",
                     "description": "打包脚本自动触发质审（AGENT.md §17）"},
    "severity:P0": {"color": "D93F0B", "description": "必须修：影响取值正确性"},
    "severity:P1": {"color": "FBCA04", "description": "待评估：可读性/结构问题"},
}


# ---------------------------------------------------------------- 环境
def _cfg(env: dict[str, str] | None = None) -> tuple[str, str]:
    """取 `(repo, token)`。环境变量优先于 `.env.local`，最后兜底到发布仓库。"""
    e = env if env is not None else read_env_file()
    repo = (os.getenv("GITHUB_ISSUES_REPO") or e.get("GITHUB_ISSUES_REPO")
            or os.getenv("GITHUB_RELEASE_REPO") or e.get("GITHUB_RELEASE_REPO")
            or DEFAULT_ISSUES_REPO).strip()
    token = (os.getenv("GITHUB_ISSUES_TOKEN") or e.get("GITHUB_ISSUES_TOKEN")
             or os.getenv("GITHUB_RELEASE_TOKEN") or e.get("GITHUB_RELEASE_TOKEN")
             or "").strip()
    return repo, token


# ---------------------------------------------------------------- 缺陷归一
#: 排序用，数字越小越严重。未知严重度排最后（不猜，也不悄悄升成 P0）。
SEVERITY_RANK = {"P0": 0, "P1": 1, "P2": 2}

#: 机器 kind → 人读类别。工单是给人看的，`fused_column_blocking` 这种字面量
#: 只有机器认；但**原始 kind 不丢** —— 详情块里单列一行，便于回查代码。
#: 类别同时充当跨来源去重的键：qwen-long 的「多列塌缩」与 qwen-max 的
#: `column_collapse_suspect` 说的是同一件事，合并成一条，而不是并列两条。
KIND_LABEL: dict[str, str] = {
    # qwen-long（原文校对）
    "qwen_long_mismatch": "原文不一致",
    # qwen-max（逻辑审查）
    "column_collapse_suspect": "多列塌缩",
    "missing_key_param": "关键参数缺失",
    "duplicate_param": "重复参数",
    "absmax_in_operating": "绝对最大值混入",
    "condition_missing": "缺条件区分",
    "logic_unspecified": "结构问题",
    # Deterministic（qc/table_audit.py 写回的 finding kind）
    "fused_column_blocking": "列融合（阻断）",
    # A22（2026-11-03）：多封装表只抽第一列，与 qwen-max 的 `column_collapse_suspect`
    # 是同一件事的确定性版本；**类别必须同名**，否则同一缺陷会被 merge 成两条。
    "column_collapse": "多列塌缩",
    "range_collapse": "取值范围塌缩",
    "qualifier_loss": "限定条件丢失",
    "row_missing": "整行缺失",
    "row_mispair": "行错配",
    "option_conflation": "封装/选项混同",
    "condition_leak": "条件串行",
    "direction_reversal": "方向反转",
    "pin_mismatch": "引脚错配",
    "row_ambiguous_unresolved": "行归属未定",
    "cell_unparsable_unresolved": "单元格不可解析",
    "anchor_gate_blocked": "证据未达门槛",
}

#: `_norm_sev` 的输出域。其它一律落 P1 —— 模型偶尔回 `critical`/`HIGH`，
#: 收敛到既有两档，不允许未经判断就升 P0。
_VALID_SEV = ("P0", "P1")


def dedup_key(mpn: str, pdf_sha256: str) -> str:
    """同一件 + 同一份 PDF = 同一张单（一件一单）。

    刻意**不含问题类型、不含时间**：含类型就退化成「一行一张单」，工单列表
    被同一件的十个毛病刷屏；含时间就等于「每跑一次都是新单」，去重形同虚设。
    """
    raw = "|".join([mpn.strip().upper(), (pdf_sha256 or "").strip().lower()])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _norm_sev(v: Any) -> str:
    s = str(v or "").strip().upper()
    return s if s in _VALID_SEV else "P1"


def category_of(defect: dict) -> str:
    """缺陷的人读类别：调用方显式给就用，否则按 `kind` 查表。"""
    cat = str(defect.get("category") or "").strip()
    if cat:
        return cat
    kind = str(defect.get("kind") or "").strip()
    return KIND_LABEL.get(kind) or kind or "未分类"


def worst_severity(defects: Iterable[dict]) -> str:
    """取最严重的一档。空清单返回 P1（调用方本不该在无缺陷时建单）。"""
    best = "P1"
    for d in defects:
        s = _norm_sev(d.get("severity"))
        if SEVERITY_RANK[s] < SEVERITY_RANK[best]:
            best = s
    return best


def severity_counts(defects: Iterable[dict]) -> dict:
    out: dict[str, int] = {}
    for d in defects:
        s = _norm_sev(d.get("severity"))
        out[s] = out.get(s, 0) + 1
    return out


def merge_defects(defects: Iterable[dict]) -> list[dict]:
    """同件内去重：`(label, 类别)` 相同即视为同一个缺陷。

    为什么必须去重：qwen-long 从原文看出「RθJC(top) 只抽一列」，qwen-max 从
    JSON 结构也看出「RθJC(top) 多列塌缩」—— 这是**一个**毛病两路都发现了，
    并列成两条会让复核方以为是两处错，按两条去改。
    合并时取更严重的级别、并集来源；`sources` 保留两路证据。
    """
    merged: dict[tuple[str, str], dict] = {}
    order: list[tuple[str, str]] = []
    for d in defects:
        d = dict(d)
        d["severity"] = _norm_sev(d.get("severity"))
        key = (str(d.get("label") or "").strip().lower(), category_of(d))
        if key not in merged:
            d["sources"] = [s for s in ([d.get("source")] if d.get("source") else []) if s]
            merged[key] = d
            order.append(key)
            continue
        cur = merged[key]
        if SEVERITY_RANK[d["severity"]] < SEVERITY_RANK[cur["severity"]]:
            cur["severity"] = d["severity"]
        for s in ([d.get("source")] if d.get("source") else []):
            if s not in cur["sources"]:
                cur["sources"].append(s)
        # 详情保留信息量更大的那条（长的那条通常带着「原文有 2 列」这类关键事实）
        if len(str(d.get("detail") or "")) > len(str(cur.get("detail") or "")):
            cur["detail"] = d.get("detail")
        for f in ("expected", "current", "evidence", "page", "bbox", "confidence",
                  "kind", "note"):
            if not cur.get(f) and d.get(f):
                cur[f] = d[f]
    return [merged[k] for k in order]


# ---------------------------------------------------------------- 渲染
def _fmt(v: Any) -> str:
    if v is None or v == "":
        return "—"
    if isinstance(v, (list, tuple)):
        return ", ".join(str(x) for x in v) if v else "—"
    return str(v)


def _one_line(v: Any, limit: int = 240) -> str:
    """压成一行：Markdown 列表项里塞换行会把 Checklist 拆成两段。"""
    s = " ".join(str(v or "").split())
    return s[:limit] + ("…" if len(s) > limit else "")


def checklist_line(defect: dict, idx: int | None = None) -> str:
    """`- [ ] [P0/多列塌缩] RθJC(top) 只抽一列，原文有 2 列…`

    勾选框不是装饰：复核方逐条修完打勾，工单本身就成了进度表。
    """
    sev = _norm_sev(defect.get("severity"))
    cat = category_of(defect)
    label = _one_line(defect.get("label"), 60)
    detail = _one_line(defect.get("detail"), 200)
    # 详情常以参数名开头（「RθJA 原文有…」），与前面的 label 重复读起来像结巴。
    if label and detail.startswith(label):
        detail = detail[len(label):].lstrip(" ：:，,")
    head = f"- [ ] [{sev}/{cat}]"
    rest = " ".join(x for x in (label, detail) if x).strip()
    return f"{head} {rest}".rstrip()


def _models_line(issue: dict) -> str:
    models = issue.get("models") or {}
    if not models:
        return "—"
    return " · ".join(f"{k}=`{v}`" for k, v in models.items() if v)


def render_body(issue: dict) -> str:
    """渲染工单正文（Markdown）：抬头 → Checklist → 逐条详情 → 复现。

    顺序刻意固定为「是哪件 → 一共几个毛病 → 每个毛病是什么 → 怎么复现」。
    复核方按件分派，通常只读抬头三段加 Checklist 就能决定先修哪个。
    """
    defects = issue.get("defects") or []
    det = issue.get("deterministic") or {}
    sev = _norm_sev(issue.get("severity"))
    omitted = int(issue.get("defects_omitted") or 0)
    n_all = len(defects) + omitted
    counts = severity_counts(defects)
    cnt_txt = " / ".join(f"{k} ×{v}" for k, v in sorted(counts.items(),
                                                       key=lambda kv: SEVERITY_RANK.get(kv[0], 9)))

    lines: list[str] = [
        f"## 质审工单 · `{issue['mpn']}`",
        "",
        "| 项 | 值 |",
        "|---|---|",
        f"| MPN | `{issue['mpn']}` |",
        f"| PDF SHA-256 | `{issue['pdf_sha256']}` |",
        f"| 模型版本 | {_models_line(issue)} |",
        f"| 缺陷数 | {n_all}（{cnt_txt or '—'}） |",
        f"| 本轮结论 | {issue.get('decision') or '—'} |",
        "",
        f"### 缺陷清单（{n_all}）",
        "",
        "> 逐条修完打勾；勾完仍要跑一遍复现命令，**打勾不等于已合格**。",
        "",
    ]
    lines += [checklist_line(d) for d in defects]
    if omitted:
        lines.append(f"- [ ] ……另有 {omitted} 项未列出（见报告 JSON 的 `qwen_long` / `qwen_max` / "
                     f"`deterministic.findings`）")
    lines += ["", "### 逐条详情", ""]

    for i, d in enumerate(defects, 1):
        sev_d = _norm_sev(d.get("severity"))
        srcs = d.get("sources") or ([d.get("source")] if d.get("source") else [])
        src_txt = _fmt("、".join(str(s) for s in srcs))
        if d.get("confidence") is not None:
            src_txt += f"（confidence={d.get('confidence')}）"
        coord = f"p{_fmt(d.get('page'))}"
        if d.get("bbox"):
            coord += f" · bbox `{json.dumps(d.get('bbox'), ensure_ascii=False)}`"
        lines += [
            f"#### {i}. `[{sev_d}/{category_of(d)}]` {d.get('label') or '—'}",
            "",
            f"- **来源**：{src_txt}",
            f"- **页码**：{coord}",
            f"- **机器 kind**：`{_fmt(d.get('kind'))}`",
            "",
            "| 期望结果 | 当前结果 |",
            "|---|---|",
            f"| {_one_line(d.get('expected')) or '—'} | {_one_line(d.get('current')) or '—'} |",
            "",
            f"**错误原因**：{d.get('detail') or '—'}",
            "",
        ]
        # 模型的原始说明单独一行：Checklist 里要短，但「它凭什么这么判」不能丢。
        if d.get("note"):
            lines += [f"**模型说明**：{_one_line(d.get('note'), 400)}", ""]
        # 原文切片随单走：只有 bbox 的话，复核方还得自己开 PDF 裁一次。
        # 切片里带列左边界 x（`39.3@392`），「哪个值属于哪个封装」在单子里就能判。
        ev = d.get("evidence") or {}
        if ev.get("header") or ev.get("row"):
            lines += ["**原文证据（bbox 切片）**", "", "```text", "【表头】",
                      str(ev.get("header") or "(未取到)"), "【目标行】",
                      str(ev.get("row") or "(空)"), "```", ""]

    if det:
        lines += [
            "### Deterministic 审计（机器结论，供对照）",
            "",
            f"- 行结论：{_fmt(det.get('verdict'))}；行数 {_fmt(det.get('n_rows'))}",
            f"- 等级分布：`{json.dumps(det.get('counts') or {}, ensure_ascii=False)}`",
            f"- 闸门：`{_fmt(det.get('anchor_gate'))}`",
            f"- findings 分布：`{json.dumps(det.get('finding_kinds') or {}, ensure_ascii=False)}`",
            "",
        ]
    lines += [
        "### 复现",
        "",
        "```bash",
        f"python -m app.qa.controller --mpn {issue['mpn']} \\",
        f"  --json <parsed>/{issue['mpn']}.json --pdf <pdfs>/{issue['mpn']}.pdf \\",
        f"  --facts <staging>/facts_audit.csv",
        "```",
        "",
    ]
    if issue.get("reasons"):
        lines += ["### 本轮决策依据", ""]
        lines += [f"- {_one_line(r, 300)}" for r in (issue["reasons"] or [])[:10]]
        lines.append("")
    lines += [
        "---",
        f"<!-- qa-issue-key: {issue.get('dedup_key')} -->",
        f"<!-- pdf-sha256: {issue['pdf_sha256']} -->",
        f"<!-- defects: {len(defects)}; worst: {sev} -->",
        "由质审流水线自动生成；**未经人工确认前不得据此修改交付物**。",
    ]
    return "\n".join(lines)[:MAX_BODY]


# ---------------------------------------------------------------- 构造
#: 单张工单最多列出的缺陷条数。超出部分合并成一行「另有 N 项」——
#: 一个缺陷要两行渲染，60 条就顶到 GitHub 正文上限（65536）了。
MAX_CHECKLIST = 60


def build_issue(*, mpn: str, pdf_sha256: str, defects: Iterable[dict],
                decision: str, models: dict | None = None,
                reasons: Iterable[str] = (),
                deterministic: dict | None = None) -> dict:
    """组装**一张**工单，把该件的全部缺陷收进同一个 Checklist。

    与旧版（一行一张单）的区别就是签名：不再收 `page/expected/current/reason`
    这些「一条缺陷」的字段，而是收 `defects` 列表。校验也跟着下移到每个缺陷上
    —— 缺页码、缺原因的单条缺陷同样不许混进来，否则它就是 Checklist 里的死条目。
    """
    if not mpn:
        raise ValueError("工单缺 MPN：无法定位到具体料号")
    if not pdf_sha256:
        raise ValueError("工单缺 PDF SHA-256：复核方无法确认比对的是哪一份原件")
    items = list(defects)
    if not items:
        raise ValueError("工单缺缺陷：一张没有 - [ ] 的工单等于空单，不该建")
    for i, d in enumerate(items, 1):
        if not isinstance(d, dict):
            raise ValueError(f"第 {i} 项缺陷不是对象：{type(d).__name__}")
        if not (d.get("detail") or d.get("label")):
            raise ValueError(f"第 {i} 项缺陷既无 label 也无 detail：不可复现")
        if d.get("page") is None:
            raise ValueError(f"第 {i} 项缺陷（{d.get('label') or d.get('kind') or '?'}）缺页码："
                             f"没有页码的条目等于让复核方去翻整份 PDF")

    items = merge_defects(items)
    # 严重度优先，同级保持发现顺序（源码顺序本身是证据：确定性→原文→结构）。
    items.sort(key=lambda d: SEVERITY_RANK.get(_norm_sev(d.get("severity")), 9))
    omitted = max(0, len(items) - MAX_CHECKLIST)
    items = items[:MAX_CHECKLIST]

    sev = worst_severity(items)
    issue = {
        "mpn": mpn,
        "pdf_sha256": pdf_sha256,
        "decision": decision,
        "severity": sev,
        "defects": items,
        "defects_omitted": omitted,
        "models": dict(models or {}),
        "reasons": list(reasons or []),
    }
    if deterministic:
        issue["deterministic"] = dict(deterministic)
    issue["dedup_key"] = dedup_key(mpn, pdf_sha256)
    # 标题只放「该件最严重的级别 + 一共几个毛病」：具体是哪几个毛病在清单里，
    # 塞进标题会被 70 字截断成半句话，在 issue 列表里反而读不出重点。
    issue["title"] = f"[质审/{sev}] {mpn} · 发现 {len(items) + omitted} 项严重缺陷"
    issue["labels"] = list(LABEL_BASE) + [SEVERITY_LABEL.get(sev, "severity:P1")]
    issue["body"] = render_body(issue)
    return issue


# ---------------------------------------------------------------- 本地台账
def ledger_path(p: str | Path | None = None) -> Path:
    return Path(p or os.getenv(LEDGER_ENV) or DEFAULT_LEDGER)


def ledger_lookup(key: str, path: str | Path | None = None) -> dict | None:
    """查本地台账。读坏一律当空 —— 台账坏掉不该阻断建单。"""
    p = ledger_path(path)
    if not p.is_file():
        return None
    try:
        blob = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    rec = (blob.get("issues") or {}).get(key)
    return rec if isinstance(rec, dict) else None


def ledger_record(key: str, info: dict, path: str | Path | None = None) -> None:
    """记一条。写失败只告警不抛：建单已经成功，台账只是加速与兜底。"""
    p = ledger_path(path)
    blob: dict = {"schema": "qa-issue-ledger/v1", "issues": {}}
    if p.is_file():
        try:
            blob = json.loads(p.read_text(encoding="utf-8"))
            blob.setdefault("issues", {})
        except (OSError, ValueError):
            blob = {"schema": "qa-issue-ledger/v1", "issues": {}}
    blob["issues"][key] = info
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(blob, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(p)
    except OSError:
        pass


# ---------------------------------------------------------------- 推送
def _existing(session, repo: str, token: str, key: str,
              label: str = "", marker: str = "qa-issue-key",
              max_pages: int = 5) -> dict | None:
    """查 open 单里有没有同一去重键。

    **默认不带标签过滤**。教训：token 只有 `issues:write` 而没有 `issues:write`
    之外的标签权限时，GitHub 会**静默丢弃** labels（HTTP 201，返回体里没有它），
    于是 `labels=qa-audit` 的查询永远查不到刚建的那张单，每跑一次就多一张。
    查重必须以**正文里的 marker** 为准，标签只能当加速提示。

    `label` 传了才过滤（给确知有标签权限的调用方用）；分页上限 5×100，
    避免在大仓库里翻几百页。
    """
    url = f"https://api.github.com/repos/{repo}/issues"
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/vnd.github+json"}
    for page in range(1, max_pages + 1):
        params: dict[str, Any] = {"state": "open", "per_page": 100, "page": page}
        if label:
            params["labels"] = label
        r = session.get(url, params=params, headers=headers, timeout=30)
        if r.status_code != 200:
            return None
        items = r.json() or []
        for it in items:
            if f"{marker}: {key}" in (it.get("body") or ""):
                return {"number": it.get("number"), "url": it.get("html_url")}
        if len(items) < 100:
            break
    return None


def ensure_labels(session, repo: str, token: str, labels: Iterable[str],
                  *, max_pages: int = 3) -> dict:
    """保证 `labels` 都在仓库里存在，缺的按 `LABEL_SPEC` 创建。

    返回 `{present, created, failed, error}`。**任何一步失败都不抛**：
    标签是分类手段，不是建单前提 —— 去重靠正文 marker 与本地台账，
    没有标签最多是列表里不好筛，不该因此整条流水线停摆。

    读失败（token 连读都不行）直接整体退回，连尝试创建都不做：那种情况下
    建标签也是 403，只会白挨三个请求。
    """
    want = [str(x) for x in (labels or []) if str(x or "").strip()]
    out: dict[str, Any] = {"present": [], "created": [], "failed": [], "error": ""}
    if not want:
        return out
    url = f"https://api.github.com/repos/{repo}/labels"
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/vnd.github+json"}
    have: set[str] = set()
    try:
        for page in range(1, max_pages + 1):
            r = session.get(url, params={"per_page": 100, "page": page},
                            headers=headers, timeout=30)
            if r.status_code != 200:
                out["error"] = f"读标签失败 HTTP {r.status_code}"
                return out
            items = r.json() or []
            for it in items:
                n = str((it or {}).get("name") or "").strip().lower()
                if n:
                    have.add(n)
            if len(items) < 100:
                break
    except Exception as e:                                # noqa: BLE001
        out["error"] = f"读标签异常：{e}"
        return out

    for name in want:
        if name.lower() in have:
            out["present"].append(name)
            continue
        spec = LABEL_SPEC.get(name) or {"color": "EDEDED", "description": ""}
        try:
            r = session.post(url, json={"name": name, **spec},
                             headers=headers, timeout=30)
        except Exception:                                 # noqa: BLE001
            out["failed"].append(name)
            continue
        if r.status_code in (200, 201):
            out["created"].append(name)
        elif r.status_code == 422:                        # 已存在（并发创建）
            out["present"].append(name)
        else:
            out["failed"].append(name)
    return out


def create_issue(issue: dict, *, dry_run: bool = True, repo: str | None = None,
                 token: str | None = None, session=None, out_dir: str | Path | None = None,
                 dedup_label: str = "", dedup_marker: str = "qa-issue-key",
                 ledger: str | Path | None = None) -> dict:
    """建单。``dry_run=True`` 时**不发网络请求**，只返回即将发送的请求体。

    去重三层，任何一层单独失效都不影响正确性：

    1. **云端正文 marker**（`_existing`，不带标签过滤）—— 权威，但要能 list issues；
    2. **本地台账**（`ledger_lookup`）—— 连 list 都失败时的兜底；
    3. **建单后校验响应 labels** —— 标签被静默丢弃时记账并告警，
       绝不让「标签丢了 → 下次查不到 → 重复建单」这条链成立。
    """
    repo0, token0 = _cfg()
    repo, token = (repo or repo0), (token or token0)
    url = f"https://api.github.com/repos/{repo}/issues" if repo else "https://api.github.com/repos/<unset>/issues"
    payload = {"title": issue["title"], "body": issue["body"],
               "labels": issue["labels"]}
    request = {"method": "POST", "url": url, "json": payload}

    result: dict[str, Any] = {"dry_run": bool(dry_run), "dedup_key": issue["dedup_key"],
                              "request": request, "issue": issue}
    if out_dir:
        p = Path(out_dir) / f"issue-{issue['mpn']}-{issue['dedup_key']}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"request": request, "issue": issue},
                                ensure_ascii=False, indent=2), encoding="utf-8")
        result["written"] = str(p)
    if dry_run:
        return result

    if not repo:
        raise RuntimeError("未配置仓库：设置 GITHUB_ISSUES_REPO（或 GITHUB_RELEASE_REPO）")
    if not token:
        raise RuntimeError("未配置 token：设置 GITHUB_ISSUES_TOKEN（或 GITHUB_RELEASE_TOKEN）")
    if session is None:
        import requests
        session = requests.Session()

    # 第一层：本地台账（最便宜，且不依赖任何权限）
    hit = ledger_lookup(issue["dedup_key"], ledger)
    if hit:
        result.update(skipped=True, duplicate_of=hit, dedup_source="ledger")
        return result
    # 第二层：云端正文 marker
    dup = _existing(session, repo, token, issue["dedup_key"],
                    label=dedup_label, marker=dedup_marker)
    if dup:
        ledger_record(issue["dedup_key"], dup, ledger)
        result.update(skipped=True, duplicate_of=dup, dedup_source="remote")
        return result

    # 建单前先保证标签存在：GitHub 对不存在的标签是静默丢弃，不补这一步
    # 「标签丢了 → 按标签查不到 → 重复建单」的链条就会重新成立。
    ensured = ensure_labels(session, repo, token, payload["labels"])
    result["labels_ensured"] = ensured

    r = session.post(url, json=payload, timeout=30,
                     headers={"Authorization": f"Bearer {token}",
                              "Accept": "application/vnd.github+json"})
    if r.status_code not in (200, 201):
        raise RuntimeError(f"建单失败 HTTP {r.status_code}: {r.text[:300]}")
    data = r.json()

    # 第三层：校验 response 里的 labels —— 这是「标签被静默丢弃」的唯一信号。
    want = [str(x) for x in (issue.get("labels") or [])]
    got = [str((lb or {}).get("name") if isinstance(lb, dict) else lb)
           for lb in (data.get("labels") or [])]
    missing = [x for x in want if x not in got]
    applied: list[str] = []
    if missing and data.get("number"):
        # 实测：POST /issues 的 labels 会被这个仓库**整批忽略**（标签存在、token 有
        # issues=write、返回 201，但 labels 为空）。单独打标签的端点却是好的
        # （POST /issues/{n}/labels → 200）。所以不能只告警，得补打一次。
        applied = _apply_labels(session, repo, token, data["number"], missing)
        got = sorted(set(got) | set(applied))
        missing = [x for x in want if x not in got]
    if missing:
        reason = (f"补齐失败 {ensured.get('failed')}" if ensured.get("failed")
                  else ensured.get("error") or "token 可能缺 label 写权限")
        hint = ("到 https://github.com/" + repo + "/labels 手动建一次 "
                + "、".join(ensured["failed"]) + " 即可（fine-grained token 无 label "
                "管理端点权限，建单权限正常）；") if ensured.get("failed") else ""
        result.update(labels_dropped=missing,
                      labels_warning=(f"服务端未接受标签 {missing}（{reason}）。{hint}"
                                      f"去重已改用正文 marker + 本地台账，不受影响"))
    if applied:
        result["labels_applied"] = applied

    info = {"number": data.get("number"), "url": data.get("html_url"),
            "repo": repo, "at": _now_iso()}
    ledger_record(issue["dedup_key"], info, ledger)
    result.update(created=True, number=data.get("number"),
                  html_url=data.get("html_url"), labels=got)
    return result


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _apply_labels(session, repo: str, token: str, number: Any,
                  labels: Iterable[str]) -> list[str]:
    """建单后单独打标签，返回服务端确认的标签名。

    **为什么不靠建单那一次**：实测 `POST /issues` 里的 `labels` 会被整批忽略
    （标签存在、token 有 issues=write、HTTP 201，返回体 labels 为空），
    而 `POST /issues/{n}/labels` 是好的。少这一次补打，§17 要求的两个标签
    就永远落不到单上。失败只返回已成功的部分，由调用方决定告警。
    """
    want = [str(x) for x in (labels or [])]
    if not want or not number:
        return []
    url = f"https://api.github.com/repos/{repo}/issues/{number}/labels"
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/vnd.github+json"}
    try:
        r = session.post(url, json={"labels": want}, headers=headers, timeout=30)
    except Exception:                                     # noqa: BLE001
        return []
    if r.status_code not in (200, 201):
        return []
    try:
        return [str((lb or {}).get("name") if isinstance(lb, dict) else lb)
                for lb in (r.json() or [])]
    except ValueError:
        return []


def trigger_auto_qa(*, pkg: str, releases_dir: str | Path = "data/_delivery_releases",
                    dry_run: bool = True, repo: str | None = None,
                    token: str | None = None, remote: str = "origin",
                    require_pushed: bool = True,
                    out_dir: str | Path | None = None, extra: str = "") -> dict:
    """**AGENT.md §17 的唯一入口**：新包推送成功后自动开一张 `[CMD]` 质审单。

    实现放在 `release_notify`（要算 ZIP 哈希、验 git 推送状态），这里只做转发：
    §17 是项目级约束，别的脚本应当 import 这个函数名，而不是各自去拼 Issue。

    默认 `dry_run=True` —— 自动建单会污染仓库，先看请求体再 `--push`。
    `.json/.csv` 与 `--dry-run/--push` 的语义跟 `app.qa.controller` 保持一致，
    两个 CLI 不该有两种约定。
    """
    from app.integrations import release_notify as RN   # 延迟导入：避免模块级循环引用
    return RN.notify(releases_dir=releases_dir, pkg=pkg, dry_run=dry_run,
                     repo=repo, token=token, remote=remote,
                     require_pushed=require_pushed, out_dir=out_dir, extra=extra)


# ---------------------------------------------------------------- 同步（GitHub → 本地）
#: 只同步带这个标签的 open issue。它同时是建单侧的 `LABEL_BASE[0]`，两侧同一个标签
#: 才不会出现「自动建的单一单都同步不下来」。
SYNC_LABEL = "qa-audit"

#: 反向标记：`<!-- gh-issue: 14 -->`。**不靠文件名反查编号** —— 文件名里的
#: 标题 slug 是会变的（issue 一改标题就变），拿它当主键迟早对不上。
SYNC_MARKER = "gh-issue"

#: 索引文件名。下划线开头，一眼和 `GH-*.md` 区分开。
INDEX_NAME = "_index.md"

#: 标题 slug 的截断长度。Windows 路径总长 260，仓库前缀已经占掉约 55，
#: 剩下的余量要留给中文标题。
SLUG_MAX = 56

#: 默认落盘目录（相对仓库根）。Trae 接手时只读这里。
DEFAULT_SYNC_DIR = "algorithm_lab/issues"

#: 分页上限。20 × 100 = 2000 张单，超过说明该分仓库或该加过滤条件了，
#: 无上限地翻页只会把一次同步拖成几分钟。
SYNC_MAX_PAGES = 20


class SyncError(RuntimeError):
    """同步失败。消息必须能让读的人**直接动手** —— 只丢一个状态码等于没说。"""


#: 路径非法字符。Windows 上 `:` `*` `?` `"` `<` `>` `|` 与 `/` `\` 都不能进文件名。
_SLUG_BAD = re.compile(r'[\\/:*?"<>|]+')
#: 分隔符类字符：空白与各种圆点。标题里 `LM317 · 多列塌缩` 的 `·` 不该留在文件名里。
_SLUG_SEP = re.compile("[\\s\u00b7\u2022\u2014\u2013]+")
_SLUG_DASHES = re.compile(r"-{2,}")
_TAG_PREFIX = re.compile(r"^\s*\[[^\]]*\]\s*")


def issue_slug(title: str) -> str:
    """标题 → 文件名片段。`[质审/P0] LM317 · 多列塌缩` → `LM317-多列塌缩`。

    开头的 `[xxx]` 是分类标签不是标题内容，带进文件名会让整个目录一列全是
    `质审-` 开头。中文原样保留（Windows 文件名支持 UTF-8）。
    """
    s = str(title or "").strip()
    while True:                                   # 可能连着好几个 `[A] [B]`
        m = _TAG_PREFIX.match(s)
        if not m:
            break
        s = s[m.end():]
    s = _SLUG_BAD.sub("-", s)
    s = _SLUG_SEP.sub("-", s)
    s = _SLUG_DASHES.sub("-", s).strip("-")
    return s[:SLUG_MAX].strip("-") or "issue"


def issue_filename(number: int | str, title: str) -> str:
    """`GH-14-LM317-多列塌缩.md`。编号在最前，目录按编号排序即可读。"""
    return f"GH-{int(number)}-{issue_slug(title)}.md"


def _fmt_utc(iso: str | None) -> str:
    """`2026-11-03T04:30:00Z` → `2026-11-03 04:30 UTC`（人读，且保留时区含义）。"""
    s = str(iso or "").strip()
    m = re.match(r"^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})", s)
    return f"{m.group(1)} {m.group(2)} UTC" if m else (s or "—")


def _names(items) -> list[str]:
    out = []
    for x in (items or []):
        n = str((x or {}).get("name") if isinstance(x, dict) else x or "").strip()
        if n:
            out.append(n)
    return out


def render_issue_md(issue: dict, comments: list[dict] | None = None) -> str:
    """一张工单的完整本地镜像：抬头元信息 → 正文 → 全部评论 → 机器标记。

    刻意**不写「本次同步时间」**：内容一个字没变也每次同步都产生 diff，
    增量判断（内容相同就不重写）会立刻失效，git log 也会被「同步于 XX:XX」刷满。
    源数据的 `updated_at` 照写 —— 读者需要知道这页有多旧。同步时间只进 `_index.md`。
    """
    number = issue.get("number")
    title = str(issue.get("title") or "").strip() or "（无标题）"
    state = str(issue.get("state") or "").strip().upper() or "—"
    labels = _names(issue.get("labels"))
    user = ((issue.get("user") or {}).get("login")) or "—"
    url = str(issue.get("html_url") or "").strip()
    body = str(issue.get("body") or "").strip()
    cmts = list(comments or [])
    lab_txt = "".join("`" + x + "` " for x in labels).strip() or "—"

    lines: list[str] = [
        f"# GH-{number} · {title}",
        "",
        "> 本文件由 `python -m app.integrations.github_issues sync` 从 GitHub 自动同步，",
        "> **不要手工编辑** —— 下次同步会整篇覆盖。要改请改 GitHub 上的 issue。",
        "",
        "| 项 | 值 |",
        "|---|---|",
        f"| 编号 | #{number} |",
        f"| 状态 | **{state}** |",
        f"| 标签 | {lab_txt} |",
        f"| 作者 | `{user}` |",
        f"| 创建 | {_fmt_utc(issue.get('created_at'))} |",
        f"| 更新 | {_fmt_utc(issue.get('updated_at'))} |",
        f"| 评论 | {len(cmts)} 条 |",
        f"| 链接 | {url or '—'} |",
        "",
        "---",
        "",
        "## 正文",
        "",
        body or "（正文为空）",
        "",
        "---",
        "",
        f"## 评论（{len(cmts)}）",
        "",
    ]
    if not cmts:
        lines += ["（暂无评论）", ""]
    for i, c in enumerate(cmts, 1):
        cu = ((c.get("user") or {}).get("login")) or "—"
        lines += [f"### {i} · `{cu}` · {_fmt_utc(c.get('created_at'))}", "",
                  str(c.get("body") or "").strip() or "（空）", ""]
    # 机器标记放最后：靠它把文件反查回编号，不看文件名。
    lines.append(f"<!-- {SYNC_MARKER}: {number} -->")
    # 末尾补换行：POSIX 文本文件应当以 `\n` 结尾，否则 git 会标 "No newline at
    # end of file"，拼接/追加时也会把下一行顶到标记后面。
    return "\n".join(lines) + "\n"


def render_index(rows: list[dict], *, repo: str, label: str,
                 synced_at: str, stale: list[str]) -> str:
    """`_index.md`：一眼看全「本地有哪些单、各自什么状态」。

    这是唯一带**同步时间**的文件 —— 它的职责就是报告「这批镜像有多新」。
    """
    # 按编号升序。API 默认按 `updated` 倒序返回，直接照抄的话索引顺序会随
    # 谁刚被回复而变 —— 每次同步都魔改一遍顺序，diff 里全是无意义的行移动。
    rows = sorted(rows, key=lambda r: int(r.get("number") or 0))
    lines = [
        "# GitHub Issue 同步索引",
        "",
        f"- 仓库：`{repo}`",
        f"- 过滤：标签 `{label}`，状态 `open`",
        f"- 最后同步：{synced_at}",
        f"- 件数：{len(rows)}",
        "",
        "> 本文件由 `python -m app.integrations.github_issues sync` 生成，不要手工编辑。",
        "> 逐件详情见同目录 `GH-*.md`。",
        "",
        "| 编号 | 标题 | 状态 | 标签 | 更新 | 文件 |",
        "|---|---|---|---|---|---|",
    ]
    for r in rows:
        labs = " ".join("`" + str(x) + "`" for x in (r.get("labels") or [])) or "—"
        lines.append(
            f"| [#{r['number']}]({r.get('url') or ''}) | {r.get('title') or '—'} | "
            f"{r.get('state') or '—'} | {labs} | {_fmt_utc(r.get('updated_at'))} | "
            f"`{r.get('file')}` |")
    if stale:
        lines += [
            "",
            "## 本地有、本次未返回",
            "",
            "这些文件仍在目录里（**没有自动删除**）。原因可能是 issue 已关闭，",
            "或者只是不再带该标签 —— 仍然是有价值的记录，删不删由人定：",
            "",
        ]
        lines += [f"- `{x}`" for x in stale]
    lines.append("")
    return "\n".join(lines)


def _raise_for(r, repo: str) -> None:
    """按状态码给出**能动手**的错误信息。

    404 这一条尤其重要：GitHub 对**无权限的私有仓库返回 404 而不是 403**。
    照抄「仓库不存在」会让人去查一个根本没有拼错的仓库名，查半天。
    """
    code = int(getattr(r, "status_code", 0) or 0)
    if code == 200:
        return
    if code == 401:
        raise SyncError(
            f"401 未授权：token 无效或已过期（repo=`{repo}`）。"
            "检查 GITHUB_ISSUES_TOKEN / GITHUB_RELEASE_TOKEN。")
    if code == 403:
        hdr = getattr(r, "headers", None) or {}
        if str(hdr.get("x-ratelimit-remaining", "")).strip() == "0":
            raise SyncError(
                "403 触发 GitHub 限流（剩余配额 0，"
                f"重置时间戳 {hdr.get('x-ratelimit-reset') or '未知'}）。"
                "等窗口重置，或换一个 token / 加 token 提高配额。")
        raise SyncError(
            f"403 无权限：token 缺少读 issues 的权限（repo=`{repo}`）。")
    if code == 404:
        raise SyncError(
            f"404 仓库不存在**或无权访问**：repo=`{repo}`。"
            "GitHub 对私有仓库在无权限时返回 404 而不是 403 —— "
            "先确认 token 对该 repo 有 read 权限，再检查仓库名拼写。")
    body = str(getattr(r, "text", "") or "")[:200]
    raise SyncError(f"HTTP {code}（repo=`{repo}`）：{body}")


def _fetch_comments(session, repo: str, number, headers: dict) -> list[dict]:
    """一张单的全部评论。评论是「人工回复更新」的载体，body 里看不到。"""
    url = f"https://api.github.com/repos/{repo}/issues/{number}/comments"
    out: list[dict] = []
    for page in range(1, 6):                       # 单张单 500 条评论足够
        r = session.get(url, params={"per_page": 100, "page": page},
                        headers=headers, timeout=30)
        _raise_for(r, repo)
        items = r.json() or []
        out.extend(items)
        if len(items) < 100:
            break
    return out


def sync_issues_to_local(*, repo: str | None = None, token: str | None = None,
                         label: str = SYNC_LABEL,
                         out_dir: str | Path | None = None,
                         session=None, dry_run: bool = False,
                         max_pages: int = SYNC_MAX_PAGES, per_page: int = 100,
                         with_comments: bool = True) -> dict:
    """把 GitHub 上带 `label` 的 open issue 同步成本地 Markdown 镜像。

    拉什么
    ------
    ``GET /repos/{repo}/issues?state=open&labels={label}``，**逐条评论另行拉取**。
    只拉 issue 不拉评论是不完整的：人工复核往往写在回复里，body 一个字没变。

    落盘
    ----
    ``{out_dir}/GH-{number}-{slug}.md``，外加一份 ``_index.md``。
    **同编号的旧文件会被删掉**：文件名带标题 slug，issue 改标题就等于换了文件名，
    只写新的不删旧的，目录里会同时存在两份内容不同的记录。

    幂等
    ----
    内容与磁盘一致就**不写**（``unchanged``），避免每次同步产生无意义的
    mtime/git 变更。所以正文里不能有「本次同步时间」，只有源 ``updated_at``。

    不删本地残留
    ------------
    本地有、本次没返回的文件（issue 关了 / 不再带标签）只在 ``stale`` 里报出来，
    **不自动删除**：那可能是有价值的历史记录，脚本没资格替人做这个决定。
    """
    repo0, token0 = _cfg()
    repo = (repo if repo is not None else repo0 or "").strip()
    token = (token if token is not None else token0 or "").strip()
    # 校验放在任何请求之前：空仓库名会打到一个 404，让人去查一个不存在的拼写。
    if not repo:
        raise SyncError("未配置仓库：设置 GITHUB_ISSUES_REPO（或 GITHUB_RELEASE_REPO），"
                        "或用 --repo 指定 owner/name")
    if not token:
        raise SyncError("未配置 token：设置 GITHUB_ISSUES_TOKEN（或 GITHUB_RELEASE_TOKEN），"
                        "或用 --token 指定")

    if session is None:
        import requests
        session = requests.Session()

    out = Path(out_dir or DEFAULT_SYNC_DIR)
    headers = {"Authorization": f"Bearer {token}",
               "Accept": "application/vnd.github+json"}
    url = f"https://api.github.com/repos/{repo}/issues"

    # 1. 拉 issue（分页）
    issues: list[dict] = []
    for page in range(1, max(1, max_pages) + 1):
        r = session.get(url, params={"state": "open", "labels": label,
                                     "per_page": per_page, "page": page},
                        headers=headers, timeout=30)
        _raise_for(r, repo)
        items = r.json() or []
        for it in items:
            # `/issues` 端点**同时返回 PR**。不过滤的话本地会凭空多出 `GH-*` 文件，
            # 正文还是 PR 描述 —— 这是这个端点最经典的坑。
            if isinstance(it, dict) and "pull_request" in it:
                continue
            issues.append(it)
        if len(items) < per_page:
            break

    if not dry_run:
        out.mkdir(parents=True, exist_ok=True)

    written: list[dict] = []
    unchanged: list[str] = []
    planned: list[str] = []
    errors: list[dict] = []
    rows: list[dict] = []
    seen: set[str] = set()

    for it in issues:
        number = it.get("number")
        name = issue_filename(number, str(it.get("title") or ""))
        try:
            cmts = _fetch_comments(session, repo, number, headers) if with_comments else []
            md = render_issue_md(it, cmts)
        except Exception as e:                            # noqa: BLE001
            errors.append({"number": number, "error": str(e)})
            continue

        rows.append({"number": number, "title": str(it.get("title") or ""),
                     "state": str(it.get("state") or ""), "labels": _names(it.get("labels")),
                     "updated_at": it.get("updated_at"), "url": it.get("html_url"),
                     "file": name})
        seen.add(name)

        if dry_run:
            planned.append(name)
            continue

        target = out / name
        existed = target.exists()
        if existed and target.read_text(encoding="utf-8", errors="replace") == md:
            unchanged.append(name)
        else:
            tmp = target.with_suffix(".md.tmp")
            tmp.write_text(md, encoding="utf-8")
            tmp.replace(target)
            written.append({"file": name, "number": number,
                            "comments": len(cmts),
                            "action": "updated" if existed else "created"})
        # 清掉同编号的旧文件名（issue 改过标题）。`GH-1-*` 不会误伤 `GH-14-*`。
        for old in out.glob(f"GH-{int(number)}-*.md"):
            if old.name != name:
                old.unlink()

    stale = (sorted(p.name for p in out.glob("GH-*.md") if p.name not in seen)
             if out.is_dir() else [])

    index_path = None
    if not dry_run:
        idx = out / INDEX_NAME
        idx.write_text(render_index(rows, repo=repo, label=label,
                                    synced_at=_fmt_utc(_now_iso()), stale=stale),
                       encoding="utf-8")
        index_path = str(idx)

    return {"repo": repo, "label": label, "out_dir": str(out),
            "fetched": len(issues), "written": written, "unchanged": unchanged,
            "planned": planned, "stale": stale, "errors": errors,
            "index": index_path, "dry_run": bool(dry_run)}


def _sync_cli(argv: list[str]) -> int:
    """`sync` 分支的参数解析与打印。

    只打印**人要看的那几行**：新建/更新了哪些、多少件没变、哪些本地残留没被返回。
    完整结构走 `--json`，免得正常同步一次刷出几百行 JSON 把终端埋掉。
    """
    import argparse
    import sys

    ap = argparse.ArgumentParser(
        prog="python -m app.integrations.github_issues sync",
        description="把 GitHub 上带标签的 open issue 拉成本地 Markdown 镜像")
    ap.add_argument("--out", default=DEFAULT_SYNC_DIR,
                    help=f"落盘目录（默认 {DEFAULT_SYNC_DIR}）")
    ap.add_argument("--repo", default=None,
                    help="owner/name（默认读 GITHUB_ISSUES_REPO，回退 GITHUB_RELEASE_REPO）")
    ap.add_argument("--token", default=None,
                    help="访问令牌（默认读 GITHUB_ISSUES_TOKEN，回退 GITHUB_RELEASE_TOKEN）")
    ap.add_argument("--label", default=SYNC_LABEL,
                    help=f"只同步带此标签的单（默认 {SYNC_LABEL}）")
    ap.add_argument("--dry-run", action="store_true",
                    help="只列出将要写哪些文件，不落盘")
    ap.add_argument("--no-comments", action="store_true",
                    help="不拉评论（人工回复就在评论里，一般不要关）")
    ap.add_argument("--json", action="store_true", help="输出完整 JSON 结果")
    a = ap.parse_args(argv)

    try:
        res = sync_issues_to_local(repo=a.repo, token=a.token, label=a.label,
                                   out_dir=str(a.out), dry_run=a.dry_run,
                                   with_comments=not a.no_comments)
    except SyncError as e:
        # 退出码 2 与「跑成功但一条没拉到」区分开：后者是 0。
        print(f"同步失败：{e}", file=sys.stderr)
        return 2
    except Exception as e:                              # noqa: BLE001
        print(f"同步异常：{type(e).__name__}: {e}", file=sys.stderr)
        return 1

    if a.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0

    written = res.get("written") or []
    print(f"仓库 {res.get('repo')}  标签 {res.get('label')}  "
          f"拉到 {res.get('fetched', 0)} 张单 → {res.get('out_dir')}")
    if res.get("dry_run"):
        print(f"[dry-run] 将写 {len(res.get('planned') or [])} 个文件：")
        for n in (res.get("planned") or []):
            print(f"  + {n}")
        return 0
    if written:
        print(f"写入 {len(written)} 个：")
        for w in written:
            print(f"  {w.get('action', '?'):8s} {w.get('file')}"
                  f"（评论 {w.get('comments', 0)} 条）")
    else:
        print("无变化（内容与磁盘一致，未重写任何文件）")
    if res.get("unchanged"):
        print(f"未变 {len(res['unchanged'])} 个")
    if res.get("stale"):
        print(f"本地有、本次未返回 {len(res['stale'])} 个（**未删除**，请看 {INDEX_NAME}）：")
        for n in res["stale"]:
            print(f"  ? {n}")
    if res.get("errors"):
        print(f"失败 {len(res['errors'])} 张：", file=sys.stderr)
        for x in res["errors"]:
            print(f"  ! #{x.get('number')}: {x.get('error')}", file=sys.stderr)
        return 1
    return 0


# ---------------------------------------------------------------- 回帖（修复汇报）
#: 回帖用的最小校验：GitHub 的评论正文上限是 65536 字符（与 issue body 同档），
#: 留 2k 余量给后续追加。超了不截断 —— 截断会静默丢掉最后一段结论。
MAX_COMMENT = 63000


def reply_issue(number: int, body: str, *, repo: str | None = None,
                token: str | None = None, session=None,
                dry_run: bool = False) -> dict:
    """在指定 issue 下发一条评论（POST `/issues/{n}/comments`）。

    为什么单独一个函数而不是复用 `create_issue`：建单要带 labels / 去重三层 /
    台账，回帖只需要「把一段人写的证据贴上去」。硬塞进建单路径会让去重逻辑
    误把评论当成第二次建单。

    返回值带 `html_url`：这是**回帖真的落库**的唯一凭据（可为人工复核点开）。
    4xx 一律带上下文抛错，不静默 —— 帖子没发出去而脚本返回成功，是最坏的失败。
    """
    repo0, token0 = _cfg()
    repo = str(repo if repo is not None else repo0 or "").strip()
    token = str(token if token is not None else token0 or "").strip()
    body = str(body or "").strip()
    if not body:
        raise ValueError("评论正文为空：拒绝发一条没有内容的回帖")
    if len(body) > MAX_COMMENT:
        raise ValueError(f"评论正文 {len(body)} 字符，超过上限 {MAX_COMMENT}")
    n = int(number)
    url = f"https://api.github.com/repos/{repo}/issues/{n}/comments"
    request = {"method": "POST", "url": url, "json": {"body": body}}
    if dry_run:
        return {"dry_run": True, "issue": n, "request": request}
    if not repo:
        raise RuntimeError("未配置仓库：设置 GITHUB_ISSUES_REPO（或 GITHUB_RELEASE_REPO），"
                           "或用 --repo 指定 owner/name")
    if not token:
        raise RuntimeError("未配置 token：设置 GITHUB_ISSUES_TOKEN（或 GITHUB_RELEASE_TOKEN）")
    if session is None:
        import requests
        session = requests.Session()
    r = session.post(url, json={"body": body}, timeout=30,
                     headers={"Authorization": f"Bearer {token}",
                              "Accept": "application/vnd.github+json"})
    if r.status_code not in (200, 201):
        raise RuntimeError(f"回帖失败 HTTP {r.status_code}（issue #{n}）："
                           f"{str(getattr(r, 'text', '') or '')[:300]}")
    data = r.json() or {}
    return {"dry_run": False, "issue": n, "comment_id": data.get("id"),
            "html_url": data.get("html_url"), "created_at": data.get("created_at"),
            "body": data.get("body")}


def _reply_cli(argv: list[str]) -> int:
    """`reply` 分支：`--id N --body "…"`（或 `--body-file 文件`）。"""
    import argparse
    import sys

    ap = argparse.ArgumentParser(
        prog="python -m app.integrations.github_issues reply",
        description="给指定 issue 追加一条评论（修复汇报/证据）")
    ap.add_argument("--id", type=int, required=True, help="issue 编号（不带 #）")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--body", default="", help="评论正文（Markdown）")
    g.add_argument("--body-file", default="", help="从文件读正文（长文本用这个）")
    ap.add_argument("--repo", default=None,
                    help="owner/name（默认读 GITHUB_ISSUES_REPO，回退 GITHUB_RELEASE_REPO）")
    ap.add_argument("--token", default=None,
                    help="访问令牌（默认读 GITHUB_ISSUES_TOKEN，回退 GITHUB_RELEASE_TOKEN）")
    ap.add_argument("--dry-run", action="store_true", help="只打印请求体，不发网络请求")
    a = ap.parse_args(argv)

    body = a.body
    if a.body_file:
        body = Path(a.body_file).read_text(encoding="utf-8")
    try:
        res = reply_issue(a.id, body, repo=a.repo, token=a.token, dry_run=a.dry_run)
    except (ValueError, RuntimeError) as e:
        print(f"回帖失败：{e}", file=sys.stderr)
        return 2
    if res.get("dry_run"):
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    print(f"已回帖 #{a.id}：{res.get('html_url')}")
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0


def comment_issue(issue_number: int, body: str, **kw) -> dict:
    """`comment_issue(n, body)` —— 名字对齐调用方直觉的回帖入口。

    实现在 `reply_issue`，这里只做**改名转发**，不复制逻辑：两份实现迟早漂移
    （一份加了长度校验、另一份没加），而回帖恰恰是「内容超长被 GitHub 静默截断」
    最容易出事的路径。留一个薄壳，函数名好读，行为只有一个来源。
    """
    return reply_issue(issue_number, body, **kw)


def close_issue(issue_number: int, *, repo: str | None = None,
                token: str | None = None, session=None,
                dry_run: bool = False, state_reason: str = "completed") -> dict:
    """把 issue 置为 `closed`（`PATCH /repos/{repo}/issues/{n}`）。

    为什么必须真的关单，而不是「回帖说已修」：工单是**待办队列**。
    修完不回帖不关单，下一轮 `sync` 仍然把它当 open 拉下来，`next` 子命令还会
    把它派给本地 Agent —— 已修完的活被反复返工，队列越用越假。
    回帖给的是证据，关单给的是「这条已出队」。

    `state_reason="completed"` 而不是默认的 `"reopened"`/空：GitHub 据此把单子
    显示成「completed」而不是「closed as not planned」，人扫一眼能分清
    「修完了」和「不修了」。

    4xx 一律抛错：静默失败会让调用方以为关掉了，队列里却还挂着。
    """
    repo0, token0 = _cfg()
    repo = str(repo if repo is not None else repo0 or "").strip()
    token = str(token if token is not None else token0 or "").strip()
    n = int(issue_number)
    url = f"https://api.github.com/repos/{repo}/issues/{n}"
    payload = {"state": "closed", "state_reason": state_reason}
    if dry_run:
        return {"dry_run": True, "issue": n,
                "request": {"method": "PATCH", "url": url, "json": payload}}
    if not repo:
        raise RuntimeError("未配置仓库：设置 GITHUB_ISSUES_REPO（或 GITHUB_RELEASE_REPO），"
                           "或用 --repo 指定 owner/name")
    if not token:
        raise RuntimeError("未配置 token：设置 GITHUB_ISSUES_TOKEN（或 GITHUB_RELEASE_TOKEN）")
    if session is None:
        import requests
        session = requests.Session()
    r = session.patch(url, json=payload, timeout=30,
                      headers={"Authorization": f"Bearer {token}",
                               "Accept": "application/vnd.github+json"})
    if r.status_code not in (200, 201):
        raise RuntimeError(f"关单失败 HTTP {r.status_code}（issue #{n}）："
                           f"{str(getattr(r, 'text', '') or '')[:300]}")
    data = r.json() or {}
    return {"dry_run": False, "issue": n, "state": data.get("state"),
            "state_reason": data.get("state_reason"),
            "closed_at": data.get("closed_at"), "html_url": data.get("html_url")}


def _close_cli(argv: list[str]) -> int:
    """`close` 分支：`--id 14 23`（可一次关多张）。"""
    import argparse
    import sys

    ap = argparse.ArgumentParser(
        prog="python -m app.integrations.github_issues close",
        description="把 issue 置为 closed（修完出队）")
    ap.add_argument("--id", type=int, nargs="+", required=True,
                    help="issue 编号（可多个，不带 #）")
    ap.add_argument("--reason", default="completed",
                    choices=("completed", "not_planned"),
                    help="关闭原因（默认 completed=修完了）")
    ap.add_argument("--repo", default=None)
    ap.add_argument("--token", default=None)
    ap.add_argument("--dry-run", action="store_true", help="只打印请求体")
    a = ap.parse_args(argv)

    rc = 0
    for n in a.id:
        try:
            res = close_issue(n, repo=a.repo, token=a.token,
                              dry_run=a.dry_run, state_reason=a.reason)
        except (ValueError, RuntimeError) as e:
            print(f"关单失败 #{n}：{e}", file=sys.stderr)
            rc = 2
            continue
        if res.get("dry_run"):
            print(json.dumps(res, ensure_ascii=False, indent=2))
        else:
            print(f"已关单 #{n} → {res.get('state')}"
                  f"（{res.get('state_reason')}）{res.get('html_url')}")
    return rc


# ---------------------------------------------------------------- 下一个任务（Trae 接手）
#: 扫描本地镜像目录而不是打 GitHub API：Trae 跑在 Windows 上，看一眼「下一个该修哪个」
#: 不应该依赖网络与额度；而且镜像里连 Checklist 都是现成的，省一次解析 issue body。
TASK_ISSUES_DIR = DEFAULT_SYNC_DIR
#: 生成的提示词落盘位置。守护脚本（algorithm_lab/daemon.py）监听的就是这个文件。
NEXT_TASK_PATH = "algorithm_lab/next_task.md"
#: 只挑这一档交给本地修。P1 是「可读性/结构问题」，掺进来会让 Trae 淹没在噪声里。
TASK_SEVERITY = "P0"
#: 顶部标记行。守护脚本靠 `sha=` 做幂等（内容没变就不重复唤醒），
#: 人也一眼能看出这文件是机器生成的、别手改。
TASK_MARKER = "next-task"

_GH_HEAD = re.compile(r"^#\s+GH[- ]?(\d+)\s*[·:：]\s*(.+?)\s*$")
_CHECK = re.compile(r"^- \[ \]\s+\[(P\d+)/([^\]]+)\]\s*(.+?)\s*$")
_COUNT = re.compile(r"P(\d+)\s*×\s*(\d+)")
_BACKTICK = re.compile(r"`([^`]+)`")
_LINK = re.compile(r"https?://\S+")


def _cell(text: str, name: str) -> str:
    """取 Markdown 表格里 `| name | value |` 的 value，去掉粗体与反引号。

    只认**行首是 `|`** 的表格行，避免正文里的同名粗体被误当元信息。
    """
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) >= 2 and cells[0] == name:
            return cells[1].replace("**", "").strip()
    return ""


def parse_issue_markdown(text: str, path: str | Path | None = None) -> dict | None:
    """解析 `sync` 产出的 `GH-<n>-*.md`。

    只认能稳定往返的几处结构：标题行 `# GH-23 · …`、开头元信息表、Checklist 行
    `- [ ] [P0/多列塌缩] …`。**解析不出编号就返回 None** —— 宁可少挑一张，
    也不要挑错一张让 Trae 白改一版。
    """
    head = None
    for line in text.splitlines():
        head = _GH_HEAD.match(line)
        if head:
            break
    if not head:
        return None

    number = int(head.group(1))
    title = head.group(2)
    labels = _BACKTICK.findall(_cell(text, "标签"))
    state = (_cell(text, "状态") or "").upper()
    link_m = _LINK.search(_cell(text, "链接"))
    counts = {f"P{k}": int(v) for k, v in _COUNT.findall(_cell(text, "缺陷数"))}
    items = [
        {"severity": m.group(1), "category": m.group(2), "text": m.group(3)}
        for m in (_CHECK.match(line) for line in text.splitlines()) if m
    ]
    # 逐条详情里的「页码 + bbox」是给本地 Agent 的定位证据：没有它，它得自己翻 PDF。
    # 块按 `#### 1. …` 切开，顺序与 Checklist 一致，按下标对齐。
    for i, blk in enumerate(re.split(r"^####\s+\d+\.\s+", text, flags=re.M)[1:]):
        if i >= len(items):
            break
        loc = re.search(r"\*\*页码\*\*[：:]\s*(p\d+)(?:\s*·\s*bbox\s*`([^`]+)`)?", blk)
        if loc:
            items[i]["page"] = loc.group(1)
            items[i]["bbox"] = (loc.group(2) or "").strip()
        row = re.search(r"【目标行】\n(.+?)(?:\n```|\Z)", blk, re.S)
        if row:
            first = next((x.strip() for x in row.group(1).splitlines() if x.strip()), "")
            items[i]["row"] = first[:200]

    # 复现命令整段拿走：让 Trae 拿到就能跑，不用回 GitHub 翻正文。
    repro = ""
    m = re.search(r"```bash\n(.*?)```", text, re.S)
    if m and "app.qa.controller" in m.group(1):
        repro = m.group(1).strip()

    return {
        "number": number,
        "title": title,
        "state": state or "OPEN",
        "labels": labels,
        "link": link_m.group(0) if link_m else "",
        "mpn": _cell(text, "MPN").strip("` "),
        "conclusion": _cell(text, "本轮结论"),
        "counts": counts,
        "total": sum(counts.values()) or len(items),
        "items": items,
        "repro": repro,
        "path": str(path or ""),
        "mtime": Path(path).stat().st_mtime if path and Path(path).is_file() else 0.0,
    }


def scan_issues(issues_dir: str | Path = TASK_ISSUES_DIR,
                severity: str = TASK_SEVERITY) -> list[dict]:
    """扫描镜像目录，返回指定级别、状态为 OPEN 的单，按编号升序。

    **状态只信镜像里的 `状态` 行** —— 而镜像有一个已知缺陷：`sync` 只拉 open，
    已关闭的单不会被重写，于是它的镜像会永远停在 `OPEN`。所以真正下手前
    用 `verify=True` 打一次 GitHub 复核（见 `build_next_task_prompt`）。
    """
    root = Path(issues_dir)
    if not root.is_dir():
        return []
    out: list[dict] = []
    for p in sorted(root.glob("GH-*.md")):
        try:
            text = p.read_text(encoding="utf-8")
        except OSError:
            continue
        rec = parse_issue_markdown(text, p)
        if not rec:
            continue
        if rec["state"] != "OPEN":
            continue
        if severity and severity not in rec["labels"] and f"/{severity}]" not in rec["title"]:
            continue
        out.append(rec)
    return sorted(out, key=lambda r: r["number"])


def pick_next_issue(issues: Iterable[dict], number: int | None = None) -> dict | None:
    """挑一张：指定编号优先，否则取**编号最大**（最新）的那张。"""
    items = list(issues)
    if number is not None:
        return next((r for r in items if r["number"] == number), None)
    return max(items, key=lambda r: r["number"]) if items else None


def _verify_issue(number: int, *, repo: str | None = None,
                  token: str | None = None, session=None) -> dict | None:
    """打一次 GitHub 复核这张单是否仍然 open。拿不到就返回 None（不阻断）。"""
    repo0, token0 = _cfg()
    repo, token = repo or repo0, token or token0
    if not repo or not token:
        return None
    if session is None:
        try:
            import requests
            session = requests.Session()
        except Exception:                                 # noqa: BLE001
            return None
    try:
        r = session.get(f"https://api.github.com/repos/{repo}/issues/{number}",
                        headers={"Authorization": f"Bearer {token}",
                                 "Accept": "application/vnd.github+json"}, timeout=30)
    except Exception:                                     # noqa: BLE001
        return None
    if r.status_code != 200:
        return None
    try:
        d = r.json()
    except ValueError:
        return None
    return {"state": (d.get("state") or "").upper(),
            "labels": [str((x or {}).get("name")) for x in (d.get("labels") or [])]}


def render_task_prompt(issue: dict | None, *, max_items: int = 5) -> str:
    """把一张单渲染成 `next_task.md` —— 结构固定为四段，Trae 直接照着做。

    ```
    # 待修任务：#23 LM358 · 10 项缺陷
    ## 核心 checklist      —— 前 5 条 checklist 原文（不改写，改了就没法逐条勾）
    ## 相关证据            —— 页码 + bbox + 原文切片（没有它，Trae 得自己翻 PDF）
    ## 修复要求            —— 固定四条：改 Prompt/table_audit、dry-run、fixes #N、回帖
    ```
    """
    if not issue:
        return (
            "# 待修任务：无\n\n"
            "`algorithm_lab/issues/` 里当前没有 OPEN 的 P0 质审单。\n"
            "要么都修完了，要么镜像没刷新：`python -m app.integrations.github_issues "
            "sync` 之后再 `next`。\n"
        )

    n = issue["number"]
    mpn = issue["mpn"] or "?"
    top = [x for x in issue["items"] if x["severity"] == TASK_SEVERITY][:max_items]
    if not top:                                  # 没标 P0 的镜像：退化成前 5 条
        top = issue["items"][:max_items]

    lines = [f"# 待修任务：#{n} {mpn} · {issue['total']} 项缺陷", "", "## 核心 checklist", ""]
    lines += [f"- [ ] [{x['severity']}/{x['category']}] {x['text']}" for x in top]
    lines += ["", "## 相关证据", ""]
    for i, x in enumerate(top, 1):
        loc = x.get("page") or "页码未定"
        if x.get("bbox"):
            loc += f" · bbox `{x['bbox']}`"
        lines.append(f"{i}. `{x['category']}` · {loc}")
        if x.get("row"):
            lines.append(f"   - 原文：`{x['row']}`")
    if not any(x.get("page") for x in top):
        lines.append("- 镜像里没有 bbox/页码，需人工在原文定位后再改")
    lines += [
        "",
        "## 修复要求",
        "",
        "1. 修改 Prompt / table_audit，按 AGENT.md 规则修复",
        f"2. 本地用 {mpn} 跑 dry-run 验证通过",
        f"3. 提交时 commit message 带 `fixes #{n}`",
        "4. 提交后调用 reply_to_issue 回复结果",
        "",
    ]
    return "\n".join(lines)


def build_next_task_prompt(*, issues_dir: str | Path = TASK_ISSUES_DIR,
                           out_path: str | Path = NEXT_TASK_PATH,
                           number: int | None = None,
                           severity: str = TASK_SEVERITY,
                           verify: bool = True,
                           repo: str | None = None, token: str | None = None,
                           session=None, dry_run: bool = False) -> dict:
    """挑出最新一张 open 的 P0 单，渲染成 `algorithm_lab/next_task.md`。

    返回 `{written, changed, sha, issue, issues_open, verified, stale, path, content}`。
    **`changed=False` 表示内容与磁盘一致、没重写** —— 守护脚本据此判断要不要叫醒
    Trae：没有这一层，任何一次调用都会让文件 mtime 变新，watchdog 就会无限自激。
    """
    root = Path(issues_dir)
    out = Path(out_path)
    issues = scan_issues(root, severity=severity)

    picked = pick_next_issue(issues, number=number)
    verified = None
    stale: list[int] = []
    if picked and verify:
        verified = _verify_issue(picked["number"], repo=repo, token=token, session=session)
        # 镜像说 open、线上已 close（sync 只拉 open，关单不会回写镜像）→ 跳过它继续挑。
        while verified and verified["state"] != "OPEN":
            stale.append(picked["number"])
            rest = [r for r in issues if r["number"] not in stale]
            picked = pick_next_issue(rest, number=None if number is None else number)
            if not picked:
                break
            verified = _verify_issue(picked["number"], repo=repo, token=token, session=session)

    body = render_task_prompt(picked)
    sha = hashlib.sha256(body.encode("utf-8")).hexdigest()[:16]
    stamp = _now_iso()
    head = (f"<!-- {TASK_MARKER}: issue={picked['number'] if picked else 'none'} "
            f"sha={sha} at={stamp} "
            f"mirror={(Path(picked['path']).name if picked else '-')} "
            f"url={(picked['link'] if picked else '-')} -->")
    content = f"{head}\n\n{body}"

    old = out.read_text(encoding="utf-8") if out.is_file() else ""
    # 幂等：首行标记里的 sha 一致就不重写 —— mtime 不变，守护脚本不会被自己的写入唤醒
    same = bool(old) and bool(old.splitlines()) and f"sha={sha}" in old.splitlines()[0]
    changed = not same
    result = {"written": False, "changed": False, "sha": sha, "path": str(out),
              "issue": ({k: picked[k] for k in ("number", "title", "mpn", "link",
                                                "counts", "total", "path")} if picked else None),
              "issues_open": len(issues), "verified": verified, "stale": stale,
              "content": content}
    if dry_run or not changed:
        return result

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(out.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(out)
    result.update(written=True, changed=True)
    return result


def _next_cli(argv: list[str]) -> int:
    """`python -m app.integrations.github_issues next` —— 生成 next_task.md。"""
    import argparse
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser(
        prog="github_issues next",
        description="挑最新一张 open 的 P0 质审单，生成给本地 Agent 接手的提示词")
    ap.add_argument("--issues", default=TASK_ISSUES_DIR, help=f"镜像目录（默认 {TASK_ISSUES_DIR}）")
    ap.add_argument("--out", default=NEXT_TASK_PATH, help=f"输出文件（默认 {NEXT_TASK_PATH}）")
    ap.add_argument("--number", type=int, default=None, help="指定工单编号（默认取最新）")
    ap.add_argument("--severity", default=TASK_SEVERITY, help="标签级别（默认 P0）")
    ap.add_argument("--no-verify", action="store_true",
                    help="不查 GitHub 复核状态（离网时用；镜像可能把已关闭的单显示成 OPEN）")
    ap.add_argument("--sync", action="store_true", help="先刷新本地镜像再挑")
    ap.add_argument("--dry-run", action="store_true", help="只打印，不落盘")
    ap.add_argument("--print", dest="show", action="store_true", help="把生成内容打到 stdout")
    ap.add_argument("--json", action="store_true", help="输出 JSON 结果")
    a = ap.parse_args(argv)

    if a.sync:
        try:
            res = sync_issues_to_local(out_dir=a.issues)
            print(f"[sync] 同步 {res.get('written', 0)} 张，删除 {res.get('removed', 0)} 张",
                  file=sys.stderr)
        except Exception as e:                            # noqa: BLE001
            print(f"[sync] 刷新失败（继续用现有镜像）：{e}", file=sys.stderr)

    res = build_next_task_prompt(issues_dir=a.issues, out_path=a.out, number=a.number,
                                 severity=a.severity, verify=not a.no_verify,
                                 dry_run=a.dry_run)
    if a.show:
        print(res["content"])
    if a.json:
        print(json.dumps({k: v for k, v in res.items() if k != "content"},
                         ensure_ascii=False, indent=2))
    elif not a.show:
        issue = res.get("issue")
        if issue:
            flag = "已更新" if res["changed"] else "无变化（未重写）"
            print(f"[next] GH-{issue['number']} {issue['mpn']} · P0 "
                  f"{issue['counts'].get('P0', 0)} 条 → {res['path']}（{flag}）")
        else:
            print(f"[next] 没有待修的 {a.severity} 单 → {res['path']}（{res['changed']}）")
        if res["stale"]:
            print(f"[next] 跳过 {res['stale']}：镜像显示 OPEN，线上已关闭", file=sys.stderr)
        if res["verified"] is None and not a.no_verify:
            print("[next] 未复核线上状态（无 token 或网络不可用）", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    """CLI。两种用法，按**首参数是不是 `sync`** 分派，不用 argparse 子命令。

    1. `python -m app.integrations.github_issues sync` —— 把 issue 拉回本地镜像；
    2. `python -m app.integrations.github_issues next` —— 生成 `algorithm_lab/next_task.md`；
    3. `python -m app.integrations.github_issues reply --id 14 --body "…"` —— 回帖汇报；
    4. `python -m app.integrations.github_issues close --id 14 23` —— 关单出队；
    5. `python -m app.integrations.github_issues x.json --push` —— 发单（旧用法）。

    为什么不用 subparsers：subparsers 会把第一个位置参数当子命令名，流水线里
    已经写死的「文件名在前的」调用会立刻变成「invalid choice」非法参数。
    一个 `if` 换来零破坏，比让调用方全部改参数便宜得多。
    """
    import argparse
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                   # noqa: BLE001
        pass
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] == "sync":
        return _sync_cli(args[1:])
    if args and args[0] == "next":
        return _next_cli(args[1:])
    if args and args[0] == "reply":
        return _reply_cli(args[1:])
    if args and args[0] == "close":
        return _close_cli(args[1:])
    ap = argparse.ArgumentParser(description="GitHub 质审工单（默认 dry-run）")

    ap.add_argument("issue_json", help="controller --emit-issue 产出的 JSON")
    ap.add_argument("--push", action="store_true", help="真的推到 GitHub（默认只打印）")
    a = ap.parse_args(argv)
    blob = json.loads(Path(a.issue_json).read_text(encoding="utf-8"))
    issue = blob.get("issue") or blob
    res = create_issue(issue, dry_run=not a.push)
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
