"""交付包上架后自动开一张 `[CMD]` 工单 —— 让质审流水线不必人工提 Issue。

**触发链**：`delivery_bundle.py` 出包 → 把包推进 `IcDeliveryReleases` →
本模块在新包**确实已在远端**时建一张 `[CMD]` 单，DSH 捕获后自动跑质审。

四条约束，每条都对应一次踩坑：

* **先验证再建单。** 只看本地有没有这个目录是不够的：建完单 DSH 去拉，会发现
  包根本不在远端。`git_state()` 走三关 —— `HEAD == origin/main`、包目录在提交树里、
  工作区没有未提交改动。
* **默认 dry-run。** 自动建单会污染仓库，于是 `notify()` 的默认值是 `dry_run=True`，
  CLI 要显式 `--push` 才真发。
* **一件一单。** 去重键 = 包名 + ZIP 的 SHA-256。重跑、补发、换机器都不会刷屏；
  包内容一变（重新打包）就是新键，会另开一单 —— 这是对的，那是另一个交付物。
* **包路径要写全。** 工单是给另一台机器上的 agent 看的，`data/_delivery_releases/x`
  这种相对路径在它那边不存在。正文同时给仓库内相对路径、绝对路径、ZIP 哈希。
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from app.integrations import github_issues as GH
from app.integrations.env import get as env_get

#: 建单规范按 AGENT.md §17：标题 `[CMD] 质审自动化 - <包名>`，
#: 标签 `qa-audit` + `auto-trigger`。`auto-trigger` 用来把「自动开出来的」
#: 和人工提的质审单区分开 —— 出问题时先怀疑触发链。
CMD_LABEL = "auto-trigger"
LABEL_BASE = ("qa-audit", CMD_LABEL)
DEDUP_MARKER = "cmd-issue-key"

#: §17 模板首行必须 @ 到的账号。**这不是客套话，是全链路唯一开关**：
#: DSH 的准入判据是 `body.includes('@' + login)`，而 login 就是 `esanwu-bot`；
#: 一旦写成别的账号（曾经的 `@agent-dsh`，GitHub 上 404），单子建出来也会被
#: 准入矩阵判成「名单内但没叫我」→ `listedUnaddressed` → 配的是 `ignore`，
#: 于是工单安安静静躺在那里，DSH 永远不会接。改这个常量前先读 AGENT.md §17。
MENTION = "@esanwu-bot"


class NotifyError(RuntimeError):
    """推送状态不成立（没推、没提交、工作区脏）。**不带病建单。**"""


# ---------------------------------------------------------------- git 取证
def _git(repo: Path, *args: str, check: bool = True) -> str:
    try:
        r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True,
                           text=True, timeout=60)
    except FileNotFoundError as e:                       # 没装 git
        raise NotifyError(f"找不到 git：{e}") from e
    except subprocess.TimeoutExpired as e:
        raise NotifyError(f"git {args[0]} 超时（{repo}）") from e
    if check and r.returncode != 0:
        raise NotifyError(f"git {' '.join(args)} 失败：{(r.stderr or r.stdout).strip()[:300]}")
    return (r.stdout or "").strip()


def git_state(repo: Path, *, remote: str = "origin", fetch: bool = True) -> dict:
    """返回 `{head, branch, remote_head, pushed, dirty, pkg_in_tree(由调用方填)}`。

    `fetch` 默认开：不 fetch 的 `origin/main` 可能是几天前的，那就等于没验证。
    """
    repo = Path(repo)
    if not (repo / ".git").exists():
        raise NotifyError(f"不是一个 git 仓库：{repo}")
    branch = _git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    head = _git(repo, "rev-parse", "HEAD")
    dirty = _git(repo, "status", "--porcelain")
    if fetch:
        _git(repo, "fetch", remote, "--quiet", check=False)
    remote_head = _git(repo, "rev-parse", f"{remote}/{branch}", check=False)
    return {
        "branch": branch, "head": head, "remote_head": remote_head,
        "pushed": bool(remote_head) and head == remote_head,
        "dirty": dirty.splitlines(),
    }


def _in_tree(repo: Path, rev: str, rel: str) -> bool:
    r = subprocess.run(["git", "-C", str(repo), "cat-file", "-e", f"{rev}:{rel}"],
                       capture_output=True, text=True)
    return r.returncode == 0


# ---------------------------------------------------------------- 包指纹
def pkg_fingerprint(pkg_dir: Path) -> dict:
    """包目录指纹：文件数/总字节/主 ZIP 的大小与 SHA-256。

    哈希只算**主 ZIP**（`*.zip`），不算目录里所有文件 —— 工单要回答的是
    「复核方手上那个压缩包是不是我出的这个」，逐文件哈希在 issue 里没人看。
    """
    pkg_dir = Path(pkg_dir)
    if not pkg_dir.is_dir():
        raise NotifyError(f"包目录不存在：{pkg_dir}")
    files = [p for p in pkg_dir.rglob("*") if p.is_file()]
    zips = sorted(pkg_dir.glob("*.zip"))
    main_zip = zips[0] if zips else None
    sha = ""
    if main_zip:
        h = hashlib.sha256()
        with open(main_zip, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        sha = h.hexdigest()
    return {
        "name": pkg_dir.name,
        "path": str(pkg_dir.resolve()),
        "files": len(files),
        "bytes": sum(p.stat().st_size for p in files),
        "zip": main_zip.name if main_zip else "",
        "zip_bytes": main_zip.stat().st_size if main_zip else 0,
        "zip_sha256": sha,
        "n_zips": len(zips),
    }


def dedup_key(fp: dict) -> str:
    raw = f"{fp['name']}|{fp.get('zip_sha256') or ''}".lower()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


# ---------------------------------------------------------------- 工单
def _mb(n: int) -> str:
    return f"{n / 1048576:.1f} MB" if n else "—"


def render_body(fp: dict, st: dict, *, rel_path: str, extra: str = "") -> str:
    # 前四行逐字对齐 AGENT.md §17 的模板。`@esanwu-bot` 不是寒暄 —— 它是 DSH 的
    # GitHub 账号，DSH 的 Source 只认「正文/评论里 @ 到自己的登录名」这种再触发信号
    # （`body.includes('@' + login)`）；写一个不存在的账号等于没喊人。
    # 模板写「路径：delivery-<包名>」而包名本身已带 `delivery-` 前缀，照抄会变成
    # `delivery-delivery-20261101-V9`，所以这里写实际路径。
    # git 字段全部走 .get：require_pushed=False 的离线演练拿不到 git 事实，
    # 拿不到就老实写「未校验」，不能把空值渲染成 ``（）`` 这种看不懂的东西。
    head = (st.get("head") or "")[:12]
    branch = st.get("branch") or ""
    commit_cell = f"`{head}`（{branch}）" if head else "—（未校验）"
    pushed_cell = ("是" if st.get("pushed") else "**否**") if head else "—（未校验）"
    lines = [
        f"{MENTION} 检测到新包发布。",
        f"包名：{fp['name']}",
        f"路径：{rel_path}",
        "请拉取最新代码，执行双 Qwen 质审（dry-run 和 --push）。",
        "",
        "## 交付包信息",
        "",
        "| 项 | 值 |",
        "|---|---|",
        f"| 包名 | `{fp['name']}` |",
        f"| 仓库内路径 | `{rel_path}` |",
        # 绝对路径只用于溯源，不能当操作路径：出包在 Windows 上，质审在 Linux 上，
        # `E:\...` 在对面根本不存在。写清「仅供溯源」比直接给一条死路径好。
        f"| 出包机路径 | `{fp['path']}`（仅供溯源，对方机器不可用） |",
        f"| 文件数 | {fp['files']} |",
        f"| 总大小 | {_mb(fp['bytes'])} |",
        f"| 主 ZIP | `{fp['zip'] or '—'}`（{_mb(fp['zip_bytes'])}） |",
        f"| ZIP SHA-256 | `{fp['zip_sha256'] or '—'}` |",
        f"| 提交 | {commit_cell} |",
        f"| 已推送 | {pushed_cell} |",
        "",
        "## 复现命令",
        "",
        "```bash",
        f"cd {rel_path}",
        "",
        "# 逐件：确定性审计 + qwen-long 原文校对 + qwen-max 逻辑审查",
        "python -m app.qa.controller \\",
        "  --mpn <MPN> \\",
        "  --json <parsed>/<MPN>.json --pdf <pdfs>/<MPN>.pdf \\",
        f"  --facts {rel_path}/facts_audit.json \\",
        "  --dry-run          # 先看请求体；确认后换 --push 建单",
        "```",
        "",
        "> `--facts` 传 `.csv` 或 `.json` 都行：JSON 会优先取同目录同名 CSV 拿 bbox/页码，",
        "> 没有同名 CSV 时退化为「汇总 + blocked 清单」并在工单里写明缺什么。",
        "",
    ]
    if extra:
        lines += [extra, ""]
    lines += [
        "---",
        f"<!-- {DEDUP_MARKER}: {dedup_key(fp)} -->",
        f"<!-- pkg: {fp['name']} -->",
        f"<!-- zip-sha256: {fp['zip_sha256']} -->",
        "由打包脚本自动生成（AGENT.md §17）；包的**发布状态**以包内《交付说明.md》"
        "与 manifest 为准，本单只表示「有新包需要质审」，不代表放行。",
    ]
    return "\n".join(lines)


def build_cmd_issue(fp: dict, st: dict, *, rel_path: str, extra: str = "") -> dict:
    body = render_body(fp, st, rel_path=rel_path, extra=extra)
    # 硬护栏：首行没有 @esanwu-bot 就等于没喊人，单子会被准入矩阵静默 ignore。
    # 宁可在这里抛，也不要建出一张「看起来成功了、其实永远没人接」的单。
    if not body.startswith(MENTION):
        raise NotifyError(f"工单首行必须以 {MENTION} 开头（当前：{body.splitlines()[0][:60]!r}）")
    return {
        "mpn": fp["name"],
        # §17 规定的标题格式
        "title": f"[CMD] 质审自动化 - {fp['name']}",
        "labels": list(LABEL_BASE),
        "dedup_key": dedup_key(fp),
        "body": body,
    }


# ---------------------------------------------------------------- 主入口
def notify(*, releases_dir: str | Path, pkg: str, remote: str = "origin",
           dry_run: bool = True, require_pushed: bool = True,
           repo: str | None = None, token: str | None = None,
           out_dir: str | Path | None = None, extra: str = "") -> dict:
    """验证推送状态 → 建 `[CMD]` 单（`dry_run=True` 时只返回请求体）。"""
    root = Path(releases_dir)
    pkg_dir = root / pkg
    fp = pkg_fingerprint(pkg_dir)
    try:
        st = git_state(root, remote=remote)
    except NotifyError:
        # 只有明确关掉校验（离线演练/预渲染邮件）时才容忍拿不到 git 事实；
        # 严格模式下仍要硬失败 —— 否则「不是 git 仓库」会被静默降级成能建单。
        if require_pushed:
            raise
        st = {"branch": "", "head": "", "remote_head": "", "pushed": False, "dirty": []}
    rel = f"{pkg_dir.relative_to(root).as_posix()}"

    if require_pushed:
        if not st["pushed"]:
            raise NotifyError(
                f"包尚未推送：本地 HEAD {st['head'][:12]} 与 {remote}/{st['branch']} "
                f"{st['remote_head'][:12] or '(无)'} 不一致。先 `git -C {root} push {remote} "
                f"{st['branch']}` 再跑本步 —— 提前建单会让 DSH 去拉一个还不存在的包。")
        if not _in_tree(root, st["head"], rel):
            raise NotifyError(f"包目录不在提交树里：{st['head'][:12]}:{rel}（忘了 git add？）")
        if st["dirty"]:
            raise NotifyError(f"仓库有未提交改动（{len(st['dirty'])} 项），"
                              f"提交并推送后再建单：{st['dirty'][:3]}")

    repo0 = repo or env_get("GITHUB_RELEASE_REPO", "") or GH.DEFAULT_ISSUES_REPO
    token0 = token or env_get("GITHUB_RELEASE_TOKEN", "")
    issue = build_cmd_issue(fp, st, rel_path=rel, extra=extra)
    # dedup_label 传空：查重只认正文 marker。标签可能被服务端静默丢弃（§17 事故），
    # 按标签查重等于把去重能力绑在一个没有写权限的字段上。
    res = GH.create_issue(issue, dry_run=dry_run, repo=repo0, token=token0,
                          out_dir=out_dir, dedup_marker=DEDUP_MARKER)
    res["pkg"] = fp
    res["git"] = st
    return res


def main(argv: list[str] | None = None) -> int:
    """CLI：`python -m app.integrations.release_notify --pkg <包名>`（默认 dry-run）。"""
    import argparse
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser(
        description="新交付包推送后自动建 [CMD] 工单（默认 dry-run）")
    ap.add_argument("--pkg", required=True, help="包目录名，如 delivery-20261103-V1")
    ap.add_argument("--releases", default="data/_delivery_releases",
                    help="发布仓库的本地克隆（默认 data/_delivery_releases）")
    ap.add_argument("--remote", default="origin")
    ap.add_argument("--extra", default="", help="附加说明（Markdown），插在正文末尾")
    ap.add_argument("--out", default="", help="把请求体落盘到该目录")
    ap.add_argument("--dry-run", action="store_true",
                    help="只打印请求体（**默认行为**，写出来只为明确）")
    ap.add_argument("--push", action="store_true", help="真的建单")
    ap.add_argument("--no-verify-push", action="store_true",
                    help="跳过「已推送」校验（**不要用**：会让 DSH 拉到不存在的包）")
    a = ap.parse_args(argv)
    if a.dry_run and a.push:
        ap.error("--dry-run 与 --push 不能同时给")
    try:
        res = notify(releases_dir=a.releases, pkg=a.pkg, remote=a.remote,
                     dry_run=not a.push, require_pushed=not a.no_verify_push,
                     out_dir=a.out or None, extra=a.extra)
    except NotifyError as e:
        print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({k: v for k, v in res.items() if k != "issue"} | {
        "title": res["issue"]["title"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
