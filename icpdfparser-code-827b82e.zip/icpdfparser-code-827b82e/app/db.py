"""工作台 SQLite 库：连接管理 + DDL + 常用读写。

设计要点
--------
1. `item` 以归一化料号 `mpn_key` 做唯一键 —— 这就是「已解析型号去重」的落点，
   同一型号无论被上传多少次，都只保留一行，解析次数与最近解析时间累加。
2. `item_batch` 是 item 与 batch 的多对多：型号首次出现的批次记在 item.batch_id，
   后续批次通过关系表关联，批次导出才不会漏型号。
3. `doc_source` 记录每个型号在各平台尝试过的每一条链接（含失败原因），
   (mpn_key, url) 唯一，重复采集不会膨胀。
4. SQLite 连接不能跨线程，这里按线程各持一个连接。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime
from typing import Any, Iterable

from . import config

_local = threading.local()
_init_lock = threading.Lock()
_initialised = False

DDL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

-- 上传批次：parts=型号表 / catalog=站内商品目录 / images=应用领域图片命名表
CREATE TABLE IF NOT EXISTS batch (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT NOT NULL,
    filename     TEXT NOT NULL DEFAULT '',
    stored_path  TEXT NOT NULL DEFAULT '',
    sha256       TEXT NOT NULL DEFAULT '',
    total_rows   INTEGER NOT NULL DEFAULT 0,
    unique_mpns  INTEGER NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'pending',  -- pending|running|ready|failed
    progress     INTEGER NOT NULL DEFAULT 0,
    note         TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL
);

-- 型号任务（去重主体）
CREATE TABLE IF NOT EXISTS item (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id       INTEGER,
    mpn            TEXT NOT NULL,
    mpn_key        TEXT NOT NULL UNIQUE,
    brand          TEXT NOT NULL DEFAULT '',
    status         TEXT NOT NULL DEFAULT 'pending',
        -- pending|queued|resolving|downloading|parsing|rendering|done|failed|skipped|nodata
    stage          TEXT NOT NULL DEFAULT '',
    progress       INTEGER NOT NULL DEFAULT 0,
    provider       TEXT NOT NULL DEFAULT '',   -- 命中的采集来源
    pdf_url        TEXT NOT NULL DEFAULT '',
    pdf_path       TEXT NOT NULL DEFAULT '',
    pdf_sha256     TEXT NOT NULL DEFAULT '',
    pdf_bytes      INTEGER NOT NULL DEFAULT 0,
    json_path      TEXT NOT NULL DEFAULT '',
    txt_path       TEXT NOT NULL DEFAULT '',
    alt_json_path  TEXT NOT NULL DEFAULT '',
    alt_html_path  TEXT NOT NULL DEFAULT '',
    symbol_path    TEXT NOT NULL DEFAULT '',
    seo_path       TEXT NOT NULL DEFAULT '',
    parse_ms       INTEGER NOT NULL DEFAULT 0,
    parse_count    INTEGER NOT NULL DEFAULT 0,
    last_parsed_at TEXT NOT NULL DEFAULT '',
    error          TEXT NOT NULL DEFAULT '',
    meta           TEXT NOT NULL DEFAULT '{}',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_item_status ON item(status);
CREATE INDEX IF NOT EXISTS idx_item_batch  ON item(batch_id);
CREATE INDEX IF NOT EXISTS idx_item_parsed ON item(last_parsed_at);

CREATE TABLE IF NOT EXISTS item_batch (
    item_id  INTEGER NOT NULL,
    batch_id INTEGER NOT NULL,
    PRIMARY KEY (item_id, batch_id)
);

-- 各平台采集记录：一个型号可能试过多条链接
CREATE TABLE IF NOT EXISTS doc_source (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    mpn_key    TEXT NOT NULL,
    provider   TEXT NOT NULL,
    stage      TEXT NOT NULL DEFAULT '',
    url        TEXT NOT NULL,
    ok         INTEGER NOT NULL DEFAULT 0,
    http_status INTEGER NOT NULL DEFAULT 0,
    bytes      INTEGER NOT NULL DEFAULT 0,
    sha256     TEXT NOT NULL DEFAULT '',
    error      TEXT NOT NULL DEFAULT '',
    tried_at   TEXT NOT NULL,
    UNIQUE(mpn_key, url)
);
CREATE INDEX IF NOT EXISTS idx_source_mpn ON doc_source(mpn_key);

-- 事件时间线
CREATE TABLE IF NOT EXISTS event (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id    INTEGER,
    batch_id   INTEGER,
    kind       TEXT NOT NULL DEFAULT 'info',
    message    TEXT NOT NULL DEFAULT '',
    detail     TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_event_created ON event(created_at);

-- 模型调用记账：一条 = 一次 chat/completions 调用（含修复重试）
-- 没有这张表，谈成本、谈哪家网关快，都是猜。
CREATE TABLE IF NOT EXISTS llm_usage (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id           INTEGER,
    mpn_key           TEXT NOT NULL DEFAULT '',
    stage             TEXT NOT NULL DEFAULT 'parse',  -- parse | alternatives | repair
    provider          TEXT NOT NULL DEFAULT '',       -- 网关 host
    model             TEXT NOT NULL DEFAULT '',
    prompt_tokens     INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens      INTEGER NOT NULL DEFAULT 0,
    latency_ms        INTEGER NOT NULL DEFAULT 0,
    attempt           INTEGER NOT NULL DEFAULT 1,
    ok                INTEGER NOT NULL DEFAULT 1,
    error             TEXT NOT NULL DEFAULT '',
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_usage_created ON llm_usage(created_at);
CREATE INDEX IF NOT EXISTS idx_usage_model   ON llm_usage(model);
CREATE INDEX IF NOT EXISTS idx_usage_item    ON llm_usage(item_id);

-- 应用领域图片命名表（图片 SEO 的唯一事实来源，随上传覆盖）
CREATE TABLE IF NOT EXISTS app_image (
    category   TEXT PRIMARY KEY,
    image      TEXT NOT NULL,
    alt_en     TEXT NOT NULL DEFAULT '',
    alt_zh     TEXT NOT NULL DEFAULT '',
    title_en   TEXT NOT NULL DEFAULT '',
    keywords   TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);

-- 键值配置（记录最近一次导入的文档指纹等）
CREATE TABLE IF NOT EXISTS kv (
    k          TEXT PRIMARY KEY,
    v          TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);

-- ================= 质量审计 QC =================
-- 一次 QC 执行（回归 / 抽样 / 单件 / 批量选中），qc_run 允许 UPDATE 汇总；
-- qc_finding / qc_audit_log 是 append-only 台账，代码路径禁止 UPDATE/DELETE。
CREATE TABLE IF NOT EXISTS qc_run (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    mode        TEXT NOT NULL DEFAULT 'single',   -- regression|sample|single|selected
    scope       TEXT NOT NULL DEFAULT 'facts',    -- facts,render,claims 逗号分隔
    dry         INTEGER NOT NULL DEFAULT 1,       -- 1=dry 不写盘；0=write 补丁
    parts       INTEGER NOT NULL DEFAULT 0,       -- 本次应处理件数
    parts_done  INTEGER NOT NULL DEFAULT 0,      -- 已完成件数（并发原子累加）
    findings    INTEGER NOT NULL DEFAULT 0,
    patched     INTEGER NOT NULL DEFAULT 0,
    unresolved  INTEGER NOT NULL DEFAULT 0,
    duration_s  REAL NOT NULL DEFAULT 0,
    status      TEXT NOT NULL DEFAULT 'running',  -- running|ok|fail|missing
    operator    TEXT NOT NULL DEFAULT 'auto',
    report_path TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_qcrun_created ON qc_run(created_at);

CREATE TABLE IF NOT EXISTS qc_finding (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     INTEGER NOT NULL,
    mpn        TEXT NOT NULL DEFAULT '',
    kind       TEXT NOT NULL DEFAULT '',
    path       TEXT NOT NULL DEFAULT '',
    json_val   TEXT NOT NULL DEFAULT '',
    table_val  TEXT NOT NULL DEFAULT '',
    action     TEXT NOT NULL DEFAULT '',          -- patched|badge|unresolved|debt(render)|pass|fail
    tool       TEXT NOT NULL DEFAULT '',          -- table_audit|lint|qc_regression
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_qcfind_run  ON qc_finding(run_id);
CREATE INDEX IF NOT EXISTS idx_qcfind_mpn  ON qc_finding(mpn);

CREATE TABLE IF NOT EXISTS qc_audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     INTEGER NOT NULL,
    mpn        TEXT NOT NULL DEFAULT '',
    kind       TEXT NOT NULL DEFAULT '',
    path       TEXT NOT NULL DEFAULT '',
    json_val   TEXT NOT NULL DEFAULT '',
    table_val  TEXT NOT NULL DEFAULT '',
    action     TEXT NOT NULL DEFAULT '',
    tool       TEXT NOT NULL DEFAULT '',
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);  -- 只 INSERT，永不 UPDATE/DELETE
CREATE INDEX IF NOT EXISTS idx_qcaudit_run  ON qc_audit_log(run_id);
CREATE INDEX IF NOT EXISTS idx_qcaudit_mpn  ON qc_audit_log(mpn);
CREATE INDEX IF NOT EXISTS idx_qcaudit_kind ON qc_audit_log(kind);

-- ================= 质量工程 QE =================
-- Gold Set 基准集：人工标准答案，独立于生产解析结果，机器修复不得直接改动；
-- gold_review_log 为 append-only 人工审核台账（只 INSERT）。
CREATE TABLE IF NOT EXISTS gold_set (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    version     TEXT NOT NULL DEFAULT 'v1',    -- 所属基准集版本（冻结单元）
    mpn         TEXT NOT NULL,
    manufacturer TEXT NOT NULL DEFAULT '',
    pdf_name    TEXT NOT NULL DEFAULT '',
    pdf_sha256  TEXT NOT NULL DEFAULT '',      -- 原厂 PDF 哈希（登记时计算）
    doc_rev     TEXT NOT NULL DEFAULT '',      -- 原厂文档版本（Rev. C 之类）
    status      TEXT NOT NULL DEFAULT 'draft',-- draft|review|frozen
    risk_tags   TEXT NOT NULL DEFAULT '',      -- 逗号分隔风险标签
    note        TEXT NOT NULL DEFAULT '',
    created_by  TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    UNIQUE(version, mpn)
);
CREATE INDEX IF NOT EXISTS idx_goldset_mpn ON gold_set(mpn);

CREATE TABLE IF NOT EXISTS gold_field (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    gold_id     INTEGER NOT NULL,              -- → gold_set.id
    field_path  TEXT NOT NULL,                 -- electrical[3].value / specs.package.type ...
    field_name  TEXT NOT NULL DEFAULT '',      -- 参数名（VOH / package.type）
    expected    TEXT NOT NULL DEFAULT '',      -- 标准值（人工录入/核验后冻结）
    unit        TEXT NOT NULL DEFAULT '',
    cond        TEXT NOT NULL DEFAULT '',      -- 测试条件（须保留原文）
    page_no     INTEGER NOT NULL DEFAULT 0,    -- 证据页码
    evidence    TEXT NOT NULL DEFAULT '',      -- 证据定位（表名/行/列/章节）
    status      TEXT NOT NULL DEFAULT 'pending', -- pending|verified|conflict
    verified_by TEXT NOT NULL DEFAULT '',
    verified_at TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_goldfield_gold ON gold_field(gold_id);

CREATE TABLE IF NOT EXISTS gold_review_log (   -- append-only
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    gold_id    INTEGER NOT NULL,
    field_id   INTEGER NOT NULL DEFAULT 0,     -- 0 = 器件级操作
    action     TEXT NOT NULL,                  -- seed|field_add|verify|conflict|freeze|unfreeze|note|import
    detail     TEXT NOT NULL DEFAULT '',
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_goldreview_gold ON gold_review_log(gold_id);

-- 风险审计队列：评分用于排队，不替代字段级硬阻断；与 qc_finding 共享 finding_id 不复制数据
CREATE TABLE IF NOT EXISTS risk_case (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    mpn        TEXT NOT NULL,
    kind       TEXT NOT NULL DEFAULT '',
    finding_id INTEGER NOT NULL DEFAULT 0,     -- → qc_finding.id
    priority   TEXT NOT NULL DEFAULT 'P2',     -- P0|P1|P2
    reason     TEXT NOT NULL DEFAULT '',
    score      REAL NOT NULL DEFAULT 0,
    status     TEXT NOT NULL DEFAULT 'open',   -- open|confirming|to_regression|closed|rejected
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_riskcase_mpn ON risk_case(mpn);

-- 随机审计（盲审抽样，测 QC 漏报）：种子与总体快照留档，可复现
CREATE TABLE IF NOT EXISTS sample_batch (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL,                  -- RA-2026-001
    population TEXT NOT NULL DEFAULT '',       -- 抽样总体描述
    method     TEXT NOT NULL DEFAULT 'random', -- random|stratified_vendor
    n          INTEGER NOT NULL DEFAULT 0,
    seed       TEXT NOT NULL DEFAULT '',
    snapshot   TEXT NOT NULL DEFAULT '',       -- 总体快照 JSON（mpn 列表）
    done       INTEGER NOT NULL DEFAULT 0,
    defects    INTEGER NOT NULL DEFAULT 0,
    status     TEXT NOT NULL DEFAULT 'open',   -- open|done
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sample_item (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id   INTEGER NOT NULL,
    mpn        TEXT NOT NULL,
    result     TEXT NOT NULL DEFAULT 'pending',-- pending|pass|miss
    note       TEXT NOT NULL DEFAULT '',
    operator   TEXT NOT NULL DEFAULT '',
    reviewed_at TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sampleitem_batch ON sample_item(batch_id);

-- 反馈闭环：人工确认的缺陷 → 回归用例 → 修复后重跑防回归
CREATE TABLE IF NOT EXISTS feedback_case (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL,                  -- QC-REG-001
    source     TEXT NOT NULL DEFAULT 'manual', -- manual|risk|random_audit|customer
    mpn        TEXT NOT NULL,
    kind       TEXT NOT NULL DEFAULT '',
    gold_evidence TEXT NOT NULL DEFAULT '',    -- 已关联原厂证据 / 等待二次复核
    status     TEXT NOT NULL DEFAULT 'pending',-- pending|fixture|fail|passed|closed
    fixture    TEXT NOT NULL DEFAULT '',       -- 导出的回归夹具记录
    note       TEXT NOT NULL DEFAULT '',
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- ==================== Agent Lab 任务与审计 ====================
CREATE TABLE IF NOT EXISTS agent_task (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id      TEXT NOT NULL UNIQUE,         -- 外部引用 ID（UUID）
    user_id      TEXT NOT NULL DEFAULT 'agent',
    intent       TEXT NOT NULL DEFAULT '',     -- QC_DIAGNOSE/QC_ANALYZE/EVIDENCE_LOOKUP/REPAIR_DRY_RUN/...
    status       TEXT NOT NULL DEFAULT 'CREATED', -- CREATED|INTENT_PARSED|PLANNED|RUNNING|WAITING_APPROVAL|VERIFYING|COMPLETED|FAILED|CANCELLED
    budget       TEXT NOT NULL DEFAULT '{}',   -- JSON: max_steps/max_llm_calls/tool_timeout/max_retries/max_cost
    context      TEXT NOT NULL DEFAULT '{}',   -- JSON: batch_id/device_ids/finding_ids/severity/...
    result       TEXT NOT NULL DEFAULT '{}',   -- JSON: 最终结果摘要
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_task_status ON agent_task(status);
CREATE INDEX IF NOT EXISTS idx_agent_task_intent ON agent_task(intent);

CREATE TABLE IF NOT EXISTS agent_step (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id      TEXT NOT NULL,
    step_no      INTEGER NOT NULL,
    tool_name    TEXT NOT NULL,
    arguments    TEXT NOT NULL DEFAULT '{}',   -- JSON
    result       TEXT NOT NULL DEFAULT '{}',   -- JSON
    status       TEXT NOT NULL DEFAULT 'PENDING', -- PENDING|RUNNING|COMPLETED|FAILED|SKIPPED
    started_at   TEXT NOT NULL DEFAULT '',
    finished_at  TEXT NOT NULL DEFAULT '',
    error        TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_agent_step_task ON agent_step(task_id);

CREATE TABLE IF NOT EXISTS agent_tool_event (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_call_id    TEXT NOT NULL UNIQUE,      -- UUID
    task_id         TEXT NOT NULL,
    step_no         INTEGER NOT NULL,
    tool_name       TEXT NOT NULL,
    input_summary   TEXT NOT NULL DEFAULT '{}', -- JSON: 输入参数摘要
    output_summary  TEXT NOT NULL DEFAULT '{}', -- JSON: 输出结果摘要
    duration_ms     INTEGER NOT NULL DEFAULT 0,
    error           TEXT NOT NULL DEFAULT '',
    idempotency_key TEXT NOT NULL DEFAULT '',  -- 幂等键，防重复执行
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_tool_event_task ON agent_tool_event(task_id);
CREATE INDEX IF NOT EXISTS idx_agent_tool_event_idempotency ON agent_tool_event(idempotency_key);

CREATE TABLE IF NOT EXISTS agent_approval (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id      TEXT NOT NULL,
    operation    TEXT NOT NULL DEFAULT '',     -- commit_patch/recheck_finding/...
    approver     TEXT NOT NULL DEFAULT '',     -- 审批人
    decision     TEXT NOT NULL DEFAULT '',     -- approved|rejected|pending
    reason       TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_approval_task ON agent_approval(task_id);

CREATE TABLE IF NOT EXISTS agent_repair_patch (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id      TEXT NOT NULL,
    task_id         TEXT NOT NULL,
    before_hash     TEXT NOT NULL DEFAULT '',
    patch           TEXT NOT NULL DEFAULT '{}', -- JSON: 补丁内容
    after_hash      TEXT NOT NULL DEFAULT '',
    validation_status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING|PASSED|FAILED
    applied         INTEGER NOT NULL DEFAULT 0, -- 0|1
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_repair_patch_finding ON agent_repair_patch(finding_id);
"""

# 原厂证据登记（source_document / source_evidence / source_field_evidence /
# source_verification_log）：DDL 放在 qc/source_evidence.py 单一来源，离线单测可直接复用。
from qc.source_evidence import SOURCE_DDL as _SOURCE_DDL   # noqa: E402
from .services.feedback import DDL as _FEEDBACK_DDL        # noqa: E402
from .services.qc_analyzer import DDL as _ANALYZER_DDL     # noqa: E402
from .services.i18n_qa import DDL as _I18N_DDL             # noqa: E402

DDL += _SOURCE_DDL
DDL += _FEEDBACK_DDL
DDL += _ANALYZER_DDL
DDL += _I18N_DDL

# 已有环境增量迁移：CREATE TABLE IF NOT EXISTS 不会给旧表补列。
_FEEDBACK_MIGRATIONS = (
    "ALTER TABLE customer_feedback_issue ADD COLUMN root_cause_hypothesis "
    "TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE customer_feedback_issue ADD COLUMN required_evidence "
    "TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE customer_feedback_issue ADD COLUMN acceptance_criteria "
    "TEXT NOT NULL DEFAULT ''",
)


def _migrate_feedback(c: sqlite3.Connection) -> None:
    for sql in _FEEDBACK_MIGRATIONS:
        try:
            c.execute(sql)
        except sqlite3.OperationalError as e:
            if "duplicate column name" not in str(e).lower():
                raise


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def qc_now() -> str:
    """QC 台账时间戳：SQLite julianday() 可解析的本地格式。

    now() 的 ISO 格式带 +08:00 时区后缀，julianday() 解析不了，
    duration_s 会被算错约 8 小时。
    """
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def conn() -> sqlite3.Connection:
    """当前线程的连接（WAL + Row 工厂）。"""
    global _initialised
    c = getattr(_local, "c", None)
    if c is None:
        config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(config.DB_PATH, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        # 每个线程连接都要设：synchronous 是连接级参数，不能只靠建库时那一次 DDL。
        # fetch 阶段几千条 doc_source 全是单条 commit，FULL 会在 Windows 上把写锁拖长。
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA busy_timeout=5000")
        _local.c = c
    if not _initialised:
        with _init_lock:
            if not _initialised:
                c.executescript(DDL)
                _migrate_feedback(c)
                c.commit()
                _initialised = True
    return c


def q(sql: str, args: Iterable[Any] = ()) -> list[dict]:
    return [dict(r) for r in conn().execute(sql, tuple(args)).fetchall()]


def q1(sql: str, args: Iterable[Any] = ()) -> dict | None:
    r = conn().execute(sql, tuple(args)).fetchone()
    return dict(r) if r else None


_WRITE_RETRIES = 4


def _is_busy(e: sqlite3.OperationalError) -> bool:
    msg = str(e).lower()
    return "locked" in msg or "busy" in msg


def _sleep_before_retry(attempt: int) -> None:
    time.sleep(min(0.1 * (2 ** attempt), 0.8))


def x(sql: str, args: Iterable[Any] = ()) -> int:
    """写一条。WAL 的写锁是全库的，fetch 每秒几十条写入，撞锁不能直接抛给 worker。"""
    c = conn()
    for attempt in range(_WRITE_RETRIES):
        try:
            cur = c.execute(sql, tuple(args))
            c.commit()
            return cur.lastrowid if cur.lastrowid else cur.rowcount
        except sqlite3.OperationalError as e:
            if not _is_busy(e) or attempt == _WRITE_RETRIES - 1:
                raise
            try:
                c.rollback()
            except sqlite3.Error:
                pass
            _sleep_before_retry(attempt)
    raise RuntimeError("unreachable")


def x_count(sql: str, args: Iterable[Any] = ()) -> int:
    """执行写语句并返回**受影响行数**（条件更新的判据）。

    `x()` 为了兼容 INSERT 会优先返回 `lastrowid`，用它判断一条
    `UPDATE ... WHERE status=?` 到底改到几行是不可靠的。去重、并发领取
    这些"谁改到了这一行，谁才继续干"的地方必须看 rowcount。
    """
    c = conn()
    for attempt in range(_WRITE_RETRIES):
        try:
            cur = c.execute(sql, tuple(args))
            c.commit()
            return cur.rowcount
        except sqlite3.OperationalError as e:
            if not _is_busy(e) or attempt == _WRITE_RETRIES - 1:
                raise
            try:
                c.rollback()
            except sqlite3.Error:
                pass
            _sleep_before_retry(attempt)
    raise RuntimeError("unreachable")


def xmany(sql: str, rows: list[tuple]) -> int:
    c = conn()
    for attempt in range(_WRITE_RETRIES):
        try:
            cur = c.executemany(sql, rows)
            c.commit()
            return cur.rowcount
        except sqlite3.OperationalError as e:
            if not _is_busy(e) or attempt == _WRITE_RETRIES - 1:
                raise
            try:
                c.rollback()
            except sqlite3.Error:
                pass
            _sleep_before_retry(attempt)
    raise RuntimeError("unreachable")


# ---------------------------------------------------------------- 便捷写入
def add_event(message: str, *, kind: str = "info", item_id: int | None = None,
              batch_id: int | None = None, detail: str = "") -> None:
    x("INSERT INTO event (item_id,batch_id,kind,message,detail,created_at) VALUES (?,?,?,?,?,?)",
      (item_id, batch_id, kind, message[:500], detail[:4000], now()))


def kv_get(k: str, default: str = "") -> str:
    r = q1("SELECT v FROM kv WHERE k=?", (k,))
    return r["v"] if r else default


def kv_set(k: str, v: str) -> None:
    x("INSERT INTO kv (k,v,updated_at) VALUES (?,?,?) "
      "ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at",
      (k, v, now()))


def kv_json(k: str, default: Any = None) -> Any:
    raw = kv_get(k, "")
    if not raw:
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return default


# ---------------------------------------------------------------- item 状态机
STATUS_TEXT = {
    "pending": "待处理",
    "queued": "已入队",
    "resolving": "采集链接",
    "downloading": "下载 PDF",
    "parsing": "LLM 解析",
    "rendering": "生成物料",
    "done": "已完成",
    "failed": "失败",
    "skipped": "跳过（已有解析）",
    "nodata": "未找到 Datasheet",
}


def set_item(item_id: int, **fields: Any) -> None:
    """局部更新 item，自动刷新 updated_at。"""
    if not fields:
        return
    fields["updated_at"] = now()
    cols = ", ".join(f"{k}=?" for k in fields)
    x(f"UPDATE item SET {cols} WHERE id=?", (*fields.values(), item_id))


def touch_status(item_id: int, status: str, stage: str = "", progress: int | None = None,
                 error: str | None = None) -> None:
    fields: dict[str, Any] = {"status": status}
    if stage:
        fields["stage"] = stage
    if progress is not None:
        fields["progress"] = max(0, min(100, progress))
    if error is not None:
        fields["error"] = error[:2000]
    set_item(item_id, **fields)
