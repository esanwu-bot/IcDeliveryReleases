"""工作台全局配置：路径、Redis、并发、产物目录。

所有路径都基于仓库根目录推导，不依赖启动时的工作目录，
以便 uvicorn / celery 从任意目录拉起。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:                     # 保证能 import 根目录的老脚本
    sys.path.insert(0, str(ROOT))


def _load_env() -> None:
    """读 .env.local / .env（不覆盖已有环境变量）。

    解析侧的 parse_datasheets.py 会自己读一遍，但配置项（并发、Redis 地址）
    在这里就要用，所以必须更早读。
    """
    for name in (".env.local", ".env"):
        p = ROOT / name
        if not p.exists():
            continue
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

DATA = ROOT / "data"
PDFS = DATA / "pdfs"
PARSED = DATA / "parsed"
TXT = DATA / "txt"
ALTS = DATA / "alts"
SYMBOLS = DATA / "symbols"
PKGS = DATA / "pkgs"
SEO = DATA / "seo"
EXPORTS = DATA / "exports"
UPLOADS = ROOT / "uploads"
IMG_DIR = DATA / "img"                            # 应用领域配图（可选，缺图自动生成占位图）
TEMPLATES = DATA / "templates"                    # 型号表模板等可下载文件
STATIC = ROOT / "app" / "static"

DB_PATH = Path(os.getenv("ICPDF_WORKBENCH_DB", DATA / "workbench.sqlite3"))
CATALOG_DB = DATA / "products.sqlite3"            # 内链索引（站内目录）
APP_IMG_CSV = DATA / "app_images.csv"             # json_to_txt 读取的图片命名表

# ---------------------------------------------------------------- Redis / Celery
REDIS_URL = os.getenv("ICPDF_REDIS", "redis://127.0.0.1:6379/0")
CELERY_QUEUE = os.getenv("ICPDF_QUEUE", "icpdf")               # llm 解析队列（贵槽位）
FETCH_QUEUE = os.getenv("ICPDF_FETCH_QUEUE", "icpdf_fetch")    # 下载队列（纯网络 IO，高并发）
RENDER_QUEUE = os.getenv("ICPDF_RENDER_QUEUE", "icpdf_render") # 渲染队列（本地产物）
# Phase 1.6 五段链路新增的两个队列。**独立队列是这条链路的成立条件**：
# preprocess 是 PyMuPDF 抽文本（吃 CPU、不吃网络），audit 是裁表核对（同样吃 CPU），
# 塞进 llm 队列就会占住贵槽位等 CPU，塞进 render 队列又会让渲染排在审计后面。
PREPROCESS_QUEUE = os.getenv("ICPDF_PREPROCESS_QUEUE", "icpdf_preprocess")
AUDIT_QUEUE = os.getenv("ICPDF_AUDIT_QUEUE", "icpdf_audit")
# 任务 -> 队列路由：下载/解析/渲染三段独立并发，互不占用槽位（L1 槽位分离）
# QC 审计走 render 队列（本地 PyMuPDF CPU 任务）：保证 fetch/llm 队列零新增
# 自动修复：review 要调模型走 llm 队列；dispatch/apply/finalize 是本地 IO 走 render
# 五段链路（V2）只多两个 kind：切片走 preprocess，复核走 audit；
# llm/render 复用既有队列，避免灰度期凭空多出两拨并发。v2 的任务名带 _v2 后缀，
# 与旧任务**分名不分队列**，这样旧 worker 不会误接新消息（见 worker/tasks.py）。
TASK_QUEUE = {"fetch_item": FETCH_QUEUE, "llm_item": CELERY_QUEUE, "render_item": RENDER_QUEUE,
             "qc_audit_item": RENDER_QUEUE, "qc_regression_tick": RENDER_QUEUE,
             "review_item": CELERY_QUEUE, "fix_dispatch": RENDER_QUEUE,
             "fix_apply": RENDER_QUEUE, "fix_finalize": RENDER_QUEUE,
             "preprocess_item": PREPROCESS_QUEUE,
             "llm_item_v2": CELERY_QUEUE, "audit_item_v2": AUDIT_QUEUE,
             "render_item_v2": RENDER_QUEUE}

# ---------------------------------------------------------------- 灰度开关
# 五段链路（fetch -> preprocess -> llm -> audit -> render）的总闸。**默认关闭**。
# 关闭时全站走原来的单链 fetch_item -> llm_item -> render_item，代码路径与开启前
# 逐字节相同；打开只改一件事：fetch 成功后接力到 preprocess_item 而不是 llm_item。
# 为什么必须是 env 开关而不是常量：回滚要能在不重新构建镜像的前提下完成。
PIPELINE_V2 = os.getenv("ICPDF_PIPELINE_V2", "0") == "1"
# Redis 不可用时是否退回进程内线程池执行（工作台仍可用，只是不能横向扩 worker）
ALLOW_INLINE_FALLBACK = os.getenv("ICPDF_INLINE_FALLBACK", "1") != "0"
# QC 回归 beat 开关（每日 03:30 跑 qc_regression 11 件夹具）
QC_BEAT = os.getenv("ICPDF_QC_BEAT", "0") == "1"

# ---------------------------------------------------------------- 自动修复
# 同一型号最多自动修几轮；到顶仍有 finding 就转 customer_feedback 交人工。
# 轮次上限是防「修→审→修」无限循环的最后一道闸，不要为了省事调大。
FIX_MAX_ROUNDS = int(os.getenv("ICPDF_FIX_MAX_ROUNDS", "2"))
# 超轮次是否自动建 customer_feedback_issue（关掉就只写审计，不建单）
FIX_AUTO_PROMOTE = os.getenv("ICPDF_FIX_AUTO_PROMOTE", "1") == "1"
# 单型号单轮最多执行多少个 action（防一批 P2 把队列打满）
FIX_MAX_ACTIONS = int(os.getenv("ICPDF_FIX_MAX_ACTIONS", "12"))

# ---------------------------------------------------------------- 运行参数
LLM_WORKERS = int(os.getenv("ICPDF_WORKERS", "2"))     # llm 队列并发（建议等于 celery worker -c）
FETCH_WORKERS = int(os.getenv("ICPDF_FETCH_WORKERS", "32"))   # fetch 队列并发（下载纯等网络）
RENDER_WORKERS = int(os.getenv("ICPDF_RENDER_WORKERS", "8"))  # render 队列并发（本地渲染）
FETCH_TIMEOUT = int(os.getenv("ICPDF_FETCH_TIMEOUT", "60"))
AGGREGATOR_ENABLED = os.getenv("ICPDF_AGGREGATOR", "0") == "1"   # 聚合站默认关闭（易 403）
# 电气参数少于 3 条时是否仍接受解析结果（默认关闭）。
# 连接器/晶振/无源件本来就没几条电气参数，卡在阈值上会白白丢文档；
# 打开后仍需「引脚表或特性列表成规模 + 模型置信度达标」才放行。
ACCEPT_THIN = os.getenv("ICPDF_ACCEPT_THIN", "0") == "1"
MAX_ITEMS_PER_UPLOAD = int(os.getenv("ICPDF_MAX_UPLOAD", "20000"))
PREVIEW_MAX_BYTES = 2 * 1024 * 1024

for _d in (PDFS, PARSED, TXT, ALTS, SYMBOLS, PKGS, SEO, EXPORTS, UPLOADS, IMG_DIR, TEMPLATES, DATA):
    _d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------- 路径归一化
# item 表里的产物路径是「落库那台机器」的绝对路径；换机部署（Windows -> Linux 容器）
# 后原路径必然失效。读取时统一走 resolve_artifact：原路径不存在就回退
# <对应目录>/<文件名>，跨机迁移免疫。文件名由 mpn_key/sha 派生，目录内唯一。
ARTIFACT_DIRS = {
    "pdf_path": PDFS, "json_path": PARSED, "txt_path": TXT,
    "alt_json_path": ALTS, "alt_html_path": ALTS, "symbol_path": SYMBOLS,
    "seo_path": SEO,
}


def resolve_artifact(stored: str, dir_: Path) -> Path:
    """库中产物路径 -> 当前机器可用路径。stored 为空返回空 Path。"""
    p = Path(stored or "")
    if not p.name:
        return p
    if p.exists():
        return p
    # Windows 路径进 Linux 后 Path.name 不会按反斜杠切分，需手工取最后一段
    name = (stored or "").replace("\\", "/").rsplit("/", 1)[-1]
    if not name:
        return p
    cand = dir_ / name
    return cand if cand.exists() else p
