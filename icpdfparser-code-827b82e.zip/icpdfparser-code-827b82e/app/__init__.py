"""IcPdfParser 工作台（FastAPI + Celery）。

app/ 只做「编排 + 展示」，真正的解析/渲染能力全部复用仓库根目录的既有脚本：
    parse_datasheets.py   PDF -> JSON
    json_to_txt.py        JSON -> 详情页片段
    alternatives.py       AI 内链匹配 -> 替代型号片段
    symbol_svg.py         JSON -> 三视图
    build_product_index.py 站内目录 -> 内链索引
"""
__version__ = "1.0.0"
