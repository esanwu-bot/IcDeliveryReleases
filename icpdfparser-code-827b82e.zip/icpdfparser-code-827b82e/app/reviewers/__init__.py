"""评委层：把「判断」外包给独立模型，但不外包「取证」与「改数」。

约定：
* 评委只输出结构化裁决（agree/mismatch/unsure、pass/suspect + issues）；
* 证据切片（bbox → snippet）由本层自己做，模型只看切片；
* 任何「改 JSON」的动作都不在本层发生。
"""
