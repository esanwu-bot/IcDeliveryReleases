"""双 Qwen 评委（阿里云百炼 / DashScope）—— 质审流水线的**取证层**。

两个角色，两套判据，互不替代：

* **qwen-long 扮「元宝」：原文校对。** 输入不是整份 PDF，而是
  `facts_audit.csv` 里那一行的 **bbox → 从 PDF 裁出的 snippet（目标行 + 表头）**。
  原因很实际：判断「这个 0.1 是 MIN 还是 MAX」靠的是**列坐标**，而坐标在我们
  自己的 bbox 里；整份 PDF 丢给模型，它只能靠数值大小猜。顺带把单次评审从
  5 万字符压到几百字符，一批跑下来才付得起。
* **qwen-max 扮「ChatGPT」：逻辑挑刺。** 只看 JSON 结构，不碰原文。
  它负责的是「表型」问题：Absolute Maximum 混进工作条件、同一参数两条无区分、
  关键参数整块缺失、多封装表只剩一条却没有 `condition`。

两个评委都**只输出结构化裁决**，不做修改、不写 JSON —— 改数据是人的事。
`app/qa/controller.py` 负责汇总与建单。
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from app.integrations.env import get as env_get
from app.integrations.env import read_env_file

DASHSCOPE_BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"

#: 角色分工写死在常量里，CLI/调度器不许各自传字符串 —— 传错了就是「用便宜的
#: 模型查证据、用贵的模型抄原文」，评审结论看着正常但全是错的。
MODEL_EVIDENCE = "qwen-long"
MODEL_LOGIC = "qwen-max"

#: 单行评审允许的最大 snippet 字符数。超了说明表头抓多了，宁可截断并标注，
#: 也不要把一整页塞进去（那就退化成「传整份 PDF」了）。
MAX_SNIPPET_CHARS = 1600


class ReviewerError(RuntimeError):
    """评审失败（网络/鉴权/输出不可解析）。**不静默降级为 agree**。"""


# ---------------------------------------------------------------- 模型调用
def _config(env: dict[str, str] | None = None) -> tuple[str, str, str]:
    """返回 `(base, key, default_model)`。"""
    e = env if env is not None else read_env_file()
    base = (env_get("DASHSCOPE_BASE", DASHSCOPE_BASE, e) or DASHSCOPE_BASE).rstrip("/")
    key = env_get("DASHSCOPE_API_KEY", "", e)
    return base, key, env_get("DASHSCOPE_MODEL", "qwen-flash", e)


def chat(messages: list[dict], *, model: str, json_mode: bool = True,
         temperature: float = 0.0, max_tokens: int = 1200, timeout: int = 120,
         retries: int = 3, session=None, env: dict[str, str] | None = None) -> dict:
    """调一次 OpenAI 兼容接口，返回 ``{"content", "model", "usage"}``。

    百炼的 OpenAI 兼容层支持 `response_format={"type":"json_object"}`，
    但**不是所有模型都认**；400 时降级重发一次（与解析链路同一策略）。
    """
    base, key, _ = _config(env)
    if not key:
        raise ReviewerError("缺 DASHSCOPE_API_KEY（环境变量或 .env.local）")
    if session is None:
        import requests
        session = requests.Session()

    url = f"{base}/chat/completions"
    payload: dict[str, Any] = {"model": model, "messages": messages,
                               "temperature": temperature, "max_tokens": max_tokens}
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    last: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            r = session.post(url, headers=headers, json=payload, timeout=timeout)
            if r.status_code == 400 and "response_format" in payload:
                payload.pop("response_format", None)      # 该模型不认 JSON mode
                r = session.post(url, headers=headers, json=payload, timeout=timeout)
            if r.status_code == 429 or 500 <= r.status_code < 600:
                raise ReviewerError(f"HTTP {r.status_code}: {r.text[:200]}")
            if r.status_code != 200:
                # 鉴权/参数错误重试没有意义，直接抛，别把配额烧在必败的请求上
                raise ReviewerError(f"{model} HTTP {r.status_code}: {r.text[:300]}")
            data = r.json()
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
            return {"content": content or "", "model": model,
                    "usage": data.get("usage") or {}}
        except ReviewerError as e:
            last = e
            if "HTTP 429" not in str(e) and "HTTP 5" not in str(e):
                raise
        except Exception as e:                            # noqa: BLE001 - 网关偶发断连
            last = e
        if attempt < retries:
            time.sleep(2 ** attempt)
    raise ReviewerError(f"{model} 调用失败：{last}")


def _json_of(text: str) -> dict:
    """从模型回复里取 JSON。容忍 ```json 围栏与前后废话。"""
    s = (text or "").strip()
    s = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", s, flags=re.M).strip()
    try:
        return json.loads(s)
    except ValueError:
        i, j = s.find("{"), s.rfind("}")
        if 0 <= i < j:
            try:
                return json.loads(s[i:j + 1])
            except ValueError:
                pass
    raise ReviewerError(f"模型输出不是合法 JSON：{s[:200]!r}")


# ---------------------------------------------------------------- 证据切片
@dataclass
class Snippet:
    """一行原文的证据切片：目标行 + 上方表头，**都带列左边界 x**。

    为什么不直接 `get_text(clip=...)`：文本流按阅读顺序重排，多列数值会被
    串成一行，`39.3 43.6` 看不出谁属于哪个封装。实测 LM317 p7 的目标行还会
    带出上一行的残字（`θ(J )`）—— 因为 clip 切在字框中间，PyMuPDF 把相交的
    字符也收进来了。按**词中心点**取行、再按 x 排序，两个问题一起消失。
    """
    page: int
    bbox: list[float]
    header: str
    row: str
    values: list[dict] = field(default_factory=list)
    #: 表头封装列 `[{"code":"D","x":267.0}, …]`（按 x 从左到右）。
    #: 有了它，「值属于哪一列」可以**算**出来，不必让模型看坐标猜 ——
    #: 2026-11-03 实测模型在同一份 snippet 上先判 mismatch、又在 reason 里
    #: 写「原判错误，修正为 agree」，结构化字段却仍是 mismatch。
    columns: list[dict] = field(default_factory=list)
    truncated: bool = False

    @property
    def text(self) -> str:
        head = self.header.strip() or "(未取到表头)"
        vals = "，".join(f"{v['text']}@{v['x']:.0f}" for v in self.values) or "（未识别到数值）"
        return (f"【表头（数字为列左边界 x）】\n{head}\n"
                f"【目标行】\n{self.row.strip() or '(空)'}\n"
                f"【机器计数】该行数值 {len(self.values)} 个：{vals}")

    def as_dict(self) -> dict:
        return {"page": self.page, "bbox": list(self.bbox),
                "header": self.header, "row": self.row,
                "values": list(self.values), "columns": list(self.columns),
                "truncated": self.truncated}


#: 表头候选：带列角色词，或带封装码（`DCY (SOT-223)`）。
_ROLE_HINT = re.compile(r"\b(MIN|TYP|MAX|MINIMUM|TYPICAL|MAXIMUM|UNIT)\b", re.I)
_PKG_HINT = re.compile(r"\b[A-Z]{2,4}\s*\(\s*[A-Za-z0-9][A-Za-z0-9\-\s]*\)")
_PKG_CODE = re.compile(r"^[A-Z]{2,4}$")
#: 括号封装名 `(SOT-223)` / `(TO-263)`。也标 x：它和封装码分两行印，
#: 不标坐标就看不出 `(SOT-223)` 属于 `DCY@391` 还是 `KTT@454`。
_PKG_NAME = re.compile(r"^\([A-Za-z0-9][A-Za-z0-9\-\s]*\)$")
_NUM_TOKEN = re.compile(r"^[±+\-−]?\d+(?:[.,]\d+)?$")
#: 裸封装码行（`D FK JG P PS PW`）。NE555 的封装码与封装名**分两行印**，
#: 码行不含括号，`_PKG_HINT` 打 0 分 → 表头退化成 `THERMAL METRIC (1) SE555 UNIT`，
#: 评委看不到列只能靠猜（实测把最左列认成 PS）。单字母码必须算进来。
_BARE_CODE = re.compile(r"^[A-Z]{1,4}$")
#: 这些词不是封装码：引脚数行 `8 PINS 20 PINS …` 会被数成 6 个"封装码"。
_CODE_STOP = {"PINS", "PIN", "UNIT", "MIN", "MAX", "TYP", "NOM", "GND", "NC"}


def _open_pdf(pdf_path: str | Path):
    try:
        import pymupdf
    except ImportError:                                   # pragma: no cover
        try:
            import fitz as pymupdf
        except ImportError as e:
            raise ReviewerError("取证据需要 pymupdf（pip install pymupdf）") from e
    return pymupdf, pymupdf.open(str(pdf_path))


def _cy(w) -> float:
    return (w[1] + w[3]) / 2.0


def _cluster_lines(words: list, gap: float = 6.0) -> list[list]:
    """按词中心 y 聚类成行（同一行的字高/基线可能差 1~2 点）。

    `gap=6` 是实测值：LM317 的表头把 `DCY (SOT-223)` 印在基线 300.6、
    `THERMAL METRIC` 印在 305.4，相差 4.8 点。gap 取 3 会把同一行拆成两簇，
    于是封装列定义被丢掉、只剩 `THERMAL METRIC UNIT` —— 而「哪一列是哪个封装」
    正是本模块唯一要回答的问题。
    """
    out: list[list] = []
    for w in sorted(words, key=lambda x: _cy(x)):
        if out and abs(_cy(w) - _cy(out[-1][0])) <= gap:
            out[-1].append(w)
        else:
            out.append([w])
    for ln in out:
        ln.sort(key=lambda x: x[0])
    return out


def _annotate(words: list, short_codes: bool = False) -> str:
    """拼一行文本；对封装码/角色词/数值标注左边界 x。

    标注是给模型对齐用的：`39.3@392` 落在 `DCY@381` 与 `KTT@446` 之间，
    归属一眼可判，不需要模型自己数空格。

    ``short_codes`` 只对**表头**开：NE555 的码是单字母（`D`/`P`），不标 x 时
    模型只能按顺序猜，而 `PINS`/`UNIT` 这类 3~4 字母词在行里不该被标。
    """
    parts: list[str] = []
    for w in words:
        t = str(w[4])
        if (_PKG_CODE.match(t) or _PKG_NAME.match(t) or _ROLE_HINT.match(t)
                or _NUM_TOKEN.match(t)
                or (short_codes and _BARE_CODE.match(t) and t not in _CODE_STOP)):
            parts.append(f"{t}@{w[0]:.0f}")
        else:
            parts.append(t)
    return " ".join(parts)


def _header_columns(lines: list[list]) -> list[dict]:
    """从表头行里读出封装列 `[{"code":"D","x":267.0}, …]`（按 x 排序）。

    只认**封装码**（`DCY` / 单字母 `D`），并且取「码最多」的那一行：
    NE555 的码行是 `D FK JG P PS PW`，LM317 是 `DCY KCS KCT KTT`。
    `PINS`/`UNIT` 这类词在 `_CODE_STOP` 里，引脚数行不会被读成封装列。
    """
    best: list[dict] = []
    for ln in lines:
        codes = [{"code": str(w[4]), "x": round(float(w[0]), 1)}
                 for w in ln
                 if (_PKG_CODE.fullmatch(str(w[4]))
                     or (_BARE_CODE.fullmatch(str(w[4]))
                         and str(w[4]) not in _CODE_STOP))]
        if len(codes) >= 2 and len(codes) >= len(best):
            best = codes
    best.sort(key=lambda c: c["x"])
    return best


def _code_in_condition(cond: Any, codes: list[str]) -> str:
    """`condition` 里点名的封装码（按词边界，`PDIP` 不算点了 `P`）。"""
    low = str(cond or "").lower()
    for c in codes:
        if re.search(rf"(?<![a-z0-9]){re.escape(str(c).lower())}(?![a-z0-9])", low):
            return c
    return ""


def _assigned_columns(snip: "Snippet") -> dict[str, str]:
    """原文该行的每个数值 → 它按 x 最近的封装列码。"""
    out: dict[str, str] = {}
    for v in snip.values:
        key = _num_key(v.get("text"))
        if not key:
            continue
        col = min(snip.columns, key=lambda c: abs(float(v.get("x") or 0.0) - c["x"]))
        out.setdefault(col["code"], key)
    return out


def machine_column_check(snip: "Snippet", siblings: list[dict] | None) -> dict | None:
    """机器核对「JSON 的 value ↔ condition 点名的列」是否逐条成立。

    全部成立才返回结论；任何一条对不上（值落错列、漏列、条件没点名）返回 None，
    **交回给模型** —— 这不是放宽判据，而是把「值属于哪一列」从模型的肉眼估计
    换成 PDF 词坐标的可复算结果。实测同一份 snippet 上模型会先判 mismatch、
    又在 reason 里写「原判错误，修正为 agree」，结构化字段却仍是 mismatch。
    """
    sibs = [s for s in (siblings or []) if s]
    if len(snip.columns) < 2 or len(sibs) < 2:
        return None
    assigned = _assigned_columns(snip)
    # 值必须一值一列，且 JSON 条目数必须等于原文数值个数（多一条 = 编造）
    if len(assigned) != len(snip.values) or len(sibs) != len(snip.values):
        return None
    codes = [c["code"] for c in snip.columns]
    seen: dict[str, str] = {}
    for s in sibs:
        code = _code_in_condition(s.get("condition"), codes)
        if not code or code in seen:
            return None
        if assigned.get(code) != _num_key(s.get("value")):
            return None
        seen[code] = _num_key(s.get("value"))
    if set(seen) != set(assigned):
        return None
    return {"columns": snip.columns, "matched": len(seen)}


def slice_row(pdf_path: str | Path, page: int, bbox: list[float], *,
              header_up: float = 220.0, header_lines: int = 2) -> Snippet:
    """从 PDF 裁出目标行与它上方的表头（按词坐标重建）。

    ``page`` 是 1-based（与 `facts_audit.csv` 一致）。``bbox`` 为
    ``[x0, y0, x1, y1]``（PDF 点）。

    表头取法：在目标行上方 `header_up` 点内按行聚类，**优先选带封装码或
    MIN/TYP/MAX/UNIT 的行**（这正是判断列归属需要的），取最靠近目标行的
    若干条。取不到就留空 —— 模型会因此判 `unsure`，比喂假表头让它自信判错好。
    """
    if not bbox or len(bbox) != 4:
        raise ReviewerError(f"bbox 非法：{bbox!r}")
    pymupdf, doc = _open_pdf(pdf_path)
    try:
        if page < 1 or page > doc.page_count:
            raise ReviewerError(f"页码越界：{page} / 共 {doc.page_count} 页")
        pg = doc[page - 1]
        words = pg.get_text("words") or []
    finally:
        doc.close()

    x0, y0, x1, y1 = [float(v) for v in bbox]
    row_ws = [w for w in words
              if y0 - 2.0 <= _cy(w) <= y1 + 2.0 and w[2] > x0 - 1.0 and w[0] < x1 + 1.0]
    row_ws.sort(key=lambda w: w[0])
    row_text = _annotate(row_ws)
    values = [{"text": str(w[4]), "x": round(float(w[0]), 1)}
              for w in row_ws if _NUM_TOKEN.match(str(w[4]))]

    above = [w for w in words
             if y0 - header_up <= _cy(w) <= y0 - 1.0 and w[2] > x0 - 1.0]
    lines = _cluster_lines(above)
    scored: list[tuple[int, int, list]] = []
    for idx, ln in enumerate(lines):
        txt = " ".join(str(w[4]) for w in ln)
        # 封装列定义是最高价值表头（`DCY (SOT-223)`）；裸大写词只有在紧跟
        # `(` 时才算封装码 —— 否则 `THERMAL METRIC UNIT` 会被数成 3 个封装码，
        # 反而压过真正的封装行（实测踩到）。
        score = 3 if _PKG_HINT.search(txt) else 0
        score += len(re.findall(r"\b[A-Z]{2,4}\s*\(", txt))
        score += 1 if _ROLE_HINT.search(txt) else 0
        # NE555 式排版：封装码一行（`D FK JG P PS PW`）、封装名一行（`(SOIC) …`），
        # 两行都不含 `CODE (NAME)` 形式，上面的打分全是 0。不补这两条，表头会
        # 退化成 `THERMAL METRIC (1) SE555 UNIT`，评委只能猜列（实测猜错）。
        lower = bool(re.search(r"[a-z]", txt))
        bare = [t for t in txt.split() if _BARE_CODE.fullmatch(t) and t not in _CODE_STOP]
        if not lower and len(bare) >= 3:
            score = max(score, 3)
        if not lower and len(re.findall(r"\([A-Za-z0-9][^)]*\)", txt)) >= 2:
            score = max(score, 2)
        scored.append((score, idx, ln))
    picked: list[list] = []
    if scored:
        best = max(scored, key=lambda s: (s[0], s[1]))    # 分数高优先，其次更靠近行
        if best[0] > 0:
            by = sum(_cy(w) for w in best[2]) / len(best[2])
            # 封装名常印在封装码的下一行（`DCY` / `(SOT-223)`），字号还更小，
            # 聚类时会分家。把 best 附近 12 点内、含括号名的行并回来 ——
            # 否则表头只剩 `DCY@391 KTT@454`，模型知道有列但不知道是哪两个封装。
            near = [ln for ln in lines
                    if abs(sum(_cy(w) for w in ln) / len(ln) - by) <= 12.0]
            picked = [ln for ln in near
                      if ln is best[2]
                      or re.search(r"\([A-Za-z0-9]", " ".join(str(w[4]) for w in ln))]
            picked.sort(key=lambda ln: sum(_cy(w) for w in ln) / len(ln))
            picked = picked[:header_lines]
        else:
            picked = lines[-header_lines:]
    header = "\n".join(_annotate(ln, short_codes=True) for ln in picked)
    columns = _header_columns(picked)

    truncated = False
    if len(header) + len(row_text) > MAX_SNIPPET_CHARS:
        keep = max(200, MAX_SNIPPET_CHARS - len(row_text))
        header = header[-keep:]
        truncated = True
    return Snippet(page=page, bbox=[x0, y0, x1, y1], header=header,
                   row=row_text, values=values, columns=columns, truncated=truncated)


#: 热阻参数名的宽松匹配（`RθJA` / `Rθ(JA)` / `RθJC(top)` / `ψJT`）。
_THERMAL_TOKEN = re.compile(r"(R\s*θ\s*\(?[A-Za-z]{2,3}\)?(?:\s*\((?:top|bot)\))?|ψ\s*[A-Z]{2})")


def thermal_labels_in_pdf(pdf_path: str | Path, max_pages: int = 20) -> list[str]:
    """机器扫出原文里**出现过**的热阻参数名（不做数值抽取，只做存在性）。

    用途只有一个：给 qwen-max 一份「原文有哪些参数」的对照清单，
    让「RθJA 整块缺失」这类问题**有据可查**，而不是靠模型凭常识猜。
    归一化只去空白与括号，`Rθ(JA)` → `RθJA`，不做任何别名映射。
    """
    pymupdf, doc = _open_pdf(pdf_path)
    seen: dict[str, str] = {}
    try:
        for i in range(min(doc.page_count, max_pages)):
            txt = doc[i].get_text("text") or ""
            for m in _THERMAL_TOKEN.finditer(txt):
                raw = m.group(1)
                key = re.sub(r"[\s()]", "", raw).upper()
                seen.setdefault(key, " ".join(raw.split()))
    finally:
        doc.close()
    return sorted(seen.values())


# ---------------------------------------------------------------- 评委一：原文校对
LONG_SYSTEM = """你是严苛的原文校对员。你唯一的工作是核对 JSON 抽取值与 PDF 原文是否一致。

规则（按优先级）：
1. 只依据给出的 snippet 判断。snippet 里看不到的内容一律判 `unsure`，
   严禁用器件常识补全，严禁假设「应该是多少」。
2. MIN/TYP/MAX 的列归属是重点。看表头与列的位置关系判断，**不要用数值大小猜**
   （例如 MAX 列的 0.1 完全可能比 TYP 列的 0.3 小）。
3. 数值逐字符比对：`1.25` ≠ `1.2`；`0.1` 与 `0.10` 视为一致；`±2000` ≠ `2000`。
4. 单位不同即判错（`μA` ≠ `mA`，`°C/W` ≠ `W/°C`）。
5. 若 JSON 的 condition 与 snippet 表头指示的封装/条件不符，判 `mismatch`。
6. **多列塌缩**（只在**真的漏列**时判）：多封装表的一行在原文里有 2 个及以上
   数值。此时看「同参数的其他 JSON 行」：
   · 若它们把原文这几个数值**全部覆盖**、每条 `condition` 非空且互不相同
     （封装码前后可带表名，如 `Legacy Chip; DCY (SOT-223) 4 PINS`），那说明
     抽取器**已按列展开** —— 本条只需核对「本条 value 是否落在 condition 所指
     的那一列」，对得上就判 `agree`；对不上（值落错列）判 `mismatch`。
   · 若同参数只有一条 JSON、condition 为空，或条目数少于原文数值个数，
     才是塌缩 —— 判 `mismatch`，reason 写「只抽了第一列，原文另有 N 列」。
   数值与第一列对得上也要判错：漏列就是漏数据。
7. 数值后的 `@数字` 是列左边界 x，不是值的一部分。

只输出 JSON，不要解释性文字：
{"verdict":"agree|mismatch|unsure","expected_value":"","expected_unit":"",
 "expected_column":"","json_column":"","reason":"","confidence":0.0}
`confidence` 取 0~1；`unsure` 时 reason 必须写明缺什么证据。"""

LONG_USER = """MPN: {mpn}
JSON 抽取：name={name!r} value={value!r} unit={unit!r} condition={cond!r}
同参数的其他 JSON 行（同一原文行按封装列展开的结果）：
{siblings}
【机器核对】{machine}

{snippet}

请判断该 JSON 值是否与原文一致，并说明它实际落在哪一列。"""


def _num_key(s: Any) -> str:
    """数值归一：`0.10` 与 `0.1` 视为同一个，`−`/`–` 统一成 `-`。

    只用于「覆盖计数」，不参与真正的取值比对 —— 取值仍由评委逐字符看原文。
    """
    t = str(s or "").strip().replace("−", "-").replace("–", "-")
    try:
        return f"{float(t):.12g}"
    except (TypeError, ValueError):
        return t


def sibling_block(siblings: list[dict] | None) -> str:
    """把同参数的其它 JSON 行写成给评委看的一行一条。"""
    rows = [s for s in (siblings or []) if s]
    if not rows:
        return "（无：该参数在 JSON 里只有这一条）"
    return "\n".join(
        f"- value={str(s.get('value'))!r} unit={str(s.get('unit') or '')!r} "
        f"condition={str(s.get('condition') or '')!r}"
        for s in rows)


def coverage_line(snip: "Snippet", siblings: list[dict] | None) -> str:
    """机器核对：原文这一行的 N 个数，是否被同参数 JSON 行全部覆盖。

    这条**不是**给评委放水的证据，而是它缺的那半块上下文：`slice_row` 取的是
    **原文行**的 bbox，多封装表一行里本来就有 N 个数；只看单条 JSON 永远会得出
    「只抽了第一列」。覆盖计数把「展开成 N 条」与「只有 1 条」区分开，
    判据本身不变：覆盖不全 / condition 为空仍按塌缩判错。
    """
    src = {_num_key(v.get("text")) for v in snip.values}
    src.discard("")
    got = {_num_key(s.get("value")) for s in (siblings or [])}
    got.discard("")
    conds = {str(s.get("condition") or "").strip() for s in (siblings or [])}
    conds.discard("")
    return (f"原文该行数值 {len(src)} 个（{'、'.join(sorted(src))}）；"
            f"JSON 同参数 {len(siblings or [])} 条，命中 {len(src & got)}/{len(src)}；"
            f"非空且互异的 condition {len(conds)} 个")


def review_row(item: dict, pdf_path: str | Path, *,
               siblings: list[dict] | None = None,
               model: str | None = None, chat_fn: Callable[..., dict] | None = None,
               env: dict[str, str] | None = None) -> dict:
    """评审一条 JSON 行。``item`` 至少含 label/value/unit/page/bbox。

    ``siblings`` 是**同参数的全部 JSON 行**（含本条）。多封装表的原文一行会被
    展开成 N 条 JSON，只给评委看一条，它必然判「只抽了第一列」—— 不是它判错，
    是我们没给证据。
    """
    mpn = str(item.get("mpn") or "")
    name = str(item.get("label") or item.get("name") or "")
    if not item.get("bbox"):
        # 没有 bbox 就没有证据。**不许**退化成「整页丢给模型」。
        return {"reviewer": MODEL_EVIDENCE, "verdict": "unsure", "label": name,
                "reason": "缺 bbox，无法定位原文（未调用模型）",
                "confidence": 0.0, "skipped": True, "evidence": {}}
    snip = slice_row(pdf_path, int(item["page"]), list(item["bbox"]))
    chk = machine_column_check(snip, siblings)
    if chk:
        # 坐标算出来的结论优先：列归属、覆盖数量都逐条对上，不需要模型再猜。
        # `machine_verified` 落盘，工单/报告里能看见这一条**没调模型**。
        cond = str(item.get("condition") or item.get("cond") or "")
        code = _code_in_condition(cond, [c["code"] for c in chk["columns"]])
        return {
            "reviewer": MODEL_EVIDENCE, "verdict": "agree", "label": name,
            "model": "machine-column-check", "machine_verified": True,
            "json_value": item.get("value"), "json_unit": item.get("unit"),
            "json_column": code,
            "expected_value": item.get("value"), "expected_unit": item.get("unit"),
            "expected_column": code,
            "reason": (f"机器核对：原文该行 {len(snip.values)} 个值按词坐标归属，"
                       f"与 JSON 的 {chk['matched']} 条封装展开一一对应"
                       f"（列 {[c['code'] for c in chk['columns']]}），无漏列、无错列"),
            "confidence": 1.0, "evidence": snip.as_dict(), "usage": {},
        }
    user = LONG_USER.format(
        mpn=mpn, name=name, value=item.get("value"), unit=item.get("unit"),
        cond=item.get("condition") or item.get("cond") or "",
        siblings=sibling_block(siblings),
        machine=coverage_line(snip, siblings),
        snippet=snip.text)
    fn = chat_fn or chat
    res = fn([{"role": "system", "content": LONG_SYSTEM},
              {"role": "user", "content": user}],
             model=model or MODEL_EVIDENCE, env=env)
    got = _json_of(res.get("content", ""))
    verdict = str(got.get("verdict") or "unsure").strip().lower()
    if verdict not in ("agree", "mismatch", "unsure"):
        verdict = "unsure"
    try:
        conf = max(0.0, min(1.0, float(got.get("confidence") or 0.0)))
    except (TypeError, ValueError):
        conf = 0.0
    return {
        "reviewer": MODEL_EVIDENCE, "verdict": verdict, "label": name,
        # 工单抬头要写「模型版本」：网关回的 `model` 是真实快照名（可能带日期后缀），
        # 比常量更利于复现；拿不到就退回常量，不编造。
        "model": res.get("model") or (model or MODEL_EVIDENCE),
        "kind": "qwen_long_mismatch" if verdict == "mismatch" else "",
        "json_value": item.get("value"), "json_unit": item.get("unit"),
        "json_column": got.get("json_column") or item.get("column_role") or "",
        "expected_value": got.get("expected_value"),
        "expected_unit": got.get("expected_unit"),
        "expected_column": got.get("expected_column"),
        "reason": str(got.get("reason") or "")[:800],
        "confidence": conf,
        "evidence": snip.as_dict(),
        "usage": res.get("usage") or {},
    }


# ---------------------------------------------------------------- 评委二：逻辑挑刺
MAX_SYSTEM = """你是独立质检员。你不看 PDF 原文，只审查这份 JSON 的内部一致性与表型。

逐项检查（发现即报，没有问题就不要凑数）：
1. `absmax_in_operating`：Absolute Maximum 的条目（电压/电流/功耗/结温上限）
   混进了 electrical 工作条件表。
2. `duplicate_param`：同一参数出现两次及以上，却没有任何 condition 区分
   （多封装/多温度/多测试条件是合法重复，但 condition 必须非空且互不相同）。
3. `missing_key_param`：对照 `pdf_parameter_hints`（机器从原文扫出的参数名）
   发现**整块缺失** —— 即该参数名在 JSON 里**一条都没有**（例：原文热阻表有
   RθJC(top)/RθJB 却没有 RθJA）。**同一参数在部分封装下没有条目不算缺失**：
   多封装表的某些格原文印的就是 `NA` / `—`，按「宁可缺、不许错列」跳过它是
   正确做法 —— 不得据此判 P0，更不得要求补齐原文不存在的值（2026-11-03
   NE555 实测：RθJC(bot) 四个封装原文全是 N/A，却被判 P0 缺失）。
4. `column_collapse_suspect`：**热阻表（thermal）**里同一参数只有一条、condition
   为空，而 hints 显示原文有多个封装列 —— 这是「只抽第一列」的典型形态。
   **只对 thermal 判**：电气参数的单值行本来就不印 condition，不得据此判塌缩；
   JSON 里该参数已有两条及以上（condition 互异）就更不构成塌缩。
5. `condition_missing`：多封装表的行没有写 condition，读者无法判断数字属于哪个封装。

严重度：`P0` = 数据错或缺失到会误导选型；`P1` = 表述不完整但数值可信。

只输出 JSON：
{"verdict":"pass|suspect","reason":"","issues":[
  {"kind":"","severity":"P0|P1","label":"","detail":"","expected":"","current":""}]}"""

MAX_USER = """MPN: {mpn}
pdf_parameter_hints（机器从原文扫出的参数名，仅作对照）: {hints}

JSON（已按容器裁剪，数值原样）:
{payload}"""

#: 送进 qwen-max 的每个容器最多保留多少行。热阻/电气表通常 < 40 行；
#: 超出的部分是引脚/特性描述，与「表型」判断无关。
MAX_ROWS_PER_CONTAINER = 80


def _logic_payload(doc: dict) -> str:
    """把 JSON 压成「结构视图」：保留 basic_info 与 specs 全部行，引脚只留计数。

    为什么裁引脚：`pin_configuration` 动辄上百条，塞进去只会把热阻/电气表挤出
    上下文窗口；而本评委要查的四类问题没有一类与引脚描述有关。
    """
    specs = doc.get("specs") or {}
    trimmed: dict[str, Any] = {}
    for k, v in specs.items():
        if isinstance(v, list):
            trimmed[k] = v[:MAX_ROWS_PER_CONTAINER]
            if len(v) > MAX_ROWS_PER_CONTAINER:
                trimmed[k] = list(trimmed[k]) + [{"_truncated": len(v) - MAX_ROWS_PER_CONTAINER}]
        else:
            trimmed[k] = v
    pins = doc.get("pin_configuration") or []
    view = {
        "basic_info": doc.get("basic_info") or {},
        "specs": trimmed,
        "pin_configuration_count": len(pins),
        "pin_names": [p.get("name") or p.get("pin_name") for p in pins[:12]],
    }
    return json.dumps(view, ensure_ascii=False, indent=1)


def review_doc(doc: dict, *, mpn: str = "", pdf_label_hints: list[str] | None = None,
               model: str | None = None, chat_fn: Callable[..., dict] | None = None,
               env: dict[str, str] | None = None) -> dict:
    """逻辑审查整件 JSON。"""
    fn = chat_fn or chat
    hints = list(pdf_label_hints or [])
    res = fn([{"role": "system", "content": MAX_SYSTEM},
              {"role": "user", "content": MAX_USER.format(
                  mpn=mpn or (doc.get("basic_info") or {}).get("mpn", ""),
                  hints=", ".join(hints) or "(未提供)",
                  payload=_logic_payload(doc))}],
             model=model or MODEL_LOGIC, env=env)
    got = _json_of(res.get("content", ""))
    issues = []
    for it in (got.get("issues") or [])[:20]:
        if not isinstance(it, dict):
            continue
        sev = str(it.get("severity") or "P1").upper()
        issues.append({
            "kind": str(it.get("kind") or "logic_unspecified"),
            "severity": sev if sev in ("P0", "P1") else "P1",
            "label": it.get("label") or "",
            "detail": str(it.get("detail") or "")[:600],
            "expected": str(it.get("expected") or "")[:400],
            "current": str(it.get("current") or "")[:400],
        })
    verdict = str(got.get("verdict") or ("suspect" if issues else "pass")).lower()
    if verdict not in ("pass", "suspect"):
        verdict = "suspect" if issues else "pass"
    return {"reviewer": MODEL_LOGIC, "verdict": verdict,
            "model": res.get("model") or (model or MODEL_LOGIC),
            "reason": str(got.get("reason") or "")[:800], "issues": issues,
            "usage": res.get("usage") or {}}


# ---------------------------------------------------------------- CLI（单行自测）
def _load_items(json_path: str | Path, facts_csv: str | Path | None = None,
                focus: str = "thermal", limit: int | None = None) -> list[dict]:
    """从 JSON 取待审行，并按 `(label, cond)` 从事实表补 bbox/page。"""
    import csv
    doc = json.loads(Path(json_path).read_text(encoding="utf-8"))
    mpn = str((doc.get("basic_info") or {}).get("mpn") or Path(json_path).stem)
    coords: dict[tuple[str, str], dict] = {}
    if facts_csv and Path(facts_csv).is_file():
        with open(facts_csv, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                if str(r.get("mpn") or "") != mpn:
                    continue
                raw = str(r.get("bbox") or "").strip()
                bbox: list[float] = []
                if raw:
                    try:
                        bbox = [float(x) for x in json.loads(raw)] if raw.startswith("[") \
                            else [float(x) for x in re.split(r"[,\s]+", raw) if x]
                    except (ValueError, TypeError):
                        bbox = []
                coords[(str(r.get("label") or ""), str(r.get("cond") or ""))] = {
                    "bbox": bbox if len(bbox) == 4 else [],
                    "page": int(r["page"]) if str(r.get("page") or "").isdigit() else None,
                    "verdict": str(r.get("verdict") or ""),
                }
    rows: list[dict] = []
    for container in (focus.split(",") if focus else []):
        for r in ((doc.get("specs") or {}).get(container.strip()) or []):
            cond = str(r.get("condition") or "")
            c = coords.get((str(r.get("name") or ""), cond)) or {}
            rows.append({"mpn": mpn, "container": container.strip(),
                         "label": r.get("name"), "value": r.get("value"),
                         "unit": r.get("unit"), "condition": cond,
                         "column_role": r.get("column_role") or "",
                         "page": c.get("page"), "bbox": c.get("bbox") or [],
                         "fact_verdict": c.get("verdict") or ""})
    if limit:
        rows = rows[:limit]
    return rows


def main(argv: list[str] | None = None) -> int:
    import argparse
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser(description="qwen-long 逐行原文校对")
    ap.add_argument("--json", required=True)
    ap.add_argument("--pdf", required=True)
    ap.add_argument("--facts", default="", help="facts_audit.csv（提供 bbox/page）")
    ap.add_argument("--focus", default="thermal", help="逗号分隔的容器名")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args(argv)
    items = _load_items(a.json, a.facts or None, a.focus, a.limit or None)
    out = [review_row(it, a.pdf) for it in items]
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
