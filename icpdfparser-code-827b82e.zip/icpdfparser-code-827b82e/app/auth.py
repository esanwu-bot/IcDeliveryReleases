"""单用户登录：环境变量配账号密码，HMAC 签名 cookie。

三项环境变量（ICPDF_AUTH_USER / ICPDF_AUTH_PASSWORD / ICPDF_AUTH_SECRET）
任一未配置即完全关闭登录——本机开发不受影响；服务器部署必须三项都配。
"""
from __future__ import annotations

import hashlib
import hmac
import time


COOKIE = "icpdf_auth"
TTL = 7 * 86400                                    # 登录态保持 7 天


def user() -> str:
    import os
    return os.getenv("ICPDF_AUTH_USER", "").strip()


def password() -> str:
    import os
    return os.getenv("ICPDF_AUTH_PASSWORD", "").strip()


def secret() -> str:
    import os
    return os.getenv("ICPDF_AUTH_SECRET", "").strip()


def enabled() -> bool:
    return bool(user() and password() and secret())


def _sig(payload: str) -> str:
    return hmac.new(secret().encode("utf-8"), payload.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def make_token(u: str) -> str:
    exp = str(int(time.time()) + TTL)
    payload = f"{u}.{exp}"
    return f"{payload}.{_sig(payload)}"


def verify(token: str) -> bool:
    try:
        u, exp, sig = (token or "").rsplit(".", 2)
        if not hmac.compare_digest(sig, _sig(f"{u}.{exp}")):
            return False
        if int(exp) < time.time():
            return False
        return u == user()
    except (ValueError, AttributeError):
        return False


def check_login(u: str, p: str) -> bool:
    """常数时间比较，避免时序侧信道。"""
    return (hmac.compare_digest(u or "", user())
            and hmac.compare_digest(p or "", password()))
