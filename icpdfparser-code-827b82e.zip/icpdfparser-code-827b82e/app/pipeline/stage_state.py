"""阶段状态表 `pipeline_stage`：一个键一行，记录每个阶段跑到哪、产出了什么。

为什么另起一张表，而不复用 `item.status`
----------------------------------------
`item` 是**业务态**（pending/parsing/done/failed），它回答「这件货交付了没」。
阶段表是**执行态**，回答「这份 PDF 的 preprocess 跑过没、用的哪版抽取器」。
两者维度不同：一件货可能重跑三次 LLM，业务态一直是 parsing，但阶段表里有三行
不同 prompt 指纹的记录。把执行态塞进 `item.status` 正是上一版「重试只能整条
重跑」的根因。

为什么自己在 `app/pipeline/` 里建表，而不改 `app/db.py` 的 DDL
-------------------------------------------------------------
`db.py` 的 DDL 是**全站共用**的建库脚本，改它等于让所有环境（含灰度前的老
进程）都跟着变。阶段表只服务新链路，因此自带 `ensure_schema()`：连自己的库、
建自己的表，`CREATE TABLE IF NOT EXISTS` 幂等，老环境不受影响。
这也让测试能指向一个一次性临时库，不污染 `data/workbench.sqlite3`。

状态机（单一方向，不回退）
--------------------------
    pending ──begin──> running ──finish──> ok | skipped | blocked | failed
                          ^                                    │
                          └──────────── 重新 begin（failed）────┘

`ok` / `skipped` / `blocked` 是终态：重复投递直接命中缓存，不重跑。
`failed` 不是终态：允许重试，但 `attempts` 会累加，重试次数可审计。
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from . import contracts as C

DDL = """
CREATE TABLE IF NOT EXISTS pipeline_stage (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    mpn_key       TEXT NOT NULL DEFAULT '',
    mpn           TEXT NOT NULL DEFAULT '',
    stage         TEXT NOT NULL,
    stage_version TEXT NOT NULL DEFAULT '',
    idem_key      TEXT NOT NULL UNIQUE,
    status        TEXT NOT NULL DEFAULT 'pending',
    attempts      INTEGER NOT NULL DEFAULT 0,
    artifact      TEXT NOT NULL DEFAULT '',
    detail        TEXT NOT NULL DEFAULT '{}',
    error         TEXT NOT NULL DEFAULT '',
    ms            INTEGER NOT NULL DEFAULT 0,
    started_at    TEXT NOT NULL DEFAULT '',
    finished_at   TEXT NOT NULL DEFAULT '',
    updated_at    TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_pipeline_stage_mpn  ON pipeline_stage(mpn_key, stage);
CREATE INDEX IF NOT EXISTS idx_pipeline_stage_stat ON pipeline_stage(status);
"""


def now() -> str:
    """和 `db.now()` 同一格式（带时区的 ISO）。刻意不 import db —— 见模块头。"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


class StageStateStore:
    """阶段状态的读写口。**一个实例一条连接**，线程安全靠内部锁。

    默认连 `config.DB_PATH`（就是工作台那个库，同一个文件、不同的表），
    测试传 `db_path=tmp/xxx.sqlite3` 即可完全隔离。
    """

    def __init__(self, db_path: Path | str | None = None) -> None:
        self._explicit = db_path is not None
        if db_path is None:
            from .. import config                              # noqa: PLC0415
            db_path = config.DB_PATH
        self.db_path = Path(db_path)
        self._lock = threading.RLock()
        self._c: sqlite3.Connection | None = None

    # -- 连接 -----------------------------------------------------
    def _conn(self) -> sqlite3.Connection:
        if self._c is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            c = sqlite3.connect(str(self.db_path), timeout=30, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("PRAGMA busy_timeout=5000")
            c.executescript(DDL)
            c.commit()
            self._c = c
        return self._c

    def close(self) -> None:
        with self._lock:
            if self._c is not None:
                self._c.close()
                self._c = None

    def __enter__(self) -> "StageStateStore":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- 读 -------------------------------------------------------
    def get(self, idem_key: str) -> dict | None:
        with self._lock:
            r = self._conn().execute(
                "SELECT * FROM pipeline_stage WHERE idem_key=?", (idem_key,)).fetchone()
            return self._row(r)

    def of_mpn(self, mpn_key: str) -> list[dict]:
        with self._lock:
            rows = self._conn().execute(
                "SELECT * FROM pipeline_stage WHERE mpn_key=? ORDER BY id", (mpn_key,)
            ).fetchall()
            return [self._row(r) for r in rows]

    @staticmethod
    def _row(r: sqlite3.Row | None) -> dict | None:
        if r is None:
            return None
        d = dict(r)
        try:
            d["detail"] = json.loads(d.get("detail") or "{}")
        except (json.JSONDecodeError, TypeError):
            d["detail"] = {"_corrupt": d.get("detail")}
        return d

    # -- 幂等判定 -------------------------------------------------
    def cached(self, idem_key: str, *, artifact: str = "") -> dict | None:
        """命中可用缓存时返回那一行，否则 `None`。

        判据有三条，缺一不可：
          1. 状态是成功态（ok / cached）；
          2. 该阶段本应有产物时，产物文件**确实还在**（记录说成功、文件被删了
             是最容易骗过缓存的情形，必须按文件系统核实）；
          3. `failed` / `running` 一律不命中。
        """
        row = self.get(idem_key)
        if not row or not C.is_success(row["status"]):
            return None
        want = artifact or row.get("artifact") or ""
        if want and not Path(want).exists():
            return None
        return row

    # -- 写 -------------------------------------------------------
    def begin(self, *, idem_key: str, stage: str, mpn: str = "", mpn_key: str = "",
              version: str | None = None) -> None:
        """把该键置为 running 并累加尝试次数。"""
        ts = now()
        ver = C.stage_version(stage) if version is None else str(version)
        with self._lock:
            c = self._conn()
            cur = c.execute(
                "UPDATE pipeline_stage SET status=?, attempts=attempts+1, error='', "
                "started_at=?, updated_at=?, stage_version=? WHERE idem_key=?",
                (C.STATUS_RUNNING, ts, ts, ver, idem_key))
            if cur.rowcount == 0:
                c.execute(
                    "INSERT INTO pipeline_stage(mpn_key, mpn, stage, stage_version, idem_key, "
                    "status, attempts, started_at, updated_at) VALUES(?,?,?,?,?,?,1,?,?)",
                    (mpn_key, mpn, stage, ver, idem_key, C.STATUS_RUNNING, ts, ts))
            c.commit()

    def finish(self, idem_key: str, *, status: str, artifact: str = "",
               detail: dict | None = None, error: str = "", ms: int = 0) -> None:
        """落终态（或 failed）。`detail` 整体覆盖，不做合并 —— 免得旧字段阴魂不散。"""
        ts = now()
        payload = json.dumps(detail or {}, ensure_ascii=False, sort_keys=True)
        with self._lock:
            c = self._conn()
            c.execute(
                "UPDATE pipeline_stage SET status=?, artifact=?, detail=?, error=?, ms=?, "
                "finished_at=?, updated_at=? WHERE idem_key=?",
                (status, artifact, payload, (error or "")[:1000], int(ms), ts, ts, idem_key))
            c.commit()

    def record(self, result: C.StageResult, *, mpn: str = "", mpn_key: str = "") -> None:
        """把 `StageResult` 写进去。键已存在则更新，不存在则补插一行终态。"""
        with self._lock:
            if self.get(result.idem_key) is None:
                c = self._conn()
                ts = now()
                c.execute(
                    "INSERT INTO pipeline_stage(mpn_key, mpn, stage, stage_version, idem_key, "
                    "status, attempts, artifact, detail, error, ms, started_at, finished_at, "
                    "updated_at) VALUES(?,?,?,?,?,?,1,?,?,?,?,?,?,?)",
                    (mpn_key, mpn, result.stage, C.stage_version(result.stage),
                     result.idem_key, result.status, result.artifact,
                     json.dumps(result.detail or {}, ensure_ascii=False, sort_keys=True),
                     (result.error or "")[:1000], int(result.ms), ts, ts, ts))
                c.commit()
            else:
                self.finish(result.idem_key, status=result.status, artifact=result.artifact,
                            detail=result.detail, error=result.error, ms=result.ms)

    # -- 汇总 -----------------------------------------------------
    def summary(self, mpn_key: str) -> dict[str, str]:
        """`{stage: status}`，只保留每个阶段最新的一行。"""
        out: dict[str, str] = {}
        for row in self.of_mpn(mpn_key):
            out[row["stage"]] = row["status"]
        return out
