"""五段链路的阶段契约（Phase 1.2 的唯一真源）。

为什么要有这一层
----------------
现在的 fetch / llm / render 三段是 `worker/tasks.py` 里三个独立 task，靠
`dispatch.submit()` 手写接力，中间进度全压在 `item.status` 一个枚举上：

1. 一个 `status` 字段要同时表达「下载到哪了」「LLM 跑没跑」「渲染成没成」。
   失败重试只能整条重跑 —— `pdf_sha256` 明明没变，也要重新下载、重新抽文本。
2. 没有阶段级幂等键。同一件重复投递，贵槽位（llm 队列）会再烧一次。
3. 抽出来的文本没有落盘。事后想复核「模型到底看到了哪些页」，只能重跑
   `select_pages()`；而 `select_pages()` 一旦改版，历史结论就不可复现。

这一层只做三件事：定义阶段名与版本、定义阶段产物的形状、定义幂等键算法。
**不碰数据库连接、不碰任务队列、不 import worker** —— 保证 worker / CLI /
测试三边都能共用，不引入循环依赖。

为什么幂等键要带 `stage_version`
--------------------------------
`{pdf_sha256}:{stage}:{stage_version}`。前两段保证「同一份 PDF 的同一个阶段
只算一次」，第三段是给「阶段实现本身改了」留的逃生门：抽取规则一变，旧键
必须失效，否则新代码会命中旧产物，把一次代码升级伪装成一次缓存命中。

LLM 段还要再叠三层（`llm_idem_key`）：prompt 指纹、模型名、配置指纹。理由同
上 —— 换了 prompt 或换了模型，等于换了一次实验，不能复用旧结果。
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

# ------------------------------------------------------------------ 版本常量

#: 切片文件（`data/slices/*.json`）的 schema 版本。加字段不必升，改语义必须升。
SLICE_SCHEMA_VERSION = 1

#: 文本抽取器的版本标识。`extract_pdf_text` / `select_pages` / 页预算
#: （MAX_PAGES / MAX_CHARS / PAGE_PRIORITY / MANDATORY_PAGE_KEYS）任一变动都必须升。
EXTRACTOR_VERSION = "extract_pdf_text/v1"

#: 默认的切片根目录（相对仓库根）。测试可传 `root=` 覆盖，不写死。
SLICE_SUBDIR = "slices"


# ------------------------------------------------------------------ 阶段名

STAGE_FETCH = "fetch"
STAGE_PREPROCESS = "preprocess"
STAGE_LLM = "llm"
STAGE_AUDIT = "audit"
STAGE_RENDER = "render"

#: 链路的固定顺序。`run_chain()` 按这个元组推进，不按调用方给的顺序。
STAGE_ORDER: tuple[str, ...] = (
    STAGE_FETCH, STAGE_PREPROCESS, STAGE_LLM, STAGE_AUDIT, STAGE_RENDER,
)

#: 给日志/事件表用的中文标签（和 `item.stage` 里现有的措辞保持一致）。
STAGE_LABELS: dict[str, str] = {
    STAGE_FETCH: "采集与下载",
    STAGE_PREPROCESS: "文本切片",
    STAGE_LLM: "模型解析",
    STAGE_AUDIT: "确定性复核",
    STAGE_RENDER: "交付物渲染",
}

#: 每个阶段的实现版本。**改实现就改这里**，后缀是给人看的说明，不参与算法。
STAGE_VERSIONS: dict[str, str] = {
    STAGE_FETCH: "1",
    STAGE_PREPROCESS: "1",
    STAGE_LLM: "1",
    STAGE_AUDIT: "1",
    STAGE_RENDER: "1",
}


# ------------------------------------------------------------------ 阶段状态

STATUS_PENDING = "pending"
STATUS_RUNNING = "running"
STATUS_OK = "ok"
STATUS_CACHED = "cached"
STATUS_SKIPPED = "skipped"
STATUS_FAILED = "failed"
STATUS_BLOCKED = "blocked"

#: 有产物的成功态。`cached` 不是「没跑」，是「这次没跑但产物在」，下游照常推进。
SUCCESS_STATUSES = frozenset({STATUS_OK, STATUS_CACHED})

#: 终态：链路上不会再重试（`failed` 刻意不算终态 —— 失败必须可重试）。
TERMINAL_STATUSES = frozenset({STATUS_OK, STATUS_CACHED, STATUS_SKIPPED, STATUS_BLOCKED})


def is_success(status: str) -> bool:
    return status in SUCCESS_STATUSES


def should_continue(status: str) -> bool:
    """该阶段结束后，链路要不要往下走。

    `skipped` 不继续（User Guide 没有解析价值，别再烧 LLM）；
    `blocked` 不继续（缺前置产物，往下走只会连环报错）。
    """
    return status in SUCCESS_STATUSES


# ------------------------------------------------------------------ 开关

def v2_enabled(env: dict[str, str] | None = None) -> bool:
    """`ICPDF_PIPELINE_V2` 是否打开。默认关闭 —— 灰度前一律走老路径。"""
    e = os.environ if env is None else env
    return str(e.get("ICPDF_PIPELINE_V2", "0")).strip().lower() in {"1", "true", "yes", "on"}


# ------------------------------------------------------------------ 哈希工具

def sha256_text(text: str) -> str:
    """文本指纹。空串也有确定的指纹（e3b0c442...），不是特例。"""
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    """文件指纹。按块读，不把 40MB 手册整个吃进内存。"""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj: Any) -> str:
    """稳定序列化：键排序 + 紧凑分隔符，同一个对象永远同一个字节串。"""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


# ------------------------------------------------------------------ prompt 契约
#
# P1-02 要求「最终 LLM Prompt SHA256 一致」。要做到这一条，prompt 的拼装必须
# 只有一份实现 —— 所以这里不复制 `USER_TMPL` / `SYSTEM_PROMPT` 的文本，而是
# 运行时从 `parse_datasheets` 取。取的是**同一个对象**，不是抄了一份常量。

def prompt_messages(*, mpn: str, pdf_name: str, pages_used: int, pages_total: int,
                    text: str, pd_module: Any = None) -> list[dict]:
    """按 `pipeline.parse_pdf` 的**逐字符相同**方式拼 messages。

    `pdf_name` 必须是 PDF 的文件名（`pdf.name`），不是完整路径 —— 老代码用的是
    `pdf.name`，这里传完整路径会让 prompt 指纹和基线的对不上，而差异只在一个
    目录前缀里，肉眼极难发现。

    `pd_module` 只为测试注入用（可以让抽取模块在没配置 API 的环境里被替换），
    生产路径留空即可。
    """
    pd = pd_module
    if pd is None:
        import parse_datasheets as pd                     # noqa: PLC0415

    return [
        {"role": "system", "content": pd.SYSTEM_PROMPT},
        {"role": "user", "content": pd.USER_TMPL.format(
            mpn=mpn, fname=pdf_name, pages_used=pages_used,
            pages_total=pages_total, text=text)},
    ]


def prompt_sha256(messages: list[dict]) -> str:
    """整条 messages（含 system prompt 与页数元信息）的指纹。

    刻意对整个 list 做哈希，而不是只哈希 `text`：`pages_used/pages_total` 进
    prompt 正文，改了页预算但文本碰巧不变时，只哈希 text 会漏掉这个差异。
    """
    return sha256_text(canonical_json(messages))


def llm_config_fingerprint(pd_module: Any = None) -> str:
    """影响模型输出的配置指纹。

    只收「进了 prompt 或进了调用参数」的项：模型名、温度上限、重试额度、
    prompt 版本号、语言开关。收多了会让缓存天天失效，收少了会拿旧结果充新。
    """
    pd = pd_module
    if pd is None:
        import parse_datasheets as pd                     # noqa: PLC0415
    parts = {
        "model": str(getattr(pd, "MODEL", "")),
        "prompt_version": str(getattr(pd, "PROMPT_VERSION", "")),
        "retry_max_tokens": str(getattr(pd, "RETRY_MAX_TOKENS", "")),
        "langs": list(getattr(pd, "LANGS", []) or []),
        "schema_hint": sha256_text(str(getattr(pd, "SCHEMA_HINT", ""))),
    }
    return sha256_text(canonical_json(parts))


# ------------------------------------------------------------------ 幂等键

def stage_version(stage: str) -> str:
    return STAGE_VERSIONS.get(stage, "0")


def idem_key(pdf_sha256: str, stage: str, *, version: str | None = None,
             extra: Iterable[str] = ()) -> str:
    """`{pdf_sha256}:{stage}:{stage_version}[:extra...]`。

    `pdf_sha256` 缺失时用 `-` 占位而不是抛异常：fetch 阶段在下载完成前
    本来就没有哈希，这时键退化成 `-:fetch:1`，只用于「同名同件别重复下」，
    精度低但不会把链路卡死。真正带产物的阶段（preprocess 及以后）在调用前
    必须已经拿到哈希，那由 `Ctx.require_sha256()` 守。
    """
    ver = stage_version(stage) if version is None else str(version)
    bits = [pdf_sha256 or "-", stage, ver]
    bits.extend(str(x) for x in extra if str(x))
    return ":".join(bits)


def llm_idem_key(pdf_sha256: str, prompt_sha: str, model: str, config_fp: str) -> str:
    """LLM 段的键：哈希 + 阶段 + 版本 + prompt 指纹 + 模型 + 配置指纹。

    六段任何一段变化都会换键 —— 这正是「换实验不复用旧结果」的含义。
    """
    return idem_key(pdf_sha256, STAGE_LLM,
                    extra=(prompt_sha, model or "-", config_fp or "-"))


# ------------------------------------------------------------------ 阶段结果

@dataclass(frozen=True)
class StageResult:
    """一个阶段跑完的结论。不可变 —— 免得下游就地改状态，把账改乱。"""

    stage: str
    status: str
    idem_key: str = ""
    artifact: str = ""          # 产物路径；空串表示该阶段本就没有文件产物
    error: str = ""
    ms: int = 0
    detail: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return is_success(self.status)

    @property
    def stopped(self) -> bool:
        """链路是否应当在此停下。"""
        return not should_continue(self.status)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def __str__(self) -> str:                                  # 便于日志
        tail = f" err={self.error}" if self.error else ""
        return f"[{self.stage}] {self.status} {self.ms}ms{tail}"


# ------------------------------------------------------------------ 切片

#: 切片文件里**必须**有的键。缺任何一个都视为文件损坏，不做「尽力猜」。
SLICE_REQUIRED_KEYS: tuple[str, ...] = (
    "schema_version", "mpn", "pdf_sha256", "pdf_path", "text",
    "pages_used", "pages_total", "has_text", "is_datasheet",
    "extractor_version", "created_at",
)


@dataclass(frozen=True)
class Slice:
    """一次文本抽取的完整留档。

    落盘后，这条记录就是「模型当时看到了什么」的唯一证据。它必须自证：
    带 `pdf_sha256`（原文是哪一份）、`extractor_version`（哪版抽取器）、
    `pages_used/pages_total`（页预算花了多少）。三者齐了，历史结论才可复现。

    `selected_pages` 目前恒为空列表：`extract_pdf_text()` 只返回
    `(text, total, used, has_text)`，不返回页码清单。要拿到页码得重写
    `select_pages()`，属于 Phase 2 的 `scan_tables()` 范畴；本阶段按约束
    「不实现生产 scan_tables」只留字段占位，不假装有数据。
    """

    mpn: str
    pdf_sha256: str
    pdf_path: str
    text: str
    pages_used: int = 0
    pages_total: int = 0
    has_text: bool = True
    is_datasheet: bool = True
    extractor_version: str = EXTRACTOR_VERSION
    selected_pages: list[int] = field(default_factory=list)
    created_at: str = ""
    schema_version: int = SLICE_SCHEMA_VERSION

    # -- 派生量 ---------------------------------------------------
    @property
    def text_sha256(self) -> str:
        return sha256_text(self.text)

    @property
    def pdf_name(self) -> str:
        """`pdf_path` 的文件名。prompt 里的 `fname` 用它，不是完整路径。"""
        return Path(self.pdf_path).name

    @property
    def skip_reason(self) -> str:
        """不可解析时给人类看的原因；能解析时是空串。"""
        if not self.has_text:
            return "PDF_UNREADABLE: 无文本层（需 OCR）"
        if not self.is_datasheet:
            return "NOT_A_DATASHEET: 无参数表特征词（User Guide / Quick Start），跳过 LLM"
        return ""

    # -- 序列化 ---------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Any) -> "Slice":
        if not isinstance(data, dict):
            raise ValueError("切片必须是 JSON 对象")
        missing = [k for k in SLICE_REQUIRED_KEYS if k not in data]
        if missing:
            raise ValueError("切片缺字段: " + ", ".join(missing))
        ver = data.get("schema_version")
        if int(ver) != SLICE_SCHEMA_VERSION:
            raise ValueError(f"切片 schema_version={ver}，当前只认 {SLICE_SCHEMA_VERSION}")
        return cls(
            mpn=str(data["mpn"]),
            pdf_sha256=str(data["pdf_sha256"]),
            pdf_path=str(data["pdf_path"]),
            text=data["text"] if isinstance(data["text"], str) else str(data["text"]),
            pages_used=int(data.get("pages_used") or 0),
            pages_total=int(data.get("pages_total") or 0),
            has_text=bool(data.get("has_text")),
            is_datasheet=bool(data.get("is_datasheet")),
            extractor_version=str(data.get("extractor_version") or ""),
            selected_pages=[int(i) for i in (data.get("selected_pages") or [])],
            created_at=str(data.get("created_at") or ""),
            schema_version=int(ver),
        )

    def stale(self, *, extractor_version: str | None = None) -> bool:
        """是否该重建。抽取器换版 = 必须重建，没有讨论余地。"""
        want = EXTRACTOR_VERSION if extractor_version is None else extractor_version
        return self.extractor_version != want


# ---------------------------------------------------------------- 状态映射
def llm_status_to_stage(st: str) -> str:
    """解析层 `rec["status"]` -> 阶段状态。

    **白名单映射，不是黑名单**：只有明确列出的值才算通过，其余一律 failed。
    这一点很关键 —— `parsed_core_fail`（JSON 可解析、结构合格、但核心字段
    有硬错误）必须落进 failed，不能被当成 ok 继续往下游走。
    """
    # `thin_accepted` 单独列进来，理由和 `parsed_core_fail` 相反：
    # 它是**解析层明确愿意收**的件（板卡/UG 无电气表，按 ICPDF_ACCEPT_THIN
    # 放行），只是不愿意自称 ok。门禁集合与改动前**完全一致**，不增不减：
    # 标签变诚实，放行范围不动。若把它也丢进 failed，等于借这次修复
    # 顺手收紧了 ACCEPT_THIN，那不是本轮授权范围。
    return {STATUS_OK: STATUS_OK,
            "thin_accepted": STATUS_OK,
            "skipped": STATUS_SKIPPED}.get(str(st or ""), STATUS_FAILED)
