"""PDF 生命周期解耦（Phase 1）：把一条「PDF → 交付物」的长流程拆成五段。

    FETCH ──> PREPROCESS ──> LLM ──> AUDIT ──> RENDER

为什么拆
--------
旧实现是 `worker/tasks.py` 里三个 task 靠 `dispatch.submit()` 手写接力，中间
进度全压在 `item.status` 一个枚举上，导致三件具体的事做不了：

1. **不能重试单段。** LLM 挂了要从下载重来，`pdf_sha256` 没变也照下不误。
2. **不能防重复烧钱。** 没有阶段级幂等键，重复投递会把 LLM 槽位再烧一次。
3. **不能复现历史。** 抽出来的文本没留档，`select_pages()` 一改版，
   「当时模型看到了哪 47KB」就永久不可考。

本包提供的是**契约与实现**，不是接线。`ICPDF_PIPELINE_V2` 默认关闭，
生产仍走老的 `fetch_item / llm_item / render_item`；灰度前只跑
`stages.shadow_compare()` 做新旧对照，新链路不接管任何正式状态。

模块
----
* `contracts`    —— 阶段名/版本/状态/幂等键/切片与结果的形状。无副作用，可随便 import。
* `stage_state`  —— `pipeline_stage` 表：每个阶段跑了没、产出什么、试了几次。
* `slice_store`  —— `data/slices/*.json` 读写：原子写、旧版留档、脏文件不删。
* `preprocess`   —— PDF → 切片，唯一一处「把 PDF 变成文本」的入口。
* `stages`       —— 五段实现 + `run_chain()` + `shadow_compare()`。

刻意没做的事
------------
* 没有 `scan_tables()`：表格坐标扫描是 Phase 2 的事。切片里的
  `selected_pages` 恒为空列表，字段占位但不假装有数据。
* 没有改 `app/db.py` 的 DDL：阶段表自带 `ensure_schema()`，老环境不受影响。
* 没有删/改/清理任何既有脏文件与审计产物（V11 那 22 项原样不动）。
"""
from __future__ import annotations

from . import contracts, preprocess, slice_store, stage_state, stages
from .contracts import (                                    # noqa: F401
    STAGE_AUDIT, STAGE_FETCH, STAGE_LLM, STAGE_ORDER, STAGE_PREPROCESS,
    STAGE_RENDER, STAGE_VERSIONS, STATUS_BLOCKED, STATUS_CACHED, STATUS_FAILED,
    STATUS_OK, STATUS_SKIPPED, Slice, StageResult, idem_key, v2_enabled,
)
from .stage_state import StageStateStore                    # noqa: F401
from .stages import Ctx, run_chain, shadow_compare          # noqa: F401

__all__ = [
    "contracts", "stage_state", "slice_store", "preprocess", "stages",
    "Ctx", "run_chain", "shadow_compare", "StageStateStore",
    "Slice", "StageResult", "idem_key", "v2_enabled",
    "STAGE_FETCH", "STAGE_PREPROCESS", "STAGE_LLM", "STAGE_AUDIT", "STAGE_RENDER",
    "STAGE_ORDER", "STAGE_VERSIONS",
    "STATUS_OK", "STATUS_CACHED", "STATUS_SKIPPED", "STATUS_FAILED", "STATUS_BLOCKED",
]
