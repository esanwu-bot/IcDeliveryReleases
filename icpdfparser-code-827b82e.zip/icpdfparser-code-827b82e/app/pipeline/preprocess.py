"""PREPROCESS 阶段：PDF → 文本切片（落盘留档）。

本阶段做的事，就是把 `pipeline.parse_pdf()` 里那两行内联操作拆出来单独可缓存：

    text, total, used, has_text = pd.extract_pdf_text(pdf)
    pd.is_datasheet(text)

拆出来的理由不是「代码更好看」，是**可复现**：`select_pages()` 的页预算、
`PAGE_PRIORITY` 词表、`MAX_PAGES_OVERRIDE` 白名单任一变动，同一份 PDF 抽出来
的文本就变了。文本没留档时，历史结论只能「重跑试试」；留档之后，能直接说
「当时模型看到的是这 47,382 个字符」。

三条不能碰的红线（否则 P1-01/P1-03 必挂）
-----------------------------------------
1. **必须无参数调用** `pd.extract_pdf_text(path)`。传 `max_pages=MAX_PAGES`
   会让 `select_pages()` 里的 `max_pages == MAX_PAGES` 自适应分支照样触发，
   但传别的值就绕过了「百页级手册自动放宽」的逻辑 —— 那正是 228 件实测逼
   出来的行为。结论：一个关键字都别传，让它自己走默认。
2. **必须用 `pd.is_datasheet`**，不能在这里抄一份 `DS_MARKERS`。抄一份就多
   一个会漂移的真源，词表一改两边就对不上（P1-03 要的是逐件一致）。
3. **必须用 `pd.sha256`**，不是自己写个 hasher。它和 `parse_pdf` 写进
   `metadata.pdf_hash` 的是同一个函数，切片里的哈希因此能和 JSON 里的对上。

按约束「不实现生产 scan_tables()」：本阶段**不做**任何表格坐标扫描、不存
表结构、不猜列语义。切片的 `selected_pages` 恒为空列表，占位不假装有数据。
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from . import contracts as C
from . import slice_store


def _pd(pd_module: Any = None):
    if pd_module is not None:
        return pd_module
    import parse_datasheets as pd                              # noqa: PLC0415
    return pd


def extract_text(pdf_path: Path, *, pd_module: Any = None) -> tuple[str, int, int, bool]:
    """原样调用抽取器，返回 `(text, total, used, has_text)`。

    这是全链路唯一一处「把 PDF 变成文本」的入口。stage 层、CLI、对照测试都
    走这里，保证不会有第二条路抽出不一样的文本。
    """
    pd = _pd(pd_module)
    return pd.extract_pdf_text(Path(pdf_path))


def build_slice(pdf_path: Path, mpn: str, *, pdf_sha256: str | None = None,
                pd_module: Any = None, created_at: str | None = None) -> C.Slice:
    """抽一次文本，包成 `Slice`（**不落盘**，落盘交给 `slice_store`）。"""
    pd = _pd(pd_module)
    pdf_path = Path(pdf_path)
    text, total, used, has_text = extract_text(pdf_path, pd_module=pd)
    sha = pdf_sha256 or pd.sha256(pdf_path)
    return C.Slice(
        mpn=mpn,
        pdf_sha256=sha,
        pdf_path=str(pdf_path),
        text=text,
        pages_used=int(used),
        pages_total=int(total),
        has_text=bool(has_text),
        is_datasheet=bool(pd.is_datasheet(text)),
        extractor_version=C.EXTRACTOR_VERSION,
        created_at=created_at or _now(),
    )


def _now() -> str:
    from datetime import datetime                                   # noqa: PLC0415
    return datetime.now().astimezone().isoformat(timespec="seconds")


def load_or_build(pdf_path: Path, mpn: str, *, root: Path | None = None,
                  pdf_sha256: str | None = None, force: bool = False,
                  pd_module: Any = None) -> tuple[C.Slice, bool]:
    """取切片：命中就用现成的，否则抽一次并落盘。

    返回 `(slice, reused)`。`reused=True` 表示这次没读 PDF —— 这正是 P1-07
    「失败重试不重复抽取」要的证据：重试时 `reused` 必须是 True。

    命中条件（全部满足才算）：
      * 文件在、能解析（损坏 → 重建，旧文件被 `slice_store` 改成 `.bak` 留档）；
      * `pdf_sha256` 与本次一致（PDF 换了修订，切片必须作废）；
      * `extractor_version` 与当前一致（抽取器换版，切片必须作废）。
    """
    pdf_path = Path(pdf_path)
    pd = _pd(pd_module)
    sha = pdf_sha256 or pd.sha256(pdf_path)

    if not force:
        old = slice_store.find_slice(mpn, sha, root=root)
        if old is not None and not old.stale() and old.pdf_sha256 == sha:
            return old, True

    slc = build_slice(pdf_path, mpn, pdf_sha256=sha, pd_module=pd)
    slice_store.write_slice(slc, root=root)
    return slc, False


def summarize(slc: C.Slice) -> dict[str, Any]:
    """给事件日志/审计用的短摘要。**不含全文** —— 全文在切片文件里，别塞进 DB。"""
    return {
        "text_sha256": slc.text_sha256,
        "chars": len(slc.text),
        "pages_used": slc.pages_used,
        "pages_total": slc.pages_total,
        "has_text": slc.has_text,
        "is_datasheet": slc.is_datasheet,
        "extractor_version": slc.extractor_version,
    }


def timed_extract(pdf_path: Path, *, pd_module: Any = None) -> tuple[tuple, int]:
    """带耗时的抽取，供 stage 层填 `StageResult.ms`。"""
    t0 = time.perf_counter()
    res = extract_text(pdf_path, pd_module=pd_module)
    return res, int((time.perf_counter() - t0) * 1000)
