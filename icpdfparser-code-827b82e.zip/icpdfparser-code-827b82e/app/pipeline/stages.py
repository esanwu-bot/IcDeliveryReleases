"""五段链路的阶段实现：FETCH → PREPROCESS → LLM → AUDIT → RENDER。

**本模块不改生产接线。** `worker/tasks.py` 里的 `fetch_item` / `llm_item` /
`render_item` 行为一字未动，新任务是否走这里由 `ICPDF_PIPELINE_V2` 决定，默认关。
灰度前只做 Shadow Comparison（本文件末尾 `shadow_compare()`），新链路**不接管
任何正式状态**。

阶段职责与「谁不能做什么」
------------------------
================  ============================================  ==========================
阶段              产物                                            绝对不碰
================  ============================================  ==========================
fetch             `data/pdfs/*.pdf` + `pdf_sha256`                 不解析、不调 LLM
preprocess        `data/slices/*.json`（文本留档）                  不碰 PDF 坐标、不做 scan_tables
llm               `data/parsed/*.json`                             不写 item 状态、不渲染
audit             findings 列表（只读）                              **不写回 JSON**（write 恒 False）
render            txt/alt/seo/symbol + item.status                  不在 shadow 里跑
================  ============================================  ==========================

关于 fetch 的幂等键为何不用 `pdf_sha256`
----------------------------------------
`{pdf_sha256}:fetch:1` 在下载完成前无法构造 —— 那时还没有哈希。硬套会让键退化成
`-:fetch:1`，全站共用一个键，比没有幂等还糟（一件下载成功，其余全部误判命中）。
因此 fetch 阶段以 `mpn_key` 作为身份维度：`idem_key(mpn_key, "fetch")`。这是本
设计里唯一一处偏离「哈希做主键」的地方，写在这里以免后来人以为是笔误。
从 preprocess 开始，键一律由 `pdf_sha256` 派生 —— 那时哈希已在手。
"""
from __future__ import annotations

import json
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from . import contracts as C
from . import preprocess as PP
from . import slice_store
from .stage_state import StageStateStore


# ------------------------------------------------------------------ 上下文

@dataclass
class Ctx:
    """一次链路调用的全部输入。

    显式传参，不用全局状态：影子对照要同时跑新旧两条路，任何隐式全局都会让
    两条路互相污染（这正是「新链路不能接管正式状态」的技术含义）。
    """

    mpn: str
    mpn_key: str = ""
    pdf_path: Path | None = None
    pdf_sha256: str = ""
    url: str = ""
    item: dict | None = None            # 老路径的 item 行；fetch/render 需要它
    slice_root: Path | None = None       # 切片目录，None = data/slices
    out_dir: Path | None = None          # JSON 落盘目录，None = data/parsed
    shadow: bool = False                 # True 时禁止一切正式写操作
    force: bool = False                  # 忽略缓存（人工重跑用）
    state: StageStateStore | None = None

    # 阶段间传递（由链路填充，也可由调用方预置以跳过上游）
    slice: C.Slice | None = None
    json_path: str = ""
    doc: dict | None = None
    trace: list[C.StageResult] = field(default_factory=list)

    def store(self) -> StageStateStore:
        """惰性拿状态库。shadow 模式用一次性临时库，**不写工作台库**。"""
        if self.state is None:
            if self.shadow:
                tmp = Path(tempfile.mkdtemp(prefix="icpdf_shadow_state_"))
                self.state = StageStateStore(tmp / "shadow.sqlite3")
            else:
                self.state = StageStateStore()
        return self.state

    def require_pdf(self) -> Path:
        if not self.pdf_path or not Path(self.pdf_path).exists():
            raise FileNotFoundError("缺少 PDF（fetch 阶段未完成或文件已丢失）")
        return Path(self.pdf_path)


# ------------------------------------------------------------------ 工具

def _pd(pd_module: Any = None):
    if pd_module is not None:
        return pd_module
    import parse_datasheets as pd                              # noqa: PLC0415
    return pd


def _ms(t0: float) -> int:
    return int((time.perf_counter() - t0) * 1000)


def _guard(fn: Callable[[], C.StageResult], stage: str, key: str,
           t0: float) -> C.StageResult:
    """兜异常：阶段内部炸了要变成一条 FAILED 记录，不能让异常穿出去把链路打断在
    半路 —— 半路的链路最容易留下「状态说 running、实际早死了」的僵尸行。"""
    try:
        return fn()
    except Exception as e:                                     # noqa: BLE001
        return C.StageResult(stage=stage, status=C.STATUS_FAILED, idem_key=key,
                             error=f"{type(e).__name__}: {e}"[:300], ms=_ms(t0))


# ------------------------------------------------------------------ FETCH

def stage_fetch(ctx: Ctx, *, fetch_fn: Callable[..., dict] | None = None,
                pd_module: Any = None) -> C.StageResult:
    """采集 + 下载。复用已有 PDF，否则调用老函数 `pipeline.fetch_stage`。

    Phase 1.2 **不重写下载逻辑**：`collector.fetch_datasheet()` 里有各平台的重试、
    反爬、UA、以及一堆用真实失败换来的坑。在阶段层重写一遍等于把那些坑再踩一遍。
    这里只负责：判定能不能复用、登记幂等键、把结果翻译成 `StageResult`。
    """
    t0 = time.perf_counter()
    subject = ctx.mpn_key or ctx.mpn or "-"
    key = C.idem_key(subject, C.STAGE_FETCH)

    pdf = Path(ctx.pdf_path) if ctx.pdf_path else None
    if pdf and pdf.exists() and pdf.stat().st_size > 0:
        pd = _pd(pd_module)
        sha = ctx.pdf_sha256 or pd.sha256(pdf)
        ctx.pdf_path, ctx.pdf_sha256 = pdf, sha
        res = C.StageResult(stage=C.STAGE_FETCH, status=C.STATUS_CACHED, idem_key=key,
                            artifact=str(pdf), ms=_ms(t0),
                            detail={"pdf_sha256": sha, "bytes": pdf.stat().st_size})
        # 不落库：缓存命中不是一次「尝试」。写进去会让 attempts 虚增，
        # 而 attempts 的用途恰恰是「这份 PDF 到底下过几次」——虚增等于账做假。
        return res

    if fetch_fn is None:
        from ..services import pipeline as PLATFORM               # noqa: PLC0415
        fetch_fn = PLATFORM.fetch_stage

    if ctx.item is None:
        return C.StageResult(stage=C.STAGE_FETCH, status=C.STATUS_BLOCKED, idem_key=key,
                             error="缺少 item 行，无法执行下载", ms=_ms(t0))

    ctx.store().begin(idem_key=key, stage=C.STAGE_FETCH, mpn=ctx.mpn, mpn_key=ctx.mpn_key)

    def _run() -> C.StageResult:
        got = fetch_fn(ctx.item, force=ctx.force)                 # type: ignore[arg-type]
        if got.get("skipped"):
            return C.StageResult(stage=C.STAGE_FETCH, status=C.STATUS_SKIPPED, idem_key=key,
                                 error=str(got.get("reason") or "already_parsed"),
                                 ms=_ms(t0), detail=got)
        if not got.get("ok"):
            return C.StageResult(stage=C.STAGE_FETCH, status=C.STATUS_FAILED, idem_key=key,
                                 error=str(got.get("reason") or got.get("error") or "fetch_failed"),
                                 ms=_ms(t0), detail=got)
        pdf = Path(got["pdf"])
        pd = _pd(pd_module)
        sha = pd.sha256(pdf)
        ctx.pdf_path, ctx.pdf_sha256, ctx.url = pdf, sha, got.get("url", ctx.url)
        return C.StageResult(stage=C.STAGE_FETCH, status=C.STATUS_OK, idem_key=key,
                             artifact=str(pdf), ms=_ms(t0),
                             detail={"pdf_sha256": sha, "url": ctx.url,
                                     "bytes": pdf.stat().st_size})

    res = _guard(_run, C.STAGE_FETCH, key, t0)
    ctx.store().record(res, mpn=ctx.mpn, mpn_key=ctx.mpn_key)
    return res


# ------------------------------------------------------------------ PREPROCESS

def stage_preprocess(ctx: Ctx, *, pd_module: Any = None) -> C.StageResult:
    """PDF → 切片。命中缓存就不读 PDF（P1-07：重试不重复抽取）。"""
    t0 = time.perf_counter()
    pd = _pd(pd_module)

    try:
        pdf = ctx.require_pdf()
    except FileNotFoundError as e:
        return C.StageResult(stage=C.STAGE_PREPROCESS, status=C.STATUS_BLOCKED,
                             error=str(e), ms=_ms(t0))

    sha = ctx.pdf_sha256 or pd.sha256(pdf)
    ctx.pdf_sha256 = sha
    key = C.idem_key(sha, C.STAGE_PREPROCESS)
    target = slice_store.slice_path(ctx.mpn, sha, root=ctx.slice_root)

    # 缓存判据：状态成功 + 文件在 + 版本一致 + 哈希一致。四条任一不满足就重抽。
    hit = None if ctx.force else ctx.store().cached(key, artifact=str(target))
    if hit:
        slc = slice_store.read_slice(target)
        if slc is not None and not slc.stale() and slc.pdf_sha256 == sha:
            ctx.slice = slc
            return C.StageResult(stage=C.STAGE_PREPROCESS, status=C.STATUS_CACHED,
                                 idem_key=key, artifact=str(target), ms=_ms(t0),
                                 detail=PP.summarize(slc))

    ctx.store().begin(idem_key=key, stage=C.STAGE_PREPROCESS,
                      mpn=ctx.mpn, mpn_key=ctx.mpn_key)

    def _run() -> C.StageResult:
        slc, reused = PP.load_or_build(pdf, ctx.mpn, root=ctx.slice_root,
                                       pdf_sha256=sha, force=ctx.force, pd_module=pd)
        ctx.slice = slc
        detail = PP.summarize(slc)
        detail["reused"] = reused

        # 无文本层：不是「这次失败下次可能成功」，是「需要 OCR 这件外部干预」，
        # 因此记 blocked 而不是 failed —— failed 会被重试策略反复捡起来空转。
        if not slc.has_text:
            return C.StageResult(stage=C.STAGE_PREPROCESS, status=C.STATUS_BLOCKED,
                                 idem_key=key, artifact=str(target), ms=_ms(t0),
                                 error=slc.skip_reason, detail=detail)
        # 不是 datasheet：老路径把 item 标 skipped 且不调 LLM，这里保持同一结论。
        if not slc.is_datasheet:
            return C.StageResult(stage=C.STAGE_PREPROCESS, status=C.STATUS_SKIPPED,
                                 idem_key=key, artifact=str(target), ms=_ms(t0),
                                 error=slc.skip_reason, detail=detail)
        return C.StageResult(stage=C.STAGE_PREPROCESS, status=C.STATUS_OK,
                             idem_key=key, artifact=str(target), ms=_ms(t0),
                             detail=detail)

    res = _guard(_run, C.STAGE_PREPROCESS, key, t0)
    ctx.store().record(res, mpn=ctx.mpn, mpn_key=ctx.mpn_key)
    return res


# ------------------------------------------------------------------ LLM

def llm_identity(ctx: Ctx, *, pd_module: Any = None) -> tuple[str, list[dict], str]:
    """算出 LLM 段的幂等键 + 要发出去的 messages。

    单独抽成公开函数，是为了让对照测试能**只算键和 prompt、不真的调模型**就能
    验证 P1-02 —— 花在断言 prompt 指纹上的钱，一分都不该是 API 费。
    """
    if ctx.slice is None:
        raise ValueError("LLM 阶段需要切片（preprocess 未完成）")
    pd = _pd(pd_module)
    msgs = C.prompt_messages(mpn=ctx.mpn, pdf_name=ctx.slice.pdf_name,
                             pages_used=ctx.slice.pages_used,
                             pages_total=ctx.slice.pages_total,
                             text=ctx.slice.text, pd_module=pd)
    cfg = C.llm_config_fingerprint(pd)
    model = str(pd.model_for("parse") or getattr(pd, "MODEL", ""))
    key = C.llm_idem_key(ctx.slice.pdf_sha256, C.prompt_sha256(msgs), model, cfg)
    return key, msgs, model


def _record_llm_calls(ctx: Ctx, got: dict) -> None:
    """把这次阶段内**真实发生**的模型调用逐条落进 `llm_usage`。

    Phase 1.7 D2（2026-11-03）：V2 的 `stage_llm` 不落账，灰度里 token 指标
    完全不可观测。这里**复用** `app.services.pipeline._log_calls`（与 Legacy
    同一份实现、同一张表），不另写一份记账：

    * 一次真实调用一条记录 —— `llm_calls` 由 `parse_pdf` 的 `call()` 逐次追加；
    * 缓存命中走 `stage_llm` 的早返回，根本不进 `_run`，不会产生假记录；
    * 重试 / 多次调用按 `attempt` 原样保留；失败调用带 `ok=False` + `error`。
    """
    calls = [c for c in (got.get("llm_calls") or []) if isinstance(c, dict)]
    if not calls:
        return
    item = getattr(ctx, "item", None) or {}
    try:
        from ..services import pipeline as PLATFORM                # noqa: PLC0415
        PLATFORM._log_calls(item.get("id"), str(getattr(ctx, "mpn_key", "") or ""), calls)
    except Exception:                                            # noqa: BLE001
        # 记账失败不能拖垮解析；`_log_calls` 内部对每条记录另有兜底与事件留痕。
        pass


def stage_llm(ctx: Ctx, *, llm_fn: Callable[..., dict] | None = None,
              pd_module: Any = None) -> C.StageResult:
    """调模型出 JSON。**复用 `pipeline.parse_pdf()`**，不另写一套 prompt/修复/校验。

    `parse_pdf(text=...)` 是本次唯一的接缝（见该函数 docstring）：把切片文本喂
    进去，让抽取在外、模型在内。这样 P1-02「prompt 指纹一致」不是靠人肉比对维持
    的，而是**同一条代码路径**自然成立。
    """
    t0 = time.perf_counter()

    if ctx.slice is None:
        return C.StageResult(stage=C.STAGE_LLM, status=C.STATUS_BLOCKED,
                             error="缺少切片（preprocess 未完成）", ms=_ms(t0))
    if ctx.slice.skip_reason:
        return C.StageResult(stage=C.STAGE_LLM, status=C.STATUS_SKIPPED,
                             error=ctx.slice.skip_reason, ms=_ms(t0))

    try:
        key, _msgs, model = llm_identity(ctx, pd_module=pd_module)
    except Exception as e:                                     # noqa: BLE001
        return C.StageResult(stage=C.STAGE_LLM, status=C.STATUS_FAILED,
                             error=f"{type(e).__name__}: {e}"[:300], ms=_ms(t0))

    # 重复投递不重复调模型（P1-08）：命中缓存直接返回既有 JSON 路径。
    hit = None if ctx.force else ctx.store().cached(key)
    if hit:
        ctx.json_path = hit.get("artifact") or ""
        if ctx.json_path and Path(ctx.json_path).exists():
            try:
                ctx.doc = json.loads(Path(ctx.json_path).read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                ctx.doc = None
            return C.StageResult(stage=C.STAGE_LLM, status=C.STATUS_CACHED, idem_key=key,
                                 artifact=ctx.json_path, ms=_ms(t0),
                                 detail={"model": model, "prompt_sha256": key.split(":")[3]})

    if llm_fn is None:
        from ..services import pipeline as PLATFORM               # noqa: PLC0415
        llm_fn = PLATFORM.parse_pdf

    ctx.store().begin(idem_key=key, stage=C.STAGE_LLM, mpn=ctx.mpn, mpn_key=ctx.mpn_key)

    def _run() -> C.StageResult:
        pdf = ctx.require_pdf()
        got = llm_fn(pdf, ctx.mpn, ctx.url,
                     text=ctx.slice.text,                         # type: ignore[union-attr]
                     pages_used=ctx.slice.pages_used,              # type: ignore[union-attr]
                     pages_total=ctx.slice.pages_total,            # type: ignore[union-attr]
                     out_dir=ctx.out_dir)
        _record_llm_calls(ctx, got)
        st = str(got.get("status") or "failed")
        ctx.json_path = str(got.get("json_path") or "")
        ctx.doc = got.get("doc")
        detail = {
            "model": model,
            "prompt_sha256": key.split(":")[3],
            "confidence": got.get("confidence"),
            "electrical_rows": got.get("electrical"),
            "pins": got.get("pins"),
            "llm_calls": len(got.get("llm_calls") or []),
        }
        # 白名单映射：`parsed_core_fail` 必须落进 failed，不能被当成 ok。
        mapped = C.llm_status_to_stage(st)
        return C.StageResult(stage=C.STAGE_LLM, status=mapped, idem_key=key,
                             artifact=ctx.json_path, error=str(got.get("error") or "")[:300],
                             ms=int(got.get("ms") or _ms(t0)), detail=detail)

    res = _guard(_run, C.STAGE_LLM, key, t0)
    ctx.store().record(res, mpn=ctx.mpn, mpn_key=ctx.mpn_key)
    return res


# ------------------------------------------------------------------ AUDIT

def stage_audit(ctx: Ctx, *, audit_fn: Callable[..., dict] | None = None) -> C.StageResult:
    """确定性表格复核。**只取证，不改 JSON，不改阶段状态为失败。**

    `write=True`（备份后写回补丁）**永远不在链路里触发**：补丁必须人工/QC 流程
    显式发起，链路自动打补丁的话，「模型输出」和「机检修正后」两种 JSON 就混在
    一起，事后无法区分哪条结论是模型给的、哪条是规则改的。
    """
    t0 = time.perf_counter()
    key = C.idem_key(ctx.pdf_sha256, C.STAGE_AUDIT)

    doc = ctx.doc
    json_path = ctx.json_path
    if doc is None and json_path and Path(json_path).exists():
        try:
            doc = json.loads(Path(json_path).read_text(encoding="utf-8"))
            ctx.doc = doc
        except (OSError, json.JSONDecodeError) as e:
            return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_BLOCKED,
                                 idem_key=key, error=f"JSON 不可读: {e}"[:200], ms=_ms(t0))
    if doc is None:
        return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_BLOCKED, idem_key=key,
                             error="缺少 JSON（LLM 阶段未完成）", ms=_ms(t0))
    if not ctx.pdf_path or not Path(ctx.pdf_path).exists():
        # audit 要靠 PDF 裁表核对，没有原件的审计是凭空断言 —— 直接 blocked。
        return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_BLOCKED, idem_key=key,
                             error="缺少 PDF（审计需要原件核对）", ms=_ms(t0))

    hit = None if ctx.force else ctx.store().cached(key)
    if hit:
        return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_CACHED, idem_key=key,
                             ms=_ms(t0), detail=hit.get("detail") or {})

    if audit_fn is None:
        def _default_audit(_doc: dict, _pdf: str, **_kw) -> dict:  # noqa: ANN001
            from qc import table_audit as TA                     # noqa: PLC0415
            return TA.audit_json(_doc, _pdf, write=False,
                                 requested=ctx.mpn, src_json=json_path or None)
        audit_fn = _default_audit

    ctx.store().begin(idem_key=key, stage=C.STAGE_AUDIT, mpn=ctx.mpn, mpn_key=ctx.mpn_key)

    def _run() -> C.StageResult:
        got = audit_fn(doc, str(ctx.pdf_path), write=False)       # type: ignore[arg-type]
        findings = got.get("findings") or []
        by_kind: dict[str, int] = {}
        for f in findings:
            k = str((f or {}).get("kind") or "unknown")
            by_kind[k] = by_kind.get(k, 0) + 1
        return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_OK, idem_key=key,
                             ms=_ms(t0),
                             detail={"findings": len(findings), "by_kind": by_kind,
                                     "write": False})

    res = _guard(_run, C.STAGE_AUDIT, key, t0)
    ctx.store().record(res, mpn=ctx.mpn, mpn_key=ctx.mpn_key)
    return res


# ------------------------------------------------------------------ RENDER

def render_gate(doc: dict, mpn: str, *, pd_module: Any | None = None) -> str | None:
    """交付前准入复核：返回阻断原因；None = 放行。

    为什么交付侧还要再判一次：`stage_render` 有条缓存捷径 —— 缓存命中直接
    返回 CACHED，`render_item_v2` 再把它写成 `done`。在闸门上线之前，
    「当初渲染成功过」与「现在仍然合格」是等价的；上线之后不再等价：
    data/parsed 里躺着一批闸门之前产出的 JSON，它们可能带着核心硬错误。

    判据复用解析入口同一个 `check_core` / `check_acceptance`，不另写一套：
      * 带 `accept_status=parsed_core_fail` 的 → 直接拒（当初就没过核心闸）；
      * 带 `accept_status=thin_accepted` 的 → 放行（解析层已明确收下的芯片
        低规格件，交付侧不再二次收紧，否则等于偷偷改放行范围）；
      * **没有** accept_status 的旧产物 → 现场重算 core_errs，有错就拒。
    这里拿不到 PDF 正文，所以不做薄件判定；那件事已经发生在解析入口。
    """
    try:
        if pd_module is None:
            import parse_datasheets as pd_module             # noqa: PLC0415
        from qc import deterministic_extract as DE           # noqa: PLC0415
    except Exception:                                        # noqa: BLE001
        # 依赖不可用时不阻断交付，但也绝不假装通过：把原因留给调用方记 detail。
        return None
    stamp = str((doc.get("metadata") or {}).get("accept_status") or "")
    if stamp == getattr(pd_module, "STATUS_PARSED_CORE_FAIL", "parsed_core_fail"):
        return "parsed_core_fail: 核心字段硬错误，不得进入交付"
    if stamp == getattr(pd_module, "STATUS_THIN_ACCEPTED", "thin_accepted"):
        return None
    core_errs = DE.check_core(doc, {}) + DE.check_acceptance(doc, mpn or "")
    if core_errs:
        return "core_errs: " + "; ".join(core_errs)[:200]
    return None


def stage_render(ctx: Ctx, *, finish_fn: Callable[..., dict] | None = None,
                 pd_module: Any = None) -> C.StageResult:
    """交付物渲染：内链 / 详情页 / SEO 图 / 符号 / 状态。

    **shadow 模式一律跳过。** 这个阶段会 `touch_status("done")` 并写
    `data/alts`、`data/seo`、`data/symbols`、`data/txt` —— 让它跑就等于让新链路
    接管正式状态，和「只比结果不改状态」直接冲突。
    """
    t0 = time.perf_counter()
    key = C.idem_key(ctx.pdf_sha256, C.STAGE_RENDER)

    if ctx.shadow:
        return C.StageResult(stage=C.STAGE_RENDER, status=C.STATUS_SKIPPED, idem_key=key,
                             ms=_ms(t0),
                             detail={"reason": "shadow_no_render",
                                     "why": "渲染会写正式产物目录并改 item.status"})

    doc = ctx.doc
    if doc is None and ctx.json_path and Path(ctx.json_path).exists():
        try:
            doc = json.loads(Path(ctx.json_path).read_text(encoding="utf-8"))
            ctx.doc = doc
        except (OSError, json.JSONDecodeError):
            doc = None
    if doc is None:
        return C.StageResult(stage=C.STAGE_RENDER, status=C.STATUS_BLOCKED, idem_key=key,
                             error="缺少 JSON（LLM 阶段未完成）", ms=_ms(t0))
    if ctx.item is None:
        return C.StageResult(stage=C.STAGE_RENDER, status=C.STATUS_BLOCKED, idem_key=key,
                             error="缺少 item 行，无法落渲染产物", ms=_ms(t0))

    if finish_fn is None:
        from ..services import pipeline as PLATFORM               # noqa: PLC0415
        finish_fn = PLATFORM.finish_item

    # 复核排在查缓存**之前**：否则一条闸门之前渲染成功的旧件会命中缓存，
    # 直接拿到 CACHED → 被写成 done，等于绕开准入。
    _why = render_gate(doc, ctx.mpn or "", pd_module=pd_module)
    if _why:
        return C.StageResult(stage=C.STAGE_RENDER, status=C.STATUS_FAILED, idem_key=key,
                             error=_why[:300], ms=_ms(t0),
                             detail={"gate": "final_gate_v1", "blocked": True})

    hit = None if ctx.force else ctx.store().cached(key)
    if hit:
        return C.StageResult(stage=C.STAGE_RENDER, status=C.STATUS_CACHED, idem_key=key,
                             artifact=hit.get("artifact") or "", ms=_ms(t0),
                             detail=hit.get("detail") or {})

    ctx.store().begin(idem_key=key, stage=C.STAGE_RENDER, mpn=ctx.mpn, mpn_key=ctx.mpn_key)

    def _run() -> C.StageResult:
        got = finish_fn(ctx.item, doc)                            # type: ignore[arg-type]
        errs = got.get("errors") or []
        return C.StageResult(stage=C.STAGE_RENDER,
                             status=C.STATUS_FAILED if got.get("status") == "failed" else C.STATUS_OK,
                             idem_key=key, artifact=str(got.get("txt_path") or ""),
                             error="; ".join(str(e) for e in errs)[:300], ms=_ms(t0),
                             detail={"errors": len(errs)})

    res = _guard(_run, C.STAGE_RENDER, key, t0)
    ctx.store().record(res, mpn=ctx.mpn, mpn_key=ctx.mpn_key)
    return res


# ------------------------------------------------------------------ 链路

STAGE_FUNCS: dict[str, Callable[..., C.StageResult]] = {
    C.STAGE_FETCH: stage_fetch,
    C.STAGE_PREPROCESS: stage_preprocess,
    C.STAGE_LLM: stage_llm,
    C.STAGE_AUDIT: stage_audit,
    C.STAGE_RENDER: stage_render,
}


def run_chain(ctx: Ctx, *, stages: Iterable[str] | None = None,
              **kwargs: Any) -> list[C.StageResult]:
    """按 `STAGE_ORDER` 顺序推进，遇非成功态即停。

    停在哪一步是**结论**，不是异常：`skipped`（不是 datasheet）、`blocked`
    （缺前置/需 OCR）都意味着链路已给出诚实答案，不该继续往下空转。
    `except` 里不吞异常 —— 阶段内部的异常已在 `_guard` 里转成 FAILED，
    这里若还接到异常，说明是编排层自己的问题，必须炸出来。

    `kwargs` 按各阶段的实际形参**过滤**后再传：五个阶段的注入点不同
    （`fetch_fn` / `llm_fn` / `audit_fn` / `finish_fn` / `pd_module`），
    无脑全传会让 `stage_audit` 因为多了一个 `pd_module` 直接 TypeError，
    而那个错误看起来像「审计阶段有 bug」，实际是编排层传参不讲究。
    """
    import inspect                                             # noqa: PLC0415

    chosen = list(stages) if stages is not None else list(C.STAGE_ORDER)
    out: list[C.StageResult] = []
    for stage in chosen:
        fn = STAGE_FUNCS[stage]
        params = inspect.signature(fn).parameters
        var_kw = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
        kw = dict(kwargs) if var_kw else {k: v for k, v in kwargs.items() if k in params}
        res = fn(ctx, **kw) if kw else fn(ctx)
        out.append(res)
        ctx.trace.append(res)
        if res.stopped:
            break
    return out


# ------------------------------------------------------------------ 影子对照

#: 对照时忽略的易变字段：时间戳、耗时、模型自报版本。它们每次都不一样，
#: 把它们算进「差异」会让对照永远报 diff，等于没有对照。
VOLATILE_PATHS = ("metadata.parse_timestamp", "metadata.pdf_hash", "metadata.ms")


def _get_path(doc: Any, path: str) -> Any:
    cur = doc
    for part in path.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def structure(doc: dict) -> dict[str, Any]:
    """把一份 JSON 压成可对比的骨架：顶层键、各表行数、关键计数。

    刻意不整篇逐字段 diff：模型温度 0.1 下同输入两次运行也会有措辞差异，
    逐字比会淹没真正的问题（行数掉了、表整张没了、字段类型从 list 变 str）。
    骨架对比回答的是「结构有没有变」，这正是五段改造该背的责任。
    """
    specs = doc.get("specs") or {}
    return {
        "keys": sorted(doc.keys()),
        "spec_keys": sorted(specs.keys()) if isinstance(specs, dict) else [],
        "electrical_rows": len(specs.get("electrical") or []) if isinstance(specs, dict) else 0,
        "absolute_max_rows": len(specs.get("absolute_max") or []) if isinstance(specs, dict) else 0,
        "thermal_rows": len(specs.get("thermal") or []) if isinstance(specs, dict) else 0,
        "ac_rows": len(specs.get("ac_performance") or []) if isinstance(specs, dict) else 0,
        "unresolved_ac_rows": len(specs.get("unresolved_ac_rows") or []) if isinstance(specs, dict) else 0,
        "pins": len(doc.get("pin_configuration") or []),
        "features": len(doc.get("features") or []),
        "ordering": len(doc.get("ordering_info") or []),
        "alternatives": len(doc.get("alternatives") or []),
        "has_metadata": isinstance(doc.get("metadata"), dict),
        "pdf_hash": _get_path(doc, "metadata.pdf_hash"),
    }


def _diff_struct(a: dict, b: dict) -> dict[str, tuple[Any, Any]]:
    out: dict[str, tuple[Any, Any]] = {}
    for k in sorted(set(a) | set(b)):
        if k == "pdf_hash":            # 同一个 PDF，哈希必相同；不同才值得报
            if a.get(k) != b.get(k):
                out[k] = (a.get(k), b.get(k))
            continue
        if a.get(k) != b.get(k):
            out[k] = (a.get(k), b.get(k))
    return out


def shadow_compare(pdf_path: Path, mpn: str, *, url: str = "", with_llm: bool = False,
                   baseline_json: str | Path | None = None,
                   pd_module: Any = None, llm_fn: Callable[..., dict] | None = None,
                   out_root: Path | None = None) -> dict:
    """同一份 PDF 上跑新旧两条路的**确定性部分**，只比结果，不接管状态。

    三级结论
    --------
    * `identical`  —— 文本、页数、datasheet 判定、prompt 指纹四项全等；
    * `differs`    —— 有不等项，`mismatch` 里逐项给出旧值/新值；
    * `inconclusive` —— 缺基准 JSON 且未开 `with_llm`，只能验 prompt/文本，
      不能对「模型输出」下结论。**不许把 inconclusive 报成 identical。**

    `with_llm=True` 时新链路在**系统临时目录**里落 JSON（`out_root` 可覆盖），
    正式 `data/parsed` 一个字节都不碰。旧链路不重跑：基准取 `baseline_json`，
    没有就取 `data/parsed/{safe}_{sha8}.json`。
    """
    pdf_path = Path(pdf_path)
    pd = _pd(pd_module)
    sha = pd.sha256(pdf_path)
    checks: dict[str, Any] = {}
    mismatch: dict[str, Any] = {}

    # ---- 旧路径：复刻 `pipeline.parse_pdf()` 里那两行（故意独立写一遍） ----
    old_text, old_total, old_used, old_has = pd.extract_pdf_text(pdf_path)
    old_msgs = [
        {"role": "system", "content": pd.SYSTEM_PROMPT},
        {"role": "user", "content": pd.USER_TMPL.format(
            mpn=mpn, fname=pdf_path.name, pages_used=old_used,
            pages_total=old_total, text=old_text)},
    ]
    old_prompt_sha = C.prompt_sha256(old_msgs)
    old_is_ds = bool(pd.is_datasheet(old_text))

    # ---- 新路径：走 preprocess.py（无参数调用抽取器） ----
    tmp_root = Path(out_root) if out_root else Path(tempfile.mkdtemp(prefix="icpdf_shadow_slices_"))
    new_slice = PP.build_slice(pdf_path, mpn, pdf_sha256=sha, pd_module=pd)
    ctx = Ctx(mpn=mpn, mpn_key=mpn, pdf_path=pdf_path, pdf_sha256=sha, url=url,
              slice=new_slice, shadow=True, slice_root=tmp_root)
    new_msgs = C.prompt_messages(mpn=mpn, pdf_name=new_slice.pdf_name,
                                 pages_used=new_slice.pages_used,
                                 pages_total=new_slice.pages_total,
                                 text=new_slice.text, pd_module=pd)
    new_prompt_sha = C.prompt_sha256(new_msgs)

    # 1) 文本逐字节（P1-01）
    checks["text_sha256"] = {"old": C.sha256_text(old_text), "new": new_slice.text_sha256}
    if checks["text_sha256"]["old"] != checks["text_sha256"]["new"]:
        mismatch["text_sha256"] = checks["text_sha256"]
    # 2) 页预算（P1-02 的前置：页数进 prompt 正文，页数变则 prompt 必变）
    checks["pages"] = {"old": (old_used, old_total), "new": (new_slice.pages_used, new_slice.pages_total)}
    if checks["pages"]["old"] != checks["pages"]["new"]:
        mismatch["pages"] = checks["pages"]
    # 3) datasheet 判定（P1-03）
    checks["is_datasheet"] = {"old": old_is_ds, "new": new_slice.is_datasheet}
    if old_is_ds != new_slice.is_datasheet:
        mismatch["is_datasheet"] = checks["is_datasheet"]
    # 4) prompt 指纹（P1-02）—— 连整条 messages 一起比，不只比哈希
    checks["prompt_sha256"] = {"old": old_prompt_sha, "new": new_prompt_sha}
    if old_prompt_sha != new_prompt_sha or old_msgs != new_msgs:
        mismatch["prompt_sha256"] = checks["prompt_sha256"]
    # 5) 哈希一致性（P1-06）
    checks["pdf_sha256"] = {"old": sha, "new": new_slice.pdf_sha256}

    result: dict[str, Any] = {
        "mpn": mpn, "pdf": str(pdf_path), "pdf_sha256": sha,
        "checks": checks, "mismatch": mismatch,
        "struct_diff": {}, "baseline": "", "new_json": "",
    }

    # ---- 结构对照（可选） ----
    base_path = Path(baseline_json) if baseline_json else (
        _default_json(mpn, sha))
    base_doc = _load_json(base_path)
    if base_doc is not None:
        result["baseline"] = str(base_path)

    if with_llm:
        out_dir = Path(tempfile.mkdtemp(prefix="icpdf_shadow_out_"))
        ctx.out_dir = out_dir
        res = stage_llm(ctx, llm_fn=llm_fn, pd_module=pd)
        result["llm_stage"] = res.as_dict()
        new_doc = _load_json(res.artifact) if res.artifact else None
        if new_doc is not None:
            result["new_json"] = res.artifact
            if base_doc is not None:
                d = _diff_struct(structure(base_doc), structure(new_doc))
                result["struct_diff"] = {k: {"baseline": v[0], "new": v[1]} for k, v in d.items()}
    elif base_doc is not None:
        # 没跑新 LLM：只能确认基准 JSON 与当前 PDF 哈希一致（防错配）
        result["baseline_pdf_hash"] = _get_path(base_doc, "metadata.pdf_hash")

    if mismatch:
        result["verdict"] = "differs"
    elif with_llm or base_doc is not None:
        result["verdict"] = "differs" if result["struct_diff"] else "identical"
    else:
        result["verdict"] = "inconclusive"
    return result


def _default_json(mpn: str, pdf_sha256: str) -> Path:
    from .. import config                                      # noqa: PLC0415
    return Path(config.PARSED) / f"{slice_store.safe_name(mpn)}_{pdf_sha256[:8]}.json"


def _load_json(path: str | Path | None) -> dict | None:
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None
