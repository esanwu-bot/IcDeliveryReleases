"""切片文件仓库：`data/slices/{safe_mpn}_{pdf_sha8}.json`。

三条硬规矩
----------
1. **原子写**：先写 `*.tmp` 再 `os.replace`。进程被 kill 在中途时，宁可没有
   切片，也不能留一个半截 JSON 让下游当成「已抽取」。
2. **不覆盖历史**：目标文件已存在且内容不同、版本也不同时，旧文件先改名成
   `*.{oldver}.bak` 留档，再写新文件。V11 那轮的教训 —— 覆盖掉的旧产物
   等于丢证据，事后无法证明「当时读到的是什么」。
3. **读坏了不删**：解析失败返回 `None`，文件原样留着等人查。自动清理会把
   「文件是怎么坏的」这个唯一的现场也一起清掉。

路径为什么不带 mpn_key 归一：文件名里已经有 `safe_name(mpn)`，而 `pdf_sha8`
才是真正的去重维度（同一颗料可能有多份不同修订的 PDF，各自要留切片）。
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from . import contracts as C


def safe_name(mpn: str) -> str:
    """文件名安全化。**必须**和 `app.services.parts.safe_name` 同一口径，
    否则切片名和 JSON 名对不上，人工按名对账时会莫名少几件。"""
    try:
        from ..services.parts import safe_name as _sn          # noqa: PLC0415
        return _sn(mpn)
    except Exception:                                          # noqa: BLE001
        bad = '<>:"/\\|?*'
        out = "".join("_" if c in bad else c for c in str(mpn or "")).strip()
        return out or "unknown"


def slice_dir(root: Path | None = None) -> Path:
    """切片目录。`root` 只给测试用，生产走 `config.DATA/slices`。"""
    if root is not None:
        return Path(root)
    from .. import config                                      # noqa: PLC0415
    return Path(config.DATA) / C.SLICE_SUBDIR


def slice_path(mpn: str, pdf_sha256: str, *, root: Path | None = None) -> Path:
    return slice_dir(root) / f"{safe_name(mpn)}_{(pdf_sha256 or '')[:8]}.json"


def _atomic_write(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        # 自己的临时文件可以清，别人的一律不碰
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_slice(slc: C.Slice, *, root: Path | None = None) -> Path:
    """落盘并返回路径。已存在且逐字节相同则直接返回（不产生无意义的 mtime 变更）。"""
    path = slice_path(slc.mpn, slc.pdf_sha256, root=root)
    payload = json.dumps(slc.to_dict(), ensure_ascii=False, indent=2) + "\n"

    if path.exists():
        try:
            old = path.read_text(encoding="utf-8")
        except OSError:
            old = ""
        if old == payload:
            return path
        # 内容不同：旧文件先留档，再写新的。绝不静默覆盖。
        try:
            prev = C.Slice.from_dict(json.loads(old))
            ver = prev.extractor_version.replace("/", "_") or "unknown"
        except Exception:                                      # noqa: BLE001
            ver = "corrupt"
        bak = path.with_name(f"{path.name}.{ver}.bak")
        try:
            os.replace(path, bak)
        except OSError:
            pass

    _atomic_write(path, payload)
    return path


def read_slice(path: Path) -> C.Slice | None:
    """读切片。坏了返回 `None`，**不删文件**。"""
    try:
        return C.Slice.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
    except (OSError, ValueError, TypeError):
        return None


def find_slice(mpn: str, pdf_sha256: str, *, root: Path | None = None) -> C.Slice | None:
    p = slice_path(mpn, pdf_sha256, root=root)
    return read_slice(p) if p.exists() else None


def list_slices(*, root: Path | None = None) -> list[Path]:
    d = slice_dir(root)
    return sorted(d.glob("*.json")) if d.exists() else []
