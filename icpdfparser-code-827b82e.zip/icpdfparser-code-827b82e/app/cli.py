#!/usr/bin/env python
"""工作台维护命令（不调模型，纯本地重渲染）。

    python -m app.cli stats
    python -m app.cli rebuild --all                 # 用已有 JSON 重渲染 详情页/三视图/图片SEO
    python -m app.cli rebuild --keys LM358,NE555
    python -m app.cli reset --keys LM358            # 清空解析结果，下次重新走全链路

「改了渲染规则但不想重新花 token 解析」时用 rebuild —— 这是最高频的运维动作。
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

from app import config, db


def cmd_stats() -> None:
    rows = db.q("SELECT status, count(*) n FROM item GROUP BY status ORDER BY n DESC")
    print("型号任务：")
    for r in rows:
        print(f"  {r['status']:<12} {r['n']}")
    cat = db.q1("SELECT count(*) n FROM catalog") if False else None
    _ = cat
    print(f"内链索引：{config.CATALOG_DB} {'存在' if config.CATALOG_DB.exists() else '缺失'}")
    print(f"配图表  ：{len(db.q('SELECT 1 FROM app_image'))} 类")


def _rerender(item: dict) -> list[str]:
    from app.services import pkg_lib, pipeline, seo_image
    import json_to_txt
    import symbol_svg

    pj = (item.get("json_path") or "").strip()
    if not pj or not Path(pj).exists():
        return ["缺 JSON"]
    doc = json.loads(Path(pj).read_text(encoding="utf-8"))
    mpn = item["mpn"]
    done: list[str] = []
    errors: list[str] = []

    try:
        html = json_to_txt.render(doc)
        plan = seo_image.build(doc, mpn)
        html = seo_image.optimize_html(html, plan)
        p = config.TXT / f"{item['mpn_key'] or mpn}.txt"
        from app.services.parts import safe_name
        p = config.TXT / f"{safe_name(mpn)}.txt"
        p.write_text(html, encoding="utf-8")
        db.set_item(item["id"], txt_path=str(p), seo_path=plan.get("_path", ""))
        done += ["txt", "seo"]
    except Exception as e:                                       # noqa: BLE001
        errors.append(f"render: {e}")

    try:
        # 与在线链路一致：先补齐共享封装图，再渲染（封装/3D 引用图库，符号内联）
        info = pkg_lib.ensure_for_doc(doc)
        page = symbol_svg.render_page(doc, pkg_dir=config.PKGS)
        if page:
            from app.services.parts import safe_name
            p = config.SYMBOLS / f"{safe_name(mpn)}.html"
            p.write_text(page, encoding="utf-8")
            db.set_item(item["id"], symbol_path=str(p))
            done.append("symbols" + (f"[{info['key']}新生成]" if info.get("generated") else ""))
    except Exception as e:                                       # noqa: BLE001
        errors.append(f"symbols: {e}")

    # 内链片段：优先复用已存的 alt_json 重渲染（零模型调用），
    # 没有 alt_json 才走 build_alternatives（可能触发一次 AI 提案）
    try:
        aj = (item.get("alt_json_path") or "").strip()
        rows: list[dict] = []
        payload: dict = {}
        mfr = ""
        if aj and Path(aj).exists():
            payload = json.loads(Path(aj).read_text(encoding="utf-8"))
            rows = payload.get("alternatives") or []
            mfr = payload.get("manufacturer") or ""
        else:
            res = pipeline.build_alternatives(doc, mpn)
            rows = res.get("rows") or []
            payload = res.get("payload") or {}
            mfr = (doc.get("basic_info") or {}).get("manufacturer") or ""
            if res.get("json"):
                db.set_item(item["id"], alt_json_path=res["json"])
        from app.services.parts import safe_name
        hp = config.ALTS / f"{safe_name(mpn)}.html"
        hp.parent.mkdir(parents=True, exist_ok=True)
        hp.write_text(pipeline._alts_section_html(mpn, mfr, rows, payload), encoding="utf-8")
        db.set_item(item["id"], alt_html_path=str(hp))
        done.append("alts")
    except Exception as e:                                       # noqa: BLE001
        errors.append(f"alts: {e}")
    return done + errors


def cmd_rebuild(keys: list[str], all_items: bool) -> None:
    if all_items:
        items = db.q("SELECT * FROM item WHERE json_path<>''")
    else:
        marks = ",".join("?" * len(keys))
        items = db.q(f"SELECT * FROM item WHERE mpn_key IN ({marks}) OR mpn IN ({marks})",
                     (*keys, *keys))
    if not items:
        print("没有匹配的型号")
        return
    for it in items:
        r = _rerender(it)
        print(f"{it['mpn']:<24} {' '.join(r)}")
    db.add_event(f"本地重渲染 {len(items)} 个型号", kind="rebuild")


def cmd_reset(keys: list[str]) -> None:
    marks = ",".join("?" * len(keys))
    rows = db.q(f"SELECT id,mpn FROM item WHERE mpn_key IN ({marks})", tuple(keys))
    for r in rows:
        db.set_item(r["id"], status="pending", stage="已重置", progress=0, error="",
                    json_path="", txt_path="", alt_json_path="", alt_html_path="",
                    symbol_path="", seo_path="")
        print(f"reset {r['mpn']}")
    if not rows:
        print("没有匹配的型号")


def cmd_worker_stop(wait: int = 3) -> None:
    """让 Celery worker 优雅退出：跑完手上的任务再走，不丢队列里的消息。"""
    from worker.celery_app import app
    replies = app.control.shutdown(reply=True, timeout=wait) or []
    print(f"已广播停止指令，{len(replies)} 个 worker 收到；"
          "它会先跑完当前任务再退出（新任务留在 Redis 里不动）")


def cmd_pkg_lib(backfill: bool) -> None:
    from app.services import pkg_lib
    if backfill:
        r = pkg_lib.backfill()
        print(f"封装图库：命中/生成 {r['keys']} 种，本次新生成 {len(r['generated'])} 种"
              + (f"：{', '.join(r['generated'])}" if r["generated"] else ""))
        for b in r["failed"]:
            print(f"  生成失败 {b['key']}: {b['error']}")
    rep = pkg_lib.report()
    print(f"型号 {rep['models']} 个：共享封装图命中 {rep['shared']}，"
          f"待补 {rep['missing_key']}，板卡类(不共享) {rep['board']}；库中 {rep['lib_keys']} 种")
    for m in rep["missing"][:12]:
        print(f"  待补 {m['key']:<14} {m['family']:<6} {m['pins']} 脚 × {m['n']} 个型号  <- {m['raw'][:40]}")


def cmd_rerun(status: str, workers: int, limit: int, keys: str, budget: float) -> None:
    """本地并行复核「被误判」的型号：不投 Celery 队列，直接起线程池跑完整链路。

    为什么不用队列：队列里还压着上万条正常任务，误判复核优先级低但时效性重要，
    投到队尾要等一两天。这里在 CLI 进程内直接并发跑，结果照样写回 item 表，
    工作台前端能实时看到状态变化。

    典型用法（复核旧逻辑误判的 nodata）：
        python -m app.cli rerun --status nodata --workers 6
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from app.services import pipeline

    only = [k.strip() for k in keys.split(",") if k.strip()]
    sql = "SELECT * FROM item WHERE 1=1"
    args: list = []
    if status:
        sql += " AND status=?"
        args.append(status)
    if only:
        marks = ",".join("?" * len(only))
        sql += f" AND mpn_key IN ({marks})"
        args += only
    sql += " ORDER BY id"
    rows = db.q(sql, args)
    if limit > 0:
        rows = rows[:limit]
    if not rows:
        print(f"没有 status={status or '不限'} 的型号可复核")
        return

    print(f"待复核 {len(rows)} 个型号（status={status or '不限'}），并发 {workers}")
    if budget > 0:
        print(f"单型号采集预算 {budget}s（0=用环境变量默认）")
    before = {r["mpn_key"]: r["status"] for r in rows}
    stats: dict[str, int] = {}
    rescued: list[str] = []
    t0 = time.time()

    def one(item: dict) -> tuple[str, dict]:
        try:
            r = pipeline.run_item(item, force=True)
        except Exception as e:                                   # noqa: BLE001
            return item["mpn"], {"ok": False, "reason": f"exception: {type(e).__name__}: {e}"}
        return item["mpn"], r

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futs = [pool.submit(one, it) for it in rows]
        for i, fut in enumerate(as_completed(futs), 1):
            mpn, r = fut.result()
            reason = r.get("reason") or ("done" if r.get("ok") else "failed")
            stats[reason] = stats.get(reason, 0) + 1
            if r.get("ok") and before.get(mpn) != "done":
                rescued.append(mpn)
            if i % 10 == 0 or i == len(rows):
                print(f"  进度 {i}/{len(rows)}  用时 {time.time() - t0:.0f}s  {stats}")

    print(f"\n复核完成，用时 {time.time() - t0:.0f}s")
    for k, v in sorted(stats.items(), key=lambda kv: -kv[1]):
        print(f"  {k:<16} {v}")
    print(f"\n救回（本次变为 done）{len(rescued)} 个：")
    for m in rescued[:60]:
        print(f"  {m}")
    if len(rescued) > 60:
        print(f"  ... 另有 {len(rescued) - 60} 个")
    db.add_event(f"复核 {len(rows)} 个 {status} 型号，救回 {len(rescued)} 个", kind="rerun")


def cmd_batch(action: str, file: str = "", batch_id: str = "", limit: int = 200,
              yes: bool = False, keys: str = "") -> None:
    from app.services import batch
    if action == "emit":
        only = [k.strip() for k in keys.split(",") if k.strip()] or None
        r = batch.emit(limit=limit, mpn_keys=only)
        print(f"生成 {len(r['files'])} 个文件 / {r['requests']} 条请求"
              f"（本地跳过 {r['skipped_local']}，缺 PDF {r['no_pdf']}，"
              f"无法抽取 {r['unreadable']}），模型 {r['model']}")
        for f in r["files"]:
            print(f"  {f}  {Path(f).stat().st_size / 1024:.0f} KB")
        return
    if action == "submit":
        src = file
        if not src:
            last_emit = db.kv_json("batch:last_emit", {}) or {}
            files = last_emit.get("files") or []
            src = files[0] if files else ""
        if not src:
            print("没有可提交的文件，先跑 batch emit")
            return
        if not yes:
            print(f"将上传并创建批次：{src}\n确认后加 --yes 重跑")
            return
        info = batch.submit(src)
        print(f"已提交 batch_id={info.get('id')} status={info.get('status')}")
        return
    if action == "status":
        bid = batch_id or (batch.last() or {}).get("id", "")
        if not bid:
            print("没有 batch_id")
            return
        print(json.dumps(batch.status(bid), ensure_ascii=False, indent=2)[:2000])
        return
    if action == "ingest":
        bid = batch_id or (batch.last() or {}).get("id", "")
        if not bid:
            print("没有 batch_id")
            return
        r = batch.ingest(bid)
        print(json.dumps(r, ensure_ascii=False, indent=2)[:2000])


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("stats")
    rb = sub.add_parser("rebuild")
    rb.add_argument("--keys", default="")
    rb.add_argument("--all", action="store_true")
    rs = sub.add_parser("reset")
    rs.add_argument("--keys", required=True)
    pl = sub.add_parser("pkg-lib", help="封装图库：盘点覆盖率 / 批量补齐")
    pl.add_argument("--backfill", action="store_true", help="把库里缺的封装图一次性生成")
    ws = sub.add_parser("worker-stop", help="优雅停止 Celery worker（跑完当前任务再退）")
    ws.add_argument("--wait", type=int, default=3)
    bt = sub.add_parser("batch", help="百炼 Batch：emit / submit / status / ingest")
    bt.add_argument("action", choices=["emit", "submit", "status", "ingest"])
    bt.add_argument("--file", default="")
    bt.add_argument("--id", default="")
    bt.add_argument("--limit", type=int, default=200)
    bt.add_argument("--yes", action="store_true", help="提交批次需要显式确认")
    bt.add_argument("--keys", default="", help="只对这些型号 emit（逗号分隔）")
    rr = sub.add_parser("rerun", help="本地并行复核被误判的型号（不投 Celery 队列）")
    rr.add_argument("--status", default="nodata", help="要复核的状态，默认 nodata")
    rr.add_argument("--workers", type=int, default=4, help="并发线程数，默认 4")
    rr.add_argument("--limit", type=int, default=0, help="最多复核多少个，0=不限")
    rr.add_argument("--keys", default="", help="只复核这些型号（逗号分隔）")
    rr.add_argument("--budget", type=float, default=0, help="单型号采集预算秒，0=用环境变量默认")
    a = ap.parse_args()

    if a.cmd == "stats":
        cmd_stats()
    elif a.cmd == "rebuild":
        cmd_rebuild([k.strip() for k in a.keys.split(",") if k.strip()], a.all)
    elif a.cmd == "reset":
        cmd_reset([k.strip() for k in a.keys.split(",") if k.strip()])
    elif a.cmd == "pkg-lib":
        cmd_pkg_lib(a.backfill)
    elif a.cmd == "worker-stop":
        cmd_worker_stop(a.wait)
    elif a.cmd == "batch":
        cmd_batch(a.action, a.file, a.id, a.limit, a.yes, a.keys)
    elif a.cmd == "rerun":
        if a.budget > 0:
            os.environ["ICPDF_FETCH_BUDGET"] = str(a.budget)
        cmd_rerun(a.status, a.workers, a.limit, a.keys, a.budget)


if __name__ == "__main__":
    main()
