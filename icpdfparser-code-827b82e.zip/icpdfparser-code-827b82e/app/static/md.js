/**
 * DeepSeek 风格 Markdown 渲染器（纯正则，零依赖）。
 *
 * 来源：ReactSSERender-DeepSeekStyle 技能，改写成浏览器全局函数。
 * 用途：Agent Lab 对话气泡。流式时每收到一段就整段重渲染——
 * 正则解析几百字的开销远小于重建 DOM，实测不会掉帧。
 *
 * 支持：代码块（语言标签 + 复制）、行内代码、表格、有序/无序列表、
 *       h1-h6、粗体、斜体、链接、分隔线、段落，以及剥掉 <think> 块。
 */
(function () {
  'use strict';

  function renderMarkdown(text) {
    if (!text) return '';

    // 1. 去掉推理块
    text = String(text).replace(/<think[\s\S]*?<\/think>/gi, '').trim();
    if (!text) return '';

    // 2. HTML 转义（必须在提取代码块之前，否则代码里的 < > 会被当标签）
    let html = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // 3. 代码块先抽出来占位，避免内部内容被后续规则改写
    const codeBlocks = [];
    html = html.replace(/```(\w*)\n([\s\S]*?)```/g, function (_m, lang, code) {
      const i = codeBlocks.length;
      const langLabel = lang ? '<div class="md-code-lang">' + lang + '</div>' : '';
      codeBlocks.push(
        '<pre class="md-pre">' + langLabel +
        '<button class="md-copy-btn" type="button" onclick="(function(btn){' +
        'var c=btn.parentElement.querySelector(\'code\');' +
        'if(c){navigator.clipboard.writeText(c.textContent);' +
        'btn.textContent=\'Copied!\';setTimeout(function(){btn.textContent=\'Copy\'},1500)}})(' +
        'this)">Copy</button>' +
        '<code class="md-code ' + (lang ? 'language-' + lang : '') + '">' + code + '</code></pre>'
      );
      return '__CODE_BLOCK_' + i + '__';
    });

    // 4. 行内代码
    html = html.replace(/`([^`]+)`/g, '<code class="md-inline-code">$1</code>');

    // 5. 分隔线
    // 注意：行首缩进只能用 [ \t]，不能用 \s —— \s 会吃掉前一行的换行符，
    // 把本该分开的两个段落粘成一个（列表被塞进 <p> 里就是这么来的）。
    html = html.replace(/^[ \t]*-{3,}[ \t]*$/gm, '<hr class="md-hr" />');
    html = html.replace(/^[ \t]*\*{3,}[ \t]*$/gm, '<hr class="md-hr" />');

    // 6. 标题（从长到短，否则 ### 会先被 ## 吃掉）
    html = html.replace(/^###### (.*)$/gm, '<h6 class="md-h6">$1</h6>');
    html = html.replace(/^##### (.*)$/gm, '<h5 class="md-h5">$1</h5>');
    html = html.replace(/^#### (.*)$/gm, '<h4 class="md-h4">$1</h4>');
    html = html.replace(/^### (.*)$/gm, '<h3 class="md-h3">$1</h3>');
    html = html.replace(/^## (.*)$/gm, '<h2 class="md-h2">$1</h2>');
    html = html.replace(/^# (.*)$/gm, '<h1 class="md-h1">$1</h1>');

    // 7. 表格
    // 结尾用 $ + 可选 \n：最后一行没有换行符也要算进表格，
    // 否则表格永远少最后一行（流式最后一段没有尾随 \n 时必现）。
    html = html.replace(/(?:^[ \t]*\|[^\n]*\|[ \t]*$\n?)+/gm, function (block) {
      const lines = block.trim().split('\n').filter(function (l) { return l.trim(); });
      if (lines.length < 2) return block;
      const sep = lines[1].trim();
      if (!/^\|[\s|:-]+\|$/.test(sep) && !/^\|[\s|:-]+/.test(sep)) return block;
      const headCells = lines[0].split('|').map(function (c) { return c.trim(); })
        .filter(function (c) { return c !== ''; });
      let tbl = '<table class="md-table"><thead><tr>';
      headCells.forEach(function (c) { tbl += '<th>' + c + '</th>'; });
      tbl += '</tr></thead><tbody>';
      for (let i = 2; i < lines.length; i++) {
        const cells = lines[i].split('|').map(function (c) { return c.trim(); })
          .filter(function (c) { return c !== ''; });
        tbl += '<tr>';
        cells.forEach(function (c) { tbl += '<td>' + c + '</td>'; });
        tbl += '</tr>';
      }
      return tbl + '</tbody></table>';
    });

    // 8. 无序列表
    html = html.replace(/^[ \t]*[-*][ \t]+(.*)$/gm, '<li class="md-li">$1</li>');
    html = html.replace(/((?:<li class="md-li">.*?<\/li>(?:\n|$))+)/g, function (m) {
      return '<ul class="md-ul">' + m.trim() + '</ul>';
    });

    // 9. 有序列表
    html = html.replace(/^[ \t]*\d+\.[ \t]+(.*)$/gm, '<li class="md-li-ol">$1</li>');
    html = html.replace(/((?:<li class="md-li-ol">.*?<\/li>(?:\n|$))+)/g, function (m) {
      if (m.indexOf('<ul class="md-ul">') >= 0) return m;
      const items = m.trim()
        .replace(/<li class="md-li-ol">/g, '<li class="md-li">')
        .replace(/<\/ul>/g, '');
      return '<ol class="md-ol">' + items + '</ol>';
    });

    // 10. 粗体 / 斜体
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong class="md-strong">$1</strong>');
    html = html.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em class="md-em">$2</em>');

    // 11. 链接
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener" class="md-link">$1</a>');

    // 12. 段落
    // 块级元素一律不能再包进 <p>（浏览器会强行闭合，后面的结构全乱）；
    // 文字与块级混排时，块级标签前后也不该留 <br>，否则多出空行。
    const BLOCK = 'h[1-6]|pre|table|ul|ol|hr|blockquote';
    const blocks = html.split(/\n{2,}/).map(function (p) {
      p = p.trim();
      if (!p) return '';
      if (/^__CODE_BLOCK_\d+__$/.test(p)) return p;   // 代码块占位符也是块级
      if (new RegExp('^<(' + BLOCK + ')').test(p)) return p;
      if (new RegExp('<(' + BLOCK + ')\\b').test(p)) {
        return p
          .replace(new RegExp('\\n+(?=<(?:' + BLOCK + ')\\b)', 'g'), '')
          .replace(/(<\/(?:ul|ol|table|pre)>)\n+/g, '$1')
          // 块内换行直接清掉：<li> 之间被替换成 <br> 会多出一堆空行
          .replace(/(<(?:ul|ol|table)\b[^]*?<\/(?:ul|ol|table)>)/g, function (m) {
            return m.replace(/\n/g, '');
          })
          .replace(/\n/g, '<br>');
      }
      return '<p class="md-p">' + p.replace(/\n/g, '<br>') + '</p>';
    });
    html = blocks.join('\n');

    // 13. 还原代码块
    codeBlocks.forEach(function (blk, i) {
      html = html.replace('__CODE_BLOCK_' + i + '__', blk);
    });

    return html;
  }

  window.renderMarkdown = renderMarkdown;
})();
