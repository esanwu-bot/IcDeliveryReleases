/**
 * Agent Lab 前端逻辑
 * QC Agent Chat 界面、工具调用、任务历史、模型路由配置
 */
(function() {
  'use strict';

  // ==================== 状态管理 ====================
  const state = {
    currentView: 'agent-chat',
    chatHistory: [],
    tasks: [],
    auditLogs: [],
    modelConfig: {
      parse: 'qwen-flash',
      review: 'qwen3.7-plus',
      repair: 'qwen3.7-plus',
      alternatives: 'qwen3.7-plus',
      fix: 'rules-only',
      intent: 'qwen-flash',
      planner: 'qwen-flash'
    }
  };

  // ==================== 初始化 ====================
  function init() {
    setupEventListeners();
    loadModelConfig();
    console.log('[AgentLab] 初始化完成');
  }

  function setupEventListeners() {
    // 菜单切换
    document.querySelectorAll('#navAgent .nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        const view = e.target.dataset.view;
        if (view) switchView(view);
      });
    });

    // Chat 输入
    const chatInput = document.getElementById('agentChatInput');
    const chatSend = document.getElementById('agentChatSend');
    
    if (chatInput && chatSend) {
      chatSend.addEventListener('click', handleSendMessage);
      chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          handleSendMessage();
        }
      });
    }

    // 快捷操作
    document.querySelectorAll('.agent-quick-actions button').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const command = e.target.dataset.command;
        if (command && chatInput) {
          chatInput.value = command;
          chatInput.focus();
        }
      });
    });

    // 模型选择
    const modelSelect = document.getElementById('agentModelSelect');
    if (modelSelect) {
      modelSelect.addEventListener('change', (e) => {
        console.log('[AgentLab] 模型切换:', e.target.value);
      });
    }

    // 模式选择
    const modeSelect = document.getElementById('agentModeSelect');
    if (modeSelect) {
      modeSelect.addEventListener('change', (e) => {
        console.log('[AgentLab] 模式切换:', e.target.value);
      });
    }
  }

  // ==================== 视图切换 ====================
  function switchView(viewName) {
    // 隐藏所有视图
    document.querySelectorAll('[id^="view-agent-"]').forEach(el => {
      el.classList.add('hide');
    });

    // 显示目标视图
    const targetView = document.getElementById(`view-${viewName}`);
    if (targetView) {
      targetView.classList.remove('hide');
      state.currentView = viewName;
      
      // 更新菜单激活状态
      document.querySelectorAll('#navAgent .nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.view === viewName);
      });

      // 更新顶栏标题
      const viewTitles = {
        'agent-chat': 'QC Agent Chat',
        'agent-tools': '工具注册表',
        'agent-tasks': '任务历史',
        'agent-models': '模型路由',
        'agent-audit': '审计日志'
      };
      const titleEl = document.getElementById('viewTitle');
      if (titleEl) {
        titleEl.textContent = viewTitles[viewName] || 'Agent Lab';
      }
    }
  }

  // ==================== Chat 功能 ====================
  async function handleSendMessage() {
    const chatInput = document.getElementById('agentChatInput');
    if (!chatInput || !chatInput.value.trim()) return;

    const message = chatInput.value.trim();
    chatInput.value = '';

    // 添加用户消息
    addChatMessage('user', message);

    // 先插一条空的 agent 气泡，后面往里逐段追加
    const live = addStreamingMessage();

    try {
      const modelSelect = document.getElementById('agentModelSelect');
      const modeSelect = document.getElementById('agentModeSelect');

      await streamChat(message, {
        model: modelSelect ? modelSelect.value : 'auto',
        mode: modeSelect ? modeSelect.value : 'dry_run'
      }, live);
    } catch (error) {
      console.error('[AgentLab] Chat 流式调用失败:', error);
      live.status(`调用失败：${error.message}`);
      live.finish();
      live.setText(`抱歉，调用后端 API 失败：${error.message}。请检查服务是否启动。`);
    }
  }

  /**
   * 读 SSE 流。
   *
   * 为什么不用 EventSource：它只能发 GET，带不了 message/model/mode 这些
   * JSON body。所以用 fetch + ReadableStream 手动按帧解析。
   */
  async function streamChat(message, opts, live) {
    const resp = await fetch('/api/agent/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: message,
        model: opts.model,
        mode: opts.mode,
        context: {}
      })
    });

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status}: ${resp.statusText}`);
    }
    if (!resp.body) {
      throw new Error('浏览器不支持流式读取');
    }

    const reader = resp.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buf = '';
    let text = '';
    let steps = [];

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });

      // SSE 以空行分帧；最后一段可能不完整，留在 buf 里等下一块
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx);
        buf = buf.slice(idx + 2);

        let evt = 'message';
        const dataLines = [];
        frame.split('\n').forEach(function (line) {
          if (line.startsWith('event:')) evt = line.slice(6).trim();
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).trim());
        });
        if (!dataLines.length) continue;   // 心跳帧 ": ping"

        let payload = {};
        try { payload = JSON.parse(dataLines.join('\n')); } catch (e) { continue; }

        if (evt === 'intent') {
          live.status(`识别意图：${payload.intent || '—'}`);
        } else if (evt === 'plan') {
          const tools = payload.tools || [];
          live.status(tools.length ? `计划调用：${tools.join(' → ')}` : '无需调用工具');
        } else if (evt === 'step_start') {
          live.status(`正在执行 ${payload.tool || '工具'}…`);
        } else if (evt === 'step_done') {
          const ms = payload.ms ? `（${payload.ms}ms）` : '';
          live.status(`${payload.tool || '工具'} 完成${ms}`);
        } else if (evt === 'delta') {
          text += payload.text || '';
          live.setText(text);
        } else if (evt === 'done') {
          steps = payload.steps || [];
          live.setMeta({ status: payload.status, intent: payload.intent });
        } else if (evt === 'error') {
          live.status(`出错：${payload.message || '未知错误'}`);
        }
      }
    }

    live.finish();
    if (!text) live.setText('（没有返回内容）');
    if (steps.length) live.setTools(steps);
  }

  function addChatMessage(role, content, metadata = {}) {
    const messagesContainer = document.getElementById('agentChatMessages');
    if (!messagesContainer) return;

    // 移除欢迎消息
    const welcome = messagesContainer.querySelector('.agent-welcome');
    if (welcome) welcome.remove();

    const messageEl = document.createElement('div');
    messageEl.className = `agent-message agent-message-${role}`;
    
    const avatar = role === 'user' ? '👤' : '🤖';
    const roleName = role === 'user' ? '你' : 'QC Agent';
    
    messageEl.innerHTML = `
      <div class="message-avatar">${avatar}</div>
      <div class="message-content">
        <div class="message-header">
          <span class="message-role">${roleName}</span>
          <span class="message-time">${new Date().toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'})}</span>
        </div>
        <div class="message-text">${role === 'user' ? escapeHtml(content) : md(content)}</div>
        ${metadata.tools ? `<div class="message-tools">${renderToolCalls(metadata.tools)}</div>` : ''}
        ${metadata.result ? `<div class="message-result">${renderResult(metadata.result)}</div>` : ''}
      </div>
    `;

    messagesContainer.appendChild(messageEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    state.chatHistory.push({ role, content, metadata, timestamp: Date.now() });
  }

  /** 渲染 Markdown；md.js 没加载时退回转义纯文本，别把 HTML 直接插进页面。 */
  function md(text) {
    if (typeof window.renderMarkdown === 'function') {
      return window.renderMarkdown(text);
    }
    return escapeHtml(text).replace(/\n/g, '<br>');
  }

  /**
   * 建一条空的 agent 气泡，返回句柄供流式更新。
   *
   * 每次 delta 都整段重渲染 Markdown 而不是 appendChild：
   * 列表/表格跨行才有意义，按行拼接会把结构切碎。
   */
  function addStreamingMessage() {
    const messagesContainer = document.getElementById('agentChatMessages');
    const welcome = messagesContainer && messagesContainer.querySelector('.agent-welcome');
    if (welcome) welcome.remove();

    const el = document.createElement('div');
    el.className = 'agent-message agent-message-agent';
    el.innerHTML = `
      <div class="message-avatar">🤖</div>
      <div class="message-content">
        <div class="message-header">
          <span class="message-role">QC Agent</span>
          <span class="message-time">${new Date().toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'})}</span>
        </div>
        <div class="message-text md-body"></div>
        <div class="agent-live">连接中…</div>
        <div class="message-tools" style="display:none"></div>
      </div>
    `;
    messagesContainer.appendChild(el);

    const textEl = el.querySelector('.message-text');
    const liveEl = el.querySelector('.agent-live');
    const toolsEl = el.querySelector('.message-tools');
    let raw = '';

    const scroll = function () {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    };
    scroll();

    return {
      setText: function (t) {
        raw = t;
        textEl.innerHTML = md(raw);
        scroll();
      },
      status: function (s) {
        liveEl.textContent = s;
        scroll();
      },
      finish: function () {
        liveEl.remove();
      },
      setMeta: function (meta) {
        state.chatHistory.push({
          role: 'agent', content: raw, metadata: meta, timestamp: Date.now()
        });
      },
      setTools: function (steps) {
        const items = (steps || []).map(function (s) {
          return { name: s.tool, status: 'completed', params: {}, result: s.result };
        });
        toolsEl.innerHTML = renderToolCalls(items);
        toolsEl.style.display = '';
        scroll();
      }
    };
  }

  function simulateAgentResponse(userMessage) {
    // 简单的意图识别（后续接入真实 Intent Router）
    const intent = detectIntent(userMessage);
    
    const responses = {
      'QC_DIAGNOSE': {
        text: '正在诊断当前批次的 P0 问题...',
        tools: [
          { name: 'qc.get_findings', status: 'running', params: { severity: ['P0'] } }
        ]
      },
      'QC_ANALYZE': {
        text: '正在使用 Pandas 分析参数错误分布...',
        tools: [
          { name: 'qc.pandas_analyze', status: 'running', params: { filters: {} } }
        ]
      },
      'EVIDENCE_LOOKUP': {
        text: '正在检索 PDF 证据...',
        tools: [
          { name: 'qc.get_evidence', status: 'running', params: { mpn: 'BUF634PG4' } }
        ]
      },
      'REPAIR_DRY_RUN': {
        text: '正在生成修复方案（dry-run 模式）...',
        tools: [
          { name: 'qc.propose_patch', status: 'running', params: { mode: 'dry_run' } }
        ]
      },
      'GENERAL_QA': {
        text: '这是一个关于 QC 流程的问题。我可以帮你诊断质量问题、分析异常分布、检索证据或生成修复方案。',
        tools: []
      }
    };

    const response = responses[intent] || responses['GENERAL_QA'];
    
    // 模拟工具调用完成
    setTimeout(() => {
      response.tools.forEach(tool => {
        tool.status = 'completed';
        tool.result = {
          status: 'OK',
          message: `工具 ${tool.name} 执行成功（模拟）`,
          data: {}
        };
      });

      addChatMessage('agent', response.text, {
        tools: response.tools,
        result: { status: 'completed', summary: '任务执行完成' }
      });
    }, 1000);
  }

  function detectIntent(message) {
    const lower = message.toLowerCase();
    if (lower.includes('p0') || lower.includes('问题') || lower.includes('诊断')) return 'QC_DIAGNOSE';
    if (lower.includes('pandas') || lower.includes('分析') || lower.includes('分布')) return 'QC_ANALYZE';
    if (lower.includes('证据') || lower.includes('pdf') || lower.includes('查找')) return 'EVIDENCE_LOOKUP';
    if (lower.includes('修复') || lower.includes('patch') || lower.includes('dry-run')) return 'REPAIR_DRY_RUN';
    return 'GENERAL_QA';
  }

  function renderToolCalls(tools) {
    return tools.map(tool => `
      <div class="tool-call">
        <span class="tool-call-name">${tool.name}</span>
        <span class="tool-call-status ${tool.status}">${tool.status === 'running' ? '⏳' : '✓'}</span>
        <div class="tool-call-params">${JSON.stringify(tool.params, null, 2)}</div>
      </div>
    `).join('');
  }

  function renderResult(result) {
    return `<pre>${JSON.stringify(result, null, 2)}</pre>`;
  }

  // ==================== 模型配置 ====================
  function loadModelConfig() {
    // 从环境变量或 API 加载模型配置
    console.log('[AgentLab] 加载模型配置:', state.modelConfig);
  }

  // ==================== 工具函数 ====================
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ==================== 启动 ====================
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // 暴露到全局，供 app.js 调用
  window.AgentLab = { switchView: switchView };

})();
