/* IcPdfParser 工作台前端。无框架：fetch + 原生 DOM，兼容老 Chromium。 */
(function () {
  "use strict";

  var state = {
    view: "tasks",
    page: 1,
    size: 20,
    q: "",
    status: "",
    batchId: "",
    total: 0,
    selected: {},
    current: null,
    tab: "txt"
  };

  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  };

  function toast(msg, isErr) {
    var t = $("toast");
    t.textContent = msg;
    t.className = "toast" + (isErr ? " err" : "");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.className = "toast hide"; }, 4200);
  }

  function api(path, opts) {
    opts = opts || {};
    var cfg = { method: opts.method || "GET", headers: {} };
    if (opts.body !== undefined) {
      cfg.headers["Content-Type"] = "application/json";
      cfg.body = JSON.stringify(opts.body);
    }
    return fetch(path, cfg).then(function (r) {
      if (r.status === 401) { location.reload(); throw new Error("未登录"); }
      return r.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = { detail: txt }; }
        if (!r.ok) {
          var msg = (data && (data.detail || data.message)) || ("HTTP " + r.status);
          throw new Error(typeof msg === "string" ? msg : JSON.stringify(msg));
        }
        return data;
      });
    });
  }

  function fmtSize(n) {
    if (!n) return "—";
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(0) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  }

  function fmtTime(s) {
    if (!s) return "—";
    return String(s).replace("T", " ").slice(0, 16);
  }

  /* ---------------- 视图切换 ---------------- */
  var TITLES = { tasks: "型号任务", batch: "上传批次", data: "数据源", system: "运行状态", qc: "质量审计 QC",
                 deliveries: "QC 交付历史", feedback: "客户反馈闭环",
                 analyzer: "pandas QC 分析",
                 "i18n-overview": "多语言质量总览", "i18n-jobs": "翻译任务",
                 "i18n-review": "AI 语义审校", "i18n-lqa": "LQA 质量门禁",
                 "i18n-terms": "半导体术语库", "i18n-memory": "批准译文记忆库",
                 "i18n-reports": "质量报告", "i18n-settings": "模型与策略",
                 "agent-chat": "QC Agent Chat", "agent-tools": "工具注册表",
                 "agent-tasks": "任务历史", "agent-models": "模型路由", "agent-audit": "审计日志" };

  function switchView(v, keepHash) {
    state.view = v;
    if (!keepHash) {
      try { history.replaceState(null, "", "#view=" + v); } catch (e) {}
    }
    var items = document.querySelectorAll(".nav-item");
    for (var i = 0; i < items.length; i++) {
      var cls = "nav-item" + (items[i].getAttribute("data-sub") === "1" ? " sub" : "");
      items[i].className = cls + (items[i].getAttribute("data-view") === v ? " active" : "");
    }
    var grp = $("navI18n");
    if (grp) {
      grp.className = "nav-group" + (v.indexOf("i18n-") === 0 ? " has-active" : " collapsed");
    }
    var grpAgent = $("navAgent");
    if (grpAgent) {
      grpAgent.className = "nav-group" + (v.indexOf("agent-") === 0 ? " has-active" : " collapsed");
    }
    var views = document.querySelectorAll(".view");
    for (var j = 0; j < views.length; j++) {
      views[j].className = "view" + (views[j].id === "view-" + v ? "" : " hide");
    }
    $("viewTitle").textContent = TITLES[v] || v;
    if (v === "tasks") { loadOverview(); loadItems(); loadBatches(); }
    if (v === "batch") loadBatchTable();
    if (v === "data") loadData();
    if (v === "system") loadSystem();
    if (v === "qc") loadQC();
    if (v === "deliveries") loadDeliveries();
    if (v === "feedback") loadFeedback();
    if (v === "analyzer") loadAnalyzer();
    if (v.indexOf("i18n-") === 0 && window.I18NQA) window.I18NQA.show(v.slice(5));
    if (v.indexOf("agent-") === 0 && window.AgentLab) window.AgentLab.switchView(v);
  }
  window.switchViewTo = switchView;

  function loadSideInfo() {
    api("/api/health").then(function (h) {
      $("sideCatalog").textContent = "内链索引 " +
        (h.catalog.rows ? (h.catalog.rows / 10000).toFixed(1) + " 万条" : "未建");
      $("sideImages").textContent = "配图表 " + h.images.categories + " 类";
      var pill = $("modePill");
      if (h.mode === "celery") { pill.className = "pill ok"; pill.textContent = "Celery + Redis"; }
      else if (h.mode === "inline") { pill.className = "pill warn"; pill.textContent = "降级：进程内线程池"; }
      else { pill.className = "pill bad"; pill.textContent = "队列不可用"; }
      $("sideMode").textContent = "队列：" +
        (h.mode === "celery" ? "Celery" : (h.mode === "inline" ? "线程池" : "不可用"));
    }).catch(function () {});
    api("/api/qc/overview").then(function (d) { qcBadge(d.badge); })
      .catch(function () {});
  }

  /* ---------------- 质量审计 QC ---------------- */
  var qcState = { tab: "ov", logPage: 1, logSize: 50, logTotal: 0,
                  pollTimer: null, pollRun: 0, pollSeen: 0 };

  function qcBadge(n) {
    var b = $("qcBadge");
    if (!b) return;
    b.textContent = n > 0 ? (n > 99 ? "99+" : String(n)) : "";
  }

  function qcSetTab(t) {
    qcState.tab = t;
    var tabs = document.querySelectorAll("#qcTabs .tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].className = "tab" + (tabs[i].getAttribute("data-qctab") === t ? " active" : "");
    }
    var panels = ["ov", "run", "log", "fix", "lint", "gold", "ev", "risk", "sample", "eng", "fb"];
    for (var j = 0; j < panels.length; j++) {
      var p = $("qc-" + panels[j]);
      if (p) p.className = panels[j] === t ? "" : "hide";
    }
    if (t === "ov") loadQCOverview();
    if (t === "run") { loadQCOverview(); loadQCRuns(); }
    if (t === "log") loadQCLog();
    if (t === "fix") loadQCFixtures();
    if (t === "lint") loadQCLint(0);
    if (t === "gold") loadGold();
    if (t === "ev") loadEvidence();
    if (t === "risk") loadRisk();
    if (t === "sample") loadSample();
    if (t === "eng") loadEngines();
    if (t === "fb") loadFb();
  }

  function loadQC() {
    var sel = selectedKeys().length;
    if ($("qcSelN")) $("qcSelN").textContent = sel ? ("(" + sel + ")") : "";
    qcSetTab(qcState.tab || "ov");
  }

  /* ---------------- QC 交付历史 ---------------- */
  function delivLayerPill(st) {
    var cls = st === "PASS" ? "ok" : (st === "FAIL" ? "bad" : "warn");
    return "<span class='pill " + cls + "'>" + esc(st || "—") + "</span>";
  }

  var DELIV_GATE_SHORT = {
    PACKAGE_PASS: "包", PROVENANCE_PASS: "溯源", DATA_SEMANTICS_PASS: "语义",
    DOWNSTREAM_PASS: "下游", RELEASE_APPROVED: "发布"
  };
  var DELIV_GATE_ORDER = ["PACKAGE_PASS", "PROVENANCE_PASS", "DATA_SEMANTICS_PASS",
                          "DOWNSTREAM_PASS", "RELEASE_APPROVED"];

  function delivGatePill(key, st) {
    var cls = st === "PASS" ? "ok" : (st === "FAIL" ? "bad" : "warn");
    var txt = st === "NOT_CHECKED" ? "NC" : (st || "—");
    return "<span class='pill " + cls + "' title='" + esc(key) + "'>" +
      esc(DELIV_GATE_SHORT[key] || key) + " " + esc(txt) + "</span> ";
  }

  function delivManualCount(b) {
    return (b.manual_review && b.manual_review.count) || 0;
  }

  var delivCache = [];
  var delivFilter = { status: "", q: "" };
  var delivPage = { page: 1, size: 20 };
  var delivRfSummary = null;     // review-fix 状态汇总（/api/qe/review-fix/summary）

  function loadDeliveries() {
    api("/api/qe/deliveries").then(function (d) {
      delivCache = d.batches || [];
      renderDeliveries();
    }).catch(function (e) { toast("交付历史加载失败：" + e.message, true); });
    api("/api/qe/review-fix/summary").then(function (s) {
      delivRfSummary = s;
      renderDeliveries();
    }).catch(function () { delivRfSummary = null; });
  }

  function delivIsRf(b) {
    return b.kind === "review_fix";
  }

  function delivMatch(b) {
    var st = delivFilter.status, q = (delivFilter.q || "").toLowerCase();
    var aq = b.auto_qc || {}, rel = b.release || {};
    var sc = (b.status || {}).code || "";
    if (st === "blocked" && sc !== "REVIEWED_BLOCKED") return false;
    if (st === "still_warn" && sc !== "REVIEWED_STILL_WARN") return false;
    if (st === "qa_pass" && sc !== "REVIEWED_QA_PASS") return false;
    if (st === "incomplete" && sc !== "INCOMPLETE" && sc !== "LEGACY_UNRESOLVED") return false;
    if (st === "qc_pass" && aq.status !== "PASS") return false;
    if (st === "qc_fail" && aq.status !== "FAIL") return false;
    if (st === "qc_warn" && !(aq.status === "PASS" && (aq.warn_items || 0) > 0)) return false;
    if (st === "batch_fail" && b.verdict !== "FAIL") return false;
    if (st === "batch_partial" && b.verdict !== "PARTIAL") return false;
    if (st === "release_unapproved" &&
        !(rel.status && rel.status !== "UNKNOWN" && !rel.approved)) return false;
    if (q) {
      var hay = (b.id + " " + (b.label || "") + " " + (b.mpns || []).join(" ")).toLowerCase();
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  }

  function renderDeliveries() {
    var all = delivCache;
    var samples = 0, bytes = 0, shots = 0, aqPass = 0, aqFail = 0;
    for (var i = 0; i < all.length; i++) {
      samples += all[i].sample_count || 0;
      if (all[i].zip) bytes += all[i].zip.size || 0;
      shots += delivManualCount(all[i]);
      if (all[i].auto_qc && all[i].auto_qc.status === "PASS") aqPass++;
      else if (all[i].auto_qc && all[i].auto_qc.status === "FAIL") aqFail++;
    }
    var latest = all.length ? all[0] : null;
    var rel = latest && latest.release;
    var mb = bytes / 1048576;
    var rf = delivRfSummary || {};
    var rfBlocked = rf.blocked || 0, rfWarn = rf.still_warn || 0;
    var rfPass = rf.qa_pass || 0, rfInc = rf.incomplete || 0;
    var rfKpi = kpi("review-fix 状态",
        rfBlocked + " 阻断 / " + rfWarn + " 警告",
        (rfBlocked ? "bad" : (rfWarn ? "warn" : "ok")),
        "通过 " + rfPass + " · 证据不完整 " + rfInc +
        " · 待成批 " + (rf.pending || 0) + " · " + (rf.batches || 0) + " 批");
    $("delivKpis").innerHTML =
      kpi("交付批次", all.length) +
      kpi("样本型号", samples) +
      rfKpi +
      kpi("最新批次", latest ? latest.date : "—", "", latest ? latest.id : "暂无") +
      kpi("ZIP 总大小", mb >= 1024 ? (mb / 1024).toFixed(2) + " GB" : mb.toFixed(2) + " MB") +
      kpi("自动 QC", aqPass + " PASS / " + aqFail + " FAIL",
          aqFail ? "bad" : (aqPass ? "ok" : ""), "机器检查；不代表发布批准") +
      kpi("发布状态", rel && rel.status !== "UNKNOWN"
            ? (rel.approved ? "已批准" : "未批准") : "—",
          rel && rel.approved ? "ok" : "bad",
          latest ? ("audit v" + (latest.audit_version || 1) + " · " +
                    delivGatePassText(rel)) : "暂无") +
      kpi("人工核对截图", shots, shots ? "ok" : "warn", "批次留痕，可点击查看");
    var bs = [];
    for (var fi = 0; fi < all.length; fi++) {
      if (delivMatch(all[fi])) bs.push(all[fi]);
    }
    if ($("delivFilterInfo")) {
      $("delivFilterInfo").textContent = (delivFilter.status || delivFilter.q)
        ? "显示 " + bs.length + " / " + all.length + " 批"
        : all.length + " 批";
    }
    var pages = Math.max(1, Math.ceil(bs.length / delivPage.size));
    if (delivPage.page > pages) delivPage.page = pages;
    if (delivPage.page < 1) delivPage.page = 1;
    var start = (delivPage.page - 1) * delivPage.size;
    var rows = bs.slice(start, start + delivPage.size);
    var html = "";
    for (var j = 0; j < rows.length; j++) {
      var b = rows[j];
      var mpns = "";
      var mpnMax = 3, mpnLen = (b.mpns || []).length;
      for (var k = 0; k < Math.min(mpnMax, mpnLen); k++) {
        mpns += "<span class='tag'>" + esc(b.mpns[k]) + "</span> ";
      }
      if (mpnLen > mpnMax) {
        mpns += "<span class='sub'>+" + (mpnLen - mpnMax) + " 件</span>";
      }
      var layers = "";
      var L = ["L1", "L2", "L3", "L4"];
      if (delivIsRf(b)) {
        layers = "<span class='tag ok'>review-fix</span> <span class='sub'>不走 L1–L4 四层门禁</span>";
      } else {
        for (var li = 0; li < L.length; li++) {
          var ly = (b.layers || {})[L[li]] || {};
          layers += "<span class='mono'>" + L[li] + "</span> " + delivLayerPill(ly.status) + " ";
        }
      }
      var vtag;
      if (delivIsRf(b)) {
        var stCode = (b.status || {}).code || "";
        var stLabel = (b.status || {}).label || "";
        var stLegacy = (b.status || {}).legacy;
        var vcls = stCode === "REVIEWED_BLOCKED" ? "failed"
                 : (stCode === "REVIEWED_STILL_WARN" ? "warn"
                 : (stCode === "REVIEWED_QA_PASS" ? "ok"
                 : "nodata"));
        vtag = statusTag(vcls, stLegacy ? ("旧口径：" + (stLabel || stCode || "未重算"))
                                        : (stLabel || stCode || "—"));
      } else {
        vtag = b.verdict === "PASS" ? statusTag("done", "PASS")
          : (b.verdict === "FAIL" ? statusTag("failed", "FAIL")
          : (b.verdict === "PARTIAL" ? statusTag("queued", "PARTIAL")
          : statusTag("nodata", "UNKNOWN")));
      }
      var z = b.zip;
      var ztxt = z ? (z.mb + " MB<br><span class='sub mono'>" + esc((z.sha256 || "").slice(0, 12)) +
        "…</span>") : "<span class='sub'>无 ZIP</span>";
      var gates = (b.release && b.release.gates) || {};
      var gateHtml = "";
      if (delivIsRf(b)) {
        var rfx = b.review_fix || {};
        var vb = rfx.verdicts_before || {}, va = rfx.verdicts_after || {};
        var vbTxt = Object.keys(vb).map(function (k) { return k + " " + vb[k]; }).join(" / ");
        var vaTxt = Object.keys(va).map(function (k) { return k + " " + va[k]; }).join(" / ");
        gateHtml = statusTag("queued", "RELEASE_APPROVED 未检查") +
          "<div class='sub'>修前 " + esc(vbTxt || "—") + "</div>" +
          "<div class='sub'>修后 " + esc(vaTxt || "—") +
          " · 共改动 " + (rfx.fixes_total || 0) + " 处</div>";
      } else {
        for (var gi = 0; gi < DELIV_GATE_ORDER.length; gi++) {
          var gk = DELIV_GATE_ORDER[gi];
          gateHtml += delivGatePill(gk, gates[gk] || "UNKNOWN");
        }
      }
      var relTag = delivIsRf(b) ? ""
        : (b.release && b.release.status !== "UNKNOWN"
          ? statusTag(b.release.approved ? "done" : "failed",
                      b.release.approved ? "已批准" : "未批准") : "");
      var reportBtns = b.report && b.report.available
        ? "<button class='btn sm' data-delivact='report' data-id='" + esc(b.id) + "'>核验报告（HTML）</button>" +
          "<button class='btn sm ghost' data-delivact='md' data-id='" + esc(b.id) + "'>.md</button>"
        : "<span class='sub'>无报告</span>";
      var zipBtn = z ? "<button class='btn sm ghost' data-delivact='zip' data-id='" +
        esc(b.id) + "'>ZIP</button>" : "";
      var shotN = delivManualCount(b);
      var shotBtn = "<button class='btn sm ghost' data-delivact='manual' data-id='" +
        esc(b.id) + "'>人工核对截图" + (shotN ? " (" + shotN + ")" : "") + "</button>";
      var fb = b.feedback || {};
      var fbBtn = "<button class='btn sm ghost' data-delivact='feedback' data-id='" +
        esc(b.id) + "'>客户反馈" + (fb.issues ? " (" + fb.issues + ")" : "") +
        (fb.blocking ? " · 阻断 " + fb.blocking : "") + "</button>";
      var aq = b.auto_qc || {};
      var aqTag = aq.status
        ? statusTag(aq.status === "PASS" ? "done" : (aq.status === "FAIL" ? "failed" : "queued"),
                    "自动 QC " + aq.status)
        : "";
      var aqExtra = aq.warn_items ? " · 警告 " + aq.warn_items : "";
      html += "<tr><td class='mono'>" + esc(b.id) +
        "<div class='sub'>" + esc(b.label || "") + "</div>" +
        (aqTag ? "<div class='sub'>" + aqTag + esc(aqExtra) + "</div>" : "") +
        "</td><td>" + esc(b.date) +
        "</td><td>" + mpns + "<div class='sub'>" + (b.fields_total || 0) + " 字段</div></td>" +
        "<td>" + layers + "<div class='sub'>" + vtag + " " + esc(b.verdict_note || "") +
        "</div></td><td>" + gateHtml + (relTag ? "<div class='sub'>" + relTag + "</div>" : "") +
        "</td><td>" + ztxt + "</td><td>" + reportBtns + zipBtn + shotBtn + fbBtn + "</td></tr>";
    }
    if (!html) {
      html = all.length
        ? "<tr><td colspan='7' class='empty'>没有匹配的批次（当前筛选：状态、批次/型号关键词）</td></tr>"
        : "<tr><td colspan='7' class='empty'>还没有交付批次（data/qc/&lt;batch&gt;/）</td></tr>";
    }
    $("delivBody").innerHTML = html;
    renderDelivPager(bs.length, pages, start, rows.length);
  }

  function renderDelivPager(total, pages, start, shown) {
    var info = $("delivPageInfo"), prev = $("delivPrev");
    var next = $("delivNext"), sel = $("delivPageSel");
    if (info) {
      info.textContent = total
        ? "第 " + delivPage.page + " / " + pages + " 页 · " +
          (start + 1) + "–" + (start + shown) + " / 共 " + total + " 批"
        : "第 1 / 1 页 · 0 批";
    }
    if (prev) prev.disabled = delivPage.page <= 1;
    if (next) next.disabled = delivPage.page >= pages;
    if (sel) {
      var want = "";
      for (var i = 1; i <= pages; i++) {
        want += "<option value='" + i + "'>第 " + i + " 页</option>";
      }
      if (sel.getAttribute("data-pages") !== String(pages)) {
        sel.innerHTML = want;
        sel.setAttribute("data-pages", String(pages));
      }
      sel.value = String(delivPage.page);
    }
  }

  function delivGatePassText(rel) {
    if (!rel || !rel.gates) return "无发布门禁";
    var pass = 0, n = 0;
    for (var k in rel.gates) {
      if (!rel.gates.hasOwnProperty(k)) continue;
      n++;
      if (rel.gates[k] === "PASS") pass++;
    }
    return pass + "/" + n + " PASS";
  }

  function openDelivManual(id) {
    $("qeDrawerMask").className = "drawer-mask";
    $("qeDrawer").className = "drawer";
    $("qeDTitle").textContent = "人工核对截图 · " + id;
    $("qeDSub").textContent = "用户上传的核对留痕；点击缩略图看原图。截图不自动改变 L3/发布门禁结论。";
    $("qeDBody").innerHTML = "<div class='sub'>加载中…</div>";
    loadDelivManual(id);
  }

  function delivManualBase(id) {
    return "/api/qe/deliveries/" + encodeURIComponent(id) + "/manual-review";
  }

  function loadDelivManual(id) {
    api(delivManualBase(id)).then(function (d) {
      var items = d.items || [];
      var html = "<div class='shot-upload'>" +
        "<input type='file' id='delivShotFiles' accept='image/png,image/jpeg,image/webp,image/gif' multiple>" +
        "<button class='btn sm' id='delivShotUpload'>上传截图</button>" +
        "<span class='sub'>PNG/JPG/WebP/GIF，单张 ≤8MB，单次 ≤12 张</span></div>";
      if (!items.length) {
        html += "<div class='empty'>还没有人工核对截图；可上传 PDF 表格/页面截图作为留痕。</div>";
      } else {
        html += "<div class='shot-grid'>";
        for (var i = 0; i < items.length; i++) {
          var it = items[i];
          html += "<div class='shot-card'><a href='" + esc(it.url) +
            "' target='_blank' rel='noopener'><img class='shot-img' src='" + esc(it.url) +
            "' alt='" + esc(it.name) + "'></a><div class='mono'>" + esc(it.name) +
            "</div><div class='sub'>" + fmtSize(it.size) + " · " + fmtTime(it.mtime) +
            "</div></div>";
        }
        html += "</div>";
      }
      $("qeDBody").innerHTML = html;
      if ($("delivShotUpload")) {
        $("delivShotUpload").addEventListener("click", function () { uploadDelivShots(id); });
      }
    }).catch(function (e) { toast("截图加载失败：" + e.message, true); });
  }

  function uploadDelivShots(id) {
    var input = $("delivShotFiles");
    if (!input || !input.files || !input.files.length) {
      toast("请先选择图片", true); return;
    }
    var fd = new FormData();
    for (var i = 0; i < input.files.length; i++) {
      fd.append("files", input.files[i], input.files[i].name);
    }
    var btn = $("delivShotUpload");
    if (btn) { btn.disabled = true; btn.textContent = "上传中…"; }
    fetch(delivManualBase(id), { method: "POST", body: fd }).then(function (r) {
      if (r.status === 401) { location.reload(); throw new Error("未登录"); }
      return r.json().then(function (d) {
        if (!r.ok) throw new Error(d.detail || ("HTTP " + r.status));
        return d;
      });
    }).then(function (d) {
      var bad = (d.errors || []).map(function (e) {
        return (e.name ? e.name + "：" : "") + e.error;
      }).join("；");
      toast("已上传 " + (d.saved || []).length + " 张" + (bad ? "；" + bad : ""), !!bad);
      loadDelivManual(id);
      loadDeliveries();
    }).catch(function (e) {
      toast("上传失败：" + e.message, true);
      if (btn) { btn.disabled = false; btn.textContent = "上传截图"; }
    });
  }

  /* ---------------- 客户反馈闭环 ---------------- */
  var FB_BASE = "/api/qe/customer-feedback/v1";
  var FB_CAT = {
    IDENTITY_PACKAGE: "型号与封装", ELECTRICAL_TABLE: "电气表解析",
    PIN_MAPPING: "引脚映射", CONTENT_CONSISTENCY: "内容一致性",
    TRANSLATION: "多语言", DUPLICATE_CONTENT: "重复内容",
    RENDER_ASSET: "渲染与图片", STATUS_SEMANTICS: "状态语义", OTHER: "其他"
  };
  var FB_SEV = { P0_BLOCKER: "P0 阻断", P1_HIGH: "P1 高", P2_NORMAL: "P2 普通",
                 P3_LOW: "P3 低" };
  var FB_STATUS = {
    OPEN: "待复现", NEEDS_REPRODUCTION: "需复现", TRIAGED: "已定位",
    IN_PROGRESS: "修复中", READY_FOR_REGRESSION: "待回归",
    REGRESSION_PASSED: "回归通过", PENDING_HUMAN_ACCEPTANCE: "待人工验收",
    ACCEPTED: "已验收", CLOSED: "已关闭", WAIVED: "已豁免"
  };
  var fbState = { status: "", severity: "", category: "", batch: "", q: "",
                  meta: null, items: [], total: 0 };

  function fbKey(path) { return FB_BASE + path; }

  function fbLabel(map, k) { return map[k] || k || "—"; }

  function fbStatusTag(st) {
    var cls = st === "CLOSED" || st === "ACCEPTED" ? "done"
      : (st === "WAIVED" ? "queued"
      : (st === "REGRESSION_PASSED" || st === "PENDING_HUMAN_ACCEPTANCE" ? "queued"
      : (st === "NEEDS_REPRODUCTION" ? "nodata" : "failed")));
    return "<span class='tag " + cls + "'>" + esc(fbLabel(FB_STATUS, st)) + "</span>";
  }

  function fbSevTag(sev) {
    var cls = sev === "P0_BLOCKER" ? "failed"
      : (sev === "P1_HIGH" ? "queued" : "done");
    return "<span class='tag " + cls + "'>" + esc(fbLabel(FB_SEV, sev)) + "</span>";
  }

  function fbEnsureMeta() {
    if (fbState.meta) return Promise.resolve(fbState.meta);
    return api(fbKey("/meta")).then(function (m) {
      fbState.meta = m;
      fbFillSelect("fbStatus", m.statuses, FB_STATUS, "全部状态");
      fbFillSelect("fbSeverity", m.severities, FB_SEV, "全部严重度");
      fbFillSelect("fbCategory", m.categories, FB_CAT, "全部类型");
      return m;
    });
  }

  function fbFillSelect(id, values, labels, allText) {
    var el = $(id);
    if (!el) return;
    var cur = el.value;
    var html = "<option value=''>" + allText + "</option>";
    for (var i = 0; i < values.length; i++) {
      html += "<option value='" + esc(values[i]) + "'>" +
        esc(labels[values[i]] || values[i]) + "</option>";
    }
    el.innerHTML = html;
    if (cur) el.value = cur;
  }

  function fbSyncFilters() {
    if ($("fbStatus")) $("fbStatus").value = fbState.status;
    if ($("fbSeverity")) $("fbSeverity").value = fbState.severity;
    if ($("fbCategory")) $("fbCategory").value = fbState.category;
    if ($("fbBatch")) $("fbBatch").value = fbState.batch;
    if ($("fbQ")) $("fbQ").value = fbState.q;
  }

  function fbQuery() {
    var p = ["limit=100"];
    if (fbState.status) p.push("status=" + encodeURIComponent(fbState.status));
    if (fbState.severity) p.push("severity=" + encodeURIComponent(fbState.severity));
    if (fbState.category) p.push("category=" + encodeURIComponent(fbState.category));
    if (fbState.batch) p.push("batch_id=" + encodeURIComponent(fbState.batch));
    if (fbState.q) p.push("q=" + encodeURIComponent(fbState.q));
    return p.join("&");
  }

  function loadFeedback() {
    fbSyncFilters();
    fbEnsureMeta().then(function () {
      return Promise.all([
        api(fbKey("/dashboard")),
        api(fbKey("/issues?" + fbQuery()))
      ]);
    }).then(function (arr) {
      var d = arr[0], l = arr[1];
      $("fbKpis").innerHTML =
        kpi("问题总数", d.total) +
        kpi("未关闭阻断", d.blocking, d.blocking ? "bad" : "ok", "P0/P1 未关闭") +
        kpi("待人工验收", d.pending_acceptance, d.pending_acceptance ? "warn" : "") +
        kpi("回归失败问题", d.regression_fail_issues,
            d.regression_fail_issues ? "bad" : "") +
        kpi("问题关闭率", d.closed_rate + "%", "", d.closed + "/" + d.total) +
        kpi("样本验证覆盖", d.sample_coverage + "%", "",
            d.samples_accepted + "/" + d.samples);
      fbState.items = l.items || [];
      fbState.total = l.total || 0;
      if ($("fbFilterInfo")) $("fbFilterInfo").textContent = "显示 " +
        fbState.items.length + " / " + fbState.total + " 条";
      var html = "";
      for (var i = 0; i < fbState.items.length; i++) {
        var it = fbState.items[i];
        html += "<tr><td class='mono'>" + esc(it.issue_key) +
          (it.source ? "<div class='sub'>" + esc(it.source) + "</div>" : "") +
          "</td><td><b>" + esc(it.title) + "</b><div class='sub'>" +
          esc((it.description || "").slice(0, 120)) + "</div></td><td>" +
          esc(fbLabel(FB_CAT, it.category)) + "</td><td>" + fbSevTag(it.severity) +
          "</td><td>" + fbStatusTag(it.status) + "</td><td>" +
          (it.sample_count || 0) + "</td><td>" +
          (it.blocking ? "<span class='tag failed'>阻断</span>" : "—") +
          "</td><td class='sub'>" + esc(fmtTime(it.updated_at)) +
          "</td><td><button class='btn sm ghost' data-fbopen='" + esc(it.issue_key) +
          "'>详情</button></td></tr>";
      }
      $("fbBody").innerHTML = html ||
        "<tr><td colspan='9' class='empty'>还没有客户反馈问题单；可新建。</td></tr>";
    }).catch(function (e) { toast("客户反馈加载失败：" + e.message, true); });
  }

  function openFeedbackForBatch(batchId) {
    fbState.batch = batchId || "";
    if ($("fbBatch")) $("fbBatch").value = fbState.batch;
    switchView("feedback");
  }

  function fbOptions(values, labels) {
    var html = "";
    for (var i = 0; i < values.length; i++) {
      html += "<option value='" + esc(values[i]) + "'>" +
        esc(labels[values[i]] || values[i]) + "</option>";
    }
    return html;
  }

  function fbVal(id) {
    var el = $(id);
    return el ? String(el.value || "").trim() : "";
  }

  function openFeedbackCreate() {
    fbEnsureMeta().then(function (m) {
      $("qeDrawerMask").className = "drawer-mask";
      $("qeDrawer").className = "drawer";
      $("qeDTitle").textContent = "新建客户反馈问题";
      $("qeDSub").textContent = "问题单创建后通过状态机推进；证据/回归/验收均为追加审计";
      $("qeDBody").innerHTML =
        "<div class='fb-form'>" +
        "<label>标题<input class='input' id='fbCTitle' placeholder='如：电气参数表格错列'></label>" +
        "<label>描述<textarea class='input' id='fbCDesc' rows='3'></textarea></label>" +
        "<div class='fb-row'><label>类型<select class='input' id='fbCCat'>" +
        fbOptions(m.categories, FB_CAT) + "</select></label>" +
        "<label>严重度<select class='input' id='fbCSev'>" +
        fbOptions(m.severities, FB_SEV) + "</select></label>" +
        "<label>来源<select class='input' id='fbCSource'><option value='CUSTOMER'>客户</option>" +
        "<option value='INTERNAL_QC'>内部 QC</option><option value='SUPPORT'>支持</option>" +
        "<option value='OTHER'>其他</option></select></label></div>" +
        "<label>客户参考<input class='input' id='fbCRef' placeholder='support-123'></label>" +
        "<label>预期行为<textarea class='input' id='fbCExp' rows='2'></textarea></label>" +
        "<label>实际行为<textarea class='input' id='fbCAct' rows='2'></textarea></label>" +
        "<label>复现步骤<textarea class='input' id='fbCRepro' rows='2'></textarea></label>" +
        "<div class='fb-row'><button class='btn' id='fbCreateSubmit'>创建问题单</button>" +
        "<button class='btn ghost' id='fbCreateCancel'>取消</button></div></div>";
      $("fbCreateCancel").addEventListener("click", closeQeDrawer);
      $("fbCreateSubmit").addEventListener("click", function () {
        var body = {
          title: fbVal("fbCTitle"), description: fbVal("fbCDesc"),
          category: fbVal("fbCCat"), severity: fbVal("fbCSev"),
          source: fbVal("fbCSource"), customer_reference: fbVal("fbCRef"),
          expected_behavior: fbVal("fbCExp"), actual_behavior: fbVal("fbCAct"),
          reproduction_steps: fbVal("fbCRepro")
        };
        api(fbKey("/issues"), { method: "POST", body: body }).then(function (d) {
          toast("已创建 " + d.issue.issue_key);
          closeQeDrawer();
          loadFeedback();
        }).catch(function (e) { toast("创建失败：" + e.message, true); });
      });
    }).catch(function (e) { toast("元数据加载失败：" + e.message, true); });
  }

  function openFeedbackIssue(key) {
    api(fbKey("/issues/" + encodeURIComponent(key))).then(function (d) {
      $("qeDrawerMask").className = "drawer-mask";
      $("qeDrawer").className = "drawer";
      $("qeDTitle").textContent = d.issue.issue_key + " · " + d.issue.title;
      $("qeDSub").textContent = fbLabel(FB_CAT, d.issue.category) + " · " +
        fbLabel(FB_SEV, d.issue.severity) + " · " +
        fbLabel(FB_STATUS, d.issue.status) +
        (d.blocking ? " · 阻断发布" : "") +
        (d.high_risk ? " · 高风险类" : "");
      $("qeDBody").innerHTML = fbDetailHtml(d);
      fbBindDetail(key, d);
    }).catch(function (e) { toast("问题详情加载失败：" + e.message, true); });
  }

  function fbDetailHtml(d) {
    var i = d.issue;
    var trans = (fbState.meta && fbState.meta.transitions[i.status]) || [];
    var h = "<div class='fb-detail'>" +
      "<div class='fb-meta'><div><span class='sub'>状态</span> " + fbStatusTag(i.status) +
      "</div><div><span class='sub'>严重度</span> " + fbSevTag(i.severity) +
      "</div><div><span class='sub'>样本</span> " + d.samples.length +
      "</div><div><span class='sub'>版本</span> " + i.version + "</div></div>" +
      "<p>" + esc(i.description) + "</p>" +
      "<div class='kv-row'><div class='kv-k'>预期行为</div><div class='kv-v'>" +
      esc(i.expected_behavior || "—") + "</div></div>" +
      "<div class='kv-row'><div class='kv-k'>实际行为</div><div class='kv-v'>" +
      esc(i.actual_behavior || "—") + "</div></div>" +
      "<div class='kv-row'><div class='kv-k'>复现步骤</div><div class='kv-v'>" +
      esc(i.reproduction_steps || "—") + "</div></div>" +
      "<div class='kv-row'><div class='kv-k'>根因假设（待证）</div><div class='kv-v'>" +
      esc(i.root_cause_hypothesis || "—") + "</div></div>" +
      "<div class='kv-row'><div class='kv-k'>所需证据</div><div class='kv-v'>" +
      esc(i.required_evidence || "—") + "</div></div>" +
      "<div class='kv-row'><div class='kv-k'>验收标准</div><div class='kv-v'>" +
      esc(i.acceptance_criteria || "—") + "</div></div>" +
      "<div class='fb-form fb-inline'><label>推进状态<select class='input' id='fbTransTo'>" +
      (trans.length ? fbOptions(trans, FB_STATUS) : "<option value=''>无可用迁移</option>") +
      "</select></label><label>原因<input class='input' id='fbTransReason'></label>" +
      "<button class='btn sm' id='fbTransApply' " + (trans.length ? "" : "disabled") +
      ">执行</button>" +
      (i.status === "ACCEPTED"
        ? "<button class='btn sm ghost' id='fbCloseIssue'>关闭问题</button>" : "") +
      "</div>" +
      "<h4>受影响样本</h4>" + fbSamplesHtml(d) +
      "<div class='fb-form fb-inline'><input class='input' id='fbSBatch' placeholder='批次 ID' value='" +
      esc(fbState.batch || (d.samples[0] ? d.samples[0].batch_id : "")) + "'>" +
      "<input class='input' id='fbSMpn' placeholder='MPN'>" +
      "<input class='input' id='fbSField' placeholder='字段路径（可空）'>" +
      "<input class='input' id='fbSExpected' placeholder='预期值'>" +
      "<input class='input' id='fbSActual' placeholder='实际值'>" +
      "<button class='btn sm' id='fbAddSample'>关联样本</button></div>" +
      "<h4>原厂证据</h4>" + fbEvidenceHtml(d) +
      "<div class='fb-form fb-inline'><select class='input' id='fbEvType'>" +
      fbOptions(fbState.meta ? fbState.meta.evidence_types :
                ["MANUFACTURER_PDF", "CUSTOMER_SCREENSHOT", "HTML_RENDER", "OTHER"],
                {MANUFACTURER_PDF: "原厂 PDF", MANUFACTURER_PRODUCT_PAGE: "原厂页面",
                 ERRATA: "Errata", APP_NOTE: "应用笔记", CUSTOMER_SCREENSHOT: "客户截图",
                 HTML_RENDER: "HTML 渲染", LOG: "日志", OTHER: "其他"}) +
      "</select><input class='input' id='fbEvPage' placeholder='页码' style='width:70px'>" +
      "<input class='input' id='fbEvTitle' placeholder='文档标题'>" +
      "<input class='input' id='fbEvSha' placeholder='文档 SHA256（可空）'>" +
      "<input class='input' id='fbEvQuote' placeholder='原文 quote'>" +
      "<button class='btn sm' id='fbAddEvidence'>登记证据</button></div>" +
      "<h4>修复记录</h4>" + fbFixesHtml(d) +
      "<div class='fb-form fb-inline'><input class='input' id='fbFixSummary' placeholder='修复摘要'>" +
      "<input class='input' id='fbFixCommit' placeholder='commit SHA'>" +
      "<input class='input' id='fbFixRule' placeholder='规则版本'>" +
      "<button class='btn sm' id='fbAddFix'>登记修复</button></div>" +
      "<h4>定向回归</h4>" + fbRegHtml(d) +
      "<div class='fb-form fb-inline'><input class='input' id='fbRegKey' placeholder='run_key'>" +
      "<input class='input' id='fbRegScope' placeholder='范围说明'>" +
      "<select class='input' id='fbRegResult'><option value='PASS'>PASS</option>" +
      "<option value='FAIL'>FAIL</option><option value='PARTIAL'>PARTIAL</option>" +
      "<option value='BLOCKED'>BLOCKED</option></select>" +
      "<input class='input' id='fbRegTotal' placeholder='total' style='width:64px'>" +
      "<input class='input' id='fbRegPassed' placeholder='passed' style='width:64px'>" +
      "<input class='input' id='fbRegFailed' placeholder='failed' style='width:64px'>" +
      "<button class='btn sm' id='fbAddReg'>登记回归</button></div>" +
      "<h4>人工验收</h4>" + fbAccHtml(d) +
      "<div class='fb-form fb-inline'><select class='input' id='fbAccSample'>" +
      (d.samples.length ? fbOptions(d.samples.map(function (s) {
        return String(s.id);
      }), d.samples.reduce(function (m, s) {
        m[String(s.id)] = s.mpn + " / " + (s.field_path || "整体");
        return m;
      }, {})) : "<option value=''>先关联样本</option>") +
      "</select><select class='input' id='fbAccDecision'><option value='ACCEPT'>通过</option>" +
      "<option value='REJECT'>驳回</option><option value='WAIVE'>豁免</option>" +
      "<option value='REOPEN'>重开</option></select>" +
      "<input class='input' id='fbAccScope' placeholder='验收范围'>" +
      "<input class='input' id='fbAccReason' placeholder='验收理由/依据'>" +
      "<button class='btn sm' id='fbAddAcc' " +
      (d.samples.length ? "" : "disabled") + ">提交验收</button></div>" +
      "<h4>审计时间线</h4>" + fbAuditHtml(d.audit) +
      "</div>";
    return h;
  }

  function fbSamplesHtml(d) {
    if (!d.samples.length) return "<div class='empty'>还没有关联样本。</div>";
    var h = "<div class='table-wrap'><table class='grid'><thead><tr>" +
      "<th>MPN</th><th>批次</th><th>字段</th><th>证据</th><th>回归</th><th>验收</th></tr></thead><tbody>";
    for (var i = 0; i < d.samples.length; i++) {
      var s = d.samples[i];
      h += "<tr><td class='mono'>" + esc(s.mpn) + "</td><td class='mono'>" +
        esc(s.batch_id) + "</td><td class='mono'>" + esc(s.field_path || "—") +
        "</td><td>" + esc(s.evidence_status) + "</td><td>" +
        esc(s.regression_status) + "</td><td>" + esc(s.acceptance_status) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function fbEvidenceHtml(d) {
    if (!d.evidence.length) return "<div class='empty'>还没有证据。</div>";
    var h = "<div class='table-wrap'><table class='grid'><thead><tr>" +
      "<th>类型</th><th>文档/页码</th><th>quote</th><th>审核</th><th>操作</th></tr></thead><tbody>";
    for (var i = 0; i < d.evidence.length; i++) {
      var e = d.evidence[i];
      var act = e.review_status === "PENDING"
        ? "<button class='btn sm ghost' data-fbrev='" + e.id + "' data-fbacc='VERIFIED'>通过</button>" +
          "<button class='btn sm ghost' data-fbrev='" + e.id + "' data-fbacc='REJECTED'>驳回</button>"
        : "—";
      h += "<tr><td>" + esc(e.evidence_type) + "</td><td class='mono'>" +
        esc((e.document_title || "—") + " / p" + (e.page_number || "—")) +
        "</td><td class='sub'>" + esc((e.quote_text || "—").slice(0, 100)) +
        "</td><td>" + esc(e.review_status) + "<div class='sub'>" +
        esc(e.review_reason || "") + "</div></td><td>" + act + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function fbFixesHtml(d) {
    if (!d.fixes.length) return "<div class='empty'>还没有修复记录。</div>";
    var h = "<div class='table-wrap'><table class='grid'><thead><tr>" +
      "<th>摘要</th><th>commit</th><th>规则版本</th><th>时间</th></tr></thead><tbody>";
    for (var i = 0; i < d.fixes.length; i++) {
      var f = d.fixes[i];
      h += "<tr><td>" + esc(f.summary) + "</td><td class='mono'>" +
        esc(f.commit_sha || "—") + "</td><td>" + esc(f.rule_version || "—") +
        "</td><td class='sub'>" + esc(fmtTime(f.created_at)) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function fbRegHtml(d) {
    if (!d.regressions.length) return "<div class='empty'>还没有回归记录。</div>";
    var h = "<div class='table-wrap'><table class='grid'><thead><tr>" +
      "<th>run_key</th><th>范围</th><th>结果</th><th>计数</th><th>时间</th></tr></thead><tbody>";
    for (var i = 0; i < d.regressions.length; i++) {
      var r = d.regressions[i];
      h += "<tr><td class='mono'>" + esc(r.run_key) + "</td><td>" +
        esc(r.scope_description) + "</td><td>" +
        (r.result === "PASS" ? "<span class='tag done'>PASS</span>"
          : "<span class='tag failed'>" + esc(r.result) + "</span>") +
        "</td><td>" + r.passed_cases + "/" + r.total_cases + "</td><td class='sub'>" +
        esc(fmtTime(r.created_at)) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function fbAccHtml(d) {
    if (!d.acceptances.length) return "<div class='empty'>还没有验收记录。</div>";
    var h = "<div class='table-wrap'><table class='grid'><thead><tr>" +
      "<th>决定</th><th>范围</th><th>理由</th><th>审核人</th><th>时间</th></tr></thead><tbody>";
    for (var i = 0; i < d.acceptances.length; i++) {
      var a = d.acceptances[i];
      h += "<tr><td>" + esc(a.decision) + "</td><td>" + esc(a.scope_description) +
        "</td><td class='sub'>" + esc(a.reason) + "</td><td>" + esc(a.reviewer) +
        "</td><td class='sub'>" + esc(fmtTime(a.decided_at)) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function fbAuditHtml(audit) {
    if (!audit || !audit.length) return "<div class='empty'>暂无审计记录。</div>";
    var h = "<div class='fb-tl'>";
    for (var i = 0; i < audit.length && i < 30; i++) {
      var a = audit[i];
      h += "<div class='fb-tl-item'><span class='mono'>" + esc(fmtTime(a.created_at)) +
        "</span> <b>" + esc(a.action) + "</b> " + esc(a.actor || "") +
        (a.old_status || a.new_status
          ? " · " + esc(a.old_status || "—") + " → " + esc(a.new_status || "—") : "") +
        "<div class='sub mono'>" + esc((a.payload || "").slice(0, 200)) + "</div></div>";
    }
    h += "</div>";
    return h;
  }

  function fbBindDetail(key, d) {
    function reload() {
      loadFeedback();
      openFeedbackIssue(key);
    }
    if ($("fbTransApply")) {
      $("fbTransApply").addEventListener("click", function () {
        var to = fbVal("fbTransTo"), reason = fbVal("fbTransReason");
        if (!to) return;
        api(fbKey("/issues/" + encodeURIComponent(key) + "/transition"),
            { method: "POST", body: { to_status: to, reason: reason,
                                      version: d.issue.version } })
          .then(function () { toast("状态已更新"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbCloseIssue")) {
      $("fbCloseIssue").addEventListener("click", function () {
        var reason = window.prompt("关闭理由（必填）");
        if (!reason) return;
        api(fbKey("/issues/" + encodeURIComponent(key) + "/close"),
            { method: "POST", body: { reason: reason } })
          .then(function () { toast("问题已关闭"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbAddSample")) {
      $("fbAddSample").addEventListener("click", function () {
        var body = { batch_id: fbVal("fbSBatch"), mpn: fbVal("fbSMpn"),
                     field_path: fbVal("fbSField"), expected_value: fbVal("fbSExpected"),
                     actual_value: fbVal("fbSActual") };
        api(fbKey("/issues/" + encodeURIComponent(key) + "/samples"),
            { method: "POST", body: body })
          .then(function () { toast("样本已关联"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbAddEvidence")) {
      $("fbAddEvidence").addEventListener("click", function () {
        var body = { evidence_type: fbVal("fbEvType"),
                     page_number: Number(fbVal("fbEvPage") || 0),
                     document_title: fbVal("fbEvTitle"),
                     document_sha256: fbVal("fbEvSha"),
                     quote_text: fbVal("fbEvQuote") };
        api(fbKey("/issues/" + encodeURIComponent(key) + "/evidence"),
            { method: "POST", body: body })
          .then(function () { toast("证据已登记"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    var revs = document.querySelectorAll("#qeDBody [data-fbrev]");
    for (var i = 0; i < revs.length; i++) {
      revs[i].addEventListener("click", function () {
        var id = this.getAttribute("data-fbrev");
        var st = this.getAttribute("data-fbacc");
        var reason = st === "REJECTED" ? window.prompt("驳回原因（必填）") : "人工核对通过";
        if (st === "REJECTED" && !reason) return;
        api(fbKey("/evidence/" + encodeURIComponent(id) + "/review"),
            { method: "POST", body: { review_status: st, review_reason: reason } })
          .then(function () { toast("证据审核已记录"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbAddFix")) {
      $("fbAddFix").addEventListener("click", function () {
        var body = { summary: fbVal("fbFixSummary"), commit_sha: fbVal("fbFixCommit"),
                     rule_version: fbVal("fbFixRule") };
        api(fbKey("/issues/" + encodeURIComponent(key) + "/fixes"),
            { method: "POST", body: body })
          .then(function () { toast("修复已登记"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbAddReg")) {
      $("fbAddReg").addEventListener("click", function () {
        var body = { run_key: fbVal("fbRegKey") || ("run-" + Date.now()),
                     scope_type: "SAMPLE", scope_description: fbVal("fbRegScope"),
                     result: fbVal("fbRegResult"),
                     total_cases: Number(fbVal("fbRegTotal") || 0),
                     passed_cases: Number(fbVal("fbRegPassed") || 0),
                     failed_cases: Number(fbVal("fbRegFailed") || 0) };
        api(fbKey("/issues/" + encodeURIComponent(key) + "/regressions"),
            { method: "POST", body: body })
          .then(function () { toast("回归已登记"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("fbAddAcc")) {
      $("fbAddAcc").addEventListener("click", function () {
        var sid = fbVal("fbAccSample");
        var body = { sample_link_id: Number(sid), decision: fbVal("fbAccDecision"),
                     scope_description: fbVal("fbAccScope"),
                     reason: fbVal("fbAccReason"),
                     evidence_ids: [], regression_ids: [] };
        api(fbKey("/issues/" + encodeURIComponent(key) + "/acceptance"),
            { method: "POST", body: body })
          .then(function () { toast("验收决定已记录"); reload(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
  }

  /* ---------------- pandas QC Analyzer ---------------- */
  var AN_BASE = "/api/qe/analyzer/v1";
  var AN = { meta: null, runs: [], run: null, tab: "overview", task: null, cmp: null };

  function anKey(path) { return AN_BASE + path; }
  function anNum(n) {
    if (n === null || n === undefined || n === "") return "—";
    return Number(n).toLocaleString();
  }
  function anPct(v) {
    if (v === null || v === undefined || v === "") return "—";
    return (Number(v) * 100).toFixed(2) + "%";
  }
  function anVal(id) { var e = $(id); return e ? e.value : ""; }

  function anTable(rows, cols, emptyText) {
    if (!rows || !rows.length) {
      return "<div class='empty'>" + esc(emptyText || "暂无数据") + "</div>";
    }
    var h = "<div class='table-wrap tall'><table class='grid compact'><thead><tr>";
    for (var i = 0; i < cols.length; i++) h += "<th>" + esc(cols[i][1]) + "</th>";
    h += "</tr></thead><tbody>";
    for (var j = 0; j < rows.length; j++) {
      h += "<tr>";
      for (var k = 0; k < cols.length; k++) {
        var v = rows[j][cols[k][0]];
        if (v === true) v = "YES";
        if (v === false) v = "NO";
        if (/_rate$/.test(cols[k][0]) && v !== "" && !isNaN(Number(v))) {
          v = anPct(v);
        }
        h += "<td>" + esc(v === null || v === undefined ? "" : v) + "</td>";
      }
      h += "</tr>";
    }
    return h + "</tbody></table></div>";
  }
  function anTableAuto(rows, emptyText) {
    if (!rows || !rows.length) {
      return "<div class='empty'>" + esc(emptyText || "暂无数据") + "</div>";
    }
    var keys = Object.keys(rows[0]);
    return anTable(rows, keys.map(function (k) { return [k, k]; }), emptyText);
  }
  function anBlock(title, body, hint) {
    return "<div style='margin-bottom:16px'><div class='card-head'><h3>" +
      esc(title) + "</h3>" + (hint ? "<span class='hint'>" + esc(hint) + "</span>" : "") +
      "</div>" + body + "</div>";
  }
  function anTasksTable(tasks, limit) {
    var rows = (tasks || []).slice(0, limit || tasks.length);
    if (!rows.length) return "<div class='empty'>暂无候选任务。</div>";
    var h = "<div class='table-wrap tall'><table class='grid compact'><thead><tr>" +
      "<th>#</th><th>优先级</th><th>来源</th><th>问题组</th><th>MPN / 批次</th>" +
      "<th>候选技术环节</th><th>证据缺口</th><th>建议动作</th></tr></thead><tbody>";
    for (var i = 0; i < rows.length; i++) {
      var t = rows[i];
      var idx = (tasks || []).indexOf(t);
      h += "<tr data-antask='" + idx + "' style='cursor:pointer'" +
        (AN.task && AN.task.task_key === t.task_key ? " class='sel'" : "") + ">" +
        "<td>" + esc(t.index) + "</td>" +
        "<td>" + esc(t.priority) + "</td>" +
        "<td>" + esc(t.source_system) + "</td>" +
        "<td>" + esc(t.group_name) + "</td>" +
        "<td><b>" + esc(t.mpn || "—") + "</b><div class='sub'>" + esc(t.batch_id || "") + "</div></td>" +
        "<td>" + esc(t.candidate_layer) + "</td>" +
        "<td>" + esc(t.evidence_gap) + "</td>" +
        "<td>" + esc(t.suggested_action) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }
  function anTaskDetail() {
    var t = AN.task;
    if (!t) return "<div class='empty'>点击任务行查看详情。</div>";
    function kv(k, v) {
      return "<div class='kv'><label>" + esc(k) + "</label><strong>" +
        esc(v === null || v === undefined || v === "" ? "—" : v) + "</strong></div>";
    }
    return "<div class='card' style='background:#fbfcfe;margin-top:12px'>" +
      "<div class='card-head'><h3>" + esc(t.task_key) + " · " + esc(t.priority) +
      "</h3><span class='hint'>候选任务 · 人工确认后才能建反馈单 / 改代码</span></div>" +
      "<div class='cols'>" +
      "<div>" + kv("来源", t.source_system) + kv("问题组", t.group_name) +
      kv("MPN", t.mpn) + kv("批次", t.batch_id) +
      kv("异常信号", t.signal) + "</div>" +
      "<div>" + kv("候选技术环节", t.candidate_layer) +
      kv("证据缺口", t.evidence_gap) + kv("建议动作", t.suggested_action) +
      kv("回归范围", t.regression_scope) +
      kv("边界", "人工确认 / 不改 facts / 不自动关闭") + "</div></div></div>";
  }
  function anRunInfo() {
    var r = AN.run;
    if (!r) return "";
    return "<div class='sub' style='margin-bottom:10px'>记录 <b>" + esc(r.run_key) +
      "</b> · " + esc(fmtTime(r.generated_at)) + " · 快照 " + esc(r.snapshot_id) +
      " · 矩阵 " + esc(r.matrix_version) + " · 分析器 " + esc(r.analyzer_version) +
      " · 扫描 " + anNum(r.inventory.matrix_rows) + " 件 / FAIL " +
      anNum(r.inventory.matrix_fail) + " 件</div>";
  }

  function anOverviewHtml() {
    var r = AN.run, d = r.distributions || {};
    var h = anRunInfo();
    h += "<div class='cols'><div>" +
      anBlock("异常类别分布（auto QC 矩阵 FAIL）",
        anTable(d.by_group || [], [["root_cause_groups", "问题组"], ["count", "数量"]]),
        "分类可能重叠；不直接相加当根因结论") +
      anBlock("失败码分布",
        anTable(d.by_fail_code || [], [["fail_code", "失败码"], ["count", "数量"]])) +
      anBlock("反馈问题类型",
        anTable(d.feedback_by_category || [], [["category", "类型"], ["count", "数量"]])) +
      anBlock("厂商异常率",
        anTable(d.by_brand || [], [
          ["brand", "厂商"], ["total", "总数"], ["fail", "FAIL"], ["fail_rate", "失败率"]])) +
      anBlock("解析器版本异常率",
        anTable(d.by_parser || [], [
          ["facts_model", "解析器"], ["total", "总数"], ["fail", "FAIL"],
          ["fail_rate", "失败率"]])) +
      "</div><div>" +
      anBlock("批次失败排行（前 30）",
        anTable((d.by_batch || []).slice(0, 12),
          [["batch_id", "批次"], ["total", "总数"], ["fail", "FAIL"], ["fail_rate", "失败率"]])) +
      anBlock("型号家族异常率（前缀启发式）",
        anTable((d.by_family || []).slice(0, 15),
          [["_family", "家族前缀"], ["total", "总数"], ["fail", "FAIL"], ["fail_rate", "失败率"]]),
        "家族前缀由 MPN 规则截取，仅用于排序") +
      anBlock("来源异常原因分布",
        anTable((r.identity_source || {}).by_reason || [],
          [["reason", "原因"], ["count", "数量"]]),
        "MPN / PDF SHA / revision / facts 来源") +
      anBlock("来源/身份待核实（前 30）",
        anTable(((r.identity_source || {}).items || []).slice(0, 30),
          [["source_system", "来源"], ["mpn", "MPN"], ["batch_id", "批次"],
           ["reasons", "原因"], ["priority", "优先级"]]),
        "完整清单见分析包 02_identity_source_anomalies.csv") +
      anBlock("近期高优先级候选任务",
        anTasksTable(r.tasks || [], 8),
        "点击行查看候选细节") +
      "</div></div>";
    if (AN.task) h += anTaskDetail();
    if (r.caveats && r.caveats.length) {
      h += "<div class='card' style='background:#fff8e9;border-color:#f4dfb6'>" +
        "<b>边界</b><ul style='margin:8px 0 0 18px;padding:0'>";
      for (var i = 0; i < r.caveats.length; i++) h += "<li>" + esc(r.caveats[i]) + "</li>";
      h += "</ul></div>";
    }
    return h;
  }

  function anTasksHtml() {
    var r = AN.run;
    var h = "<div class='tools' style='margin-bottom:10px'>" +
      "<button class='btn ghost' id='anTaskCsv'>导出任务 CSV</button>" +
      "<button class='btn ghost' id='anTaskXlsx'>导出任务 Excel</button>" +
      "<span class='hint'>候选任务 = 排查线索；不能自动变成根因结论或自动建单。</span></div>";
    h += anTasksTable(r.tasks || [], 300);
    h += anTaskDetail();
    return h;
  }

  function anElectricalHtml() {
    var e = (AN.run.electrical || {});
    var h = "<div class='kpis'>" +
      kpi("I 组记录", anNum(e.total), "bad", "ELECTRICAL_ROW_BAD / EMPTY") +
      kpi("PDF 文本层", (e.pdf_signals || []).map(function (x) {
        return (x.pdf_signal || x.pdf_has_ec_text || "?") + " " + x.count;
      }).join(" · ") || "—", "", "YES/NO/PDF_MISSING") +
      kpi("表格结构", (e.structures || []).map(function (x) {
        return (x.table_structure_type || "?") + " " + x.count;
      }).join(" · ") || "—", "", "关键词启发式") +
      kpi("依赖 PDF 信号", "只读", "", "不据此改 parser") +
      "</div>";
    h += "<div class='cols'><div>" +
      anBlock("异常类型 × PDF 电气表文本",
        anTableAuto((e.crosstabs || {}).error_x_ec_text || [])) +
      anBlock("异常类型 × 表格结构",
        anTableAuto((e.crosstabs || {}).error_x_structure || [])) +
      "</div><div>" +
      anBlock("解析器版本 × 异常类型",
        anTableAuto((e.crosstabs || {}).parser_x_error || [])) +
      anBlock("结构 × 文本层 × 异常（分组）",
        anTableAuto((e.crosstabs || {}).structure_combos || []),
        "每组至少一个失败例 + 一个同结构正例/边界例") +
      "</div></div>";
    h += anBlock("I 组逐条候选清单",
      anTable(e.rows || [], [
        ["mpn", "MPN"], ["batch_id", "批次"], ["error_code", "异常"],
        ["pdf_signal", "PDF 文本层"], ["table_structure_type", "表格结构"],
        ["parser_version", "解析器"], ["candidate_layer", "候选环节"],
        ["suggested_first_check", "建议先查"]]),
      "禁止把 56 条统一判为 parser bug；按实际结构拆分");
    return h;
  }

  function anRegressionHtml() {
    var g = (AN.run.regression || {});
    var h = "<div class='kpis'>" +
      kpi("反馈回归记录", anNum(g.total), "", "含 FAIL/PASS") +
      kpi("回归通过率", anPct(g.pass_rate), (g.pass_rate >= 1 ? "ok" : "bad"),
        "不是人工验收通过率") +
      kpi("矩阵基线 FAIL", anNum((g.matrix_baseline || {}).fail_items), "bad",
        "全量 " + anNum((g.matrix_baseline || {}).total_items) + " 件") +
      kpi("基线失败率", anPct((g.matrix_baseline || {}).fail_rate), "warn") +
      "</div>";
    h += "<div class='cols'><div>" +
      anBlock("回归结果分布",
        anTable(g.result_counts || [], [["result", "结果"], ["count", "数量"]])) +
      anBlock("关联样本覆盖",
        anTable(g.coverage || [], [
          ["issue_key", "问题"], ["mpn", "MPN"], ["batch_id", "批次"],
          ["last_result", "最后结果"], ["evidence_status", "证据"],
          ["acceptance_status", "验收"], ["parser_version", "解析器"]])) +
      "</div><div>" +
      anBlock("失败用例",
        anTable(g.failures || [], [
          ["run_key", "用例"], ["result", "结果"], ["failure_summary", "失败摘要"],
          ["scope_description", "范围"], ["finished_at", "时间"]])) +
      anBlock("受影响同组样本",
        anTable(g.affected_cohorts || [], [
          ["group_code", "组"], ["matrix_fail_count", "矩阵 FAIL"],
          ["matrix_batches", "批次"], ["feedback_samples_linked", "已关联反馈"],
          ["feedback_pass", "PASS"], ["feedback_fail", "FAIL"]])) +
      "</div></div>";
    h += "<div class='card'><div class='card-head'><h3>修复前后对比</h3>" +
      "<span class='hint'>比较两次真实分析快照；不自动判定修复成功</span></div>" +
      "<div class='tools'><select class='input' id='anCmpBefore'>" +
      AN.runs.map(function (x) {
        return "<option value='" + esc(x.run_key) + "'>" + esc(x.run_key) +
          " · " + esc(fmtTime(x.created_at)) + "</option>";
      }).join("") + "</select><select class='input' id='anCmpAfter'>" +
      AN.runs.map(function (x) {
        return "<option value='" + esc(x.run_key) + "'>" + esc(x.run_key) +
          " · " + esc(fmtTime(x.created_at)) + "</option>";
      }).join("") + "</select><button class='btn' id='anCompare'>比较差异</button></div>";
    if (AN.cmp) {
      var c = AN.cmp;
      h += "<div class='sub' style='margin:10px 0'>" + esc(c.before) + " → " +
        esc(c.after) + " · 回归修复 " + anNum(c.regression_resolved) +
        " · 新增失败 " + anNum(c.regression_new_fail) + "</div>" +
        anBlock("关键指标变化",
          anTable(Object.keys(c.headline_delta || {}).map(function (k) {
            return { metric: k, delta: c.headline_delta[k] };
          }), [["metric", "指标"], ["delta", "变化"]])) +
        anBlock("问题状态变化",
          anTable(c.status_changes || [], [
            ["issue_key", "问题"], ["change", "变化"], ["before", "前"], ["after", "后"]])) +
        anBlock("回归结果变化",
          anTable(c.regression_changes || [], [
            ["case", "用例"], ["change", "变化"], ["before", "前"], ["after", "后"],
            ["failure", "失败摘要"]])) +
        anBlock("任务数量变化",
          anTable(c.task_delta || [], [
            ["source_system", "来源"], ["group_name", "问题组"], ["priority", "优先级"],
            ["before", "前"], ["after", "后"], ["delta", "变化"]]));
    }
    h += "</div>";
    return h;
  }

  function anExportHtml() {
    var r = AN.run, m = AN.meta || {};
    var h = "<div class='tools' style='margin-bottom:12px'>" +
      "<button class='btn' id='anBundle'>导出分析包 ZIP</button>" +
      "<button class='btn ghost' id='anTaskCsv'>任务 CSV</button>" +
      "<button class='btn ghost' id='anTaskXlsx'>任务 Excel</button></div>";
    h += anBlock("本次分析快照", anRunInfo() +
      anTable([r.inventory || {}], Object.keys(r.inventory || {}).map(function (k) {
        return [k, k];
      })));
    h += anBlock("分析记录",
      "<div class='table-wrap'><table class='grid compact'><thead><tr>" +
      "<th>记录</th><th>时间</th><th>FAIL</th><th>任务</th><th>快照</th><th>操作</th>" +
      "</tr></thead><tbody>" + (AN.runs || []).map(function (x) {
        return "<tr><td class='mono'>" + esc(x.run_key) + "</td><td>" +
          esc(fmtTime(x.created_at)) + "</td><td>" + anNum(x.fail_count) +
          "</td><td>" + anNum(x.task_count) + "</td><td class='mono'>" +
          esc(x.snapshot_id) + "</td><td><button class='btn sm ghost' data-anopen='" +
          esc(x.run_key) + "'>查看</button></td></tr>";
      }).join("") + "</tbody></table></div>",
      "历史只读快照；可下载任务与分析包");
    h += anBlock("分析能力与边界",
      "<div class='cols'><div><div class='kv'><label>pandas 负责</label><strong>" +
      esc((m.outputs || []).join(" · ")) + "</strong></div></div>" +
      "<div><div class='kv'><label>pandas 不负责</label><strong>" +
      "读 PDF/裁定原厂事实/改 facts/冻结 Gold/发布审批/自动关闭</strong></div></div></div>",
      "analyzer " + (m.analyzer_version || "") + " · matrix " + (m.matrix_version || ""));
    return h;
  }

  function renderAnalyzer() {
    var r = AN.run;
    if (!r) {
      $("anKpis").innerHTML = "";
      $("anInfo").textContent = "";
      $("anBody").innerHTML =
        "<div class='empty'>还没有分析记录。选择筛选条件后点「运行分析」。<br>" +
        "首次运行会读取 13,504 件 auto QC 矩阵、反馈表与 PDF 文本层信号；只读，不改业务数据。</div>";
      return;
    }
    var h = r.headline || {};
    $("anKpis").innerHTML =
      kpi("矩阵 FAIL", anNum(h.fail_items), "bad",
        "全量 " + anNum(r.inventory.matrix_rows) + " 件 · 当前筛选 " +
        anNum(h.selected_fail)) +
      kpi("来源/身份待核实", anNum(h.identity_pending), "warn", "MPN / PDF SHA") +
      kpi("电气表异常", anNum(h.electrical_items), "bad", "I 组结构专项") +
      kpi("证据缺口", anNum(h.evidence_gaps), "warn", "反馈样本") +
      kpi("反馈回归失败", anNum(h.regression_fails), "bad", "不等于根因") +
      kpi("候选任务", anNum(h.tasks), "accent", "人工确认后立项");
    $("anInfo").textContent = r.run_key + " · " + fmtTime(r.generated_at);
    var tabs = document.querySelectorAll("#anTabs button");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].className = tabs[i].getAttribute("data-tab") === AN.tab ? "on" : "";
    }
    var html = AN.tab === "tasks" ? anTasksHtml()
      : AN.tab === "electrical" ? anElectricalHtml()
      : AN.tab === "regression" ? anRegressionHtml()
      : AN.tab === "export" ? anExportHtml()
      : anOverviewHtml();
    $("anBody").innerHTML = html;
    anBindBody();
  }

  function anBindBody() {
    var rows = document.querySelectorAll("#anBody [data-antask]");
    for (var i = 0; i < rows.length; i++) {
      rows[i].addEventListener("click", function () {
        var idx = Number(this.getAttribute("data-antask"));
        AN.task = (AN.run.tasks || [])[idx] || null;
        renderAnalyzer();
      });
    }
    var open = document.querySelectorAll("#anBody [data-anopen]");
    for (var j = 0; j < open.length; j++) {
      open[j].addEventListener("click", function () {
        var key = this.getAttribute("data-anopen");
        api(anKey("/runs/" + encodeURIComponent(key)))
          .then(function (s) { AN.run = s; AN.tab = "overview"; AN.task = null; renderAnalyzer(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
    if ($("anTaskCsv")) {
      $("anTaskCsv").addEventListener("click", function () {
        window.open(anKey("/runs/" + encodeURIComponent(AN.run.run_key) + "/tasks.csv"), "_blank");
      });
    }
    if ($("anTaskXlsx")) {
      $("anTaskXlsx").addEventListener("click", function () {
        window.open(anKey("/runs/" + encodeURIComponent(AN.run.run_key) + "/tasks.xlsx"), "_blank");
      });
    }
    if ($("anBundle")) {
      $("anBundle").addEventListener("click", function () {
        window.open(anKey("/runs/" + encodeURIComponent(AN.run.run_key) + "/bundle.zip"), "_blank");
      });
    }
    var cmp = $("anCmpBefore");
    if (cmp && $("anCmpAfter")) {
      var keys = AN.runs.map(function (x) { return x.run_key; });
      if (keys.length >= 2) {
        $("anCmpBefore").value = keys[1];
        $("anCmpAfter").value = keys[0];
      }
    }
    if ($("anCompare")) {
      $("anCompare").addEventListener("click", function () {
        var b = anVal("anCmpBefore"), a = anVal("anCmpAfter");
        if (!b || !a) return toast("需要至少两次分析记录", true);
        api(anKey("/compare?before=" + encodeURIComponent(b) +
                   "&after=" + encodeURIComponent(a)))
          .then(function (c) { AN.cmp = c; renderAnalyzer(); })
          .catch(function (e) { toast(e.message, true); });
      });
    }
  }

  function anReloadRuns() {
    return api(anKey("/runs?limit=50")).then(function (d) {
      AN.runs = d.items || [];
    });
  }

  function loadAnalyzer() {
    api(anKey("/meta")).then(function (m) {
      AN.meta = m;
      return anReloadRuns();
    }).then(function () {
      if (AN.run) { renderAnalyzer(); return null; }
      if (!AN.runs.length) { renderAnalyzer(); return null; }
      return api(anKey("/runs/" + encodeURIComponent(AN.runs[0].run_key)))
        .then(function (s) { AN.run = s; renderAnalyzer(); });
    }).catch(function (e) {
      toast(e.message, true);
      $("anBody").innerHTML = "<div class='empty'>分析器加载失败：" +
        esc(e.message) + "</div>";
    });
  }

  function anRunNow() {
    var body = {
      status: anVal("anStatus"), group: anVal("anGroup"),
      batch_id: anVal("anBatch"), mpn: anVal("anMpn"), q: anVal("anQ"),
      persist: true
    };
    var btn = $("anRun");
    btn.disabled = true;
    btn.textContent = "分析中…";
    api(anKey("/run"), { method: "POST", body: body }).then(function (s) {
      AN.run = s; AN.tab = "overview"; AN.task = null; AN.cmp = null;
      return anReloadRuns().then(function () {
        renderAnalyzer();
        toast("分析完成：" + anNum(s.inventory.matrix_rows) + " 件扫描 / " +
              anNum(s.inventory.matrix_fail) + " 件 FAIL / " +
              anNum((s.tasks || []).length) + " 个候选任务");
      });
    }).catch(function (e) {
      toast(e.message, true);
    }).then(function () {
      btn.disabled = false;
      btn.textContent = "运行分析";
    });
  }

  function loadQCOverview() {
    api("/api/qc/overview").then(function (d) {
      qcBadge(d.badge);
      var reg = d.regression || {};
      $("qcKpis").innerHTML =
        kpi("已审计型号", d.audited_mpns) +
        kpi("已补丁（事实层）", d.patched, "ok") +
        kpi("unresolved", d.unresolved, d.unresolved ? "bad" : "") +
        kpi("回归通过", (reg.status === "ok" ? "11/11" : (reg.status || "—")),
            reg.status === "fail" ? "bad" : (reg.status === "ok" ? "ok" : ""),
            reg.at ? "最近 " + fmtTime(reg.at) : "尚未运行") +
        kpi("渲染层债务", d.lint_debt_mpns, d.lint_debt_mpns ? "warn" : "", "仅重渲染可清") +
        kpi("审计日志条数", d.logs.toLocaleString(), "", "append-only 可导出 CSV");
      var rows = d.kinds || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var k = rows[i];
        var actTag = { patched: "done", badge: "nodata", unresolved: "failed", "debt(render)": "queued" }[k.action] || "queued";
        html += "<tr><td class='mono'>" + esc(k.kind) + "</td><td>" + k.n +
          "</td><td>" + statusTag(actTag, k.action) + "</td></tr>";
      }
      $("qcKinds").innerHTML = html ||
        "<tr><td colspan='3' class='empty'>还没有审计发现 —— 先在「自动化 QC」跑一轮</td></tr>";
      var v = d.verification || {};
      $("qcVer").innerHTML = kvRows({
        "identity = verified": (v.identity_verified || 0).toLocaleString(),
        "identity = unverified（不签准确 SKU）": v.identity_unverified || 0,
        "identity = family_inherited": v.identity_family || 0,
        "回归连续通过轮数": v.regression_green_runs || 0,
        "审计日志保留策略": v.log_policy || "append-only",
        "自动回归": v.beat || "beat 未开启"
      });
    }).catch(function (e) { toast("QC 概览加载失败：" + e.message, true); });
  }

  function loadQCRuns() {
    api("/api/qc/runs?page=1&size=20").then(function (d) {
      var rows = d.runs || [];
      var html = "";
      var MODE_TEXT = { regression: "回归", sample: "抽样", single: "单件", selected: "批量选中" };
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        var stTag = r.status === "ok" ? statusTag("done", "PASS " + r.parts_done + "/" + r.parts)
          : (r.status === "fail" ? statusTag("failed", "FAIL")
          : (r.status === "missing" ? statusTag("nodata", "MISSING")
          : statusTag("queued", "running " + r.parts_done + "/" + r.parts)));
        var opBtn = r.mode === "regression" && r.status !== "running"
          ? "<button class='btn sm' data-qr2gold='" + r.id + "' title='逐件记录转 Gold 核验任务 + 风险队列'>转核验</button>"
          : "";
        html += "<tr><td class='mono'>#" + r.id + "</td><td>" +
          esc(MODE_TEXT[r.mode] || r.mode) + "</td><td class='mono'>" + esc(r.scope) +
          "</td><td>" + (r.dry ? "是" : "否(write)") + "</td><td>" + r.parts_done + "/" + r.parts +
          "</td><td>" + r.findings + "</td><td>" + r.patched + "</td><td>" + r.unresolved +
          "</td><td>" + (r.duration_s ? r.duration_s.toFixed(1) + "s" : "—") + "</td><td>" +
          stTag + "</td><td class='mono'>" + esc(r.operator) + "</td><td class='mono'>" +
          esc(fmtTime(r.created_at)) + "</td><td>" + opBtn + "</td></tr>";
      }
      $("qcRuns").innerHTML = html || "<tr><td colspan='13' class='empty'>还没有运行记录</td></tr>";
    }).catch(function (e) { toast("运行历史加载失败：" + e.message, true); });
  }

  function qcScope() {
    var s = [];
    if ($("qcScFacts") && $("qcScFacts").checked) s.push("facts");
    if ($("qcScRender") && $("qcScRender").checked) s.push("render");
    return s.join(",");
  }

  function qcRunStart() {
    var mode = "regression";
    var rds = document.querySelectorAll("input[name=qcMode]");
    for (var i = 0; i < rds.length; i++) if (rds[i].checked) mode = rds[i].value;
    var write = !!($("qcWrite") && $("qcWrite").checked);
    var body = { mode: mode, scope: qcScope() || "facts", write: write, confirm: write };
    if (mode === "sample") body.sample = Number($("qcSampleN").value || 60);
    if (mode === "single") body.mpns = [$("qcMpn").value.trim()];
    if (mode === "selected") {
      body.mpns = selectedKeys();
      if (!body.mpns.length) { toast("先在「型号任务」勾选型号", true); return; }
    }
    if (mode === "single" && !body.mpns[0]) { toast("填写单件型号", true); return; }
    if (write && !confirm("write 补丁将写回 JSON（先备份 .pre_audit.json）并触发重渲染。\n继续？")) {
      body.write = false; body.confirm = false;
      toast("已取消 write，改按 dry 运行");
    }
    api("/api/qc/run", { method: "POST", body: body }).then(function (d) {
      toast("已投递 run#" + d.run_id + "（" + d.queued + " 件）");
      qcPollRun(d.run_id, body);
    }).catch(function (e) { toast("QC 投递失败：" + e.message, true); });
  }

  function qcCon(line) {
    var c = $("qcConsole");
    if (!c) return;
    c.textContent += line + "\n";
    c.scrollTop = c.scrollHeight;
  }

  function qcPollRun(runId, body) {
    clearInterval(qcState.pollTimer);
    var c = $("qcConsole");
    if (c) c.textContent = "[run#" + runId + "] " + body.mode + " · scope=" + body.scope +
      " · " + (body.write ? "write 补丁" : "dry") + "\n";
    qcState.pollRun = runId;
    qcState.pollSeen = 0;
    var tries = 0;
    qcState.pollTimer = setInterval(function () {
      tries++;
      api("/api/qc/audit-log?run_id=" + runId + "&size=200").then(function (d) {
        var logs = (d.logs || []).slice().reverse();
        for (var i = qcState.pollSeen; i < logs.length; i++) {
          qcCon("[" + logs[i].mpn + "] " + logs[i].action + " " + logs[i].kind +
            (logs[i].path && logs[i].path !== "-" ? " " + logs[i].path : ""));
        }
        qcState.pollSeen = logs.length;
      }).catch(function () {});
      api("/api/qc/runs?page=1&size=30").then(function (d) {
        var rows = d.runs || [];
        for (var j = 0; j < rows.length; j++) {
          if (rows[j].id !== runId) continue;
          if (rows[j].status !== "running") {
            clearInterval(qcState.pollTimer);
            qcCon("[done] run#" + runId + " " + (rows[j].status === "ok" ? "PASS" : rows[j].status) +
              " · 发现 " + rows[j].findings + " · 补丁 " + rows[j].patched +
              " · unresolved " + rows[j].unresolved +
              (rows[j].duration_s ? " · " + rows[j].duration_s.toFixed(1) + "s" : ""));
            loadQCRuns(); loadQCOverview();
            return;
          }
        }
        if (tries > 400) clearInterval(qcState.pollTimer);
      }).catch(function () { if (tries > 400) clearInterval(qcState.pollTimer); });
    }, 1500);
  }

  function loadQCLog() {
    var qs = "/api/qc/audit-log?page=" + qcState.logPage + "&size=" + qcState.logSize;
    if (state.qcLogMpn) qs += "&mpn=" + encodeURIComponent(state.qcLogMpn);
    if (state.qcLogKind) qs += "&kind=" + encodeURIComponent(state.qcLogKind);
    if (state.qcLogAct) qs += "&action=" + encodeURIComponent(state.qcLogAct);
    api(qs).then(function (d) {
      qcState.logTotal = d.total;
      var rows = d.logs || [];
      var ACT_TAG = { patched: "done", badge: "nodata", unresolved: "failed",
                      "debt(render)": "queued", pass: "done", fail: "failed", missing: "skipped" };
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        html += "<tr class='qcrow-click' data-qcid='" + r.id + "'><td class='mono'>" +
          esc(fmtTime(r.created_at)) + "</td><td class='mono'><b>" + esc(r.mpn) +
          "</b></td><td class='mono'>" + esc(r.kind) + "</td><td class='mono'>" + esc(r.path) +
          "</td><td class='mono'>" + esc(r.json_val) + " → " + esc(r.table_val) + "</td><td>" +
          statusTag(ACT_TAG[r.action] || "queued", r.action) + "</td><td class='mono'>" +
          esc(r.tool) + "</td><td class='mono'>" + esc(r.operator) + "</td></tr>";
      }
      $("qcLogBody").innerHTML = html ||
        "<tr><td colspan='8' class='empty'>台账为空 —— 先在「自动化 QC」跑一轮</td></tr>";
      var pages = Math.max(1, Math.ceil(d.total / qcState.logSize));
      $("qcLogPage").textContent = "共 " + d.total + " 条 · 第 " + qcState.logPage + " / " + pages + " 页";
      $("qcLogPrev").disabled = qcState.logPage <= 1;
      $("qcLogNext").disabled = qcState.logPage >= pages;
    }).catch(function (e) { toast("台账加载失败：" + e.message, true); });
    api("/api/qc/kinds").then(function (d) {
      var sel = $("qcLogKind"), cur = state.qcLogKind;
      var html = "<option value=''>全部 kind</option>";
      var ks = d.kinds || [];
      for (var i = 0; i < ks.length; i++) {
        html += "<option" + (cur === ks[i] ? " selected" : "") + ">" + esc(ks[i]) + "</option>";
      }
      sel.innerHTML = html;
    }).catch(function () {});
  }

  function openQCDrawer(id) {
    $("qcDrawerMask").className = "drawer-mask";
    $("qcDrawer").className = "drawer";
    $("qcDTitle").textContent = "审计记录 #" + id;
    $("qcDSub").textContent = "加载中…";
    qcDf = { id: id, base: "pre", mode: "field", only: true, q: "", rv: {}, diff: null };
    $("qcBaseSel").value = "pre";
    $("qcOnlyChg").checked = true;
    $("qcQ").value = "";
    api("/api/qc/audit-log/" + id).then(function (d) {
      var r = d.log || {};
      $("qcDTitle").textContent = r.mpn + " · " + r.kind;
      $("qcDSub").textContent = fmtTime(r.created_at) + " · run#" + r.run_id + " · " +
        r.tool + " · " + r.operator + " · 处置 " + r.action;
      var policy = r.action === "badge" ? "只标不改（不签准确 SKU）"
        : (r.action === "unresolved" ? "定位失败不猜，进 unresolved 清单"
        : (r.action === "debt(render)" ? "渲染层债务：仅重渲染清偿，不重解 PDF"
        : "确定性覆盖（程序化单元格优先）"));
      $("qcDJson").textContent = JSON.stringify({
        id: r.id, run_id: r.run_id, mpn: r.mpn, kind: r.kind, path: r.path,
        json: r.json_val, table: r.table_val, at: r.created_at, tool: r.tool,
        operator: r.operator, action: r.action, policy: policy
      }, null, 1);
      var v = d.verification || {};
      var vk = {};
      for (var k in v) {
        if (!v.hasOwnProperty(k) || v[k] === null) continue;
        vk[k] = String(v[k]);
      }
      vk["run#"] = "#" + r.run_id + "（" + (d.run ? d.run.mode + " · " + d.run.status : "") + "）";
      $("qcDVer").innerHTML = kvRows(vk);
      var chain = d.chain || [];
      var lines = [];
      for (var i = 0; i < chain.length; i++) {
        lines.push(fmtTime(chain[i].created_at) + " #" + chain[i].id + " " +
          chain[i].mpn + " " + chain[i].kind + " → " + chain[i].action +
          " (" + chain[i].tool + " · " + chain[i].operator + ")");
      }
      $("qcDChain").textContent = lines.join("\n") || "（无）";
      $("qcDPatch").setAttribute("data-mpn", r.mpn);
      $("qcDRerender").setAttribute("data-mpn", r.mpn);
    }).catch(function (e) { toast("审计详情加载失败：" + e.message, true); });
    qcDiffReload();
  }

  /* ── 产物链 diff 视图（pre_audit ↔ patched；原型三模式 + 基线切换 + 逐字段回滚） ── */
  var qcDf = { id: 0, base: "pre", mode: "field", only: true, q: "", rv: {}, diff: null };
  var QC_ART_ICON = { parsed_json: "🧾", pre_audit: "🗄", facts: "🧊", txt_en: "📃",
                      txt_ja: "📃", txt_ko: "📃", txt_de: "📃", txt_es: "📃", symbol_svg: "🖼" };

  function qcDiffReload() {
    $("qcStats").textContent = "diff 加载中…";
    api("/api/qc/audit-log/" + qcDf.id + "/diff?baseline=" + qcDf.base).then(function (d) {
      qcDf.diff = d;
      qcDf.rv = {};
      renderQCDiff();
    }).catch(function (e) {
      qcDf.diff = { error: e.message, stats: {}, fields: [], artifacts: [], verification: {} };
      renderQCDiff();
    });
  }

  function qcVs(v) {                       // 值渲染：容器 JSON 化，null → ∅
    if (v === null || v === undefined) return "∅";
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  }
  function qcLeaf(p) { return p.split(".").pop().split("[").shift() || p; }

  function qcFiltered() {
    var fs = (qcDf.diff && qcDf.diff.fields) || [];
    if (qcDf.only) fs = fs.filter(function (x) { return x.op !== "same"; });
    if (qcDf.q) {
      var q = qcDf.q.toLowerCase();
      fs = fs.filter(function (x) { return x.p.toLowerCase().indexOf(q) >= 0; });
    }
    return fs;
  }

  function renderQCDiff() {
    var d = qcDf.diff || {};
    var fs = d.fields || [];
    var badgeOnly = d.log && d.log.action === "badge";
    /* 产物链 */
    var arts = d.artifacts || [];
    var h = "";
    for (var i = 0; i < arts.length; i++) {
      var a = arts[i];
      var isBase = (qcDf.base === "pre" && a.kind === "pre_audit") ||
                   (qcDf.base === "facts" && a.kind === "facts");
      var nm = (a.path || a.kind || "").replace(/^.*[\\\/]/, "");
      h += '<div class="art' + (a.exists ? "" : " miss") + (isBase ? " base" : "") +
        '" title="' + esc(a.path || "") + '｜' + esc(a.note || "") + '">' +
        (QC_ART_ICON[a.kind] || "📦") + " <span class=mono>" + esc(nm) +
        "</span> <small>" + esc(a.note || "") + "</small></div>";
    }
    $("qcChain").innerHTML = h || "（无产物记录）";
    /* 统计条 */
    var st = d.stats || {};
    if (d.error) {
      $("qcStats").innerHTML = '<span class="bad">⚠ ' + esc(d.error) + "</span>";
    } else if (!fs.length) {
      $("qcStats").innerHTML = '<span class="ok">✓ 0 差异：' +
        (qcDf.base === "facts" ? "facts ↔ patched 一致（SSOT 已生效，渲染消费同一事实表）"
                               : "pre_audit ↔ patched 无差异") + "</span>";
    } else {
      $("qcStats").innerHTML =
        '<span class="add"><b>' + (st.add || 0) + "</b> 新增字段</span>" +
        '<span class="mod"><b>' + (st.mod || 0) + "</b> 修改字段</span>" +
        '<span class="del"><b>' + (st.del || 0) + "</b> 删除字段</span>" +
        '<span class="same"><b>' + (st.same || 0) + "</b> 未变更</span>" +
        "<span>表格依据 " + fs.filter(function (x) { return x.src; }).length + " 处</span>";
    }
    var show = qcFiltered();
    $("qcCnt").textContent = "显示 " + show.length + " / " + fs.length + " 字段";
    /* 三模式切换 */
    $("qcViewField").className = qcDf.mode === "field" ? "" : "hide";
    $("qcViewJson").className = qcDf.mode === "json" ? "" : "hide";
    $("qcViewUni").className = qcDf.mode === "uni" ? "" : "hide";
    var chg = fs.filter(function (x) { return x.op !== "same"; });
    if (qcDf.mode === "field") {
      var rows = "";
      for (var r = 0; r < show.length; r++) {
        var x = show[r];
        var rv = !!qcDf.rv[x.p];
        rows += '<tr class="op-' + x.op + '"><td class="mono">' + esc(x.p) +
          (x.note ? '<div class="qc-src">' + esc(x.note) + "</div>" : "") + "</td>";
        rows += "<td>" + (x.op === "add" ? '<span class="qc-val none">∅ 不存在</span>'
          : '<span class="qc-val pre">' + esc(qcVs(x.pre)) + "</span>") + "</td><td>→</td>";
        rows += "<td>" + (x.op === "del" ? '<span class="qc-val none">∅</span>'
          : '<span class="qc-val post">' + esc(qcVs(x.post)) + "</span>") + "</td>";
        rows += '<td><span class="tag' + (x.op === "same" ? "" : " nodata") + '">' +
          esc(x.kind || "-") + "</span></td>";
        rows += '<td><div class="qc-src mono">' + esc(x.src || "") + "</div>" +
          (x.op !== "same" && !badgeOnly
            ? '<button class="qc-rv' + (rv ? " done" : "") + '" data-qcrv="' + esc(x.p) + '">' +
              (rv ? "已回滚" : "回滚此字段") + "</button>"
            : (badgeOnly && x.op !== "same" ? '<span class="qc-src">badge 件只标不改</span>' : "")) +
          "</td></tr>";
      }
      $("qcDiffBody").innerHTML = rows ||
        '<tr><td colspan="6" class="empty">' + (d.error ? esc(d.error)
        : (qcDf.base === "facts" ? "facts 基线 ↔ patched 无差异；切回 pre_audit 查看补丁明细"
        : "无变更字段")) + "</td></tr>";
    } else if (qcDf.mode === "json") {
      var cap = chg.slice(0, 12);
      var l = "", rr = "";
      if (d.error) {
        l = esc(d.error); rr = "";
      } else if (!cap.length) {
        l = "（无差异）"; rr = "（无差异）";
      } else {
        for (var j = 0; j < cap.length; j++) {
          var y = cap[j];
          l += '<span class="ln-del">"' + esc(qcLeaf(y.p)) + '": ' + esc(qcVs(y.pre)) +
            (y.op !== "del" ? "," : "") + ",   // " + esc(y.kind || "") + "</span>\n";
          rr += '<span class="ln-add">"' + esc(qcLeaf(y.p)) + '": ' + esc(qcVs(y.post)) +
            (y.op !== "del" ? "," : "") + ",   // patched</span>\n";
        }
      }
      $("qcJhL").textContent = (qcDf.base === "facts" ? "facts 基线（节选）" : "pre_audit 基线（节选）") +
        (chg.length > 12 ? " · 前 12 条" : "");
      $("qcJhR").textContent = "patched json（节选）";
      $("qcJL").innerHTML = l || "{ … }";
      $("qcJR").innerHTML = rr || "{ … }";
    } else {
      var u = "";
      if (d.error) {
        u = esc(d.error);
      } else {
        for (var m = 0; m < chg.length; m++) {
          var z = chg[m];
          u += '<span class="h">  # ' + esc(z.kind || "") + " · " +
            esc(z.src || z.note || "") + "</span>\n";
          if (z.op !== "add")
            u += '<span class="d">- ' + esc(z.p) + ": " + esc(qcVs(z.pre)) + "</span>\n";
          else
            u += '<span class="h">  (基线无此字段)</span>\n';
          if (z.op !== "del")
            u += '<span class="a">+ ' + esc(z.p) + ": " + esc(qcVs(z.post)) + "</span>\n";
        }
        if (!u) u = '<span class="h">（无差异）</span>';
      }
      $("qcUPre").innerHTML = u;
    }
    $("qcRvCnt").textContent = "已回滚 " + Object.keys(qcDf.rv).length + " 字段";
  }

  function qcTogRV(p) {
    if (qcDf.rv[p]) delete qcDf.rv[p]; else qcDf.rv[p] = 1;
    renderQCDiff();
  }

  function closeQCDrawer() {
    $("qcDrawerMask").className = "drawer-mask hide";
    $("qcDrawer").className = "drawer hide";
  }

  function loadQCFixtures() {
    api("/api/qc/fixtures").then(function (d) {
      var rows = d.fixtures || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var f = rows[i];
        var tag = f.result === "pass" ? statusTag("done", "PASS")
          : (f.result === "fail" ? statusTag("failed", "FAIL")
          : (f.result ? statusTag("nodata", f.result) : statusTag("skipped", "未运行")));
        html += "<tr><td class='mono'>" + esc(f.mpn) + "</td><td class='mono'>" +
          esc(f.findings) + "</td><td>" + f.asserts + "</td><td>" + tag +
          "</td><td class='mono'>" + esc(f.at ? fmtTime(f.at) : "—") + "</td></tr>";
      }
      $("qcFixBody").innerHTML = html;
      var lr = d.last_run || {};
      $("qcFixKv").innerHTML = kvRows({
        "回归通过率": d.pass + "/11",
        "最近运行": lr.created_at ? fmtTime(lr.created_at) + " · " + (lr.status || "") : "尚未运行",
        "下次自动回归": d.beat
      });
    }).catch(function (e) { toast("夹具加载失败：" + e.message, true); });
  }

  function loadQCLint(live) {
    api("/api/qc/lint" + (live ? "?live=1" : "")).then(function (d) {
      var rows = d.groups || [];
      qcState.lintGroups = rows;
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var g = rows[i];
        var actionBtn = g.kind === "i18n_missing"
          ? "<button class='btn sm ghost' data-lintkind='" + esc(g.kind) + "'>翻译续跑提示</button>"
          : "<button class='btn sm' data-lintkind='" + esc(g.kind) + "'>仅重渲染</button>";
        html += "<tr><td class='mono'>" + esc(g.kind) + "</td><td>" + g.mpns.length +
          " 件</td><td class='mono'>" + esc(g.mpns.slice(0, 5).join(", ")) +
          (g.mpns.length > 5 ? " …" : "") + "</td><td>" + actionBtn + "</td></tr>";
      }
      $("qcLintBody").innerHTML = html ||
        "<tr><td colspan='4' class='empty'>无渲染层债务（或尚未跑过 lint —— 运行一轮 QC，scope 含 render）</td></tr>";
    }).catch(function (e) { toast("lint 加载失败：" + e.message, true); });
  }

  /* ---------------- 质量工程 QE（Gold Set / 风险队列 / 随机审计 / 引擎对比 / 反馈闭环） ---------------- */
  var qeState = { goldDetail: null, sampleBatch: null, evDetail: null };

  function qeSetBar(id, pct) {
    var el = $(id);
    if (el) el.style.width = Math.max(0, Math.min(100, pct)) + "%";
  }

  /* ── Gold Set ── */
  function loadGold() {
    var qs = [];
    if (state.qeGoldStatus) qs.push("status=" + encodeURIComponent(state.qeGoldStatus));
    if (state.qeGoldQ) qs.push("q=" + encodeURIComponent(state.qeGoldQ));
    api("/api/qe/gold" + (qs.length ? "?" + qs.join("&") : "")).then(function (d) {
      var st = d.stats || {};
      if ($("qeGoldVer")) $("qeGoldVer").textContent = d.version || "v1";
      $("qeGoldKpis").innerHTML =
        kpi("样本 PDF", st.n, "", (st.manufacturers || 0) + " 家制造商") +
        kpi("已冻结", st.frozen, st.frozen ? "ok" : "") +
        kpi("已核验字段", st.fields_verified, "ok") +
        kpi("待复核字段", st.fields_pending, st.fields_pending ? "warn" : "");
      var tot = st.fields_total || 0, ver = st.fields_verified || 0;
      $("qeGoldProgTxt").textContent = tot ? (ver + " / " + tot + " · " +
        Math.round(ver / tot * 100) + "%") : "—";
      qeSetBar("qeGoldProgBar", tot ? ver / tot * 100 : 0);
      $("qeGoldSha").textContent = (st.n ? st.sha_ok + " / " + st.n : "—");
      qeSetBar("qeGoldShaBar", st.n ? st.sha_ok / st.n * 100 : 0);
      $("qeGoldEv").textContent = tot ? (ver + " / " + tot) : "—";
      qeSetBar("qeGoldEvBar", tot ? ver / tot * 100 : 0);
      var rows = d.items || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var g = rows[i];
        var stTag = g.status === "frozen" ? statusTag("done", "已冻结")
          : (g.status === "review" ? statusTag("nodata", "待复核")
          : statusTag("skipped", "草稿"));
        html += "<tr class='qcrow-click' data-qegold='" + g.id + "'><td><b>" + esc(g.mpn) +
          "</b></td><td>" + esc(g.manufacturer || "—") +
          "</td><td><div>" + esc(g.doc_rev || "—") + "</div><div class='sub mono'>sha256: " +
          esc((g.pdf_sha256 || "").slice(0, 8) + "…" + (g.pdf_sha256 || "").slice(-4)) +
          "</div></td><td>" + g.verified + " / " + g.total +
          (g.conflict ? ' <span class="tag failed">冲突 ' + g.conflict + "</span>" : "") +
          "</td><td>" + stTag + "</td><td class='mono'>" + esc(fmtTime(g.updated_at)) +
          "</td><td><button class='btn sm' data-qegold='" + g.id + "'>" +
          (g.status === "frozen" ? "查看 / 核验记录" : "继续核验") + "</button></td></tr>";
      }
      $("qeGoldBody").innerHTML = html ||
        "<tr><td colspan='7' class='empty'>基准集为空 —— 输入 MPN 导入样本生成机器草稿（建议先导入 11 件回归夹具型号）</td></tr>";
    }).catch(function (e) { toast("Gold Set 加载失败：" + e.message, true); });
  }

  function qeGoldSeed() {
    var v = ($("qeGoldSeedMpn").value || "").trim();
    if (!v) { toast("请输入 MPN", true); return; }
    var mpns = v.split(/[,，\s]+/).filter(Boolean).slice(0, 50);
    api("/api/qe/gold/seed", { method: "POST", body: { mpns: mpns } })
      .then(function (d) {
        var ok = 0, err = 0;
        for (var i = 0; i < (d.seeded || []).length; i++) {
          if (d.seeded[i].error) err++; else ok++;
        }
        toast("已生成 " + ok + " 件机器草稿" + (err ? "（" + err + " 件未找到产物）" : ""));
        $("qeGoldSeedMpn").value = "";
        loadGold();
      }).catch(function (e) { toast("seed 失败：" + e.message, true); });
  }

  function openGoldDrawer(goldId) {
    $("qeDrawerMask").className = "drawer-mask";
    $("qeDrawer").className = "drawer";
    $("qeDTitle").textContent = "加载中…";
    $("qeDBody").innerHTML = "";
    api("/api/qe/gold/" + goldId).then(function (d) {
      var g = d.gold || {};
      qeState.goldDetail = d;
      $("qeDTitle").textContent = g.mpn + " · Gold 标准答案";
      $("qeDSub").textContent = (g.manufacturer || "") + " · " + (g.doc_rev || "版本未登记") +
        " · sha256 " + (g.pdf_sha256 || "").slice(0, 12) + "… · " +
        (g.status === "frozen" ? "已冻结" : (g.status === "review" ? "待复核" : "草稿"));
      var rows = d.fields || [];
      var html = '<div class="stats">' +
        '<div class="stat"><div class="stat-k">字段总数</div><div class="stat-v">' + rows.length +
        '</div></div><div class="stat"><div class="stat-k">已核验</div><div class="stat-v">' +
        rows.filter(function (x) { return x.status === "verified"; }).length +
        '</div></div><div class="stat"><div class="stat-k">冲突</div><div class="stat-v">' +
        rows.filter(function (x) { return x.status === "conflict"; }).length +
        '</div></div><div class="stat"><div class="stat-k">产物</div><div class="stat-v">' +
        esc((d.artifacts && d.artifacts.pdf) || "PDF 缺") + "</div></div></div>";
      html += '<div class="row-actions"><div class="tools">' +
        (g.status !== "frozen"
          ? "<button class='btn sm' data-qegoldact='freeze'>❄ 冻结样本（需全部字段 verified）</button>" +
            "<button class='btn sm ghost' data-qegoldact='review'>标记待复核</button>"
          : "<button class='btn sm ghost' data-qegoldact='unfreeze'>解冻回 review（标准值仍不可改）</button>") +
        "<button class='btn sm' data-qegoldact='cheatsheet'>核验单（预览）</button>" +
        "<button class='btn sm ghost' data-qegoldact='cheatsheetmd' title='下载 Markdown 归档'>.md</button>" +
        "<button class='btn sm ghost' data-qegoldact='addfield'>＋ 补录字段</button></div></div>";
      html += '<p class="note">核验口径：<b>页码(物理页 1 起) + 证据定位</b> 双必填；' +
        '高风险字段（身份/封装/引脚/电流类电气）证据必须含原文 quote；' +
        '空白 = not_specified，绝不补 0；推翻机器草稿请用「标记冲突」并写入 PDF 正确值。</p>';
      html += '<div class="table-wrap tall"><table class="grid compact"><thead><tr>' +
        "<th>字段路径</th><th>参数名</th><th>标准值</th><th>单位</th><th>条件</th>" +
        "<th style='width:64px'>页码</th><th>证据定位</th><th style='width:86px'>状态</th>" +
        "<th style='width:210px'>操作</th></tr></thead><tbody>";
      for (var i = 0; i < rows.length; i++) {
        var f = rows[i];
        var tag = f.status === "verified" ? statusTag("done", "verified")
          : (f.status === "conflict" ? statusTag("failed", "conflict")
          : statusTag("skipped", "待核验"));
        html += "<tr><td class='mono'>" + esc(f.field_path) + "</td><td>" + esc(f.field_name) +
          "</td><td class='mono'>" + esc(f.expected || "∅") + "</td><td>" + esc(f.unit || "") +
          "</td><td class='sub'>" + esc((f.cond || "").slice(0, 40)) + "</td><td>" +
          (f.page_no || "—") + "</td><td class='sub'>" + esc((f.evidence || "").slice(0, 30)) +
          "</td><td>" + tag + "</td><td>";
        if (f.status !== "verified") {
          html += "<button class='btn sm' data-qefv='" + f.id + "'>✓ 核验通过</button> ";
        }
        html += "<button class='btn sm ghost' data-qefc='" + f.id + "'>标记冲突</button>";
        html += "</td></tr>";
      }
      html += "</tbody></table></div>";
      html += '<div class="sec-title">人工审核记录（append-only）</div><pre class="code">';
      var logs = d.logs || [], lines = [];
      for (var li = 0; li < logs.length; li++) {
        lines.push(fmtTime(logs[li].created_at) + " [" + logs[li].action + "] " +
          (logs[li].operator || "auto") + " " + (logs[li].detail || ""));
      }
      html += esc(lines.join("\n") || "（暂无记录）") + "</pre>";
      html += '<p class="note">' + esc(d.rules || "") + "</p>";
      $("qeDBody").innerHTML = html;
    }).catch(function (e) { toast("Gold 详情加载失败：" + e.message, true); });
  }

  function qeGoldFieldAction(fid, status) {
    var d = qeState.goldDetail;
    if (!d) return;
    var f = null;
    for (var i = 0; i < (d.fields || []).length; i++) {
      if (d.fields[i].id === fid) f = d.fields[i];
    }
    if (!f) return;
    var body = { status: status };
    if (status === "verified") {
      var pg = prompt("① 证据页码（原厂 PDF 物理页，1 起，必填；TI 印刷页码常差 2，可注 p7(印刷p5)）",
                      String(f.page_no || 0));
      if (pg === null) return;
      body.page_no = parseInt(pg, 10) || 0;
      var ev = prompt("② 证据定位（表名 / 行 / 列；高风险字段必须含原文 quote，如 " +
                      'Table 7-3 IDD 行 MAX 列，原文 "10 µA"）', f.evidence || "");
      if (ev === null) return;
      body.evidence = ev;
      if (!body.page_no) { toast("核验通过必须填页码（>0）", true); return; }
      if (!String(ev).trim()) { toast("核验通过必须填证据定位", true); return; }
    } else if (status === "conflict") {
      // 推翻机器草稿：写入 PDF 正确值（可留空表示仅记冲突原因），必须带证据/原因
      var val = prompt("① PDF 正确值（覆盖机器草稿；不填则仅记录冲突不动标准值）",
                       f.expected || "");
      if (val === null) return;
      var cp = parseInt(prompt("② 证据页码（物理页，1 起，可空）",
                              String(f.page_no || 0)) || "0", 10) || 0;
      var why = prompt("③ 冲突原因 / 证据定位（审计必填，如 " +
                       'Table 7-3 行归属错误，PDF 为 0.65 mA）', f.evidence || "");
      if (!why) { toast("标记冲突必须写原因或 PDF 正确值+证据", true); return; }
      if (val !== "") body.expected = val;
      if (cp) body.page_no = cp;
      body.evidence = why;
    }
    api("/api/qe/gold/field/" + fid, { method: "POST", body: body })
      .then(function () {
        toast(status === "verified" ? "字段已核验（已留审计）" : "已标记冲突（已留审计）");
        openGoldDrawer(d.gold.id);
        loadGold();
      }).catch(function (e) { toast(e.message, true); });
  }

  function qeGoldDeviceAction(act) {
    var d = qeState.goldDetail;
    if (!d) return;
    var gid = d.gold.id;
    if (act === "cheatsheet") {
      window.open("/api/qe/gold/" + gid + "/cheatsheet.html", "_blank");
      toast("核验单已开新窗口（渲染版，可打印/双屏对照；另有 .md 供归档）");
      return;
    }
    if (act === "cheatsheetmd") {
      window.open("/api/qe/gold/" + gid + "/cheatsheet.md", "_blank");
      return;
    }
    if (act === "freeze") {
      if (!confirm("冻结 " + d.gold.mpn + "？\n冻结后标准值不可修改（变更须新版本流程）；" +
                   "需全部字段已核验。")) return;
    }
    if (act === "unfreeze" && !confirm("解冻回 review？（标准值历史仍保留）")) return;
    if (act === "addfield") {
      var path = prompt("字段路径（如 electrical[48].value / pin[17].name）", "");
      if (!path) return;
      var val = prompt("预期值（原厂 PDF 值）", "");
      if (val === null) return;
      var unit = prompt("单位（可空）", "") || "";
      var pg = parseInt(prompt("证据页码（物理页 1 起；填 >0 即直接进 verified，留 0 则存 pending）",
                               "0") || "0", 10) || 0;
      var ev = "";
      if (pg) {
        ev = prompt('证据定位（必须；高风险字段含原文 quote，如 Table 7-3 行，原文 "10 µA"）', "");
        if (!ev) { toast("补录并核验必须填证据定位", true); return; }
      }
      api("/api/qe/gold/" + gid + "/field", { method: "POST",
        body: { field_path: path, field_name: path, expected: val, unit: unit,
                page_no: pg, evidence: ev, status: pg ? "verified" : "pending" } })
        .then(function (r) {
          toast("字段已补录（" + r.status + "）"); openGoldDrawer(gid); loadGold();
        }).catch(function (e) { toast(e.message, true); });
      return;
    }
    var status = act === "freeze" ? "frozen" : "review";
    api("/api/qe/gold/" + gid + "/status", { method: "POST", body: { status: status } })
      .then(function () { toast("状态 → " + status); openGoldDrawer(gid); loadGold(); })
      .catch(function (e) { toast(e.message, true); });
  }

  /* ── 原厂证据卡（Source Evidence Registry） ── */
  var EV_ST = {
    pending: ["skipped", "待发现"], identity_review: ["queued", "身份核验中"],
    field_review: ["nodata", "字段核验中"], verified: ["done", "已核验"],
    source_unresolved: ["failed", "来源未解决"], conflict: ["failed", "冲突"],
    frozen: ["done", "已冻结"]
  };
  var EV_ID = {
    pending: ["skipped", "待核验"], verified: ["done", "已核验"],
    mismatch: ["failed", "不匹配"], unresolved: ["failed", "未解决"]
  };
  var EV_FE = {
    pending: ["skipped", "待核验"], verified: ["done", "已核验"],
    rejected: ["failed", "已否决"], conflict: ["failed", "冲突"],
    ready: ["nodata", "就绪待确认"], conflict_draft: ["failed", "冲突草稿"],
    ambiguous: ["queued", "多候选"], ocr_pending: ["skipped", "无文本层"],
    ready_for_confirm: ["nodata", "就绪待确认"]
  };

  function evTag(map, key) {
    var m = map[key] || ["skipped", key || "—"];
    return statusTag(m[0], m[1]);
  }

  function loadEvidence() {
    var qs = [];
    if (state.qeEvStatus) qs.push("status=" + encodeURIComponent(state.qeEvStatus));
    if (state.qeEvQ) qs.push("q=" + encodeURIComponent(state.qeEvQ));
    api("/api/qe/evidence" + (qs.length ? "?" + qs.join("&") : "")).then(function (d) {
      var st = d.stats || {};
      $("qeEvKpis").innerHTML =
        kpi("证据卡", st.evidence, "", (st.documents || 0) + " 份文档") +
        kpi("身份已核验", st.identity_verified, st.identity_verified ? "ok" : "") +
        kpi("来源未解决", st.source_unresolved, st.source_unresolved ? "bad" : "") +
        kpi("已冻结", st.frozen, st.frozen ? "ok" : "");
      $("qeEvIdent").textContent = (st.identity_verified || 0) + " / " + (st.documents || 0);
      qeSetBar("qeEvIdentBar", st.documents ? st.identity_verified / st.documents * 100 : 0);
      $("qeEvField").textContent = (st.field_verified || 0) + " / " + (st.field_evidence || 0);
      qeSetBar("qeEvFieldBar", st.field_evidence ? st.field_verified / st.field_evidence * 100 : 0);
      var tiers = d.tiers || {}, keys = ["P0", "P1", "P2", "P3", "P4"], th = "";
      for (var ti = 0; ti < keys.length; ti++) {
        th += "<div class='kv-row'><div class='kv-k'>" + keys[ti] +
          "</div><div class='kv-v sub'>" + esc(tiers[keys[ti]] || "") + "</div></div>";
      }
      $("qeEvTiers").innerHTML = th;
      var rows = d.items || [], html = "";
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        var sha = r.pdf_sha256 || "";
        html += "<tr class='qcrow-click' data-qeev='" + r.id + "'><td><b>" + esc(r.mpn) + "</b>" +
          (sha ? "<div class='sub mono'>sha256: " + esc(sha.slice(0, 8) + "…" + sha.slice(-4)) +
            "</div>" : "") +
          "</td><td>" + esc(r.manufacturer || "—") +
          "</td><td class='mono'>" + esc(r.source_tier || "—") +
          (r.is_official ? " <span class='tag done'>官方</span>" : "") +
          "</td><td>" + evTag(EV_ID, r.doc_identity || "pending") +
          "</td><td>" + (r.fields_verified || 0) + " / " + (r.fields || 0) +
          "</td><td>" + evTag(EV_ST, r.status) +
          "</td><td><button class='btn sm' data-qeev='" + r.id + "'>打开</button></td></tr>";
      }
      $("qeEvBody").innerHTML = html ||
        "<tr><td colspan='7' class='empty'>还没有证据卡 —— 输入 MPN 建卡，再登记原厂 PDF</td></tr>";
    }).catch(function (e) { toast("证据卡加载失败：" + e.message, true); });
  }

  function qeEvNew() {
    var mpn = ($("qeEvMpn").value || "").trim();
    if (!mpn) { toast("请输入目标 MPN", true); return; }
    api("/api/qe/evidence", { method: "POST",
      body: { mpn: mpn, manufacturer: ($("qeEvMaker").value || "").trim() } })
      .then(function (d) {
        toast("证据卡 #" + d.evidence_id + " 已建");
        $("qeEvMpn").value = "";
        loadEvidence();
        openEvidenceDrawer(d.evidence_id);
      }).catch(function (e) { toast(e.message, true); });
  }

  function openEvidenceDrawer(id) {
    $("qeDrawerMask").className = "drawer-mask";
    $("qeDrawer").className = "drawer";
    $("qeDTitle").textContent = "加载中…";
    $("qeDBody").innerHTML = "";
    api("/api/qe/evidence/" + id).then(function (d) {
      var e = d.evidence || {}, doc = d.document || {}, fs = d.fields || [];
      var g = d.gold || {};
      qeState.evDetail = d;
      $("qeDTitle").textContent = e.mpn + " · 原厂证据卡";
      $("qeDSub").textContent = (e.manufacturer || "制造商未登记") + " · " +
        (doc.source_tier || "无文档") + " · 身份 " + (doc.identity_status || "pending") +
        (g.id ? " · Gold #" + g.id + " " + (g.status || "") : " · 未建 Gold");
      var fev = 0;
      for (var i = 0; i < fs.length; i++) {
        if (fs[i].verification_status === "verified") fev++;
      }
      var cov = [];
      try { cov = JSON.parse(doc.covered_mpn_json || "[]"); } catch (err) { cov = []; }
      var html = '<div class="stats">' +
        '<div class="stat"><div class="stat-k">证据卡状态</div><div class="stat-v" style="font-size:15px">' +
        esc((EV_ST[e.status] || ["", e.status || "—"])[1]) + "</div></div>" +
        '<div class="stat"><div class="stat-k">文档身份</div><div class="stat-v" style="font-size:15px">' +
        esc((EV_ID[doc.identity_status || "pending"] || ["", "—"])[1]) + "</div></div>" +
        '<div class="stat"><div class="stat-k">字段证据</div><div class="stat-v">' + fev + " / " +
        fs.length + "</div></div>" +
        '<div class="stat"><div class="stat-k">PDF 页数</div><div class="stat-v">' +
        (doc.page_count || "—") + "</div></div></div>";
      html += '<div class="kv">' + kvRows({
        "来源 URL": doc.source_url || "—",
        "官方来源": doc.is_official ? "是（官方域名白名单命中）" : "否 / 尚未确认",
        "本地 PDF": doc.local_path || "—",
        "SHA-256": doc.pdf_sha256 || "—",
        "文档版本 / 日期": [doc.document_revision || "—", doc.document_date || ""].join(" ").trim(),
        "已确认覆盖型号": cov.length ? cov.join(", ") : "（未人工确认）",
        "身份说明": doc.identity_notes || "—"
      }) + "</div>";
      html += '<div class="row-actions"><div class="tools">' +
        "<button class='btn sm' data-qeevact='chain'>⚙ 一键定位（机器起草）</button>" +
        "<button class='btn sm' data-qeevact='batchdry'>批量预览</button>" +
        "<button class='btn sm' data-qeevact='batch'>批量确认（非高风险）</button>" +
        "<button class='btn sm ghost' data-qeevact='readiness'>冻结就绪度</button>" +
        "</div><div class='tools' style='margin-top:6px'>" +
        "<button class='btn sm' data-qeevact='doc'>＋ 登记文档</button>" +
        "<button class='btn sm' data-qeevact='identity'>✓ 人工确认身份</button>" +
        "<button class='btn sm ghost' data-qeevact='field'>＋ 字段证据</button>" +
        "<button class='btn sm ghost' data-qeevact='unresolved'>标来源未解决</button>" +
        "<button class='btn sm ghost' data-qeevact='conflict'>标冲突</button>" +
        "<button class='btn sm' data-qeevact='freeze'>❄ 冻结 Gold</button></div></div>";
      html += '<p class="note">机器只起草：一键定位写 <code>ready/ambiguous/ocr_pending/conflict_draft</code> 草稿' +
        '（reviewer 留空）；<b>批量确认永不碰高风险字段</b>（勾选框已禁用），高风险必须单字段核验且证据含 quote。' +
        '</p>';
      html += '<div class="qe-progress"><span id="qeEvBatchInfo">可批量 — / 高风险 —</span></div>' +
        '<div class="qe-progress"><span id="qeWlTxt">必须人工量：加载中…</span>' +
        '<b id="qeWlClicks">—</b></div>' +
        '<div class="qe-bar"><i id="qeWlBar"></i></div>' +
        '<div class="row-actions"><div class="tools">' +
        "<button class='btn sm' data-qeevact='worklist'>↻ 刷新人工量</button>" +
        "<button class='btn sm' data-qeevact='attachbox'>批量挂接（粘贴清单）</button>" +
        "<button class='btn sm' data-qeevact='riskguide'>高风险对照表（预览）</button>" +
        "<button class='btn sm ghost' data-qeevact='riskguidemd' title='下载 Markdown 归档'>.md</button>" +
        "</div></div>" +
        '<div id="qeEvAttach" class="hide">' +
        "<textarea id='qeAttachBox' class='code' rows='4' style='width:100%;margin-top:6px' " +
        "placeholder='每行一个 field_path（freeze_precheck 清单可直接粘贴）&#10;pin[9].name&#10;electrical[12].value'></textarea>" +
        "<div class='tools' style='margin-top:6px'>" +
        "<label class='sub'><input type='checkbox' id='qeAttachTf' checked> 同时并入 target_fields</label>" +
        "<button class='btn sm' data-qeevact='attachdry'>预览(dry)</button>" +
        "<button class='btn sm' data-qeevact='attachapply'>挂接</button></div></div>" +
        '<pre class="code hide" id="qeEvRejected"></pre>';
      html += '<div class="table-wrap tall"><table class="grid compact"><thead><tr>' +
        "<th style='width:30px'></th><th>字段路径</th><th style='width:56px'>页码</th>" +
        "<th>表 / 行 / 列</th><th>候选/原文</th><th style='width:150px'>状态</th>" +
        "<th style='width:80px'>操作</th></tr></thead><tbody>";
      for (var j = 0; j < fs.length; j++) {
        var f = fs[j];
        var cands = [];
        try { cands = JSON.parse(f.candidates_json || "[]"); } catch (err) { cands = []; }
        var stTxt = EV_FE[f.verification_status]
          ? statusTag(EV_FE[f.verification_status][0], EV_FE[f.verification_status][1])
          : statusTag("queued", f.verification_status);
        html += "<tr data-frow='" + f.id + "'><td><input type='checkbox' data-fid='" + f.id + "'></td>" +
          "<td class='mono'>" + esc(f.field_path) + "</td><td>" + (f.page_number || "—") +
          "</td><td class='sub'>" + esc([f.table_name, f.row_key, f.column_key]
            .filter(function (x) { return !!x; }).join(" / ") || "—") +
          "</td><td class='sub'>" + esc((f.evidence_quote || "—").slice(0, 60)) +
          (cands.length > 1 ? " <span class='tag warn'>候选 " + cands.length + "</span>" : "") +
          "</td><td>" + stTxt + " <span class='hr-slot'></span></td><td>" +
          (f.verification_status !== "verified"
            ? "<button class='btn sm' data-qeevf='" + f.id + "'>核验</button>" : "—") +
          "</td></tr>";
      }
      if (!fs.length) html += "<tr><td colspan='7' class='empty'>还没有字段证据 —— 点「⚙ 一键定位」起草，或「＋ 字段证据」手录</td></tr>";
      html += "</tbody></table></div>";
      html += '<div class="sec-title">核验台账（append-only）</div><pre class="code">';
      var logs = d.logs || [], lines = [];
      for (var k = 0; k < logs.length; k++) {
        lines.push(fmtTime(logs[k].created_at) + " [" + logs[k].action + "] " +
          (logs[k].actor || "auto") + " " + (logs[k].old_status || "-") + "→" +
          (logs[k].new_status || "-") + " " + (logs[k].details_json || ""));
      }
      html += esc(lines.join("\n") || "（暂无记录）") + "</pre>";
      html += '<p class="note">' + esc(d.rules || "") + "</p>";
      $("qeDBody").innerHTML = html;
      loadEvHighRisk(id);
      loadEvWorklist(id);
    }).catch(function (e) { toast("证据卡详情加载失败：" + e.message, true); });
  }

  /* 高风险行禁勾选 + 打标（批量永不碰高风险） */
  function loadEvHighRisk(evId) {
    api("/api/qe/evidence/" + evId + "/high-risk").then(function (d) {
      var hr = d.high_risk || [], bt = {};
      for (var i = 0; i < (d.batchable || []).length; i++) bt[d.batchable[i]] = 1;
      qeState.evBatchable = d.batchable || [];
      qeState.evPolicy = d.policy || "";
      for (var j = 0; j < hr.length; j++) {
        var row = document.querySelector("[data-frow='" + hr[j].id + "']");
        if (!row) continue;
        var cb = row.querySelector("input[data-fid]");
        if (cb) { cb.disabled = true; cb.checked = false; cb.title = hr[j].text; }
        var slot = row.querySelector(".hr-slot");
        if (slot) slot.innerHTML = "<span class='tag failed' title='" +
          esc(hr[j].text) + "'>高风险·单验</span>";
      }
      var n = qeState.evBatchable.length;
      var box = $("qeEvBatchInfo");
      if (box) box.textContent = "可批量 " + n + " 条 / 高风险 " + hr.length + " 条（禁批量）";
    }).catch(function () {});
  }

  /* 必须人工量清单（进度环）：判定归人、定位归机器 */
  function loadEvWorklist(evId) {
    api("/api/qe/evidence/" + evId + "/worklist").then(function (r) {
      var c = r.counts || {}, G = r.groups || {};
      var txt = $("qeWlTxt"), clk = $("qeWlClicks");
      qeState.evWorklist = r;
      if (txt) {
        txt.innerHTML = "核验进度 <b>" + r.closed + "/" + r.total + "</b> · " +
          "<span class='tag failed'>高风险逐条 " + (c.A || 0) + "</span> " +
          "<span class='tag done'>可批量 " + (c.B || 0) + "（1 点击）</span> " +
          "<span class='tag warn'>待判定 " + ((c.C || 0) + (c.D || 0) + (c.F || 0)) + "</span>" +
          ((c.E || 0) ? " <span class='tag'>OCR 阻塞 " + c.E + "</span>" : "");
      }
      if (clk) clk.textContent = "剩余必须点击 " + r.clicks_est + " 次";
      qeSetBar("qeWlBar", (r.progress || 0) * 100);
      if (r.clicks_est === 0 && r.total) toast("无剩余人工量，可跑冻结自查");
    }).catch(function () {});
  }

  function evAttach(dry) {
    var d = qeState.evDetail;
    if (!d) return;
    var box = $("qeAttachBox");
    var paths = (box && box.value || "").split(/[\r\n,，]+/)
      .map(function (s) { return s.trim(); }).filter(Boolean);
    if (!paths.length) { toast("粘贴 field_path 清单（每行一个）", true); return; }
    var tf = $("qeAttachTf");
    api("/api/qe/evidence/" + d.evidence.id + "/fields/batch-attach",
        { method: "POST", body: { field_paths: paths,
          extend_target: !!(tf && tf.checked), dry: !!dry } })
      .then(function (r) {
        toast((dry ? "[预览] " : "") + "挂接草稿 " + r.field_evidence +
              " / target +" + r.target_fields + " / 跳过 " + r.skipped +
              (dry ? "" : "（草稿≠核验，page+quote 仍须人工）"), !dry && r.field_evidence > 0);
        if (!dry) {
          openEvidenceDrawer(d.evidence.id);
          loadEvidence();
        } else {
          var panel = $("qeEvRejected");
          if (panel) {
            panel.textContent = "挂接预览（dry，未写库）：草稿 " + r.field_evidence +
              " / target +" + r.target_fields + " / 跳过 " + r.skipped +
              "\n" + paths.slice(0, 40).join("\n");
            panel.className = "code";
          }
        }
      }).catch(function (e) { toast(e.message, true); });
  }

  function evCheckedIds() {
    var out = [], boxes = document.querySelectorAll("#qeDBody input[data-fid]:checked");
    for (var i = 0; i < boxes.length; i++) {
      if (!boxes[i].disabled) out.push(Number(boxes[i].getAttribute("data-fid")));
    }
    return out;
  }

  function evBatchRender(rep) {
    var rj = rep.rejected || [], groups = {};
    for (var i = 0; i < rj.length; i++) {
      var code = String(rj[i].reason || "").split(":")[0];
      groups[code] = (groups[code] || 0) + 1;
    }
    var parts = [];
    for (var k in groups) if (groups.hasOwnProperty(k)) parts.push(k + "×" + groups[k]);
    toast((rep.dry ? "预览" : "batch " + rep.batch_id) + "：可验证 " + (rep.verified || []).length +
      " / 拒绝 " + rj.length + (parts.length ? "（" + parts.join("、") + "）" : "") +
      " / 已核验 " + (rep.already || []).length, rj.length > 0);
    var panel = $("qeEvRejected");
    if (panel && rj.length) {
      var lines = [];
      for (var m = 0; m < rj.length; m++) {
        lines.push((rj[m].field_path || ("#" + rj[m].id)) + " ← " + rj[m].reason);
      }
      panel.textContent = "拒绝明细（" + rj.length + "）：\n" + lines.join("\n");
      panel.className = "code";
    } else if (panel) {
      panel.textContent = "";
      panel.className = "code hide";
    }
  }

  function evBatchVerify(dry) {
    var d = qeState.evDetail;
    if (!d) return;
    var ids = evCheckedIds();
    if (!ids.length) { toast("先勾选要确认的行（高风险行不可勾选）", true); return; }
    api("/api/qe/evidence/" + d.evidence.id + "/fields/batch-verify",
        { method: "POST", body: { field_ids: ids, dry: !!dry } })
      .then(function (rep) {
        evBatchRender(rep);
        if (dry) {
          // 两段式：预览后手工确认再写库（拒绝明细进 confirm 文本）
          var rj = rep.rejected || [], lines = [];
          for (var i = 0; i < rj.length && i < 15; i++) {
            lines.push("  • " + (rj[i].field_path || ("#" + rj[i].id)) + " ← " + rj[i].reason);
          }
          var msg = "可验证 " + (rep.verified || []).length + " · 已核验 " +
            (rep.already || []).length + " · 拒绝 " + rj.length +
            (lines.length ? "\n\n拒绝明细：\n" + lines.join("\n") +
              (rj.length > 15 ? "\n  … 共 " + rj.length + " 条" : "") : "") +
            "\n\n确认写库？";
          if (confirm(msg)) evBatchVerify(false);
          return;
        }
        openEvidenceDrawer(d.evidence.id);
        loadEvidence();
      }).catch(function (e) { toast(e.message, true); });
  }

  /* A 组：高险字段核验弹窗（预填 E3 top-1 候选，多候选可一键切换） */
  function evVerifyModal(fid) {
    api("/api/qe/evidence/field/" + fid + "/candidates").then(function (c) {
      var cands = c.candidates || [];
      var page = (c.top && c.top.page) || c.current_page || "";
      var quote = (c.top && c.top.quote) || c.current_quote || "";
      var box = document.createElement("div");
      box.id = "qeVmMask";
      box.style.cssText = "position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:9999;" +
        "display:flex;align-items:center;justify-content:center";
      var alts = "";
      for (var i = 1; i < cands.length; i++) {
        alts += "<button class='btn sm' data-vmal='p" + cands[i].page + "' " +
          "data-vmq=\"" + esc(String(cands[i].quote || "").slice(0, 120)) + "\">" +
          "p" + cands[i].page + " 「" + esc(String(cands[i].quote || "").slice(0, 48)) + "」</button> ";
      }
      box.innerHTML =
        "<div style='background:#fff;border-radius:10px;max-width:620px;width:94%;" +
        "max-height:86vh;overflow:auto;padding:16px 18px'>" +
        "<div style='font-weight:600;margin-bottom:8px'>字段核验 · <span class='mono'>" +
        esc(c.field_path) + "</span> <span class='sub'>(" + esc(c.mpn) + " · " +
        esc(c.status || "") + ")</span></div>" +
        (cands.length > 1 ? "<div class='note'>E3 候选 " + cands.length +
          " 条，已预填 top-1；下列可一键切换，**必须翻原厂 PDF 目视确认**后再提交。</div>" : "") +
        "<div class='note' style='margin:6px 0'>Gold 期望值：<b>" + esc(c.expected || "—") + "</b>" +
        (c.unit ? " " + esc(c.unit) : "") +
        (String(c.status || "").indexOf("conflict") === 0
          ? "　<span class='tag failed'>冲突行：须先裁决</span> 以 PDF 为准会改写 Gold 草稿值" : "") +
        "</div>" +
        "<div style='margin:10px 0'><div class='sub'>页码（PDF 物理页，1 起，必填）</div>" +
        "<input id='qeVmPage' type='number' min='1' value='" + (page || "") +
        "' style='width:140px;padding:6px 8px;border:1px solid #d6dae2;border-radius:6px'></div>" +
        "<div style='margin:10px 0'><div class='sub'>证据定位 / 原文 quote（高风险必含原文）</div>" +
        "<textarea id='qeVmQuote' rows='3' style='width:100%;font:12px monospace;" +
        "border:1px solid #d6dae2;border-radius:6px;padding:6px 8px'>" + esc(quote) + "</textarea></div>" +
        (alts ? "<div style='margin:10px 0'><div class='sub'>其他候选（点击切换）：</div>" +
          "<div style='margin-top:4px'>" + alts + "</div></div>" : "") +
        "<div style='display:flex;gap:8px;justify-content:flex-end;margin-top:12px'>" +
        "<button class='btn' data-vmact='cancel'>取消</button>" +
        (String(c.status || "").indexOf("conflict") === 0
          ? "<button class='btn' data-vmact='resolve_gold'>裁决：保留 Gold</button>" +
            "<button class='btn' data-vmact='resolve_pdf'>裁决：以 PDF 为准</button>"
          : "") +
        "<button class='btn' data-vmact='conflict'>标记冲突</button>" +
        "<button class='btn p' data-vmact='ok'>确认核验</button></div></div>";
      document.body.appendChild(box);
      box.addEventListener("click", function (ev) {
        var t = ev.target;
        if (!t.getAttribute) return;
        if (t === box || t.getAttribute("data-vmact") === "cancel") { box.remove(); return; }
        var al = t.getAttribute("data-vmal");
        if (al) {
          $("qeVmPage").value = String(al).replace("p", "");
          $("qeVmQuote").value = t.getAttribute("data-vmq") || "";
          return;
        }
        var act = t.getAttribute("data-vmact");
        var pg = parseInt(($("qeVmPage") || {}).value || "0", 10) || 0;
        var q = (($("qeVmQuote") || {}).value || "").trim();
        if (act === "resolve_pdf" || act === "resolve_gold") {
          var isPdf = act === "resolve_pdf";
          var newexp = "";
          if (isPdf) {
            if (!pg) { toast("页码必填且 >0", true); return; }
            if (!q) { toast("PDF 真值 quote 必填（须能在原页命中）", true); return; }
            newexp = prompt("PDF 真值（将写入 Gold 草稿 expected）", c.expected || "");
            if (newexp === null) return;
            if (!String(newexp).trim()) { toast("PDF 真值必填", true); return; }
          }
          var why2 = prompt(isPdf ? "裁决理由（审计必填，如：p1 Ordering 行原文）"
                                   : "保留 Gold 的理由（审计必填）", "");
          if (!why2) { toast("裁决必须写理由", true); return; }
          t.disabled = true;
          var body2 = { action: isPdf ? "use_pdf" : "keep_gold", reason: why2 };
          if (isPdf) {
            body2.expected = String(newexp).trim();
            body2.page_number = pg;
            body2.evidence_quote = q;
          }
          api("/api/qe/evidence/field/" + fid + "/resolve", { method: "POST", body: body2 })
            .then(function (d) {
              box.remove();
              toast("已裁决：Gold 期望值 " + (d.old_expected || "—") + " → " +
                    (d.expected || "—") + "；状态转 ready，请再点「核验」");
              if (qeState.evDetail) openEvidenceDrawer(qeState.evDetail.evidence.id);
            }).catch(function (err) { t.disabled = false; toast("裁决被拒：" + err.message, true); });
          return;
        }
        if (act === "conflict") {
          var why = prompt("冲突原因 / PDF 正确值（审计必填）", "");
          if (!why) { toast("标记冲突必须写原因", true); return; }
          t.disabled = true;
          api("/api/qe/evidence/field/" + fid + "/conflict",
              { method: "POST", body: { reason: why } })
            .then(function () {
              box.remove();
              toast("已标冲突（冻结守卫会阻断，直到裁决完）", true);
              if (qeState.evDetail) openEvidenceDrawer(qeState.evDetail.evidence.id);
            }).catch(function (err) { t.disabled = false; toast(err.message, true); });
          return;
        }
        if (act !== "ok") return;
        if (!pg) { toast("页码必填且 >0", true); return; }
        if (!q) { toast("证据 quote 必填", true); return; }
        t.disabled = true;
        api("/api/qe/evidence/field/" + fid + "/verify",
            { method: "POST", body: { page_number: pg, evidence_quote: q } })
          .then(function () {
            box.remove();
            toast("字段已核验（已留审计）");
            if (qeState.evDetail) openEvidenceDrawer(qeState.evDetail.evidence.id);
            loadEvidence();
          }).catch(function (err) { t.disabled = false; toast(err.message, true); });
      });
    }).catch(function (e) { toast("候选加载失败：" + e.message, true); });
  }

  function evReadiness() {
    var d = qeState.evDetail;
    if (!d) return;
    api("/api/qe/evidence/" + d.evidence.id + "/freeze-precheck").then(function (r) {
      var lines = [], bad = [];
      for (var i = 0; i < (r.checks || []).length; i++) {
        var c = r.checks[i];
        lines.push((c.ok ? "✓" : "✗") + " G" + c.no + " " + c.name + " — " + c.detail);
        if (!c.ok) bad.push("  └ G" + c.no + " 处置：" + c.fix);
      }
      var good = (r.checks || []).length - bad.length;
      var head = "冻结前置自查 · " + r.mpn + "（evidence#" + r.evidence_id +
        " gold#" + r.gold_id + " " + (r.gold_status || "") + "）\n" +
        "汇总：" + good + "/" + (r.checks || []).length + " 绿 → " +
        (good === (r.checks || []).length ? "冻结就绪 YES" : "未就绪 NO") +
        (r.server_can_freeze !== undefined && r.server_can_freeze !== null
          ? " · 服务端 can_freeze=" + r.server_can_freeze : "") + "\n";
      var extra = "";
      if ((r.missing_fe || []).length) {
        extra += "\n补挂接清单（缺字段证据）：\n" + r.missing_fe.join("\n");
      }
      if ((r.missing_tf || []).length) {
        extra += "\n补 target_fields：\n" + JSON.stringify(r.missing_tf);
      }
      var panel = $("qeEvRejected");
      if (panel) {
        panel.textContent = head + lines.join("\n") +
          (bad.length ? "\n\n" + bad.join("\n") : "") + extra;
        panel.className = "code";
      } else {
        alert(head + lines.join("\n"));
      }
      toast("冻结自查：" + good + "/" + (r.checks || []).length + " 绿" +
            (good === (r.checks || []).length ? "（可冻结）" : "（红项见面板）"),
            good !== (r.checks || []).length);
    }).catch(function (e) { toast(e.message, true); });
  }

  function evAutoChain() {
    var d = qeState.evDetail;
    if (!d) return;
    var id = d.evidence.id;
    if (!confirm("一键定位（机器起草）？\n会重算：身份预检 + 逐字段页码/表/行/列/quote 候选 + 三向比对。\n" +
                 "只写草稿（reviewer 留空），不改标准值、不做 verified。\n\n先跑 dry 预览？点「确定」= 预览，点「取消」= 直接落草稿。")) {
      if (!confirm("直接落草稿（写库）？")) return;
      runChain(id, false);
      return;
    }
    runChain(id, true);
  }

  function runChain(id, dry) {
    api("/api/qe/evidence/" + id + "/auto-chain", { method: "POST", body: { dry: !!dry } })
      .then(function (r) {
        var e2 = r.e2 || {}, e3 = r.e3 || {}, e4 = r.e4 || {};
        var msg = (dry ? "[预览] " : "[已落草稿] ") +
          "预检 " + (e2.verdict || "—") +
          " · 定位 " + (e3.located || 0) + "/" + (e3.fields_total || "?") +
          "（多候选 " + (e3.ambiguous || 0) + " / 缺 " + (e3.missing || 0) + "）" +
          " · 就绪 " + (e4.ready || 0) + " / 冲突 " + (e4.conflict || 0);
        toast(msg, (e2.verdict === "red") || (e4.conflict > 0));
        if (!dry) { openEvidenceDrawer(id); loadEvidence(); }
        var panel = $("qeEvRejected");
        if (panel && e3.fields) {
          var miss = [];
          for (var i = 0; i < e3.fields.length; i++) {
            if (!e3.fields[i].locator) miss.push(e3.fields[i].path);
          }
          if (miss.length) {
            panel.textContent = "未定位字段（" + miss.length + "）：\n" + miss.slice(0, 40).join("\n");
            panel.className = "code";
          }
        }
      }).catch(function (e) { toast(e.message, true); });
  }

  function qeEvAct(act) {
    var d = qeState.evDetail;
    if (!d) return;
    var e = d.evidence || {}, doc = d.document || {}, id = e.id;
    if (act === "chain") { evAutoChain(); return; }
    if (act === "batchdry") { evBatchVerify(true); return; }
    if (act === "batch") { evBatchVerify(false); return; }
    if (act === "readiness") { evReadiness(); return; }
    if (act === "worklist") { loadEvWorklist(id); return; }
    if (act === "attachbox") {
      var ab = $("qeEvAttach");
      if (ab) ab.className = ab.className === "hide" ? "" : "hide";
      return;
    }
    if (act === "riskguide") {
      window.open("/api/qe/evidence/" + id + "/risk-guide.html", "_blank");
      return;
    }
    if (act === "riskguidemd") {
      window.open("/api/qe/evidence/" + id + "/risk-guide.md", "_blank");
      return;
    }
    if (act === "attachdry") { evAttach(true); return; }
    if (act === "attachapply") { evAttach(false); return; }
    if (act === "doc") {
      var tier = prompt("来源等级（P0 原厂 PDF / P1 产品页·勘误·封装图 / P2 应用说明 / " +
                        "P3 分销聚合 / P4 OCR·LLM·解析 JSON）", "P0");
      if (tier === null) return;
      var url = prompt("来源 URL（官方 datasheet 链接，可空）", doc.source_url || "");
      if (url === null) return;
      var lp = prompt("本地 PDF 路径（仓库相对或绝对，如 qc/pdfs/xxx.pdf；可空）",
                      doc.local_path || "");
      if (lp === null) return;
      api("/api/qe/evidence/" + id + "/documents",
          { method: "POST", body: { source_tier: tier, source_url: url, local_path: lp } })
        .then(function (r) {
          var ins = r.inspection || {};
          toast("文档已登记 #" + r.document_id + (r.reused ? "（同 SHA 复用）" : "") +
                " · " + (ins.page_count || 0) + " 页 · " +
                (ins.is_official ? "官方域名" : "非官方/未确认"));
          openEvidenceDrawer(id);
          loadEvidence();
        }).catch(function (err) { toast(err.message, true); });
      return;
    }
    if (act === "identity") {
      if (!doc.id) { toast("先登记文档", true); return; }
      var cov = prompt("人工确认此 PDF 覆盖的型号（逗号分隔，必须含 " + e.mpn + "）", e.mpn);
      if (cov === null) return;
      var notes = prompt("核验依据（型号 / 后缀 / 封装 / 修订版本，写清楚）", "");
      if (notes === null) return;
      api("/api/qe/evidence/" + id + "/verify-identity",
          { method: "POST", body: { covered_mpns: cov, notes: notes } })
        .then(function (r) {
          if (r.identity_status === "verified") {
            toast("身份已核验 → 进入字段核验");
          } else {
            toast("未通过：已置 source_unresolved（风险任务 +" + (r.risk_added || 0) + "）", true);
          }
          openEvidenceDrawer(id);
          loadEvidence();
        }).catch(function (err) { toast(err.message, true); });
      return;
    }
    if (act === "field") {
      var path = prompt("字段路径（对齐 Gold，如 pins.V_PLUS.pin_number）", "");
      if (!path) return;
      var pg = parseInt(prompt("PDF 页码（必填，正整数）", "0") || "0", 10) || 0;
      if (!pg) { toast("页码必须 > 0 才能核验", true); return; }
      var table = prompt("表名（如 Table 5-1 Pin Functions）", "") || "";
      var row = prompt("行（如 V+）", "") || "";
      var col = prompt("列（如 D (SOIC)）", "") || "";
      var cell = prompt("该单元格原值", "") || "";
      var gid = prompt("绑定 Gold 字段 ID（可空，填则核验时同步 Gold）", "0") || "0";
      api("/api/qe/evidence/" + id + "/fields", { method: "POST", body: {
        field_path: path, page_number: pg, table_name: table, row_key: row,
        column_key: col, cell_value: cell, gold_field_id: parseInt(gid, 10) || 0 } })
        .then(function (r) {
          toast("字段证据 #" + r.field_evidence_id + " 已登记");
          openEvidenceDrawer(id);
        }).catch(function (err) { toast(err.message, true); });
      return;
    }
    if (act === "unresolved" || act === "conflict") {
      var why = prompt("原因（审计必填：缺什么证据 / 与哪份文档冲突）", "");
      if (!why) return;
      api("/api/qe/evidence/" + id + "/status", { method: "POST",
        body: { status: act === "conflict" ? "conflict" : "source_unresolved", reason: why } })
        .then(function (r) {
          toast("状态 → " + r.status + (r.risk_added ? "（风险任务 +" + r.risk_added + "）" : ""));
          openEvidenceDrawer(id);
          loadEvidence();
        }).catch(function (err) { toast(err.message, true); });
      return;
    }
    if (act === "freeze") {
      if (!confirm("冻结 " + e.mpn + " 的 Gold？\n守卫条件：来源官方 + 身份已验证 + " +
                   "覆盖型号含目标 + 每个待冻结字段都有已核验页码证据。")) return;
      api("/api/qe/evidence/" + id + "/freeze", { method: "POST", body: {} })
        .then(function (r) {
          toast("已冻结：" + r.mpn + "（" + r.message + "）");
          openEvidenceDrawer(id);
          loadEvidence();
          loadGold();
        }).catch(function (err) { toast(err.message, true); });
    }
  }

  function qeEvFieldVerify(fid) {
    evVerifyModal(fid);
  }

  /* ── 风险队列 ── */
  function loadRisk() {
    var qs = [];
    if (state.qeRiskPri) qs.push("priority=" + state.qeRiskPri);
    if (state.qeRiskQ) qs.push("q=" + encodeURIComponent(state.qeRiskQ));
    api("/api/qe/risk" + (qs.length ? "?" + qs.join("&") : "")).then(function (d) {
      var dist = d.distribution || {};
      $("qeRiskP0").textContent = dist.P0 || 0;
      $("qeRiskP1").textContent = dist.P1 || 0;
      $("qeRiskP2").textContent = dist.P2 || 0;
      var rows = d.items || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        var priTag = r.priority === "P0" ? statusTag("failed", "P0 阻断")
          : (r.priority === "P1" ? statusTag("nodata", "P1 高风险")
          : statusTag("queued", "P2 普通"));
        var stTag = r.status === "confirming" ? statusTag("parsing", "核验中")
          : (r.status === "to_regression" ? statusTag("done", "已转回归")
          : (r.status === "rejected" ? statusTag("skipped", "已驳回")
          : (r.status === "closed" ? statusTag("skipped", "已关闭")
          : statusTag("queued", "待核验"))));
        var ops = "";
        if (r.status === "open")
          ops += "<button class='btn sm' data-qerisk='" + r.id + "' data-act='start'>开始核验</button> ";
        if (r.status === "open" || r.status === "confirming") {
          ops += "<button class='btn sm warn' data-qerisk='" + r.id + "' data-act='confirm'>确认缺陷→转回归</button> " +
                 "<button class='btn sm ghost' data-qerisk='" + r.id + "' data-act='reject'>误报驳回</button>";
        }
        if (!ops) ops = "<span class='sub'>—</span>";
        html += "<tr><td>" + priTag + "</td><td class='mono'><b>" + esc(r.mpn) +
          "</b></td><td class='mono'>" + esc(r.kind) + "</td><td>" + r.score.toFixed(1) +
          "</td><td>" + esc(r.reason) + "</td><td>" + stTag + "</td><td>" + ops + "</td></tr>";
      }
      $("qeRiskBody").innerHTML = html ||
        "<tr><td colspan='7' class='empty'>队列为空 —— 跑一轮自动化 QC 后点「从 QC findings 同步队列」</td></tr>";
    }).catch(function (e) { toast("风险队列加载失败：" + e.message, true); });
  }

  function qeRiskAction(id, act) {
    var body = { action: act };
    if (act === "confirm" &&
        !confirm("确认该缺陷为真实错误？\n→ 创建反馈用例（进入回归闭环）→ 风险条目转 to_regression")) return;
    if (act === "reject") {
      var why = prompt("误报原因（留档）", "");
      if (why === null) return;
      body.note = why;
    }
    api("/api/qe/risk/" + id + "/action", { method: "POST", body: body })
      .then(function (d) {
        toast(act === "confirm" ? "已确认并创建反馈用例 #" + (d.feedback_id || "")
              : "已" + (act === "start" ? "开始核验" : (act === "reject" ? "驳回" : "关闭")));
        loadRisk();
      }).catch(function (e) { toast(e.message, true); });
  }

  /* ── 随机审计 ── */
  function loadSample() {
    api("/api/qe/sample").then(function (d) {
      var mr = d.miss_rate || {};
      $("qeMissKpis").innerHTML =
        kpi("已完成审计（30 天）", mr.audited || 0) +
        kpi("发现漏报", mr.miss || 0, mr.miss ? "warn" : "ok") +
        kpi("漏报比例", mr.rate == null ? "—" : (mr.rate * 100).toFixed(1) + "%",
            mr.rate && mr.rate > 0.05 ? "bad" : "", "样本内观测值");
      var rows = d.batches || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var b = rows[i];
        var stTag = b.status === "done" ? statusTag("done", "已完成")
          : statusTag("parsing", "进行中");
        html += "<tr><td class='mono'><b>" + esc(b.code) + "</b></td><td>" +
          esc(b.population) + "</td><td>" + b.n + "</td><td>" + (b.done || 0) + " / " + b.n +
          "</td><td>" + (b.defects || 0) + "</td><td>" + stTag + "</td><td class='mono'>" +
          esc(fmtTime(b.created_at)) + "</td><td><button class='btn sm' data-qesample='" +
          b.id + "'>" + (b.status === "done" ? "查看报告" : "继续核验") + "</button></td></tr>";
      }
      $("qeSampleBody").innerHTML = html ||
        "<tr><td colspan='8' class='empty'>暂无批次 —— 配置总体与数量后点「生成审计批次」</td></tr>";
    }).catch(function (e) { toast("随机审计加载失败：" + e.message, true); });
  }

  function qeSampleCreate() {
    var n = parseInt($("qeSampleN").value || "30", 10);
    var days = parseInt($("qeSampleDays").value || "30", 10);
    var method = "random";
    var rds = document.querySelectorAll("input[name=qeSampleMethod]");
    for (var i = 0; i < rds.length; i++) if (rds[i].checked) method = rds[i].value;
    api("/api/qe/sample/create", { method: "POST",
      body: { n: n, days: days, method: method } })
      .then(function (d) {
        toast("已创建 " + d.code + "：" + d.n + " 件（总体 " + d.population_n + "，种子留档）");
        loadSample();
      }).catch(function (e) { toast(e.message, true); });
  }

  function openSampleDrawer(batchId) {
    $("qeDrawerMask").className = "drawer-mask";
    $("qeDrawer").className = "drawer";
    $("qeDTitle").textContent = "加载中…";
    $("qeDBody").innerHTML = "";
    api("/api/qe/sample/" + batchId).then(function (d) {
      var b = d.batch || {};
      qeState.sampleBatch = d;
      $("qeDTitle").textContent = b.code + " · 随机审计批次";
      $("qeDSub").textContent = b.population + " · 方式 " + b.method + " · 种子 " + b.seed +
        " · 样本 " + b.n + " 件";
      var items = d.items || [];
      var html = '<p class="note" style="margin-top:0">' + esc(d.blind || "") + " · 种子与总体快照已留档（" +
        (b.snapshot || "").length + " 字符），漏报判定后可一键转反馈闭环。</p>";
      html += '<div class="table-wrap tall"><table class="grid compact"><thead><tr>' +
        "<th>#</th><th>型号</th><th>判定</th><th>备注</th><th>核验人 / 时间</th>" +
        "<th style='width:250px'>操作</th></tr></thead><tbody>";
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        var tag = it.result === "pass" ? statusTag("done", "无漏报")
          : (it.result === "miss" ? statusTag("failed", "漏报")
          : statusTag("queued", "待核验"));
        var ops = "";
        if (it.result === "pending") {
          ops += "<button class='btn sm' data-qesv='" + it.id + "' data-r='pass'>✓ 无漏报</button> " +
                 "<button class='btn sm warn' data-qesv='" + it.id + "' data-r='miss'>✗ 发现漏报→转反馈</button>";
        } else if (it.result === "miss") {
          ops += "<span class='sub'>已转反馈闭环</span> " +
                 "<button class='btn sm ghost' data-qesv='" + it.id + "' data-r='pending'>撤销判定</button>";
        } else {
          ops += "<button class='btn sm ghost' data-qesv='" + it.id + "' data-r='pending'>撤销判定</button>";
        }
        html += "<tr><td class='mono'>" + (i + 1) + "</td><td class='mono'><b>" + esc(it.mpn) +
          "</b></td><td>" + tag + "</td><td class='sub'>" + esc(it.note || "") +
          "</td><td class='mono'>" + esc(it.operator || "") + " " +
          esc(it.reviewed_at ? fmtTime(it.reviewed_at) : "") + "</td><td>" + ops + "</td></tr>";
      }
      html += "</tbody></table></div>";
      $("qeDBody").innerHTML = html;
    }).catch(function (e) { toast("批次加载失败：" + e.message, true); });
  }

  function qeSampleReview(itemId, result) {
    var d = qeState.sampleBatch;
    if (!d) return;
    var body = { item_id: itemId, result: result };
    if (result === "miss") {
      var kind = prompt("漏报类型（kind，如 pin_mismatch / unit_dimension / missed_defect）",
                        "missed_defect");
      if (kind === null) return;
      var note = prompt("漏报说明（对照原厂文档描述错误）", "");
      if (note === null) return;
      body.kind = kind; body.note = note; body.to_feedback = true;
    }
    api("/api/qe/sample/" + d.batch.id + "/review", { method: "POST", body: body })
      .then(function () {
        toast(result === "miss" ? "已记漏报并创建反馈用例"
              : (result === "pass" ? "已判定无漏报" : "已撤销"));
        openSampleDrawer(d.batch.id);
        loadSample();
      }).catch(function (e) { toast(e.message, true); });
  }

  /* ── 引擎对比 ── */
  var QE_ENGINE_NOTE = {
    pymupdf: "Baseline · 轻量稳定，风险：可能漏抽",
    opendataloader: "结构化 · 覆盖更广，风险：行列配对需验证",
    docstrange: "暂跳过 · 云端模式需 NanoNets OAuth 授权（首次调用弹授权页），"
      + "对比口径先按 PyMuPDF/ODL 双引擎；需要时在 dsenv venv 授权后重跑即可"
  };

  function loadEngines() {
    api("/api/qe/engines").then(function (d) {
      renderEngines(d.last);
      var ab = d.ab_report;
      var abKv = {};
      if (ab && ab.total) {
        var t = ab.total;
        abKv[ab.label_a + " findings / unresolved"] = t.a.f + " / " + t.a.u;
        abKv[ab.label_b + " findings / unresolved"] = t.b.f + " / " + t.b.u;
        abKv[ab.label_a + " row_mispair"] = (t.a.kinds || {}).row_mispair || 0;
        abKv[ab.label_b + " row_mispair"] = (t.b.kinds || {}).row_mispair || 0;
        abKv["报告文件"] = ab.file;
        abKv["口径"] = "非 Gold Set 准确率（finding 数不是错误率）";
      } else {
        abKv["说明"] = "尚无 A/B 报告（qc/ab_odl.py 产物）";
      }
      $("qeEngAb").innerHTML = kvRows(abKv);
    }).catch(function (e) { toast("引擎对比加载失败：" + e.message, true); });
  }

  function renderEngines(rep) {
    var html = "";
    var engines = ["pymupdf", "opendataloader", "docstrange"];
    for (var i = 0; i < engines.length; i++) {
      var en = engines[i];
      var m = rep && rep.engines && rep.engines[en];
      html += '<div class="qe-engine"><div class="qe-engine-name"><b>' + en +
        '</b><span class="tag ' + (m && m.docs ? "done" : "nodata") + '">' +
        (m && m.docs ? "有产物" : "无产物") + "</span></div>";
      if (m && m.docs) {
        html += '<div class="qe-score">' + m.avg_rows +
          ' <span>行 / 器件</span></div>';
        html += qeBarLine("抽取完整度", m.completeness);
        html += qeBarLine("字段准确率", m.accuracy, true);
        html += qeBarLine("证据覆盖（条件保留）", m.evidence_cov);
        html += '<div class="qe-engine-note">' + esc(QE_ENGINE_NOTE[en] || "") +
          "</div>";
      } else {
        html += '<div class="qe-score">— <span>尚无结果</span></div>' +
          '<div class="qe-engine-note">' + esc(QE_ENGINE_NOTE[en] || "") +
          "</div>";
      }
      html += "</div>";
    }
    $("qeEngCards").innerHTML = html +
      '<p class="note" style="flex-basis:100%">' + (rep && rep.at
        ? "上次对比：" + esc(rep.at) + " · Gold " + rep.n_gold + " 件（frozen）"
        : "尚未运行对比 —— 冻结 Gold 样本后点「对比 Gold Set（frozen）」") + "</p>";
  }

  function qeBarLine(label, v, green) {
    var pct = (v == null) ? 0 : Math.round(v * 100);
    var txt = (v == null) ? "待 Gold" : pct + "%";
    return '<div class="qe-barrow"><label>' + label + '</label>' +
      '<div class="qe-bar' + (green ? " ok" : "") + '"><i style="width:' + pct + '%"></i></div>' +
      "<b>" + txt + "</b></div>";
  }

  function qeEngCompare() {
    toast("正在对比 Gold（frozen）× 各引擎产物…");
    api("/api/qe/engines/compare", { method: "POST", body: {} })
      .then(function (d) {
        if (!d.n_gold) {
          toast("Gold 集还没有冻结样本 —— 先核验字段并冻结，或对比仅统计已冻结件", true);
        }
        renderEngines(d);
        loadEngines();
      }).catch(function (e) { toast("对比失败：" + e.message, true); });
  }

  /* ── 反馈闭环 ── */
  function loadFb() {
    var qs = [];
    if (state.qeFbStatus) qs.push("status=" + encodeURIComponent(state.qeFbStatus));
    if (state.qeFbQ) qs.push("q=" + encodeURIComponent(state.qeFbQ));
    api("/api/qe/feedback" + (qs.length ? "?" + qs.join("&") : "")).then(function (d) {
      var st = d.stats || {};
      $("qeFbKpis").innerHTML =
        kpi("待转回归", st.pending || 0, st.pending ? "warn" : "") +
        kpi("已转夹具", st.fixture || 0, "", "修复后重跑") +
        kpi("回归失败", st.fail || 0, st.fail ? "bad" : "") +
        kpi("已通过", st.passed || 0, st.passed ? "ok" : "");
      var lr = d.last_regression || {};
      $("qeFbReg").innerHTML = kvRows({
        "最近回归": lr.created_at ? ("run#" + lr.id + " · " + fmtTime(lr.created_at)) : "尚未运行",
        "结果": lr.status === "ok" ? "PASS" : (lr.status || "—"),
        "件数": lr.parts ? (lr.parts_done + "/" + lr.parts) : "—",
        "夹具文件": (d.fixtures_file || "").replace(/^.*[\\\/]/, ""),
        "门禁": d.gate || ""
      });
      var rows = d.items || [];
      var html = "";
      for (var i = 0; i < rows.length; i++) {
        var f = rows[i];
        var tag = f.status === "pending" ? statusTag("nodata", "待转回归")
          : (f.status === "fixture" ? statusTag("parsing", "已转夹具")
          : (f.status === "fail" ? statusTag("failed", "回归失败")
          : (f.status === "passed" ? statusTag("done", "已通过")
          : statusTag("skipped", "已关闭"))));
        var ops = "";
        if (f.status === "pending" || f.status === "fail")
          ops += "<button class='btn sm' data-qefb='" + f.id + "' data-act='to-fixture'>转回归夹具</button> ";
        if (f.status === "fixture")
          ops += "<button class='btn sm' data-qefb='" + f.id + "' data-act='run'>▶ 跑回归（捕获缺陷）</button> " +
                 "<button class='btn sm warn' data-qefb='" + f.id + "' data-act='run-post'>✔ 修复后复验</button> ";
        if (f.status === "fixture" || f.status === "fail" || f.status === "passed")
          ops += "<button class='btn sm ghost' data-qefb='" + f.id + "' data-act='mark-fail'>标失败</button> " +
                 "<button class='btn sm ghost' data-qefb='" + f.id + "' data-act='mark-pass'>标通过</button>";
        if (!ops) ops = "<span class='sub'>—</span>";
        html += "<tr><td class='mono'><b>" + esc(f.code) + "</b></td><td>" +
          esc({ manual: "人工录入", risk: "风险队列", random_audit: "随机审计",
                customer: "客户反馈" }[f.source] || f.source) +
          "</td><td class='mono'>" + esc(f.mpn) + "</td><td class='mono'>" + esc(f.kind) +
          "</td><td class='sub'>" + esc(f.gold_evidence) + "</td><td>" + tag + "</td><td>" +
          ops + "</td></tr>";
      }
      $("qeFbBody").innerHTML = html ||
        "<tr><td colspan='7' class='empty'>暂无反馈用例 —— 从风险队列「确认缺陷」或随机审计「发现漏报」进入，也可人工新增</td></tr>";
    }).catch(function (e) { toast("反馈闭环加载失败：" + e.message, true); });
  }

  function qeFbAdd() {
    var mpn = ($("qeFbMpn").value || "").trim();
    var kind = ($("qeFbKind").value || "").trim();
    if (!mpn) { toast("请输入 MPN", true); return; }
    api("/api/qe/feedback", { method: "POST", body: { mpn: mpn, kind: kind, source: "manual" } })
      .then(function (d) {
        toast("已创建反馈用例 #" + d.feedback_id);
        $("qeFbMpn").value = ""; $("qeFbKind").value = "";
        loadFb();
      }).catch(function (e) { toast(e.message, true); });
  }

  function qeFbAction(id, act) {
    if (act === "to-fixture") {
      if (!confirm("转回归夹具？\n从 Gold 标准答案自动生成断言写入 regression_fixtures.json，" +
                   "与基础 11 件夹具一起跑。")) return;
      api("/api/qe/feedback/" + id + "/to-fixture", { method: "POST", body: {} })
        .then(function (d) {
          toast("已导出 " + d.asserts + " 条断言 → " + (d.path || "").replace(/^.*[\\\/]/, ""));
          loadFb();
        }).catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "run" || act === "run-post") {
      var post = act === "run-post";
      if (!confirm(post
        ? "修复后复验（--post 口径）：期望该缺陷已消失、断言仍成立。\n跑 11 件基础夹具 + 附加夹具。"
        : "跑回归（捕获口径）：期望回归能捕获该缺陷（用例有效性验证）。")) return;
      api("/api/qe/feedback/" + id + "/run", { method: "POST", body: { post: post } })
        .then(function (d) {
          toast("已投递回归 run#" + d.run_id + "（结果在「自动化 QC」运行历史查看）");
        }).catch(function (e) { toast(e.message, true); });
      return;
    }
    var status = act === "mark-fail" ? "fail" : "passed";
    api("/api/qe/feedback/" + id + "/status", { method: "POST", body: { status: status } })
      .then(function () { toast("状态 → " + status); loadFb(); })
      .catch(function (e) { toast(e.message, true); });
  }

  function closeQeDrawer() {
    $("qeDrawerMask").className = "drawer-mask hide";
    $("qeDrawer").className = "drawer hide";
  }


  /* ---------------- 概览 ---------------- */
  function kpi(label, value, cls, sub) {
    return '<div class="kpi ' + (cls || "") + '"><div class="kpi-label">' + esc(label) +
      '</div><div class="kpi-value">' + esc(value) +
      (sub ? '<small>' + esc(sub) + "</small>" : "") + "</div></div>";
  }

  function loadOverview() {
    api("/api/overview").then(function (d) {
      $("kpis").innerHTML =
        kpi("型号总数", d.total) +
        kpi("已完成交付", d.done, "ok") +
        kpi("执行中", d.running, "accent") +
        kpi("失败", d.failed, d.failed ? "bad" : "") +
        kpi("未找到 Datasheet", d.nodata, d.nodata ? "warn" : "") +
        kpi("已解析", d.parsed_count, "", d.pdf_mb + " MB PDF");
      var pill = $("modePill");
      if (d.mode === "celery") { pill.className = "pill ok"; pill.textContent = "Celery + Redis"; }
      else if (d.mode === "inline") { pill.className = "pill warn"; pill.textContent = "降级：进程内线程池"; }
      else { pill.className = "pill bad"; pill.textContent = "队列不可用"; }
      $("sideMode").textContent = "队列：" + (d.mode === "celery" ? "Celery" : (d.mode === "inline" ? "线程池" : "不可用"));
    }).catch(function (e) { toast("概览加载失败：" + e.message, true); });
  }

  /* ---------------- 型号列表 ---------------- */
  function statusTag(s, text) {
    return '<span class="tag ' + esc(s) + '">' + esc(text || s) + "</span>";
  }

  function loadItems() {
    var qs = "/api/items?page=" + state.page + "&size=" + state.size;
    if (state.q) qs += "&q=" + encodeURIComponent(state.q);
    if (state.status) qs += "&status=" + encodeURIComponent(state.status);
    if (state.batchId) qs += "&batch_id=" + encodeURIComponent(state.batchId);
    api(qs).then(function (d) {
      state.total = d.total;
      var rows = d.items || [];
      var html = "";
      if (!rows.length) {
        html = '<tr><td colspan="8" class="empty">还没有型号。先上传型号表。</td></tr>';
      }
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        var sel = state.selected[r.mpn_key] ? " sel" : "";
        var meta = r.meta || {};
        html += '<tr class="' + sel + '" data-key="' + esc(r.mpn_key) + '">' +
          '<td><input type="checkbox" class="rowck" data-key="' + esc(r.mpn_key) + '"' +
          (state.selected[r.mpn_key] ? " checked" : "") + "></td>" +
          '<td><div class="mpnn">' + esc(r.mpn) + "</div>" +
          '<div class="sub">' + esc(r.brand || "—") +
          (meta.pkg || meta.pkg_hint ? " · " + esc(String(meta.pkg || meta.pkg_hint).slice(0, 46)) : "") +
          "</div></td>" +
          "<td>" + statusTag(r.status, r.status_text) + "</td>" +
          '<td><span class="mono">' + esc(r.provider || "—") + "</span></td>" +
          '<td><span class="ready' + (r.ready >= 6 ? " full" : "") + '">' + r.ready + "/7</span></td>" +
          "<td>" + fmtSize(r.pdf_bytes) + "</td>" +
          '<td class="mono">' + esc(fmtTime(r.last_parsed_at)) + "</td>" +
          '<td><button class="btn sm ghost act-open" data-key="' + esc(r.mpn_key) +
          '">详情</button> <button class="btn sm ghost act-review" data-mpn="' +
          esc(r.mpn) + '" title="红线质量审查：规则先过、LLM 兜底；只读产物">审计</button></td></tr>';
      }
      $("itemBody").innerHTML = html;
      updateSelCount();
      var pages = Math.max(1, Math.ceil(d.total / state.size));
      $("pageInfo").textContent = "共 " + d.total + " 条 · 第 " + state.page + " / " + pages + " 页";
      $("btnPrev").disabled = state.page <= 1;
      $("btnNext").disabled = state.page >= pages;
    }).catch(function (e) { toast("列表加载失败：" + e.message, true); });
  }

  /* ---------------- 批次 ---------------- */
  function loadBatches() {
    api("/api/batches").then(function (list) {
      var sel = $("batchFilter");
      var cur = state.batchId;
      var html = '<option value="">全部批次</option>';
      for (var i = 0; i < list.length; i++) {
        var b = list[i];
        if (b.kind !== "parts") continue;
        html += '<option value="' + b.id + '"' + (String(cur) === String(b.id) ? " selected" : "") +
          ">#" + b.id + " " + esc(b.filename) + "</option>";
      }
      sel.innerHTML = html;
    }).catch(function () {});
  }

  function loadBatchTable() {
    api("/api/batches").then(function (list) {
      var html = "";
      for (var i = 0; i < list.length; i++) {
        var b = list[i];
        var kindText = { parts: "型号表", catalog: "站内目录", images: "图片命名表" }[b.kind] || b.kind;
        var n = b.kind === "parts" ? (b.items || 0) + " 型号" : (b.unique_mpns || b.total_rows || "—");
        html += "<tr><td>" + b.id + "</td>" +
          '<td><div class="truncate" title="' + esc(b.filename) + '">' + esc(b.filename) + "</div>" +
          '<div class="sub">' + esc(b.note || "") + "</div></td>" +
          "<td>" + kindText + "</td><td>" + esc(n) + "</td>" +
          "<td>" + statusTag(b.status === "ready" ? "done" : (b.status === "failed" ? "failed" : "queued"), b.status) + "</td>" +
          '<td class="mono">' + esc(fmtTime(b.created_at)) + "</td><td>";
        if (b.kind === "parts") {
          html += '<button class="btn sm ghost act-bparse" data-id="' + b.id + '">解析本批</button> ' +
            '<button class="btn sm act-bexport" data-id="' + b.id + '">打包导出</button>';
        }
        html += "</td></tr>";
      }
      $("batchBody").innerHTML = html || '<tr><td colspan="7" class="empty">暂无批次</td></tr>';
    }).catch(function (e) { toast(e.message, true); });
  }

  /* ---------------- 数据源 ---------------- */
  function kvRows(obj) {
    var html = "";
    for (var k in obj) {
      if (!obj.hasOwnProperty(k)) continue;
      html += '<div class="kv-row"><div class="kv-k">' + esc(k) + '</div><div class="kv-v">' +
        esc(obj[k] === "" ? "—" : obj[k]) + "</div></div>";
    }
    return html;
  }

  function renderPkgReport(r) {
    var html = kvRows({
      "库中封装": r.lib_keys + " 种",
      "已解析型号": r.models + " 个",
      "命中共享图": r.shared + " 个",
      "待补封装": r.missing_key + " 个型号 / " + r.missing.length + " 种",
      "板卡类不共享": r.board + " 个"
    });
    if (r.missing && r.missing.length) {
      var list = [];
      for (var i = 0; i < r.missing.length && i < 12; i++) {
        var m = r.missing[i];
        list.push(m.key + "（" + m.pins + " 脚 × " + m.n + "）");
      }
      html += '<div class="kv-row"><div class="kv-k">待补清单</div><div class="kv-v">' +
        esc(list.join("、")) + "</div></div>";
    }
    $("pkgKv").innerHTML = html;
  }

  function loadData() {
    api("/api/health").then(function (h) {
      $("catalogKv").innerHTML = kvRows({
        "索引状态": h.catalog.exists ? "已就绪" : "未建",
        "收录料号": h.catalog.rows ? h.catalog.rows.toLocaleString() : "0",
        "索引体积": h.catalog.size_mb + " MB",
        "建库时间": h.catalog.built_at || "—"
      });
      $("imagesKv").innerHTML = kvRows({
        "类别数": h.images.categories,
        "来源文件": h.images.source || "—",
        "导入时间": h.images.imported_at || "—",
        "渲染用 CSV": h.images.csv ? "已同步 data/app_images.csv" : "缺失"
      });
      $("sideCatalog").textContent = "内链索引 " + (h.catalog.rows ? (h.catalog.rows / 10000).toFixed(1) + " 万" : "未建");
      $("sideImages").textContent = "配图表 " + h.images.categories + " 类";
      if (h.pkgs) {
        $("pkgKv").innerHTML = kvRows({
          "库中封装": h.pkgs.keys + " 种",
          "共享粒度": "封装族 + 脚数（如 SOIC-8、TSSOP-38）",
          "未命中策略": "跑批时当场生成一次并入库，同封装型号共用",
          "不可共享": "原理图符号带引脚名，按型号内联；板卡/模块每块不同"
        });
      }
    }).catch(function (e) { toast(e.message, true); });

    api("/api/images").then(function (d) {
      var html = "";
      var rows = d.rows || [];
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        html += "<tr><td>" + esc(r.category) + "</td><td class=\"mono\">" + esc(r.image) +
          "</td><td class=\"sub\">" + esc(r.alt_en) + "</td></tr>";
      }
      $("imageBody").innerHTML = html || '<tr><td colspan="3" class="empty">还没有导入命名表</td></tr>';
    }).catch(function () {});
  }

  /* ---------------- 运行状态 ---------------- */
  function loadUsage() {
    var days = $("usageDays") ? $("usageDays").value : "7";
    api("/api/usage/summary?days=" + encodeURIComponent(days)).then(function (r) {
      var t = r.totals || {};
      var kv = {
        "调用次数": (t.calls || 0).toLocaleString(),
        "总 token": (t.total || 0).toLocaleString() + "（输入 " +
          (t.prompt || 0).toLocaleString() + " / 输出 " + (t.completion || 0).toLocaleString() + "）",
        "覆盖型号": (t.items || 0).toLocaleString(),
        "每型号平均": (t.tokens_per_item || 0).toLocaleString() + " token",
        "平均耗时": (t.avg_ms || 0) + " ms",
        "失败调用": (t.fails || 0).toLocaleString()
      };
      if (r.cost) {
        kv["估算成本"] = r.cost.total + " " + r.cost.currency +
          "（每型号约 " + r.cost.per_item + "）";
      }
      $("usageKv").innerHTML = kvRows(kv);

      var html = "";
      var rows = r.by_model || [];
      for (var i = 0; i < rows.length; i++) {
        var m = rows[i];
        html += "<tr><td>" + esc(m.model || "—") + "</td><td class=\"mono\">" +
          esc(m.provider || "—") + "</td><td>" + (m.calls || 0).toLocaleString() +
          "</td><td>" + (m.prompt || 0).toLocaleString() +
          "</td><td>" + (m.completion || 0).toLocaleString() +
          "</td><td>" + (m.total || 0).toLocaleString() +
          "</td><td>" + (m.share || 0) + "%</td><td>" + (m.avg_ms || 0) + " ms</td></tr>";
      }
      $("usageBody").innerHTML = html || '<tr><td colspan="8" class="empty">暂无数据（新版本 worker 开始记账后才有）</td></tr>';
    }).catch(function (e) { toast("用量加载失败：" + e.message, true); });
  }

  function loadSystem() {
    loadUsage();
    api("/api/health").then(function (h) {
      $("healthKv").innerHTML = kvRows({
        "队列模式": h.mode === "celery" ? "Celery（Redis 已连通）" : "降级：进程内线程池",
        "Redis": h.redis + (h.redis_ok ? "（通）" : "（不通）"),
        "队列名": h.queue,
        "解析并发": h.workers,
        "聚合站采集": h.aggregator ? "已开启" : "已关闭",
        "内链索引": h.catalog.rows ? h.catalog.rows.toLocaleString() + " 条" : "未建"
      });
      var lines = [
        "# 1) 工作台（本页）",
        "python run_server.py",
        "",
        "# 2) Celery worker（Windows 用线程池）",
        "celery -A worker.celery_app worker -Q icpdf -P threads -c " + h.workers + " -l info",
        "",
        "# 3) 只看 Redis 通不通",
        "python -c \"import redis;print(redis.Redis.from_url('" + h.redis + "').ping())\""
      ];
      $("cmdBlock").textContent = lines.join("\n");
    }).catch(function (e) { toast(e.message, true); });

    api("/api/events?limit=60").then(function (list) {
      var html = "";
      for (var i = 0; i < list.length; i++) {
        var e = list[i];
        html += "<tr><td>" + statusTag(e.kind === "error" ? "failed" : "done", e.kind) + "</td>" +
          "<td>" + esc(e.message) + (e.detail ? '<div class="sub">' + esc(e.detail.slice(0, 220)) + "</div>" : "") +
          '</td><td class="mono">' + esc(fmtTime(e.created_at)) + "</td></tr>";
      }
      $("eventBody").innerHTML = html || '<tr><td colspan="3" class="empty">暂无事件</td></tr>';
    }).catch(function () {});
  }

  /* ---------------- 上传 ---------------- */
  function upload(kind, file, barId, statusId) {
    var url = { parts: "/api/uploads/parts", catalog: "/api/uploads/catalog",
                images: "/api/uploads/images" }[kind];
    var bar = $(barId), st = $(statusId);
    var fd = new FormData();
    fd.append("file", file);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    st.className = "drop-status";
    st.textContent = "上传中 0%";
    bar.style.width = "0%";
    xhr.upload.onprogress = function (e) {
      if (!e.lengthComputable) return;
      var p = Math.round(e.loaded / e.total * 100);
      bar.style.width = p + "%";
      st.textContent = "上传中 " + p + "%";
    };
    xhr.onload = function () {
      var data = {};
      try { data = JSON.parse(xhr.responseText || "{}"); } catch (e2) { data = {}; }
      if (xhr.status >= 200 && xhr.status < 300) {
        bar.style.width = "100%";
        st.className = "drop-status ok";
        if (kind === "parts") {
          st.textContent = "已入库：" + data.rows + " 个型号（新增 " + data.created + "，复用 " + data.reused + "）" +
            (data.truncated ? "　注意：已达单批上限 " + data.cap + " 行，超出部分未入库" : "");
          if (confirm("型号表已入库（" + data.rows + " 个型号）。要立刻开始解析吗？\n解析会依次采集 PDF、调用模型，耗时较长。")) {
            startBatch(data.batch_id, false);
          }
          loadBatches(); loadItems(); loadOverview();
        } else if (kind === "catalog") {
          st.textContent = "已上传，后台开始重建内链索引（约 1-2 分钟）";
          pollBatch(data.batch_id, statusId);
        } else {
          st.textContent = "已导入 " + data.categories + " 类应用领域";
          loadData();
        }
        toast("上传成功");
      } else {
        bar.style.width = "0%";
        st.className = "drop-status err";
        st.textContent = "失败：" + (data.detail || ("HTTP " + xhr.status));
      }
    };
    xhr.onerror = function () {
      st.className = "drop-status err";
      st.textContent = "网络错误";
    };
    xhr.send(fd);
  }

  function pollBatch(batchId, statusId) {
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      api("/api/batches").then(function (list) {
        for (var i = 0; i < list.length; i++) {
          if (list[i].id !== batchId) continue;
          var b = list[i];
          $(statusId).textContent = "建索引：" + (b.progress || 0) + "% " + (b.note || "");
          if (b.status === "ready" || b.status === "failed" || tries > 100) {
            clearInterval(timer);
            $(statusId).className = "drop-status " + (b.status === "ready" ? "ok" : "err");
            loadData();
          }
        }
      }).catch(function () { if (tries > 100) clearInterval(timer); });
    }, 2500);
  }

  function bindDrop(zoneId, inputId, kind, barId, statusId) {
    var zone = $(zoneId), input = $(inputId);
    zone.addEventListener("click", function () { input.click(); });
    input.addEventListener("change", function () {
      if (input.files && input.files[0]) upload(kind, input.files[0], barId, statusId);
      input.value = "";
    });
    ["dragenter", "dragover"].forEach(function (ev) {
      zone.addEventListener(ev, function (e) { e.preventDefault(); zone.className = "drop over"; });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      zone.addEventListener(ev, function (e) {
        e.preventDefault(); zone.className = "drop";
        if (ev === "drop" && e.dataTransfer.files && e.dataTransfer.files[0]) {
          upload(kind, e.dataTransfer.files[0], barId, statusId);
        }
      });
    });
  }

  /* ---------------- 投递 ---------------- */
  function startBatch(batchId, force) {
    api("/api/items/parse", { method: "POST", body: { batch_id: batchId, force: !!force, only: "pending" } })
      .then(function (d) {
        toast("已投递 " + d.queued + " 个型号（" + (d.mode === "celery" ? "Celery" : "线程池") + "）");
        loadItems(); loadOverview();
      }).catch(function (e) { toast("投递失败：" + e.message, true); });
  }

  function selectedKeys() {
    var out = [];
    for (var k in state.selected) if (state.selected[k]) out.push(k);
    return out;
  }

  function updateSelCount() {
    var n = selectedKeys().length;
    var b = $("btnParseSelected");
    if (b) b.textContent = n ? ("解析选中 (" + n + ")") : "解析选中";
  }

  /* ---------------- 详情抽屉 ---------------- */
  function openDrawer(key) {
    state.current = key;
    $("drawerMask").className = "drawer-mask";
    $("drawer").className = "drawer";
    $("dTitle").textContent = "加载中…";
    if (("#item=" + key) !== location.hash) {
      try { history.replaceState(null, "", "#item=" + encodeURIComponent(key)); } catch (e) {}
    }
    api("/api/items/" + encodeURIComponent(key)).then(renderDrawer)
      .catch(function (e) { toast(e.message, true); });
  }

  function closeDrawer() {
    $("drawerMask").className = "drawer-mask hide";
    $("drawer").className = "drawer hide";
    state.current = null;
    try { history.replaceState(null, "", "#view=" + state.view); } catch (e) {}
    loadItems();
  }

  function renderDrawer(it) {
    var meta = it.meta || {};
    $("dTitle").textContent = it.mpn;
    $("dSub").textContent = (it.brand || meta.mfr || "—") + " · " + it.status_text +
      (meta.pkg ? " · " + meta.pkg : "");

    var altMode = ({
      board: meta.alts_onboard ? "评估板：板载 " + meta.alts_onboard : "评估板",
      grounded: "datasheet 同系列",
      "catalog-rank": "站内目录内排序",
      "catalog-miss": "站内目录未覆盖",
      "prefix-too-short": "前缀过短，跳过 AI",
      "ai-empty": "目录内无兼容项",
      "ai-error": "AI 失败，保留目录命中",
      off: "已关闭"
    })[meta.alts_mode] || "—";
    var stats = [
      ["采集来源", it.provider || "—"],
      ["PDF", fmtSize(it.pdf_bytes)],
      ["解析耗时", it.parse_ms ? (it.parse_ms / 1000).toFixed(1) + " s" : "—"],
      ["置信度", meta.confidence != null ? meta.confidence : "—"],
      ["段落", (meta.sections || []).length + " 段"],
      ["内链命中", (meta.alts_linked || 0) + "/" + (meta.alts_total || 0)],
      ["内链方式", altMode],
      ["配图 SEO", (meta.seo_images || 0) + " 张"],
      ["解析次数", it.parse_count || 0]
    ];
    var sh = "";
    for (var i = 0; i < stats.length; i++) {
      sh += '<div class="stat"><div class="stat-k">' + esc(stats[i][0]) +
        '</div><div class="stat-v">' + esc(stats[i][1]) + "</div></div>";
    }
    if (it.pdf_url) {
      sh += '<div class="stat" style="flex:1 1 100%"><div class="stat-k">Datasheet 链接</div>' +
        '<div class="stat-v"><a href="' + esc(it.pdf_url) + '" target="_blank">' +
        esc(it.pdf_url) + "</a></div></div>";
    }
    if (it.error) {
      sh += '<div class="stat" style="flex:1 1 100%"><div class="stat-k">降级/错误</div>' +
        '<div class="stat-v" style="color:#c02b2b">' + esc(it.error) + "</div></div>";
    }
    $("dStats").innerHTML = sh;

    var arts = (it.bundle && it.bundle.artifacts) || [];
    var ah = "";
    for (var j = 0; j < arts.length; j++) {
      var a = arts[j];
      ah += a.exists
        ? '<a class="art" href="' + esc(a.url) + '">' + esc(a.label) + " · " + fmtSize(a.size) + "</a>"
        : '<span class="art miss">' + esc(a.label) + " · 缺失</span>";
    }
    $("dArtifacts").innerHTML = ah;

    // 采集轨迹
    var src = it.sources || [];
    var th = '<div class="table-wrap"><table class="grid compact"><thead><tr>' +
      "<th>来源</th><th>阶段</th><th>链接</th><th>结果</th><th>时间</th></tr></thead><tbody>";
    for (var s = 0; s < src.length; s++) {
      var r = src[s];
      th += '<tr><td class="mono">' + esc(r.provider) + '</td><td class="mono">' + esc(r.stage) +
        '</td><td><a href="' + esc(r.url) + '" target="_blank" class="truncate">' + esc(r.url) +
        "</a></td><td>" + (r.ok ? '<span class="tag done">成功 ' + fmtSize(r.bytes) + "</span>"
          : '<span class="tag failed">' + esc(r.error || "失败") + "</span>") +
        '</td><td class="mono">' + esc(fmtTime(r.tried_at)) + "</td></tr>";
    }
    th += "</tbody></table></div>";
    $("dSources").innerHTML = th;

    setTab(state.tab || "txt");
  }

  function setTab(tab) {
    state.tab = tab;
    var tabs = document.querySelectorAll("#dTabs .tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].className = "tab" + (tabs[i].getAttribute("data-tab") === tab ? " active" : "");
    }
    if (tab === "sources") {
      $("dFrame").className = "preview hide";
      $("dSources").className = "";
      return;
    }
    $("dFrame").className = "preview";
    $("dSources").className = "hide";
    var url = "/api/items/" + encodeURIComponent(state.current) + "/preview/" + tab +
      "?t=" + new Date().getTime();
    $("dFrame").src = url;
  }

  /* ---------------- 型号审计（review）抽屉 ---------------- */
  var RV_BASE = "/api/qe/review/v1";
  var RV = { mpn: "", safe: "", has: false, running: false };

  function rvSafe(mpn) {
    return String(mpn || "").replace(/[^A-Za-z0-9._-]/g, "_").toUpperCase();
  }

  function rvSevTag(sev) {
    var cls = sev === "P0" ? "bad" : (sev === "P1" ? "warn" : "");
    return "<span class='pill " + cls + "'>" + esc(sev || "P2") + "</span>";
  }

  function rvFindingsTable(rows, title) {
    if (!rows || !rows.length) {
      return "<p class='note'>「" + esc(title) + "」无 finding。</p>";
    }
    var h = "<div class='table-wrap'><table class='grid compact'><thead><tr>" +
      "<th style='width:56px'>级别</th><th style='width:200px'>类型</th><th>问题</th>" +
      "<th style='width:36%'>证据</th></tr></thead><tbody>";
    for (var i = 0; i < rows.length; i++) {
      var f = rows[i];
      var ev = f.evidence || {};
      var quote = String(ev.quote || ev.sample || "").slice(0, 160);
      var field = String(ev.field || "");
      h += "<tr><td>" + rvSevTag(f.severity) + "</td>" +
        "<td class='mono'>" + esc(f.kind) + "</td>" +
        "<td>" + esc(f.message) + "</td>" +
        "<td class='sub'>" + esc(field ? field + " · " : "") + esc(quote) + "</td></tr>";
    }
    return h + "</tbody></table></div>";
  }

  function rvRender(res) {
    RV.has = !res.dry_run;                     // 规则层快查不落报告
    var usage = res.usage || {};
    $("rvTitle").textContent = res.mpn;
    $("rvSub").textContent = "review " + res.verdict + " · " + fmtTime(res.generated_at) +
      (res.cached ? " ·（缓存，点「运行审计」重算）" : "") +
      (res.dry_run ? " · 规则层（未调模型、不落报告）" : "");
    var vCls = res.verdict === "FAIL" ? "bad" : (res.verdict === "PASS" ? "ok" : "warn");
    $("rvKpis").innerHTML =
      kpi("结论", res.verdict, vCls,
          "FAIL=命中 P0；WARN=命中 P1/P2；PASS=无 finding") +
      kpi("规则层 findings", (res.rule_findings || []).length, "", "确定性检查，不花 token") +
      kpi("LLM findings", (res.llm_findings || []).length, "", "语义可疑点，不判数值正确性") +
      kpi("模型", res.model || "—", "",
          res.dry_run ? "未调用" :
            ((usage.total_tokens || "—") + " tokens · " + (res.wall_s || "—") + "s")) +
      kpi("批次", (res.item && res.item.batch_id) || "—", "",
          "item #" + ((res.item && res.item.id) || "—"));
    $("rvFindings").innerHTML =
      rvFindingsTable(res.rule_findings, "规则层") +
      rvFindingsTable(res.llm_findings, "LLM");
    $("rvFrame").src = res.dry_run ? "about:blank" :
      RV_BASE + "/reports/" + encodeURIComponent(res.safe_key) + "/report.html";
  }

  function rvRenderEmpty() {
    RV.has = false;
    $("rvKpis").innerHTML =
      kpi("结论", "未审计", "warn") +
      kpi("规则层", "—") +
      kpi("LLM", "—") +
      kpi("报告", "—", "", "完整审查后生成 json / md / html");
    $("rvFindings").innerHTML =
      "<p class='note'>该型号还没有审计报告。点「▶ 运行审计（LLM）」生成完整报告" +
      "（约 20~40s，覆盖旧报告）；「仅规则层」快速检查不调模型、不落报告。" +
      "审查只读产物，不改 facts / Gold；LLM 不判数值正确性（证据卡职责）。</p>";
    $("rvFrame").src = "about:blank";
  }

  function rvLoad() {
    api(RV_BASE + "/reports/" + encodeURIComponent(RV.safe)).then(rvRender)
      .catch(function () { rvRenderEmpty(); });
  }

  function openReviewDrawer(mpn) {
    RV.mpn = String(mpn || "");
    RV.safe = rvSafe(RV.mpn);
    $("rvDrawerMask").className = "drawer-mask";
    $("rvDrawer").className = "drawer";
    $("rvTitle").textContent = RV.mpn;
    $("rvSub").textContent = "规则先过、LLM 兜底；只读产物，不改 facts / Gold / 渲染";
    rvRenderEmpty();
    rvLoad();
  }

  function closeReviewDrawer() {
    $("rvDrawerMask").className = "drawer-mask hide";
    $("rvDrawer").className = "drawer hide";
    RV.mpn = "";
    RV.safe = "";
    RV.has = false;
  }

  function rvRun(withLlm) {
    if (!RV.mpn || RV.running) return;
    RV.running = true;
    var btn = withLlm ? $("rvRun") : $("rvRule");
    var old = btn.textContent;
    btn.textContent = withLlm ? "审计中…（LLM 20~40s）" : "规则层检查中…";
    api(RV_BASE + "/run", { method: "POST", body: {
      mpn: RV.mpn, dry_run: !withLlm, force: withLlm, with_pdf_text: false
    } }).then(function (res) {
      RV.running = false;
      btn.textContent = old;
      rvRender(res);
      toast("review " + res.verdict + "（规则 " + (res.rule_findings || []).length +
        " · LLM " + (res.llm_findings || []).length + "）" +
        (res.dry_run ? "；规则层不落报告" : ""));
    }).catch(function (e) {
      RV.running = false;
      btn.textContent = old;
      toast("review 失败：" + e.message, true);
    });
  }

  function rvOpenReport(ext) {
    if (!RV.mpn) return;
    if (!RV.has) { toast("先运行审计生成报告（仅规则层不落报告）", true); return; }
    window.open(RV_BASE + "/reports/" + encodeURIComponent(RV.safe) +
      "/report." + ext, "_blank");
  }

  /* ---------------- 事件绑定 ---------------- */
  function bind() {
    var navs = document.querySelectorAll(".nav-item");
    for (var i = 0; i < navs.length; i++) {
      navs[i].addEventListener("click", function () {
        switchView(this.getAttribute("data-view"));
      });
    }

    // 导航组展开/折叠
    var navHeads = document.querySelectorAll(".nav-group-head");
    for (var j = 0; j < navHeads.length; j++) {
      navHeads[j].addEventListener("click", function () {
        var grp = this.parentElement;
        if (grp.className.indexOf("collapsed") >= 0) {
          grp.className = "nav-group has-active";
        } else {
          grp.className = "nav-group collapsed";
        }
      });
    }

    // 模板下载链接在下拉区内部，阻止冒泡，否则会同时弹出文件选择框
    var tpl = $("tplLink");
    if (tpl) tpl.addEventListener("click", function (e) { e.stopPropagation(); });

    bindDrop("dropParts", "fileParts", "parts", "barParts", "statusParts");
    bindDrop("dropCatalog", "fileCatalog", "catalog", "barCatalog", "statusCatalog");
    bindDrop("dropImages", "fileImages", "images", "barImages", "statusImages");

    $("btnRefresh").addEventListener("click", function () { switchView(state.view); });
    if ($("btnUsage")) $("btnUsage").addEventListener("click", loadUsage);
    if ($("usageDays")) $("usageDays").addEventListener("change", loadUsage);

    var timer = null;
    $("searchInput").addEventListener("input", function () {
      var v = this.value;
      clearTimeout(timer);
      timer = setTimeout(function () { state.q = v; state.page = 1; loadItems(); }, 300);
    });
    $("statusFilter").addEventListener("change", function () {
      state.status = this.value; state.page = 1; loadItems();
    });
    $("batchFilter").addEventListener("change", function () {
      state.batchId = this.value; state.page = 1; loadItems();
    });

    $("btnPrev").addEventListener("click", function () { if (state.page > 1) { state.page--; loadItems(); } });
    $("btnNext").addEventListener("click", function () {
      if (state.page * state.size < state.total) { state.page++; loadItems(); }
    });

    $("checkAll").addEventListener("change", function () {
      var on = this.checked;
      var cks = document.querySelectorAll(".rowck");
      for (var i = 0; i < cks.length; i++) {
        cks[i].checked = on;
        if (on) state.selected[cks[i].getAttribute("data-key")] = true;
        else delete state.selected[cks[i].getAttribute("data-key")];
      }
      updateSelCount();
    });

    $("itemBody").addEventListener("click", function (e) {
      var t = e.target;
      if (t.className && t.className.indexOf("rowck") >= 0) {
        var k = t.getAttribute("data-key");
        if (t.checked) state.selected[k] = true; else delete state.selected[k];
        updateSelCount();
        return;
      }
      if (t.className && t.className.indexOf("act-review") >= 0) {
        openReviewDrawer(t.getAttribute("data-mpn"));
        return;
      }
      if (t.className && t.className.indexOf("act-open") >= 0) {
        openDrawer(t.getAttribute("data-key"));
        return;
      }
      var tr = t.parentNode;
      while (tr && tr.tagName !== "TR") tr = tr.parentNode;
      if (tr && tr.getAttribute("data-key")) openDrawer(tr.getAttribute("data-key"));
    });

    $("btnParseSelected").addEventListener("click", function () {
      var keys = selectedKeys();
      if (!keys.length) { toast("先在列表左侧勾选型号", true); return; }
      var force = confirm("已勾选 " + keys.length + " 个型号。\n\n" +
        "「确定」= 强制重跑（覆盖已有交付物）\n「取消」= 只处理未完成的");
      // 不强制时必须带 only=pending，否则已完成的型号会被投进去、再被判成「跳过」
      var body = force ? { mpn_keys: keys, force: true }
                       : { mpn_keys: keys, only: "pending" };
      api("/api/items/parse", { method: "POST", body: body })
        .then(function (d) {
          if (!d.queued) {
            toast(d.hint || d.message || "没有可解析的型号", true);
          } else {
            toast("已投递 " + d.queued + " 个（" + d.mode + (force ? "，强制重跑" : "") + "）");
          }
          loadItems(); loadOverview();
        })
        .catch(function (e) { toast(e.message, true); });
    });

    $("btnParseAll").addEventListener("click", function () {
      // 勾选了就按勾选走，否则按当前筛选（批次 / 搜索词 / 状态）
      var body = { only: "pending" };
      var keys = selectedKeys();
      if (keys.length) {
        body.mpn_keys = keys;
      } else if (state.batchId) {
        body.batch_id = Number(state.batchId);
      } else {
        body.filter = { q: state.q, status: state.status };
      }
      api("/api/items/parse", { method: "POST", body: body })
        .then(function (d) {
          if (!d.queued) {
            toast(d.hint || d.message || "没有未完成的型号", true);
          } else {
            toast("已投递 " + d.queued + " 个（" + d.mode + "）");
          }
          loadItems(); loadOverview();
        })
        .catch(function (e) { toast(e.message, true); });
    });

    $("btnCsv").addEventListener("click", function () {
      window.open("/api/items/export.csv?status=" + encodeURIComponent(state.status), "_blank");
    });

    $("batchBody").addEventListener("click", function (e) {
      var t = e.target;
      if (t.className && t.className.indexOf("act-bparse") >= 0) {
        startBatch(Number(t.getAttribute("data-id")), false);
      }
      if (t.className && t.className.indexOf("act-bexport") >= 0) {
        var id = t.getAttribute("data-id");
        t.disabled = true;
        t.textContent = "打包中…";
        api("/api/batches/" + id + "/export", { method: "POST" }).then(function () {
          waitExport(id, t);
        }).catch(function (e) { t.disabled = false; t.textContent = "打包导出"; toast(e.message, true); });
      }
    });

    $("btnPkgReport").addEventListener("click", function () {
      api("/api/pkgs/report").then(renderPkgReport)
        .catch(function (e) { toast("盘点失败：" + e.message, true); });
    });

    $("btnPkgBackfill").addEventListener("click", function () {
      var btn = this;
      btn.disabled = true;
      btn.textContent = "生成中…";
      api("/api/pkgs/backfill", { method: "POST" }).then(function (r) {
        var msg = "已补齐 " + r.generated.length + " 种封装";
        if (r.failed.length) msg += "，失败 " + r.failed.length + " 种";
        toast(msg, r.failed.length > 0);
        return api("/api/pkgs/report").then(renderPkgReport);
      }).catch(function (e) {
        toast("补齐失败：" + e.message, true);
      }).then(function () {
        btn.disabled = false;
        btn.textContent = "补齐缺失封装图";
      });
    });

    $("btnRebuildCatalog").addEventListener("click", function () {
      if (!confirm("用 uploads 里最新的站内目录导出表重建内链索引？约 1-2 分钟。")) return;
      this.disabled = true;
      api("/api/catalog/rebuild", { method: "POST" }).then(function () {
        toast("已开始重建内链索引");
        setTimeout(function () { loadData(); }, 5000);
      }).catch(function (e) { toast(e.message, true); })
        .then(function () { $("btnRebuildCatalog").disabled = false; });
    });

    $("dClose").addEventListener("click", closeDrawer);
    $("drawerMask").addEventListener("click", closeDrawer);

    $("rvClose").addEventListener("click", closeReviewDrawer);
    $("rvDrawerMask").addEventListener("click", closeReviewDrawer);
    $("rvRun").addEventListener("click", function () { rvRun(true); });
    $("rvRule").addEventListener("click", function () { rvRun(false); });
    $("rvMd").addEventListener("click", function () { rvOpenReport("md"); });
    $("rvWin").addEventListener("click", function () { rvOpenReport("html"); });

    $("dReparse").addEventListener("click", function () {
      if (!state.current) return;
      api("/api/items/" + encodeURIComponent(state.current) + "/parse",
        { method: "POST", body: { force: true } })
        .then(function () { toast("已重新投递解析"); setTimeout(function () { openDrawer(state.current); }, 1200); })
        .catch(function (e) { toast(e.message, true); });
    });

    $("dExport").addEventListener("click", function () {
      if (!state.current) return;
      api("/api/items/" + encodeURIComponent(state.current) + "/export", { method: "POST" })
        .then(function (d) { window.location.href = d.url; toast("已打包 " + d.mb + " MB"); })
        .catch(function (e) { toast(e.message, true); });
    });

    $("dManualGo").addEventListener("click", function () {
      var url = $("dManualUrl").value.trim();
      if (!state.current) return;
      if (!/^https?:\/\//i.test(url)) { toast("粘贴 http/https 直链", true); return; }
      api("/api/items/" + encodeURIComponent(state.current) + "/parse",
        { method: "POST", body: { force: true, manual_url: url } })
        .then(function () { toast("已投递补链解析"); })
        .catch(function (e) { toast(e.message, true); });
    });

    var tabs = document.querySelectorAll("#dTabs .tab");
    for (var k = 0; k < tabs.length; k++) {
      tabs[k].addEventListener("click", function () { setTab(this.getAttribute("data-tab")); });
    }

    /* ---- QC 交付历史 ---- */
    if ($("delivRefresh")) {
      $("delivRefresh").addEventListener("click", loadDeliveries);
    }
    if ($("delivRfBuild")) {
      $("delivRfBuild").addEventListener("click", function () {
        var btn = this;
        btn.disabled = true;
        api("/api/qe/review-fix/batches", {
          method: "POST", body: { size: 30, max_batches: 1 }
        }).then(function (r) {
          if (!r.built || !r.built.length) {
            toast(r.skipped_reason === "no_pending_reviewed"
              ? "没有待成批的已 review 型号"
              : "本次没有新增批次", false);
            return;
          }
          var b = r.built[0];
          toast("已追加批次 " + b.batch + "（" + b.mpns + " 型号 · " +
                (b.bytes / 1048576).toFixed(2) + " MB），剩余待成批 " +
                (r.remaining || 0) + " 件", false);
          loadDeliveries();
        }).catch(function (e) {
          toast("追加失败：" + e.message, true);
        }).then(function () { btn.disabled = false; });
      });
    }
    if ($("delivStatus")) {
      $("delivStatus").addEventListener("change", function () {
        delivFilter.status = this.value;
        delivPage.page = 1;
        renderDeliveries();
      });
    }
    if ($("delivQ")) {
      $("delivQ").addEventListener("input", function () {
        var v = this.value.trim();
        clearTimeout(delivFilter._t);
        delivFilter._t = setTimeout(function () {
          delivFilter.q = v;
          delivPage.page = 1;
          renderDeliveries();
        }, 200);
      });
    }
    if ($("delivPrev")) {
      $("delivPrev").addEventListener("click", function () {
        if (delivPage.page > 1) { delivPage.page--; renderDeliveries(); }
      });
    }
    if ($("delivNext")) {
      $("delivNext").addEventListener("click", function () {
        delivPage.page++;
        renderDeliveries();
      });
    }
    if ($("delivPageSel")) {
      $("delivPageSel").addEventListener("change", function () {
        delivPage.page = Number(this.value) || 1;
        renderDeliveries();
      });
    }
    if ($("delivBody")) {
      $("delivBody").addEventListener("click", function (ev) {
        var t = ev.target;
        if (!t || !t.getAttribute) return;
        var act = t.getAttribute("data-delivact");
        var id = t.getAttribute("data-id");
        if (!act || !id) return;
        var base = "/api/qe/deliveries/" + encodeURIComponent(id);
        if (act === "report") { window.open(base + "/report.html", "_blank"); return; }
        if (act === "md") { window.open(base + "/report.md", "_blank"); return; }
        if (act === "zip") { window.open(base + "/zip", "_blank"); return; }
        if (act === "manual") { openDelivManual(id); return; }
        if (act === "feedback") { openFeedbackForBatch(id); return; }
      });
    }

    /* ---- pandas QC Analyzer ---- */
    if ($("anRun")) $("anRun").addEventListener("click", anRunNow);
    if ($("anRefresh")) $("anRefresh").addEventListener("click", loadAnalyzer);
    var anTabs = document.querySelectorAll("#anTabs button");
    for (var at = 0; at < anTabs.length; at++) {
      anTabs[at].addEventListener("click", function () {
        AN.tab = this.getAttribute("data-tab");
        renderAnalyzer();
      });
    }

    /* ---- 客户反馈闭环 ---- */
    if ($("fbRefresh")) $("fbRefresh").addEventListener("click", loadFeedback);
    if ($("fbCreate")) $("fbCreate").addEventListener("click", openFeedbackCreate);
    if ($("fbExportBundle")) {
      $("fbExportBundle").addEventListener("click", function () {
        window.open(fbKey("/issues/export-bundle?" + fbQuery()), "_blank");
      });
    }
    if ($("fbExport")) {
      $("fbExport").addEventListener("click", function () {
        window.open(fbKey("/issues/export?" + fbQuery()), "_blank");
      });
    }
    ["fbStatus", "fbSeverity", "fbCategory"].forEach(function (id) {
      if ($(id)) {
        $(id).addEventListener("change", function () {
          fbState.status = $("fbStatus").value;
          fbState.severity = $("fbSeverity").value;
          fbState.category = $("fbCategory").value;
          loadFeedback();
        });
      }
    });
    ["fbBatch", "fbQ"].forEach(function (id) {
      if ($(id)) {
        $(id).addEventListener("input", function () {
          clearTimeout(fbState._t);
          fbState._t = setTimeout(function () {
            fbState.batch = fbVal("fbBatch");
            fbState.q = fbVal("fbQ");
            loadFeedback();
          }, 250);
        });
      }
    });
    if ($("fbBody")) {
      $("fbBody").addEventListener("click", function (ev) {
        var t = ev.target;
        if (!t || !t.getAttribute) return;
        var key = t.getAttribute("data-fbopen");
        if (key) openFeedbackIssue(key);
      });
    }

    /* ---- 质量审计 QC ---- */
    var qcTabs = document.querySelectorAll("#qcTabs .tab");
    for (var qi = 0; qi < qcTabs.length; qi++) {
      qcTabs[qi].addEventListener("click", function () {
        qcSetTab(this.getAttribute("data-qctab"));
      });
    }
    $("qcRunBtn").addEventListener("click", qcRunStart);
    $("qcRuns").addEventListener("click", function (ev) {
      var btn = ev.target && ev.target.getAttribute ? ev.target : null;
      if (!btn || !btn.getAttribute("data-qr2gold")) return;
      var runId = btn.getAttribute("data-qr2gold");
      btn.disabled = true; btn.textContent = "转换中…";
      api("/api/qe/gold/seed-from-run", { method: "POST", body: { run_id: Number(runId) } })
        .then(function (d) {
          toast("run#" + runId + " 已转核验：Gold 新建 " + d.gold_seeded + " / 已存 " +
            d.gold_existed + "，风险任务 +" + d.risk_added +
            "（去「Gold Set」与「风险」tab 处置）");
          loadQCOverview();
        }).catch(function (e) { toast("转核验失败：" + e.message, true); })
        .then(function () { btn.disabled = false; btn.textContent = "转核验"; });
    });
    var qcTimer = null;
    $("qcLogMpn").addEventListener("input", function () {
      var v = this.value;
      clearTimeout(qcTimer);
      qcTimer = setTimeout(function () {
        state.qcLogMpn = v; qcState.logPage = 1; loadQCLog();
      }, 300);
    });
    $("qcLogKind").addEventListener("change", function () {
      state.qcLogKind = this.value; qcState.logPage = 1; loadQCLog();
    });
    $("qcLogAct").addEventListener("change", function () {
      state.qcLogAct = this.value; qcState.logPage = 1; loadQCLog();
    });
    $("qcLogPrev").addEventListener("click", function () {
      if (qcState.logPage > 1) { qcState.logPage--; loadQCLog(); }
    });
    $("qcLogNext").addEventListener("click", function () {
      if (qcState.logPage * qcState.logSize < qcState.logTotal) {
        qcState.logPage++; loadQCLog();
      }
    });
    $("qcLogBody").addEventListener("click", function (e) {
      var tr = e.target;
      while (tr && tr.tagName !== "TR") tr = tr.parentNode;
      if (tr && tr.getAttribute("data-qcid")) openQCDrawer(Number(tr.getAttribute("data-qcid")));
    });
    $("qcLogExport").addEventListener("click", function () {
      var qs = [];
      if (state.qcLogMpn) qs.push("mpn=" + encodeURIComponent(state.qcLogMpn));
      if (state.qcLogKind) qs.push("kind=" + encodeURIComponent(state.qcLogKind));
      if (state.qcLogAct) qs.push("action=" + encodeURIComponent(state.qcLogAct));
      window.open("/api/qc/export.csv" + (qs.length ? "?" + qs.join("&") : ""), "_blank");
    });
    $("qcDClose").addEventListener("click", closeQCDrawer);
    $("qcDrawerMask").addEventListener("click", closeQCDrawer);
    /* diff 视图：三模式 / 基线 / 过滤 / 逐字段回滚 */
    var qcSegBtns = $("qcModeSeg").querySelectorAll("button");
    for (var si = 0; si < qcSegBtns.length; si++) {
      qcSegBtns[si].addEventListener("click", function () {
        var bs = $("qcModeSeg").querySelectorAll("button");
        for (var bi = 0; bi < bs.length; bi++) bs[bi].classList.remove("on");
        this.classList.add("on");
        qcDf.mode = this.getAttribute("data-m");
        renderQCDiff();
      });
    }
    $("qcBaseSel").addEventListener("change", function () {
      qcDf.base = this.value; qcDiffReload();
    });
    $("qcOnlyChg").addEventListener("change", function () {
      qcDf.only = this.checked; renderQCDiff();
    });
    $("qcQ").addEventListener("input", function () {
      qcDf.q = this.value; renderQCDiff();
    });
    $("qcDiffBody").addEventListener("click", function (e) {
      var t = e.target;
      var p = t.getAttribute && t.getAttribute("data-qcrv");
      if (p) qcTogRV(p);
    });
    $("qcRvAll").addEventListener("click", function () {
      var fs = qcDf.diff && qcDf.diff.fields || [];
      for (var i = 0; i < fs.length; i++)
        if (fs[i].op !== "same") qcDf.rv[fs[i].p] = 1;
      renderQCDiff();
    });
    $("qcKeepAll").addEventListener("click", function () {
      qcDf.rv = {}; renderQCDiff();
    });
    $("qcApplyRv").addEventListener("click", function () {
      var paths = Object.keys(qcDf.rv);
      if (!paths.length) { toast("未选择回滚字段", true); return; }
      if (!confirm("应用回滚 " + paths.length + " 字段？\n" +
                   "→ 备份当前 json（.pre_revert）→ 从 pre_audit 写回原值\n" +
                   "→ 仅投 render_item 重渲染（不重解 PDF）→ 台账追加 revert 记录")) return;
      api("/api/qc/audit-log/" + qcDf.id + "/revert", { method: "POST", body: { paths: paths, confirm: true } })
        .then(function (d) {
          toast("已回滚 " + d.reverted.length + " 字段" +
                (d.rendered ? "，已投递重渲染" : "（该型号不在库，未投渲染）"));
          qcDf.rv = {};
          qcDiffReload();
        }).catch(function (e) { toast("回滚失败：" + e.message, true); });
    });
    $("qcDExportDiff").addEventListener("click", function () {
      window.open("/api/qc/audit-log/" + qcDf.id + "/diff?baseline=" + qcDf.base, "_blank");
    });
    $("qcDPatch").addEventListener("click", function () {
      var mpn = this.getAttribute("data-mpn") || "";
      if (!mpn) return;
      if (!confirm("对 " + mpn + " 应用 write 补丁？\n" +
                   "将备份 .pre_audit.json → 写回补丁 → 落 facts 侧车 → 仅重渲染（不重解 PDF）。")) return;
      api("/api/qc/run", { method: "POST",
        body: { mode: "single", mpns: [mpn], write: true, confirm: true, scope: "facts,render" } })
        .then(function (d) { toast("已投递 write 补丁 run#" + d.run_id); closeQCDrawer(); qcSetTab("run"); })
        .catch(function (e) { toast("补丁投递失败：" + e.message, true); });
    });
    $("qcDRerender").addEventListener("click", function () {
      var mpn = this.getAttribute("data-mpn") || "";
      if (!mpn) return;
      api("/api/qc/rerender", { method: "POST", body: { mpns: [mpn] } })
        .then(function (d) { toast("已投递重渲染 " + d.queued + " 件（不重解 PDF）"); })
        .catch(function (e) { toast(e.message, true); });
    });
    $("qcLintLive").addEventListener("click", function () { loadQCLint(1); });
    $("qcLintBody").addEventListener("click", function (e) {
      var t = e.target;
      var kind = t.getAttribute && t.getAttribute("data-lintkind");
      if (!kind) return;
      if (kind === "i18n_missing") {
        toast("i18n 缺失需先跑翻译续跑（translate_i18n.py --scope full）再重渲染", true);
        return;
      }
      var groups = qcState.lintGroups || [], mpns = [];
      for (var i = 0; i < groups.length; i++) {
        if (groups[i].kind === kind) mpns = groups[i].mpns || [];
      }
      if (!mpns.length) { toast("该类暂无件清单", true); return; }
      t.disabled = true; t.textContent = "渲染中…";
      api("/api/qc/rerender", { method: "POST", body: { mpns: mpns } })
        .then(function (d) {
          toast("已投递重渲染 " + d.queued + " 件（不重解 PDF）");
          loadQCLint(0);
        }).catch(function (e) { toast(e.message, true); });
    });
    /* ---- QE：Gold Set / 风险队列 / 随机审计 / 引擎对比 / 反馈闭环 ---- */
    $("qeGoldSeedBtn").addEventListener("click", qeGoldSeed);
    $("qeGoldReload").addEventListener("click", loadGold);
    $("qeGoldQ").addEventListener("input", function () {
      clearTimeout(qcState.goldQTimer);
      qcState.goldQTimer = setTimeout(function () {
        state.qeGoldQ = $("qeGoldQ").value.trim(); loadGold();
      }, 300);
    });
    $("qeGoldStatus").addEventListener("change", function () {
      state.qeGoldStatus = this.value; loadGold();
    });
    $("qeGoldBody").addEventListener("click", function (e) {
      var t = e.target;
      var id = t.getAttribute && t.getAttribute("data-qegold");
      if (id) { openGoldDrawer(Number(id)); return; }
      var tr = t;
      while (tr && tr.tagName !== "TR") tr = tr.parentNode;
      if (tr && tr.getAttribute("data-qegold")) openGoldDrawer(Number(tr.getAttribute("data-qegold")));
    });
    $("qeEvNewBtn").addEventListener("click", qeEvNew);
    $("qeEvReload").addEventListener("click", loadEvidence);
    $("qeEvQ").addEventListener("input", function () {
      clearTimeout(qcState.evQTimer);
      qcState.evQTimer = setTimeout(function () {
        state.qeEvQ = $("qeEvQ").value.trim(); loadEvidence();
      }, 300);
    });
    $("qeEvStatus").addEventListener("change", function () {
      state.qeEvStatus = this.value; loadEvidence();
    });
    $("qeEvBody").addEventListener("click", function (e) {
      var t = e.target;
      var id = t.getAttribute && t.getAttribute("data-qeev");
      if (id) { openEvidenceDrawer(Number(id)); return; }
      var tr = t;
      while (tr && tr.tagName !== "TR") tr = tr.parentNode;
      if (tr && tr.getAttribute("data-qeev")) openEvidenceDrawer(Number(tr.getAttribute("data-qeev")));
    });
    $("qeRiskSync").addEventListener("click", function () {
      var btn = this;
      btn.disabled = true; btn.textContent = "同步中…";
      api("/api/qe/risk/sync", { method: "POST", body: {} })
        .then(function (d) {
          toast("风险队列同步：新增 " + d.added + "，跳过 " + d.skipped + "（扫描 " + d.scanned + "）");
          loadRisk();
        }).catch(function (e) { toast(e.message, true); })
        .then(function () {
          btn.disabled = false; btn.textContent = "↻ 从 QC findings 同步队列";
        });
    });
    $("qeRiskReload").addEventListener("click", loadRisk);
    $("qeRiskQ").addEventListener("input", function () {
      clearTimeout(qcState.riskQTimer);
      qcState.riskQTimer = setTimeout(function () {
        state.qeRiskQ = $("qeRiskQ").value.trim(); loadRisk();
      }, 300);
    });
    $("qeRiskPri").addEventListener("change", function () {
      state.qeRiskPri = this.value; loadRisk();
    });
    $("qeRiskBody").addEventListener("click", function (e) {
      var t = e.target;
      var id = t.getAttribute && t.getAttribute("data-qerisk");
      var act = t.getAttribute && t.getAttribute("data-act");
      if (id && act) qeRiskAction(Number(id), act);
    });
    $("qeSampleCreate").addEventListener("click", qeSampleCreate);
    $("qeSampleReload").addEventListener("click", loadSample);
    $("qeSampleBody").addEventListener("click", function (e) {
      var t = e.target;
      var id = t.getAttribute && t.getAttribute("data-qesample");
      if (id) openSampleDrawer(Number(id));
    });
    $("qeEngCompare").addEventListener("click", qeEngCompare);
    $("qeEngReload").addEventListener("click", loadEngines);
    $("qeFbAdd").addEventListener("click", qeFbAdd);
    $("qeFbReload").addEventListener("click", loadFb);
    $("qeFbQ").addEventListener("input", function () {
      clearTimeout(qcState.fbQTimer);
      qcState.fbQTimer = setTimeout(function () {
        state.qeFbQ = $("qeFbQ").value.trim(); loadFb();
      }, 300);
    });
    $("qeFbStatus").addEventListener("change", function () {
      state.qeFbStatus = this.value; loadFb();
    });
    $("qeFbBody").addEventListener("click", function (e) {
      var t = e.target;
      var id = t.getAttribute && t.getAttribute("data-qefb");
      var act = t.getAttribute && t.getAttribute("data-act");
      if (id && act) qeFbAction(Number(id), act);
    });
    $("qeDClose").addEventListener("click", closeQeDrawer);
    $("qeDrawerMask").addEventListener("click", closeQeDrawer);
    $("qeDBody").addEventListener("click", function (e) {
      var t = e.target;
      var fv = t.getAttribute && t.getAttribute("data-qefv");
      var fc = t.getAttribute && t.getAttribute("data-qefc");
      var da = t.getAttribute && t.getAttribute("data-qegoldact");
      var sv = t.getAttribute && t.getAttribute("data-qesv");
      var sr = t.getAttribute && t.getAttribute("data-r");
      var eva = t.getAttribute && t.getAttribute("data-qeevact");
      var evf = t.getAttribute && t.getAttribute("data-qeevf");
      if (fv) qeGoldFieldAction(Number(fv), "verified");
      else if (fc) qeGoldFieldAction(Number(fc), "conflict");
      else if (da) qeGoldDeviceAction(da);
      else if (eva) qeEvAct(eva);
      else if (evf) qeEvFieldVerify(Number(evf));
      else if (sv && sr) qeSampleReview(Number(sv), sr);
    });
  }

  function waitExport(batchId, btn) {
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      api("/api/batches/" + batchId + "/export").then(function (d) {
        if (d.ready) {
          clearInterval(timer);
          btn.disabled = false; btn.textContent = "打包导出";
          window.location.href = d.url;
          toast("已打包 " + d.mb + " MB");
        } else if (tries > 40) {
          clearInterval(timer);
          btn.disabled = false; btn.textContent = "打包导出";
          toast("打包耗时较长，稍后可在批次列表重试", true);
        }
      }).catch(function () { if (tries > 40) clearInterval(timer); });
    }, 3000);
  }

  /* ---------------- 轮询刷新（仅任务视图）---------------- */
  function autoRefresh() {
    if (state.view === "tasks" && !state.current) { loadOverview(); loadItems(); }
  }

  document.addEventListener("DOMContentLoaded", function () {
    bind();
    var v = /#view=([\w-]+)/.exec(location.hash || "");
    switchView(v ? v[1] : "tasks", true);
    loadSideInfo();
    var m = /#item=([^&]+)/.exec(location.hash || "");
    if (m) openDrawer(decodeURIComponent(m[1]));
    setInterval(autoRefresh, 6000);
  });
})();
