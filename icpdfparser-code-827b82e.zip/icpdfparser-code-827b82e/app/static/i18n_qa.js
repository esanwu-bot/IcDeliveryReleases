/* 多语言质量中心：8 个子页（总览 / 任务 / 审校 / LQA / 术语 / 记忆库 / 报告 / 策略）。
   独立 IIFE，不依赖 app.js 内部作用域；对外只暴露 window.I18NQA.show(view)。 */
(function () {
  "use strict";

  var VIEWS = ["overview", "jobs", "review", "lqa", "terms", "memory", "reports", "settings"];
  var LANG_ZH = { ja: "日语", ko: "韩语", de: "德语", es: "西班牙语" };
  var LANGS = ["ja", "ko", "de", "es"];
  var FIELD_ZH = { title: "标题", meta: "描述摘要", description: "正文",
                   features: "特性", applications: "应用" };

  var state = {
    view: "overview",
    cand: null,          // 当前展开的候选 id
    issue: null,         // 当前审校问题 id
    run: 0,              // 当前查看的 LQA run
    tmTab: "approved",
    termLang: "",
    lqaSev: "",
    reviewSev: "",
    jobsBatch: ""
  };
  var cache = {};

  /* ---------------------------------------------------------------- 工具 */
  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function api(path, opts) {
    opts = opts || {};
    var cfg = { method: opts.method || "GET", headers: {} };
    if (opts.body !== undefined) {
      cfg.headers["Content-Type"] = "application/json";
      cfg.body = JSON.stringify(opts.body);
    }
    return fetch(path, cfg).then(function (r) {
      if (r.status === 401) { location.reload(); throw new Error("未登录"); }
      return r.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = { detail: txt }; }
        if (!r.ok) {
          var msg = (data && (data.detail || data.message)) || ("HTTP " + r.status);
          throw new Error(typeof msg === "string" ? msg : JSON.stringify(msg));
        }
        return data;
      });
    });
  }

  function toast(msg, isErr) {
    var t = $("toast");
    if (!t) return;
    t.textContent = msg;
    t.className = "toast" + (isErr ? " err" : "");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.className = "toast hide"; }, 4200);
  }

  function fmtTime(s) {
    if (!s) return "—";
    return String(s).replace("T", " ").slice(0, 16);
  }

  function pct(a, b) { return b ? Math.round(1000 * a / b) / 10 : 0; }

  function sevPill(sev) {
    var cls = { FAIL: "red", WARN: "amber", REVIEW: "purple", PASS: "green" }[sev] || "gray";
    return '<span class="pill ' + cls + '">' + esc(sev || "—") + "</span>";
  }

  function statusPill(s) {
    var m = { approved: ["green", "已批准"], rejected: ["red", "已驳回"],
              pending: ["gray", "待审"], open: ["amber", "待裁决"],
              accepted: ["green", "已接受"], fixed: ["blue", "已修复"],
              ok: ["green", "正常"], fail: ["red", "失败"] };
    var v = m[s] || ["gray", s || "—"];
    return '<span class="pill ' + v[0] + '">' + esc(v[1]) + "</span>";
  }

  function bar(value, max, color) {
    var w = max ? Math.max(2, Math.round(100 * value / max)) : 0;
    return '<div class="bar"><i style="width:' + w + "%" +
      (color ? ";background:" + color : "") + '"></i></div>';
  }

  function empty(msg) { return '<div class="i18n-empty">' + esc(msg) + "</div>"; }

  function head(title, sub, actions) {
    return '<div class="i18n-head"><div><h2>' + esc(title) + "</h2><p>" + sub + "</p></div>" +
      '<div class="i18n-actions">' + (actions || "") + "</div></div>";
  }

  function stat(label, value, foot) {
    return '<div class="stat"><div class="stat-top"><span>' + esc(label) + "</span></div>" +
      "<strong>" + esc(value) + "</strong><div class=\"stat-foot\">" + (foot || "") + "</div></div>";
  }

  /* ---------------------------------------------------------------- 视图骨架 */
  function show(view) {
    if (VIEWS.indexOf(view) < 0) view = "overview";
    state.view = view;
    var root = $("i18n-" + view);
    if (!root) return;
    var group = $("navI18n");
    if (group && group.className.indexOf("collapsed") >= 0) {
      group.className = "nav-group has-active";
    }
    if (view === "overview") return loadOverview(root);
    if (view === "jobs") return loadJobs(root);
    if (view === "review") return loadReview(root);
    if (view === "lqa") return loadLqa(root);
    if (view === "terms") return loadTerms(root);
    if (view === "memory") return loadMemory(root);
    if (view === "reports") return loadReports(root);
    if (view === "settings") return loadSettings(root);
  }

  function fail(root, e) {
    root.innerHTML = '<div class="i18n-empty">加载失败：' + esc(e.message || e) + "</div>";
    toast(e.message || String(e), true);
  }

  function go(view) {
    if (window.switchViewTo) { window.switchViewTo("i18n-" + view); return; }
    location.hash = "#view=i18n-" + view;
  }

  /* ---------------------------------------------------------------- 总览 */
  function loadOverview(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([
      api("/api/i18n/overview"),
      api("/api/i18n/review/issues?status=open"),
      api("/api/i18n/batches")
    ]).then(function (r) {
      var o = r[0], issues = r[1].rows || [], batches = r[2].rows || [];
      var cand = o.candidates || {}, lqa = o.lqa || {}, tm = o.tm || {},
          iss = o.issues || {}, g = o.glossary || {}, b = o.banned || {};
      var b0 = batches.length ? batches[0] : null;
      var stageOk = [
        cand.total > 0, lqa.cells > 0, lqa.fail_cells === 0 && lqa.cells > 0,
        iss.total > 0, cand.approved > 0
      ];
      var pipes = [
        ["01 · SOURCE", "⌕", "源文分析", cand.total + " 个候选已绑定源版本"],
        ["02 · MT", "文", "机器翻译", cand.total * 20 + " 行字段快照"],
        ["03 · LQA", "◈", "规则门禁", lqa.fail_cells + " 格 FAIL / " + lqa.cells + " 格"],
        ["04 · AI QA", "✧", "语义审校", iss.open + " 条待裁决" +
          (iss.total > iss.open ? " · 累计 " + iss.total + " 条" : "")],
        ["05 · HUMAN", "✓", "人工批准", cand.approved + " 个候选已批准"]
      ];
      var pipeHtml = "";
      for (var i = 0; i < pipes.length; i++) {
        var cls = i === 2 && lqa.fail_cells > 0 ? "blocked" : (stageOk[i] ? "done" : (i === 3 ? "active" : ""));
        pipeHtml += '<div class="pipe ' + cls + '"><div class="n">' + pipes[i][0] + '</div>' +
          '<div class="pi">' + pipes[i][1] + "</div><strong>" + pipes[i][2] +
          "</strong><small>" + esc(pipes[i][3]) + "</small></div>";
      }
      var hi = issues.slice(0, 6).map(function (it) {
        return '<div class="issue"><span class="sev' + (it.severity === "P0" ? "" : " warn") +
          '"></span><div><strong>' + esc(it.mpn || "—") + " · " + esc(FIELD_ZH[it.field] || it.field) +
          '</strong><p><code>' + esc(it.lang) + "</code> · " + esc(it.rationale || it.category) +
          "</p></div>" + '<span class="pill ' + (it.severity === "P0" ? "red" : "amber") + '">' +
          esc(it.severity) + "</span></div>";
      }).join("") || empty("没有待裁决问题");

      var rules = (o.rules || []).map(function (rl) {
        return '<div class="rule"><div><strong>' + esc(rl.name) + "</strong><small>" +
          esc(rl.id) + " · " + esc(rl.desc) + "</small></div>" + sevPill(rl.severity) + "</div>";
      }).join("");

      var queue = [
        ["⚑", "待人工裁决", issues.length + " 条待裁决 · 累计 " + (iss.total || 0) + " 条登记", "review", "进入队列"],
        ["⌕", "术语库", g.approved + " / " + g.total + " 条已批准", "terms", "管理术语"],
        ["▤", "翻译记忆", tm.approved + " 条已批准句段 · 候选 " + (tm.total - tm.approved), "memory", "查看记忆库"],
        ["◈", "LQA 门禁", "通过率 " + lqa.pass_rate + "%", "lqa", "查看门禁"]
      ].map(function (q) {
        return '<div class="queue-row"><div class="queue-ico">' + q[0] + "</div><div><strong>" +
          esc(q[1]) + "</strong><small>" + esc(q[2]) + "</small>" +
          bar(q[1] === "待人工裁决" ? issues.length : (q[1] === "LQA 门禁" ? lqa.pass_rate : 60), 100) +
          '</div><button class="btn sm" data-act="go" data-view="' + q[3] + '">' + q[4] + "</button></div>";
      }).join("");

      root.innerHTML =
        head("多语言质量工作台",
          "从翻译生成、确定性门禁、AI 语义审校到人工批准与记忆沉淀，建立可追溯的半导体技术翻译闭环。" +
          (b0 ? ' 当前批次 <b>' + esc(b0.batch + " · " + b0.revision) + "</b>" : ""),
          '<button class="btn" data-act="go" data-view="jobs">批次与候选</button>' +
          '<button class="btn ghost" data-act="go" data-view="review">进入待审队列 →</button>') +
        '<div class="stats">' +
        stat("待人工裁决", String(iss.open || 0), iss.open
          ? (iss.p0_open ? '<span class="negative">' + iss.p0_open + " 条 P0</span>" : "无 P0") + " 需优先处理"
          : (iss.total ? "累计 " + iss.total + " 条已裁决" : "暂无登记问题")) +
        stat("LQA 通过率", (lqa.pass_rate || 0) + "%", "失败格 <span class='negative'>" + (lqa.fail_cells || 0) + "</span> / " + (lqa.cells || 0)) +
        stat("候选版本", String(cand.total || 0), "已批准 " + cand.approved + " · 门禁失败 " + cand.gate_failed) +
        stat("批准译文记忆", String(tm.approved || 0), "总句段 " + (tm.total || 0) + " · 只有人工批准才入库") +
        "</div>" +
        '<div class="grid-main"><div><div class="card"><div class="card-head"><h3>翻译质量流水线</h3>' +
        '<span class="hint">每一阶段独立状态，机器不越权</span></div><div class="card-body"><div class="pipeline">' +
        pipeHtml + "</div></div></div>" +
        '<div class="section-title"><h3>待处理</h3><span>点击直达</span></div>' +
        '<div class="card"><div class="card-body queue">' + queue + "</div></div></div>" +
        '<div><div class="card"><div class="card-head"><h3>高优先级问题</h3>' +
        '<button class="btn ghost sm" data-act="go" data-view="review">查看全部</button></div>' +
        '<div class="card-body issue-list">' + hi + "</div></div>" +
        '<div class="card" style="margin-top:16px"><div class="card-head"><h3>门禁规则</h3>' +
        '<span class="hint">确定性规则 · rule-set v1</span></div><div class="card-body">' + rules + "</div></div></div></div>";
    }).catch(function (e) { fail(root, e); });
  }

  /* ---------------------------------------------------------------- 翻译任务 */
  function loadJobs(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([api("/api/i18n/batches"), api("/api/i18n/candidates")]).then(function (r) {
      cache.batches = r[0].rows || [];
      cache.candidates = r[1].rows || [];
      renderJobs(root);
    }).catch(function (e) { fail(root, e); });
  }

  function renderJobs(root) {
    var bs = cache.batches || [], cs = cache.candidates || [];
    var tot = { n: 0, appr: 0, rej: 0, failed: 0 };
    cs.forEach(function (c) {
      tot.n++; if (c.status === "approved") tot.appr++;
      if (c.status === "rejected") tot.rej++;
      if (c.gate_verdict === "FAIL") tot.failed++;
    });
    var bRows = bs.map(function (b) {
      return "<tr><td><strong>" + esc(b.batch + " · " + b.revision) + "</strong>" +
        '<div class="muted code">' + esc(b.model || "—") + " · " + fmtTime(b.imported_at) + "</div></td>" +
        "<td>" + b.n + " 个器件 · 4 语种</td>" +
        "<td>" + (b.failed ? sevPill("FAIL") : sevPill("PASS")) +
        '<div class="muted">' + (b.failed ? b.failed + " 件阻断" : "全部通过") + "</div></td>" +
        "<td>" + b.approved + " / " + b.n + "</td>" +
        '<td><button class="btn sm" data-act="lqa-batch" data-batch="' + esc(b.batch) +
        '" data-rev="' + esc(b.revision) + '">重跑门禁</button> ' +
        '<button class="btn sm ghost" data-act="jobs-filter" data-batch="' + esc(b.batch) +
        '">筛选</button></td></tr>';
    }).join("") || '<tr><td colspan="5">' + empty("还没有导入任何候选批次") + "</td></tr>";

    var rows = cs.filter(function (c) { return !state.jobsBatch || c.batch === state.jobsBatch; })
      .map(function (c) {
        var detail = state.cand === c.id && cache.detail && cache.detail.id === c.id
          ? candidateDetail(cache.detail) : "";
        return "<tr><td><strong>" + esc(c.mpn || c.filename) + '</strong><div class="muted code">' +
          esc(c.filename) + " · sha " + esc(String(c.sha256 || "").slice(0, 8)) + "</div></td>" +
          "<td>" + esc(c.batch + " · " + c.revision) + "</td>" +
          "<td>" + (c.fields || 0) + "</td>" +
          "<td>" + (c.gate_verdict ? sevPill(c.gate_verdict) : '<span class="pill gray">未跑</span>') + "</td>" +
          "<td>" + statusPill(c.status) + "</td>" +
          '<td><button class="btn sm" data-act="cand-detail" data-id="' + c.id + '">字段</button> ' +
          '<button class="btn sm ghost" data-act="lqa-one" data-id="' + c.id + '">跑 LQA</button> ' +
          (c.status === "approved" ? "" :
            '<button class="btn sm" data-act="cand-approve" data-id="' + c.id + '">批准</button> ' +
            '<button class="btn sm warn" data-act="cand-reject" data-id="' + c.id + '">驳回</button>') +
          "</td></tr>" + detail;
      }).join("") || '<tr><td colspan="6">' + empty("没有候选") + "</td></tr>";

    root.innerHTML =
      head("翻译任务", "按批次跟踪源版本、模型、门禁与人工批准状态。候选与生产数据完全隔离，" +
        "批准只改变本地候选状态，不写回生产文件。",
        '<button class="btn" data-act="go" data-view="lqa">LQA 门禁</button>' +
        '<button class="btn ghost" data-act="reload">刷新</button>') +
      '<div class="stats">' +
      stat("候选总数", String(tot.n), bs.length + " 个批次 / 版本") +
      stat("门禁失败", String(tot.failed), tot.failed ? '<span class="negative">已阻止批准</span>' : "全部通过") +
      stat("已批准", String(tot.appr), "人工批准后才可进记忆库") +
      stat("已驳回", String(tot.rej), "保留历史，不覆盖") +
      "</div>" +
      '<div class="card"><div class="card-head"><h3>批次列表</h3>' +
      '<span class="hint">判定以最严格的未解决问题为准</span></div><div class="table-wrap">' +
      '<table class="grid"><thead><tr><th>批次 / 版本</th><th>范围</th><th>LQA</th><th>已批准</th><th>操作</th></tr></thead>' +
      "<tbody>" + bRows + "</tbody></table></div></div>" +
      '<div class="card"><div class="card-head"><h3>候选明细</h3>' +
      '<div class="tools">' + (state.jobsBatch ?
        '<button class="btn ghost sm" data-act="jobs-filter" data-batch="">显示全部批次</button>' : "") +
      "</div></div><div class=\"table-wrap\"><table class=\"grid\"><thead><tr>" +
      "<th>型号 / 文件</th><th>批次</th><th>字段数</th><th>门禁</th><th>状态</th><th>操作</th>" +
      "</tr></thead><tbody>" + rows + "</tbody></table></div></div>";
  }

  function candidateDetail(c) {
    var f = c.fields || [];
    var cells = f.map(function (x) {
      return "<tr><td>" + esc(x.lang) + "</td><td>" + esc(FIELD_ZH[x.field] || x.field) +
        (x.idx >= 0 ? "[" + x.idx + "]" : "") + "</td>" +
        '<td class="muted">' + esc(String(x.en || "").slice(0, 90)) + "</td>" +
        "<td>" + esc(String(x.target || "").slice(0, 90)) + "</td>" +
        "<td>" + (x.changed ? '<span class="pill blue">改</span>' : "") + "</td></tr>";
    }).join("");
    return '<tr><td colspan="6" style="background:#fbfcfe"><div style="padding:10px 6px">' +
      '<div class="section-title"><h3>候选字段快照</h3><span>' + esc(c.filename) + " · " +
      (c.fields ? c.fields.length : 0) + " 行</span></div>" +
      '<div class="table-wrap" style="max-height:340px;overflow:auto"><table class="grid"><thead><tr>' +
      "<th style='width:52px'>语种</th><th style='width:110px'>字段</th><th>英文源</th><th>译文</th>" +
      '<th style="width:44px">变更</th></tr></thead><tbody>' + cells + "</tbody></table></div></div></td></tr>";
  }

  /* ---------------------------------------------------------------- AI 审校 */
  function loadReview(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([
      api("/api/i18n/review/issues" + (state.reviewSev ? "?severity=" + state.reviewSev : "")),
      api("/api/i18n/candidates"),
      api("/api/i18n/settings")
    ]).then(function (r) {
      cache.issues = r[0].rows || [];
      cache.candidates = r[1].rows || [];
      cache.settings = r[2];
      renderReview(root);
    }).catch(function (e) { fail(root, e); });
  }

  function renderReview(root) {
    var issues = cache.issues || [];
    var cur = null;
    for (var i = 0; i < issues.length; i++) if (issues[i].id === state.issue) cur = issues[i];
    if (!cur && issues.length) cur = issues[0];

    var rows = issues.map(function (it) {
      var cls = it.severity === "P0" ? "red" : (it.severity === "P1" ? "amber" : "gray");
      return '<tr style="cursor:pointer' + (cur && cur.id === it.id ? ";background:#f2f6ff" : "") +
        '" data-act="issue-pick" data-id="' + it.id + '">' +
        '<td><span class="pill ' + cls + '">' + esc(it.severity) + "</span></td>" +
        "<td><strong>" + esc(it.mpn) + '</strong><div class="muted">' + esc(LANG_ZH[it.lang] || it.lang) +
        "</div></td><td>" + esc(FIELD_ZH[it.field] || it.field) +
        (it.idx >= 0 ? "[" + it.idx + "]" : "") + '<div class="muted">' +
        esc(String(it.rationale || "").slice(0, 56)) + "</div></td>" +
        "<td>" + statusPill(it.verdict) + "</td></tr>";
    }).join("") || '<tr><td colspan="4">' + empty("没有待审校问题（可先运行 AI 审校或登记人工问题）") + "</td></tr>";

    var detail = cur ?
      '<div class="card"><div class="card-head"><h3>问题详情与裁决</h3>' + statusPill(cur.verdict) + "</div>" +
      '<div class="card-body"><div class="ev-grid">' +
      '<div class="ev-box"><div class="k">EN 源文</div><div class="v">' + esc(cur.src_ev || "—") + "</div></div>" +
      '<div class="ev-box bad"><div class="k">' + esc((LANG_ZH[cur.lang] || cur.lang) + " 译文") +
      '</div><div class="v">' + esc(cur.tgt_ev || "—") + "</div></div>" +
      '<div class="ev-box"><div class="k">判定理由</div><div class="v">' + esc(cur.rationale || "—") + "</div></div>" +
      "</div>" +
      '<div class="field-label">MRC · ' + esc(cur.category) + " · " + esc(cur.severity) + "</div>" +
      '<div class="footer-note">AI 审校只提出问题，不修改候选、不写入记忆库。裁决记录会进审计台账。</div>' +
      '<div class="i18n-actions" style="justify-content:flex-start;margin-top:12px">' +
      '<button class="btn" data-act="issue-decide" data-id="' + cur.id + '" data-verdict="accepted">接受（确认缺陷）</button>' +
      '<button class="btn ghost" data-act="issue-decide" data-id="' + cur.id + '" data-verdict="rejected">驳回（误报）</button>' +
      '<button class="btn ghost" data-act="issue-decide" data-id="' + cur.id + '" data-verdict="fixed">已修复</button>' +
      "</div></div></div>" : '<div class="card"><div class="card-body">' + empty("选择左侧问题查看证据") + "</div></div>";

    var candOpts = (cache.candidates || []).map(function (c) {
      return '<option value="' + c.id + '">' + esc(c.mpn + " · " + c.batch + "/" + c.revision) + "</option>";
    }).join("");
    var st = cache.settings || {};
    var runCard = '<div class="card"><div class="card-head"><h3>运行 AI 语义审校</h3>' +
      (st.key_present ? '<span class="pill green">密钥已配置 ' + esc(st.key_masked) + "</span>" :
        '<span class="pill red">未配置密钥</span>') + "</div>" +
      '<div class="card-body"><div class="form-grid">' +
      '<div class="full"><label>候选</label><select class="input" id="rvCand">' +
      (candOpts || '<option value="">无候选</option>') + "</select></div>" +
      '<div class="full"><label>审校模型</label><input class="input" id="rvModel" value="' +
      esc(st.review_model || "qwen-plus") + '"></div></div>' +
      '<div class="footer-note" style="margin-top:10px">审校与翻译使用不同模型，避免"自己生成、自己打分、自己批准"。' +
      "运行结果只进问题队列。</div>" +
      '<div class="i18n-actions" style="justify-content:flex-start;margin-top:10px">' +
      '<button class="btn" data-act="review-run">▶ 运行审校</button>' +
      '<button class="btn ghost" data-act="reload-review">刷新问题</button></div></div></div>';

    root.innerHTML =
      head("AI 语义审校", "AI 提供可定位的问题证据，人工负责裁决。审校结果不会自动修改候选文件或写入正式记忆库。",
        '<button class="btn ghost" data-act="reload-review">刷新</button>') +
      '<div class="review-layout"><div class="card"><div class="card-head"><h3>问题队列</h3>' +
      '<div class="tabs">' +
      ['', "P0", "P1", "P2"].map(function (s) {
        return '<button class="tab' + (state.reviewSev === s ? " active" : "") +
          '" data-act="review-sev" data-sev="' + s + '">' + (s || "全部") + "</button>";
      }).join("") + "</div></div>" +
      '<div class="table-wrap"><table class="grid"><thead><tr><th style="width:62px">严重度</th>' +
      "<th>器件 / 语言</th><th>问题</th><th style=\"width:92px\">状态</th></tr></thead><tbody>" +
      rows + "</tbody></table></div></div>" +
      "<div>" + detail + runCard + "</div></div>";
  }

  /* ---------------------------------------------------------------- LQA */
  function loadLqa(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([
      api("/api/i18n/rules"),
      api("/api/i18n/lqa/runs?limit=20"),
      api("/api/i18n/lqa/findings?limit=400" + (state.lqaSev ? "&severity=" + state.lqaSev : "")),
      api("/api/i18n/batches")
    ]).then(function (r) {
      cache.rules = r[0].rules || [];
      cache.runs = r[1].rows || [];
      cache.findings = r[2].rows || [];
      cache.batches = r[3].rows || [];
      renderLqa(root);
    }).catch(function (e) { fail(root, e); });
  }

  function renderLqa(root) {
    var rules = cache.rules || [], runs = cache.runs || [], fs = cache.findings || [];
    var fail = fs.filter(function (f) { return f.severity === "FAIL"; }).length;
    var warn = fs.filter(function (f) { return f.severity === "WARN"; }).length;
    var ruleRows = rules.map(function (r) {
      return '<div class="rule"><div><strong>' + esc(r.id + " · " + r.name) + "</strong><small>" +
        esc(r.desc) + "</small></div>" + sevPill(r.severity) + "</div>";
    }).join("");

    var runRows = runs.map(function (x) {
      var v = x.fail_n ? "FAIL" : (x.warn_n ? "WARN" : "PASS");
      return "<tr><td><strong>" + esc(x.mpn || ("#" + x.candidate_id)) + '</strong><div class="muted code">' +
        esc((x.batch || "") + "/" + (x.revision || "")) + "</div></td>" +
        "<td>" + x.total + " 格</td><td>" + x.pass_n + "</td><td>" + x.warn_n + "</td>" +
        "<td>" + (x.fail_n ? '<span class="i18n-sev-fail">' + x.fail_n + "</span>" : "0") + "</td>" +
        "<td>" + sevPill(v) + "</td>" +
        '<td class="muted">' + fmtTime(x.created_at) + "</td>" +
        '<td><button class="btn sm ghost" data-act="lqa-run-pick" data-run="' + x.id + '">明细</button></td></tr>';
    }).join("") || '<tr><td colspan="7">' + empty("还没有 LQA 运行记录") + "</td></tr>";

    var shown = state.run ? fs.filter(function (f) { return f.run_id === state.run; }) : fs;
    var fRows = shown.slice(0, 200).map(function (f) {
      return "<tr><td>" + sevPill(f.severity) + "</td><td><strong>" + esc(f.mpn) + "</strong></td>" +
        "<td>" + esc(LANG_ZH[f.lang] || f.lang) + "</td>" +
        "<td>" + esc(FIELD_ZH[f.field] || f.field) + (f.idx >= 0 ? "[" + f.idx + "]" : "") + "</td>" +
        "<td><code>" + esc(f.rule) + "</code></td>" +
        '<td class="muted">' + esc(String(f.tgt_ev || "").slice(0, 64)) + "</td>" +
        "<td>" + esc(f.detail) + "</td></tr>";
    }).join("") || '<tr><td colspan="7">' + empty("该范围内没有发现项") + "</td></tr>";

    var bOpts = (cache.batches || []).map(function (b) {
      return '<option value="' + esc(b.batch) + "|" + esc(b.revision) + '">' +
        esc(b.batch + " · " + b.revision + "（" + b.n + " 件）") + "</option>";
    }).join("");

    root.innerHTML =
      head("LQA 质量门禁", "确定性规则独立于翻译与 AI 审校运行：同一输入必然同一输出。硬错误阻止批准，" +
        "所有判定保留规则编号与证据。",
        '<button class="btn ghost" data-act="lqa-reload">刷新</button>') +
      '<div class="stats">' +
      stat("启用规则", String(rules.length), "覆盖 6 个质量维度") +
      stat("硬门禁失败", String(fail), fail ? '<span class="negative">失败即阻断批准</span>' : "无阻断") +
      stat("警告待复核", String(warn), "不允许静默忽略") +
      stat("运行次数", String(runs.length), "最近 " + fmtTime(runs[0] && runs[0].created_at)) +
      "</div>" +
      '<div class="two-col"><div class="card"><div class="card-head"><h3>规则清单</h3>' +
      '<span class="pill blue">rule-set v1</span></div><div class="card-body">' + ruleRows + "</div></div>" +
      '<div class="card"><div class="card-head"><h3>批量运行</h3></div><div class="card-body">' +
      '<div class="form-grid"><div class="full"><label>批次</label><select class="input" id="lqaBatch">' +
      (bOpts || '<option value="">无批次</option>') + "</select></div></div>" +
      '<div class="footer-note" style="margin-top:10px">门禁只读写候选快照，不碰生产 parsed/*.json。' +
      "结构 PASS 不等于语义 PASS：AI 审校与人工裁决是独立阶段。</div>" +
      '<div class="i18n-actions" style="justify-content:flex-start;margin-top:10px">' +
      '<button class="btn" data-act="lqa-batch-run">▶ 运行选中批次</button></div></div></div></div>' +
      '<div class="card"><div class="card-head"><h3>最近运行</h3><span class="hint">按时间倒序</span></div>' +
      '<div class="table-wrap"><table class="grid"><thead><tr><th>候选</th><th>格数</th><th>PASS</th>' +
      "<th>WARN</th><th>FAIL</th><th>判定</th><th>时间</th><th></th></tr></thead><tbody>" +
      runRows + "</tbody></table></div></div>" +
      '<div class="card"><div class="card-head"><h3>发现项</h3><div class="tabs">' +
      ["", "FAIL", "WARN", "PASS"].map(function (s) {
        return '<button class="tab' + (state.lqaSev === s ? " active" : "") +
          '" data-act="lqa-sev" data-sev="' + s + '">' + (s || "全部") + "</button>";
      }).join("") + "</div></div>" +
      '<div class="table-wrap"><table class="grid"><thead><tr><th style="width:70px">级别</th><th>型号</th>' +
      "<th style='width:64px'>语种</th><th style='width:110px'>字段</th><th style='width:74px'>规则</th>" +
      "<th>译文片段</th><th>判定说明</th></tr></thead><tbody>" + fRows + "</tbody></table></div></div>";
  }

  /* ---------------------------------------------------------------- 术语库 */
  function loadTerms(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([api("/api/i18n/glossary"), api("/api/i18n/banned")]).then(function (r) {
      cache.glossary = r[0].rows || [];
      cache.banned = r[1].rows || [];
      renderTerms(root);
    }).catch(function (e) { fail(root, e); });
  }

  function renderTerms(root) {
    var gs = (cache.glossary || []).filter(function (g) {
      if (state.termLang && !g[state.termLang]) return false;
      return true;
    });
    var totals = { g: (cache.glossary || []).length,
                   a: (cache.glossary || []).filter(function (x) { return x.status === "approved"; }).length };
    var rows = gs.map(function (g) {
      var banned = g.banned_obj || {};
      var bl = [];
      LANGS.forEach(function (l) {
        (banned[l] || []).forEach(function (p) { bl.push('<span class="pill red">' + esc(l) + " " + esc(p) + "</span>"); });
      });
      return "<tr><td><strong>" + esc(g.term_en) + '</strong><div class="muted">' +
        esc(g.domain || "general") + '</div><div class="muted code">' + esc(g.origin || "") + "</div></td>" +
        "<td>" + esc(g.ja || "—") + "</td><td>" + esc(g.ko || "—") + "</td><td>" +
        esc(g.de || "—") + "</td><td>" + esc(g.es || "—") + "</td>" +
        "<td>" + (bl.join(" ") || '<span class="muted">—</span>') + "</td>" +
        "<td>" + statusPill(g.status === "approved" ? "approved" : (g.status === "retired" ? "rejected" : "pending")) +
        "</td><td>" +
        (g.status !== "approved" ? '<button class="btn sm" data-act="term-status" data-id="' + g.id +
          '" data-status="approved">批准</button> ' : "") +
        (g.status !== "retired" ? '<button class="btn sm ghost" data-act="term-status" data-id="' + g.id +
          '" data-status="retired">停用</button>' : "") + "</td></tr>";
    }).join("") || '<tr><td colspan="8">' + empty("还没有术语条目") + "</td></tr>";

    var bRows = (cache.banned || []).map(function (b) {
      return "<tr><td>" + esc(LANG_ZH[b.lang] || b.lang) + "</td><td><code>" + esc(b.pattern) + "</code></td>" +
        "<td>" + esc(b.kind) + "</td><td>" + sevPill(b.severity) + "</td>" +
        '<td class="muted">' + esc(b.note || "") + "</td>" +
        "<td>" + (b.active ? '<span class="pill green">启用</span>' : '<span class="pill gray">停用</span>') +
        '</td><td><button class="btn sm ghost" data-act="banned-toggle" data-id="' + b.id +
        '" data-active="' + (b.active ? 0 : 1) + '">' + (b.active ? "停用" : "启用") + "</button></td></tr>";
    }).join("") || '<tr><td colspan="7">' + empty("没有禁用词") + "</td></tr>";

    root.innerHTML =
      head("半导体术语库", "按术语、领域、语种管理批准译法与禁用变体。禁用变体直接进 LQA 硬门禁；" +
        "仅人工确认的译法才可用于校验。",
        '<button class="btn ghost" data-act="term-form-toggle">＋ 新增术语</button>' +
        '<button class="btn ghost" data-act="reload-terms">刷新</button>') +
      '<div class="stats">' +
      stat("术语总数", String(totals.g), "半导体器件领域") +
      stat("已批准", String(totals.a), "可用于门禁校验") +
      stat("禁用译法", String((cache.banned || []).length), "命中即 FAIL / WARN") +
      stat("语言覆盖", "4", "ja · ko · de · es") +
      "</div>" +
      '<div class="card hide" id="termForm"><div class="card-head"><h3>新增术语</h3>' +
      '<span class="hint">批准译法多种写法用 | 分隔；留空表示该语种不校验</span></div>' +
      '<div class="card-body"><div class="form-grid">' +
      '<div><label>英文术语</label><input class="input" id="tTerm" placeholder="quadrature encoder"></div>' +
      '<div><label>领域</label><select class="input" id="tDomain">' +
      ["general", "logic", "power", "battery", "encoder", "protection", "package", "interface"]
        .map(function (d) { return "<option>" + d + "</option>"; }).join("") + "</select></div>" +
      '<div><label>日语批准译法</label><input class="input" id="tJa"></div>' +
      '<div><label>韩语批准译法</label><input class="input" id="tKo"></div>' +
      '<div><label>德语批准译法</label><input class="input" id="tDe"></div>' +
      '<div><label>西班牙语批准译法</label><input class="input" id="tEs"></div>' +
      '<div class="full"><label>禁用变体（JSON，如 {"ja":["準位エンコーダ"]}）</label>' +
      '<textarea id="tBanned" placeholder=\'{"ja":["..."],"ko":["..."]}\'></textarea></div>' +
      '<div class="full"><label>备注</label><input class="input" id="tNote"></div></div>' +
      '<div class="i18n-actions" style="justify-content:flex-start;margin-top:10px">' +
      '<button class="btn" data-act="term-save">保存为已批准</button>' +
      '<button class="btn ghost" data-act="term-form-toggle">取消</button></div></div></div>' +
      '<div class="card"><div class="card-head"><h3>术语条目</h3><div class="tabs">' +
      ["", "ja", "ko", "de", "es"].map(function (l) {
        return '<button class="tab' + (state.termLang === l ? " active" : "") +
          '" data-act="term-lang" data-lang="' + l + '">' + (l ? LANG_ZH[l] : "全部") + "</button>";
      }).join("") + "</div></div>" +
      '<div class="table-wrap"><table class="grid"><thead><tr><th>英文术语</th><th>ja</th><th>ko</th>' +
      "<th>de</th><th>es</th><th>禁用变体</th><th>状态</th><th>操作</th></tr></thead><tbody>" +
      rows + "</tbody></table></div></div>" +
      '<div class="card"><div class="card-head"><h3>全局禁用词</h3>' +
      '<span class="hint">与术语禁用变体叠加执行；命中按登记级别判 FAIL/WARN</span></div>' +
      '<div class="table-wrap"><table class="grid"><thead><tr><th style="width:78px">语种</th><th>模式</th>' +
      "<th style='width:78px'>类型</th><th style='width:74px'>级别</th><th>说明</th><th style='width:70px'>状态</th>" +
      "<th style='width:74px'>操作</th></tr></thead><tbody>" + bRows + "</tbody></table></div></div>";
  }

  /* ---------------------------------------------------------------- 记忆库 */
  function loadMemory(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    Promise.all([api("/api/i18n/tm?status=" + state.tmTab), api("/api/i18n/candidates")])
      .then(function (r) {
        cache.tm = r[0];
        cache.candidates = r[1].rows || [];
        renderMemory(root);
      }).catch(function (e) { fail(root, e); });
  }

  function renderMemory(root) {
    var rows = (cache.tm.rows || []).map(function (t) {
      return "<tr><td>" + esc(t.mpn || "—") + "</td><td>" + esc(LANG_ZH[t.lang] || t.lang) + "</td>" +
        "<td>" + esc(FIELD_ZH[t.field] || t.field) + (t.idx >= 0 ? "[" + t.idx + "]" : "") + "</td>" +
        '<td class="muted">' + esc(String(t.source_text || "").slice(0, 76)) + "</td>" +
        "<td>" + esc(String(t.target_text || "").slice(0, 76)) + "</td>" +
        "<td>" + statusPill(t.status === "approved" ? "approved" : "pending") + "</td>" +
        '<td class="muted">' + esc(t.approved_by || "—") + "<br>" + fmtTime(t.approved_at) + "</td>" +
        "<td>" + (t.status === "approved" ? "" :
          '<button class="btn sm" data-act="tm-approve" data-id="' + t.id + '">批准</button>') + "</td></tr>";
    }).join("") || '<tr><td colspan="8">' + empty("暂无记录") + "</td></tr>";

    var candOpts = (cache.candidates || []).map(function (c) {
      return '<option value="' + c.id + '">' + esc(c.mpn + " · " + c.batch + "/" + c.revision +
        " · " + c.status) + "</option>";
    }).join("");

    root.innerHTML =
      head("批准译文记忆库", "只保存人工批准的源文—译文对应关系。机器译文与待审内容永远留在候选区，" +
        "不得直接参与强制复用。",
        '<button class="btn ghost" data-act="reload-memory">刷新</button>') +
      '<div class="stats">' +
      stat("已批准句段", String(cache.tm.approved || 0), "仅人工批准内容") +
      stat("候选区句段", String((cache.tm.total || 0) - (cache.tm.approved || 0)), "不得强制复用") +
      stat("总句段", String(cache.tm.total || 0), "按 lang+源文哈希唯一") +
      stat("入库方式", "人工", "批准候选后按语种沉淀") +
      "</div>" +
      '<div class="card"><div class="card-head"><h3>沉淀候选到记忆库</h3>' +
      '<span class="hint">只有候选已批准，写入的句段才是 approved</span></div><div class="card-body">' +
      '<div class="form-grid"><div><label>候选</label><select class="input" id="tmCand">' +
      (candOpts || '<option value="">无候选</option>') + "</select></div>" +
      '<div><label>语种</label><select class="input" id="tmLang">' +
      LANGS.map(function (l) { return "<option value='" + l + "'>" + LANG_ZH[l] + "</option>"; }).join("") +
      '</select></div></div><div class="i18n-actions" style="justify-content:flex-start;margin-top:10px">' +
      '<button class="btn" data-act="tm-promote">沉淀该语种</button></div></div></div>' +
      '<div class="card"><div class="card-head"><h3>译文记录</h3><div class="tabs">' +
      '<button class="tab' + (state.tmTab === "approved" ? " active" : "") +
      '" data-act="tm-tab" data-tab="approved">已批准</button>' +
      '<button class="tab' + (state.tmTab === "candidate" ? " active" : "") +
      '" data-act="tm-tab" data-tab="candidate">候选区</button></div></div>' +
      '<div class="table-wrap"><table class="grid"><thead><tr><th>型号</th><th style="width:64px">语种</th>' +
      "<th style='width:110px'>字段</th><th>英文源</th><th>译文</th><th style='width:80px'>状态</th>" +
      "<th style='width:120px'>批准人 / 时间</th><th style='width:72px'>操作</th></tr></thead><tbody>" +
      rows + "</tbody></table></div></div>";
  }

  /* ---------------------------------------------------------------- 报告 */
  function loadReports(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    api("/api/i18n/report").then(function (d) {
      var byLang = d.by_lang || [], byRule = d.by_rule || [], byCat = d.by_category || [],
          trend = d.trend || [], verdicts = d.verdicts || [];
      var maxL = Math.max.apply(null, byLang.map(function (x) { return x.n; }).concat([1]));
      var maxR = Math.max.apply(null, byRule.map(function (x) { return x.n; }).concat([1]));
      var colors = { de: "#d58d34", ko: "#8b72d6", ja: "#4c83dd", es: "#26a17b" };
      var langHtml = byLang.map(function (x) {
        return '<div><div style="display:flex;justify-content:space-between;font-size:12px">' +
          "<span>" + esc(LANG_ZH[x.lang] || x.lang) + " " + esc(x.lang) + "</span><strong>" +
          x.n + " 条（FAIL " + (x.f || 0) + "）</strong></div>" + bar(x.n, maxL, colors[x.lang]) + "</div>";
      }).join("") || empty("暂无 LQA 发现项");
      var ruleHtml = byRule.map(function (x) {
        return '<div><div style="display:flex;justify-content:space-between;font-size:12px">' +
          "<span><code>" + esc(x.rule) + "</code></span><strong>" + x.n +
          " 条</strong></div>" + bar(x.n, maxR) + "</div>";
      }).join("") || empty("暂无规则命中");
      var catTotal = byCat.reduce(function (a, x) { return a + x.n; }, 0) || 1;
      var catHtml = byCat.map(function (x) {
        return '<div class="issue"><span class="sev info"></span><div><strong>' +
          esc(x.category) + "</strong><p>" + x.n + " 条</p></div><strong>" +
          Math.round(100 * x.n / catTotal) + "%</strong></div>";
      }).join("") || empty("暂无审校问题");
      var vHtml = verdicts.map(function (v) {
        return '<div class="rule"><div><strong>' + esc(v.v) + "</strong></div>" + sevPill(v.v) +
          "<strong>" + v.n + "</strong></div>";
      }).join("") || empty("暂无门禁判定");
      var trendHtml = trend.slice(-14).map(function (t) {
        return '<div style="display:flex;justify-content:space-between;font-size:12px">' +
          "<span>" + esc(t.d) + "</span><strong>" + t.n + " 次 · FAIL " + (t.f || 0) + "</strong></div>";
      }).join("") || empty("暂无趋势");

      root.innerHTML =
        head("质量报告", "按语种、规则、问题类别与时间观察质量走势，判断修复是否真实有效。") +
        '<div class="stats">' +
        stat("LQA 发现项", String(byLang.reduce(function (a, x) { return a + x.n; }, 0)), "规则层累计") +
        stat("审校问题", String(catTotal), "AI + 人工登记") +
        stat("门禁阻断", String(verdicts.filter(function (v) { return v.v === "FAIL"; })
          .reduce(function (a, v) { return a + v.n; }, 0)), "候选级判定 FAIL") +
        stat("运行批次", String(trend.length ? trend[trend.length - 1].n : 0), "最近一日") +
        "</div>" +
        '<div class="two-col"><div class="card"><div class="card-head"><h3>各语种问题分布</h3></div>' +
        '<div class="card-body" style="display:grid;gap:16px">' + langHtml + "</div></div>" +
        '<div class="card"><div class="card-head"><h3>问题类别分布</h3></div>' +
        '<div class="card-body issue-list">' + catHtml + "</div></div></div>" +
        '<div class="two-col"><div class="card"><div class="card-head"><h3>规则命中</h3></div>' +
        '<div class="card-body" style="display:grid;gap:16px">' + ruleHtml + "</div></div>" +
        '<div class="card"><div class="card-head"><h3>候选门禁判定 / 最近运行</h3></div>' +
        '<div class="card-body">' + vHtml + '<div class="field-label">最近 14 天运行</div>' +
        '<div style="display:grid;gap:8px">' + trendHtml + "</div></div></div></div>";
    }).catch(function (e) { fail(root, e); });
  }

  /* ---------------------------------------------------------------- 设置 */
  function loadSettings(root) {
    root.innerHTML = '<div class="i18n-empty">加载中…</div>';
    api("/api/i18n/settings").then(function (s) {
      var rules = (s.rules || []).map(function (r) {
        return '<div class="rule"><div><strong>' + esc(r.id + " · " + r.name) + "</strong><small>" +
          esc(r.desc) + "</small></div>" + sevPill(r.severity) + "</div>";
      }).join("");
      var policy = (s.policy || []).map(function (p) {
        return '<div class="issue"><span class="sev ok"></span><div><strong>' + esc(p) + "</strong></div></div>";
      }).join("");
      root.innerHTML =
        head("模型与策略", "管理翻译模型、审校模型与放行策略。模型输出不能绕过 LQA 门禁和人工审批直接发布。",
          '<button class="btn" data-act="settings-save">保存策略</button>') +
        '<div class="two-col"><div class="card"><div class="card-head"><h3>模型配置</h3>' +
        '<span class="pill gray">只读环境变量</span></div><div class="card-body"><div class="form-grid">' +
        '<div class="full"><label>翻译模型（环境变量 ICPDF_TRANSLATE_MODEL）</label>' +
        '<input class="input" value="' + esc(s.translate_model) + '" readonly></div>' +
        '<div class="full"><label>翻译端点</label><input class="input" value="' +
        esc(s.translate_base) + '" readonly></div>' +
        '<div class="full"><label>语义审校模型</label><input class="input" id="stModel" value="' +
        esc(s.review_model) + '"></div>' +
        '<div class="full"><label>模型密钥</label><input class="input" value="' +
        esc(s.key_present ? "已配置（" + s.key_masked + "）" : "未配置") + '" readonly>' +
        '<div class="muted" style="margin-top:5px">密钥只由容器环境提供，本模块永不回显明文。</div></div>' +
        "</div></div></div>" +
        '<div class="card"><div class="card-head"><h3>放行策略</h3><span class="pill blue">rule-set ' +
        esc(s.ruleset) + "</span></div><div class=\"card-body issue-list\">" + policy + "</div></div></div>" +
        '<div class="card"><div class="card-head"><h3>规则清单</h3>' +
        '<span class="hint">规则实现在后端，开关需改代码与规则版本</span></div>' +
        '<div class="card-body">' + rules + "</div></div>" +
        '<div class="footer-note">生产写回与渲染是独立授权动作，不由本模块触发。' +
        "候选、记忆库与审计台账均在独立 i18n_* 表中，与 item / qc_* / parsed/*.json 完全隔离。</div>";
    }).catch(function (e) { fail(root, e); });
  }

  /* ---------------------------------------------------------------- 事件 */
  function closest(el, tag) {
    while (el && el !== document) {
      if (el.getAttribute && el.getAttribute("data-act")) return el;
      el = el.parentNode;
    }
    return null;
  }

  document.addEventListener("click", function (ev) {
    var t = closest(ev.target, null);
    if (!t || state.view === null) return;
    var act = t.getAttribute("data-act");
    if (!act) return;
    var root = $("i18n-" + state.view);
    if (!root || !root.contains(t)) return;
    ev.preventDefault();

    if (act === "go") { go(t.getAttribute("data-view")); return; }
    if (act === "reload") { show(state.view); return; }
    if (act === "jobs-filter") { state.jobsBatch = t.getAttribute("data-batch") || ""; renderJobs(root); return; }
    if (act === "cand-detail") {
      var cid = +t.getAttribute("data-id");
      if (state.cand === cid) { state.cand = null; renderJobs(root); return; }
      api("/api/i18n/candidates/" + cid).then(function (d) {
        state.cand = cid; cache.detail = d; renderJobs(root);
      }).catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "lqa-one") { runLqa(root, +t.getAttribute("data-id")); return; }
    if (act === "lqa-batch") {
      api("/api/i18n/lqa/run-batch", { method: "POST", body: {
        batch: t.getAttribute("data-batch"), revision: t.getAttribute("data-rev") } })
        .then(function (d) { toast("门禁完成：" + d.candidates + " 件，FAIL " + d.fail + " 件"); show("jobs"); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "cand-approve" || act === "cand-reject") {
      var approve = act === "cand-approve";
      api("/api/i18n/candidates/" + t.getAttribute("data-id") + "/decide",
        { method: "POST", body: { approve: approve, note: approve ? "" : "人工驳回" } })
        .then(function () { toast(approve ? "已批准（仍需推进记忆库）" : "已驳回"); loadJobs(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "issue-pick") {
      state.issue = +t.getAttribute("data-id"); renderReview(root); return;
    }
    if (act === "review-sev") { state.reviewSev = t.getAttribute("data-sev") || ""; loadReview(root); return; }
    if (act === "reload-review") { loadReview(root); return; }
    if (act === "issue-decide") {
      api("/api/i18n/review/issues/" + t.getAttribute("data-id") + "/decide",
        { method: "POST", body: { verdict: t.getAttribute("data-verdict") } })
        .then(function () { toast("裁决已记录"); loadReview(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "review-run") {
      var cid = $("rvCand") ? $("rvCand").value : "";
      var model = $("rvModel") ? $("rvModel").value.trim() : "";
      if (!cid) { toast("没有可审校的候选", true); return; }
      if (model) {
        api("/api/i18n/settings", { method: "PUT", body: { review_model: model } }).catch(function () {});
      }
      t.disabled = true;
      t.textContent = "审校中…";
      api("/api/i18n/review/run", { method: "POST", body: { candidate_id: +cid } })
        .then(function (d) {
          toast("审校完成：新增 " + d.issues + " 条问题（" + d.tokens + " tokens）");
          loadReview(root);
        }).catch(function (e) {
          toast(e.message, true);
          t.disabled = false; t.textContent = "▶ 运行审校";
        });
      return;
    }
    if (act === "lqa-reload") { loadLqa(root); return; }
    if (act === "lqa-sev") { state.lqaSev = t.getAttribute("data-sev") || ""; state.run = 0; loadLqa(root); return; }
    if (act === "lqa-run-pick") { state.run = +t.getAttribute("data-run"); renderLqa(root); return; }
    if (act === "lqa-batch-run") {
      var sel = $("lqaBatch") ? $("lqaBatch").value : "";
      if (!sel) { toast("没有批次", true); return; }
      var parts = sel.split("|");
      t.disabled = true;
      api("/api/i18n/lqa/run-batch", { method: "POST", body: { batch: parts[0], revision: parts[1] } })
        .then(function (d) { toast("门禁完成：" + d.candidates + " 件，FAIL " + d.fail + " 件"); loadLqa(root); })
        .catch(function (e) { toast(e.message, true); t.disabled = false; });
      return;
    }
    if (act === "term-form-toggle") {
      var f = $("termForm");
      if (f) f.className = f.className.indexOf("hide") >= 0 ? "card" : "card hide";
      return;
    }
    if (act === "term-lang") { state.termLang = t.getAttribute("data-lang") || ""; loadTerms(root); return; }
    if (act === "reload-terms") { loadTerms(root); return; }
    if (act === "term-status") {
      var gid = +t.getAttribute("data-id");
      var g = (cache.glossary || []).filter(function (x) { return x.id === gid; })[0];
      if (!g) return;
      api("/api/i18n/glossary", { method: "POST", body: {
        id: gid, term_en: g.term_en, domain: g.domain, ja: g.ja, ko: g.ko, de: g.de, es: g.es,
        banned: g.banned_obj || {}, note: g.note, status: t.getAttribute("data-status") } })
        .then(function () { toast("术语状态已更新"); loadTerms(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "banned-toggle") {
      var bid = +t.getAttribute("data-id");
      var b = (cache.banned || []).filter(function (x) { return x.id === bid; })[0];
      if (!b) return;
      api("/api/i18n/banned", { method: "POST", body: {
        id: bid, lang: b.lang, pattern: b.pattern, kind: b.kind, severity: b.severity,
        note: b.note, active: t.getAttribute("data-active") === "1" } })
        .then(function () { toast("禁用词状态已更新"); loadTerms(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "term-save") {
      var banned = {};
      var raw = $("tBanned") ? $("tBanned").value.trim() : "";
      if (raw) {
        try { banned = JSON.parse(raw); } catch (e) { toast("禁用变体不是合法 JSON", true); return; }
      }
      api("/api/i18n/glossary", { method: "POST", body: {
        term_en: $("tTerm").value.trim(), domain: $("tDomain").value,
        ja: $("tJa").value.trim(), ko: $("tKo").value.trim(),
        de: $("tDe").value.trim(), es: $("tEs").value.trim(),
        banned: banned, note: $("tNote").value.trim(), status: "approved" } })
        .then(function () { toast("术语已保存"); loadTerms(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "tm-tab") { state.tmTab = t.getAttribute("data-tab") || "approved"; loadMemory(root); return; }
    if (act === "reload-memory") { loadMemory(root); return; }
    if (act === "tm-promote") {
      var tc = $("tmCand") ? $("tmCand").value : "";
      var tl = $("tmLang") ? $("tmLang").value : "ja";
      if (!tc) { toast("没有候选", true); return; }
      api("/api/i18n/tm/promote", { method: "POST", body: { candidate_id: +tc, lang: tl } })
        .then(function (d) {
          toast(d.approved ? ("已沉淀 " + d.rows + " 段（approved）")
                           : ("候选未批准，写入候选区 " + d.rows + " 段"));
          loadMemory(root);
        }).catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "tm-approve") {
      api("/api/i18n/tm/" + t.getAttribute("data-id") + "/approve", { method: "POST" })
        .then(function () { toast("已批准该句段"); loadMemory(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
    if (act === "settings-save") {
      api("/api/i18n/settings", { method: "PUT", body: {
        review_model: $("stModel") ? $("stModel").value.trim() : "" } })
        .then(function () { toast("策略已保存"); loadSettings(root); })
        .catch(function (e) { toast(e.message, true); });
      return;
    }
  });

  /* 导航展开/收起 */
  document.addEventListener("DOMContentLoaded", function () {
    var g = $("navI18n"), h = $("navI18nHead");
    if (g && h) {
      h.addEventListener("click", function () {
        var on = g.className.indexOf("has-active") >= 0 ? " has-active" : "";
        g.className = g.className.indexOf("collapsed") >= 0
          ? "nav-group" + on : "nav-group collapsed" + on;
      });
    }
  });

  window.I18NQA = { show: show };
})();
