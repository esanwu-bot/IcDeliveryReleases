"""客户反馈闭环 V1 路由（/api/qe/customer-feedback/v1）。

复用现有登录 cookie；所有写操作写 append-only 审计；不修改既有 QC 结果。
"""
from __future__ import annotations

from fastapi import APIRouter, Body, HTTPException, Query
from fastapi.responses import Response

from .. import auth, config, db
from ..services import feedback as FB

router = APIRouter(prefix="/api/qe/customer-feedback/v1")


def _op() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except FB.FeedbackError as e:
        raise HTTPException(e.http_status, e.message)


@router.get("/meta")
def feedback_meta() -> dict:
    return {
        "categories": list(FB.CATEGORIES), "severities": list(FB.SEVERITIES),
        "statuses": list(FB.STATUSES), "sources": list(FB.SOURCES),
        "transitions": FB.TRANSITIONS, "high_risk": sorted(FB.HIGH_RISK),
        "evidence_types": list(FB.EV_TYPES),
    }


@router.get("/dashboard")
def feedback_dashboard() -> dict:
    return _run(FB.dashboard, db)


@router.get("/issues")
def feedback_issues(status: str = "", severity: str = "", category: str = "",
                    batch_id: str = "", mpn: str = "", assignee: str = "",
                    q: str = "", limit: int = Query(50, ge=1, le=200),
                    cursor: int = Query(0, ge=0)) -> dict:
    return _run(FB.list_issues, db,
                {"status": status, "severity": severity, "category": category,
                 "batch_id": batch_id, "mpn": mpn, "assignee": assignee, "q": q},
                limit, cursor)


@router.post("/issues", status_code=201)
def feedback_create(payload: dict = Body(...)) -> dict:
    return _run(FB.create_issue, db, payload, _op())


@router.get("/issues/export-bundle")
def feedback_export_bundle(status: str = "", severity: str = "", category: str = "",
                           batch_id: str = "", mpn: str = "", assignee: str = "",
                           q: str = "") -> Response:
    """一键导出 pandas 分析包（只读快照 ZIP）。"""
    import datetime as _dt
    filters = {"status": status, "severity": severity, "category": category,
               "batch_id": batch_id, "mpn": mpn, "assignee": assignee, "q": q}
    data = FB.export_bundle(db, filters, config.DATA / "qc")
    name = "icpdf_feedback_export_%s.zip" % _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    return Response(data, media_type="application/zip",
                    headers={"Content-Disposition":
                             'attachment; filename="%s"' % name})


@router.get("/issues/export")
def feedback_export(status: str = "", severity: str = "", category: str = "",
                    batch_id: str = "", mpn: str = "", assignee: str = "",
                    q: str = "") -> Response:
    txt = _run(FB.export_csv, db,
               {"status": status, "severity": severity, "category": category,
                "batch_id": batch_id, "mpn": mpn, "assignee": assignee, "q": q})
    return Response(txt, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition":
                             'attachment; filename="customer_feedback_issues.csv"'})


@router.get("/issues/{issue_key}")
def feedback_detail(issue_key: str) -> dict:
    return _run(FB.get_issue, db, issue_key)


@router.patch("/issues/{issue_key}")
def feedback_update(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.update_issue, db, issue_key, payload, _op())


@router.post("/issues/{issue_key}/transition")
def feedback_transition(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.transition, db, issue_key,
                str(payload.get("to_status") or ""),
                str(payload.get("reason") or ""), _op(),
                payload.get("version"))


@router.post("/issues/{issue_key}/samples", status_code=201)
def feedback_sample_add(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.add_sample, db, issue_key, payload, _op())


@router.get("/issues/{issue_key}/samples")
def feedback_samples(issue_key: str) -> dict:
    d = _run(FB.get_issue, db, issue_key)
    return {"items": d["samples"]}


@router.patch("/samples/{sample_link_id}")
def feedback_sample_update(sample_link_id: int, payload: dict = Body(...)) -> dict:
    return _run(FB.update_sample, db, sample_link_id, payload, _op())


@router.post("/issues/{issue_key}/evidence", status_code=201)
def feedback_evidence_add(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.add_evidence, db, issue_key, payload, _op())


@router.post("/evidence/{evidence_id}/review")
def feedback_evidence_review(evidence_id: int, payload: dict = Body(...)) -> dict:
    return _run(FB.review_evidence, db, evidence_id, payload, _op())


@router.post("/issues/{issue_key}/fixes", status_code=201)
def feedback_fix_add(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.add_fix, db, issue_key, payload, _op())


@router.post("/issues/{issue_key}/regressions", status_code=201)
def feedback_regression_add(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.add_regression, db, issue_key, payload, _op())


@router.post("/issues/{issue_key}/acceptance", status_code=201)
def feedback_acceptance(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.acceptance, db, issue_key, payload, _op())


@router.post("/issues/{issue_key}/close")
def feedback_close(issue_key: str, payload: dict = Body(...)) -> dict:
    return _run(FB.close_issue, db, issue_key, payload, _op())


@router.get("/batches/{batch_id}/feedback-summary")
def feedback_batch_summary(batch_id: str) -> dict:
    return _run(FB.batch_summary, db, batch_id)
