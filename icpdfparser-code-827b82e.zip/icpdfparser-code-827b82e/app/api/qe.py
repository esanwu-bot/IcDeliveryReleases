"""质量工程 QE 路由组（/api/qe/*）——Gold Set / 风险分流 / 随机审计 / 引擎对比 / 反馈闭环。

对应原型五个页面的功能布局（样式沿用现有工作台）：
  * Gold Set：人工标准答案（PDF 哈希、版本、字段真值、证据页码、append-only 审核台账）；
    机器只允许 seed 草稿，改标准值/核验/冻结全部是人工动作。
  * 风险队列：评分（严重度×字段重要性×QC不确定性×累积）只排队，P0 由 kind 硬规则决定。
  * 随机审计：从"自动 QC 通过"总体盲审抽样测漏报，种子+快照留档。
  * 引擎对比：Gold(frozen×verified) × pymupdf/odl/docstrange 四维度对比。
  * 反馈闭环：人工确认缺陷 → 导出回归夹具（qc_regression --extra）→ 修复后重跑防回归。

数据面新表：gold_set / gold_field / gold_review_log / risk_case / sample_batch /
sample_item / feedback_case（见 db.py DDL）。
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Body, File, HTTPException, Query, UploadFile

from .. import auth, config, db
from ..services import dispatch
from ..services import feedback as FB
from qc import goldset as GS      # 自包含模块：无 stdout 包装副作用，server 进程安全
from qc import source_evidence as SE   # 原厂证据卡：纯判定 + db 注入，同样无副作用
from qc import cheatsheet as CS   # 核验单规则引擎（import 零 stdout）
from qc import evidence_verify as EV   # batch-verify 十项重校验（不 import table_audit）
from qc import evidence_chain as EC    # E1–E4 机器起草
from qc import freeze_precheck as FP   # 冻结前置自查 G1–G10（只读）
from qc import attach_missing as AM    # 补挂接执行器（机器草稿）
from qc import verify_worklist as VW   # 必须人工量清单（只读）
from qc import risk_guide as RG        # A 组高风险对照表（按类型分组，只读）
from qc import high_risk as HR         # 高风险分类器
from qc import delivery_history as DH   # QC 交付历史（只读：data/qc + data/delivery-*）

router = APIRouter(prefix="/api/qe")

GOLD_VERSION = "v1"               # 当前基准集版本（新版本走冻结→新 version 流程）


def _op() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _log_review(gold_id: int, field_id: int, action: str, detail: str) -> None:
    db.x("INSERT INTO gold_review_log(gold_id,field_id,action,detail,operator,created_at) "
         "VALUES(?,?,?,?,?,?)", (gold_id, field_id, action, detail[:800], _op(), db.qc_now()))


# ================================================================ Gold Set
@router.get("/gold")
def gold_list(status: str = "", q: str = "", page: int = Query(1, ge=1),
              size: int = Query(50, ge=1, le=200)) -> dict:
    where, args = ["1=1"], []
    if status:
        where.append("g.status=?"); args.append(status)
    if q:
        where.append("(g.mpn LIKE ? OR g.manufacturer LIKE ?)")
        args += [f"%{q}%", f"%{q}%"]
    cond = " AND ".join(where)
    total = db.q1(f"SELECT count(*) n FROM gold_set g WHERE {cond}", args)["n"]
    rows = db.q(
        f"SELECT g.*, (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id) total,"
        f" (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id AND f.status='verified') verified,"
        f" (SELECT count(*) FROM gold_field f WHERE f.gold_id=g.id AND f.status='conflict') conflict"
        f" FROM gold_set g WHERE {cond} ORDER BY g.id DESC LIMIT ? OFFSET ?",
        (*args, size, (page - 1) * size))
    st = db.q1("SELECT count(*) n FROM gold_set")["n"]
    fr = db.q1("SELECT count(*) n FROM gold_set WHERE status='frozen'")["n"]
    ft = db.q1("SELECT count(*) n FROM gold_field")["n"]
    fv = db.q1("SELECT count(*) n FROM gold_field WHERE status='verified'")["n"]
    fc = db.q1("SELECT count(*) n FROM gold_field WHERE status='conflict'")["n"]
    mfr = db.q1("SELECT count(DISTINCT manufacturer) n FROM gold_set "
                "WHERE manufacturer<>''")["n"]
    return {"total": total, "page": page, "size": size, "items": rows,
            "stats": {"n": st, "frozen": fr, "manufacturers": mfr,
                      "fields_total": ft, "fields_verified": fv,
                      "fields_pending": ft - fv - fc, "fields_conflict": fc,
                      "sha_ok": db.q1("SELECT count(*) n FROM gold_set "
                                      "WHERE pdf_sha256<>''")["n"]},
            "version": GOLD_VERSION}


@router.get("/gold/candidates")
def gold_candidates(q: str = "", limit: int = 20) -> dict:
    """seed 候选：库里有 parsed JSON + PDF、且尚未进 Gold Set 的型号。"""
    where = "i.json_path<>'' AND i.pdf_path<>''"
    args: list = []
    if q:
        where += " AND i.mpn LIKE ?"; args.append(f"%{q}%")
    rows = db.q(f"SELECT i.mpn FROM item i WHERE {where} "
                f"AND i.mpn NOT IN (SELECT mpn FROM gold_set) "
                f"ORDER BY i.last_parsed_at DESC LIMIT ?", (*args, min(limit, 100)))
    return {"mpns": [r["mpn"] for r in rows]}


@router.get("/gold/{gold_id}")
def gold_detail(gold_id: int) -> dict:
    g = db.q1("SELECT * FROM gold_set WHERE id=?", (gold_id,))
    if not g:
        raise HTTPException(404, "基准样本不存在")
    fields = db.q("SELECT * FROM gold_field WHERE gold_id=? ORDER BY id", (gold_id,))
    logs = db.q("SELECT * FROM gold_review_log WHERE gold_id=? ORDER BY id DESC LIMIT 200",
                (gold_id,))
    loc = GS.locate(g["mpn"])
    return {"gold": g, "fields": fields, "logs": logs,
            "artifacts": {"pdf": loc["pdf"].name if loc else "",
                          "json": loc["json"].name if loc else ""},
            "rules": "未核实字段不得标记 verified；机器修复不能直接修改 Gold Set；"
                     "冻结后变更须创建新版本并留审计记录"}


@router.post("/gold/seed")
def gold_seed(payload: dict = Body(...)) -> dict:
    """从生产 parsed JSON 生成 Gold 草稿（含 PDF SHA-256 登记）。机器只出草稿。"""
    mpns = [str(m).strip() for m in (payload.get("mpns") or
             ([payload["mpn"]] if payload.get("mpn") else [])) if str(m).strip()]
    if not mpns:
        raise HTTPException(400, "请提供 mpn 或 mpns 列表")
    out = []
    for m in mpns[:200]:
        r = GS.seed_gold(m, operator=_op(), version=GOLD_VERSION, db_mod=db)
        out.append(r)
        if r.get("error"):
            continue
    db.add_event(f"QE Gold Set seed {len(out)} 件（机器草稿，待人工核验）", kind="qc")
    return {"seeded": out, "note": "草稿字段须人工对照原厂 PDF 核验后才能 verified/冻结"}


@router.post("/gold/seed-from-run")
def gold_seed_from_run(payload: dict = Body(...)) -> dict:
    """「转人工核验」：回归运行逐件记录 → Gold 草稿 + 风险核验任务。

    四类信号保真携带（findings/缺发现/断言败/lint）；断言败与缺发现各建
    risk_case 供人工判定；未经确认的 QC 信号不当标准答案（不建反馈用例、
    不写 expected 真值）。
    """
    run_id = int(payload.get("run_id") or 0)
    if not run_id:
        raise HTTPException(400, "请提供 run_id")
    r = db.q1("SELECT id, mode FROM qc_run WHERE id=?", (run_id,))
    if not r:
        raise HTTPException(404, f"run#{run_id} 不存在")
    if r["mode"] != "regression":
        raise HTTPException(400, f"run#{run_id} 不是回归运行（mode={r['mode']}）")
    out = GS.seed_from_run(run_id, operator=_op(), version=GOLD_VERSION, db_mod=db)
    if out.get("error"):
        raise HTTPException(400, out["error"])
    db.add_event(f"QE 回归转核验 run#{run_id}：Gold {out['gold_seeded']} 新 / "
                 f"{out['gold_existed']} 已存，风险任务 +{out['risk_added']}", kind="qc")
    return out


@router.post("/gold/{gold_id}/status")
def gold_status(gold_id: int, payload: dict = Body(...)) -> dict:
    """器件级状态机：draft → review → frozen（冻结需全部字段 verified）。"""
    g = db.q1("SELECT * FROM gold_set WHERE id=?", (gold_id,))
    if not g:
        raise HTTPException(404, "基准样本不存在")
    status = str(payload.get("status") or "").strip()
    if status not in ("draft", "review", "frozen"):
        raise HTTPException(400, "status 仅支持 draft / review / frozen")
    if status == "frozen":
        n = db.q1("SELECT count(*) n FROM gold_field WHERE gold_id=? "
                  "AND status<>'verified'", (gold_id,))["n"]
        if n:
            raise HTTPException(400, f"还有 {n} 个字段未核验（pending/conflict），"
                                     "冻结前必须全部 verified")
    db.x("UPDATE gold_set SET status=?, updated_at=? WHERE id=?",
         (status, db.qc_now(), gold_id))
    if status == "frozen":
        act, detail = "freeze", f"status → frozen（版本冻结）"
    elif (g["status"] or "") == "frozen":
        act, detail = "unfreeze", "status → review（从冻结回退，标准值历史保留）"
    else:
        act, detail = "review", f"status {g['status']} → {status}"
    _log_review(gold_id, 0, act, detail)
    db.add_event(f"QE Gold {g['mpn']} 状态 → {status}", kind="qc")
    return {"ok": True, "status": status}


@router.post("/gold/field/{field_id}")
def gold_field_update(field_id: int, payload: dict = Body(...)) -> dict:
    """人工核验/修订标准答案。

    口径（《人工核验落实手册》硬约束）：
      * `verified` 必须同时有**页码(>0)** 与**证据定位**——两者缺一即 400；
      * 高风险字段（引脚/封装/身份/电流类电气）证据必须含**原文 quote**；
      * `conflict` = 推翻机器草稿：可同时写入 PDF 正确值（expected）与证据，
        禁止「静默改值后点通过」——状态必须显式置 conflict 并留原因。
    """
    f = db.q1("SELECT * FROM gold_field WHERE id=?", (field_id,))
    if not f:
        raise HTTPException(404, "字段不存在")
    g = db.q1("SELECT * FROM gold_set WHERE id=?", (f["gold_id"],))
    if g and g["status"] == "frozen" and payload.get("expected") is not None:
        raise HTTPException(400, "已冻结样本的标准值不可改（新版本流程）："
                                 "可先解冻回 review，或标记 conflict 留证")
    status = str(payload.get("status") or "").strip()
    if status and status not in ("pending", "verified", "conflict"):
        raise HTTPException(400, "status 仅支持 pending / verified / conflict")
    page_no = int(payload.get("page_no") if payload.get("page_no") is not None
                  else (f["page_no"] or 0))
    evidence = str(payload.get("evidence") if payload.get("evidence") is not None
                   else (f["evidence"] or "")).strip()
    expected = str(payload.get("expected") if payload.get("expected") is not None
                   else (f["expected"] or ""))
    if status == "verified":
        if page_no <= 0:
            raise HTTPException(400, "核验通过必须填 PDF 物理页码（1 起，>0）")
        if not evidence:
            raise HTTPException(400, "核验通过必须填证据定位（表名 / 行列 / 章节）")
        if CS.is_high_risk(f["field_path"], f["field_name"], f["unit"], expected) \
                and not CS.has_quote(evidence):
            raise HTTPException(400, "高风险字段（身份/封装/电源脚/电流类电气）证据必须含"
                                     "原文 quote，如：Table 7-3 IDD 行 MAX 列，原文 \"10 µA\"")
    if status == "conflict" and not evidence:
        raise HTTPException(400, "标记冲突必须写原因或 PDF 正确值+证据（审计要求）")
    sets, args = [], []
    for col in ("expected", "unit", "cond", "evidence"):
        if payload.get(col) is not None:
            sets.append(f"{col}=?"); args.append(str(payload[col]))
    if payload.get("page_no") is not None:
        sets.append("page_no=?"); args.append(page_no)
    if status:
        sets.append("status=?"); args.append(status)
        sets.append("verified_by=?"); args.append(_op())
        sets.append("verified_at=?"); args.append(db.qc_now())
    if sets:
        args.append(field_id)
        db.x(f"UPDATE gold_field SET {', '.join(sets)} WHERE id=?", args)
    _log_review(f["gold_id"], field_id, status or "update",
                json.dumps({k: payload.get(k) for k in
                            ("expected", "unit", "page_no", "evidence")
                            if payload.get(k) is not None}, ensure_ascii=False))
    return {"ok": True}


@router.get("/gold/{gold_id}/cheatsheet.html")
def gold_cheatsheet_html(gold_id: int, no_json: int = 0):
    """核验单 HTML 预览（浏览器可读可打印；.md 版仍保留供归档）。"""
    from fastapi.responses import HTMLResponse
    from qc import mdpreview as MP
    try:
        md = CS.render_gold(gold_id=gold_id, include_json=not no_json, db_mod=db)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"核验单生成失败：{e}") from e
    if not md:
        raise HTTPException(404, "Gold 或字段不存在")
    g = db.q1("SELECT mpn FROM gold_set WHERE id=?", (gold_id,)) or {}
    return HTMLResponse(MP.to_html(md, title=f"核验单 · {g.get('mpn') or ('gold#' + str(gold_id))}",
                                   subtitle="三遍法：身份/封装 → 电气参数 → 扫尾收口"))


@router.get("/gold/{gold_id}/cheatsheet.md")
def gold_cheatsheet(gold_id: int, no_json: int = 0):
    """按 Gold 字段实时生成三遍法 Markdown 核验单（双屏对照 / 打印 / 归档）。"""
    from fastapi.responses import Response
    try:
        md = CS.render_gold(gold_id=gold_id, include_json=not no_json, db_mod=db)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"核验单生成失败：{e}") from e
    if not md:
        raise HTTPException(404, "Gold 或字段不存在")
    return Response(md, media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition":
                             f'inline; filename="gold{gold_id}_cheatsheet.md"'})


@router.post("/gold/{gold_id}/field")
def gold_field_add(gold_id: int, payload: dict = Body(...)) -> dict:
    """补录字段：机器漏而原厂 PDF 有的字段，可**直接带预期+证据进 verified**。

    status=verified 时同样要求页码>0 + 证据定位（高风险另需 quote），
    避免「补录即免核验」绕过手册口径。
    """
    g = db.q1("SELECT * FROM gold_set WHERE id=?", (gold_id,))
    if not g:
        raise HTTPException(404, "基准样本不存在")
    path = str(payload.get("field_path") or "").strip()
    if not path:
        raise HTTPException(400, "field_path 必填（如 electrical[40].value）")
    page_no = int(payload.get("page_no") or 0)
    evidence = str(payload.get("evidence") or "").strip()
    name = str(payload.get("field_name") or "")
    unit = str(payload.get("unit") or "")
    expected = str(payload.get("expected") or "")
    status = str(payload.get("status") or "").strip()
    if status not in ("", "pending", "verified"):
        raise HTTPException(400, "补录仅支持 pending / verified 初始状态")
    if not status:
        # 手册：「+补录字段」带预期+证据可直接进 verified；两者不全则先存 pending
        status = "verified" if (page_no > 0 and evidence) else "pending"
    if status == "verified":
        if page_no <= 0:
            raise HTTPException(400, "补录并核验必须填 PDF 物理页码（1 起，>0）")
        if not evidence:
            raise HTTPException(400, "补录并核验必须填证据定位（表名 / 行列 / 章节）")
        if CS.is_high_risk(path, name, unit, expected) and not CS.has_quote(evidence):
            raise HTTPException(400, "高风险字段补录核验同样必须含原文 quote")
    fid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,cond,"
               "page_no,evidence,status,verified_by,verified_at)"
               " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
               (gold_id, path, name, expected, unit,
                str(payload.get("cond") or ""), page_no, evidence, status,
                _op() if status == "verified" else "",
                db.qc_now() if status == "verified" else ""))
    _log_review(gold_id, fid, "field_add",
                json.dumps({"field_path": path, "status": status, "page_no": page_no},
                           ensure_ascii=False))
    return {"field_id": fid, "status": status}


# ================================================================ 原厂证据卡
# 原则：先确认 PDF 身份，再核验字段。P0–P4 只是来源优先级，不等于身份已核验；
# 官方域名也不等于覆盖目标订购型号——覆盖型号必须人工确认。
@router.get("/evidence")
def evidence_list(status: str = "", q: str = "", page: int = Query(1, ge=1),
                  size: int = Query(50, ge=1, le=200)) -> dict:
    where, args = ["1=1"], []
    if status:
        where.append("e.status=?"); args.append(status)
    if q:
        where.append("(e.mpn LIKE ? OR e.manufacturer LIKE ?)"); args += [f"%{q}%", f"%{q}%"]
    cond = " AND ".join(where)
    total = db.q1(f"SELECT count(*) n FROM source_evidence e WHERE {cond}", args)["n"]
    rows = db.q(
        f"SELECT e.*, d.source_tier, d.source_url, d.is_official, d.identity_status doc_identity,"
        f" d.pdf_sha256, d.page_count, d.covered_mpn_json,"
        f" (SELECT count(*) FROM source_field_evidence f WHERE f.evidence_id=e.id) fields,"
        f" (SELECT count(*) FROM source_field_evidence f WHERE f.evidence_id=e.id"
        f"   AND f.verification_status='verified') fields_verified"
        f" FROM source_evidence e LEFT JOIN source_document d ON d.id=e.document_id"
        f" WHERE {cond} ORDER BY e.id DESC LIMIT ? OFFSET ?",
        (*args, size, (page - 1) * size))
    return {"items": rows, "total": total, "page": page, "size": size,
            "stats": SE.stats(db), "tiers": SE.TIER_RULES}


@router.post("/evidence")
def evidence_create(payload: dict = Body(...)) -> dict:
    """建器件证据卡：目标 MPN + 制造商 + 本次待核验字段（方案 §2.1）。"""
    try:
        eid = SE.create_evidence(str(payload.get("mpn") or ""),
                                 str(payload.get("manufacturer") or ""),
                                 payload.get("target_fields") or [], _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    db.add_event(f"QE 证据卡 #{eid} 建立：{payload.get('mpn')}", kind="qc")
    return {"evidence_id": eid}


@router.get("/evidence/{evidence_id}")
def evidence_detail(evidence_id: int) -> dict:
    d = SE.detail(evidence_id, db)
    if not d:
        raise HTTPException(404, "证据卡不存在")
    g = db.q1("SELECT id, mpn, status, pdf_sha256 FROM gold_set WHERE mpn=? "
              "ORDER BY id DESC LIMIT 1", (d["evidence"]["mpn"],))
    d["gold"] = g or {}
    d["rules"] = ("来源等级只表示优先级；identity=verified 与字段核验必须人工确认。"
                  "source_unresolved 表示现有证据不足以确认适用于目标器件，"
                  "恢复须有新证据与审计记录，不能靠重试搜索自动清除。")
    return d


@router.post("/evidence/{evidence_id}/documents")
def evidence_add_document(evidence_id: int, payload: dict = Body(...)) -> dict:
    """登记候选文档：算 SHA-256、检查可读性与官方域名（不自动确认身份）。"""
    lp = str(payload.get("local_path") or "").strip()
    if lp and not Path(lp).is_absolute():
        lp = str(Path(__file__).resolve().parents[2] / lp)
    try:
        out = SE.add_document(evidence_id, str(payload.get("source_tier") or "P0"),
                              str(payload.get("source_url") or ""), lp,
                              str(payload.get("source_type") or "datasheet_pdf"), _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return out


@router.post("/evidence/{evidence_id}/verify-identity")
def evidence_verify_identity(evidence_id: int, payload: dict = Body(...)) -> dict:
    """人工确认文档身份与型号覆盖。reviewer 取当前登录用户，覆盖型号必须人工填写。"""
    cov = payload.get("covered_mpns") or []
    if isinstance(cov, str):
        cov = [x for x in cov.replace("，", ",").split(",") if x.strip()]
    try:
        out = SE.verify_identity(evidence_id, _op(), cov,
                                 str(payload.get("notes") or ""), _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    db.add_event(f"QE 证据卡 #{evidence_id} 身份核验 → {out['identity_status']}", kind="qc")
    return out


@router.post("/evidence/{evidence_id}/status")
def evidence_set_status(evidence_id: int, payload: dict = Body(...)) -> dict:
    """处置 source_unresolved / conflict（必须写原因，append-only 审计）。"""
    try:
        return SE.set_evidence_status(evidence_id, str(payload.get("status") or ""),
                                      str(payload.get("reason") or ""), _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/evidence/{evidence_id}/fields")
def evidence_add_field(evidence_id: int, payload: dict = Body(...)) -> dict:
    """登记字段级证据定位（页码必填 >0 才能核验）。"""
    try:
        fid = SE.add_field_evidence(
            evidence_id, str(payload.get("field_path") or ""),
            int(payload.get("page_number") or 0), str(payload.get("table_name") or ""),
            str(payload.get("row_key") or ""), str(payload.get("column_key") or ""),
            str(payload.get("cell_value") or ""), str(payload.get("evidence_quote") or ""),
            int(payload.get("gold_field_id") or 0), _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return {"field_evidence_id": fid}


@router.post("/evidence/field/{field_evidence_id}/verify")
def evidence_verify_field(field_evidence_id: int, payload: dict = Body(default={})) -> dict:
    """单字段证据核验（**放行高风险**，但 quote 必填）。

    可带 `page_number` / `evidence_quote`：先按人工填写的证据更新该行，再走十项重校验
    （A 组弹窗预填 E3 候选 → 人工确认/微调 → 核验）。
    """
    try:
        out = EV.verify_one(db, field_evidence_id, _op(), dry=bool(payload.get("dry")),
                            page_number=payload.get("page_number"),
                            evidence_quote=payload.get("evidence_quote"))
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"字段核验失败：{e}") from e
    if out.get("error"):
        raise HTTPException(404, out["error"])
    if out.get("rejected"):
        raise HTTPException(400, f"字段核验被拒（{out['reason']}）：{out.get('field_path')}")
    return out


@router.get("/evidence/field/{field_evidence_id}/candidates")
def evidence_field_candidates(field_evidence_id: int) -> dict:
    """E3 候选（A 组核验弹窗 top-1 预填用）：当前值 + 候选 ≤5 + mpn。"""
    out = EV.field_candidates(db, field_evidence_id)
    if not out:
        raise HTTPException(404, "字段证据不存在")
    return out


@router.post("/evidence/field/{field_evidence_id}/conflict")
def evidence_field_conflict(field_evidence_id: int, payload: dict = Body(...)) -> dict:
    """人工裁决：字段证据标 `conflict` + 原因（冻结守卫会因此阻断，直到裁决完）。"""
    try:
        return EV.mark_conflict(db, field_evidence_id, str(payload.get("reason") or ""), _op())
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/evidence/field/{field_evidence_id}/resolve")
def evidence_field_resolve(field_evidence_id: int, payload: dict = Body(...)) -> dict:
    """人工裁决 `conflict_draft`：use_pdf 改 Gold 草稿值 / keep_gold 保留，转 ready 后再核验。

    `use_pdf` 的 quote 必须先命中原文该页（回打校验）；已冻结样本一律拒绝改值。
    """
    try:
        out = EV.resolve_conflict(
            db, field_evidence_id, str(payload.get("action") or ""), _op(),
            expected=payload.get("expected"),
            page_number=payload.get("page_number"),
            evidence_quote=payload.get("evidence_quote"),
            reason=str(payload.get("reason") or ""),
            dry=bool(payload.get("dry")))
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    if out.get("error") == "field_not_found":
        raise HTTPException(404, "字段证据不存在")
    if out.get("error") == "gold_missing":
        raise HTTPException(404, "该型号无 Gold")
    if out.get("error") == "gold_frozen":
        raise HTTPException(400, "已冻结样本不可改值：请先解冻回 review")
    if out.get("error") == "not_conflict":
        raise HTTPException(400, f"只有 conflict_draft/conflict 行可裁决（当前 {out.get('status')}）")
    if out.get("error"):
        raise HTTPException(400, f"裁决被拒（{out['error']}）")
    if not out.get("dry"):
        db.add_event(f"QE 裁决 {out['field_path']}：{out['action']} "
                     f"expected {out['old_expected']} → {out['expected']}", kind="qc")
    return out


@router.post("/evidence/{evidence_id}/fields/batch-verify")
def evidence_batch_verify(evidence_id: int, payload: dict = Body(...)) -> dict:
    """人工批量确认（**仅非高风险**）：dry 预览 → 确认写库。

    高风险字段会被 400 级拒绝（reason=high_risk:*），必须走单字段核验。
    """
    ids = payload.get("field_ids") or []
    try:
        rep = EV.batch_verify(db, evidence_id, ids, _op(), dry=bool(payload.get("dry")))
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"批量核验失败：{e}") from e
    if rep.get("error") == "evidence_not_found":
        raise HTTPException(404, "证据卡不存在")
    if rep.get("error") == "field_ids_empty":
        raise HTTPException(400, "field_ids 为空")
    if not rep.get("dry"):
        db.add_event(f"QE 证据卡 #{evidence_id} 批量确认：verified {len(rep['verified'])} / "
                     f"rejected {len(rep['rejected'])}", kind="qc")
    return rep


@router.get("/evidence/{evidence_id}/high-risk")
def evidence_high_risk(evidence_id: int) -> dict:
    """高风险字段清单（禁批量）+ 可批量行（前端默认勾选集）。"""
    if not db.q1("SELECT id FROM source_evidence WHERE id=?", (evidence_id,)):
        raise HTTPException(404, "证据卡不存在")
    return {"high_risk": EV.list_high_risk(db, evidence_id),
            "batchable": EV.batchable(db, evidence_id),
            "policy": HR.HIGH_RISK_BATCH_POLICY}


@router.post("/evidence/{evidence_id}/auto-chain")
def evidence_auto_chain(evidence_id: int, payload: dict = Body(default={})) -> dict:
    """E1–E4 机器起草（sha256/预检/字段定位/三向比对）。

    只写草稿（reviewer=NULL、status=ready|ambiguous|ocr_pending|conflict_draft）；
    identity/verified/freeze 仍需人工。
    """
    ev = db.q1("SELECT mpn FROM source_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise HTTPException(404, "证据卡不存在")
    mpn = ev["mpn"]
    try:
        EV.ensure_cols(db)
        out = {"mpn": mpn, "dry": bool(payload.get("dry"))}
        # 已建卡：跳过 E1 建档，直接预检 → 定位 → 比对（幂等）
        out["e2"] = EC.e2_precheck(db, evidence_id, mpn, out["dry"])
        out["e3"] = EC.e3_locate(db, evidence_id, mpn, out["dry"])
        out["e4"] = EC.e4_crosscheck(db, evidence_id, mpn, out["dry"])
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"证据链起草失败：{e}") from e
    if not out["dry"]:
        db.add_event(f"QE 证据卡 #{evidence_id}({mpn}) 一键定位："
                     f"就绪 {out['e3'].get('located')} / 多候选 {out['e3'].get('ambiguous')} / "
                     f"缺 {out['e3'].get('missing')}", kind="qc")
    return out


@router.get("/evidence/{evidence_id}/freeze-readiness")
def evidence_freeze_readiness(evidence_id: int) -> dict:
    """E6 冻结就绪度：守卫逐项绿/黄/红（全绿才可点冻结）。"""
    out = EC.freeze_readiness(db, evidence_id)
    if out.get("error"):
        raise HTTPException(404, "证据卡不存在")
    return out


@router.post("/evidence/{evidence_id}/fields/batch-attach")
def evidence_batch_attach(evidence_id: int, payload: dict = Body(...)) -> dict:
    """批量挂接（机器草稿）：粘贴 field_path 列表 → 建字段证据草稿（可并入 target_fields）。

    红线：**只起草**（page/quote 空、reviewer 空、状态 pending）；挂接后 G5/G9 转绿，
    但 G6/G7 仍红 —— page+quote+verify 必须人工。
    """
    if not db.q1("SELECT id FROM source_evidence WHERE id=?", (evidence_id,)):
        raise HTTPException(404, "证据卡不存在")
    paths = [str(x).strip() for x in (payload.get("field_paths") or []) if str(x).strip()]
    if not paths:
        raise HTTPException(400, "field_paths 为空")
    paths = list(dict.fromkeys(paths))[:500]
    rows = [{"evidence_id": evidence_id, "gap": "field_evidence", "field_path": p}
            for p in paths]
    if payload.get("extend_target"):
        rows += [{"evidence_id": evidence_id, "gap": "target_fields", "field_path": p}
                 for p in paths]
    out = AM.apply_rows(db, rows, dry=bool(payload.get("dry")))
    if not out["dry"]:
        db.add_event(f"QE 证据卡 #{evidence_id} 批量挂接：草稿 {out['field_evidence']} / "
                     f"target +{out['target_fields']} / 跳过 {out['skipped']}", kind="qc")
    return out


@router.get("/evidence/{evidence_id}/risk-guide.html")
def evidence_risk_guide_html(evidence_id: int):
    """A 组高风险对照表 HTML 预览（浏览器渲染 + 可打印）。"""
    from fastapi.responses import HTMLResponse
    from qc import mdpreview as MP
    try:
        d = RG.build(db, ev_id=evidence_id)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"对照表生成失败：{e}") from e
    if not d:
        raise HTTPException(404, "证据卡不存在")
    return HTMLResponse(MP.to_html(
        RG.render_md(d), title=f"高风险字段对照表 · {d['mpn']}",
        subtitle=f"A 组 {d['a_total']} 条须逐条核验 · 剩余必须点击 {d['clicks_est']} 次 · "
                 f"页码口径 = PDF 物理页"))


@router.get("/evidence/{evidence_id}/risk-guide.md")
def evidence_risk_guide(evidence_id: int):
    """A 组高风险对照表（按字段类型 → 该翻哪张表分组），Markdown 直出可打印。"""
    from fastapi.responses import Response
    try:
        d = RG.build(db, ev_id=evidence_id)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"对照表生成失败：{e}") from e
    if not d:
        raise HTTPException(404, "证据卡不存在")
    md = RG.render_md(d)
    mpn = d["mpn"]
    return Response(md, media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition":
                             f'inline; filename="risk_guide_{mpn}.md"'})


@router.get("/evidence/{evidence_id}/worklist")
def evidence_worklist(evidence_id: int) -> dict:
    """必须人工量清单：分组 A/B/C/D/F/E + 点击数下限（只读，供抽屉进度环）。"""
    out = VW.build(db, ev_id=evidence_id)
    if not out:
        raise HTTPException(404, "证据卡不存在")
    return out


@router.get("/evidence/{evidence_id}/freeze-precheck")
def evidence_freeze_precheck(evidence_id: int) -> dict:
    """冻结前置自查 G1–G10（清单 §4 的 1:1 实现；只读，不写库不冻结）。

    红行自带处置建议；附 `missing_fe`（补挂接清单）与 `missing_tf`（target_fields 补齐）。
    末尾 `server_can_freeze` 为服务端守卫复核行（口径漂移自检）。
    """
    out = FP.run(db, evidence_id=evidence_id)
    if not out:
        raise HTTPException(404, "证据卡不存在")
    return out


@router.post("/evidence/{evidence_id}/freeze")
def evidence_freeze(evidence_id: int, payload: dict = Body(...)) -> dict:
    """冻结 Gold：全部守卫通过才允许（来源/身份/覆盖/字段证据/页码/哈希一致性）。"""
    gold_id = int(payload.get("gold_id") or 0)
    if not gold_id:
        ev = db.q1("SELECT mpn FROM source_evidence WHERE id=?", (evidence_id,))
        if not ev:
            raise HTTPException(404, "证据卡不存在")
        g = db.q1("SELECT id FROM gold_set WHERE mpn=? AND version=? ORDER BY id DESC LIMIT 1",
                  (ev["mpn"], GOLD_VERSION))
        if not g:
            raise HTTPException(400, "该 MPN 还没有 Gold 样本，先 seed 再冻结")
        gold_id = g["id"]
    try:
        out = SE.freeze(evidence_id, gold_id, _op(), db)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    db.add_event(f"QE Gold {out['mpn']} 经证据卡 #{evidence_id} 冻结", kind="qc")
    return out


# ================================================================ 风险队列
@router.get("/risk")
def risk_queue(priority: str = "", status: str = "", q: str = "") -> dict:
    where, args = ["1=1"], []
    if priority:
        where.append("r.priority=?"); args.append(priority)
    if status:
        where.append("r.status=?"); args.append(status)
    else:
        where.append("r.status IN ('open','confirming','to_regression')")
    if q:
        where.append("(r.mpn LIKE ? OR r.kind LIKE ?)"); args += [f"%{q}%", f"%{q}%"]
    rows = db.q(f"SELECT r.* FROM risk_case r WHERE {' AND '.join(where)} "
                f"ORDER BY CASE r.priority WHEN 'P0' THEN 0 WHEN 'P1' THEN 1 ELSE 2 END, "
                f"r.score DESC, r.id DESC LIMIT 300", args)
    dist = {p["priority"]: p["n"] for p in db.q(
        "SELECT priority, count(*) n FROM risk_case "
        "WHERE status IN ('open','confirming') GROUP BY priority")}
    return {"items": rows, "distribution": {"P0": dist.get("P0", 0),
                                            "P1": dist.get("P1", 0),
                                            "P2": dist.get("P2", 0)},
            "rules": "P0 硬阻断：identity/pin/package/unit/mpn 类 kind；"
                     "评分 = 严重度 × 字段重要性 × QC不确定性 × 同件累积惩罚（仅排队用）"}


@router.post("/risk/sync")
def risk_sync() -> dict:
    r = GS.sync_risk_queue(operator=_op(), db_mod=db)
    db.add_event(f"QE 风险队列同步：新增 {r['added']}，跳过 {r['skipped']}", kind="qc")
    return r


@router.post("/risk/{case_id}/action")
def risk_action(case_id: int, payload: dict = Body(...)) -> dict:
    """人工分流：start（开始核验）/ confirm（确认缺陷→转反馈闭环）/ reject（误报）/ close。"""
    c = db.q1("SELECT * FROM risk_case WHERE id=?", (case_id,))
    if not c:
        raise HTTPException(404, "风险条目不存在")
    act = str(payload.get("action") or "").strip()
    note = str(payload.get("note") or "").strip()
    if act == "start":
        status = "confirming"
    elif act == "confirm":
        status = "to_regression"
    elif act == "reject":
        status = "rejected"
    elif act == "close":
        status = "closed"
    else:
        raise HTTPException(400, "action 仅支持 start / confirm / reject / close")
    db.x("UPDATE risk_case SET status=?, operator=?, updated_at=? WHERE id=?",
         (status, _op(), db.qc_now(), case_id))
    if act == "confirm":                     # 确认的新错误 → 反馈闭环（回归集入口）
        fid = _new_feedback(mpn=c["mpn"], kind=c["kind"], source="risk",
                            note=note or f"风险队列确认（score={c['score']}）")
        return {"ok": True, "status": status, "feedback_id": fid}
    if note:
        _log_review(0, 0, "risk_note", f"{c['mpn']} {c['kind']}: {note}")
    return {"ok": True, "status": status}


# ================================================================ 随机审计
@router.get("/sample")
def sample_list() -> dict:
    rows = db.q("SELECT b.*, (SELECT count(*) FROM sample_item i WHERE i.batch_id=b.id "
                "AND i.result<>'pending') done_n FROM sample_batch b ORDER BY b.id DESC LIMIT 50")
    done = db.q1("SELECT count(*) n FROM sample_item WHERE result<>'pending' "
                 "AND reviewed_at>=datetime('now','localtime','-30 day')")["n"]
    miss = db.q1("SELECT count(*) n FROM sample_item WHERE result='miss' "
                 "AND reviewed_at>=datetime('now','localtime','-30 day')")["n"]
    return {"batches": rows,
            "miss_rate": {"audited": done, "miss": miss,
                          "rate": round(miss / done, 4) if done else None},
            "population_note": "自动通过总体 = 已解析且最近一轮 table_audit 无 unresolved/badge"
                               "、无未处置风险 case 的件；从未审计的件不算自动通过"}


@router.post("/sample/create")
def sample_create(payload: dict = Body(...)) -> dict:
    n = int(payload.get("n") or 30)
    days = int(payload.get("days") or 30)
    method = str(payload.get("method") or "random")
    if not 1 <= n <= 200:
        raise HTTPException(400, "抽样数量 1-200")
    r = GS.stratified_sample(n, days=days, method=method)
    if not r["pick"]:
        raise HTTPException(400, "自动通过总体为空 —— 先跑一轮自动化 QC（sample 模式）")
    code = f"RA-{db.qc_now()[:10].replace('-', '')}-{db.q1('SELECT count(*)+1 n FROM sample_batch')['n']:03d}"
    bid = db.x("INSERT INTO sample_batch(code,population,method,n,seed,snapshot,status,"
               "operator,created_at) VALUES(?,?,?,?,?,?, 'open',?,?)",
               (code, f"近 {days} 天自动 QC 通过（总体 {r['population_n']} 件）",
                method, len(r["pick"]), r["seed"], r["snapshot"], _op(), db.qc_now()))
    for m in r["pick"]:
        db.x("INSERT INTO sample_item(batch_id,mpn) VALUES(?,?)", (bid, m))
    db.add_event(f"QE 随机审计批次 {code}：{len(r['pick'])} 件（种子留档）", kind="qc")
    return {"batch_id": bid, "code": code, "n": len(r["pick"]),
            "population_n": r["population_n"], "seed": r["seed"]}


@router.get("/sample/{batch_id}")
def sample_detail(batch_id: int) -> dict:
    b = db.q1("SELECT * FROM sample_batch WHERE id=?", (batch_id,))
    if not b:
        raise HTTPException(404, "批次不存在")
    items = db.q("SELECT * FROM sample_item WHERE batch_id=? ORDER BY id", (batch_id,))
    return {"batch": b, "items": items,
            "blind": "盲审：核验界面不展示置信度与风险评分，降低确认偏差"}


@router.post("/sample/{batch_id}/review")
def sample_review(batch_id: int, payload: dict = Body(...)) -> dict:
    """人工判定单件：pass（无漏报）/ miss（发现漏报，可勾选转反馈闭环）。"""
    it = db.q1("SELECT * FROM sample_item WHERE id=? AND batch_id=?",
               (int(payload.get("item_id") or 0), batch_id))
    if not it:
        raise HTTPException(404, "样本条目不存在")
    result = str(payload.get("result") or "").strip()
    if result not in ("pass", "miss", "pending"):
        raise HTTPException(400, "result 仅支持 pass / miss / pending")
    note = str(payload.get("note") or "").strip()
    db.x("UPDATE sample_item SET result=?, note=?, operator=?, reviewed_at=? WHERE id=?",
         (result, note, _op(), db.qc_now(), it["id"]))
    done = db.q1("SELECT count(*) n FROM sample_item WHERE batch_id=? "
                 "AND result<>'pending'", (batch_id,))["n"]
    defects = db.q1("SELECT count(*) n FROM sample_item WHERE batch_id=? "
                    "AND result='miss'", (batch_id,))["n"]
    total = db.q1("SELECT n FROM sample_batch WHERE id=?", (batch_id,))["n"]
    db.x("UPDATE sample_batch SET done=?, defects=?, status=? WHERE id=?",
         (done, defects, "done" if done >= total else "open", batch_id))
    fid = 0
    if result == "miss" and payload.get("to_feedback"):
        kind = str(payload.get("kind") or "missed_defect").strip()
        fid = _new_feedback(mpn=it["mpn"], kind=kind, source="random_audit",
                            note=note or "随机审计发现漏报")
    return {"ok": True, "done": done, "defects": defects, "feedback_id": fid}


# ================================================================ 引擎对比
@router.get("/engines")
def engines_report() -> dict:
    last = db.kv_json("qe_engine_report")
    # 现有 A/B 报告摘要（qc/ab_odl.py 产物，非 Gold 准确率）
    ab = None
    try:
        reps = sorted((config.DATA / "qc" / "ab_odl").glob("ab_report-*.json"),
                      key=lambda p: p.stat().st_mtime)
        if reps:
            d = json.loads(reps[-1].read_text(encoding="utf-8"))
            ab = {"file": reps[-1].name, "total": d.get("total"),
                  "label_a": d.get("label_a"), "label_b": d.get("label_b")}
    except Exception:                                    # noqa: BLE001
        ab = None
    return {"last": last, "ab_report": ab,
            "engines": list(GS.ENGINE_DIRS),
            "note": "同一 PDF / 同一 LLM / 同一提示词 / 同一 QC 规则，唯一变量是抽取引擎；"
                    "结论边界：finding 数不是错误率，字段准确率只对 Gold Set(frozen×verified) 计算"}


@router.post("/engines/compare")
def engines_compare() -> dict:
    r = GS.compare_engines(version=GOLD_VERSION)
    db.kv_set("qe_engine_report", json.dumps(r, ensure_ascii=False))
    db.add_event(f"QE 引擎对比：{r['n_gold']} 件 Gold × {len(r['engines'])} 引擎", kind="qc")
    return r


# ================================================================ 反馈闭环
def _new_feedback(mpn: str, kind: str, source: str, note: str = "",
                  gold_evidence: str = "") -> int:
    code = f"QC-REG-{db.q1('SELECT count(*)+1 n FROM feedback_case')['n']:03d}"
    ts = db.qc_now()
    fid = db.x("INSERT INTO feedback_case(code,source,mpn,kind,gold_evidence,status,"
               "note,operator,created_at,updated_at) "
               "VALUES(?,?,?,?,?,'pending',?,?,?,?)",
               (code, source, mpn, kind, gold_evidence or "等待二次复核", note,
                _op(), ts, ts))
    db.add_event(f"QE 反馈用例 {code}：{mpn} {kind}（来源 {source}）", kind="qc")
    return fid


@router.get("/feedback")
def feedback_list(status: str = "", q: str = "") -> dict:
    where, args = ["1=1"], []
    if status:
        where.append("f.status=?"); args.append(status)
    if q:
        where.append("(f.mpn LIKE ? OR f.code LIKE ? OR f.kind LIKE ?)")
        args += [f"%{q}%"] * 3
    rows = db.q(f"SELECT * FROM feedback_case f WHERE {' AND '.join(where)} "
                f"ORDER BY f.id DESC LIMIT 200", args)
    last_reg = db.q1("SELECT * FROM qc_run WHERE mode='regression' "
                     "ORDER BY id DESC LIMIT 1") or {}
    return {"items": rows,
            "stats": {
                "pending": db.q1("SELECT count(*) n FROM feedback_case "
                                 "WHERE status='pending'")["n"],
                "fixture": db.q1("SELECT count(*) n FROM feedback_case "
                                 "WHERE status='fixture'")["n"],
                "fail": db.q1("SELECT count(*) n FROM feedback_case "
                              "WHERE status='fail'")["n"],
                "passed": db.q1("SELECT count(*) n FROM feedback_case "
                                "WHERE status='passed'")["n"]},
            "last_regression": last_reg,
            "fixtures_file": str(GS.FIXTURE_PATH),
            "gate": "执行错误/样本未运行/未核实字段不得计入 PASS；"
                    "P0 回归失败阻断相关字段发布"}


@router.post("/feedback")
def feedback_create(payload: dict = Body(...)) -> dict:
    mpn = str(payload.get("mpn") or "").strip()
    if not mpn:
        raise HTTPException(400, "mpn 必填")
    fid = _new_feedback(mpn, str(payload.get("kind") or ""),
                        str(payload.get("source") or "manual"),
                        str(payload.get("note") or ""),
                        str(payload.get("gold_evidence") or ""))
    return {"feedback_id": fid}


@router.post("/feedback/{fid}/to-fixture")
def feedback_to_fixture(fid: int) -> dict:
    """转回归用例：从 Gold 标准答案自动生成断言，导出到 regression_fixtures.json。"""
    f = db.q1("SELECT * FROM feedback_case WHERE id=?", (fid,))
    if not f:
        raise HTTPException(404, "反馈用例不存在")
    if f["status"] not in ("pending", "fail"):
        raise HTTPException(400, f"当前状态 {f['status']} 不可转夹具（pending/fail 才可）")
    r = GS.export_fixture({"mpn": f["mpn"], "kind": f["kind"], "code": f["code"],
                           "source": f["source"]}, db_mod=db)
    db.x("UPDATE feedback_case SET status='fixture', fixture=?, updated_at=? WHERE id=?",
         (json.dumps({"path": r["path"], "asserts": r["asserts"]}, ensure_ascii=False),
          db.qc_now(), fid))
    db.add_event(f"QE {f['code']} 转回归夹具：{r['asserts']} 条断言", kind="qc")
    return r


@router.post("/feedback/{fid}/run")
def feedback_run(fid: int, payload: dict = Body(...)) -> dict:
    """重跑回归（防回归）：--extra 附加夹具 + 11 件基础夹具一起跑。

    post=true 用修补后口径（期望缺陷已消失）；默认修补前口径（期望捕获到缺陷）。
    """
    f = db.q1("SELECT * FROM feedback_case WHERE id=?", (fid,))
    if not f:
        raise HTTPException(404, "反馈用例不存在")
    if f["status"] != "fixture":
        raise HTTPException(400, "先转回归用例（fixture）再运行")
    post = bool(payload.get("post"))
    extra = str(GS.FIXTURE_PATH)
    if not Path(extra).exists():
        raise HTTPException(400, f"夹具文件不存在：{extra}")
    try:
        n_extra = len(json.loads(Path(extra).read_text(encoding="utf-8")))
    except Exception:                                    # noqa: BLE001
        raise HTTPException(400, "附加夹具 JSON 损坏，请先在反馈列表检查导出内容")
    run_id = db.x("INSERT INTO qc_run(mode,scope,dry,parts,status,operator,created_at) "
                  "VALUES('regression','qe_feedback',1,?,'running',?,?)",
                  (11 + n_extra, _op(), db.qc_now()))
    dispatch.submit("qc_regression_tick", run_id, False, _op(), extra, post)
    return {"run_id": run_id, "queued": True, "post": post}


@router.post("/feedback/{fid}/status")
def feedback_status(fid: int, payload: dict = Body(...)) -> dict:
    """闭环状态推进（人工）：fixture → fail（回归失败）/ passed（已修复）/ closed。"""
    f = db.q1("SELECT * FROM feedback_case WHERE id=?", (fid,))
    if not f:
        raise HTTPException(404, "反馈用例不存在")
    status = str(payload.get("status") or "").strip()
    if status not in ("pending", "fixture", "fail", "passed", "closed"):
        raise HTTPException(400, "status 仅支持 pending/fixture/fail/passed/closed")
    db.x("UPDATE feedback_case SET status=?, updated_at=? WHERE id=?",
         (status, db.qc_now(), fid))
    db.add_event(f"QE 反馈用例 {f['code']} 状态 → {status}", kind="qc")
    return {"ok": True}

# ================================================================ QC 交付历史
def _delivery_base():
    """交付扫描根。`None` = 让 `qc.delivery_history` 用它自己登记的多个根。

    原来这里写死 `data/qc`，于是 1101 起的 `data/delivery-YYYYMMDD-VX`
    一个都扫不到 —— 页面上的「最新批次」永远停在一周前，不是数据丢了，
    是扫描根和产出根不是同一个（AGENT.md §16 定的是 `data/delivery-*`）。
    """
    return None


@router.get("/deliveries")
def deliveries_list() -> dict:
    """按批次列出交付包（只读）；附带客户反馈计数。"""
    batches = DH.list_batches(_delivery_base())
    fmap = FB.batch_map(db, [b["id"] for b in batches])
    for b in batches:
        b["feedback"] = fmap.get(b["id"], {
            "issues": 0, "open_issues": 0, "blocking": 0, "samples": 0,
            "pending_acceptance": 0, "release_blocked": False})
    # 「最新批次」由后端给定，前端不要自己再取 max(date)：同日多版本
    # （V2/V3 都是 2026-11-02）按日期取会取到 V2，而列表第一是 V3。
    latest = batches[0]["id"] if batches else ""
    return {"batches": batches, "latest": latest,
            "total": len(batches)}


@router.get("/deliveries/{batch_id}")
def delivery_detail(batch_id: str) -> dict:
    b = DH.get_batch(batch_id, _delivery_base())
    if not b:
        raise HTTPException(404, "交付批次不存在")
    b["feedback"] = FB.batch_summary(db, batch_id)
    return b


# ------------------------------------------------ review-fix 状态汇总
# 状态推导在 qc/review_status.py（纯函数）；这里只负责汇总与「分批追加到交付历史」。
@router.get("/review-fix/summary")
def review_fix_summary() -> dict:
    from qc import review_fix as RF
    st = RF.summary(_delivery_base())
    st["next_batch_size"] = 30
    st["note"] = ("状态只看最近一次复审的有效 findings：P0>0 阻断 / 只有 P1 警告 / "
                  "都没有才是机器检查通过；证据不足单列。任何状态都不等于发布批准。")
    return st


@router.post("/review-fix/batches")
def review_fix_batches(payload: dict = Body(...)) -> dict:
    """把「已 review、尚未成批」的型号按 size 一批物化成交付批次（追加到列表）。

    幂等：已进过批次的型号不会再进第二个批次（索引 data/qc/review_fix_index.json）。
    `dry_run=true` 只算分片不落盘。
    """
    from qc import review_fix as RF
    size = int(payload.get("size") or 30)
    max_batches = int(payload.get("max_batches") or 1)
    dry = bool(payload.get("dry_run"))
    if not 1 <= size <= 200:
        raise HTTPException(400, "size 仅支持 1–200")
    if not 1 <= max_batches <= 50:
        raise HTTPException(400, "max_batches 仅支持 1–50")
    out = RF.build_next(_delivery_base(), size=size, max_batches=max_batches,
                        data_dir=config.DATA, dry_run=dry)
    if not dry and out.get("built"):
        ids = ", ".join(b["batch"] for b in out["built"])
        db.add_event(f"review-fix 分批交付 {ids}", kind="qc")
    return out


@router.get("/deliveries/{batch_id}/report.html")
def delivery_report_html(batch_id: str):
    from fastapi.responses import HTMLResponse
    from qc import mdpreview as MP
    b = DH.get_batch(batch_id, _delivery_base())
    got = DH.report_md(batch_id, _delivery_base())
    if not b or not got:
        raise HTTPException(404, "该批次没有核验报告")
    md, _name = got
    layers = b.get("layers") or {}
    sub = " · ".join("%s %s" % (k, (layers.get(k) or {}).get("status") or "—")
                     for k in ("L1", "L2", "L3", "L4"))
    return HTMLResponse(MP.to_html(
        md, title="QC 交付核验报告 · %s" % b["id"],
        subtitle="%s · %s（%s）" % (", ".join(b["mpns"]), sub, b.get("verdict") or "")))


@router.get("/deliveries/{batch_id}/report.md")
def delivery_report_md(batch_id: str):
    from fastapi.responses import Response
    got = DH.report_md(batch_id, _delivery_base())
    if not got:
        raise HTTPException(404, "该批次没有核验报告")
    md, _name = got
    return Response(md, media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition":
                             'attachment; filename="%s-report.md"' % batch_id})


@router.get("/deliveries/{batch_id}/zip")
def delivery_zip(batch_id: str):
    from fastapi.responses import FileResponse
    z = DH.zip_path(batch_id, _delivery_base())
    if not z:
        raise HTTPException(404, "该批次没有交付 ZIP")
    return FileResponse(str(z), media_type="application/zip", filename=z.name)


# ------------------------------------------------ 人工核对截图（批次留痕）
_MAX_SHOT = 8 * 1024 * 1024          # 单张 8MB
_MAX_SHOTS = 12                      # 单次最多 12 张
_IMG_MEDIA = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
              ".webp": "image/webp", ".gif": "image/gif"}


@router.get("/deliveries/{batch_id}/manual-review")
def delivery_manual_list(batch_id: str) -> dict:
    if not DH.get_batch(batch_id, _delivery_base()):
        raise HTTPException(404, "交付批次不存在")
    return {"batch": batch_id, "items": DH.list_manual(batch_id, _delivery_base()),
            "note": "人工核对截图是留痕，不自动改变 L3/发布门禁结论"}


@router.get("/deliveries/{batch_id}/manual-review/{name}")
def delivery_manual_file(batch_id: str, name: str):
    from fastapi.responses import FileResponse
    p = DH.manual_path(batch_id, name, _delivery_base())
    if not p:
        raise HTTPException(404, "截图不存在")
    media = _IMG_MEDIA.get(p.suffix.lower(), "application/octet-stream")
    return FileResponse(str(p), media_type=media)


@router.post("/deliveries/{batch_id}/manual-review")
async def delivery_manual_upload(batch_id: str,
                                 files: list[UploadFile] = File(...)) -> dict:
    if not DH.get_batch(batch_id, _delivery_base()):
        raise HTTPException(404, "交付批次不存在")
    saved, errors = [], []
    for f in files[:_MAX_SHOTS]:
        name = f.filename or ""
        data = await f.read(_MAX_SHOT + 1)
        await f.close()
        if len(data) > _MAX_SHOT:
            errors.append({"name": name, "error": "超过单张 8MB 限制"})
            continue
        try:
            saved.append(DH.save_manual(batch_id, name, data, _delivery_base()))
        except ValueError as e:
            errors.append({"name": name, "error": str(e)})
    if len(files) > _MAX_SHOTS:
        errors.append({"name": "", "error": "单次最多上传 %d 张，多余文件已忽略"
                                            % _MAX_SHOTS})
    return {"saved": saved, "errors": errors,
            "items": DH.list_manual(batch_id, _delivery_base())}
