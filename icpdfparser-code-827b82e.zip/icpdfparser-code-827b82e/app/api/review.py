"""review 路由（/api/qe/review/v1）：单型号交付物红线质量审查。

规则先过、LLM 兜底；只读产物，报告落 data/qc/reviews/，
write_db 仅 append qc_audit_log / llm_usage（append-only 台账）。
"""
from __future__ import annotations

from fastapi import APIRouter, Body, HTTPException, Query
from fastapi.responses import HTMLResponse, Response

from .. import auth, config, db
from ..services import review as RV

router = APIRouter(prefix="/api/qe/review/v1")


def _op() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _out_dir():
    return config.DATA / "qc" / "reviews"


def _wrap(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except RV.ReviewError as e:
        raise HTTPException(e.http_status, e.message)


@router.get("/meta")
def review_meta() -> dict:
    cfg = RV.env_config()
    reports = RV.list_reports(_out_dir(), limit=500)
    return {
        "review_version": RV.REVIEW_VERSION,
        "rule_version": RV.RULE_VERSION,
        "model": cfg["model"],
        "llm_available": bool(cfg["key"]),
        "out_dir": str(_out_dir()),
        "report_count": len(reports),
        "verdicts": ["FAIL", "WARN", "PASS"],
        "board_tokens": list(RV.BOARD_TOKENS),
        "rule_kinds": [
            "identity_board_unresolved", "board_package_mismatch",
            "board_identity_missing", "mpn_rewritten",
            "double_escape_multi", "escape_entity_in_json",
            "pin_pair_broken", "pin_polarity_missing",
            "electrical_field_missing", "unit_duplicated",
            "i18n_english_residue", "hero_overview_duplicate",
        ],
        "caveats": RV.CAVEATS,
    }


@router.post("/run")
def review_run(payload: dict = Body(default={})) -> dict:
    mpn = str(payload.get("mpn") or "").strip()
    dry_run = bool(payload.get("dry_run"))
    if not mpn:
        raise HTTPException(400, "mpn 不能为空")
    cfg = RV.env_config()
    if not dry_run and not cfg.get("key"):
        raise HTTPException(400, "DASHSCOPE_API_KEY 未设置；可用 dry_run=true 只跑规则层")
    return _wrap(
        RV.run_review, db, mpn,
        data_dir=config.DATA, out_dir=_out_dir(),
        with_pdf_text=bool(payload.get("with_pdf_text")),
        dry_run=dry_run,
        force=bool(payload.get("force")),
        write_db=not dry_run,                       # 台账只记完整审查
        operator=_op(), cfg=cfg)


@router.get("/reports")
def review_reports(limit: int = Query(100, ge=1, le=500)) -> dict:
    return {"items": RV.list_reports(_out_dir(), limit)}


@router.get("/reports/{safe}")
def review_report(safe: str) -> dict:
    d = RV.get_report(_out_dir(), safe)
    if not d:
        raise HTTPException(404, "审计报告不存在：先运行审计")
    return d


@router.get("/reports/{safe}/report.md")
def review_report_md(safe: str) -> Response:
    d = RV.get_report(_out_dir(), safe)
    if not d:
        raise HTTPException(404, "审计报告不存在：先运行审计")
    name = f"review_{RV._safe_stem(d.get('mpn') or safe)}.md"
    return Response(RV.render_md(d).encode("utf-8"),
                    media_type="text/markdown; charset=utf-8",
                    headers={"Content-Disposition":
                             'attachment; filename="%s"' % name})


@router.get("/reports/{safe}/report.html")
def review_report_html(safe: str) -> HTMLResponse:
    d = RV.get_report(_out_dir(), safe)
    if not d:
        raise HTTPException(404, "审计报告不存在：先运行审计")
    return HTMLResponse(RV.render_html(d))
