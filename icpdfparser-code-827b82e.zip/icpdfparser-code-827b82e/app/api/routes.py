"""工作台 API 路由。

约定：
  * 所有写操作都返回 JSON，前端据此刷新；
  * 产物下载一律通过 /api/exports/{name} 与 /api/items/{key}/artifact/{kind}，
    路径只从库里取，不接受任意文件路径，避免目录穿越。
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import time
from pathlib import Path

from fastapi import APIRouter, Body, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response

from .. import config, db, preview
from ..services import (catalog_index, collector, dispatch, images, packager, parts,
                        pipeline)

router = APIRouter(prefix="/api")

ALLOWED_PART_EXT = {".xlsx", ".xls", ".xlsm", ".csv", ".txt"}
ALLOWED_TABLE_EXT = {".xlsx", ".xls", ".xlsm"}
SAFE_FILE = re.compile(r"^[^\\/:*?\"<>|]+$")


# ---------------------------------------------------------------- 工具
async def _save_upload(file: UploadFile, kind: str) -> tuple[Path, str]:
    name = Path(file.filename or f"{kind}.bin").name
    if not SAFE_FILE.match(name):
        raise HTTPException(400, "文件名包含非法字符")
    ext = Path(name).suffix.lower()
    allowed = ALLOWED_PART_EXT if kind == "parts" else ALLOWED_TABLE_EXT
    if ext not in allowed:
        raise HTTPException(400, f"不支持的文件类型 {ext}，允许：{', '.join(sorted(allowed))}")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = config.UPLOADS / f"{stamp}_{name}"
    h = hashlib.sha256()
    size = 0
    with open(dest, "wb") as fh:
        while True:
            chunk = await file.read(1 << 20)
            if not chunk:
                break
            fh.write(chunk)
            h.update(chunk)
            size += len(chunk)
    await file.close()
    if size == 0:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, "上传的文件是空的")
    return dest, h.hexdigest()


def _item_or_404(key: str) -> dict:
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (key,))
    if not item:
        raise HTTPException(404, "型号不存在")
    return item


def _artifact_path(item: dict, kind: str) -> Path:
    mapping = {
        "pdf": "pdf_path", "json": "json_path", "txt": "txt_path",
        "alt_json": "alt_json_path", "alt_html": "alt_html_path",
        "symbol": "symbol_path", "seo": "seo_path",
    }
    # 详情页多语言变体：txt_ja / txt_ko / txt_de / txt_es
    if kind.startswith("txt_") and kind[4:] in packager.I18N_LANGS:
        lang = kind[4:]
        base = _artifact_path(item, "txt")
        variant = base.with_name(f"{base.stem}.{lang}.txt")
        if not variant.exists():
            raise HTTPException(404, "该语言变体尚未生成")
        return variant
    col = mapping.get(kind)
    if not col:
        raise HTTPException(404, "未知产物类型")
    p = (item.get(col) or "").strip()
    if not p:
        raise HTTPException(404, "该产物尚未生成")
    # 库里存的是落库机器的绝对路径，跨机部署后按目录+文件名回退解析
    path = config.resolve_artifact(p, config.ARTIFACT_DIRS[col])
    if not path.exists():
        raise HTTPException(404, "该产物尚未生成")
    return path


# ---------------------------------------------------------------- 系统
@router.get("/health")
def health() -> dict:
    cat = catalog_index.catalog_stats()
    return {
        "ok": True,
        "mode": dispatch.mode(),
        "redis": config.REDIS_URL,
        "redis_ok": dispatch.redis_ok(force=True),
        "queue": config.CELERY_QUEUE,
        "queues": dispatch.queue_depths(),
        "workers": config.LLM_WORKERS,
        "worker_roles": {"llm": config.LLM_WORKERS, "fetch": config.FETCH_WORKERS,
                         "render": config.RENDER_WORKERS},
        "aggregator": config.AGGREGATOR_ENABLED,
        "catalog": cat,
        "images": {
            "categories": len(db.q("SELECT 1 FROM app_image")),
            "source": db.kv_get("images_source", ""),
            "imported_at": db.kv_get("images_imported_at", ""),
            "csv": config.APP_IMG_CSV.exists(),
        },
        "pkgs": {
            "keys": len(list(config.PKGS.glob("*.3d.svg"))),
        },
        "uploads": [{"name": p.name, "mb": round(p.stat().st_size / 1048576, 1),
                     "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))}
                    for p in sorted(config.UPLOADS.glob("*"), key=lambda x: -x.stat().st_mtime)
                    if p.is_file()][:12],
    }


@router.get("/overview")
def overview() -> dict:
    rows = db.q("SELECT status, count(*) n FROM item GROUP BY status")
    by = {r["status"]: r["n"] for r in rows}
    total = sum(by.values())
    done = by.get("done", 0)
    running = sum(by.get(k, 0) for k in ("queued", "resolving", "downloading", "parsing", "rendering"))
    parsed = db.q1("SELECT count(*) n, coalesce(sum(pdf_bytes),0) bytes FROM item "
                   "WHERE last_parsed_at<>''") or {"n": 0, "bytes": 0}
    return {
        "total": total, "done": done, "running": running,
        "failed": by.get("failed", 0), "nodata": by.get("nodata", 0),
        "skipped": by.get("skipped", 0), "pending": by.get("pending", 0),
        "by_status": by,
        "parsed_count": parsed["n"],
        "pdf_mb": round((parsed["bytes"] or 0) / 1048576, 1),
        "mode": dispatch.mode(),
        "recent": db.q("SELECT id,item_id,batch_id,kind,message,created_at FROM event "
                       "ORDER BY id DESC LIMIT 12"),
    }


@router.get("/events")
def events(limit: int = Query(50, ge=1, le=500), item_id: int = 0) -> list[dict]:
    if item_id:
        return db.q("SELECT * FROM event WHERE item_id=? ORDER BY id DESC LIMIT ?", (item_id, limit))
    return db.q("SELECT * FROM event ORDER BY id DESC LIMIT ?", (limit,))


@router.get("/usage/summary")
def usage_summary(days: int = Query(7, ge=0, le=365)) -> dict:
    """模型调用记账汇总。days=0 表示全部历史。"""
    from ..services import usage
    return usage.summary(days)


# ---------------------------------------------------------------- 上传
@router.post("/uploads/parts")
async def upload_parts(file: UploadFile = File(...), auto_start: bool = False,
                       force: bool = False) -> dict:
    path, sha = await _save_upload(file, "parts")
    try:
        info = pipeline.ingest_parts(path, Path(file.filename or path.name).name, sha)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(400, f"型号表解析失败：{e}") from e
    result = {"batch_id": info["batch_id"], "rows": info["rows"],
              "created": info["created"], "reused": info["reused"],
              "truncated": info.get("truncated", False), "cap": info.get("cap", 0),
              "queued": 0, "mode": ""}
    if auto_start:
        queued = _queue({"batch_id": info["batch_id"], "force": force, "only": "pending"})
        result.update(queued)
    return result


@router.post("/uploads/catalog")
async def upload_catalog(file: UploadFile = File(...), rebuild: bool = True) -> dict:
    path, sha = await _save_upload(file, "catalog")
    batch_id = db.x(
        "INSERT INTO batch (kind,filename,stored_path,sha256,total_rows,unique_mpns,status,"
        "progress,note,created_at) VALUES ('catalog',?,?,?,0,0,'pending',0,'等待建索引',?)",
        (Path(file.filename or path.name).name, str(path), sha, db.now()))
    if not rebuild:
        return {"batch_id": batch_id, "message": "已保存，未重建索引"}
    r = dispatch.submit("build_catalog", batch_id, str(path))
    return {"batch_id": batch_id, **r}


@router.post("/uploads/images")
async def upload_images(file: UploadFile = File(...)) -> dict:
    """应用领域图片命名表：同步导入（秒级），立即生效。"""
    path, sha = await _save_upload(file, "images")
    batch_id = db.x(
        "INSERT INTO batch (kind,filename,stored_path,sha256,total_rows,unique_mpns,status,"
        "progress,note,created_at) VALUES ('images',?,?,?,0,0,'running',0,'导入命名表',?)",
        (Path(file.filename or path.name).name, str(path), sha, db.now()))
    try:
        info = images.import_table(path, batch_id=batch_id)
    except Exception as e:                                       # noqa: BLE001
        db.x("UPDATE batch SET status='failed', note=? WHERE id=?", (str(e)[:400], batch_id))
        raise HTTPException(400, f"命名表导入失败：{e}") from e
    db.x("UPDATE batch SET status='ready', progress=100, note=? WHERE id=?",
         (f"{info['categories']} 类", batch_id))
    return {"batch_id": batch_id, **info}


# ---------------------------------------------------------------- 模板
@router.get("/template/model-table")
def template_model_table() -> FileResponse:
    """下载型号表模板：型号 / 品牌 / 封装 / 包装 / 产品描述 / PDF链接。"""
    dest = config.TEMPLATES / "型号表模板.xlsx"
    if not dest.exists():
        parts.write_template(dest)
    return FileResponse(
        dest, filename="型号表模板.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------------------------------------------------------------- 批次
@router.get("/batches")
def batches(limit: int = Query(50, ge=1, le=200)) -> list[dict]:
    rows = db.q("SELECT * FROM batch ORDER BY id DESC LIMIT ?", (limit,))
    for r in rows:
        if r["kind"] == "parts":
            c = db.q1("SELECT count(*) n FROM item_batch WHERE batch_id=?", (r["id"],))
            r["items"] = c["n"] if c else 0
    return rows


@router.post("/batches/{batch_id}/export")
def batch_export(batch_id: int) -> dict:
    b = db.q1("SELECT * FROM batch WHERE id=?", (batch_id,))
    if not b:
        raise HTTPException(404, "批次不存在")
    return dispatch.submit("export_batch", batch_id, b["filename"])


@router.get("/batches/{batch_id}/export")
def batch_export_status(batch_id: int) -> dict:
    raw = db.kv_get(f"export:batch:{batch_id}", "")
    if not raw:
        return {"ready": False}
    try:
        info = json.loads(raw)
    except json.JSONDecodeError:
        return {"ready": False}
    p = Path(info.get("path", ""))
    if not p.exists():
        return {"ready": False}
    return {"ready": True, "name": p.name, "mb": round(p.stat().st_size / 1048576, 2),
            "url": f"/api/exports/{p.name}", "at": info.get("at", "")}


# ---------------------------------------------------------------- 型号列表
@router.get("/items/export.csv")
def export_csv(status: str = "") -> Response:
    sql = ("SELECT mpn,mpn_key,brand,status,provider,pdf_url,pdf_sha256,pdf_bytes,"
           "last_parsed_at,parse_count,parse_ms,error FROM item")
    args: list = []
    if status:
        sql += " WHERE status=?"
        args.append(status)
    sql += " ORDER BY updated_at DESC"
    rows = db.q(sql, args)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["型号", "归一化", "品牌", "状态", "采集来源", "Datasheet 链接", "PDF SHA256",
                "PDF 字节", "最近解析时间", "解析次数", "解析耗时(ms)", "备注"])
    for r in rows:
        w.writerow([r["mpn"], r["mpn_key"], r["brand"], r["status"], r["provider"],
                    r["pdf_url"], r["pdf_sha256"], r["pdf_bytes"], r["last_parsed_at"],
                    r["parse_count"], r["parse_ms"], r["error"]])
    csv_bytes = buf.getvalue().encode("utf-8-sig")
    return Response(csv_bytes, media_type="text/csv",
                    headers={"Content-Disposition":
                             f'attachment; filename="icpdf-items-{time.strftime("%Y%m%d-%H%M")}.csv"'})


@router.get("/items")
def list_items(q: str = "", status: str = "", batch_id: str = "", page: int = Query(1, ge=1),
               size: int = Query(20, ge=1, le=200), sort: str = "updated") -> dict:
    bid = int(batch_id) if str(batch_id).strip().isdigit() else 0
    where, args = [], []
    if q:
        where.append("(mpn LIKE ? OR mpn_key LIKE ? OR brand LIKE ?)")
        like = f"%{q.strip()}%"
        args += [like, like.upper(), like]
    if status:
        where.append("status=?")
        args.append(status)
    if bid:
        where.append("id IN (SELECT item_id FROM item_batch WHERE batch_id=?)")
        args.append(bid)
    wsql = (" WHERE " + " AND ".join(where)) if where else ""
    order = {"updated": "updated_at DESC", "mpn": "mpn ASC",
             "parsed": "last_parsed_at DESC", "status": "status ASC"}.get(sort, "updated_at DESC")
    total = db.q1(f"SELECT count(*) n FROM item{wsql}", args)["n"]
    rows = db.q(f"SELECT * FROM item{wsql} ORDER BY {order} LIMIT ? OFFSET ?",
                (*args, size, (page - 1) * size))
    for r in rows:
        try:
            meta = json.loads(r.get("meta") or "{}")
        except json.JSONDecodeError:
            meta = {}
        r["meta"] = meta
        r["ready"] = sum(1 for k in ("pdf_path", "json_path", "txt_path", "alt_json_path",
                                     "alt_html_path", "symbol_path", "seo_path") if r.get(k))
        r["status_text"] = db.STATUS_TEXT.get(r["status"], r["status"])
        r.pop("meta_raw", None)
    return {"total": total, "page": page, "size": size, "items": rows}


@router.get("/items/{key}")
def item_detail(key: str) -> dict:
    item = _item_or_404(key)
    try:
        item["meta"] = json.loads(item.get("meta") or "{}")
    except json.JSONDecodeError:
        item["meta"] = {}
    item["status_text"] = db.STATUS_TEXT.get(item["status"], item["status"])
    item["bundle"] = packager.summary(item)
    item["sources"] = collector.sources(key)
    item["events"] = db.q("SELECT * FROM event WHERE item_id=? ORDER BY id DESC LIMIT 40",
                          (item["id"],))
    item["batches"] = db.q("SELECT b.id,b.filename,b.created_at FROM batch b "
                           "JOIN item_batch ib ON ib.batch_id=b.id WHERE ib.item_id=?",
                           (item["id"],))
    return item


# ---------------------------------------------------------------- 投递解析
# 「解析未完成」口径 = 全部非终态（含停机残留的中间态 queued/resolving/downloading/
# parsing/rendering），这样 worker 停机/换机后 UI 一键即可续跑，无需先修数据
PENDING_STATUS = ("pending", "queued", "resolving", "downloading",
                  "parsing", "rendering", "failed", "nodata")
_PENDING_SQL = "('" + "','".join(PENDING_STATUS) + "')"


def _queue(payload: dict) -> dict:
    """把一批型号投递到 Celery（或降级线程池）。

    范围优先级：显式 mpn_keys（勾选）> batch_id（批次）> filter（当前筛选）。
    无论哪条路径，`only=pending` 都只挑「未完成」的型号，已 done 的不会重跑。
    """
    force = bool(payload.get("force"))
    only = (payload.get("only") or "").strip()
    keys: list[str] = list(payload.get("mpn_keys") or [])
    filt = payload.get("filter") or {}

    if keys:
        marks = ",".join("?" * len(keys))
        rows = db.q(f"SELECT mpn_key,status FROM item WHERE mpn_key IN ({marks})", tuple(keys))
        if only == "pending":
            rows = [r for r in rows if r["status"] in PENDING_STATUS]
        elif only == "failed":
            rows = [r for r in rows if r["status"] == "failed"]
        keys = [r["mpn_key"] for r in rows]
    else:
        where, args = [], []
        if payload.get("batch_id"):
            where.append("id IN (SELECT item_id FROM item_batch WHERE batch_id=?)")
            args.append(payload["batch_id"])
        if (filt.get("q") or "").strip():
            like = f"%{filt['q'].strip()}%"
            where.append("(mpn LIKE ? OR mpn_key LIKE ? OR brand LIKE ?)")
            args += [like, like.upper(), like]
        if (filt.get("status") or "").strip():
            where.append("status=?")
            args.append(filt["status"].strip())
        if only == "pending":
            where.append(f"status IN {_PENDING_SQL}")
        elif only == "failed":
            where.append("status='failed'")
        sql = "SELECT mpn_key FROM item" + (" WHERE " + " AND ".join(where) if where else "")
        keys = [r["mpn_key"] for r in db.q(sql + " ORDER BY id", args)]

    if not keys:
        return {"queued": 0, "mode": dispatch.mode(), "message": "没有符合条件的型号",
                "hint": "已完成的型号不会重复解析；要重跑请在列表勾选后用「解析选中」并选择强制重跑"}

    # 安全网：没显式 force 时，已完成的型号绝不重投 —— 否则会被 run_item 判成「跳过」，
    # 把「已完成」翻成「跳过」，看起来像数据被改坏了。
    if not force:
        marks = ",".join("?" * len(keys))
        done = {r["mpn_key"] for r in db.q(
            f"SELECT mpn_key FROM item WHERE mpn_key IN ({marks}) AND status='done'", tuple(keys))}
        keys = [k for k in keys if k not in done]
        if not keys:
            return {"queued": 0, "mode": dispatch.mode(), "message": "选中的型号都已完成",
                    "hint": "要重跑请用「解析选中」并在弹窗里点「确定」（强制重跑）"}

    n = 0
    mode = dispatch.mode()
    for k in keys:
        # 强制重跑时连 done 也要改成 queued，否则界面上看不出任务已投递
        sql = ("UPDATE item SET status='queued', stage='等待执行', progress=1, updated_at=? "
               "WHERE mpn_key=?")
        if not force:
            sql += " AND status<>'done'"
        db.x(sql, (db.now(), k))
        dispatch.submit("fetch_item", k, force, payload.get("manual_url", ""))
        n += 1
    db.add_event(f"投递 {n} 个型号解析任务", kind="queue", batch_id=payload.get("batch_id") or None,
                 detail=f"mode={mode} force={force}")
    return {"queued": n, "mode": mode}


@router.post("/items/parse")
def queue_items(payload: dict = Body(...)) -> dict:
    return _queue(payload)


@router.post("/items/{key}/parse")
def reparse(key: str, payload: dict = Body(default={})) -> dict:
    item = _item_or_404(key)
    manual = (payload.get("manual_url") or "").strip()
    if manual and not manual.lower().startswith("http"):
        raise HTTPException(400, "链接必须以 http/https 开头")
    force = bool(payload.get("force", True))
    db.x("UPDATE item SET status='queued', stage='等待执行', progress=1, error='', updated_at=? "
         "WHERE id=?", (db.now(), item["id"]))
    r = dispatch.submit("fetch_item", key, force, manual)
    db.add_event(("手动补链重解析 " if manual else "重新解析 ") + item["mpn"],
                 kind="queue", item_id=item["id"], detail=manual)
    return {"ok": True, **r}


# ---------------------------------------------------------------- 产物
@router.get("/items/{key}/preview/{kind}", response_class=HTMLResponse)
def preview_artifact(key: str, kind: str) -> HTMLResponse:
    item = _item_or_404(key)
    col = {"txt": "txt_path", "alts": "alt_html_path", "symbols": "symbol_path",
           "json": "json_path", "seo": "seo_path", "alt_json": "alt_json_path"}.get(kind)
    if not col:
        raise HTTPException(404, "未知预览类型")
    p = _artifact_path(item, {"txt_path": "txt", "alt_html_path": "alt_html",
                              "symbol_path": "symbol", "json_path": "json",
                              "seo_path": "seo", "alt_json_path": "alt_json"}[col])
    if p.stat().st_size > config.PREVIEW_MAX_BYTES:
        raise HTTPException(413, "文件过大，请直接下载")
    raw = p.read_text(encoding="utf-8", errors="replace")
    title = {"txt": "详情页片段", "alts": "替代型号内链", "symbols": "三视图",
             "json": "解析 JSON", "seo": "图片 SEO", "alt_json": "替代型号 JSON"}[kind]
    return HTMLResponse(preview.page_for(
        "json" if kind in ("json", "seo", "alt_json") else
        ("symbols" if kind == "symbols" else "txt"), f"{item['mpn']} · {title}", raw))


@router.get("/items/{key}/artifact/{kind}")
def download_artifact(key: str, kind: str) -> FileResponse:
    item = _item_or_404(key)
    p = _artifact_path(item, kind)
    stem = parts.safe_name(item["mpn"])
    return FileResponse(p, filename=f"{stem}{p.suffix}", media_type="application/octet-stream")


@router.post("/items/{key}/export")
def export_item(key: str) -> dict:
    item = _item_or_404(key)
    try:
        p = packager.zip_item(item)
    except Exception as e:                                       # noqa: BLE001
        raise HTTPException(500, f"打包失败：{e}") from e
    db.add_event(f"导出 {item['mpn']} 交付包", kind="export", item_id=item["id"])
    return {"name": p.name, "mb": round(p.stat().st_size / 1048576, 2),
            "url": f"/api/exports/{p.name}"}


@router.get("/exports/{name}")
def download_export(name: str) -> FileResponse:
    if not SAFE_FILE.match(name) or ".." in name:
        raise HTTPException(400, "非法文件名")
    p = config.EXPORTS / name
    if not p.exists():
        raise HTTPException(404, "文件不存在或已过期")
    return FileResponse(p, filename=name, media_type="application/zip")


# ---------------------------------------------------------------- 数据源
@router.get("/images")
def image_table() -> dict:
    return {"rows": images.table(),
            "source": db.kv_get("images_source", ""),
            "imported_at": db.kv_get("images_imported_at", "")}


# ---------------------------------------------------------------- 封装图库（三视图共享）
@router.get("/pkgs/report")
def pkgs_report() -> dict:
    from ..services import pkg_lib
    return pkg_lib.report()


@router.post("/pkgs/backfill")
def pkgs_backfill() -> dict:
    """把已解析型号里缺的封装图一次性补齐（纯本地绘制，不调模型）。"""
    from ..services import pkg_lib
    return pkg_lib.backfill()


@router.post("/catalog/rebuild")
def rebuild_catalog() -> dict:
    candidates = sorted(config.UPLOADS.glob("*.xls"), key=lambda p: -p.stat().st_mtime)
    candidates += sorted(config.UPLOADS.glob("*.xlsx"), key=lambda p: -p.stat().st_mtime)
    if not candidates:
        raise HTTPException(400, "uploads 目录里没有站内目录导出表，请先上传")
    src = candidates[0]
    batch_id = db.x(
        "INSERT INTO batch (kind,filename,stored_path,sha256,total_rows,unique_mpns,status,"
        "progress,note,created_at) VALUES ('catalog',?,?,?,0,0,'pending',0,'重建索引',?)",
        (src.name, str(src), "", db.now()))
    r = dispatch.submit("build_catalog", batch_id, str(src))
    return {"batch_id": batch_id, "source": src.name, **r}
