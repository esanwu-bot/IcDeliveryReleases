"""Agent Lab API 路由。

提供 Chat、工具列表、任务历史、模型配置等接口。
"""
from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app import db
from qc.agent_tools import registry

router = APIRouter(prefix="/api/agent", tags=["agent"])


# ==================== 请求/响应模型 ====================

class ChatRequest(BaseModel):
    message: str
    model: str = "auto"
    mode: str = "dry_run"
    context: dict = {}


class ChatResponse(BaseModel):
    status: str
    task_id: str
    intent: str
    response: str
    tools_called: list[dict] = []
    result: dict = {}


class ToolExecuteRequest(BaseModel):
    tool_name: str
    arguments: dict
    task_id: str = ""


# ==================== Chat 接口 ====================

@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, request: Request):
    """处理自然语言命令，识别意图并执行工具。"""
    from app.services.agent import run_agent_task
    
    # 使用 Agent Loop 执行任务
    result = await run_agent_task(
        user_input=req.message,
        context={
            "model": req.model,
            "mode": req.mode,
            "user_context": req.context,
            "user_id": "agent",
        }
    )
    
    # 提取工具调用链
    tools_called = []
    if "steps" in result:
        for step in result["steps"]:
            tools_called.append({
                "tool": step.get("step", {}).get("tool", ""),
                "arguments": step.get("step", {}).get("arguments", {}),
                "result": step.get("result", {}),
            })
    
    # 生成响应文本
    response_text = _generate_response_from_result(result)
    
    return ChatResponse(
        status=result.get("status", "OK"),
        task_id=result.get("task_id", ""),
        intent=result.get("intent", "GENERAL_QA"),
        response=response_text,
        tools_called=tools_called,
        result=result.get("result", {}),
    )


# ==================== Chat SSE 接口 ====================

def _trim_step_result(payload: dict) -> dict:
    """给前端看的工具结果摘要。

    完整 findings 里每条都带 evidence 原文，批量场景 50 条能到几十 KB，
    而 done 帧只是用来渲染"调了哪些工具"的小面板——正文已经把这些讲清楚了。
    只留标量摘要，别让最后一帧把流式体验拖回去。
    """
    if not isinstance(payload, dict):
        return {}
    keep = ("status", "scope", "mpn", "total", "by_severity",
            "severity_filter", "error", "count")
    out = {k: payload[k] for k in keep if k in payload}
    if isinstance(payload.get("findings"), list):
        out["returned"] = len(payload["findings"])
    return out


def _sse(event: str, payload: dict) -> str:
    """SSE 帧。data 必须是单行 JSON，否则浏览器按行切会断。"""
    return f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _stream_chunks(text: str, width: int = 60) -> list[str]:
    """按行切块，超长行再按宽度切。

    为什么不按字符切：这类回答是「一行一条问题」的列表，
    按行吐出来读感是"逐条冒出来"，按字符切只是在屏幕上爬字。
    """
    out: list[str] = []
    for line in (text or "").splitlines(keepends=True):
        if len(line) <= width:
            out.append(line)
            continue
        for i in range(0, len(line), width):
            out.append(line[i:i + width])
    return out


@router.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    """流式对话：先推进度事件，再逐块吐最终回答。

    进度事件（intent / plan / step_start / step_done）是真事件，
    在工具真正执行时发出；最终文本是算完再切块推的——它本来就是
    一次工具调用返回的结果，没有逐 token 可流。
    """
    from app.services.agent import run_agent_task

    queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def emit(kind: str, payload: dict) -> None:
        # 工具在子线程里跑，必须走 call_soon_threadsafe 才能跨回事件循环
        loop.call_soon_threadsafe(queue.put_nowait, (kind, payload))

    def work() -> None:
        try:
            r = asyncio.run(run_agent_task(
                user_input=req.message,
                context={
                    "model": req.model,
                    "mode": req.mode,
                    "user_context": req.context,
                    "user_id": "agent",
                },
                on_event=emit,
            ))
            emit("__result__", r)
        except Exception as e:  # noqa: BLE001
            emit("__error__", {"message": str(e)[:300]})

    async def gen():
        yield _sse("open", {"ok": True, "ts": datetime.now().isoformat()})
        worker = asyncio.create_task(asyncio.to_thread(work))

        while True:
            try:
                kind, payload = await asyncio.wait_for(queue.get(), timeout=15)
            except asyncio.TimeoutError:
                # 心跳：nginx 默认 60s 空闲断连，这里 15s 一次足够
                yield ": ping\n\n"
                continue

            if kind == "__error__":
                yield _sse("error", payload)
                break

            if kind == "__result__":
                text = _generate_response_from_result(payload)
                for chunk in _stream_chunks(text):
                    yield _sse("delta", {"text": chunk})
                    await asyncio.sleep(0.012)
                yield _sse("done", {
                    "status": payload.get("status", ""),
                    "task_id": payload.get("task_id", ""),
                    "intent": payload.get("intent", ""),
                    "steps": [
                        {"tool": s.get("step", {}).get("tool", ""),
                         "result": _trim_step_result(s.get("result", {}))}
                        for s in payload.get("steps", [])
                    ],
                })
                break

            yield _sse(kind, payload)

        if not worker.done():
            worker.cancel()

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            # 宝塔 nginx 默认会缓冲，不关掉就变成"最后一次性刷出来"
            "X-Accel-Buffering": "no",
        },
    )


def _generate_response_from_result(result: dict) -> str:
    """根据任务结果生成响应文本。"""
    status = result.get("status", "OK")
    intent = result.get("intent", "GENERAL_QA")

    if status == "NEED_CLARIFICATION":
        missing = result.get("missing_slots", [])
        return f"缺少必要参数：{', '.join(missing)}。请提供更多信息。"

    if status == "UNAUTHORIZED":
        return "权限不足，无法执行此操作。"

    if status == "WAITING_APPROVAL":
        return "任务需要人工审批，已暂停等待审批。"

    if status == "BUDGET_EXCEEDED":
        return result.get("message", "超出预算限制，任务终止。")

    if status == "FAILED":
        error = result.get("error", "未知错误")
        return f"任务执行失败：{error}"

    if status == "COMPLETED":
        steps = result.get("steps", [])
        if not steps:
            return "任务完成，但这一步没有需要调用的工具。"

        # 只报「执行了 N 个步骤」等于没说——把工具返回的实际内容摊开。
        parts = []
        for step in steps:
            tool = step.get("step", {}).get("tool", "")
            payload = step.get("result") or {}
            rendered = _render_tool_result(tool, payload)
            if rendered:
                parts.append(rendered)
        if parts:
            return "\n\n".join(parts)
        return f"任务完成。执行了 {len(steps)} 个步骤：{', '.join(s.get('step', {}).get('tool', '') for s in steps)}。"

    # 默认响应
    return "任务已处理。"


def _render_tool_result(tool: str, payload: dict) -> str:
    """把工具返回值翻成人话。只处理已知工具，其余返回空串走兜底。"""
    if not isinstance(payload, dict):
        return ""

    if payload.get("status") == "ERROR":
        return f"工具 {tool} 报错：{payload.get('error', '未知错误')}"

    if tool == "qc.get_findings":
        return _render_findings(payload)

    # 通用兜底：列出前几个键值，避免又把结果吞掉
    keys = [k for k in payload if k not in ("status",)]
    if not keys:
        return ""
    brief = ", ".join(f"{k}={payload[k]}" for k in keys[:4] if not isinstance(payload[k], (list, dict)))
    return f"{tool}：{brief}" if brief else ""


def _render_findings(p: dict) -> str:
    """问题清单摘要。"""
    scope = p.get("scope", "single")
    total = int(p.get("total") or 0)
    by_sev = p.get("by_severity") or {}
    detail = p.get("sources_detail") or {}

    where = "当前批次" if scope == "batch" else f"型号 {p.get('mpn') or '(未指定)'}"
    head = []
    for sev in ("P0", "P1", "P2"):
        if by_sev.get(sev):
            head.append(f"{sev} {by_sev[sev]} 条")
    head_txt = "、".join(head) if head else "无问题记录"

    # 数据来源交代清楚：review 报告有几份、台账命中几条
    src_bits = []
    rev = detail.get("review") or {}
    if rev.get("error"):
        src_bits.append(f"review 读取失败({rev['error'][:60]})")
    elif rev.get("found") is False:
        src_bits.append(f"未找到 {rev.get('safe','')} 的审计报告")
    elif scope == "batch" and rev.get("reports") is not None:
        verdicts = rev.get("verdicts") or {}
        v_txt = "、".join(f"{k} {v}" for k, v in verdicts.items()) if verdicts else "无判定"
        src_bits.append(f"扫了最近 {rev.get('reports', 0)} 份审计报告（{v_txt}）")
    elif scope == "single" and rev.get("verdict"):
        src_bits.append(f"审计判定 {rev['verdict']}，生成于 {rev.get('generated_at','')[:19]}")
    for key in ("auto_qc", "table_audit"):
        d = detail.get(key) or {}
        if d.get("count"):
            src_bits.append(f"{key} 台账 {d['count']} 条")

    lines = [f"{where}：{head_txt}。"]
    applied = p.get("severity_filter") or []
    if applied and sum(by_sev.values()) > total:
        lines[0] = f"{where}：{head_txt}（按 {'/'.join(applied)} 过滤后 {total} 条）。"
    if src_bits:
        lines.append("来源：" + "；".join(src_bits) + "。")

    rows = p.get("findings") or []
    if rows:
        lines.append("")
        for f in rows[:10]:
            mpn = f.get("mpn") or ""
            prefix = f"{f.get('severity')} {mpn} " if mpn else f"{f.get('severity')} "
            field = f.get("field_path") or ""
            msg = (f.get("message") or "")[:80]
            lines.append(f"- {prefix}{f.get('kind','')}"
                         + (f" [{field}]" if field else "")
                         + (f"：{msg}" if msg else ""))
        if total > 10:
            lines.append(f"- …… 还有 {total - 10} 条")
    elif total == 0:
        # 关键区分：是「真没问题」还是「按 P0/P1 过滤掉了」
        filtered_out = sum(by_sev.values())
        if filtered_out:
            lines.append(f"按当前等级过滤后为 0 条，但存在 {filtered_out} 条更低等级问题"
                         f"（{'、'.join(f'{k} {v}' for k, v in by_sev.items())}）。")
        else:
            lines.append("没有查到问题记录。如果预期应该有，先确认这批型号跑过审计。")

    return "\n".join(lines)


# ==================== 工具列表接口 ====================

@router.get("/tools")
async def list_tools():
    """列出所有可用工具。"""
    return {
        "status": "OK",
        "tools": registry.list_tools(),
        "total": len(registry.list_tools()),
    }


# ==================== 工具执行接口 ====================

@router.post("/tools/execute")
async def execute_tool(req: ToolExecuteRequest):
    """直接执行指定工具（调试用）。"""
    result = registry.execute(
        tool_name=req.tool_name,
        arguments=req.arguments,
        task_id=req.task_id,
        user_id="agent",
    )
    return result


# ==================== 任务历史接口 ====================

@router.get("/tasks")
async def list_tasks(limit: int = 50, offset: int = 0):
    """列出任务历史。"""
    conn = db.conn()
    try:
        rows = conn.execute(
            """
            SELECT task_id, intent, status, result, created_at
            FROM agent_task
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        ).fetchall()
        
        tasks = [
            {
                "task_id": row["task_id"],
                "intent": row["intent"],
                "status": row["status"],
                "result": json.loads(row["result"]) if row["result"] else {},
                "created_at": row["created_at"],
            }
            for row in rows
        ]
        
        return {
            "status": "OK",
            "tasks": tasks,
            "total": len(tasks),
        }
    finally:
        pass


# ==================== 模型配置接口 ====================

@router.get("/models")
async def get_model_config():
    """获取模型路由配置。"""
    import os
    
    return {
        "status": "OK",
        "models": {
            "parse": os.getenv("ICPDF_MODEL_PARSE", "qwen-flash"),
            "review": os.getenv("ICPDF_MODEL_REVIEW", "qwen3.7-plus"),
            "repair": os.getenv("ICPDF_MODEL_REPAIR", "qwen3.7-plus"),
            "alternatives": os.getenv("ICPDF_MODEL_ALTERNATIVES", "qwen3.7-plus"),
            "fix": os.getenv("ICPDF_MODEL_FIX", "rules-only"),
            "intent": os.getenv("ICPDF_MODEL_INTENT", "qwen-flash"),
            "planner": os.getenv("ICPDF_MODEL_PLANNER", "qwen-flash"),
        },
    }


# ==================== 审计日志接口 ====================

@router.get("/audit")
async def get_audit_log(task_id: str = None, limit: int = 50):
    """获取工具调用审计日志。"""
    conn = db.conn()
    try:
        if task_id:
            rows = conn.execute(
                """
                SELECT tool_call_id, task_id, step_no, tool_name, input_summary, output_summary,
                       duration_ms, error, created_at
                FROM agent_tool_event
                WHERE task_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (task_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT tool_call_id, task_id, step_no, tool_name, input_summary, output_summary,
                       duration_ms, error, created_at
                FROM agent_tool_event
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        
        logs = [
            {
                "tool_call_id": row["tool_call_id"],
                "task_id": row["task_id"],
                "step_no": row["step_no"],
                "tool_name": row["tool_name"],
                "input_summary": json.loads(row["input_summary"]) if row["input_summary"] else {},
                "output_summary": json.loads(row["output_summary"]) if row["output_summary"] else {},
                "duration_ms": row["duration_ms"],
                "error": row["error"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]
        
        return {
            "status": "OK",
            "logs": logs,
            "total": len(logs),
        }
    finally:
        pass
