"""pandas QC Analyzer 路由（/api/qe/analyzer/v1）。

只读分析；运行记录写 qc_analysis_run/qc_analysis_task，不改业务表。
"""
from __future__ import annotations

from fastapi import APIRouter, Body, HTTPException, Query
from fastapi.responses import Response

from .. import auth, config, db
from ..services import qc_analyzer as QA

router = APIRouter(prefix="/api/qe/analyzer/v1")


def _op() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except QA.AnalyzerError as e:
        raise HTTPException(e.http_status, e.message)


def _paths():
    return (config.ROOT / "auto_qc_issue_matrix.csv",
            config.ROOT / "evidence_cards.csv",
            config.PDFS)


@router.get("/meta")
def analyzer_meta() -> dict:
    matrix, cards, pdfs = _paths()
    return {
        "analyzer_version": QA.ANALYZER_VERSION,
        "matrix_version": QA.MATRIX_VERSION,
        "rule_version": QA.RULE_VERSION,
        "matrix_available": matrix.is_file(),
        "cards_available": cards.is_file(),
        "pdf_root_available": pdfs.is_dir(),
        "statuses": ["FAIL", "WARN", "PASS", "ALL"],
        "groups": ["A1", "A2", "A3", "E", "I"],
        "priorities": ["P0", "P1", "P2"],
        "outputs": [
            "issue_distribution", "identity_source_anomalies",
            "root_cause_candidates", "electrical_crosstabs",
            "regression_coverage", "run_comparison", "engineering_tasks",
        ],
        "caveats": [
            "统计只生成排查线索，不构成根因结论。",
            "pdf_has_ec_text/table_structure_type 为文本层关键词启发式。",
            "不自动修改 facts/Gold、不自动验收或关闭问题。",
            "候选任务需人工核对原厂 PDF 后立项。",
        ],
    }


@router.post("/run")
def analyzer_run(payload: dict = Body(default={})) -> dict:
    filters = {
        "status": str(payload.get("status") or ""),
        "batch_id": str(payload.get("batch_id") or ""),
        "brand": str(payload.get("brand") or ""),
        "group": str(payload.get("group") or ""),
        "mpn": str(payload.get("mpn") or ""),
        "q": str(payload.get("q") or ""),
    }
    matrix, cards, pdfs = _paths()
    if not matrix.is_file():
        raise HTTPException(500, "analysis matrix 不存在")
    try:
        return QA.run_analysis(db, filters, matrix, cards, pdfs, _op(),
                               persist=bool(payload.get("persist", True)))
    except QA.AnalyzerError as e:
        raise HTTPException(e.http_status, e.message)


@router.get("/runs")
def analyzer_runs(limit: int = Query(30, ge=1, le=200)) -> dict:
    return {"items": _run(QA.list_runs, db, limit)}


@router.get("/runs/{run_key}")
def analyzer_run_detail(run_key: str) -> dict:
    return _run(QA.get_run, db, run_key)


@router.get("/runs/{run_key}/tasks.csv")
def analyzer_tasks_csv(run_key: str) -> Response:
    summary = _run(QA.get_run, db, run_key)
    data = QA.tasks_csv(summary)
    name = "qc_analyzer_tasks_%s.csv" % run_key
    return Response(data.encode("utf-8-sig"), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition":
                             'attachment; filename="%s"' % name})


@router.get("/runs/{run_key}/tasks.xlsx")
def analyzer_tasks_xlsx(run_key: str) -> Response:
    summary = _run(QA.get_run, db, run_key)
    data = _run(QA.tasks_xlsx, summary)
    name = "qc_analyzer_tasks_%s.xlsx" % run_key
    return Response(data, media_type=(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        headers={"Content-Disposition":
                 'attachment; filename="%s"' % name})


@router.get("/runs/{run_key}/bundle.zip")
def analyzer_bundle(run_key: str) -> Response:
    summary = _run(QA.get_run, db, run_key)
    data = _run(QA.export_bundle, summary)
    name = "qc_analyzer_%s.zip" % run_key
    return Response(data, media_type="application/zip",
                    headers={"Content-Disposition":
                             'attachment; filename="%s"' % name})


@router.get("/compare")
def analyzer_compare(before: str = Query(...),
                     after: str = Query(...)) -> dict:
    return _run(QA.compare_runs, db, before, after)
