"""多语言质量中心 API（/api/i18n）。

边界与 services/i18n_qa.py 一致：只读写 i18n_* 表，不碰 item / qc_* / parsed。
批准候选、写入记忆库都是人工发起；AI 审校只返回问题清单。
"""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Query

from .. import auth, config, db
from ..services import i18n_qa as Q

router = APIRouter(prefix="/api/i18n")

LLM_TIMEOUT = 120


def _op() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _guarded(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except ValueError as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------------- 总览
@router.get("/overview")
def overview() -> dict:
    return Q.overview()


@router.get("/rules")
def rules() -> dict:
    return {"rules": Q.RULES, "ruleset": "v1"}


# ---------------------------------------------------------------- 术语库
@router.get("/glossary")
def glossary(q: str = Query("", max_length=80), domain: str = "",
             status: str = "", lang: str = "") -> dict:
    return {"rows": Q.glossary_list(q, domain, status, lang)}


@router.post("/glossary")
def glossary_save(payload: dict = Body(...)) -> dict:
    return _guarded(Q.glossary_save, payload, _op())


@router.get("/banned")
def banned(lang: str = "") -> dict:
    return {"rows": Q.banned_list(lang)}


@router.post("/banned")
def banned_save(payload: dict = Body(...)) -> dict:
    return _guarded(Q.banned_save, payload, _op())


# ---------------------------------------------------------------- 候选批次
@router.get("/batches")
def batches() -> dict:
    return {"rows": Q.batches()}


@router.get("/candidates")
def candidates(batch: str = "", revision: str = "", status: str = "") -> dict:
    return {"rows": Q.candidate_list(batch, revision, status)}


@router.get("/candidates/{cid}")
def candidate_detail(cid: int) -> dict:
    d = Q.candidate_detail(cid)
    if not d:
        raise HTTPException(404, "候选不存在")
    return d


@router.post("/candidates/{cid}/decide")
def candidate_decide(cid: int, payload: dict = Body(...)) -> dict:
    approve = bool(payload.get("approve"))
    return _guarded(Q.decide_candidate, cid, approve, _op(), str(payload.get("note") or ""))


@router.post("/ingest")
def ingest(payload: dict = Body(...)) -> dict:
    """导入服务器上 data/i18n_candidates/<subdir>/ 里的候选 JSON。

    只允许该目录内路径；每个文件按 <batch>/<revision> 入库（batch 取 subdir 首段）。
    """
    subdir = str(payload.get("subdir") or "").strip()
    base_subdir = str(payload.get("base_subdir") or "").strip()
    if not subdir:
        raise HTTPException(400, "subdir 不能为空")
    root = (config.DATA / "i18n_candidates").resolve()
    src = _safe_dir(root, subdir)
    base = _safe_dir(root, base_subdir) if base_subdir else None
    parts = Path(subdir).parts
    batch = payload.get("batch") or parts[0]
    revision = payload.get("revision") or (parts[-1] if len(parts) > 1 else "v1")
    model = str(payload.get("model") or "qwen-flash")
    scope = str(payload.get("scope") or "full")

    out, fails = [], []
    for p in sorted(src.glob("*.json")):
        try:
            raw = p.read_bytes()
            doc = json.loads(raw.decode("utf-8"))
            bdoc = None
            if base and (base / p.name).exists():
                bdoc = json.loads((base / p.name).read_text(encoding="utf-8"))
            c = Q.import_candidate(batch, revision, p.name, doc, model=model, scope=scope,
                                   base_doc=bdoc, raw=raw, operator=_op())
            run = Q.run_lqa(c["id"], _op())
            out.append({"id": c["id"], "file": p.name, "verdict": run["verdict"],
                        "fail_cells": run["counts"]["FAIL"]})
        except Exception as e:                                   # noqa: BLE001
            fails.append({"file": p.name, "error": str(e)[:300]})
    return {"batch": batch, "revision": revision, "imported": len(out), "rows": out,
            "failed": fails}


def _safe_dir(root: Path, sub: str) -> Path:
    p = (root / sub).resolve()
    if root not in p.parents and p != root:
        raise HTTPException(400, "路径越界")
    if not p.is_dir():
        raise HTTPException(404, f"目录不存在：{sub}")
    return p


# ---------------------------------------------------------------- LQA
@router.post("/lqa/run")
def lqa_run(payload: dict = Body(...)) -> dict:
    cid = int(payload.get("candidate_id") or 0)
    if not cid:
        raise HTTPException(400, "candidate_id 必填")
    return _guarded(Q.run_lqa, cid, _op())


@router.post("/lqa/run-batch")
def lqa_run_batch(payload: dict = Body(...)) -> dict:
    batch = str(payload.get("batch") or "")
    if not batch:
        raise HTTPException(400, "batch 必填")
    return Q.run_lqa_batch(batch, str(payload.get("revision") or ""), _op())


@router.get("/lqa/runs")
def lqa_runs(candidate_id: int = 0, limit: int = Query(50, ge=1, le=300)) -> dict:
    return {"rows": Q.lqa_runs(candidate_id, limit)}


@router.get("/lqa/findings")
def lqa_findings(run_id: int = 0, candidate_id: int = 0, severity: str = "",
                 rule: str = "", limit: int = Query(500, ge=1, le=2000)) -> dict:
    return {"rows": Q.lqa_findings(run_id, candidate_id, severity, rule, limit)}


# ---------------------------------------------------------------- AI 审校
@router.get("/review/issues")
def review_issues(status: str = "", severity: str = "", candidate_id: int = 0) -> dict:
    return {"rows": Q.review_issues(status, severity, candidate_id)}


@router.post("/review/issues")
def review_issue_add(payload: dict = Body(...)) -> dict:
    return _guarded(Q.review_issue_add, payload, _op())


@router.post("/review/issues/{issue_id}/decide")
def review_issue_decide(issue_id: int, payload: dict = Body(...)) -> dict:
    return _guarded(Q.review_issue_decide, issue_id, str(payload.get("verdict") or ""), _op())


@router.get("/review/runs")
def review_runs(candidate_id: int = 0) -> dict:
    if candidate_id:
        return {"rows": db.q("SELECT * FROM i18n_review_run WHERE candidate_id=? "
                             "ORDER BY id DESC LIMIT 20", (candidate_id,))}
    return {"rows": db.q("SELECT r.*, c.mpn, c.batch, c.revision FROM i18n_review_run r "
                         "JOIN i18n_candidate c ON c.id=r.candidate_id "
                         "ORDER BY r.id DESC LIMIT 50")}


@router.post("/review/run")
def review_run(payload: dict = Body(...)) -> dict:
    """独立 AI 审校：只产出 i18n_review_issue，不改候选、不写记忆库。"""
    cid = int(payload.get("candidate_id") or 0)
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,))
    if not c:
        raise HTTPException(404, "候选不存在")
    key = os.getenv("DASHSCOPE_API_KEY", "") or os.getenv("ICPDF_TRANSLATE_API_KEY", "")
    if not key:
        raise HTTPException(503, "未配置 DASHSCOPE_API_KEY，AI 审校不可用")
    langs = payload.get("langs") or list(Q.LANGS)
    langs = [x for x in langs if x in Q.LANGS] or list(Q.LANGS)
    model = db.kv_get("i18n.review.model", "") or "qwen-plus"
    base = (os.getenv("ICPDF_REVIEW_BASE_URL")
            or os.getenv("ICPDF_TRANSLATE_BASE_URL")
            or "https://dashscope.aliyuncs.com/compatible-mode/v1")
    run_id = db.x("INSERT INTO i18n_review_run (candidate_id,lang,model,status,operator,"
                  "created_at) VALUES (?,?,?,?,?,?)",
                  (cid, ",".join(langs), model, "running", _op(), db.now()))
    total_tokens = 0
    added = 0
    errors = []
    rows = db.q("SELECT lang,field,idx,en,target FROM i18n_candidate_field "
                "WHERE candidate_id=? ORDER BY lang,field,idx", (cid,))
    for lang in langs:
        bundle = [r for r in rows if r["lang"] == lang]
        if not bundle:
            continue
        try:
            issues, tokens = _llm_review(base, key, model, c["mpn"], lang, bundle)
            total_tokens += tokens
            for it in issues:
                db.x("INSERT INTO i18n_review_issue (run_id,candidate_id,mpn,lang,field,idx,"
                     "category,severity,src_ev,tgt_ev,rationale,verdict,created_at) "
                     "VALUES (?,?,?,?,?,?,?,?,?,?,?,'open',?)",
                     (run_id, cid, c["mpn"], lang, str(it.get("field") or "")[:40],
                      int(it.get("idx", -1) or -1), str(it.get("category") or "mistranslation"),
                      str(it.get("severity") or "P1"), str(it.get("src_ev") or "")[:1000],
                      str(it.get("tgt_ev") or "")[:1000], str(it.get("rationale") or "")[:2000],
                      db.now()))
                added += 1
        except Exception as e:                                   # noqa: BLE001
            errors.append({"lang": lang, "error": str(e)[:300]})
    status = "fail" if errors and not added else "ok"
    db.x("UPDATE i18n_review_run SET status=?,issues=?,tokens=?,error=?,finished_at=? WHERE id=?",
         (status, added, total_tokens, "; ".join(e["error"] for e in errors)[:1000],
          db.now(), run_id))
    Q.audit("review.run", f"candidate={cid}", {"issues": added, "errors": errors}, _op())
    return {"run_id": run_id, "candidate_id": cid, "issues": added, "tokens": total_tokens,
            "errors": errors, "model": model}


_REVIEW_SYSTEM = (
    "You are a senior semiconductor datasheet localization reviewer. You review machine "
    "translations of English datasheet marketing copy into Japanese, Korean, German or "
    "Spanish. Report only genuine defects: mistranslation of technical meaning, omission, "
    "addition, terminology error, corrupted part numbers or numbers, ambiguity, or register "
    "problems. Do NOT rewrite the translation and do NOT approve anything. "
    "Return ONLY a JSON array; each element: "
    '{"field":"title|meta|description|features|applications","idx":<int,-1 for scalar>,'
    '"category":"mistranslation|omission|addition|terminology|entity_integrity|ambiguity|style",'
    '"severity":"P0|P1|P2","src_ev":"<english snippet>","tgt_ev":"<target snippet>",'
    '"rationale":"<one sentence, Chinese>"}. '
    "P0 = wrong technical meaning or corrupted identifier; P1 = terminology/consistency; "
    "P2 = style. Return [] when there is no defect."
)


def _llm_review(base: str, key: str, model: str, mpn: str, lang: str,
                bundle: list[dict]) -> tuple[list[dict], int]:
    lang_name = {"ja": "Japanese", "ko": "Korean", "de": "German", "es": "Spanish"}[lang]
    cells = [{"field": r["field"], "idx": r["idx"], "en": r["en"], "target": r["target"]}
             for r in bundle]
    payload = {
        "model": model,
        "temperature": 0,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": _REVIEW_SYSTEM},
            {"role": "user", "content": json.dumps(
                {"mpn": mpn, "target_language": lang_name, "cells": cells},
                ensure_ascii=False)},
        ],
    }
    url = base.rstrip("/") + "/chat/completions"
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json; charset=utf-8",
                 "Authorization": f"Bearer {key}"})
    try:
        with urllib.request.urlopen(req, timeout=LLM_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:200]}") from e
    content = (data["choices"][0]["message"]["content"] or "").strip()
    content = re.sub(r"^```(?:json)?|```$", "", content, flags=re.M).strip()
    parsed = json.loads(content)
    if isinstance(parsed, dict):
        parsed = parsed.get("issues") or parsed.get("findings") or []
    if not isinstance(parsed, list):
        raise RuntimeError("模型返回不是数组")
    ok_fields = {"title", "meta", "description", "features", "applications"}
    clean = []
    for it in parsed:
        if not isinstance(it, dict):
            continue
        if str(it.get("field") or "") not in ok_fields:
            continue
        sev = str(it.get("severity") or "P1").upper()
        it["severity"] = sev if sev in ("P0", "P1", "P2") else "P1"
        clean.append(it)
    tokens = int(((data.get("usage") or {}).get("total_tokens")) or 0)
    return clean, tokens


# ---------------------------------------------------------------- 记忆库
@router.get("/tm")
def tm_list(status: str = "", lang: str = "", limit: int = Query(200, ge=1, le=1000)) -> dict:
    rows = Q.tm_list(status, lang, limit)
    total = db.q1("SELECT COUNT(*) n, SUM(status='approved') a FROM i18n_tm") or {}
    return {"rows": rows, "total": total.get("n") or 0, "approved": total.get("a") or 0}


@router.post("/tm/promote")
def tm_promote(payload: dict = Body(...)) -> dict:
    cid = int(payload.get("candidate_id") or 0)
    lang = str(payload.get("lang") or "")
    if not cid or lang not in Q.LANGS:
        raise HTTPException(400, "candidate_id / lang 非法")
    return _guarded(Q.tm_from_candidate, cid, lang, _op())


@router.post("/tm/{tm_id}/approve")
def tm_approve(tm_id: int) -> dict:
    return _guarded(Q.tm_approve, tm_id, _op())


# ---------------------------------------------------------------- 报告与设置
@router.get("/report")
def report(days: int = Query(30, ge=1, le=365)) -> dict:
    return Q.report(days)


@router.get("/settings")
def settings() -> dict:
    return Q.settings()


@router.put("/settings")
def set_settings(payload: dict = Body(...)) -> dict:
    return Q.set_settings(payload)
