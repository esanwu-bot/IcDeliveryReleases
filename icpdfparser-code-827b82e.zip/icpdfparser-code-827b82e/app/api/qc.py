"""质量审计 QC 路由组（/api/qc/*）。

数据面：qc_run（状态机）/ qc_finding / qc_audit_log（append-only 台账，
代码路径只 INSERT，禁止 UPDATE/DELETE —— 见 db.py DDL 注释）。

执行面：包装 worker.tasks.qc_audit_item / qc_regression_tick（内部走
qc/table_audit.py + qc/qc_regression.py 三引擎：facts 审计 / 回归 / 渲染层 lint）。
客户约束：补丁只走 render_item 重渲染，不重解 PDF；write 需二次确认。
"""
from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Query
from fastapi.responses import Response

from .. import auth, config, db
from ..services import dispatch, parts as parts_svc
from qc import qc_diff as QD      # qc/qc_diff.py：无 stdout 包装副作用，server 进程可安全 import

router = APIRouter(prefix="/api/qc")

# 11 件回归夹具清单 —— 与 qc/qc_regression.py 的 FIXTURES 保持同步（只读展示用，
# 不在 server 进程 import qc_regression，避免其模块级 stdout 包装器接管工作台进程）。
FIXTURE_MODELS = [
    {"mpn": "5962-9053801PA", "findings": "range_collapse", "asserts": 2},
    {"mpn": "74LVC1G132DCKTG4", "findings": "condition_leak", "asserts": 3},
    {"mpn": "ADC3910S065IRSMT", "findings": "unit_dimension", "asserts": 2},
    {"mpn": "ADS7812B/1K", "findings": "identity_unverified", "asserts": 1},
    {"mpn": "AM26C32IDG4", "findings": "pin_mismatch", "asserts": 1},
    {"mpn": "BQ24300DSGR", "findings": "qualifier_loss", "asserts": 1},
    {"mpn": "BUF634PG4", "findings": "package_mismatch", "asserts": 1},
    {"mpn": "CD74FCT244SM96", "findings": "package_mismatch, pin_mismatch", "asserts": 2},
    {"mpn": "CDC421106RGER", "findings": "option_conflation", "asserts": 1},
    {"mpn": "CY74FCT245ATSOCT", "findings": "pin_mismatch, direction_reversal", "asserts": 1},
    {"mpn": "DAC8555IPWG4", "findings": "row_mispair", "asserts": 2},
]

LINT_KIND_HINT = {
    "i18n_residual": "ja/de 叙述段残英 ratio>0.15",
    "i18n_missing": "语言变体缺失（翻译失败件，先续跑翻译再渲染）",
    "escape_double": "重复 HTML 转义（&amp;lt; 之类）",
    "dup_lead_overview": "导语≈Overview 段落重复",
    "dup_unit": "单位重复（如 24 mA mA）",
    "image_reuse": "同一图片一页复用 ≥3 次",
    "image_missing": "引用的本地图片不存在",
    "txt_missing": "详情页产物缺失",
}


def _operator() -> str:
    u = auth.user()
    return f"user:{u}" if u else "auto"


def _qc_sn(mpn: str) -> str:
    """safe_name：与 qc/table_audit 同口径（/ # 空格 → _）。"""
    return re.sub(r"[/#\s]+", "_", (mpn or "").strip())


# ---------------------------------------------------------------- 概览
@router.get("/overview")
def qc_overview() -> dict:
    audited = db.q1("SELECT count(DISTINCT mpn) n FROM qc_audit_log "
                    "WHERE tool IN ('table_audit','lint')")["n"]
    patched = db.q1("SELECT count(*) n FROM qc_audit_log WHERE action='patched'")["n"]
    unresolved = db.q1("SELECT count(*) n FROM qc_audit_log WHERE action='unresolved'")["n"]
    logs = db.q1("SELECT count(*) n FROM qc_audit_log")["n"]
    lint_debt = db.q1("SELECT count(DISTINCT mpn) n FROM qc_finding WHERE tool='lint'")["n"]
    last_reg = db.q1("SELECT * FROM qc_run WHERE mode='regression' ORDER BY id DESC LIMIT 1") or {}
    kind_rows = db.q(
        "SELECT kind, action, count(*) n FROM qc_audit_log "
        "WHERE tool='table_audit' GROUP BY kind, action ORDER BY n DESC")
    kinds: dict[str, dict] = {}
    for r in kind_rows:
        k = kinds.setdefault(r["kind"], {"kind": r["kind"], "n": 0, "action": r["action"]})
        k["n"] += r["n"]
        # 处置优先级：unresolved > badge > patched（一个 kind 多种处置时显示最重的）
        for a in ("unresolved", "badge", "debt(render)"):
            if r["action"] == a:
                k["action"] = a
    ident_badge = db.q1("SELECT count(*) n FROM qc_audit_log "
                        "WHERE kind='identity_unverified'")["n"]
    ident_family = db.q1("SELECT count(*) n FROM qc_audit_log "
                         "WHERE kind='identity_family'")["n"]
    reg_pass = db.q1("SELECT count(*) n FROM qc_run WHERE mode='regression' "
                     "AND status='ok'")["n"]
    return {
        "audited_mpns": audited,
        "patched": patched,
        "unresolved": unresolved,
        "regression": {
            "parts": last_reg.get("parts", 0),
            "status": last_reg.get("status", ""),
            "at": last_reg.get("created_at", ""),
            "pass_runs": reg_pass,
        },
        "lint_debt_mpns": lint_debt,
        "logs": logs,
        "kinds": sorted(kinds.values(), key=lambda x: -x["n"]),
        "verification": {
            "identity_unverified": ident_badge,
            "identity_family": ident_family,
            "identity_verified": max(0, audited - ident_badge - ident_family),
            "regression_green_runs": reg_pass,
            "log_policy": "append-only（只 INSERT，禁 UPDATE/DELETE）",
            "beat": "每日 03:30 回归（ICPDF_QC_BEAT=1）",
        },
        "badge": unresolved,          # 侧栏红徽标
        "beat_enabled": config.QC_BEAT,
    }


# ---------------------------------------------------------------- 运行
@router.get("/runs")
def qc_runs(page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=200)) -> dict:
    total = db.q1("SELECT count(*) n FROM qc_run")["n"]
    rows = db.q("SELECT * FROM qc_run ORDER BY id DESC LIMIT ? OFFSET ?",
                (size, (page - 1) * size))
    return {"total": total, "page": page, "size": size, "runs": rows}


@router.post("/run")
def qc_run(payload: dict = Body(...)) -> dict:
    mode = (payload.get("mode") or "regression").strip()
    scope = payload.get("scope") or "facts"
    write = bool(payload.get("write"))
    operator = _operator()
    if write and not payload.get("confirm"):
        raise HTTPException(400, "write 补丁需二次确认（confirm=true），且会先备份 .pre_audit.json")
    if mode == "regression":
        run_id = db.x("INSERT INTO qc_run(mode,scope,dry,parts,status,operator,created_at) "
                      "VALUES(?,?,?,?,?,?,?)",
                      (mode, scope, 0 if write else 1, 11, "running", operator, db.qc_now()))
        dispatch.submit("qc_regression_tick", run_id, write, operator)
        return {"run_id": run_id, "mode": mode, "queued": 11}

    if mode == "sample":
        n = int(payload.get("sample") or 60)
        rows = db.q("SELECT mpn FROM item WHERE last_parsed_at<>'' "
                    "AND json_path<>'' AND pdf_path<>'' ORDER BY random() LIMIT ?", (n,))
        mpns = [r["mpn"] for r in rows]
        if not mpns:
            raise HTTPException(400, "库里没有已解析型号可抽样")
    else:                                            # single / selected
        mpns = [str(m).strip() for m in (payload.get("mpns") or []) if str(m).strip()]
        if mode == "single":
            mpn = str(payload.get("mpn") or "").strip()
            mpns = [mpn] if mpn else mpns[:1]
        if not mpns:
            raise HTTPException(400, "没有可审计的型号")

    run_id = db.x("INSERT INTO qc_run(mode,scope,dry,parts,status,operator,created_at) "
                  "VALUES(?,?,?,?,?,?,?)",
                  (mode, scope, 0 if write else 1, len(mpns), "running", operator, db.qc_now()))
    for m in mpns:
        dispatch.submit("qc_audit_item", m, run_id, write, scope, operator)
    return {"run_id": run_id, "mode": mode, "queued": len(mpns), "mpns": mpns}


# ---------------------------------------------------------------- 台账
@router.get("/audit-log")
def qc_audit_log(mpn: str = "", kind: str = "", action: str = "", run_id: int = 0,
                 page: int = Query(1, ge=1), size: int = Query(50, ge=1, le=200)) -> dict:
    where, args = ["1=1"], []
    if mpn:
        where.append("mpn LIKE ?"); args.append(f"%{mpn}%")
    if kind:
        where.append("kind=?"); args.append(kind)
    if action:
        where.append("action=?"); args.append(action)
    if run_id:
        where.append("run_id=?"); args.append(run_id)
    cond = " AND ".join(where)
    total = db.q1(f"SELECT count(*) n FROM qc_audit_log WHERE {cond}", args)["n"]
    rows = db.q(f"SELECT * FROM qc_audit_log WHERE {cond} "
                f"ORDER BY id DESC LIMIT ? OFFSET ?", (*args, size, (page - 1) * size))
    return {"total": total, "page": page, "size": size, "logs": rows}


@router.get("/audit-log/{log_id}")
def qc_audit_detail(log_id: int) -> dict:
    row = db.q1("SELECT * FROM qc_audit_log WHERE id=?", (log_id,))
    if not row:
        raise HTTPException(404, "审计记录不存在")
    run = db.q1("SELECT * FROM qc_run WHERE id=?", (row["run_id"],)) or {}
    # verification / 产物链：从工作台 item 动态组装（dry 未写盘时显示当前落盘态）
    item = db.q1("SELECT * FROM item WHERE mpn LIKE ? OR mpn_key LIKE ? LIMIT 1",
                 (row["mpn"], row["mpn"]))
    artifacts: list[str] = []
    verification: dict = {}
    if item:
        if item.get("json_path"):
            artifacts.append(Path(item["json_path"]).name)
            try:
                p = config.resolve_artifact(item["json_path"], config.PARSED)
                doc = json.loads(p.read_text(encoding="utf-8"))
                verification = (doc.get("metadata", {}) or {}).get("verification") or {}
            except Exception:                            # noqa: BLE001
                verification = {}
        for col, base in (("txt_path", "txt"), ("symbol_path", "symbols"), ("seo_path", "seo")):
            v = item.get(col) or ""
            if v:
                artifacts.append(f"{base}/{Path(v).name}")
    # safe_name 与 qc.table_audit 同口径（不在 server 进程 import qc 工具箱，
    # 避免其模块级 stdout 包装器接管工作台进程）
    import re as _re
    sn = _re.sub(r"[/#\s]+", "_", (row["mpn"] or "").strip())
    jp = config.PARSED / f"{sn}.json"
    if jp and jp.exists():
        for suffix in (".pre_audit", ".pre_audit.json"):
            b = jp.with_name(jp.name + suffix)
            if b.exists():
                artifacts.append(b.name + "（备份）")
        facts = config.DATA / "facts" / f"{Path(jp).stem}.facts.json"
        if facts.exists():
            artifacts.append(f"facts/{facts.name}（SSOT 侧车）")
    chain = db.q("SELECT id,created_at,mpn,kind,action,tool,operator FROM qc_audit_log "
                 "WHERE run_id=? ORDER BY id", (row["run_id"],))
    return {"log": row, "run": run, "verification": verification,
            "artifacts": artifacts, "chain": chain}


# ----------------------------------------------------- 产物链 diff / 逐字段回滚（diff 原型）
@router.get("/audit-log/{log_id}/diff")
def qc_log_diff(log_id: int, baseline: str = "pre") -> dict:
    """抽屉产物链 diff：baseline=pre（补丁明细）/ facts（SSOT 一致性，应 0 差异）。

    字段与原型 1:1：fields[].{p,op,pre,post,kind,src,note}；基线缺失时带 error 前端出提示。
    """
    row = db.q1("SELECT * FROM qc_audit_log WHERE id=?", (log_id,))
    if not row:
        raise HTTPException(404, "审计记录不存在")
    if row["tool"] == "qc_regression":
        return {"mpn": row["mpn"], "baseline": baseline,
                "error": "回归断言行：无字段级 diff（夹具红绿见「回归夹具」Tab）",
                "stats": {"add": 0, "mod": 0, "del": 0, "same": 0}, "fields": [],
                "artifacts": QD.artifacts(row["mpn"], QD.locate(row["mpn"])),
                "verification": {}, "audit_kinds": []}
    p = QD.build(row["mpn"], baseline=baseline)
    if not p:
        raise HTTPException(404, f"无 patched json：{row['mpn']}")
    p["log"] = {"id": row["id"], "mpn": row["mpn"], "kind": row["kind"],
                "action": row["action"], "tool": row["tool"], "run_id": row["run_id"],
                "operator": row["operator"], "created_at": row["created_at"]}
    return p


@router.post("/audit-log/{log_id}/revert")
def qc_log_revert(log_id: int, payload: dict = Body(...)) -> dict:
    """逐字段回滚（写操作）：confirm 二次确认 → staged 覆盖正式 json → 仅投 render_item。

    客户约束同 write 补丁：先备份当前 json（.json.pre_revert 留痕），不重解 PDF；
    台账只 INSERT 追加 revert 记录（append-only）。
    """
    row = db.q1("SELECT * FROM qc_audit_log WHERE id=?", (log_id,))
    if not row:
        raise HTTPException(404, "审计记录不存在")
    if not payload.get("confirm"):
        raise HTTPException(400, "回滚是写操作：需二次确认（confirm=true），会先备份当前 json 再写回基线值")
    paths = [str(p).strip() for p in (payload.get("paths") or []) if str(p).strip()]
    if not paths:
        raise HTTPException(400, "未指定回滚字段（paths）")
    mpn = row["mpn"]
    r = QD.revert(mpn, paths, write=True)               # 生成 staged 暂存，不直接覆盖
    if r.get("error"):
        raise HTTPException(400, f"回滚失败：{r['error']}")
    if not r.get("reverted"):
        raise HTTPException(400, "无可回滚字段（先在 diff 视图勾选字段）")
    loc = QD.locate(mpn)
    jp = loc["patched"]
    bak = jp.with_name(jp.name + ".pre_revert")          # 覆盖前备份当前态（留痕）
    bak.write_text(jp.read_text(encoding="utf-8"), encoding="utf-8")
    jp.write_text(Path(r["staged"]).read_text(encoding="utf-8"), encoding="utf-8")
    db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,"
         "tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
         (row["run_id"], mpn, "revert", ";".join(r["reverted"])[:500],
          json.dumps({"paths": r["reverted"], "n": len(r["reverted"])}, ensure_ascii=False),
          "-", "reverted", "qc_diff", _operator(), db.qc_now()))
    key = parts_svc.key_of(mpn)
    rendered = bool(key) and bool(db.q1("SELECT 1 FROM item WHERE mpn_key=? LIMIT 1", (key,)))
    if rendered:
        dispatch.submit("render_item", key)              # 仅重渲染，不重解 PDF
    db.add_event(f"QC 回滚 {mpn} {len(r['reverted'])} 字段（仅重渲染）", kind="qc")
    return {"reverted": r["reverted"], "missed": r.get("missed", []),
            "rendered": rendered, "backup": bak.name}


# ---------------------------------------------------------------- 夹具 / lint / 重渲染
@router.get("/fixtures")
def qc_fixtures() -> dict:
    rows = db.q("SELECT t.mpn, t.action, t.created_at, t.run_id FROM qc_audit_log t "
                "JOIN (SELECT mpn, max(id) mid FROM qc_audit_log "
                "     WHERE tool='qc_regression' GROUP BY mpn) x "
                "  ON x.mid=t.id")
    latest = {r["mpn"]: r for r in rows}
    last_run = db.q1("SELECT * FROM qc_run WHERE mode='regression' ORDER BY id DESC LIMIT 1") or {}
    return {
        "fixtures": [{**f, "result": (latest.get(f["mpn"]) or {}).get("action", ""),
                      "at": (latest.get(f["mpn"]) or {}).get("created_at", "")}
                     for f in FIXTURE_MODELS],
        "pass": sum(1 for f in FIXTURE_MODELS
                    if (latest.get(f["mpn"]) or {}).get("action") == "pass"),
        "last_run": last_run,
        "beat": "beat 每日 03:30（ICPDF_QC_BEAT=1）" if config.QC_BEAT else "beat 未开启",
    }


@router.get("/lint")
def qc_lint(live: int = 0) -> dict:
    """渲染层债务分组。默认聚合台账（tool='lint'）；live=1 时对 11 件夹具现场复检。"""
    groups: dict[str, dict] = {}
    for r in db.q("SELECT kind, mpn, table_val, json_val FROM qc_finding "
                  "WHERE tool='lint' ORDER BY id DESC"):
        g = groups.setdefault(r["kind"], {"kind": r["kind"], "mpns": [], "n": 0,
                                          "hint": LINT_KIND_HINT.get(r["kind"], "")})
        if r["mpn"] not in g["mpns"]:
            g["mpns"].append(r["mpn"])
        g["n"] += 1
    if live:
        try:
            from qc import qc_regression as QR          # noqa: PLC0415（现场复检，延迟 import）
            for f in FIXTURE_MODELS:
                for l in QR.lint_txt(f["mpn"]):
                    g = groups.setdefault(l["kind"], {"kind": l["kind"], "mpns": [], "n": 0,
                                                       "hint": LINT_KIND_HINT.get(l["kind"], "")})
                    if f["mpn"] not in g["mpns"]:
                        g["mpns"].append(f["mpn"])
                    g["n"] += 1
        except Exception as e:                            # noqa: BLE001
            raise HTTPException(500, f"现场 lint 失败：{e}")
    for g in groups.values():
        g["mpns"] = g["mpns"][:40]
    return {"groups": sorted(groups.values(), key=lambda x: -x["n"]),
            "note": "模板层问题只走 render_item 重渲染，不重解 PDF；i18n 缺失先续跑翻译"}


@router.post("/rerender")
def qc_rerender(payload: dict = Body(...)) -> dict:
    """仅投 render_item 清偿渲染层债务，不碰 fetch/llm 队列。"""
    mpns = [str(m).strip() for m in (payload.get("mpns") or []) if str(m).strip()]
    if not mpns:
        raise HTTPException(400, "没有型号")
    queued = 0
    for m in mpns[:500]:
        key = parts_svc.key_of(m)
        if db.q1("SELECT 1 FROM item WHERE mpn_key=? LIMIT 1", (key,)):
            dispatch.submit("render_item", key)
            queued += 1
    db.add_event(f"QC 重渲染投递 {queued} 件（不重解 PDF）", kind="qc")
    return {"queued": queued, "mode": dispatch.mode()}


# ---------------------------------------------------------------- 导出
@router.get("/export.csv")
def qc_export_csv(mpn: str = "", kind: str = "", action: str = "", run_id: int = 0) -> Response:
    where, args = ["1=1"], []
    if mpn:
        where.append("mpn LIKE ?"); args.append(f"%{mpn}%")
    if kind:
        where.append("kind=?"); args.append(kind)
    if action:
        where.append("action=?"); args.append(action)
    if run_id:
        where.append("run_id=?"); args.append(run_id)
    rows = db.q(f"SELECT * FROM qc_audit_log WHERE {' AND '.join(where)} ORDER BY id", args)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "时间", "run_id", "型号", "kind", "path", "json", "table",
                "处置", "工具", "操作者"])
    for r in rows:
        w.writerow([r["id"], r["created_at"], r["run_id"], r["mpn"], r["kind"], r["path"],
                    r["json_val"], r["table_val"], r["action"], r["tool"], r["operator"]])
    data = buf.getvalue().encode("utf-8-sig")            # Excel 友好 BOM
    return Response(content=data, media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=qc_audit_log.csv"})


# 方案 kind 下拉（原型 Tab3 过滤器）取动态值
@router.get("/kinds")
def qc_kinds() -> dict:
    rows = db.q("SELECT kind, count(*) n FROM qc_audit_log GROUP BY kind ORDER BY n DESC")
    return {"kinds": [r["kind"] for r in rows]}
