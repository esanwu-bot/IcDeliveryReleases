"""客户反馈闭环 V1：问题单 → 样本 → 证据 → 修复 → 回归 → 人工验收（只追加审计）。

设计边界（对齐 PRD）：
  * 不修改 facts / Gold / item / 既有 QC 结论；
  * 不把“已生成 / done / 截图存在 / 回归 PASS”当成人工验收；
  * 所有状态变更、证据审核、回归、验收都写 customer_feedback_audit_log；
  * 高风险类别（型号/封装、电气表、引脚）验收必须有已核验原厂证据 + PASS 回归。

SQLite DDL 作为单一来源导出，app/db.py 启动时执行；业务函数通过 db_mod 注入，便于离线单测。
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import datetime
import uuid
import zipfile
from pathlib import Path

from .pdf_signals import signals as _pdf_signals

CATEGORIES = (
    "IDENTITY_PACKAGE", "ELECTRICAL_TABLE", "PIN_MAPPING",
    "CONTENT_CONSISTENCY", "TRANSLATION", "DUPLICATE_CONTENT",
    "RENDER_ASSET", "STATUS_SEMANTICS", "OTHER",
)
SEVERITIES = ("P0_BLOCKER", "P1_HIGH", "P2_NORMAL", "P3_LOW")
STATUSES = (
    "OPEN", "NEEDS_REPRODUCTION", "TRIAGED", "IN_PROGRESS",
    "READY_FOR_REGRESSION", "REGRESSION_PASSED",
    "PENDING_HUMAN_ACCEPTANCE", "ACCEPTED", "CLOSED", "WAIVED",
)
SOURCES = ("CUSTOMER", "INTERNAL_QC", "SUPPORT", "OTHER")
HIGH_RISK = {"IDENTITY_PACKAGE", "ELECTRICAL_TABLE", "PIN_MAPPING"}
EV_TYPES = ("MANUFACTURER_PDF", "MANUFACTURER_PRODUCT_PAGE", "ERRATA",
            "APP_NOTE", "CUSTOMER_SCREENSHOT", "HTML_RENDER", "LOG", "OTHER")
EV_STATUSES = ("MISSING", "DRAFT", "READY_FOR_REVIEW", "HUMAN_VERIFIED",
               "REJECTED")
REG_STATUSES = ("NOT_RUN", "PASS", "FAIL", "BLOCKED", "NOT_APPLICABLE")
ACC_STATUSES = ("PENDING", "ACCEPTED", "REJECTED", "WAIVED")

# 状态机：不允许普通 PATCH 改状态
TRANSITIONS = {
    "OPEN": ("NEEDS_REPRODUCTION", "TRIAGED", "IN_PROGRESS", "WAIVED"),
    "NEEDS_REPRODUCTION": ("TRIAGED", "IN_PROGRESS", "WAIVED"),
    "TRIAGED": ("IN_PROGRESS", "NEEDS_REPRODUCTION", "WAIVED"),
    "IN_PROGRESS": ("READY_FOR_REGRESSION", "NEEDS_REPRODUCTION", "WAIVED"),
    "READY_FOR_REGRESSION": ("REGRESSION_PASSED", "IN_PROGRESS", "WAIVED"),
    "REGRESSION_PASSED": ("PENDING_HUMAN_ACCEPTANCE", "IN_PROGRESS", "WAIVED"),
    "PENDING_HUMAN_ACCEPTANCE": ("ACCEPTED", "IN_PROGRESS",
                                 "READY_FOR_REGRESSION", "WAIVED"),
    "ACCEPTED": ("CLOSED", "IN_PROGRESS"),
    "CLOSED": (),
    "WAIVED": (),
}

DDL = """
-- 客户反馈闭环 V1（SQLite 增量；不修改既有 QC 表）
CREATE TABLE IF NOT EXISTS customer_feedback_issue (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_key          TEXT NOT NULL UNIQUE,
    title              TEXT NOT NULL,
    description        TEXT NOT NULL,
    category           TEXT NOT NULL,
    severity           TEXT NOT NULL,
    status             TEXT NOT NULL DEFAULT 'OPEN',
    source             TEXT NOT NULL DEFAULT 'CUSTOMER',
    customer_reference TEXT NOT NULL DEFAULT '',
    expected_behavior  TEXT NOT NULL DEFAULT '',
    actual_behavior    TEXT NOT NULL DEFAULT '',
    reproduction_steps TEXT NOT NULL DEFAULT '',
    root_cause_summary TEXT NOT NULL DEFAULT '',
    root_cause_hypothesis TEXT NOT NULL DEFAULT '',
    required_evidence  TEXT NOT NULL DEFAULT '',
    acceptance_criteria TEXT NOT NULL DEFAULT '',
    assignee           TEXT NOT NULL DEFAULT '',
    reporter           TEXT NOT NULL,
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL,
    closed_at          TEXT NOT NULL DEFAULT '',
    version            INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_cf_issue_status_severity
    ON customer_feedback_issue(status, severity);
CREATE INDEX IF NOT EXISTS idx_cf_issue_updated
    ON customer_feedback_issue(updated_at);
CREATE INDEX IF NOT EXISTS idx_cf_issue_category
    ON customer_feedback_issue(category);

CREATE TABLE IF NOT EXISTS customer_feedback_sample (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    batch_id           TEXT NOT NULL,
    mpn                TEXT NOT NULL,
    sample_ref         TEXT NOT NULL DEFAULT '',
    field_path         TEXT NOT NULL DEFAULT '',
    original_pdf_name  TEXT NOT NULL DEFAULT '',
    original_pdf_sha256 TEXT NOT NULL DEFAULT '',
    facts_source_sha256 TEXT NOT NULL DEFAULT '',
    source_revision    TEXT NOT NULL DEFAULT '',
    parser_version     TEXT NOT NULL DEFAULT '',
    rule_version       TEXT NOT NULL DEFAULT '',
    expected_value     TEXT NOT NULL DEFAULT '',
    actual_value       TEXT NOT NULL DEFAULT '',
    evidence_status    TEXT NOT NULL DEFAULT 'MISSING',
    regression_status  TEXT NOT NULL DEFAULT 'NOT_RUN',
    acceptance_status  TEXT NOT NULL DEFAULT 'PENDING',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL,
    UNIQUE(issue_id, batch_id, mpn, field_path)
);
CREATE INDEX IF NOT EXISTS idx_cf_sample_batch ON customer_feedback_sample(batch_id);
CREATE INDEX IF NOT EXISTS idx_cf_sample_mpn ON customer_feedback_sample(mpn);
CREATE INDEX IF NOT EXISTS idx_cf_sample_status
    ON customer_feedback_sample(regression_status, acceptance_status);

CREATE TABLE IF NOT EXISTS customer_feedback_evidence (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    sample_link_id     INTEGER NOT NULL DEFAULT 0,
    evidence_type      TEXT NOT NULL,
    source_url         TEXT NOT NULL DEFAULT '',
    document_title     TEXT NOT NULL DEFAULT '',
    document_revision  TEXT NOT NULL DEFAULT '',
    document_sha256    TEXT NOT NULL DEFAULT '',
    page_number        INTEGER NOT NULL DEFAULT 0,
    field_path         TEXT NOT NULL DEFAULT '',
    quote_text         TEXT NOT NULL DEFAULT '',
    storage_key        TEXT NOT NULL DEFAULT '',
    submitted_by       TEXT NOT NULL,
    submitted_at       TEXT NOT NULL,
    reviewer           TEXT NOT NULL DEFAULT '',
    reviewed_at        TEXT NOT NULL DEFAULT '',
    review_status      TEXT NOT NULL DEFAULT 'PENDING',
    review_reason      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_cf_evidence_issue
    ON customer_feedback_evidence(issue_id, submitted_at);

CREATE TABLE IF NOT EXISTS customer_feedback_fix (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    commit_sha         TEXT NOT NULL DEFAULT '',
    release_version    TEXT NOT NULL DEFAULT '',
    parser_version     TEXT NOT NULL DEFAULT '',
    rule_version       TEXT NOT NULL DEFAULT '',
    mapping_version    TEXT NOT NULL DEFAULT '',
    summary            TEXT NOT NULL,
    changed_paths      TEXT NOT NULL DEFAULT '[]',
    created_by         TEXT NOT NULL,
    created_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cf_fix_issue
    ON customer_feedback_fix(issue_id, created_at);

CREATE TABLE IF NOT EXISTS customer_feedback_regression (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    fix_id             INTEGER NOT NULL DEFAULT 0,
    run_key            TEXT NOT NULL UNIQUE,
    scope_type         TEXT NOT NULL,
    scope_description  TEXT NOT NULL,
    test_suite_version TEXT NOT NULL DEFAULT '',
    commit_sha         TEXT NOT NULL DEFAULT '',
    rule_version       TEXT NOT NULL DEFAULT '',
    result             TEXT NOT NULL,
    total_cases        INTEGER NOT NULL DEFAULT 0,
    passed_cases       INTEGER NOT NULL DEFAULT 0,
    failed_cases       INTEGER NOT NULL DEFAULT 0,
    report_storage_key TEXT NOT NULL DEFAULT '',
    failure_summary    TEXT NOT NULL DEFAULT '',
    started_at         TEXT NOT NULL DEFAULT '',
    finished_at        TEXT NOT NULL DEFAULT '',
    run_by             TEXT NOT NULL,
    created_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cf_regression_issue
    ON customer_feedback_regression(issue_id, created_at);

CREATE TABLE IF NOT EXISTS customer_feedback_acceptance (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    sample_link_id     INTEGER NOT NULL DEFAULT 0,
    decision           TEXT NOT NULL,
    scope_description  TEXT NOT NULL,
    evidence_ids       TEXT NOT NULL DEFAULT '[]',
    regression_ids     TEXT NOT NULL DEFAULT '[]',
    reason             TEXT NOT NULL,
    reviewer           TEXT NOT NULL,
    decided_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cf_accept_issue
    ON customer_feedback_acceptance(issue_id, decided_at);

CREATE TABLE IF NOT EXISTS customer_feedback_audit_log (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id           INTEGER NOT NULL,
    actor              TEXT NOT NULL,
    action             TEXT NOT NULL,
    old_status         TEXT NOT NULL DEFAULT '',
    new_status         TEXT NOT NULL DEFAULT '',
    payload            TEXT NOT NULL DEFAULT '{}',
    request_id         TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cf_audit_issue
    ON customer_feedback_audit_log(issue_id, created_at);
"""


class FeedbackError(Exception):
    def __init__(self, code: str, message: str, http_status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.http_status = http_status


def now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _json(v) -> str:
    return json.dumps(v if v is not None else {}, ensure_ascii=False)


def _audit(db, issue_id, actor, action, old_status="", new_status="",
           payload=None) -> None:
    db.x("INSERT INTO customer_feedback_audit_log"
         "(issue_id,actor,action,old_status,new_status,payload,created_at) "
         "VALUES(?,?,?,?,?,?,?)",
         (issue_id, actor or "auto", action, old_status or "", new_status or "",
          _json(payload or {}), now()))


def _issue(db, issue_key):
    row = db.q1("SELECT * FROM customer_feedback_issue WHERE issue_key=?",
                (issue_key,))
    if not row:
        raise FeedbackError("NOT_FOUND", "问题单不存在", 404)
    return row


def _sample(db, sample_link_id, issue_id=None):
    row = db.q1("SELECT * FROM customer_feedback_sample WHERE id=?",
                (sample_link_id,))
    if not row or (issue_id and int(row["issue_id"]) != int(issue_id)):
        raise FeedbackError("NOT_FOUND", "样本关联不存在", 404)
    return row


def _validate_enum(value, allowed, label):
    if value not in allowed:
        raise FeedbackError("VALIDATION_ERROR",
                            "%s 不合法：%s" % (label, value), 400)


def _new_issue_key(db) -> str:
    today = datetime.datetime.now().strftime("%Y%m%d")
    prefix = "CF-%s-" % today
    n = db.q1("SELECT count(*) n FROM customer_feedback_issue WHERE issue_key LIKE ?",
              (prefix + "%",))["n"]
    for i in range(n + 1, n + 1000):
        key = prefix + "%04d" % i
        if not db.q1("SELECT 1 FROM customer_feedback_issue WHERE issue_key=?", (key,)):
            return key
    raise FeedbackError("INTERNAL", "无法生成问题编号", 500)


# ---------------------------------------------------------------- 问题单
def create_issue(db, payload: dict, actor: str) -> dict:
    for k in ("title", "description", "category", "severity"):
        if not str(payload.get(k) or "").strip():
            raise FeedbackError("VALIDATION_ERROR", "缺少 %s" % k, 400)
    _validate_enum(payload["category"], CATEGORIES, "category")
    _validate_enum(payload["severity"], SEVERITIES, "severity")
    source = payload.get("source") or "CUSTOMER"
    _validate_enum(source, SOURCES, "source")
    key = str(payload.get("issue_key") or _new_issue_key(db)).strip()
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,31}$", key):
        raise FeedbackError("VALIDATION_ERROR", "issue_key 格式不合法", 400)
    if db.q1("SELECT 1 FROM customer_feedback_issue WHERE issue_key=?", (key,)):
        raise FeedbackError("DUPLICATE_ISSUE", "issue_key 已存在", 409)
    ts = now()
    issue_id = db.x(
        "INSERT INTO customer_feedback_issue(issue_key,title,description,category,"
        "severity,status,source,customer_reference,expected_behavior,actual_behavior,"
        "reproduction_steps,root_cause_summary,root_cause_hypothesis,required_evidence,"
        "acceptance_criteria,assignee,reporter,created_at,updated_at,version) "
        "VALUES(?,?,?,?,?,'OPEN',?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
        (key, str(payload["title"]).strip(), str(payload["description"]).strip(),
         payload["category"], payload["severity"], source,
         str(payload.get("customer_reference") or ""),
         str(payload.get("expected_behavior") or ""),
         str(payload.get("actual_behavior") or ""),
         str(payload.get("reproduction_steps") or ""),
         str(payload.get("root_cause_summary") or ""),
         str(payload.get("root_cause_hypothesis") or ""),
         str(payload.get("required_evidence") or ""),
         str(payload.get("acceptance_criteria") or ""),
         str(payload.get("assignee") or ""), actor, ts, ts))
    _audit(db, issue_id, actor, "create", "", "OPEN",
           {"issue_key": key, "category": payload["category"],
            "severity": payload["severity"]})
    return get_issue(db, key)


def list_issues(db, filters: dict | None = None, limit=50, cursor=0) -> dict:
    f = filters or {}
    where, args = ["1=1"], []
    for col, key in (("status", "status"), ("severity", "severity"),
                     ("category", "category"), ("assignee", "assignee")):
        if f.get(key):
            where.append("i.%s=?" % col)
            args.append(f[key])
    if f.get("batch_id"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE batch_id=?)")
        args.append(f["batch_id"])
    if f.get("mpn"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE mpn LIKE ?)")
        args.append("%" + f["mpn"] + "%")
    if f.get("q"):
        where.append("(i.issue_key LIKE ? OR i.title LIKE ? OR i.description LIKE ?)")
        q = "%" + f["q"] + "%"
        args += [q, q, q]
    cond = " AND ".join(where)
    total = db.q1("SELECT count(*) n FROM customer_feedback_issue i WHERE " + cond,
                  args)["n"]
    limit = max(1, min(int(limit or 50), 200))
    cursor = max(0, int(cursor or 0))
    rows = db.q(
        "SELECT i.*, "
        "(SELECT count(*) FROM customer_feedback_sample s WHERE s.issue_id=i.id) "
        "sample_count, "
        "(SELECT count(*) FROM customer_feedback_sample s WHERE s.issue_id=i.id "
        " AND s.acceptance_status='PENDING') pending_acceptance, "
        "(SELECT count(*) FROM customer_feedback_regression r WHERE r.issue_id=i.id "
        " AND r.result='FAIL') regression_fail, "
        "CASE WHEN i.severity IN ('P0_BLOCKER','P1_HIGH') "
        " AND i.status NOT IN ('CLOSED','WAIVED') THEN 1 ELSE 0 END blocking "
        "FROM customer_feedback_issue i WHERE " + cond +
        " ORDER BY i.updated_at DESC, i.id DESC LIMIT ? OFFSET ?",
        (*args, limit, cursor))
    return {"items": rows, "total": total, "limit": limit, "cursor": cursor,
            "next_cursor": cursor + limit if cursor + limit < total else None}


def get_issue(db, issue_key) -> dict:
    issue = _issue(db, issue_key)
    iid = issue["id"]
    samples = db.q("SELECT * FROM customer_feedback_sample WHERE issue_id=? "
                   "ORDER BY id", (iid,))
    evidence = db.q("SELECT * FROM customer_feedback_evidence WHERE issue_id=? "
                    "ORDER BY id DESC", (iid,))
    fixes = db.q("SELECT * FROM customer_feedback_fix WHERE issue_id=? "
                 "ORDER BY id DESC", (iid,))
    regressions = db.q("SELECT * FROM customer_feedback_regression WHERE issue_id=? "
                       "ORDER BY id DESC", (iid,))
    acceptances = db.q("SELECT * FROM customer_feedback_acceptance WHERE issue_id=? "
                       "ORDER BY id DESC", (iid,))
    audit = db.q("SELECT * FROM customer_feedback_audit_log WHERE issue_id=? "
                 "ORDER BY id DESC LIMIT 200", (iid,))
    for row in evidence:
        row["evidence_ids"] = None
    for row in acceptances:
        try:
            row["evidence_ids"] = json.loads(row.get("evidence_ids") or "[]")
            row["regression_ids"] = json.loads(row.get("regression_ids") or "[]")
        except Exception:                                    # noqa: BLE001
            pass
    return {"issue": issue, "samples": samples, "evidence": evidence,
            "fixes": fixes, "regressions": regressions,
            "acceptances": acceptances, "audit": audit,
            "blocking": (issue["severity"] in ("P0_BLOCKER", "P1_HIGH")
                         and issue["status"] not in ("CLOSED", "WAIVED")),
            "high_risk": issue["category"] in HIGH_RISK}


def update_issue(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    if payload.get("version") is not None and int(payload["version"]) != int(issue["version"]):
        raise FeedbackError("VERSION_CONFLICT", "版本冲突，请刷新后重试", 409)
    allowed = ("title", "description", "category", "severity", "assignee",
               "expected_behavior", "actual_behavior", "reproduction_steps",
               "root_cause_summary", "root_cause_hypothesis", "required_evidence",
               "acceptance_criteria")
    sets, args = [], []
    for k in allowed:
        if k in payload:
            if k == "category":
                _validate_enum(payload[k], CATEGORIES, "category")
            if k == "severity":
                _validate_enum(payload[k], SEVERITIES, "severity")
            sets.append("%s=?" % k)
            args.append(payload[k])
    if not sets:
        return get_issue(db, issue_key)
    sets += ["updated_at=?", "version=version+1"]
    args += [now(), issue_key]
    db.x("UPDATE customer_feedback_issue SET %s WHERE issue_key=?" %
         ",".join(sets), tuple(args))
    _audit(db, issue["id"], actor, "update", issue["status"], issue["status"],
           {"fields": [k for k in allowed if k in payload]})
    return get_issue(db, issue_key)


def transition(db, issue_key, to_status: str, reason: str, actor: str,
               version=None) -> dict:
    issue = _issue(db, issue_key)
    _validate_enum(to_status, STATUSES, "to_status")
    if version is not None and int(version) != int(issue["version"]):
        raise FeedbackError("VERSION_CONFLICT", "版本冲突，请刷新后重试", 409)
    old = issue["status"]
    if to_status not in TRANSITIONS.get(old, ()):
        raise FeedbackError("INVALID_TRANSITION",
                            "不允许 %s → %s" % (old, to_status), 409)
    if to_status in ("WAIVED",) and not (reason or "").strip():
        raise FeedbackError("VALIDATION_ERROR", "豁免必须填写理由", 400)
    if to_status == "CLOSED" and old != "ACCEPTED":
        raise FeedbackError("INVALID_TRANSITION", "仅 ACCEPTED 可关闭", 409)
    ts = now()
    db.x("UPDATE customer_feedback_issue SET status=?,updated_at=?,version=version+1,"
         "closed_at=? WHERE issue_key=?",
         (to_status, ts, ts if to_status == "CLOSED" else "",
          issue_key))
    _audit(db, issue["id"], actor, "transition", old, to_status,
           {"reason": reason or ""})
    return get_issue(db, issue_key)


# ---------------------------------------------------------------- 样本关联
def add_sample(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    for k in ("batch_id", "mpn"):
        if not str(payload.get(k) or "").strip():
            raise FeedbackError("VALIDATION_ERROR", "缺少 %s" % k, 400)
    field_path = str(payload.get("field_path") or "")
    exists = db.q1("SELECT id FROM customer_feedback_sample WHERE issue_id=? "
                   "AND batch_id=? AND mpn=? AND field_path=?",
                   (issue["id"], payload["batch_id"], payload["mpn"], field_path))
    if exists:
        raise FeedbackError("DUPLICATE_SAMPLE_LINK", "样本关联已存在", 409)
    ts = now()
    sid = db.x(
        "INSERT INTO customer_feedback_sample(issue_id,batch_id,mpn,sample_ref,"
        "field_path,original_pdf_name,original_pdf_sha256,facts_source_sha256,"
        "source_revision,parser_version,rule_version,expected_value,actual_value,"
        "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (issue["id"], payload["batch_id"], payload["mpn"],
         str(payload.get("sample_ref") or ""), field_path,
         str(payload.get("original_pdf_name") or ""),
         str(payload.get("original_pdf_sha256") or ""),
         str(payload.get("facts_source_sha256") or ""),
         str(payload.get("source_revision") or ""),
         str(payload.get("parser_version") or ""),
         str(payload.get("rule_version") or ""),
         str(payload.get("expected_value") or ""),
         str(payload.get("actual_value") or ""), ts, ts))
    _audit(db, issue["id"], actor, "sample_add", issue["status"], issue["status"],
           {"sample_link_id": sid, "batch_id": payload["batch_id"],
            "mpn": payload["mpn"], "field_path": field_path})
    return _sample(db, sid, issue["id"])


def update_sample(db, sample_link_id, payload: dict, actor: str) -> dict:
    row = _sample(db, sample_link_id)
    allowed = ("sample_ref", "field_path", "original_pdf_name",
               "original_pdf_sha256", "facts_source_sha256", "source_revision",
               "parser_version", "rule_version", "expected_value", "actual_value")
    sets, args = [], []
    for k in allowed:
        if k in payload:
            sets.append("%s=?" % k)
            args.append(payload[k])
    if "evidence_status" in payload:
        _validate_enum(payload["evidence_status"], EV_STATUSES, "evidence_status")
        sets.append("evidence_status=?")
        args.append(payload["evidence_status"])
    if "regression_status" in payload:
        _validate_enum(payload["regression_status"], REG_STATUSES, "regression_status")
        sets.append("regression_status=?")
        args.append(payload["regression_status"])
    if "acceptance_status" in payload:
        raise FeedbackError("FORBIDDEN", "验收状态只能通过验收接口变更", 422)
    if not sets:
        return row
    sets.append("updated_at=?")
    args += [now(), sample_link_id]
    db.x("UPDATE customer_feedback_sample SET %s WHERE id=?" % ",".join(sets),
         tuple(args))
    _audit(db, row["issue_id"], actor, "sample_update", "", "",
           {"sample_link_id": sample_link_id,
            "fields": [k for k in allowed if k in payload]})
    return _sample(db, sample_link_id)


# ---------------------------------------------------------------- 证据
def add_evidence(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    _validate_enum(payload.get("evidence_type"), EV_TYPES, "evidence_type")
    sid = int(payload.get("sample_link_id") or 0)
    if sid:
        _sample(db, sid, issue["id"])
    page = int(payload.get("page_number") or 0)
    if page < 0:
        raise FeedbackError("VALIDATION_ERROR", "page_number 必须 >0", 400)
    sha = str(payload.get("document_sha256") or "").strip()
    if sha and not re.match(r"^[0-9a-fA-F]{64}$", sha):
        raise FeedbackError("VALIDATION_ERROR", "document_sha256 必须是 64 位十六进制", 400)
    ts = now()
    eid = db.x(
        "INSERT INTO customer_feedback_evidence(issue_id,sample_link_id,"
        "evidence_type,source_url,document_title,document_revision,document_sha256,"
        "page_number,field_path,quote_text,storage_key,submitted_by,submitted_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (issue["id"], sid, payload["evidence_type"],
         str(payload.get("source_url") or ""),
         str(payload.get("document_title") or ""),
         str(payload.get("document_revision") or ""), sha, page,
         str(payload.get("field_path") or ""),
         str(payload.get("quote_text") or ""),
         str(payload.get("storage_key") or ""), actor, ts))
    _audit(db, issue["id"], actor, "evidence_add", issue["status"], issue["status"],
           {"evidence_id": eid, "evidence_type": payload["evidence_type"],
            "sample_link_id": sid})
    return db.q1("SELECT * FROM customer_feedback_evidence WHERE id=?", (eid,))


def review_evidence(db, evidence_id, payload: dict, actor: str) -> dict:
    ev = db.q1("SELECT * FROM customer_feedback_evidence WHERE id=?", (evidence_id,))
    if not ev:
        raise FeedbackError("NOT_FOUND", "证据不存在", 404)
    status = payload.get("review_status")
    if status not in ("VERIFIED", "REJECTED"):
        raise FeedbackError("VALIDATION_ERROR", "review_status 仅支持 VERIFIED/REJECTED", 400)
    reason = str(payload.get("review_reason") or "").strip()
    if status == "REJECTED" and not reason:
        raise FeedbackError("VALIDATION_ERROR", "驳回必须填写原因", 400)
    ts = now()
    db.x("UPDATE customer_feedback_evidence SET review_status=?,reviewer=?,"
         "reviewed_at=?,review_reason=? WHERE id=?",
         (status, actor, ts, reason, evidence_id))
    _audit(db, ev["issue_id"], actor, "evidence_review", "", "",
           {"evidence_id": evidence_id, "status": status, "reason": reason})
    return db.q1("SELECT * FROM customer_feedback_evidence WHERE id=?", (evidence_id,))


# ---------------------------------------------------------------- 修复/回归
def add_fix(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    summary = str(payload.get("summary") or "").strip()
    if not summary:
        raise FeedbackError("VALIDATION_ERROR", "缺少 summary", 400)
    paths = payload.get("changed_paths") or []
    if not isinstance(paths, list):
        raise FeedbackError("VALIDATION_ERROR", "changed_paths 必须是数组", 400)
    ts = now()
    fid = db.x(
        "INSERT INTO customer_feedback_fix(issue_id,commit_sha,release_version,"
        "parser_version,rule_version,mapping_version,summary,changed_paths,"
        "created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (issue["id"], str(payload.get("commit_sha") or ""),
         str(payload.get("release_version") or ""),
         str(payload.get("parser_version") or ""),
         str(payload.get("rule_version") or ""),
         str(payload.get("mapping_version") or ""), summary,
         _json(paths), actor, ts))
    _audit(db, issue["id"], actor, "fix_add", issue["status"], issue["status"],
           {"fix_id": fid, "commit_sha": payload.get("commit_sha") or ""})
    return db.q1("SELECT * FROM customer_feedback_fix WHERE id=?", (fid,))


def add_regression(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    run_key = str(payload.get("run_key") or "").strip()
    if not run_key:
        raise FeedbackError("VALIDATION_ERROR", "缺少 run_key", 400)
    if db.q1("SELECT 1 FROM customer_feedback_regression WHERE run_key=?", (run_key,)):
        raise FeedbackError("DUPLICATE_RUN_KEY", "run_key 已存在", 409)
    scope_type = payload.get("scope_type")
    if scope_type not in ("SAMPLE", "AFFECTED_BATCH", "STRUCTURE_COHORT",
                          "TARGETED_SUITE"):
        raise FeedbackError("VALIDATION_ERROR", "scope_type 不合法", 400)
    result = payload.get("result")
    if result not in ("PASS", "FAIL", "BLOCKED", "PARTIAL"):
        raise FeedbackError("VALIDATION_ERROR", "result 不合法", 400)
    total = int(payload.get("total_cases") or 0)
    passed = int(payload.get("passed_cases") or 0)
    failed = int(payload.get("failed_cases") or 0)
    if min(total, passed, failed) < 0 or passed + failed > total:
        raise FeedbackError("VALIDATION_ERROR", "回归计数不合法", 400)
    if result == "PASS" and (total <= 0 or failed != 0):
        raise FeedbackError("VALIDATION_ERROR", "PASS 必须 total>0 且 failed=0", 400)
    if not str(payload.get("scope_description") or "").strip():
        raise FeedbackError("VALIDATION_ERROR", "缺少 scope_description", 400)
    fix_id = int(payload.get("fix_id") or 0)
    if fix_id and not db.q1("SELECT 1 FROM customer_feedback_fix WHERE id=? AND issue_id=?",
                            (fix_id, issue["id"])):
        raise FeedbackError("NOT_FOUND", "修复记录不存在", 404)
    ts = now()
    rid = db.x(
        "INSERT INTO customer_feedback_regression(issue_id,fix_id,run_key,scope_type,"
        "scope_description,test_suite_version,commit_sha,rule_version,result,"
        "total_cases,passed_cases,failed_cases,report_storage_key,failure_summary,"
        "started_at,finished_at,run_by,created_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (issue["id"], fix_id, run_key, scope_type,
         str(payload.get("scope_description") or ""),
         str(payload.get("test_suite_version") or ""),
         str(payload.get("commit_sha") or ""),
         str(payload.get("rule_version") or ""), result, total, passed, failed,
         str(payload.get("report_storage_key") or ""),
         str(payload.get("failure_summary") or ""),
         str(payload.get("started_at") or ""),
         str(payload.get("finished_at") or ""), actor, ts))
    _audit(db, issue["id"], actor, "regression_add", issue["status"], issue["status"],
           {"regression_id": rid, "run_key": run_key, "result": result})
    return db.q1("SELECT * FROM customer_feedback_regression WHERE id=?", (rid,))


# ---------------------------------------------------------------- 人工验收/关闭
def acceptance(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    sid = int(payload.get("sample_link_id") or 0)
    if not sid:
        raise FeedbackError("VALIDATION_ERROR", "缺少 sample_link_id", 400)
    sample = _sample(db, sid, issue["id"])
    decision = payload.get("decision")
    if decision not in ("ACCEPT", "REJECT", "WAIVE", "REOPEN"):
        raise FeedbackError("VALIDATION_ERROR", "decision 不合法", 400)
    scope = str(payload.get("scope_description") or "").strip()
    reason = str(payload.get("reason") or "").strip()
    if not scope or not reason:
        raise FeedbackError("VALIDATION_ERROR", "验收必须填写范围和理由", 400)
    if decision == "ACCEPT":
        reg = db.q1("SELECT id FROM customer_feedback_regression WHERE issue_id=? "
                    "AND result='PASS' ORDER BY id DESC LIMIT 1", (issue["id"],))
        if not reg:
            raise FeedbackError("REGRESSION_REQUIRED", "没有 PASS 回归记录，不能验收", 422)
        if issue["category"] in HIGH_RISK:
            ev = db.q1("SELECT id FROM customer_feedback_evidence WHERE issue_id=? "
                       "AND review_status='VERIFIED' AND evidence_type IN "
                       "('MANUFACTURER_PDF','MANUFACTURER_PRODUCT_PAGE','ERRATA',"
                       "'APP_NOTE') LIMIT 1", (issue["id"],))
            if not ev:
                raise FeedbackError("EVIDENCE_REQUIRED",
                                    "高风险类别缺少已核验原厂证据，不能验收", 422)
    if decision == "WAIVE" and not reason:
        raise FeedbackError("VALIDATION_ERROR", "豁免必须填写理由", 400)
    ts = now()
    evidence_ids = payload.get("evidence_ids") or []
    regression_ids = payload.get("regression_ids") or []
    if not isinstance(evidence_ids, list) or not isinstance(regression_ids, list):
        raise FeedbackError("VALIDATION_ERROR", "证据/回归 ID 必须是数组", 400)
    aid = db.x(
        "INSERT INTO customer_feedback_acceptance(issue_id,sample_link_id,decision,"
        "scope_description,evidence_ids,regression_ids,reason,reviewer,decided_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (issue["id"], sid, decision, scope, _json(evidence_ids),
         _json(regression_ids), reason, actor, ts))
    new_acc = {"ACCEPT": "ACCEPTED", "REJECT": "REJECTED",
               "WAIVE": "WAIVED", "REOPEN": "PENDING"}[decision]
    db.x("UPDATE customer_feedback_sample SET acceptance_status=?,updated_at=? "
         "WHERE id=?", (new_acc, ts, sid))
    _audit(db, issue["id"], actor, "acceptance", issue["status"], issue["status"],
           {"acceptance_id": aid, "sample_link_id": sid, "decision": decision,
            "reason": reason})
    return db.q1("SELECT * FROM customer_feedback_acceptance WHERE id=?", (aid,))


def close_issue(db, issue_key, payload: dict, actor: str) -> dict:
    issue = _issue(db, issue_key)
    if issue["status"] != "ACCEPTED":
        raise FeedbackError("INVALID_TRANSITION", "仅 ACCEPTED 可关闭", 409)
    samples = db.q("SELECT * FROM customer_feedback_sample WHERE issue_id=?",
                   (issue["id"],))
    if not samples:
        raise FeedbackError("VALIDATION_ERROR", "没有样本关联，不能关闭", 422)
    bad = [s for s in samples if s["acceptance_status"] not in ("ACCEPTED", "WAIVED")]
    if bad:
        raise FeedbackError("SAMPLES_PENDING",
                            "还有 %d 个样本未验收/未豁免，不能关闭" % len(bad), 422)
    reason = str(payload.get("reason") or "").strip()
    if not reason:
        raise FeedbackError("VALIDATION_ERROR", "关闭必须填写理由", 400)
    ts = now()
    db.x("UPDATE customer_feedback_issue SET status='CLOSED',updated_at=?,"
         "closed_at=?,version=version+1 WHERE id=?", (ts, ts, issue["id"]))
    _audit(db, issue["id"], actor, "close", issue["status"], "CLOSED",
           {"reason": reason})
    return get_issue(db, issue_key)


# ---------------------------------------------------------------- 汇总/批次
def dashboard(db) -> dict:
    total = db.q1("SELECT count(*) n FROM customer_feedback_issue")["n"]
    by_status = {r["status"]: r["n"] for r in db.q(
        "SELECT status,count(*) n FROM customer_feedback_issue GROUP BY status")}
    by_sev = {r["severity"]: r["n"] for r in db.q(
        "SELECT severity,count(*) n FROM customer_feedback_issue GROUP BY severity")}
    by_cat = {r["category"]: r["n"] for r in db.q(
        "SELECT category,count(*) n FROM customer_feedback_issue GROUP BY category")}
    closed = by_status.get("CLOSED", 0)
    blocking = db.q1("SELECT count(*) n FROM customer_feedback_issue WHERE "
                     "severity IN ('P0_BLOCKER','P1_HIGH') AND "
                     "status NOT IN ('CLOSED','WAIVED')")["n"]
    pending = by_status.get("PENDING_HUMAN_ACCEPTANCE", 0)
    reg_fail = db.q1("SELECT count(DISTINCT issue_id) n FROM customer_feedback_regression "
                     "WHERE result='FAIL'")["n"]
    samples = db.q1("SELECT count(*) n FROM customer_feedback_sample")["n"]
    accepted = db.q1("SELECT count(*) n FROM customer_feedback_sample WHERE "
                     "acceptance_status IN ('ACCEPTED','WAIVED')")["n"]
    return {
        "total": total, "closed": closed,
        "closed_rate": round(closed / total * 100, 2) if total else 0,
        "blocking": blocking, "pending_acceptance": pending,
        "regression_fail_issues": reg_fail,
        "samples": samples, "samples_accepted": accepted,
        "sample_coverage": round(accepted / samples * 100, 2) if samples else 0,
        "by_status": by_status, "by_severity": by_sev, "by_category": by_cat,
    }


def batch_summary(db, batch_id: str) -> dict:
    rows = db.q(
        "SELECT DISTINCT i.id,i.issue_key,i.title,i.severity,i.status "
        "FROM customer_feedback_issue i JOIN customer_feedback_sample s "
        "ON s.issue_id=i.id WHERE s.batch_id=?", (batch_id,))
    sample_count = db.q1("SELECT count(*) n FROM customer_feedback_sample "
                         "WHERE batch_id=?", (batch_id,))["n"]
    pending = db.q1("SELECT count(*) n FROM customer_feedback_sample WHERE "
                    "batch_id=? AND acceptance_status='PENDING'", (batch_id,))["n"]
    blocking = [r for r in rows if r["severity"] in ("P0_BLOCKER", "P1_HIGH")
                and r["status"] not in ("CLOSED", "WAIVED")]
    open_rows = [r for r in rows if r["status"] not in ("CLOSED", "WAIVED")]
    return {
        "batch_id": batch_id, "issues": len(rows), "open_issues": len(open_rows),
        "blocking": len(blocking), "samples": sample_count,
        "pending_acceptance": pending,
        "release_blocked": len(blocking) > 0,
        "items": rows,
    }


def batch_map(db, batch_ids: list) -> dict:
    """交付历史用：一次查询返回多个批次的反馈计数。"""
    if not batch_ids:
        return {}
    ph = ",".join("?" * len(batch_ids))
    rows = db.q(
        "SELECT s.batch_id, count(DISTINCT s.issue_id) issues, "
        "count(DISTINCT CASE WHEN i.status NOT IN ('CLOSED','WAIVED') "
        "THEN i.id END) open_issues, "
        "count(DISTINCT CASE WHEN i.severity IN ('P0_BLOCKER','P1_HIGH') "
        "AND i.status NOT IN ('CLOSED','WAIVED') THEN i.id END) blocking, "
        "count(s.id) samples, "
        "sum(CASE WHEN s.acceptance_status='PENDING' THEN 1 ELSE 0 END) pending "
        "FROM customer_feedback_sample s JOIN customer_feedback_issue i "
        "ON i.id=s.issue_id WHERE s.batch_id IN (%s) GROUP BY s.batch_id" % ph,
        tuple(batch_ids))
    out = {}
    for r in rows:
        out[r["batch_id"]] = {
            "issues": r["issues"] or 0, "open_issues": r["open_issues"] or 0,
            "blocking": r["blocking"] or 0, "samples": r["samples"] or 0,
            "pending_acceptance": r["pending"] or 0,
            "release_blocked": (r["blocking"] or 0) > 0,
        }
    return out


def export_csv(db, filters=None) -> str:
    f = filters or {}
    where, args = ["1=1"], []
    for col, key in (("status", "status"), ("severity", "severity"),
                     ("category", "category"), ("assignee", "assignee")):
        if f.get(key):
            where.append("i.%s=?" % col)
            args.append(f[key])
    if f.get("batch_id"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE batch_id=?)")
        args.append(f["batch_id"])
    if f.get("mpn"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE mpn LIKE ?)")
        args.append("%" + f["mpn"] + "%")
    if f.get("q"):
        where.append("(i.issue_key LIKE ? OR i.title LIKE ? OR i.description LIKE ?)")
        q = "%" + f["q"] + "%"
        args += [q, q, q]
    cond = " AND ".join(where)
    rows = db.q(
        "SELECT i.*, "
        "(SELECT count(*) FROM customer_feedback_sample s WHERE s.issue_id=i.id) "
        "sample_count, "
        "(SELECT count(*) FROM customer_feedback_sample s WHERE s.issue_id=i.id "
        " AND s.acceptance_status='PENDING') pending_acceptance "
        "FROM customer_feedback_issue i WHERE " + cond +
        " ORDER BY i.id LIMIT 100000", args)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["issue_key", "title", "category", "severity", "status",
                "source", "reporter", "assignee", "sample_count",
                "pending_acceptance", "updated_at", "closed_at"])
    for r in rows:
        w.writerow([r.get("issue_key"), r.get("title"), r.get("category"),
                    r.get("severity"), r.get("status"), r.get("source"),
                    r.get("reporter"), r.get("assignee"),
                    r.get("sample_count", 0), r.get("pending_acceptance", 0),
                    r.get("updated_at"), r.get("closed_at")])
    return buf.getvalue()


# ---------------------------------------------------------------- 分析包导出
def _csv_text(rows: list, columns: list) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({c: r.get(c, "") if r.get(c) is not None else "" for c in columns})
    return buf.getvalue()


def _base(s: str) -> str:
    return (s or "").replace("\\", "/").rsplit("/", 1)[-1]


def _filtered_issues(db, filters=None) -> list:
    f = filters or {}
    where, args = ["1=1"], []
    for col, key in (("status", "status"), ("severity", "severity"),
                     ("category", "category"), ("assignee", "assignee")):
        if f.get(key):
            where.append("i.%s=?" % col)
            args.append(f[key])
    if f.get("batch_id"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE batch_id=?)")
        args.append(f["batch_id"])
    if f.get("mpn"):
        where.append("i.id IN (SELECT issue_id FROM customer_feedback_sample "
                     "WHERE mpn LIKE ?)")
        args.append("%" + f["mpn"] + "%")
    if f.get("q"):
        where.append("(i.issue_key LIKE ? OR i.title LIKE ? OR i.description LIKE ?)")
        q = "%" + f["q"] + "%"
        args += [q, q, q]
    return db.q("SELECT * FROM customer_feedback_issue i WHERE %s "
                "ORDER BY i.id" % " AND ".join(where), args)


def export_bundle(db, filters=None, qc_dir=None) -> bytes:
    """生成只读分析包 ZIP；不包含绝对路径/密钥/会话信息。"""
    filters = filters or {}
    issues = _filtered_issues(db, filters)
    ids = [i["id"] for i in issues]
    ph = ",".join("?" * len(ids)) if ids else "0"
    samples = db.q("SELECT * FROM customer_feedback_sample WHERE issue_id IN (%s) "
                   "ORDER BY id" % ph, tuple(ids)) if ids else []
    evidence = db.q("SELECT * FROM customer_feedback_evidence WHERE issue_id IN (%s) "
                    "ORDER BY id" % ph, tuple(ids)) if ids else []
    regs = db.q("SELECT * FROM customer_feedback_regression WHERE issue_id IN (%s) "
                "ORDER BY id" % ph, tuple(ids)) if ids else []
    audits = db.q("SELECT * FROM customer_feedback_audit_log WHERE issue_id IN (%s) "
                  "ORDER BY id" % ph, tuple(ids)) if ids else []
    # 批次交付门禁（只读 audit JSON）
    batch_ids = sorted({s["batch_id"] for s in samples if s.get("batch_id")})
    gate_rows = []
    for b in batch_ids:
        audit = {}
        if qc_dir:
            p = qc_dir / b / "qc_quality_audit.json"
            try:
                audit = json.loads(p.read_text(encoding="utf-8"))
            except Exception:                                # noqa: BLE001
                audit = {}
        layers = audit.get("layers") or {}
        gates = audit.get("release_gates") or {}
        gate_rows.append({
            "batch_id": b,
            "l1_status": (layers.get("L1") or {}).get("status") or "NOT_CHECKED",
            "l2_status": (layers.get("L2") or {}).get("status") or "NOT_CHECKED",
            "l3_status": (layers.get("L3") or {}).get("status") or "NOT_CHECKED",
            "l4_status": (layers.get("L4") or {}).get("status") or "NOT_CHECKED",
            "package_status": (gates.get("PACKAGE_PASS") or {}).get("status")
                              or "NOT_CHECKED",
            "provenance_status": (gates.get("PROVENANCE_PASS") or {}).get("status")
                                 or "NOT_CHECKED",
            "semantics_status": (gates.get("DATA_SEMANTICS_PASS") or {}).get("status")
                                or "NOT_CHECKED",
            "downstream_status": (gates.get("DOWNSTREAM_PASS") or {}).get("status")
                                 or "NOT_CHECKED",
            "release_approved": "true" if audit.get("release_approved") else "false",
            "open_blocker_count": sum(
                1 for s in samples if s.get("batch_id") == b and
                next((i for i in issues if i["id"] == s["issue_id"]), {}).get("severity")
                in ("P0_BLOCKER", "P1_HIGH") and
                next((i for i in issues if i["id"] == s["issue_id"]), {}).get("status")
                not in ("CLOSED", "WAIVED")),
        })
    items = {r["mpn"]: r for r in db.q(
        "SELECT mpn,brand,pdf_path,pdf_url,pdf_sha256 FROM item")} if ids else {}
    gold = ({r["mpn"]: r for r in db.q("SELECT mpn,status FROM gold_set ORDER BY rowid")}
            if ids else {})
    issue_cols = ["id", "issue_key", "title", "category", "severity", "status",
                  "root_cause_code", "root_cause_summary", "root_cause_hypothesis",
                  "required_evidence", "acceptance_criteria", "assignee",
                  "created_at", "updated_at", "closed_at", "description",
                  "expected_behavior", "actual_behavior", "reproduction_steps"]
    issue_rows = []
    for i in issues:
        x = dict(i)
        x["root_cause_code"] = ""
        issue_rows.append(x)
    sample_cols = ["id", "issue_id", "batch_id", "mpn", "field_path",
                   "original_pdf_name", "original_pdf_sha256", "facts_source_sha256",
                   "source_revision", "pdf_has_ec_text", "electrical_parse_status",
                   "table_structure_type", "parser_version", "rule_version",
                   "expected_value", "actual_value", "evidence_status",
                   "regression_status", "acceptance_status"]
    sample_rows = []
    source_rows = []
    diff_rows = []
    signal_cache = {}
    for s in samples:
        x = dict(s)
        it = items.get(s.get("mpn")) or {}
        pdf_name = s.get("original_pdf_name") or _base(it.get("pdf_path"))
        pdf_path = it.get("pdf_path") or ""
        cand = Path(pdf_path) if pdf_path and Path(pdf_path).is_file() else None
        if cand is None and qc_dir and pdf_name:
            alt = qc_dir.parent / "pdfs" / pdf_name
            if alt.is_file():
                cand = alt
        key = s.get("original_pdf_sha256") or str(cand or "")
        if key not in signal_cache:
            signal_cache[key] = _pdf_signals(cand) or {}
        sig = signal_cache[key]
        x["pdf_has_ec_text"] = sig.get("pdf_has_ec_text", "NOT_CHECKED")
        parse = sig.get("electrical_parse_status")
        if parse == "HAS_EC_TEXT":
            parse = ("HAS_FIELD_PATH"
                     if "specs.electrical" in (s.get("field_path") or "")
                     else "EC_TEXT_NO_FIELD_PATH")
        x["electrical_parse_status"] = parse or (
            "HAS_FIELD_PATH"
            if "specs.electrical" in (s.get("field_path") or "")
            else "NOT_CHECKED")
        x["table_structure_type"] = sig.get("table_structure_type",
                                            "NOT_CLASSIFIED")
        sample_rows.append(x)
        g = gold.get(s.get("mpn")) or {}
        source_rows.append({
            "source_document_id": "",
            "manufacturer": it.get("brand") or "",
            "document_title": pdf_name,
            "document_revision": s.get("source_revision") or "",
            "source_url": it.get("pdf_url") or "",
            "pdf_sha256": s.get("original_pdf_sha256") or "",
            "canonical_status": g.get("status") or "NOT_IN_GOLD",
            "identity_status": "NOT_CHECKED",
        })
        diff_rows.append({
            "batch_id": s.get("batch_id") or "",
            "mpn": s.get("mpn") or "",
            "field_path": s.get("field_path") or "",
            "expected_value": s.get("expected_value") or "",
            "actual_value": s.get("actual_value") or "",
            "source_document_id": "",
            "pdf_sha256": s.get("original_pdf_sha256") or "",
            "pdf_page": "",
            "source_quote": "",
            "parser_version": s.get("parser_version") or "",
            "rule_version": s.get("rule_version") or "",
            "check_result": ("DIFF_UNVERIFIED"
                             if (s.get("expected_value") or "") !=
                                (s.get("actual_value") or "")
                             else "NO_DIFF_UNVERIFIED"),
        })
    evidence_cols = ["id", "issue_id", "sample_link_id", "evidence_type",
                     "source_url", "document_title", "document_revision",
                     "document_sha256", "pdf_page", "quote", "field_path",
                     "review_status", "reviewer", "reviewed_at"]
    evidence_rows = [{
        "id": e["id"], "issue_id": e["issue_id"],
        "sample_link_id": e["sample_link_id"], "evidence_type": e["evidence_type"],
        "source_url": e["source_url"], "document_title": e["document_title"],
        "document_revision": e["document_revision"],
        "document_sha256": e["document_sha256"],
        "pdf_page": e["page_number"] or "", "quote": e["quote_text"],
        "field_path": e["field_path"], "review_status": e["review_status"],
        "reviewer": e["reviewer"], "reviewed_at": e["reviewed_at"],
    } for e in evidence]
    reg_cols = ["id", "issue_id", "sample_link_id", "suite_name", "test_case_id",
                "code_commit", "parser_version", "rule_version", "result",
                "failure_code", "started_at", "finished_at"]
    first_sample = {}
    for s in samples:
        first_sample.setdefault(s["issue_id"], s)
    reg_rows = [{
        "id": r["id"], "issue_id": r["issue_id"],
        "sample_link_id": (first_sample.get(r["issue_id"]) or {}).get("id", ""),
        "suite_name": r["test_suite_version"], "test_case_id": r["run_key"],
        "code_commit": r["commit_sha"],
        "parser_version": (first_sample.get(r["issue_id"]) or {}).get(
            "parser_version", ""),
        "rule_version": r["rule_version"], "result": r["result"],
        "failure_code": r["failure_summary"],
        "started_at": r["started_at"], "finished_at": r["finished_at"],
    } for r in regs]
    audit_cols = ["id", "issue_id", "event_type", "actor", "from_status",
                  "to_status", "reason", "created_at"]
    audit_rows = []
    for a in audits:
        reason = ""
        try:
            p = json.loads(a.get("payload") or "{}")
            reason = p.get("reason") or ""
        except Exception:                                    # noqa: BLE001
            pass
        audit_rows.append({
            "id": a["id"], "issue_id": a["issue_id"], "event_type": a["action"],
            "actor": a["actor"], "from_status": a["old_status"],
            "to_status": a["new_status"], "reason": reason,
            "created_at": a["created_at"],
        })
    gate_cols = ["batch_id", "l1_status", "l2_status", "l3_status", "l4_status",
                 "package_status", "provenance_status", "semantics_status",
                 "downstream_status", "release_approved", "open_blocker_count"]
    source_cols = ["source_document_id", "manufacturer", "document_title",
                   "document_revision", "source_url", "pdf_sha256",
                   "canonical_status", "identity_status"]
    diff_cols = ["batch_id", "mpn", "field_path", "expected_value", "actual_value",
                 "source_document_id", "pdf_sha256", "pdf_page", "source_quote",
                 "parser_version", "rule_version", "check_result"]
    files = {
        "issues.csv": _csv_text(issue_rows, issue_cols),
        "samples.csv": _csv_text(sample_rows, sample_cols),
        "evidence.csv": _csv_text(evidence_rows, evidence_cols),
        "regressions.csv": _csv_text(reg_rows, reg_cols),
        "audit_events.csv": _csv_text(audit_rows, audit_cols),
        "delivery_gates.csv": _csv_text(gate_rows, gate_cols),
        "source_files.csv": _csv_text(source_rows, source_cols),
        "field_diff.csv": _csv_text(diff_rows, diff_cols),
    }
    created = now()
    export_id = "fbexp-" + uuid.uuid4().hex[:12]
    manifest = {
        "export_id": export_id, "created_at": created, "filters": filters,
        "schema_version": "feedback-export-v1", "timezone": "Asia/Shanghai",
        "redaction_profile": "no-secrets-no-absolute-paths",
        "pdf_signal_method": ("pymupdf_text_markers_v1 (heuristic; "
                              "not a verified table parse)"),
        "snapshot_id": hashlib.sha1(
            (",".join(str(i) for i in ids) + created).encode()).hexdigest()[:16],
        "row_counts": {
            "issues.csv": len(issue_rows),
            "samples.csv": len(sample_rows),
            "evidence.csv": len(evidence_rows),
            "regressions.csv": len(reg_rows),
            "audit_events.csv": len(audit_rows),
            "delivery_gates.csv": len(gate_rows),
            "source_files.csv": len(source_rows),
            "field_diff.csv": len(diff_rows),
        },
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json",
                   json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        for name, text in files.items():
            z.writestr(name, text.encode("utf-8-sig"))
    return buf.getvalue()
