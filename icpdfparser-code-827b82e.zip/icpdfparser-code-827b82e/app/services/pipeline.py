"""单型号全链路编排：采集 -> 下载 -> LLM 解析 -> 详情页 -> 内链 -> 三视图 -> 图片 SEO。

每一步都写回 item 表（status/stage/progress/产物路径），
所以进度是「库里的真实状态」，不是内存变量 —— 前端轮询、worker 重启都不会丢。
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .. import config, db
from . import collector, seo_image, usage
from .parts import safe_name

# PDF 抽文本是 CPU 密集（PyMuPDF），24 个 LLM 线程各抽各的会在 6 核机上互相踩踏：
# 单件 3.6s 会膨胀到 40s+。抽文本固定走小池子，LLM 线程只负责等结果。
_EXTRACT_WORKERS = max(2, min(6, (os.cpu_count() or 4) // 2))
_extract_pool = ThreadPoolExecutor(max_workers=_EXTRACT_WORKERS,
                                   thread_name_prefix="pdftext")

# ---------------------------------------------------------------- 惰性单例
_index_lock = threading.Lock()
_index = None
_universe: set[str] | None = None


def get_index():
    """内链索引：data/products.sqlite3（由站内目录导出表建成）。"""
    global _index
    if _index is not None:
        return _index
    with _index_lock:
        if _index is None:
            from alternatives import Index
            idx = Index()
            if config.CATALOG_DB.exists():
                idx.load(config.CATALOG_DB)
                idx.series = True          # 工作台开启「同系列前缀」兜底（见 alternatives._series_match）
            _index = idx
    return _index


def get_universe() -> set[str]:
    global _universe
    if _universe is None:
        try:
            from alternatives import load_universe
            _universe = load_universe()
        except Exception:                                        # noqa: BLE001
            _universe = set()
    return _universe


# ---------------------------------------------------------------- 解析
def _thin_doc_ok(doc: dict) -> bool:
    """低规格文档是否仍值得交付：有引脚表或足够特性，且模型自评置信度不低。"""
    pins = len(doc.get("pin_configuration") or [])
    feats = len(doc.get("features") or [])
    try:
        conf = float((doc.get("metadata") or {}).get("confidence") or 0)
    except (TypeError, ValueError):
        conf = 0.0
    return (pins >= 8 or feats >= 3) and conf >= 0.4


def parse_pdf(pdf: Path, mpn: str, datasheet_url: str = "", *,
              text: str | None = None, pages_used: int | None = None,
              pages_total: int | None = None, out_dir: Path | str | None = None) -> dict:
    """PDF -> JSON。逻辑与 parse_datasheets.parse_one 一致，但型号由调用方给定。

    每次模型调用的 tokens 与耗时都记进 rec["llm_calls"]，由调用方落 llm_usage 表。

    Phase 1.2 接缝（四个关键字参数，全部可选，默认行为与本轮之前**逐字节相同**）
    --------------------------------------------------------------------------
    `text` / `pages_used` / `pages_total`
        给了就不再自己抽文本，直接用调用方递进来的切片。这是 `app/pipeline`
        能把 PREPROCESS 与 LLM 拆成两段的前提：**抽文本搬出去，模型留在这里**。
        这样 P1-02「新旧 prompt 指纹一致」不是靠人肉比对维持的 —— 两条路走的是
        同一段 prompt 拼装代码，差异在结构上就不可能出现。
        只给 `text` 不给页数时，页数按 0 计（prompt 里会出现 `0/0`，那是显式的
        「不知道」，不是猜的数字）；两者必须成对传入才不会制造假指纹。
    `out_dir`
        JSON 落盘目录，默认 `config.PARSED`。影子对照用它把新链路的产物丢到系统
        临时目录 —— 「不让新链路接管正式状态」在文件系统这一层就得成立，否则
        跑一次对照就把正式 `data/parsed/*.json` 覆盖了。
    """
    import time as _t

    import parse_datasheets as pd

    t0 = time.time()
    rec = {"status": "failed", "error": "", "json_path": "", "ms": 0, "confidence": 0.0,
           "electrical": 0, "pins": 0, "doc": None, "llm_calls": []}
    provider = usage.provider_of(pd.API_BASE)

    def call(messages: list[dict], stage: str, attempt: int, **kw) -> str:
        ts = _t.perf_counter()
        # 按环节取模型（parse / repair 可独立配置）
        kw.setdefault("model", pd.model_for(stage))
        try:
            content, u = pd.chat(messages, **kw)
        except Exception as e:                                  # noqa: BLE001
            rec["llm_calls"].append({
                "stage": stage, "model": kw.get("model") or pd.MODEL, "provider": provider, "usage": {},
                "latency_ms": int((_t.perf_counter() - ts) * 1000), "ok": False,
                "error": f"{type(e).__name__}: {e}", "attempt": attempt})
            raise
        # 多路由下真实网关/模型随每次调用变化，以返回的 _base/_model 为准
        rec["llm_calls"].append({
            "stage": stage, "model": u.get("_model") or kw.get("model") or pd.MODEL,
            "provider": usage.provider_of(u.get("_base") or pd.API_BASE), "usage": u,
            "latency_ms": int((_t.perf_counter() - ts) * 1000), "ok": True, "error": "",
            "attempt": attempt})
        return content

    try:
        if text is None:
            text, total, used, has_text = _extract_pool.submit(pd.extract_pdf_text, pdf).result()
        else:
            # 切片由调用方给：不再读 PDF。页数缺省记 0 —— 宁可显式说「不知道」，
            # 也不要拿当前 PDF 的总页数去填一个它可能并不属于的切片。
            used = int(pages_used or 0)
            total = int(pages_total or 0)
            has_text = bool(text.strip())
        if not has_text:
            rec["error"] = "PDF_UNREADABLE: 无文本层（需 OCR）"
            return rec
        if not pd.is_datasheet(text):
            rec["status"] = "skipped"
            rec["error"] = "NOT_A_DATASHEET: 无参数表特征词（User Guide / Quick Start），跳过 LLM"
            return rec

        pdf_hash = pd.sha256(pdf)
        messages = [
            {"role": "system", "content": pd.SYSTEM_PROMPT},
            {"role": "user", "content": pd.USER_TMPL.format(
                mpn=mpn, fname=pdf.name, pages_used=used, pages_total=total, text=text)},
        ]
        content = call(messages, "parse", 1)
        try:
            doc = pd.parse_json_loose(content)
        except json.JSONDecodeError:
            # 大文档会被 max_tokens 截断（completion 恰好等于上限），加大额度重来一次
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "上次输出在 JSON 中途被 max_tokens 截断。请重新输出完整 "
                                            "JSON（只输出 JSON，保持全部 key）；features 每条控制在 120 字以内。"},
            ]
            content = call(messages, "repair", 2, temperature=0.0, max_tokens=pd.RETRY_MAX_TOKENS)
            doc = pd.parse_json_loose(content)
        errs = pd.validate(doc)
        if errs:                                     # 一次修复重试（与命令行口径一致）
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "上面的 JSON 有问题：" + "；".join(errs) +
                 "。请修正并重新输出完整 JSON（只输出 JSON，保持全部 key）。"},
            ]
            content = call(messages, "repair", 2, temperature=0.0, enable_thinking=True,
                           max_tokens=pd.RETRY_MAX_TOKENS)
            doc = pd.parse_json_loose(content)
            errs = pd.validate(doc)
            if errs:
                # 连接器/晶振/无源件本来就没几条电气参数：结构完整时允许低规格交付
                hard = [e for e in errs if not e.startswith("specs.electrical only")]
                if not (config.ACCEPT_THIN and not hard and _thin_doc_ok(doc)):
                    rec["error"] = "PARSE_FAILED: " + "; ".join(errs)
                    return rec

        meta = doc.setdefault("metadata", {})
        if errs:
            meta["quality_warning"] = "; ".join(errs)
        # 溯源链先落库：`check_core` 的第一条就是 datasheet_url。V2 的 URL 是
        # fetch/调用方给的，等到后面再 setdefault 会让核心校验必然报一条
        # 「URL 为空」→ 白触发一次修复重试（实测多烧 23k tokens）。
        bi = doc.setdefault("basic_info", {})
        if datasheet_url and not str(bi.get("datasheet_url") or "").strip():
            bi["datasheet_url"] = datasheet_url

        # ---- 确定性抽取：与 parse_datasheets.parse_one **同一份实现** ----
        # Phase 1.7 D1（2026-11-03）：V2 曾漏掉这一步 —— 同一份 LM317 PDF，
        # Legacy 热阻 34 行、V2 却是模型原样的 36 行（含 `NA`/`—`）。根因不是
        # 模型方差，是链路没执行相同的确定性后处理。这里**只调用** qc 的同一份
        # `apply_deterministic`，不复制任何判据；调用时机与 Legacy 一致：
        # 模型输出校验通过 → 确定性覆盖 → 核心字段校验 → 不达标时一次修复重试后
        # **再覆盖一次**（避免拿模型的脏行去覆盖重试稿）。
        from qc import core_validation as _CV                    # noqa: PLC0415
        from qc import deterministic_extract as DE                # noqa: PLC0415

        det_rep: dict = {}

        def _apply_deterministic() -> None:
            nonlocal det_rep
            try:
                import pymupdf as _fitz                          # noqa: PLC0415
                with _fitz.open(str(pdf)) as _fd:
                    det_rep = DE.apply_deterministic(doc, _fd)
            except ImportError:
                det_rep = {"skipped": "pymupdf 不可用，确定性抽取未执行"}
            except Exception as e:                              # noqa: BLE001
                det_rep = {"error": f"{type(e).__name__}: {e}"[:200]}

        _apply_deterministic()
        core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)
        if core_errs:
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "核心字段不达标：" + "；".join(core_errs) +
                 "。请修正并重新输出完整 JSON（只输出 JSON，保持全部 key）。"},
            ]
            content = call(messages, "repair", 3, temperature=0.0,
                           enable_thinking=True, max_tokens=pd.RETRY_MAX_TOKENS)
            doc, _clean_stats = pd.parse_doc_clean(content)
            # 重试稿替换了 doc：`meta` 还指向上一个 doc 的 metadata，不重取的话
            # 后面所有 meta.update 都写进孤儿对象（Legacy 同款坑）。
            meta = doc.setdefault("metadata", {})
            _apply_deterministic()
            core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)

        try:
            conf = float(meta.get("confidence") or 0)
        except (TypeError, ValueError):
            conf = 0.0
        meta.update({
            "pdf_hash": pdf_hash,
            "parse_timestamp": db.now(),
            "model_version": pd.MODEL,
            # 电气表规则（3b/3c）的形态随 prompt 版本变化，下游 auto_qc 的 r3
            # 判定必须按版本分组，否则 v1（value 空）与 v2（value 取 MAX/TYP）
            # 混在一起会出两套结论。
            "prompt_version": pd.PROMPT_VERSION,
            "confidence": round(max(0.0, min(1.0, conf)), 2),
            "requested_mpn": mpn,
        })
        bi = doc.setdefault("basic_info", {})
        if not bi.get("datasheet_url"):
            bi["datasheet_url"] = datasheet_url

        # 身份落库 + 板卡口径归一。**必须和 parse_datasheets.parse_one 同步**：
        # 这条是本文件的平行实现，只改一边的话，线上的批次（worker 走这里）
        # 依然会把评估板渲染成「48 脚 WQFN 的芯片」。
        try:
            from qc import identity_scope as IS                    # noqa: PLC0415
            rec["identity"] = IS.apply(doc, mpn, pdf_text=text, pdf_path=pdf)
        except Exception as e:                                     # noqa: BLE001
            meta["identity_scope_error"] = f"{type(e).__name__}: {e}"[:200]

        # 确定性处理的改动摘要 + 核心字段校验：与 Legacy 同名字段，下游能用
        # 同一套审计脚本回答「这条链到底跑没跑确定性抽取」。
        # **必须在 `IS.apply` 之后重取 metadata**：它会 `doc["metadata"] = …`
        # 换成新 dict，上面那个 `meta` 变量已指向旧对象（Legacy 同款坑，
        # 实测导致 deterministic_extract / core_validation 两个字段丢失）。
        meta = doc["metadata"] = pd._as_dict(doc.get("metadata"))

        # ---- 落盘前的最终复验（与 `parse_datasheets.parse_one` 同一判据）----
        # 到这一步 doc 已被改过多次：确定性抽取原地覆盖、修复稿整份替换、
        # `IS.apply` 再做身份归一。任何改动之后都必须重验，所以 core_errs
        # 在这里重算，`core_validation` 的盖章也用这一份 —— 否则会出现
        # 「章上写着三条硬错、status 却是 ok」这种自相矛盾的件。
        # 薄件放行判据必须与 `parse_one` 对齐，否则同一份板卡 PDF 走 CLI 是 ok、
        # 走 worker 是 failed —— 两条链出来的件没法放在一张表里比。
        # 两条既有判据原样沿用，不新造：`_thin_doc_ok`（引脚/特性兜底 + 置信度）
        # 仍需 `config.ACCEPT_THIN` 开关；`pd.accept_thin` 自己查开关 + 板卡后缀
        # + 正文无电气表头。判成薄件时状态是 thin_accepted，不伪装成 ok。
        thin_allowed = (bool(config.ACCEPT_THIN) and _thin_doc_ok(doc)) \
            or pd.accept_thin(pdf.name, text or "")
        core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)
        status_final, errs_final = pd.final_gate(doc, core_errs,
                                                 thin_allowed=thin_allowed)
        if status_final == "failed":
            rec["error"] = "PARSE_FAILED: " + "; ".join(errs_final)
            rec["core_errs"] = list(errs_final)
            return rec

        meta["deterministic_extract"] = det_rep
        meta["core_validation"] = _CV.stamp(meta, doc, core_errs or _CV.PASS)
        # 验收结论随 JSON 落盘（与 parse_one 同名同义）。下游只认这一份，
        # 不靠「文件存在」推断这件当初是否过关。
        meta["accept_status"] = status_final
        if core_errs:
            meta["accept_core_errs"] = list(core_errs)

        config.PARSED.mkdir(parents=True, exist_ok=True)
        _out_dir = Path(out_dir) if out_dir else config.PARSED
        _out_dir.mkdir(parents=True, exist_ok=True)
        out = _out_dir / f"{safe_name(mpn)}_{pdf_hash[:8]}.json"
        out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")

        rec.update(status=status_final, json_path=str(out), doc=doc,
                   confidence=meta["confidence"],
                   electrical=len(((doc.get("specs") or {}).get("electrical")) or []),
                   pins=len(doc.get("pin_configuration") or []))
        if status_final == pd.STATUS_PARSED_CORE_FAIL:
            rec["core_errs"] = list(core_errs)
    except json.JSONDecodeError as e:
        rec["error"] = f"PARSE_FAILED: invalid_json ({e})"
    except Exception as e:                                       # noqa: BLE001
        rec["error"] = f"{type(e).__name__}: {e}"[:300]
    finally:
        rec["ms"] = int((time.time() - t0) * 1000)
    return rec


# ---------------------------------------------------------------- 内链（替代型号）
_BOARD_RE = re.compile(r"(EVM|EVAL|EVK|EMK|EVB|KIT|BOARD|DONGLE|MODULE)", re.I)


def _is_board(doc: dict, mpn: str) -> bool:
    """评估板 / 模块：整块板不能拿芯片替代，但板载器件可以链到站内目录。

    口径唯一定义在 qc/board_identity.py（证据优先：不在 datasheet 订货表内 +
    板卡后缀）。这里只是薄封装，避免与 review 各判一套。
    """
    try:
        from qc import board_identity as BI
        pkg = ((doc.get("specs") or {}).get("package") or {}).get("type") or ""
        return BI.is_board(BI.classify(mpn, doc, pkg))
    except Exception:                                            # noqa: BLE001
        if _BOARD_RE.search(mpn or ""):
            return True
        try:
            import symbol_svg as S
            pkg = ((doc.get("specs") or {}).get("package") or {}).get("type") or ""
            return S.canon_pkg(pkg, 0) == "PCB-UNK"
        except Exception:                                        # noqa: BLE001
            return False


def _onboard_mpn(doc: dict, mpn: str) -> str:
    """评估板料号 -> 板载器件；识别不出返回空串。

    优先取解析层显式写入的 `basic_info.device_mpn`（评估板身份分支会填这个字段），
    再退回套件名推断与 datasheet 里的 mpn。否则会出现「basic_info 已写明板载器件、
    alternatives 却报识别不出」的两处口径矛盾（CF-QC28-012 W1）。
    """
    import alternatives as alt
    root = alt.kit_root(mpn)
    if root:
        return root
    try:
        from qc import board_identity as BI
        pkg = ((doc.get("specs") or {}).get("package") or {}).get("type") or ""
        dev = alt.clean(BI.classify(mpn, doc, pkg).get("device_mpn"))
        if dev and alt.norm(dev) != alt.norm(mpn):
            return dev
    except Exception:                                            # noqa: BLE001
        pass
    bi = doc.get("basic_info") or {}
    for key in ("device_mpn", "mpn"):
        dev = alt.clean(bi.get(key))
        if dev and alt.norm(dev) != alt.norm(mpn):
            return dev
    return ""


def _want_ai_alts(linked_grounded: int, board: bool = False) -> bool:
    """要不要为替代型号调一次模型（只用于站内目录候选排序，不再自由生成）。

    datasheet 的 ordering_info 里本来就有一批同系列可订购料号（零幻觉来源），
    先拿它们去站内目录匹配；够用了就不必再花一次模型调用（约 12.5s / 1k token）。
    板卡不走 AI：整块板没有芯片级替代，板载器件直接查目录。

        ICPDF_ALTS_AI=auto   默认。内链命中数 < ICPDF_ALTS_MIN 时才调 AI
        ICPDF_ALTS_AI=always 每次都调（仍然只允许在目录候选内排序）
        ICPDF_ALTS_AI=never  完全不调，只用 ordering_info
    """
    if board:
        return False
    mode = (os.getenv("ICPDF_ALTS_AI", "auto") or "auto").strip().lower()
    if mode == "never":
        return False
    if mode == "always":
        return True
    try:
        need = int(os.getenv("ICPDF_ALTS_MIN", "3"))
    except ValueError:
        need = 3
    return linked_grounded < need


def _alts_pool_size() -> int:
    try:
        return max(1, min(int(os.getenv("ICPDF_ALTS_POOL", "60")), 200))
    except ValueError:
        return 60


def _board_rows(idx, mpn: str, onboard: str, mfr: str) -> list[dict]:
    """评估板的板载器件行：每条都来自站内目录，保证有真实内链。"""
    import alternatives as alt
    prefix = alt.search_prefix(onboard)
    if len(prefix) < 4:
        return []
    out = []
    for c in idx.candidates(prefix, limit=8):
        if alt.norm(c["mpn"]) == alt.norm(mpn):
            continue
        if not alt.prefix_safe(onboard, c["mpn"]):
            continue
        n, ob = alt.norm(c["mpn"]), alt.norm(onboard)
        same = n.startswith(ob) and len(n) - len(ob) <= 6
        out.append({
            "mpn": c["mpn"],
            "manufacturer": alt.clean(c.get("brand")) or mfr,
            "type": "Onboard device",
            "package": "",
            "feature": (f"Onboard device of {mpn}; catalog ordering code"
                        if same else
                        f"Same-series part for onboard {onboard}; verify package and "
                        f"pinout against board BOM"),
            "similarity": 0.99 if n == ob else (0.8 if same else 0.6),
            "basis": "onboard-device",
            "internal": True,
            "match": "exact" if n == ob else "series",
            "url": c["url"],
            "catalog_mpn": c["mpn"],
            "verified": True,
        })
    return out


def _alts_copy(mpn: str, payload: dict) -> tuple[str, str]:
    """替代型号段的导语/补充说明；动态值在这里统一转义。"""
    import alternatives as alt
    mode = payload.get("ai_mode") or ""
    if payload.get("board"):
        intro = f"{alt.esc(mpn)} is an evaluation board/kit."
        onboard = payload.get("onboard_mpn") or ""
        if onboard:
            intro += (f" The parts below are catalog ordering codes for its onboard device "
                      f"{alt.esc(onboard)}, not board-level replacements. Verify the board BOM, "
                      f"revision and configuration before ordering.")
        else:
            intro += " Board-level alternative substitution is not applicable."
        return intro, ""
    note = ""
    if mode == "catalog-miss":
        prefix = payload.get("prefix") or ""
        note = ("The internal catalog has no additional entries"
                + (f" in the {alt.esc(prefix)} series" if prefix else "")
                + "; only datasheet order codes with catalog matches are listed.")
    elif mode == "ai-empty":
        note = ("Catalog candidates were reviewed, but none was confirmed compatible; "
                "no unverified part numbers were added.")
    elif mode == "ai-error":
        note = ("Automatic ranking was unavailable for this run; only datasheet order codes "
                "verified against the catalog are listed.")
    elif mode == "prefix-too-short":
        note = ("The part number is too short for a safe series lookup; no additional "
                "candidates were generated.")
    return "", note


def _alts_empty_html(mpn: str, mfr: str, reviewed: int = 0, *,
                     board: bool = False, onboard: str = "", prefix: str = "",
                     catalog_miss: bool = False, mode: str = "") -> str:
    """站内目录零命中时的替代型号片段：结构与正常片段一致，内容说明未命中原因。"""
    from alternatives import esc
    if board:
        if onboard:
            body = (f"{esc(mpn)} is an evaluation board/kit. Its onboard device {esc(onboard)} "
                    "was identified, but no matching entry was found in the current product "
                    "catalog, so no internal product link is available.")
        else:
            body = (f"{esc(mpn)} is an evaluation board/kit. Board-level alternative substitution "
                    "is not applicable, and no onboard device could be identified for catalog lookup.")
        note = ("Select replacements for the onboard IC using its manufacturer datasheet and board "
                "BOM; do not substitute a bare IC for the assembled board.")
    elif catalog_miss:
        body = (f"The current product catalog has no entry for {esc(mpn)}"
                + (f" ({esc(mfr)})" if mfr else "")
                + ". No internal alternative links were generated.")
        note = ((f"The catalog does not cover the {esc(prefix)} series. " if prefix else "")
                + "Coverage follows the site product list; check the manufacturer documentation "
                "and authorized distributors for lifecycle status.")
    elif mode == "ai-empty" and reviewed:
        body = (f"{reviewed} catalog part(s) were reviewed for {esc(mpn)}, but none was confirmed "
                "compatible. No internal links were generated.")
        note = ("Check package, pinout, supply range, interface timing and software or circuit "
                "compatibility against the current manufacturer datasheet.")
    else:
        body = (f"No exact match for {esc(mpn)} was found in the current product catalog"
                + (f" ({esc(mfr)})" if mfr else "")
                + (f". {reviewed} candidate part(s) were reviewed." if reviewed else "."))
        note = ("Check the current manufacturer documentation and authorized distribution "
                "list for drop-in alternatives and lifecycle status.")
        if mode == "ai-error":
            note = ("Automatic ranking was unavailable for this run; no unverified part numbers "
                    "were added. Check the manufacturer documentation and authorized distributors.")
        elif mode == "prefix-too-short":
            note = ("The part number is too short for a safe series lookup; no additional "
                    "candidates were generated.")
    return "\n".join([
        "<!-- 8) Equivalent -->",
        '<section class="pd-sec" id="equivalent">',
        '\t<div class="pd-sec-head">',
        '\t\t<div class="pd-badge">',
        "\t\t\tE",
        "\t\t</div>",
        '\t\t<h2 class="pd-sec-title">',
        "\t\t\tAlternative Parts",
        "\t\t</h2>",
        "\t</div>",
        '\t<div class="pd-sec-body">',
        "\t\t<p>",
        f"\t\t\t{body}",
        "\t\t</p>",
        '\t\t<p class="pd-note">',
        f"\t\t\t{note}",
        "\t\t</p>",
        "\t</div>",
        "</section>",
    ])


def _alts_section_html(mpn: str, mfr: str, rows: list[dict], payload: dict) -> str:
    """渲染 Equivalent 段；零内链时给出明确原因，保证交付物不缺件。"""
    import alternatives as alt
    intro, note = _alts_copy(mpn, payload)
    html = alt.render_section(mpn, rows, mfr, only_linked=True, note=note, intro=intro)
    if html.strip():
        return html
    mode = payload.get("ai_mode") or ""
    reviewed = int(payload.get("candidate_pool") or 0) if mode == "ai-empty" else len(rows)
    return _alts_empty_html(
        mpn, mfr, reviewed,
        board=bool(payload.get("board")),
        onboard=payload.get("onboard_mpn") or "",
        prefix=payload.get("prefix") or "",
        catalog_miss=mode == "catalog-miss",
        mode=mode,
    )


def build_alternatives(doc: dict, mpn: str) -> dict:
    """datasheet 同系列 -> 站内目录候选 ->（必要时）目录内 AI 排序 -> 5 列表格。

    AI 不再自由生成料号：候选池全部来自站内目录，模型只负责挑选/排序/解释；
    目录没覆盖该系列时直接报告未覆盖，不调模型、不猜料号。
    评估板不参与芯片级替代，改为查板载器件（CC1020EMK-868 -> CC1020）。
    整段失败不影响主交付物。
    """
    import alternatives as alt
    import parse_datasheets as pd
    out = {"total": 0, "linked": 0, "json": "", "html": "", "rows": [],
           "llm_call": None, "ai_used": False, "board": False, "onboard_mpn": "",
           "ai_mode": "", "catalog_covered": None, "candidate_pool": 0,
           "prefix": "", "payload": {}}
    try:
        idx = get_index()
        universe = get_universe()
        mfr = alt.clean((doc.get("basic_info") or {}).get("manufacturer"))
        board = (os.getenv("ICPDF_ALTS_BOARD", "1") != "0" and _is_board(doc, mpn))
        out["board"] = board
        rows: list[dict] = []
        prefix = ""
        if board:
            onboard = _onboard_mpn(doc, mpn)
            out["onboard_mpn"] = onboard
            prefix = alt.search_prefix(onboard) if onboard else ""
            out["prefix"] = prefix
            out["ai_mode"] = "board"
            if onboard:
                rows = _board_rows(idx, mpn, onboard, mfr)
                out["candidate_pool"] = len(rows)
                out["catalog_covered"] = bool(rows)
        else:
            grounded = alt.enrich(alt.grounded_rows(doc, mpn), idx, universe)
            linked_grounded = sum(1 for r in grounded if r["internal"])
            rows = list(grounded)
            out["catalog_covered"] = linked_grounded > 0
            prefix = alt.search_prefix(mpn)
            out["prefix"] = prefix
            if not _want_ai_alts(linked_grounded):
                mode = (os.getenv("ICPDF_ALTS_AI", "auto") or "").strip().lower()
                out["ai_mode"] = "off" if mode == "never" else "grounded"
            elif len(prefix) < 4:
                out["ai_mode"] = "prefix-too-short"
            else:
                # 多取一些再按 prefix_safe 过滤：短前缀会混入 LM358 这类另一颗芯片
                raw = idx.candidates(prefix, limit=min(_alts_pool_size() * 2, 200))
                pool = [c for c in raw if alt.prefix_safe(mpn, c["mpn"])][:_alts_pool_size()]
                out["candidate_pool"] = len(pool)
                out["catalog_covered"] = bool(pool) or linked_grounded > 0
                if not pool:
                    out["ai_mode"] = "catalog-miss"
                else:
                    out["ai_used"] = True
                    ts = time.perf_counter()
                    proposed: list[dict] = []
                    prop_usage: dict = {}
                    try:
                        proposed, prop_usage = alt.propose_grounded(doc, pool, with_usage=True)
                        llm_ok, llm_err = True, ""
                        out["ai_mode"] = "catalog-rank" if proposed else "ai-empty"
                    except Exception as e:                    # noqa: BLE001
                        llm_ok, llm_err = False, f"{type(e).__name__}: {e}"[:300]
                        out["ai_mode"] = "ai-error"
                    out["llm_call"] = {
                        "stage": "alternatives",
                        "model": (prop_usage or {}).get("_model") or alt.MODEL,
                        "provider": usage.provider_of((prop_usage or {}).get("_base") or pd.API_BASE),
                        "usage": prop_usage or {},
                        "latency_ms": int((time.perf_counter() - ts) * 1000),
                        "ok": llm_ok, "error": llm_err, "attempt": 1,
                    }
                    if proposed:
                        rows += alt.enrich(proposed, idx, universe)
        seen, uniq = set(), []
        for r in sorted(rows, key=lambda x: (x["internal"], x["verified"], x["similarity"]),
                        reverse=True):
            k = alt.norm(r["mpn"])
            if k in seen:
                continue
            seen.add(k)
            uniq.append(r)
        # README 口径：替代料必须原样命中候选 MPN，否则丢弃。
        # 之前只在渲染层（only_linked=True）过滤，JSON 里仍留着 match=miss 的行——
        # 同一份数据 JSON 报 6 条、HTML/TXT 只有 2 条，下游按数组长度统计就会误报。
        #
        # 2026-10-31（Reviewer B1）：口径收紧到「可订购号**精确命中**」。
        # 旧逻辑只丢 `miss`，`family` 仍算 internal=True 放行——而 `family` 恰恰是
        # 「目录有同族变体、但没有这个可订购号」，同样不能当替代料发布。
        dropped = [r["mpn"] for r in uniq if str(r.get("match") or "") == "miss"]
        uniq, rejected = alt.enforce_orderable(uniq, idx)
        dropped += [r["mpn"] for r in rejected if r["mpn"] not in dropped]
        rows = uniq[:6]
        linked = sum(1 for r in rows if r.get("internal"))
        if out["catalog_covered"] is None:
            out["catalog_covered"] = linked > 0
        stem = safe_name(mpn)
        payload = {
            "mpn": mpn,
            "manufacturer": mfr,
            "generated_at": db.now(),
            "catalog_rows": len(idx),
            "board": board,
            "onboard_mpn": out["onboard_mpn"],
            "prefix": prefix,
            "catalog_covered": bool(out["catalog_covered"]),
            "ai_mode": out["ai_mode"],
            "candidate_pool": out["candidate_pool"],
            "alternatives": rows,
            "dropped_miss": dropped,
        }
        config.ALTS.mkdir(parents=True, exist_ok=True)
        jp = config.ALTS / f"{stem}.json"
        jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        html = _alts_section_html(mpn, mfr, rows, payload)
        hp = config.ALTS / f"{stem}.html"
        hp.write_text(html, encoding="utf-8")
        out.update(total=len(rows), linked=linked, json=str(jp), html=str(hp),
                   rows=rows, payload=payload)
    except Exception as e:                                       # noqa: BLE001
        out["error"] = f"{type(e).__name__}: {e}"[:200]
    return out


def _alts_status(res: dict) -> str:
    linked, total = res.get("linked", 0), res.get("total", 0)
    mode = res.get("ai_mode") or ""
    if res.get("board"):
        onboard = res.get("onboard_mpn") or ""
        if linked:
            return f"内链命中 {linked}（板载 {onboard}）" if onboard else f"内链命中 {linked}（评估板）"
        if onboard:
            return f"评估板：板载 {onboard} 未收录站内目录"
        return "评估板：未识别板载器件"
    if mode == "catalog-miss":
        prefix = res.get("prefix") or ""
        return f"内链命中 {linked}/{total}（目录未覆盖 {prefix}）"
    if mode == "ai-empty":
        return f"内链命中 {linked}/{total}（目录内无兼容项）"
    if mode == "ai-error":
        return f"内链命中 {linked}/{total}（AI 排序失败，保留目录命中）"
    if mode == "prefix-too-short":
        return f"内链命中 {linked}/{total}（前缀过短，跳过 AI）"
    return f"内链命中 {linked}/{total}"


# ---------------------------------------------------------------- 主流程
# fetch 段的领取租约（秒）：只有在「正在跑」的中间态上才用它。
# 一个采集要串行探十几个来源，最长的一次实测 40s 上下；900s 是给慢网络留的余量。
# 调小会把真正在跑的下载误判成僵尸、被重复消息抢走（双下）；调大则残留态要等更久。
FETCH_LEASE_SEC = int(os.getenv("ICPDF_FETCH_LEASE_SEC", "900"))

# 闲置态：谁看到都能接手干（含 failed/nodata/skipped —— 那些就该被重试）
_IDLE_STATUS = ("pending", "queued", "failed", "nodata", "skipped")
# 在跑态：默认不许抢，除非租约过期或人工强制重跑
_BUSY_STATUS = ("resolving", "downloading", "parsing", "rendering")


def _claim_fetch(item_id: int, *, redo: bool) -> int:
    """原子领取 fetch 段的执行权。返回 1=抢到，0=别人在做/已经做完。

    为什么不能只靠调用方读到的 status：两个重复任务可能同时读到 `pending`，
    然后都进入下载。判断和改状态必须在同一条 UPDATE 里完成 —— 由 SQLite
    的行锁保证只有一个能把行从闲置态推进到 `resolving`。

    `redo`（force / manual_url）是**人工显式重跑**，连在跑态都覆盖：
    否则点了"强制重跑"要等租约过期才动，操作员会以为按钮坏了。
    """
    return db.x_count(
        "UPDATE item SET status='resolving', stage=?, progress=5, error='', updated_at=? "
        "WHERE id=? AND ("
        "  status IN (" + ",".join("?" * len(_IDLE_STATUS)) + ")"
        "  OR (status='done' AND ?)"
        "  OR (status IN (" + ",".join("?" * len(_BUSY_STATUS)) + ")"
        "      AND (? OR julianday(updated_at) < julianday('now', ?)))"
        ")",
        ("采集各平台 Datasheet 链接", db.now(), item_id,
         *_IDLE_STATUS, 1 if redo else 0, *_BUSY_STATUS,
         1 if redo else 0, f"-{FETCH_LEASE_SEC} seconds"))


def fetch_stage(item: dict, *, force: bool = False, manual_url: str = "") -> dict:
    """阶段1：采集 + 下载（纯网络 IO，跑 fetch 队列，不占 LLM 槽位）。

    成功返回 {ok, pdf, url, sheet_url}；终态（去重跳过 / nodata）已写好 item 状态。

    去重顺序在这里，且**先于任何状态写入**：先把 `done` 判掉再谈别的。
    反过来的话（先改状态再判），第二次投递会把 `done` 降级成 `queued`，
    第三次投递就去重失败、真重下一遍 —— Phase 1.6.1 修的就是这个。
    """
    item_id = item["id"]
    mpn = item["mpn"]
    seen = (item.get("status") or "").strip()
    redo = bool(force or manual_url)

    if seen == "done" and not redo:
        # 重复投递不能把 done 降级成 skipped/queued，否则交付统计会凭空少一批
        db.add_event("已解析过，按去重规则跳过", kind="dedup", item_id=item_id)
        return {"ok": True, "skipped": True, "reason": "already_parsed"}

    if not _claim_fetch(item_id, redo=redo):
        # 抢不到 = 别人已经把它推进到在跑态，或刚刚做完。
        # 两种情况都不该由本次投递重复下载、也不该往下游接力（接力会重复调模型）。
        cur = db.q1("SELECT status FROM item WHERE id=?", (item_id,)) or {}
        cur_status = (cur.get("status") or "").strip()
        if cur_status == "done" and not redo:
            db.add_event("已解析过，按去重规则跳过", kind="dedup", item_id=item_id)
            return {"ok": True, "skipped": True, "reason": "already_parsed"}
        db.add_event(f"已有任务在执行（{cur_status or '状态未知'}），本次重复投递跳过",
                     kind="dedup", item_id=item_id)
        return {"ok": True, "skipped": True, "reason": "already_running",
                "status": cur_status}

    try:
        meta = json.loads(item.get("meta") or "{}")
    except json.JSONDecodeError:
        meta = {}
    sheet_url = meta.get("sheet_url", "")
    cached_url = item.get("pdf_url", "") if seen != "pending" else ""

    # 状态已在 _claim_fetch 里推进到 resolving，这里只落 meta（并续一次租约）
    db.set_item(item_id, meta=json.dumps(meta, ensure_ascii=False))
    db.add_event(f"开始处理 {mpn}", kind="start", item_id=item_id)

    hit = collector.fetch_datasheet(
        mpn, item["mpn_key"], brand=item.get("brand", ""), sheet_url=sheet_url if not manual_url else "",
        cached_url=cached_url, manual_url=manual_url)

    if not hit["ok"]:
        tried = hit.get("tried", [])
        if hit.get("transient"):
            # 网络故障不是「没有资料」：标成可重试的 failed，避免一次断网把整批写成 nodata
            db.set_item(item_id, provider="", stage="网络异常，未取到 PDF")
            db.touch_status(item_id, "failed", "网络异常，未取到 PDF", 20,
                            "采集来源超时/断连，未判定为无资料；网络恢复后重试即可")
            db.add_event("采集网络异常（可重试）", kind="error", item_id=item_id,
                         detail=json.dumps(tried, ensure_ascii=False)[:4000])
            return {"ok": False, "reason": "transient_network", "tried": tried}
        db.set_item(item_id, provider="", stage="未找到可下载的 Datasheet PDF")
        db.touch_status(item_id, "nodata", "未找到可下载的 Datasheet PDF", 20,
                        "所有采集来源均未取到 PDF；可在详情页手工补链接后重试")
        db.add_event("未找到 Datasheet", kind="nodata", item_id=item_id,
                     detail=json.dumps(tried, ensure_ascii=False)[:4000])
        return {"ok": False, "reason": "nodata", "tried": tried}

    pdf = Path(hit["path"])
    db.set_item(item_id, pdf_url=hit["url"], pdf_path=str(pdf), pdf_sha256=hit["sha256"],
                pdf_bytes=hit["bytes"], provider=hit["provider"])
    db.touch_status(item_id, "downloading", f"PDF 已下载（{hit['bytes'] / 1024:.0f} KB）", 30)
    db.add_event(f"PDF 就绪：{hit['provider']} {hit['bytes'] / 1024:.0f} KB",
                 kind="download", item_id=item_id, detail=hit["url"])
    return {"ok": True, "pdf": str(pdf), "url": hit["url"], "sheet_url": sheet_url}


def llm_stage(item: dict, *, pdf: str | Path | None = None, url: str = "") -> dict:
    """阶段2：LLM 解析（跑 llm 队列）。pdf 缺省读 item 行（fetch 阶段已落库）。"""
    item_id = item["id"]
    mpn = item["mpn"]
    pdf = Path(pdf) if pdf else config.resolve_artifact(item["pdf_path"], config.PDFS)
    url = url or item.get("pdf_url", "")

    db.touch_status(item_id, "parsing", "LLM 解析 PDF", 45)
    rec = parse_pdf(pdf, mpn, url)
    _log_calls(item_id, item["mpn_key"], rec.get("llm_calls") or [])
    if rec["status"] == "skipped":
        db.set_item(item_id, parse_ms=rec["ms"], last_parsed_at=db.now(),
                    parse_count=(item.get("parse_count") or 0) + 1)
        db.touch_status(item_id, "skipped", "非 Datasheet 文档，跳过解析", 100, rec["error"])
        db.add_event("跳过：非 Datasheet", kind="skip", item_id=item_id, detail=rec["error"])
        return {"ok": False, "reason": "not_a_datasheet", "error": rec["error"]}
    if rec["status"] != "ok":
        db.set_item(item_id, parse_ms=rec["ms"], last_parsed_at=db.now(),
                    parse_count=(item.get("parse_count") or 0) + 1)
        db.touch_status(item_id, "failed", "解析失败", 100, rec["error"])
        db.add_event("解析失败", kind="error", item_id=item_id, detail=rec["error"])
        return {"ok": False, "reason": "parse_failed", "error": rec["error"]}

    db.set_item(item_id, json_path=rec["json_path"], parse_ms=rec["ms"],
                last_parsed_at=db.now(), parse_count=(item.get("parse_count") or 0) + 1)
    db.touch_status(item_id, "rendering", "解析完成，开始生成交付物料", 60)
    db.add_event(f"解析完成：{rec['electrical']} 条规格 / {rec['pins']} 个引脚",
                 kind="parse", item_id=item_id)
    return {"ok": True, "doc": rec["doc"]}


def run_item(item: dict, *, force: bool = False, manual_url: str = "") -> dict:
    """执行一个型号的完整链路：fetch -> llm -> render 三段顺序跑。

    拆分模式下三段是独立任务（worker/tasks.py 的 fetch_item/llm_item/render_item，
    各自排队、接力落库）；本函数保留给降级模式与兼容入口，行为与拆分前完全一致。
    """
    r = fetch_stage(item, force=force, manual_url=manual_url)
    if not r.get("ok") or r.get("skipped"):
        # skipped 的结果里没有 pdf：照原样往下走会 KeyError，被上层 except
        # 兜底写成 failed —— 一件已交付的货就变成"失败"了。跳过就到此为止。
        return r
    r2 = llm_stage(item, pdf=r["pdf"], url=r["url"])
    if not r2.get("ok"):
        return r2
    return finish_item(item, r2["doc"], sheet_url=r.get("sheet_url", ""))


def finish_item(item: dict, doc: dict, *, sheet_url: str = "") -> dict:
    """JSON 已就绪时跑完交付物料：内链 -> 详情页+图片SEO -> 三视图 -> 落状态。

    在线解析与 Batch 回填都调这里，保证两条路径的产物完全一致。
    """
    item_id = item["id"]
    mpn = item["mpn"]
    mpn_key = item["mpn_key"]
    try:
        meta = json.loads(item.get("meta") or "{}")
    except json.JSONDecodeError:
        meta = {}
    if sheet_url:
        meta["sheet_url"] = sheet_url

    errors: list[str] = []

    # ---- 3. 内链（替代型号，AI 按需匹配站内目录）
    alt_res = build_alternatives(doc, mpn)
    _log_calls(item_id, mpn_key, [alt_res.get("llm_call")] if alt_res.get("llm_call") else [])
    if alt_res.get("error"):
        errors.append("alternatives: " + alt_res["error"])
    if alt_res["rows"]:
        # 板载器件不是整板的替代型号，不写进详情页的 orderable/alternatives 表
        doc["alternatives"] = [
            {"mpn": r["mpn"], "manufacturer": r.get("manufacturer", ""),
             "reason": r.get("feature", ""), "package": r.get("package", "")}
            for r in alt_res["rows"]
            if r.get("internal") and r.get("basis") != "onboard-device"
        ]
    db.set_item(item_id, alt_json_path=alt_res.get("json", ""),
                alt_html_path=alt_res.get("html", ""))
    db.touch_status(item_id, "rendering", _alts_status(alt_res), 72)

    # ---- 4. 详情页片段 + 图片 SEO
    txt_path = ""
    seo_path = ""
    seo_plan: dict = {}
    try:
        import json_to_txt
        html = json_to_txt.render(doc)
        seo_plan = seo_image.build(doc, mpn)
        html = seo_image.optimize_html(html, seo_plan)
        config.TXT.mkdir(parents=True, exist_ok=True)
        p = config.TXT / f"{safe_name(mpn)}.txt"
        p.write_text(html, encoding="utf-8")
        txt_path, seo_path = str(p), seo_plan.get("_path", "")
        db.add_event(f"详情页片段 {len(html) / 1024:.1f} KB，配图 SEO {len(seo_plan['images'])} 张",
                     kind="render", item_id=item_id)
    except Exception as e:                                       # noqa: BLE001
        errors.append("render: " + f"{type(e).__name__}: {e}"[:180])
        db.add_event("详情页渲染失败", kind="error", item_id=item_id, detail=str(e))
    db.set_item(item_id, txt_path=txt_path, seo_path=seo_path)
    db.touch_status(item_id, "rendering", "生成三视图", 85)

    # ---- 5. 三视图（封装/3D 走共享图库，原理图符号内联）
    sym_path = ""
    pkg_info: dict = {}
    try:
        import symbol_svg
        from . import pkg_lib
        # 先确保该封装的共享图存在（缺就生成一次），再渲染 —— 同封装的型号从此共用一张
        pkg_info = pkg_lib.ensure_for_doc(doc)
        page = symbol_svg.render_page(doc, pkg_dir=config.PKGS)
        if page:
            config.SYMBOLS.mkdir(parents=True, exist_ok=True)
            p = config.SYMBOLS / f"{safe_name(mpn)}.html"
            p.write_text(page, encoding="utf-8")
            sym_path = str(p)
    except Exception as e:                                       # noqa: BLE001
        errors.append("symbols: " + f"{type(e).__name__}: {e}"[:180])
    db.set_item(item_id, symbol_path=sym_path)

    # ---- 6. 收尾
    sections = _sections(txt_path)
    specs = doc.get("specs") or {}
    meta.update({
        "electrical": len(specs.get("electrical") or []),
        "pins": len(doc.get("pin_configuration") or []),
        "confidence": ((doc.get("metadata") or {}).get("confidence") or 0),
        "sections": sections,
        "alts_total": alt_res["total"],
        "alts_linked": alt_res["linked"],
        "alts_ai": bool(alt_res.get("ai_used")),
        "alts_board": bool(alt_res.get("board")),
        "alts_onboard": alt_res.get("onboard_mpn", ""),
        "alts_mode": alt_res.get("ai_mode", ""),
        "alts_covered": alt_res.get("catalog_covered"),
        "seo_images": len(seo_plan.get("images") or []),
        "device_mpn": ((doc.get("basic_info") or {}).get("mpn") or ""),
        "mfr": ((doc.get("basic_info") or {}).get("manufacturer") or ""),
        "pkg": ((specs.get("package") or {}).get("type") or ""),
        "pkg_key": pkg_info.get("key", ""),
        "pkg_shared": bool(pkg_info.get("shared")),
        "pkg_generated": bool(pkg_info.get("generated")),
    })
    db.set_item(item_id, meta=json.dumps(meta, ensure_ascii=False),
                error="; ".join(errors)[:2000])
    db.touch_status(item_id, "done", "交付物已生成", 100,
                    "; ".join(errors)[:2000] if errors else "")
    db.add_event("处理完成" + (f"（{len(errors)} 项降级）" if errors else ""),
                 kind="done", item_id=item_id,
                 detail="; ".join(errors)[:2000])
    return {"ok": True, "sections": sections, "errors": errors}


def _log_calls(item_id: int, mpn_key: str, calls: list[dict]) -> None:
    """把模型调用的 token / 耗时落进 llm_usage。记账失败绝不能拖垮解析。"""
    for c in calls:
        if not c:
            continue
        try:
            usage.record(item_id=item_id, mpn_key=mpn_key, stage=c.get("stage", "parse"),
                         model=c.get("model", ""), provider=c.get("provider", ""),
                         usage=c.get("usage") or {}, latency_ms=c.get("latency_ms", 0),
                         ok=bool(c.get("ok", True)), error=c.get("error", ""),
                         attempt=int(c.get("attempt", 1)))
        except Exception as e:                                   # noqa: BLE001
            db.add_event("用量记账失败", kind="error", item_id=item_id,
                         detail=f"{type(e).__name__}: {e}"[:300])


def _sections(txt_path: str) -> list[str]:
    if not txt_path or not Path(txt_path).exists():
        return []
    html = Path(txt_path).read_text(encoding="utf-8", errors="ignore")
    return re.findall(r'id="([a-z\-]+)"', html)


# ---------------------------------------------------------------- 批次入库
def ingest_parts(path: Path, filename: str, sha: str = "") -> dict:
    """型号表 -> batch + item（按 mpn_key 去重，已存在的复用旧行）。"""
    from .parts import read_parts_table

    rows = read_parts_table(path, limit=config.MAX_ITEMS_PER_UPLOAD)
    if not rows:
        raise ValueError("型号表里没有解析到任何型号，请确认表头或第一列是否为型号")

    batch_id = db.x(
        "INSERT INTO batch (kind,filename,stored_path,sha256,total_rows,unique_mpns,status,"
        "progress,created_at) VALUES ('parts',?,?,?,?,?,'running',0,?)",
        (filename, str(path), sha, len(rows), len(rows), db.now()))

    stamp = db.now()
    created = reused = 0
    for r in rows:
        cur = db.q1("SELECT id,status,brand,meta FROM item WHERE mpn_key=?", (r["mpn_key"],))
        hints = {"sheet_url": r["url"], "pkg_hint": r["package"],
                 "packaging": r["packaging"], "desc_hint": r["description"]}
        if cur:
            item_id = cur["id"]
            reused += 1
            # 补齐此前空着的品牌与表内线索（不覆盖已有值）
            try:
                old = json.loads(cur.get("meta") or "{}")
            except json.JSONDecodeError:
                old = {}
            for k, v in hints.items():
                if v and not old.get(k):
                    old[k] = v
            db.x("UPDATE item SET brand=?, meta=?, updated_at=? WHERE id=?",
                 (cur.get("brand") or r["brand"], json.dumps(old, ensure_ascii=False),
                  stamp, item_id))
        else:
            meta = json.dumps({k: v for k, v in hints.items() if v}, ensure_ascii=False)
            item_id = db.x(
                "INSERT INTO item (batch_id,mpn,mpn_key,brand,status,stage,meta,created_at,updated_at) "
                "VALUES (?,?,?,?,'pending','待处理',?,?,?)",
                (batch_id, r["mpn"], r["mpn_key"], r["brand"], meta, stamp, stamp))
            created += 1
        db.x("INSERT OR IGNORE INTO item_batch (item_id,batch_id) VALUES (?,?)", (item_id, batch_id))

    truncated = len(rows) >= config.MAX_ITEMS_PER_UPLOAD
    db.x("UPDATE batch SET status='ready', progress=100, note=? WHERE id=?",
         (f"新增 {created} / 复用 {reused}"
          + (f"（已达单批上限 {config.MAX_ITEMS_PER_UPLOAD}，超出部分未入库）" if truncated else ""),
          batch_id))
    db.add_event(f"上传型号表 {filename}：{len(rows)} 个型号（新增 {created}，复用 {reused}）"
                 + ("，已截断" if truncated else ""),
                 kind="upload", batch_id=batch_id)
    return {"batch_id": batch_id, "rows": len(rows), "created": created, "reused": reused,
            "truncated": truncated, "cap": config.MAX_ITEMS_PER_UPLOAD}
