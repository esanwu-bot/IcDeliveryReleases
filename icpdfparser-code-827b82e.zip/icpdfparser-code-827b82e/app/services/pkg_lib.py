"""封装图库（共享三视图）：按 package_type 生成一次，全站同封装型号共用。

为什么能共用
------------
封装俯视图与 3D 示意只由「封装族 + 脚数」决定，跟具体型号无关：
TI 的 SOIC-16 和 ADI 的 SOIC-16 是同一套 JEDEC 尺寸，画出来一模一样。
所以正确做法不是每个型号画一张，而是：

    型号  ->  canon_pkg(package_type, pins)  ->  KEY（如 TSSOP-38）
          ->  data/pkgs/{KEY}.svg + {KEY}.3d.svg 命中则引用
          ->  没命中就当场生成一次，之后所有同封装型号共用

原理图符号不能共享——它带引脚名（AVDD / REFEN / GPIO2），是型号特有的，仍然内联。

与 build_pkg_lib.py 的关系
--------------------------
命令行版本（build_pkg_lib.py）是「预先批量铺满」：--preset 一次生成 85 种常见封装。
这里是「按需补齐」：跑到没见过的新封装时生成一次，让在线链路不用等人工铺库。
两者产物完全一致（同一套 footprint_svg / model3d_svg / 同样的 KEY），可以混用。
"""
from __future__ import annotations

import csv
import os
import threading
from pathlib import Path

import symbol_svg as S

from .. import config, db

# RLock 而不是 Lock：ensure() 持锁期间会调 _index_append()，后者也要这把锁
_lock = threading.RLock()


# ---------------------------------------------------------------- 归一
def key_of(doc: dict) -> dict | None:
    """从解析结果算出共享图 KEY。板卡/模块类返回 None（每块板都不一样，不共享）。"""
    pins = S.pins_of(doc)
    if len(pins) < 2:
        return None
    pkg = S.package_of(doc, len(pins))
    declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
    n = declared or len(pins)
    key = S.canon_pkg(pkg, n)
    fam = S.pkg_family(key)
    if fam == "other" or not n:
        return None
    return {"key": key, "family": fam, "pins": n, "raw": pkg,
            "n_pins_parsed": len(pins)}


def has(key: str) -> bool:
    d = config.PKGS
    return (d / f"{key}.svg").exists() and (d / f"{key}.3d.svg").exists()


# ---------------------------------------------------------------- 生成
def _write_atomic(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _index_append(key: str, family: str, pins: int, raw: str) -> None:
    """往 index.csv 追加一行（只做台账，不影响渲染）。并发写失败不致命。"""
    path = config.PKGS / "index.csv"
    try:
        with _lock:
            exists = path.exists()
            if exists:
                with open(path, encoding="utf-8-sig", newline="") as fh:
                    for row in csv.DictReader(fh):
                        if (row.get("key") or "") == key:
                            return
            with open(path, "a", encoding="utf-8-sig", newline="") as fh:
                w = csv.writer(fh)
                if not exists:
                    w.writerow(["key", "family", "pins", "n_models", "raw_types",
                                "sample_models", "footprint", "model3d"])
                w.writerow([key, family, pins, 0, raw or "(on-demand)", "",
                            f"{key}.svg", f"{key}.3d.svg"])
    except OSError:
        pass


def ensure(key: str, family: str, pins: int, raw: str = "") -> dict:
    """确保 {KEY}.svg / {KEY}.3d.svg 存在；缺就生成一次。"""
    if has(key):
        return {"ok": True, "key": key, "generated": False}
    with _lock:
        if has(key):                                  # 双检：另一个线程刚生成完
            return {"ok": True, "key": key, "generated": False}
        fake = [(i, "") for i in range(1, pins + 1)]   # 共享图只要脚号，不要引脚名
        err = S.verify_footprint(fake, key, pins)
        if err:
            return {"ok": False, "key": key, "generated": False, "error": err}
        try:
            fp = S.footprint_svg(fake, key, pins)
            md = S.model3d_svg(fake, key)
            config.PKGS.mkdir(parents=True, exist_ok=True)
            _write_atomic(config.PKGS / f"{key}.svg", fp)
            _write_atomic(config.PKGS / f"{key}.3d.svg", md)
        except Exception as e:                        # noqa: BLE001
            return {"ok": False, "key": key, "generated": False,
                    "error": f"{type(e).__name__}: {e}"}
        _index_append(key, family, pins, raw)
        return {"ok": True, "key": key, "generated": True}


def ensure_for_doc(doc: dict) -> dict:
    """渲染三视图前调用。返回 {shared, key, family, pins, generated, error}。"""
    info = key_of(doc)
    if not info:
        return {"shared": False, "key": "", "family": "other", "pins": 0, "generated": False}
    res = ensure(info["key"], info["family"], info["pins"], info["raw"])
    out = {"shared": bool(res["ok"]), "key": info["key"], "family": info["family"],
           "pins": info["pins"], "raw": info["raw"], "generated": bool(res.get("generated"))}
    if res.get("error"):
        out["error"] = res["error"]
    return out


# ---------------------------------------------------------------- 盘点 / 回填
def _iter_parsed():
    for f in sorted(config.PARSED.glob("*.json")):
        try:
            import json
            yield f.stem, json.loads(f.read_text(encoding="utf-8"))
        except Exception:                             # noqa: BLE001
            continue


def report() -> dict:
    """覆盖率：多少型号能命中共享封装图，多少属于「每块都不同」的板卡。"""
    by_mpn: dict[str, dict | None] = {}
    for stem, doc in _iter_parsed():
        mpn = ((doc.get("basic_info") or {}).get("mpn") or "").strip() or stem
        by_mpn[mpn] = key_of(doc)          # 同一型号有多份 JSON 时只算一次
    total = shared = board = nokey = 0
    missing: dict[str, dict] = {}
    for mpn, info in by_mpn.items():
        total += 1
        if not info:
            board += 1
            continue
        if has(info["key"]):
            shared += 1
        else:
            nokey += 1
            row = missing.setdefault(info["key"], {"key": info["key"], "family": info["family"],
                                                   "pins": info["pins"], "n": 0, "raw": info["raw"]})
            row["n"] += 1
    return {"models": total, "shared": shared, "missing_key": nokey, "board": board,
            "lib_keys": len(list(config.PKGS.glob("*.3d.svg"))),
            "missing": sorted(missing.values(), key=lambda x: -x["n"])}


def backfill() -> dict:
    """扫 data/parsed/*.json，把库里没有的封装一次性补齐。"""
    made, ok, bad = [], 0, []
    seen: set[str] = set()
    for stem, doc in _iter_parsed():
        info = key_of(doc)
        if not info or info["key"] in seen:
            continue
        seen.add(info["key"])
        res = ensure(info["key"], info["family"], info["pins"], info["raw"])
        if res["ok"]:
            ok += 1
            if res["generated"]:
                made.append(info["key"])
        else:
            bad.append({"key": info["key"], "error": res.get("error", "")})
    if made:
        db.add_event(f"封装图库按需补齐 {len(made)} 种：{', '.join(made[:12])}",
                     kind="pkg")
    return {"keys": ok, "generated": made, "failed": bad}
