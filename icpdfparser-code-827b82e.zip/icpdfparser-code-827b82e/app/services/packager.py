"""交付物盘点与打包导出（单型号 / 整批次）。"""
from __future__ import annotations

import csv
import io
import json
import time
import zipfile
from pathlib import Path

from .. import config, db
from .parts import safe_name

# (键, 中文名, item 列, 解压后的文件名后缀)
ARTIFACTS = [
    ("pdf", "Datasheet 原件", "pdf_path", ".pdf"),
    ("json", "结构化 JSON", "json_path", ".json"),
    ("txt", "详情页 HTML 片段", "txt_path", ".html"),
    ("alt_json", "替代型号 JSON", "alt_json_path", ".alts.json"),
    ("alt_html", "替代型号内链片段", "alt_html_path", ".alts.html"),
    ("symbol", "三视图 HTML", "symbol_path", ".symbols.html"),
    ("seo", "图片 SEO 清单", "seo_path", ".seo.json"),
]

ART_LABEL = {k: n for k, n, _, _ in ARTIFACTS}

# 详情页多语言变体（json_to_txt.py --langs 产出的 {mpn}.{lang}.txt）
I18N_LANGS = ["ja", "ko", "de", "es"]
I18N_LABEL = {"ja": "日语", "ko": "韩语", "de": "德语", "es": "西班牙语"}


def artifacts(item: dict) -> list[dict]:
    stem = safe_name(item["mpn"])
    out = []
    for key, label, col, suffix in ARTIFACTS:
        p = (item.get(col) or "").strip()
        # 库里存的是落库机器的绝对路径，跨机部署后按目录+文件名回退解析
        path = config.resolve_artifact(p, config.ARTIFACT_DIRS[col]) if p else None
        ok = bool(path and path.name and path.exists())
        out.append({
            "key": key, "label": label, "path": str(path) if ok else "",
            "exists": ok,
            "size": path.stat().st_size if ok else 0,
            "filename": f"{stem}{suffix}",
            "url": f"/api/items/{item['mpn_key']}/artifact/{key}" if ok else "",
        })
    # 详情页语言变体：与 txt 同目录的 {mpn}.{lang}.txt，存在才纳入
    txt_entry = next((a for a in out if a["key"] == "txt" and a["exists"]), None)
    if txt_entry:
        base = Path(txt_entry["path"])
        for lang in I18N_LANGS:
            cand = base.with_name(f"{base.stem}.{lang}.txt")
            if cand.exists():
                out.append({
                    "key": f"txt_{lang}",
                    "label": f"详情页 HTML 片段（{I18N_LABEL[lang]}）",
                    "path": str(cand), "exists": True, "size": cand.stat().st_size,
                    "filename": f"{stem}.{lang}.html",
                    "url": f"/api/items/{item['mpn_key']}/artifact/txt_{lang}",
                })
    return out


def _manifest_csv(item: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["型号", "品牌", "状态", "采集来源", "PDF 链接", "PDF SHA256",
                "最近解析时间", "解析次数", "解析耗时(ms)"])
    w.writerow([item["mpn"], item.get("brand", ""), item.get("status", ""),
                item.get("provider", ""), item.get("pdf_url", ""), item.get("pdf_sha256", ""),
                item.get("last_parsed_at", ""), item.get("parse_count", 0),
                item.get("parse_ms", 0)])
    return buf.getvalue()


def zip_item(item: dict) -> Path:
    config.EXPORTS.mkdir(parents=True, exist_ok=True)
    stem = safe_name(item["mpn"])
    dest = config.EXPORTS / f"{stem}_{time.strftime('%Y%m%d-%H%M%S')}.zip"
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for a in artifacts(item):
            if a["exists"]:
                z.write(a["path"], f"{stem}/{a['filename']}")
        z.writestr(f"{stem}/_manifest.csv", _manifest_csv(item))
        if item.get("meta"):
            z.writestr(f"{stem}/_meta.json", item["meta"])
    return dest


def zip_batch(batch_id: int, name: str = "") -> Path:
    items = db.q("SELECT i.* FROM item i JOIN item_batch b ON b.item_id=i.id WHERE b.batch_id=?",
                 (batch_id,))
    config.EXPORTS.mkdir(parents=True, exist_ok=True)
    label = safe_name(name or f"batch{batch_id}")
    dest = config.EXPORTS / f"{label}_{time.strftime('%Y%m%d-%H%M%S')}.zip"
    lines = ["型号,品牌,状态,采集来源,PDF链接,最近解析时间,解析次数,交付物"]
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for it in items:
            arts = artifacts(it)
            got = [a for a in arts if a["exists"]]
            if got:
                stem = safe_name(it["mpn"])
                for a in got:
                    z.write(a["path"], f"{stem}/{a['filename']}")
            lines.append(",".join('"' + str(v).replace('"', "'") + '"' for v in [
                it["mpn"], it.get("brand", ""), it.get("status", ""), it.get("provider", ""),
                it.get("pdf_url", ""), it.get("last_parsed_at", ""), it.get("parse_count", 0),
                str(len([a for a in arts if a["exists"]])) + "/7"]))
        z.writestr("_batch.csv", "\n".join(lines))
    return dest


def summary(item: dict) -> dict:
    arts = artifacts(item)
    raw = item.get("meta")
    if isinstance(raw, dict):
        meta = raw
    else:
        try:
            meta = json.loads(raw or "{}")
        except json.JSONDecodeError:
            meta = {}
    return {"artifacts": arts, "meta": meta,
            "ready": sum(1 for a in arts if a["exists"]), "total": len(arts)}
