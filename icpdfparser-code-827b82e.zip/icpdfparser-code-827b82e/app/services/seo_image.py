"""图片 SEO：按「应用领域图片命名表」给详情页 #application 段配图做 alt / title / 文件名。

规则来源是最新上传的命名表（app_image 表 + data/app_images.csv），不是硬编码。
产出两样东西：
  1. data/seo/{型号}.json —— 可直接交给 CMS / 前端复用的图片 SEO 清单；
  2. 详情页 HTML 片段里的 <img> 被替换为带 alt/title 的 SEO 版本。
"""
from __future__ import annotations

import json
import re
from typing import Any

from .. import config, db
from .parts import safe_name

IMG_TAG = re.compile(r"<img\b[^>]*>", re.I)
ALT_MAX = 125          # Google 建议 alt 上限
TITLE_MAX = 70


def _renderer():
    import json_to_txt
    return json_to_txt


def _img_records(doc: dict, mpn: str) -> list[dict]:
    """型号的应用领域 -> 命名表里的类别与图片文件。"""
    jt = _renderer()
    apps = [re.sub(r"\s+", " ", str(a)).strip() for a in (doc.get("applications") or [])]
    apps = [a for a in apps if a][:4]
    out = []
    for app in apps:
        try:
            image = jt.pick_icon(app)
            category = jt.pick_category(app)
        except Exception:                                    # noqa: BLE001
            image, category = "app-industrial-automation.png", "Industrial Automation"
        base = image.rsplit(".", 1)[0]
        alt = f"{mpn} {app} application — {category} illustration"
        if len(alt) > ALT_MAX:
            alt = alt[:ALT_MAX - 1].rstrip(" ,—-") + "…"
        title = f"{mpn} used in {app} ({category})"
        if len(title) > TITLE_MAX:
            title = title[:TITLE_MAX - 1].rstrip() + "…"
        out.append({
            "application": app,
            "category": category,
            "image": image,
            "filename": f"{safe_name(mpn).lower()}-{base.replace('app-', '')}.png",
            "asset": f"/upload/img/{image}",
            "alt": alt,
            "title": title,
            "caption": f"{app} — a typical {category.lower()} application of {mpn}.",
            "width": 64, "height": 64,
            "loading": "lazy", "decoding": "async",
            "_key": base,
        })
    return out


def _shared_stats(images: list[dict]) -> dict:
    """共享分类图统计。

    应用领域只有 4 类，分类配图却常被多类复用（工业自动化同时服务温度与系统监控）。
    下游要按图数做去重/缓存，就必须知道「4 条记录其实只有 2 张图」——
    不标出来，会把同一张图当两个 asset 各传一次。
    """
    by_icon: dict[str, list[str]] = {}
    for r in images:
        icon = str(r.get("image") or "")
        if icon:
            by_icon.setdefault(icon, []).append(str(r.get("application") or ""))
    distinct = sorted(by_icon)
    shared = {k: v for k, v in by_icon.items() if len(v) > 1}
    return {
        "distinct_images": distinct,
        "distinct_image_count": len(distinct),
        "shared_icon_count": len(shared),
        "shared_by_applications": {k: v for k, v in shared.items()},
        "shared_category_icon": bool(shared),
    }


def _subject(doc: dict) -> dict:
    """页面主体的归属（V9 P1-2）。

    芯片手册被用来交付评估板时（`ADS8568EVM-PDK` 挂的是 ADS8568 的 SBAS543），
    侧车里的标题/描述不带主体，搜索引擎与任何读侧车的下游都会把芯片参数
    当成整板能力。页面正文里写了声明，但**结构化数据不能只靠正文**。
    """
    sp = doc.get("specs") or {}
    bi = doc.get("basic_info") or {}
    ods = sp.get("onboard_device_specs") or {}
    scope = str(sp.get("scope") or "")
    device = str(ods.get("device_mpn")
                 or (sp.get("package") or {}).get("onboard_device") or "")
    if scope == "onboard_device" and device:
        return {"data_subject": device, "attribution": "onboard_device",
                "subject_note": (f"Parameter values on this page describe the onboard "
                                 f"{device}; they are not limits of the assembled board.")}
    return {"data_subject": str(bi.get("mpn") or ""),
            "attribution": "board_level" if scope == "board" else "device",
            "subject_note": ""}


def build(doc: dict, mpn: str) -> dict:
    """生成图片 SEO 清单并落盘。"""
    images = _img_records(doc, mpn)
    seo = doc.get("seo") or {}
    stats = _shared_stats(images)
    payload: dict[str, Any] = {
        "mpn": mpn,
        "generated_at": db.now(),
        "table": {
            "source": db.kv_get("images_source", ""),
            "imported_at": db.kv_get("images_imported_at", ""),
            "categories": len(db.q("SELECT 1 FROM app_image")),
        },
        "page": {
            "title_en": seo.get("title_en", ""),
            "title_zh": seo.get("title_zh", ""),
            "meta_description_en": seo.get("meta_description_en", ""),
            "meta_description_zh": seo.get("meta_description_zh", ""),
            "keywords": seo.get("keywords") or [],
        },
        # 共享图统计与 images 同级：不做进进 images 里，避免每条重复一遍
        "shared_category_icon": stats["shared_category_icon"],
        "shared_icon_count": stats["shared_icon_count"],
        "shared_by_applications": stats["shared_by_applications"],
        "distinct_images": stats["distinct_images"],
        "distinct_image_count": stats["distinct_image_count"],
        "images": [{k: v for k, v in r.items() if not k.startswith("_")} for r in images],
    }
    # 主体归属随侧车一起落盘：下游（发布、结构化数据、检索）拿到的是同一个答案，
    # 不必再去 join manifest 的 document_subject / data_subject 两列。
    payload["subject"] = _subject(doc)
    payload["page"].update({k: v for k, v in payload["subject"].items() if k != "subject_note"})
    path = config.SEO / f"{safe_name(mpn)}.json"
    config.SEO.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    payload["_path"] = str(path)
    payload["_raw"] = images
    return payload


def optimize_html(html: str, plan: dict) -> str:
    """把 #application 段里的 <img> 换成 SEO 版本（数量对不上就只加 title）。"""
    records = plan.get("_raw") or []
    if not html or not records:
        return html
    anchor = html.find('id="application"')
    if anchor < 0:
        return html
    end = html.find("</section>", anchor)
    if end < 0:
        end = len(html)
    head, body, tail = html[:anchor], html[anchor:end], html[end:]

    tags = list(IMG_TAG.finditer(body))
    if not tags:
        return html
    out, last = [], 0
    for i, m in enumerate(tags):
        out.append(body[last:m.start()])
        rec = records[i] if i < len(records) else None
        if rec:
            out.append(
                f'<img src="{rec["asset"]}" width="{rec["width"]}" height="{rec["height"]}" '
                f'alt="{_esc(rec["alt"])}" title="{_esc(rec["title"])}" '
                f'loading="{rec["loading"]}" decoding="{rec["decoding"]}" />')
        else:
            out.append(m.group(0))
        last = m.end()
    out.append(body[last:])
    return head + "".join(out) + tail


def _esc(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))
