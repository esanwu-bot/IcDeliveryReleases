"""百炼 Batch（异步批处理）：把积压型号的 LLM 解析挪出在线并发，走 5 折价格。

流程四段，各是一条命令，互不耦合：

    emit    型号 -> JSONL 请求文件（本地抽文本 + is_datasheet 预检，不合格的不进批次）
    submit  上传 JSONL -> 创建 batch 任务
    status  查任务状态 / 进度
    ingest  下载结果 -> 写 data/parsed -> 走 finish_item 生成交付物

为什么值得单独做：在线链路一个型号要 66~156 秒，Batch 不占在线槽位，
且百炼异步批处理按 5 折计费。代价是延迟（分钟到小时级），适合历史积压而不是即时要看的结果。

接口走 DashScope 的 OpenAI 兼容模式（/files、/batches），与 /chat/completions 同一套 key。
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import requests

from .. import config, db
from . import pipeline, usage

BASE = os.getenv("ICPDF_BATCH_BASE",
                 "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
MODEL = os.getenv("ICPDF_BATCH_MODEL") or os.getenv("DASHSCOPE_MODEL", "qwen-flash")
DIR = config.DATA / "batch"


def _key() -> str:
    return (os.getenv("DASHSCOPE_API_KEY", "") or "").strip()


def _headers(json_body: bool = False) -> dict:
    h = {"Authorization": f"Bearer {_key()}"}
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def _check() -> None:
    if not _key():
        raise RuntimeError("没配 DASHSCOPE_API_KEY（.env.local），Batch 通道不可用")


# ---------------------------------------------------------------- emit
def emit(limit: int = 200, mpn_keys: list[str] | None = None,
         chunk: int = 1000, download: bool = True) -> dict:
    """把待解析型号的 PDF 文本打成 Batch 请求文件。

    custom_id 用归一化料号，回填时靠它精确对回型号（模型可能改写 basic_info.mpn）。
    没下载过的型号会先走一次采集下载（download=True），否则 Batch 覆盖不到积压队列。
    """
    import parse_datasheets as pd

    from . import collector

    where = ["status IN ('pending','failed','nodata')"]
    args: list = []
    if mpn_keys:
        marks = ",".join("?" * len(mpn_keys))
        where = [f"mpn_key IN ({marks})"]
        args = list(mpn_keys)

    rows = db.q("SELECT * FROM item WHERE " + " AND ".join(where) + " ORDER BY id LIMIT ?",
                (*args, int(limit)))
    DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    files: list[Path] = []
    buf: list[dict] = []
    kept = skipped = no_pdf = unreadable = 0

    def flush() -> None:
        nonlocal buf
        if not buf:
            return
        p = DIR / f"{stamp}-part{len(files) + 1}.jsonl"
        with open(p, "w", encoding="utf-8") as fh:
            for obj in buf:
                fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
        files.append(p)
        buf = []

    for r in rows:
        pdf = Path(r.get("pdf_path") or "")
        if not pdf.exists():
            if not download:
                no_pdf += 1
                continue
            try:
                meta = json.loads(r.get("meta") or "{}")
            except json.JSONDecodeError:
                meta = {}
            hit = collector.fetch_datasheet(
                r["mpn"], r["mpn_key"], brand=r.get("brand", ""),
                sheet_url=meta.get("sheet_url", ""),
                cached_url=r.get("pdf_url", "") if r.get("status") != "pending" else "")
            if not hit["ok"]:
                db.touch_status(r["id"], "nodata", "Batch 阶段未找到 PDF", 20,
                                "所有采集来源均未取到 PDF")
                no_pdf += 1
                continue
            pdf = Path(hit["path"])
            db.set_item(r["id"], pdf_url=hit["url"], pdf_path=str(pdf),
                        pdf_sha256=hit["sha256"], pdf_bytes=hit["bytes"],
                        provider=hit["provider"])
        try:
            text, total, used, has_text = pd.extract_pdf_text(pdf)
        except Exception as e:                                   # noqa: BLE001
            unreadable += 1
            db.touch_status(r["id"], "failed", "PDF 无法抽取文本", 100,
                            f"{type(e).__name__}: {e}"[:300])
            continue
        if not has_text:
            unreadable += 1
            db.touch_status(r["id"], "failed", "PDF 无文本层（需 OCR）", 100,
                            "PDF_UNREADABLE: 无文本层")
            continue
        if not pd.is_datasheet(text):
            # 本地就能判掉的（User Guide / 扫描件）不要送进批次，白花钱
            skipped += 1
            db.touch_status(r["id"], "skipped", "非 Datasheet，Batch 前已跳过", 100,
                            "NOT_A_DATASHEET: 无参数表特征词")
            continue
        body = {
            "model": MODEL,
            "messages": [
                {"role": "system", "content": pd.SYSTEM_PROMPT},
                {"role": "user", "content": pd.USER_TMPL.format(
                    mpn=r["mpn"], fname=pdf.name, pages_used=used, pages_total=total,
                    text=text)},
            ],
            "temperature": 0.1,
            "max_tokens": 8000,
            "response_format": {"type": "json_object"},
        }
        buf.append({"custom_id": r["mpn_key"], "method": "POST",
                    "url": "/v1/chat/completions", "body": body})
        kept += 1
        if len(buf) >= chunk:
            flush()
    flush()

    if files:
        db.kv_set("batch:last_emit", json.dumps(
            {"files": [str(p) for p in files], "count": kept, "at": db.now(),
             "model": MODEL}, ensure_ascii=False))
        db.add_event(f"Batch 请求文件已生成：{kept} 条 / {len(files)} 个文件", kind="batch",
                     detail=", ".join(p.name for p in files))
    return {"files": [str(p) for p in files], "requests": kept,
            "skipped_local": skipped, "no_pdf": no_pdf, "unreadable": unreadable,
            "model": MODEL,
            "bytes": sum(p.stat().st_size for p in files) if files else 0}


# ---------------------------------------------------------------- submit / status
def submit(path: str) -> dict:
    _check()
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    with open(p, "rb") as fh:
        r = requests.post(f"{BASE}/files", headers=_headers(),
                          files={"file": (p.name, fh, "application/jsonl")},
                          data={"purpose": "batch"}, timeout=300)
    if r.status_code >= 300:
        raise RuntimeError(f"上传失败 HTTP {r.status_code}: {r.text[:300]}")
    fid = r.json().get("id")
    r2 = requests.post(f"{BASE}/batches", headers=_headers(True), timeout=120,
                       json={"input_file_id": fid, "endpoint": "/v1/chat/completions",
                             "completion_window": "24h"})
    if r2.status_code >= 300:
        raise RuntimeError(f"创建批次失败 HTTP {r2.status_code}: {r2.text[:300]}")
    info = r2.json()
    db.kv_set("batch:last", json.dumps(
        {"id": info.get("id"), "input_file_id": fid, "file": str(p), "at": db.now()},
        ensure_ascii=False))
    db.add_event(f"Batch 任务已提交：{info.get('id')}", kind="batch", detail=str(p))
    return info


def status(batch_id: str) -> dict:
    _check()
    r = requests.get(f"{BASE}/batches/{batch_id}", headers=_headers(), timeout=60)
    if r.status_code >= 300:
        raise RuntimeError(f"查询失败 HTTP {r.status_code}: {r.text[:300]}")
    return r.json()


def last() -> dict | None:
    raw = db.kv_get("batch:last", "")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


# ---------------------------------------------------------------- ingest
def ingest(batch_id: str) -> dict:
    """下载批次结果，写回 data/parsed 并生成交付物。"""
    _check()
    b = status(batch_id)
    state = b.get("status") or ""
    if state != "completed":
        return {"ok": False, "status": state,
                "counts": b.get("request_counts") or {}, "message": "批次未完成"}
    out_id = b.get("output_file_id")
    if not out_id:
        return {"ok": False, "status": state, "message": "没有 output_file_id"}

    r = requests.get(f"{BASE}/files/{out_id}/content", headers=_headers(), timeout=300)
    if r.status_code >= 300:
        raise RuntimeError(f"下载结果失败 HTTP {r.status_code}: {r.text[:300]}")

    import parse_datasheets as pd

    ok = bad = 0
    errors: list[str] = []
    for line in r.text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            mpn_key = obj.get("custom_id")
            body = obj["response"]["body"]
            content = body["choices"][0]["message"]["content"]
            u = body.get("usage") or {}
        except (KeyError, json.JSONDecodeError, IndexError) as e:
            bad += 1
            errors.append(f"解析结果行失败：{type(e).__name__}")
            continue

        item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))
        if not item:
            bad += 1
            continue
        try:
            doc = pd.parse_json_loose(content)
            errs = pd.validate(doc)
            if errs:
                bad += 1
                db.touch_status(item["id"], "failed", "Batch 结果校验失败", 100, "; ".join(errs))
                errors.append(f"{item['mpn']}: {'; '.join(errs)}")
                continue

            meta = doc.setdefault("metadata", {})
            meta.setdefault("parse_timestamp", db.now())
            meta["model_version"] = MODEL
            meta["requested_mpn"] = item["mpn"]
            meta["batch_id"] = batch_id
            bi = doc.setdefault("basic_info", {})
            if not bi.get("datasheet_url"):
                bi["datasheet_url"] = item.get("pdf_url", "")

            # ---- 与在线解析同一道最终闸门（2026-11-04 收口）----
            # 这里曾是一条**绕过 final_gate 的写盘路径**：只跑 validate 就把 doc
            # 写进 data/parsed。Batch 回填出来的件因此可以带着核心硬错误躺进
            # 正式目录，而在线那条路却被闸门拦下 —— 同一个 data/parsed 两种准入。
            # 回填拿不到正文，确定性抽取这一步天然缺席（det_rep 传空），这不影响
            # 「核心字段是否齐」的判定：check_core 只看 doc 本身。
            from qc import core_validation as _CV                  # noqa: PLC0415
            from qc import deterministic_extract as DE             # noqa: PLC0415

            core_errs = DE.check_core(doc, {}) + DE.check_acceptance(doc, item["mpn"])
            status_final, errs_final = pd.final_gate(doc, core_errs)
            if status_final == "failed":
                bad += 1
                db.touch_status(item["id"], "failed", "Batch 结果未通过最终闸门",
                                100, "; ".join(errs_final))
                errors.append(f"{item['mpn']}: {'; '.join(errs_final)}")
                continue
            meta["accept_status"] = status_final
            meta["core_validation"] = _CV.stamp(meta, doc, core_errs or _CV.PASS)
            if core_errs:
                meta["accept_core_errs"] = list(core_errs)

            from .parts import safe_name
            out = config.PARSED / f"{safe_name(item['mpn'])}_{(item.get('pdf_sha256') or 'batch')[:8]}.json"
            out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
            db.set_item(item["id"], json_path=str(out), last_parsed_at=db.now(),
                        parse_count=(item.get("parse_count") or 0) + 1)
            usage.record(item_id=item["id"], mpn_key=item["mpn_key"], stage="parse",
                         model=MODEL, provider=usage.provider_of(BASE), usage=u,
                         latency_ms=0, ok=True)
            pipeline.finish_item(item, doc)
            ok += 1
        except Exception as e:                                   # noqa: BLE001
            bad += 1
            errors.append(f"{item['mpn']}: {type(e).__name__}: {e}"[:200])
            db.touch_status(item["id"], "failed", "Batch 回填失败", 100, str(e)[:300])

    db.add_event(f"Batch 回填完成：成功 {ok} / 失败 {bad}", kind="batch", detail="; ".join(errors[:5]))
    return {"ok": True, "ingested": ok, "failed": bad, "errors": errors[:20],
            "counts": b.get("request_counts") or {}}
