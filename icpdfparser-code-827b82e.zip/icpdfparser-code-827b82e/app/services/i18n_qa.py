"""多语言质量中心：术语库、禁用词、LQA 确定性门禁、批准译文记忆库、审校问题台账。

设计边界
--------
1. 本模块**只读写自己的 i18n_* 表**，不碰 item / qc_* / parsed/*.json。
2. 候选译文以"版本快照"入库（v1/v2/v3 并存，各自独立哈希），批准与否是人的动作，
   机器只能产出 finding，不能把候选自动标记为 approved。
3. 只有人工批准的句段才写入 `i18n_tm`（status='approved'）；未批准的留在候选区。
4. LQA 是确定性规则：同一输入必然同一输出，不需要调用模型。
5. `i18n_audit_log` 只 INSERT，不做 UPDATE/DELETE。
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from typing import Any, Iterable

class _DBProxy:
    """延迟取 app.db：db.py 启动时要 import 本模块的 DDL，模块级 import 会成环。

    单测直接把 `i18n_qa.db` 换成内存实现即可（与本项目其它服务的注入式单测同效）。
    """

    def __getattr__(self, name: str):
        from .. import db as real
        return getattr(real, name)


db = _DBProxy()

LANGS = ("ja", "ko", "de", "es")
LANG_ZH = {"ja": "日语", "ko": "韩语", "de": "德语", "es": "西班牙语"}
TEXT_FIELDS = (("title", "seo", "title_en"), ("meta", "seo", "meta_description_en"),
               ("description", "basic_info", "description"))

DDL = """
PRAGMA foreign_keys=ON;

-- 术语库：批准的译法 + 禁用译法（禁用项同时进 LQA 门禁）
CREATE TABLE IF NOT EXISTS i18n_glossary (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    term_en    TEXT NOT NULL,
    domain     TEXT NOT NULL DEFAULT '',      -- logic|power|battery|encoder|protection|package|interface|general
    ja         TEXT NOT NULL DEFAULT '',      -- 多种批准译法用 | 分隔
    ko         TEXT NOT NULL DEFAULT '',
    de         TEXT NOT NULL DEFAULT '',
    es         TEXT NOT NULL DEFAULT '',
    banned     TEXT NOT NULL DEFAULT '{}',    -- {"ja":["..."],"ko":["..."]} 仅在源含 term_en 时生效
    note       TEXT NOT NULL DEFAULT '',
    status     TEXT NOT NULL DEFAULT 'draft', -- draft|approved|retired
    origin     TEXT NOT NULL DEFAULT '',      -- manual|review-2026-10-29|import
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(term_en, domain)
);
CREATE INDEX IF NOT EXISTS idx_i18ngloss_status ON i18n_glossary(status);
CREATE INDEX IF NOT EXISTS idx_i18ngloss_domain ON i18n_glossary(domain);

-- 全局禁用词：与源文无关，出现即判（用于无歧义的错译串）
CREATE TABLE IF NOT EXISTS i18n_term_banned (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    lang       TEXT NOT NULL,
    pattern    TEXT NOT NULL,
    kind       TEXT NOT NULL DEFAULT 'literal',  -- literal|regex
    severity   TEXT NOT NULL DEFAULT 'FAIL',     -- FAIL|WARN
    note       TEXT NOT NULL DEFAULT '',
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    UNIQUE(lang, pattern)
);
CREATE INDEX IF NOT EXISTS idx_i18nbanned_lang ON i18n_term_banned(lang);

-- 候选版本：同一 batch 可以有 v1/v2/v3 多个 revision，各自哈希，永不覆盖
CREATE TABLE IF NOT EXISTS i18n_candidate (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    batch          TEXT NOT NULL,
    revision       TEXT NOT NULL,
    mpn            TEXT NOT NULL,
    filename       TEXT NOT NULL,
    sha256         TEXT NOT NULL,
    base_sha256    TEXT NOT NULL DEFAULT '',   -- 对应生产原件哈希（before）
    source_version TEXT NOT NULL DEFAULT '',
    model          TEXT NOT NULL DEFAULT '',
    scope          TEXT NOT NULL DEFAULT 'full',
    status         TEXT NOT NULL DEFAULT 'pending', -- pending|approved|rejected
    gate_verdict   TEXT NOT NULL DEFAULT '',        -- PASS|WARN|REVIEW|FAIL
    note           TEXT NOT NULL DEFAULT '',
    imported_at    TEXT NOT NULL,
    approved_by    TEXT NOT NULL DEFAULT '',
    approved_at    TEXT NOT NULL DEFAULT '',
    UNIQUE(batch, revision, filename)
);
CREATE INDEX IF NOT EXISTS idx_i18ncand_batch ON i18n_candidate(batch, revision);
CREATE INDEX IF NOT EXISTS idx_i18ncand_mpn   ON i18n_candidate(mpn);

-- 候选的逐字段译文（4 语 × 5 字段）
CREATE TABLE IF NOT EXISTS i18n_candidate_field (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id INTEGER NOT NULL REFERENCES i18n_candidate(id) ON DELETE CASCADE,
    lang         TEXT NOT NULL,
    field        TEXT NOT NULL,               -- title|meta|description|features|applications
    idx          INTEGER NOT NULL DEFAULT -1, -- 列表用下标，标量 -1
    en           TEXT NOT NULL DEFAULT '',
    target       TEXT NOT NULL DEFAULT '',
    changed      INTEGER NOT NULL DEFAULT 0   -- 相对上一 revision 是否变化
);
CREATE INDEX IF NOT EXISTS idx_i18nfield_cand ON i18n_candidate_field(candidate_id, lang);

-- LQA 执行与发现项
CREATE TABLE IF NOT EXISTS i18n_lqa_run (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id INTEGER NOT NULL,
    ruleset      TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'ok',   -- ok|fail
    total        INTEGER NOT NULL DEFAULT 0,   -- 检查格数（语种×字段）
    pass_n       INTEGER NOT NULL DEFAULT 0,
    warn_n       INTEGER NOT NULL DEFAULT 0,
    review_n     INTEGER NOT NULL DEFAULT 0,
    fail_n       INTEGER NOT NULL DEFAULT 0,
    duration_ms  INTEGER NOT NULL DEFAULT 0,
    operator     TEXT NOT NULL DEFAULT 'auto',
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_i18nrun_cand ON i18n_lqa_run(candidate_id);

CREATE TABLE IF NOT EXISTS i18n_lqa_finding (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id       INTEGER NOT NULL,
    candidate_id INTEGER NOT NULL,
    mpn          TEXT NOT NULL DEFAULT '',
    lang         TEXT NOT NULL DEFAULT '',
    field        TEXT NOT NULL DEFAULT '',
    idx          INTEGER NOT NULL DEFAULT -1,
    rule         TEXT NOT NULL DEFAULT '',
    severity     TEXT NOT NULL DEFAULT 'FAIL',
    verdict      TEXT NOT NULL DEFAULT '',
    src_ev       TEXT NOT NULL DEFAULT '',
    tgt_ev       TEXT NOT NULL DEFAULT '',
    detail       TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_i18nfind_run  ON i18n_lqa_finding(run_id);
CREATE INDEX IF NOT EXISTS idx_i18nfind_cand ON i18n_lqa_finding(candidate_id);
CREATE INDEX IF NOT EXISTS idx_i18nfind_rule ON i18n_lqa_finding(rule);

-- AI 语义审校（模型只提问题，不落盘改译文）
CREATE TABLE IF NOT EXISTS i18n_review_run (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id INTEGER NOT NULL,
    lang         TEXT NOT NULL DEFAULT '',
    model        TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'running', -- running|ok|fail|disabled
    issues       INTEGER NOT NULL DEFAULT 0,
    tokens       INTEGER NOT NULL DEFAULT 0,
    error        TEXT NOT NULL DEFAULT '',
    operator     TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL,
    finished_at  TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_i18nrevrun_cand ON i18n_review_run(candidate_id);

CREATE TABLE IF NOT EXISTS i18n_review_issue (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id       INTEGER NOT NULL DEFAULT 0,     -- 0 = 人工录入
    candidate_id INTEGER NOT NULL,
    mpn          TEXT NOT NULL DEFAULT '',
    lang         TEXT NOT NULL DEFAULT '',
    field        TEXT NOT NULL DEFAULT '',
    idx          INTEGER NOT NULL DEFAULT -1,
    category     TEXT NOT NULL DEFAULT '',       -- mistranslation|omission|addition|terminology|entity_integrity|ambiguity|style
    severity     TEXT NOT NULL DEFAULT 'P1',     -- P0|P1|P2
    src_ev       TEXT NOT NULL DEFAULT '',
    tgt_ev       TEXT NOT NULL DEFAULT '',
    rationale    TEXT NOT NULL DEFAULT '',
    verdict      TEXT NOT NULL DEFAULT 'open',   -- open|accepted|rejected|fixed
    decided_by   TEXT NOT NULL DEFAULT '',
    decided_at   TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_i18nissue_cand ON i18n_review_issue(candidate_id);
CREATE INDEX IF NOT EXISTS idx_i18nissue_sev  ON i18n_review_issue(severity, verdict);

-- 批准译文记忆库：只有人工批准才进 approved
CREATE TABLE IF NOT EXISTS i18n_tm (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    lang           TEXT NOT NULL,
    source_hash    TEXT NOT NULL,
    source_text    TEXT NOT NULL,
    target_text    TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'candidate', -- candidate|approved
    source_version TEXT NOT NULL DEFAULT '',
    model          TEXT NOT NULL DEFAULT '',
    candidate_id   INTEGER NOT NULL DEFAULT 0,
    mpn            TEXT NOT NULL DEFAULT '',
    field          TEXT NOT NULL DEFAULT '',
    idx            INTEGER NOT NULL DEFAULT -1,
    approved_by    TEXT NOT NULL DEFAULT '',
    approved_at    TEXT NOT NULL DEFAULT '',
    created_at     TEXT NOT NULL,
    UNIQUE(lang, source_hash)
);
CREATE INDEX IF NOT EXISTS idx_i18ntm_status ON i18n_tm(status, lang);

-- 审计台账：只 INSERT
CREATE TABLE IF NOT EXISTS i18n_audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    action     TEXT NOT NULL,
    target     TEXT NOT NULL DEFAULT '',
    detail     TEXT NOT NULL DEFAULT '',
    operator   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_i18naudit_created ON i18n_audit_log(created_at);
"""

# ---------------------------------------------------------------- 规则目录
RULES = [
    {"id": "R-ID", "name": "型号与技术标识保号", "category": "entity_integrity",
     "severity": "FAIL", "desc": "源文出现的 MPN / 完整订货码 / SN 前缀，译文必须完整保留，不许缩写或截断"},
    {"id": "R-NUM", "name": "数值与单位", "category": "accuracy", "severity": "FAIL",
     "desc": "源文数字必须出现在同字段译文；大于 10 的数字缺失判 FAIL，小数字缺失判 WARN"},
    {"id": "R-BANNED", "name": "禁用译法", "category": "terminology", "severity": "FAIL",
     "desc": "命中全局禁用词表即判（错译串，如 Nickelmanganhydrid / ピール）"},
    {"id": "R-TERM", "name": "批准术语一致性", "category": "terminology", "severity": "FAIL",
     "desc": "命中术语禁用变体判 FAIL（概念错位）；仅未用批准译法判 WARN（常为合法保留英文原词）"},
    {"id": "R-LIST", "name": "列表完整性", "category": "completeness", "severity": "FAIL",
     "desc": "features/applications 条数必须与源文一致，元素不得为空或整条重复"},
    {"id": "R-LANG", "name": "语言与泄漏", "category": "language", "severity": "FAIL",
     "desc": "日语正文成片汉字无假名、韩语出现汉字无谚文、德语西语含 CJK 判泄漏；纯汉字名词短语与英文规格短句不算"},
    {"id": "R-ECHO", "name": "整句回退英文", "category": "completeness", "severity": "FAIL",
     "desc": "超过 20 字符的译文与英文源完全相同：标题判 WARN，正文判 FAIL"},
]
RULE_IDS = [r["id"] for r in RULES]
_SEV_RANK = {"PASS": 0, "WARN": 1, "REVIEW": 2, "FAIL": 3}

_DIGIT = re.compile(r"\d+(?:[.,]\d+)?")
_TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9./+-]{4,}")
_KANA = re.compile(r"[\u3040-\u30ff]")
_HANGUL = re.compile(r"[\uac00-\ud7af]")
_CJK = re.compile(r"[\u4e00-\u9fff]")
_LATIN = re.compile(r"[A-Za-z\u00c0-\u024f]")

# 1–10 在目标语里写成词形时视为命中（只用于小数字，避免"三态"被词形误伤）
_SMALL_WORDS = {
    1: ("一", "ひと", "하나", "일", "uno", "una", "ein", "eine", "one"),
    2: ("二", "ふた", "두", "이", "dos", "zwei", "two"),
    3: ("三", "みっ", "세", "삼", "tres", "drei", "three"),
    4: ("四", "よん", "네", "사", "cuatro", "vier", "four"),
    5: ("五", "いつ", "다섯", "오", "cinco", "fünf", "five"),
    6: ("六", "むっ", "여섯", "육", "seis", "sechs", "six"),
    7: ("七", "なな", "일곱", "칠", "siete", "sieben", "seven"),
    8: ("八", "やっ", "여덟", "팔", "ocho", "acht", "eight"),
    9: ("九", "きゅう", "아홉", "구", "nueve", "neun", "nine"),
    10: ("十", "じゅう", "열", "십", "diez", "zehn", "ten"),
}


# ---------------------------------------------------------------- 基础工具
def _now() -> str:
    return db.now()


def norm_mpn(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def source_fields(doc: dict) -> dict:
    seo = doc.get("seo") or {}
    bi = doc.get("basic_info") or {}
    return {
        "title": (seo.get("title_en") or "").strip(),
        "meta": (seo.get("meta_description_en") or "").strip(),
        "description": (bi.get("description") or "").strip(),
        "features": [str(x).strip() for x in (doc.get("features") or [])],
        "applications": [str(x).strip() for x in (doc.get("applications") or [])],
    }


def _canon(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def source_version(doc: dict) -> str:
    """与 docs/qc 计划里的 src_version 同一口径（sha256[:16]）。"""
    return hashlib.sha256(_canon(source_fields(doc)).encode("utf-8")).hexdigest()[:16]


def _digits(s: str) -> set[str]:
    out = set()
    for t in _DIGIT.findall(s or ""):
        t = t.replace(",", ".")
        out.add(t[:-1] if t.endswith(".") else t)
    return out


def _identity_tokens(texts: Iterable[str], mpn: str, stem: str) -> list[str]:
    cands = [c for c in {mpn, stem} if c]
    for t in texts:
        for tok in _TOKEN.findall(t or ""):
            nt = norm_mpn(tok)
            for m in list(cands):
                nm = norm_mpn(m)
                if nm and nt.endswith(nm) and len(nt) > len(nm) and tok not in cands:
                    cands.append(tok)
    return cands


def audit(action: str, target: str = "", detail: Any = "", operator: str = "") -> None:
    _audit(action, target, detail, operator)


def _audit(action: str, target: str = "", detail: Any = "", operator: str = "") -> None:
    if not isinstance(detail, str):
        detail = json.dumps(detail, ensure_ascii=False)[:4000]
    db.x("INSERT INTO i18n_audit_log (action,target,detail,operator,created_at) VALUES (?,?,?,?,?)",
         (action, target[:200], detail[:4000], operator[:80], _now()))


# ---------------------------------------------------------------- 种子数据
# 全部来自 2026-10-29 人工审查确认的修订（docs/qc 第二十三节），没有一条是机器自拟
_SEED_GLOSSARY = [
    ("3-state output", "logic", "", "3상태 출력", "", "",
     {"ko": ["3상 출력"], "ja": ["三相出力"]},
     "三态=高/低/高阻；3상 在韩语里默认指三相（ja 未确认批准译法，留空不校验）", "approved",
     "review-2026-10-29"),
    ("nickel-metal hydride", "battery", "", "", "Nickel-Metallhydrid", "",
     {"de": ["Nickelmanganhydrid"]},
     "镍氢电池；Nickelmanganhydrid 是镍锰氢化物，化学体系错误", "approved", "review-2026-10-29"),
    ("rapid shutdown", "protection", "", "", "Schnellabschaltung", "",
     {"de": ["Schnellschaltung"]},
     "光伏 NEC 术语：快速关断，不是普通快速切换", "approved", "review-2026-10-29"),
    ("solar arc protection", "protection", "", "", "Lichtbogenschutz für Solaranlagen", "",
     {"de": ["Solarspannungsschutz"]},
     "拉弧保护；Solarspannungsschutz 是过压保护，概念错位", "approved", "review-2026-10-29"),
    ("configurable logic block", "logic", "構成可能ロジックブロック", "", "", "",
     {"ja": ["可編集ロジック"]},
     "CLB 官方日文译法；可編集=editable，语义偏", "approved", "review-2026-10-29"),
    ("quadrature encoder", "encoder", "直交エンコーダ|直交エンコーダー", "직교 인코더", "", "",
     {"ja": ["準位エンコーダ"], "ko": ["사각파 인코더", "사각형 인코더"]},
     "正交编码器；準位=电平、사각파=方波，均丢失正交含义", "approved", "review-2026-10-29"),
    ("passive balancing", "battery", "パッシブバランス", "", "", "",
     {"ja": ["パスティブ"]},
     "被动均衡；パスティブ 是误拼", "approved", "review-2026-10-29"),
    ("charging (pile) station", "power", "充電スタンド", "충전소", "", "",
     {"ja": ["ピール"], "ko": ["기둥"]},
     "充电桩；ピール（果皮）与 기둥（柱子）都是直译事故", "approved", "review-2026-10-29"),
    ("dual-supply", "interface", "デュアル電源", "", "", "",
     {"ja": ["デュアルスアップ"]},
     "双电源；デュアルスアップ 是 dual-supply 的硬译", "approved", "review-2026-10-29"),
    ("bidirectional", "interface", "双方向", "", "", "",
     {"ja": ["双向"]},
     "日语用 双方向；双向 是简体字形混入", "approved", "review-2026-10-29"),
    ("enhanced capture", "encoder", "", "", "Erfassungsmodul", "", {},
     "eCAP；德语复数 Erfassungsmodule（数词后名词须变复数）", "approved", "review-2026-10-29"),
    ("rail-to-rail", "interface", "", "", "Rail-to-Rail-Schalten|Rail-to-Rail", "", {},
     "满轨导通；只写 GND..VCC 范围会丢失器件原始术语", "approved", "review-2026-10-29"),
]

_SEED_BANNED = [
    ("de", "Nickelmanganhydrid", "literal", "FAIL", "镍锰氢化物，化学体系错误"),
    ("de", "Solarspannungsschutz", "literal", "FAIL", "过压保护，不是拉弧保护"),
    ("de", "Schnellschaltung", "literal", "WARN", "可能只是普通快速切换"),
    ("de", r"erweiterte Erfassungsmodul(?!e)", "regex", "WARN", "数词后应为复数 Erfassungsmodule"),
    ("ja", "ピール", "literal", "FAIL", "pile 音译成『果皮』"),
    ("ja", "パスティブ", "literal", "FAIL", "passive 误拼"),
    ("ja", "準位エンコーダ", "literal", "FAIL", "quadrature 应为 直交"),
    ("ja", "可編集ロジック", "literal", "FAIL", "Configurable 应为 構成可能"),
    ("ja", "デュアルスアップ", "literal", "FAIL", "dual-supply 硬译"),
    ("ja", "双向", "literal", "FAIL", "日语应为 双方向"),
    ("ko", "사각파 인코더", "literal", "FAIL", "方波编码器，丢失正交"),
    ("ko", "사각형 인코더", "literal", "FAIL", "同上"),
    ("ko", "기둥) 스테이션", "literal", "WARN", "charging pile 直译为柱子"),
]


def ensure_seed(operator: str = "system") -> dict:
    """幂等写入种子术语与禁用词；已存在的不覆盖（人工改过的保留）。"""
    added_g = added_b = 0
    for (term, domain, ja, ko, de, es, banned, note, status, origin) in _SEED_GLOSSARY:
        row = db.q1("SELECT id FROM i18n_glossary WHERE term_en=? AND domain=?", (term, domain))
        if row:
            continue
        db.x("INSERT INTO i18n_glossary (term_en,domain,ja,ko,de,es,banned,note,status,origin,"
             "created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
             (term, domain, ja, ko, de, es, json.dumps(banned, ensure_ascii=False), note,
              status, origin, _now(), _now()))
        added_g += 1
    for (lang, pattern, kind, sev, note) in _SEED_BANNED:
        if db.q1("SELECT id FROM i18n_term_banned WHERE lang=? AND pattern=?", (lang, pattern)):
            continue
        db.x("INSERT INTO i18n_term_banned (lang,pattern,kind,severity,note,active,created_at) "
             "VALUES (?,?,?,?,?,1,?)", (lang, pattern, kind, sev, note, _now()))
        added_b += 1
    if added_g or added_b:
        _audit("seed", "terms", {"glossary": added_g, "banned": added_b}, operator)
    return {"glossary": added_g, "banned": added_b}


# ---------------------------------------------------------------- 术语 / 禁用词
def glossary_list(q: str = "", domain: str = "", status: str = "", lang: str = "") -> list[dict]:
    sql = "SELECT * FROM i18n_glossary WHERE 1=1"
    args: list[Any] = []
    if q:
        sql += " AND (term_en LIKE ? OR ja LIKE ? OR ko LIKE ? OR de LIKE ? OR es LIKE ?)"
        args += [f"%{q}%"] * 5
    if domain:
        sql += " AND domain=?"
        args.append(domain)
    if status:
        sql += " AND status=?"
        args.append(status)
    if lang:
        sql += f" AND {lang}<>''"
    sql += " ORDER BY status='approved' DESC, domain, term_en"
    rows = db.q(sql, args)
    for r in rows:
        try:
            r["banned_obj"] = json.loads(r.get("banned") or "{}")
        except json.JSONDecodeError:
            r["banned_obj"] = {}
    return rows


def glossary_save(payload: dict, operator: str = "") -> dict:
    gid = int(payload.get("id") or 0)
    banned = payload.get("banned")
    banned_s = json.dumps(banned, ensure_ascii=False) if isinstance(banned, (dict, list)) \
        else (payload.get("banned") or "{}")
    fields = {
        "term_en": (payload.get("term_en") or "").strip(),
        "domain": (payload.get("domain") or "general").strip(),
        "ja": (payload.get("ja") or "").strip(),
        "ko": (payload.get("ko") or "").strip(),
        "de": (payload.get("de") or "").strip(),
        "es": (payload.get("es") or "").strip(),
        "banned": banned_s,
        "note": (payload.get("note") or "").strip(),
        "status": payload.get("status") or "draft",
    }
    if not fields["term_en"]:
        raise ValueError("term_en 不能为空")
    if fields["status"] not in ("draft", "approved", "retired"):
        raise ValueError("status 非法")
    if gid:
        db.x("UPDATE i18n_glossary SET term_en=?,domain=?,ja=?,ko=?,de=?,es=?,banned=?,note=?,"
             "status=?,updated_at=? WHERE id=?",
             (*fields.values(), _now(), gid))
        _audit("glossary.update", f"id={gid}", fields, operator)
        return db.q1("SELECT * FROM i18n_glossary WHERE id=?", (gid,)) or {}
    row = db.q1("SELECT id FROM i18n_glossary WHERE term_en=? AND domain=?",
                (fields["term_en"], fields["domain"]))
    if row:
        raise ValueError("同领域下该术语已存在")
    new_id = db.x("INSERT INTO i18n_glossary (term_en,domain,ja,ko,de,es,banned,note,status,"
                  "origin,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,'manual',?,?)",
                  (*fields.values(), _now(), _now()))
    _audit("glossary.create", f"id={new_id}", fields, operator)
    return db.q1("SELECT * FROM i18n_glossary WHERE id=?", (new_id,)) or {}


def banned_list(lang: str = "") -> list[dict]:
    if lang:
        return db.q("SELECT * FROM i18n_term_banned WHERE lang=? ORDER BY lang,severity,pattern",
                    (lang,))
    return db.q("SELECT * FROM i18n_term_banned ORDER BY lang,severity,pattern")


def banned_save(payload: dict, operator: str = "") -> dict:
    bid = int(payload.get("id") or 0)
    if bid:
        db.x("UPDATE i18n_term_banned SET lang=?,pattern=?,kind=?,severity=?,note=?,active=? "
             "WHERE id=?",
             (payload.get("lang") or "de", (payload.get("pattern") or "").strip(),
              payload.get("kind") or "literal", payload.get("severity") or "FAIL",
              (payload.get("note") or "").strip(), 1 if payload.get("active", True) else 0, bid))
        _audit("banned.update", f"id={bid}", payload, operator)
        return db.q1("SELECT * FROM i18n_term_banned WHERE id=?", (bid,)) or {}
    pattern = (payload.get("pattern") or "").strip()
    if not pattern:
        raise ValueError("pattern 不能为空")
    if payload.get("kind") == "regex":
        try:
            re.compile(pattern)
        except re.error as e:
            raise ValueError(f"正则不合法：{e}") from e
    new_id = db.x("INSERT INTO i18n_term_banned (lang,pattern,kind,severity,note,active,created_at)"
                  " VALUES (?,?,?,?,?,?,?)",
                  (payload.get("lang") or "de", pattern, payload.get("kind") or "literal",
                   payload.get("severity") or "FAIL", (payload.get("note") or "").strip(),
                   1 if payload.get("active", True) else 0, _now()))
    _audit("banned.create", f"id={new_id}", payload, operator)
    return db.q1("SELECT * FROM i18n_term_banned WHERE id=?", (new_id,)) or {}


# ---------------------------------------------------------------- 候选版本
def import_candidate(batch: str, revision: str, filename: str, doc: dict, *,
                     mpn: str = "", model: str = "qwen-flash", scope: str = "full",
                     base_doc: dict | None = None, raw: bytes | None = None,
                     operator: str = "import") -> dict:
    """把一个候选 JSON 作为不可变快照入库；同 (batch,revision,filename) 重复导入直接返回。"""
    sha = hashlib.sha256(raw if raw is not None else _canon(doc).encode("utf-8")).hexdigest()
    exist = db.q1("SELECT * FROM i18n_candidate WHERE batch=? AND revision=? AND filename=?",
                  (batch, revision, filename))
    if exist:
        return exist
    src = source_fields(base_doc or doc)
    mpn = mpn or ((doc.get("basic_info") or {}).get("mpn") or "").strip()
    base_sha = hashlib.sha256(_canon(source_fields(base_doc)).encode("utf-8")).hexdigest() \
        if base_doc else ""
    cid = db.x("INSERT INTO i18n_candidate (batch,revision,mpn,filename,sha256,base_sha256,"
               "source_version,model,scope,status,imported_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
               (batch, revision, mpn, filename, sha, base_sha, source_version(base_doc or doc),
                model, scope, "pending", _now()))
    ml = doc.get("multi_language") or {}
    rows = []
    prev = _prev_fields(batch, revision, filename)
    for lang in LANGS:
        e = ml.get(lang) or {}
        for out_key, _sec, _f in TEXT_FIELDS:
            en, tg = src[out_key], (e.get(out_key) or "")
            rows.append((cid, lang, out_key, -1, en, tg,
                         1 if prev.get((lang, out_key, -1)) not in (None, tg) else 0))
        for f in ("features", "applications"):
            for i, en in enumerate(src[f]):
                tg = (e.get(f) or [""] * (i + 1))[i] if i < len(e.get(f) or []) else ""
                rows.append((cid, lang, f, i, en, tg,
                             1 if prev.get((lang, f, i)) not in (None, tg) else 0))
    db.xmany("INSERT INTO i18n_candidate_field (candidate_id,lang,field,idx,en,target,changed) "
             "VALUES (?,?,?,?,?,?,?)", rows)
    _audit("candidate.import", f"{batch}/{revision}/{filename}",
           {"sha256": sha, "fields": len(rows)}, operator)
    return db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,)) or {}


def _prev_fields(batch: str, revision: str, filename: str) -> dict:
    """取同批次上一 revision 的字段值，用于标记 changed。"""
    prev = db.q1("SELECT id FROM i18n_candidate WHERE batch=? AND revision<>? AND filename=? "
                 "ORDER BY id DESC LIMIT 1", (batch, revision, filename))
    if not prev:
        return {}
    out = {}
    for r in db.q("SELECT lang,field,idx,target FROM i18n_candidate_field WHERE candidate_id=?",
                  (prev["id"],)):
        out[(r["lang"], r["field"], r["idx"])] = r["target"]
    return out


def candidate_list(batch: str = "", revision: str = "", status: str = "") -> list[dict]:
    sql = ("SELECT c.*, (SELECT COUNT(*) FROM i18n_candidate_field f WHERE f.candidate_id=c.id) "
           "AS fields FROM i18n_candidate c WHERE 1=1")
    args: list[Any] = []
    if batch:
        sql += " AND c.batch=?"
        args.append(batch)
    if revision:
        sql += " AND c.revision=?"
        args.append(revision)
    if status:
        sql += " AND c.status=?"
        args.append(status)
    sql += " ORDER BY c.batch, c.revision DESC, c.mpn"
    return db.q(sql, args)


def candidate_detail(cid: int) -> dict:
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,))
    if not c:
        return {}
    fields = db.q("SELECT lang,field,idx,en,target,changed FROM i18n_candidate_field "
                  "WHERE candidate_id=? ORDER BY lang,field,idx", (cid,))
    runs = db.q("SELECT * FROM i18n_lqa_run WHERE candidate_id=? ORDER BY id DESC LIMIT 5", (cid,))
    issues = db.q("SELECT * FROM i18n_review_issue WHERE candidate_id=? "
                  "ORDER BY CASE severity WHEN 'P0' THEN 0 WHEN 'P1' THEN 1 ELSE 2 END, id",
                  (cid,))
    c["fields"] = fields
    c["runs"] = runs
    c["issues"] = issues
    return c


def batches() -> list[dict]:
    return db.q("""SELECT batch, revision, COUNT(*) n,
                          SUM(status='approved') approved, SUM(status='rejected') rejected,
                          SUM(gate_verdict='FAIL') failed, MAX(imported_at) imported_at,
                          MAX(model) model
                     FROM i18n_candidate GROUP BY batch, revision
                     ORDER BY MAX(imported_at) DESC, batch, revision""")


# ---------------------------------------------------------------- LQA 引擎
def _rule_severity(rule: str) -> str:
    for r in RULES:
        if r["id"] == rule:
            return r["severity"]
    return "FAIL"


def _banned_hits(lang: str, text: str) -> list[tuple[str, str, str]]:
    """返回 (pattern, severity, note)。"""
    out = []
    for r in db.q("SELECT pattern,kind,severity,note FROM i18n_term_banned "
                  "WHERE lang=? AND active=1", (lang,)):
        pat, kind = r["pattern"], r["kind"]
        try:
            hit = re.search(pat, text or "") if kind == "regex" else (pat in (text or ""))
        except re.error:
            hit = False
        if hit:
            out.append((pat, r["severity"], r["note"]))
    return out


def _term_checks(lang: str, text: str, src_text: str) -> list[dict]:
    """源文命中已批准术语时，校验译文，且没踩该术语的禁用变体。

    命中禁用变体 = FAIL（概念错）；只是没用批准译法 = WARN（一致性待人工判断）——
    后者常是合法保留英文原词，不能硬阻断。
    """
    out = []
    low_src = (src_text or "").lower()
    for g in db.q("SELECT * FROM i18n_glossary WHERE status='approved'"):
        term = (g["term_en"] or "").lower()
        if not term or term not in low_src:
            continue
        try:
            banned = json.loads(g.get("banned") or "{}")
        except json.JSONDecodeError:
            banned = {}
        hit_banned = False
        for b in banned.get(lang) or []:
            if b and b in (text or ""):
                hit_banned = True
                out.append({"rule": "R-TERM", "severity": "FAIL",
                            "detail": f"术语「{g['term_en']}」的禁用变体「{b}」出现"})
        approved = [x.strip() for x in (g.get(lang) or "").split("|") if x.strip()]
        if approved and not hit_banned and not any(a in (text or "") for a in approved):
            out.append({"rule": "R-TERM", "severity": "WARN",
                        "detail": f"术语「{g['term_en']}」未使用批准译法：{' / '.join(approved)}"})
    return out


def _lang_checks(lang: str, text: str, en: str, field: str = "") -> list[dict]:
    """语言泄漏检测。

    日语规格短句常为纯汉字/纯英文（「5V時最大tpd 6ns」「IEEE 754単精度浮動小数点命令」），
    这不是缺陷；只有"成片汉字且完全无假名、无拉丁技术词"才判中文泄漏。
    """
    out = []
    t = text or ""
    if lang == "ja":
        # 只查成段正文：日语名词短语常纯汉字（「電子決済端末」），成段汉字无假名必是中文
        if field == "description" and not _KANA.search(t) and len(_CJK.findall(t)) >= 12 \
                and not _LATIN.search(t):
            out.append({"rule": "R-LANG", "severity": "FAIL",
                        "detail": "日语正文成片汉字且无假名（疑似中文未翻译）"})
    elif lang == "ko":
        if _CJK.search(t) and not _HANGUL.search(t):
            out.append({"rule": "R-LANG", "severity": "FAIL",
                        "detail": "韩语译文出现汉字且无谚文（疑似中文未翻译）"})
    else:
        if _CJK.search(t):
            out.append({"rule": "R-LANG", "severity": "FAIL",
                        "detail": f"{LANG_ZH[lang]}译文出现 CJK 字符"})
    if t.strip() and t.strip() == (en or "").strip() and len(t.strip()) > 20 and _LATIN.search(t):
        out.append({"rule": "R-ECHO",
                    "severity": "WARN" if field == "title" else "FAIL",
                    "detail": ("标题与英文源相同（型号+规格标题常态，供人工确认）" if field == "title"
                               else "译文与英文源完全相同（整句未翻译）")})
    return out


def _num_checks(text: str, en: str) -> list[dict]:
    out = []
    tgt_digits = _digits(text)
    for n in sorted(_digits(en) - tgt_digits, key=lambda x: (len(x), x)):
        try:
            val = float(n)
        except ValueError:
            continue
        if val == int(val) and 1 <= val <= 10 and any(w in (text or "")
                                                      for w in _SMALL_WORDS[int(val)]):
            continue
        # 小数（5.5V / 4.5V）没有词形写法，缺失一律判 FAIL；小整数可能是「三态」这类词形
        out.append({"rule": "R-NUM", "severity": "FAIL" if (val > 10 or "." in n) else "WARN",
                    "detail": f"源文数值 {n} 未出现在译文中"})
    return out


def _id_checks(text: str, tokens: list[str], en: str) -> list[dict]:
    out = []
    n = norm_mpn(text)
    for tok in tokens:
        nt = norm_mpn(tok)
        if not nt or nt not in norm_mpn(en):
            continue
        if nt in n:
            continue
        pref = [k for k in range(len(nt) - 1, 7, -1) if nt[:k] in n]
        out.append({"rule": "R-ID", "severity": "FAIL",
                    "detail": (f"型号 {tok} 只保留前 {max(pref)} 位" if pref
                               else f"型号 {tok} 缺失")})
    return out


def run_lqa(candidate_id: int, operator: str = "auto") -> dict:
    """对单个候选跑确定性门禁，写 run + findings，返回汇总。"""
    t0 = time.time()
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (candidate_id,))
    if not c:
        raise ValueError("候选不存在")
    rows = db.q("SELECT lang,field,idx,en,target FROM i18n_candidate_field WHERE candidate_id=?",
                (candidate_id,))
    tokens = _identity_tokens([r["en"] for r in rows if r["field"] in
                               ("title", "meta", "description")], c["mpn"],
                              c["filename"].rsplit("_", 1)[0])

    findings: list[dict] = []
    cells: dict[tuple[str, str], list[dict]] = {}

    def add(lang: str, field: str, idx: int, en: str, tg: str, ch: dict) -> None:
        """findings 与 cell 必须同时落：只进 cell 会算进判定却查不到明细。"""
        cells.setdefault((lang, field), []).append(ch)
        findings.append({"lang": lang, "field": field, "idx": idx, "en": en, "tg": tg,
                         "rule": ch["rule"], "severity": ch["severity"], "detail": ch["detail"]})

    for r in rows:
        lang, field, idx = r["lang"], r["field"], r["idx"]
        en, tg = r["en"], r["target"]
        cells.setdefault((lang, field), [])
        if not (tg or "").strip():
            add(lang, field, idx, en, tg, {"rule": "R-LIST", "severity": "FAIL",
                                          "detail": "译文为空（漏译）"})
            continue
        checks = []
        checks += _num_checks(tg, en)
        checks += _id_checks(tg, tokens, en)
        checks += _lang_checks(lang, tg, en, field)
        checks += _term_checks(lang, tg, en)
        for (pat, sev, note) in _banned_hits(lang, tg):
            checks.append({"rule": "R-BANNED", "severity": sev,
                           "detail": f"命中禁用词「{pat}」{('：' + note) if note else ''}"})
        for ch in checks:
            add(lang, field, idx, en, tg, ch)

    # 列表条数与重复（按语种一次）
    for lang in LANGS:
        for f in ("features", "applications"):
            items = [r for r in rows if r["lang"] == lang and r["field"] == f]
            src_n = len([r for r in items if r["en"].strip()])
            tgt_n = len([r for r in items if r["target"].strip()])
            cells.setdefault((lang, f), [])
            if src_n != tgt_n:
                add(lang, f, -1, "", "", {"rule": "R-LIST", "severity": "FAIL",
                                          "detail": f"{f} 条数不一致：源 {src_n} / 译 {tgt_n}"})
            seen = set()
            for r in items:
                t = (r["target"] or "").strip()
                if t and t in seen:
                    add(lang, f, r["idx"], r["en"], t,
                        {"rule": "R-LIST", "severity": "WARN",
                         "detail": f"{f}[{r['idx']}] 译文重复"})
                seen.add(t)

    total = len(cells)
    counts = {"PASS": 0, "WARN": 0, "REVIEW": 0, "FAIL": 0}
    for cell in cells.values():
        sev = "PASS"
        for ch in cell:
            if _SEV_RANK[ch["severity"]] > _SEV_RANK[sev]:
                sev = ch["severity"]
        counts[sev] += 1
    status = "fail" if counts["FAIL"] else "ok"
    dur = int((time.time() - t0) * 1000)
    run_id = db.x("INSERT INTO i18n_lqa_run (candidate_id,ruleset,status,total,pass_n,warn_n,"
                  "review_n,fail_n,duration_ms,operator,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                  (candidate_id, "v1", status, total, counts["PASS"], counts["WARN"],
                   counts["REVIEW"], counts["FAIL"], dur, operator, _now()))
    db.xmany("INSERT INTO i18n_lqa_finding (run_id,candidate_id,mpn,lang,field,idx,rule,severity,"
             "verdict,src_ev,tgt_ev,detail,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
             [(run_id, candidate_id, c["mpn"], f["lang"], f["field"], f["idx"], f["rule"],
               f["severity"], f["rule"], (f["en"] or "")[:500], (f["tg"] or "")[:500],
               f["detail"], _now()) for f in findings])
    verdict = "FAIL" if counts["FAIL"] else ("REVIEW" if counts["REVIEW"] else
                                             ("WARN" if counts["WARN"] else "PASS"))
    db.x("UPDATE i18n_candidate SET gate_verdict=? WHERE id=?", (verdict, candidate_id))
    _audit("lqa.run", f"candidate={candidate_id}",
           {"verdict": verdict, "total": total, "counts": counts, "findings": len(findings)},
           operator)
    return {"run_id": run_id, "candidate_id": candidate_id, "verdict": verdict,
            "total": total, "counts": counts, "findings": len(findings), "duration_ms": dur}


def run_lqa_batch(batch: str, revision: str = "", operator: str = "auto") -> dict:
    ids = [r["id"] for r in candidate_list(batch, revision)]
    out = [run_lqa(i, operator) for i in ids]
    return {"candidates": len(out),
            "fail": sum(1 for x in out if x["verdict"] == "FAIL"),
            "pass": sum(1 for x in out if x["verdict"] == "PASS"),
            "runs": out}


def lqa_runs(candidate_id: int = 0, limit: int = 50) -> list[dict]:
    if candidate_id:
        return db.q("SELECT * FROM i18n_lqa_run WHERE candidate_id=? ORDER BY id DESC LIMIT ?",
                    (candidate_id, limit))
    return db.q("""SELECT r.*, c.mpn, c.batch, c.revision, c.filename
                     FROM i18n_lqa_run r JOIN i18n_candidate c ON c.id=r.candidate_id
                    ORDER BY r.id DESC LIMIT ?""", (limit,))


def lqa_findings(run_id: int = 0, candidate_id: int = 0, severity: str = "",
                 rule: str = "", limit: int = 500) -> list[dict]:
    sql = "SELECT * FROM i18n_lqa_finding WHERE 1=1"
    args: list[Any] = []
    if run_id:
        sql += " AND run_id=?"
        args.append(run_id)
    if candidate_id:
        sql += " AND candidate_id=?"
        args.append(candidate_id)
    if severity:
        sql += " AND severity=?"
        args.append(severity)
    if rule:
        sql += " AND rule=?"
        args.append(rule)
    sql += " ORDER BY CASE severity WHEN 'FAIL' THEN 0 WHEN 'REVIEW' THEN 1 ELSE 2 END, id"
    sql += " LIMIT ?"
    args.append(limit)
    return db.q(sql, args)


# ---------------------------------------------------------------- 人工裁决
def decide_candidate(cid: int, approve: bool, operator: str, note: str = "") -> dict:
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,))
    if not c:
        raise ValueError("候选不存在")
    run = db.q1("SELECT * FROM i18n_lqa_run WHERE candidate_id=? ORDER BY id DESC LIMIT 1", (cid,))
    if approve and run and run["fail_n"]:
        raise ValueError("LQA 仍有 FAIL，不能批准（先修复或驳回）")
    status = "approved" if approve else "rejected"
    db.x("UPDATE i18n_candidate SET status=?,note=?,approved_by=?,approved_at=? WHERE id=?",
         (status, note[:500], operator[:80], _now(), cid))
    _audit("candidate." + status, f"id={cid}", {"note": note, "gate": c["gate_verdict"]}, operator)
    return db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,)) or {}


def review_issue_decide(issue_id: int, verdict: str, operator: str) -> dict:
    if verdict not in ("open", "accepted", "rejected", "fixed"):
        raise ValueError("verdict 非法")
    db.x("UPDATE i18n_review_issue SET verdict=?,decided_by=?,decided_at=? WHERE id=?",
         (verdict, operator[:80], _now(), issue_id))
    _audit("review.decide", f"issue={issue_id}", {"verdict": verdict}, operator)
    return db.q1("SELECT * FROM i18n_review_issue WHERE id=?", (issue_id,)) or {}


def review_issue_add(payload: dict, operator: str = "") -> dict:
    cid = int(payload.get("candidate_id") or 0)
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,))
    if not c:
        raise ValueError("候选不存在")
    iid = db.x("INSERT INTO i18n_review_issue (run_id,candidate_id,mpn,lang,field,idx,category,"
               "severity,src_ev,tgt_ev,rationale,verdict,created_at) VALUES (0,?,?,?,?,?,?,?,?,?,?,"
               "'open',?)",
               (cid, c["mpn"], payload.get("lang") or "", payload.get("field") or "",
                int(payload.get("idx", -1)), payload.get("category") or "mistranslation",
                payload.get("severity") or "P1", (payload.get("src_ev") or "")[:1000],
                (payload.get("tgt_ev") or "")[:1000], (payload.get("rationale") or "")[:2000],
                _now()))
    _audit("review.issue_add", f"candidate={cid}", payload, operator)
    return db.q1("SELECT * FROM i18n_review_issue WHERE id=?", (iid,)) or {}


def review_issues(status: str = "", severity: str = "", candidate_id: int = 0) -> list[dict]:
    sql = "SELECT * FROM i18n_review_issue WHERE 1=1"
    args: list[Any] = []
    if status:
        sql += " AND verdict=?"
        args.append(status)
    if severity:
        sql += " AND severity=?"
        args.append(severity)
    if candidate_id:
        sql += " AND candidate_id=?"
        args.append(candidate_id)
    sql += " ORDER BY CASE severity WHEN 'P0' THEN 0 WHEN 'P1' THEN 1 ELSE 2 END, id DESC"
    return db.q(sql, args)


# ---------------------------------------------------------------- 记忆库
def tm_list(status: str = "", lang: str = "", limit: int = 200) -> list[dict]:
    sql = "SELECT * FROM i18n_tm WHERE 1=1"
    args: list[Any] = []
    if status:
        sql += " AND status=?"
        args.append(status)
    if lang:
        sql += " AND lang=?"
        args.append(lang)
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(limit)
    return db.q(sql, args)


def tm_from_candidate(cid: int, lang: str, operator: str) -> dict:
    """把某候选某语种的字段写入候选区；只有候选已批准时才落 approved。"""
    c = db.q1("SELECT * FROM i18n_candidate WHERE id=?", (cid,))
    if not c:
        raise ValueError("候选不存在")
    approved = c["status"] == "approved"
    rows = db.q("SELECT field,idx,en,target FROM i18n_candidate_field WHERE candidate_id=? "
                "AND lang=? AND target<>''", (cid, lang))
    n = 0
    for r in rows:
        sh = hashlib.sha256(f"{lang}:{r['en'].strip()}".encode("utf-8")).hexdigest()
        db.x("INSERT INTO i18n_tm (lang,source_hash,source_text,target_text,status,source_version,"
             "model,candidate_id,mpn,field,idx,approved_by,approved_at,created_at) "
             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
             "ON CONFLICT(lang,source_hash) DO UPDATE SET target_text=excluded.target_text,"
             "status=excluded.status,approved_by=excluded.approved_by,"
             "approved_at=excluded.approved_at WHERE excluded.status='approved'",
             (lang, sh, r["en"], r["target"], "approved" if approved else "candidate",
              c["source_version"], c["model"], cid, c["mpn"], r["field"], r["idx"],
              operator if approved else "", _now() if approved else "", _now()))
        n += 1
    _audit("tm.promote", f"candidate={cid}/{lang}", {"rows": n, "approved": approved}, operator)
    return {"rows": n, "approved": approved}


def tm_approve(tm_id: int, operator: str) -> dict:
    db.x("UPDATE i18n_tm SET status='approved',approved_by=?,approved_at=? WHERE id=?",
         (operator[:80], _now(), tm_id))
    _audit("tm.approve", f"id={tm_id}", "", operator)
    return db.q1("SELECT * FROM i18n_tm WHERE id=?", (tm_id,)) or {}


# ---------------------------------------------------------------- 聚合
def overview() -> dict:
    g = db.q1("SELECT COUNT(*) n, SUM(status='approved') a FROM i18n_glossary") or {}
    b = db.q1("SELECT COUNT(*) n, SUM(active=1) a FROM i18n_term_banned") or {}
    c = db.q1("SELECT COUNT(*) n, SUM(status='approved') a, SUM(status='rejected') r, "
              "SUM(gate_verdict='FAIL') f FROM i18n_candidate") or {}
    tm = db.q1("SELECT COUNT(*) n, SUM(status='approved') a FROM i18n_tm") or {}
    is_ = db.q1("SELECT COUNT(*) n, SUM(verdict='open') o, "
                "SUM(severity='P0' AND verdict='open') p0 FROM i18n_review_issue") or {}
    last = db.q1("SELECT * FROM i18n_lqa_run ORDER BY id DESC LIMIT 1") or {}
    tot = db.q1("SELECT SUM(total) t, SUM(pass_n) p, SUM(fail_n) f FROM i18n_lqa_run") or {}
    hit = round(100.0 * (tot.get("p") or 0) / (tot.get("t") or 1), 1)
    return {
        "glossary": {"total": g.get("n") or 0, "approved": g.get("a") or 0},
        "banned": {"total": b.get("n") or 0, "active": b.get("a") or 0},
        "candidates": {"total": c.get("n") or 0, "approved": c.get("a") or 0,
                       "rejected": c.get("r") or 0, "gate_failed": c.get("f") or 0},
        "tm": {"total": tm.get("n") or 0, "approved": tm.get("a") or 0},
        "issues": {"total": is_.get("n") or 0, "open": is_.get("o") or 0,
                   "p0_open": is_.get("p0") or 0},
        "lqa": {"cells": tot.get("t") or 0, "fail_cells": tot.get("f") or 0,
                "pass_rate": hit, "last": last},
        "rules": RULES,
    }


def report(days: int = 30) -> dict:
    by_lang = db.q("""SELECT lang, COUNT(*) n,
                             SUM(severity='FAIL') f, SUM(severity='WARN') w
                        FROM i18n_lqa_finding GROUP BY lang ORDER BY n DESC""")
    by_rule = db.q("""SELECT rule, COUNT(*) n, SUM(severity='FAIL') f
                        FROM i18n_lqa_finding GROUP BY rule ORDER BY n DESC""")
    by_cat = db.q("""SELECT category, COUNT(*) n FROM i18n_review_issue GROUP BY category
                     ORDER BY n DESC""")
    trend = db.q("""SELECT substr(created_at,1,10) d, COUNT(*) n, SUM(fail_n) f
                      FROM i18n_lqa_run GROUP BY d ORDER BY d DESC LIMIT 30""")
    verdicts = db.q("SELECT gate_verdict v, COUNT(*) n FROM i18n_candidate "
                    "WHERE gate_verdict<>'' GROUP BY gate_verdict")
    return {"by_lang": by_lang, "by_rule": by_rule, "by_category": by_cat,
            "trend": list(reversed(trend)), "verdicts": verdicts,
            "issues": db.q("SELECT severity, verdict, COUNT(*) n FROM i18n_review_issue "
                           "GROUP BY severity, verdict")}


def settings() -> dict:
    import os
    key = os.getenv("DASHSCOPE_API_KEY", "")
    return {
        "translate_model": os.getenv("ICPDF_TRANSLATE_MODEL", "qwen-flash"),
        "translate_base": os.getenv("ICPDF_TRANSLATE_BASE_URL",
                                    "https://dashscope.aliyuncs.com/compatible-mode/v1"),
        "review_model": db.kv_get("i18n.review.model", "") or "qwen-plus",
        "key_present": bool(key),
        "key_masked": (key[:4] + "…" + key[-4:]) if len(key) >= 12 else ("已配置" if key else "未配置"),
        "ruleset": "v1",
        "rules": RULES,
        "policy": [
            "模型输出不能绕过 LQA 门禁：有 FAIL 的候选不允许被批准",
            "AI 审校只能提出问题，不能修改候选或直接写入记忆库",
            "只有人工批准的译文才进入 approved 记忆库",
            "候选版本各自留哈希，新 revision 不覆盖旧 revision",
            "生产写回与渲染是独立动作，不由本模块触发",
        ],
    }


def set_settings(payload: dict) -> dict:
    if "review_model" in payload:
        db.kv_set("i18n.review.model", str(payload["review_model"])[:80])
    return settings()
