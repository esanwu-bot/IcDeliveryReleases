"""模型调用记账：每次 chat/completions 落一行，按模型/阶段/天汇总。

为什么必须做：不谈 token 就无法判断「换平台能不能省」「哪家网关快」。
之前的 usage 从网关拿到后直接丢掉了。

单价通过环境变量配，格式是 JSON（元 / 百万 token）：
    ICPDF_PRICES={"agnes-3.0-flash":{"in":0.8,"out":2.0}}
不配就只统计 token，不算钱 —— 不猜价格。
"""
from __future__ import annotations

import json
import os
from urllib.parse import urlsplit

from .. import db


def provider_of(base: str) -> str:
    """网关标识：取 host，例如 apihub.agnes-ai.com / dashscope.aliyuncs.com。"""
    try:
        host = urlsplit(base or "").netloc.lower()
        return host or "unknown"
    except ValueError:
        return "unknown"


def prices() -> dict:
    raw = os.getenv("ICPDF_PRICES", "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    out = {}
    for model, p in (data or {}).items():
        try:
            out[str(model)] = {"in": float(p.get("in", 0)), "out": float(p.get("out", 0))}
        except (TypeError, ValueError):
            continue
    return out


def record(*, item_id: int | None, mpn_key: str, stage: str, model: str, provider: str,
           usage: dict | None, latency_ms: int, ok: bool = True, error: str = "",
           attempt: int = 1) -> None:
    """写一条用量记录。usage 是网关返回的 dict，字段名各家略有差异，这里统一取值。"""
    u = usage or {}
    prompt = int(u.get("prompt_tokens") or u.get("input_tokens") or 0)
    completion = int(u.get("completion_tokens") or u.get("output_tokens") or 0)
    total = int(u.get("total_tokens") or (prompt + completion))
    db.x(
        "INSERT INTO llm_usage (item_id,mpn_key,stage,provider,model,prompt_tokens,"
        "completion_tokens,total_tokens,latency_ms,attempt,ok,error,created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (item_id, mpn_key[:120], stage, provider[:80], model[:80], prompt, completion,
         total, int(latency_ms), int(attempt), 1 if ok else 0, (error or "")[:300], db.now()))


def _rows(sql: str, args: tuple = ()) -> list[dict]:
    return db.q(sql, args)


def summary(days: int = 7) -> dict:
    """按模型 / 阶段 / 天汇总。days<=0 表示全量。"""
    where, args = "", ()
    if days > 0:
        where = " WHERE created_at >= datetime('now','localtime',?)"
        args = (f"-{int(days)} day",)

    tot = db.q1(
        "SELECT count(*) calls, coalesce(sum(prompt_tokens),0) prompt, "
        "coalesce(sum(completion_tokens),0) completion, coalesce(sum(total_tokens),0) total, "
        "coalesce(sum(latency_ms),0) ms, sum(case when ok=0 then 1 else 0 end) fails, "
        "count(DISTINCT mpn_key) items "
        f"FROM llm_usage{where}", args) or {}

    calls = tot.get("calls") or 0
    items = tot.get("items") or 0
    totals = {
        "calls": calls,
        "prompt": tot.get("prompt") or 0,
        "completion": tot.get("completion") or 0,
        "total": tot.get("total") or 0,
        "fails": tot.get("fails") or 0,
        "items": items,
        "avg_ms": round((tot.get("ms") or 0) / calls) if calls else 0,
        "tokens_per_item": round((tot.get("total") or 0) / items) if items else 0,
    }

    by_model = _rows(
        "SELECT model, provider, count(*) calls, coalesce(sum(prompt_tokens),0) prompt, "
        "coalesce(sum(completion_tokens),0) completion, coalesce(sum(total_tokens),0) total, "
        "round(avg(latency_ms)) avg_ms, sum(case when ok=0 then 1 else 0 end) fails "
        f"FROM llm_usage{where} GROUP BY model, provider ORDER BY total DESC", args)
    for r in by_model:
        r["share"] = round(r["total"] * 100.0 / totals["total"], 1) if totals["total"] else 0.0
        r["tokens_per_call"] = round(r["total"] / r["calls"]) if r["calls"] else 0

    by_stage = _rows(
        "SELECT stage, count(*) calls, coalesce(sum(total_tokens),0) total, "
        "round(avg(latency_ms)) avg_ms "
        f"FROM llm_usage{where} GROUP BY stage ORDER BY total DESC", args)

    daily = _rows(
        "SELECT substr(created_at,1,10) day, count(*) calls, "
        "coalesce(sum(total_tokens),0) total, round(avg(latency_ms)) avg_ms "
        f"FROM llm_usage{where} GROUP BY day ORDER BY day DESC LIMIT 14", args)

    table = prices()
    cost = None
    if table:
        rows = [r for r in by_model if r["model"] in table]
        if rows:
            detail = []
            sum_cost = 0.0
            for r in rows:
                p = table[r["model"]]
                c = r["prompt"] / 1e6 * p["in"] + r["completion"] / 1e6 * p["out"]
                sum_cost += c
                detail.append({"model": r["model"], "cost": round(c, 4),
                               "in": r["prompt"], "out": r["completion"]})
            cost = {"currency": "CNY", "total": round(sum_cost, 4), "detail": detail,
                    "per_item": round(sum_cost / totals["items"], 4) if totals["items"] else 0}

    return {"window_days": days, "totals": totals, "by_model": by_model,
            "by_stage": by_stage, "daily": daily, "cost": cost, "prices": table}
