"""站内商品目录 -> 内链索引（data/products.sqlite3）。

复用 build_product_index.py 的归一化与读取逻辑，只换写入目标路径与进度回调，
这样「工作台上传的目录」与「命令行跑的目录」产物完全一致。
"""
from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path
from typing import Callable

from build_product_index import base_of, norm, read_xls

from .. import config, db

DDL = """
DROP TABLE IF EXISTS catalog;
CREATE TABLE catalog (
    key  TEXT PRIMARY KEY,
    base TEXT,
    mpn  TEXT,
    brand TEXT,
    url  TEXT
);
"""


def catalog_stats() -> dict:
    p = config.CATALOG_DB
    if not p.exists():
        return {"exists": False, "rows": 0, "size_mb": 0, "built_at": db.kv_get("catalog_built_at", "")}
    rows = 0
    try:
        con = sqlite3.connect(f"file:{p.as_posix()}?mode=ro", uri=True)
        rows = con.execute("SELECT count(*) FROM catalog").fetchone()[0]
        con.close()
    except sqlite3.Error:
        rows = 0
    return {"exists": True, "rows": rows, "size_mb": round(p.stat().st_size / 1048576, 1),
            "built_at": db.kv_get("catalog_built_at", "")}


def build_catalog(xls_path: Path, *, progress: Callable[[int, str], None] | None = None) -> dict:
    """重建内链索引。先写临时库，成功后原子替换，避免建到一半索引不可用。"""
    t0 = time.time()
    tmp = config.CATALOG_DB.with_suffix(".building")
    tmp.unlink(missing_ok=True)
    con = sqlite3.connect(tmp)
    con.executescript("PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF;" + DDL)

    batch: list[tuple] = []
    seen: set[str] = set()
    rows = skipped = 0

    def flush() -> None:
        con.executemany("INSERT OR REPLACE INTO catalog (key,base,mpn,brand,url) VALUES (?,?,?,?,?)", batch)
        con.commit()
        batch.clear()

    for title, brand, link in read_xls(Path(xls_path)):
        mpn = (title or "").strip()
        url = (link or "").strip()
        if not mpn or not url.lower().startswith("http"):
            skipped += 1
            continue
        k = norm(mpn)
        if not k or k in seen:
            skipped += 1
            continue
        seen.add(k)
        rel = url.split("in-fortune.com", 1)[1] if "in-fortune.com" in url else url
        batch.append((k, base_of(mpn), mpn, (brand or "").strip(), rel))
        rows += 1
        if len(batch) >= 20000:
            flush()
            if progress and rows % 100000 < 20000:
                progress(min(95, rows // 6500), f"已索引 {rows:,} 条")
    flush()
    con.executescript("CREATE INDEX IF NOT EXISTS idx_catalog_base ON catalog(base);")
    con.commit()
    total = con.execute("SELECT count(*) FROM catalog").fetchone()[0]
    con.close()

    os.replace(tmp, config.CATALOG_DB)
    db.kv_set("catalog_built_at", db.now())
    db.kv_set("catalog_source", str(xls_path))
    if progress:
        progress(100, f"完成 {total:,} 条")
    return {"rows": rows, "unique": total, "skipped": skipped,
            "secs": round(time.time() - t0, 1), "db": str(config.CATALOG_DB)}
