"""客户型号表解析：xlsx / xls / csv -> [{mpn, brand, url}]。

列识别不靠固定列号，靠表头关键词；识别不到表头时退化为一律取第一列。
大文件（十几万行）用只读流式读，不整表载入内存。
"""
from __future__ import annotations

import csv
import io
import re
from pathlib import Path

# 归一化口径与站内 slug 完全一致（去非字母数字 + 大写），复用以确保匹配不漂移
from build_product_index import base_of, norm  # noqa: F401  (base_of 供其它模块用)

MPN_KEYS = ("mpn", "part number", "partnumber", "part no", "partno", "model", "model number",
            "型号", "料号", "产品型号", "器件型号", "物料编号", "manufacturer part number",
            "mfr part", "pn", "p/n", "title", "sku")
BRAND_KEYS = ("brand", "manufacturer", "mfr", "vendor", "品牌", "厂商", "制造商", "厂家")
URL_KEYS = ("datasheet", "datasheet url", "pdf", "pdf url", "url", "link", "数据手册",
            "规格书", "手册链接", "链接")
# 客户模板（Texas Instruments.xlsx）里的附加列：只作为线索展示，不参与解析判定
PKG_KEYS = ("封装", "封装形式", "package type", "package")
PACK_KEYS = ("包装", "packaging", "packing", "tape & reel")
DESC_KEYS = ("产品描述", "描述", "description", "功用", "说明")

SKU_SPLIT = re.compile(r"[;,\s]+")


def key_of(mpn: str) -> str:
    return norm(mpn)


def _hits(header: str, keys: tuple[str, ...]) -> bool:
    h = (header or "").strip().lower()
    return bool(h) and any(k in h for k in keys)


def _pick_cols(header: list[str]) -> dict[str, int]:
    """按表头识别列。返回 {'mpn','brand','url','package','packaging','description'}，缺的给 -1。"""
    cols = {k: -1 for k in ("mpn", "brand", "url", "package", "packaging", "description")}
    for i, cell in enumerate(header):
        h = (cell or "").strip()
        if not h:
            continue
        hl = h.lower()
        if cols["mpn"] < 0 and _hits(h, MPN_KEYS):
            cols["mpn"] = i
            continue
        if cols["brand"] < 0 and _hits(h, BRAND_KEYS):
            cols["brand"] = i
            continue
        if cols["url"] < 0 and _hits(h, URL_KEYS):
            cols["url"] = i
            continue
        # 「包装」要排在「封装」前判定：packaging 里含 package
        if cols["packaging"] < 0 and _hits(hl, PACK_KEYS):
            cols["packaging"] = i
            continue
        if cols["package"] < 0 and _hits(h, PKG_KEYS):
            cols["package"] = i
            continue
        if cols["description"] < 0 and _hits(h, DESC_KEYS):
            cols["description"] = i
    return cols


def _looks_like_header(row: list[str]) -> bool:
    joined = " ".join((c or "").lower() for c in row[:8])
    if not joined.strip():
        return False
    words = ("mpn", "part", "型号", "料号", "brand", "品牌", "manufacturer", "datasheet", "title")
    return any(w in joined for w in words)


def _clean_mpn(raw: str) -> str:
    s = (raw or "").strip().strip('"').strip("'")
    s = re.sub(r"\s+", " ", s)
    return s


def _rows_xlsx(path: Path):
    import openpyxl
    wb = openpyxl.load_workbook(filename=str(path), read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                yield ["" if v is None else str(v) for v in row]
    finally:
        wb.close()


def _rows_xls(path: Path):
    import xlrd
    bk = xlrd.open_workbook(str(path), on_demand=True)
    try:
        for name in bk.sheet_names():
            sh = bk.sheet_by_name(name)
            for r in range(sh.nrows):
                yield [str(sh.cell_value(r, c)) for c in range(sh.ncols)]
            bk.unload_sheet(name)
    finally:
        try:
            bk.release_resources()
        except Exception:                                    # noqa: BLE001
            pass


def _rows_csv(path: Path):
    raw = path.read_bytes()
    text = None
    for enc in ("utf-8-sig", "utf-8", "gbk", "gb18030", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:                                          # 兜底
        text = raw.decode("utf-8", "replace")
    reader = csv.reader(io.StringIO(text))
    for row in reader:
        yield ["" if v is None else str(v) for v in row]


def read_parts_table(path: Path, *, limit: int = 20000) -> list[dict]:
    """读取型号表，返回去重后的型号行。

    客户模板（型号 / 品牌 / 封装 / 包装 / 产品描述 / PDF链接）与通用表头都适用，
    识别不到表头时把第一列当型号。
    返回项：{mpn, mpn_key, brand, url, package, packaging, description}
    """
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        rows = _rows_xlsx(path)
    elif suffix == ".xls":
        rows = _rows_xls(path)
    elif suffix in (".csv", ".txt", ".tsv"):
        rows = _rows_csv(path)
    else:
        raise ValueError(f"不支持的型号表格式：{suffix}（支持 .xlsx / .xls / .csv）")

    out: list[dict] = []
    seen: set[str] = set()
    cols = {k: -1 for k in ("mpn", "brand", "url", "package", "packaging", "description")}
    cols["mpn"] = 0
    for idx, row in enumerate(rows):
        if idx == 0:
            if _looks_like_header(row):
                picked = _pick_cols(row)
                if picked["mpn"] < 0:
                    picked["mpn"] = 0
                cols = picked
                continue
            cols = {k: -1 for k in cols}
            cols["mpn"] = 0
        if not row:
            continue

        def cell(name: str) -> str:
            i = cols.get(name, -1)
            return row[i] if 0 <= i < len(row) else ""

        mpn_raw = _clean_mpn(cell("mpn"))
        if not mpn_raw:
            continue
        # 多型号挤在一个单元格里（"LM358;LM324"）时展开
        pieces = [mpn_raw] if len(mpn_raw) <= 40 else []
        if not pieces:
            pieces = [p for p in SKU_SPLIT.split(mpn_raw) if p][:50]
        brand = cell("brand").strip()
        url = cell("url").strip()
        pkg = cell("package").strip()[:80]
        pack = cell("packaging").strip()[:120]
        desc = cell("description").strip()[:400]
        for p in pieces:
            mpn = _clean_mpn(p)
            k = key_of(mpn)
            if not k or k in seen:
                continue
            if len(k) < 2 or len(mpn) > 180:
                continue
            if not re.search(r"[A-Za-z]", mpn):          # 纯数字基本是行号/ID，不是型号
                continue
            seen.add(k)
            out.append({"mpn": mpn, "mpn_key": k, "brand": brand, "url": url,
                        "package": pkg, "packaging": pack, "description": desc})
            if len(out) >= limit:
                return out
    return out


# ---------------------------------------------------------------- 模板
TEMPLATE_HEADERS = ["型号", "品牌", "封装", "包装", "产品描述", "PDF链接"]
TEMPLATE_SAMPLES = [
    ["CDC6CE040000ADLFR", "Texas Instruments", "4-VDFN", "Tape & Reel (TR)",
     "LOW-POWER, LOW-JITTER, BULK-ACOUSTIC-WAVE OSCILLATOR",
     "https://www.ti.com/lit/ds/symlink/cdc6c.pdf"],
    ["LM358DR", "Texas Instruments", "SOIC-8", "Tape & Reel (TR)",
     "DUAL OPERATIONAL AMPLIFIER", "https://www.ti.com/lit/ds/symlink/lm358.pdf"],
    ["NE555P", "Texas Instruments", "PDIP-8", "Tube", "PRECISION TIMER",
     ""],
]
TEMPLATE_NOTES = [
    ["列名", "是否必填", "说明"],
    ["型号", "必填", "制造商料号。会按「去非字母数字并大写」归一化后全库去重"],
    ["品牌", "建议", "用于匹配原厂 URL 规则（TI / ST / Microchip / ADI / onsemi / NXP / Diodes / Silicon Labs / Espressif / Renesas）"],
    ["封装", "可选", "仅作线索展示，解析结果里的封装仍以 Datasheet 为准"],
    ["包装", "可选", "仅作线索展示"],
    ["产品描述", "可选", "仅作线索展示"],
    ["PDF链接", "可选", "有就优先用；TI 网关 / Rochester 查看页会自动改写成文件本体。留空则按原厂规则直拼"],
    ["", "", ""],
    ["注意", "", "表头放在第一行；一个工作表即可；数量大时建议单批不超过 2 万行"],
]


def write_template(dest: Path) -> Path:
    """生成型号表模板（表头 + 3 行示例 + 填写说明）。"""
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "型号表"
    ws.append(TEMPLATE_HEADERS)
    head_fill = PatternFill("solid", fgColor="E8F0FB")
    for i, _ in enumerate(TEMPLATE_HEADERS, start=1):
        c = ws.cell(row=1, column=i)
        c.font = Font(bold=True)
        c.fill = head_fill
        c.alignment = Alignment(vertical="center")
    for row in TEMPLATE_SAMPLES:
        ws.append(row)
    for col, width in zip("ABCDEF", (28, 22, 16, 30, 60, 62)):
        ws.column_dimensions[col].width = width
    ws.freeze_panes = "A2"

    notes = wb.create_sheet("填写说明")
    for row in TEMPLATE_NOTES:
        notes.append(row)
    for col, width in zip("ABC", (14, 12, 110)):
        notes.column_dimensions[col].width = width
    notes.cell(row=1, column=1).font = Font(bold=True)

    dest.parent.mkdir(parents=True, exist_ok=True)
    wb.save(dest)
    return dest


def safe_name(mpn: str) -> str:
    """产物文件名：只留字母数字点横线下划线。"""
    return re.sub(r"[^A-Za-z0-9._-]+", "_", mpn or "").strip("_") or "unknown"
