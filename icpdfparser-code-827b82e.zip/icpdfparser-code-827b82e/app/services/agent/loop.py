"""Agent Loop - 多步任务编排。

负责调度工具调用、状态管理、循环控制、超时和失败恢复。
"""
from __future__ import annotations

import json
import time
import uuid
from datetime import datetime
from typing import Any, Callable

from app import db
from app.services.agent.intent import detect_intent
from qc.agent_tools import registry


# 默认预算配置
DEFAULT_BUDGET = {
    "max_steps": 12,
    "max_llm_calls": 6,
    "tool_timeout": 60,  # 秒
    "max_retries": 2,
    "max_cost": 0.5,  # 元
}

VALID_SEVERITIES = ("P0", "P1", "P2")


def _normalize_severity(raw) -> list[str]:
    """把模型给的 severity 洗成合法等级。

    模型会把「PQ 问题」这类说法当成等级吐回来（实测 severity=["PQ"]），
    过滤时一条都命中不了，界面上就变成「有问题但显示 0 条」——比报错还难查。
    非法值一律丢掉，洗空了就退回默认 P0/P1。
    """
    if isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, (list, tuple)):
        return ["P0", "P1"]

    cleaned = []
    for s in raw:
        t = str(s).strip().upper()
        if t in VALID_SEVERITIES and t not in cleaned:
            cleaned.append(t)
    return cleaned or ["P0", "P1"]


class AgentState:
    """Agent 任务状态。"""
    
    def __init__(self, task_id: str, user_id: str = "agent"):
        self.task_id = task_id
        self.user_id = user_id
        self.intent = None
        self.intent_result = None
        self.status = "CREATED"
        self.steps = []
        self.budget = DEFAULT_BUDGET.copy()
        self.context = {}
        self.result = {}
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
    
    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "user_id": self.user_id,
            "intent": self.intent,
            "status": self.status,
            "steps": self.steps,
            "budget": self.budget,
            "context": self.context,
            "result": self.result,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


class AgentLoop:
    """Agent 执行循环。"""
    
    def __init__(self, state: AgentState, on_event: Callable[[str, dict], None] | None = None):
        self.state = state
        self.step_count = 0
        self.llm_call_count = 0
        self.total_cost = 0.0
        self.on_event = on_event

    def _emit(self, kind: str, payload: dict) -> None:
        """进度回调。SSE 靠它把"正在干什么"推给前端。

        回调本身不能影响主流程：前端断开、序列化失败都不该让任务挂掉。
        """
        if not self.on_event:
            return
        try:
            self.on_event(kind, payload)
        except Exception as e:  # noqa: BLE001
            print(f"[AgentLoop] 进度回调失败: {e}")
    
    async def run(self, user_input: str, context: dict = None) -> dict:
        """执行 Agent 任务。
        
        Args:
            user_input: 用户自然语言输入
            context: 会话上下文
        
        Returns:
            任务执行结果
        """
        try:
            # 1. 意图识别
            self.state.status = "INTENT_PARSING"
            self._save_state()
            
            intent_result = detect_intent(user_input, context)
            self.state.intent = intent_result.get("intent", "GENERAL_QA")
            self.state.intent_result = intent_result
            self.state.status = "INTENT_PARSED"
            self._save_state()
            self._emit("intent", {
                "intent": self.state.intent,
                "confidence": intent_result.get("confidence", 0),
                "entities": intent_result.get("entities", {}),
            })
            
            # 2. 检查缺失参数
            missing_slots = intent_result.get("missing_slots", [])
            if missing_slots:
                return {
                    "status": "NEED_CLARIFICATION",
                    "task_id": self.state.task_id,
                    "intent": self.state.intent,
                    "missing_slots": missing_slots,
                    "message": f"缺少必要参数：{', '.join(missing_slots)}",
                }
            
            # 3. 权限检查
            constraints = intent_result.get("constraints", {})
            if not self._check_permissions(intent_result):
                return {
                    "status": "UNAUTHORIZED",
                    "task_id": self.state.task_id,
                    "intent": self.state.intent,
                    "message": "权限不足，无法执行此操作",
                }
            
            # 4. 生成任务计划
            self.state.status = "PLANNING"
            self._save_state()
            
            plan = self._build_plan(intent_result)
            self.state.status = "PLANNED"
            self._save_state()
            self._emit("plan", {"tools": [s.get("tool", "") for s in plan]})

            # 5. 执行任务计划
            self.state.status = "RUNNING"
            self._save_state()

            for step in plan:
                if self.step_count >= self.state.budget["max_steps"]:
                    return {
                        "status": "BUDGET_EXCEEDED",
                        "task_id": self.state.task_id,
                        "intent": self.state.intent,
                        "message": f"超出最大步数限制：{self.state.budget['max_steps']}",
                    }

                self._emit("step_start", {
                    "tool": step.get("tool", ""),
                    "arguments": step.get("arguments", {}),
                })
                _t0 = time.monotonic()
                step_result = await self._execute_step(step)
                self._emit("step_done", {
                    "tool": step.get("tool", ""),
                    "status": step_result.get("status", ""),
                    "ms": int((time.monotonic() - _t0) * 1000),
                })
                self.state.steps.append({
                    "step": step,
                    "result": step_result,
                    "timestamp": datetime.now().isoformat(),
                })
                
                # 检查是否需要审批
                if step_result.get("requires_approval"):
                    self.state.status = "WAITING_APPROVAL"
                    self._save_state()
                    return {
                        "status": "WAITING_APPROVAL",
                        "task_id": self.state.task_id,
                        "intent": self.state.intent,
                        "message": "需要人工审批",
                        "step_result": step_result,
                    }
                
                # 检查是否失败
                if step_result.get("status") == "ERROR":
                    if self._is_recoverable(step_result):
                        # 可恢复错误，重试
                        retry_result = await self._retry_step(step)
                        if retry_result.get("status") == "ERROR":
                            return {
                                "status": "FAILED",
                                "task_id": self.state.task_id,
                                "intent": self.state.intent,
                                "message": f"步骤失败：{step['tool']}",
                                "error": retry_result.get("error"),
                            }
                    else:
                        # 不可恢复错误，终止
                        return {
                            "status": "FAILED",
                            "task_id": self.state.task_id,
                            "intent": self.state.intent,
                            "message": f"步骤失败：{step['tool']}",
                            "error": step_result.get("error"),
                        }
                
                self.step_count += 1
            
            # 6. 验证结果
            self.state.status = "VERIFYING"
            self._save_state()
            
            validation = await self._validate_results()
            
            # 7. 完成任务
            self.state.status = "COMPLETED"
            self.state.result = {
                "validation": validation,
                "total_steps": self.step_count,
                "total_cost": self.total_cost,
            }
            self._save_state()
            
            return {
                "status": "COMPLETED",
                "task_id": self.state.task_id,
                "intent": self.state.intent,
                "result": self.state.result,
                "steps": self.state.steps,
            }
            
        except Exception as e:
            self.state.status = "FAILED"
            self.state.result = {"error": str(e)}
            self._save_state()
            
            return {
                "status": "FAILED",
                "task_id": self.state.task_id,
                "intent": self.state.intent,
                "error": str(e),
            }
    
    def _check_permissions(self, intent_result: dict) -> bool:
        """检查权限。"""
        intent = intent_result.get("intent", "")
        constraints = intent_result.get("constraints", {})
        
        # P0 问题禁止自动修复
        severity = intent_result.get("entities", {}).get("severity", [])
        if "P0" in severity and intent in ["REPAIR_APPLY"]:
            return False
        
        # 写入操作需要授权
        if constraints.get("allow_write") and intent in ["REPAIR_APPLY"]:
            # 这里应该检查用户权限，暂时返回 True
            return True
        
        return True
    
    def _build_plan(self, intent_result: dict) -> list[dict]:
        """根据意图构建任务计划。"""
        intent = intent_result.get("intent", "GENERAL_QA")
        entities = intent_result.get("entities", {})
        constraints = intent_result.get("constraints", {})
        severity = _normalize_severity(entities.get("severity"))

        plan = []

        if intent == "QC_DIAGNOSE":
            plan.append({
                "tool": "qc.get_findings",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "severity_filter": severity,
                },
            })

        elif intent == "QC_ANALYZE":
            plan.append({
                "tool": "qc.pandas_analyze",
                "arguments": {
                    "filters": entities.get("filters", {}),
                    "persist": constraints.get("persist", False),
                },
            })

        elif intent == "EVIDENCE_LOOKUP":
            plan.append({
                "tool": "qc.get_evidence",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "dry": constraints.get("dry", True),
                },
            })

        elif intent == "REPAIR_DRY_RUN":
            plan.append({
                "tool": "qc.get_findings",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "severity_filter": ["P1"],
                },
            })
            plan.append({
                "tool": "qc.propose_patch",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "finding_id": entities.get("finding_id", ""),
                    "fixer_name": entities.get("fixer_name", "fix_escape"),
                    "target_fields": entities.get("target_fields", []),
                    "mode": "dry_run",
                },
            })
            plan.append({
                "tool": "qc.validate_patch",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "candidate_path": "",  # 由上一步填充
                },
            })
        
        elif intent == "REPAIR_APPLY":
            plan.append({
                "tool": "qc.commit_patch",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "finding_id": entities.get("finding_id", ""),
                    "candidate_path": entities.get("candidate_path", ""),
                    "authorization": {
                        "authorized_by": self.state.user_id,
                        "authorization_reason": "User approved",
                        "run_id": self.state.task_id,
                    },
                },
            })
            plan.append({
                "tool": "qc.recheck_finding",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "finding_id": entities.get("finding_id", ""),
                    "dry_run": True,
                },
            })
        
        elif intent == "REGRESSION_TEST":
            plan.append({
                "tool": "qc.run_regression",
                "arguments": {
                    "mpn": entities.get("mpn", ""),
                    "write": constraints.get("write", False),
                },
            })
        
        elif intent == "TASK_STATUS":
            # 查询任务状态不需要调用工具
            pass
        
        # GENERAL_QA 不调用工具
        
        return plan
    
    async def _execute_step(self, step: dict) -> dict:
        """执行单个步骤。"""
        tool_name = step["tool"]
        arguments = step["arguments"]
        
        # 执行工具
        result = registry.execute(
            tool_name=tool_name,
            arguments=arguments,
            task_id=self.state.task_id,
            user_id=self.state.user_id,
        )
        
        return result
    
    async def _retry_step(self, step: dict) -> dict:
        """重试失败的步骤。"""
        for attempt in range(self.state.budget["max_retries"]):
            result = await self._execute_step(step)
            if result.get("status") != "ERROR":
                return result
            time.sleep(1)  # 等待 1 秒后重试
        
        return result
    
    def _is_recoverable(self, result: dict) -> bool:
        """判断错误是否可恢复。"""
        error = result.get("error", "")
        # 网络超时、临时错误等可恢复
        recoverable_keywords = ["timeout", "temporary", "network", "retry"]
        return any(kw in error.lower() for kw in recoverable_keywords)
    
    async def _validate_results(self) -> dict:
        """验证任务结果。"""
        # 这里应该调用独立验证器，暂时返回简单验证
        return {
            "status": "PASSED",
            "message": "结果验证通过",
        }
    
    def _save_state(self):
        """保存状态到数据库。"""
        self.state.updated_at = datetime.now()
        
        conn = db.conn()
        try:
            # 更新或插入任务
            existing = conn.execute(
                "SELECT id FROM agent_task WHERE task_id = ?",
                (self.state.task_id,),
            ).fetchone()
            
            if existing:
                conn.execute(
                    """
                    UPDATE agent_task
                    SET intent = ?, status = ?, context = ?, result = ?, updated_at = ?
                    WHERE task_id = ?
                    """,
                    (
                        self.state.intent,
                        self.state.status,
                        json.dumps(self.state.context, ensure_ascii=False),
                        json.dumps(self.state.result, ensure_ascii=False),
                        self.state.updated_at.isoformat(),
                        self.state.task_id,
                    ),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO agent_task
                    (task_id, user_id, intent, status, budget, context, result, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        self.state.task_id,
                        self.state.user_id,
                        self.state.intent or "",
                        self.state.status,
                        json.dumps(self.state.budget),
                        json.dumps(self.state.context, ensure_ascii=False),
                        json.dumps(self.state.result, ensure_ascii=False),
                        self.state.created_at.isoformat(),
                        self.state.updated_at.isoformat(),
                    ),
                )
            
            conn.commit()
        except Exception as e:
            print(f"[AgentLoop] 保存状态失败: {e}")
        finally:
            pass


async def run_agent_task(user_input: str, context: dict = None,
                         on_event: Callable[[str, dict], None] | None = None) -> dict:
    """运行 Agent 任务（便捷函数）。
    
    Args:
        user_input: 用户自然语言输入
        context: 会话上下文
        on_event: 进度回调 (kind, payload)，供 SSE 推送；可为 None
    
    Returns:
        任务执行结果
    """
    task_id = str(uuid.uuid4())
    state = AgentState(task_id=task_id, user_id=context.get("user_id", "agent") if context else "agent")
    loop = AgentLoop(state, on_event=on_event)
    
    return await loop.run(user_input, context)
