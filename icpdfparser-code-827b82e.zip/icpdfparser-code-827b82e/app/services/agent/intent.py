"""Intent Router - LLM 意图识别。

使用百炼模型对用户自然语言命令进行意图分类和参数提取。
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from parse_datasheets import model_for


# 意图类型定义
INTENT_TYPES = [
    "QC_DIAGNOSE",      # 诊断质量问题
    "QC_ANALYZE",       # Pandas 分析
    "EVIDENCE_LOOKUP",  # 证据检索
    "REPAIR_DRY_RUN",   # 生成修复方案（dry-run）
    "REPAIR_APPLY",     # 应用修复（受控写入）
    "REGRESSION_TEST",  # 回归测试
    "TASK_STATUS",      # 任务状态查询
    "GENERAL_QA",       # 通用问答
]

# 意图识别 Prompt
INTENT_PROMPT = """你是一个 QC Agent 意图识别器。分析用户的自然语言命令，提取意图和参数。

## 意图类型

1. **QC_DIAGNOSE**：诊断质量问题，查找 P0/P1 问题
   - 关键词：检查、诊断、问题、P0、P1、错误、异常
   - 示例："检查当前批次的 P0 问题"、"诊断 BUF634PG4 的质量问题"

2. **QC_ANALYZE**：使用 Pandas 分析异常分布
   - 关键词：分析、分布、统计、Pandas、聚合
   - 示例："用 Pandas 分析哪些参数错误最多"、"分析电气参数的分布"

3. **EVIDENCE_LOOKUP**：检索 PDF 证据
   - 关键词：证据、PDF、查找、定位、引用
   - 示例："找出 BUF634PG4 的 PDF 证据"、"查找这个参数的原始依据"

4. **REPAIR_DRY_RUN**：生成修复方案（不实际应用）
   - 关键词：修复、补丁、dry-run、方案、候选
   - 示例："给这些 P1 问题生成修复方案"、"为 BUF634PG4 生成修复补丁"

5. **REPAIR_APPLY**：应用修复（受控写入，需要授权）
   - 关键词：应用、提交、写入、修复并应用
   - 示例："应用已确认的修复补丁"、"提交 BUF634PG4 的修复"

6. **REGRESSION_TEST**：运行回归测试
   - 关键词：回归、测试、regression、验证
   - 示例："跑一遍 74 系列回归测试"、"验证 BUF634PG4 是否通过回归"

7. **TASK_STATUS**：查询任务状态
   - 关键词：状态、任务、进度、历史
   - 示例："查看上次修复执行到哪里"、"任务进度如何"

8. **GENERAL_QA**：通用问答（不属于以上类别）
   - 示例："解释为什么这个参数被阻断"、"什么是 P0 问题"

## 输出格式

返回 JSON，包含：
- intent: 意图类型（必须是上述 8 种之一）
- entities: 提取的实体（mpn, batch_id, finding_ids, severity 等）
- constraints: 约束条件（dry_run, allow_write, require_evidence 等）
- missing_slots: 缺失的必要参数（如果有的话）
- confidence: 置信度（0.0-1.0）

## 示例

用户输入："检查 BUF634PG4 的 P0 问题"

输出：
```json
{
  "intent": "QC_DIAGNOSE",
  "entities": {
    "mpn": "BUF634PG4",
    "severity": ["P0"]
  },
  "constraints": {
    "dry_run": true,
    "allow_write": false
  },
  "missing_slots": [],
  "confidence": 0.95
}
```

## 用户输入

{user_input}

请分析并返回 JSON（不要包含其他内容）：
"""


def detect_intent(user_input: str, context: dict = None) -> dict:
    """使用 LLM 识别用户意图。
    
    Args:
        user_input: 用户自然语言输入
        context: 会话上下文（可选）
    
    Returns:
        意图识别结果，包含 intent, entities, constraints, missing_slots, confidence
    """
    # 1. 先尝试规则匹配（快速路径）
    rule_result = _rule_based_intent(user_input)
    if rule_result and rule_result.get("confidence", 0) > 0.9:
        return rule_result
    
    # 2. 调用 LLM 进行意图识别
    try:
        from parse_datasheets import chat
        
        # 不能用 str.format：INTENT_PROMPT 里的 JSON 示例自带 { }，
        # format 会把 '"intent"' 当成字段名去查，直接抛 KeyError。
        prompt = INTENT_PROMPT.replace("{user_input}", user_input)
        messages = [
            {"role": "system", "content": "你是 QC Agent 意图识别器，只返回 JSON。"},
            {"role": "user", "content": prompt},
        ]
        
        # 使用 Intent 模型（默认 qwen-flash）
        model = os.getenv("ICPDF_MODEL_INTENT", model_for("parse"))
        
        content, usage = chat(
            messages,
            model=model,
            temperature=0.1,  # 低温度，确定性输出
            max_tokens=500,
        )
        
        # 解析 JSON 响应
        result = _parse_intent_response(content)
        
        # 合并上下文
        if context:
            result["context"] = context
        
        return result
        
    except Exception as e:
        # LLM 调用失败，回退到规则匹配
        print(f"[IntentRouter] LLM 调用失败: {e}，回退到规则匹配")
        return rule_result or {
            "intent": "GENERAL_QA",
            "entities": {},
            "constraints": {},
            "missing_slots": [],
            "confidence": 0.5,
            "error": str(e),
        }


def _rule_based_intent(user_input: str) -> dict:
    """基于规则的意图识别（快速路径）。"""
    lower = user_input.lower()
    
    # 提取 MPN（简单规则）
    mpn_match = re.search(r'\b([A-Z0-9\-]{5,30})\b', user_input.upper())
    mpn = mpn_match.group(1) if mpn_match else None
    
    entities = {}
    if mpn:
        entities["mpn"] = mpn
    
    # 规则匹配
    if any(kw in lower for kw in ["p0", "p1", "问题", "诊断", "检查"]):
        if "p0" in lower:
            entities["severity"] = ["P0"]
        elif "p1" in lower:
            entities["severity"] = ["P1"]
        return {
            "intent": "QC_DIAGNOSE",
            "entities": entities,
            "constraints": {"dry_run": True, "allow_write": False},
            "missing_slots": [],
            "confidence": 0.85,
        }
    
    if any(kw in lower for kw in ["pandas", "分析", "分布", "统计"]):
        return {
            "intent": "QC_ANALYZE",
            "entities": entities,
            "constraints": {"persist": False},
            "missing_slots": [],
            "confidence": 0.80,
        }
    
    if any(kw in lower for kw in ["证据", "pdf", "查找", "定位"]):
        return {
            "intent": "EVIDENCE_LOOKUP",
            "entities": entities,
            "constraints": {"dry": True},
            "missing_slots": ["mpn"] if not mpn else [],
            "confidence": 0.85,
        }
    
    if any(kw in lower for kw in ["修复", "补丁", "dry-run", "方案"]):
        if "应用" in lower or "提交" in lower:
            return {
                "intent": "REPAIR_APPLY",
                "entities": entities,
                "constraints": {"allow_write": True},
                "missing_slots": ["mpn"] if not mpn else [],
                "confidence": 0.80,
            }
        else:
            return {
                "intent": "REPAIR_DRY_RUN",
                "entities": entities,
                "constraints": {"dry_run": True, "allow_write": False},
                "missing_slots": ["mpn"] if not mpn else [],
                "confidence": 0.85,
            }
    
    if any(kw in lower for kw in ["回归", "测试", "regression", "验证"]):
        return {
            "intent": "REGRESSION_TEST",
            "entities": entities,
            "constraints": {"write": False},
            "missing_slots": ["mpn"] if not mpn else [],
            "confidence": 0.85,
        }
    
    if any(kw in lower for kw in ["状态", "任务", "进度", "历史"]):
        return {
            "intent": "TASK_STATUS",
            "entities": entities,
            "constraints": {},
            "missing_slots": [],
            "confidence": 0.75,
        }
    
    # 默认：通用问答
    return {
        "intent": "GENERAL_QA",
        "entities": entities,
        "constraints": {},
        "missing_slots": [],
        "confidence": 0.60,
    }


def _parse_intent_response(content: str) -> dict:
    """解析 LLM 返回的意图识别结果。"""
    text = (content or "").strip()

    # 1) markdown 代码块
    json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1)
    else:
        json_str = text

    result = None
    try:
        result = json.loads(json_str)
    except json.JSONDecodeError:
        # 2) 模型爱在 JSON 前面写一句"好的，分析如下："，整体 loads 会失败。
        #    退一步抓第一个 {...} 块再试一次。
        brace = re.search(r'\{.*\}', text, re.DOTALL)
        if brace:
            try:
                result = json.loads(brace.group(0))
            except json.JSONDecodeError as e:
                print(f"[IntentRouter] JSON 解析失败: {e}")
        else:
            print("[IntentRouter] 响应里没有 JSON 块")

    if not isinstance(result, dict):
        return {
            "intent": "GENERAL_QA",
            "entities": {},
            "constraints": {},
            "missing_slots": [],
            "confidence": 0.5,
            "error": "JSON parse failed",
        }

    # 验证意图类型
    if result.get("intent") not in INTENT_TYPES:
        result["intent"] = "GENERAL_QA"
        result["confidence"] = 0.5

    # 确保必要字段存在
    result.setdefault("entities", {})
    result.setdefault("constraints", {})
    result.setdefault("missing_slots", [])
    result.setdefault("confidence", 0.7)

    return result
