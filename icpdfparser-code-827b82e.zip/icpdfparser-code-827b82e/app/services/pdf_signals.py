"""PDF 文本层信号（只读启发式）。

用于分析包/分析器的分组：是否含电气表文字、表格结构类型。
不是表格解析引擎，也不产生任何“已核验”结论。
"""
from __future__ import annotations

from pathlib import Path


def signals(path) -> dict | None:
    """读取 PDF 文本层并返回启发式信号；无法读取时返回 None。

    table_structure_type 仅按 MIN/TYP/MAX 与 CONDITIONS 关键词归类，
    必须由工程人员按原厂页码/表头复核后才能作为修复依据。
    """
    try:
        import fitz                                            # noqa: F401
    except Exception:                                          # noqa: BLE001
        return None
    p = str(path or "")
    if not p or not Path(p).is_file():
        return None
    try:
        if Path(p).stat().st_size > 30_000_000:
            return {"pdf_has_ec_text": "PDF_TOO_LARGE",
                    "electrical_parse_status": "PDF_TOO_LARGE",
                    "table_structure_type": "PDF_TOO_LARGE"}
        with fitz.open(p) as doc:
            text = "\n".join(page.get_text() for page in doc)
    except Exception:                                          # noqa: BLE001
        return {"pdf_has_ec_text": "PDF_UNREADABLE",
                "electrical_parse_status": "PDF_UNREADABLE",
                "table_structure_type": "PDF_UNREADABLE"}
    low = text.lower()
    has_ec = ("electrical characteristics" in low
              or "electrical specifications" in low)
    if not has_ec:
        return {"pdf_has_ec_text": "NO",
                "electrical_parse_status": "NO_EC_TEXT",
                "table_structure_type": "NO_EC_TEXT"}
    cols = all(k in low for k in ("min", "typ", "max"))
    cond = "conditions" in low or "test conditions" in low
    if cols and cond:
        kind = "CONDITIONAL_MIN_TYP_MAX"
    elif cols:
        kind = "MIN_TYP_MAX"
    elif cond:
        kind = "CONDITIONAL_COLUMNS"
    else:
        kind = "EC_TEXT_ONLY"
    return {"pdf_has_ec_text": "YES",
            "electrical_parse_status": "HAS_EC_TEXT",
            "table_structure_type": kind}
