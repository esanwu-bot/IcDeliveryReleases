"""review：单型号交付物红线质量审查（规则先过、LLM 兜底）。

边界（与方案一致，对齐客户 8 条红线）：
  * 只读产物（parsed JSON / txt / alts / seo / 可选 PDF 前 6 页文本），
    不改 facts / Gold / item / 渲染；补链重解析等操作一律不在此做；
  * 规则层做确定性检查（EVM 判板、MPN 重写、双重转义、单位重复、
    electrical 字段缺失、多语言英文残留、hero/overview 重复），不花 token；
  * LLM 只判语义可疑点与结构合理性，不判「值对不对」（那是证据卡的活），
    finding 的 page_hint 恒为 null——它没看 PDF 就不能给页码；
  * 结果落 data/qc/reviews/{SAFE}.review.{json,md,html}；
    write_db 仅 append qc_audit_log（先建 qc_run 汇总行）并记 llm_usage(stage=review)，
    全部是 append-only 台账，不 UPDATE/DELETE 业务表；
  * verdict=FAIL 不等于 release blocked，验收必须在客户反馈闭环人工完成；
  * dry_run 只跑规则层、不调模型、不落报告文件。

工作台入口：型号任务列表「审计」按钮（app/api/review.py）；
CLI 入口：仓库根 review.py（--mpn / --batch / --all-parsed）。
"""
from __future__ import annotations

import html
import json
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

import requests

from parse_datasheets import model_for

# 差分对物理相邻性检查：零依赖纯函数，放在 qc/pin_pairs.py（顶层不 import pymupdf，
# 常驻进程引用无副作用）。导入失败时该条规则自动跳过，不影响其余审查。
try:
    from qc.pin_pairs import audit_pin_pairs as _audit_pin_pairs
except Exception:                                               # noqa: BLE001
    _audit_pin_pairs = None

# 「Features 条目误入 electrical」检测：判据走「可测量特征优先」口径，不用关键词
# （关键词版在 `Chip enable access time | 70 | ns` 这类行上必假阳）。导入失败时
# 该条规则自动跳过，与 _audit_pin_pairs 同一套降级策略。
try:
    from qc.electrical_classify import (classify_electrical_row
                                        as _classify_elec_row,
                                        ECHO_NAME as _ECHO_NAME)
except Exception:                                               # noqa: BLE001
    _classify_elec_row = None
    _ECHO_NAME = ""

REVIEW_VERSION = "review-v1"
RULE_VERSION = "redline-8-2026-10-28-v1"
LANGS = ("ja", "ko", "de", "es")

# 图 2#1：MPN 形似评估板/套件的 token（与 json_to_txt 的 evaluation_board 口径互补）
BOARD_TOKENS = ("EVM", "EVK", "EMK", "EVB", "EVAL", "KIT", "BOARD",
                "MODULE", "PDK", "DYNO", "PGMA")

CAVEATS = [
    "LLM 不判数值正确性（需原厂 PDF 证据卡），page_hint 恒为 null。",
    "verdict=FAIL ≠ release blocked；验收必须在客户反馈闭环人工确认。",
    "规则层与 LLM 输出都是「可疑点」，不构成根因结论。",
    "本审查只读产物，不修改 facts / Gold / 渲染。",
]


class ReviewError(Exception):
    def __init__(self, code: str, message: str, http_status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.http_status = http_status


# ---------------------------------------------------------------- 配置 / 时间

def env_config() -> dict:
    return {
        "key": os.getenv("DASHSCOPE_API_KEY", "").strip(),
        "base": os.getenv(
            "DASHSCOPE_BASE",
            "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/"),
        "model": model_for("review"),
        "max_tokens": int(os.getenv("ICPDF_MAX_TOKENS", "6000") or 6000),
        "enable_thinking": os.getenv("ICPDF_ENABLE_THINKING", "0")
            .strip().lower() in ("1", "true", "yes", "on"),
    }


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _now_qc() -> str:
    # 与 db.qc_now() 同格式：julianday() 可解析的本地时间
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _safe_stem(mpn: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(mpn or "")).upper()


def _valid_safe(safe: str) -> bool:
    return bool(re.fullmatch(r"[A-Z0-9._-]{1,120}", str(safe or "")))


# ---------------------------------------------------------------- 快照加载

def find_item(db, mpn: str) -> dict | None:
    return db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1",
                 (mpn, mpn))


def _resolve(stored: str, sub: str, data_dir: Path) -> Path:
    """库中产物路径 -> 当前机器可用路径（跨机迁移免疫，口径同 config.resolve_artifact）。

    找不到时返回「应有位置」，调用方据此报告缺失。
    """
    p = Path(stored or "")
    if p.is_file():
        return p
    name = (stored or "").replace("\\", "/").rsplit("/", 1)[-1]
    return (Path(data_dir) / sub / name) if name else p


def _read_text(path: Path, max_chars: int = 0) -> str:
    if not path or not path.is_file():
        return ""
    try:
        s = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""
    return s[:max_chars] if max_chars else s


def _load_json(path: Path) -> dict:
    if not path or not path.is_file():
        return {}
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


def _load_snapshot(row: dict, data_dir: Path) -> dict:
    """把单型号产物聚成规则层 + LLM 共用的只读快照。"""
    data_dir = Path(data_dir)
    snap: dict[str, Any] = {
        "mpn": str(row.get("mpn") or ""),
        "mpn_key": str(row.get("mpn_key") or ""),
        "item": {k: row.get(k) for k in
                 ("id", "batch_id", "status", "stage", "brand",
                  "pdf_sha256", "pdf_bytes", "last_parsed_at")},
        "paths": {},
    }
    jp = _resolve(row.get("json_path") or "", "parsed", data_dir)
    snap["paths"]["json"] = str(jp)
    snap["json"] = _load_json(jp)

    tp = _resolve(row.get("txt_path") or "", "txt", data_dir)
    snap["paths"]["txt"] = str(tp)
    snap["txt_en"] = _read_text(tp, max_chars=200_000)
    stem = tp.stem if tp.name else _safe_stem(snap["mpn"])
    snap["lang_txt"] = {
        lang: _read_text(data_dir / "txt" / f"{stem}.{lang}.txt", max_chars=8_000)
        for lang in LANGS
    }

    ap = _resolve(row.get("alt_json_path") or "", "alts", data_dir)
    snap["paths"]["alts"] = str(ap)
    snap["alts"] = _load_json(ap)

    sp = _resolve(row.get("seo_path") or "", "seo", data_dir)
    snap["paths"]["seo"] = str(sp)
    snap["seo"] = _load_json(sp)

    # 符号页（三视图）：工程模型边界断言要看页面实际文本；缺页就跳过（不伪造通过）。
    yp = _resolve(row.get("symbol_path") or "", "symbols", data_dir)
    snap["paths"]["symbols"] = str(yp)
    snap["symbols_html"] = _read_text(yp, max_chars=400_000)
    snap["pkgs_dir"] = str(Path(data_dir) / "pkgs")

    snap["pdf_path"] = str(_resolve(row.get("pdf_path") or "", "pdfs", data_dir))
    return snap


_ORDER_SECTION_RE = re.compile(
    r"(orderable\s+part\s+number|package\s+option\s+addendum|ordering\s+information)",
    re.I)


def _pdf_excerpt(path: str, pages: int = 6) -> str:
    """PDF 前 N 页 + **订货表所在页**（判身份/封装更稳但成本翻倍）。

    订货表几乎总在文档末尾（实测 284 页的 F280037CSPTR 在第 246 页），
    只取前 N 页会让 identity 永远看不到原厂订货表，一律落到「证据不全」。
    所以额外定位第一处订货表章节页，并把它排在前面——后面 `[:12000]`
    截断时才不会把它切掉。
    """
    try:
        import fitz                                             # noqa: F401
    except Exception:                                           # noqa: BLE001
        return ""
    try:
        with fitz.open(str(path)) as doc:
            n = doc.page_count
            head = [doc[i].get_text("text") for i in range(min(pages, n))]
            order_txt = ""
            for i in range(n):
                if i < pages:
                    continue
                t = doc[i].get_text("text")
                if _ORDER_SECTION_RE.search(t):
                    order_txt = t
                    break
            parts = ([order_txt] if order_txt else []) + head
            return "\n".join(parts)[:12_000]
    except Exception:                                           # noqa: BLE001
        return ""


# ---------------------------------------------------------------- 规则层（不花 token）

def _looks_like_board(mpn: str, package_type: str = "") -> bool:
    """兼容旧调用：词表 + 封装形态。身份判定请用 `_identity()`（带 datasheet 证据）。"""
    up = str(mpn or "").upper()
    if any(t in up for t in BOARD_TOKENS):
        return True
    return str(package_type or "").upper().startswith("PCB")


def _identity(mpn: str, doc: dict, package_type: str = "",
              manufacturer: str = "", pdf_text: str = "") -> dict:
    """证据驱动的身份判定（口径唯一定义在 qc/board_identity.py）。

    L2 只给「候选身份 + 置信度 + 五态判决」，是否记 finding 由下面的映射决定：
      IDENTITY_SUPPORTED  （订货表精确命中 / 只是包装变体 / 同族变体）→ 不报
      BOARD_CONFIRMED     （板卡，且订购码在表内或 datasheet 有板卡表述）→ 未标板卡才报
      IDENTITY_REVIEW     （后缀命中但证据不足）                      → P1，人工
      IDENTITY_CONFLICT   （上游给了正面矛盾证据，缺匹配**不算**）      → P0
      EVIDENCE_INCOMPLETE （订货表没提取到 / 抽到了但对不上任何同族）  → 非 advisory 才报
    """
    try:
        from qc import board_identity as BI
        return BI.classify(mpn, doc, package_type, manufacturer, pdf_text)
    except Exception:                                           # noqa: BLE001
        return {"identity": "unknown", "decision": "EVIDENCE_INCOMPLETE",
                "is_board": _looks_like_board(mpn, package_type),
                "device_mpn": "", "severity": "P2", "in_orderables": True,
                "rule_id": "", "confidence": "low", "requires_human": True,
                "evidence": ["判定器不可用，退化到词表口径"]}


# 单层实体：HTML 里是正确转义，JSON 里是残留——两层语义不同，必须分开判。
_ENTITY = re.compile(r"&(?:amp|lt|gt|quot|apos|nbsp|#\d{1,6}|#x[0-9a-fA-F]{1,5});")
# 双层/多层实体：不管在哪一层，都是被 escape 执行了两遍以上。
_DOUBLE_ENTITY = re.compile(
    r"&(?:amp;){2,}|&amp;(?:lt|gt|quot|apos|nbsp|#\d{1,6}|#x[0-9a-fA-F]{1,5});")


def _iter_strings(node: Any, path: str = "") -> Iterator[tuple[str, str]]:
    """递归取 JSON 里所有字符串（含 key 路径），用于纯文本层的转义扫描。"""
    if isinstance(node, str):
        yield path, node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from _iter_strings(v, f"{path}.{k}" if path else str(k))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            yield from _iter_strings(v, f"{path}[{i}]")


def _snip(text: str, start: int, end: int, pad: int = 20) -> str:
    return re.sub(r"\s+", " ", text[max(0, start - pad):end + pad]).strip()


def _find_json_escape(j: dict) -> list[dict]:
    """JSON 是纯文本层：出现任何 HTML 实体都会被渲染器再转义一遍，必成乱码。

    这是转义类缺陷的**根因层**，优先级高于渲染层的双层实体。
    """
    hits: list[dict] = []
    for path, s in _iter_strings(j):
        for m in _ENTITY.finditer(s):
            hits.append({"field": path, "quote": _snip(s, m.start(), m.end())})
            break                                   # 每个字段只取第一处证据
        if len(hits) >= 5:
            break
    if not hits:
        return []
    return [{"kind": "escape_entity_in_json", "evidence": {
        "fields": [h["field"] for h in hits],
        "quote": " | ".join(h["quote"] for h in hits)}}]


def _find_html_double_escape(text: str) -> list[dict]:
    """HTML 渲染层只看双层实体。

    单层 `&lt;` / `&amp;` 是 HTML 的正确转义（浏览器显示 `<` / `&`），不是残留。
    早期版本把「同时含实体和 &amp;」一律判成 mixed_escape，结果所有带比较符的
    页面（如 `TRIG &lt; 1/2 CONT`）全量 WARN，污染自动修复队列——已废弃该判据。
    """
    hits = [_snip(text, m.start(), m.end())
            for m in list(_DOUBLE_ENTITY.finditer(text))[:5]]
    if not hits:
        return []
    return [{"kind": "double_escape_multi",
             "evidence": {"quote": " | ".join(hits)}}]


def _find_double_escape(j: dict, txt: str = "") -> list[dict]:
    """转义残留总入口：JSON 层有残留就只报根因，不重复报渲染层症状。"""
    return _find_json_escape(j) or _find_html_double_escape(txt or "")


def _english_ratio(s: str) -> float:
    s = re.sub(r"[\s\d\W_]", "", s or "")
    if not s:
        return 0.0
    letters = sum(1 for ch in s if "a" <= ch.lower() <= "z")
    return letters / len(s)


# de/es 本身就是拉丁字母，不能用 ascii 占比判英文残留（正常德语/西语会 0.97+ 误报）；
# 改看英文功能词：德语用 der/die/und，西语用 el/la/y，正常译文不会命中这些词。
_EN_STOPWORDS = (" the ", " and ", " with ", " of ", " for ", " from ",
                 " this ", " that ", " are ", " was ", " when ")


def _en_stopword_hits(desc: str) -> int:
    low = " " + re.sub(r"\s+", " ", desc or "").lower() + " "
    return sum(low.count(w) for w in _EN_STOPWORDS)


def _i18n_residue(lang: str, desc: str) -> tuple[bool, str]:
    """多语言英文残留判定：ja/ko 看 ascii 字母占比，de/es 看英文功能词。"""
    if lang in ("ja", "ko"):
        r = _english_ratio(desc)
        return r >= 0.55, f"ascii 字母占比 {r:.2f}"
    hits = _en_stopword_hits(desc)
    return hits >= 2, f"英文功能词命中 {hits} 处（the/and/of/with…）"


def _hero_overview_similarity(txt_en: str) -> float:
    m = re.search(r'<h1 class="pd-hero-title">(.*?)</h1>', txt_en, re.S)
    m2 = re.search(r'<section[^>]*id="product-introduction".*?<p>(.*?)</p>',
                   txt_en, re.S)
    if not (m and m2):
        return 0.0
    from difflib import SequenceMatcher
    a = re.sub(r"<[^>]+>", " ", m.group(1)).strip()
    b = re.sub(r"<[^>]+>", " ", m2.group(1)).strip()
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def _rule_checks(snap: dict) -> list[dict]:
    """8 条红线里可确定性判的项在此封口，不进 LLM。"""
    out: list[dict] = []
    j = snap.get("json") or {}
    bi = j.get("basic_info") or {}
    specs = j.get("specs") or {}
    pkg = specs.get("package") or {}
    mpn = snap["mpn"]

    # 1) EVM/EVK/EB 判板矛盾（红线 #1）——证据驱动，词表只作候选线索
    identity = str(bi.get("identity") or "").strip().lower()
    onboard = str(pkg.get("onboard_device") or "").strip()
    ident = _identity(mpn, j, str(pkg.get("type") or ""),
                      str(bi.get("manufacturer") or ""),
                      snap.get("pdf_text") or "")
    state = str(ident.get("state") or "")
    snap["identity_state"] = state
    snap["identity"] = {k: ident.get(k) for k in (
        "identity", "state", "verdict", "blocks_release", "confidence",
        "rule_id", "device_mpn", "in_orderables", "orderable_count",
        "requires_human")}
    ev = "；".join(ident.get("evidence") or [])[:240]
    quote = (f"mpn={mpn}; state={state}; rule={ident.get('rule_id') or '-'};"
             f" identity={(identity or '(空)')}; device_mpn={ident.get('device_mpn') or '(空)'}")
    if state == "IDENTITY_CONFLICT" and identity != "evaluation_board":
        # 只有上游给出「这份 datasheet 不是这个料号」的正面证据才会到这里；
        # 缺匹配（BOM 写族根/旧封装）已在判定层按同族变体收为 PASS。
        out.append({"kind": "identity_conflict", "severity": "P0",
                    "message": "身份冲突：%s" % ev,
                    "evidence": {"field": "basic_info.identity", "quote": quote}})
    elif state == "IDENTITY_REVIEW" and identity != "evaluation_board":
        # 这条正是 ADC128D818EB/NOPB 该落的位置：WARN + 阻断 + 人工，
        # 既不自动标 board（假阳性），也不当芯片放过去（历史失败案例）
        out.append({"kind": "identity_review", "severity": "P1",
                    "message": "身份待人工核验（%s）" % ev,
                    "evidence": {"field": "basic_info.identity", "quote": quote}})
    elif state == "EVIDENCE_INCOMPLETE" and not identity \
            and not ident.get("advisory"):
        # advisory（这份 datasheet 本来就没有订货表）不报，否则老 datasheet 全量误报
        out.append({"kind": "identity_evidence_incomplete", "severity": "P1",
                    "message": "身份证据不全（%s）；应先修订货表提取，不猜身份" % ev,
                    "evidence": {"field": "basic_info.identity", "quote": quote}})
    elif state == "BOARD_CONFIRMED" and identity != "evaluation_board":
        out.append({"kind": "board_confirmed_unmarked", "severity": "P1",
                    "message": "datasheet 有板卡证据（%s），但 identity 未标 evaluation_board" % ev,
                    "evidence": {"field": "basic_info.identity", "quote": quote}})
    if identity == "evaluation_board":
        ptype = str(pkg.get("type") or "").strip()
        if ptype and not ptype.upper().startswith("PCB"):
            out.append({"kind": "board_package_mismatch", "severity": "P0",
                        "message": "identity 判为评估板，但 specs.package.type 是芯片封装",
                        "evidence": {"field": "specs.package.type",
                                     "quote": f"identity=evaluation_board; type={ptype}"}})
    elif onboard:
        out.append({"kind": "board_identity_missing", "severity": "P1",
                    "message": "specs.package.onboard_device 已登记板载器件，"
                               "但 basic_info.identity 未标 evaluation_board，口径不一致",
                    "evidence": {"field": "specs.package.onboard_device",
                                 "quote": f"onboard_device={onboard}"}})

    # 2) MPN 被改写成板载/其它器件（红线 #1）
    basic_mpn = str(bi.get("mpn") or "").strip()
    requested = str((j.get("metadata") or {}).get("requested_mpn") or "").strip()
    if basic_mpn and basic_mpn != mpn:
        out.append({"kind": "mpn_rewritten", "severity": "P0",
                    "message": "basic_info.mpn 与请求 MPN 不一致（疑似被替换成板载器件）",
                    "evidence": {"field": "basic_info.mpn",
                                 "quote": f"requested={mpn}; json_mpn={basic_mpn}"}})
    elif requested and basic_mpn and requested != basic_mpn:
        out.append({"kind": "mpn_rewritten", "severity": "P0",
                    "message": "metadata.requested_mpn 与 basic_info.mpn 不一致",
                    "evidence": {"field": "basic_info.mpn",
                                 "quote": f"requested={requested}; json_mpn={basic_mpn}"}})

    # 3) HTML 实体转义残留（红线 #7）：JSON 纯文本层优先，其次才是渲染层双层转义
    for f in _find_double_escape(j, snap.get("txt_en", "")):
        f["severity"] = "P1"
        f["message"] = ("JSON 文本字段里混入 HTML 实体，渲染会再转义一次变乱码"
                        if f["kind"] == "escape_entity_in_json"
                        else "渲染层存在双层 HTML 实体（&amp;amp; 这类），会显示为乱码")
        out.append(f)

    # 4) electrical 三件套缺失（红线 #2）
    bad_elec = []
    for i, e in enumerate(specs.get("electrical") or []):
        missing = [k for k in ("name", "value", "unit")
                   if not str(e.get(k, "") or "").strip()]
        if missing:
            bad_elec.append({"index": i, "missing": missing,
                             "name": str(e.get("name") or "")[:40]})
    if bad_elec:
        out.append({"kind": "electrical_field_missing", "severity": "P1",
                    "message": f"electrical 存在 {len(bad_elec)} 条缺 name/value/unit",
                    "evidence": {"field": "specs.electrical",
                                 "quote": json.dumps(bad_elec[:5], ensure_ascii=False)}})

    # 4b) Features 条目混入 electrical（`value` 回灌 `name`）
    #     与 #4 互补：#4 抓「字段缺失」，这条抓「字段填满但填的是错的」——
    #     三件套都非空，所以 #4 不会响，必须单独判。
    #     实证：prompt v2 dry-run 里 DAC37J84IAAV 有 10 处（"Sinx/x Correction
    #     Filters" 这类），原文来自 Features 章节而非电气表；这类行没有可测量的
    #     值，下游会把「特性标题」当成参数渲染。
    #     `not_specified` 行判 INSUFFICIENT_EVIDENCE，不在此报警（那是原表无值的
    #     明确降级，不是缺陷）。
    if _classify_elec_row is not None:
        echo_rows: list[dict] = []
        for i, e in enumerate(specs.get("electrical") or []):
            if not isinstance(e, dict):
                continue
            if _classify_elec_row(e) == _ECHO_NAME:
                echo_rows.append({"index": i,
                                  "name": str(e.get("name") or "")[:40],
                                  "value": str(e.get("value") or "")[:40]})
        if echo_rows:
            out.append({"kind": "electrical_like_feature", "severity": "P1",
                        "message": (f"electrical 有 {len(echo_rows)} 行 value 回灌 name"
                                    f"（疑似 Features/描述性章节条目，非电气参数）"),
                        "evidence": {"field": "specs.electrical",
                                     "quote": json.dumps(echo_rows[:5],
                                                         ensure_ascii=False)}})

    # 5) 单位重复（"10 mA" + unit "mA" -> 渲染成 10 mA mA，红线 #7）
    dup_units = []
    for i, e in enumerate(specs.get("electrical") or []):
        v = str(e.get("value") or "").strip()
        u = str(e.get("unit") or "").strip()
        if v and u and v.lower().endswith(" " + u.lower()):
            dup_units.append({"index": i, "value": v[:40], "unit": u[:20]})
    if dup_units:
        out.append({"kind": "unit_duplicated", "severity": "P1",
                    "message": f"electrical 存在 {len(dup_units)} 条 value 已带单位、"
                               f"unit 字段又重复（渲染会出现 10 mA mA）",
                    "evidence": {"field": "specs.electrical",
                                 "quote": json.dumps(dup_units[:5], ensure_ascii=False)}})

    # 6) 差分对物理相邻性（红线 #3 引脚）
    #    与逐条 pin_mismatch 互补：后者靠「PDF 表 → JSON」同一条映射，若解析时把
    #    名字按前缀分组重排（先全部 +、再全部 -），两边一起错会互相印证掩盖问题。
    #    这条只看 JSON 自身（脚号 vs 名字里的通道号/极性），能独立抓出方向性错位。
    if _audit_pin_pairs is not None:
        try:
            raw = _audit_pin_pairs(j)
        except Exception:                                       # noqa: BLE001
            raw = []
        pairs = [p for p in raw if p.get("kind") == "pin_pair_broken"]
        pol = [p for p in raw if p.get("kind") == "pin_polarity_missing"]
        if pairs:
            banks = sorted({re.sub(r"^pin_pair\[|\]$", "", str(p.get("path") or ""))
                            for p in pairs})
            out.append({"kind": "pin_pair_broken", "severity": "P1",
                        "message": f"{', '.join(banks)} 组差分对脚号间距恒等于固定值"
                                   f"（疑似名字按前缀分组重排，P/N 被塞进两段脚号）",
                        "evidence": {"field": "pin_configuration",
                                     "banks": banks,
                                     "quote": " | ".join(
                                         f"{p.get('path')}: {p.get('json')}"
                                         for p in pairs[:5])}})
        if pol:
            # 只有单侧极性：可能是单端信号，也可能是名字丢了负端——不可证错位，
            # 因此只记 P2，绝不进自动修复队列
            out.append({"kind": "pin_polarity_missing", "severity": "P2",
                        "message": f"{len(pol)} 个 bank 的差分对只有单侧极性，"
                                   f"无法判定错位（需人工看 PDF 引脚表）",
                        "evidence": {"field": "pin_configuration",
                                     "quote": " | ".join(
                                         f"{p.get('path')}: {p.get('json')}"
                                         for p in pol[:5])}})

    # 6b) 引脚编号超出封装脚数（确定性，零 token）
    #     AM26C32IDG4（SOIC-16）实测 pin_configuration 18 行、编号 1..15/17/18/19
    #     —— 16 脚封装不可能有 17 号脚。这是「重建引脚表」类修复的典型副作用，
    #     必须由规则层硬判，不能指望 LLM 从抽样里偶然发现。
    pkg_pins = int(pkg.get("pins") or 0) if str(pkg.get("pins") or "").isdigit() else 0
    pin_rows = j.get("pin_configuration") or []
    if pkg_pins and pin_rows:
        nums = []
        for p in pin_rows:
            v = (p or {}).get("pin") if isinstance(p, dict) else None
            if isinstance(v, int):
                nums.append(v)
            elif str(v or "").strip().isdigit():
                nums.append(int(str(v).strip()))
        over = sorted(n for n in set(nums) if n < 1 or n > pkg_pins)
        dup = sorted(n for n in set(nums) if nums.count(n) > 1)
        if over or dup:
            out.append({
                "kind": "pin_count_mismatch", "severity": "P0",
                "message": f"引脚表 {len(pin_rows)} 行，封装声明 {pkg_pins} 脚；"
                           + (f"超界脚号 {over[:6]} " if over else "")
                           + (f"重复脚号 {dup[:4]}" if dup else ""),
                "evidence": {"field": "pin_configuration",
                             "quote": f"rows={len(pin_rows)}; pkg_pins={pkg_pins};"
                                      f" numbers={nums[:16]}"}})

    # 7) 多语言英文残留（红线 #5）：先看 parsed JSON 的 multi_language，
    #    缺失再看 {stem}.{lang}.txt 的 meta description
    ml = j.get("multi_language") or {}
    for lang in LANGS:
        block = ml.get(lang)
        desc = str((block or {}).get("description") or "") if isinstance(block, dict) else ""
        if not desc:
            txt = snap.get("lang_txt", {}).get(lang, "")
            m = re.search(r'<meta name="description"[^>]+content="([^"]{40,})"', txt)
            desc = m.group(1) if m else ""
        if not desc:
            continue
        bad, why = _i18n_residue(lang, desc)
        if bad:
            out.append({"kind": "i18n_english_residue", "severity": "P1",
                        "message": f"{lang} 描述疑似仍为英文（{why}）",
                        "evidence": {"field": f"multi_language.{lang}.description",
                                     "quote": desc[:120]}})

    # 8) Hero 与 Overview 重复（红线 #6）
    sim = _hero_overview_similarity(snap.get("txt_en", ""))
    if sim >= 0.9:
        out.append({"kind": "hero_overview_duplicate", "severity": "P2",
                    "message": f"Hero 与 Overview 首段相似度 {sim:.2f}，属于凑字数",
                    "evidence": {"field": "txt.hero/overview",
                                 "quote": f"similarity={round(sim, 3)}"}})

    # 9) 正文级多语残留 / sentinel 泄露 / alts 三处不一致 / SEO 共享图
    out.extend(_rule_i18n_body(snap))
    out.extend(_rule_render_sentinel(snap))
    out.extend(_rule_alts_consistency(snap))
    out.extend(_rule_seo_shared(snap))
    # 10) 符号页「工程模型边界」：页面断言 vs derive_state 状态（A1–A5，零 token）
    out.extend(_rule_engineering_model(snap))
    return out


def _rule_engineering_model(snap: dict) -> list[dict]:
    """符号页文案与状态是否同源（qc/engineering_model.py::check）。

    只在页面带 `data-em-page="symbols"` 标记时断言：存量页面是旧文案 + 旧状态，
    重渲染前逐条报没有意义。状态由同一个纯函数派生，不落库、不改 JSON。
    """
    page = snap.get("symbols_html") or ""
    if not page:
        return []
    from qc import engineering_model as EM                    # noqa: PLC0415
    doc = snap.get("json") or {}
    # 用**页面自述的主体**派生状态（板卡页 / 脚数待核页各带一个标记）。
    # 用默认参数派生会让审查状态与页面文案分叉，A5 变成噪声。
    state = EM.derive_state_for_page(doc, snap.get("pkgs_dir") or None, page)
    return EM.check(doc, page, state)


def _text_segments(html: str, min_len: int = 40, narrative_only: bool = False) -> set[str]:
    """从 HTML 里取可见文本片段（去标签、按块切），用于判「这段是不是没翻」。

    narrative_only=True 时先剔除 `<table>` 整块：电气/绝对最大值/订货表的
    condition 是**技术原文**（`BW = 20kHz, AVDD = 5V …`），
    本地化页保留英文是正确口径，翻译反而会改坏技术语义。
    早期版本把表格 cell 也算进来，结果每个参数表齐全的型号全量误报
    「未达全量本地化」（DAC8555IPWG4 实测 15 段里 11 段是条件原文）。
    """
    import html as _h
    txt = html or ""
    if narrative_only:
        txt = re.sub(r"<table[^>]*>.*?</table>", " ", txt, flags=re.S)
    txt = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", txt, flags=re.S)
    txt = re.sub(r"<[^>]+>", "\n", txt)
    out: set[str] = set()
    for line in txt.splitlines():
        s = _h.unescape(line).strip()
        s = re.sub(r"\s+", " ", s)
        if len(s) >= min_len:
            out.add(s)
    return out


def _rule_i18n_body(snap: dict) -> list[dict]:
    """正文级多语残留：只查 meta description 会放过整段英文。

    判据是「与英文正文逐字相同的长片段」——de/es 也是拉丁字母，靠字母占比判不出来，
    但**完全没翻**的段落必然与英文一字不差，这个信号既准又不会误伤正常译文。
    ja/ko 另外加一条：正文里出现长段纯 ASCII 句子，也视为未翻。
    """
    en = _text_segments(snap.get("txt_en", ""), narrative_only=True)
    if not en:
        return []
    out: list[dict] = []
    for lang in LANGS:
        loc = snap.get("lang_txt", {}).get(lang, "")
        if not loc:
            continue
        segs = _text_segments(loc, narrative_only=True)
        same = [s for s in segs if s in en]
        ascii_only = [s for s in segs
                      if lang in ("ja", "ko") and _english_ratio(s) >= 0.9]
        hits = sorted(set(same) | set(ascii_only))
        if not hits:
            continue
        sev = "P1" if len(hits) >= 3 else "P2"
        out.append({
            "kind": "i18n_body_untranslated", "severity": sev,
            "message": f"{lang} 正文有 {len(hits)} 段与英文原文逐字相同"
                       f"（共 {len(segs)} 段，未达全量本地化）",
            "evidence": {"field": f"txt.{lang}",
                         "quote": " | ".join(h[:70] for h in hits[:3])}})
    return out


def _rule_render_sentinel(snap: dict) -> list[dict]:
    """库内 sentinel（not_specified 等）泄到文案里。

    解析层用 not_specified 表示「原文没这一格」（qc/cheatsheet.py 口径），
    那是库内语义不是给人看的字；一旦被 `{value} {unit}` 拼进表格，
    就成了 `12-bit not_specified`，而且是 5 个语种一起发出去。
    """
    out: list[dict] = []
    pat = re.compile(r"\b(not_specified|unspecified|unknown_value)\b", re.I)
    for label, txt in [("en", snap.get("txt_en", ""))] + \
            [(lg, t) for lg, t in (snap.get("lang_txt") or {}).items()]:
        m = pat.search(txt or "")
        if not m:
            continue
        i = txt.rfind("\n", 0, m.start())
        j = txt.find("\n", m.end())
        frag = txt[i + 1:j if j > 0 else m.end() + 40]
        line = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", frag)).strip()
        out.append({"kind": "sentinel_leaked_to_copy", "severity": "P1",
                    "message": f"{label} 正文出现库内 sentinel `{m.group(0)}`"
                               f"（应按「原文未规定」留空或渲染 -）",
                    "evidence": {"field": f"txt.{label}", "quote": line[:120]}})
    return out


def _rule_alts_consistency(snap: dict) -> list[dict]:
    """alts.json / alts.html / txt 三处口径必须一致。

    历史问题：JSON 留 4 条 `match=miss`、HTML 只渲染 2 条、txt 又按 internal 过滤，
    下游按数组长度统计「替代料个数」就报 6 条。
    """
    alts = snap.get("alts") or {}
    if not isinstance(alts, dict):
        return []
    rows = alts.get("alternatives") or []
    out: list[dict] = []
    miss = [r for r in rows if str((r or {}).get("match") or "") == "miss"]
    if miss:
        out.append({"kind": "alts_json_has_miss", "severity": "P1",
                    "message": f"alts.json 含 {len(miss)} 条 match=miss 的候选"
                               f"（README 口径：未命中即丢弃，不能留在数组里）",
                    "evidence": {"field": "alts.alternatives",
                                 "quote": "、".join(str((r or {}).get("mpn"))
                                                    for r in miss[:4])}})
    linked = [r for r in rows if (r or {}).get("internal")]
    if rows and not linked:
        out.append({"kind": "alts_no_internal_link", "severity": "P2",
                    "message": "替代型号数组里没有任何站内可内链条目",
                    "evidence": {"field": "alts.catalog_covered",
                                 "quote": f"rows={len(rows)}; linked=0"}})
    return out


def _rule_seo_shared(snap: dict) -> list[dict]:
    """分类配图被多个应用领域共用时必须标注，否则下游会重复上传同一张图。"""
    seo = snap.get("seo") or {}
    imgs = (seo.get("images") or []) if isinstance(seo, dict) else []
    if not imgs:
        return []
    icons = [str((r or {}).get("image") or "") for r in imgs]
    icons = [i for i in icons if i]
    distinct = len(set(icons))
    if distinct == len(icons) or "shared_icon_count" in seo:
        return []
    return [{"kind": "seo_shared_icon_unmarked", "severity": "P2",
             "message": f"{len(icons)} 条应用配图只有 {distinct} 张 distinct 图，"
                        f"但 seo.json 未标 shared_category_icon / shared_by_applications",
             "evidence": {"field": "seo.shared_category_icon",
                          "quote": f"records={len(icons)}; distinct={distinct}"}}]


# ---------------------------------------------------------------- LLM 层

RULES_TEXT = """你是元器件 Datasheet 结构化产物的红线质量审查员。
你有且仅有以下权限：判断结构/一致性/语义可疑点。
你没有权限修改任何产物，也没有权限断言某个数值"正确"，因为那需要原厂 PDF 证据卡。

对给定产物快照，只做以下判断（命中即列 finding，不命中就不要编）：
1. 身份/封装：MPN 是芯片还是评估板？specs.package.type/pins/onboard_device 与 MPN 是否匹配？
2. 表格语义：electrical 的 value/unit/condition 组合是否可疑（如 mA 写成 mW、MIN/TYP/MAX 丢失、condition 缺失但仍报数值）？
3. 引脚：pin_configuration 的 pin→name 是否呈物理引脚顺序（不是符号图分组顺序）；有无 VDD/GND 位置明显反置？（差分对相邻性已由规则层 pin_pair_broken 判定，不要重复报）
4. 跨文件：features/benefits/applications 是否与 basic_info 描述的定位一致？
5. 多语言：multi_language.{ja,ko,de,es} 是否仍有英文残留（粗判，给 quote）；
6. 冗余：features/applications 是否是"标题+句号"凑数？有无实质信息？
7. 渲染：任何 &amp; / &gt; 转义残留、单位重复（如 "10 mA mA"）、标签闭合异常。
8. 置信度/溯源：metadata.confidence 是否与明显问题并存（如 confidence>=0.9 但有 P0 级可疑点）。

输出严格 JSON，schema 如下，不要输出任何解释文字、不要 markdown 代码围栏：
{
  "verdict": "PASS|WARN|FAIL",
  "findings": [
    {
      "kind": "<snake_case，尽量复用: identity_board_unresolved | board_package_mismatch | pin_mismatch | pin_pair_broken | electrical_condition_leak | unit_dimension | i18n_english_residue | hero_overview_duplicate | double_escape_multi | escape_entity_in_json | features_boilerplate | faq_boilerplate | package_mismatch | identity_unverified | mpn_rewritten>",
      "severity": "P0|P1|P2",
      "message": "<一句话，≤60 字，说明问题而不是重复规则>",
      "evidence": {"field": "<json 路径>", "quote": "<产物里的原文片段，≤120 字>", "page_hint": null}
    }
  ],
  "notes": "<≤200 字；无法判定但值得人工复核的点>"
}
找不到问题时 findings 输出空数组、verdict 输出 PASS。禁止把"值可能错"当 finding，除非能引用产物原文。
severity 只能用 P1 / P2：P0（发布阻断）由确定性规则层与已核验证据卡判定，你无权给出。
没有引用产物原文（evidence.quote 为空）的 finding 会被降级为「参考」，不参与最终判定。
身份/封装/转义/多语统计这类结构性结论由规则层独占判定，你只须给出语义可疑点。"""


def _trim_snapshot(snap: dict, with_pdf_text: bool) -> dict:
    """给 LLM 的产物切片，控 token。"""
    j = snap.get("json") or {}
    specs = j.get("specs") or {}
    ml = j.get("multi_language") or {}
    alts_file = snap.get("alts") or {}
    body: dict[str, Any] = {
        "mpn": snap["mpn"],
        "basic_info": j.get("basic_info"),
        "specs.package": specs.get("package"),
        "specs.electrical": (specs.get("electrical") or [])[:30],
        "specs.absolute_max": (specs.get("absolute_max") or [])[:10],
        "pin_configuration": (j.get("pin_configuration") or [])[:20],
        "features": (j.get("features") or [])[:6],
        "applications": (j.get("applications") or [])[:4],
        "alternatives_in_json": (j.get("alternatives") or [])[:5],
        "catalog_alternatives_count":
            len(alts_file.get("alternatives") or [])
            if isinstance(alts_file, dict) else 0,
        "multi_language": {
            lang: {"title": str((ml.get(lang) or {}).get("title") or "")[:120],
                   "description": str((ml.get(lang) or {}).get("description") or "")[:600]}
            for lang in LANGS if isinstance(ml.get(lang), dict)
        },
        "metadata": {k: (j.get("metadata") or {}).get(k)
                     for k in ("pdf_hash", "parse_timestamp", "model_version",
                               "confidence", "requested_mpn")},
    }
    if with_pdf_text and snap.get("pdf_text"):
        body["pdf_text_excerpt"] = snap["pdf_text"][:4000]
    return body


def _chat(messages: list[dict], cfg: dict, timeout: int = 120) -> dict:
    """调百炼 OpenAI 兼容接口；400 时逐个去掉网关不认识的参数重发。"""
    payload: dict[str, Any] = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": 0.1,
        "max_tokens": cfg["max_tokens"],
        "response_format": {"type": "json_object"},
    }
    if not cfg["enable_thinking"]:
        payload["enable_thinking"] = False
    url = cfg["base"].rstrip("/") + "/chat/completions"
    headers = {"Authorization": "Bearer " + cfg["key"],
               "Content-Type": "application/json"}
    r = None
    for drop in (None, "response_format", "enable_thinking"):
        if drop:
            payload.pop(drop, None)
        r = requests.post(url, headers=headers, json=payload, timeout=timeout)
        if r.status_code != 400:
            break
    if r is None or r.status_code != 200:
        code = r.status_code if r is not None else 0
        detail = (r.text[:200] if r is not None else "")
        raise ReviewError("LLM_CALL_FAILED",
                          f"百炼调用失败 HTTP {code}: {detail}", 502)
    data = r.json()
    content = ((data.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    return {"content": content, "usage": data.get("usage") or {}}


def _parse_json_lenient(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
    return {"verdict": "WARN", "findings": [], "notes": "LLM 输出非 JSON，已忽略正文；需人工复核",
            "_parse_failed": True}


# 这些类型由规则层（确定性 + 证据链）独占判定，LLM 的同类结论一律降级为 P2 参考：
# 实测 qwen-flash 会把 BUF634PG4（PDIP-8 芯片）判成评估板（P0），
# 也会在纯德文段落里「编出」双层转义（P2）。若让这类结论参与 verdict，
# 一件合格产物会因为幻觉被标成 FAIL，进而污染「已 review 并已修复」的统计。
_RULE_OWNED_KINDS = {
    "identity_board_unresolved", "board_package_mismatch",
    "board_confirmed_unmarked", "identity_conflict", "identity_review",
    "identity_evidence_incomplete", "pin_count_mismatch",
    "escape_entity_in_json", "double_escape_multi", "mixed_escape",
    "i18n_body_untranslated", "alts_json_has_miss", "alts_no_internal_link",
    "seo_shared_icon_unmarked", "sentinel_leaked_to_copy", "unit_duplicated",
    "electrical_field_missing", "electrical_like_feature",
    "hero_overview_duplicate", "mpn_rewritten", "pin_pair_broken",
    "pin_polarity_missing",
    # 值级判定（单位/封装是否"应该"是别的值）必须由原厂 PDF + 证据卡裁定，
    # LLM 只能提示「像是有问题」，不能据此阻断发布。
    "unit_dimension", "package_mismatch", "identity_unverified",
}

# LLM 产出的 finding 最高只到 P1：P0（发布阻断）只能来自确定性规则或已核验证据卡，
# 否则一次模型幻觉就能把合格型号标成 FAIL，污染「已 review 并已修复」统计。
_LLM_MAX_SEV = "P1"


def _artifact_corpus(snap: dict) -> str:
    """证据核对语料：JSON 原文 + 英文页 + 各语种页（压缩空白后做子串匹配）。"""
    parts = [json.dumps(snap.get("json") or {}, ensure_ascii=False),
             snap.get("txt_en") or ""]
    parts += [t for t in (snap.get("lang_txt") or {}).values() if t]
    return re.sub(r"\s+", " ", " ".join(parts))


def _sanitize_llm_findings(findings, corpus: str = "") -> list[dict]:
    """LLM finding 规范化 + 两道证据闸（见 _RULE_OWNED_KINDS 注释）。"""
    norm_corpus = re.sub(r"\s+", " ", corpus or "")
    out = []
    for f in (findings or [])[:20]:
        if not isinstance(f, dict):
            continue
        kind = re.sub(r"[^a-z0-9_]", "_",
                      str(f.get("kind") or "").strip().lower())[:60] or "llm_finding"
        sev = str(f.get("severity") or "").strip().upper()
        if sev not in ("P0", "P1", "P2"):
            sev = "P2"
        msg = str(f.get("message") or "").strip()[:120]
        ev = f.get("evidence")
        ev = ev if isinstance(ev, dict) else {}
        quote = str(ev.get("quote") or "")[:200]
        flags = {}
        advisory = False
        if sev == "P0":
            sev = _LLM_MAX_SEV                       # P0 只由规则层/证据卡产生
            flags["severity_capped"] = True
        qn = re.sub(r"\s+", " ", quote).strip()
        if kind in _RULE_OWNED_KINDS:
            # 规则层没报 = 证据链没证实；只作参考，不参与 verdict
            flags["rule_owned"] = True
            advisory = True
            sev = "P2"
            msg = (msg + "（该类型由规则层判定，LLM 结论仅供参考）")[:160]
        elif sev in ("P0", "P1") and not qn:
            flags["quote_missing"] = True
            advisory = True
            sev = "P2"
        elif qn and norm_corpus and qn not in norm_corpus:
            flags["quote_not_in_artifact"] = True
            advisory = True
            sev = "P2"
        out.append({
            "kind": kind, "severity": sev,
            "message": msg or "（LLM 未给出说明）",
            "evidence": {"field": str(ev.get("field") or "")[:120],
                         "quote": quote,
                         "page_hint": None},          # 硬性：LLM 没看 PDF，不能给页码
            "advisory": advisory,                      # 降级项不参与 verdict
            "flags": sorted(flags),
        })
    return out


def _llm_review(snap: dict, cfg: dict, with_pdf_text: bool) -> dict:
    body = _trim_snapshot(snap, with_pdf_text)
    messages = [
        {"role": "system", "content": RULES_TEXT},
        {"role": "user", "content":
            "产物快照（JSON）：\n" + json.dumps(body, ensure_ascii=False)
            + "\n\n请按 schema 输出审查结果 JSON。"},
    ]
    t0 = time.time()
    out = _chat(messages, cfg)
    parsed = _parse_json_lenient(out["content"])
    verdict = str(parsed.get("verdict") or "").strip().upper()
    return {
        "findings": _sanitize_llm_findings(parsed.get("findings"),
                                           _artifact_corpus(snap)),
        "notes": str(parsed.get("notes") or "")[:600],
        "llm_verdict": verdict if verdict in ("PASS", "WARN", "FAIL") else "",
        "usage": out.get("usage") or {},
        "wall_s": round(time.time() - t0, 2),
        "model": cfg["model"],
        "parse_failed": bool(parsed.get("_parse_failed")),
    }


def _merge_verdict(rule_findings: list[dict], llm_findings: list[dict]) -> str:
    """合并判定：advisory（被证据闸降级的 LLM 结论）不参与，只作展示。"""
    sev = {f.get("severity") for f in list(rule_findings)
           if isinstance(f, dict)}
    sev |= {f.get("severity") for f in list(llm_findings)
            if isinstance(f, dict) and not f.get("advisory")}
    if "P0" in sev:
        return "FAIL"
    if "P1" in sev or "P2" in sev:
        return "WARN"
    return "PASS"


# ---------------------------------------------------------------- 报告渲染

def _findings_md(rows: list[dict]) -> list[str]:
    lines = []
    for f in rows or []:
        adv = ""
        if f.get("advisory"):
            adv = " ·（参考，未参与判定：%s）" % ", ".join(f.get("flags") or [])
        lines.append(f"- **[{f.get('severity', '?')}] {f.get('kind', '')}** — "
                     f"{f.get('message', '')}{adv}")
        ev = f.get("evidence") or {}
        if isinstance(ev, dict) and ev:
            q = ev.get("quote") or ev.get("sample") or ""
            fld = ev.get("field") or ""
            if q or fld:
                lines.append(f"  - 证据: `{str(fld)[:80]}{' · ' if fld and q else ''}"
                             f"{str(q)[:120]}`")
    return lines


def render_md(result: dict) -> str:
    r = result
    model_desc = (f"{r.get('model') or 'N/A'}"
                  f"（wall {r.get('wall_s', 0)}s，"
                  f"tokens {(r.get('usage') or {}).get('total_tokens', '-')}）")
    if r.get("dry_run"):
        model_desc = "规则层 only（未调模型）"
    lines = [
        f"# {r.get('mpn')} · 交付物 review — {r.get('verdict')}", "",
        f"- 生成: {r.get('generated_at')}",
        f"- 模型: {model_desc}",
        f"- 规则层 findings: {len(r.get('rule_findings') or [])}"
        f" · LLM findings: {len(r.get('llm_findings') or [])}",
        f"- 审查版本: {r.get('review_version')} · 规则: {r.get('rule_version')}",
        "",
    ]
    for tag, arr in (("规则层（确定性检查）", r.get("rule_findings") or []),
                     ("LLM（语义可疑点）", r.get("llm_findings") or [])):
        if not arr:
            continue
        lines.append(f"## {tag}")
        lines += _findings_md(arr)
        lines.append("")
    if r.get("notes"):
        lines += ["## 备注（无法判定、值得人工复核）", str(r["notes"]), ""]
    paths = r.get("paths") or {}
    if paths:
        lines.append("## 审计对象")
        for k, v in paths.items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
    lines += ["## 边界声明"]
    for c in CAVEATS:
        lines.append(f"- {c}")
    lines.append("")
    return "\n".join(lines)


def _esc(v) -> str:
    return html.escape(str(v if v is not None else ""))


def _html_findings(rows: list[dict], empty_text: str) -> str:
    if not rows:
        return f'<p class="empty">{_esc(empty_text)}</p>'
    h = ['<table><thead><tr><th style="width:56px">级别</th>'
         '<th style="width:210px">类型</th><th>问题</th>'
         '<th style="width:36%">证据</th></tr></thead><tbody>']
    for f in rows:
        ev = f.get("evidence") or {}
        quote = str(ev.get("quote") or "") if isinstance(ev, dict) else ""
        field = str(ev.get("field") or "") if isinstance(ev, dict) else ""
        adv = ""
        if f.get("advisory"):
            adv = ('<div class="adv">参考 · 未参与判定（%s）</div>'
                   % _esc(", ".join(f.get("flags") or [])))
        h.append(
            f'<tr><td><span class="sev {_esc(f.get("severity"))}">'
            f'{_esc(f.get("severity"))}</span></td>'
            f'<td class="mono">{_esc(f.get("kind"))}</td>'
            f'<td>{_esc(f.get("message"))}{adv}</td>'
            f'<td class="quote">{_esc(field)}{" · " if field and quote else ""}'
            f'{_esc(quote[:200])}</td></tr>')
    h.append("</tbody></table>")
    return "".join(h)


def render_html(result: dict) -> str:
    """自包含 HTML 预览页（无外部依赖，可直接 iframe / 新窗口打开 / 打印）。"""
    r = result
    v = str(r.get("verdict") or "WARN")
    usage = r.get("usage") or {}
    model_desc = (f"{_esc(r.get('model') or '—')} · "
                  f"{_esc(r.get('wall_s', 0))}s · "
                  f"{_esc(usage.get('total_tokens', '—'))} tokens")
    if r.get("dry_run"):
        model_desc = "规则层 only（未调模型）"
    item = r.get("item") or {}
    chips = [
        ("结论", v, "FAIL→P0 命中；WARN→P1/P2 命中；PASS→无 finding"),
        ("规则层 findings", len(r.get("rule_findings") or []), "确定性检查，不花 token"),
        ("LLM findings", len(r.get("llm_findings") or []), "语义可疑点，不判数值正确性"),
        ("模型", model_desc, ""),
        ("批次 / item", f"{_esc(item.get('batch_id') or '—')} · #{_esc(item.get('id') or '—')}",
         f"status={_esc(item.get('status') or '—')}"),
    ]
    chips_html = "".join(
        f'<div class="chip"><span>{_esc(k)}</span><b>{v2}</b>'
        f'<small>{_esc(s)}</small></div>' for k, v2, s in chips)
    paths = r.get("paths") or {}
    paths_html = "".join(
        f'<div class="mono">{_esc(k)}: {_esc(v)}</div>' for k, v in paths.items()
    ) or '<p class="empty">—</p>'
    caveats_html = "".join(f"<li>{_esc(c)}</li>" for c in CAVEATS)
    notes = str(r.get("notes") or "").strip()
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_esc(r.get('mpn'))} · 交付物 review {_esc(v)}</title>
<style>
:root{{--ink:#1e293b;--sub:#64748b;--line:#e2e8f0;--bg:#f8fafc}}
*{{box-sizing:border-box}}
body{{margin:0;font:14px/1.65 system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;
  color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1000px;margin:0 auto;padding:26px 20px 48px}}
header.v{{border-radius:12px;padding:20px 24px;color:#fff;margin-bottom:18px}}
.v.FAIL{{background:linear-gradient(135deg,#b91c1c,#ef4444)}}
.v.WARN{{background:linear-gradient(135deg,#b45309,#f59e0b)}}
.v.PASS{{background:linear-gradient(135deg,#15803d,#22c55e)}}
.v h1{{margin:0 0 6px;font-size:20px;word-break:break-all}}
.v .meta{{opacity:.92;font-size:12.5px}}
.chips{{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:18px}}
.chip{{background:#fff;border:1px solid var(--line);border-radius:10px;
  padding:10px 16px;min-width:150px;flex:1}}
.chip span{{color:var(--sub);font-size:12px;display:block}}
.chip b{{display:block;font-size:16px;margin:2px 0}}
.chip small{{color:var(--sub);font-size:11.5px}}
section{{background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:16px 20px;margin-bottom:16px}}
section h2{{margin:0 0 10px;font-size:15px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{background:#f1f5f9;text-align:left;padding:7px 10px;
  border-bottom:1px solid var(--line);white-space:nowrap}}
td{{padding:7px 10px;border-bottom:1px solid #f1f5f9;vertical-align:top}}
.sev{{display:inline-block;border-radius:6px;padding:1px 8px;font-size:12px;
  font-weight:700;color:#fff}}
.sev.P0{{background:#dc2626}}.sev.P1{{background:#d97706}}.sev.P2{{background:#64748b}}
.mono{{font-family:ui-monospace,Consolas,monospace;font-size:12px;color:#334155;
  word-break:break-all}}
.quote{{color:#475569;font-size:12px;word-break:break-all}}
.adv{{color:#b45309;font-size:11.5px;margin-top:2px}}
.notes{{white-space:pre-wrap;margin:0}}
.empty{{color:var(--sub);margin:0}}
footer{{color:var(--sub);font-size:12px;line-height:1.8;
  border-top:1px dashed var(--line);padding-top:12px}}
</style></head><body><div class="wrap">
<header class="v {_esc(v)}">
  <h1>{_esc(r.get('mpn'))} · 交付物红线审查 — {_esc(v)}</h1>
  <div class="meta">生成 {_esc(r.get('generated_at'))} · {_esc(model_desc)} ·
    review {_esc(r.get('review_version'))} / 规则 {_esc(r.get('rule_version'))}</div>
</header>
<div class="chips">{chips_html}</div>
<section><h2>规则层 findings（确定性检查，不花 token）</h2>
{_html_findings(r.get('rule_findings') or [], '规则层无 finding。')}</section>
<section><h2>LLM findings（语义可疑点；不判数值正确性，page_hint 恒为 null）</h2>
{_html_findings(r.get('llm_findings') or [], 'LLM 无 finding。')}</section>
<section><h2>备注（无法判定、值得人工复核）</h2>
<p class="notes">{_esc(notes) if notes else '（无）'}</p></section>
<section><h2>审计对象（只读）</h2>{paths_html}</section>
<footer><b>边界声明</b><ul>{caveats_html}</ul></footer>
</div></body></html>"""


# ---------------------------------------------------------------- 落盘 / 台账

def report_paths(out_dir: Path, safe: str) -> dict:
    out_dir = Path(out_dir)
    return {
        "json": out_dir / f"{safe}.review.json",
        "md": out_dir / f"{safe}.review.md",
        "html": out_dir / f"{safe}.review.html",
    }


def _write_reports(safe: str, result: dict, out_dir: Path) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = report_paths(out_dir, safe)
    p["json"].write_text(json.dumps(result, ensure_ascii=False, indent=2),
                         encoding="utf-8")
    p["md"].write_text(render_md(result), encoding="utf-8")
    p["html"].write_text(render_html(result), encoding="utf-8")


def get_report(out_dir: Path, safe: str) -> dict | None:
    if not _valid_safe(safe):
        return None
    p = report_paths(Path(out_dir), safe)["json"]
    if not p.is_file():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return d if isinstance(d, dict) else None


def list_reports(out_dir: Path, limit: int = 200) -> list[dict]:
    out_dir = Path(out_dir)
    if not out_dir.is_dir():
        return []
    items = []
    for p in out_dir.glob("*.review.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(d, dict):
            continue
        items.append({
            "mpn": d.get("mpn") or "",
            "safe_key": d.get("safe_key") or p.name[:-len(".review.json")],
            "verdict": d.get("verdict") or "",
            "generated_at": d.get("generated_at") or "",
            "rule_findings": len(d.get("rule_findings") or []),
            "llm_findings": len(d.get("llm_findings") or []),
            "model": d.get("model") or "",
            "dry_run": bool(d.get("dry_run")),
            "_mtime": p.stat().st_mtime,
        })
    items.sort(key=lambda x: x.pop("_mtime"), reverse=True)
    return items[:limit]


def _record_usage(db, snap: dict, llm: dict, cfg: dict) -> None:
    """模型调用记账（llm_usage，append-only）：不记账就没法谈成本。"""
    u = llm.get("usage") or {}
    prompt = int(u.get("prompt_tokens") or u.get("input_tokens") or 0)
    completion = int(u.get("completion_tokens") or u.get("output_tokens") or 0)
    total = int(u.get("total_tokens") or (prompt + completion))
    try:
        from urllib.parse import urlsplit
        provider = urlsplit(cfg["base"] or "").netloc.lower() or "unknown"
    except ValueError:
        provider = "unknown"
    db.x("INSERT INTO llm_usage (item_id,mpn_key,stage,provider,model,prompt_tokens,"
         "completion_tokens,total_tokens,latency_ms,attempt,ok,error,created_at) "
         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
         (snap.get("item", {}).get("id"), str(snap.get("mpn_key") or "")[:120],
          "review", provider[:80], str(llm.get("model") or "")[:80],
          prompt, completion, total, int(float(llm.get("wall_s") or 0) * 1000),
          1, 1, "", _now_qc()))


def _audit_append(db, mpn: str, result: dict, operator: str, out_dir: Path) -> None:
    """qc_run（汇总行）+ qc_audit_log（append-only），绝不 UPDATE/DELETE 业务表。"""
    md_path = report_paths(Path(out_dir), _safe_stem(mpn))["md"]
    n_all = len(result.get("rule_findings") or []) + len(result.get("llm_findings") or [])
    run_id = db.x(
        "INSERT INTO qc_run(mode,scope,dry,parts,parts_done,findings,patched,"
        "unresolved,duration_s,status,operator,report_path,created_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ("review", "review", 1, 1, 1, n_all, 0, 0,
         float(result.get("wall_s") or 0), "ok", operator or "auto",
         str(md_path), _now_qc()))
    db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,"
         "tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
         (run_id, mpn, "llm_review", str(md_path),
          json.dumps({"verdict": result.get("verdict"),
                      "rule_findings": len(result.get("rule_findings") or []),
                      "llm_findings": len(result.get("llm_findings") or []),
                      "model": result.get("model"),
                      "review_version": result.get("review_version"),
                      "safe_key": result.get("safe_key")},
                     ensure_ascii=False),
          "-", "reviewed", "review.py", operator or "auto", _now_qc()))


# ---------------------------------------------------------------- 单件入口

def run_review(db, mpn: str, *, data_dir, out_dir, with_pdf_text: bool = False,
               dry_run: bool = False, write_db: bool = False,
               operator: str = "auto", force: bool = False,
               cfg: dict | None = None) -> dict:
    """审查单型号交付物并落报告。

    * dry_run=True：只跑规则层，不调模型、不落报告文件、不写台账（且不吃缓存）；
    * 已存在报告且非 force 时直接返回缓存（dry_run 的旧结果会被完整审查覆盖）；
    * write_db=True：append qc_run/qc_audit_log 并记 llm_usage（完整审查时）。
    """
    mpn = str(mpn or "").strip()
    if not mpn:
        raise ReviewError("MPN_EMPTY", "mpn 不能为空")
    row = find_item(db, mpn)
    if not row:
        raise ReviewError("ITEM_NOT_FOUND", f"型号不存在：{mpn}", 404)

    safe = _safe_stem(mpn)
    existing = get_report(Path(out_dir), safe)
    # dry_run 必须真跑：它的语义是「看规则层此刻怎么判」，若命中旧的完整报告缓存，
    # 会把改规则之前的结论原样返回（实测让 mixed_escape 假阳性在修好后仍复现）。
    if existing and not force and not dry_run and not existing.get("dry_run"):
        existing["cached"] = True
        return existing

    snap = _load_snapshot(row, Path(data_dir))
    if not snap.get("json"):
        raise ReviewError("ARTIFACTS_MISSING",
                          "该型号没有可审查的解析产物（json 缺失或未解析）", 404)

    if with_pdf_text and snap.get("pdf_path") and Path(snap["pdf_path"]).is_file():
        snap["pdf_text"] = _pdf_excerpt(snap["pdf_path"])

    rule_findings = _rule_checks(snap)
    llm = {"findings": [], "notes": "", "llm_verdict": "", "usage": {},
           "wall_s": 0, "model": "rule-only", "parse_failed": False}
    if not dry_run:
        cfg = cfg or env_config()
        if not cfg.get("key"):
            raise ReviewError("LLM_KEY_MISSING",
                              "DASHSCOPE_API_KEY 未设置；可用 dry_run 只跑规则层")
        llm = _llm_review(snap, cfg, with_pdf_text)
        if db is not None:
            try:
                _record_usage(db, snap, llm, cfg)
            except Exception:                                   # noqa: BLE001
                pass                                            # 记账失败不阻断审查

    verdict = _merge_verdict(rule_findings, llm["findings"])
    result = {
        "review_version": REVIEW_VERSION,
        "rule_version": RULE_VERSION,
        "mpn": mpn,
        "mpn_key": row.get("mpn_key") or "",
        "safe_key": safe,
        "generated_at": _now_iso(),
        "verdict": verdict,
        "dry_run": bool(dry_run),
        "rule_findings": rule_findings,
        "llm_findings": llm["findings"],
        "llm_verdict": llm.get("llm_verdict") or "",
        "notes": llm.get("notes") or "",
        "model": llm.get("model") or "",
        "usage": llm.get("usage") or {},
        "wall_s": llm.get("wall_s") or 0,
        "paths": snap.get("paths") or {},
        "item": snap.get("item") or {},
        "caveats": CAVEATS,
    }
    if not dry_run:
        _write_reports(safe, result, Path(out_dir))
        if write_db and db is not None:
            _audit_append(db, mpn, result, operator, Path(out_dir))
    return result
