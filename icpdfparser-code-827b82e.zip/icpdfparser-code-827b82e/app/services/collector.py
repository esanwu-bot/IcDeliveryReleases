"""多平台 Datasheet 链接采集 + 下载。

采集分层（按成本从低到高，命中即停）：
  1. manual    工作台上人工补的链接（最高优先，可覆盖自动结果）
  2. sheet     客户型号表里自带的链接（若上传的表里有 PDF/URL 列）
  3. cached    该型号上一次成功下载的链接（增量重跑零成本）
  4. vendor    原厂规则直拼（14 家原厂 URL 规则库），先 HEAD/Range 探活再下载
  5. aggregator 聚合站搜索（alldatasheet / datasheetspdf），默认关闭：
               Cloudflare 对脚本返回 403，需要代理环境时用 ICPDF_AGGREGATOR=1 打开

每次尝试（成功或失败）都写入 doc_source 表，型号详情页可以看到完整采集轨迹。
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Iterable
from urllib.parse import urlsplit

import requests
import urllib3

from pipeline import fetcher, resolver

from .. import config, db
from .parts import safe_name

urllib3.disable_warnings()

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

# ---------------------------------------------------------------- 原厂规则库
# 值：URL 模板列表，{s} 为料号主干（含后缀裁剪变体）
VENDOR_RULES: dict[str, list[str]] = {
    "ti": ["https://www.ti.com/lit/ds/symlink/{s}.pdf",
           "https://www.ti.com/lit/gpn/{s}"],
    "st": ["https://www.st.com/resource/en/datasheet/{s}.pdf"],
    "microchip": ["https://ww1.microchip.com/downloads/en/DeviceDoc/{s}.pdf",
                  "https://ww1.microchip.com/downloads/en/DeviceDoc/{s}-Data-Sheet.pdf"],
    "adi": ["https://www.analog.com/media/en/technical-documentation/data-sheets/{s}.pdf"],
    "onsemi": ["https://www.onsemi.com/pdf/datasheet/{s}-d.pdf",
               "https://www.onsemi.com/pub/Collateral/{s}-D.PDF"],
    "nxp": ["https://www.nxp.com/docs/en/data-sheet/{s}.pdf"],
    "diodes": ["https://www.diodes.com/assets/Datasheets/{s}.pdf"],
    "silabs": ["https://www.silabs.com/documents/public/data-sheets/{s}.pdf"],
    "espressif": ["https://www.espressif.com/sites/default/files/documentation/{s}_datasheet_en.pdf"],
    "renesas": ["https://www.renesas.com/us/en/document/dst/{s}-datasheet"],
}

BRAND_RULES: list[tuple[tuple[str, ...], str]] = [
    (("texas", "ti ", "^ti$", "德州仪器"), "ti"),
    (("st micro", "stmicro", "意法"), "st"),
    (("microchip", "atmel", "微芯"), "microchip"),
    (("analog devices", "linear tech", "maxim", "adi", "亚德诺"), "adi"),
    (("onsemi", "on semi", "fairchild", "安森美"), "onsemi"),
    (("nxp", "freescale", "恩智浦"), "nxp"),
    (("diodes", "达尔"), "diodes"),
    (("silicon lab", "silabs"), "silabs"),
    (("espressif", "乐鑫"), "espressif"),
    (("renesas", "nec electronics", "瑞萨"), "renesas"),
]

AGGREGATORS = [
    ("alldatasheet", "https://www.alldatasheet.com/view.jsp?Searchword={s}"),
    ("datasheetspdf", "https://datasheetspdf.com/search/{s}"),
]
AGG_PDF_RE = re.compile(r"https?://[^\"'\s]+\.pdf", re.I)


def vendor_of(brand: str) -> str:
    b = (brand or "").strip().lower()
    if not b:
        return ""
    for keys, vendor in BRAND_RULES:
        for k in keys:
            k = k.strip()
            if k.startswith("^"):
                if re.fullmatch(k.strip("^$"), b):
                    return vendor
            elif k in b:
                return vendor
    return ""


def _stems(mpn: str) -> list[str]:
    """料号主干变体：原样 + 逐层剥掉包装/等级后缀。"""
    base = re.sub(r"[^A-Za-z0-9\-]", "", mpn or "").lower()
    if not base:
        return []
    out: list[str] = [base]
    cur = base
    # 6 层而不是 3 层：横杠料号剥掉封装后缀后常常还要再退一两步。
    for _ in range(6):
        trimmed = re.sub(r"(?:[a-z]{1,3}\d{0,3}|r2|reel|tr|ct|t&r)$", "", cur)
        if trimmed == cur or len(trimmed) < 4:
            break
        out.append(trimmed)
        cur = trimmed
    # 订货后缀常以「字母 + 4 位以上数字」开头（LMK6C|E10800DDLFT、CSD25211|W1015），
    # 从那里切一刀才是真正的家族 slug；逐层剥后缀剥不到（lmk6ce10800 削不动）。
    # 放最后：家族名比具体型号泛，只在前面几步都没命中时才该轮到它。
    m = [x for x in re.finditer(r"[a-z]\d{4,}", base) if x.start() >= 3]
    if m:
        out.append(base[:m[-1].start()])
    # 带「-封装/温度等级」的料号（ads1201u-1_1k、pic16f877a-i/p）：横杠前通常是家族主干。
    # 插在全料号之后、逐层裁剪之前，且不再往下削 —— pic16f877a 再削一步就是另一个家族。
    cut = base.split("-", 1)[0]
    if cut != base and len(cut) >= 4:
        out.insert(1, cut)
    # 去掉「boostxl-」这种把尾字母整段削掉的残骸，它们 100% 探活失败，纯浪费请求。
    # 保持顺序：全料号优先（有些原厂按 ordering code 命名），再逐层退到家族主干。
    return list(dict.fromkeys(s for s in out if len(s) >= 4 and not s.endswith("-")))


def vendor_candidates(mpn: str, brand: str) -> list[tuple[str, str]]:
    vendor = vendor_of(brand)
    rules = VENDOR_RULES.get(vendor, [])
    if not rules:
        return []
    out = []
    for stem in _stems(mpn):
        for tpl in rules:
            out.append((f"vendor:{vendor}", tpl.format(s=stem)))
    return out


def aggregator_candidates(mpn: str) -> list[tuple[str, str]]:
    if not config.AGGREGATOR_ENABLED:
        return []
    return [(f"agg:{name}", tpl.format(s=mpn)) for name, tpl in AGGREGATORS]


# ---------------------------------------------------------------- 采集轨迹
def _record(mpn_key: str, provider: str, stage: str, url: str, *, ok: bool,
            http_status: int = 0, size: int = 0, sha: str = "", error: str = "") -> None:
    try:
        db.x(
            "INSERT INTO doc_source (mpn_key,provider,stage,url,ok,http_status,bytes,sha256,error,tried_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(mpn_key,url) DO UPDATE SET ok=excluded.ok, provider=excluded.provider, "
            "stage=excluded.stage, http_status=excluded.http_status, bytes=excluded.bytes, "
            "sha256=excluded.sha256, error=excluded.error, tried_at=excluded.tried_at",
            (mpn_key, provider, stage, url[:900], 1 if ok else 0, http_status, size, sha,
             error[:300], db.now()))
    except Exception:                                            # noqa: BLE001
        # 采集轨迹是旁路记录：写不进去也不能把这次下载判失败。
        pass


def sources(mpn_key: str) -> list[dict]:
    return db.q("SELECT provider,stage,url,ok,http_status,bytes,sha256,error,tried_at "
                "FROM doc_source WHERE mpn_key=? ORDER BY ok DESC, id DESC", (mpn_key,))


# ---------------------------------------------------------------- 聚合站解析
def _aggregator_pdf(url: str, deadline: float | None = None) -> str:
    """从聚合站搜索结果页里捞 PDF 直链（拿不到就返回空，不抛异常）。"""
    timeout: float = 12.0
    if deadline is not None:
        remain = deadline - time.monotonic()
        if remain <= 1.0:
            return ""
        timeout = min(timeout, remain)
    try:
        r = requests.get(url, timeout=timeout, verify=False,
                         headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
        if r.status_code != 200:
            return ""
        for m in AGG_PDF_RE.finditer(r.text):
            link = m.group(0).rstrip(").,")
            if "datasheet" in link.lower() or "pdf" in link.lower():
                return link
    except requests.RequestException:
        return ""
    return ""


# ---------------------------------------------------------------- 主流程
DOC_PATH = re.compile(r"/lit/(ug|an|wp|ml)/", re.I)   # 用户指南/应用笔记，不是 datasheet


_NET_HINTS = ("timeout", "timed out", "connection", "ssl", "proxy", "reset", "eof",
              "chunked", "protocol", "remote disconnected", "getaddrinfo",
              "name or service not known", "handshake")


def _transient_error(err: str) -> bool:
    """网络层失败（超时/断连/TLS/5xx）不能判成「没有资料」，只能算暂时性失败。

    403 也算暂时性：机房 IP 被反爬拦截（TI 的 Akamai）时链接本身是好的，
    换镜像/换出口后能恢复，不能写成终态 nodata。
    """
    e = (err or "").lower()
    if "not a pdf" in e or "not pdf" in e or "too small" in e:
        return False
    m = re.search(r"http (\d{3})", e)
    if m:
        return int(m.group(1)) >= 500 or int(m.group(1)) in (403, 408, 429)
    return any(h in e for h in _NET_HINTS)


def _probe_fast(url: str, connect: float = 4.0, read: float = 10.0,
                deadline: float | None = None) -> tuple[bool, str, int]:
    """比 fetcher.probe 更短的超时。

    一个型号失败后要试 4~8 个候选，每个 8+20 秒的话，光探活就能耗掉三四分钟，
    BQ/DRV 这类冷门 EVM 会把 6 个并发槽位全占死（实测单型号 325~348 秒）。

    返回值带 HTTP 状态码：失败时只留 URL 会把 403 和 404 混成同一类，
    下游无法判断「被封」还是「确实没有」。
    """
    if deadline is not None:
        remain = deadline - time.monotonic()
        if remain <= 1.0:
            return False, "Timeout: fetch deadline exceeded", 0
        connect, read = min(connect, remain), min(read, remain)
    try:
        with fetcher.host_slot(urlsplit(url).netloc.lower()):
            r = fetcher.session().head(url, timeout=(connect, read), allow_redirects=True,
                                       verify=False)
            ctype = r.headers.get("Content-Type", "")
            if r.status_code in (200, 206) and "pdf" in ctype.lower():
                return True, r.url, r.status_code
            if r.status_code in (404, 410):
                # 明确不存在，没必要再发一次 Range GET（403 不能短路：有的站点禁 HEAD 但放行 GET）
                return False, f"HTTP {r.status_code} {ctype}", r.status_code
            r = fetcher.session().get(url, timeout=(connect, read), allow_redirects=True,
                                      verify=False, headers={"Range": "bytes=0-4"}, stream=True)
            ok = r.status_code in (200, 206) and r.raw.read(5).startswith(b"%PDF")
            final, status = r.url, r.status_code
            r.close()
            return ok, (final if ok else f"HTTP {status} {ctype}"), status
    except Exception as e:                                       # noqa: BLE001
        return False, f"{type(e).__name__}: {e}", 0


def fetch_datasheet(mpn: str, mpn_key: str, brand: str = "", sheet_url: str = "",
                    cached_url: str = "", manual_url: str = "",
                    *, probe_redirect: bool = True,
                    budget: float | None = None) -> dict:
    """按优先级采集并下载。返回 {ok, path, url, sha256, bytes, provider, tried, transient}。

    budget 是单型号采集总预算（秒，默认 ICPDF_FETCH_BUDGET=90），会硬性压到每次请求上。
    transient=True 表示失败是网络层原因（超时/断连/TLS/5xx），不能判成 nodata，
    应由调用方标成可重试的 failed。命令行链路不受影响（默认值足够宽松）。
    """
    if budget is None:
        try:
            budget = float(os.getenv("ICPDF_FETCH_BUDGET", "90"))
        except ValueError:
            budget = 90.0
    deadline = time.monotonic() + budget

    chain: list[tuple[str, str]] = []
    if manual_url:
        chain.append(("manual", manual_url.strip()))
    if sheet_url and sheet_url.lower().startswith("http"):
        if DOC_PATH.search(urlsplit(sheet_url).path):
            # 表里给的是 User Guide / App Note，下载了也不是 datasheet，直接不占时间
            _record(mpn_key, "sheet", "skip_doc", sheet_url, ok=False,
                    error="table link is user-guide/app-note, not a datasheet")
        else:
            chain.append(("sheet", sheet_url.strip()))
            # 表内链接如果是 TI 网关/ROCE 查看页，先按规则换成文件本体
            for stage, u in resolver.candidates(sheet_url):
                chain.append((f"sheet:{stage}", u))
    if cached_url:
        chain.append(("cached", cached_url.strip()))

    # _stems 已按「全料号优先、逐层退到家族主干」排序；最多 6 个 stem × 2 模板 = 12 个候选。
    # 裁到 8 会把第 4 个 stem（lmk6c 这类家族名）丢掉，失败件多探 4 次换回整族命中是划算的。
    vendor_chain = vendor_candidates(mpn, brand)[:12]
    agg_chain = aggregator_candidates(mpn)

    tried: list[dict] = []
    dest_dir = config.PDFS
    dest_dir.mkdir(parents=True, exist_ok=True)

    def out_of_time() -> bool:
        return time.monotonic() > deadline

    def attempt(provider: str, stage: str, url: str, *, need_probe: bool) -> dict | None:
        if out_of_time():
            return None
        url = fetcher.rewrite_url(url)
        if need_probe:
            ok, final, status = _probe_fast(url, deadline=deadline)
            if not ok:
                err = f"probe failed: {final}"
                _record(mpn_key, provider, stage, url, ok=False, http_status=status, error=err)
                tried.append({"provider": provider, "url": url, "ok": False,
                              "error": err, "transient": _transient_error(err)})
                return None
        else:
            final = url
        name = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(final.split("?")[0]).name or "datasheet.pdf")
        if not name.lower().endswith(".pdf"):
            name += ".pdf"
        dest = dest_dir / f"{safe_name(mpn)}__{name}"[:180]
        try:
            info = fetcher.fetch_pdf(url, dest, retries=2 if stage == "direct" else 1,
                                     deadline=deadline)
        except fetcher.NotPdf as e:
            _record(mpn_key, provider, stage, url, ok=False, error=f"NOT_PDF {e}")
            tried.append({"provider": provider, "url": url, "ok": False,
                          "error": "not pdf", "transient": False})
            return None
        except Exception as e:                                   # noqa: BLE001
            err = f"{type(e).__name__}: {e}"
            m = re.search(r"HTTP (\d{3})", err)
            _record(mpn_key, provider, stage, url, ok=False,
                    http_status=int(m.group(1)) if m else 0, error=err)
            tried.append({"provider": provider, "url": url, "ok": False,
                          "error": f"{type(e).__name__}", "transient": _transient_error(err)})
            return None
        _record(mpn_key, provider, stage, url, ok=True, size=info["bytes"],
                sha=info["sha256"], http_status=info.get("http_status", 200))
        tried.append({"provider": provider, "url": url, "ok": True})
        return {"ok": True, "path": str(dest), "url": info["final_url"] or url,
                "sha256": info["sha256"], "bytes": info["bytes"], "provider": provider,
                "tried": tried}

    for provider, url in chain:
        if out_of_time():
            break
        if not url.lower().startswith("http"):
            continue
        hit = attempt(provider, "direct", url, need_probe=False)
        if hit:
            return hit

    for provider, url in vendor_chain:
        if out_of_time():
            break
        hit = attempt(provider, "pattern", url, need_probe=probe_redirect)
        if hit:
            return hit

    for provider, url in agg_chain:
        if out_of_time():
            break
        pdf = _aggregator_pdf(url, deadline=deadline)
        if pdf:
            hit = attempt(provider, "search", pdf, need_probe=False)
            if hit:
                return hit
        else:
            _record(mpn_key, provider, "search", url, ok=False, error="no pdf link in SERP")
            tried.append({"provider": provider, "url": url, "ok": False, "error": "no pdf in page"})

    transient = any(t.get("transient") for t in tried) or (not tried and out_of_time())
    return {"ok": False, "path": "", "url": "", "sha256": "", "bytes": 0,
            "provider": "", "tried": tried, "transient": transient}


def batch_vendor_hint(brand: str) -> Iterable[str]:
    v = vendor_of(brand)
    return [v] if v else []
