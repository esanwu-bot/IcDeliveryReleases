"""应用领域图片命名表 -> 图片 SEO 词表。

「按最新上传的文档执行」在这里落地：
  * 上传的 xlsx 覆盖 app_image 表；
  * 同时重写 data/app_images.csv —— json_to_txt.py 的配图挑选就读这张 CSV；
  * 上传后立刻热刷新 json_to_txt.APP_IMAGES，无需重启进程。
"""
from __future__ import annotations

import csv
import re
from pathlib import Path

from .. import config, db

CAT_COL_KEYS = ("application", "category", "应用", "领域", "类别", "分类")
IMG_COL_KEYS = ("image", "filename", "file", "图片", "文件名")


def _pick(header: list[str], keys: tuple[str, ...]) -> int:
    for i, h in enumerate(header):
        hl = (h or "").strip().lower()
        if hl and any(k in hl for k in keys):
            return i
    return -1


def read_name_table(path: Path) -> list[dict]:
    """读 xlsx/xls/csv，返回 [{category, image}]。"""
    suffix = path.suffix.lower()
    table: list[list[str]] = []
    if suffix in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(filename=str(path), read_only=True, data_only=True)
        ws = wb.worksheets[0]
        for row in ws.iter_rows(values_only=True):
            table.append(["" if v is None else str(v).strip() for v in row])
        wb.close()
    elif suffix == ".xls":
        import xlrd
        bk = xlrd.open_workbook(str(path), on_demand=True)
        sh = bk.sheet_by_index(0)
        for r in range(sh.nrows):
            table.append([str(sh.cell_value(r, c)).strip() for c in range(sh.ncols)])
        bk.release_resources()
    else:
        raw = path.read_bytes().decode("utf-8-sig", "replace")
        table = [[c.strip() for c in row] for row in csv.reader(raw.splitlines())]

    if not table:
        return []
    header = table[0]
    ci, ii = _pick(header, CAT_COL_KEYS), _pick(header, IMG_COL_KEYS)
    if ci < 0 or ii < 0:                       # 没表头就按前两列
        ci, ii = 0, 1
        body = table
    else:
        body = table[1:]

    out, seen = [], set()
    for row in body:
        if len(row) <= max(ci, ii):
            continue
        cat, img = row[ci].strip(), row[ii].strip()
        if not cat or not img or cat.lower() in seen:
            continue
        if not re.match(r"^[\w.\- ]+\.(png|jpe?g|webp|svg)$", img, re.I):
            continue
        seen.add(cat.lower())
        out.append({"category": cat, "image": img})
    return out


def _slug_cat(category: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", category.lower()).strip("-")


def alt_text(category: str) -> str:
    return f"{category} application illustration"


def title_text(category: str) -> str:
    return f"{category} electronics application reference"


def keywords(category: str) -> str:
    base = _slug_cat(category).replace("-", " ")
    return ", ".join([category.lower(), base, "application illustration", "electronics"])


def import_table(path: Path, *, batch_id: int | None = None) -> dict:
    rows = read_name_table(path)
    if not rows:
        raise ValueError("未从命名表中读到任何「应用领域 / 图片文件名」行")
    stamp = db.now()
    with db.conn() as c:
        c.execute("DELETE FROM app_image")
        c.executemany(
            "INSERT INTO app_image (category,image,alt_en,alt_zh,title_en,keywords,updated_at) "
            "VALUES (?,?,?,?,?,?,?)",
            [(r["category"], r["image"], alt_text(r["category"]), f"{r['category']} 应用领域配图",
              title_text(r["category"]), keywords(r["category"]), stamp) for r in rows])
        c.commit()

    # json_to_txt.py 读的 CSV 同步刷新
    with open(config.APP_IMG_CSV, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["category", "image"])
        for r in rows:
            w.writerow([r["category"], r["image"]])

    db.kv_set("images_source", str(path))
    db.kv_set("images_imported_at", stamp)
    db.add_event(f"导入应用领域图片命名表：{len(rows)} 类", kind="import", batch_id=batch_id,
                 detail=str(path))
    refresh_renderer()
    return {"categories": len(rows), "source": str(path), "imported_at": stamp}


def refresh_renderer() -> None:
    """热刷新 json_to_txt 的配图表（该模块导入时读一次 CSV）。"""
    try:
        import json_to_txt
        json_to_txt.APP_IMAGES = json_to_txt._load_app_images()
    except Exception:                                        # noqa: BLE001
        pass


def table() -> list[dict]:
    rows = db.q("SELECT category,image,alt_en,title_en,keywords,updated_at FROM app_image "
                "ORDER BY category")
    if rows:
        return rows
    # 表还没导入时，从 CSV 兜底，界面不至于空白
    if config.APP_IMG_CSV.exists():
        with open(config.APP_IMG_CSV, encoding="utf-8-sig") as fh:
            return [{"category": r.get("category", ""), "image": r.get("image", ""),
                     "alt_en": alt_text(r.get("category", "")), "title_en": "",
                     "keywords": "", "updated_at": ""} for r in csv.DictReader(fh)]
    return []


def pick(category_hint: str) -> dict | None:
    """按应用领域文本挑一个类别（长词优先，与 json_to_txt 的打分口径一致）。"""
    rows = table()
    text = (category_hint or "").lower()
    best, best_len = None, 0
    for r in rows:
        cat = r["category"].lower()
        if cat and cat in text and len(cat) > best_len:
            best, best_len = r, len(cat)
    return best
