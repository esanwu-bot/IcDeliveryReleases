"""pandas QC Analyzer：只读批量分析，输出候选任务与统计报表。

边界（与交付包/PRD 一致）：
  * 只读 issues / samples / evidence / regressions 与 auto QC 矩阵/证据卡；
  * 不修改 facts / Gold / item，不自动判定根因，不自动关闭问题；
  * 统计相关性只生成“候选技术环节 / 待补证据 / 定向回归建议”，
    必须由工程人员核对原厂 PDF 后决定修复层；
  * 分析运行本身写入 qc_analysis_run / qc_analysis_task（可追溯，不改业务数据）。

矩阵来源：仓库根 auto_qc_issue_matrix.csv（qc/issue_matrix.py 产物，13,504 件）；
证据卡：evidence_cards.csv；PDF 文本层信号：app/services/pdf_signals.py。
"""
from __future__ import annotations

import csv
import datetime
import hashlib
import io
import json
import re
import uuid
import zipfile
from pathlib import Path

try:                                                            # 允许无 pandas 启动应用
    import pandas as pd
    import numpy as np
except Exception:                                               # noqa: BLE001
    pd = None
    np = None

from .pdf_signals import signals as pdf_signals

MATRIX_VERSION = "auto-qc-issue-matrix-2026-10-28"
RULE_VERSION = "issue-matrix-2026-10-28-v1"
ANALYZER_VERSION = "pandas-qc-analyzer-v1"

DDL = """
-- pandas QC Analyzer：只追加分析快照，不碰业务表
CREATE TABLE IF NOT EXISTS qc_analysis_run (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    run_key        TEXT NOT NULL UNIQUE,
    created_at     TEXT NOT NULL,
    created_by     TEXT NOT NULL,
    source         TEXT NOT NULL DEFAULT 'PRODUCTION',
    filters_json   TEXT NOT NULL DEFAULT '{}',
    summary_json   TEXT NOT NULL,
    headline_json  TEXT NOT NULL DEFAULT '{}',
    snapshot_id    TEXT NOT NULL DEFAULT '',
    task_count     INTEGER NOT NULL DEFAULT 0,
    issue_count    INTEGER NOT NULL DEFAULT 0,
    fail_count     INTEGER NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'DONE',
    note           TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_qc_analysis_run_created
    ON qc_analysis_run(created_at);

CREATE TABLE IF NOT EXISTS qc_analysis_task (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id             INTEGER NOT NULL,
    task_key           TEXT NOT NULL,
    priority           TEXT NOT NULL DEFAULT '',
    source_system      TEXT NOT NULL DEFAULT '',
    group_name         TEXT NOT NULL DEFAULT '',
    fix_class          TEXT NOT NULL DEFAULT '',
    mpn                TEXT NOT NULL DEFAULT '',
    batch_id           TEXT NOT NULL DEFAULT '',
    signal             TEXT NOT NULL DEFAULT '',
    candidate_layer    TEXT NOT NULL DEFAULT '',
    evidence_gap       TEXT NOT NULL DEFAULT '',
    suggested_action   TEXT NOT NULL DEFAULT '',
    regression_scope   TEXT NOT NULL DEFAULT '',
    human_required     INTEGER NOT NULL DEFAULT 1,
    auto_fix_allowed   INTEGER NOT NULL DEFAULT 0,
    status             TEXT NOT NULL DEFAULT 'OPEN_CANDIDATE',
    created_at         TEXT NOT NULL,
    UNIQUE(run_id, task_key)
);
CREATE INDEX IF NOT EXISTS idx_qc_analysis_task_run
    ON qc_analysis_task(run_id, priority);
"""


class AnalyzerError(Exception):
    def __init__(self, code: str, message: str, http_status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.http_status = http_status


def _require_pandas():
    if pd is None:
        raise AnalyzerError("PANDAS_MISSING",
                            "pandas 未安装：请 pip install -r requirements.txt", 501)
    return pd


def now() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _safe(v):
    if v is None:
        return ""
    if isinstance(v, (np.integer,)) if np is not None else False:
        return int(v)
    if isinstance(v, (np.floating,)) if np is not None else False:
        return "" if pd.isna(v) else float(v)
    if isinstance(v, (np.bool_,)) if np is not None else False:
        return bool(v)
    if isinstance(v, float) and pd is not None and pd.isna(v):
        return ""
    return v


def _records(df, limit=None, columns=None) -> list:
    if df is None or len(df) == 0:
        return []
    x = df.head(limit) if limit else df
    if columns:
        x = x[[c for c in columns if c in x.columns]]
    return [{k: _safe(v) for k, v in row.items()}
            for row in x.to_dict(orient="records")]


def _bool(s):
    return s.astype(str).str.strip().str.lower().isin(
        ["true", "1", "yes", "y", "是"])


def _family(mpn: str) -> str:
    s = re.sub(r"/.*$", "", str(mpn or "")).split("-")[0]
    m = re.match(r"^([A-Za-z]+[0-9]*|[0-9]+)", s)
    return (m.group(1) if m else s[:6]) or "(空)"


def _base(s: str) -> str:
    return (s or "").replace("\\", "/").rsplit("/", 1)[-1]


def _crosstab(df, index, column):
    if df is None or len(df) == 0 or index not in df.columns \
            or column not in df.columns:
        return pd.DataFrame() if pd is not None else None
    try:
        ct = pd.crosstab(df[index], df[column], dropna=False)
    except TypeError:
        ct = pd.crosstab(df[index], df[column])
    ct = ct.reset_index()
    ct.columns = [str(c) for c in ct.columns]
    return ct


GROUP_LAYER = {
    "A1": ("源关联 / 业务口径", "核对业务对象与组件 PDF 关联是否符合业务口径"),
    "A2": ("型号 / 封装变体归一化", "定义基础型号、订购后缀、封装归一化规则；先写规则测试"),
    "A3": ("型号 / 来源身份", "核对原厂订购表、PDF SHA 与版本；恢复正确来源"),
    "E": ("PDF 来源 / 版本漂移", "确认 canonical PDF 与 revision；先修来源关联"),
    "I": ("电气表结构解析", "按表头/列角色/条件/单位拆分，不能统一判为 parser bug"),
    "DOWNSTREAM": ("下游模板 / 内容生成", "沿共享事实源定位正文/SEO/FAQ/多语言/渲染模板"),
}

FAIL_LAYER = {
    "MPN_MISMATCH": ("型号 / 来源身份", "核对精确 MPN、订购后缀、PDF 版本与 alias 来源"),
    "PDF_SHA_MISMATCH": ("来源 / 版本", "核对 PDF SHA、canonical 文件与 facts 来源版本"),
    "ELECTRICAL_ROW_BAD": ("电气表结构", "比对表头、MIN/TYP/MAX 列角色、条件与单位"),
    "ELECTRICAL_EMPTY": ("表格区域 / 解析路径", "检查表格区域定位、结构类型覆盖与字段映射"),
    "PIN_CONFIG_EMPTY": ("引脚表 / 解析路径", "检查封装专属 pin table、功能表与符号生成"),
    "PIN_CONFIG_MISMATCH": ("引脚映射", "对照封装 pin table、功能表与符号图"),
    "package_mismatch": ("型号 / 封装映射", "核对精确订购后缀与封装/替代料映射"),
}

CATEGORY_LAYER = {
    "IDENTITY_PACKAGE": ("型号 / 来源身份", "核对原厂订购表、PDF SHA、精确 SKU 与封装"),
    "ELECTRICAL_TABLE": ("电气表结构解析", "比对表头、列角色、条件、单位与脚注"),
    "PIN_MAPPING": ("引脚映射 / 符号生成", "核对封装 pin table、功能表、方向与有效电平"),
    "CONTENT_CONSISTENCY": ("共享事实源 / 下游模板", "核对型号专属参数在正文/SEO/FAQ/多语言的一致性"),
    "TRANSLATION": ("翻译模板", "核对术语表与共享事实源版本"),
    "DUPLICATE_CONTENT": ("下游模板", "核对型号专属字段是否被家族共用内容覆盖"),
    "RENDER_ASSET": ("渲染 / 资源", "核对模板、缓存与资源生成版本"),
    "STATUS_SEMANTICS": ("状态语义", "核对生命周期与状态字段来源"),
    "OTHER": ("待分诊", "先补字段路径、证据与版本"),
}


def _matrix_group(value: str) -> str:
    for k in ("A1", "A2", "A3", "E", "I"):
        if str(value or "").startswith(k + "_"):
            return k
    return "" if not value else str(value)


def _priority_for_group(group: str) -> str:
    return {"A3": "P0", "E": "P0", "A2": "P1", "I": "P1",
            "A1": "P1"}.get(group, "P2")


def _load_matrix(path: Path):
    pd = _require_pandas()
    df = pd.read_csv(path, dtype=str, keep_default_na=False,
                     encoding="utf-8-sig")
    for col in ("mpn_mismatch", "pdf_sha_mismatch", "electrical_row_bad",
                "electrical_empty"):
        if col in df.columns:
            df[col + "_b"] = _bool(df[col])
    df["_family"] = df["mpn"].map(_family)
    df["root_cause_group"] = df["root_cause_groups"].map(_matrix_group)

    def error_code(row):
        if row.get("electrical_empty_b"):
            return "ELECTRICAL_EMPTY"
        if row.get("electrical_row_bad_b"):
            return "ELECTRICAL_ROW_BAD"
        codes = [c for c in str(row.get("fail_codes") or "").split(";") if c]
        return codes[0] if codes else (row.get("status") or "")

    df["error_code"] = df.apply(error_code, axis=1)
    df["pdf_has_ec_text"] = df["pdf_has_ec_text"].map(
        lambda v: "YES" if str(v).strip().lower() in ("true", "1", "yes")
        else ("NO" if str(v).strip().lower() in ("false", "0", "no") else "NOT_CHECKED"))
    return df


def _load_cards(path: Path):
    pd = _require_pandas()
    if not path or not Path(path).is_file():
        return pd.DataFrame()
    df = pd.read_csv(path, dtype=str, keep_default_na=False,
                     encoding="utf-8-sig")
    keep = [c for c in ("mpn", "batch_id", "priority", "human_verdict",
                        "human_required", "automation_class", "suggested_action",
                        "evidence_pdf_page", "evidence_quote",
                        "adjudication_reason", "repair_status", "rule_version")
            if c in df.columns]
    return df[keep].drop_duplicates(["mpn", "batch_id"])


def load_feedback(db):
    pd = _require_pandas()
    issues = pd.DataFrame(db.q("SELECT * FROM customer_feedback_issue ORDER BY id"))
    samples = pd.DataFrame(db.q("SELECT * FROM customer_feedback_sample ORDER BY id"))
    evidence = pd.DataFrame(db.q("SELECT * FROM customer_feedback_evidence ORDER BY id"))
    regs = pd.DataFrame(db.q("SELECT * FROM customer_feedback_regression ORDER BY id"))
    return issues, samples, evidence, regs


def _pdf_for(name, pdf_root):
    if not name:
        return None
    p = Path(pdf_root) / _base(name)
    return p if p.is_file() else None


def _electrical_rows(matrix, pdf_root):
    pd = _require_pandas()
    rows = matrix[matrix["root_cause_group"] == "I"].copy()
    if len(rows) == 0:
        return rows, {}
    cache = {}
    structures, statuses = [], []
    for _, r in rows.iterrows():
        name = r.get("pdf_name") or ""
        if name not in cache:
            cache[name] = pdf_signals(_pdf_for(name, pdf_root))
        sig = cache[name]
        if sig is None:
            structures.append("NOT_CHECKED")
            statuses.append("PDF_MISSING" if name else "PDF_NAME_MISSING")
        else:
            structures.append(sig.get("table_structure_type", "NOT_CHECKED"))
            statuses.append(sig.get("pdf_has_ec_text", "NOT_CHECKED"))
    rows["table_structure_type"] = structures
    rows["pdf_signal"] = statuses
    rows["parser_version"] = rows["facts_model"].replace("", "UNKNOWN")
    rows["rule_version"] = RULE_VERSION

    def candidate(r):
        if r["pdf_signal"] == "PDF_MISSING":
            return ("来源文件缺失", "先恢复 canonical PDF / 核对文件名与批次关联")
        if r["pdf_signal"] == "NO":
            return ("来源 / 文本层（非解析器优先）", "PDF 无 EC 表文字：核对来源与版本，不能先改 parser")
        if r["error_code"] == "ELECTRICAL_EMPTY":
            return ("表格区域定位 / 解析路径", "检查 EC 表区域检测、结构类型覆盖与字段映射")
        return ("表格结构 / 列角色", "比对表头、MIN/TYP/MAX、条件、单位与脚注")

    cand = rows.apply(candidate, axis=1, result_type="expand")
    rows["candidate_layer"] = cand[0]
    rows["suggested_first_check"] = cand[1]
    rows["regression_scope"] = "该实际表格结构失败样本 + 同结构正例/边界例"
    rows["human_required"] = "YES"
    return rows, cache


def _electrical_crosstabs(rows):
    pd = _require_pandas()
    if len(rows) == 0:
        return {}
    out = {}
    out["error_x_ec_text"] = _records(
        _crosstab(rows, "error_code", "pdf_signal"))
    out["error_x_structure"] = _records(
        _crosstab(rows, "error_code", "table_structure_type"))
    out["parser_x_error"] = _records(
        _crosstab(rows, "parser_version", "error_code"))
    out["structure_x_parser"] = _records(
        _crosstab(rows, "table_structure_type", "parser_version"))
    combos = rows.groupby(
        ["table_structure_type", "pdf_signal", "error_code"], dropna=False
    ).size().reset_index(name="count").sort_values("count", ascending=False)
    out["structure_combos"] = _records(combos)
    return out


def _identity_anomalies(matrix, feedback_samples):
    pd = _require_pandas()
    out = []
    if len(matrix):
        m = matrix[matrix["status"] == "FAIL"].copy()
        for _, r in m.iterrows():
            reasons = []
            if r.get("mpn_mismatch_b"):
                reasons.append("MPN_MISMATCH")
            if r.get("pdf_sha_mismatch_b"):
                reasons.append("PDF_SHA_MISMATCH")
            if not r.get("pdf_sha256_item"):
                reasons.append("PDF_SHA_MISSING")
            if (r.get("pdf_sha256_item") and r.get("pdf_sha256_file")
                    and r["pdf_sha256_item"] != r["pdf_sha256_file"]):
                reasons.append("ITEM_FILE_SHA_DIFF")
            if (r.get("pdf_sha256_item") and r.get("facts_pdf_hash")
                    and r["pdf_sha256_item"] != r["facts_pdf_hash"]):
                reasons.append("ITEM_FACTS_SHA_DIFF")
            if not r.get("pdf_name"):
                reasons.append("PDF_NAME_MISSING")
            if not r.get("pdf_rev"):
                reasons.append("PDF_REV_MISSING")
            if reasons:
                out.append({
                    "source_system": "MATRIX",
                    "mpn": r.get("mpn", ""),
                    "batch_id": r.get("batch_id", ""),
                    "pdf_name": r.get("pdf_name", ""),
                    "reasons": ";".join(reasons),
                    "priority": "P0" if ("MPN_MISMATCH" in reasons
                                         or "PDF_SHA_MISMATCH" in reasons) else "P1",
                    "human_required": "YES",
                })
    if len(feedback_samples):
        for _, r in feedback_samples.iterrows():
            reasons = []
            if (r.get("original_pdf_sha256") and r.get("facts_source_sha256")
                    and r["original_pdf_sha256"] != r["facts_source_sha256"]):
                reasons.append("FACTS_SOURCE_SHA_DIFF")
            if not r.get("source_revision"):
                reasons.append("SOURCE_REVISION_MISSING")
            if not r.get("original_pdf_sha256"):
                reasons.append("PDF_SHA_MISSING")
            if reasons:
                out.append({
                    "source_system": "FEEDBACK",
                    "mpn": r.get("mpn", ""),
                    "batch_id": r.get("batch_id", ""),
                    "pdf_name": r.get("original_pdf_name", ""),
                    "reasons": ";".join(reasons),
                    "priority": "P1",
                    "human_required": "YES",
                })
    return out


def _root_cause_candidates(matrix, cards, issues, samples):
    pd = _require_pandas()
    rows = []
    fails = matrix[matrix["status"] == "FAIL"].copy()
    if len(fails):
        for (grp, fix, code), g in fails.groupby(
                ["root_cause_groups", "fix_class", "error_code"],
                dropna=False):
            key = _matrix_group(grp) or "OTHER"
            layer, action = GROUP_LAYER.get(
                key, FAIL_LAYER.get(code, ("待分诊", "先补证据与复现")))
            rep = g["mpn"].drop_duplicates().head(5).tolist()
            rows.append({
                "candidate_key": "MX-%s-%s-%s" % (key, fix or "NA", code or "NA"),
                "source_system": "MATRIX",
                "group_name": grp or "未分组",
                "group_code": key,
                "fix_class": fix or "",
                "error_code": code or "",
                "count": int(len(g)),
                "batch_count": int(g["batch_id"].nunique()),
                "mpn_count": int(g["mpn"].nunique()),
                "representative_mpns": ";".join(rep),
                "candidate_layer": layer,
                "suggested_action": action,
                "evidence_needed": "原厂 PDF 页码/原文/表头或订购表；精确 MPN/SHA/版本",
                "regression_scope": "该组代表样本 + 同结构/同规则正例与边界例",
                "priority": _priority_for_group(key),
                "human_required": "YES",
                "confidence": "CANDIDATE_NOT_PROVEN",
            })
    if len(issues):
        for (cat, sev), g in issues.groupby(["category", "severity"], dropna=False):
            layer, action = CATEGORY_LAYER.get(cat, ("待分诊", "先补证据"))
            keys = [str(x) for x in g["issue_key"].tolist()]
            mpns = []
            batches = set()
            if len(samples):
                ss = samples[samples["issue_id"].isin(g["id"])]
                mpns = ss["mpn"].tolist()
                batches = set(ss["batch_id"].tolist())
            rows.append({
                "candidate_key": "FB-%s-%s" % (cat, sev),
                "source_system": "FEEDBACK",
                "group_name": cat,
                "group_code": cat,
                "fix_class": "",
                "error_code": ";".join(sorted({str(x) for x in g["category"]})),
                "count": int(len(g)),
                "batch_count": int(len(batches)),
                "mpn_count": int(len(set(mpns))),
                "representative_mpns": ";".join(mpns[:5]),
                "candidate_layer": layer,
                "suggested_action": action,
                "evidence_needed": next((x for x in g["required_evidence"] if x), ""),
                "regression_scope": "该问题样本 + 同类别代表样本；先建最小失败用例",
                "priority": "P0" if sev == "P0_BLOCKER" else ("P1" if sev == "P1_HIGH" else "P2"),
                "human_required": "YES",
                "confidence": "CANDIDATE_NOT_PROVEN",
                "issue_keys": ";".join(keys),
            })
    return rows


def _regression_analysis(regs, issues, samples, matrix):
    pd = _require_pandas()
    out = {}
    if len(regs):
        out["result_counts"] = _records(
            regs.groupby("result", dropna=False).size()
            .rename("count").reset_index())
        out["total"] = int(len(regs))
        out["pass_rate"] = round(
            float((regs["result"] == "PASS").sum()) / len(regs), 4)
        out["failures"] = _records(
            regs[regs["result"] != "PASS"],
            columns=["id", "issue_id", "run_key", "scope_type",
                     "scope_description", "result", "failure_summary",
                     "report_storage_key", "finished_at"])
    else:
        out["result_counts"] = []
        out["total"] = 0
        out["pass_rate"] = 0
        out["failures"] = []
    cov = []
    if len(samples):
        issue_by_id = ({int(r["id"]): r for _, r in issues.iterrows()}
                       if len(issues) else {})
        reg_by_issue = {}
        if len(regs):
            for _, r in regs.iterrows():
                reg_by_issue.setdefault(int(r["issue_id"]), []).append(r)
        for _, s in samples.iterrows():
            i = issue_by_id.get(int(s["issue_id"]), {})
            rr = reg_by_issue.get(int(s["issue_id"]), [])
            cov.append({
                "issue_key": i.get("issue_key", ""),
                "mpn": s.get("mpn", ""),
                "batch_id": s.get("batch_id", ""),
                "field_path": s.get("field_path", ""),
                "evidence_status": s.get("evidence_status", ""),
                "regression_status": s.get("regression_status", ""),
                "acceptance_status": s.get("acceptance_status", ""),
                "regression_runs": len(rr),
                "last_result": rr[-1]["result"] if rr else "NOT_RUN",
                "parser_version": s.get("parser_version", ""),
                "rule_version": s.get("rule_version", ""),
            })
    out["coverage"] = cov
    if len(matrix):
        total = len(matrix)
        fails = int((matrix["status"] == "FAIL").sum())
        out["matrix_baseline"] = {
            "total_items": total, "fail_items": fails,
            "warn_items": int((matrix["status"] == "WARN").sum()),
            "pass_items": int((matrix["status"] == "PASS").sum()),
            "fail_rate": round(fails / total, 4) if total else 0,
        }
        cohorts = []
        for grp, g in matrix[matrix["status"] == "FAIL"].groupby(
                "root_cause_groups", dropna=False):
            key = _matrix_group(grp) or "OTHER"
            linked = samples[samples["mpn"].isin(set(g["mpn"]))] if len(samples) else []
            cohorts.append({
                "group_code": key,
                "group_name": grp or "未分组",
                "matrix_fail_count": int(len(g)),
                "matrix_batches": int(g["batch_id"].nunique()),
                "feedback_samples_linked": int(len(linked)),
                "feedback_pass": int((linked["regression_status"] == "PASS").sum())
                if len(linked) else 0,
                "feedback_fail": int((linked["regression_status"] == "FAIL").sum())
                if len(linked) else 0,
            })
        out["affected_cohorts"] = cohorts
    return out


def _tasks(candidates, electrical_rows, issues, samples):
    pd = _require_pandas()
    tasks = []

    def add(**kw):
        tasks.append({
            "task_key": "", "priority": "P2", "source_system": "",
            "group_name": "", "fix_class": "", "mpn": "", "batch_id": "",
            "signal": "", "candidate_layer": "", "evidence_gap": "",
            "suggested_action": "", "regression_scope": "",
            "human_required": True, "auto_fix_allowed": False,
            "status": "OPEN_CANDIDATE", **kw,
        })

    # 反馈问题优先：客户已提交，必须先补证据/复现
    if len(issues):
        s_by_issue = {}
        if len(samples):
            for _, s in samples.iterrows():
                s_by_issue.setdefault(int(s["issue_id"]), []).append(s)
        for _, i in issues.iterrows():
            ss = s_by_issue.get(int(i["id"]), [])
            add(task_key="QCA-FB-%s" % i["issue_key"],
                priority=("P0" if i["severity"] == "P0_BLOCKER"
                          else ("P1" if i["severity"] == "P1_HIGH" else "P2")),
                source_system="FEEDBACK",
                group_name=i["category"], fix_class="",
                mpn=";".join(str(s["mpn"]) for s in ss[:3]),
                batch_id=";".join(str(s["batch_id"]) for s in ss[:3]),
                signal=(i.get("actual_behavior") or i.get("title") or "")[:200],
                candidate_layer=CATEGORY_LAYER.get(
                    i["category"], ("待分诊", ""))[0],
                evidence_gap=(i.get("required_evidence") or
                              "缺原厂页码/原文/字段路径/版本")[:300],
                suggested_action=(i.get("root_cause_hypothesis") or
                                  "先复现并补证据")[:300],
                regression_scope="该问题样本 + 同类别代表样本；人工验收前不得关闭")
    # 矩阵组任务
    for c in candidates:
        if c["source_system"] != "MATRIX":
            continue
        add(task_key="QCA-MX-%s-%s" % (c["group_code"],
                                       hashlib.sha1(
                                           c["candidate_key"].encode()).hexdigest()[:6]),
            priority=c["priority"], source_system="MATRIX",
            group_name=c["group_name"], fix_class=c["fix_class"],
            mpn=c["representative_mpns"], batch_id="",
            signal=c["error_code"], candidate_layer=c["candidate_layer"],
            evidence_gap=c["evidence_needed"],
            suggested_action=c["suggested_action"],
            regression_scope=c["regression_scope"])
    # 电气结构专项任务
    if len(electrical_rows):
        for (st, sig, code), g in electrical_rows.groupby(
                ["table_structure_type", "pdf_signal", "error_code"],
                dropna=False):
            add(task_key="QCA-EC-%s-%s" % (
                    hashlib.sha1(("%s|%s|%s" % (st, sig, code)).encode()).hexdigest()[:8],
                    code),
                priority="P1", source_system="ELECTRICAL",
                group_name="I_解析结构缺陷（电气表行）", fix_class="",
                mpn=";".join(g["mpn"].head(5).tolist()),
                batch_id=";".join(g["batch_id"].head(3).tolist()),
                signal="%s × %s × %s" % (code, sig, st),
                candidate_layer=g["candidate_layer"].iloc[0],
                evidence_gap="PDF 页码/表头/条件/单位/原文；结构代表样本",
                suggested_action=g["suggested_first_check"].iloc[0],
                regression_scope=g["regression_scope"].iloc[0])
    prio = {"P0": 0, "P1": 1, "P2": 2}
    dedup, seen = [], set()
    for t in sorted(tasks, key=lambda x: (prio.get(x["priority"], 9),
                                          -len(str(x["mpn"])), x["task_key"])):
        if t["task_key"] in seen:
            continue
        seen.add(t["task_key"])
        dedup.append(t)
    for n, t in enumerate(dedup, 1):
        t["index"] = n
    return dedup[:300]


def _inventory(full, selected, issues, samples, evidence, regs):
    pd = _require_pandas()
    fail = full[full["status"] == "FAIL"] if len(full) else full
    sel_fail = selected[selected["status"] == "FAIL"] if len(selected) else selected
    return {
        "matrix_rows": int(len(full)),
        "matrix_fail": int(len(fail)),
        "matrix_warn": int((full["status"] == "WARN").sum()) if len(full) else 0,
        "matrix_pass": int((full["status"] == "PASS").sum()) if len(full) else 0,
        "selected_rows": int(len(selected)),
        "selected_fail": int(len(sel_fail)),
        "batches": int(full["batch_id"].nunique()) if len(full) else 0,
        "mpns": int(full["mpn"].nunique()) if len(full) else 0,
        "brands": int(full["brand"].nunique()) if len(full) else 0,
        "feedback_issues": int(len(issues)),
        "feedback_samples": int(len(samples)),
        "feedback_evidence": int(len(evidence)),
        "feedback_regressions": int(len(regs)),
        "matrix_version": MATRIX_VERSION,
        "rule_version": RULE_VERSION,
        "analyzer_version": ANALYZER_VERSION,
    }


def run_analysis(db, filters=None, matrix_path=None, cards_path=None,
                 pdf_root=None, actor="system:qc-analyzer",
                 persist=True) -> dict:
    pd = _require_pandas()
    filters = filters or {}
    matrix_path = Path(matrix_path or "")
    if not matrix_path.is_file():
        raise AnalyzerError("MATRIX_MISSING", "analysis matrix 不存在", 500)
    cards_path = Path(cards_path) if cards_path else None
    pdf_root = Path(pdf_root) if pdf_root else None

    matrix = _load_matrix(matrix_path)
    cards = _load_cards(cards_path)
    issues, samples, evidence, regs = load_feedback(db)

    # 合并证据卡（只补优先级/人工裁决，不改变矩阵结论）
    if len(cards) and len(matrix):
        matrix = matrix.merge(cards, on=["mpn", "batch_id"], how="left",
                              suffixes=("", "_card"))
        if "priority_card" in matrix.columns:
            matrix["priority"] = matrix["priority_card"].fillna("")
        for col in ("human_verdict", "repair_status", "rule_version_card"):
            if col in matrix.columns:
                matrix[col] = matrix[col].fillna("")

    # 过滤（全量矩阵保留给基线/失败率，筛选矩阵用于当前任务）
    full_matrix = matrix.copy()
    f = matrix.copy()
    status = (filters.get("status") or "").upper()
    if status and status != "ALL":
        f = f[f["status"] == status]
    elif not status:
        f = f[f["status"] == "FAIL"]
    for key in ("batch_id", "brand"):
        if filters.get(key):
            f = f[f[key] == filters[key]]
    if filters.get("group"):
        f = f[f["root_cause_group"] == filters["group"]]
    if filters.get("mpn"):
        f = f[f["mpn"].str.contains(filters["mpn"], case=False, na=False)]
    if filters.get("q"):
        q = filters["q"]
        f = f[f.apply(lambda r: q.lower() in " ".join(
            str(x) for x in r.values).lower(), axis=1)]

    inventory = _inventory(full_matrix, f, issues, samples, evidence, regs)
    fails = f[f["status"] == "FAIL"] if len(f) else f
    all_fails = (full_matrix[full_matrix["status"] == "FAIL"]
                 if len(full_matrix) else full_matrix)
    # 异常率分母用“未按 status 过滤”的同一批次/型号集合，避免 FAIL 子集算出 100%
    dist_base = full_matrix.copy()
    for key in ("batch_id", "brand"):
        if filters.get(key):
            dist_base = dist_base[dist_base[key] == filters[key]]
    if filters.get("group"):
        dist_base = dist_base[dist_base["root_cause_group"] == filters["group"]]
    if filters.get("mpn"):
        dist_base = dist_base[dist_base["mpn"].str.contains(
            filters["mpn"], case=False, na=False)]
    if filters.get("q"):
        qq = filters["q"]
        dist_base = dist_base[dist_base.apply(
            lambda r: qq.lower() in " ".join(str(x) for x in r.values).lower(),
            axis=1)]

    # 分布
    distributions = {}
    if len(fails):
        distributions["by_group"] = _records(
            fails.groupby("root_cause_groups", dropna=False).size()
            .rename("count").reset_index().sort_values("count", ascending=False))
        codes = fails["fail_codes"].str.split(";").explode()
        distributions["by_fail_code"] = _records(
            codes[codes != ""].value_counts().rename_axis("fail_code")
            .reset_index(name="count"))
    if len(dist_base):
        distributions["by_brand"] = _records(
            dist_base.groupby("brand", dropna=False).agg(
                total=("mpn", "size"),
                fail=("status", lambda x: int((x == "FAIL").sum())))
            .reset_index().assign(
                fail_rate=lambda d: (d["fail"] / d["total"]).round(4))
            .sort_values("fail", ascending=False))
        distributions["by_batch"] = _records(
            dist_base.groupby("batch_id", dropna=False).agg(
                total=("mpn", "size"),
                fail=("status", lambda x: int((x == "FAIL").sum())))
            .reset_index().assign(
                fail_rate=lambda d: (d["fail"] / d["total"]).round(4))
            .sort_values("fail", ascending=False).head(30))
        distributions["by_family"] = _records(
            dist_base.groupby("_family", dropna=False).agg(
                total=("mpn", "size"),
                fail=("status", lambda x: int((x == "FAIL").sum())))
            .reset_index().assign(
                fail_rate=lambda d: (d["fail"] / d["total"]).round(4))
            .sort_values("fail", ascending=False).head(30))
        distributions["by_parser"] = _records(
            dist_base.groupby("facts_model", dropna=False).agg(
                total=("mpn", "size"),
                fail=("status", lambda x: int((x == "FAIL").sum())))
            .reset_index().assign(
                fail_rate=lambda d: (d["fail"] / d["total"]).round(4))
            .sort_values("fail", ascending=False))
    if len(issues):
        distributions["feedback_by_category"] = _records(
            issues.groupby("category", dropna=False).size()
            .rename("count").reset_index())
        distributions["feedback_by_severity"] = _records(
            issues.groupby("severity", dropna=False).size()
            .rename("count").reset_index())
        distributions["feedback_by_status"] = _records(
            issues.groupby("status", dropna=False).size()
            .rename("count").reset_index())

    anomalies = _identity_anomalies(f, samples)
    candidates = _root_cause_candidates(f, cards, issues, samples)
    electrical_rows, _ = _electrical_rows(f, pdf_root)
    crosstabs = _electrical_crosstabs(electrical_rows)
    regression = _regression_analysis(regs, issues, samples, full_matrix)
    tasks = _tasks(candidates, electrical_rows, issues, samples)

    snapshot = hashlib.sha1(
        (MATRIX_VERSION + "|" + json.dumps(filters, sort_keys=True) + "|" +
         ",".join(sorted(str(x) for x in fails["mpn"].tolist())) + "|" +
         ",".join(sorted(str(x) for x in issues.get("issue_key", [])))).encode()
    ).hexdigest()[:16]
    run_key = "QCA-%s-%s-%s" % (
        datetime.datetime.now().strftime("%Y%m%d-%H%M%S"),
        snapshot[:6], uuid.uuid4().hex[:4])
    summary = {
        "run_key": run_key,
        "generated_at": now(),
        "created_by": actor,
        "analyzer_version": ANALYZER_VERSION,
        "matrix_version": MATRIX_VERSION,
        "rule_version": RULE_VERSION,
        "filters": filters,
        "snapshot_id": snapshot,
        "inventory": inventory,
        "distributions": distributions,
        "identity_source": {
            "total": len(anomalies),
            "by_reason": _records(
                pd.DataFrame(anomalies)["reasons"].str.split(";").explode()
                .value_counts().rename_axis("reason").reset_index(name="count"))
            if anomalies else [],
            "items": anomalies[:5000],
        },
        "root_cause_candidates": candidates,
        "electrical": {
            "total": int(len(electrical_rows)),
            "pdf_signals": _records(
                electrical_rows.groupby("pdf_signal", dropna=False).size()
                .rename("count").reset_index()) if len(electrical_rows) else [],
            "structures": _records(
                electrical_rows.groupby("table_structure_type", dropna=False).size()
                .rename("count").reset_index()) if len(electrical_rows) else [],
            "crosstabs": crosstabs,
            "rows": _records(electrical_rows),
        },
        "regression": regression,
        "tasks": tasks,
        "issues": _records(issues, columns=[
            "issue_key", "category", "severity", "status", "title"]),
        "samples": _records(samples, columns=[
            "mpn", "batch_id", "field_path", "regression_status",
            "evidence_status", "acceptance_status"]),
        "regressions": _records(regs, columns=[
            "issue_id", "run_key", "result", "failure_summary"]),
        "comparison": None,
        "caveats": [
            "统计结果只生成排查线索，不构成根因结论。",
            "pdf_has_ec_text / table_structure_type 为文本层关键词启发式。",
            "不得据此自动修改 facts/Gold、自动验收或关闭问题。",
            "候选任务必须经工程人员核对原厂 PDF/订购表后才能立项。",
        ],
    }
    summary["headline"] = {
        "fail_items": inventory["matrix_fail"],
        "selected_fail": inventory["selected_fail"],
        "identity_pending": sum(
            1 for a in anomalies if "MPN_MISMATCH" in a["reasons"]
            or "PDF_SHA_MISMATCH" in a["reasons"]),
        "electrical_items": int(len(electrical_rows)),
        "evidence_gaps": sum(1 for s in summary["samples"]
                             if s.get("evidence_status") in ("MISSING", "")),
        "regression_fails": int((regs["result"] == "FAIL").sum())
        if len(regs) else 0,
        "tasks": len(tasks),
    }
    if persist:
        _persist(db, summary, filters)
    return summary


def _persist(db, summary, filters):
    ids = db.x(
        "INSERT INTO qc_analysis_run(run_key,created_at,created_by,source,"
        "filters_json,summary_json,headline_json,snapshot_id,task_count,"
        "issue_count,fail_count,status,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (summary["run_key"], summary["generated_at"], summary["created_by"],
         "PRODUCTION", json.dumps(filters, ensure_ascii=False),
         json.dumps(summary, ensure_ascii=False),
         json.dumps(summary.get("headline") or {}, ensure_ascii=False),
         summary["snapshot_id"],
         len(summary["tasks"]), summary["inventory"]["feedback_issues"],
         summary["inventory"]["matrix_fail"], "DONE",
         "只读分析快照；候选任务需人工确认"))
    for t in summary["tasks"]:
        db.x("INSERT INTO qc_analysis_task(run_id,task_key,priority,"
             "source_system,group_name,fix_class,mpn,batch_id,signal,"
             "candidate_layer,evidence_gap,suggested_action,regression_scope,"
             "human_required,auto_fix_allowed,status,created_at) "
             "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
             (ids, t["task_key"], t["priority"], t["source_system"],
              t["group_name"], t["fix_class"], t["mpn"], t["batch_id"],
              t["signal"], t["candidate_layer"], t["evidence_gap"],
              t["suggested_action"], t["regression_scope"],
              1 if t["human_required"] else 0,
              1 if t["auto_fix_allowed"] else 0, t["status"],
              summary["generated_at"]))
    return ids


def list_runs(db, limit=30) -> list:
    rows = db.q("SELECT * FROM qc_analysis_run ORDER BY id DESC LIMIT ?",
                (max(1, min(int(limit or 30), 200)),))
    out = []
    for r in rows:
        item = {k: r[k] for k in ("run_key", "created_at", "created_by",
                                  "snapshot_id", "task_count", "issue_count",
                                  "fail_count", "status", "note")}
        try:
            item["headline"] = json.loads(r.get("headline_json") or "{}")
        except Exception:                                    # noqa: BLE001
            item["headline"] = {}
        out.append(item)
    return out


def get_run(db, run_key) -> dict:
    row = db.q1("SELECT * FROM qc_analysis_run WHERE run_key=?", (run_key,))
    if not row:
        raise AnalyzerError("NOT_FOUND", "分析记录不存在", 404)
    try:
        return json.loads(row["summary_json"])
    except Exception:                                        # noqa: BLE001
        raise AnalyzerError("BAD_SNAPSHOT", "分析快照损坏", 500)


def compare_runs(db, before_key, after_key) -> dict:
    before = get_run(db, before_key)
    after = get_run(db, after_key)
    b_issues = {i["issue_key"]: i for i in before.get("issues", [])}
    a_issues = {i["issue_key"]: i for i in after.get("issues", [])}
    status_changes = []
    for key in sorted(set(b_issues) | set(a_issues)):
        b = b_issues.get(key)
        a = a_issues.get(key)
        if not b:
            status_changes.append({"issue_key": key, "change": "ADDED",
                                   "before": "", "after": a.get("status", "")})
        elif not a:
            status_changes.append({"issue_key": key, "change": "REMOVED",
                                   "before": b.get("status", ""), "after": ""})
        elif b.get("status") != a.get("status"):
            status_changes.append({"issue_key": key, "change": "STATUS_CHANGED",
                                   "before": b.get("status", ""),
                                   "after": a.get("status", "")})

    def reg_map(run):
        return {r.get("run_key") or str(r.get("issue_id")): r
                for r in run.get("regressions", [])}
    b_reg, a_reg = reg_map(before), reg_map(after)
    reg_changes = []
    for key in sorted(set(b_reg) | set(a_reg)):
        b, a = b_reg.get(key), a_reg.get(key)
        if b and a and b.get("result") != a.get("result"):
            reg_changes.append({
                "case": key, "change": "RESULT_CHANGED",
                "before": b.get("result", ""), "after": a.get("result", ""),
                "failure": a.get("failure_summary", ""),
            })
        elif b and not a:
            reg_changes.append({"case": key, "change": "REMOVED",
                                "before": b.get("result", ""), "after": ""})
        elif a and not b:
            reg_changes.append({"case": key, "change": "ADDED",
                                "before": "", "after": a.get("result", "")})
    task_delta = []
    def task_counts(run):
        d = {}
        for t in run.get("tasks", []):
            k = (t.get("source_system", ""), t.get("group_name", ""),
                 t.get("priority", ""))
            d[k] = d.get(k, 0) + 1
        return d
    bt, at = task_counts(before), task_counts(after)
    for k in sorted(set(bt) | set(at)):
        if bt.get(k, 0) != at.get(k, 0):
            task_delta.append({"source_system": k[0], "group_name": k[1],
                               "priority": k[2], "before": bt.get(k, 0),
                               "after": at.get(k, 0),
                               "delta": at.get(k, 0) - bt.get(k, 0)})
    result = {
        "before": before_key, "after": after_key,
        "before_generated_at": before.get("generated_at", ""),
        "after_generated_at": after.get("generated_at", ""),
        "status_changes": status_changes,
        "regression_changes": reg_changes,
        "regression_resolved": sum(
            1 for r in reg_changes if r["change"] == "RESULT_CHANGED"
            and r["after"] == "PASS"),
        "regression_new_fail": sum(
            1 for r in reg_changes if r["change"] == "RESULT_CHANGED"
            and r["after"] != "PASS"),
        "task_delta": task_delta,
        "headline_delta": {
            k: (after.get("headline", {}).get(k, 0)
                - before.get("headline", {}).get(k, 0))
            for k in ("fail_items", "identity_pending", "electrical_items",
                      "evidence_gaps", "regression_fails", "tasks")
        },
        "note": "差异来自两次只读分析快照；不自动判定修复成功。",
    }
    return result


# ---------------------------------------------------------------- 导出
def _csv(rows, columns):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
    w.writeheader()
    for r in rows or []:
        w.writerow({c: r.get(c, "") if r.get(c) is not None else ""
                    for c in columns})
    return buf.getvalue()


def tasks_csv(summary) -> str:
    return _csv(summary.get("tasks", []), [
        "index", "task_key", "priority", "source_system", "group_name",
        "fix_class", "mpn", "batch_id", "signal", "candidate_layer",
        "evidence_gap", "suggested_action", "regression_scope",
        "human_required", "auto_fix_allowed", "status"])


def tasks_xlsx(summary) -> bytes:
    pd = _require_pandas()
    tasks = pd.DataFrame(summary.get("tasks", []))
    buf = io.BytesIO()
    try:
        with pd.ExcelWriter(buf, engine="openpyxl") as w:
            tasks.to_excel(w, index=False, sheet_name="tasks")
            inv = pd.DataFrame([summary.get("inventory", {})])
            inv.to_excel(w, index=False, sheet_name="inventory")
            pd.DataFrame(summary.get("root_cause_candidates", [])).to_excel(
                w, index=False, sheet_name="root_cause_candidates")
    except Exception as e:                                   # noqa: BLE001
        raise AnalyzerError("XLSX_UNAVAILABLE", "Excel 导出不可用：%s" % e, 501)
    return buf.getvalue()


def export_bundle(summary) -> bytes:
    pd = _require_pandas()
    files = {
        "00_inventory.csv": _csv(
            [{"key": k, "value": v} for k, v in summary["inventory"].items()],
            ["key", "value"]),
        "01_issue_distribution.csv": _csv(
            [{"group_type": k, **r}
             for k, rows in summary["distributions"].items() for r in rows],
            ["group_type", "root_cause_groups", "fail_code", "brand", "batch_id",
             "_family", "facts_model", "total", "fail", "fail_rate", "count",
             "category", "severity", "status"]),
        "02_identity_source_anomalies.csv": _csv(
            summary["identity_source"]["items"],
            ["source_system", "mpn", "batch_id", "pdf_name", "reasons",
             "priority", "human_required"]),
        "03_root_cause_candidates.csv": _csv(
            summary["root_cause_candidates"],
            ["candidate_key", "source_system", "group_name", "group_code",
             "fix_class", "error_code", "count", "batch_count", "mpn_count",
             "representative_mpns", "candidate_layer", "suggested_action",
             "evidence_needed", "regression_scope", "priority",
             "human_required", "confidence", "issue_keys"]),
        "04_electrical_crosstabs.csv": _csv(
            [{"crosstab": k, **r}
             for k, rows in summary["electrical"]["crosstabs"].items()
             for r in rows],
            ["crosstab", "error_code", "pdf_signal", "table_structure_type",
             "parser_version", "count"]),
        "04b_electrical_rows.csv": _csv(
            summary["electrical"]["rows"],
            ["mpn", "batch_id", "brand", "error_code", "pdf_name",
             "pdf_has_ec_text", "pdf_signal", "table_structure_type",
             "parser_version", "rule_version", "candidate_layer",
             "suggested_first_check", "regression_scope", "human_required"]),
        "05_regression_coverage.csv": _csv(
            summary["regression"].get("coverage", []),
            ["issue_key", "mpn", "batch_id", "field_path", "evidence_status",
             "regression_status", "acceptance_status", "regression_runs",
             "last_result", "parser_version", "rule_version"]),
        "05b_regression_failures.csv": _csv(
            summary["regression"].get("failures", []),
            ["id", "issue_id", "run_key", "scope_type", "scope_description",
             "result", "failure_summary", "report_storage_key", "finished_at"]),
        "06_engineering_tasks.csv": tasks_csv(summary),
        "README.txt": (
            "IcPdfParser pandas QC Analyzer 分析包（只读）\n"
            "==========================================\n"
            "本包由生产反馈表 + auto QC 矩阵 + 证据卡生成。\n"
            "- 统计结果只生成排查线索，不构成根因结论。\n"
            "- pdf_has_ec_text/table_structure_type 为 PDF 文本层关键词启发式。\n"
            "- 不包含 PDF 二进制、绝对路径、会话/密钥。\n"
            "- 不得据此自动修改 facts/Gold、自动验收或关闭问题。\n"
            "- 候选任务需工程人员核对原厂 PDF/订购表后再立项。\n"),
    }
    created = now()
    manifest = {
        "export_id": "qcaexp-" + hashlib.sha1(
            (summary["run_key"] + created).encode()).hexdigest()[:12],
        "run_key": summary["run_key"],
        "created_at": created,
        "analyzer_version": summary["analyzer_version"],
        "matrix_version": summary["matrix_version"],
        "snapshot_id": summary["snapshot_id"],
        "schema_version": "qc-analyzer-export-v1",
        "timezone": "Asia/Shanghai",
        "redaction_profile": "no-secrets-no-absolute-paths",
        "row_counts": {
            "identity_source_anomalies": len(summary["identity_source"]["items"]),
            "identity_source_anomalies_total": summary["identity_source"]["total"],
            "root_cause_candidates": len(summary["root_cause_candidates"]),
            "electrical_rows": len(summary["electrical"]["rows"]),
            "regression_coverage": len(summary["regression"].get("coverage", [])),
            "tasks": len(summary["tasks"]),
        },
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json",
                   json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        for name, text in files.items():
            z.writestr(name, text.encode("utf-8-sig"))
        try:
            z.writestr("06_engineering_tasks.xlsx", tasks_xlsx(summary))
        except AnalyzerError:
            pass
    return buf.getvalue()
