"""任务投递：优先 Celery + Redis，Redis 不可用时降级为进程内线程池。

工作台不会因为 Redis 没启动就完全不可用——降级模式仍能跑通单机全链路，
只是任务不能跨进程分发、重启会丢队列。
"""
from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor

from .. import config

log = logging.getLogger("icpdf.dispatch")

_pool: ThreadPoolExecutor | None = None
_pool_lock = threading.Lock()
_redis_state = {"ok": None, "checked_at": 0.0}


def _pool_get() -> ThreadPoolExecutor:
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                _pool = ThreadPoolExecutor(max_workers=max(1, config.LLM_WORKERS),
                                           thread_name_prefix="inline")
    return _pool


def redis_ok(force: bool = False) -> bool:
    """带 3 秒缓存的探测，避免每个请求都去连 Redis。"""
    import time
    now = time.time()
    if not force and _redis_state["ok"] is not None and now - _redis_state["checked_at"] < 3:
        return bool(_redis_state["ok"])
    ok = False
    try:
        import redis
        r = redis.Redis.from_url(config.REDIS_URL, socket_connect_timeout=0.8,
                                 socket_timeout=0.8)
        ok = bool(r.ping())
        r.close()
    except Exception:                                            # noqa: BLE001
        ok = False
    _redis_state.update(ok=ok, checked_at=now)
    return ok


def mode() -> str:
    return "celery" if redis_ok() else ("inline" if config.ALLOW_INLINE_FALLBACK else "down")


def queue_depths() -> dict:
    """各队列当前积压量（L2 观测：fetch/llm/render 各自独立消化）。

    五段链路开启后会多出 preprocess / audit 两个队列；这里按 `TASK_QUEUE` 的
    值集合推导，**不另抄一份队列名**——抄一份的结果是新增队列永远不出现在监控里，
    而「看不见的队列」在压测时表现为「任务明明投了却没进度」。
    """
    if not redis_ok():
        return {}
    try:
        import redis
        r = redis.Redis.from_url(config.REDIS_URL, socket_connect_timeout=0.8,
                                 socket_timeout=0.8)
        names = list(dict.fromkeys(config.TASK_QUEUE.values()))
        out = {q: int(r.llen(q)) for q in names}
        r.close()
        return out
    except Exception:                                            # noqa: BLE001
        return {}


def submit(kind: str, *args, **kwargs) -> dict:
    """投递任务，返回 {mode, task_id}。队列按 config.TASK_QUEUE 路由（默认 llm 队列）。"""
    if redis_ok():
        try:
            from worker.tasks import CELERY_TASKS
            task = CELERY_TASKS[kind]
            r = task.apply_async(args=args, kwargs=kwargs,
                                 queue=config.TASK_QUEUE.get(kind, config.CELERY_QUEUE))
            return {"mode": "celery", "task_id": r.id, "kind": kind}
        except Exception as e:                                   # noqa: BLE001
            log.warning("celery 投递失败，转降级：%s", e)

    if not config.ALLOW_INLINE_FALLBACK:
        raise RuntimeError(f"Redis 不可用（{config.REDIS_URL}），且已禁用降级执行")

    from worker.tasks import FUNCS
    fn = FUNCS[kind]
    _pool_get().submit(_guard, fn, args, kwargs)
    return {"mode": "inline", "task_id": "", "kind": kind}


def _guard(fn, args, kwargs) -> None:
    try:
        fn(*args, **kwargs)
    except Exception:                                            # noqa: BLE001
        log.exception("inline 任务异常：%s", getattr(fn, "__name__", fn))
