#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review.py — 用百炼 qwen-flash 对型号交付物做「红线质量审查」（CLI 入口）。

核心逻辑在 app/services/review.py（工作台「审计」按钮走同一份代码）。

定位：
  - 只读产物（parsed JSON / txt / alts / seo），不改任何 facts / DB / 渲染
  - 规则先过、LLM 兜底：确定性检查（EVM 判板、转义、重复度、多语残留）不走模型
  - LLM 只判语义可疑点与结构合理性，不判「值对不对」（那是证据卡的活）
  - 完整审查落 data/qc/reviews/{SAFE}.review.{json,md,html}；--dry-run 不落盘
  - --write-db 只 append qc_run/qc_audit_log 并记 llm_usage（append-only 台账）

用法：
  python review.py --mpn DS80PCI402EVK/NOPB
  python review.py --mpn DS80PCI402EVK/NOPB --with-pdf-text
  python review.py --batch qc30-20261028-0229
  python review.py --all-parsed --concurrency 4 --out-dir data/qc/reviews-full
  python review.py --mpn X --dry-run            # 不调模型、不落盘，只看规则层
  python review.py --mpn X --max-tokens 6000
  python review.py --pin-pairs-scan             # 零 token 扫全库差分对错位
  python review.py --pin-pairs-scan --batch qc30-20261028-0229 \
      --json-out data/qc/pin_pair_scan.json

环境（.env.local）：
  DASHSCOPE_API_KEY / DASHSCOPE_MODEL=qwen-flash
  DASHSCOPE_BASE=https://dashscope.aliyuncs.com/compatible-mode/v1
  ICPDF_ENABLE_THINKING=0  ICPDF_MAX_TOKENS=6000

断点续跑：已存在完整报告（非 dry_run）的自动跳过；需重算时删对应
data/qc/reviews/{SAFE}.review.json 再跑（删文件比加 --force 更可控）。
"""
from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

REPO = Path(__file__).resolve().parent
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from app import config, db                      # noqa: E402
from app.services import review as RV           # noqa: E402


def _targets(args) -> list[str]:
    if args.mpn:
        return [args.mpn]
    if args.batch:
        rows = db.q("SELECT mpn FROM item WHERE batch_id=? AND status='done'",
                    (args.batch,))
        return [r["mpn"] for r in rows]
    if args.all_parsed:
        rows = db.q("SELECT mpn FROM item WHERE json_path<>'' ORDER BY id")
        return [r["mpn"] for r in rows]
    return []


def _pin_pair_scan(args) -> int:
    """批量扫差分对错位（零 token、零 PDF）：先看全库有多少件被同一种错位命中。

    逐件跑完整 review 要调模型、有成本；这条规则只看 JSON 自身结构，所以适合
    先全量扫一遍定位「同族/同批受害面」，再决定对哪几件跑完整审查与自动修复。
    """
    from qc.pin_pairs import scan_files

    sql = "SELECT mpn, json_path FROM item WHERE json_path<>''"
    params: tuple = ()
    if args.batch:
        sql += " AND batch_id=? AND status='done'"
        params = (args.batch,)
    if args.mpn:
        sql += " AND mpn=?"
        params = (args.mpn,)
    rows = db.q(sql + " ORDER BY id", params)
    # json_path 为空/失效的行退回 data_dir 里的同名文件
    paths = [r["json_path"] for r in rows if r.get("json_path")]
    mpn_of = {r["json_path"]: r["mpn"] for r in rows if r.get("json_path")}
    if not paths:
        print("没有可扫的 parsed JSON（检查 --mpn/--batch，或先解析）",
              file=sys.stderr)
        return 2

    res = scan_files(paths, limit=args.limit or 0)
    print(f"[pin-pairs] 扫描 {res['scanned']} 件：错位 {res['broken_hit']} 件、"
          f"单侧极性 {res['polarity_hit']} 件（不可解析 {res['errors']} 件）")
    if res["hit"]:
        print(f"{'MPN':<28}{'bank':<16}{'断对':>4} {'缺极性':>5}  file")
        for it in sorted(res["items"],
                         key=lambda x: (-x["broken_pairs"], -x["polarity_missing"])):
            banks = ",".join(sorted(it.get("banks") or {}))
            print(f"{mpn_of.get(it['file'], it['mpn'])[:27]:<28}{banks[:15]:<16}"
                  f"{it['broken_pairs']:>4} {it['polarity_missing']:>6}  "
                  f"{Path(it['file']).name}")
        if res["by_bank"]:
            print("[pin-pairs] 错位 bank 分布：" + ", ".join(
                f"{b}={c}" for b, c in sorted(res["by_bank"].items(),
                                              key=lambda kv: -kv[1])))
    if args.json_out:
        out = Path(args.json_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        payload = {"tool": "qc.pin_pairs", "generated_at": RV._now_iso(),
                   "scanned": res["scanned"], "hit": res["hit"],
                   "broken_hit": res["broken_hit"],
                   "polarity_hit": res["polarity_hit"],
                   "errors": res["errors"], "by_bank": res["by_bank"],
                   "items": [{"mpn": mpn_of.get(i["file"], i["mpn"]),
                              "file": i["file"],
                              "broken_pairs": i["broken_pairs"],
                              "polarity_missing": i["polarity_missing"],
                              "banks": i["banks"], "findings": i["findings"]}
                             for i in res["items"]]}
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        print(f"[pin-pairs] 明细：{out}")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="百炼 LLM 交付物红线审查（只读）")
    ap.add_argument("--mpn", help="单个型号（原样 MPN，可含 /）")
    ap.add_argument("--batch", help="按 item.batch_id 全量 done 型号")
    ap.add_argument("--all-parsed", action="store_true", help="所有已解析型号")
    ap.add_argument("--data-dir", default=str(config.DATA))
    ap.add_argument("--out-dir", default=str(config.DATA / "qc" / "reviews"))
    ap.add_argument("--with-pdf-text", action="store_true",
                    help="读 PDF 前 6 页给 LLM 交叉验证身份/封装（更贵、更稳）")
    ap.add_argument("--max-tokens", type=int, default=None)
    ap.add_argument("--concurrency", type=int, default=1)
    ap.add_argument("--dry-run", action="store_true", help="只跑规则层，不调百炼、不落盘")
    ap.add_argument("--write-db", action="store_true",
                    help="append qc_audit_log / llm_usage（不改任何 facts）")
    ap.add_argument("--operator", default="cli")
    ap.add_argument("--pin-pairs-scan", action="store_true",
                    help="只扫差分对错位（零 token、零 PDF），统计全库受害面")
    ap.add_argument("--limit", type=int, default=0, help="--pin-pairs-scan 的扫描上限")
    ap.add_argument("--json-out", default="", help="--pin-pairs-scan 明细输出路径")
    args = ap.parse_args(argv)

    if args.pin_pairs_scan:
        return _pin_pair_scan(args)

    cfg = RV.env_config()
    if args.max_tokens:
        cfg["max_tokens"] = args.max_tokens
    if not args.dry_run and not cfg["key"]:
        print("DASHSCOPE_API_KEY 未设置；退出（--dry-run 可只跑规则层）",
              file=sys.stderr)
        return 2

    mpns = _targets(args)
    if not mpns:
        print("没有命中任何 MPN（检查 --mpn/--batch/--all-parsed）", file=sys.stderr)
        return 2

    # 断点续跑：已存在完整报告的跳过（dry_run 报告会被完整审查覆盖，不视为已完成）
    out_dir = Path(args.out_dir)
    todo = []
    for m in mpns:
        existing = RV.get_report(out_dir, RV._safe_stem(m))
        if existing and not existing.get("dry_run"):
            continue
        todo.append(m)
    print(f"[review] 待处理 {len(todo)}/{len(mpns)}（已存在完整报告的跳过）")

    def _one(mpn: str) -> dict:
        return RV.run_review(
            db, mpn, data_dir=args.data_dir, out_dir=out_dir,
            with_pdf_text=args.with_pdf_text, dry_run=args.dry_run,
            write_db=args.write_db, operator=args.operator, cfg=cfg)

    results: list[dict] = []
    if args.concurrency <= 1:
        for i, m in enumerate(todo, 1):
            try:
                r = _one(m)
            except RV.ReviewError as e:
                print(f"[{i}/{len(todo)}] {m} ERROR({e.code}): {e.message}",
                      file=sys.stderr)
                continue
            print(f"[{i}/{len(todo)}] {m} → {r['verdict']} "
                  f"(rule {len(r['rule_findings'])} / llm {len(r['llm_findings'])}, "
                  f"{r.get('wall_s', 0)}s)")
            results.append(r)
    else:
        with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
            futs = {ex.submit(_one, m): m for m in todo}
            for i, fut in enumerate(as_completed(futs), 1):
                m = futs[fut]
                try:
                    r = fut.result()
                except RV.ReviewError as e:
                    print(f"[{i}/{len(todo)}] {m} ERROR({e.code}): {e.message}",
                          file=sys.stderr)
                    continue
                print(f"[{i}/{len(todo)}] {m} → {r['verdict']} "
                      f"(rule {len(r['rule_findings'])} / llm {len(r['llm_findings'])})")
                results.append(r)

    agg = {"total": len(results), "PASS": 0, "WARN": 0, "FAIL": 0}
    for r in results:
        agg[r["verdict"]] = agg.get(r["verdict"], 0) + 1
    print(f"[review] 汇总 {agg}")
    if results and not args.dry_run:
        print(f"[review] 报告目录：{out_dir}")
    elif results and args.dry_run:
        print("[review] dry-run 不落报告；去掉 --dry-run 生成 json/md/html")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
