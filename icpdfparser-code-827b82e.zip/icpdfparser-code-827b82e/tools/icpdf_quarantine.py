#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""准入分流器：扫一个产物目录，按**生产同一道闸**给每件定准入结论，并写出台账。

它解决的问题
------------
batch100 收网时，「哪件该拦、哪件该放、哪件是板卡诚实空」这三件事靠人肉脚本一件件算：
手动移文件、手动拼台账、手动数电气行。同一个判据在三处各写一遍，改一处忘两处。
本工具把这段固化成一条命令，判据全部来自核心模块，不另写一份：

    validate()            parse_datasheets 的结构校验（正式桶计分）
    check_core/acceptance qc.deterministic_extract 的核心硬错误与型号级验收点
    source_has_container  源 PDF 文本层有没有该容器（决定「源无表」还是「抽丢了」）
    final_gate()          parse_datasheets 的最终闸门（结构先于核心、板卡不得借薄件通道）
    accept_thin()         parse_datasheets 的薄件通道（开关 + 板卡后缀 + 正文无电气表）
    _thin_doc_ok()        app.services.pipeline 的同样板薄件判据
    BOARD_TYPES           qc.scope_contract 的身份值域（板卡只认这一个来源）

三种准入结论（**互斥**，就这三种）
----------------------------------
| admission | 含义 | 能否进正式交付 |
|---|---|---|
| `normal` | 正常件：结构过、核心过（`thin_accepted` 也算这里，但打 `thin` 标、不计入 ok 分母） | 可以 |
| `allowlist_board` | 身份明确的板卡，**主桶**电气为 0，且**除「板卡零电气」外没有别的结构/核心错误** | 可以，但必须标列、不得计入 ok 分母 |
| `quarantine` | 结构错误、核心错误、身份不明、或任何无法确认的情况 | 不可以 |

这条边界是 2026-11-04 签核意见：
「板卡的零电气参数可以是合法业务状态；板卡的核心结构错误不能因为 allowlist 而被豁免。
这两件事必须分开。」于是：

* allowlist **只**豁免「板卡主桶电气为 0」这一项；
* 缺 `pin_configuration`、缺 `manufacturer`、缺必需键、身份无法确认 —— 一律隔离；
* 「是不是只有零电气这一类错误」这个问题**不在这里重新定义**，而是把身份抹掉后再问
  一次 `final_gate`：它若判 `thin_accepted`，说明这批错误只有板卡零电气那一类
  （`final_gate` 的薄件分支只在这种条件下触发）。判据只有一份，工具不持有副本。

为什么 allowlist 看主桶而不是正式桶
-----------------------------------
`validate()` 用正式桶（主桶 ∪ 板载器件桶）计分，所以板卡件能过 validate；
而「这件有没有器件级电气表」问的是主桶。batch100 的准入件主桶全为 0、
其中多件正式桶 ≥3 —— 用正式桶当判据会把它们全部漏掉。两个数都进台账，读者可自行复核。

扣押行（withheld_in_quarantine）为什么要单独喊一声
--------------------------------------------------
`final_gate` 的可放行类里，「电气条数不足」和「withheld_in_quarantine」是同一档，
所以板卡带扣押行仍会走 allowlist —— **这是核心口径的决定，工具不改判**。
但两者的业务含义差得远：主桶真空是「板卡本来没有器件级电气表」，
带扣押行则是「抽到了、但被列塌缩闸门拦下」。结论不改，标出来让人看：
`BOOSTXL-DRV8320H` 曾带 241 行扣押，交付前必须确认这批行该不该放回。

安全默认
--------
* **默认干跑**：只出报告、不动文件。要真移，加 `--apply`。
* 只移动**隔离件**的产物，绝不删除；目标已存在则跳过并记录。
* 台账跨运行**合并**：第二次运行不会把已有隔离记录洗成空（batch100 踩过）。
* 不写 `results.csv`、不改 JSON、不碰 `data/parsed`。

用法
----
    # 1) 先看：这批里谁会被拦、谁是板卡诚实空
    python tools/icpdf_quarantine.py --src data/batch100/stage

    # 2) 确认无误后真移
    python tools/icpdf_quarantine.py --src data/batch100/stage --apply

    # 3) 机器消费（stdout 只输出一段 JSON）
    python tools/icpdf_quarantine.py --src data/batch100/stage --json

退出码
------
    0  没有需要隔离的件
    1  有件被隔离（台账已写出，可 `--allow-quarantine` 强制返回 0）
    2  输入/环境错误（目录不存在、参数自相矛盾等）
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

SCHEMA = "icpdf-quarantine/v1"
TOOL_VERSION = "1.1.1"

#: 状态常量直接取自核心模块，不在这里抄字符串字面量（抄一份就会分叉）。
STATUS_OK = "ok"
STATUS_CORE_FAIL = "parsed_core_fail"
STATUS_THIN = "thin_accepted"
STATUS_FAILED = "failed"

#: 三种准入结论。**不要**在这三种之外再造第四种（清单与下游都按这三个值分支）。
ADM_NORMAL = "normal"
ADM_ALLOWLIST = "allowlist_board"
ADM_QUARANTINE = "quarantine"

#: 每类产物在装配根下的相对路径模板。用**显式文件名**而不是 `<safe>*` 前缀通配：
#: `ADS1252U` 与 `ADS1252UX` 这种前缀重叠的件，通配会把别人的文件一起搬走。
ARTIFACTS = (
    ("parsed", "{safe}.json"),
    ("pdfs", "{safe}.pdf"),
    ("pdfs", "{safe}__*.pdf"),
    ("seo", "{safe}.seo.json"),
    ("symbols", "{safe}.symbols.html"),
    ("txt", "{safe}.txt"),
    ("txt", "{safe}.i18n.json"),
    ("alts", "{safe}.alts.json"),
    ("alts", "{safe}.alts.html"),
)

_KEEP_ERR = 6


@dataclass
class Layout:
    """产物目录布局。装配根（parsed/ pdfs/ …）与平铺 JSON 目录都支持。"""

    root: Path
    parsed_dir: Path
    dirs: dict[str, Path] = field(default_factory=dict)
    flat: bool = False

    @classmethod
    def detect(cls, src: Path, pdf_dir: Path | None = None) -> Layout:
        src = src.resolve()
        if (src / "parsed").is_dir():
            dirs = {k: src / k for k in ("parsed", "pdfs", "seo", "symbols", "txt", "alts")}
            lay = cls(root=src, parsed_dir=src / "parsed", dirs=dirs, flat=False)
        else:
            lay = cls(root=src, parsed_dir=src, dirs={"parsed": src}, flat=True)
        if pdf_dir:
            lay.dirs["pdfs"] = pdf_dir.resolve()
        return lay

    def find_files(self, safe: str) -> list[Path]:
        """这一件的全部产物（parsed 必须存在，其余有就带上）。"""
        out: list[Path] = []
        for sub, tpl in ARTIFACTS:
            d = self.dirs.get(sub)
            if not d or not d.is_dir():
                continue
            for p in sorted(d.glob(tpl.format(safe=safe))):
                if p.is_file():
                    out.append(p)
        return out


def _core():
    """惰性导入核心模块：`--accept-thin` 要在导入前设好环境变量。"""
    import parse_datasheets as pd
    from qc import deterministic_extract as DE
    from qc.scope_contract import BOARD_TYPES
    from app import config

    try:                                     # 重量级（会拉 db/collector），失败则保守处理
        from app.services.pipeline import _thin_doc_ok
    except Exception as exc:                 # noqa: BLE001
        print(f"[warn] 取不到 _thin_doc_ok（{exc}），本批薄件通道按关闭处理", file=sys.stderr)
        _thin_doc_ok = None
    return pd, DE, BOARD_TYPES, config, _thin_doc_ok


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def resolve_mpn(doc: dict, path: Path) -> tuple[str, str, str]:
    """件身份：metadata.requested_mpn → basic_info.mpn → 文件名前缀。

    **请求号优先于文档自称**，这条是 batch100 教出来的：`AFE7950EVM` 的 JSON 里
    `basic_info.mpn` 写的是 `AFE7950`（模型按正文器件名填的），而交付包、台账、
    客户清单认的是请求号。若按文档自称为准，同一个件在两张表里叫两个名字，
    交接时就得靠人对；更糟的是 `AFE7900EVM` 那件 `basic_info.mpn` 直接是 `None`，
    按它建索引整件会消失。

    返回 `(件名, 文档自称, 取值来源)`；两者不一致时由调用方记 `name_conflict`。
    """
    doc_name = str((doc.get("basic_info") or {}).get("mpn") or "").strip()
    req = str((doc.get("metadata") or {}).get("requested_mpn") or "").strip()
    if req:
        return req, doc_name, "metadata.requested_mpn"
    if doc_name:
        return doc_name, doc_name, "basic_info.mpn"
    stem = path.stem
    if "_" in stem:
        stem = stem.rsplit("_", 1)[0]        # 去掉落盘时加的 8 位 hash
    if stem.strip():
        return stem.strip(), doc_name, "filename"
    return "", doc_name, "unresolved"


def _pdf_text(pd, pdf: Path | None, pages: int = 3) -> str:
    """取 PDF 前几页文本，只用于 `accept_thin` 的「正文有没有电气表」判定。"""
    if not pdf or not pdf.is_file():
        return ""
    try:
        text, _total, _used, _has = pd.extract_pdf_text(pdf, max_pages=pages)
        return text or ""
    except Exception as exc:                 # noqa: BLE001
        print(f"[warn] {pdf.name} 取文本失败：{exc}", file=sys.stderr)
        return ""


def _core_errs(pd, DE, doc: dict, mpn: str, pdf: Path | None) -> tuple[list[str], str]:
    """核心硬错误。有 PDF 时按**装配口径**算，没有就退回严格口径。

    为什么要分两种口径：`qc/stage_release.py::_revalidate` 在装配时会先看**源 PDF
    文本层有没有 thermal/ESD 表** —— 没有就记 `not_applicable`，不判失败（老 TI 手册
    常不印这两张表）；而 `check_core()` 在不传证据时按严格口径一律报错。batch100 的
    `ADS1252U` 就是典型：源文档确实没有 thermal/ESD 表，严格口径判 `parsed_core_fail`，
    装配口径判 pass —— 交付包里它是对的。

    所以本函数按 `_revalidate` 的调法组装同样的参数；**判据仍在 `check_core` 里**，
    这里只负责把证据（source_absent / withheld）找出来喂进去。那边改了这边要跟，
    测试 `test_thermal_absent_in_source_is_not_a_core_error` 就是钉子。
    """
    meta = doc.get("metadata") or {}
    det = meta.get("deterministic_extract")
    sp = doc.get("specs") or {}
    absent: set[str] = set()
    basis = "strict(无PDF证据)"

    if pdf and pdf.is_file():
        try:
            import pymupdf                                    # noqa: PLC0415
            with pymupdf.open(str(pdf)) as fd:
                basis = "assembly(源文档证据)"
                for k in ("thermal", "esd"):
                    if not (sp.get(k) or []) and not DE.source_has_container(fd, k):
                        absent.add(k)
        except Exception as exc:                              # noqa: BLE001
            print(f"[warn] {pdf.name} 探测容器失败，按严格口径：{exc}", file=sys.stderr)
            absent, basis = set(), "strict(PDF 打不开)"

    # 主动扣下的容器：容器空是**我们的决定**，不是源文档没有（同 `_revalidate`）。
    cs = meta.get("column_collapse_state") or {}
    withheld = {k for k in ("thermal", "esd")
                if k in (cs.get("containers") or []) and not (sp.get(k) or [])}

    errs = DE.check_core(doc, det, frozenset(absent), frozenset(withheld)) \
        + DE.check_acceptance(doc, mpn)
    return errs, basis


def only_board_empty_exception(pd, doc: dict, core_errs: list[str]) -> tuple[bool, str]:
    """这批结构错误是不是**只有**「板卡零电气」那一类。

    做法：把身份抹掉（当作芯片）再问一次 `final_gate`。
    `final_gate` 的薄件分支只在「错误全属可放行薄件类 ∧ 薄件允许 ∧ 不是板卡」时触发，
    所以它判 `thin_accepted` ⟺ 这批错误只有板卡零电气那类。

    为什么绕这一圈而不是在工具里判断错误前缀：判据只能有一份。
    工具自己抄一遍 `specs.electrical only` / `withheld_in_quarantine` 的前缀匹配，
    明天核心侧加一类可豁免错误，这里就会变成「更严」或「更松」的第二套标准。
    """
    if core_errs:
        return False, "有核心硬错"
    if not isinstance(doc, dict):
        return False, "文档结构异常"
    probe = copy.deepcopy(doc)
    bi = probe.get("basic_info")
    if isinstance(bi, dict):
        bi.pop("identity", None)             # 抹掉身份 → 按芯片问
    status, _errs = pd.final_gate(probe, core_errs, thin_allowed=True)
    if status == pd.STATUS_THIN_ACCEPTED:
        return True, "仅板卡零电气类错误（闸门判定）"
    return False, f"含非板卡零电气类结构错误（闸门判定 {status}）"


def judge(doc: dict, mpn: str, name: str, pdf: Path | None, core) -> dict:
    """单件判定。**只做组装** —— 每条判据都来自核心模块。"""
    pd, DE, BOARD_TYPES, config, thin_doc_ok = core
    meta = doc.get("metadata") or {}
    bi = doc.get("basic_info") or {}

    errs = pd.validate(doc)
    core_errs, core_basis = _core_errs(pd, DE, doc, mpn, pdf)

    # ---- 薄件通道：三条既有判据原样沿用，不新造 ----
    thin = False
    thin_why = ""
    if meta.get("accept_thin") is True:
        thin, thin_why = True, "metadata.accept_thin（解析时已判板卡/UG 无电气表）"
    elif config.ACCEPT_THIN and thin_doc_ok is not None and thin_doc_ok(doc):
        thin, thin_why = True, "_thin_doc_ok（引脚/特性兜底 + 置信度 ≥0.4）"
    elif pd.accept_thin(name, ""):
        # 名字像板卡套件 → accept_thin 的「正文无电气表」这一条必须靠真文本佐证。
        # 拿空串顶替会让该条恒真，等于把板卡放回薄件通道（batch100 的原错）。
        text = _pdf_text(pd, pdf)
        if text and pd.accept_thin(name, text):
            thin, thin_why = True, "accept_thin（板卡后缀 + 正文确无电气表）"
        elif text:
            thin_why = "名字像板卡套件，但正文有电气表 → 不走薄件"
        else:
            thin_why = "名字像板卡套件，取不到正文 → 不允许走薄件（无证据不放行）"

    gate_status, errs_final = pd.final_gate(doc, core_errs, thin_allowed=thin)

    fc = pd.spec_formal_counts(doc)
    sp = doc.get("specs") or {}
    elec_main = len(sp.get("electrical") or [])
    identity = str(bi.get("identity") or "").strip()
    identity_state = str(bi.get("identity_state") or "").strip()
    pins = len(doc.get("pin_configuration") or [])
    is_board = identity in BOARD_TYPES

    # ---- 与 JSON 自带的验收章对照：章不是权威，冲突要报 ----
    stamp = str(meta.get("accept_status") or "")
    if not stamp:
        verdict_source = "recomputed(无章)"
    elif stamp == gate_status:
        verdict_source = f"recomputed(章一致:{stamp})"
    else:
        verdict_source = f"recomputed(章={stamp} 冲突)"
    stamp_conflict = bool(stamp and stamp != gate_status)

    # ---- 准入三分类（顺序即优先级）----
    # 铁律：allowlist 只豁免「板卡主桶电气为 0」这一项，不豁免任何结构/核心错误。
    admission, adm_reason = ADM_QUARANTINE, ""
    if gate_status == STATUS_CORE_FAIL:
        adm_reason = "核心硬错：" + "；".join((core_errs or [])[:_KEEP_ERR])
    elif gate_status == STATUS_THIN:
        admission, adm_reason = ADM_NORMAL, "解析层明确收下的薄件；交付须标列、不计入 ok 分母"
    elif gate_status == STATUS_OK:
        if is_board and elec_main == 0:
            admission, adm_reason = ADM_ALLOWLIST, "板卡主桶电气为 0（诚实空），其余检查通过"
        else:
            admission, adm_reason = ADM_NORMAL, "结构与核心均通过"
    elif gate_status == STATUS_FAILED:
        if not is_board:
            adm_reason = "结构不过：" + "；".join(errs_final[:_KEEP_ERR])
        elif core_errs:
            adm_reason = "板卡但有核心硬错：" + "；".join(core_errs[:_KEEP_ERR])
        else:
            ok_empty, why = only_board_empty_exception(pd, doc, core_errs)
            if elec_main == 0 and ok_empty:
                admission = ADM_ALLOWLIST
                adm_reason = "板卡主桶电气为 0，且无其他结构错误（" + why + "）"
            else:
                adm_reason = "板卡但" + why + "：" + "；".join(errs_final[:_KEEP_ERR])

    reasons = [adm_reason] if adm_reason else []
    if stamp_conflict:
        reasons.append(f"JSON 章写 {stamp}，现场复判为 {gate_status}（以现场为准）")

    # 扣押行必须响：`withheld_in_quarantine` 在 `final_gate` 里与「电气不足」同属薄件类，
    # 所以板卡带扣押行仍会走 allowlist —— **这是核心口径的决定，工具不改判**。
    # 但「主桶为空」在有没有扣押行时语义不同：前者是诚实空，后者是抽到了被拦下。
    # 不改结论，只把它标出来，交付前必须人看一眼（BOOSTXL-DRV8320H 曾带 241 行）。
    withheld_n = fc.get("_withheld", 0)
    if admission == ADM_ALLOWLIST and withheld_n:
        reasons.append(f"有 {withheld_n} 行被扣押（withheld_in_quarantine），主桶为空不是完全"
                       "诚实空；按核心口径仍属薄件类放行，交付前须人工确认这批行该不该放回")

    return {
        "mpn": mpn,
        "doc_mpn": str(bi.get("mpn") or "").strip(),
        "identity": identity,
        "identity_source": "basic_info.identity" if identity else "missing",
        "identity_state": identity_state,
        "final_gate_status": gate_status,
        "accept_status": stamp,
        "stamp_conflict": stamp_conflict,
        "verdict_source": verdict_source,
        "admission": admission,
        "override_reason": (adm_reason if admission == ADM_ALLOWLIST
                            and gate_status != STATUS_OK else ""),
        "validate_errors": errs[:_KEEP_ERR],
        "core_errs": core_errs[:_KEEP_ERR],
        "core_basis": core_basis,
        "electrical_main": elec_main,
        "formal_elec": fc.get("electrical", 0),
        "withheld": fc.get("_withheld", 0),
        "pins": pins,
        "thin": gate_status == STATUS_THIN,
        "thin_why": thin_why,
        "is_board": is_board,
        "reasons": reasons,
    }


def scan(lay: Layout, core, read_text: bool = True) -> list[dict]:
    files = sorted(p for p in lay.parsed_dir.glob("*.json") if p.is_file())
    out: list[dict] = []
    for p in files:
        safe = p.stem
        pdf = None
        d = lay.dirs.get("pdfs")
        if d and d.is_dir():
            for pat in (f"{safe}.pdf", f"{safe}__*.pdf"):
                hit = sorted(d.glob(pat))
                if hit:
                    pdf = hit[0]
                    break
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:             # noqa: BLE001
            out.append({"mpn": "", "safe": safe, "file": p.name, "mpn_unresolved": True,
                        "final_gate_status": STATUS_FAILED, "admission": ADM_QUARANTINE,
                        "identity": "", "identity_source": "unreadable",
                        "identity_state": "", "electrical_main": 0, "formal_elec": 0,
                        "pins": 0, "thin": False, "thin_why": "", "accept_status": "",
                        "stamp_conflict": False, "verdict_source": "unreadable",
                        "is_board": False, "validate_errors": [], "core_errs": [],
                        "core_basis": "", "withheld": 0, "doc_mpn": "", "name_conflict": False,
                        "mpn_source": "", "override_reason": "", "source_pdf_hash": "",
                        "reasons": [f"JSON 读不开：{exc}"]})
            continue
        mpn, doc_mpn, mpn_src = resolve_mpn(doc, p)
        rec = judge(doc, mpn, p.name, pdf if read_text else None, core)
        rec["mpn_source"] = mpn_src
        rec["name_conflict"] = bool(doc_mpn and mpn and doc_mpn != mpn)
        rec["safe"] = safe
        rec["file"] = p.name
        rec["sha256"] = _sha(p)
        rec["source_pdf_hash"] = _sha(pdf) if pdf else ""
        if not mpn:
            rec["mpn_unresolved"] = True
            rec["admission"] = ADM_QUARANTINE
            rec["reasons"] = (rec.get("reasons") or []) + ["件身份无法确定（mpn 三级回退全空）"]
        out.append(rec)
    return out


def _load_ledger(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:                        # noqa: BLE001
        return {}


def merge_ledger(old: dict, new_items: list[dict], run: dict) -> dict:
    """按 mpn 合并：新结论覆盖旧的；旧件没再出现也保留（它可能已被移走）。"""
    if not old or old.get("schema") != SCHEMA:
        old = {"schema": SCHEMA, "items": [], "runs": []}
    by = {str(it.get("mpn") or it.get("safe") or ""): it for it in old.get("items") or []}
    for it in new_items:
        by[str(it.get("mpn") or it.get("safe") or "")] = it
    items = [by[k] for k in sorted(by)]
    runs = list(old.get("runs") or []) + [run]
    counts: dict[str, int] = {}
    for it in items:
        key = it.get("admission") or "unknown"
        counts[key] = counts.get(key, 0) + 1
    return {"schema": SCHEMA, "items": items, "runs": runs, "counts": counts}


def write_csv(path: Path, columns: list[str], rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(columns)
        w.writerows(rows)


def move_quarantined(lay: Layout, out_dir: Path, items: list[dict]) -> int:
    """把隔离件的产物搬到 out_dir 下同名子目录。只移动、不删除、不覆盖。"""
    moved = 0
    for it in items:
        if it.get("admission") != ADM_QUARANTINE:
            continue
        safe = it.get("safe") or it.get("mpn")
        files = lay.find_files(safe)
        it["files_moved"] = []
        for src in files:
            dst = out_dir / src.parent.name / src.name
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                it["files_moved"].append(f"{src.parent.name}/{src.name}(已存在，跳过)")
                continue
            shutil.move(str(src), str(dst))
            it["files_moved"].append(f"{src.parent.name}/{src.name}")
            moved += 1
    return moved


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="icpdf_quarantine",
        description="按生产同一道闸给解析产物定准入：normal / allowlist_board / quarantine。")
    ap.add_argument("--src", required=True, help="装配根（含 parsed/）或平铺 JSON 目录")
    ap.add_argument("--out", default="", help="隔离与台账输出目录，默认 <src>/../_quarantine")
    ap.add_argument("--pdf-dir", default="", help="PDF 目录（默认取 <src>/pdfs）")
    ap.add_argument("--apply", action="store_true", help="真正移动文件（默认只出报告）")
    ap.add_argument("--accept-thin", action="store_true",
                    help="强制打开 ICPDF_ACCEPT_THIN（默认跟随环境变量）")
    ap.add_argument("--no-pdf-text", action="store_true",
                    help="完全不读 PDF：核心校验退回严格口径（源文档本就没有 thermal/ESD "
                         "表的件会被误报为 hard error），薄件也因缺正文证据而不放行")
    ap.add_argument("--force", action="store_true", help="重建台账（丢弃历史 runs/items）")
    ap.add_argument("--allow-quarantine", "--allow-blocked", dest="allow_quarantine",
                    action="store_true", help="有隔离件也返回 0")
    ap.add_argument("--json", action="store_true", help="stdout 只输出一段 JSON 摘要")
    ap.add_argument("--version", action="version", version=f"icpdf_quarantine {TOOL_VERSION}")
    a = ap.parse_args(argv)

    src = Path(a.src).expanduser()
    if not src.is_dir():
        print(f"[error] 源目录不存在：{src}", file=sys.stderr)
        return 2
    if a.accept_thin:
        os.environ["ICPDF_ACCEPT_THIN"] = "1"

    out_dir = Path(a.out).expanduser() if a.out else src.resolve().parent / "_quarantine"
    if a.apply and out_dir.resolve() == src.resolve():
        print("[error] --out 不能等于 --src（会把整批件搬进自己）", file=sys.stderr)
        return 2

    lay = Layout.detect(src, Path(a.pdf_dir) if a.pdf_dir else None)
    core = _core()
    items = scan(lay, core, read_text=not a.no_pdf_text)

    ledger_path = out_dir / "quarantine_ledger.json"
    old = {} if a.force else _load_ledger(ledger_path)
    moved = move_quarantined(lay, out_dir, items) if a.apply else 0

    counts: dict[str, int] = {}
    for it in items:
        counts[it["admission"]] = counts.get(it["admission"], 0) + 1
    run = {
        "at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "tool": f"icpdf_quarantine {TOOL_VERSION}",
        "src": str(src.resolve()),
        "applied": bool(a.apply),
        "files_moved": moved,
        "counts": counts,
        "thin": sum(1 for it in items if it.get("thin")),
        "env": {"ICPDF_ACCEPT_THIN": os.getenv("ICPDF_ACCEPT_THIN", "(未设)")},
    }
    ledger = merge_ledger(old, items, run)
    ledger["generated"] = run["at"]
    ledger["rules"] = {
        "gate": "final-gate-v1（parse_datasheets.final_gate）",
        "statuses": [STATUS_OK, STATUS_CORE_FAIL, STATUS_THIN, STATUS_FAILED],
        "admission": {
            ADM_NORMAL: "结构过 + 核心过；thin_accepted 归此类但打 thin 标、不计入 ok 分母",
            ADM_ALLOWLIST: "identity ∈ BOARD_TYPES ∧ 主桶 electrical == 0 ∧ 无核心硬错 ∧ "
                           "除板卡零电气外无其他结构错误（由 final_gate 复核判定）",
            ADM_QUARANTINE: "结构错误 / 核心错误 / 身份不明",
        },
        "board_empty_exception": "把身份抹掉再问一次 final_gate：判 thin_accepted 才算"
                                 "「只有板卡零电气类错误」，工具不另写前缀匹配",
        "withheld": "板卡准入件若带 withheld_in_quarantine 行，结论不变（核心口径把它与"
                    "电气不足同归薄件类），但台账与 allowlist 都会标出，交付前须人工确认",
        "core_basis": "有 PDF 时按装配口径取证（源文档无 thermal/ESD 表 → not_applicable），"
                      "无 PDF 时按严格口径",
        "note": "JSON 自带的 metadata.accept_status 只作对照，冲突以现场复判为准",
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")

    cols = ["mpn", "doc_mpn", "name_conflict", "identity", "identity_source",
            "identity_state", "admission", "final_gate_status", "accept_status",
            "stamp_conflict", "elec_main", "formal_elec", "withheld", "pins", "thin",
            "override_reason", "validate_errors", "core_errs", "source_pdf_hash",
            "reasons", "files_moved"]
    write_csv(out_dir / "quarantine.csv", cols,
              [[it.get("mpn", ""), it.get("doc_mpn", ""), it.get("name_conflict", False),
                it.get("identity", ""), it.get("identity_source", ""),
                it.get("identity_state", ""), it.get("admission", ""),
                it.get("final_gate_status", ""), it.get("accept_status", ""),
                it.get("stamp_conflict", False), it.get("electrical_main", 0),
                it.get("formal_elec", 0), it.get("withheld", 0), it.get("pins", 0),
                it.get("thin", False),
                it.get("override_reason", ""),
                "；".join(it.get("validate_errors") or []),
                "；".join(it.get("core_errs") or []), it.get("source_pdf_hash", ""),
                "；".join(it.get("reasons") or []),
                "；".join(it.get("files_moved") or [])] for it in items])

    allow = [it for it in items if it.get("admission") == ADM_ALLOWLIST]
    write_csv(out_dir / "allowlist.csv",
              ["mpn", "identity", "identity_source", "elec_main", "formal_elec", "withheld",
               "pins", "final_gate_status", "override_reason", "by", "why"],
              [[it["mpn"], it["identity"], it["identity_source"], it["electrical_main"],
                it["formal_elec"], it.get("withheld", 0), it["pins"], it["final_gate_status"],
                it.get("override_reason", ""),
                f"icpdf_quarantine {TOOL_VERSION}（rule v2：只豁免板卡零电气）",
                "板卡件：电气参数在 onboard_device_specs，主桶空是诚实空"
                + (f"；但有 {it['withheld']} 行被扣押，交付前须人工确认"
                   if it.get("withheld") else "")] for it in allow])

    quarantined = [it for it in items if it.get("admission") == ADM_QUARANTINE]
    if a.json:
        print(json.dumps({"schema": SCHEMA, "run": run, "counts": ledger["counts"],
                          "ledger": str(ledger_path),
                          "quarantine": [it["mpn"] or it["safe"] for it in quarantined],
                          "thin": [it["mpn"] for it in items if it.get("thin")],
                          "allowlist": [it["mpn"] for it in allow]},
                         ensure_ascii=False, indent=2))
    else:
        mode = "已移动文件" if a.apply else "干跑（加 --apply 才移动）"
        print(f"源目录 : {src.resolve()}   模式：{mode}")
        print(f"台账   : {ledger_path}")
        for it in items:
            if it["admission"] == ADM_NORMAL and not it.get("thin"):
                continue
            tag = {ADM_NORMAL: "薄件", ADM_ALLOWLIST: "板卡准入",
                   ADM_QUARANTINE: "隔离"}[it["admission"]]
            extra = ""
            if it["admission"] == ADM_QUARANTINE:
                extra = "；" + (it.get("reasons") or [""])[0]
            elif it["admission"] == ADM_ALLOWLIST:
                extra = f"；主桶电{it['electrical_main']} 正式桶{it['formal_elec']}"
                if it.get("override_reason"):
                    extra += "（" + it["override_reason"] + "）"
            print(f"  [{tag}] {it.get('mpn') or it.get('safe'):<24}{extra}")
        print(f"\n合计 {len(items)} 件：" +
              " / ".join(f"{k} {v}" for k, v in sorted(counts.items())) +
              f"（其中薄件 {run['thin']} 件）")
        conflicts = [it for it in items if it.get("stamp_conflict")]
        if conflicts:
            print(f"[注意] {len(conflicts)} 件的 JSON 验收章与现场复判不一致（以现场为准）："
                  + "、".join(it["mpn"] for it in conflicts))
        risky = [it for it in allow if it.get("withheld")]
        if risky:
            print(f"[须人工确认] {len(risky)} 件板卡准入带扣押行（withheld_in_quarantine）："
                  + "、".join(f"{it['mpn']}({it['withheld']}行)" for it in risky)
                  + " —— 结论不改（核心口径归薄件类），但交付前必须确认这批行该不该放回")

    if quarantined and not a.allow_quarantine:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
