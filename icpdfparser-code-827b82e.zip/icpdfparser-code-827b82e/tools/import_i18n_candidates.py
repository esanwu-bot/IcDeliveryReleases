"""导入多语言候选快照并跑 LQA 门禁。

    python tools/import_i18n_candidates.py --src data/i18n_candidates/pilot10/v3 \
        --base data/i18n_candidates/pilot10/before --batch pilot10 --revision v3

只写 i18n_* 表；同一 (batch, revision, filename) 重复执行是幂等的（不会覆盖已有快照）。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import db                                    # noqa: E402
from app.services import i18n_qa as Q                 # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="候选 JSON 目录")
    ap.add_argument("--base", default="", help="对应的生产原件目录（计算 base_sha256 用）")
    ap.add_argument("--batch", required=True)
    ap.add_argument("--revision", required=True)
    ap.add_argument("--model", default="qwen-flash")
    ap.add_argument("--scope", default="full")
    ap.add_argument("--no-lqa", action="store_true", help="只导入不跑门禁")
    ap.add_argument("--operator", default="cli")
    a = ap.parse_args()

    src = Path(a.src)
    if not src.is_dir():
        print(f"目录不存在：{src}", file=sys.stderr)
        return 2
    base = Path(a.base) if a.base else None
    db.conn()
    seed = Q.ensure_seed(a.operator)
    print(f"种子：术语 +{seed['glossary']} / 禁用词 +{seed['banned']}")

    ok = fail = 0
    verdicts: dict[str, int] = {}
    for p in sorted(src.glob("*.json")):
        try:
            raw = p.read_bytes()
            doc = json.loads(raw.decode("utf-8"))
            bdoc = None
            if base and (base / p.name).exists():
                bdoc = json.loads((base / p.name).read_text(encoding="utf-8"))
            c = Q.import_candidate(a.batch, a.revision, p.name, doc, model=a.model,
                                   scope=a.scope, base_doc=bdoc, raw=raw, operator=a.operator)
            if a.no_lqa:
                print(f"  导入 {p.name} → #{c['id']}")
                ok += 1
                continue
            r = Q.run_lqa(c["id"], a.operator)
            verdicts[r["verdict"]] = verdicts.get(r["verdict"], 0) + 1
            print(f"  {r['verdict']:5s} {p.name:38s} 格 {r['total']:2d} "
                  f"PASS {r['counts']['PASS']:2d} WARN {r['counts']['WARN']:2d} "
                  f"FAIL {r['counts']['FAIL']:2d}")
            ok += 1
        except Exception as e:                        # noqa: BLE001
            fail += 1
            print(f"  ERROR {p.name}: {e}", file=sys.stderr)
    print(f"\n完成：{a.batch}/{a.revision} 导入 {ok} 件，失败 {fail} 件，判定分布 {verdicts}")
    return 1 if fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
