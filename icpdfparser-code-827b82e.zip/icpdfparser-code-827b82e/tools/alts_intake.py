#!/usr/bin/env python
"""替代料「运营侧收录」清单生成器（不调 LLM）。

背景：`ADC12DJ5200SE` 的三条错候选，错法完全一致 —— 模型把「系列名 / 速度档」
当成了可订购号（`AD9680-1000` 实为 `AD9680BCPZ-1000`）。目录里本来就有正确码，
所以这不是「缺料」，而是**命名不规范 + 目录无法按同族反查**。

本脚本做两件事，只读、只出 CSV，不写库：
  1. 对每个请求型号，按**器件前缀**在 `products.sqlite3` 里反查同族可订购码，
     给出「可直接内链」的清单（这些是站内已有页面，能立刻挂上去）；
  2. 把上一版门禁剔除的候选逐条对照目录，标成 `link / sourcing / blacklist`
     三种处置，作为运营补数据的工单。

为什么按前缀而不按 `catalog.base`：实测 `base` 恒等于 `key`（每个可订购码
自成一族），用它反查同族恒返回 1 行，等于没有分组能力。

用法：
    python tools/alts_intake.py [--index data/products.sqlite3]
                                [--rejected data/alts/_rejected]
                                [--out data/alts/_intake]
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# 请求型号 -> 板载/同族器件前缀。评估板类必须显式给出器件前缀，
# 因为板子本身（BOOSTXL-*/ADS8568EVM）在站内目录里没有页面。
DEVICE_PREFIX = {
    "ADS1201U-1/1K": "ADS1201U",
    "ADS8568EVM-PDK": "ADS8568",
    "BOOST-DRV8711": "DRV8711",
    "ADC12DJ5200SE": "ADC12DJ5200SE",
    "BOOSTXL-C2KLED": "BOOSTXL",     # 预期 0 条：站内不收录评估板
}

# 已取证为「原厂不存在」的料号，永久拉黑（见 qc/evidence_20261031/二次确认…§7.3）
BLACKLIST = {
    "ADS8V11": "TI 三种标准 URL 全 404，产品不存在（§7.3 已取证）",
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default=str(ROOT / "data" / "products.sqlite3"))
    ap.add_argument("--rejected", default=str(ROOT / "data" / "alts" / "_rejected"))
    ap.add_argument("--out", default=str(ROOT / "data" / "alts" / "_intake"))
    a = ap.parse_args()

    con = sqlite3.connect(f"file:{Path(a.index).as_posix()}?mode=ro", uri=True)
    cur = con.cursor()

    rejected: dict[str, list[dict]] = {}
    for f in sorted(Path(a.rejected).glob("*.json")):
        doc = json.loads(f.read_text(encoding="utf-8"))
        rejected[doc["mpn"]] = doc.get("rejected") or []

    rows: list[dict] = []
    for req, prefix in DEVICE_PREFIX.items():
        cands = cur.execute(
            "SELECT mpn,url FROM catalog WHERE mpn LIKE ? COLLATE NOCASE "
            "ORDER BY LENGTH(mpn), mpn", (prefix + "%",)).fetchall()
        # 请求型号自己是否在库。不在库时，目录里「以它开头的更长码」就是它本人的
        # 可订购号（ADC12DJ5200SE -> ADC12DJ5200SEAAV），不是替代料，必须排除。
        # 反之在库时不能按前缀排（ADS1201U-1/1K 在库，ADS1201U-1 是另一个订货码）。
        req_in_catalog = cur.execute(
            "SELECT 1 FROM catalog WHERE mpn=? COLLATE NOCASE", (req,)).fetchone()
        # 1) 站内已有、可直接内链的同族可订购码
        links = []
        for mpn, url in cands:
            if _same(req, mpn):
                continue
            if not req_in_catalog and _same_prefix(req, mpn):
                continue
            links.append({"requested_mpn": req, "kind": "link", "mpn": mpn, "url": url,
                          "action": "直接内链（站内已有页面）",
                          "evidence": f"目录前缀 {prefix}% 命中"})
        rows.extend(links)
        if not links:
            rows.append({
                "requested_mpn": req, "kind": "gap", "mpn": "", "url": "",
                "action": "运营侧补录（站内无同族替代页面）",
                "evidence": f"目录前缀 {prefix}% 命中 {len(cands)} 条，"
                            f"其中均为本型号自身可订购号" if cands else
                            f"目录前缀 {prefix}% 命中 0 条",
            })
        # 2) 上一版被剔除的候选，逐条给处置
        for r in rejected.get(req, []):
            m = r.get("mpn") or ""
            if m in BLACKLIST:
                kind, action, ev = "blacklist", "拉黑，不再提议", BLACKLIST[m]
            elif re.fullmatch(r"(?i)n/?a", m.strip()):
                kind, action, ev = "undetermined", "模型主动写 N/A，按工单补录", "模型认不准"
            elif r.get("reject_reason") == "mpn_undetermined":
                kind, action, ev = "undetermined", "模型主动写 N/A，按工单补录", "模型认不准"
            else:
                kind = "sourcing"
                action = "待人工核对完整可订购号"
                ev = f"目录精确命中 0 条（match={r.get('match')}）"
            rows.append({
                "requested_mpn": req, "kind": kind, "mpn": m, "url": "",
                "action": action, "evidence": ev,
            })

    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"运营侧收录_{time.strftime('%Y%m%d')}.csv"
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["requested_mpn", "kind", "mpn",
                                           "url", "action", "evidence"])
        w.writeheader()
        w.writerows(rows)

    stat: dict[str, int] = {}
    for r in rows:
        stat[r["kind"]] = stat.get(r["kind"], 0) + 1
    print(f"[out] {out}  {len(rows)} 行")
    print("[stat]", ", ".join(f"{k}={v}" for k, v in sorted(stat.items())))


def _same(req: str, mpn: str) -> bool:
    """请求型号与目录料号是否同一件（忽略分隔符）。"""
    n = lambda s: re.sub(r"[^A-Z0-9]", "", (s or "").upper())      # noqa: E731
    return n(req) == n(mpn)


def _same_prefix(req: str, mpn: str) -> bool:
    """目录料号是否是请求型号的「更长写法」（= 它本人的可订购号）。"""
    n = lambda s: re.sub(r"[^A-Z0-9]", "", (s or "").upper())      # noqa: E731
    a, b = n(req), n(mpn)
    return bool(a) and b.startswith(a) and len(b) > len(a)


if __name__ == "__main__":
    main()
