"""把人工审查 CSV 导入审校问题台账（i18n_review_issue）。

CSV 列（来自 docs/qc/i18n_pilot10_v3_rules_*.csv）：
    id,file,lang,field,index,occurrences,old,new,rationale

问题登记到「缺陷所在的候选版本」（例如 v2），old 作为 tgt_ev 证据，英文源从候选字段自动取，
rationale 里追加修复说明。只 INSERT，不改候选，也不写记忆库。
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import db                                    # noqa: E402
from app.services import i18n_qa as Q                 # noqa: E402

_CAT = {"omission": "omission", "entity": "entity_integrity", "style": "style"}


def category_of(rule_id: str, field: str) -> str:
    if "10" in rule_id and field == "meta":
        return "omission"
    if field in ("features", "applications"):
        return "terminology"
    return "terminology"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--batch", required=True)
    ap.add_argument("--revision", required=True, help="缺陷所在的候选版本")
    ap.add_argument("--verdict", default="fixed", choices=["open", "accepted", "fixed", "rejected"])
    ap.add_argument("--operator", default="review-2026-10-29")
    a = ap.parse_args()

    db.conn()
    rows = list(csv.DictReader(Path(a.csv).open(encoding="utf-8-sig")))
    cache: dict[str, dict] = {}
    added = skipped = 0
    for r in rows:
        mpn = (r.get("file") or "").strip()
        if not mpn:
            continue
        if mpn not in cache:
            c = db.q1("SELECT * FROM i18n_candidate WHERE batch=? AND revision=? AND mpn=? "
                      "ORDER BY id DESC LIMIT 1", (a.batch, a.revision, mpn))
            if not c:
                # CSV 用的是文件名去哈希后缀，可能与 basic_info.mpn 有包装后缀差异
                c = db.q1("SELECT * FROM i18n_candidate WHERE batch=? AND revision=? "
                          "AND (filename LIKE ? OR mpn LIKE ?) ORDER BY id DESC LIMIT 1",
                          (a.batch, a.revision, mpn + "%", "%" + mpn))
            cache[mpn] = c or {}
        c = cache[mpn]
        if not c:
            print(f"  SKIP 找不到候选 {a.batch}/{a.revision}/{mpn}", file=sys.stderr)
            skipped += 1
            continue
        lang = (r.get("lang") or "").strip()
        field = (r.get("field") or "").strip()
        idx = int(r["index"]) if (r.get("index") or "").strip() else -1
        en = ""
        f = db.q1("SELECT en FROM i18n_candidate_field WHERE candidate_id=? AND lang=? AND field=? "
                  "AND idx=?", (c["id"], lang, field, idx))
        if f:
            en = f["en"] or ""
        rid = (r.get("id") or "").strip()
        sev = "P0" if rid.startswith("P0") else "P1"
        rationale = (r.get("rationale") or "").strip()
        new = (r.get("new") or "").strip()
        if new:
            rationale += f"｜修订为：{new[:160]}"
        dup = db.q1("SELECT id FROM i18n_review_issue WHERE candidate_id=? AND lang=? AND field=? "
                    "AND idx=? AND rationale=?", (c["id"], lang, field, idx, rationale[:2000]))
        if dup:
            continue
        iid = Q.review_issue_add({
            "candidate_id": c["id"], "lang": lang, "field": field, "idx": idx,
            "category": category_of(rid, field), "severity": sev,
            "src_ev": en[:1000], "tgt_ev": (r.get("old") or "")[:1000],
            "rationale": rationale,
        }, a.operator)
        if a.verdict != "open":
            Q.review_issue_decide(iid["id"], a.verdict, a.operator)
        added += 1
    print(f"导入 {added} 条审校问题（{a.batch}/{a.revision}，verdict={a.verdict}），跳过 {skipped}")
    return 1 if skipped else 0


if __name__ == "__main__":
    raise SystemExit(main())
