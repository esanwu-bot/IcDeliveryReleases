#!/usr/bin/env python
"""对**已有** alts.json 重跑「可订购号精确匹配」门禁，不调用 LLM。

与 `alternatives.py::run_one` 尾部行为一致（enforce_orderable → 重写 json →
render_section → 0 条不落空文件），区别只在于候选是上一版已生成的，
本脚本不做任何模型调用、不重新提议候选。

用途：重打包（如 `delivery-20261031-V3`）时，让旧候选也过一遍新门禁，
而不必为了「重新生成候选」再烧一次模型调用 —— 候选是同一批，门禁是新规则。

用法：
    python tools/apply_alts_gate.py <alts_dir> [--index data/products.sqlite3]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import alternatives as A  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("alts_dir")
    ap.add_argument("--index", default=str(ROOT / "data" / "products.sqlite3"))
    ap.add_argument("--reject-dir", default=str(ROOT / "data" / "alts" / "_rejected"))
    a = ap.parse_args()

    d = Path(a.alts_dir)
    idx = A.Index().load(Path(a.index))
    print(f"[index] {a.index} -> {len(idx)} 料号")
    rej_dir = Path(a.reject_dir)
    rej_dir.mkdir(parents=True, exist_ok=True)

    for f in sorted(d.glob("*.alts.json")):
        doc = json.loads(f.read_text(encoding="utf-8"))
        mpn = doc.get("mpn") or f.stem
        rows = doc.get("alternatives") or []
        kept, rejected = A.enforce_orderable(rows, idx)
        stem = f.name[: -len(".alts.json")]
        doc["alternatives"] = kept
        und = sum(1 for r in rejected if r.get("reject_reason") == "mpn_undetermined")
        doc["gate"] = {
            "rule": "orderable_part_number_exact_match",
            "applied_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "input": len(rows), "kept": len(kept), "rejected": len(rejected),
            "undetermined": und,
            "note": "只保留在 products.sqlite3 精确命中的完整可订购号；其余进 _rejected 审计，不进交付",
        }
        f.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
        if rejected:
            (rej_dir / f"{stem}.json").write_text(json.dumps(
                {"mpn": mpn, "applied_at": doc["gate"]["applied_at"],
                 "rule": "orderable_part_number_exact_match", "rejected": rejected},
                ensure_ascii=False, indent=2), encoding="utf-8")

        html_path = d / f"{stem}.alts.html"
        html = A.render_section(mpn, kept, doc.get("manufacturer") or "", only_linked=True)
        if html.strip():
            html_path.write_text(html, encoding="utf-8")
        elif html_path.exists():
            html_path.unlink()
        print(f"[{mpn:<18}] {len(rows)} → {len(kept)}（剔除 {len(rejected)}）"
              f" html={'有' if html.strip() else '无'}")


if __name__ == "__main__":
    main()
