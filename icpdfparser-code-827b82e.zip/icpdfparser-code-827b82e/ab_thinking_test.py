#!/usr/bin/env python
"""A/B 验证：百炼 qwen-flash 开/关思考的 token、耗时与质量差异（临时脚本）。

Phase 1: 小探针 —— 默认(不带参) vs enable_thinking=false，看 usage 明细
Phase 2: 10 个真实样本关思考（有 agnes 基线可对比质量）+ 2 个同样本开思考对照

样本从 workbench 库 item 表选（status=done 且真跑过 parse 的件），
产物写 data/parsed_abtest/ 与 data/parsed_abtest_ctrl/，不动正式 data/parsed/。
用法: python ab_thinking_test.py
"""
from __future__ import annotations

import json
import re
import sqlite3
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

import parse_datasheets as pd

ROOT = pd.ROOT
PARSED = ROOT / "data" / "parsed"
AB_OUT = ROOT / "data" / "parsed_abtest"
CTRL_OUT = ROOT / "data" / "parsed_abtest_ctrl"
AB_OUT.mkdir(parents=True, exist_ok=True)
CTRL_OUT.mkdir(parents=True, exist_ok=True)

assert pd.DASHSCOPE_KEY, "DASHSCOPE_API_KEY 未配置（.env.local）"
pd.API_BASE, pd.API_KEY, pd.MODEL = pd.DASHSCOPE_BASE, pd.DASHSCOPE_KEY, pd.DASHSCOPE_MODEL
pd.OUT_DIR = AB_OUT
pd.TIMEOUT = 360                     # 开思考的对照组解码慢，放宽
print(f"[setup] backend=dashscope model={pd.MODEL} enable_thinking={pd.ENABLE_THINKING}")

# ---- 记录每次 chat 的耗时与 usage（parse/repair 分开）
_calls: list[dict] = []
_orig_chat = pd.chat


def _wrapped_chat(messages, **kw):
    t0 = time.perf_counter()
    stage = "repair" if len(messages) > 2 else "parse"
    try:
        content, usage = _orig_chat(messages, **kw)
    except Exception as e:                                    # noqa: BLE001
        _calls.append({"stage": stage, "secs": round(time.perf_counter() - t0, 1),
                       "usage": {}, "ok": False, "err": f"{type(e).__name__}: {e}"[:150]})
        raise
    _calls.append({"stage": stage, "secs": round(time.perf_counter() - t0, 1),
                   "usage": usage or {}, "ok": True})
    return content, usage


pd.chat = _wrapped_chat

HDRS = {"Authorization": f"Bearer {pd.API_KEY}", "Content-Type": "application/json"}


# ---------------------------------------------------------------- Phase 1: 探针
def probe(label: str, extra: dict | None) -> dict:
    payload = {"model": pd.MODEL,
               "messages": [{"role": "system", "content": "你是 JSON 生成器，只输出 JSON。"},
                            {"role": "user", "content": '输出 {"a": 1, "b": "hello", "c": [1,2,3]}'}],
               "temperature": 0.1, "max_tokens": 2000,
               "response_format": {"type": "json_object"}}
    if extra:
        payload.update(extra)
    t0 = time.perf_counter()
    try:
        r = requests.post(f"{pd.API_BASE}/chat/completions", headers=HDRS,
                          json=payload, timeout=300)
    except Exception as e:                                    # noqa: BLE001
        return {"label": label, "exc": str(e)[:150]}
    secs = round(time.perf_counter() - t0, 1)
    if r.status_code != 200:
        return {"label": label, "http": r.status_code, "err": r.text[:200], "secs": secs}
    d = r.json()
    return {"label": label, "http": 200, "secs": secs,
            "usage": d.get("usage", {}),
            "finish": d["choices"][0].get("finish_reason"),
            "content": (d["choices"][0]["message"]["content"] or "")[:60]}


print("\n=== Phase 1: API 探针（同一个小任务，max_tokens=2000） ===")
for p in (probe("默认(不带参数)", None),
          probe("enable_thinking=false", {"enable_thinking": False})):
    print(json.dumps(p, ensure_ascii=False)[:500])

# ---------------------------------------------------------------- 选样（workbench 库）
BOARD_RE = re.compile(r"(EVM|EVAL|EVK|EMK|EVB|KIT|BOARD|BOOST|DEM-|MODULE|INTERFACE|2MTR)", re.I)
db = sqlite3.connect(ROOT / "data" / "workbench.sqlite3")
db.row_factory = sqlite3.Row
cand = []
for r in db.execute("""
    SELECT mpn, pdf_path, json_path, pdf_bytes FROM item
    WHERE status='done' AND IFNULL(parse_count,0) >= 1
      AND pdf_path IS NOT NULL AND json_path IS NOT NULL
"""):
    pdf, base = Path(r["pdf_path"]), Path(r["json_path"])
    if not pdf.exists() or not base.exists():
        continue
    if BOARD_RE.search(r["mpn"] or ""):
        continue
    cand.append({"mpn": r["mpn"], "pdf": pdf, "base": base, "bytes": r["pdf_bytes"] or 0})

cand.sort(key=lambda x: x["bytes"])
samples = ([c for c in cand if "CDC6CE" in c["mpn"]][:2] +           # 历史 qwen 调用同族优先
           [c for c in cand if "CDC6CE" not in c["mpn"]][:8])
if len(samples) < 10:
    samples = cand[:10]
print(f"\n[setup] 候选(done且非板卡)={len(cand)}  选 {len(samples)} 个:")
for s in samples:
    print(f"  {s['mpn'][:26]:<26} {s['bytes'] // 1024:>6}KB  {s['pdf'].name[:40]}")

url_map = pd.load_url_map()


def run_one(s: dict, ctrl: bool = False) -> dict:
    pd.ENABLE_THINKING = ctrl                # False=关思考(测试组) True=开思考(对照)
    r = pd.parse_one(s["pdf"], url_map)
    r["_base"] = str(s["base"])
    r["_ctrl"] = ctrl
    return r


# ---------------------------------------------------------------- Phase 2a: 关思考 x10
print("\n=== Phase 2a: 关思考（enable_thinking=false）x10，3 并发 ===")
t_start = time.time()
results = []
with ThreadPoolExecutor(max_workers=3) as ex:
    futs = {ex.submit(run_one, s): s for s in samples}
    for f in as_completed(futs):
        r = f.result()
        results.append(r)
        u = r["usage"]
        print(f"  [{'OK' if r['status'] == 'ok' else r['status'][:4].upper()}] "
              f"{r['mpn'][:24]:<24} {r['secs']:>6.1f}s "
              f"completion={u.get('completion_tokens', '-'):>5} "
              f"elec={r['electrical']:<3} pins={r['pins']:<3} {(r['error'] or '')[:50]}")
print(f"  [phase2a] {len(results)} 件完成，墙钟 {round(time.time() - t_start)}s")

# ---------------------------------------------------------------- Phase 2b: 开思考对照 x2
print("\n=== Phase 2b: 开思考对照（同样本前 2 个，enable_thinking=true） ===")
pd.OUT_DIR = CTRL_OUT
ctrl_results = []
with ThreadPoolExecutor(max_workers=2) as ex:
    futs = {ex.submit(run_one, s, ctrl=True): s for s in samples[:2]}
    for f in as_completed(futs):
        r = f.result()
        ctrl_results.append(r)
        u = r["usage"]
        print(f"  [{'OK' if r['status'] == 'ok' else r['status'][:4].upper()}] "
              f"{r['mpn'][:24]:<24} {r['secs']:>6.1f}s "
              f"completion={u.get('completion_tokens', '-'):>5} "
              f"elec={r['electrical']:<3} pins={r['pins']:<3} {(r['error'] or '')[:50]}")


# ---------------------------------------------------------------- 汇总
def agg(rs):
    ok = [r for r in rs if r["status"] == "ok"]
    comp = [r["usage"].get("completion_tokens", 0) for r in ok]
    secs = [r["secs"] for r in ok]
    out = {"ok": f"{len(ok)}/{len(rs)}"}
    if comp:
        out["completion"] = f"avg={statistics.mean(comp):.0f} min={min(comp)} max={max(comp)}"
    if secs:
        out["secs"] = f"avg={statistics.mean(secs):.0f} min={min(secs):.0f} max={max(secs):.0f}"
    return out


print("\n=== 汇总（真实解析调用） ===")
print("关思考(测试组) : ", json.dumps(agg(results), ensure_ascii=False))
print("开思考(对照组) : ", json.dumps(agg(ctrl_results), ensure_ascii=False))
print("历史 agnes-3.0-flash 294次: completion avg=2986  secs avg=92.4")
print("历史 qwen-flash 默认 2次:   completion 5954/7001")


def counts(doc: dict):
    return {"elec": len(((doc.get("specs") or {}).get("electrical")) or []),
            "pins": len(doc.get("pin_configuration") or []),
            "order": len(doc.get("ordering_info") or []),
            "feat": len(doc.get("features") or [])}


print("\n=== 质量对比（关思考 vs agnes 基线，同 PDF） ===")
print(f"{'mpn':<24} {'qwen关思考':<28} {'agnes基线':<28} conf")
for r in sorted(results, key=lambda x: x["mpn"]):
    if r["status"] != "ok":
        print(f"{r['mpn'][:24]:<24} FAILED: {r['error'][:70]}")
        continue
    bdoc = json.loads(Path(r["_base"]).read_text(encoding="utf-8"))
    q = counts(json.loads(Path(r["out"]).read_text(encoding="utf-8")))
    b = counts(bdoc)
    print(f"{r['mpn'][:24]:<24} {str(q):<28} {str(b):<28} {r['confidence']}")

print("\n=== 每次模型调用明细 ===")
for c in _calls:
    u = c["usage"]
    print(f"  [{c['stage']:<7}] {'ok' if c['ok'] else 'FAIL'} {c['secs']:>6.1f}s "
          f"p={u.get('prompt_tokens', '-'):>6} c={u.get('completion_tokens', '-'):>6} "
          f"{c.get('err', '')[:60]}")
print("\ndone.")
