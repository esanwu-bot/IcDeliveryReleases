#!/usr/bin/env python
"""把一个交付批次打成「每型号一个目录」的交付树（含 PDF 原件）。

产物格式对齐单型号交付口径（DS80PCI402EVK_NOPB_fixed_*）：

    <out>/
      <型号>/
        <型号>.pdf              Datasheet 原件
        <型号>.json             结构化 JSON（唯一事实来源）
        <型号>.txt              详情页正文（英文）
        <型号>.ja.txt           日语变体（其余 ko/de/es 同理，有才收）
        <型号>.alts.json        替代型号候选
        <型号>.alts.html        替代型号内链片段
        <型号>.symbols.html     三视图
        <型号>.seo.json         图片 SEO 清单
        <型号>.provenance.json  来源与修复留痕（合成，见 build_provenance）

用法：
    # 打整个 review-fix 批次（MPN 取自 manifest.csv）
    python pack_batch_dirs.py --batch data/qc/rf-20261028-001

    # 只打指定型号
    python pack_batch_dirs.py --mpn NE555 --mpn LM358 --out data/exports/pick

    # 只要目录不要 zip / 不要 PDF
    python pack_batch_dirs.py --batch X --no-zip
    python pack_batch_dirs.py --batch X --no-pdf

型号里的 `/`、空格等按 safe_name 归一成 `_`（页面主键仍用原始型号）。
PDF 用 ZIP_STORED（本身已压缩），文本产物用 deflate。
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app import config, db                        # noqa: E402
from app.services.parts import safe_name          # noqa: E402
from qc import review_fix as RF                   # noqa: E402

LANGS = ("ja", "ko", "de", "es")

# (key, 库里字段, 目录, 目标后缀)；txt 的后缀按源文件真实扩展名决定
SPEC = (
    ("pdf", "pdf_path", config.PDFS, ".pdf"),
    ("json", "json_path", config.PARSED, ".json"),
    ("txt", "txt_path", config.TXT, ""),
    ("alt_json", "alt_json_path", config.ALTS, ".alts.json"),
    ("alt_html", "alt_html_path", config.ALTS, ".alts.html"),
    ("symbol", "symbol_path", config.SYMBOLS, ".symbols.html"),
    ("seo", "seo_path", config.SEO, ".seo.json"),
)


def _resolve(stored: str, sub: Path, stem: str, suffix: str) -> Path | None:
    """库里存的是落库机的绝对路径；跨机按 目录+文件名 回退（口径同 config）。"""
    p = (stored or "").strip()
    if p:
        f = config.resolve_artifact(p, sub)
        if f.is_file():
            return f
    for s in (stem, safe_name(stem)):
        f = sub / (s + suffix)
        if f.is_file():
            return f
    return None


def build_provenance(row: dict, mpn: str, batch: str, meta: dict,
                     files: dict[str, Path]) -> dict:
    """合成 provenance（口径唯一来源：`qc/review_fix.build_provenance`）。

    刻意不写 `human_accepted: true` / `released: true`——自动修复到 PASS 只代表
    机器复审通过，值级正确性仍需证据卡与人工验收，发布门禁恒为未批准。
    `row` 仅为兼容旧签名保留（DB 行里的字段已并入 meta）。
    """
    return RF.build_provenance(mpn, batch, meta, files)


def collect(mpn: str, with_pdf: bool = True) -> tuple[dict[str, Path], list[str]]:
    """返回 ({目标后缀: 源文件}, [缺失项])。"""
    row = db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1",
                (mpn, mpn)) or {}
    stem = str(row.get("mpn_key") or mpn)
    files: dict[str, Path] = {}
    missing: list[str] = []
    for key, col, sub, suffix in SPEC:
        if key == "pdf" and not with_pdf:
            continue
        f = _resolve(str(row.get(col) or ""), sub, stem, suffix)
        if f is None and key == "json":
            cands = sorted(sub.glob("%s_*.json" % safe_name(stem))) if sub.is_dir() else []
            f = cands[0] if cands else None
        if f is None:
            missing.append(key)
            continue
        files[suffix or f.suffix] = f
    # 语言变体：与英文正文同目录的 {stem}.{lang}.txt
    base = files.get(".txt")
    if base is not None:
        for lg in LANGS:
            cand = base.with_name("%s.%s.txt" % (base.name[: -len(".txt")], lg))
            if cand.is_file():
                files[".%s.txt" % lg] = cand
    return files, missing


def pack_one(mpn: str, out_root: Path, batch: str, meta: dict,
             with_pdf: bool) -> dict:
    safe = safe_name(mpn)
    d = out_root / safe
    d.mkdir(parents=True, exist_ok=True)
    files, missing = collect(mpn, with_pdf=with_pdf)
    written = []
    landed: dict[str, Path] = {}
    for suffix, src in files.items():
        dest = d / (safe + suffix)
        dest.write_bytes(src.read_bytes())
        written.append(dest.name)
        landed[suffix] = dest
    prov = build_provenance(db.q1(
        "SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1",
        (mpn, mpn)) or {}, mpn, batch, meta, landed)
    (d / (safe + ".provenance.json")).write_text(
        json.dumps(prov, ensure_ascii=False, indent=2), encoding="utf-8")
    written.append(safe + ".provenance.json")
    return {"mpn": mpn, "dir": str(d), "files": sorted(written),
            "missing": missing, "pdf": ".pdf" in files}


def write_zip(out_root: Path, zip_path: Path) -> dict:
    n = 0
    with zipfile.ZipFile(zip_path, "w") as z:
        for f in sorted(out_root.rglob("*")):
            if not f.is_file():
                continue
            comp = zipfile.ZIP_STORED if f.suffix.lower() == ".pdf" else \
                zipfile.ZIP_DEFLATED
            z.write(f, str(f.relative_to(out_root)), compress_type=comp)
            n += 1
    return {"zip": str(zip_path), "files": n, "bytes": zip_path.stat().st_size}


def read_batch(batch_dir: Path) -> tuple[str, list[dict]]:
    """读批次 manifest.csv → (批次号, [{mpn, ...}])。"""
    f = batch_dir / "manifest.csv"
    if not f.is_file():
        raise SystemExit("批次目录里没有 manifest.csv：%s" % batch_dir)
    with f.open(encoding="utf-8-sig", newline="") as fh:
        rows = [r for r in csv.DictReader(fh) if (r.get("mpn") or "").strip()]
    return batch_dir.name, rows


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="按每型号一个目录打包交付树")
    ap.add_argument("--batch", help="批次目录（读 manifest.csv 取型号）")
    ap.add_argument("--mpn", action="append", default=[], help="指定型号，可多次")
    ap.add_argument("--out", help="输出目录（默认 data/exports/<batch>_fixed_<ts>）")
    ap.add_argument("--no-pdf", action="store_true", help="不打 PDF")
    ap.add_argument("--no-zip", action="store_true", help="只出目录，不压 zip")
    a = ap.parse_args(argv)

    mpns: list[str] = list(a.mpn)
    metas: dict[str, dict] = {}
    batch = ""
    if a.batch:
        batch, rows = read_batch(Path(a.batch))
        for r in rows:
            m = r["mpn"].strip()
            if m and m not in mpns:
                mpns.append(m)
            metas[m] = r
    if not mpns:
        raise SystemExit("没有型号可打：给 --batch 或 --mpn")
    for m in mpns:
        metas.setdefault(m, {})

    stamp = time.strftime("%Y%m%d-%H%M")
    out = Path(a.out) if a.out else \
        config.EXPORTS / ("%s_fixed_%s" % (batch or "pick", stamp))
    out.mkdir(parents=True, exist_ok=True)

    print("批次 %s · %d 件 → %s" % (batch or "(指定型号)", len(mpns), out))
    bad = 0
    for m in mpns:
        r = pack_one(m, out, batch, metas.get(m) or {}, not a.no_pdf)
        flag = "ok " if r["pdf"] and not r["missing"] else "!  "
        print("  %s%-26s %2d 文件%s%s" % (
            flag, m, len(r["files"]),
            "" if r["pdf"] else "  缺 PDF",
            ("  缺 " + "/".join(r["missing"])) if r["missing"] else ""))
        if r["missing"] or not r["pdf"]:
            bad += 1

    if not a.no_zip:
        z = write_zip(out, out.with_suffix(".zip"))
        print("ZIP %s（%d 文件 · %.2f MB）"
              % (z["zip"], z["files"], z["bytes"] / 1048576.0))
    print("完成：%d 件，其中 %d 件有缺项" % (len(mpns), bad))
    return 0 if bad == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
