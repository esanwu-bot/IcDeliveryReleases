#!/usr/bin/env python
"""替代型号（Alternative Parts）：站内目录候选 → AI 排序 → 渲染 Equivalent 段。

工作台口径（catalog-first，默认）：
    Index.candidates() 按型号系列前缀取站内目录候选，每个候选都带真实 URL
    propose_grounded() 只允许模型在候选清单内排序/解释，禁止新增或拼凑料号
    render_section()   只输出站内目录命中的型号；目录未覆盖时明确报告，不让 AI 猜

命令行 alternatives.py --workers 仍保留旧的「AI 自由提案 → 目录校验」批量模式，
仅供人工批量复核；工作台 build_alternatives() 不再自由生成候选。

站内 URL 规律（从 in-fortune 线上页验证）：
    /products/detail/{slug}-{id}
    slug = 小写 + 只留字母数字      AD8606ARMZ-R7 -> ad8606armzr7
                                   0685T0750-01  -> 0685t075001

用法：
    python alternatives.py --selftest                  # 只验匹配器，不花 token
    python alternatives.py --only CDC6C                # 单个料号
    python alternatives.py --workers 3                 # 全部已解析 JSON
    python alternatives.py --index data/products.csv   # 指定站内产品索引
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from parse_datasheets import chat, model_for

ROOT = Path(__file__).resolve().parent
PARSED = ROOT / "data" / "parsed"
ALTS = ROOT / "data" / "alts"
INDEX_CSV = ROOT / "data" / "products.csv"
INDEX_DB = ROOT / "data" / "products.sqlite3"


def clean(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()

# 包装/温度后缀：做"同族"匹配时逐层剥掉
PACK_SUFFIX = re.compile(
    r"(?:-?R[1-7]|-?RL-?|TR|CT|T&R|REEL|TAPE|BULK|TRAY|-?E2|-?E3|-?ND|-?DKR)$", re.I)


def norm(mpn: str) -> str:
    """站内 slug 口径：只留字母数字，大写。"""
    return re.sub(r"[^A-Z0-9]", "", (mpn or "").upper())


def base(mpn: str) -> str:
    """剥包装后缀，用于同族匹配（AD8606ARMZ-R7 -> AD8606ARMZ）。"""
    s = re.sub(r"\s+", "", (mpn or "").upper())
    prev = None
    while prev != s:
        prev = s
        s = PACK_SUFFIX.sub("", s)
    return norm(s)


# 评估板/套件后缀：CC1020EMK-868 -> CC1020，DRV2667EVM-CT -> DRV2667
# DK 后可直接跟频段数字（CC1020-CC1070DK868），所以尾部允许 [-_ ].* 或 数字.*
KIT_RE = re.compile(
    r"(?:[-_ ]?)(EMK|EVK|EVM|EVB|EVAL|KIT|BOARD|MODULE|DK)(?:[-_ ].*|\d.*)?$", re.I)


def kit_root(mpn: str) -> str:
    """从评估板/套件料号反推板载器件系列根；不是套件返回空串。"""
    s = (mpn or "").strip()
    m = KIT_RE.search(s)
    if not m:
        return ""
    root = re.sub(r"[-_ ]+$", "", s[:m.start()])
    # CC1020-CC1070DK868 这类双器件板，取第一个
    root = root.split("-")[0].strip()
    return root if len(norm(root)) >= 4 else ""


def search_prefix(mpn: str) -> str:
    """站内目录前缀检索口径：剥包装后缀，再去掉尾部封装字母，取前 8 位。

    LM358DR -> LM358，NE555P -> NE555，AD8606ARMZ-R7 -> AD8606。
    """
    b = base(mpn)
    m = re.match(r"^(.*\d)[A-Z]{1,4}$", b)
    if m and len(m.group(1)) >= 4:
        b = m.group(1)
    if not b:
        return ""
    return b[:8] if len(b) > 8 else b


def prefix_safe(mpn: str, candidate: str) -> bool:
    """前缀候选取舍：短的一方后面紧跟数字时视为不同器件。

    LM35 -> LM358 / LM3588 是另一颗芯片（运放），必须拒；
    LM358 -> LM358D、AD8606AR -> AD8606ARZ 是封装/等级后缀，保留。
    """
    a, b = norm(mpn), norm(candidate)
    if not a or not b:
        return False
    if b.startswith(a):
        return len(b) == len(a) or b[len(a)].isalpha()
    if a.startswith(b):
        return len(a) == len(b) or a[len(b)].isalpha()
    return True


# ---------------------------------------------------------------- 站内索引
class Index:
    """mpn -> url。

    三种后端，按参数自动选：
      mysql://...  MySQL（icpdf.catalog），多进程/多机共享（生产可选）
      *.sqlite3    站内全量目录（60 万级），惰性 SQL 查询 + 内存缓存，不占内存（默认）
      *.csv        少量种子（mpn,url），全量载入内存
    """

    def __init__(self) -> None:
        self.by_norm: dict[str, dict] = {}
        self.by_base: dict[str, dict] = {}
        self._cache: dict[str, tuple[dict | None, str]] = {}
        self._total = -1
        self._ph = "?"          # 参数占位符：sqlite 用 ?，mysql 用 %s
        self._keycol = "key"    # mysql 里 key 是保留字，列名用 k
        self._dsn = ""          # 线程局部连接用的连接串
        self._tls = threading.local()
        # 站内目录经常只收录「带封装/等级后缀」的可订购料号（LM358DR 有，裸 LM358 没有），
        # 只有 exact + family 两级时这类型号全部落空。打开 series 后多一级「同系列前缀」兜底。
        # 默认关闭，命令行行为不变；工作台显式打开。
        self.series = False

    # -------------------------------------------------- 连接（每线程一个）
    def _cur(self):
        """取本线程的游标对。sqlite/pymysql 连接都不是线程安全的，
        而 alternatives 用线程池跑批，所以必须按线程各持一个连接。"""
        pair = getattr(self._tls, "pair", None)
        if pair is None:
            if self._ph == "%s":
                import pymysql
                from build_product_index import dsn_parts
                p = dsn_parts(self._dsn)
                con = pymysql.connect(host=p["host"], port=p["port"], user=p["user"],
                                      password=p["password"], database="icpdf",
                                      charset="utf8mb4", autocommit=True)
            else:
                import sqlite3
                con = sqlite3.connect(f"file:{self._dsn}?mode=ro", uri=True,
                                      check_same_thread=False)
            pair = (con, con.cursor(), con.cursor())
            self._tls.pair = pair
        return pair

    # -------------------------------------------------- SQLite 后端
    def load_sqlite(self, path: Path) -> "Index":
        self._dsn = Path(path).as_posix()
        con, _, _ = self._cur()
        self._total = con.execute("SELECT count(*) FROM catalog").fetchone()[0]
        return self

    # -------------------------------------------------- MySQL 后端
    def load_mysql(self, dsn: str) -> "Index":
        self._ph, self._keycol = "%s", "k"
        self._dsn = dsn
        con, cur, _ = self._cur()
        cur.execute("SELECT COUNT(*) FROM catalog")
        self._total = cur.fetchone()[0]
        return self

    def _sql_match(self, mpn: str) -> tuple[dict | None, str]:
        n = norm(mpn)
        if not n:
            return None, "miss"
        hit = self._cache.get(n)
        if hit is not None:
            return hit
        ph, kc = self._ph, self._keycol
        con, q_exact, q_base = self._cur()
        if self._ph == "%s":
            con.ping(reconnect=True)            # 长时间跑批防 "MySQL server has gone away"
        q_exact.execute(f"SELECT mpn,url FROM catalog WHERE {kc}={ph}", (n,))
        row = q_exact.fetchone()
        if row:
            out = ({"mpn": row[0], "url": row[1]}, "exact")
        else:
            b = base(mpn)
            row = None
            if b:
                # 确定性排序：优先"裸料号"（key 就是 base），其次最短、再按字典序，
                # 避免 LIMIT 1 在 sqlite/mysql 上返回不同行
                q_base.execute(
                    f"SELECT mpn,url FROM catalog WHERE base={ph} "
                    f"ORDER BY ({kc}=base) DESC, LENGTH(mpn), mpn LIMIT 1", (b,))
                row = q_base.fetchone()
            out = (({"mpn": row[0], "url": row[1]}, "family") if row else (None, "miss"))
        self._cache[n] = out
        return out

    # -------------------------------------------------- CSV 后端
    def load(self, path: Path) -> "Index":
        if isinstance(path, str) and path.startswith("mysql"):
            return self.load_mysql(path)
        if not path.exists():
            return self
        if path.suffix.lower() in (".sqlite3", ".db", ".sqlite"):
            return self.load_sqlite(path)
        with open(path, encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                url = (row.get("url") or "").strip()
                mpn = (row.get("mpn") or "").strip()
                if not url and (row.get("id") or "").strip():
                    url = f"/products/detail/{norm(mpn).lower()}-{row['id'].strip()}"
                if not url:
                    continue
                if not mpn:                              # 从 slug 反推
                    m = re.search(r"/detail/([a-z0-9]+)-(\d+)", url)
                    mpn = m.group(1) if m else url
                self._add(mpn, url)
        return self

    def _add(self, mpn: str, url: str) -> None:
        rec = {"mpn": mpn, "url": url}
        self.by_norm.setdefault(norm(mpn), rec)
        self.by_base.setdefault(base(mpn), rec)

    def _series_match(self, mpn: str) -> tuple[dict | None, str]:
        """同系列前缀兜底：候选是站内料号的前缀，且下一位必须是「字母」后缀码。

        安全边界（踩过的坑）：只看前缀会出事故 —— LM35（温度传感器）会命中 LM358（运放）。
        所以要求分歧点后面紧跟字母（封装/等级码：LM358 -> LM358DR），
        紧跟数字的一律拒绝（LM35 -> LM3588 这种是不同器件的型号顺延）。
        """
        n = norm(mpn)
        if len(n) < 4:
            return None, "miss"
        ph, kc = self._ph, self._keycol
        con, _, q_base = self._cur()
        if self._ph == "%s":
            con.ping(reconnect=True)
        q_base.execute(
            f"SELECT mpn,url FROM catalog WHERE {kc} LIKE {ph} "
            f"ORDER BY LENGTH(mpn), mpn LIMIT 60", (n + "%",))
        for row in q_base.fetchall():
            cat = norm(row[0])
            if len(cat) <= len(n) or len(cat) - len(n) > 10:
                continue
            if not cat[len(n)].isalpha():       # 紧跟数字 = 别的器件，不算同系列
                continue
            return {"mpn": row[0], "url": row[1]}, "series"
        return None, "miss"

    def candidates(self, prefix: str, limit: int = 60) -> list[dict]:
        """按归一化前缀取站内目录候选（每条都带真实 url）。

        用主键范围扫描而不是 LIKE '%...'，避免 60 万行全表扫描。
        """
        n = norm(prefix)
        limit = max(1, min(int(limit), 200))
        if not n:
            return []
        if not self._dsn:
            out = []
            for k in sorted(self.by_norm):
                if not k.startswith(n):
                    continue
                rec = self.by_norm[k]
                out.append({"mpn": rec["mpn"], "url": rec["url"], "brand": ""})
                if len(out) >= limit:
                    break
            return out
        ph, kc = self._ph, self._keycol
        con, cur, _ = self._cur()
        if self._ph == "%s":
            con.ping(reconnect=True)
        # 归一化 key 只含 A-Z0-9，"~" 是安全的右边界
        cur.execute(
            f"SELECT mpn,url,brand FROM catalog WHERE {kc} >= {ph} AND {kc} < {ph} "
            f"ORDER BY ({kc}={ph}) DESC, LENGTH(mpn), mpn LIMIT {limit}",
            (n, n + "~", n))
        return [{"mpn": r[0], "url": r[1], "brand": (r[2] or "")}
                for r in cur.fetchall()]

    def match(self, mpn: str) -> tuple[dict | None, str]:
        if self._dsn:
            rec, how = self._sql_match(mpn)
            if rec is None and self.series:
                return self._series_match(mpn)
            return rec, how
        n = norm(mpn)
        if n in self.by_norm:
            return self.by_norm[n], "exact"
        b = base(mpn)
        if b and b in self.by_base:
            return self.by_base[b], "family"
        return None, "miss"

    def __len__(self) -> int:
        if self._dsn:
            return max(self._total, 0)
        return len(self.by_norm)

    def close(self) -> None:
        pair = getattr(self._tls, "pair", None)
        if pair:
            pair[0].close()
            self._tls.pair = None


# ---------------------------------------------------------------- 料号universe
def load_universe() -> set[str]:
    """本地料号表（SQLite links）作为真伪校验池；没有库就返回空集。"""
    db = ROOT / "data" / "icpdf.sqlite3"
    if not db.exists():
        return set()
    import sqlite3
    con = sqlite3.connect(db)
    try:
        return {norm(m) for (m,) in con.execute("SELECT DISTINCT mpn FROM links")}
    finally:
        con.close()


def grounded_rows(doc: dict, mpn: str) -> list[dict]:
    """同系列替代：直接取 datasheet 自己的 ordering_info，零幻觉。"""
    out = []
    for o in doc.get("ordering_info") or []:
        m = clean(o.get("mpn"))
        if not m or norm(m) == norm(mpn):
            continue
        pkg = clean(o.get("package"))
        out.append({
            "mpn": m,
            "manufacturer": clean((doc.get("basic_info") or {}).get("manufacturer")),
            # 表头是 Part Number / Brand / Type / Package / Key Feature。
            # Type 若取封装，会和 Package 列完全重复（都是 16-TSSOP 变体），
            # 这里用「包装/载体」（TUBE / LARGE T&R）——同族订货码真正的差异项。
            "type": clean(o.get("packaging"))
                    or clean((doc.get("specs") or {}).get("package", {}).get("type"))
                    or pkg,
            "package": pkg,
            "feature": "Same datasheet order code" + (f", {clean(o.get('packaging'))}" if o.get("packaging") else ""),
            "similarity": 0.99,
            "basis": "same-family-datasheet",
        })
    return out


# ---------------------------------------------------------------- AI 生成候选
SYS = """你是电子元器件选型工程师。给定一个料号的分类、封装和关键参数，给出 3-6 个可替代型号。

硬性要求：
1. mpn 必须是**完整的、可直接在原厂官网订购的 Part Number**，含全部后缀
   （如 BCPZ / AAVT / AAWT / ZEGT / #PBF / -R7）。**禁止输出基础系列名或速度档**
   （反例：`AD9680-1000` 不是可订购号，正确写法是 `AD9680BCPZ-1000`；
   反例：`ADC12DJ5200RF` 不是可订购号，正确写法是 `ADC12DJ5200RFAAVT`）。
   **不确定完整后缀时，mpn 必须原样输出 `N/A`**（该行其余字段可留空）——
   不要省略该行，也不要猜后缀。`N/A` 是我们统计「模型有多少次认不准」的唯一信号；
   悄悄丢掉整行会让「认不准」变成不可观测的静默失效。
2. 只给真实存在、可采购的型号，禁止编造或拼凑料号；不确定就不要写。
3. 优先顺序：同厂同系列（不同温度等级/封装/包装）> 同厂 pin-to-pin 兼容 > 跨厂功能等价。
4. 不要包含原型号本身，也不要包含纯包装差异（-R7 / -RL / TRAY）的同一料号。
5. type 写该型号的关键规格摘要，用 " / " 分隔，例如 "Cortex-M0+ / 48MHz / 32KB Flash"。
6. package 写封装短名，例如 "TSSOP-20"；不确定写 ""。
7. feature 是 8-18 词的关键差异说明，必须点明为什么能替代（封装兼容/参数接近/接口一致/温度更宽）。
8. similarity 为替代接近度：pin-to-pin 且参数接近 0.85+，功能等价但需改板 0.5-0.7。

只输出 JSON：
{"alternatives":[{"mpn":"","manufacturer":"","type":"","package":"","feature":"","similarity":0.0,"basis":"pin-compatible|same-family|functional-equivalent"}]}"""

USER = """原型号：{mpn}
厂商：{mfr}
分类：{cat} / {subcat}
封装：{pkg}（{pins} 引脚）
工作温度：{temp}
关键参数：{specs}
主要特性：{feats}
典型应用：{apps}

请给出替代型号 JSON。"""


def doc_brief(doc: dict) -> dict:
    bi = doc.get("basic_info") or {}
    sp = doc.get("specs") or {}
    pkg = sp.get("package") or {}
    el = sp.get("electrical") or []
    return {
        "mpn": clean(bi.get("mpn")),
        "mfr": clean(bi.get("manufacturer")),
        "cat": clean(bi.get("category")),
        "subcat": clean(bi.get("subcategory")),
        "pkg": clean(pkg.get("type")),
        "pins": pkg.get("pins") or "",
        "temp": clean((sp.get("temperature") or {}).get("operating")),
        "specs": "; ".join(
            f"{clean(e.get('name'))}={clean(e.get('value'))}{(' ' + clean(e.get('unit'))).strip()}"
            for e in el[:8]),
        "feats": "; ".join(clean(x) for x in (doc.get("features") or [])[:5]),
        "apps": "; ".join(clean(x) for x in (doc.get("applications") or [])[:3]),
    }


def propose(doc: dict, with_usage: bool = False):
    """旧批量模式：AI 自由提替代型号（工作台不再使用）。

    with_usage=True 时返回 (rows, usage)，供命令行批量记账。
    """
    content, u = chat([
        {"role": "system", "content": SYS},
        {"role": "user", "content": USER.format(**doc_brief(doc))},
    ], max_tokens=2000, temperature=0.1, model=model_for("alternatives"))
    data = json.loads(re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.M))
    out, seen = [], {norm((doc.get("basic_info") or {}).get("mpn"))}
    for r in data.get("alternatives") or []:
        mpn = clean(r.get("mpn"))
        n = norm(mpn)
        if not n or n in seen or not re.match(r"^[A-Za-z0-9][A-Za-z0-9./#\-]{3,28}$", mpn):
            continue
        seen.add(n)
        try:
            sim = round(float(r.get("similarity") or 0), 2)
        except (TypeError, ValueError):
            sim = 0.0
        out.append({
            "mpn": mpn,
            "manufacturer": clean(r.get("manufacturer")),
            "type": clean(r.get("type")),
            "package": clean(r.get("package")),
            "feature": clean(r.get("feature")),
            "similarity": max(0.0, min(1.0, sim)),
            "basis": clean(r.get("basis")) or "functional-equivalent",
        })
    out.sort(key=lambda x: -x["similarity"])
    return (out, u) if with_usage else out


# ---------------------------------------------------------------- 目录内 AI 排序
SYS_GROUNDED = """你是电子元器件选型工程师。你只能从给定的站内目录候选清单中选择替代型号。

硬性要求：
1. 只能选清单里已有的 MPN，输出时必须原样照抄；禁止新增、改写、拼凑或猜测料号。
2. 只保留与原型号封装、引脚、电气参数、接口兼容的候选；不确定就不要选。
3. 排除原型号本身，以及只有包装差异（-R7 / -RL / TRAY）的同一料号。
4. 按兼容性从高到低排序，最多 6 个；清单里没有合适替代时返回空数组。
5. feature 是 8-18 词的关键差异说明，必须点明为什么能替代；similarity 为 0-1。
6. 只输出 JSON：
{"alternatives":[{"mpn":"","feature":"","similarity":0.0,"basis":"pin-compatible|same-family|functional-equivalent"}]}"""

USER_GROUNDED = """原型号：{mpn}
厂商：{mfr}
分类：{cat} / {subcat}
封装：{pkg}（{pins} 引脚）
工作温度：{temp}
关键参数：{specs}
主要特性：{feats}
典型应用：{apps}

站内目录候选（只能从这里选，MPN | Brand）：
{candidates}

请给出替代型号 JSON。"""


def propose_grounded(doc: dict, candidates: list[dict], with_usage: bool = False):
    """只让模型在站内目录候选内排序/解释，返回的 mpn 必须命中候选清单。"""
    brief = doc_brief(doc)
    by = {norm(c.get("mpn")): c for c in candidates
          if norm(c.get("mpn")) and prefix_safe(brief.get("mpn") or "", c.get("mpn"))}
    if not by:
        return ([], {}) if with_usage else []
    listing = "\n".join(
        f"- {c['mpn']} | {clean(c.get('brand')).replace('|', '/') or '-'}"
        for c in by.values())
    content, u = chat([
        {"role": "system", "content": SYS_GROUNDED},
        {"role": "user", "content": USER_GROUNDED.format(candidates=listing, **brief)},
    ], max_tokens=2000, temperature=0.1, model=model_for("alternatives"))
    data = json.loads(re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.M))
    out, seen = [], {norm(brief.get("mpn"))}
    for r in data.get("alternatives") or []:
        n = norm(clean(r.get("mpn")))
        c = by.get(n)
        if not c or n in seen:
            continue
        seen.add(n)
        try:
            sim = round(float(r.get("similarity") or 0), 2)
        except (TypeError, ValueError):
            sim = 0.0
        out.append({
            "mpn": c["mpn"],
            "manufacturer": clean(c.get("brand")) or clean(r.get("manufacturer")),
            "type": clean(r.get("type")),
            "package": clean(r.get("package")),
            "feature": clean(r.get("feature")),
            "similarity": max(0.0, min(1.0, sim)),
            "basis": clean(r.get("basis")) or "same-family",
        })
        if len(out) >= 6:
            break
    out.sort(key=lambda x: -x["similarity"])
    return (out, u) if with_usage else out


# ---------------------------------------------------------------- 匹配 + 渲染
def enrich(rows: list[dict], idx: Index, universe: set[str]) -> list[dict]:
    for r in rows:
        rec, how = idx.match(r["mpn"])
        r["internal"] = bool(rec)
        r["match"] = how
        r["url"] = rec["url"] if rec else ""
        r["catalog_mpn"] = rec["mpn"] if rec else ""
        # verified: 在本地料号库里存在（同厂）或被站内目录收录
        r["verified"] = r["internal"] or norm(r["mpn"]) in universe
    return rows


#: 严格门禁开关：默认开启。只有调试时才允许放行未命中目录的候选。
#: 口径来自 2026-10-31 Reviewer B1：`ADC12DJ5200RF` / `AD9680-1000` / `ADS8V11`
#: 三条候选全部 `verified=false, match=miss`，却照样进了交付包。
KEEP_UNVERIFIED = os.getenv("ICPDF_ALTS_KEEP_UNVERIFIED", "0").strip() == "1"


UNDETERMINED_MARKS = {"NA", "NAN", "NONE", "NULL", "TBD", "UNKNOWN"}


def is_undetermined(mpn: str) -> bool:
    """模型按 Prompt 约定输出的「认不准」占位（`N/A` 及其变体）。

    Prompt 现在要求认不准时**显式输出 `N/A`**，而不是悄悄丢掉整行。理由：
    丢掉的行不可观测，`N/A` 行可以计数 —— 这是「模型有多少次认不准」的唯一信号，
    也是运营侧补数据的工单来源。这类行既不进 alts.json，也不当幻觉拉黑。
    """
    return norm(mpn) in UNDETERMINED_MARKS


def enforce_orderable(rows: list[dict], idx: "Index") -> tuple[list[dict], list[dict]]:
    """只保留能在站内目录**精确命中**的候选；其余剔除并留审计记录。

    为什么卡在「字符串精确命中」这一步：三条错候选的错法完全一致 ——
    把「系列名 / 速度档」当成了可订购号（`AD9680-1000` 实为 `AD9680BCPZ-1000`、
    裸 `ADC12DJ5200RF` 实为 `ADC12DJ5200RFAAVT`）。目录里这两个码**本来就有**，
    `match=miss` 不是「库里没这颗料」，而是「模型没按可订购号命名」。
    所以判据不能是「同族有没有」，必须是「这个字符串在不在库里」。

    返回 `(kept, rejected)`：rejected 只写进 `data/alts/_rejected/` 供人工审计，
    **绝不进 alts.json** —— 下游按数组长度统计时，一条幻觉就是一条假数据。

    `reject_reason` 三态，对应三种不同的处置动作：
      `not_in_catalog_exact` 幻觉/命名不规范 → 拉黑，不许再出现在交付里；
      `family_only`          同族有、精确码没有 → 需要人工确认完整后缀；
      `mpn_undetermined`     模型主动写 `N/A` → 不是错误，是**运营侧收录的工单**。
    """
    kept: list[dict] = []
    rejected: list[dict] = []
    for r in rows:
        # 「认不准完整可订购号」必须单列一类，不能和幻觉混在一起：
        # 幻觉是错的，认不准是「没说」。前者要拉黑，后者要补数据（运营侧收录）。
        if is_undetermined(r.get("mpn")):
            rejected.append({
                "mpn": clean(r.get("mpn")),
                "manufacturer": r.get("manufacturer", ""),
                "type": r.get("type", ""),
                "package": r.get("package", ""),
                "feature": r.get("feature", ""),
                "similarity": r.get("similarity", 0),
                "basis": r.get("basis", ""),
                "match": "undetermined",
                "catalog_mpn": "",
                "reject_reason": "mpn_undetermined",
            })
            continue
        rec, how = idx.match(r["mpn"])
        if rec is not None and how == "exact":
            r["internal"] = True
            r["match"] = how
            r["url"] = rec.get("url") or ""
            r["catalog_mpn"] = rec.get("mpn") or ""
            r["verified"] = True
            kept.append(r)
            continue
        rejected.append({
            "mpn": r.get("mpn", ""),
            "manufacturer": r.get("manufacturer", ""),
            "type": r.get("type", ""),
            "package": r.get("package", ""),
            "feature": r.get("feature", ""),
            "similarity": r.get("similarity", 0),
            "basis": r.get("basis", ""),
            "match": how,
            "catalog_mpn": (rec or {}).get("mpn", ""),
            "reject_reason": "family_only" if rec is not None else "not_in_catalog_exact",
        })
    return kept, rejected


def esc(s: str) -> str:
    return (str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def render_section(mpn: str, rows: list[dict], mfr: str = "",
                   only_linked: bool = True, note: str = "",
                   intro: str = "") -> str:
    """线上同款：5 列表格。

    only_linked=True（默认，生产口径）：只输出站内目录命中的型号；
    only_linked=False：未命中的也输出纯文本，用于人工复核。
    note：表格前的补充说明（评估板板载器件等）。
    intro：覆盖默认导语。
    """
    if only_linked:
        rows = [r for r in rows if r.get("internal")]
    if not rows:
        return ""
    lead = intro or (
        f"The following alternative parts are listed for reference. Before selecting an "
        f"alternative for {esc(mpn)}, verify package, pinout, supply range, interface timing and "
        f"software or circuit compatibility.")
    L = [
        "<!-- 8) Equivalent -->",
        '<section class="pd-sec" id="equivalent">',
        '\t<div class="pd-sec-head">',
        '\t\t<div class="pd-badge">',
        "\t\t\tE",
        "\t\t</div>",
        '\t\t<h2 class="pd-sec-title">',
        "\t\t\tAlternative Parts",
        "\t\t</h2>",
        "\t</div>",
        '\t<div class="pd-sec-body">',
        "\t\t<p>",
        f"\t\t\t{lead}",
        "\t\t</p>",
    ]
    if note:
        L += ['\t\t<p class="pd-note">', f"\t\t\t{note}", "\t\t</p>"]
    L += [
        '\t\t<table class="pd-table">',
        "\t\t\t<tbody>",
        "\t\t\t\t<tr>",
    ]
    for h in ("Part Number", "Brand", "Type", "Package", "Key Feature"):
        L += ["\t\t\t\t\t<th>", f"\t\t\t\t\t\t{h}", "\t\t\t\t\t</th>"]
    L += ["\t\t\t\t</tr>"]
    for r in rows:
        name = esc(r["mpn"])
        cell = (f'<a href="{esc(r["url"])}" target="_blank">{name}</a>'
                if r.get("internal") else name)
        L += [
            "\t\t\t\t<tr>",
            "\t\t\t\t\t<td>",
            f"\t\t\t\t\t\t{cell}",
            "\t\t\t\t\t</td>",
            "\t\t\t\t\t<td>",
            f"\t\t\t\t\t\t{esc(r.get('manufacturer', '')) or '-'}",
            "\t\t\t\t\t</td>",
            "\t\t\t\t\t<td>",
            f"\t\t\t\t\t\t{esc(r.get('type', '')) or '-'}",
            "\t\t\t\t\t</td>",
            "\t\t\t\t\t<td>",
            f"\t\t\t\t\t\t{esc(r.get('package', '')) or '-'}",
            "\t\t\t\t\t</td>",
            "\t\t\t\t\t<td>",
            f"\t\t\t\t\t\t{esc(r.get('feature', '')) or '-'}",
            "\t\t\t\t\t</td>",
            "\t\t\t\t</tr>",
        ]
    L += [
        "\t\t\t</tbody>",
        "\t\t</table>",
        '\t\t<p class="pd-note">',
        "\t\t\t<strong>Selection Tips:</strong> When selecting alternatives, check core architecture and "
        "pinout compatibility, package and footprint, supply voltage and temperature range, peripheral "
        "interface type and count, and toolchain or driver differences. Any substitute must be confirmed "
        "against the current manufacturer datasheet before production use.",
        "\t\t</p>",
        "\t</div>",
        "</section>",
    ]
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------- 单文件
def run_one(pdf_json: Path, idx: Index, universe: set[str], render: bool,
            keep_unmatched: bool) -> dict:
    t0 = time.time()
    doc = json.loads(pdf_json.read_text(encoding="utf-8"))
    mpn = clean((doc.get("basic_info") or {}).get("mpn")) or pdf_json.stem
    rec = {"mpn": mpn, "n": 0, "matched": 0, "verified": 0, "rejected": 0, "secs": 0.0,
           "status": "ok", "error": "", "out": ""}
    try:
        rows = grounded_rows(doc, mpn) + propose(doc)
        rows = enrich(rows, idx, universe)
        # 去重（同型号只留一条，优先已内链/已校验的）
        seen, uniq = set(), []
        for r in sorted(rows, key=lambda x: (x["internal"], x["verified"], x["similarity"]), reverse=True):
            if norm(r["mpn"]) in seen:
                continue
            seen.add(norm(r["mpn"]))
            uniq.append(r)
        rows = uniq[:6]
        # 可订购号精确匹配门禁（Reviewer B1）：未在站内目录精确命中的候选
        # 一律不进 alts.json —— 下游按数组长度统计时，一条幻觉就是一条假数据。
        rejected: list[dict] = []
        if not KEEP_UNVERIFIED:
            rows, rejected = enforce_orderable(uniq, idx)
            rows = rows[:6]
        rec["n"] = len(rows)
        rec["rejected"] = len(rejected)
        rec["matched"] = sum(1 for r in rows if r["internal"])
        rec["verified"] = sum(1 for r in rows if r["verified"])
        ALTS.mkdir(parents=True, exist_ok=True)
        stem = re.sub(r"[^A-Za-z0-9._-]+", "_", mpn)
        payload = {
            "mpn": mpn,
            "manufacturer": clean((doc.get("basic_info") or {}).get("manufacturer")),
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "model": model_for("alternatives"),
            "alternatives": rows,
        }
        (ALTS / f"{stem}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        if rejected:
            # 被剔除的候选留一份审计记录（不进 alts.json，也不参与渲染）
            rej_dir = ALTS / "_rejected"
            rej_dir.mkdir(parents=True, exist_ok=True)
            (rej_dir / f"{stem}.json").write_text(json.dumps(
                {"mpn": mpn, "generated_at": payload["generated_at"],
                 "rule": "orderable_part_number_exact_match",
                 "rejected": rejected}, ensure_ascii=False, indent=2), encoding="utf-8")
        if render:
            html = render_section(mpn, rows, payload["manufacturer"],
                                  only_linked=not keep_unmatched)
            out_html = ALTS / f"{stem}.html"
            if html.strip():                      # 0 条替代就不落空文件
                out_html.write_text(html, encoding="utf-8")
            elif out_html.exists():
                out_html.unlink()
        rec["out"] = f"data/alts/{stem}.json"
    except Exception as e:                                   # noqa: BLE001
        rec["status"] = "failed"
        rec["error"] = f"{type(e).__name__}: {e}"[:200]
    rec["secs"] = round(time.time() - t0, 1)
    return rec


# ---------------------------------------------------------------- 自检
def selftest(idx: Index) -> None:
    """用线上真实链接验证匹配器（含 slug 去横杠、剥包装后缀）。

    注意：期望值随索引范围变化。换索引（CSV 种子 / sqlite 全量 / MySQL）后
    若某条从 PASS 变 FAIL，先确认是「库里没有」还是「匹配器错」——见 OUT_OF_EXPORT。
    """
    cases = [
        ("AD8606ARMZ-R7", True, "exact"),        # 站点 slug: ad8606armzr7
        ("ad8606armzr7", True, "exact"),         # 小写 slug 直接喂进来
        ("AD8606ARMZ", True, "family"),          # 剥 -R7 后同族
        ("LPC812M101JDH20FP", True, "exact"),
        ("STM32F030F4P6", True, "exact"),
        ("STM32F103C8T6", True, "exact"),
        ("STM32F103C8T6TR", True, "exact"),      # 包装后缀本身也是一个独立商品
        ("LTM8061EV-8.4#PBF", True, "exact"),    # 验证 '.' 和 '#' 的归一化
        ("AD5522JSVUZ", True, "exact"),
        ("ZZZNOTAREALPART9999", False, "miss"),  # 必须不命中
    ]
    # 这几个是线上真页，但不在 140MB 导出里（导出受 65.5 万行上限截断）
    OUT_OF_EXPORT = ["0685T0750-01", "LTM8053IY-1#PBF", "HLE-106-02-L-DV-BE-LC"]

    print(f"index size={len(idx)}")
    ok = True
    for mpn, want_hit, want_how in cases:
        rec, how = idx.match(mpn)
        good = (rec is not None) == want_hit and how == want_how
        ok &= good
        print(f"{'PASS' if good else 'FAIL'}  {mpn:<22} -> {how:<7} {rec['url'] if rec else '-'}")
    print(f"{'PASS' if ok else 'FAIL'}  -- 以下 %d 条线上存在但导出未覆盖，命中与否不参与判定 --"
          % len(OUT_OF_EXPORT))
    for mpn in OUT_OF_EXPORT:
        rec, how = idx.match(mpn)
        print(f"INFO  {mpn:<22} -> {how:<7} {rec['url'] if rec else '(导出未覆盖)'}")
    print("selftest", "OK" if ok else "FAILED")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=str(PARSED))
    ap.add_argument("--index", default=str(INDEX_DB if INDEX_DB.exists() else INDEX_CSV),
                    help="站内目录：products.sqlite3（默认全量）/ products.csv（种子）"
                         " / mysql://root:root@127.0.0.1:3306/icpdf")
    ap.add_argument("--only", default="")
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--no-render", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--keep-unmatched", action="store_true",
                    help="未命中站内目录的候选也渲染（纯文本，供人工复核）")
    ap.add_argument("--keep-unverified", action="store_true",
                    help="调试用：跳过「可订购号精确匹配」门禁，放行未命中目录的候选")
    a = ap.parse_args()
    if a.keep_unverified:
        global KEEP_UNVERIFIED
        KEEP_UNVERIFIED = True

    idx = Index().load(a.index if a.index.startswith("mysql") else Path(a.index))
    print(f"[index] {a.index} -> {len(idx)} 料号", flush=True)
    if a.selftest:
        selftest(idx)
        return

    files = sorted(Path(a.src).glob("*.json"))
    if a.only:
        files = [f for f in files if a.only.lower() in f.name.lower()]
    if not files:
        raise SystemExit(f"no json in {a.src}")

    universe = load_universe()
    print(f"model={model_for('alternatives')} index={len(idx)} universe={len(universe)} files={len(files)}")
    rows = []
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = {ex.submit(run_one, f, idx, universe, not a.no_render, a.keep_unmatched): f
                for f in files}
        for fut in as_completed(futs):
            r = fut.result()
            rows.append(r)
            print(f"[{'OK ' if r['status'] == 'ok' else 'ERR'}] {r['mpn']:<24} {r['secs']:>6.1f}s "
                  f"alts={r['n']} verified={r['verified']} linked={r['matched']} "
                  f"{(r['error'] or r['out'])[:50]}")

    # 待补内链队列：AI 给了候选但站内没有 → 运营/入库侧要补的型号
    missing: dict[str, dict] = {}
    for f in ALTS.glob("*.json"):
        p = json.loads(f.read_text(encoding="utf-8"))
        for r in p.get("alternatives", []):
            if not r.get("internal"):
                k = norm(r["mpn"])
                prev = missing.get(k)
                if prev is None or r.get("similarity", 0) > prev["similarity"]:
                    missing[k] = {"mpn": r["mpn"], "manufacturer": r.get("manufacturer", ""),
                                  "similarity": r.get("similarity", 0),
                                  "referenced_by": p["mpn"]}
    ALTS.mkdir(parents=True, exist_ok=True)
    with open(ALTS / "_missing_links.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=["mpn", "manufacturer", "similarity", "referenced_by"])
        w.writeheader()
        for v in sorted(missing.values(), key=lambda x: -float(x["similarity"] or 0)):
            w.writerow(v)

    total = sum(r["n"] for r in rows)
    linked = sum(r["matched"] for r in rows)
    print(f"\nalts={total} linked={linked} "
          f"({linked / total * 100 if total else 0:.0f}%) "
          f"missing_queue={len(missing)} -> data/alts/_missing_links.csv")


if __name__ == "__main__":
    main()
