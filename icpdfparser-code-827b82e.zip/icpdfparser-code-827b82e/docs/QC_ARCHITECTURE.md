# IcPdfParser QC 模块实体清单及其角色功能说明

> **QC 体系的核心哲学**：物理坐标驱动（不轻信模型）、事实单一来源（Facts SSOT）、拒绝假绿（反静默门禁）。本清单定义了 QC 流水线中流转的核心数据实体、规则引擎和基线资产。

## 1. 数据资产类（Data Assets）

这些是 QC 流程处理的对象及其最终产物。

| 实体名称 | 存储位置/载体 | 角色定位与功能说明 |
| :--- | :--- | :--- |
| **PDF (原厂数据)** | `data/pdfs/` | **唯一物理事实源**。所有参数对错的最终裁决标准。必须校验 SHA-256。 |
| **Parsed JSON** | `data/parsed/` | **模型初步解析产物**。包含 LLM 的抽取结果，允许存在幻觉、列错位、范围塌陷等错误。 |
| **Facts JSON** | `data/facts/` | **单一事实源 (SSOT)**。经过 `table_audit` 物理校验、`identity_scope` 身份剥离、`postprocess` 合并后的纯净数据。**下游渲染唯一允许读取的源**。 |
| **TXT / HTML** | `data/txt/` | **最终渲染产物**。面向客户的详情页。渲染逻辑必须防断字（如 `8.2-52V`）且防复读。 |

---

## 2. 规则与引擎类（Rules & Engines）

它们是“执法者”，负责对数据进行校验、修复或拦截。

| 实体名称 | 核心脚本 | 角色定位与功能说明 |
| :--- | :--- | :--- |
| **Table Audit** | `qc/table_audit.py` | **物理审计引擎**。基于 PyMuPDF 的 bbox 坐标，执行 MIN/TYP/MAX 分离、融合列切分、跨列拒写（防假值）、乱码拦截。 |
| **Postprocess** | `qc/postprocess_qwen.py` | **前置合并引擎**。在审计前，把模型因列拆分产生的多条同条件记录合并为一条。 |
| **Identity Scope** | `qc/identity_scope.py` | **身份隔离引擎**。识别芯片与板卡（EVM等），将芯片参数强行剥离至 `onboard_device_specs`，防止“板卡幻觉”。 |
| **JEV Client** | `qc/jev_client.py` | **语义裁判哨兵**。当物理审计遇到 `ambiguous_tie`（并列平局）且值能匹配时，调用轻量模型做最终选行裁决（只选行，不篡改值）。 |
| **Auto QC** | `qc/auto_qc.py` | **全量体检流水线**。r1-r6 批处理引擎，输出全量件的统计报表、交付包及其完整性。 |

---

## 3. 审计结果类（Audit Results）

流水线在执行过程中产生的“诊断记录”。

| 实体名称 | 数据库表 / 文件 | 角色定位与功能说明 |
| :--- | :--- | :--- |
| **Finding (发现项)** | `qc_finding` 表 / facts 里的 `metadata.audit.findings` | **审计的原子结果**。任何拦截、修复、告警都会生成一条 finding。固定字段是 `path`（定位）、`kind`（类型）、`json`（模型值）、`table`（证据）、`at`（时间）；能定位到表的还会带 `page`。⚠️ `table` 的语义**并不统一**：多数调用点存证据（如 `"FUSED_COLUMN"`、`{"row_values":[...]}`），`row_ambiguous_unresolved` 用它存表序号；`json` 也有例外（`unit_dimension_unresolved` 里存的是单位字符串）。这是历史遗留，消费方必须按 kind 分别处理。 |
| **Finding Kind** | `qc/finding_kinds.py` | **错误类型注册表**。强制规约所有引擎产出的 finding 名称（如 `range_collapse`、`cell_unparsable_unresolved`），防止拼写错误导致静默退化。注册表靠 `finding_kinds_audit --strict` 扫描 `finding(path, "kind", ...)` 的**字面量**来核对，所以**不许把 `finding()` 包成 helper**（会扫不到，曾经出过假绿）。注意 `fused_cols` 是函数名、不是 kind。 |
| **Unresolved (未决项)** | 报告中的 `unresolved` 列表 | **机器不敢修、必须交人工的队列**。如单元格脏（`cell_unparsable`）、身份未核验（`identity_unverified`）。**反假绿的核心拦截点**。 |
| **Audit Log** | `qc_audit_log` 表 | **不可篡改的台账**。记录每次跑回归、每次写入 facts 的操作轨迹、操作人（或 Agent）及耗时。 |

---

## 4. 质量基线类（Quality Baselines）

确保系统“不退化”的护城河。

| 实体名称 | 存储位置 | 角色定位与功能说明 |
| :--- | :--- | :--- |
| **Fixture (回归夹具)** | `qc/fixtures/fix11_models.txt` | **防退化锚点**。11 个极端脏型号（`DAC8555IPWG4`、`74LVC1G132DCKTG4`、`ADC3910S065IRSMT` 等）。定义了强断言：必须报什么错、不能报什么错。回归跑不通，禁止发布新版本。 |
| **Gold Set (黄金标准)** | `gold_set` / `gold_field` 表（`data/workbench.sqlite3`） | **业务真理**。由人工基于原厂 PDF 逐字核验冻结的最高标准数据（如 `BUF634PG4` 的 36 个字段）。为模型/引擎提供终极比对基准。 |
| **Source Evidence (证据卡)** | `source_evidence` 表 | **Gold Set 的支撑点**。记录支持 Gold Set 的 PDF 页码、表格行号、原文 quote、审核人。 |

---

## 5. 特别解析：Finding 的生命周期

工作台的 `qc_run` / `qc_finding` 两张表与打包门禁，都由 Finding 驱动。

1.  **触发**：`table_audit` 在比对 `parsed JSON` 和 PDF 时，发现模型给出的值是 `4`，但 PDF 这一行的 MIN 是 `60`。触发 `condition_leak`。
2.  **生成**：系统实例化一个 Finding 对象：
    *   `kind` = `condition_leak`
    *   `path` = `specs.electrical[13].value`
    *   `json` = `"4"`
    *   `table` = `"60"`
3.  **处置**：
    *   如果命中规则，系统自动修正，Finding 被标记为 `patched`。
    *   如果超出规则，找不到唯一行（ambiguous），Finding 被标记为 `unresolved`。
4.  **门禁**：验收脚本扫描 Facts 里的 Finding 集合，只要出现未被允许的 `unresolved`，直接中断打包进程（Exit 1）。

---

### 总结

整个 QC 模块的实体协同逻辑是：
**PDF（证据）** 驱动 **Rules（引擎）**，产出 **Finding（诊断）**；
人工确认后沉淀为 **Gold Set（标准）**，生成 **Facts（纯净数据）** 供交付；
而 **Fixture（夹具）** 守卫着这一整套流程，确保无论代码如何迭代，历史踩过的坑绝不会再踩第二次。

---

> **校订（2026-10-31）**：本文件初版由模型生成，按代码逐条核对后改正 5 处 ——
> ① `data/aliases/` 不存在（代码里没有任何 aliases 输出）；
> ② `fused_cols` 不是 finding kind，是函数名；
> ③ `gold_set` / `gold_field` 是 `data/workbench.sqlite3` 里的表，不是 `data/gold_set` 目录；
> ④ Finding 的 `table` 字段语义并不统一（证据串 / 行值 dict / 表序号三种），`json` 在
> `unit_dimension_unresolved` 里存的是单位字符串；
> ⑤ 夹具实体是 `qc/fixtures/fix11_models.txt` 一个文件里的 11 个型号，不是"11 件数据"。
> 另删去初版开头的对话式说明与"客户看到红/黄"这类无出处的表述。