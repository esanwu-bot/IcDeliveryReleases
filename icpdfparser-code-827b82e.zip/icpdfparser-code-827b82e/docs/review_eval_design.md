# Review 评测集构造方案

## 一、目标

建立一套可重复、可量化的 Review 质量评测体系，用于：
1. 评估当前 Review 模型的问题识别能力（召回率、精确率、误报率）
2. 对比不同 Review 候选模型的效果
3. 定位 Review 在哪些类型的问题上表现好/差
4. 为后续 Repair 评测提供已确认的问题清单

## 二、评测集结构

```
data/review_eval/
├── samples/
│   ├── {mpn_1}/
│   │   ├── parsed.json              # 待审查的解析结果
│   │   ├── ground_truth.json        # 人工标注的真实问题
│   │   ├── pdf_ref.txt              # 原始 PDF 路径（用于人工核验）
│   │   └── notes.md                 # 标注说明（可选）
│   ├── {mpn_2}/
│   │   └── ...
│   └── ...
├── eval_config.json                 # 评测配置
└── results/
    ├── {timestamp}_{model_name}/
    │   ├── per_sample.json          # 逐件对比结果
    │   ├── metrics.json             # 聚合指标
    │   ├── confusion_matrix.json    # 混淆矩阵（按问题类型）
    │   └── report.md                # 可读报告
    └── ...
```

## 三、Ground Truth 标注格式

```json
{
  "mpn": "BUF634PG4",
  "annotator": "human",
  "annotated_at": "2026-10-29T16:00:00+08:00",
  "has_issues": true,
  "issues": [
    {
      "id": "issue_001",
      "type": "electrical_value_error",
      "severity": "P0",
      "field_path": "specs.electrical[0].value",
      "description": "Supply Voltage 数值应为 ±18V，实际解析为 -18 to 18",
      "expected": "±18",
      "actual": "-18 to 18",
      "evidence_quote": "Supply voltage: ±18V (from PDF page 3)",
      "confidence": "high"
    },
    {
      "id": "issue_002",
      "type": "unit_error",
      "severity": "P1",
      "field_path": "specs.electrical[7].unit",
      "description": "Slew Rate 单位应为 V/µs，实际解析为 V/us（ASCII 替代）",
      "expected": "V/µs",
      "actual": "V/us",
      "evidence_quote": "Slew rate: 2000 V/µs (from PDF page 4)",
      "confidence": "high"
    }
  ],
  "verified_fields": [
    "basic_info.mpn",
    "basic_info.manufacturer",
    "specs.electrical[*].name",
    "specs.absolute_max[*].value"
  ],
  "notes": "重点检查电气参数表和绝对最大额定值表"
}
```

## 四、问题类型分类

### 4.1 电气参数类（Electrical）
- `electrical_value_error`: 参数数值错误（含 MIN/TYP/MAX 错位）
- `electrical_unit_error`: 单位错误（V vs mV, A vs mA, Hz vs MHz）
- `electrical_condition_missing`: 测试条件缺失或错误
- `electrical_min_typ_max_error`: MIN/TYP/MAX 列语义丢失或错位
- `electrical_parameter_missing`: 关键电气参数遗漏

### 4.2 引脚/封装类（Pin/Package）
- `pin_count_error`: 引脚数错误
- `pin_description_error`: 引脚功能描述错误
- `package_type_error`: 封装类型错误
- `package_dimension_error`: 封装尺寸错误

### 4.3 格式/结构类（Format）
- `double_escaping`: 双重转义（\\n, \\t）
- `unit_duplication`: 单位重复（V V, mA mA）
- `i18n_untranslated`: 多语言正文未翻译（英文残留）
- `json_structure_error`: JSON 结构不符合 schema

### 4.4 内容一致性类（Consistency）
- `description_mismatch`: 描述与参数表不一致
- `hero_overview_duplicate`: Hero 区域与 Overview 重复
- `cross_reference_error`: 交叉引用错误

### 4.5 证据完整性类（Evidence）
- `evidence_missing`: 缺少 PDF 页码引用
- `evidence_quote_mismatch`: 引用内容与原文不符

## 五、样本选择策略

### 5.1 样本规模
- **目标**：30-50 件代表性样本
- **分布**：
  - 15-20 件已知正确（用于测量误报率）
  - 10-15 件已知有问题（用于测量召回率）
  - 5-10 件边界案例（用于测量判别能力）

### 5.2 已知正确样本来源
- 从 `data/parsed/` 中随机抽取 20 件
- 人工快速核验（5-10 分钟/件），确认无明显错误
- 标注 `has_issues: false`

### 5.3 已知问题样本来源
- **历史 QC 发现**：从 `data/qc/reviews/` 中提取已有 review 结果
- **已知问题器件**：BUF634PG4, 74LVC1G132DCKTG4, 5962-9053801PA, AM26C32IDG4, DAC8555IPWG4
- **人工注入错误**：在正确样本上手动修改几个字段，构造已知问题

### 5.4 边界案例来源
- 参数表格式复杂（多列、合并单元格）
- 单位不常见（nV/√Hz, µA, pF）
- 测试条件描述模糊
- 多语言翻译边界（部分翻译、混合语言）

## 六、评测指标

### 6.1 核心指标
- **召回率 (Recall)**：`TP / (TP + FN)`
  - 在所有真实问题中，Review 正确识别了多少
  - 按严重程度分级：P0 召回率、P1 召回率、P2 召回率
  
- **精确率 (Precision)**：`TP / (TP + FP)`
  - 在 Review 报告的所有问题中，有多少是真实的
  - 按问题类型分组统计
  
- **误报率 (False Positive Rate)**：`FP / (FP + TN)`
  - 在正确样本中，Review 错误报告了多少问题
  
- **漏报率 (False Negative Rate)**：`FN / (TP + FN)`
  - 在有问题样本中，Review 漏掉了多少问题

### 6.2 辅助指标
- **问题类型分布**：每种问题类型的检出率
- **严重程度分布**：P0/P1/P2 各自的召回率
- **平均审查时间**：单件审查的 LLM 调用延迟
- **Token 消耗**：单件审查的输入/输出 token

### 6.3 综合评分
- **F1 Score**：`2 * (Precision * Recall) / (Precision + Recall)`
- **加权 F1**：按严重程度加权（P0 权重 3，P1 权重 2，P2 权重 1）

## 七、评测流程

### 7.1 构造评测集
```bash
python tools/build_review_eval_set.py \
  --output data/review_eval \
  --correct-samples 20 \
  --problem-samples 15 \
  --boundary-samples 10
```

脚本功能：
1. 从 `data/parsed/` 随机抽取样本
2. 复制 parsed.json 到评测集目录
3. 生成 ground_truth.json 模板
4. 对已知问题样本，预填充问题标注
5. 输出构造报告

### 7.2 人工标注
- 使用 `tools/annotate_review.py` 交互式标注
- 或直接在 ground_truth.json 中编辑
- 标注完成后，运行 `tools/validate_annotations.py` 检查格式

### 7.3 运行评测
```bash
python tools/run_review_eval.py \
  --eval-set data/review_eval \
  --model qwen-flash \
  --output data/review_eval/results/20261029_160000_qwen-flash
```

脚本功能：
1. 遍历评测集所有样本
2. 调用 Review 服务（app/services/review.py）
3. 对比 Review 输出与 ground truth
4. 计算各项指标
5. 生成详细报告

### 7.4 对比分析
```bash
python tools/compare_review_eval.py \
  --baseline data/review_eval/results/20261029_160000_qwen-flash \
  --candidate data/review_eval/results/20261029_170000_qwen3.7-flash \
  --output data/review_eval/results/comparison_20261029.md
```

脚本功能：
1. 加载两组评测结果
2. 逐样本对比
3. 计算指标差异
4. 生成对比报告

## 八、人工标注工具设计

### 8.1 交互式标注脚本
```python
# tools/annotate_review.py
def annotate_sample(mpn: str, eval_dir: Path):
    parsed = load_json(eval_dir / "samples" / mpn / "parsed.json")
    ground_truth = {
        "mpn": mpn,
        "has_issues": None,
        "issues": [],
        "verified_fields": [],
        "notes": ""
    }
    
    print(f"标注样本: {mpn}")
    print(f"基本描述: {parsed['basic_info']['description']}")
    
    # 逐字段核验
    for i, param in enumerate(parsed['specs'].get('electrical', [])):
        print(f"\n电气参数 {i+1}:")
        print(f"  名称: {param['name']}")
        print(f"  数值: {param['value']} {param['unit']}")
        print(f"  条件: {param.get('condition', 'N/A')}")
        
        correct = input("  是否正确? (y/n/e=edit): ").strip().lower()
        if correct == 'n':
            issue_type = input("  问题类型 (value/unit/condition/missing): ").strip()
            description = input("  问题描述: ").strip()
            ground_truth['issues'].append({
                "type": f"electrical_{issue_type}_error",
                "severity": "P0",
                "field_path": f"specs.electrical[{i}]",
                "description": description
            })
    
    # 保存标注
    save_json(eval_dir / "samples" / mpn / "ground_truth.json", ground_truth)
```

### 8.2 标注辅助功能
- **自动加载 PDF 原文**：打开 pdf_ref.txt 指向的 PDF
- **高亮显示字段**：在终端中用颜色标记已核验/未核验字段
- **批量标注模式**：对相似器件（同系列）快速复制标注
- **标注校验**：检查字段路径是否存在、问题类型是否合法

## 九、评测报告格式

### 9.1 逐件对比报告
```markdown
# Review 评测报告 - qwen-flash

- 评测时间：2026-10-29T16:00:00
- 评测集大小：45 件
- 模型：qwen-flash

## 总体指标

| 指标 | 值 |
|---|---|
| 召回率 | 78.5% (47/60) |
| 精确率 | 82.1% (47/57) |
| 误报率 | 12.3% (9/73) |
| F1 Score | 0.803 |

## 按严重程度

| 严重程度 | 召回率 | 精确率 |
|---|---|---|
| P0 | 92.3% (12/13) | 92.3% (12/13) |
| P1 | 76.5% (26/34) | 78.8% (26/33) |
| P2 | 61.5% (9/13) | 60.0% (9/15) |

## 按问题类型

| 问题类型 | 召回率 | 精确率 | 样本数 |
|---|---|---|---|
| electrical_value_error | 85.7% (18/21) | 90.0% (18/20) | 21 |
| electrical_unit_error | 75.0% (9/12) | 81.8% (9/11) | 12 |
| pin_count_error | 100% (5/5) | 100% (5/5) | 5 |
| i18n_untranslated | 66.7% (8/12) | 72.7% (8/11) | 12 |
| ... | ... | ... | ... |

## 误报案例

| MPN | 问题类型 | Review 报告 | 实际情况 |
|---|---|---|---|
| LM317 | electrical_value_error | "Input Voltage 数值错误" | 正确，Review 误判 |
| NE555 | unit_duplication | "单位重复: Hz Hz" | 正确，格式问题 |

## 漏报案例

| MPN | 问题类型 | 真实问题 | Review 未检出原因 |
|---|---|---|---|
| BUF634PG4 | electrical_unit_error | Slew Rate 单位错误 | Review 未检查该字段 |
| 74LVC1G132DCKTG4 | min_typ_max_error | MAX 列遗漏 | Review 认为结构正确 |
```

### 9.2 混淆矩阵
```json
{
  "electrical_value_error": {
    "tp": 18, "fp": 2, "fn": 3, "tn": 22
  },
  "electrical_unit_error": {
    "tp": 9, "fp": 2, "fn": 3, "tn": 31
  },
  ...
}
```

## 十、实施计划

### Phase 1: 评测集构造（1-2 天）
1. 编写 `tools/build_review_eval_set.py`
2. 随机抽取 20 件已知正确样本
3. 从历史 review 中提取 10 件已知问题样本
4. 人工标注所有样本的 ground truth
5. 验证标注格式和完整性

### Phase 2: 评测脚本开发（1 天）
1. 编写 `tools/run_review_eval.py`
2. 实现指标计算逻辑
3. 实现报告生成
4. 单元测试

### Phase 3: 基线评测（0.5 天）
1. 使用 qwen-flash 运行评测
2. 生成基线报告
3. 分析误报/漏报案例
4. 定位 Review 的薄弱环节

### Phase 4: 候选模型对比（1-2 天）
1. 使用 qwen3.7-flash 运行评测
2. 对比两组结果
3. 生成对比报告
4. 决策是否切换 Review 模型

### Phase 5: 迭代优化（持续）
1. 根据评测结果优化 Review prompt
2. 增加评测集样本
3. 定期回归测试

## 十一、风险与缓解

### 11.1 标注偏差
- **风险**：人工标注可能引入主观判断
- **缓解**：双人独立标注 + 第三方仲裁

### 11.2 样本代表性
- **风险**：评测集不能覆盖所有真实场景
- **缓解**：定期从生产数据中补充新样本

### 11.3 评测过拟合
- **风险**：过度优化评测集指标，忽视真实质量
- **缓解**：保留 20% 样本作为隐藏测试集

### 11.4 LLM 不确定性
- **风险**：同一模型多次运行结果不同
- **缓解**：每个样本运行 3 次，取多数投票结果

## 十二、成功标准

评测通过后，Review 模型应满足：
- **P0 问题召回率 ≥ 90%**：关键问题不能漏
- **精确率 ≥ 80%**：误报不能太多，否则人工复核成本高
- **F1 Score ≥ 0.75**：综合表现良好
- **单件审查延迟 ≤ 5s**：不影响生产效率

若候选模型在所有指标上优于基线 5% 以上，则推荐切换。
