# WORKBENCH — IcPdfParser 工作台

把「客户型号表 → 各平台采集 Datasheet → LLM 解析 → 详情页交付物料」整条链路做成可上传、
可排队、可预览、可打包导出的 Web 工作台。底层解析/渲染能力全部复用仓库根目录的既有脚本，
工作台只做编排与展示。

```
浏览器
  │  FastAPI（app/）
  ├─ 上传型号表 → batch + item（按归一化料号去重入库）
  ├─ 投递解析   → Redis（Celery broker）
  │                   │
  │                   └─ Celery worker（worker/）
  │                          ├─ 采集 collector.py   原厂规则/表内链接/聚合站
  │                          ├─ 下载 fetcher.py     %PDF 验真 + sha256
  │                          ├─ 解析 parse_pdf()    parse_datasheets.py
  │                          ├─ 内链 build_alternatives()  alternatives.py + 站内目录
  │                          ├─ 渲染 json_to_txt.py / seo_image.py / symbol_svg.py
  │                          └─ 回写 item（状态 / 产物路径 / 最近解析时间）
  └─ 预览 / 下载 / ZIP 导出
```

Redis 不可用时自动降级为**进程内线程池**，单机仍可跑通，只是任务不能跨进程分发
（页面右上角会显示「降级：进程内线程池」）。

---

## 1. 启动

### 一键启动（推荐）

```powershell
.\start_workbench.ps1                      # 默认 8000 端口、解析并发 2、自动开浏览器
.\start_workbench.ps1 -Port 8080 -Workers 3
.\start_workbench.ps1 -Status              # 只做环境自检，不启动任何进程
.\stop.ps1                                 # 停掉 server / worker / redis
```

`start_workbench.ps1` 按顺序做：找 Python（优先项目 venv）→ 校验依赖 → 探活 6379，
不通就用 `tools\redis` 的便携版拉起 → 启动 Celery worker → 启动 FastAPI → 轮询
`/api/health` 通了再开浏览器。Redis 起不来只提示并降级，不会中断启动。
结束时把 `port / server / worker / redis` 的 PID 写进 `data\workbench.pids`。

`stop.ps1` 关停顺序是 server → worker → redis，定位进程三条依据：PID 文件、
监听端口的进程（只认命令行带 `run_server.py` 的）、命令行含 `run_worker.py` / `icpdf.conf`
的进程。参数：

| 参数 | 说明 |
|---|---|
| `-Yes` | 跳过确认（脚本默认会列出将停的进程再问一次） |
| `-KeepRedis` | 保留 Redis，下次启动更快 |
| `-DryRun` | 只列出会停哪些进程，不动手 |
| `-Port 8080` | 换端口时同步指定 |

Redis 只认 `tools\redis` 下这个实例（按可执行文件路径判断），不会碰系统服务里那个。

脚本被策略拦住时：

```powershell
powershell -ExecutionPolicy Bypass -File .\start_workbench.ps1
```

脚本存为 UTF-8 with BOM，Windows PowerShell 5.1 下中文输出不会乱码。

双击 `start_workbench.bat` 是同样效果的简易版；也可以手动三步：

```bash
# 0) 依赖（一次性）
pip install -r requirements.txt

# 1) Redis（本机 6379）
tools\redis\redis-server.exe tools\redis\icpdf.conf

# 2) Celery worker（Windows 用线程池，并发取 ICFPDF_WORKERS，默认 2、本机 .env.local 设 6）
python run_worker.py

# 3) 工作台
python run_server.py            # http://127.0.0.1:8000
```

> `redis==5.0.8` 是刻意的：redis-py 8.x 默认走 RESP3（`HELLO 3`），连老版本 Redis（5.x，
> phpstudy/一键包常见）会直接报 `unknown command HELLO`，Celery 也会因此连不上。
> 如果服务端是 Redis 6+，可以升级 redis-py，不影响本工作台。

环境变量（可选）：

| 变量 | 默认 | 说明 |
|---|---|---|
| `ICPDF_REDIS` | `redis://127.0.0.1:6379/0` | broker + result backend |
| `ICPDF_QUEUE` | `icpdf` | 队列名 |
| `ICPDF_WORKERS` | `2` | worker 并发 / 降级线程池大小。本机在 `.env.local` 设为 **6** |
| `ICPDF_AGGREGATOR` | `0` | 打开聚合站采集（alldatasheet 等，易 403） |
| `ICPDF_INLINE_FALLBACK` | `1` | Redis 不可用时是否降级为线程池 |
| `ICPDF_WORKBENCH_DB` | `data/workbench.sqlite3` | 工作台库 |
| `ICPDF_PRICES` | 空 | 模型单价，JSON（元 / 百万 token）。配了才算钱，不配只统计 token |
| `ICPDF_LANGS` | 空 | 多语种输出，如 `ja,ko`。留空则 prompt 里不出现 `multi_language`（省约 17% 输出） |
| `ICPDF_ALTS_AI` | `auto` | 替代型号是否调 AI：`auto` / `always` / `never`。`always` 也只做目录内排序 |
| `ICPDF_ALTS_MIN` | `3` | `auto` 下：ordering_info 的内链命中数低于它才调 AI |
| `ICPDF_ALTS_POOL` | `60` | 喂给模型的站内目录候选上限（另取 2 倍原始候选做安全过滤） |
| `ICPDF_ALTS_BOARD` | `1` | 板卡/模块走「板载器件查目录」；设 `0` 关闭该分支，按普通料号处理 |
| `ICPDF_BATCH_MODEL` | `DASHSCOPE_MODEL` | Batch 通道用的模型 |
| `ICPDF_FETCH_BUDGET` | `90` | 单型号采集总预算（秒）。超了直接判 nodata，避免占死并发槽位 |

上面这些变量会先读 `.env.local` / `.env`（`os.environ.setdefault`，真实环境变量优先），
所以调并发不用改代码，改完重启 worker 即可。

**并发怎么定**：这条链路 98% 的时间在等模型（94~178 秒/型号），CPU 基本空闲，
并发数与核数没关系，只受三件事约束——内存（每路在途约 100~300 MB）、
SQLite 写锁（写入量很小）、以及**模型网关的并发配额**。超过网关限额会 429/超时，
表现为「一直在重试」，吞吐反而下降。先加 2 路观察日志再往上加。

---

## 2. 三份输入

| 输入 | 用途 | 落到哪 |
|---|---|---|
| 客户型号表（xlsx/xls/csv） | 待处理的型号清单 | `item` 表（按归一化料号去重） |
| 站内商品目录（xls/xlsx，`title / brand_name / link`） | **内链候选池（AI 只排序）** | `data/products.sqlite3`（`catalog` 表） |
| 应用领域图片命名表（xlsx，`Application Category / Image Filename`） | **图片 SEO** 的词表 | `app_image` 表 + `data/app_images.csv` |

后两份都是「以最新上传的为准」：

- 目录上传后后台重建索引（约 1–2 分钟，先写 `products.building` 再原子替换，重建期间旧索引照常可用）。
- 图片命名表秒级导入，同时重写 `data/app_images.csv` 并热刷新 `json_to_txt.APP_IMAGES`，不用重启。
- 首次启动时若 `app_image` 为空且 `uploads/` 里有命名表，会自动导入一次。

型号表按客户模板的列来（工作台里点「下载型号表模板 .xlsx」可拿到空表 + 填写说明）：

| 列 | 必填 | 用途 |
|---|---|---|
| 型号 | 是 | 按「去非字母数字并大写」归一化后全库去重 |
| 品牌 | 建议 | 决定用哪家原厂的 URL 规则去直拼 Datasheet |
| 封装 | 否 | 线索，展示在列表副标题；解析结果里的封装仍以 PDF 为准 |
| 包装 | 否 | 线索，随 `meta` 存下来备查 |
| 产品描述 | 否 | 线索，随 `meta` 存下来备查 |
| PDF链接 | 否 | 有就优先用（TI 网关 / Rochester 查看页会自动改写），留空则按原厂规则直拼 |

列是靠表头关键词识别的（`型号/mpn/part number/料号`、`品牌/brand/厂商`、`PDF链接/datasheet/url`），
不是按列序号，所以自建表只要表头能对上就行；完全识别不到表头时，退化为「第一列当型号」。
一个单元格里塞多个型号（`LM358;LM324`）会自动拆开。单批默认上限 2 万行
（`ICPDF_MAX_UPLOAD` 可调），超出会在批次备注里标明已截断。

---

## 3. 数据模型（`data/workbench.sqlite3`）

| 表 | 作用 | 关键点 |
|---|---|---|
| `batch` | 上传批次 | `kind` 区分 型号表 / 站内目录 / 图片命名表 |
| `item` | 一个型号一行 | **`mpn_key` 唯一** —— 全库去重就落在这里 |
| `item_batch` | 型号 × 批次 | 同型号跨批次复用，批次导出不漏 |
| `doc_source` | 采集轨迹 | `(mpn_key, url)` 唯一，成功失败都记，含 http 状态与错误 |
| `app_image` | 图片 SEO 词表 | 随最新上传覆盖 |
| `llm_usage` | 模型调用记账 | 每次 chat/completions 一行：阶段/模型/网关/tokens/耗时/成败。没有它就没法算钱、也没法比较网关 |
| `event` | 事件时间线 | 上传 / 投递 / 下载 / 解析 / 异常 |
| `kv` | 杂项 | 索引建库时间、导出路径等 |

去重与「最近一次解析时间」的口径：

- 归一化料号 = 只留字母数字并大写（`ADS1201U-1/1K` → `ADS1201U11K`），与站内 URL slug 一致；
- 同一型号重复上传只会刷新批次关系，不会新建 `item`；
- `last_parsed_at` / `parse_count` 每次真正跑完解析都会更新（含失败与「非 datasheet 跳过」，
  因为那也是花过 token 的一次尝试）；
- 已 `done` 且未强制时，再次投递直接标记 `skipped`，不重复烧模型；
- PDF 按 `sha256` 记录，模型改写型号（EVM 类文档）也不影响文件与型号的关联。

`item.status` 状态机：

```
pending → queued → resolving → downloading → parsing → rendering → done
                                   │            │
                                   ├→ nodata    └→ failed / skipped（非 datasheet）
                                   └→ failed
```

### 用量记账（`llm_usage`）

每次 chat/completions 记一行：阶段（`parse` / `repair` / `alternatives`）、模型、网关 host、
输入/输出/合计 token、耗时、成败。`/api/usage/summary` 与「运行状态」页的 Token 用量卡片
都读这张表。

实测单型号（agnes-3.0-flash，2026-10-23 样本）：

| 阶段 | 占比 | 平均耗时 |
|---|---|---|
| `parse` | 92.5% token | 142 s |
| `alternatives` | 7.5% token | 12.5 s |
| 合计 | **约 11k token/型号**（输入 8k / 输出 3k） | 约 77 s |

想算钱就配单价（元/百万 token），不配只统计 token —— 不猜价格：

```
ICPDF_PRICES={"agnes-3.0-flash":{"in":0.8,"out":2.0}}
```

仓库不预置任何价格，因为各家计费口径（包月额度 / 按量 / Batch 折扣）不同，
单价应该由使用者按自己的合同填。

---

## 4. 一条型号的 7 件交付物

| # | 产物 | 文件 | 说明 |
|---|---|---|---|
| 1 | Datasheet 原件 | `data/pdfs/{型号}__{原名}.pdf` | 归档 / 复核 |
| 2 | 结构化 JSON | `data/parsed/{型号}_{hash8}.json` | 唯一事实来源 |
| 3 | 详情页 HTML 片段 | `data/txt/{型号}.txt` | 直接注入站点正文，最多 10 段 |
| 4 | 替代型号 JSON | `data/alts/{型号}.json` | 候选 + 是否内链命中 + `ai_mode` / `onboard_mpn` |
| 5 | 替代型号内链片段 | `data/alts/{型号}.html` | `#equivalent` 段，只输出命中的型号 |
| 6 | 三视图 | `data/symbols/{型号}.html` | 原理图符号内联；封装与 3D 引用共享图库 `data/pkgs/{KEY}.svg` |
| 7 | 图片 SEO 清单 | `data/seo/{型号}.json` | 配图文件名 + alt/title/caption |

工作台里每件产物都能单独预览/下载，也能整包 `ZIP`（附 `_manifest.csv`）。

---

## 5. 采集：链接从哪来

按成本从低到高依次尝试，命中即停，每一步都写入 `doc_source`：

| 层 | 说明 |
|---|---|
| `manual` | 详情抽屉里手工粘贴的 PDF 直链，优先级最高，用于兜底 |
| `sheet` | 型号表自带的链接；TI 网关 / Rochester 查看页会先按规则改写成文件本体 |
| `cached` | 该型号上次成功下载的链接，增量重跑零成本 |
| `vendor` | 原厂规则直拼：TI / ST / Microchip / ADI / onsemi / NXP / Diodes / Silicon Labs / Espressif / Renesas |
| `agg` | 聚合站搜索（alldatasheet / datasheetspdf），默认关闭 |

都拿不到就标记 `nodata`，并保留全部尝试记录 —— 详情页可以直接看到「试过什么、为什么失败」。

---

## 6. 内链匹配：目录候选优先，AI 只做排序

`alternatives.py` 的 `Index` 支持三种后端（SQLite / CSV / MySQL）。工作台分两条路：

**datasheet 同系列（零幻觉来源）**：`grounded_rows()` 取 `ordering_info`，再走

1. `exact` —— 归一化全等；
2. `family` —— 剥掉 `-R7 / TR / REEL / TRAY` 等包装后缀后同族；
3. `series` —— **工作台开启**：候选是站内料号的前缀，且分歧点后面紧跟**字母**。

**站内目录候选（AI 排序的候选池）**：`Index.candidates(prefix)` 用主键范围扫描
（`key >= prefix AND key < prefix~`，60 万行也是毫秒级），再经 `prefix_safe` 过滤。
`search_prefix()` 会剥包装后缀并去掉尾部封装字母：`LM358DR → LM358`、
`AD8606ARMZ-R7 → AD8606`、`TPS7A0233DBVR → TPS7A023`。

安全边界（别去掉）：短的一方后面**紧跟数字的一律拒绝** —— 否则 `LM35`（温度传感器）
会因为前缀命中 `LM358`（运放）而链错型号，这类错误在元器件页面上是事故。
`LM35` 实测为 `miss`，`LM358` 命中 `LM358D`。

**AI 只做目录内排序**：候选池全部来自 `data/products.sqlite3`，`propose_grounded()`
要求模型原样返回清单中的 MPN，清单外的料号（含编造的 `nRF9050`）直接丢弃。
目录没覆盖该系列时不调模型，片段明确写「catalog has no entry / does not cover」。

**AI 不是每次都调**（`ICPDF_ALTS_AI=auto`，默认）：先拿 `ordering_info` 匹配目录，
命中 ≥ `ICPDF_ALTS_MIN`（默认 3）条就直接跳过；`always` 只强制排序；实际调用时每次约
12.5 秒 / 1 千 token（候选清单按 `ICPDF_ALTS_POOL` 截断）。

**评估板/套件**（`EVM / EVK / EMK / EVB / EVAL / KIT / BOARD / MODULE` 或 `PCB-UNK`）：
不调 AI，先从料号反推板载器件（`CC1020EMK-868 → CC1020`、`BQ25895EVM-664 → BQ25895`），
再查站内目录，只输出板载器件的链接。板载器件未收录时片段明确说明，不拿别的芯片凑数。
`ICPDF_ALTS_BOARD=0` 可关闭该分支。

---

## 7. 三视图：按封装共享，不是按型号各画

三格三视图的生成方式并不一样：

| 格 | 生成方式 | 能否共享 |
|---|---|---|
| 原理图符号 | 由 `pin_configuration` 内联生成 | 否——带引脚名（AVDD / REFEN / GPIO2），型号特有 |
| 封装俯视 | 引用 `data/pkgs/{KEY}.svg` | 是——只由「封装族 + 脚数」决定 |
| 3D 示意 | 引用 `data/pkgs/{KEY}.3d.svg` | 同上 |

KEY 由 `symbol_svg.canon_pkg(package_type, pins)` 归一，脚数优先取 `specs.package.pins`：

```
64-VQFN or 64-LQFP   -> VQFN-64     （多封装取第一个）
8-Lead VSSOP         -> VSSOP-8
FCBGA (144)          -> FCBGA-144
38-TSSOP             -> TSSOP-38
```

两条生成路径，产物完全一致，可以混用：

- **按需**（在线链路默认）：跑批时算出 KEY，`data/pkgs` 里没有就**当场生成一次**，
  之后所有同封装型号共用（`app/services/pkg_lib.py`）。
- **批量**：`python -m app.cli pkg-lib --backfill` 扫 `data/parsed/*.json` 把缺的一次补齐，
  等价于「数据源」页的「补齐缺失封装图」按钮；命令行版的
  `build_pkg_lib.py --all --preset` 还能预先铺满 85 种标准封装。

板卡/模块类（`PCB` / `BoosterPack` / 评估板）归 `PCB-UNK`，**不共享、不进库**——每块板
都不一样，共享没有意义，页面照常内联生成。所以「覆盖率」永远不可能到 100%，看的是
`report()` 里 `shared / (shared + missing)`。

`item.meta` 会记下 `pkg_key` / `pkg_shared` / `pkg_generated`，可以回溯某个型号的封装图
是命中的还是新生成的。

## 8. 图片 SEO

词表来自最新上传的命名表，规则是「型号 + 应用领域 + 类别」的组合，而不是一句通用 alt：

```
alt      = "{MPN} {应用领域} application — {类别} illustration"      # ≤125 字符，超出截断加省略号
title    = "{MPN} used in {应用领域} ({类别})"                        # ≤70 字符
filename = "{mpn}-{类别}.png"                                        # 供 CDN 重命名
asset    = /upload/img/{命名表里的原文件名}
```

`data/seo/{型号}.json` 里还带上 `doc.seo` 的 title/meta/keywords，前端可以直接整段取用。
详情页 `#application` 段的 `<img>` 会被替换成带 `alt/title/loading=lazy/decoding=async` 的版本；
命名表里没配图的类别，工作台预览会用一张按文件名生成的占位 SVG 顶上。

---

## 9. API

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/health` | 队列模式 / Redis / 索引 / 图表的自检 |
| GET | `/api/overview` | KPI + 最近事件 |
| POST | `/api/uploads/parts?auto_start=&force=` | 上传型号表（`auto_start=1` 直接投递） |
| GET | `/api/template/model-table` | 下载型号表模板（型号/品牌/封装/包装/产品描述/PDF链接） |
| POST | `/api/uploads/catalog` | 上传站内目录并重建索引 |
| POST | `/api/uploads/images` | 上传图片命名表（同步生效） |
| GET | `/api/items?q=&status=&batch_id=&page=&size=` | 型号列表 |
| GET | `/api/items/export.csv` | 型号 + PDF 链接 + 最近解析时间 导出 |
| POST | `/api/items/parse` | `{mpn_keys \| batch_id \| filter{q,status}, force, only}` 批量投递；`only=pending` 只挑未完成的 |
| POST | `/api/items/{key}/parse` | `{force, manual_url}` 单型号重跑 / 补链 |
| GET | `/api/items/{key}` | 详情（产物清单 + 采集轨迹 + 事件） |
| GET | `/api/items/{key}/preview/{kind}` | `txt / symbols / alts / seo / json` 预览 |
| GET | `/api/items/{key}/artifact/{kind}` | 单件下载 |
| POST | `/api/items/{key}/export` | 单型号 ZIP |
| POST/GET | `/api/batches/{id}/export` | 整批 ZIP（异步，GET 查进度拿下载链接） |
| GET | `/media/pkg/{name}`、`/media/img/{name}` | 预览用封装图 / 配图（缺图自动占位） |
| GET | `/api/pkgs/report` | 封装图库覆盖率：命中 / 待补 / 板卡类不共享 |
| POST | `/api/pkgs/backfill` | 把已解析型号缺的封装图一次性补齐（纯本地绘制） |
| GET | `/api/usage/summary?days=` | 模型用量汇总：调用次数 / token / 耗时，按模型与阶段分组 |

`input` 里不接受任意文件路径，下载只按库里记录的路径取，避免目录穿越。

---

## 10. 运维命令

```bash
python -m app.cli stats                          # 状态分布
python -m app.cli rebuild --all                  # 用已有 JSON 重渲染（不花 token）
python -m app.cli rebuild --keys LM358           # 只重渲染指定型号
python -m app.cli reset --keys LM358             # 清空产物，下次重走全链路
python -m app.cli pkg-lib                        # 封装图库覆盖率（缺哪些）
python -m app.cli pkg-lib --backfill             # 把缺的封装图一次性生成
python -m app.cli worker-stop                    # 让 worker 跑完当前任务再退出（不丢队列）
python -m app.cli batch emit --limit 200         # 把待解析型号打成 Batch 请求文件（含下载）
python -m app.cli batch submit --yes             # 上传并创建批次
python -m app.cli batch status                   # 查进度
python -m app.cli batch ingest                   # 下载结果 -> 写 JSON -> 生成交付物
```

### Batch 通道（异步 5 折）

在线链路一个型号要 66~156 秒且占并发槽位；百炼异步批处理**不占在线并发、按 5 折计费**，
代价是延迟（分钟到小时级），适合清历史积压而不是等结果。

```
emit -> submit -> status -> ingest
```

- `emit` 会先补下载没 PDF 的型号（`ICPDF_BATCH_MODEL`，默认 qwen-flash）；
  本地 `is_datasheet` 判掉的（User Guide / 扫描件）不进批次，不花钱。
- `custom_id` 用归一化料号，回填时靠它精确对回型号——模型可能改写 `basic_info.mpn`。
- `ingest` 写完 JSON 后走的还是 `finish_item()`，与在线链路的产物完全一致
  （内链 / 详情页 / 图片 SEO / 三视图 / 封装图库）。
- 结果里 `403` 之类通常是 key 没有 Batch 权限；`/files`、`/batches` 走的是 DashScope
  OpenAI 兼容模式，与 `chat/completions` 同一个 key。

改了 `pipeline.py` / `pkg_lib.py` / `celery_app.py` 之后**必须重启 worker** 才生效；
只改渲染模板（`json_to_txt.py` / `seo_image.py`）可以不动 worker，用 `rebuild` 重渲染。

> 注意：本机 `app.control.inspect / shutdown` 走不通（Redis 广播收不到回复），
> `worker-stop` 可能返回 0 个 worker。此时只能强杀进程，被中断的 1~2 个型号
> 按上表「解析中卡住」的办法补投，Redis 里排队的消息不会丢。

改了 `json_to_txt.py` / `symbol_svg.py` / 图片命名表之后，用 `rebuild` 而不是重解析 ——
解析结果 JSON 没变，没必要再调模型。

---

## 11. 排障

| 现象 | 原因 | 处理 |
|---|---|---|
| 页面右上角「降级：进程内线程池」 | Redis 没起 / 端口不通 | 起 Redis；`/api/health` 里 `redis_ok` 应为 true |
| `unknown command HELLO` | redis-py 8 走 RESP3，服务端太老 | `pip install "redis==5.0.8"` |
| worker 起来了但不消费 | 队列名不一致 | worker 与 `ICPDF_QUEUE` 必须同为 `icpdf` |
| 型号一直 `nodata` | 品牌列缺失，原厂规则拼不出来 | 详情抽屉手工补链，或补上品牌列重传 |
| 交付物十几分钟不增长 | 槽位被"采集地狱"占住：下载超时后还会逐个 probe 厂商候选 | 现已用 `ICPDF_FETCH_BUDGET`(90s) 兜底；仍出现就看详情页的采集轨迹，多半是站点整体慢 |
| 解析很慢（1–5 分钟/型号） | 98% 时间在模型生成 | 加大 `ICPDF_WORKERS` 并起多个 worker |
| 内链 0 命中 | 站内目录没导入 / 型号不在目录 | 数据源页看索引条数，重建索引 |
| 评估板内链 0 命中 | 板载器件未收录站内目录 | 看 alt JSON 的 `onboard_mpn` / `ai_mode`；补目录后 `rebuild` |
| 配图都是同一个 | 应用领域文本太泛 | 换命名表的类别关键词，或补 `APP_RULES` |
| 三视图里每个型号各画一张封装图 | 该封装的 `{KEY}.svg` 不在库里 | 跑批会自动生成一次；历史型号用 `pkg-lib --backfill` 补齐 |
| 封装 KEY 很怪（如 `8LEADVSSOP-8`） | `canon_pkg` 没识别这个族名 | 往 `symbol_svg.FAMILIES` 补族名（长的在前），再 `rebuild` |
| ZIP 下载 404 | 导出文件被清理 | 重新点「打包导出」 |
| 型号停在「解析中」很久不动 | worker 被强杀，消息还挂在 unacked | 状态筛选「解析中」→ 全选 →「解析选中」→ 确定（强制重跑）。已加 `visibility_timeout=1800`，正常情况 30 分钟内会自动回队 |
