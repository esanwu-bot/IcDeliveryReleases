# 2026-10-28 全量自动 QC 汇总（30 件/批 · r1–r6）

范围：**13,504 件 done** → **451 批**；机器自动 QC，人工语义/母语/视觉未执行。

| 项 | 值 |
|---|---|
| 批次 | 451 |
| 自动 QC 批次 | PASS **233** / FAIL **218** |
| 逐件 | PASS **7,688** / WARN **5,187** / FAIL **629** |
| ZIP 总量 | **22.65 GB**（451/451 读回通过） |
| 用时/错误 | 681.4s / 0 |
| Gold 对照件 | 10（无 Gold 的批次 r4=NOT_APPLICABLE） |

## 失败代码（r1–r6）

| 阶段 | 代码 | 件数 |
|---|---|---:|
| r1 | `MPN_MISMATCH` | 476 |
| r1 | `PDF_SHA_MISMATCH` | 97 |
| r3 | `ELECTRICAL_ROW_BAD` | 46 |
| r2 | `ELECTRICAL_EMPTY` | 10 |

## 说明

- `MPN_MISMATCH`：JSON 型号与 item 型号不一致（EVM/变体若仅有前缀/型号片段关系已降为警告）。
- `PDF_SHA_MISMATCH`：item.pdf_sha256 与当前 pdf_path 文件不一致，需修元数据或 PDF。
- `ELECTRICAL_ROW_BAD` / `ELECTRICAL_EMPTY`：解析行缺 name/value 或电气表为空。
- `RELEASE_APPROVED=false`：自动 QC 不等于发布批准；L3 人工语义未做。
- 批次 ZIP/报告：`data/qc/qc30-20261028-0001..0451/`；进度与计划在 `_staging/`。
