# QC Agent Tools 层设计

## 一、现有能力 → Tool 映射表

| 提议 Tool 名称 | 对应现有代码 | 函数/入口 | 权限 | 备注 |
|---|---|---|---|---|
| `qc.get_findings` | `app/services/review.py` + `qc/auto_qc.py` + `app/api/qc.py` | `get_report()`, `check_item()` 的 findings 输出, HTTP `GET /api/qc/audit-log` | 只读 | 聚合 review findings + auto_qc findings |
| `qc.get_device_snapshot` | `data/parsed/{SAFE}.json` + `app/db.py` | 读 JSON + 查 `item` 表 | 只读 | 返回当前字段、版本、来源 |
| `qc.auto_qc` | `qc/auto_qc.py` | `check_item(item, data_dir, gold, ...)` | 只读（dry-run 模式） | 不写 ZIP，只返回 findings |
| `qc.pandas_analyze` | `app/services/qc_analyzer.py` | `run_analysis(db, filters, ...)` | 只读（不 persist） | 返回分析结果，不写分析快照表 |
| `qc.get_evidence` | `qc/evidence_chain.py` + `qc/evidence_verify.py` | `run_all(db, mpn, dry=True)`, `batch_verify()` | 只读（dry=True） | 返回证据链，不写表 |
| `qc.compare_fields` | 新建（薄封装） | 读两份 JSON，按 field_path 比较 | 只读 | 计算修复前后差异 |
| `qc.propose_patch` | `worker/fixers.py` | 各 `fix_*()` 函数 | 候选写入（隔离副本） | 生成补丁，不覆盖原数据 |
| `qc.validate_patch` | `worker/fixers.py` + `qc/table_audit.py` | `audit_electrical()`, 规则校验器 | 只读 | 验证补丁是否满足约束 |
| `qc.run_regression` | `qc/qc_regression.py` + `qc/table_audit.py` | `run_one(mpn, write=False)` | 只读（dry 模式） | 验证已知问题是否复发 |
| `qc.commit_patch` | `worker/fixers.py::commit()` | `commit(ctx, patch)` | 受限写入 | 在授权后应用补丁并留存快照 |
| `qc.recheck_finding` | `app/services/review.py` | `run_review(db, mpn, dry_run=True)` | 只读 | 重新检查原 Finding 是否解决 |
| `qc.audit_repair` | `app/db.py` + `app/api/qc.py` | INSERT `qc_audit_log` | 追加写入 | 记录工具调用、输入输出、差异 |

## 二、Tool JSON Schema 设计

### 2.1 `qc.get_findings`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "sources": ["review", "auto_qc", "table_audit"],
  "severity_filter": ["P0", "P1"],
  "limit": 50
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "findings": [
    {
      "finding_id": "F-001",
      "source": "review",
      "kind": "i18n_body_untranslated",
      "severity": "P1",
      "message": "ja 正文有 4 段与英文原文逐字相同",
      "field_path": "txt.ja",
      "evidence": {
        "quote": "Absolute maximum ratings limit...",
        "page_hint": null
      },
      "created_at": "2026-10-29T12:50:37+08:00"
    }
  ],
  "total": 4,
  "generated_at": "2026-10-29T16:00:00+08:00"
}
```

**实现**：
```python
def get_findings(mpn: str, sources: list[str] = None, severity_filter: list[str] = None, limit: int = 50) -> dict:
    """聚合 review + auto_qc + table_audit 的 findings。"""
    findings = []
    
    # 1. Review findings
    if not sources or "review" in sources:
        review_report = RV.get_report(mpn, data_dir=DATA_DIR)
        if review_report:
            for f in review_report.get("rule_findings", []):
                findings.append(_normalize_finding(f, source="review"))
            for f in review_report.get("llm_findings", []):
                findings.append(_normalize_finding(f, source="review_llm"))
    
    # 2. auto_qc findings（需要重新运行或从缓存读取）
    if not sources or "auto_qc" in sources:
        # 从 qc_run 表读取最近的 auto_qc 结果
        qc_run = db.get_latest_qc_run(mpn, tool="auto_qc")
        if qc_run:
            for f in qc_run.get("findings", []):
                findings.append(_normalize_finding(f, source="auto_qc"))
    
    # 3. 过滤和排序
    if severity_filter:
        findings = [f for f in findings if f["severity"] in severity_filter]
    findings.sort(key=lambda f: (f["severity"], f["created_at"]))
    
    return {
        "status": "OK",
        "mpn": mpn,
        "findings": findings[:limit],
        "total": len(findings),
        "generated_at": datetime.now().isoformat()
    }
```

---

### 2.2 `qc.get_device_snapshot`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "include_metadata": true,
  "include_paths": true
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "snapshot": {
    "basic_info": {
      "mpn": "BUF634PG4",
      "manufacturer": "Texas Instruments",
      "category": "Integrated Circuits (ICs)",
      "description": "The BUF634 is a high-speed..."
    },
    "specs": {
      "electrical": [...],
      "absolute_max": [...],
      "package": {...}
    }
  },
  "metadata": {
    "json_path": "E:\\workspace\\IcPdfParser\\data\\parsed\\BUF634PG4_176bed1f.json",
    "pdf_sha256": "176bed1f5b0210184e8dc7283ab48057a18d211c0f570953c9683b9815d9ba16",
    "last_parsed_at": "2026-10-23T18:50:08+08:00",
    "item_id": 8918,
    "batch_id": 4,
    "status": "done"
  },
  "paths": {
    "json": "data/parsed/BUF634PG4_176bed1f.json",
    "txt": "data/txt/BUF634PG4.txt",
    "alts": "data/alts/BUF634PG4.json",
    "seo": "data/seo/BUF634PG4.json"
  }
}
```

**实现**：
```python
def get_device_snapshot(mpn: str, include_metadata: bool = True, include_paths: bool = True) -> dict:
    """读取解析 JSON 和器件元数据。"""
    safe = safe_key(mpn)
    json_path = DATA_DIR / "parsed" / f"{safe}_*.json"
    
    # 查找匹配的 JSON 文件
    matches = list(json_path.parent.glob(json_path.name))
    if not matches:
        return {"status": "NOT_FOUND", "mpn": mpn, "error": "Parsed JSON not found"}
    
    json_file = matches[0]
    snapshot = json.loads(json_file.read_text(encoding="utf-8"))
    
    result = {
        "status": "OK",
        "mpn": mpn,
        "snapshot": snapshot
    }
    
    if include_metadata:
        item = db.get_item_by_mpn(mpn)
        result["metadata"] = {
            "json_path": str(json_file),
            "pdf_sha256": item.get("pdf_sha256") if item else None,
            "last_parsed_at": item.get("last_parsed_at") if item else None,
            "item_id": item.get("id") if item else None,
            "batch_id": item.get("batch_id") if item else None,
            "status": item.get("status") if item else None
        }
    
    if include_paths:
        result["paths"] = {
            "json": str(json_file.relative_to(REPO_ROOT)),
            "txt": str(Path(f"data/txt/{safe}.txt")),
            "alts": str(Path(f"data/alts/{safe}.json")),
            "seo": str(Path(f"data/seo/{safe}.json"))
        }
    
    return result
```

---

### 2.3 `qc.auto_qc`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "stages": ["r1", "r2", "r3", "r4", "r5", "r6"],
  "dry_run": true
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "findings": [
    {
      "severity": "P1",
      "stage": "r3",
      "code": "elec_missing_condition",
      "detail": "specs.electrical[7] 缺少 condition 字段"
    }
  ],
  "total_findings": 1,
  "stages_run": ["r1", "r2", "r3", "r4", "r5", "r6"],
  "dry_run": true
}
```

**实现**：
```python
def auto_qc(mpn: str, stages: list[str] = None, dry_run: bool = True) -> dict:
    """运行 auto_qc 检查，返回 findings（不写 ZIP）。"""
    from qc.auto_qc import check_item
    
    safe = safe_key(mpn)
    json_path = _find_parsed_json(safe)
    if not json_path:
        return {"status": "NOT_FOUND", "mpn": mpn, "error": "Parsed JSON not found"}
    
    item = {
        "mpn": mpn,
        "safe_key": safe,
        "json_path": str(json_path),
        "pdf_sha256": _get_pdf_sha256(mpn)
    }
    
    # 调用 check_item（dry_run 模式不写 ZIP）
    result = check_item(
        item=item,
        data_dir=DATA_DIR,
        gold=None,
        hash_pdf=True,
        probe_pdf=False,
        stages=stages
    )
    
    return {
        "status": "OK",
        "mpn": mpn,
        "findings": result.get("findings", []),
        "total_findings": len(result.get("findings", [])),
        "stages_run": stages or ["r1", "r2", "r3", "r4", "r5", "r6"],
        "dry_run": dry_run
    }
```

---

### 2.4 `qc.pandas_analyze`

**输入**：
```json
{
  "filters": {
    "status": "done",
    "batch_id": 4,
    "brand": "Texas Instruments"
  },
  "include_distributions": true,
  "include_root_cause": true,
  "persist": false
}
```

**输出**：
```json
{
  "status": "OK",
  "analysis": {
    "inventory": {
      "total": 150,
      "by_status": {"done": 120, "reviewed": 30},
      "by_brand": {"Texas Instruments": 80, "ADI": 70}
    },
    "distributions": {
      "finding_kinds": [
        {"kind": "i18n_body_untranslated", "count": 45},
        {"kind": "elec_missing_condition", "count": 12}
      ]
    },
    "root_cause_candidates": [
      {
        "hypothesis": "电气参数 condition 字段缺失集中在 74LVC 系列",
        "confidence": 0.78,
        "affected_mpns": ["74LVC1G132DCKTG4", "74LVC1G08DCKRG4"]
      }
    ]
  },
  "persisted": false
}
```

**实现**：
```python
def pandas_analyze(filters: dict = None, include_distributions: bool = True, 
                   include_root_cause: bool = True, persist: bool = False) -> dict:
    """运行 Pandas QC 分析，返回结果（默认不写快照表）。"""
    from app.services.qc_analyzer import run_analysis
    
    result = run_analysis(
        db=db,
        filters=filters or {},
        matrix_path=DATA_DIR / "qc" / "auto_qc_issue_matrix.csv",
        cards_path=DATA_DIR / "qc" / "evidence_cards.csv",
        pdf_root=DATA_DIR / "pdf",
        actor="agent",
        persist=persist
    )
    
    return {
        "status": "OK",
        "analysis": result,
        "persisted": persist
    }
```

---

### 2.5 `qc.get_evidence`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "stages": ["e1", "e2", "e3", "e4"],
  "dry": true
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "evidence": {
    "e1_register": {
      "document_id": "DOC-001",
      "pdf_sha256": "176bed1f...",
      "pages": 28,
      "has_text_layer": true,
      "official_domain": "ti.com"
    },
    "e2_precheck": {
      "cover_mpn_match": true,
      "ordering_table_found": true
    },
    "e3_locate": {
      "fields": [
        {
          "field_path": "specs.electrical[0].value",
          "pdf_page": 3,
          "table": "Electrical Characteristics",
          "row": 1,
          "col": "value",
          "quote": "Supply voltage: ±18V"
        }
      ]
    },
    "e4_crosscheck": {
      "matches": 15,
      "mismatches": 0,
      "unverified": 2
    }
  },
  "dry": true
}
```

**实现**：
```python
def get_evidence(mpn: str, stages: list[str] = None, dry: bool = True) -> dict:
    """运行证据链查询（E1-E4），返回证据（默认 dry 模式不写表）。"""
    from qc.evidence_chain import run_all
    
    result = run_all(db=db, mpn=mpn, dry=dry)
    
    return {
        "status": "OK",
        "mpn": mpn,
        "evidence": result,
        "dry": dry
    }
```

---

### 2.6 `qc.compare_fields`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "baseline_path": "data/parsed/BUF634PG4_176bed1f.json",
  "candidate_path": "data/qc/fix_backups/BUF634PG4_176bed1f.pre_audit.json",
  "field_paths": ["specs.electrical[0].value", "specs.electrical[7].unit"]
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "comparisons": [
    {
      "field_path": "specs.electrical[0].value",
      "baseline": "-18 to 18",
      "candidate": "±18",
      "changed": true,
      "diff_type": "value_change"
    },
    {
      "field_path": "specs.electrical[7].unit",
      "baseline": "V/us",
      "candidate": "V/µs",
      "changed": true,
      "diff_type": "unicode_normalization"
    }
  ],
  "total_changed": 2,
  "total_unchanged": 0
}
```

**实现**：
```python
def compare_fields(mpn: str, baseline_path: str, candidate_path: str, 
                   field_paths: list[str] = None) -> dict:
    """比较两份 JSON 的指定字段差异。"""
    baseline = json.loads(Path(baseline_path).read_text(encoding="utf-8"))
    candidate = json.loads(Path(candidate_path).read_text(encoding="utf-8"))
    
    comparisons = []
    paths_to_check = field_paths or _extract_all_paths(baseline)
    
    for path in paths_to_check:
        baseline_val = _get_by_path(baseline, path)
        candidate_val = _get_by_path(candidate, path)
        
        if baseline_val != candidate_val:
            comparisons.append({
                "field_path": path,
                "baseline": baseline_val,
                "candidate": candidate_val,
                "changed": True,
                "diff_type": _classify_diff(baseline_val, candidate_val)
            })
    
    return {
        "status": "OK",
        "mpn": mpn,
        "comparisons": comparisons,
        "total_changed": len(comparisons),
        "total_unchanged": len(paths_to_check) - len(comparisons)
    }
```

---

### 2.7 `qc.propose_patch`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "fixer_name": "fix_unit_duplicated",
  "target_fields": ["specs.electrical[7].unit"],
  "mode": "dry_run"
}
```

**输出**：
```json
{
  "status": "PATCH_PROPOSED",
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "fixer_name": "fix_unit_duplicated",
  "patch": {
    "field_path": "specs.electrical[7].unit",
    "old_value": "V/us",
    "new_value": "V/µs",
    "change_type": "unicode_normalization"
  },
  "candidate_snapshot_path": "data/qc/agent_patches/BUF634PG4_F-001_candidate.json",
  "validation": {
    "schema": "PENDING",
    "electrical_semantics": "PENDING",
    "regression": "PENDING"
  },
  "requires_human_review": true,
  "mode": "dry_run"
}
```

**实现**：
```python
def propose_patch(mpn: str, finding_id: str, fixer_name: str, 
                  target_fields: list[str], mode: str = "dry_run") -> dict:
    """生成候选补丁（不直接覆盖原数据）。"""
    from worker.fixers import preflight, _FIXERS
    
    if fixer_name not in _FIXERS:
        return {"status": "ERROR", "error": f"Unknown fixer: {fixer_name}"}
    
    fixer_fn = _FIXERS[fixer_name]
    
    # 1. 预检：备份 + 载入
    ctx = preflight(mpn=mpn, data_dir=DATA_DIR)
    if not ctx["ok"]:
        return {"status": "ERROR", "error": ctx["error"]}
    
    # 2. 在隔离副本上运行 fixer
    candidate_doc = deepcopy(ctx["doc"])
    ctx["doc"] = candidate_doc
    ctx["allowed_paths"] = target_fields
    
    result = fixer_fn(ctx)
    
    # 3. 保存候选快照
    candidate_path = DATA_DIR / "qc" / "agent_patches" / f"{mpn}_{finding_id}_candidate.json"
    candidate_path.parent.mkdir(parents=True, exist_ok=True)
    candidate_path.write_text(json.dumps(candidate_doc, ensure_ascii=False, indent=2), encoding="utf-8")
    
    return {
        "status": "PATCH_PROPOSED",
        "mpn": mpn,
        "finding_id": finding_id,
        "fixer_name": fixer_name,
        "patch": {
            "changed_fields": result.get("changed", []),
            "note": result.get("note", "")
        },
        "candidate_snapshot_path": str(candidate_path),
        "validation": {
            "schema": "PENDING",
            "electrical_semantics": "PENDING",
            "regression": "PENDING"
        },
        "requires_human_review": True,
        "mode": mode
    }
```

---

### 2.8 `qc.validate_patch`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "candidate_path": "data/qc/agent_patches/BUF634PG4_F-001_candidate.json",
  "validation_rules": ["schema", "electrical_semantics", "regression"]
}
```

**输出**：
```json
{
  "status": "VALIDATION_PASSED",
  "mpn": "BUF634PG4",
  "validation_results": {
    "schema": {
      "passed": true,
      "errors": []
    },
    "electrical_semantics": {
      "passed": true,
      "warnings": ["specs.electrical[7].unit 从 ASCII 转为 Unicode"]
    },
    "regression": {
      "passed": true,
      "failures": []
    }
  },
  "all_passed": true,
  "requires_human_review": false
}
```

**实现**：
```python
def validate_patch(mpn: str, candidate_path: str, 
                   validation_rules: list[str] = None) -> dict:
    """验证候选补丁是否满足约束。"""
    from qc.table_audit import audit_electrical, audit_json
    
    candidate = json.loads(Path(candidate_path).read_text(encoding="utf-8"))
    rules = validation_rules or ["schema", "electrical_semantics", "regression"]
    
    results = {}
    
    # 1. Schema 校验
    if "schema" in rules:
        schema_errors = _validate_json_schema(candidate)
        results["schema"] = {
            "passed": len(schema_errors) == 0,
            "errors": schema_errors
        }
    
    # 2. 电气语义校验
    if "electrical_semantics" in rules:
        elec_audit = audit_electrical(candidate)
        results["electrical_semantics"] = {
            "passed": elec_audit["ok"],
            "warnings": elec_audit.get("warnings", [])
        }
    
    # 3. 回归测试
    if "regression" in rules:
        from qc.qc_regression import run_one
        regression_result = run_one(mpn, write=False)
        results["regression"] = {
            "passed": regression_result["exit_code"] == 0,
            "failures": regression_result.get("failures", [])
        }
    
    all_passed = all(r["passed"] for r in results.values())
    
    return {
        "status": "VALIDATION_PASSED" if all_passed else "VALIDATION_FAILED",
        "mpn": mpn,
        "validation_results": results,
        "all_passed": all_passed,
        "requires_human_review": not all_passed
    }
```

---

### 2.9 `qc.run_regression`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "write": false,
  "post": false
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "exit_code": 0,
  "result": "PASS",
  "assertions": {
    "total": 5,
    "passed": 5,
    "failed": 0
  },
  "write": false,
  "post": false
}
```

**实现**：
```python
def run_regression(mpn: str, write: bool = False, post: bool = False) -> dict:
    """运行回归测试（默认 dry 模式不写盘）。"""
    from qc.qc_regression import run_one
    
    result = run_one(mpn, write=write)
    
    return {
        "status": "OK",
        "mpn": mpn,
        "exit_code": result["exit_code"],
        "result": "PASS" if result["exit_code"] == 0 else "FAIL",
        "assertions": {
            "total": result.get("total", 0),
            "passed": result.get("passed", 0),
            "failed": result.get("failed", 0)
        },
        "write": write,
        "post": post
    }
```

---

### 2.10 `qc.commit_patch`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "candidate_path": "data/qc/agent_patches/BUF634PG4_F-001_candidate.json",
  "authorization": {
    "authorized_by": "agent",
    "authorization_reason": "VALIDATION_PASSED + P1 severity allows auto-apply",
    "run_id": "RUN-20261029-001"
  }
}
```

**输出**：
```json
{
  "status": "PATCH_APPLIED",
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "backup_path": "data/qc/fix_backups/BUF634PG4_176bed1f.json.bak",
  "applied_path": "data/parsed/BUF634PG4_176bed1f.json",
  "patch_hash": "sha256:abc123...",
  "previous_hash": "sha256:def456...",
  "audit_log_id": 12345,
  "requires_recheck": true
}
```

**实现**：
```python
def commit_patch(mpn: str, finding_id: str, candidate_path: str, 
                 authorization: dict) -> dict:
    """在授权后应用补丁并留存快照。"""
    from worker.fixers import commit
    
    # 1. 权限检查（P0 禁止自动解除阻断）
    finding = _get_finding_by_id(finding_id)
    if finding["severity"] == "P0":
        return {
            "status": "UNAUTHORIZED",
            "error": "P0 findings require human approval before patch application"
        }
    
    # 2. 载入候选补丁
    candidate = json.loads(Path(candidate_path).read_text(encoding="utf-8"))
    
    # 3. 计算哈希
    previous_hash = _compute_json_hash(_get_current_json(mpn))
    patch_hash = _compute_json_hash(candidate)
    
    # 4. 应用补丁（commit 会自动备份）
    ctx = preflight(mpn=mpn, data_dir=DATA_DIR)
    result = commit(ctx, candidate)
    
    if not result["ok"]:
        return {"status": "ERROR", "error": result["error"]}
    
    # 5. 记录审计日志
    audit_log_id = _audit_append(
        run_id=authorization.get("run_id"),
        mpn=mpn,
        kind="patch_applied",
        path=candidate_path,
        json_val={"finding_id": finding_id, "patch_hash": patch_hash},
        table_val=None,
        action="commit_patch",
        tool="qc.commit_patch",
        operator=authorization.get("authorized_by", "agent")
    )
    
    return {
        "status": "PATCH_APPLIED",
        "mpn": mpn,
        "finding_id": finding_id,
        "backup_path": result["backup_path"],
        "applied_path": result["applied_path"],
        "patch_hash": patch_hash,
        "previous_hash": previous_hash,
        "audit_log_id": audit_log_id,
        "requires_recheck": True
    }
```

---

### 2.11 `qc.recheck_finding`

**输入**：
```json
{
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "dry_run": true
}
```

**输出**：
```json
{
  "status": "OK",
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "recheck_result": "RESOLVED",
  "original_finding": {
    "kind": "i18n_body_untranslated",
    "severity": "P1",
    "message": "ja 正文有 4 段与英文原文逐字相同"
  },
  "new_findings": [],
  "resolved": true,
  "dry_run": true
}
```

**实现**：
```python
def recheck_finding(mpn: str, finding_id: str, dry_run: bool = True) -> dict:
    """重新检查原 Finding 是否真正解决。"""
    from app.services.review import run_review
    
    # 1. 获取原始 finding
    original_finding = _get_finding_by_id(finding_id)
    
    # 2. 重新运行 review
    review_result = run_review(
        db=db,
        mpn=mpn,
        data_dir=DATA_DIR,
        out_dir=DATA_DIR / "qc" / "reviews",
        with_pdf_text=False,
        dry_run=dry_run,
        write_db=False,
        operator="agent",
        force=True
    )
    
    # 3. 检查原 finding 是否还在
    new_findings = review_result.get("rule_findings", []) + review_result.get("llm_findings", [])
    resolved = not any(
        f.get("kind") == original_finding.get("kind") and 
        f.get("field_path") == original_finding.get("field_path")
        for f in new_findings
    )
    
    return {
        "status": "OK",
        "mpn": mpn,
        "finding_id": finding_id,
        "recheck_result": "RESOLVED" if resolved else "STILL_PRESENT",
        "original_finding": original_finding,
        "new_findings": new_findings,
        "resolved": resolved,
        "dry_run": dry_run
    }
```

---

### 2.12 `qc.audit_repair`

**输入**：
```json
{
  "run_id": "RUN-20261029-001",
  "mpn": "BUF634PG4",
  "finding_id": "F-001",
  "action": "patch_proposed",
  "tool": "qc.propose_patch",
  "input_data": {"fixer_name": "fix_unit_duplicated"},
  "output_data": {"patch": {...}},
  "operator": "agent"
}
```

**输出**：
```json
{
  "status": "OK",
  "audit_log_id": 12345,
  "created_at": "2026-10-29T16:00:00+08:00"
}
```

**实现**：
```python
def audit_repair(run_id: str, mpn: str, finding_id: str, action: str, 
                 tool: str, input_data: dict, output_data: dict, 
                 operator: str = "agent") -> dict:
    """记录工具调用、输入输出、差异与验证结果。"""
    log_id = _audit_append(
        run_id=run_id,
        mpn=mpn,
        kind=f"repair_{action}",
        path=None,
        json_val={"finding_id": finding_id, "input": input_data, "output": output_data},
        table_val=None,
        action=action,
        tool=tool,
        operator=operator
    )
    
    return {
        "status": "OK",
        "audit_log_id": log_id,
        "created_at": datetime.now().isoformat()
    }
```

## 三、Repair 状态机

```
┌─────────────────┐
│  FINDING_OPEN   │ ← Review / auto_qc 发现问题
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ DIAGNOSING      │ ← Agent 调用 get_findings, get_evidence, pandas_analyze
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ PATCH_PROPOSED  │ ← Agent 调用 propose_patch（dry_run）
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ VALIDATING      │ ← 调用 validate_patch（schema + electrical + regression）
└────────┬────────┘
         │
         ├─→ VALIDATION_FAILED → 回到 DIAGNOSING 或人工介入
         │
         ▼
┌─────────────────┐
│ AWAITING_AUTH   │ ← P0 需要人工审批；P1/P2 可按策略自动授权
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ PATCH_APPLIED   │ ← 调用 commit_patch（备份 + 写入 + 审计）
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ RECHECKING      │ ← 调用 recheck_finding（重新运行 review）
└────────┬────────┘
         │
         ├─→ STILL_PRESENT → 回到 DIAGNOSING
         │
         ▼
┌─────────────────┐
│ REVIEWED_QA_PASS│ ← 机器检查全部通过（现有 QC 体系）
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ RELEASE_APPROVED│ ← 经过独立授权的发布批准（P0 必须人工）
└─────────────────┘
```

## 四、Python Adapter 目录结构

```
qc/agent_tools/
├── __init__.py
├── registry.py              # Tool 注册表
├── schemas.py               # JSON Schema 定义
├── adapters/
│   ├── __init__.py
│   ├── get_findings.py
│   ├── get_device_snapshot.py
│   ├── auto_qc.py
│   ├── pandas_analyze.py
│   ├── get_evidence.py
│   ├── compare_fields.py
│   ├── propose_patch.py
│   ├── validate_patch.py
│   ├── run_regression.py
│   ├── commit_patch.py
│   ├── recheck_finding.py
│   └── audit_repair.py
├── policy.py                # 权限策略引擎
├── state_machine.py         # Repair 状态机
└── utils.py                 # 辅助函数（哈希、路径、归一化）
```

## 五、下一步实施计划

### Phase 1: 只读工具封装（1-2 天）
1. 实现 `qc/agent_tools/registry.py`（Tool 注册表）
2. 实现 6 个只读工具：
   - `qc.get_findings`
   - `qc.get_device_snapshot`
   - `qc.auto_qc`（dry_run 模式）
   - `qc.pandas_analyze`（persist=False）
   - `qc.get_evidence`（dry=True）
   - `qc.compare_fields`
3. 编写单元测试
4. 验收标准：工具输出结构化、可追溯，不改变生产数据

### Phase 2: 修复工具封装（1-2 天）
1. 实现 4 个修复工具：
   - `qc.propose_patch`
   - `qc.validate_patch`
   - `qc.run_regression`（dry 模式）
   - `qc.commit_patch`（受控写入）
2. 实现 `qc.audit_repair`
3. 实现 `qc.recheck_finding`
4. 验收标准：所有变更在隔离副本中执行，审计日志完整

### Phase 3: 状态机与策略引擎（1 天）
1. 实现 `policy.py`（P0-Pn 权限策略）
2. 实现 `state_machine.py`（Repair 状态转换）
3. 集成测试
4. 验收标准：P0 禁止自动解除阻断，P1/P2 可按策略自动授权

### Phase 4: Agent 集成（后续）
1. 将 Tool Registry 暴露给 Agent（OpenAI Tool Calling 或 MCP）
2. 实现 Repair Agent Orchestrator
3. 端到端测试
4. 验收标准：Agent 能读取 Finding、调用诊断工具、生成修复计划、应用补丁、验证结果
