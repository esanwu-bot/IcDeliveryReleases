# 全量自动 QC 问题交叉矩阵与根因分组

生成时间：2026-10-28T10:59:54+08:00  
范围：**451 批 / 13504 件**；逐件 FAIL **629**。  
边界：只读分析，**未修改生产 facts / Gold / item**；根因分组是建议分类，最终修复需证据卡与人工确认。

## 1. 结论摘要

| 项 | 值 |
|---|---|
| 逐件状态 | PASS 7688 / WARN 5187 / FAIL 629 |
| 有 FAIL 的批次 | 218 / 451 |
| 唯一 FAIL 器件 | 629 |

### 1.1 你关心的交叉问题（按唯一器件计）

| 问题 | 结果 |
|---|---|
| MPN 不一致同时 SHA 不一致 | **0** |
| MPN 不一致单独 | **476** |
| SHA 不一致单独 | **97** |
| 电气行/空表同时存在 | **0** |

## 2. 错误码与复合组合

| 错误码 | 唯一器件 |
|---|---:|
| `MPN_MISMATCH` | 476 |
| `PDF_SHA_MISMATCH` | 97 |
| `ELECTRICAL_ROW_BAD` | 46 |
| `ELECTRICAL_EMPTY` | 10 |

| 复合组合 | 器件 |
|---|---:|
| `MPN_MISMATCH` | 476 |
| `PDF_SHA_MISMATCH` | 97 |
| `ELECTRICAL_ROW_BAD` | 46 |
| `ELECTRICAL_EMPTY` | 10 |

**本轮无复合错误**：所有 FAIL 器件都只命中 1 个错误码；`MPN_MISMATCH+PDF_SHA_MISMATCH = 0`，因此 476 + 97 + 46 + 10 = 629 就是唯一 FAIL 器件数，可直接相加。

## 3. 根因分组（建议分类）

| 分组 | 器件 | 建议处理类 |
|---|---:|---|
| A3_型号错配（可能 PDF/关联错误） | 266 | source_pdf_recovery_or_human |
| A2_可订购型号/封装变体（JSON 用基础型号） | 129 | identity_normalization_or_source_review |
| E_PDF 文件被替换/版本漂移 | 97 | source_pdf_replacement_verify |
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | 81 | source_mapping_business_review |
| I_解析结构缺陷（电气表行） | 56 | parser_fix_then_rerun_item_batch |

### 3.1 分组样例（每类前 5，完整见 CSV）

| 分组 | 样例：item -> JSON / PDF |
|---|---|
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | 2MTR-DYNO -> TMS320F2806x / 2MTR-DYNO__tms320f28062f.pdf<br>COP8-PGMA-28CSP -> COP8SAB7 / COP8-PGMA-28CSP__COP8SA_Family.pdf<br>COP8-PGMA-44QFP -> COP8SAC744V9 / COP8-PGMA-44QFP__COP8SA_Family.pdf<br>ADS8900BEVM-PDK -> OPA625 / ADS8900BEVM-PDK__opa625.pdf<br>ADC32RF45EVM -> LMK04828 / ADC32RF45EVM__lmk04828.pdf |
| E_PDF 文件被替换/版本漂移 | DAC81416EVM -> — / DAC81416EVM__dac81416.pdf<br>DRV81620-Q1EVM -> — / DRV81620-Q1EVM__drv81620-q1.pdf<br>DRV81602-Q1EVM -> — / DRV81602-Q1EVM__drv81602-q1.pdf<br>BZX84C27VDBZRQ1 -> — / BZX84C27VDBZRQ1__bzx84c15v-q1.pdf<br>CSD17577Q3A -> — / CSD17577Q3A__csd17577q3a.pdf |
| A3_型号错配（可能 PDF/关联错误） | CLC730145/NOPB -> LMH6560MA / CLC730145_NOPB__LMH6560.pdf<br>CC2567PAN1327ANTBT -> MSP430BT5190 / CC2567PAN1327ANTBT__msp430bt5190.pdf<br>COP8-EMFLASH-00 -> COP8CFE9 / COP8-EMFLASH-00__COP8CFE9.pdf<br>COP8C -> COP8SG / COP8C__COP8SG_Family.pdf<br>CGS74CT2524MX -> CGS74LCT2524MX / CGS74CT2524MX__CGS74LCT2524.pdf |
| A2_可订购型号/封装变体（JSON 用基础型号） | CDC208N -> CDC208DW / CDC208N__scas109f.pdf<br>AFE539F1RTERQ1 -> AFE539F1-Q1 / AFE539F1RTERQ1__afe539f1-q1.pdf<br>ADS7952QDBTRQ1 -> ADS7952-Q1 / ADS7952QDBTRQ1__ads7952-q1.pdf<br>ADS7953QDBTRQ1 -> ADS7953-Q1 / ADS7953QDBTRQ1__ads7953-q1.pdf<br>ADS7951QDBTRQ1 -> ADS7951-Q1 / ADS7951QDBTRQ1__ads7951-q1.pdf |
| I_解析结构缺陷（电气表行） | BQ3285S-SB2 -> — / BQ3285S-SB2__bq3285.pdf<br>BQ3285LFSS-A1 -> — / BQ3285LFSS-A1__BQ3285LF.pdf<br>BQ4850YMA-85N -> — / BQ4850YMA-85N__BQ4850Y.pdf<br>BQ3287EMT -> — / BQ3287EMT__BQ3287E_2CEA.pdf<br>AFE4490RHAT -> — / AFE4490RHAT__afe4490.pdf |

| 修复类（建议） | 器件 |
|---|---:|
| `source_pdf_recovery_or_human` | 266 |
| `identity_normalization_or_source_review` | 129 |
| `source_pdf_replacement_verify` | 97 |
| `source_mapping_business_review` | 81 |
| `parser_fix_then_rerun_item_batch` | 56 |

## 4. 集中度（FAIL 器件）

| 维度 | Top |
|---|---|
| 品牌 | Texas Instruments×629 |
| 型号家族 | CD×82；DS×57；F280×39；74AH×30；BQ×24；ADS×22；DAC×19；AM×18 |
| PDF 修订标记 | —×617；2015×4；2017×3；B×1；Aug×1；Nov×1 |
| 批次 | qc30-20261028-0449×13；qc30-20261028-0013×12；qc30-20261028-0166×12；qc30-20261028-0393×12；qc30-20261028-0168×11；qc30-20261028-0211×11 |

## 5. 建议执行顺序（未改生产数据）

1. **P0 先做证据卡（全部 629 件）**：逐项记录数据库型号、PDF 文件名/原文型号、PDF SHA、facts 源 SHA、来源版本、错误类型、建议动作；先只读生成，不批量改库。
2. **P0-A2 可订购/封装变体（129）**：如 Q1/封装/速度档与基础型号差异；先确认型号归一化规则或业务口径，再重跑单件 + 受影响批次。
3. **P0-A3 源 PDF/关联错配（266）**：先抽家族/厂商确认正确 PDF 或 item-PDF 关联；不得用通用规则批量覆盖。
4. **P0-E PDF 文件版本漂移（97）**：核对原件与 facts 版本，确认后修正 `item.pdf_sha256/pdf_bytes` 或更换 PDF；不改变 facts 真值。
5. **P1-A1 板卡/模块映射组件 PDF（81）**：确认是否按 family_inherited/组件型号发布；属于业务口径，必须人工/业务签字。
6. **P1-I/J 电气结构（56）**：修解析规则或补源证据；重跑单件 + 受影响批次。
7. **回归范围**：规则修复 → 受影响批次；元数据修复 → 单件 + 该批次；不得用一次全量重跑掩盖问题。

> 本轮未发现 `F_DB SHA 元数据陈旧` 类（0 件）；不要预置“可以安全批量改库”的结论。

## 6. 产物

- `auto_qc_issue_matrix.csv`：逐 MPN 全量矩阵（含 PASS/WARN/FAIL）
- `auto_qc_issue_matrix.json`：同上 + 汇总/交叉/根因分组
- 本文件：人读结论与执行顺序
