# A18：表标题的型号归属 —— 不再从「同族另一颗料的表」取数

**一句话**：同一 PDF 里并列同构表（一颗料一张）时，旧实现按表顺序取第一张，
`74FCT162H245` 的 VOH 因此写成了另一颗料（`CY74FCT16245T`）的 `TYP 3.5`。
修法不用"猜型号"，只用两条可解释的判据；改完 12 件夹具写盘 **21 → 21**、
有写盘的 9 件 **44 → 41**（差量全部来自一处，原因见 §5）。

## 1. 事故：值是对的格式，错的是"哪张表"

`74FCT162H245CTPVCT__CY74FCT162_28H_29245T.pdf` 第 3 页并列三张**表头完全同构**的表：

| 表 | 标题 | VOH 行 |
|---|---|---|
| t0 | `Output Drive Characteristics for CY74FCT16245T` | `IOH=–15 mA → MIN 2.4 / TYP 3.5` |
| t2 | `Output Drive Characteristics for CY74FCT162245T, CY74FCT162H245T` | `IOH=–24 mA → MIN 2.4 / TYP 3.3` |

JSON 条目自己写的条件是 **`VCC=Min., IOH=–24 mA`** —— 模型没错。
是 `_decide_match` 的规则错了：**按表顺序取第一张有候选的表，不跨表比较**
（原 docstring 明写）。t0 先被问到，回答"我有 VOH"，就定了，t2 再没被看过。

**MIN 恰好都是 2.4**，所以 A12（干净单值）/ A16（值没跨出该列）/ A17（值在待写列里）
三道闸门全看不出异常 —— 它们校验「值有没有落到列里」，**不校验「这张表属不属于这颗料」**。
这是闸门的空白，不是闸门的失灵。

## 2. 判据：型号归属，不用猜

```python
claims_part(token, mpn)   # 这个标题 token 在说本品吗
_same_family(token, mpn)  # 同族但不是本品？
mark_foreign_tables(tables, mpn)   # 给「同族另一颗料的表」打 foreign_part
```

`claims_part` 的判据只有一条：去掉厂商前缀（`CY`/`SN`/`TI`，最多 3 个字母）后，
与料号有 **>= 6 字符公共前缀**，且**余量只允许为空或 1~2 个纯字母**。

| 标题 token | 料号 | 公共前缀 | 余量 | 结论 |
|---|---|---|---|---|
| `CY74FCT162H245T` | `74FCT162H245CTPVCT` | `74FCT162H245` (12) | `T` | **本品** |
| `CY74FCT162245T` | 同上 | `74FCT162` (8) | `245T`（含数字） | 另一个产品号 |
| `CY74FCT16245T` | 同上 | `74FCT162` (8) | `45T`（含数字） | 另一个产品号 |
| `ADS7945` | `ADS7945SRTER` | `ADS7945` (7) | 空 | **本品**（标题只写基础型号） |
| `ADS7946` | `ADS7945SRTER` | `ADS794` (6) | `6`（数字） | 另一个产品号 |
| `SBAS258A` | `ADS5203IPFBG4` | — | — | 文档号，不参与 |

「余量里出现数字 = 另一个产品号」是这条判据的核心：型号后缀是 `T`/`N`/`A` 这类
**纯字母**；一旦分叉处还剩数字（`45T`、`245T`、`6`），说明它区分的是产品本身。

`mark_foreign_tables` 只在**本 PDF 里确实存在声称本品的表**时才动手。
一张都没有（标题里没有型号信息，比如 `Absolute Maximum Ratings`）→ 一个都不标：
那时标记任何表都是猜。同族判定用公共前缀 >= 6 字符，所以文档号
（`SBAS258A – JUNE 2002`）不会被误当型号。

## 3. 决策：两轮，顺序即优先级

```
1. 先只在本品表里找 → matched / ambiguous_tie
2. 都没候选、但外族表有候选 → foreign_part（不写，报 table_foreign_part_unresolved）
3. 都没有 → unmatched
```

外族表**不是消失**，只是不能再单独决定写什么。这样两个方向都对：

- 本品表有同一行 → 取本品那张（顺手修掉「引用别颗料的表」的口径缺陷）
- 本品表没有这一行 → 宁可交人工，也不借别人的表

`audit_missing_rows` 也把外族表排除出候选：那条路径**绕过写盘闸门**直接塞新条目，
从别人的表里补行会整片进 facts 且没有任何 finding 指向它们
（基线 50 件 `row_missing` 合计为 0，所以本语料上这处过滤是空操作）。

## 4. 验证

| 语料 | 写盘 | change |
|---|---|---|
| 12 件夹具（`part_guard_12`） | 21 → **21** | 逐件 findings 数量相同，**零外族标记** |
| 有写盘的 9 件（`part_guard_writers`） | 44 → **41** | 差量全部来自 ADS7945SRTER，见 §5 |
| 全量 pytest | — | **1035 passed / 1 skipped / 0 failed** |
| `finding_kinds_audit --strict` | — | 通过（`TABLE_AUDIT_KINDS_MIN` 22 → 23） |

**74FCT162H245CTPVCT 的写盘变化（唯一一处值的更正）**

| | 旧 | 新 |
|---|---|---|
| VOH | `{MIN: 2.4, TYP: 3.5}`，source p3/**t0**/r2 | `{MIN: 2.4, TYP: 3.3}`，source p3/**t2**/r3 |
| IODL | `{MIN: 60, TYP: 115, MAX: 150}` p3/t2/r1 | 不变 |

**红先**：`tests/test_table_foreign_part.py::test_foreign_table_is_not_used_for_write`
修复前会写出 `{'MIN': 2.4, 'TYP': 3.5}`。新增 18 条用例。

## 5. 副作用：ADS7945SRTER 写盘 3 → 0（这是正确但昂贵的取舍）

这 3 条 `AVDD supply current` 的**数值是对的**，但它们的 `source.table_title` 是
`ELECTRICAL CHARACTERISTICS: ADS7946 (Single-Ended)` —— 另一颗料的表。
A18 之后它们变成 `table_foreign_part_unresolved`（29 条），`unresolved` 14 → 32。

**真因不是守卫太严，是 ADS7945 自己的表用不了**：

```
p3/p4  ELECTRICAL CHARACTERISTICS: ADS7945 (Differential)
       header 被读成 ['Typical specif', 'D = 5 V, DVDD ', 'de = VREF/2 ± ', '= 2 MSPS.']
p5/p6  ELECTRICAL CHARACTERISTICS: ADS7946 (Single-Ended)
       header = ['PARAMETER', '', 'TESTCONDITIONS', 'MIN TYP MAX', 'UNITS']   ← 可用（A13 再切）
```

差分表的表头行是多行合并格，`pick_header` 挑错了行，于是 `role_map` 拿不到
MIN/TYP/MAX，该表对匹配完全不可用。**那 3 条值一直是"借"来的**，只是恰好同值。

要把这 3 条召回拿回来，正路是修 p3/p4 的表头识别（合并单元格的多行表头），
不是放宽 A18。已记为下一步。

## 6. 一次作废的测量（记录在案）

`data/qc/part_guard_50/` 想跑 50 件全量，结果 15 件在 `os.replace` 上抛
`PermissionError: [WinError 5]` 崩掉 —— 因为同时还在跑 pytest，本机安全软件锁了
`.json.tmp`。崩溃件的 `write_cols` 字段直接缺失，用 `result.jsonl` 做 diff 会误读成
「写盘 44 → 31」。该目录已打 `STALE.md`，不作引用。

换成只跑有写盘的 9 件、`--workers 2`、不与 pytest 并发，才得到 §4 的干净数。

## 7. 未做 / 待查

1. **ADS7945 表头识别**（p3/p4 合并单元格多行表头）—— 拿回 3 条召回的唯一正路。
2. **`qualifier_loss` 21 → 19 的差未查清**：少的两条正是 VOH / IODL。
   但我直接调 `audit_electrical` 复跑时，新旧两态**都会**报这两条 `qualifier_loss`
   （唯一差别是 VOH 的 3.5 / 3.3），说明灰度里它们走了另一条分支（postprocess 后
   条目形态不同）。**没有逐行查清，不要在报告里说"诊断也一并修好了"**。
3. `±` 号在 `columns` 里的丢失（上轮遗留）未动：改它要动写盘格式。
4. 阈值 `_FAMILY_PREFIX = 6` 是经验值。它只决定"要不要把一张表降为兜底"，
   降级之后仍要本品的表没候选才 abstain，所以错判的代价是召回不是错值；
   但语料再大一些应该按实测校准。
