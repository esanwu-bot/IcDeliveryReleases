# 阶段三 探针报告（2026-10-30）

> 目标：验证「缺失件能否重解析回生产」。结论：**链路已打通，但有两个前置问题必须先解决**。
> 全程未改动 `data/parsed`（探针产物落 `data/parsed_probe/`）。

---

## 0. 一句话结论

重解析**能跑通**（已用真实模型跑出 1 件，conf 0.95）；但 63 件里只有 **8 件的料号能在现有 PDF 正文里找到**，
且产物与现有语料有 **schema 漂移**。真正批量前要补 PDF、并对齐模型与字段。

---

## 1. 三处认知勘误（实测）

| 原设想 | 实际 |
|---|---|
| `from agent_lab import tools` | **无此模块**。等价物是 `qc/agent_tools/`，12 个 adapter |
| `tools.run_regression(force_reparse=True, output_dir=...)` | `qc.run_regression` 是**只读审计**（`TA.audit_json`），无 `force_reparse` 参数，不产生产物 |
| `python -c "import qc.pandas_qc"` | **无此模块**（全项目零命中）。实际是 `qc.pandas_analyze` ← `app/services/qc_analyzer.py`，只读聚合 |
| `parse_datasheets.py --pdf X --output Y` | **无这两个参数**。实际是 `--dir` / `--only` / `--out-dir` |

### 12 个 adapter 的权限构成

| 权限 | 数量 | 说明 |
|---|---:|---|
| `readonly` | 9 | auto_qc / compare_fields / get_device_snapshot / get_evidence / get_findings / pandas_analyze / recheck_finding / run_regression / validate_patch |
| `candidate_write` | 1 | propose_patch（生成补丁，不覆盖原数据） |
| `restricted_write` | 1 | commit_patch（授权后应用） |
| `append_write` | 1 | audit_repair（记录调用与差异） |

**没有任何一个工具做「从 PDF 生成 JSON」。** Agent Lab 是质量审核层，不是生产层。
真正的生产入口只有 `parse_datasheets.py`。

---

## 2. 63 件缺失件的 PDF 体检

判据：候选 PDF 正文是否出现该 MPN（不是文件名匹配，是打开 PDF 抽文本查）。

| 结论 | 件数 | 含义 |
|---|---:|---|
| `STRONG` | **8** | 正文里**有**这个料号原文，可直接喂解析 |
| `WEAK` | 22 | 同族 PDF 存在，但正文没匹配到（可能只在订货表里，或格式差异） |
| `NONE` | 33 | ├ 家族内**没有任何候选 PDF**：17 件<br>└ 有候选 PDF 但正文未命中：16 件 |

按桶看：`D_ambiguous` 32 件有家族 PDF（其中 5 件 STRONG）、`E_absent` 仅 9 件有家族 PDF、`F_dup_target` 5 件全有。

### 8 件 STRONG（可直接进下一批）

| MPN | 可用 PDF |
|---|---|
| `ADS1254E` | `ADS1254EVM__ADS1254-Rev2006.pdf` |
| `ADS1271IPW` | `ADS1271IPWG4__ads1271.pdf` |
| `ADS1271IPWR` | `ADS1271IBPWR__ads1271.pdf` |
| `BQ2000SN-B5TR` | `BQ2000PWG4__bq2000.pdf` |
| `BQ2003S` | `BQ2003PNG4__bq2003.pdf` |
| `CC2530F32RHAR` | `CC2530DK__CC2530F32_2C64_2C128_2C256_Rev2011.pdf` |
| `D9LVRA2DEMR` | `D9LVRA2DEMRQ1__ds90lvra2-q1.pdf` |
| `DAC0800LCM` | `DAC0800LCMX_NOPB__snas538c.pdf` |

### 17 件连候选 PDF 都没有（重解析无解，除非新抓 PDF）

`2U3820-50QDBVRG4Q1`、`2U3823-25/30/50QDBVRG4Q1`、`2U3824-33QDBVRG4Q1`、`78SR110HC`、`78SR115HC`、
`78SR115SC`、`BQ26150DCKRG4`、`CC1000-RTB1`、`CC1000YZ`、`CC1010-RTY1`、`CC2560AYFVT`、
`CC3220S-LAUNCHXL`、`DDC114IRTCT`、`TMDXOSKL138BET`、`TMDXSK437X`

> `2U3820-*` 是 TI 内部订购码（对应 TPS382x），`5962-*` 是军标码 —— 这两类在 `data/pdfs` 里的
> 命名体系完全不同，靠料号前缀找不到。

---

## 3. 真实解析探针（已跑通）

### 3.1 绕开 DashScope 的通路

`parse_datasheets.py` 两个后端都是 OpenAI 兼容协议，且 `AGNES_API_BASE` 可被环境变量覆盖：

```bash
AGNES_API_BASE="https://generativelanguage.googleapis.com/v1beta/openai" \
AGNES_API_KEY="$GEMINI_API_KEY" AGNES_MODEL="gemini-2.5-flash" ICPDF_BACKEND=agnes \
python parse_datasheets.py --dir data/pdfs --only BQ2003PNG4 --backend agnes \
  --workers 1 --out-dir data/parsed_probe
```

连通性先行验证：`gemini-2.5-flash` 短请求返回 OK（5 tokens）。

### 3.2 探针结果

```
[OK] BQ2003PNG4  56.3s  conf=0.95  elec=25  pins=16  -> data/parsed_probe/BQ2003PNG4_54f3e246.json
success 1/1
```

| 项 | 值 |
|---|---|
| `confidence` | 0.95 |
| `specs.electrical` | 25 条 |
| `pin_configuration` | 16 个 |
| `features` | **7 条**（非空） |
| `applications` | **2 条**（非空） |
| `multi_language` | 无（翻译是独立环节，符合预期） |
| 生产目录影响 | **零**：8990 件、最新 mtime 均与快照一致 |

features 样例：`Fast charge and conditioning of nickel cadmium or nickel-metal hydride batteries`；
applications 样例：`Stand-alone battery chargers`。内容是真抽出来的，不是壳。

---

## 4. 批量前必须解决的两个问题

### 4.1 MPN 取自 PDF 文件名 —— 要救 X 必须先有 `X__slug.pdf`

`mpn_from_name(path.name)`（`parse_datasheets.py:838`），料号完全由文件名决定。
探针跑出来的是 `BQ2003PNG4`，**不是**缺失的 `BQ2003S`。

所以恢复配方是：

```
① 把同族 PDF 复制成 <缺失MPN>__<slug>.pdf
② parse --only <缺失MPN> --out-dir data/parsed_probe
③ 产物过 qc（auto_qc / 身份门禁）后再并入 data/parsed
```

⚠️ 直接复制改名有风险：若该 PDF 的订货表里**没有**这个订货号，
模型会把整份文档的内容安到这个料号名下 —— **造出一个真料号配假规格**。
所以第③步必须验「订货表里确有该 MPN」。

### 4.2 schema 漂移

| 维度 | 现有语料（8990 件） | 探针产物 |
|---|---|---|
| 顶层键 | 9 个（无 `pin_scope`） | **10 个（多 `pin_scope`）** |
| 含 `pin_scope` 的件数 | **0 / 8990** | 1 / 1 |
| `metadata.model_version` | `qwen-flash` 8469 / `agnes-3.0-flash` 522 | `gemini-2.5-flash` |
| `metadata.requested_mpn` | 有 | **缺** |

这两项会让回填来的产品与存量语料对不上：下游若按 9 键或按 `requested_mpn` 读，会踩空。
**建议用百炼 `qwen-flash` 跑正式批次**，保持模型与字段一致；Gemini 仅作无 key 时的备用通路。

---

## 5. 建议的下一步

| 优先级 | 动作 |
|---|---|
| P0 | 配 `DASHSCOPE_API_KEY`，用 `qwen-flash` 重跑 1 件对照，确认 `pin_scope` / `requested_mpn` 差异是否来自模型还是来自代码版本 |
| P1 | 8 件 STRONG 走「复制 PDF 改名 → 解析 → 订货表验证」流程，先打通 1 件闭环 |
| P2 | 22 件 WEAK 逐件核对 PDF 订货表是否含目标料号，含的升级为可救 |
| P3 | 17 件无 PDF：确认是否已下架，或去原厂补抓；短期从交付范围剔除并记录 |
| P4 | 244 条 ambiguous 研发任务（表类型过滤 + 条件字段化） |

---

## 6. 产物

| 文件 | 内容 |
|---|---|
| `data/qc/stage3_reparse_probe_20261030.csv` | 63 件逐件 PDF 可得性 + 判定 |
| `data/parsed_probe/BQ2003PNG4_54f3e246.json` | 探针产物（未并入生产） |
| `data/parsed_probe/_summary.csv` | 解析汇总 |
| `data/_probe_missing.py` | 体检脚本（可复跑） |

---

## 7. 百炼 qwen-flash 对照实验（2026-10-30 06:33 补）

`DASHSCOPE_API_KEY` 连通正常（短请求返回 OK）。用同一份 `BQ2003PNG4__bq2003.pdf` 重跑：

```
model=qwen-flash  [OK] BQ2003PNG4  40.1s  conf=0.95  elec=30  pins=16
```

### 7.1 三方对比

| 维度 | qwen-flash | gemini-2.5-flash | 交付包 BQ2003S |
|---|---|---|---|
| 顶层键 | 10 | 10 | 10（含 `multi_language`） |
| electrical | 30 | 25 | 8 |
| pins | 16 | 16 | 16 |
| features | 7 | 7 | 7 |
| applications | **4** | **2** | **4** |
| `pin_scope` | device | device | **无** |
| `metadata.requested_mpn` | **缺** | **缺** | BQ2003S |

**结论一：正式批次用 qwen-flash。** features/applications 与交付版完全一致（7/4），Gemini 的
applications 只有 2，口径偏离存量。

**结论二：`pin_scope` 是代码级、不是模型级。** qwen 同样有它，由
`parse_datasheets.py:918` 调 `qc.identity_scope` 写入；而存量 8990 件是 **0 件**有该键 ——
说明存量是老版本产物，代码已前进。

**结论三：`requested_mpn` 缺失是工具选择问题。** 该字段由 `app/services/pipeline.py:167`
与 `app/services/batch.py:255` 写入，`parse_datasheets.py` 不写。
**走 `parse_datasheets.py` 重解析会丢掉 `requested_mpn`**，而身份映射的 A 级判据正依赖它。

### 7.2 更严重的发现：`name` 口径变了

| | 老语料（8990 件抽样 60 件 / 2086 条） | 新探针产物（30 条） |
|---|---|---|
| `symbol` 字段 | **100% 为空** | 100% 为空 |
| `name` 形态 | **78% 以符号开头**（`VIH`、`VIL`、`VT+`） | 参数全名（`Supply Voltage`） |
| `condition` 填充率 | **83%**（1737/2086） | 100%（30/30） |

老产物把 PDF 符号列写进 `name`，新提示词（`parse_datasheets.py:265`）要求 `name`=参数名。
**若把新产物直接并入生产，`table_audit.locate_candidates` 会大面积失配** ——
因为它的打分是「符号命中 100 + 参数名前 12 位 80」，而老语料正是靠 `name` 的前 12 位
（就是符号本身）在命中。

### 7.3 244 条 ambiguous 的根因修正

之前判断「限定词在抽取阶段丢了」—— **实测不准确**。`condition` 其实有值（83%），
真正的问题是 **`locate_candidates` 的打分完全没使用 `condition`**：

```python
score = (100 if ns and ns in blob else 0) + (80 if npf and npf[:12] and npf[:12] in blob else 0) + 25 * ov
#        符号命中                             参数名前12位命中                              共同词
#        ↑ 没有 condition 参与
```

同名多值有两种成因，修法不同：

**A1 行拆分**（`74LVC1G132DCKTG4`，47 条电气里 `VT+` 占 10 条）

```
VT+ = 0.79 V   cond=VCC = 1.65V, -40°C to +85°C
VT+ = 1.16 V   cond=VCC = 1.65V, -40°C to +125°C
VT+ = 1.11 V   cond=VCC = 2.3V,  -40°C to +85°C
… 共 10 条，condition 各不相同，每条单值
```

**数据是对的**（PDF 确实按 VCC×温度分行），错在匹配时不看 condition → 10 条全撞一行。

**A2 列拆分**（`BQ2003PNG4` 探针产物）

```
Supply Voltage = 4.5 V   cond=TA = 0 to +70°C
Supply Voltage = 5.0 V   cond=TA = 0 to +70°C
Supply Voltage = 5.5 V   cond=TA = 0 to +70°C
```

同 condition 三值 = 一行的 MIN/TYP/MAX，被拆成 3 条。应合并为一条带 `columns`。

### 7.4 因此研发任务的优先级要改

| 原计划 | 修正后 |
|---|---|
| ① 写正则从参数名提取括号条件 | ✗ `condition` 已有值，不需要从名字里抠 |
| ② `_decide_match` 加表类型过滤 | ✓ 仍需要（吃掉匹配到绝对最大额定值表的 28 条） |
| **新增 ③ `locate_candidates` 打分纳入 `condition`** | ★ 最高杠杆，直接解 A1 类 |
| **新增 ④ 同 name 同 condition 多条先合并成 `columns`** | ★ 解 A2 类，纯后处理，不动 prompt |
| ⑤ 改抽取 Prompt 让 condition 独立成字段 | ✗ 已经是独立字段 |

### 7.5 批量重解析的前置条件（结论）

1. **先定 `name` 口径**：新产物的 `name` 要不要保留符号前缀？若不保留，须同步改
   `locate_candidates` 的匹配依据，否则并入后审计全乱。这是 P0。
2. **补 `requested_mpn`**：要么改用 `pipeline.py` 的编排路径，要么给
   `parse_datasheets.py` 补写该字段。
3. `pin_scope` 键：存量没有，新增有。下游若按固定 9 键读取需同步适配。
