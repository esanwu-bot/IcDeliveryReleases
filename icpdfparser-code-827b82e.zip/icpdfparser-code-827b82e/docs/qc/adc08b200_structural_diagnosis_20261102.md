# ADC08B200EB 结构性诊断（零 LLM 取证，2026-11-02）

## 一句话结论

**这张表有完整竖线，也不是合并单元格把列头搞乱。** 真正的原因是两处**表头识别**的结构性缺陷：

1. `header_roles()` 只认 `MIN / TYP / MAX` 字面 → TI 老式 `Limits (3)` 一列一个角色都数不到
   → 真表头只数到 1 个角色（`Typ(3)`）→ `pick_header` 的 `>= 2` 不成立 → **表头没认出来**。
2. `t.header.names` 是**表头上方那段脚注**，而 `choose_header` 在 `picked` 为空时维持
   "names 优先" → 脚注段落当了表头，真表头行留在数据里，**所有列下标错位**。

> 换模型不可能解决这个问题：plus 只是把值平铺出来（`role_coverage = 0/39`），
> 结构不由模型决定。

## 取证（`pymupdf` 默认 `find_tables()`，只读、零 LLM）

```
p8 t0 rows=32 cols=6
  names（PyMuPDF 认定的表头）= ['50% duty cycle, OEDGE/TEN = 1, Buf 25°C (1)(2)', '',
                                'ffer and PLL bypassed. Boldface limits apply for TJ = T',
                                'TMIN to TM', 'MAX: all oth', 'her limits TJ =']
  extract()[0]（真表头）      = ['Parameter', '', 'TestConditions', 'Typ(3)', 'Limits (3)', 'Units (Limits)']
  extract()[1]                = ['HD3', '3rdHarmonicDistortion', 'f IN = 10 MHz , V IN = FS −0 .25 dB', '−62', '', 'dBc']
```

p6 / p7 / p8 / p9 四张电气表的表头**都**是 `Parameter | TestConditions | Typ(3) | Limits (3) | Units (Limits)`，
其中 `Limits` 一列同时装 MIN 与 MAX，**侧别不写在列名上，写在 Units 格里**：

```
['INL', ..., '±0.55', '±1.3', 'LSB(max)']            → TYP=0.55, MAX=1.3
['FSE', ..., '−3.9', '−8.0 0', 'mV(min) mV(max)']    → MIN=−8.0, MAX=0
['tCL', ..., '', '1.7', 'ns(min)']                   → MIN=1.7
['I A', ..., '76.8', '88.3', 'mA(max)']              → TYP=76.8, MAX=88.3
```

p9 还多一层：`t.header.names` 同样是脚注，而窗口里第一行数据
`['f C1','MaximumInputClockRate','PLLDisabled','210','200','MHz(min)']`
因为 `maximum` 命中（旧正则没有词边界）+ `MHz(min)` 命中 MIN，被**升级成表头**，
真正的表头 row0 反而被当成数据丢弃。

## 已实现修复（`qc/table_audit.py`，ADAPT A20）

| # | 改动 | 落点 |
|---|------|------|
| 1 | 所有角色词加词边界：`\bmin\b\|\bminimum\b`、`\bmax\b\|\bmaximum\b` … | `ROLE_RES` |
| 2 | 新增伪角色 `LIMITS`，**整格锚定** `^\s*limit(s)?\s*(?:\([^)]*\))?\s*$`（`Units (Limits)` 和脚注里的 `limits` 都不命中） | `ROLE_RES` / `header_roles` |
| 3 | `header_roles` 识别范围扩到 `MIN/TYP/MAX/LIMITS` → 真表头 `Typ + Limits` 算 2 个角色 | `_HEADER_ROLES` / `pick_header` |
| 4 | `Limits` 合并列按 Units 格的 `(min)`/`(max)` **确定性拆分**；侧别不明 / 多值 / 公式格 → `unresolved` | `limits_column_split` |
| 5 | 判不出就整条不写，报 `cell_unparsable_unresolved (LIMITS_COLUMN)`（A12 纪律，绝不猜） | `audit_electrical` |
| 6 | 表头改由"被选中的那一行"提供 bbox，并把 `xr` 同步下移（旧实现会拿表头行去比数据行，A16 误判跨列） | `scan_tables` |

修复后同一份 PDF 的真实输出（零 LLM）：

```
AnalogSupplyCurrent (fIN=50MHz)         → columns {"TYP": 76.8, "MAX": 88.3}   (limits_column.split=side:max)
HighLevelOutputVoltage                  → columns {"MIN": 2.4, "TYP": 3.0}     (side:min)
MaximumInputClockRate (PLLDisabled)     → columns {"MIN": 200, "TYP": 210}     (side:min)
Integral Non-Linearity                  → columns {"TYP": 0.55, "MAX": 1.3}    (side:max)
3rdHarmonicDistortion (Limits 格为空)   → 只写 TYP / 不写 MIN-MAX（不造伪列）
```

## `limits_column_split` 四档判据表（入库）

| 档 | 触发条件（全部满足） | 写盘结果 | 标记 |
|---|---|---|---|
| `two_sided` | Limits 格**恰 2 个数** + Units 格同时含 `(min)` 与 `(max)` | MIN = 第 1 个，MAX = 第 2 个 | `two_sided` |
| `side:min` | Limits 格**恰 1 个数** + Units 格只有 `(min)` | MIN = 该数，MAX 不写 | `side:min` |
| `side:max` | Limits 格**恰 1 个数** + Units 格只有 `(max)` | MAX = 该数，MIN 不写 | `side:max` |
| **不可判** | 其余全部：非空格子 0 个数（`V RB` 公式）、>2 个数、单数但无侧别、双数缺一侧 | **整条不写**（A12） | `unresolved:*` → `cell_unparsable_unresolved (LIMITS_COLUMN)` |
| `blank` | 空格 / `-` / `—` / `N/A` | 不写 MIN/MAX，**不算脏**（行照常处理 TYP） | `blank` |

侧别来源优先级：**Units 格** 优先；Units 无标记时才看 Limits 格自身（`V (min)` 这种写法）。
正负号/`±`/脚注 `(3)` 不计入侧别与数值：`±` 只保留数值本体（如 `±1.3` + `(max)` → MAX=1.3）。

### 「不可判」覆盖率（这门闸的牙齿，必须单独统计）

`unresolved` 不写盘，所以它不会体现在 `columns` 覆盖里 —— 必须从 findings 里数，否则
"零误写"会被误读成"零缺陷"。每次审计后跑一次：

```bash
python qc/table_audit.py --report data/qc/audit_$(date +%Y%m%d).json <mpn...>
python - <<'PY'
import json, collections
d = json.load(open("data/qc/audit_00000000.json"))
f = d.get("findings") or d if isinstance(d, list) else d.get("findings", [])
lim = [x for x in f if x.get("kind") == "cell_unparsable_unresolved"
       and x.get("table") == "LIMITS_COLUMN"]
print("limits_unresolved =", len(lim))
PY
```

口径：`limits_unresolved_rate = LIMITS_COLUMN 条数 / 命中到含 LIMITS 列的行数`。
**不可判占比高不等于修复失败** —— 它说明 PDF 侧别证据缺失，写盘正确地拒了；
但该比例必须与 `columns` 写出率一起报，否则无法判断是"表结构特殊"还是"判据太窄"。

## LIMITS 是否泄漏进诊断口径（2026-11-02 第二轮确认：曾经泄漏，已修）

**确认结果：旧实现是"双口径"** —— split 只在写盘层（`audit_electrical` 的 `derived`）做，
诊断层没有：

| 诊断入口 | 旧行为 | 后果 |
|---|---|---|
| `_num_cells` | 只收 `MIN/TYP/MAX` 格，**排除 LIMITS** | `Typ + Limits` 表里 Limits 值完全不参与支撑判定 → `value_supported` 对 `88.3` 判 False（并列裁决/语义裁判会误选别行） |
| `value_supported`（数值分支） | 对整格 `to_num('−8.0 0')` → 取到 **8.0**（左半值、且丢极性） | 极性错 = 极值错；会让"这行支持这个值"判错 |
| `cvals`（写盘前） | 已走 `derived`（A20 首版修好） | 写盘正确、诊断不正确 → 两套口径 |

修复（同一提交内）：新增 `num_values(row, rm)`，`MIN/TYP/MAX` 走 `to_num`、
`LIMITS` 走 `limits_column_split` 拆出的 MIN/MAX；`_num_cells` 扩到
`_NUM_CELL_ROLES = MIN/TYP/MAX + LIMITS`（只扩**诊断取格**，不改写盘的角色语义）；
`value_supported` 的数值分支改用 `num_values`。表头无任何数值角色时仍退回整行（守旧行为）。
红先 4 例在 `tests/test_table_limits_column.py::TestLimitsInDiagnostics`
（`value_supported` 那例修复前实测 `False`）。

## 同批发现、尚未修的三个结构性 Bug（已留证，不在本次提交范围）

1. **引脚表抢走电气条目（P0）**：`AnalogSupplyCurrent` 在 p4 的 Pin Functions 表里命中
   `Positive analog supply pin`（`npf[:12]='analogsupply'` 子串命中，80 分），
   `_decide_match` 按表序取第一张 → 真正的 p8 电气行根本没被考虑，`columns` 为空。
   修法应走"优先数值角色表"而不是"表序"，但要单独做交叉表歧义裁决，需另立红先用例。
2. **PDF 文本层丢小数点（P2）**：p6 的 `−3.9` 抽出来是 `−39`、`5.5` 是 `55`、`7.0` 是 `70`
   （`rawdict` 里根本没有 `.` 字符）。不属于本次结构修复范围，记入已知边界：
   写盘侧仍由"模型 value 必须与本格数值相等"兜住，不会把 70 当成 7.0 写出去。
3. **`to_num` 对 U+2212 取号不对（P1，独立成项）**：`−3.9` 被读成 `+3.9`。
   这是**极性错误**，不是噪声：跨零比较（MIN/MAX 互换、D1d/D1g/value_supported）
   都会失判。修法应与 `cell_num` 同口径归一（`−`/`–` → `-` 后再取号），
   红先用例用跨零对（`−3.9 / 5.5`）。

## 同期处置

- plus 救回的 39 行：`role_coverage = 0/39`、有效 condition 23/39 →
  定级 **`unverified_pending_reaudit`**（未定性、待重审；旧理由码"模型幻觉"已撤回）。
  不进任何命中率/正确率分母，见 `docs/qc/fallback_quarantine_20261102.md`。
- 兜底开关：代码默认已改为 **关闭**（`5cc0d30`）；`deploy/.env` 无该键 → 生产不启用。

### 「R_effective = 7.69%」的分母定义（补写，防止裸百分比被二次推断）

| 符号 | 定义（实测口径） | 本轮值 |
|---|---|---|
| 样本 | `qc/step3_zero_cost_audit.py --gray-dirs /root/_gray100_run/parsed /root/_gray20_run/parsed`，按 `identity_scope` 判为 **CHIP** 的件 | **13 件**（BOARD 1 件已排除） |
| 分子 | CHIP 中「`specs.electrical` 为空 **且** 上下文里确有电气表证据（`context_has_elec_table`）」 | **1 件**（`ADC08B200EB`） |
| `chip_empty_rate` | 分子 / 样本 | **1/13 = 7.69%**（不是全库 empty 率） |
| `ctx_share` | 抽样件中「电气页确实被选进上下文」的比例 | **1/1 = 100%** |
| `R_effective` | `chip_empty_rate × ctx_share`（理论上"选页没丢、纯靠修复能救回"的比例） | **7.69%** |

三条必须一起读的限定：

1. **样本 13 件 → 只有 1 个分子**，粒度就是 7.69 个百分点，**不能外推成全库比例**，
   也不能当作置信区间的中点；
2. 该分子件（`ADC08B200EB`）的空表**已由 A20 修复**（同一份 PDF 零 LLM 已出 columns），
   所以 7.69% 是**修复前**的点估计，新基线必须重算（不能拿它预测未来）；
3. 「不为 7.69% 花 Token」的决策依据是**量级**（个位数百分比 × 极小样本），
   不是"精确比例" —— 换样本会变。
