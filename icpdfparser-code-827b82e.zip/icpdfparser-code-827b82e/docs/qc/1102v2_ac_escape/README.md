# 1102V2：AC 参数跨容器逃逸 —— 前后页面证据

**结论**：`ADS8568EVM-PDK` 页面上原本出现在
`On-board Device Electrical Specifications` 表里的 4 条 AC 数据
（SNR / THD / SFDR / Channel-to-Channel Isolation）在改后消失；
AC 段披露从「6 条已扣押」变为「10 条已扣押」，并补充了
「从其它容器复制、无独立坐标/行指纹」这一原因。机器可读状态为
`metadata.formal_container_integrity="pass"`、`metadata.ac_data_state="withheld"`。

## 对比口径

| 项 | 值 |
| --- | --- |
| 型号 | `ADS8568EVM-PDK` |
| 基线（before） | `1102-V11` 已交付页，commit `6661ff3`；实际文件 `delivery-20261102/part-0001-of-0001/ADS8568EVM-PDK/ADS8568EVM-PDK.html` |
| 改后（after） | 本分支修复后的 `json_to_txt.render(doc, "en")`；同一份 JSON，同一 `facts_verdicts` 侧车 |
| 语言 / 主题 / 视口 | `en` / 亮色 / 560×900 pt（同一渲染参数） |
| 数据差异 | 改后 `specs.onboard_device_specs.electrical` 24 → 20 行；`specs.unresolved_ac_rows` 6 → 10 行 |

## 实测截图

### 电气规格表（before）

![before electrical](before_electrical.png)

4 条 AC 行仍在 `On-board Device Electrical Specifications (ADS8568)` 表内：
`Signal-to-Noise Ratio (SNR) 91.5 dB`、`Total Harmonic Distortion (THD) -94 dB`、
`Spurious-Free Dynamic Range (SFDR) 92 dB †`、`Channel-to-Channel Isolation 120 dB †`。
表头披露为 “13 of 24 entries … unverified”。

### 电气规格表（after）

![after electrical](after_electrical.png)

同一张表不再包含这 4 行（20 行）；表头披露为 “11 of 20 entries … unverified”。
其余电气行（AVDD / DVDD / HVDD / HVSS / 功耗 / 转换时间等）原样保留。

### AC 段披露（before）

![before AC withheld](before_ac_withheld.png)

“6 AC rows were extracted … but are withheld from this page …”。

### AC 段披露（after）

![after AC withheld](after_ac_withheld.png)

“10 AC rows were extracted … but are withheld from this page: their MIN/TYP/MAX
column roles **or their provenance** could not be validated (… or the row was
copied from another container without its own bbox/row fingerprint) …”。

## 采集方式与限制

- 本机没有 headless 浏览器（Chromium / Firefox / Playwright 均不可用），
  因此截图不是浏览器像素级截图。
- 两张图都是把**应用实际生成的 HTML 片段**（before 取自已发布 V11 页面，
  after 取自定义函数 `json_to_txt.render`）经 PyMuPDF `Story` 渲染成 PDF 后
  栅格化；不是手绘 mockup，但版式只覆盖 HTML/CSS 的子集（表格边框等）。
- 对比关注**表格行内容与披露句**，不评价浏览器像素级版式；渲染参数
  （宽度、字号、语言、主题）两侧一致。

## 机器可读状态（改后 JSON，实测）

```json
{
  "metadata": {
    "formal_container_integrity": "pass",
    "ac_data_state": "withheld"
  }
}
```

```text
specs.onboard_device_specs.electrical : 24 -> 20
specs.unresolved_ac_rows             :  6 -> 10
隔离报告: 4 行，来源均为 onboard_device_specs.electrical
```

## 复现

以下命令在出包机的 `v11stage/` 目录（`delivery-20261102/` 与 `staging_20261102/`
同级）执行，只读使用已发布产物：

```bash
# 1) 只读复核：把 V11 交付 JSON 复制到临时目录后跑隔离（不碰已发布产物）
cp delivery-20261102/part-0001-of-0001/ADS8568EVM-PDK/ADS8568EVM-PDK.json /tmp/v12/ADS8568EVM-PDK.json
python qc/ac_quarantine.py /tmp/v12/ADS8568EVM-PDK.json

# 2) 渲染并比对（沿用 stage_release 的 facts_verdicts 侧车，保证与已发布页同口径）
python - <<'PY'
import json, sys; sys.path.insert(0, ".")
import json_to_txt as J
doc = json.load(open("/tmp/v12/ADS8568EVM-PDK.json"))
fv = json.load(open("staging_20261102/facts_verdicts.json"))
doc["metadata"]["facts_verdicts"] = (fv["mpns"] or {})["ADS8568EVM-PDK"]
open("/tmp/v12/after.html", "w", encoding="utf-8").write(J.render(doc, "en"))
PY
```
