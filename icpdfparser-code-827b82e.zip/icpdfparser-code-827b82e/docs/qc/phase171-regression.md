# Phase 1.7.1 · D1/D2/D3 修复与冻结样本回归

**日期**：2026-11-03 · **基线**：Phase 1.7 外审裁决（三件灰度通过、V2 不提升）
**代码**：`origin/main@88d023e` · **镜像**：`icpdf/app:latest`
**回归样本**：Phase 1.7 的三件**冻结样本**（URL/SHA 未变）

## 0. 结论

| 缺陷 | 级别 | 结论 | 关键证据 |
|---|---|---|---|
| D1 确定性后处理缺失 | P0 | **PASS** | LM317 thermal **36 → 34**、`NA`/`—` 不落行；`metadata.deterministic_extract` 可审计；Legacy/V2 同输入逐条一致 |
| D2 `llm_usage` 空账 | P1 | **PASS** | 真实灰度 1 次调用 → 1 条记录（17,632 / 27,131 tokens）；缓存命中 0 条假记录；失败/重试按 attempt 保留 |
| D3 板卡 thermal/esd 无字段级归属 | P1 | **PASS** | 样本 2：thermal 11 + esd 2 **全部** `subject=onboard_device`、`subject_source=onboard_device_datasheet`，`unlabeled=0`；容器未搬 |

三项都通过之前不进入下一批灰度 —— 本轮不提升 V2、不扩容、不改模型/Prompt/Audit 算法。

## 1. 提交

| 提交 | 内容 |
|---|---|
| `27bdd02` | D1：`parse_pdf` 接入 `apply_deterministic`（复用 legacy 同一份函数）+ 5 条红先测试 |
| `4951c4b` | D2：`stage_llm` 复用 `_log_calls` 落账 + 3 条红先测试 |
| `35d4e62` | D3：板卡 `thermal`/`esd` 字段级 `subject` + 5 条红先测试 |
| `88d023e` | D1 复核修正：早落 `datasheet_url`、重试后重取 metadata（见 §2.3） |

## 2. D1 · 确定性处理对齐

### 2.1 改了什么

`app/services/pipeline.py::parse_pdf` 在「模型输出通过 `validate`」之后，按 Legacy
`parse_datasheets.parse_one` 的**同一时机**执行：

1. 打开同一份 PDF → `DE.apply_deterministic(doc, fd)`（**同一份函数**，不复制判据）；
2. `DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)`；
3. 核心字段不达标 → 一次修复重试 → **再覆盖一次**确定性结果 → 再校验；
4. `metadata.deterministic_extract` / `metadata.core_validation` 落盘（与 Legacy 同名字段）。

### 2.2 验收（裁决五条）

| 要求 | 证据 |
|---|---|
| 调用时机与 Legacy 一致 | 均在 `validate` 之后、`identity_scope` 之前；重试后再次覆盖（`tests/test_phase171_d1_deterministic.py`）|
| 输入对象/字段/配置一致 | 同一 `doc` 对象、同一 PDF、`apply_deterministic` 默认参数；无自定义开关 |
| 重复调用不二次清洗 | `test_apply_deterministic_is_idempotent`：连续两次结果逐字节相同（34 行不变）|
| 同冻结 PDF 比较 Legacy/V2 | `test_v2_and_legacy_deterministic_agree`：同一份模型输出，thermal/引脚逐条一致 |
| NA/—/重复引脚边界一致 | 占位符不落行、KCS 的 0.1 不冒充 DCY（`test_placeholder_edges_are_consistent`）|

### 2.3 复核中修掉的两个坑（`88d023e`）

- **URL 早落**：`check_core` 第一条就要求 `basic_info.datasheet_url`，而 V2 原来在
  校验之后才 setdefault → 每次都白触发一次修复重试。灰度实测多烧 23,278 tokens。
  现在在确定性/核心校验之前写入调用方给的 URL。
- **重试后重取 `meta`**：修复重试会把 `doc` 换成新对象，原 `meta` 变量指向孤儿
  metadata，导致 `deterministic_extract` / `core_validation` 丢字段（灰度实测为 null）。
  现在重试后 `meta = doc.setdefault("metadata", {})`，写盘前再按 `IS.apply` 之后的
  新 metadata 重取一次。

### 2.4 事实更正：LM317 的「3 vs 4 引脚」不是确定性差异

`extract_pins` 只认 `NAME | NO.` 布局；LM317 的引脚表是 `PIN | FUNCTION` 两列，
实测 `extract_pins=0`。所以 Phase 1.7 里 Legacy 3 条 / V2 4 条是**模型方差**，
不是「确定性没跑」。本轮冻结样本重跑 V2 得到 3 条（模型这次给了 3 条），
`deterministic_extract` 中也没有 `pins` 改写记录 —— 与 Legacy 行为一致。
**重复 OUTPUT 若要被代码消除，需要扩展 `extract_pins` 覆盖 `PIN | FUNCTION`，
属新缺陷（建议编号 D4），不在 D1 范围。**

## 3. D2 · LLM Usage 记账

- `app/pipeline/stages.py::stage_llm` 在真实调用返回后复用
  `app.services.pipeline._log_calls`，一次真实调用写一条 `llm_usage`。
- 缓存命中走 `stage_llm` 的早返回，不进 `_run` → **不产生假记录**。
- 重试/多次调用按 `attempt` 逐条保留；失败调用带 `ok=False` + `error`。
- 本地用例：`tests/test_phase171_d2_usage.py`（逐次、缓存、空调用三条）。
- 灰度实测（本轮）：

| 样本 | `llm_calls` | `llm_usage` 行数 | prompt / completion / total |
|---|---|---|---|
| LM317 | 1 | 1 | 11,644 / 5,988 / **17,632** |
| ADS8568EVM-PDK | 1 | 1 | 17,418 / 9,713 / **27,131** |
| DAC8568EVM | 0 | 0 | —（preprocess 短路，未调模型）|

> `llm_usage` 是内部可观测性账本；Token 成本的最终核对仍以网关账单为准。

## 4. D3 · 板卡字段级主体归属

### 4.1 做法（不搬容器）

`qc/identity_scope.py::_stamp_row_subjects` 在板卡归一流程里，给
`specs.thermal` / `specs.esd` **每一行**补：

```json
{"subject": "onboard_device" | "board" | "ambiguous",
 "subject_source": "onboard_device_datasheet" | "board_user_guide" | "unresolved",
 "subject_review": "needs_human"          // 仅 ambiguous
}
```

外加容器级汇总 `specs.subject_summary`。证据口径只认「这份 PDF 是什么」：

| 来源证据 | 主体 |
|---|---|
| `onboard_device_datasheet` | `onboard_device` |
| `board_user_guide` | `board` |
| 无法确认 | `ambiguous`（保留行、标人工，不猜） |

**不按参数名猜**：`RθJA` 在板卡 UG 里也可能引用器件值、`HBM` 也可能指整板接口保护。
一个 item 只有一份 PDF，`document_scope` 是可复算的行来源证据。

### 4.2 样本 2 实测

```
identity=evaluation_board  document_scope=onboard_device_datasheet
specs.scope=onboard_device  pin_scope=board
主容器 thermal=11  esd=2（未搬走）
subject_summary = {"thermal": {"onboard_device": 11}, "esd": {"onboard_device": 2}}
unlabeled_thermal=0  unlabeled_esd=0
```

电气/绝对最大值仍按既有逻辑搬进 `onboard_device_specs`（D3 不改这部分）。

## 5. 冻结样本回归矩阵（代码 `88d023e`）

| 项 | LM317（芯片） | ADS8568EVM-PDK（板卡） | DAC8568EVM（异常件） |
|---|---|---|---|
| 终态 | `done` / 100 | `done` / 100 | **`skipped`** / 100 |
| 五段阶段 | 全部 ok（attempts=1） | 全部 ok（attempts=1） | 仅 preprocess skipped |
| PDF SHA 实收 | `1646fb2e…` ✅ | `79c02991…` ✅ | `a7e7253d…` ✅ |
| `parse_count` | 1 | 1 | **0** |
| `start/download` | 1 / 1 | 1 / 1 | 1 / 1 |
| `dedup` / `already_running` | 0 / 0 | 0 / 0 | 0 / 0 |
| D1：thermal | **34**（36→34） | 11（11→11） | 不适用 |
| D1：占位符/重试 | `NA`/`—` 不落行；llm_calls=1（无白烧） | 无占位符；llm_calls=1 | — |
| D2：usage | 1 行 / 17,632 tokens | 1 行 / 27,131 tokens | **0 行** |
| D3：subject | 不适用（chip，不加字段） | **11+2 行全部标注** | 不适用 |
| 身份 | chip / device | evaluation_board / onboard_device | — |
| 产物 | JSON/TXT/symbol 齐全，render errors=0 | 同 | 仅 PDF，无 JSON |

三件仍然使用**同一冻结样本**（URL 与 SHA 复核一致），未换更容易通过的样本。

## 6. 测试

- 新增 `tests/test_phase171_d1_deterministic.py`（5）、`test_phase171_d2_usage.py`（3）、
  `test_phase171_d3_subject.py`（5），全部红先：实现前 V2 thermal=7/36 原样、usage=0 行、
  无 subject 字段。
- 关联回归（pipeline stages/wiring、identity/board/scope、deterministic）：
  **262 passed**（107.59s）。

## 7. 生产隔离复核

```
parsed files=13539  bytes=281419444  digest=acf8d167bb360afc933f0468840c08af2ec4fe410a93069c89deb808c9a1a6c4
db sha256=d93d65851f773169cace5754defdb326af616500d69cbda430adfb8c2bfa074c size=95834112
五个生产容器 RestartCount=0（StartedAt 未变）
```

灰度写入只在 `/tmp/p17/data_r{1,2,3}` 与 Redis DB8（5 个键保留待查）；`p17-*` 容器已全部清除。

## 8. 残留（不在 D1/D2/D3 范围，不得混入「已通过」）

1. **LM317 电气行数与 audit findings 的模型方差**：本轮模型给出 33 条电气、
   audit 32 findings（`row_ambiguous_unresolved` 28）；Legacy 同 PDF 也有同类方差
   （上轮 17 条 / 14 findings）。确定性层不覆盖电气行，属 Phase 1.8（双 Qwen 事实级复核）
   与 `AC`／`electrical` 列角色治理，不能拿本轮回归当内容批准。
2. **LM317 引脚表布局未覆盖**：`PIN | FUNCTION` 不在 `extract_pins` 的识别范围，
   重复/多余的引脚仍按模型输出保留（建议 D4）。
3. 三件 `PIPELINE_PASS` 仍不等于 `CONTENT_APPROVED` / `RELEASE_APPROVED`。

## 9. 建议的下一步

1. 给 D4（`PIN | FUNCTION` 引脚表）立项并补红先测试；它与 D1 同属「确定性覆盖缺口」，
   但会改抽取器判据，须单独授权。
2. Phase 1.8 再接双 Qwen 事实级复核（当前 audit 只取证、`write=false`）。
3. V2 保持 `ICPDF_PIPELINE_V2=0`，直到 D4 与内容治理有结论再谈下一批灰度。
