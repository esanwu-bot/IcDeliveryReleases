# D3-UG · 真实 ADS8568EVM-PDK User Guide 分支验证

**PDF**：`SBAU193E`《ADS8568EVM-PDK Evaluation Module》，本地下载自
`https://www.ti.com/lit/ug/sbau193e/sbau193e.pdf`
**SHA-256**：`4a35747ce9b9dd8369dd030815df9082949128531ff9187cb42bb7a7780da21a`（与 `docs/qc/ads8568_board_ug_20261102/README.md` 冻结值一致）
**代码**：HEAD `e23751b` 的 `qc.identity_scope.apply` + `qc.scope_contract.canonical_view`

## 1. 身份与文档 scope

| 项 | 结果 |
|---|---|
| identity | `evaluation_board` |
| identity_state | `BOARD_CONFIRMED` |
| document_scope | **`board_user_guide`** |
| specs.scope | `board` |
| pin_scope | `board` |

`document_evidence` 命中首页 `User's Guide` + `ADS8568EVM-PDK Evaluation Module`，
不是按文件名猜的：

```json
[
  {
    "kind": "board_guide_title",
    "requested_mpn": "ADS8568EVM-PDK",
    "title": "User’s Guide",
    "excerpt": "User’s Guide\nADS8568EVM-PDK Evaluation Module\nABSTRACT\nThis user's guide describes the operation and use of the ADS8568 evaluation module (EVM). The ADS8568 is\nan 8-channel, simultaneous sampling, 16-bit successive approximation (SAR) analog-to-digital converter (ADC).\nEach input channel on the device can support true bipolar input ranges up to ±12 V. The devi",
    "start": 0,
    "end": 362
  }
]
```

## 2. 行数统计（真实 UG）

| 容器 | 原始行数 | board | onboard_device | ambiguous |
|---|---:|---:|---:|---:|
| thermal | 2 | 2 | 0 | 0 |
| esd | 2 | 2 | 0 | 0 |

`subject_summary`：

```json
{
  "thermal": {
    "board": 2
  },
  "esd": {
    "board": 2
  }
}
```

## 3. 发布视图（canonical_view）

| 容器 | 主容器 | onboard 桶 | unresolved |
|---|---:|---:|---:|
| thermal | 2 | 0 | 0 |
| esd | 2 | 0 | 0 |

整板参数（board）保留主容器，没有把 UG 里的行误搬进 `onboard_device_specs`。

## 4. 本次能关闭与不能关闭的部分

- **可以关闭**：真实 `board_user_guide` 的 `document_scope` 识别，以及该 UG 中
  thermal 2 / esd 2 的 `subject=board` 归属与发布视图保留。
- **不能关闭**：该 UG 本身没有 `onboard_device` 或 `ambiguous` 的 thermal/esd 样本行，
  因此这两类在**真实 UG**上的行为仍只有单元测试覆盖（四分支用例）；不能外推为
  所有板卡文档已验证。
- 电气/绝对最大值行的 `attribution` 仍是 `unresolved`（见原始 JSON），未冒充整板参数。

## 5. 用例

```text
python -m pytest tests/test_phase171_d3_subject.py tests/test_scope_contract.py -q
..............................................                           [100%]
46 passed in 0.65s
```

## 6. 原始证据

```json
{
  "probe": "real SBAU193E UG + current identity_scope (HEAD e23751b)",
  "pdf": "sbau193e.pdf",
  "pdf_sha256": "4a35747ce9b9dd8369dd030815df9082949128531ff9187cb42bb7a7780da21a",
  "identity": "evaluation_board",
  "document_scope": "board_user_guide",
  "document_evidence": [
    {
      "kind": "board_guide_title",
      "requested_mpn": "ADS8568EVM-PDK",
      "title": "User’s Guide",
      "excerpt": "User’s Guide\nADS8568EVM-PDK Evaluation Module\nABSTRACT\nThis user's guide describes the operation and use of the ADS8568 evaluation module (EVM). The ADS8568 is\nan 8-channel, simultaneous sampling, 16-bit successive approximation (SAR) analog-to-digital converter (ADC).\nEach input channel on the device can support true bipolar input ranges up to ±12 V. The devi",
      "start": 0,
      "end": 362
    }
  ],
  "specs_scope": "board",
  "pin_scope": "board",
  "identity_state": "BOARD_CONFIRMED",
  "rows": {
    "thermal": 2,
    "esd": 2,
    "electrical": 9,
    "absolute_max": 6
  },
  "subjects": {
    "thermal": {
      "board": 2
    },
    "esd": {
      "board": 2
    }
  },
  "subject_summary": {
    "thermal": {
      "board": 2
    },
    "esd": {
      "board": 2
    }
  },
  "thermal": [
    {
      "name": "RθJA",
      "value": "75 °C/W",
      "unit": "°C/W",
      "attribution": "unresolved",
      "subject": "board",
      "subject_source": "board_user_guide"
    },
    {
      "name": "RθJC(top)",
      "value": "35 °C/W",
      "unit": "°C/W",
      "attribution": "unresolved",
      "subject": "board",
      "subject_source": "board_user_guide"
    }
  ],
  "esd": [
    {
      "name": "HBM",
      "value": "±2000",
      "unit": "V",
      "attribution": "unresolved",
      "subject": "board",
      "subject_source": "board_user_guide"
    },
    {
      "name": "CDM",
      "value": "±1000",
      "unit": "V",
      "attribution": "unresolved",
      "subject": "board",
      "subject_source": "board_user_guide"
    }
  ],
  "electrical_sample": [
    {
      "name": "Supply Voltage (AVDD)",
      "value": "5 V",
      "unit": "V",
      "condition": "",
      "source": {
        "page": 7,
        "bbox": [
          56.7,
          304.9,
          539.3,
          316.1
        ],
        "paragraph_sha256": "7c4dd241f95a1100046005cf2c944e1bbac1f86350f832fa1a9d3c279256cf70"
      },
      "verification": {
        "status": "audited_paragraph",
        "method": "facts_replay",
        "page": 7,
        "bbox": [
          56.7,
          304.9,
          539.3,
          316.1
        ]
      },
      "attribution": "unresolved"
    },
    {
      "name": "Supply Voltage (DVDD)",
      "value": "3.3 V",
      "unit": "V",
      "condition": "",
      "source": {
        "page": 2,
        "quote": ".............................................5 2.1 ADC Supply, Input, Voltage Reference, and Digital Connections...........................................................................",
        "method": "label_value_colocation"
      },
      "verification": {
        "page": 2,
        "status": "label_value_same_page",
        "reason": "same_page_only"
      },
      "attribution": "unresolved"
    },
    {
      "name": "High Voltage Supply (HVDD)",
      "value": "±15 V",
      "unit": "V",
      "condition": "",
      "source": {
        "page": 2,
        "quote": ".............................................5 2.1 ADC Supply, Input, Voltage Reference, and Digital Connections...........................................................................",
        "method": "label_value_colocation"
      },
      "verification": {
        "page": 2,
        "status": "label_value_same_page",
        "reason": "same_page_only"
      },
      "attribution": "unresolved"
    }
  ],
  "metadata_attribution": {
    "identity": "evaluation_board",
    "source_doc_type": "user_guide",
    "rule": "board_interface_vocabulary",
    "note": "attribution=unresolved 表示「整板还是板载器件」未能从源文档判定，不是数值有问题；与 verification.status=unresolved（列角色未核）是两件事。",
    "board_level": [
      "electrical:Input Voltage Range",
      "absolute_max:Input Voltage Range"
    ],
    "onboard_device": [],
    "unresolved": [
      "electrical:Supply Voltage (AVDD)",
      "electrical:Supply Voltage (DVDD)",
      "electrical:High Voltage Supply (HVDD)",
      "electrical:Resolution",
      "electrical:Sampling Rate",
      "electrical:Interface Type",
      "electrical:SPI Clock Frequency",
      "electrical:Operating Temperature Range",
      "absolute_max:Supply Voltage (AVDD)",
      "absolute_max:Supply Voltage (DVDD)",
      "absolute_max:High Voltage Supply (HVDD)",
      "absolute_max:Operating Temperature Range",
      "absolute_max:Storage Temperature Range",
      "thermal:RθJA",
      "thermal:RθJC(top)",
      "esd:HBM",
      "esd:CDM"
    ]
  },
  "publication_view": {
    "main_thermal": 2,
    "main_esd": 2,
    "onboard_thermal": 0,
    "onboard_esd": 0,
    "unresolved_thermal": 0,
    "unresolved_esd": 0
  }
}
```
