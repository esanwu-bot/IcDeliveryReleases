# Phase 1.7.1 · Reviewer 裁决后的执行状态（2026-11-03）

## 0. 裁决映射

| 项 | Reviewer 裁决 | 本机动作 |
|---|---|---|
| D1 | 有条件通过 | 不重复改代码；D2 实跑再次记录 36→34（真实 PDF）与 7→34（夹具）两种口径 |
| D2 | 证据不足 | **已补**：`D2_AUDIT.json` / `D2_AUDIT.md`，原始 `llm_usage` 行 + 调用/记录对照 + 缓存 0 新增 + repair 计数 |
| D3 datasheet | 样本级通过 | 保持 |
| D3 UG | PENDING | **已补真实 UG**：SBAU193E（SHA `4a35747c…`）board 分支实跑；见 `D3_UG_AUDIT.md` |
| D4 | 样本级通过 | 保持；未外推为通用引脚规则 |
| V2 灰度解除 | 不批准 | 未解除，未扩大流量 |
| DEPLOY-P171 | 阻断 | 本机无 Docker/Redis/服务器凭据；已出 `DEPLOY_P171_RUNBOOK.md`，状态 PENDING |
| V3 候选重建 | 允许启动 | 已按 `e23751b` 建冻结快照并启动重新解析；不产出最终包，不标 APPROVED |

## 1. D2 原始证据（已补）

文件：

- `docs/qc/phase171/D2_AUDIT.json`（原始行级记录）
- `docs/qc/phase171/D2_AUDIT.md`（人读报告）

| 场景 | 真实调用数 | `llm_usage` 行数 | 缓存新增 | 最终 JSON |
|---|---:|---:|---:|---|
| 正常任务（item 901） | 1 | **1** | 0 | thermal 34 / pins 3 / elec 22 / core pass |
| 二次调用同一任务 | 0 | 0 | **0** | 命中 `cached`，不写假账 |
| 强制 repair（item 900，故意空 URL） | 2 | **2** | — | `parse` attempt=1（17,063 tokens）+ `repair` attempt=3（15,768 tokens）；core 失败，行落 `unresolved_specs` |

- D2 用例：`python -m pytest tests/test_phase171_d2_usage.py -q` → **3 passed**。
- 正常任务 JSON 内容指纹、`idem_key`、阶段账、usage 行全部在 JSON 证据中。
- **边界**：这是本机 `preprocess + llm` 任务；服务器同构五阶段仍属 `DEPLOY-P171`，不冒充。

## 2. D3-UG 真实 UG 证据（已补）

文件：`docs/qc/phase171/D3_UG_AUDIT.md`、`docs/qc/phase171/evidence/s2b-ug-sbau193e.json`

| 项 | 结果 |
|---|---|
| PDF | SBAU193E《ADS8568EVM-PDK Evaluation Module》 |
| SHA-256 | `4a35747ce9b9dd8369dd030815df9082949128531ff9187cb42bb7a7780da21a`（与冻结值一致） |
| `document_scope` | **`board_user_guide`** |
| `specs.scope` / `pin_scope` | `board` / `board` |
| thermal | 2 行，全部 `subject=board` |
| esd | 2 行，全部 `subject=board` |
| onboard_device / ambiguous | 0 / 0（该 UG 没有这两类热阻/ESD 行） |
| 发布视图 | 主容器 thermal 2 / esd 2；onboard 桶 0 / 0 |
| 用例 | `test_phase171_d3_subject.py + test_scope_contract.py` → **46 passed** |

**边界**：真实 UG 只覆盖了 `board` 分支；`onboard_device` / `ambiguous` 仍只有单元测试覆盖，
不能外推为「所有板卡文档已验收」。

## 3. DEPLOY-P171

`docs/qc/phase171/DEPLOY_P171_RUNBOOK.md` 已写好，包含：

- 固定 `e23751b` 的只读归档；
- 镜像 ID、Redis DB8、五个 worker role、数据根；
- 五阶段状态/attempts/耗时、`parse_count`、下载/dedup、PDF SHA；
- `llm_usage` 与最终 JSON 关联；
- 生产目录与生产库的**内容 SHA256**前后对照（不是只比文件数/mtime）；
- 停止线与现场保留。

**当前状态：PENDING**。本机没有 Docker、Redis、Celery worker，也没有目标服务器凭据；
不把本机隔离运行写成服务器同构验证。

## 4. V3 候选重建

- 冻结快照：`e23751b`（含 D1–D4；D4=`19ef765`）+ 闸门文件 `pipeline_stamp` / `fact_status_sync` /
  `bundle_selfcheck` / `coverage_gate`（按 SHA256 冻结）。
- 已启动 8 件重新解析（V2 `preprocess + llm`，真实模型，隔离 sqlite 记录 usage），
  质量闸要求 `electrical>0`、`pins>0`、`core_validation ∈ {pass, not_applicable}`；
  不满足则重试，最多 6 次，**不会用空 JSON 冒充通过**。
- 上一轮 `9beeb7d` 的 7/8 结果不作为 V3 最终物料（Reviewer 明确要求 `e23751b`）。
- 在 `DEPLOY-P171`、`D2-AUDIT` 复核、`D3-UG` 复核完成前，候选包只能标记
  **`V3-CANDIDATE / NOT-APPROVED`**；不执行 `CONTENT_APPROVED` / `RELEASE_APPROVED`。
- 未覆盖/未执行：`D4-REGRESSION`（跨布局去重）、真实服务器五阶段、V3 正式发布。

## 5. 待办

| Issue | 状态 |
|---|---|
| D2-AUDIT | 原始证据已补，等 Reviewer 复核 |
| D3-UG | 真实 UG board 分支已补；onboard/ambiguous 真实样本仍缺 |
| DEPLOY-P171 | PENDING（需服务器执行） |
| D4-REGRESSION | 部分完成（LM317 样本 + 单测；跨布局去重未验） |
| V3 candidate | 解析进行中；最终包等待上述阻断项 |
