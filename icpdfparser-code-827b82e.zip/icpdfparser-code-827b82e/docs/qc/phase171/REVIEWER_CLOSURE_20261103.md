# Phase 1.7.1 · 收网报告（2026-11-03，Trae 下线后由 WB 接手）

> 状态一句话：**V3-CANDIDATE 已隔离构建并推送；G1 服务器同构复跑已完成且生产零污染；
> 三个 PENDING 里，服务器复跑已关闭，D3-UG 与 D4 经独立验收后仍维持 PENDING。**
> 未设 `CONTENT_APPROVED` / `RELEASE_APPROVED`，未改 `release_status`，未覆盖 V2，未写生产目录。

## 1. V3-CANDIDATE 包

| 项 | 值 |
|---|---|
| 包名 | **`delivery-batch20-eval-V3-CANDIDATE`** |
| ZIP | `part-0001-of-0001.zip` · 21,918,020 B |
| **SHA-256** | **`a3752d1fff933fdf2c22849fdeed8671ec3a590d3f62253cd58ef0d72804c6bf`** |
| 提交 | `3cdf5d6` · https://github.com/esanwu-bot/IcDeliveryReleases/tree/main/delivery-batch20-eval-V3-CANDIDATE |
| 质审单 | **[CMD] #24** · https://github.com/esanwu-bot/IcDeliveryReleases/issues/24 |
| 自检 | **56 项 / 0 失败**（`qc/bundle_selfcheck.py` 从包内文件独立重算） |
| 型号 | **7 件**，全部 `release_status=not_approved`、`release_state=PACKAGING_PASSED` |

自检项数比 V2 的 63 少 7，原因可核对：少的正好是 `record[CDC6CE025000ADLYR].*`
那 7 个逐型号项 —— 该件本轮未产出（见第 5 节），不在包内。
README / 交付说明 / manifest 三处均写明 **V3-CANDIDATE / NOT-APPROVED** 并列出未完成项。

代码基线：物料解析取自 2026-11-03 20:06–21:28 那一轮（冻结快照 `e23751b` 的解析输出），
**装配、确定性复核、事实验收走当前 HEAD `948c2c2`**（含 G2 引脚修复），未跨轮拼接。

## 2. G1 · 服务器五阶段同构复跑（已完成）

- 服务器 `159.89.190.225`；`git fetch origin main` → **`948c2c2`**（与本地同源），
  `git archive` 落到 `/tmp/p171/code`，挂载覆盖 `/app`（镜像只供依赖，`icpdf/app:latest` = `b85eff869971`）。
- 隔离：Redis **DB8** + `/tmp/p171/data_s{1,2,3}` + `p17-s{1,2,3}-{fetch,preprocess,llm,audit,render}`。

| 样本 | 终态 | parse_count | 各段（attempts 全 1） | 关键点 |
|---|---|---:|---|---|
| s1 LM317 | done 100% | 1 | preprocess 1651ms / llm 55490ms / audit 43393ms / render 265ms | thermal **34**（36→34 确定性复核） |
| s2 ADS8568EVM-PDK | done 100% | 1 | preprocess 2169ms / llm 132269ms / audit 36057ms / render 77ms | 主容器 thermal **0**、`onboard_device_specs` 13 → D3 datasheet 分支在服务器侧成立 |
| s3 DAC8568EVM | skipped | 0 | preprocess skipped | `NOT_A_DATASHEET`，**0 次模型调用**（UG 跳过路径如预期） |

**零污染**（同一命令跑前跑后各一次，`diff` 无差异）：

```text
data/parsed        13539 files / 281,419,444 B / digest acf8d167…   前后一致
workbench.sqlite3  sha256 d93d6585… / 95,834,112 B                  前后一致
icpdf-server/render/llm/fetch/redis  RestartCount=0，StartedAt 未变
```

隔离容器已清理，DB8 只留 5 个 kombu 绑定键。日志原件：`docs/qc/phase171/g1_server/`。

两处如实说明：① 三件都是 URL 直供下载（`provider=manual`），严格讲是「采集 + 四段」，
阶段表里没有独立的网络抓取行；② 生产 Redis DB0 键数**没取跑前基线**（只记了跑后 2581），
零污染结论以目录内容 SHA、sqlite 全文件 SHA、容器 StartedAt 三项为准。

## 3. G2 引脚修复：已生效（但见第 4 节）

包内物料（装配段 = `948c2c2`）：`ADS42JB49SEK` **64** 脚、`LM358` **8** 脚、
`LM317` **3** 脚、`NE555` **8** 脚、`ADS1675REF` 64 脚 —— 与 `G2_PIN_FIX.md` 一致。

## 4. D4 `PIN|FUNCTION` 独立验收 —— **不通过，维持 PENDING**

本地 HEAD 复跑 LM317 得 3 脚（1 ADJUST / 2 OUTPUT / 3 INPUT）✓；
**但同一 commit 的服务器复跑得 4 脚**，多出一条重复的 `OUTPUT 4`，
而确定性侧只抽到 3 条（`det_pins=3`）却没纠正它：

```text
deterministic_extract.pins = {"skipped": "model_pins_complete", "kept": 4, "det_pins": 3}
```

根因：`model_pins_complete` 只校验「脚号连续」，不校验「脚数正确」也不查重名；
G2 加的补脚条件 `len(det_pins) > len(existing)` 只覆盖「模型少脚」方向。
所以**模型稿引脚数仍不可信**，本包 `pins` 应视为未验证字段。详见 `D4_PIN_VERIFY_20261103.md`。

## 5. D3 真实 UG（SBAU193E）—— **维持 PENDING**

- PDF 本轮从 TI 实下，SHA `4a35747c…` 与冻结值一致（可复核）；
- 生产口径 `is_datasheet=False` → `skipped`、0 模型调用（与 s3 一致）；
- 身份识别**通过**：`identity=evaluation_board`、`device_mpn=ADS8568`、
  `document_scope=board_user_guide`（真实 PDF，非夹具）；
- **但这份 UG 里没有热阻/ESD 参数行**：全文 `RθJA/θ/°C/W/ESD/HBM/CDM` 命中全 0
  （唯一的 "Thermal" 是 BOM 里的 "Thermal Transfer Printable Labels"）；
  确定性抽取 0 行，强制过 LLM 也 `failed`（2 次调用）。
  → **没有真实行可验，行级归属无法关闭**。

另外：**此前提交的 `D3_UG_AUDIT.md` 里那 2/2 行（`RθJA 75 °C/W`、`RθJC(top) 35 °C/W`）
在这份冻结 PDF 全文里检索不到** —— 该条证据建议撤回，不要用来关闭 D3-UG。

## 6. 本批少一件：`CDC6CE025000ADLYR`

批次原定 8 件，该件未产出。本轮用 HEAD 独立重解析 **2 次**（22:11 / 22:19），
两次都是 `status=ok` 但四容器全 0。按「不用空 JSON 冒充通过」的口径不进包，
改在 `skipped.csv` + README 留痕。宁可如实少一件，不跨轮回填。

## 7. 仍未关闭（交 Reviewer 裁定）

1. **D3-UG 行级归属** —— 需一份**真正含热阻/ESD 参数行的真实 UG**才能取证；
2. **D4 引脚** —— 建议补 `det_pins` 数量一致性校验（本轮未改代码，避免与 G2 混淆一次改两处）；
3. LM317 本地 3 脚 / 服务器 4 脚的分歧，需要裁定以哪一份为准。
