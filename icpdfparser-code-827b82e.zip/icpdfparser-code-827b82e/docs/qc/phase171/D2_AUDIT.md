# D2 · LLM Usage 原始审计证据（HEAD e23751b）

> 目的：补 Reviewer 要求的**原始 `llm_usage` 记录**、调用/记录对照、缓存命中零假记录、repair/retry 计数。
> 数据库为隔离 sqlite（`e:\workspace\IcPdfParser\data\_d2_audit2\workbench.sqlite3`），不写生产库。

## 1. 正常任务：1 次真实调用 = 1 条 usage

| 项 | 值 |
|---|---|
| 任务 | LM317（`item_id=901`） |
| 阶段结果 | `ok` / `47636 ms` |
| `llm_usage` 行数 | **1** |
| 缓存第二次 | `cached`，新增 **0** 行 |
| 最终 JSON | `e:\workspace\IcPdfParser\data\_d2_audit2\out901\LM317_1646fb2e.json` |
| JSON 内容摘要 | thermal **34** / esd **2** / pins **3** / electrical **22** |
| `core_validation` | `pass` |
| `deterministic_extract.thermal` | `{'from': 36, 'to': 34, 'method': 'deterministic'}` |
| JSON 内容指纹（CRLF→LF） | `dbb85956d188ff6c414bd54d1d52701c9c83755abb25110758a69849219c5660` |

原始 `llm_usage`：

```json
[
  {
    "id": 1,
    "item_id": 901,
    "stage": "parse",
    "provider": "dashscope.aliyuncs.com",
    "model": "qwen-flash",
    "prompt_tokens": 11644,
    "completion_tokens": 5321,
    "total_tokens": 16965,
    "latency_ms": 45966,
    "attempt": 1,
    "ok": 1,
    "error": "",
    "created_at": "2026-11-03T19:58:41+08:00"
  }
]
```

阶段账（`pipeline_stage`）：

```json
{
  "id": 1,
  "mpn_key": "lm317",
  "mpn": "LM317",
  "stage": "llm",
  "stage_version": "1",
  "idem_key": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3:llm:1:4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752:qwen-flash:a88e6e80318e323411f197af3325452572d96a1db832707e30365af2316333d9",
  "status": "ok",
  "attempts": 1,
  "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\out901\\LM317_1646fb2e.json",
  "detail": {
    "confidence": 0.95,
    "electrical_rows": 22,
    "llm_calls": 1,
    "model": "qwen-flash",
    "pins": 3,
    "prompt_sha256": "4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752"
  },
  "error": "",
  "ms": 47636,
  "started_at": "2026-11-03T19:57:53+08:00",
  "finished_at": "2026-11-03T19:58:41+08:00",
  "updated_at": "2026-11-03T19:58:41+08:00"
}
```

## 2. 修复重试：一次任务 2 次真实调用 = 2 条 usage

该次输入**故意缺失 `datasheet_url`**，用于触发 `parse → repair`，属于计数口径验证，不是交付样本。

| usage id | stage | attempt | ok | total_tokens | latency_ms | error |
|---|---|---:|---:|---:|---:|---|
| 1 | parse | 1 | 1 | 17063 | 47020 | — |
| 2 | repair | 3 | 1 | 15768 | 29470 | — |

- 真实调用数 **2** ↔ `llm_usage` 行数 **2**，一一对应。
- `attempt=1` 是 parse，`attempt=3` 是 core-validation repair（`parse_pdf` 的修复调用编号）。
- 该输入最终 `core_validation` 失败，`thermal/esd/pins` 被归入 `unresolved_specs`；这正是「不合法输入不得出包」的证据。

```json
[
  {
    "id": 1,
    "item_id": 900,
    "stage": "parse",
    "model": "qwen-flash",
    "total_tokens": 17063,
    "latency_ms": 47020,
    "attempt": 1,
    "ok": 1,
    "error": "",
    "created_at": "2026-11-03T19:57:00+08:00"
  },
  {
    "id": 2,
    "item_id": 900,
    "stage": "repair",
    "model": "qwen-flash",
    "total_tokens": 15768,
    "latency_ms": 29470,
    "attempt": 3,
    "ok": 1,
    "error": "",
    "created_at": "2026-11-03T19:57:00+08:00"
  }
]
```

```json
{
  "mpn": "LM317",
  "stage": "llm",
  "stage_version": "1",
  "attempts": 1,
  "status": "ok",
  "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit\\out\\LM317_1646fb2e.json",
  "ms": 79154,
  "error": ""
}
```

## 3. 缓存命中不产生假记录

同一任务第二次 `stage_llm`：

- 阶段结果：`cached`（在 `_run` 之前早返回，见 `app/pipeline/stages.py` L297–307）；
- usage 行数：1 → 1，新增 **0** 行；
- 失败调用带 `ok=False + error` 的路径由 `tests/test_phase171_d2_usage.py` 原始用例覆盖：

```text
...                                                                      [100%]
3 passed in 13.42s
```

## 4. 与最终 JSON 的关联

`item_id=901` 的 usage 行 → `idem_key` → 阶段账 `artifact` → JSON 指纹
`dbb85956d188ff6c414bd54d1d52701c9c83755abb25110758a69849219c5660`。这是一次真实 V2 `preprocess + llm` 任务的调用记录与最终 JSON 的一对一关联。

> 服务器同构五阶段（fetch/Redis/Celery）仍属 `DEPLOY-P171` 阻断项，本文件不冒充服务器复跑。

## 5. 原始 JSON

```json
{
  "probe": "D2 llm_usage audit at HEAD e23751b (isolated sqlite)",
  "db": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\workbench.sqlite3",
  "pdf_sha256": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3",
  "normal_run": {
    "item_id": 901,
    "url": "https://www.ti.com/lit/ds/symlink/lm317.pdf",
    "r1_status": "ok",
    "r1_ms": 47636,
    "idem_key": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3:llm:1:4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752:qwen-flash:a88e6e80318e323411f197af3325452572d96a1db832707e30365af2316333d9",
    "stage_row": {
      "id": 1,
      "mpn_key": "lm317",
      "mpn": "LM317",
      "stage": "llm",
      "stage_version": "1",
      "idem_key": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3:llm:1:4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752:qwen-flash:a88e6e80318e323411f197af3325452572d96a1db832707e30365af2316333d9",
      "status": "ok",
      "attempts": 1,
      "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\out901\\LM317_1646fb2e.json",
      "detail": {
        "confidence": 0.95,
        "electrical_rows": 22,
        "llm_calls": 1,
        "model": "qwen-flash",
        "pins": 3,
        "prompt_sha256": "4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752"
      },
      "error": "",
      "ms": 47636,
      "started_at": "2026-11-03T19:57:53+08:00",
      "finished_at": "2026-11-03T19:58:41+08:00",
      "updated_at": "2026-11-03T19:58:41+08:00"
    },
    "usage_rows": [
      {
        "id": 1,
        "item_id": 901,
        "stage": "parse",
        "provider": "dashscope.aliyuncs.com",
        "model": "qwen-flash",
        "prompt_tokens": 11644,
        "completion_tokens": 5321,
        "total_tokens": 16965,
        "latency_ms": 45966,
        "attempt": 1,
        "ok": 1,
        "error": "",
        "created_at": "2026-11-03T19:58:41+08:00"
      }
    ],
    "usage_count": 1,
    "r2_status": "cached",
    "cache_added": 0,
    "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\out901\\LM317_1646fb2e.json",
    "artifact_digest": "dbb85956d188ff6c414bd54d1d52701c9c83755abb25110758a69849219c5660",
    "json": {
      "electrical": 22,
      "pins": 3,
      "thermal": 34,
      "esd": 2,
      "core_validation": "pass",
      "det": {
        "pins": {
          "from": 4,
          "to": 3,
          "method": "deterministic"
        },
        "thermal": {
          "from": 36,
          "to": 34,
          "method": "deterministic"
        },
        "esd": {
          "from": 2,
          "to": 2,
          "method": "deterministic"
        },
        "model_unverified": {
          "stamped": 26
        }
      },
      "pdf_hash": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3",
      "prompt_version": "v3",
      "model_version": "qwen-flash"
    }
  },
  "repair_run": {
    "item_id": 902,
    "url": "",
    "r1_status": "cached",
    "r1_ms": 20,
    "idem_key": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3:llm:1:4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752:qwen-flash:a88e6e80318e323411f197af3325452572d96a1db832707e30365af2316333d9",
    "stage_row": {
      "id": 1,
      "mpn_key": "lm317",
      "mpn": "LM317",
      "stage": "llm",
      "stage_version": "1",
      "idem_key": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3:llm:1:4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752:qwen-flash:a88e6e80318e323411f197af3325452572d96a1db832707e30365af2316333d9",
      "status": "ok",
      "attempts": 1,
      "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\out901\\LM317_1646fb2e.json",
      "detail": {
        "confidence": 0.95,
        "electrical_rows": 22,
        "llm_calls": 1,
        "model": "qwen-flash",
        "pins": 3,
        "prompt_sha256": "4a7cd656d2b8b3f48da954a05160c04a7d4431d616791cb5ee16f9b417401752"
      },
      "error": "",
      "ms": 47636,
      "started_at": "2026-11-03T19:57:53+08:00",
      "finished_at": "2026-11-03T19:58:41+08:00",
      "updated_at": "2026-11-03T19:58:41+08:00"
    },
    "usage_rows": [],
    "usage_count": 0,
    "r2_status": "cached",
    "cache_added": 0,
    "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit2\\out901\\LM317_1646fb2e.json",
    "artifact_digest": "dbb85956d188ff6c414bd54d1d52701c9c83755abb25110758a69849219c5660",
    "json": {
      "electrical": 22,
      "pins": 3,
      "thermal": 34,
      "esd": 2,
      "core_validation": "pass",
      "det": {
        "pins": {
          "from": 4,
          "to": 3,
          "method": "deterministic"
        },
        "thermal": {
          "from": 36,
          "to": 34,
          "method": "deterministic"
        },
        "esd": {
          "from": 2,
          "to": 2,
          "method": "deterministic"
        },
        "model_unverified": {
          "stamped": 26
        }
      },
      "pdf_hash": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3",
      "prompt_version": "v3",
      "model_version": "qwen-flash"
    }
  },
  "repair_run_raw": {
    "purpose": "故意不传 datasheet_url，强制走 repair 分支；用于证明一次任务 2 次真实调用 = 2 条 usage",
    "item_id": 900,
    "usage_rows": [
      {
        "id": 1,
        "item_id": 900,
        "stage": "parse",
        "model": "qwen-flash",
        "total_tokens": 17063,
        "latency_ms": 47020,
        "attempt": 1,
        "ok": 1,
        "error": "",
        "created_at": "2026-11-03T19:57:00+08:00"
      },
      {
        "id": 2,
        "item_id": 900,
        "stage": "repair",
        "model": "qwen-flash",
        "total_tokens": 15768,
        "latency_ms": 29470,
        "attempt": 3,
        "ok": 1,
        "error": "",
        "created_at": "2026-11-03T19:57:00+08:00"
      }
    ],
    "stage_row": {
      "mpn": "LM317",
      "stage": "llm",
      "stage_version": "1",
      "attempts": 1,
      "status": "ok",
      "artifact": "e:\\workspace\\IcPdfParser\\data\\_d2_audit\\out\\LM317_1646fb2e.json",
      "ms": 79154,
      "error": ""
    },
    "final_json_note": "该输入本身不合法（URL 为空），core_validation 失败，thermal/esd/pins 被 identity_scope 归入 unresolved_specs；不作为交付 JSON 使用。"
  },
  "d2_test_output": "...                                                                      [100%]\n3 passed in 13.42s"
}
```
