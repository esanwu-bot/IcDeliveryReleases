# D4 · `PIN|FUNCTION` 布局独立验收（2026-11-03，本地 HEAD `948c2c2`）

**初判结论：不通过竣工验收，D4 维持 PENDING。**（→ 当日已修复，见文末《修复与双端验证》，GitHub Issue #25）

## 1. 本地独立复跑（HEAD `948c2c2`，真实模型）

```text
mpn=LM317  pdf_sha256=1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3
status=ok  llm_calls=1  elapsed=51.5s  thermal_rows=34
deterministic_extract.pins = {"skipped": "model_pins_complete", "kept": 3, "det_pins": 3, "ordered": "numeric_asc"}
pin_configuration:
  {"pin": 1, "name": "ADJUST"}
  {"pin": 2, "name": "OUTPUT"}
  {"pin": 3, "name": "INPUT"}
```

LM317（TO-220）的真实脚表就是 3 脚，与 PDF 一致。**这一次是对的。**

## 2. 服务器同构复跑（同一 commit，同一镜像依赖，Redis DB8 隔离）

```text
pins_count = 4
  {"pin": "1", "name": "ADJUST", "description": "Output voltage adjustment pin. …"}
  {"pin": "2", "name": "OUTPUT", "description": "Output voltage pin for the regulator."}
  {"pin": "3", "name": "INPUT",  "description": "Input voltage pin for the regulator."}
  {"pin": "4", "name": "OUTPUT", "description": "Output voltage pin for the regulator."}   ← 多出来的重复行
deterministic_extract.pins = {"skipped": "model_pins_complete", "kept": 4, "det_pins": 3, "ordered": "numeric_asc"}
```

证据文件：`docs/qc/phase171/g1_server/s1.json`（`report.doc.deterministic_extract.pins`）。

## 3. 根因（不是环境问题）

`apply_deterministic()` 的引脚闸门是**单向**的：

- G2（`948c2c2`）加的补脚条件是 `len(det_pins) > len(existing)` —— 只覆盖
  「模型少脚」的方向（ADS42 33→64、LM358 2→8 就是靠它）；
- 「模型**多**脚」的方向没有任何判据：只要模型的脚号是 `1..N` 连续递增，
  就被判 `model_pins_complete` 而**整份保留**。LM317 这次模型给了 1..4，
  于是 `kept=4`，确定性侧的 3 条（`det_pins=3`）反而被当作「更少的那一份」丢弃。

也就是说：`model_pins_complete` 只验证了「编号连续」，**没有验证「脚数正确」**，
更没有检查重复脚名。LM317 的 4 脚里 `OUTPUT` 出现两次，肉眼可见是错的，
但当前没有任何一条规则会拦它。

## 4. 因此

- D4 维持 **PENDING**；本包（V3-CANDIDATE）里所有**来自模型稿的引脚行**
  都应视为**未验证字段**，`pins` 计数不得作为验收通过的证据。
- 建议的最小修法（本轮不做，避免与 G2 混在一起改）：
  在 `model_pins_complete` 分支里补一条 `det_pins` 数量的**一致性校验** ——
  `det_pins` 非空且 `len(existing) != len(det_pins)` 时不走 `skipped`，
  改走逐条比对（并显式记录冲突），而不是无条件保留模型稿。
- 已验证的部分只有：LM317 在**本地**这一轮跑出 3 脚，
  以及 ADS42 64 / LM358 8 / NE555 8 在本包物料里已生效（见 `G2_PIN_FIX.md`）。

---

## 修复与双端验证（2026-11-03 当日，`e72cddc`）

**修复**：判据收进纯函数 `_pin_gate()`（`qc/deterministic_extract.py`），编号连续之外补两关：

1. **重名**：`GND/NC/EP…` 天然可重复名之外的名字出现两次 = 多编嫌疑；
   触发**整体替换**还要求确定性侧编号完整、数量对得上账
   （`det >= model - dup_extra`）——确定性侧漏抽时不许拿它覆盖干净数据（G2 教训）；
2. **总数**：编号连续、无重名、仅 `len(det) != len(model)` → **只留痕**
   （`count_mismatch` / `why=model_pins_count_mismatch`），不盲换 —— 两边都可能是对的。

**测试**：`tests/test_pin_duplicate_guard.py` 11 例。红绿验证：stash 修复后跑旧代码
（`AttributeError: _pin_gate`）为红，恢复后 11 例全绿；G2 引脚回归
（multi_package / pin_function）+ `test_deterministic_extract` 22 例全绿，无回退。

**双端验证（同一 commit `e72cddc`，真实模型）**：

| 环境 | 模型稿 | 闸门 | 最终 |
|---|---|---|---|
| 本地 run1 | 3 脚干净 | `skipped: model_pins_complete, kept 3` | 3 ✓ |
| 本地 run2 | **又给了 4 脚（重复 OUTPUT，重演服务器 bug）** | `from 4 → to 3, why=model_pins_duplicate_name` | **3 ✓** |
| 服务器 DB8 复跑 | 3 脚 | `kept 3, dup_names=[]` | **3 ✓** `[(1,ADJUST),(2,OUTPUT),(3,INPUT)]` |

服务器侧生产指纹复跑前后一致（`data/parsed` digest `acf8d167…` / sqlite `d93d6585…` /
五容器 StartedAt）。原始记录：`docs/qc/phase171/round2_20261103/lm317_double.json`
（本地双跑）、`docs/qc/phase171/round2_20261103/d4_lm317_independent.json`（独立复核）、
`docs/qc/phase171/g1_server/s1_rerun2.json`（服务器复跑）。

**仍未声称修复的部分**：编号连续、无重名、仅总数不一致的场景仍只留痕不替换，
是否升级为硬闸待 Reviewer 裁定（Issue #25）；本修复不回溯 V3-CANDIDATE 包内已固化的
`pins` 字段 —— 包内引脚仍为未验证状态。
