# G2 · 引脚异常修复（ADS42JB49SEK 64 脚 / LM358 8 脚）

**代码**：`948c2c2`（基于 `e23751b`）
**问题**：Reviewer 点名候选解析里 ADS42 只剩 33 脚、LM358 只剩 2 脚。

## 1. 根因

| 件 | 现象 | 根因 |
|---|---|---|
| ADS42JB49SEK | 33 条「1..33」功能行 | 模型把 `Pin Functions` 的 33 个功能组当成 33 个脚号；PDF p6 的真实 `PIN NO.` 表有 **64 个物理脚**，旧 `_pin_pages()` 又被 p3 目录页 `Pin Configuration and Functions.........5` 误启动，真正的 p6 根本没进抽取范围 |
| LM358 | 2 条（OUT1/OUT2） | 表头顺序是 `NAME | LCCC | SOIC | I/O`，差分脚名 `IN1–` / `IN2+` / `V–` / `V+` 含 `–` / `+`，旧 `_PIN_NAME_RE` 不含这些字符，整行被跳过 |

## 2. 修复

1. `_pin_pages()` 不再按「正文出现 pin functions」启动，只认**真实表头结构**
   （`_pin_header_end` / `_wide_header_start`），目录页不会再截断。
2. `_PIN_NAME_RE` 放开 `– — − + ~ # ±`，LM358 的差分脚名正常进入解析。
3. `_extract_pins_wide()` 的多封装列改取「**最大脚号最小的那一列**」为主封装
   （LM358：LCCC 到 20、SOIC 到 8 → 主表取 SOIC 1..8），其余列写进 `pins_by_package`。
4. 新增表格兜底 `_extract_pins_from_table()`：仅当 `find_tables()` 抽到的脚数
   **多于**文本层时启用；ADS42 的 `NO. | NAME | I/O | FUNCTION` 分组表按行展开，
   `AGND` 的 9 个脚展开为 9 条；`52,51` 被抽成 `5251` 时按 4 位数字拆回 `52` / `51`。
5. `apply_deterministic()` 的「模型连续序号就保留」闸门加上条件
   **`len(det_pins) > len(existing)`**：连续序号但**少脚**（33/64、2/8）仍必须补全。

## 3. 修复后实测

```text
ADS42JB49SEK: 64 pins, pin set == {1..64}, AGND 9 条
LM358:        8 pins, IN1–=2 / IN1+=3 / IN2–=6 / IN2+=5 / OUT1=1 / OUT2=7 / V–=4 / V+=8
LM317:        3 pins, 行为不变
ADC12DJ5200SE (BGA): 144 balls, 行为不变（未回退）
```

回归：

```text
python -m pytest tests/test_pin_layout_multi_package.py \
  tests/test_pin_layout_pin_function.py \
  tests/test_deterministic_extract.py -q
28 passed
```

新增用例：`tests/test_pin_layout_multi_package.py`（ADS42 64 / LM358 8）。
引脚条目带 `source: {page, method: deterministic}`；ADS42 p6、LM358 p3。

## 4. 残余说明（不掩盖）

- ADS42 的表格描述列会被 pymupdf 抽成 `Analogground` / `Digitalground` 等无空格文本；
  这是**描述排版**问题，不影响脚名与脚号；已在 JSON 中保留，未伪造成人工润色文本。
- 引脚数修复只覆盖上述两种布局；其他未见样本的布局仍按原有文本解析路径，未见回归。
