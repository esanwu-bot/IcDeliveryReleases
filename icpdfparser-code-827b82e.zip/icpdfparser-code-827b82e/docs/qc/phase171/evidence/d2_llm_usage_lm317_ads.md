# D2 · LM317 / ADS8568EVM-PDK 原始 llm_usage（精简）

| MPN | attempt | tokens | 状态 |
|---|---:|---:|---|
| LM317 | 1 | 16965 | ok |
| LM317(repair) | 1 | 17063 | ok |
| LM317(repair) | 3 | 15768 | ok |
| ADS8568EVM-PDK | 1 | 29418 | ok |
| ADS8568EVM-PDK | 2 | 27860 | ok |

缓存复核：两个任务第二次 `stage_llm` 均为 `cached`，usage 新增 **0** 行；原始行来源见 `d2_llm_usage_lm317_ads.csv` 与 `D2_AUDIT.json` / `evidence/d2_ads8568_usage.json`。
