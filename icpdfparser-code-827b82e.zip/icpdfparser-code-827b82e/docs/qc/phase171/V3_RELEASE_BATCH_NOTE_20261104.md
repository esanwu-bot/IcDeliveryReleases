## 本批次说明（V3-RELEASE · 2026-11-04）

### 1. 本批 5 件，从 V3-FINAL 的 7 件里剔除 2 件

| 型号 | 处置 | 理由 |
|---|---|---|
| ADS42JB49SEK | **剔除（Rejected）** | D4 引脚硬闸 `failed`：`DA0P/M`、`DA1P/M`、`DB0P/M`、`DB1P/M` 各被写成**一个名字占两个脚位**（原厂 PDF 第 6 页即合并写法，脚号 54/53）。差分对未拆分等于物理引脚无法接线；叠加电气维度 43% 未验证，退回。 |
| ADS1675REF | **剔除（Rejected）** | D4 引脚硬闸 `failed`：`DOUT` / `DRDY` / `SCLK` 各出现两次（单通道 ADC 只有一组 SPI），且属不可重复名，白名单不收。该件 PDF 引脚表文本层抽不到（`det=0`），无法用确定性结果替换，只能退回人工对照。 |

两件的剔除**不是管线判失败后的静默丢弃**，是人工复核裁决，逐条理由同时写在随包
`signoff.json` 的 `excluded` 块里。

### 2. 两个维度并列记录：机器闸门与人工签核互不覆盖

本批 5 件的机器精度闸 `anchor_gate` **全部 `blocked`** —— 底层解析没有拿到行坐标，
或只有「值出现在同页/别处」的弱证据。按 V7 起的口径，这一档不足以进 `DATA_VALIDATED`，
包内 5 件的 `gate` 因此**仍为 `BLOCKED`**，本包一个字都没有改它。

同时，5 件已由人工专家逐字段复核并签署 `content_approved=true`（签署人
`wuxiaoxian`，2026-11-04，原件 `signoff.json` 随包）。签核与机器审计量的是两件事：

| 维度 | 字段 | 本批取值 | 含义 |
|---|---|---|---|
| 机器 | `gate` / `anchor_gate` | `BLOCKED` | 机器审计未获坐标证据 |
| 人工 | `content_signoff` | `APPROVED (with warnings)` | 专家逐字段看过并签字放行 |

**机器审计未获坐标证据，由人工专家强签放行。** 逐件的豁免理由写在 `manifest.json` /
`manifest.csv` 的 `content_signoff_note` 列，不在本说明里复述。

`content_signoff=APPROVED (with warnings)` 中的 `(with warnings)` 是**保留字**：
它表示 `release_state` 跨过了 `DATA_VALIDATED` 这一机器档位。把这一档折成
`APPROVED`，等于把跨级放行洗成「机器也验过了」。身份门禁不可跨 —— 本批 5 件均为
`IDENTITY_SUPPORTED`，不涉及该情形。

### 3. 本包与 V3-FINAL 的差异边界

- **物料内容逐字节相同**：本包验收根由 `qc/subset_release_root.py` 从
  `data/staging_batch20_v3_final` 取 5 件子集并逐文件核对 SHA-256（搬运前后一致），
  **没有重解析、没有重跑归一、没有重新调用模型**。
- **事实表按 5 件重算**：`qc/fact_acceptance.py --mpns <5 件>` 重新出表，
  分母已剔除那 2 件；逐件 `anchor_gate` / 不达标条数与 7 件版**完全一致**
  （LM317 6、LM358 1、CDC6C 两件各 28、NE555 41）。
- **新增**：随包 `signoff.json` 原件；`manifest.csv` 增加 `content_signoff` /
  `content_signoff_by` / `content_signoff_note` 三列。

### 4. 状态与边界

- 5 件 `release_status` 仍为 `not_approved`，`release_state` 为 `CONTENT_APPROVED`。
- `RELEASE_APPROVED` **未签发**。本包是正式发布候选件，取得 Reviewer 的发布许可前不得上线。
- 多语言本次**仅交付 `en`**（`i18n_complete=false` 是如实记录，不是缺陷）。
- 引脚硬闸分布见下方速览；`passed` 只对账总数，逐件 `det_count` / `pin_validation`
  等结构化字段见 `manifest.json`（`manifest.csv` 放的是扁平列）。
