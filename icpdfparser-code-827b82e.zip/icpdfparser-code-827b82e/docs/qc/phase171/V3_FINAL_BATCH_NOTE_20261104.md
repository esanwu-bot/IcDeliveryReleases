# V3-FINAL 批次说明（2026-11-04 重跑）

## 1. 这一包与 V3-CANDIDATE 的唯一实质差异：引脚硬闸真的落盘了

`V3-CANDIDATE` 的 7 件解析产物冻结于 `948c2c2`，早于 D4 引脚硬闸（`217a4b9`）上线，
包内 `metadata.pin_validation` **全部为空**。`delivery_bundle._gate` 当时把「没有这道闸的
记录」读成了「这道闸放行了」，7 件全判 `CLEAN` —— 这是本包重跑的直接原因。

本包用 `4e9e31e` 在装配期重放了 `apply_pin_gate()`（与解析期同一实现、幂等，
只吃「PDF + 现有引脚集」，不重新调模型），引脚状态是这一趟算出来的：

| 型号 | `pin_validation.status` | `reason` | actual | det | model | 可信预期脚数 |
|---|---|---|---|---|---|---|
| ADS1675REF | **failed** | `duplicate_pin_name` | 64 | 0 | 64 | —（确定性侧抽不到引脚表） |
| ADS42JB49SEK | **failed** | `duplicate_pin_name` | 64 | 64 | 64 | RGC=64 |
| CDC6CE025000ADLET | **passed** | `all_checks_passed` | 4 | 2 | 4 | 4（DLE/DLF/DLX/DLY 四列同值） |
| CDC6CE025000ADLFR | **passed** | `all_checks_passed` | 4 | 2 | 4 | 同上 |
| LM317 | **unverified** | `count_unverified` | 3 | 3 | 3 | DCY=4 / KCS=3 / KCT=3 / KTT=3 |
| LM358 | **unverified** | `count_unverified` | 8 | 8 | 8 | 8 脚群中混 FK(LCCC)=20 |
| NE555 | **unverified** | `count_unverified` | 8 | 1 | 8 | 8 脚群中混 FK=20 |

**三档含义不同，不要互相替代**：

- `passed` —— 编号连续、无不可解释的重名、总数与封装表唯一可信脚数一致。
- `failed` —— 结构性错误，签核前必须逐脚对照 PDF 整改或明确豁免。
- `unverified` —— 数据在，但**无法唯一对账**（多封装脚数不一致）。不冒称通过。

### 两件 `failed` 的真实原因（不是抽取器坏了）

- **ADS1675REF**：模型稿里 `SCLK` / `DOUT` / `DRDY` 各出现两次。ADS1675 是单通道
  ADC，SPI 只有一组时钟/数据/就绪，重复即多编。该件 PDF 的引脚表文本层抽不到
  （`det=0`），无法用确定性结果替换，只能标 failed 交人工。
- **ADS42JB49SEK**：`DA0P/M`、`DA1P/M`、`DB0P/M`、`DB1P/M` 各出现两次 —— 模型把
  差分对的 P 与 M **合并成一个名字**写进两个脚位（真实应为 `DA1P` / `DA1M`）。
  该件的确定性引脚抽取同样产出合并名（PDF 单元格原文就是 `DA1P/M`），所以替换后
  仍判 failed。**放行这一类名字等于把抽取错误洗成「合法重复」**，故白名单刻意不收。

### `passed` 不等于「每个脚名都有 PDF 证据」

CDC6C 两件的 `det_count=2`（确定性只抽到 2/4 个脚），`passed` 只对账**总数**
（封装表四列全 4 脚 = 模型 4 脚）。签核时请把 `det_count` 一起看。

## 2. Evidence 精度闸：7 件全部 `anchor_gate=blocked`

`blocked` 表示「存在未达门槛的行」，**不是整件否决**。逐行明细在
`part-0001-of-0001/risk_queue.csv`（本包 346 行）。达标行可签，未达标行需人工裁决。

各件的坐标级锚定（`row_anchor / 可判行`）：

| 型号 | row_anchor | 可判行 | 总行 | anchor_gate |
|---|---|---|---|---|
| ADS1675REF | 73 | 85 | 91 | blocked |
| ADS42JB49SEK | 79 | 136 | 136 | blocked |
| CDC6CE025000ADLET | 120 | 148 | 148 | blocked |
| CDC6CE025000ADLFR | 120 | 148 | 148 | blocked |
| LM317 | 55 | 61 | 62 | blocked |
| LM358 | 99 | 101 | 101 | blocked |
| NE555 | 116 | 157 | 158 | blocked |

## 3. 多语言

本包**仅交付 `en`**。`ja` / `ko` / `de` / `es` 未开启，`i18n_complete` 因此为 `false`，
`i18n_coverage` 按最低语言记 `0.0000` —— 这是如实记录，不是缺陷。

## 4. 状态与边界

- 7 件 `release_status` 全部 `not_approved`，**未申请人工签核**。
- 本包是**灰度候选件**，供内容审批与盲审使用，不是正式发布版本。
- 包内 7 件同源于 `data/staging_batch20_v3/parsed`，本次仅重跑装配链
  （`stage_release --normalize` → `fact_acceptance` → `stage_release --keep-out`），
  **没有重新调用模型**，参数内容与 V3-CANDIDATE 一致。
