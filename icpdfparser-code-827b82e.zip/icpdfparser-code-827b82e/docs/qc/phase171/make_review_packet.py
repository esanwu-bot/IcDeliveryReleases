#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 Phase 1.7.1 独立审查包（自包含，可直接给 Reviewer）。

产出目录：data/_delivery_releases/reviews/phase171-20261103/
最终 zip：同目录 phase171-review-packet-20261103.zip
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
REL = ROOT / "data" / "_delivery_releases"
OUT = REL / "reviews" / "phase171-20261103"
EVID = ROOT / "docs" / "qc" / "phase171" / "evidence"
CODE = ROOT / "docs" / "qc" / "phase171"

COMMITS = [
    ("27bdd02", "D1 parse_pdf 接入确定性后处理"),
    ("4951c4b", "D2 stage_llm 落 llm_usage"),
    ("35d4e62", "D3 板卡 thermal/esd 字段级主体归属"),
    ("88d023e", "D1 复核修正（早落 URL / 重试后重取 metadata）"),
    ("9beeb7d", "D3 消费端闭环（canonical_view 按 subject 隔离）"),
    ("19ef765", "D4 PIN|FUNCTION 多封装列布局（待独立验收）"),
]

CODE_FILES = [
    ("run_samples.py", CODE / "run_samples.py"),
    ("check_render_view.py", CODE / "check_render_view.py"),
    ("test_phase171_d1_deterministic.py", ROOT / "tests" / "test_phase171_d1_deterministic.py"),
    ("test_phase171_d2_usage.py", ROOT / "tests" / "test_phase171_d2_usage.py"),
    ("test_phase171_d3_subject.py", ROOT / "tests" / "test_phase171_d3_subject.py"),
]

README = """# Phase 1.7.1 独立审查包（20261103）

> 目标：让 Reviewer 不依赖 GitHub 代码仓库权限，也能完成逐项复核。
> 本包是**自包含**的：基线提交、全部 diff、被测代码、测试、真实样本证据、待验清单。

## 1. 基线（本包对应的代码状态）

```
HEAD = {head}
{commits}
```

> 报告中的测试结果均对应上述基线；`19ef765`（D4）是独立项，**未被本轮 D1–D3 证据复跑覆盖**。

## 2. 先读什么

| 顺序 | 文件 | 用途 |
|---|---|---|
| 1 | `VERDICT.md` | 工程结论、逐项证据、风险与回滚 |
| 2 | `PENDING.md` | 三项未验证内容（服务器五段 / 真实 UG / D4） |
| 3 | `diffs/9beeb7d.diff` | **本轮最关键的新增修复**：D3 消费端闭环 |
| 4 | `diffs/35d4e62.diff` | D3 行级主体标注（上一环） |
| 5 | `code/test_phase171_d3_subject.py` | 四种主体分支 + 幂等 + 发布视图用例 |
| 6 | `evidence/s2-ads8568evm-pdk.json` | 真实 PDF 复跑：11 thermal / 2 esd 全 onboard_device |
| 7 | `evidence/s2-render-view.json` | **HTML 消费端**：芯片参数只在 onboard 横幅段内出现（段外 0 处） |
| 8 | `evidence/tests-phase171.txt` | 测试实跑输出 |

## 3. 代码链路（Reviewer 重点）

```
identity_scope.apply
  → _stamp_row_subjects(): row.subject / subject_source / subject_review
  → scope_contract._row_scope(): 把行级 subject 计入 scope 证据
  → canonical_view(): thermal/esd 与 electrical/absmax 同口径分桶
      onboard_device → specs.onboard_device_specs
      board          → 保留主容器
      ambiguous      → specs.unresolved_specs（待人工）
  → json_to_txt.render(): 入参第一行即 doc = canonical_view(doc)
```

## 4. 四种行级主体（对应 Reviewer 要求）

| 行级主体 | 预期 | 用例 |
|---|---|---|
| `onboard_device` | 移入隔离桶，主容器不再出现 | `test_publication_view_isolates_onboard_thermal_esd` |
| `board` | 保留主容器，不被误隔离 | `test_publication_view_keeps_board_level_thermal` |
| `ambiguous` | 进 `unresolved_specs`，不进任一正式容器 | `test_publication_view_archives_ambiguous_rows` |
| 缺少 `subject` | 按文档 scope 兼容归档，行内容原样保留 | `test_rows_without_subject_follow_doc_scope_without_loss` |
| 重复执行 | 不重复搬迁、不丢行、不改原始 doc | `test_canonical_view_is_idempotent_and_does_not_mutate_source` |

## 5. 复现命令（本机 Windows / Python 3.11+）

```powershell
python -m pytest tests/test_phase171_d3_subject.py -q          # 10 passed
python -m pytest tests/test_scope_contract.py -q               # 36 passed
python docs/qc/phase171/run_samples.py --sample 1              # LM317
python docs/qc/phase171/run_samples.py --sample 2              # ADS8568EVM-PDK
python docs/qc/phase171/run_samples.py --sample 3              # DAC8568EVM 短路
```

> 样本 1/2 会调用真实模型（DashScope），样本 3 断言 0 次调用；三者都把产物写到
> 系统临时目录，并核对 `data/parsed` 指纹（零污染）。

## 6. 不在本包范围内

- 服务器 Docker 同构五阶段复跑（需 Reviewer 在 `/tmp/p17` 执行）；
- 真实 `board_user_guide` PDF（建议 SBAU193E）；
- D4（`19ef765`）的独立验收。

详见 `PENDING.md`。
"""


def sh(*args: str) -> str:
    r = subprocess.run(args, cwd=str(ROOT), capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return r.stdout


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT)
    (OUT / "diffs").mkdir(parents=True)
    (OUT / "code").mkdir()
    (OUT / "evidence").mkdir()

    head = sh("git", "rev-parse", "--short", "HEAD").strip()
    log = sh("git", "log", "--oneline", "-12")
    ver = sh("git", "describe", "--tags", "--always", "--dirty").strip()

    commits_md = "\n".join(f"- `{s}` — {t}" for s, t in COMMITS)
    (OUT / "README.md").write_text(
        README.format(head=head, commits=commits_md), encoding="utf-8")

    (OUT / "BASELINE.md").write_text(
        "# 代码基线\n\n```\nHEAD=%s  describe=%s\n\n%s```\n" % (head, ver, log),
        encoding="utf-8")

    (OUT / "PENDING.md").write_text("""# 待验证项（Reviewer 阻断清单）

| 项 | 级别 | 状态 | 要求 |
|---|---|---|---|
| 服务器同构五阶段复跑 | 阻断整体验收 | PENDING | 用服务器 Docker + Redis DB8 + `/tmp/p17` 跑 `p17.sh`/`run_s1..s3.sh`；核对状态流转、attempts、parse_count、重复投递、生产零污染 |
| 真实 `board_user_guide` PDF | 阻断 D3 完整性 | PENDING | 补 SBAU193E 或同类真实 UG：board 行留主容器、onboard 行隔离、ambiguous 进 unresolved |
| D4 `PIN\\|FUNCTION` | 独立验收项 | PENDING | 对 `19ef765` 之后的 HEAD 重新跑真实 LM317 + 该布局夹具，不得引用旧提交结果 |

## 当前裁定建议（实现方自述，供 Reviewer 覆盖）

- D1 / D2 / D3(datasheet 分支)：按现有证据 PASS（待代码级独立复核）
- D3(board_user_guide 分支)：PENDING
- 五段服务器同构：PENDING
- D4：PENDING
- Phase 1.7.1 整体：WAITING_FOR_REVIEWER
- V2 全量启用：不批准
- V3 重建与打包：不启动
""", encoding="utf-8")

    shutil.copy2(ROOT / "docs" / "qc" / "phase171" / "VERDICT.md", OUT / "VERDICT.md")

    for sha, _ in COMMITS:
        d = sh("git", "show", "--format=fuller", "--no-color", sha)
        (OUT / "diffs" / f"{sha}.diff").write_text(d, encoding="utf-8")

    for name, src in CODE_FILES:
        shutil.copy2(src, OUT / "code" / name)

    for f in sorted(EVID.glob("*")):
        if f.is_file():
            shutil.copy2(f, OUT / "evidence" / f.name)

    zpath = OUT / "phase171-review-packet-20261103.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(OUT.rglob("*")):
            if f.is_file() and f != zpath:
                z.write(f, f.relative_to(OUT))
    size = zpath.stat().st_size
    n = sum(1 for f in OUT.rglob("*") if f.is_file())
    print(f"[packet] {OUT}  files={n}  zip={zpath.name} ({size} B)")
    print(json.dumps({"head": head, "zip": str(zpath), "zip_bytes": size},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
