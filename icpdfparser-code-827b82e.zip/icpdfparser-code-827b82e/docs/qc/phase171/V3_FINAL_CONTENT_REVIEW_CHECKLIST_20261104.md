# 7 件 V3-FINAL · 内容审批清单（CONTENT REVIEW，2026-11-04 重跑版）

**候选包**：`delivery-batch20-eval-V3-FINAL`
**装配根**：`data/staging_batch20_v3_final`（本清单所有数字取自该根实测）
**代码版本**：`4e9e31e` —— D4 硬闸装配期重放 + 电源/参考族白名单 + 缺失即 BLOCKED
**包内状态**：7 件全部 `release_status=not_approved`，未申请人工签核
**anchor_gate**：0 件 `pass` / 7 件 `blocked`

> 与 11-04 早版清单的**根本差异**：那一版 7 件的 `metadata.pin_validation` 全为空（产物冻结于 `948c2c2`，早于硬闸上线）。本版用 `4e9e31e` 在装配期重放了`apply_pin_gate`，引脚状态是**这一趟算出来的**，不是历史遗留的空字段。

状态标记：**✅ verified**（证据链完整）· **⚠️ unverified**（数据在但未逐格核验）· **❌ failed**（已知问题行，签核前须整改或明确豁免）

---

## 0. 通用裁决要点

| # | 通用事实 | 对签核的含义 |
|---|---|---|
| 1 | **Pins 维度本版已有 `pin_validation`**（装配期重放落盘），状态逐件不同 | 只有 `passed` 的件可标 verified；`unverified` / `failed` 必须人工对照 PDF 或退回 |
| 2 | **Evidence 精度闸**：`anchor_gate=blocked` 表示存在未达门槛的行，不是整件否决 | 按各件风险队列逐行裁决；达标行可签 |
| 3 | **Identity / Scope**：7 件均 `identity=chip`、`scope=device`、`scope_contract_findings=0` | 两维度整体达标（ADS1675REF 有一处人工确认项） |
| 4 | **Provenance**：每件 PDF SHA-256 记录且随包一致；`datasheet_url` 均为 TI 官方域 | 可签 |
| 5 | **Package 字段是模型抽取**，未过确定性核验 | 只在 Pins 维度作参考，不单独算 verified |

---

## 1. 总览矩阵

| 件 | PDF SHA（前12） | Identity | Electrical | AbsMax | Thermal/ESD | **Pins（硬闸）** | Evidence | 风险队列 |
|---|---|---|---|---|---|---|---|---|
| ADS1675REF | `c26252239253` | ⚠️ medium | ✅70 `audited_row_anchored` · ⚠️6 `model_unverified` · ⚠️1 `label_value_same_page` · ❌1 `unresolved` | ❌7 `unresolved` · ⚠️3 `model_unverified` | 1T/2E | ❌ `failed` | 80/91 · blocked | 21 |
| ADS42JB49SEK | `914f6302ea4b` | ⚠️ medium | ✅54 `audited_row_anchored` · ❌24 `unresolved` · ⚠️24 `label_value_same_page` · ⚠️10 `model_unverified` | ✅13 `audited_row_anchored` | 6T/1E | ❌ `failed` | 79/136 · blocked | 66 |
| CDC6CE025000ADLET | `6756ca5f8426` | ✅ | ✅93 `audited_row_anchored` · ⚠️26 `model_unverified` · ⚠️2 `label_value_same_page` | ✅5 `audited_row_anchored` | 20T/2E | ✅ `passed` | 120/148 · blocked | 50 |
| CDC6CE025000ADLFR | `6756ca5f8426` | ✅ | ✅93 `audited_row_anchored` · ⚠️26 `model_unverified` · ⚠️2 `label_value_same_page` | ✅5 `audited_row_anchored` | 20T/2E | ✅ `passed` | 120/148 · blocked | 50 |
| LM317 | `1646fb2e4f8c` | ⚠️ medium | ✅22 `audited_row_anchored` | ✅3 `audited_row_anchored` · ⚠️1 `model_unverified` | 34T/2E | ⚠️ `unverified` | 55/62 · blocked | 37 |
| LM358 | `8277dff7b891` | ✅ | ✅49 `audited_row_anchored` · ⚠️1 `model_unverified` · ✅1 `audited_paragraph` | ✅6 `audited_row_anchored` | 42T/2E | ⚠️ `unverified` | 100/101 · blocked | 45 |
| NE555 | `a3756e59fd06` | ⚠️ medium | ✅74 `audited_row_anchored` · ⚠️43 `model_unverified` | ✅6 `audited_row_anchored` · ✅1 `audited_deterministic` | 32T/2E | ⚠️ `unverified` | 116/158 · blocked | 77 |

---

## 2. 逐件明细

### 2.1 ADS1675REF

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=medium / requested==mpn：True | ⚠️ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 78 行：✅70 `audited_row_anchored` · ⚠️6 `model_unverified` · ⚠️1 `label_value_same_page` · ❌1 `unresolved` | ❌ |
| AbsMax | 10 行：❌7 `unresolved` · ⚠️3 `model_unverified` | ❌ |
| Thermal | 1 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 64 脚 · `pin_validation.status=failed` / `reason=duplicate_pin_name` · actual=64 · det=0 · model=64 · expected=— · dup=['DOUT', 'DRDY', 'SCLK'] | ❌ |
| Evidence | row 73/85（分母=可判行，总行 91） · paragraph 7 · container 0 · weak 5 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `Signal-to-noise ratio (SNR) (have=weak, need=paragraph_anchor)`
- `Total harmonic distortion (THD) (have=weak, need=row_anchor)`
- `AVDD to AGND (have=paragraph_anchor, need=row_anchor)`
- `DVDD to DGND (have=paragraph_anchor, need=row_anchor)`
- `AGND to DGND (have=paragraph_anchor, need=row_anchor)`
- `Analog I/O to AGND (have=paragraph_anchor, need=row_anchor)`
- …另 6 条，见 `risk_queue.csv`

**人工裁决项**：

- [ ] Pins ❌ `duplicate_pin_name`，重名 `['DOUT', 'DRDY', 'SCLK']` —— 逐脚对照 PDF 整改或明确豁免
- [ ] Evidence：12 条未达门槛行 + 风险队列 21 行逐行裁决

### 2.2 ADS42JB49SEK

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=medium / requested==mpn：True | ⚠️ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 112 行：✅54 `audited_row_anchored` · ❌24 `unresolved` · ⚠️24 `label_value_same_page` · ⚠️10 `model_unverified` | ❌ |
| AbsMax | 13 行：✅13 `audited_row_anchored` | ✅ |
| Thermal | 6 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 1 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 64 脚 · `pin_validation.status=failed` / `reason=duplicate_pin_name` · actual=64 · det=64 · model=64 · expected=— · dup=['DA0P/M', 'DA1P/M', 'DB0P/M', 'DB1P/M'] | ❌ |
| Evidence | row 79/136（分母=可判行，总行 136） · paragraph 0 · container 0 · weak 57 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `SNR (have=weak, need=row_anchor)`
- `SNR (have=weak, need=row_anchor)`
- `SNR (have=weak, need=row_anchor)`
- `SINAD (have=weak, need=paragraph_anchor)`
- `SINAD (have=weak, need=paragraph_anchor)`
- `SINAD (have=weak, need=paragraph_anchor)`
- …另 51 条，见 `risk_queue.csv`

**人工裁决项**：

- [ ] Pins ❌ `duplicate_pin_name`，重名 `['DA0P/M', 'DA1P/M', 'DB0P/M', 'DB1P/M']` —— 逐脚对照 PDF 整改或明确豁免
- [ ] Evidence：57 条未达门槛行 + 风险队列 66 行逐行裁决

### 2.3 CDC6CE025000ADLET

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=high / requested==mpn：True | ✅ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 121 行：✅93 `audited_row_anchored` · ⚠️26 `model_unverified` · ⚠️2 `label_value_same_page` | ⚠️ |
| AbsMax | 5 行：✅5 `audited_row_anchored` | ✅ |
| Thermal | 20 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 4 脚 · `pin_validation.status=passed` / `reason=all_checks_passed` · actual=4 · det=2 · model=4 · expected=4 | ✅ |
| Evidence | row 120/148（分母=可判行，总行 148） · paragraph 0 · container 2 · weak 26 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- …另 22 条，见 `risk_queue.csv`

**人工裁决项**：

- [ ] Pins：`passed`（all_checks_passed）—— 复核 `det_count=2` 是否覆盖到每个脚名（`passed` 只对账**总数**，不等于每脚都有 PDF 证据）
- [ ] Evidence：28 条未达门槛行 + 风险队列 50 行逐行裁决

### 2.4 CDC6CE025000ADLFR

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=high / requested==mpn：True | ✅ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 121 行：✅93 `audited_row_anchored` · ⚠️26 `model_unverified` · ⚠️2 `label_value_same_page` | ⚠️ |
| AbsMax | 5 行：✅5 `audited_row_anchored` | ✅ |
| Thermal | 20 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 4 脚 · `pin_validation.status=passed` / `reason=all_checks_passed` · actual=4 · det=2 · model=4 · expected=4 | ✅ |
| Evidence | row 120/148（分母=可判行，总行 148） · paragraph 0 · container 2 · weak 26 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- `IDD (have=weak, need=row_anchor)`
- …另 22 条，见 `risk_queue.csv`

**人工裁决项**：

- [ ] Pins：`passed`（all_checks_passed）—— 复核 `det_count=2` 是否覆盖到每个脚名（`passed` 只对账**总数**，不等于每脚都有 PDF 证据）
- [ ] Evidence：28 条未达门槛行 + 风险队列 50 行逐行裁决

### 2.5 LM317

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=medium / requested==mpn：True | ⚠️ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 22 行：✅22 `audited_row_anchored` | ✅ |
| AbsMax | 4 行：✅3 `audited_row_anchored` · ⚠️1 `model_unverified` | ⚠️ |
| Thermal | 34 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 3 脚 · `pin_validation.status=unverified` / `reason=count_unverified` · actual=3 · det=3 · model=3 · expected={'DCY': 4, 'KCS': 3, 'KCT': 3, 'KTT': 3} | ⚠️ |
| Evidence | row 55/61（分母=可判行，总行 62） · paragraph 0 · container 6 · weak 0 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `RθJA (have=container_verified, need=row_anchor)`
- `RθJA (have=container_verified, need=row_anchor)`
- `RθJA (have=container_verified, need=row_anchor)`
- `RθJA (have=container_verified, need=row_anchor)`
- `RθJA (have=container_verified, need=row_anchor)`
- `RθJA (have=container_verified, need=row_anchor)`

**人工裁决项**：

- [ ] Pins ⚠️ `count_unverified` —— 多封装脚数不唯一，需人工确认按哪个封装签核
- [ ] Evidence：6 条未达门槛行 + 风险队列 37 行逐行裁决

### 2.6 LM358

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=high / requested==mpn：True | ✅ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 51 行：✅49 `audited_row_anchored` · ⚠️1 `model_unverified` · ✅1 `audited_paragraph` | ⚠️ |
| AbsMax | 6 行：✅6 `audited_row_anchored` | ✅ |
| Thermal | 42 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 8 脚 · `pin_validation.status=unverified` / `reason=count_unverified` · actual=8 · det=8 · model=8 · expected={'D': 8, 'DGK': 8, 'P': 8, 'PS': 8, 'PW': 8, 'DDF': 8, 'FK': 20, 'JG': 8} | ⚠️ |
| Evidence | row 99/101（分母=可判行，总行 101） · paragraph 1 · container 1 · weak 0 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `HBM (have=container_verified, need=row_anchor)`

**人工裁决项**：

- [ ] Pins ⚠️ `count_unverified` —— 多封装脚数不唯一，需人工确认按哪个封装签核
- [ ] Evidence：1 条未达门槛行 + 风险队列 45 行逐行裁决

### 2.7 NE555

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / confidence=medium / requested==mpn：True | ⚠️ |
| Scope | `device` / findings=0 | ✅ |
| Electrical | 117 行：✅74 `audited_row_anchored` · ⚠️43 `model_unverified` | ⚠️ |
| AbsMax | 7 行：✅6 `audited_row_anchored` · ✅1 `audited_deterministic` | ✅ |
| Thermal | 32 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| ESD | 2 行 · **确定性抽取**（按参数名+条件+数值复现，行级无 `verification` 是设计） | ✅ |
| Pins | 8 脚 · `pin_validation.status=unverified` / `reason=count_unverified` · actual=8 · det=1 · model=8 · expected={'D': 8, 'FK': 20, 'JG': 8, 'P': 8, 'PS': 8, 'PW': 8} | ⚠️ |
| Evidence | row 116/157（分母=可判行，总行 158） · paragraph 0 · container 0 · weak 41 · `blocked` | ⚠️ |
| Provenance | `qwen-flash` / `v3` / core=`pass` / ac=`not_withheld` / quarantine=0 / normalize=yes | ✅ |

**未达门槛的行（前 6 条）**：

- `THRES voltage level (have=weak, need=paragraph_anchor)`
- `THRES voltage level (have=weak, need=paragraph_anchor)`
- `THRES voltage level (have=weak, need=paragraph_anchor)`
- `THRES voltage level (have=weak, need=paragraph_anchor)`
- `TRIG voltage level (have=weak, need=paragraph_anchor)`
- `TRIG voltage level (have=weak, need=paragraph_anchor)`
- …另 35 条，见 `risk_queue.csv`

**人工裁决项**：

- [ ] Pins ⚠️ `count_unverified` —— 多封装脚数不唯一，需人工确认按哪个封装签核
- [ ] Evidence：41 条未达门槛行 + 风险队列 77 行逐行裁决

---

## 3. 签核汇总页（CONTENT_APPROVED 由人工填写）

> 规则：逐件逐字段；`pin_validation` 非 `passed` 不得标 verified；❌ 行未经整改或明确豁免不得签；未验证字段继续标未验证。

| 件 | Pins 硬闸 | 建议口径 | CONTENT_APPROVED（人工勾选） |
|---|---|---|---|
| ADS1675REF | `failed` | **退回整改**（引脚重名：DOUT/DRDY/SCLK）—— 逐脚对照 PDF 修正后可重审；若确认原厂就是合并写法，须在签核页写明豁免依据 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| ADS42JB49SEK | `failed` | **退回整改**（引脚重名：DA0P/M/DA1P/M/DB0P/M/DB1P/M）—— 逐脚对照 PDF 修正后可重审；若确认原厂就是合并写法，须在签核页写明豁免依据 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| CDC6CE025000ADLET | `passed` | **可条件批准**（引脚硬闸 passed）；条件：确定性只覆盖 2/4 脚，其余脚名需人工对照；条件：28 条未达门槛行 + 风险队列 50 行逐行裁决 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| CDC6CE025000ADLFR | `passed` | **可条件批准**（引脚硬闸 passed）；条件：确定性只覆盖 2/4 脚，其余脚名需人工对照；条件：28 条未达门槛行 + 风险队列 50 行逐行裁决 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| LM317 | `unverified` | **条件签核**（多封装脚数不唯一：`DCY=4/KCS=3/KCT=3/KTT=3`，需人工指定按哪个封装对账）；另需裁决 6 条未达门槛行 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| LM358 | `unverified` | **条件签核**（多封装脚数不唯一：`D=8/DGK=8/P=8/PS=8/PW=8/DDF=8/FK=20/JG=8`，需人工指定按哪个封装对账）；另需裁决 1 条未达门槛行 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| NE555 | `unverified` | **条件签核**（多封装脚数不唯一：`D=8/FK=20/JG=8/P=8/PS=8/PW=8`，需人工指定按哪个封装对账）；另需裁决 41 条未达门槛行 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |

**数据来源**：`data/staging_batch20_v3_final/` 的 `parsed/*.json`、`facts_audit.json`、`facts_verdicts.json`、`risk_queue.csv`。本文件由 `qc/gen_v3f_checklist.py` 生成，所有数字为机器实测，未手工填写。
