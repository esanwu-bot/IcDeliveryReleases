# D3-UG · 真实样本搜索与真实验证（2026-11-03 第二轮）

**结论：`board_user_guide` 的行级归属在当前生产链路下不可达 —— 这不是没找到样本，
而是结构性的。** 同时本轮拿到了第一份**生产口径真正会解析**的真实 UG 证据
（BQ24230EVM / SLVU274E），验证了 onboard 分支在真实 UG 上的闭环。

## 1. 样本搜索：1202 份板卡 PDF 的全量扫描

扫描口径（`data/pdfs` 内文件名含 EVM/BOOSTXL/LAUNCHPAD/EK-/DEM- 的 PDF，共 1202 份）：

1. `identity_scope._document_evidence`（生产同款判据）判为 `board_user_guide`：**396 份**；
2. 其中正文出现参数痕迹（`RθJA/°C/W/HBM/CDM/V(ESD)`）：**19 份**；
3. 这 19 份里 `is_datasheet=True`（生产会真正解析的）：**0 份**。

19 份「有痕迹」的样本逐份核对后，痕迹还都是**散文不是表**：
`4 kV HBM ESD rating`（特性列表 bullet）、`CDM 2.04.06 WHQL Certified`（驱动文件路径，
纯误报）、`θJA ~ 27°C/W`（散热设计脚注）。没有一份有真正的热阻/ESD 参数表行。

## 2. 反向样本：BQ24230EVM（SLVU274E）—— 生产口径真正会解析的 UG

这是本轮的关键收获：与 SBAU193E（`is_datasheet=False`，直接 skipped）不同，
SLVU274E 是**第一份生产会真正跑 LLM 的真实 User's Guide**。

| 项 | 结果 |
|---|---|
| PDF | `data/pdfs/BQ24230EVM__slvu274e.pdf`，SHA `ccf05664…f0dfb21e71d`，21 页 |
| 标题证据 | `User's Guide` + `…Charge Management IC EVM`（第 1 页） |
| `is_datasheet` | **True** → 生产链路真实解析（LLM 2 次调用，97.8s） |
| `identity` / `device_mpn` | `evaluation_board` / `BQ24230` |
| `document_scope` | **`onboard_device_datasheet`**（证据 `device_document`：正文以芯片为主角） |
| `specs.scope` / `pin_scope` | `onboard_device` / `board` |
| 行级结果 | 6 条电气行**全部**进 `onboard_device_specs` 桶，主容器 0、unresolved 0、行数守恒（6=6+0+0） |

证据：`.sandbox/d3_ug_bq24230/BQ24230EVM_ccf05664.json`（产物原件）、
`.sandbox/d3_ug_bq24230.json`（验证记录）。

**它验证了**：真实 UG 上「芯片规格行 → onboard 桶、主容器不污染」的闭环。
**它没验证**：`board_user_guide` 分支 —— 这份文档按生产判据就是
`onboard_device_datasheet`，不是 `board_user_guide`。

## 3. 为什么 `board_user_guide` 行级归属「不可达」

把 1、2 放在一起，结构性原因就出来了：

- 标题能命中 `board_user_guide`（请求型号 + `User's Guide` 同框）的 UG，
  `is_datasheet` 全是 False → 生产**跳过**，永远没有行；
- `is_datasheet=True`、有参数行的 UG（如 SLVU274E），标题证据命中的是
  `device_document` → 判成 `onboard_device_datasheet`，走的不是 UG 分支。

也就是说：**当前语料里不存在「生产会解析 + 判为 board_user_guide + 带参数行」三条件同时成立的样本**，
396 份 UG 全扫过，不是没找，是这条路径今天没有真实流量。

## 4. D3-UG 的处置建议（不擅自改，交 Reviewer 裁定）

1. **维持 PENDING，但阻断理由更新为「分支不可达」**：行级归属逻辑本身有
   单元测试覆盖（四分支用例 46 passed），真实样本侧卡在**入口策略**而不是归属算法；
2. 若产品上确实要「UG 参数表进站」，需要的不是继续找样本，而是一个**策略决定**：
   `is_datasheet` 是否要为带 SPECIFICATION 表的 UG 放行（或给 UG 单独入口）——
   这是流量与成本决策，不在本轮工程修复范围；
3. 若产品上决定「UG 不进站」，那 `board_user_guide` 分支应**显式标注为
   无生产流量、仅测试覆盖**，D3-UG 以「不可达」结案，而不是永远挂着。

## 5. 本轮证据清单（已入库）

- 扫描日志：`docs/qc/phase171/round2_20261103/ug_hunt2.log`（396 份 UG）、
  `docs/qc/phase171/round2_20261103/ug_hunt3.log`（19 份带痕迹 → 全 is_ds=False）
- 真实生产路径验证：`docs/qc/phase171/round2_20261103/d3_ug_bq24230.json` + 产物
  `docs/qc/phase171/round2_20261103/BQ24230EVM_ccf05664.json`
- GitHub：Issue #26 已建，附本报告链接与结论
