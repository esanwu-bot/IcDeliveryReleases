## 本批次说明（V3-RELEASE-V3.1 · 2026-11-04）

### 0. 本版是什么：发布元数据修订，不是重做

`V3-RELEASE-V3.1` 相对 `V3-RELEASE-V3` 只改**发布元数据与表述**，交付物料、事实表、
签核结论、机器结论**一字未动**。四项定点修复：

| # | 外审意见 | 本版处置 |
|---|---|---|
| 1 | 交付说明自相矛盾：已签核，正文却仍按未签核的口径写 | 改为按签核实况渲染：「5 件已由人工专家完成 `CONTENT_APPROVED` 签核（限定维度）」；发布放行单独一行写未申请。旧口径已加入自检禁用词，回退即红 |
| 2 | 需明确受限发布 | README 与《交付说明.md》各增「受限数据发布」小节，逐件列出批准/放弃的维度；明写 `anchor_gate=blocked` 与引脚警告**依然生效**，不得包装成完整规格 |
| 3 | 状态隔离 | `包校验报告.json` 的 `engineering_validation` 与 `release_status` 保持 `not_approved`，本版**未改**（详见第 4 节实测） |
| 4 | 需独立哈希复核记录 | 从**全新 clone** 的发布仓库取 ZIP、解压、用系统同口径算原始字节 SHA-256，与 `signoff.final.json::binding` 对账，日志原样随包为 `独立哈希复核记录.txt`（`--attach` 入清单） |

上面第 1 条之所以是「过期话」而不是「写错」：V2 时确实没签，V3 加了签核但这段模板没跟着改。
模板里写死结论，就一定会有忘改的那一次 —— 所以本版改成**按 signoff 实况渲染**，
签了两件写两件，一件没签就不出现这句话。


### 1. V3 合规补丁回顾：三项，均已在 V3.1 中生效

本包与 `V3-RELEASE-V2` 的**交付物料逐字节相同**（验收根整目录复制后逐文件核对 SHA-256，
无一处不一致）。改动只落在三个合规层面，都不触碰产品内容、不重跑解析、不改机器结论：

| # | 外审意见 | 本版处置 |
|---|---|---|
| 1 | `signoff.final.json` 的 binding 哈希与 `包校验报告.json` 不一致 | **诊断为双口径而非绑错文件**：同一份文件在「ZIP 原始字节」与「CRLF→LF 归一后」两种口径下必然哈希不同。本版把两口径**分别命名并各给一个值**，`verify` 同时校验两者 |
| 2 | CDC6C 两件 `approved_dimensions` 为空但 `content_approved=true`，自相矛盾 | 维度划分从 `by_kind`（table/prose 两桶）改为**逐容器**实测；空批复现在会让构建**直接失败**，不可能再进包 |
| 3 | 引脚使用边界需要防呆 | `manifest.json` / `README.md` / 《交付说明.md》三处并列强警告，`pin_validation=passed` 额外注明「仅总数对账」 |

### 2. 哈希「不一致」的真相：两种口径，两组值都正确

外审读到的是「binding 里的 `facts_audit.json` 哈希 ≠ 报告里的」。实际是同一份文件被两种口径各算了一次：

| 文件 | ZIP 原始字节（raw） | CRLF→LF 归一（normalized） | 谁记了哪个 |
|---|---|---|---|
| `facts_audit.json` | `c20e1420…` | `21b9c44a…` | V2 的 binding 记 raw，报告记 normalized |
| `risk_queue.csv` | `f85ba016…` | `bd0429d8…` | 同上 |
| `signoff.json` | `f815de3f…` | `eb4201cc…` | 同上 |

为什么必须存在两种口径：

- **raw** —— ZIP 成员按原始字节落盘，复核方拿 `sha256sum` 直接对得上。若只给归一值，手工复核永远失败。
- **normalized** —— `git clone` 在 Windows 会把 LF 写成 CRLF，不归一会「哈希对、大小不对」地白查一轮。自检报告因此按归一值算。

V2 的错误不是算错，是**一处记 raw、一处记 normalized 而都没命名** —— 合规文件里出现同名不同值，
在任何审计口径下都会被读成「绑定了旧文件」。本版改法是命名而非替换：

```json
"facts_audit_sha256_raw":        "c20e1420…",   // sha256sum 直核
"facts_audit_sha256_normalized": "21b9c44a…",   // 与 包校验报告.json 同口径
"risk_queue_sha256_raw":         "f85ba016…",
"risk_queue_sha256_normalized":  "bd0429d8…",
"hash_convention": { "raw": "…", "normalized": "…" }
```

`qc/signoff_v2.py verify` 现在**分别校验四个值**，并要求 `包校验报告.json` 的 `verified_members`
与 ZIP 内实测的 normalized 值一致。任一口径对不上即报错 —— 不允许「另一个口径碰巧对上」来放行，
那正是 V2 把「绑错文件」掩盖成「口径差异」的路径。

### 3. 维度划分：逐容器，不是 table/prose 聚合

V2 用 `facts_audit.json::by_kind` 的 `ok/total` 判定。CDC6C 两件是 `table 54/60` —— 未全 ok，
于是 `approved_dimensions` 落成空数组；但**逐容器看，它们的 `absolute_max` 5/5、`thermal` 20/20
全部到了坐标级**。把「有维度没全达标」写成「一个维度都没批」，再配上 `content_approved=true`，
就是外审看到的矛盾。

本版改为读 `facts_audit.csv` 的 `container` 列逐容器算，实测结果：

| 型号 | approved_dimensions | excluded_dimensions |
|---|---|---|
| LM317 | identity、`electrical` 22/22、`esd` 2/2 | `absolute_max` 3/4、`thermal` 28/34 |
| LM358 | identity、`absolute_max` 6/6、`electrical` 51/51、`thermal` 42/42 | `esd` 1/2 |
| CDC6CE025000ADLET | identity、`absolute_max` 5/5、`thermal` 20/20 | `electrical` 95/121、`esd` 0/2 |
| CDC6CE025000ADLFR | identity、`absolute_max` 5/5、`thermal` 20/20 | `electrical` 95/121、`esd` 0/2 |
| NE555 | identity、`esd` 2/2、`thermal` 32/32 | `absolute_max` 6/7、`electrical` 76/117 |

容器行统一加 `container:` 前缀，与 `electrical_pin_mapping_unverified` 消歧 ——
前者是「电特性表这一段」，后者是「引脚定义能不能接线」，不是一件事。

**空批复现在是构建期硬失败**：`content_approved=true` 而 `approved_dimensions` 为空，
`build` 直接 `SystemExit`；`verify` 侧也会独立报一次，复核方不必靠人眼发现。

### 4. 引脚使用边界：三处强警告

> `pin_validation=unverified`、或仅作总数对账的 `passed`，其引脚数据**仅供预览**，
> 绝对不可用于自动接线、封装选型或逆向工程；需要接线级可用性时，必须逐脚对照原厂 PDF 并由人工签核。

三处并列出现：`manifest.json::pin_usage_notice`、`README.md` 速览、《交付说明.md》表前。
只在 README 写等于没写 —— 客户读的是清单。

`electrical_pin_mapping_unverified` 在 `excluded_dimensions` 里**逐件必写**，且把 `passed` 的
真实含义摊开：CDC6C 两件是 `actual=4 / expected=4` 的**总数对账**，没有逐脚核对引脚名称与功能。
不写这层，下游会把 `passed` 读成「可以照着接线」，那是最贵的一种误读。

### 5. 本批 5 件，从 V3-FINAL 的 7 件里剔除 2 件

| 型号 | 处置 | 理由 |
|---|---|---|
| ADS42JB49SEK | **剔除（Rejected）** | D4 引脚硬闸 `failed`：`DA0P/M`、`DA1P/M`、`DB0P/M`、`DB1P/M` 各被写成**一个名字占两个脚位**（原厂 PDF 第 6 页即合并写法，脚号 54/53）。差分对未拆分等于物理引脚无法接线；叠加电气维度 43% 未验证，退回。 |
| ADS1675REF | **剔除（Rejected）** | D4 引脚硬闸 `failed`：`DOUT` / `DRDY` / `SCLK` 各出现两次（单通道 ADC 只有一组 SPI），且属不可重复名，白名单不收。该件 PDF 引脚表文本层抽不到（`det=0`），无法用确定性结果替换，只能退回人工对照。 |

两件的剔除**不是管线判失败后的静默丢弃**，是人工复核裁决，逐条理由同时写在随包
`signoff.json` 的 `excluded` 块里。

### 6. 两个维度并列记录：机器闸门与人工签核互不覆盖

本批 5 件的机器精度闸 `anchor_gate` **全部 `blocked`** —— 底层解析没有拿到行坐标，
或只有「值出现在同页/别处」的弱证据。按 V7 起的口径，这一档不足以进 `DATA_VALIDATED`。

同时，5 件已由人工专家逐字段复核并签署 `content_approved=true`（签署人
`wuxiaoxian`，2026-11-04，原件 `signoff.json` 随包）。签核与机器审计量的是两件事：

| 维度 | 字段 | 本批取值 | 含义 |
|---|---|---|---|
| 机器（证据等级） | `anchor_gate` | `BLOCKED`（5/5） | 机器审计未获坐标证据 |
| 机器（物料硬伤） | `gate` | 3 件 `BLOCKED`（引脚未验）/ 2 件 `CLEAN` | 只查溯源链、引脚硬闸、PDF 一致性、身份 |
| 人工 | `content_signoff` | `APPROVED (with warnings)` | 专家逐字段看过并签字放行 |

**`gate` 与 `anchor_gate` 不是同一道闸**，不可互推：`gate=CLEAN` 不代表 `anchor_gate=pass`。
本批恰有两件（CDC6C）`gate=CLEAN` 却 `anchor_gate=blocked`，两列已在 `manifest.json` /
`manifest.csv` 逐件列出，请分别判读。`manifest.json::gate_semantics` 写有同口径说明。

**机器审计未获坐标证据，由人工专家强签放行。** 逐件的豁免理由写在 `manifest.json` /
`manifest.csv` 的 `content_signoff_note` 列，不在本说明里复述。

`content_signoff=APPROVED (with warnings)` 中的 `(with warnings)` 是**保留字**：
它表示 `release_state` 跨过了 `DATA_VALIDATED` 这一机器档位。把这一档折成
`APPROVED`，等于把跨级放行洗成「机器也验过了」。身份门禁不可跨 —— 本批 5 件均为
`IDENTITY_SUPPORTED`，不涉及该情形。

### 7. 事实表口径（与 V3-FINAL 一致）

`qc/fact_acceptance.py --mpns <5 件>` 重新出表，分母已剔除那 2 件；逐件不达标条数与
7 件版**完全一致**（LM317 6、LM358 1、CDC6C 两件各 28、NE555 41）。

### 8. 状态与边界

- 5 件 `release_status` 仍为 `not_approved`，`release_state` 为 `CONTENT_APPROVED`。
- `RELEASE_APPROVED` **未签发**。本包是正式发布候选件，取得 Reviewer 的发布许可前不得上线。
- 多语言本次**仅交付 `en`**（`i18n_complete=false` 是如实记录，不是缺陷）。
- 引脚数据按第 3 节边界使用。
