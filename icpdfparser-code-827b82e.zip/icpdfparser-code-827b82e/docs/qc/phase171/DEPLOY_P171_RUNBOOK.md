# DEPLOY-P171 · 最新 HEAD 服务器同构五阶段复跑 Runbook

> 状态：**PENDING / 阻断 V3 最终验收**
> 原因：当前执行环境是 Windows 本地沙箱，没有 Docker、Redis、Celery worker，
> 也没有目标服务器凭据；不能把本地隔离运行冒充服务器同构。

## 1. 固定基线

| 项 | 值 |
|---|---|
| 代码 HEAD | `e23751b`（含 D1–D4；D4=`19ef765`） |
| 镜像 | 服务器现有 `icpdf/app:latest`；必须记录实际镜像 ID |
| 灰度隔离 | Redis **DB8**；数据根 `/tmp/p17/data_s{1,2,3}`；`p17-*` 容器 |
| 生产红线 | 不重启 `icpdf-server/render/llm/fetch/redis`；不写正式数据根 |

## 2. 执行步骤（服务器）

```bash
# 1) 只读归档固定代码，不覆盖服务器工作区
mkdir -p /tmp/p17/code-e23751b
git archive e23751b | tar -x -C /tmp/p17/code-e23751b

# 2) 确认镜像与代码
docker inspect -f '{{.Image}} {{.Created}}' icpdf/app:latest
cd /tmp/p17/code-e23751b && git rev-parse HEAD 2>/dev/null || echo "archive e23751b"

# 3) 复用 Phase 1.7 隔离 harness（三件冻结样本）
#    run_s1.sh / run_s2.sh / run_s3.sh 内已固定 MPN、URL、SHA256
bash docs/qc/phase17/harness/run_s1.sh
bash docs/qc/phase17/harness/run_s2.sh
bash docs/qc/phase17/harness/run_s3.sh

# 4) 采集
#    /tmp/p17/s{1,2,3}.json          每件 probe report
#    /tmp/p17/log_s{1,2,3}-*.log     五段 worker 原始日志
#    /tmp/p17/data_s{1,2,3}/         隔离数据根
```

## 3. 必须记录的字段（缺一项不算完成）

- 实际镜像 ID、代码 HEAD、Image Created；
- Redis DB、队列名、worker role、并发数；
- 五阶段各自 `status`、`attempts`、`ms`、`idem_key`；
- `parse_count`、`start/download`、`dedup`、`already_running`；
- PDF 实收 SHA256 与冻结值对照；
- `llm_usage` 行数与最终 JSON 路径/指纹的对应关系；
- 重复投递、并发投递的幂等结果；
- 生产数据目录与生产库的**内容 SHA256**前后对照（不是只看文件数/mtime）；
- 五个生产容器的 `RestartCount` / `StartedAt` / Image。

## 4. 停止线

1. 已完成 `done` 被降级；
2. 非预期重复下载；
3. 缓存命中导致 `parse_count` 增加；
4. `already_running` 无原任务；
5. 无法解释的永久中间态；
6. 板卡/芯片身份错误归属；
7. 生产数据/页面/交付包发生未批准变化。

触发即停，保留现场，不先清理容器或 Redis。

## 5. 与 V3 的门关系

- 本项完成前：**V3 最终验收阻断**；V3 candidate 物料只能标记 `NOT-APPROVED`。
- 本项完成后仍需：D2-AUDIT 原始记录复核、D3-UG 真实分支复核、8 件重新解析/渲染、
  63 项自检、人工 `CONTENT_APPROVED` / `RELEASE_APPROVED` 签核。

## 6. 本机已完成的替代证据（不能替代本项）

- `docs/qc/phase171/D2_AUDIT.json`：隔离 sqlite 的原始 `llm_usage` 行、调用/记录对照、缓存 0 新增、repair 计数；
- `docs/qc/phase171/D3_UG_AUDIT.md`：真实 SBAU193E UG 的 board 分支与发布视图证据；
- `docs/qc/phase171/evidence/s2b-ug-sbau193e.json`：UG 原始行/主体/发布视图计数。
