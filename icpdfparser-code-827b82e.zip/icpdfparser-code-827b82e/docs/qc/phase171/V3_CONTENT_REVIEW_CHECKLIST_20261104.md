# 7 件 V3 候选 · 内容审批清单（CONTENT REVIEW，2026-11-04）

**候选包**：`delivery-batch20-eval-V3-CANDIDATE`
**ZIP SHA-256**：`a3752d1fff933fdf2c22849fdeed8671ec3a590d3f62253cd58ef0d72804c6bf`
**发布仓库提交**：`3cdf5d6` · [CMD] 质审单 #24
**包内状态（签核期间不变）**：7 件全部 `release_status=not_approved` / `release_state=PACKAGING_PASSED` / gate=CLEAN
**裁决依据**：Reviewer 2026-11-04 收网裁决 —— 批准 7 件进入逐项内容审批；逐件逐字段检查；
未验证字段必须继续标记未验证，**不允许**通过其他字段的高质量表现抵消。

**审查维度（Reviewer 规定 8 项）**：Identity / Scope / Electrical / Absolute Maximum /
Thermal·ESD / Pins / Evidence / Provenance。

状态标记：**✅ verified**（证据链完整，可直接签核）·
**⚠️ unverified**（数据在但未逐格核验，需人工裁决后定）·
**❌ failed**（已知问题行，签核前须整改或明确豁免）。

---

## 0. 通用裁决要点（7 件共有的前提，逐件不再重复）

| # | 通用事实 | 对签核的含义 |
|---|---|---|
| 1 | **Pins 维度全部 unverified**：7 件的解析产物冻结于 commit `948c2c2`，早于 D4 硬闸（`217a4b9`，`pin_validation` 契约）上线，包内 7 件**均无** `metadata.pin_validation` | 任何一件的引脚字段都**不能**标 verified 签核；要么按新硬闸重审计，要么人工对照 PDF 逐脚确认 |
| 2 | **Evidence 精度闸全部 blocked**（`anchor_gate=blocked`）：不是整件否决，是「存在未达门槛的证据行」，行级明细在各件 `risk_queue` | 签核时参照各件风险队列逐行裁决；达标行（row_anchor 命中）可签 |
| 3 | **Identity / Scope**：7 件均 `identity=chip`、`identity_state=IDENTITY_SUPPORTED`、`requested_mpn == mpn`、`document_subject == data_subject`、`specs.scope=device`、`pin_scope=device`、`scope_contract_findings=0` | 身份与文档 scope 两个维度整体达标（ADS1675REF 有一处人工确认项，见该件明细） |
| 4 | **Provenance**：`model=qwen-flash`、`prompt=v3`、`confidence=0.95`、`core_validation=pass`、`ac_data_state=not_withheld`；每件 PDF SHA-256 已记录且与包内随行 PDF 一致（`pdf_hash_match=True`）；datasheet_url 均为 TI 官方域 | 溯源链完整，Provenance 维度可签（G1 服务器复跑已证零污染） |
| 5 | **Package 字段是模型抽取**（未过确定性核验） | 各件封装列/引脚数声明只在 Pins 维度里作为参考，不单独算 verified |

---

## 1. 总览矩阵

✅ = verified 可签 · ⚠️ = unverified 待人工 · ❌ = 存在 failed 行

| 件 | PDF SHA（前12） | Identity | Scope | Electrical | AbsMax | Thermal/ESD | Pins | Evidence | Provenance | 风险队列 |
|---|---|---|---|---|---|---|---|---|---|---|
| ADS1675REF | `c26252239253` | ⚠️¹ | ✅ | ✅64 ⚠️8 ❌6 | ⚠️3 ❌7 | ⚠️ | ⚠️64 | ⚠️ | ✅ | 25 |
| ADS42JB49SEK | `914f6302ea4b` | ✅ | ✅ | ✅45 ⚠️19 ❌48 | ✅12 ❌1 | ✅ | ⚠️64 | ⚠️ | ✅ | 75 |
| CDC6CE025000ADLET | `6756ca5f8426` | ✅ | ✅ | ✅76 ⚠️45 | ✅5 | ✅ | ⚠️4² | ⚠️ | ✅ | 50 |
| CDC6CE025000ADLFR | `6756ca5f8426` | ✅ | ✅ | ✅76 ⚠️45 | ✅5 | ✅ | ⚠️4² | ⚠️ | ✅ | 50 |
| LM317 | `1646fb2e4f8c` | ✅ | ✅ | ✅21 ⚠️1 | ✅1 ⚠️1 ❌2 | ✅ | ⚠️³ | ⚠️ | ✅ | 39 |
| LM358 | `8277dff7b891` | ✅ | ✅ | ✅49 ⚠️2 | ✅6 | ✅ | ⚠️⁴ | ⚠️ | ✅ | 45 |
| NE555 | `a3756e59fd06` | ✅ | ✅ | ✅73 ⚠️43 ❌1 | ✅7 | ✅ | ⚠️8 | ⚠️ | ✅ | 78 |

¹ ADS1675REF：MPN 为 ADS1675 的评估模块（REF），而 datasheet_url 与内容主体均为 ADS1675 芯片册；工程侧按 subject 一致判 IDENTITY_SUPPORTED（identity_confidence=medium）。**「REF 件挂芯片册」是否按板卡口径重判，属人工裁决项。**
² CDC6C 两件：引脚表为模型稿（无 source）；新硬闸重审计预告——封装表四列唯一 4 脚，但确定性引脚抽取只能抽到 3/4（缺 1、2 号），重跑将判 `incomplete_numbering`（failed）。**签核前必须人工对照 PDF。**
³ LM317：3 脚已经 D4 双端验证（本地双跑 + 服务器 DB8 复跑稳定 3 脚、确定性来源 p5）；但封装表 DCY=4/KCS=3 脚数不唯一 → 按新硬闸为 `count_unverified`，不能机器标 verified。人工确认 3 脚口径（KCS/TO-220 视角）后可签。另注意 package 字段模型稿为 "4-VDFN"，与 datasheet 封装列（SOT-223/TO-220/TO-263）不符，需人工更正或豁免。
⁴ LM358：8 脚行带确定性来源（p3），采编一致；但封装表含 FK(LCCC)=20 混值 → `count_unverified`，同 LM317 处理。

---

## 2. 逐件明细

### 2.1 ADS1675REF（TQFP-64 声明，64 脚声明）

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` / requested==mpn / identity_confidence=**medium**；描述与 URL 均指向 ADS1675 芯片 | ⚠️ 人工确认（REF 件挂芯片册，见总览注¹） |
| Scope | device / findings=0 | ✅ |
| Electrical | 78 行：`audited_row_anchored` 64（页码+bbox，name+value 匹配）；`label_value_same_page` 2；`model_unverified` 6；`unresolved(column_roles_not_verified)` 6 | ✅64 · ⚠️8 · ❌6 |
| AbsMax | 10 行：`model_unverified` 3；`unresolved` 7（列角色未证） | ⚠️3 · ❌7 —— 本件 AbsMax 是最大阻断维度 |
| Thermal/ESD | thermal 1 行（RθJA 60 °C/W, TQFP-64）、ESD 2 行（HBM ±2000 V / CDM ±1000 V）——**均为模型稿**，确定性抽取未产出（`deterministic_extract` 无 thermal/esd 记录），未逐格核验 | ⚠️ |
| Pins | 64 行模型稿，无 source 页码、无 `pin_validation`；与 TQFP-64/64 脚声明自洽但未核验 | ⚠️ |
| Evidence | row_anchor 73/91 · paragraph 7/91 · coord 80/91 · container_verified 0/91 · anchor_gate=blocked | ⚠️（风险队列 25 行逐行裁决） |
| Provenance | qwen-flash / v3 / 0.95 / core=pass / ac=not_withheld / PDF SHA 记录且随包一致 | ✅ |

**人工裁决项**：
- [ ] Identity：ADS1675REF（评估模块）挂 ADS1675 芯片册 —— 维持 chip 口径，还是改判板卡？
- [ ] AbsMax ❌7 行 + thermal/esd 3 行：逐行对照 PDF（p5 Absolute Maximum / 封装页）后签或退回
- [ ] Electrical ❌6 行（column_roles_not_verified）：列角色人工确认

### 2.2 ADS42JB49SEK（VQFN-64）

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED`，subject 一致 | ✅ |
| Scope | device / findings=0 | ✅ |
| Electrical | 112 行：anchored 45 · same_page 9 · model_unverified 10 · **unresolved 48（column_roles_not_verified，占 43%）** | ✅45 · ⚠️19 · ❌48 —— 本件最大阻断项 |
| AbsMax | 13 行：`audited_deterministic` 12 · unresolved 1 | ✅12 · ❌1 |
| Thermal/ESD | thermal 6 行、ESD 1 行，均为确定性抽取（6→6、1→1） | ✅ |
| Pins | 64 行：确定性对账 kept=64=det 64，行带来源（p6，deterministic）；无 `pin_validation`（硬闸晚于冻结） | ⚠️ |
| Evidence | row 83/140 · paragraph 0 · coord 83/140 · container 0/140 · blocked | ⚠️（风险队列 75 行，7 件中第二多） |
| Provenance | 同通用 | ✅ |

**人工裁决项**：
- [ ] Electrical ❌48 行列角色未证（JESD204B 类多列参数表）——逐行确认或退回重抽
- [ ] 其余 ⚠️19 行按风险队列裁决

### 2.3 CDC6CE025000ADLET（VSON DLE-4）与 2.4 CDC6CE025000ADLFR（VSON DLF-4）

两件**同一源 PDF**（SHA `6756ca5f8426`），内容除封装码外完全一致，可并行签核。

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` | ✅ |
| Scope | device / findings=0 | ✅ |
| Electrical | 121 行：anchored 76 · same_page 19 · model_unverified 26 · unresolved **0** | ✅76 · ⚠️45 |
| AbsMax | 5 行全部 `audited_deterministic` | ✅ |
| Thermal/ESD | thermal 20 行、ESD 2 行，均为确定性（20→20、2→2） | ✅ |
| Pins | 4 行模型稿（`1 OE/ST/NC`、`2 GND`、`3 CLK`、`4 VDD`），无 source、无 pin_validation。**新硬闸重审计预告**：确定性引脚表只抽得到 3/4 号（缺 1、2），唯一可信脚数 4 → 将判 `incomplete_numbering`（failed）。复合脚名 `OE / ST / NC`（按订单选项变化）也需人工确认表述 | ⚠️（签核前必须人工对照 PDF p2-3） |
| Evidence | row 120/148 · coord 120/148 · container 2/148 · blocked | ⚠️（风险队列各 50 行） |
| Provenance | 同通用 | ✅ |

**人工裁决项**（两件各一式）：
- [ ] 引脚 4 行逐脚对照 PDF（特别是复合名与 1、2 号脚归属）
- [ ] ⚠️45 行 model_unverified / same_page 按风险队列裁决

### 2.5 LM317

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity | `chip` / `IDENTITY_SUPPORTED` | ✅ |
| Scope | device / findings=0 | ✅ |
| Electrical | 22 行：anchored 21 · same_page 1 · **model_unverified 0 · unresolved 0**（7 件中最干净） | ✅21 · ⚠️1 |
| AbsMax | 4 行：deterministic 1 · model_unverified 1 · unresolved 2 | ✅1 · ⚠️1 · ❌2 |
| Thermal/ESD | thermal 34 行确定性（**模型稿 36 → 34**，剔除 NA 占位列）、ESD 2 行确定性（3→2）；封装列逐列展开（DCY/KCS/KCT/KTT） | ✅（G1 服务器复跑同构验证过） |
| Pins | 3 脚（ADJUST/OUTPUT/INPUT），确定性来源 p5；**D4 双端验证稳定 3 脚**（本地 run2 重演 bug 被闸门纠正 + 服务器 DB8 复跑一致）。新硬闸口径：封装表 DCY=4/KCS=3 不唯一 → `count_unverified`，机器不可标 verified | ⚠️（人工确认 3 脚口径后可签） |
| Evidence | row 55/62 · coord 55/62 · container 6/62 · blocked · verdict=partial_pass | ⚠️（风险队列 39 行） |
| Provenance | 同通用 | ✅ |

**人工裁决项**：
- [ ] **Package 字段矛盾**：模型稿 "4-VDFN, 4 pins"，但 datasheet 热阻表封装列为 DCY (SOT-223)/KCS (TO-220)/KCT/KTT (TO-263)——需人工更正或豁免
- [ ] 3 脚口径签核（建议按 KCS/TO-220 主封装视角）
- [ ] AbsMax ❌2 unresolved 行对照 PDF

### 2.6 LM358（SOIC-8）

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity / Scope | `chip` / `IDENTITY_SUPPORTED` / device / findings=0 | ✅ |
| Electrical | 51 行：anchored 49 · model_unverified 1 · same_page 1 | ✅49 · ⚠️2 |
| AbsMax | 6 行全部 `audited_deterministic` | ✅ |
| Thermal/ESD | thermal 42 行确定性（42→42，含 D/DGK/P/PS/PW/DDF/FK/JG 八封装列）、ESD 2 行确定性 | ✅ |
| Pins | 8 脚带确定性来源（p3），G2 修复对账 8=8；新硬闸口径：封装表含 FK(LCCC)=20 混值 → `count_unverified` | ⚠️（人工确认 8 脚标准封装口径后可签） |
| Evidence | row 99/101 · paragraph 1/101 · coord 100/101 · container 1/101 · blocked · partial_pass | ⚠️（风险队列 45 行） |
| Provenance | 同通用 | ✅ |

**人工裁决项**：
- [ ] 8 脚口径签核（标准双运放 D/P 封装视角；FK 20 脚为带 NC 的载板封装）
- [ ] ⚠️2 行按风险队列裁决

### 2.7 NE555（8-Pin PDIP/SOIC/TSSOP/SO/CDIP/LCCC 声明）

| 维度 | 实况 | 状态 |
|---|---|---|
| Identity / Scope | `chip` / `IDENTITY_SUPPORTED` / device / findings=0 | ✅ |
| Electrical | 117 行：anchored 73 · **model_unverified 43** · unresolved 1 | ✅73 · ⚠️43 · ❌1 —— 本件最大阻断项（43 行未核验） |
| AbsMax | 7 行全部 `audited_deterministic` | ✅ |
| Thermal/ESD | thermal 32 行确定性（33→32）、ESD 2 行确定性；**Temperature 确定性修正**：模型稿 `0°C to 70°C` → `-40°C to 105°C`（p4，原文证据） | ✅（该修正属确定性纠错，签核时确认方向） |
| Pins | 8 行模型稿（GND/TRIG/OUT/RESET/CONT/THRES/DISCH/VCC），无 source、无 pin_validation | ⚠️ |
| Evidence | row 116/158 · coord 116/158 · container 0/158 · blocked · partial_pass | ⚠️（风险队列 78 行，7 件中最多） |
| Provenance | 同通用 | ✅ |

**人工裁决项**：
- [ ] Electrical ⚠️43 行 model_unverified：逐行对照 PDF 或退回重抽
- [ ] 引脚 8 行人工对照（NE555 经典脚位，人工核对成本低）

---

## 3. 签核汇总页（CONTENT_APPROVED 由人工填写）

> 规则（Reviewer）：逐件逐字段；PIN 字段未过 `pin_validation=passed` 不得标 verified；
> ❌ 行未经整改或明确豁免不得签；未验证字段继续标未验证。

| 件 | 建议口径 | CONTENT_APPROVED（人工勾选） |
|---|---|---|
| ADS1675REF | 条件签核：先裁 Identity（REF/芯片口径）+ AbsMax ❌7 行 | - [ ] 批准　- [ ] 有条件批准（列明豁免项）　- [ ] 退回 |
| ADS42JB49SEK | 退回倾向：Electrical ❌48 行（43%）超出可豁免范围 | - [ ] 批准　- [ ] 有条件批准　- [ ] 退回（建议） |
| CDC6CE025000ADLET | 条件签核：引脚 4 行人工对照 + ⚠️45 行裁决 | - [ ] 批准　- [ ] 有条件批准　- [ ] 退回 |
| CDC6CE025000ADLFR | 同 ADLET | - [ ] 批准　- [ ] 有条件批准　- [ ] 退回 |
| LM317 | 可签：电气/热阻最干净，条件 = 3 脚口径 + package 字段更正 | - [ ] 批准（建议）　- [ ] 有条件批准　- [ ] 退回 |
| LM358 | 可签：条件 = 8 脚口径 | - [ ] 批准（建议）　- [ ] 有条件批准　- [ ] 退回 |
| NE555 | 条件签核：⚠️43 行电气 + 引脚人工对照 | - [ ] 批准　- [ ] 有条件批准　- [ ] 退回 |

**数据来源**：`data/staging_batch20_v3/parsed/<MPN>.json`（7 件产物原件）、
`data/_delivery_releases/delivery-batch20-eval-V3-CANDIDATE/{manifest.csv, risk_queue.csv, facts_audit.csv}`。
摘要聚合原件：`.sandbox/v3_content_review_summary.json`。
