# 阶段二 多语言回填 · dry-run 摸底 + 写盘报告

> 日期：2026-10-30
> 摸底（**只读**）：
> ```
> python qc/i18n_restore.py --plan-csv data/qc/i18n_restore_plan_20261030.csv \
>   --delivery-dir E:/workspace/delivery-20261026-i18n --parsed-dir data/parsed \
>   --report-csv data/qc/i18n_restore_dryrun_20261030_v4.csv --expect-count 172
> ```
> 写盘（**已执行**）：
> ```
> python qc/i18n_restore.py ... --expect-count 172 --do-write --i-understand
> ```

---

## 0. 结论

| 项 | 数 | 含义 |
|---|---:|---|
| 原始清单 | 235 | 2026-10-29 生成 |
| **可回填** | **172** | 生产文件都在，映射无需改动 |
| ├ 摸底结果 | `PLAN 169` + `SKIP_ALREADY 3` | **`FAIL=0`，退出码 0** |
| ├ **写盘结果** | **`DONE 169`** + `SKIP_ALREADY 3` | 退出码 0，闭环复核 169/169 |
| 剔除 | 63 | 生产里没有落点，单独立册 `i18n_restore_excluded_20261030.csv` |
| 守恒 | 172 + 63 = 235 | 一行没凭空消失 |

**一件改名都不用做。** 63 件里没有任何一件能用现有产物安全接上。

---

## 1. 为什么 63 件救不回来（含对上一版结论的推翻）

### 1.1 被推翻的假设

第一版用「文件名后缀 = `pdf_hash[:8]`」反查，得出「38/63 只是改名」，例如
`ADS1254E` → `ADS1254EVM`。**这个结论是错的。**

实测 `data/parsed`：

| 指标 | 值 |
|---|---:|
| 产物文件 | 8,990 |
| 唯一 `pdf_hash` | 3,428 |
| **一份 PDF 对应多个产物** | **1,809 组** |
| 单组最多 | 55 个（`AM335x` 一族共用一份手册） |

也就是说「同 hash 后缀」是**多对一**，不是一对一。拿它当改名证据，会把 9 个不同订货号
（`F28P650DH6NMRR` / `F28P650SK6PZPR` / …）全部塞进同一个文件 `F28P650DK6NMRR_849b8f00.json`。
这是**假阳性**，而且它会把「一条都救不回来」伪装成「救回 38 条」。

> 附带纠正一个架构判断：系统**不是**「一份 PDF 只留一个产物」。它按订货表里的每个可订购
> MPN 各出一份产物，同族大量共存。丢失的是**特定那几个订货号**，不是被去重合并掉了。

### 1.2 正确判据（内容级标识优先）

| 级 | 判据 | 强度 | 命中 |
|---|---|---|---:|
| A | `metadata.requested_mpn` | 生产时就是按这个料号请求的 | 0 |
| B | `basic_info.mpn` | 文档正文写明的规范料号（改名后 A 会变、B 不变） | 0 |
| C | `pdf_hash` | **仅当该 hash 在产物中唯一**才可用 | 0 |
| D | 多候选 | 同 PDF 有多个产物且无内容级标识 | 33 |
| E | 无目标 | 三种标识全不命中 | 25 |
| F | 撞目标 | 与已存在的产物指向同一目标，让位 | 5 |

A/B 命中为 0 是关键证据：**这 63 个 MPN 在生产里根本没有对应的产物**，
不是「换了名字」，是「不在了」。

### 1.3 63 件的分类

| 类别 | 件数 | 说明 | 处置 |
|---|---:|---|---|
| `D_ambiguous` | 33 | 同族共用一份 PDF，产物里有 8~24 个兄弟，但没有任何内容级标识指明哪个是它 | 阶段三重新解析 / 放弃 |
| `E_absent` | 25 | 生产无产物；`2U3820-50QDBVRG4Q1`、`5962-8670404XA`、`78SR110HC`、`CC3200-LAUNCHXL` 等 | 阶段三重新解析 |
| `F_dup_target` | 5 | 同一 MPN 在清单里有两行，只有一行有产物 | 去重 |

> 注意：`CC3200-LAUNCHXL` 的 PDF 其实在（`data/pdfs/CC3200MODLAUNCHXL__CC3200MOD_UG.pdf`），
> 只是命名与料号不同前缀。所以不能声称「PDF 也没了」，只能说**生产没有落点**。

---

## 2. 172 件能回填，但内容厚度要分开看

| 指标 | 实测 |
|---|---|
| 语言集合 | **172/172 全部 `de,es,ja,ko` 四语齐全** |
| `title` / `description` / `meta` 缺失 | **0** |
| 四语 title+desc+meta 字符数 | min 1565 / 中位 2139 / max 4091 |
| 有 `features` 列表 | 141 件，中位 8 条（1~66） |
| 有 `applications` 列表 | 141 件，中位 5 条（1~21） |
| **完全没有 `features` / `applications` 键** | **31 件**（集中在 F2800xx 家族） |

### 2.1 那 31 件不是「空壳」

上一轮我把它描述成「features 和 applications 同时为空」，**这个说法不准确**。复核结果：

- 这 31 件是**键根本不存在**，不是 `features: []`；
- 而 `OPTIONAL_LIST_KEYS` 按设计就是可选的，现有单测
  `test_write_adds_only_multi_language` 明确断言「仅三字段的交付件应通过」；
- 它们的四语 title/description/meta 齐备（≥1565 字符），是真内容。

所以正确处置是**照常回填 + 报告里标注不完整**，不是跳过。
把它跳过等于为了消除一个报告歧义，把「98% 恢复」变成「0% 恢复」。

---

## 3. 代码改动：非空校验落在哪

改的是 `qc/i18n_restore.py`，但**没有**按「空就 SKIP」的方式加。

| 层 | 条件 | 处置 |
|---|---|---|
| 硬错 | `title`/`description`/`meta` 任一为空 | `raise ValueError` → `FAIL`，整批退出码 1 |
| 硬错 | `features`/`applications` 不是 list | `raise ValueError` → `FAIL` |
| **软警告** | `features`/`applications` **存在但为空列表** | 照常写入，状态记 `PLAN_PARTIAL` / `DONE_PARTIAL`，报告 `warn` 列 |
| 合法 | `features`/`applications` **键不存在** | 无警告，按 `PLAN` / `DONE` |

配套：
- 新增 `read_delivery_ml_checked() -> (ml, warns)`；原 `read_delivery_ml()` 保留为薄包装，
  返回签名不变，**不破坏现有调用方与单测**。
- 报告 CSV 新增 `warn` 列；汇总行额外打印「N 件不完整」，不让"写进去了"冒充"内容齐了"。
- 回归：`tests/test_i18n_restore.py` **9 passed**（改前 6 passed / 3 failed，失败中有一条
  正是「仅三字段应通过」的契约，被这次修正救回）。

> 本轮语料里 `warn` 命中数为 **0** —— 那 31 件走的是「键不存在」的合法路径。
> 这条守卫是为**下一批**准备的：只要上游哪天吐出 `features: []`，它就会亮。

---

## 4. 关于「224 条 ambiguous」—— 这里有个类别错配

### 4.1 它不来自 `i18n_restore.py`

`i18n_restore.py` 全文没有行定位、没有限定词、没有表匹配。它只做一件事：

```python
new = dict(old); new[ML] = ml      # 整体搬一个顶层键
```

所以**回填阶段不可能产生 ambiguous**，也不可能出现「232 件里有多少被 `locate_row` 拦截」
这种数。`224` 这个数字出自 `qc/table_audit.py`（`MATCH_RULE = "locate_row/unique-v1"`），
量的是**电气参数表行匹配**，与多语言回填是两条互不相干的链路。

### 4.2 真实底数（11 件夹具，2026-10-30 实测）

| 项 | 值 |
|---|---:|
| `row_ambiguous_unresolved` | **244**（不是 224，224 是更早版本快照） |
| ├ `ambiguous_collision` | 177（72.5%） |
| └ `ambiguous_tie` | 67（27.5%） |
| 全量 findings | 361 |

按件分布：`ADS7812B/1K` 44、`74LVC1G132DCKTG4` 43、`DAC8555IPWG4` 36、
`CY74FCT245ATSOCT` 27、`ADC3910S065IRSMT` 16、`CDC421106RGER` 16、`BQ24300DSGR` 14、
`BUF634PG4` 13、`5962-9053801PA` 12、`AM26C32IDG4` 12、`CD74FCT244SM96` 11。

### 4.3 两类根因完全不同，别用同一把锤子

**A. 碰撞型（177 条，其中 88 条 = 50% 是「同名多值」）**

典型 `74LVC1G132DCKTG4` p4：JSON 里 20 条全部叫 `VT+ Positive-going input threshold voltage`，
只是值不同（0.79 / 1.16 / 1.11 / 1.56 …），限定条件（`VCC = 1.65 V` 这类）在抽取阶段就丢了，
于是 20 条全部认领同一行，谁都不写。

→ **这才是真正的限定词丢失**。修法：抽取阶段把 condition 带进 key 或独立字段，
匹配时用 condition 在同一参数的多个候选行里选。

**B. 并列型（67 条，其中 28 条 = 42% 候选行是长散文）**

典型 `74LVC1G132DCKTG4` p4：JSON 是 `VOH High-level output voltage`，候选是
`VO Voltage range applied to any output in the high-impedance or power-off state(2)` 与
`VO Voltage range applied to any output in the high or low state(2)(3)`。

这两行是**绝对最大额定值表**，不是电气特性表。`VOH` 和 `VO` 符号前缀相同、参数名前 12 位
不匹配、共同词为 0，得分并列 → tie。**根因是选错了表，不是限定词。**

→ 修法：`_decide_match` 目前「按表顺序取第一张有候选的表」，应改为优先限制在
Electrical Characteristics 表，或对 Absolute Maximum Ratings 表降权/排除。

### 4.4 Top 10 明细

见 `data/qc/ambiguous_top10_20261030.csv`（按认领数降序）：

| MPN | 页 | 原因 | 候选 | 认领 | JSON |
|---|---:|---|---:|---:|---|
| 74LVC1G132DCKTG4 | 4 | collision | 1 | **20** | `VT+ Positive-going input threshold voltage` |
| 74LVC1G132DCKTG4 | 4 | collision | 1 | 20 | 同上（6 条同名不同值） |
| ADS7812B/1K | — | collision | 1 | 12 | 见 CSV |
| DAC8555IPWG4 | — | collision | 1 | 10 | 见 CSV |
| CY74FCT245ATSOCT | — | collision | 1 | 8 | 见 CSV |

---

## 5. 写盘执行与闭环复核（2026-10-30 06:19）

### 5.1 写盘前探测

| 项 | 结果 |
|---|---|
| 备份目录 | `data/parsed_backup_i18n_restore_20261029`（脚本按 **UTC 日期**命名，本地是 30 号、UTC 还是 29 号） |
| 目录已存在 | 否 |
| 父目录可写 | 是 |
| 备份撞名 | **0** 件（169 件逐个 `os.path.exists` 查过） |
| 待写体积 | 2,178 KB；目标盘剩余 84.1 GB |

### 5.2 写盘结果

```
汇总 DONE=169  SKIP_ALREADY=3        退出码 0
```

- `SKIP_ALREADY` 3 件：`ADC08D1500DEV_NOPB`、`COP8-PGMA-44QFP`、`LM358` —— 生产里本来就有 `multi_language`，幂等跳过。
- `DONE` 169 件：`src_sha256` 与 `new_sha256` **全部不同**（0 件是"假写"），`warn` 列命中 **0** 次。
- 语言集合：**172/172 全是 `de,es,ja,ko`**。

### 5.3 闭环复核（不看脚本自述，只看磁盘现状）

| 检查项 | 结果 |
|---|---|
| 备份文件存在 | 169/169 |
| 备份 SHA-256 = 报告 `src_sha256` | 169/169 |
| 现状 SHA-256 = 报告 `new_sha256` | 169/169 |
| 顶层键集合 = 旧键 ∪ {`multi_language`} | 169/169 |
| 旧键值深度相等（无一被改） | 169/169 |
| 四语 `title`/`description`/`meta` 非空 | 169/169 |
| 备份目录文件数 | 169（与 DONE 数一致） |
| **闭环失败** | **0** |

脚本自带 `--verify-only`：`OK=172`，退出码 0。

生产目录多语言覆盖：**有 381 / 无 8609**（总 8990）。本次新增 169，此前已有 212。

### 5.4 内容抽样

| MPN | ja 标题 | 四语 desc 字数 |
|---|---|---|
| `2N7001TQDCKRQ1` | 2N7001T-Q1 SC70 5ピン信号変換器、1.65V～3.6V、AEC-Q100準拠 | 171 / 202 / 425 / 438 |
| `74LVC1G3157DRYRG4` | SN74LVC1G3157DRYRG4 SPDTアナログスイッチ、6ピンSON | 174 / 216 / 439 / 451 |
| `FET430F6137RF900` | TI CC430F6137 MSP430 SoC、サブ1GHz RFトランシーバー搭載 | 258 / 286 / 570 / 616 |

> `FET430F6137RF900` 就是那 31 件「无 features/applications 键」之一 —— 标题/描述/meta
> 四语齐备，只是没有两个可选列表。这印证了 §2.1 的判断：不是空壳。

---

## 6. 阶段二裁决

| 项 | 状态 |
|---|---|
| 回填链路 | 🟢 `FAIL=0`，退出码 0，`DONE 169` |
| 数据源底数 | 🟢 172 可回填 / 63 无落点，守恒 |
| 空壳守卫 | 🟢 硬错拦、软警告记，契约单测 12 passed |
| 写后闭环 | 🟢 169/169 六项全过，0 失败 |
| 63 件 | 🟡 客观缺失，不阻塞本批；进阶段三重新解析 |
| ambiguous | 🔴 属 `table_audit` 独立议题，**不阻塞多语言回填** |

**阶段二收官。**

---

## 7. 下一轮

1. **限定词解析**（真研发项）：只针对 A 类 177 条碰撞。判据：同一参数名在 JSON 里出现 N 次
   且值不同 → 必须带 condition，否则报 unresolved。
2. **表选择**：`_decide_match` 加表类型过滤，先吃掉 B 类 67 条里的 28 条（长散文行）。
3. 63 件进阶段三：`E_absent` 25 件、`D_ambiguous` 33 件需重新解析或确认是否已下架。
4. 31 件 F2800xx 缺 features/applications：属抽取侧，进阶段三专项，不在阶段二补。

---

## 8. 产物清单

| 文件 | 内容 |
|---|---|
| `data/qc/i18n_restore_plan_20261030.csv` | v2 清单 172 行（新增 `remapped_from` / `remap_tier`） |
| `data/qc/i18n_restore_excluded_20261030.csv` | 剔除 63 行，带 `tier` / `candidates` / `reason` |
| `data/qc/i18n_restore_dryrun_20261030_v4.csv` | 写盘前 dry-run 报告（含 `warn` 列） |
| **`data/qc/i18n_restore_write_20261030.csv`** | **写盘报告 172 行，三份 SHA-256 齐全** |
| **`data/parsed_backup_i18n_restore_20261029/`** | **169 份回填前原文件备份（回滚点）** |
| `data/file_remap_20261030.json` | 235 件的逐件映射与判据 |
| `data/qc/table_audit_fix11_20261030.json` | 11 件夹具表格审计全量结果 |
| `data/qc/ambiguous_top10_20261030.csv` | ambiguous Top10 明细 |
| `logs/i18n_restore_dryrun_20261030_v4.log` | dry-run 原始日志 |
| `logs/i18n_restore_write_20261030.log` | 写盘原始日志 |
| `logs/i18n_restore_verify_20261030.log` | `--verify-only` 核验日志（OK=172） |
| `logs/table_audit_fix11_20261030.log` | 审计原始日志 |

临时脚本（可复跑）：`data/_remap_v2.py`、`data/_make_plan_v2.py`、`data/_verify_write.py`。
`data/_remap_files.py`、`data/_remap_t3.py` 是已被推翻的 v1（T1 假阳性），保留仅作痕迹。

### 回滚

```bash
# 逐件恢复 169 份原文件
cp data/parsed_backup_i18n_restore_20261029/*.json data/parsed/
```
备份目录内文件与 `i18n_restore_write_20261030.csv` 的 `src_sha256` 逐件对过，
恢复后可用该列校验回滚是否干净。
