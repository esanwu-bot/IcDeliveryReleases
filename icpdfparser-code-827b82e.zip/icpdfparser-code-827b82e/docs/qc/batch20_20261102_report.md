# batch20 灰度报告（test-20261102-batch20）

> 2026-11-02 · 20 件真实抽样 · V3 代码 + `--normalize`
> 包：`test-20261102-batch20/part-0001-of-0001.zip`
> sha256 `7eea8e6fa4246157f63f94d9df6263d38d8b3557e25e6488c006121d7a09b52c`
> 53,515,080 B / 227 成员 / 20 型号 / 自检 **147 项 0 失败**

## 一、批次口径

抽样脚本 `_batch20_sample.py` 是**确定性**的（同一份库跑两次结果一样），
按产品族配额 + PDF 大小两头交替取，排除评估板件。本次 20 件与 11-01 那次
抽样**完全相同**，因此下面每一列都可以直接对差值。

**关键前提：必须带 `--normalize`。** 不带它，`specs.ac_performance` 不会被
`deterministic_extract.fill_ac_performance()` 填充 —— 该函数只在
`normalize_doc` 里调用。实测同一份数据：不带 `--normalize` 是 802 行、
带上是 998 行，差的 196 行全是 AC 性能容器。这个差异**没有任何告警**，
是本轮最值得记住的坑。

## 二、V2 → V3 前后对比（同一 20 件、同一份 PDF）

| 指标 | 旧 V2 代码 | 新 V3 代码 | 变化 |
| --- | --- | --- | --- |
| `anchor_gate=pass` | **1 / 20** | **3 / 20** | +2 |
| 行指纹复现率 `row/n_rows` | 747 / 998 = **74.8%** | 770 / 998 = **77.2%** | +2.4 pp |
| 强证据率 `(row+para)/denom` | 839 / 989 = **84.8%** | 856 / 989 = **86.6%** | +1.8 pp |
| `weak` 行数 | 150 | 133 | **−17** |
| 不达标行数中位 | 9 | 8 | −1 |
| 「差 ≤3 行」件数 | 5 | 6 | +1 |

分母 `n_rows` 两次都是 998，所以这 2.4 pp 不是口径漂移，是**真提升**。

## 三、三件彻底通过

| 型号 | 行锚定 | 段锚定 | weak |
| --- | --- | --- | --- |
| `ADC12DJ5200SE` | 90/97 | 7/97 | 0 |
| `BQ79616PAPRQ1` | 80/80 | 0/80 | 0 |
| `BQ79614PAPRQ1` | 80/80 | 0/80 | 0 |

`ADC12DJ5200SE` 是这轮最大的收获：V2 时它是 88/97 + 11 条 weak，V3 把
7 条 AC 行按段落指纹重放升到 `paragraph_anchor`，weak 清零。
两颗 BQ7961x 是 80/80 满锚定（纯表格件，最理想的形态）。

## 四、差几行 —— 17 件没过的分布

| 差行数 | 件数 | 型号 |
| --- | --- | --- |
| 1 | 1 | `LM3208TLEV`（0/6 行 + 6/6 段，只差 1 行） |
| 2 | 1 | `BQ48SH-28X6NSH` |
| 3 | 1 | `ADC12QJ1600ALREP` |
| 4 | 1 | `ADC12QJ1600-SP` |
| 6 | 3 | `BQ2201PN` / `LM358` / `DS38EP100SD/NOPB` |
| 8 | 1 | `DS14C89AM` |
| 9 | 3 | `74FCT16244CTPVCTG4` / `DAC7541AJUG4` / `LM3676SD-ADJEV` |
| 11 | 1 | `DAC5681ZIRGCR` |
| 13 | 1 | `LM3677TL-1.8EV` |
| 16 | 2 | `ADS1286U` / `CD4010BQDRQ1` |
| 19 | 1 | `ADS7815UE4` |
| 28 | 1 | `CD4021BQDRQ1` |

**6 件只差 ≤3 行** —— 这是下一批最值得先啃的：它们不是「锚定率低」，
是差一两行就能进 pass。`LM3208TLEV` 只有 6 行电气参数，差 1 行。

## 五、真正卡住量产的，不是锚定率

`manifest.csv` 的 `gate` 列（发布门禁）和 `anchor_gate`（锚定门禁）是**两件事**：

| gate | 件数 | 原因 |
| --- | --- | --- |
| `BLOCKED` | 4 | `pin_validation=unresolved` |
| `UNRESOLVED` | 16 | `specs.thermal 为空; specs.esd 为空` |

**20 件里 16 件的 `specs.thermal` 与 `specs.esd` 是空的**，
`stage_release` 逐件输出也是 `thermal=0 esd=0`。

这不是「这几颗芯片没有热阻/ESD 参数」——真实 datasheet 基本都有。
根因是**解析产物的年份**：`data/parsed/*.json` 这批是 2026-10-23 生成的，
而 thermal / esd 两个容器 2026-10-31 才加进 schema。同一个型号一比就清楚：

| 产物 | 生成时间 | thermal | esd |
| --- | --- | --- | --- |
| `data/parsed/ADC12DJ5200SEAAV_398fd1f1.json` | 2026-10-23 | **0** | **0** |
| `data/staging_20261102_v3/parsed/ADC12DJ5200SE.json` | 2026-11-02（重解析） | **5** | **2** |

规则加了，老 JSON 不会自己长出这两个键。`normalize_doc` 的步骤表里
也没有 `fill_thermal` / `fill_esd` —— 它们只能由解析期模型产出，
`--normalize` 补不出来。

对 10 万件大单的含义：**先把存量重解析一遍，比继续调锚定率收益大得多。**
锚定率从 74.8% 磨到 77.2%（+2.4 pp 花了整个 V3 周期），而 thermal/esd
是 0 → 有 的跳变，它直接决定 `gate` 能不能离开 `UNRESOLVED`。

## 六、两个可复现的坑（已修，见 commit `e34195a`）

1. **`--mpns` 两套键口径。** `stage_release._index()` 按 `basic_info.mpn`
   建键，`fact_acceptance` 按文件名主干建键。`DS38EP100SD/NOPB` 的斜杠
   让两者对不上，审计阶段**静默跳过**整件 —— 20 件批次出 19 条结论，
   报告上看不出少了谁。已加告警。
2. **隔离不可逆。** `quarantine()` 只往外搬、不往回搬，而平反判据要的坐标
   从来没被传进来（`fact_status_sync` 调的是 `quarantine(doc)`）。已改成
   可逆 + 传 evidence。

## 七、口径声明

- 本批次**不是**交付包，只是内部灰度。不推 GitHub，不占用 `delivery-` 序列
  （AGENT.md §16.1a）。
- `anchor_gate` 是**零缺陷**闸门，一行不达标就 `blocked`，所以「通过率」
  天然极低；可操作口径是上面的「差几行」分布，不是通过率本身。
- `gate=UNRESOLVED` **不是**质量结论，只表示「有必填容器是空的」。
