# Phase 1.7 三件受控灰度 · 总结与裁决建议

**日期**：2026-11-03 · **代码**：`origin/main@d6fc276` · **镜像**：`icpdf/app:latest`
**授权**：Phase 1.6.1 外审裁决「Phase 1.7 三件受控灰度获批」
**冻结单**：`docs/qc/phase17-preflight.md`（三件的 MPN / URL / SHA256 / 预期在启动前已固定）

## 1. 执行结果

| # | 类型 | MPN | SHA256 实收 | 终态 | start/download | dedup | already_running | parse_count | 判定 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 芯片 | LM317 | `1646fb2e…` ✅ | `done` / 100 | 1 / 1 | 0 | 0 | 1 | PIPELINE_PASS · **CONTENT_NOT_APPROVED** |
| 2 | 板卡 | ADS8568EVM-PDK | `79c02991…` ✅ | `done` / 100 | 1 / 1 | 0 | 0 | 1 | PIPELINE_PASS · SCOPE_PARTIAL |
| 3 | 异常件 | DAC8568EVM | `a7e7253d…` ✅ | `skipped` / 100 | 1 / 1 | 0 | 0 | 0 | **PASS** |

- 三件的 PDF SHA256 与冻结值**逐字节一致**（下载后复核，未发生源文档漂移）。
- 三件各自独立数据根、独立 `flushdb`、独立五个 worker（`-c 1`），跑完即删、日志保留。
- 灰度为**单次自动投递**（`dispatch.submit("fetch_item", …)`）；未使用 `POST /reparse`
  或任何 `force=false` 入口 —— 该入口在投递前无条件写 `status='queued'`，已明确排除在灰度路径外。

## 2. 停止线核对（7 条全部未触发）

| 停止条件 | 结果 |
|---|---|
| 已完成任务 `done` 被降级 | 未发生（三件终态分别为 done/done/skipped）|
| 非预期重复下载 | 未发生（每件 `download=1`，`doc_source` 各 1 行）|
| 缓存命中导致 `parse_count` 增加 | 未发生（1 / 1 / 0）|
| `already_running` 无可追踪原任务 | 未发生（事件数 0）|
| 无法解释的永久中间态 | 未发生（队列深度 0，阶段账 attempts 全为 1）|
| 板卡/芯片身份错误归属 | 未发生（chip / evaluation_board，`scope=onboard_device`）|
| 正式数据/页面/交付包非预期变化 | 未发生（见 §4）|

## 3. 阻断项（V2 提升前必须处置）

### D1（P0）V2 LLM 阶段漏掉确定性抽取
`app/services/pipeline.py::parse_pdf` 没有调用 `apply_deterministic`；
legacy 的 `parse_datasheets.py` 在 1572 / 1605 行调用。实测后果（样本 1）：

- `specs.thermal` **36 行**（含 `RθJC(bot) NA` / `—` 两行），冻结预期 34 行；
- `pin_configuration` 4 条，第 4 条重复 `OUTPUT`，冻结预期 3 条；
- audit 14 findings（`row_ambiguous_unresolved` 8 等），而确定性结果本可消解其中大部分。

这不是模型随机波动：同一份 PDF 在 legacy 路径（`parse_one`）下产出 34 行 / 3 引脚。

### D2（P1）V2 不落 `llm_usage`
`_log_calls` 只在 `llm_stage`（legacy 全链路）里调用；V2 的 `stage_llm` 直接调 `parse_pdf`，
`llm_usage` 表为空 —— 「灰度必须记录 LLM Token」在 V2 下不可观测。

### D3（P1）板卡分支未搬移 `thermal` / `esd`
样本 2：`electrical=0`、`absolute_max=0`、`pin_scope=board` 都正确，
但主容器仍留 `thermal=11`、`esd=2`（芯片级数值），仅靠 `specs.scope=onboard_device` 区分。
需裁决：搬进 `onboard_device_specs`，或在页面明确标注为主容器芯片参数。

## 4. 正式数据零副作用（构造性隔离 + 事后核验）

```
灰度前：parsed files=13539  bytes=281419444  digest=acf8d167bb360afc933f0468840c08af2ec4fe410a93069c89deb808c9a1a6c4
灰度后：parsed files=13539  bytes=281419444  digest=acf8d167bb360afc933f0468840c08af2ec4fe410a93069c89deb808c9a1a6c4
生产库：sha256=d93d65851f… size=95834112  前后一致
生产容器：icpdf-server/render/llm/fetch/redis  RestartCount 全为 0，StartedAt 未变
```

灰度写入只在 `/tmp/p17/data_s{1,2,3}` 与 Redis DB8（残留 5 个键，未清理，保留待查）。

## 5. 裁决建议

1. **不批准 V2 提升/全面启用**：D1 使 V2 与 legacy 产出不同的交付 JSON，且更差。
2. 下一轮只做三件事并附红先测试：
   - D1：`parse_pdf` 接入 `apply_deterministic`（与 `parse_one` 同一实现，不得复制）；
   - D2：`stage_llm` 落 `llm_usage`（复用 `_log_calls`，不新写一份）；
   - D3：板卡 `thermal`/`esd` 归属裁决（建议与 electrical 同口径搬移）。
3. 修复后用**同一三件冻结样本**复跑（URL/SHA 不变），再按本报告口径重判。
4. 三份样本报告：`phase17-sample-1-chip.md` / `-2-board.md` / `-3-abnormal.md`。

> `PIPELINE_PASS`（链路跑通） ≠ `CONTENT_APPROVED`（内容符合预期） ≠ `RELEASE_APPROVED`（可发布）。
> 本轮三件只能说明：**Phase 1.6.1 的去重/原子领取在真实五段链路上成立，生产零污染**；
> 不能说明 V2 的内容质量与 legacy 等价。

## 6. 证据位置

```
/tmp/p17/s{1,2,3}.json              # 每件的 probe report（状态/阶段账/事件/用量/产物/JSON 摘要）
/tmp/p17/log_s{1,2,3}-*.log         # 15 个 worker 日志
/tmp/p17/data_s{1,2,3}/             # 隔离数据根（pdfs / slices / parsed / txt / symbols / workbench.sqlite3）
/tmp/p17/p17.sh  /tmp/p17/probe/p17.py  /tmp/p17/run_s{1,2,3}.sh
/tmp/p17/code/                      # git archive origin/main 的只读语义副本（实际可写，供 config mkdir）
```
