# 74 功能表 · v1.0.3 候选（补 11）— 未签核

- 候选文件：`qc/74_function_codes.v1.0.3.candidate.json`
- 版本：`1.0.3` ｜ 状态：**PENDING_REVIEW**（`usable_for_p0 = False`）
- 内容哈希：`sha256:81e4191123cf080a2dd623d0a29482671dd5e6ea8fb06b3c22bd15ad6a62b098`
- 前驱：`1.0.2`（`SIGNED`，
  `sha256:c575a174c0127135be33c3b1f1ec88e5f289cf4742938dacebc550f51f91878f`）—— **已签核版本未被修改**
- 生成时间：2026-10-29T14:16:31+08:00

## 1. 新增证据（来源可追溯）

| 项 | 值 |
|---|---|
| 官方 PDF URL | https://www.ti.com/lit/ds/symlink/sn74lvc1g11.pdf |
| 取回时间 | 2026-10-29T14:13:27+08:00 |
| 文件 | `data/pdfs/SN74LVC1G11__sn74lvc1g11.pdf`（2242255 字节，37 页） |
| SHA-256 | `ffd953703273b43844eae23cfbf31cfc801a3b9443f2c863d49dde62f5a9232b` |
| 文档版本 | `SCES487I – SEPTEMBER 2003 – REVISED NOVEMBER 2024` |
| 证据页 / 原文 | p.1「`SN74LVC1G11 Single 3-Input Positive-AND Gate`」 |
| 支持原句（非必填证据） | p.1「The SN74LVC1G11 performs the Boolean function Y = A • B • C or Y = A + B + C in positive logic.」 |

## 2. 变更内容（仅一处新增）

| 项 | v1.0.2（已签核） | v1.0.3（候选） |
|---|---|---|
| 功能码 11 | 在 `unresolved`（缺证） | `function=AND / inputs=3 / schmitt=false / family=LVC`，`EVIDENCE_BACKED` |
| `unresolved` | `["11"]` | `[]` |
| 条目数 | 23 + 2 族覆盖 | 24 + 2 族覆盖 |

## 3. 校验结果（可复跑）

```bash
python qc/function_table.py validate --table qc/74_function_codes.v1.0.3.candidate.json
python qc/function_table.py verify-evidence --table qc/74_function_codes.v1.0.3.candidate.json
```

- `validate` → **OK**
- `verify-evidence` → **total=0 / error=0 / warn=0**
- 未签核状态下 `judge("132","11")` → **`NO_EVIDENCE`**（`table_unusable:table_not_signed`），
  即**本候选不会改变任何现有 P0 判定**。

## 4. 签核后的预期（仅用于评审判断，未生效）

若 `wuxiaoxian` 复核并签核 v1.0.3，则按表判定：
`132 vs 11` → **`INCOMPATIBLE`**（`function: NAND≠AND`、`inputs: 2≠3`、`schmitt: True≠False`）。
这会把 74LVC1G132 的 6 条 `74LVC1G11` 候选从 P1 提升到 P0（仍需 review 规则接入后才实际生效）。

## 5. 待办（需 Reviewer 动作）

1. 复核 `docs/qc/74_function_table_v1.0.3_review_packet.md`；
2. 通过后签核（绑定下列哈希）：

```bash
python qc/function_table.py sign --table qc/74_function_codes.v1.0.3.candidate.json \
  --reviewer wuxiaoxian --at <ISO时间> \
  --hash sha256:81e4191123cf080a2dd623d0a29482671dd5e6ea8fb06b3c22bd15ad6a62b098 --confirm
```

3. 签核后再决定是否把候选替换为主表（`qc/74_function_codes.json`），并进入阶段 ②。

## 6. 边界

- 本轮**未签核**、未替换主表、未接 review 规则、未重生成交付包、未写生产；
- 官方 PDF 仅用于功能表证据，不再分发；
- 若后续 PDF 版本更新（`SCES487I` → 更高修订），需新版本重新复核。


## 7. 签核结果（追加记录，来自实际命令执行）

- 状态：`SIGNED`
- 签核人：`wuxiaoxian`（`reviewer-in-person`）
- 签核时间：2026-10-29T14:25:14+08:00
- 绑定版本：`1.0.3`
- 内容哈希：`sha256:81e4191123cf080a2dd623d0a29482671dd5e6ea8fb06b3c22bd15ad6a62b098`
- 复核时证据回读：error=0 / warn=0

签核后 `is_usable_for_p0 = True`。按阶段门禁，下一步才是「候选提升为主表 → 进入阶段 ②」；该步尚未执行。
