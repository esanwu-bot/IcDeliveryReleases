# 符号页「工程模型边界」改造 · 五件沙箱重渲染 diff

> 结论：5/5 件**符号 SVG 主体逐字节零漂移**；可见文本变化只有「旧两段重复文案 → 状态派生短标签」与新增小节；门禁 A1–A5 在 5/5 件上零 findings。

基线 = `git show HEAD:symbol_svg.py`（harness 运行时取，不落仓），候选 = 当前工作区。两侧同一份 JSON、同一 `pkg_dir=data/pkgs`；未写 `data/symbols`、未碰任何交付目录。

| 型号 | 数据源 | 字节(前→后) | 符号SVG | 边界小节=render_notes | 可见文本删除 | 可见文本新增 | findings |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ADC12DJ5200SE | `data\staging_20261030_fixed\parsed\ADC12DJ5200SE.json` | 58818→59292 | 逐字节一致 | 逐字一致 | 封装 · 几何与视角未核验，不生成工程模型<br>3D 模型 · 几何与视角未核验，不生成工程模型 | 封装 · 轮廓未绘制<br>3D 模型 · 未生成 | 0 |
| BOOST-DRV8711 | `data\staging_20261030_fixed\parsed\BOOST-DRV8711.json` | 995→1446 | 逐字节一致 | 逐字一致 | — | — | 0 |
| ADS8568EVM-PDK | `data\staging_20261030_fixed\parsed\ADS8568EVM-PDK.json` | 1037→1488 | 逐字节一致 | 逐字一致 | — | — | 0 |
| BUF634PG4 | `data\parsed\BUF634PG4_176bed1f.json` | 4918→5444 | 逐字节一致 | 逐字一致 | — | — | 0 |
| DAC8555IPWG4 | `data\parsed\DAC8555IPWG4_f63797db.json` | 8340→8868 | 逐字节一致 | 逐字一致 | — | — | 0 |

## 逐件状态与边界小节

### ADC12DJ5200SE

- state：symbol=`pass` / outline=`not_checked` / 3d=`not_generated`
- 副标题：前 原理图符号 · 由 pin_configuration 生成；封装 · 几何与视角未核验，不生成工程模型；3D 模型 · 几何与视角未核验，不生成工程模型
- 副标题：后 原理图符号 · 由 pin_configuration 生成；封装 · 轮廓未绘制；3D 模型 · 未生成
- 边界小节：封装轮廓未绘制：该封装在库中无签核共享模板。
- 边界小节：3D 模型与球阵几何未生成：无可信来源（机械 CAD（STEP/IBIS）或原厂球阵图），不猜测。

### BOOST-DRV8711

- state：symbol=`not_checked` / outline=`not_applicable` / 3d=`not_applicable`
- 副标题：前 封装说明
- 副标题：后 封装说明
- 边界小节：板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。

### ADS8568EVM-PDK

- state：symbol=`not_checked` / outline=`not_applicable` / 3d=`not_applicable`
- 副标题：前 封装说明
- 副标题：后 封装说明
- 边界小节：板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。

### BUF634PG4

- state：symbol=`not_checked` / outline=`template` / 3d=`not_generated`
- 副标题：前 原理图符号 · 由 pin_configuration 生成；封装 · 按封装类型 + 脚数生成；3D 模型 · 按封装类型程序化绘制
- 副标题：后 原理图符号 · 由 pin_configuration 生成；封装 · 按封装类型 + 脚数生成；3D 模型 · 按封装类型程序化绘制
- 边界小节：封装轮廓按共享模板 SOIC-8 绘制（内容哈希 fe2ee720）；模板为共享轮廓，不含球阵坐标。
- 边界小节：3D 模型与球阵几何未生成：无可信来源（机械 CAD（STEP/IBIS）或原厂球阵图），不猜测。

### DAC8555IPWG4

- state：symbol=`not_checked` / outline=`template` / 3d=`not_generated`
- 副标题：前 原理图符号 · 由 pin_configuration 生成；封装 · 按封装类型 + 脚数生成；3D 模型 · 按封装类型程序化绘制
- 副标题：后 原理图符号 · 由 pin_configuration 生成；封装 · 按封装类型 + 脚数生成；3D 模型 · 按封装类型程序化绘制
- 边界小节：封装轮廓按共享模板 TSSOP-16 绘制（内容哈希 35a39ed3）；模板为共享轮廓，不含球阵坐标。
- 边界小节：3D 模型与球阵几何未生成：无可信来源（机械 CAD（STEP/IBIS）或原厂球阵图），不猜测。

## 变化性质（逐条）

1. `<html … data-em-page="symbols">`：页面标记，机器属性、不可见；A1–A5 只对带标记的新产物断言。
2. `<section data-em-boundary="engineering-model">`：新增小节，文本逐字等于 `render_notes(state)`。
3. ADC12DJ5200SE 两张卡副标题：旧重复文案 → `轮廓未绘制` / `未生成`（§3 要求合并）。
4. 板卡两件（BOOST-DRV8711 / ADS8568EVM-PDK）：只多出 not_applicable 一组小节文案，页面其余不变。
5. 模板臂两件（BUF634PG4 / DAC8555IPWG4）：副标题保持原样，只多出模板哈希与「3D 未生成」两条说明。

## 复现

```bash
# 基线必须是**改造之前**的提交：改动一旦进 HEAD，默认 --base HEAD 就等于工作区，
# 脚本会检测到「无差异」直接判红（退出码 2），避免自己跟自己比的假绿。
python qc/symbols_render_diff.py --base b623249 --json /tmp/sym_diff.json   # 退出码 0 = 5/5 通过
```

逐件 before/after HTML 落在 `.sandbox/symbols_diff/{mpn}/`（不入库）。
