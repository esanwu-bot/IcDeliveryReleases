# ADS8568EVM-PDK 原厂板卡 User Guide 专项诊断（2026-11-02）

**一句话结论**：有证据。TI 官网工具页把 **SBAU193E《ADS8568EVM-PDK Evaluation Module》**
归类为 **EVM User's guide**（30 页，2021-05 修订）；用它解析可以把该件的身份从
`IDENTITY_REVIEW` 纠正为 `BOARD_CONFIRMED` / `document_scope=board_user_guide` /
`specs.scope=board`。但这份 UG **没有电气特性表**，芯片参数（SNR/THD/绝对最大值/温区）
仍只能来自 SBAS543；本目录的探针解析过 `fact_acceptance` 为 `fail` /
`anchor_gate=blocked`，**不能直接当成交付 JSON 使用**。

## 1. 原厂证据（直接证据）

TI 工具页 `https://www.ti.com/tool/ADS8568EVM-PDK`（2026-11-02 抓取，HTTP 200）
的 Documentation 表里，原文是：

```html
doc-type="EVM User&#39;s guide"
href="https://www.ti.com/lit/pdf/SBAU193"
data-navtitle="EVM User&#39;s guide|Featured|SBAU193E"
>ADS8568EVM-PDK Evaluation Module (Rev. E)</a>
```

即 TI 自己把该文档标成 **EVM User's guide**，不是芯片 datasheet。

| 项 | 实测值 |
| --- | --- |
| 文档号 | SBAU193，Rev. E（SBAU193E） |
| 标题 | ADS8568EVM-PDK Evaluation Module (Rev. E) |
| 文档类型（PDF 元数据 Subject） | User's Guide |
| 页数 | 30 |
| 修订 | JUNE 2011 – REVISED MAY 2021 |
| 下载落点 | `https://www.ti.com/lit/ug/sbau193e/sbau193e.pdf` |
| PDF SHA-256 | `4a35747ce9b9dd8369dd030815df9082949128531ff9187cb42bb7a7780da21a` |
| 首页原文 | `User's Guide` / `ADS8568EVM-PDK Evaluation Module` / `This user's guide describes the operation and use of the ADS8568 evaluation module (EVM).` |

首页标题把请求号 `ADS8568EVM-PDK` 绑定在该 UG 上；`qc.identity_scope._document_evidence()`
判定结果为 `board_user_guide`，标题行是 `User’s Guide`，excerpt 从 `--- Page 1 ---`
起、命中 `ADS8568EVM-PDK Evaluation Module`。

## 2. 探针解析与身份纠正

用生产链路 `app.services.pipeline.parse_pdf`（qwen-flash 单次，32.8 s）解析这份 UG，
再跑 `qc.normalize_doc.normalize`。产物见
[`ADS8568EVM-PDK_SBAU193E.probe.json`](ADS8568EVM-PDK_SBAU193E.probe.json)。

| 字段 | V3 交付 JSON（源 = SBAS543C 芯片手册） | 本次探针（源 = SBAU193E 板卡 UG） |
| --- | --- | --- |
| 源 PDF SHA-256 | `79c02991…` | `4a35747c…` |
| `basic_info.doc_type` | `datasheet` | `user_guide` |
| `basic_info.doc_revision` | SBAS543C（2016-02） | SBAU193E（2021-05） |
| `basic_info.document_scope` | `onboard_device_datasheet` | `board_user_guide` |
| `basic_info.identity` / `identity_state` | `evaluation_board` / `IDENTITY_REVIEW` | `evaluation_board` / `BOARD_CONFIRMED` |
| `specs.scope` | `onboard_device` | `board` |
| `subject_match`（`delivery_bundle._subject_fields`） | `false`（document_subject=ADS8568） | `true`（document_subject=ADS8568EVM-PDK） |
| 引脚 | 48 球/脚按板卡页规则丢弃 | 48 条按板卡页规则丢弃，`pin_scope=board` |

身份纠正是由**文档证据**驱动的，不是靠料号后缀猜的：`identity_evidence` 仍保留
`TI_BOARD_SUFFIX_EVM` 规则，但 `document_scope=board_user_guide` 来自首页 UG 标题，
`_document_evidence()` 的 excerpt 已写进 JSON 的 `basic_info.document_evidence`。

## 3. 数据质量实测：身份可证，参数不可用

### 3.1 UG 本身没有电气特性表

对 SBAU193E 全文（30 页，pymupdf 文本层）逐项检索：

| 检索词 | 命中数 | 说明 |
| --- | --- | --- |
| `Electrical Characteristics` | 0 | 无电气特性章节 |
| `Absolute Maximum` | 0 | 无绝对最大值章节 |
| `Operating Temperature` / `Storage Temperature` | 0 / 0 | 无整板温区表 |
| `SNR` / `THD` / `PSRR` | 1 / 1 / 0 | `SNR`/`THD` 只在 p17 正文顺带提一句，无论文表；`PSRR` 无 |
| `100 kSPS` / `510` / `94 dB` / `-90` | 0 / 0 / 0 / 0 | 解析出的这些值不在 UG 里 |
| `48-VFQFN` / `7.0mm` | 0 / 0 | 解析出的封装/尺寸不在 UG 里 |

UG 能提供的板级事实只有：p9 电源（AVDD 5 V、DVDD 3.3 V、HVDD 15 V、HVSS −15 V，
高压由 J9 外接 ±15 V）、p4 板卡特性与连接器（8 通道、SMA/排针、60 pin J10、USB 供电、
内外参考可选、EEPROM）、p7 接口（SPI mode 2、SCLK 最高 45 MHz）、p20–30 BOM/布局/原理图。

### 3.2 探针 JSON 过事实闸门：fail

对探针 JSON 跑 `qc.fact_acceptance.py::audit_one`（报告见
[`facts_audit_probe.json`](facts_audit_probe.json)），实测：

- `n_rows=19`，`verdict=fail`，`anchor_gate=blocked`
- `verified_row=0`、`verified_paragraph=2`、`weak=16`、`no_value=1`（分母 18）
- `not_found=4`：`DVDD 绝对最大值 3.6 V`、`−65~150 °C`（operating/storage 两条）、
  `ESD HBM 2000 V` —— 这 4 个值在 UG 原文里找不到，属模型带入的芯片知识。
- `100 kSPS`、`48-VFQFN`、`-40~85 °C` 同样不在 UG 原文；`-40`/`125` 只在 p20–21
  BOM 元件描述里出现，不是整板温区。
- 探针 JSON 里还出现 `temperature.operating="-40°C°C to 85°C°C"` 的双单位瑕疵
  （`normalize_temperature` 对已带单位的字符串再次追加单位），仅记录为观察到的缺陷，
  本次未改代码。

结论：**UG 是身份/文档证据的充分来源；不是电气参数来源。** 芯片参数仍应来自
SBAS543（或该 UG 明确引用的 Related Documents），不能把 UG 解析出的电气/绝对最大值
直接写进正式容器。

## 4. 复现方式

1. 取 PDF：`curl -L -o SBAU193.pdf https://www.ti.com/lit/pdf/SBAU193`
   → 落到 `.../lit/ug/sbau193e/sbau193e.pdf`，校验 SHA-256 同上。
2. 身份证据：`qc.identity_scope._document_evidence("ADS8568EVM-PDK", text, "ADS8568")`
   应为 `board_user_guide`；`parse_datasheets.is_datasheet(text)` 为 `False`
   （所以未合入 issue #7 门禁的树会把它当 User Guide 跳过）。
3. 解析：确认上面的 UG 证据后，临时把 `parse_datasheets.is_datasheet` 置为真，
   调 `app.services.pipeline.parse_pdf(pdf, "ADS8568EVM-PDK", "https://www.ti.com/lit/pdf/SBAU193")`，
   再跑 `qc.normalize_doc.normalize(doc, pdf)`。
4. 事实闸门：`qc.fact_acceptance.audit_one("ADS8568EVM-PDK", doc, pdf)`。

本诊断脚本是临时件（未入库，按 AGENT §3.2）；本目录只保留产物与实测口径。

## 5. 边界

- 没有跑全量、没有大面积抓 UG：只取 SBAU193E 这一份。
- 没有出新包、没有写生产 `data/parsed`、没有写库。
- 没有改仓库代码；issue #7 的板卡 UG 门禁按用户 2026-11-01 23:48 的要求已废弃，
  本诊断不重新引入。
- 若要正式改该件，仍需决定“UG 作为 document + SBAS543 作为板载器件数据”的双源契约
  （以及行级归属/事实闸门）；否则只能转人工 `IDENTITY_REVIEW`。本目录不替这个决定。
