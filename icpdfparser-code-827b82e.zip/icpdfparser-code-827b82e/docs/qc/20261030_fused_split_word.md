# `fused_cols` 漏判「被劈开的角色词」——修复与验证（2026-10-30）

> 一句话：`find_tables` 会把表头的一个词按列边界劈成两半（`MAX` → `'MA'` + `'X'`），
> 旧判据只认完整词，于是整列角色认不出、**MAX 列被静默丢弃**。
> 修复后 50 件灰度写盘 48 → 44，减少的 4 条**全部是丢列的残缺写盘**，无一条新增。

---

## 1. 问题：不是"值错了"，是"一整列没了"

Review 曾指出 ADC3910 的 `Add. Latency` 被 A16 以 `SPANS_MULTIPLE_ROLES` 拦下。
顺着那条线索查几何，发现更根本的东西 —— 表头本身是残缺的。

`DRV81620-Q1EVM` p10 t0 实测：

```
header = ['PARAMETER', '', 'TESTCONDITIONS', 'MIN', 'TYP', 'MA', 'X UNIT']
role_map = {2: 'COND', 3: 'MIN', 4: 'TYP', 6: 'UNIT'}      ← index 5 ('MA') 无人认领
row 11 = ['R DS(ON)', 'ONresistance', 'T J = 25 °C', '0.4', '0.7', '0.95', '5 Ω 4']
```

PDF 原表是 `| PARAMETER | TESTCONDITIONS | MIN  TYP  MAX | UNIT |`，
但 `MAX` 一词压在列边界上，被劈成 `'MA'` 落在 index 5、`'X'` 落在 index 6。
`role_map` 用 `\bmax\b` 匹配，`'ma'` 命不中 → **index 5 不是数值列**。

后果：

| 参数 | 行内真实值 | v2 写盘 | 丢了什么 |
|---|---|---|---|
| `RDS(ON)` p10/r11 | 0.4 / 0.7 / **0.95** | `MIN 0.4, TYP 0.7` | MAX **0.95** |
| `VM_UVLO falling` p12/r2 | 2.64 / 2.73 / **2.82** | `MIN 2.64, TYP 2.73` | MAX **2.82** |
| `TOTW` p12/r20 | 120 / 140 / **160** | `MIN 120, TYP 140` | MAX **160**（`'16'` + `'0'` 被劈到两处） |
| `TTSD` p12/r22 | 150 / 175 / **200** | `MIN 150, TYP 175` | MAX **200**（同上） |

**A17 抓不到这类**：A17 检查的是「本条 value 在不在即将写入的 MIN/TYP/MAX 三列里」，
而这 4 条的 value 确实在写进去的那两列里 —— 缺的是第三列，不是值放错位置。

---

## 2. 判据：跨列拼词

新增 `_roles_split_across(header, i)`：看 `header[i]` 与 `header[i+1]` 之间是不是劈开了一个角色词。

```
a = 只留字母(header[i])       b = 只留字母(header[i+1])
对每个角色词 w（minimum/typical/maximum/min/typ/max）：
    若 w 完整出现在 a 或 b 中 → 跳过（完整词归原判据管）
    若 a 的**后缀** == w 的前 k 个字母，且 b 的**前缀** == w 的余下部分 → 判 {i, i+1} 融合
```

三个关键设计：

1. **两侧都标**。劈在边界上的词，两侧列都不可分；只标一半会让另一半被当普通列。
2. **完整词优先跳过**。否则 `UNIT` + `MIN` 这种正常相邻列会因 `'unitmin'` 里能拼出 `'min'` 而误伤 —— 这是最容易炸的地方。
3. **只在拼不出完整词时才拼**。`MIN` + `TYP` 各自完整，永不拼接。

`fused_cols` 现在是两条判据的并集：

```python
out = set()
for i, h in enumerate(header):          # 判据一：一列装多角色（DAC8555 形态）
    if sum(1 for r in _FUSED_ROLES if _ROLE_RX[r].search(h.lower())) > 1:
        out.add(i)
for i in range(len(header) - 1):        # 判据二：一个词劈在列边界（DRV81620 形态）
    out |= _roles_split_across(header, i)
```

处置完全一样：命中即整表 abstain，交人工。

---

## 3. 红先（§6.5）

`tests/test_table_fused_split_word.py`，7 条。修复前实测 **3 failed / 4 passed**：

```
FAILED test_split_role_word_is_fused
FAILED test_split_role_word_covers_both_columns
FAILED test_typ_then_ical_not_confused_with_max
```

通过的 4 条是护栏（正常表头/完整融合词/`UNIT`+`MIN` 相邻），它们必须在修复前后**都**绿 ——
否则就是"改绿了目标用例、顺手炸了别的"。

`test_normal_header_not_fused` 用的是全项目夹具的标准表头
`['PARAMETER','TESTCONDITIONS','MIN','TYP','MAX','UNIT']`。
这条一旦红，会让所有写盘用例跟着红，所以它同时是回归探针。

---

## 4. 影响面：精准到只动一处

### 4.1 12 件夹具（隔离验证）

| 指标 | 修复前 | 修复后 |
|---|---|---|
| 写 columns | 21 | **21**（不变） |
| `cell_unparsable` | 9 | 23 |
| `value_unsupported` | 13 | 9 |

ADC3910 单件：`cell_unparsable` 0 → 14，且 14 条**全部**来自同一张 Timing 表
（`Aperture Delay` / `Aperture Jitter` / `Signal Acquisition Period` / `Add. Latency` ×4 …），
证据统一为 `FUSED_COLUMN`，**无一条误伤别的表**。

### 4.2 50 件灰度（`grey_write50_v3` vs `grey_write50_v2`）

| 指标 | v2 | v3 | Δ |
|---|---|---|---|
| 写 `columns` | 48 | **44** | **-4** |
| 乱码 condition 被拦 | 7 | 6 | -1 |
| `patched` | 246 | 232 | -14 |
| `value_unsupported_unresolved` | 40 | 26 | -14 |
| `cell_unparsable_unresolved` | 24 | **91** | +67 |
| └ 其中融合列 | 19 | **86** | +67 |
| `row_ambiguous_unresolved` | 1099 | 1099 | 0 |
| `qualifier_loss` | 48 | 44 | -4 |

**写盘逐条 diff：消失 4 条、新增 0 条**，且消失的 4 条正是 §1 表里那四条。
其余 46 件写盘数量一条未变。

`qualifier_loss` 也同步 -4 —— 说明这 4 条原本是走 **D1b（限定语丢失）** 写出去的，
不是 D1d。记在这里，免得下次又归错规则。

### 4.3 为什么 44 比 48 更诚实

少掉的 4 条不是"能力退化"，是**不再写残缺列**：

- v2 写 `MIN 120, TYP 140`，读者会以为 TOTW 的规格是 120~140 ℃；
  实际规格上限是 **160 ℃**（PDF 原文），写成 140 会让下游把器件判得更宽松
- 这类错误比"不写"危险得多：字段齐全、有页码、有 MIN 列，看起来完全正确

按 §11.10 的口径，这是**用 +4 条人工复核换掉 4 条高危错值**，方向正确。

---

## 5. 遗留

1. **`X UNIT` 列本身也脏**：`DRV81620` p10/r11 的 `'5 Ω 4'`、p12/r20 的 `'0 16 °C'`
   —— 单位格里混进了数字。这条判据没管它，因为整表已 abstain；但若将来要救这类表
   （而不是永久 abstain），需要先解"单位格混数字"。
2. **A13 切分对它无效**：劈开的词，`split_fused_rows` 需要该列自身有数据才能聚出 k 个 x 簇，
   而这类的数据格整体落在前一列（`'0.95'` 在 index 5，但被 A16 视作跨列）。
   切分失败的默认行为是保持原样 → abstain，这一点已验证不会误写。
3. **`fused_cols` 现在会返回 `UNIT` 列号**（劈开词的两侧都标）。当前唯一调用方
   （1050 行的整表 abstain）不受影响；但若将来有人用这个集合做"逐列判定"，
   需要知道集合里可能含非数值列。

---

## 6. 遗留三条的收口（2026-10-31）

### 6.1 遗留 1（`X UNIT` 列混数字）：影响面实测为 0 条写盘，不清洗

`'5 Ω 4'`（p10/r11）、`'0 16 °C'`（p12/r20）这类脏单位格，只出现在三张融合列表上
（`fused_tables=3`），而这三张表全部 abstain：`DRV81620` 的 `write_cols=10`
全部来自 p6 绝对最大值表、p11 时序表、p13 阈值表，`cell_bad_fused=8`
（8 条 finding 的 `table` 都是 `"FUSED_COLUMN"`）。

再核 50 件全部 44 条写盘条目的 `unit`：`V / mA / µA / °C / %FS / pF / mW / µW / µA/MHz`
—— 没有一条带数字。结论：**脏单位格没有流进任何写盘**。

所以不清洗单位格。清洗要先决定"哪部分是单位、哪部分是串进来的数值"，那是猜；
按 §1.2 宁可 abstain。改为用 `test_dirty_unit_cell_is_never_written` 把
"永不写出"钉死。

### 6.2 遗留 2（A13 对它无效）：确认不可扩，写成限制

`split_fused_rows` 的判据是"这一列自己能不能分出 `len(roles) >= 2` 个角色"。
本形态 `header_roles('MA') == ∅`、`header_roles('X UNIT')` 只有一个 `UNIT`，
两处都 < 2，函数直接返回 `None`（`test_a13_returns_none_for_half_word` /
`test_a13_returns_none_for_unit_cell` 钉住）。这不是"还没实现"，是**形态不匹配**：
A13 解决"一列装多角色的值"（DAC8555 的 `'MIN TYP MAX'` 一列三值），
本表每个角色**已有自己的列**，坏的只是标签。

唯一可行的修法是"跨列半词重拼表头"（`'MA'` + `'X'` → `'MAX'`），但它会改动
`hx` 与列边界推断 —— 那是 A16 的坐标系来源，牵一发动全身。当前 abstain 已保证不误写，
**收益不抵风险，明确不扩**：这类表永久走人工。

### 6.3 遗留 3（`fused_cols` 含非数值列）：保持现状，已在 docstring 标注

`fused_cols` 的两个判据都会带上非数值列（跨列拼词会同时标 `'MA'` 与 `'X UNIT'`）。
当前唯一消费方是整表 abstain（`fused or grouped` → 整条跳过），集合里多一列、
少一列不改变结果。任何"逐列判定"的新用法都必须先处理这一点 —— 已写进
`qc/table_audit.py` 的 `fused_cols` docstring。

### 6.4 修复前后的行为差异（实测补齐）

遗留段原先写的是"切分失败的默认行为是保持原样 → abstain，已验证不会误写"。
按条目取值分三种，只有第三种才是 abstain：

| R DS(ON) 的值 | 修复前 | 修复后 |
|---|---|---|
| `0.4`（MIN） | **写出 `{'MIN':0.4,'TYP':0.7}`，MAX 静默丢失**，只报 `qualifier_loss` | 一条不写 |
| `0.7`（TYP） | 同上 | 一条不写 |
| `0.95`（MAX） | `value_unsupported_unresolved` | 一条不写 |

**值命中 MIN/TYP 时是最坏情形**：半张表被当成完整答案写下去，finding 里连
"角色不可分"都没提。这加强了本次修复的必要性 —— 不是"少写一点"，是"别把半张表当答案"。
