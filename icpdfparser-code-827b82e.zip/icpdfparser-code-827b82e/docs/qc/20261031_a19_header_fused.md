# A19：融合表头格让 `pick_header` 认不出表头

日期：2026-10-31
关键词：`pick_header` / `role_map` / `t.header.names` / 融合列 / A18 误诊断

---

## 1. 起因

A18 上线后，`ADS7945SRTER` 有 **29 条** 电气参数报 `table_foreign_part_unresolved`，
证据字段清一色写着 `ADS7946`。看上去像「本品的参数跑到 ADS7946 的表里去了」。

一验就发现不对：**A18 关掉时这 29 条一样不写盘**，只是换个身份出现
（`cell_unparsable_unresolved` 28 条 + `row_ambiguous_unresolved` 4 条）。
也就是说 A18 没有制造丢写，**是这批参数本来就一行都没写**。真正的问题在更早一步 ——
本品自己的两张表压根没参与匹配。

## 2. 取证：真表头就在第 0 行，而且它本来是三列

一开始的假设是「多行/合并表头把表头挤到了下面」。真机取证把这个假设推翻了。

第 4 页表头行（`PAGE_FILTER` 之后，`extract()` 之前，直接按词坐标看）：

```
[y=124] PARAMETER@113-164  TEST@272-292  CONDITIONS@295-345
         MIN@420-435  TYP@454-470  MAX@497-515  UNITS@526-550
```

`MIN`/`TYP`/`MAX` 三个词分别落在 420-435 / 454-470 / 497-515 —— **它们本来就是三个
独立子列**，MIN 与 TYP 之间差 19pt。丢的是竖向网格线，不是「表格被合并」。

于是 `extract()` 的结果是这样两行波形：

```
p4 t0 row0 = ['PARAMETER', 'TESTCONDITIONS', 'MIN TYP MAX', 'UNITS']     ← 真表头，在第 0 行
p4 t0 row1 = ['ANALOGINPUT', '', '', '']
```

**没有「表头被往下推」，所以也不需要「往下多探几行」。**

## 3. 两个各自独立的真因

### D1：`role_map` 一格只给一个角色 → 数角色数错了

`pick_header` 的判据是「这一行有几个数值角色列 >= 2」，而它用 `role_map` 来数 ——
`role_map` 一格只记一个角色，`'MIN TYP MAX'` 只产出 `rm[2] = 'MIN'`，数到 1。

```python
role_map(row0) = {1: 'COND', 2: 'MIN', 3: 'UNIT'}   # 数值角色只有 1 个
pick_header(rows) -> ([], rows)                      # 判成「这张表没有表头」
```

表头位置是对的，**是数数的方式错了**。

### D2：`names 优先` 让说明文字当了表头

即使 `pick_header` 修好了也白修 —— `scan_tables` 的表头优先级是：

```
hdr_split > t.header.names（列数匹配时） > pick_header(rows)
```

而这张表的 `t.header.names` 是表头**上方那段说明文字**被 `extract()` 切出来的碎片：

```python
names = ['Minimum/maximum specifications at TA = -40°C to +125°C, AVDD',
         '= 2.7 V to 5.25 V, DVDD = 1.65 V to AVDD, input',
         'common-mode = VREF/2 ± 0.2, and fSAMPLE =',
         '= 2 MSPS.']
len(names) == 4 == len(rows[0])          # 长度恰好相等 → 它赢了
```

碎片里 `'Minimum/maximum specifications'` 带着 `typical`/`minimum`，
所以任何「names 里有没有角色词」这种弱判据都会放过它 —— 判据必须比这更硬。

## 4. 红先用例与其自曝的第三个坑

`tests/test_table_pick_header.py`，先跑红：

| 用例 | 修复前现象 |
|---|---|
| `test_fused_cell_counts_all_three_roles` | `pick_header` 返回 `([], rows)` |
| `test_note_fragments_do_not_beat_a_real_header` | `choose_header` 返回 `from_names=True`（说明文字当表头） |
| `test_skips_note_rows_above_the_header` | **第一版修复被它当场打红** |

第三行是这个 Round 值钱的地方：**只按角色个数计**的第一版修复，会把说明文字那行
`'Minimum/maximum specifications'` 数成「MIN + MAX 两个角色」，整行升级成表头 ——
修好的 D1 立刻变成新的误判源。红先测试的作用在这里体现：它不是形式，它拦下了
「看起来很合理的第一版」。

对策是加一道 **`roles_only_cell`** 门：一格里的多个角色，只在「这格除了角色词什么
都不剩」时才算数。`'MIN TYP MAX'` 全是角色词 → 3 个；
`'Minimum/maximum specifications'` 还剩 `specifications` → 按老办法只算 1 个。

## 5. 修法

```python
HEADER_WINDOW = 3                 # 窗口不扩：3 行是决定，有测试钉住

def roles_only_cell(cell) -> bool: ...

def row_roles(row) -> dict:
    """一格可能带多个角色；只有 roles_only_cell 成立时才允许多计。"""

def pick_header(rows):
    for i, r in enumerate(rows[:HEADER_WINDOW]):
        n = sum(len(rs) for rs in row_roles(r).values())
        if n >= 2:
            return r, rows[i + 1:]
    return [], rows

def header_like(texts) -> bool:
    """至少两个格子各自带了角色词 —— 比「有没有」硬，比「必须像真表头」软。"""
    return sum(1 for t in (texts or []) if role_map([t])) >= 2

def choose_header(names, rows):
    """返回 (header, data, from_names)：names 不像表头但表里找得到表头行时才翻脸。"""
```

`scan_tables` 里原来「A13 的 `base`」和「最终 header」**各判一遍**，
现在收敛成 `choose_header` 一次 —— 两处不一致时，A13 会拿着一张错表头去切列。

## 6. 实测

见下一节「灰度验证」表格。

## 7. 明确不做的两件事

1. **窗口不扩到 5 行/8 行**。本项目实测表头就在第 0 行，往下多扫只会把数据行里
   出现的 `MIN`/`MAX` 字样升级成表头。`HEADER_WINDOW = 3` 是一个**决定**，
   由 `test_header_beyond_the_window_is_not_guessed` 钉住。
2. **A13（`ICPDF_SPLIT_FUSED`）默认仍然关闭**。它会改变表格结构（列数变多、
   表头重写），是全链路最激进的改动，必须单独走灰度。本次只把「它的前置条件」
   修好：以前 `base` 取到的是说明文字碎片，`fused_cols(base)` 为空，A13 连触发
   的机会都没有。

## 8. 这条链才是"拿回那 3 条写盘"的正路

`A19（表头）→ A13（切融合列）`：

```
修复前   header = 说明文字碎片       → 无角色列 → 本品表零候选 → 报"这是 ADS7946 的表"
修复后   header = 真表头（融合列）   → FUSED_COLUMN → 不写，但理由诚实
          └─ 再开 A13 → 切成 MIN/TYP/MAX 三列 → AVDD supply current 3 条写盘复原
```

单件（`ADS7945SRTER`，`ICPDF_SPLIT_FUSED=1`）：

```
row: ['AVDDsupplycurrent', 'I DYNAMIC', 'AVDD = 3.3 V, fSAMPLE = 2 MSPS', '3.5 4', 'mA']
      ↓ A13 按 x 切分
row: [..., 'MIN'='', 'TYP'='3.5', 'MAX'='4', 'mA']
      ↓ 写盘
columns = {'TYP': 3.5, 'MAX': 4.0}      ← 与模型给的 "3.5 TYP / 4 MAX" 一致
```

同源对比见证了横向独立性：`['AVDD', '', '', '2.7 3.3 5.25', 'V']`
→ `MIN 2.7 / TYP 3.3 / MAX 5.25`，三列各自落位，切分是对的。

**是否把 A13 默认打开，是一个独立的、要重新走灰度的决策，本次不做。**

## 9. 未做 / 待查

- A13 灰度：31 件以上跑一遍 write-dry，看切分出来的值在别的文档里会不会串列。
- `qualifier_loss` 分支差异（VOH / IODL 在灰度里合并前后条件字段不一致）—— 未查清。
- PDF 里 `±` 号的提取（专门的单测还没写）。
- `_FAMILY_PREFIX = 6` 的校准需要 50 件以上的召回实测。
