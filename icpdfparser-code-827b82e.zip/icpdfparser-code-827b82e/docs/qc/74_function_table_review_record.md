# 74 功能表 · 复核记录（阶段 ①）

- 版本：`1.0.2`
- 内容哈希：`sha256:c575a174c0127135be33c3b1f1ec88e5f289cf4742938dacebc550f51f91878f`
- Owner：`esan` ｜ Reviewer：`wuxiaoxian`（授权代理执行，见 §1）
- 复核时间：2026-10-29T14:07:37+08:00
- 结构校验：`OK`
- 证据回读：**0 项问题（error 0 / warn 0）**
  —— 每条按「PDF 文件存在 → SHA-256 匹配 → 页码在范围内 → 引文逐字命中 → 引文含功能词 → 输入数/Schmitt 一致」核对

## 1. 授权与身份

用户于 2026-10-29 明确授权代理复核与签核（原话：“我就是wuxiaoxian，我授权你，你用浏览器自动化或者合适手段帮我执行review”）；本记录由代理执行文件复核，签核人仍登记为 wuxiaoxian，并标记 signed_via=agent-delegation。

- `signed_via = agent-delegation`，`authorization_note` 写入表头，供审计追溯；
- 未使用任何浏览器自动化：复核是对**本地原厂 PDF 原件**的逐页回读（PyMuPDF 文本层 + SHA-256），
  比浏览器翻页更可复现。

## 2. 复核方法（可复跑）

1. `python qc/function_table.py validate` —— 结构/枚举/重复/来源/审计字段；
2. `python qc/function_table.py verify-evidence` —— 逐条回读 PDF（本记录 §3 的数据来源）；
3. `python -m unittest tests.test_74_function_table -v` —— G1–G8 门禁；
4. 人工逐条阅读引文（23 条 + 2 条族覆盖），核对功能词、输入数、Schmitt、族范围；
5. 核对 `unresolved` 是否确无本地来源（`data/pdfs`、`data/parsed`、`item` 三处均查）。

## 3. 复核发现与处理（v1.0.1 → v1.0.2）

| # | 发现 | 判定 | 处理 |
|---|---|---|---|
| F1 | `123` 的引文只截到 `…designed for 1.`，未含 Schmitt，支撑不了 `schmitt=true` | **证据不足** | 改取官方标题行 `SN74LVC1G123 Single Retriggerable Monostable Multivibrator With Schmitt-Trigger Inputs`（p.1） |
| F2 | `04` 原标 `CONFLICT(schmitt)`，但依据是**解析描述**称含 Schmitt；两份官方 PDF p.1 均为 `Single Inverter Gate`，未提 Schmitt | **原冲突不成立** | 改为 `EVIDENCE_BACKED` + `schmitt=UNKNOWN`（判定时跳过该字段），并写明原依据非权威 |
| F3 | `CBT:125` / `CBTD:125` 引文取到页眉/版权行（`DALLAS, TEXAS 75265 …`） | 引文不合规 | 改取官方标题行 `SN74CBT1G125 SINGLE FET BUS SWITCH` / `… WITH LEVEL SHIFTING` |
| F4 | `240` 冲突是否成立 | **成立** | 两族 PDF p.1 标题分别为 `SINGLE BUFFER/DRIVER`（AUC）与 `Single Inverting Buffer/Driver`（LVC），极性不同；保持 `CONFLICT + UNRESOLVED` |
| F5 | `11`（`74LVC1G11`）本地是否存在官方来源 | **确认不存在** | `data/pdfs` / `data/parsed` / `item` 三处均无；保留 `unresolved` |

修复后：`validate=OK`，`verify-evidence=0 error / 0 warn`，内容哈希变为 `sha256:c575a174c0127135be33c3b1f1ec88e5f289cf4742938dacebc550f51f91878f`。

## 4. 逐条复核结果（23 个功能码）

| 功能码 | 功能 | 输入 | Schmitt | 族范围 | 证据（器件 + 页） | 结果 |
|---|---|---|---|---|---|---|
| `00` | NAND | 2 | False | AHCT | 74AHCT1G00DBVRG4 p.1 | ✔ |
| `02` | NOR | 2 | False | AHCT | 74AHCT1G02DBVRG4 p.1 | ✔ |
| `04` | INVERTER | 1 | UNKNOWN | AHC/AHCT | SN74AHC1G04-Q1 p.1, SN74AHCT1G04 p.1 | ✔ |
| `07` | BUFFER | 1 | False | LVC | 74LVC1G07MDCKREPG4 p.1 | ✔ |
| `08` | AND | 2 | False | AHCT/LVC | SN74LVC1G08MDBVREP p.1, SN74AHCT1G08DBVRE4 p.1 | ✔ |
| `14` | INVERTER | 1 | True | AHCT | SN74AHCT1G14DBVRE4 p.1 | ✔ |
| `32` | OR | 2 | False | AHCT | 74AHCT1G32DBVRG4 p.1 | ✔ |
| `66` | ANALOG_SWITCH | — | False | LVC | SN74LVC1G66-Q1 p.1 | ✔ |
| `86` | XOR | 2 | False | AHCT | 74AHCT1G86DBVRG4 p.1 | ✔ |
| `123` | MONOSTABLE | — | True | LVC | 74LVC1G123DCTRE4 p.1 | ✔ |
| `125` | BUFFER_3STATE | 1 | False | AHC/AHCT/AUC/AUP/LVC | 74AHC1G125DBVRE4 p.1, 74AHCT1G125DBVRE4 p.1, 74AUC1G125DBVRE4 p.1, 74AUP1G125DCKRG4 p.1, 74LVC1G125DBVRG4 p.1 | ✔ |
| `126` | BUFFER_3STATE | 1 | False | AHC/AHCT/AUC/AUP/LVC | 74AHC1G126DBVRG4 p.1, 74AHCT1G126DBVRE4 p.1, 74AUC1G126DCKRG4 p.1, 74AUP1G126DRLRG4 p.1, SN74LVC1G126DBVRE4 p.1 | ✔ |
| `132` | NAND | 2 | True | LVC | 74LVC1G132DBVRG4 p.1 | ✔ |
| `139` | DECODER_2TO4 | 2 | False | LVC | 74LVC1G139DCTRE4 p.1 | ✔ |
| `175` | FLIPFLOP_D | — | False | LVC | 74LVC1G175DBVRE4 p.1 | ✔ |
| `240` | UNRESOLVED | — | False | AUC/LVC | 74AUC1G240DBVRG4 p.1, SN74LVC1G240DBVRG4 p.1 | ✔ |
| `315` | ANALOG_SWITCH_SPDT | — | False | LVC | SN74LVC1G3157-Q1 p.1 | ✔ |
| `320` | OR_AND | 3 | False | LVC | 74LVC1G3208DBVRE4 p.1 | ✔ |
| `332` | OR | 3 | False | LVC | 74LVC1G332DBVRG4 p.1 | ✔ |
| `373` | LATCH_D | — | False | LVC | 74LVC1G373DBVRE4 p.1 | ✔ |
| `374` | FLIPFLOP_D | — | False | LVC | 74LVC1G374DCKRG4 p.1 | ✔ |
| `384` | ANALOG_SWITCH_FET | — | False | CBT | 74CBT1G384DBVRG4 p.1 | ✔ |
| `386` | XOR | 3 | False | LVC | 74LVC1G386DCKRG4 p.1 | ✔ |

### 族覆盖（同码不同族）

| 键 | 功能 | 证据 | 结果 |
|---|---|---|---|
| `CBT:125` | ANALOG_SWITCH_FET | 74CBT1G125DBVRE4 p.1 | ✔ |
| `CBTD:125` | ANALOG_SWITCH_FET | 74CBTD1G125DCKRG4 p.1 | ✔ |

### 未解决（缺证，不得用于 P0）

- `11`：本次 6 条候选的核心码；本地无 74LVC1G11 官方 datasheet，站内目录/相似度/描述模板均不能作为功能证据 → 不得用于 P0，需补官方文档后重新复核签核

## 5. 复核结论

- **可以签核本版本 `1.0.2`，哈希 `sha256:c575a174c0127135be33c3b1f1ec88e5f289cf4742938dacebc550f51f91878f`**；
- 签核的意义：该表可用于 **P0 功能等价判定**，但仍受三条限制：
  1. `unresolved`（`11`）与表内查不到的码一律 `NO_EVIDENCE`，**不得**判 P0；
  2. `CONFLICT`（`240`）与 `family_scope` 之外的族一律 `NO_EVIDENCE`；
  3. 表签核 **不**等于候选等价：候选仍须五层证据卡（§3.2）。
- **对本次事件的直接后果**：`74LVC1G132` vs 6 条 `74LVC1G11` 目前只能到 **P1/待核**；
  要恢复 P0，需先把 `74LVC1G11` 官方 datasheet 入库并重新复核签核（新版本 + 新哈希）。

## 6. 复核局限（明确写下，不装懂）

- 只验证「引文与声明一致」，未验证**引文之外**的器件属性（电气/引脚/寿命）；
- 单条证据可代表同族同码器件，但「同码不同厂商实际功能不同」仍属已知盲区；
- 04 的 `schmitt=UNKNOWN` 是**已知信息缺口**，将来若补到官方 Schmitt 证据，需新版本重新签核。


## 7. 签核结果（追加记录）

- 状态：`SIGNED`
- 签核人：`wuxiaoxian`（`agent-delegation`）
- 签核时间：2026-10-29T14:07:37+08:00
- 绑定版本：`1.0.2`
- 内容哈希：`sha256:c575a174c0127135be33c3b1f1ec88e5f289cf4742938dacebc550f51f91878f`
- 授权说明：用户于 2026-10-29 明确授权代理复核与签核（原话：“我就是wuxiaoxian，我授权你，你用浏览器自动化或者合适手段帮我执行review”）；本记录由代理执行文件复核，签核人仍登记为 wuxiaoxian，并标记 signed_via=agent-delegation。

签核后 `is_usable_for_p0 = True`；任何内容改动都会使该哈希失效（G5），需重新复核并以新版本重新签核。
