#!/usr/bin/env python3
"""Phase 1.7 灰度探针（只在 /tmp/p17 隔离环境里跑）。

    p17.py seed   <mpn> <url>       建一条全新 item（同 mpn_key 先删后建）
    p17.py submit <kind> <mpn> [url] 投一个任务
    p17.py status <mpn>             item + 阶段账 + 采集轨迹 + 事件 + 队列
    p17.py report <mpn>             status + llm_usage 汇总 + 产物/JSON 关键字段
    p17.py wait   <mpn> [秒]        轮询到终态后打印 report（默认 420s）
"""
from __future__ import annotations

import json
import os
import sys
import time


def _queues() -> dict:
    from app.services import dispatch
    return dispatch.queue_depths() if dispatch.redis_ok() else {}


def _artifact(path: str) -> dict:
    if not path or not os.path.isfile(path):
        return {}
    return {"name": os.path.basename(path), "bytes": os.path.getsize(path),
            "mtime": int(os.path.getmtime(path))}


def _doc_summary(path: str) -> dict:
    if not path or not os.path.isfile(path):
        return {}
    try:
        d = json.loads(open(path, encoding="utf-8").read())
    except Exception as e:                                        # noqa: BLE001
        return {"error": f"{type(e).__name__}: {e}"[:120]}
    bi = d.get("basic_info") or {}
    sp = d.get("specs") or {}
    thermal = sp.get("thermal") or []
    return {
        "identity": bi.get("identity"), "document_scope": bi.get("document_scope"),
        "device_mpn": bi.get("device_mpn"),
        "scope": sp.get("scope"), "pin_scope": d.get("pin_scope"),
        "counts": {k: len(sp.get(k) or []) for k in
                   ("electrical", "absolute_max", "thermal", "ac_performance",
                    "onboard_device_specs", "unresolved_specs")},
        "pins": len(d.get("pin_configuration") or []),
        "thermal_names": sorted({str(r.get("name")) for r in thermal}),
        "audit_findings": len((((d.get("metadata") or {}).get("audit") or {})
                               .get("findings") or [])),
        "board_scope_reason": (d.get("metadata") or {}).get("board_scope_reason"),
        # D3：字段级主体归属（板卡件每一行都要有 subject + subject_source）
        "subject_summary": sp.get("subject_summary"),
        "unlabeled_thermal": sum(1 for r in thermal if not r.get("subject")),
        "unlabeled_esd": sum(1 for r in (sp.get("esd") or []) if not r.get("subject")),
        # D1：确定性摘要在 metadata 里必须留痕（否则无法证明跑过这一步）
        "deterministic_extract": (d.get("metadata") or {}).get("deterministic_extract"),
    }


def collect(mpn: str) -> dict:
    from app import db
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn,))
    if not item:
        return {"mpn": mpn, "item": None}
    stages = db.q("SELECT stage,stage_version,status,attempts,ms,idem_key,error,detail "
                  "FROM pipeline_stage WHERE mpn_key=? ORDER BY id", (mpn,))
    srcs = db.q("SELECT provider,stage,ok,bytes,substr(sha256,1,12) sha12,tried_at "
                "FROM doc_source WHERE mpn_key=? ORDER BY tried_at", (mpn,))
    ev = db.q("SELECT kind,message FROM event WHERE item_id=? ORDER BY id", (item["id"],))
    usage = db.q("SELECT stage,provider,model,SUM(prompt_tokens) prompt_tokens,"
                 "SUM(completion_tokens) completion_tokens,SUM(total_tokens) total_tokens,"
                 "COUNT(*) calls,SUM(CASE WHEN ok=0 THEN 1 ELSE 0 END) failed "
                 "FROM llm_usage WHERE mpn_key=? GROUP BY stage,provider,model", (mpn,))
    kinds: dict[str, int] = {}
    for e in ev:
        kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    keep = ("id", "mpn", "status", "stage", "progress", "provider", "pdf_path",
            "pdf_sha256", "json_path", "txt_path", "symbol_path", "parse_ms",
            "parse_count", "error", "tried_at", "updated_at")
    out = {
        "mpn": mpn,
        "item": {k: item.get(k) for k in keep},
        "stages": [{**s, "detail": (s.get("detail") or "")[:600],
                    "idem": (s.get("idem_key") or "")[:64]} for s in stages],
        "doc_source": srcs,
        "events": [f"{e['kind']}: {e['message']}" for e in ev],
        "event_kinds": kinds,
        "llm_usage": usage,
        "artifacts": {k: _artifact(item.get(k) or "") for k in
                      ("pdf_path", "json_path", "txt_path", "symbol_path")},
        "doc": _doc_summary(item.get("json_path") or ""),
        "queues": _queues(),
    }
    return out


def cmd_seed(mpn: str, url: str) -> int:
    from app import db
    db.x("DELETE FROM item WHERE mpn_key=?", (mpn,))
    iid = db.x(
        "INSERT INTO item(mpn,mpn_key,brand,status,stage,progress,pdf_url,"
        "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
        (mpn, mpn, "", "queued", "任务已入队", 2, url, db.now(), db.now()))
    print(json.dumps({"item_id": iid, "mpn": mpn, "manual_url": url},
                     ensure_ascii=False))
    return 0


def cmd_submit(kind: str, mpn: str, url: str = "") -> int:
    from app import config
    from app.services import dispatch
    if kind == "fetch_item":
        r = dispatch.submit(kind, mpn, False, url)
    else:
        r = dispatch.submit(kind, mpn)
    r["queue"] = config.TASK_QUEUE.get(kind, config.CELERY_QUEUE)
    print(json.dumps(r, ensure_ascii=False))
    return 0


def cmd_wait(mpn: str, timeout: int = 420) -> int:
    from app import db
    t0 = time.time()
    last = ("", 0)
    while time.time() - t0 < timeout:
        item = db.q1("SELECT status,progress FROM item WHERE mpn_key=?", (mpn,))
        if item:
            last = (str(item.get("status")), int(item.get("progress") or 0))
            if last[0] in ("done", "skipped", "failed") and last[1] >= 100:
                # 终态后再等队列清空（防止上一段的接力消息还没被消费）
                if not any((_queues() or {}).values()):
                    break
        time.sleep(2)
    print(json.dumps({"waited_s": round(time.time() - t0, 1), "last": last,
                      "report": collect(mpn)}, ensure_ascii=False, indent=1))
    return 0 if last[0] in ("done", "skipped", "failed") else 3


def main(argv: list[str]) -> int:
    if len(argv) < 3:
        print(__doc__)
        return 2
    cmd = argv[1]
    if cmd == "seed" and len(argv) >= 4:
        return cmd_seed(argv[2], argv[3])
    if cmd == "submit" and len(argv) >= 3:
        return cmd_submit(argv[2], argv[3] if len(argv) > 3 else "",
                          argv[4] if len(argv) > 4 else "")
    if cmd == "status":
        print(json.dumps(collect(argv[2]), ensure_ascii=False, indent=1))
        return 0
    if cmd == "report":
        print(json.dumps(collect(argv[2]), ensure_ascii=False, indent=1))
        return 0
    if cmd == "wait":
        return cmd_wait(argv[2], int(argv[3]) if len(argv) > 3 else 420)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
