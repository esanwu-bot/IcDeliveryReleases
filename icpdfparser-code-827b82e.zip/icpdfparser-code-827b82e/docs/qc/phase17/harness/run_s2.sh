#!/usr/bin/env bash
set -u
cd /tmp/p17
export SIDE=s2 DATA=/tmp/p17/data_s2 DB=8
URL="https://www.ti.com/lit/ds/sbas543c/sbas543c.pdf"
echo "=== clean ==="; ./p17.sh clean
echo "=== up ===";    ./p17.sh up
sleep 5
echo "=== seed ===";  ./p17.sh probe seed ADS8568EVM-PDK "$URL"
echo "=== submit ==="; ./p17.sh probe submit fetch_item ADS8568EVM-PDK "$URL"
echo "=== wait ===";  ./p17.sh probe wait ADS8568EVM-PDK 480 > /tmp/p17/s2.json; echo "wait_rc=$?"
echo "=== down ===";  ./p17.sh down
