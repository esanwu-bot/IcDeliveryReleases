#!/usr/bin/env bash
# Phase 1.7 三件受控灰度编排（只在服务器 /tmp/p17 下工作，不碰生产容器）
#
#   SIDE=s1 DATA=/tmp/p17/data_s1 ./p17.sh clean
#   SIDE=s1 DATA=/tmp/p17/data_s1 ./p17.sh up
#   ./p17.sh probe seed LM317 <url>
#   ./p17.sh probe submit fetch_item LM317 <url>
#   ./p17.sh probe wait LM317 420 > /tmp/p17/s1.json
#   SIDE=s1 ./p17.sh down
#   ./p17.sh digest /www/wwwroot/icpdfparser/data/parsed
#   ./p17.sh dbhash /www/wwwroot/icpdfparser/data/workbench.sqlite3
#   ./p17.sh prod
set -u
BASE=/tmp/p17
IMG=icpdf/app:latest
NET=icpdf_default
ENVF=/www/wwwroot/icpdfparser/deploy/.env
CODE=$BASE/code
DB=${DB:-8}
SIDE=${SIDE:-}
DATA=${DATA:-$BASE/data_${SIDE:-x}}
ROLES="fetch preprocess llm audit render"

mounts() {
  # 代码目录用**临时副本**（git archive 出来的），可写：config 在 import 时会
  # mkdir uploads/ 等目录，只读挂载会直接 OSError；数据根仍是独立挂载。
  printf '%s ' -v "$CODE:/app" -v "$DATA:/app/data"
}
envs() {
  printf '%s ' -e "ICPDF_REDIS=redis://redis:6379/$DB" \
    -e ICPDF_WORKBENCH_DB=/app/data/workbench.sqlite3 \
    -e ICPDF_PIPELINE_V2=1
}

cmd=${1:-}; shift || true
case "$cmd" in
  probe)
    docker run --rm --network "$NET" --env-file "$ENVF" $(envs) $(mounts) \
      "$IMG" python /app/p17.py "$@"
    ;;
  up)
    [ -n "$SIDE" ] || { echo "need SIDE=s1|s2|s3"; exit 2; }
    mkdir -p "$CODE/data" "$DATA"
    for r in $ROLES; do
      n="p17-$SIDE-$r"
      docker rm -f "$n" >/dev/null 2>&1
      docker run -d --name "$n" --network "$NET" --env-file "$ENVF" \
        $(envs) $(mounts) "$IMG" \
        python run_worker.py --role "$r" -c 1 -l info >/dev/null
      echo "up $n role=$r db=$DB data=$DATA"
    done
    ;;
  down)
    [ -n "$SIDE" ] || { echo "need SIDE=s1|s2|s3"; exit 2; }
    for r in $ROLES; do
      docker logs "p17-$SIDE-$r" > "$BASE/log_$SIDE-$r.log" 2>&1 || true
      docker rm -f "p17-$SIDE-$r" >/dev/null 2>&1 || true
    done
    echo "down $SIDE (logs -> $BASE/log_$SIDE-*.log)"
    ;;
  clean)
    docker exec icpdf-redis redis-cli -n "$DB" flushdb >/dev/null
    rm -rf "$DATA"; mkdir -p "$CODE/data" "$DATA"
    echo "clean db=$DB data=$DATA"
    ;;
  logs)
    docker logs "${1:?container}" 2>&1
    ;;
  digest)
    d=${1:?dir}
    n=$(find "$d" -type f 2>/dev/null | wc -l)
    b=$(du -sb "$d" 2>/dev/null | cut -f1)
    s=$(find "$d" -type f -print0 2>/dev/null | sort -z \
        | xargs -0 -r sha256sum 2>/dev/null | sha256sum | cut -d' ' -f1)
    echo "dir=$d files=$n bytes=${b:-0} digest=$s"
    ;;
  dbhash)
    f=${1:?sqlite}
    echo "db=$f sha256=$(sha256sum "$f" | cut -d' ' -f1) size=$(stat -c%s "$f") " \
         "mtime=$(stat -c%y "$f")"
    ;;
  prod)
    echo "--- 生产容器（重启次数） ---"
    for c in icpdf-server icpdf-render icpdf-llm icpdf-fetch icpdf-redis; do
      printf '%s restarts=%s started=%s\n' "$c" \
        "$(docker inspect -f '{{.RestartCount}}' "$c" 2>/dev/null)" \
        "$(docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null)"
    done
    echo "--- 生产数据指纹 ---"
    "$0" digest /www/wwwroot/icpdfparser/data/parsed
    "$0" dbhash /www/wwwroot/icpdfparser/data/workbench.sqlite3
    ;;
  *)
    sed -n '2,20p' "$0"
    exit 2
    ;;
esac
