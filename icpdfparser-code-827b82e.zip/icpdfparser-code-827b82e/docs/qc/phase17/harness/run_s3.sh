#!/usr/bin/env bash
set -u
cd /tmp/p17
export SIDE=s3 DATA=/tmp/p17/data_s3 DB=8
URL="https://www.ti.com/lit/ug/slau301/slau301.pdf"
echo "=== clean ==="; ./p17.sh clean
echo "=== up ===";    ./p17.sh up
sleep 5
echo "=== seed ===";  ./p17.sh probe seed DAC8568EVM "$URL"
echo "=== submit ==="; ./p17.sh probe submit fetch_item DAC8568EVM "$URL"
echo "=== wait ===";  ./p17.sh probe wait DAC8568EVM 180 > /tmp/p17/s3.json; echo "wait_rc=$?"
echo "=== down ===";  ./p17.sh down
