#!/usr/bin/env bash
set -u
cd /tmp/p17
export SIDE=s1 DATA=/tmp/p17/data_s1 DB=8
URL="https://www.ti.com.cn/lit/ds/symlink/lm317.pdf"
echo "=== clean ==="; ./p17.sh clean
echo "=== up ===";    ./p17.sh up
sleep 5
echo "=== seed ===";  ./p17.sh probe seed LM317 "$URL"
echo "=== submit ==="; ./p17.sh probe submit fetch_item LM317 "$URL"
echo "=== wait ===";  ./p17.sh probe wait LM317 420 > /tmp/p17/s1.json; echo "wait_rc=$?"
echo "=== down ===";  ./p17.sh down
