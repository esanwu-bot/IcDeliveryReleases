# delivery-20261104-batch100 内容审批清单（95 件）

> 本清单由装配报告 `stage/_stage_report.json` 与 `results.csv` 直接生成，**只读**，不改任何件。
> 用途：人工签核。**第 2、3 节是必须先看的**；第 5 节是逐件明细，用于抽查。

## 1. 总账

| 项 | 值 |
|---|---|
| 抽样 | 100 件（芯片 83 / 板卡 17） |
| 解析完成 | 95 件（done） |
| 隔离 | 5 件（见第 4 节） |
| 装配产出 | **92 件**（应为 95，缺 3 件，见 3.2） |
| 零电气且零引脚 | 8 件（见 3.1） |
| core_validation 非 pass | 3 件 |
| 身份待看（非 SUPPORTED/BOARD_CONFIRMED） | 2 件 |

## 2. 逐件评分口径（本次只有这一个口径）

- **正式桶**（参与电气门禁）：`specs.<container>` 主表 + `specs.onboard_device_specs.<container>`；容器 = electrical / absolute_max / ac_performance。
- **隔离区**（只记账、不计分）：`specs.unresolved_specs.*`、`specs.unresolved_ac_rows`。
- `status=ok` 的唯一含义：最终落盘稿通过 `validate()` **且** `core_errs` 为空。否则是 `parsed_core_fail`；结构不过则是 `failed`。
- `ACCEPT_THIN` 只允许**芯片**低规格件通行；板卡不得借这条通道（2026-11-04 守卫）。

## 3. 必须先看的三个口子

### 3.1 零电气 + 零引脚（板卡身份的诚实空，但交付价值为零）

| # | MPN | 身份 | scope | 装配内 | 处置建议 |
|---|---|---|---|---|---|
| 1 | `AFE7950` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 2 | `BQ24450EVM-691` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 3 | `EKB-UCOS3-EVM` | evaluation_board | unresolved | 是 | **隔离待重判**（不随批交付） |
| 4 | `LM3352-3.0EVAL` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 5 | `LM5064EVK/NOPB` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 6 | `LM5066EVK/NOPB` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 7 | `TPS2391EVM` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |
| 8 | `TPS65131EVM-063` | evaluation_board | onboard_device | 是 | **隔离待重判**（不随批交付） |

> 这 8 件是「ACCEPT_THIN 语义错位」的实物证据：它们没有电气也没有引脚，却被旧判据当成「低规格芯片」放进来。守卫落地后，同形状的新件会被判 `failed`。

### 3.2 装配缺失（驱动脚本用 doc_mpn 定位，5 件 done 挤成 2 条记录）

| 缺失 doc_mpn | 对应批次件 | 原因 |
|---|---|---|
| `DAC39RFS12` | DAC39RFS12ACK / DAC39RF12ACL | 两件共用同一份 datasheet，驱动按 doc_mpn 传参 → 只解析到一条 |
| `DAC39RFS10` | DAC39RFS10ACL / DAC39RF10ACK | 同上 |
| `AFE7900` | AFE7900EVM | doc_mpn 与件 mpn 不同名，`--mpns` 传 doc_mpn 找不到同名 JSON |

> 这是**装配驱动脚本**的键错误（`--mpns` 该传件 mpn，不是 doc_mpn），不是解析缺陷，也不涉及 `stage_release` 生产代码。

## 4. 5 件隔离件定性

| MPN | 类型 | 失败阶段 | 定性码 | 依据 |
|---|---|---|---|---|
| `ADC12DL500ACF` | chip | llm | `structure_defect_open` | 12.6MB 文档输出预算不足，两次同位置截断（invalid_json） |
| `LM3677LE-1.8EV` | chip | llm | `model_variance_single` | 单次 before/after 观察：一次 not an object、一次 formal=4 —— 不定量，需 N=3 才可归因 |
| `BQ24715EVM-115` | board | llm | `accept_thin_board_misroute` | 板卡 formal_elec=0/pins=0，旧判据经 ACCEPT_THIN 放行；守卫后判 failed |
| `ADS122U04EVM` | board | llm | `accept_thin_board_misroute` | 同上；旧版曾有 8 条真实板载参数，本次模型没抽到 |
| `ADS8686SEVM-PDK` | board | llm | `structure_defect_open` | 模型输出 not an object，两次如此 |

> **口径修复（a259da3）在本批的收益 = 0 件**：没有任何一件因为「正式桶相加」被救回。它防的是未来板卡件被误拒，不是本批故障。

## 5. core_validation 非 pass —— **新闸门下这 3 件会被判 parsed_core_fail**

| MPN | core_validation | 电气 | 引脚 | 装配内 |
|---|---|---|---|---|
| `ADC0802LCN` | ['pin 字段混用球位号与序号（球位 8 / 共 9）'] | 31 | 9 | 是 |
| `CD4010BQDRQ1` | ['pin_configuration 为空'] | 40 | 0 | 是 |
| `DS14C89AN/NOPB` | ['pin_configuration 为空'] | 30 | 0 | 是 |

> 这 3 件在旧链路里「盖章但不阻断」，已随 92 件进了装配包；**新闸门（status=ok 必须无 core_errs）会把它们判 parsed_core_fail 并隔离**。签核时要么按「已知存量」放行，要么从本包剔除，二选一，不能默认沉默。

## 6. 逐件明细（95 件 done，其中 92 件已进装配包）

| # | MPN | 类型 | 身份 | 电气 | 引脚 | 热阻 | ESD | 温度 | 装配 | 标记 |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `ADS7815UE4` | chip | chip | 52 | 28 | 0 | 2 | -25°C to +85°C | 是 |  |
| 2 | `ADC12DL2500ACF` | chip | chip | 134 | 136 | 5 | 2 | -40 to 85 | 是 |  |
| 3 | `ADS1286U` | chip | chip | 61 | 8 | 5 | 2 | 0°C to +70°C | 是 |  |
| 4 | `ADC12DL1500ACF` | chip | chip | 49 | 136 | 5 | 2 | -40°C to 85°C | 是 |  |
| 5 | `ADS1286U/2K5G4` | chip | chip | 60 | 8 | 4 | 2 | -40°C to +85°C | 是 |  |
| 6 | `ADC32RF83IRRHR` | chip | chip | 42 | 72 | 12 | 2 | -40°C to +85°C | 是 |  |
| 7 | `ADS1286UB/2K5` | chip | chip | 60 | 8 | 4 | 2 | -40°C to +85°C | 是 |  |
| 8 | `ADC32RF83IRMPT` | chip | chip | 58 | 72 | 12 | 2 | -40°C to 85°C | 是 |  |
| 9 | `ADS1286UC/2K5` | chip | chip | 62 | 8 | 5 | 2 | -40°C to +85°C | 是 |  |
| 10 | `ADC32RF80IRRHR` | chip | chip | 42 | 72 | 12 | 2 | -40°C to 85°C | 是 |  |
| 11 | `ADS1286UG4` | chip | chip | 60 | 8 | 0 | 2 | 0°C to +70°C | 是 |  |
| 12 | `ADC32RF80IRMPT` | chip | chip | 46 | 72 | 12 | 2 | -40°C to 85°C | 是 |  |
| 13 | `ADS1286UK` | chip | chip | 60 | 8 | 4 | 2 | -40°C to +85°C | 是 |  |
| 14 | `ADC32RF80IRMPR` | chip | chip | 54 | 72 | 12 | 2 | -40°C to 85°C | 是 |  |
| 15 | `ADC700JH` | chip | chip | 70 | 28 | 0 | 0 | 0°C to 70°C | 是 |  |
| 16 | `ADS58J64IRRHT` | chip | chip | 33 | 72 | 12 | 1 | -40°C to 85°C | 是 |  |
| 17 | `ADS7818P` | chip | chip | 59 | 8 | 0 | 2 | -40°C to +85°C | 是 |  |
| 18 | `ADS58J64IRRHR` | chip | chip | 31 | 72 | 12 | 1 | -40°C to 100°C | 是 |  |
| 19 | `ADC1061CIWM` | chip | chip | 37 | 20 | 3 | 1 | -40°C to 85°C | 是 |  |
| 20 | `ADS58J64IRMPT` | chip | chip | 31 | 72 | 12 | 1 | -40°C to 100°C | 是 |  |
| 21 | `ADS7820P` | chip | chip | 55 | 28 | 2 | 2 | -40°C to +85°C | 是 |  |
| 22 | `ADS58J64IRMPR` | chip | chip | 25 | 72 | 12 | 1 | -40°C to 100°C | 是 |  |
| 23 | `ADS7820PB` | chip | chip | 55 | 28 | 2 | 2 | -40°C to +85°C | 是 |  |
| 24 | `DAC39RF10ACLNSP` | chip | chip | 116 | 54 | 5 | 2 | -55°C to 125°C | 是 |  |
| 25 | `DAC7541AJUG4` | chip | chip | 52 | 18 | 2 | 2 | 0°C to +70°C | 是 |  |
| 26 | `DAC39RFS12ACK` | chip | - | 110 | 0 | - | - | - | **缺** | **装配缺失** |
| 27 | `DAC7541AKPG4` | chip | chip | 29 | 18 | 2 | 2 | 0°C to +70°C | 是 |  |
| 28 | `DAC39RF12ACL` | chip | chip | 91 | 27 | 5 | 2 | -40°C to 85°C | 是 |  |
| 29 | `DAC7541AKU/1K` | chip | chip | 26 | 18 | 4 | 2 | 0°C to +70°C | 是 |  |
| 30 | `DAC39RFS10ACL` | chip | - | 116 | 0 | - | - | - | **缺** | **装配缺失** |
| 31 | `DAC7541AKU/1KG4` | chip | chip | 26 | 18 | 5 | 2 | 0°C to +70°C | 是 |  |
| 32 | `DAC39RF10ACK` | chip | chip | 118 | 27 | 5 | 2 | -40°C to 85°C | 是 |  |
| 33 | `DAC725JP` | chip | chip | 33 | 28 | 0 | 0 | 0°C to +70°C | 是 |  |
| 34 | `LM358` | chip | chip | 48 | 8 | 42 | 2 | -40°C to 85°C | 是 |  |
| 35 | `LM3208TLEV` | chip | chip | 6 | 8 | 0 | 0 | -40 to 85 | 是 |  |
| 36 | `LM3677TL-1.8EV` | chip | chip | 4 | 5 | 1 | 2 | -30°C to +85°C | 是 |  |
| 37 | `LM3676SD-ADJEV` | chip | chip | 9 | 8 | 0 | 0 | -30°C to +85°C | 是 |  |
| 38 | `LM3352-3.0EVAL` | chip | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 39 | `LM3671TL-1.8EV` | chip | chip | 12 | 5 | 2 | 2 | -30°C to +85°C | 是 |  |
| 40 | `LM3658SDEV/NOPB` | chip | chip | 115 | 10 | 1 | 2 | -40°C to +85°C | 是 |  |
| 41 | `LM5064EVK/NOPB` | chip | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 42 | `BQ48SH-28X6NSH` | chip | chip | 17 | 2 | 0 | 0 | 0°C to 70°C | 是 |  |
| 43 | `LM5066EVK/NOPB` | chip | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 44 | `BQ2201PN` | chip | chip | 32 | 8 | 0 | 0 | 0°C to +70°C | 是 |  |
| 45 | `BQ24262YFFR` | chip | chip | 64 | 36 | 5 | 2 | -40°C to 85°C | 是 |  |
| 46 | `BQ2201PNG4` | chip | chip | 32 | 8 | 0 | 0 | 0°C to +70°C | 是 |  |
| 47 | `BQ24262RGER` | chip | chip | 192 | 20 | 5 | 2 | -40°C to 85°C | 是 |  |
| 48 | `BQ2201SN` | chip | chip | 33 | 8 | 0 | 0 | 0°C to +70°C | 是 |  |
| 49 | `BQ24261YFFT` | chip | chip | 192 | 36 | 5 | 2 | -40°C to 85°C | 是 |  |
| 50 | `BQ2201SNG4` | chip | chip | 28 | 8 | 0 | 0 | 0°C to +70°C | 是 |  |
| 51 | `BQ24261RGET` | chip | chip | 190 | 20 | 5 | 2 | -40°C to 85°C | 是 |  |
| 52 | `BQ2201SN-NG4` | chip | chip | 33 | 8 | 0 | 0 | -40°C to +85°C | 是 |  |
| 53 | `BQ24261MYFFT` | chip | chip | 178 | 36 | 5 | 2 | -40°C to 85°C | 是 |  |
| 54 | `BQ3285LFSS-A1` | chip | chip | 18 | 24 | 0 | 0 | 0°C to +70°C | 是 |  |
| 55 | `BQ24261MYFFR` | chip | chip | 200 | 36 | 5 | 2 | -40°C to 85°C | 是 |  |
| 56 | `BQ3285LDSS` | chip | chip | 13 | 24 | 0 | 0 | 0°C to +70°C | 是 |  |
| 57 | `CD4010BQDRQ1` | chip | chip | 40 | 0 | 0 | 3 | -40°C to 125°C | 是 | **核心非pass** |
| 58 | `74FCT16244CTPVCTG4` | chip | chip | 66 | 48 | 5 | 2 | -40°C to +85°C | 是 |  |
| 59 | `CD4021BQDRQ1` | chip | chip | 48 | 16 | 1 | 3 | -40°C to 125°C | 是 |  |
| 60 | `74FCT162245CTPVCT` | chip | chip | 39 | 48 | 1 | 2 | -40°C to +85°C | 是 |  |
| 61 | `74AVC4T245RSVR-NT` | chip | chip | 35 | 16 | 5 | 2 | -40°C to 85°C | 是 |  |
| 62 | `74ACT11132D` | chip | chip | 22 | 16 | 0 | 0 | -40°C to 85°C | 是 |  |
| 63 | `74AVC4T245RSVRG4` | chip | chip | 35 | 16 | 5 | 2 | -40°C to 85°C | 是 |  |
| 64 | `74AC11800DW` | chip | chip | 16 | 24 | 0 | 0 | -40°C to 85°C | 是 |  |
| 65 | `74AVC4T245RGYRG4` | chip | chip | 35 | 16 | 5 | 2 | -40°C to 85°C | 是 |  |
| 66 | `74ACT11020DR` | chip | chip | 20 | 20 | 0 | 0 | -55°C to 125°C | 是 |  |
| 67 | `74AVC4T245DGVRE4` | chip | chip | 35 | 16 | 5 | 2 | -40°C to 85°C | 是 |  |
| 68 | `74ACT11011N` | chip | chip | 24 | 16 | 0 | 0 | -55°C to 125°C | 是 |  |
| 69 | `DRV10963PDSNT` | chip | chip | 27 | 10 | 6 | 2 | -40°C to 125°C | 是 |  |
| 70 | `DS14C89AM` | chip | chip | 30 | 14 | 0 | 1 | 0°C to 75°C | 是 |  |
| 71 | `DRV10963PDSNR` | chip | chip | 29 | 10 | 6 | 2 | -40°C to 125°C | 是 |  |
| 72 | `DS14C89AM/NOPB` | chip | chip | 30 | 14 | 0 | 1 | 0°C to 75°C | 是 |  |
| 73 | `DRV10963JUDSNT` | chip | chip | 35 | 10 | 6 | 2 | -40°C to 125°C | 是 |  |
| 74 | `DS14C89AMX` | chip | chip | 30 | 14 | 0 | 1 | 0°C to 75°C | 是 |  |
| 75 | `DRV10963JUDSNR` | chip | chip | 29 | 10 | 6 | 2 | -40°C to 125°C | 是 |  |
| 76 | `DS14C89AMX/NOPB` | chip | chip | 30 | 14 | 0 | 2 | 0°C to 75°C | 是 |  |
| 77 | `DRV10963JMDSNT` | chip | chip | 35 | 10 | 6 | 2 | -40°C to 125°C | 是 |  |
| 78 | `DS14C89AN/NOPB` | chip | chip | 30 | 0 | 0 | 2 | 0°C to 75°C | 是 | **核心非pass** |
| 79 | `BQ76PL455EVM` | board | evaluation_board | 5 | 0 | 0 | 0 | -40°C to 105°C | 是 |  |
| 80 | `AFE7950EVM` | board | - | 101 | 0 | - | - | - | **缺** | **装配缺失** |
| 81 | `TPS65131EVM-063` | board | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 82 | `AFE7900EVM` | board | - | 0 | 0 | - | - | - | **缺** | **装配缺失** |
| 83 | `TPS65130EVM-063` | board | evaluation_board | 7 | 0 | 0 | 0 | -40°C to 85°C | 是 |  |
| 84 | `TPS2391EVM` | board | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 85 | `BQ24450EVM-691` | board | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 86 | `EKB-UCOS3-EVM` | board | evaluation_board | 0 | 0 | 0 | 0 | not_specified | 是 | 零参数板卡 |
| 87 | `ADS1252EVM` | board | - | 53 | 0 | - | - | - | **缺** | **装配缺失** |
| 88 | `LMZ10504DEMO/NOPB` | board | chip | 9 | 8 | 2 | 0 | -40°C to +94°C | 是 |  |
| 89 | `LMR14206XMKDEMO/NOPB` | board | chip | 18 | 6 | 1 | 1 | -40°C to +125°C | 是 |  |
| 90 | `BOOSTXL-DRV8320H` | board | evaluation_board | 0 | 42 | 0 | 0 | not_specified | 是 | 身份待看 |
| 91 | `TUSB9261DEMO` | board | chip | 38 | 65 | 5 | 2 | 0°C to 70°C | 是 |  |
| 92 | `LMZ14203DEMO/NOPB` | board | chip | 7 | 7 | 0 | 0 | -40°C to +78°C | 是 |  |
| 93 | `ADC07D1520CIYB/NOPB` | chip | chip | 76 | 10 | 3 | 3 | -40°C to +85°C | 是 |  |
| 94 | `ADC07D1520RB/NOPB` | chip | chip | 67 | 10 | 3 | 3 | -40°C to +85°C | 是 |  |
| 95 | `ADC0802LCN` | chip | chip | 31 | 9 | 10 | 1 | -40 to 85 | 是 | **核心非pass** |

## 7. 签核

| 角色 | 结论 | 日期 |
|---|---|---|
| 解析方（自动） | 95 件 done；装配 92 件；零参数板卡 8 件待重判 | 2026-11-04 |
| Reviewer（人工） | 待签 | |
