# -*- coding: utf-8 -*-
"""正式包定稿（v2）：3 件 core 错件转隔离、9 件板卡带标记准入、补 outcome_source 与 manifest。

与 v1 的差异（均为实测踩坑后的修正）：
  1. 补 `import sys`（v1 漏了，直接 NameError）。
  2. `results.csv` 里的 `json_path` 是**宿主机路径**（/www/wwwroot/icpdfparser/...），
     容器内不存在；v1 直接 Path() 会判成"全部 missing"。这里先归一为 /app/...。
  3. `outcome_source` 不能按 mtime 判 —— 95 个 JSON 的 mtime 全是今天（整批今天落盘），
     mtime 零区分度。改用 `metadata.parse_timestamp`（解析时点）+ `prompt_version`。
  4. `doc_mpn` 从 sample.json 取（DAC39RFS12ACK->DAC39RFS12 等 5 件不同名），
     v1 回退成件 mpn 等于没写。
  5. 隔离时连 seo/symbols/txt 一起搬，不留孤儿文件。
"""
from __future__ import annotations

import csv, datetime as dt, json, shutil, sys
from pathlib import Path

ROOT = Path("/app")
B = ROOT / "data/batch100_20261104"
STAGE = B / "stage"
QUAR = B / "_quarantine"
sys.path.insert(0, "/app")
from qc.scope_contract import BOARD_TYPES        # noqa: E402

DRY = "--dry" in sys.argv
CORE_FAIL = {"ADC0802LCN", "CD4010BQDRQ1", "DS14C89AN/NOPB"}
RUN_DATE = dt.date(2026, 11, 4)


def norm(p: str) -> Path:
    """宿主机绝对路径 -> 容器内路径。"""
    p = (p or "").strip()
    if p.startswith("/www/wwwroot/icpdfparser/"):
        p = p[len("/www/wwwroot/icpdfparser/"):]
    return ROOT / p


rep = json.loads((STAGE / "_stage_report.json").read_text(encoding="utf-8"))
recs = rep["records"]
rows = list(csv.DictReader(open(B / "results.csv", encoding="utf-8")))
by_mpn = {r["mpn"]: r for r in rows}
sample = json.loads((B / "sample.json").read_text(encoding="utf-8"))
doc_of = {it["mpn"]: (it.get("doc_mpn") or it["mpn"]) for it in sample["items"]}


def artifacts(safe: str) -> list[Path]:
    """一个件的全部落盘产物（parsed/pdfs 按全名，seo/symbols/txt 按前缀）。"""
    out = []
    for sub, ext in (("parsed", ".json"), ("pdfs", ".pdf")):
        p = STAGE / sub / f"{safe}{ext}"
        if p.exists():
            out.append(p)
    for sub in ("seo", "symbols", "txt"):
        d = STAGE / sub
        if d.is_dir():
            out.extend(sorted(p for p in d.glob(f"{safe}*") if p.is_file()))
    return out


# ---- 1. 3 件 core 非 pass：移出正式包，转隔离待修 ----
ledger, keep = [], []
for r in recs:
    if r["mpn"] in CORE_FAIL:
        safe = r.get("safe_name") or r["mpn"]
        files = artifacts(safe)
        if not DRY:
            for src in files:
                dst = QUAR / src.parent.name / src.name
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
        ledger.append({
            "mpn": r["mpn"], "safe_name": safe, "tag": "core_validation_fail",
            "core_errs": r.get("core_validation"),
            "core_errs_at_parse": r.get("core_validation_at_parse"),
            "identity": r.get("identity"),
            "electrical": r.get("electrical"), "pins": r.get("pins"),
            "src_json": r.get("src_json"),
            "files_moved": [f"{p.parent.name}/{p.name}" for p in files],
            "why": "核心字段硬错误：旧链路只盖章不阻断，新闸门判 parsed_core_fail；剔出正式包待修",
            "disposition": "隔离待修；若业务要页面，走降级说明页另立项",
        })
    else:
        keep.append(r)

# ---- 2. 板卡电气为空件：带标记准入（allowlist） ----
# 判据 2026-11-04 第二次裁决升级：`identity in BOARD_TYPES ∧ electrical == 0`。
# 原判据多要求 `pins == 0`，把「板卡有引脚、但电气表本来就不存在」的件漏在 normal 里
# （BOOSTXL-DRV8320H：elec=0 pins=42），等于让同一缺陷类的一半件走了普通准入。
allow = [r for r in keep
         if str(r.get("identity")) in BOARD_TYPES
         and int(r.get("electrical") or 0) == 0]
allow_mpns = {r["mpn"] for r in allow}

# ---- 3. outcome_source：按解析时点（不是 mtime） ----
out_rows, counts = [], {"new_parse": 0, "carried_over": 0}
for r in rows:
    if (r.get("status") or "").strip() != "done":
        continue
    jp = norm(r.get("json_path"))
    meta = {}
    if jp.exists():
        try:
            meta = json.loads(jp.read_text(encoding="utf-8")).get("metadata") or {}
        except Exception:
            meta = {}
    ts = str(meta.get("parse_timestamp") or "")
    day = None
    if len(ts) >= 10:
        try:
            day = dt.date.fromisoformat(ts[:10])
        except ValueError:
            day = None
    src = "new_parse" if (day and day >= RUN_DATE) else "carried_over"
    counts[src] += 1
    out_rows.append({**r,
                     "outcome_source": src,
                     "carried_over": int(src == "carried_over"),
                     "parse_timestamp": ts,
                     "model_generation": str(meta.get("model_version") or ""),
                     "prompt_version": str(meta.get("prompt_version") or "")})

cols = list(rows[0].keys()) + ["outcome_source", "carried_over",
                               "parse_timestamp", "model_generation", "prompt_version"]
if not DRY:
    with open(B / "results_enriched.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(out_rows)

# ---- 4. manifest.csv（正式包逐件，带准入标记） ----
def cv_text(v):
    """core_validation 既可能是 "pass" 字符串，也可能是错误列表，统一成可读文本。"""
    if isinstance(v, str):
        return v or "pass"
    if isinstance(v, (list, tuple)):
        return "; ".join(str(x) for x in v) or "pass"
    return "pass"


src_of = {r["mpn"]: r for r in out_rows}
if not DRY:
    with open(STAGE / "manifest.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["mpn", "safe_name", "identity", "electrical", "pins", "thermal", "esd",
                    "temperature", "verified_rows", "core_validation",
                    "admission", "electrical_empty_reason", "carried_over",
                    "outcome_source", "prompt_version", "doc_mpn", "pdf_sha256"])
        for r in sorted(keep, key=lambda x: x["mpn"]):
            adm = "allowlist_board" if r["mpn"] in allow_mpns else "normal"
            reason = "board_expected_empty(legacy_pre_guard)" if r["mpn"] in allow_mpns else ""
            w.writerow([r["mpn"], r.get("safe_name"), r.get("identity"), r.get("electrical"),
                        r.get("pins"), r.get("thermal"), r.get("esd"), r.get("temperature"),
                        r.get("verified_rows"), cv_text(r.get("core_validation")),
                        adm, reason, src_of.get(r["mpn"], {}).get("carried_over", ""),
                        src_of.get(r["mpn"], {}).get("outcome_source", ""),
                        src_of.get(r["mpn"], {}).get("prompt_version", ""),
                        doc_of.get(r["mpn"], r["mpn"]),
                        (r.get("pdf") or {}).get("sha256", "")])

    QUAR.mkdir(parents=True, exist_ok=True)
    with open(QUAR / "allowlist.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["mpn", "identity", "electrical", "pins", "core_validation",
                    "by", "why"])
        for r in sorted(allow, key=lambda x: x["mpn"]):
            pins = int(r.get("pins") or 0)
            why = ("守卫上线前存量；板卡诚实空（board_expected_empty）" if pins == 0 else
                   "守卫上线前存量；板卡有引脚但电气表本就不存在（board_expected_empty）"
                   "；2026-11-04 第二次裁决把判据从 pins==0 放宽为 electrical==0 后纳入")
            w.writerow([r["mpn"], r.get("identity"), r.get("electrical"), pins,
                        "pass", "总裁裁决 2026-11-04", why])

    rep["records"] = keep
    # 重跑时正式包里已经没有那 3 件了，ledger 会算成空 —— 不能因此把台账洗掉。
    old_ledger = QUAR / "ledger_core_fail.json"
    if not ledger and old_ledger.exists():
        ledger = json.loads(old_ledger.read_text(encoding="utf-8")).get("items") or []
        print(f"沿用既有隔离台账 {len(ledger)} 件（本次未重复搬文件）")
    rep["quarantined_core"] = ledger
    rep["allowlist_board"] = sorted(allow_mpns)
    rep["outcome_source_counts"] = counts
    (STAGE / "_stage_report.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")

    old_ledger = QUAR / "ledger_core_fail.json"
    if ledger or not old_ledger.exists():
        old_ledger.write_text(
            json.dumps({"generated": dt.datetime.now().isoformat(timespec="seconds"),
                        "n": len(ledger), "items": ledger}, ensure_ascii=False, indent=2),
            encoding="utf-8")

    (B / "_finalize_summary.json").write_text(
        json.dumps({"at": dt.datetime.now().isoformat(timespec="seconds"),
                    "in_pkg": len(keep), "quarantined": [x["mpn"] for x in ledger],
                    "allowlist": sorted(allow_mpns),
                    "outcome_source": counts}, ensure_ascii=False, indent=2),
        encoding="utf-8")

print(("[DRY] " if DRY else "") + f"正式包 {len(keep)} 件")
print("隔离(core fail)", len(ledger), "件:", [x["mpn"] for x in ledger])
print("板卡 allowlist", len(allow_mpns), "件:", sorted(allow_mpns))
print("outcome_source", counts)
rest = [r["mpn"] for r in keep if int(r.get("electrical") or 0) == 0
        and r["mpn"] not in allow_mpns]
print("elec=0 但不在 allowlist 的件:", rest or "无")
print("allowlist 里非板卡或非零参数:", [r["mpn"] for r in allow
                                     if str(r.get("identity")) not in BOARD_TYPES] or "无")
print("3 件错件是否仍在包内:", [m for m in CORE_FAIL if m in {r["mpn"] for r in keep}] or "否")
if not DRY:
    for sub in ("parsed", "pdfs", "seo", "symbols", "txt"):
        d = STAGE / sub
        print(f"  stage/{sub} 现有 {len(list(d.iterdir())) if d.is_dir() else 0} 个文件")
    print("quarantine 现有", sum(1 for _ in QUAR.rglob("*") if _.is_file()), "个文件")
