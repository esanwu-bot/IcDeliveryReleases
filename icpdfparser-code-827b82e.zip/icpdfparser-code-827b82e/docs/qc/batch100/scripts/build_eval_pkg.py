# -*- coding: utf-8 -*-
"""组装 batch100 盲审发布包 `data/_delivery_releases/delivery-batch100-eval/`。

为什么是 `-eval`（AGENT.md §16.1a-1）
------------------------------------
本包用途是**给外部大型模型做盲审**（双 Qwen 交叉验证），不是已签核的正式交付版。
§16.1a-1 明确：带 `-eval` 后缀的包允许推 GitHub 发布仓库，且**不占用 `-Vn` 正式序列**；
包内 `release_status` 不得声明 `approved`，`engineering_validation` 恒为 `not_approved`。

PDF 为什么没随包（如实登记，不装成已满足 §16.8）
-----------------------------------------------
§16.8 要求正式交付包逐型号带 `<型号>/<型号>.pdf`。本批 93 份原件合计 **403 MB**，
而本包要审的是「代码侧 5 个 P0 修复 + 数据侧 91 件清单/台账」，PDF 不参与本轮判定。
因此 `manifest.json` 里 `pdf_included=false` 并写明原因，包校验报告给 **WARN 不是 PASS**，
`open_items` 里留存待办 —— 正式交付包必须把 PDF 补齐后才能声明 PASS。

只读 `final-v5/`，不碰 `final/`（§16.2 只新增不改写）。
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # docs/qc/batch100
REPO = Path(__file__).resolve().parents[4]
FIN = ROOT / "final-v5"
REPLAY = REPO / "docs/qc/tools/replay_batch100"
OUT = REPO / "data/_delivery_releases/delivery-batch100-eval"
NAME = "delivery-batch100-eval"


def rows(p: Path) -> list[dict]:
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


#: 发布仓库 `.gitattributes` 规定 `* text=auto eol=lf`，并明确「manifest 里记录的
#: size / sha256 都按 CRLF→LF 归一后计算」。所以包内文本必须先落成 LF 再算哈希 ——
#: 否则复核方一 checkout（git 会把 CRLF 归一成 LF），`sha256sum` 全部对不上，
#: 自检报告自己把自己证伪。二进制（PDF/ZIP）不动。
TEXT_SUFFIX = (".md", ".csv", ".json", ".txt")


def to_lf(p: Path) -> None:
    if p.suffix.lower() not in TEXT_SUFFIX:
        return
    raw = p.read_bytes()
    lf = raw.replace(b"\r\n", b"\n")
    if lf != raw:
        p.write_bytes(lf)


def main() -> int:
    man = rows(FIN / "manifest.csv")
    allow = rows(FIN / "allowlist.csv")
    exc = rows(FIN / "excluded.csv")
    sm = json.loads((FIN / "_refinal_summary.json").read_text(encoding="utf-8"))
    led = json.loads((FIN / "quarantine_ledger.json").read_text(encoding="utf-8"))
    live = {str(it.get("safe") or ""): it for it in led.get("items") or []}

    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    # ---- 逐件清单：CSV 给人看，JSON 给机器读（DSH/双 Qwen 直接消费） ----
    shutil.copy2(FIN / "manifest.csv", OUT / "manifest.csv")
    shutil.copy2(FIN / "allowlist.csv", OUT / "allowlist.csv")
    shutil.copy2(FIN / "excluded.csv", OUT / "excluded.csv")
    shutil.copy2(FIN / "quarantine_ledger.json", OUT / "quarantine_ledger.json")
    shutil.copy2(REPLAY / "quarantine.csv", OUT / "quarantine.csv")
    shutil.copy2(REPLAY / "DIFF.md", OUT / "DIFF.md")
    shutil.copy2(ROOT / "CHECKLIST_FINAL.md", OUT / "CHECKLIST_FINAL.md")

    records = []
    for r in sorted(man, key=lambda x: x["mpn"]):
        it = live.get(r["safe_name"], {})
        records.append({
            "mpn": r["mpn"],
            "safe_name": r["safe_name"],
            "doc_mpn": r.get("doc_mpn", ""),
            "identity": r.get("identity", ""),
            "identity_source": it.get("identity_source", ""),
            "electrical_main": int(r.get("elec_main_v5") or 0),
            "formal_electrical": int(r.get("formal_elec_v5") or 0),
            "withheld_in_quarantine": int(r.get("withheld_v5") or 0),
            "pins": int(r.get("pins") or 0),
            "final_gate_status": r.get("gate_v5", ""),
            "admission": r.get("admission", ""),
            "validate_errors": [e for e in (r.get("validate_errors_v5") or "").split("；") if e],
            "core_errs": [e for e in (r.get("core_errs_v5") or "").split("；") if e],
            "override_reason": r.get("override_reason_v5", ""),
            "pdf_sha256": r.get("pdf_sha256", ""),
            "pdf_included": False,
        })

    manifest = {
        "package": NAME,
        "generated": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "batch": "batch100",
        "purpose": "代码侧 5 个 P0 修复 + 数据侧 91 件清单/隔离台账的独立盲审（双 Qwen 交叉验证）",
        "is_eval_package": True,
        "release_status": "not_approved",
        "engineering_validation": "not_approved",
        "gate": "final_gate_v1 + identity_guard + admission_v2"
                "（板卡零电气可豁免、核心结构错误不可豁免）",
        "mpn_count": len(records),
        "admission": {"normal": len([r for r in records if r["admission"] == "normal"]),
                      "allowlist_board": len([r for r in records if r["admission"] == "allowlist_board"])},
        "excluded": {
            "total": len(exc),
            "rule_quarantine": [r["mpn"] for r in exc if r["excluded_by"] == "rule_quarantine"],
            "executive_decision": [r["mpn"] for r in exc if r["excluded_by"] == "executive_decision"],
        },
        "pdf_included": False,
        "pdf_included_reason": "本轮为代码+清单盲审包；93 份原件合计 403MB，不参与本轮判定，"
                               "正式交付包必须逐型号补齐（§16.8）",
        "arithmetic": sm["arithmetic"],
        "open_items": sm["open_items"],
        "records": records,
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                       encoding="utf-8")

    # ---- 给人看的 README（包内） ----
    (OUT / "README.md").write_text(f"""# {NAME}（盲审包，非正式交付）

**用途**：给 Reviewer 与外部大型模型（双 Qwen）做交叉验证。**不是**客户交付版。

| 项 | 值 |
|---|---|
| 入包件数 | **{manifest['mpn_count']}**（normal {manifest['admission']['normal']} + allowlist_board {manifest['admission']['allowlist_board']}） |
| 剔除件数 | {len(exc)}（准入裁定隔离 {len(manifest['excluded']['rule_quarantine'])} + 总裁裁决 {len(manifest['excluded']['executive_decision'])}） |
| `release_status` | `not_approved` |
| PDF 原件 | **未随包**（见下） |
| 自检结论 | **WARN**（`包校验报告.json`） |

## 已知风险（送审前必读）

**RISK-1 `AFE7950EVM` 名实不符 —— 记录名已归一，盘上 JSON 仍为 `AFE7950`。**

| 项 | 值 |
|---|---|
| 交付名（`manifest.csv` / 文件名） | `AFE7950EVM` |
| 盘上 JSON `basic_info.mpn` | `AFE7950` |
| 台账标记 | `quarantine_ledger.json` → `name_conflict = true`（93 件中仅此一件） |
| 影响面 | 仅名称字段不一致；电气 101 行（板载器件桶）、引脚 0、身份 `evaluation_board` 均正常，准入结论 `allowlist_board` 不变 |
| 裁决 | 2026-11-04：**本批不修、立刻发包**。改 mpn 属数据侧变更，须连带重跑 §21.1 安检与重出 manifest，留待下一批统一修正 |
| 同类已修件 | `AFE7900EVM`（`basic_info.mpn` 已填为 `AFE7900EVM`） |

请按「已知风险、不影响本轮判定对象」处理：本轮判定的是代码侧 5 个 P0 与清单/台账口径，
不是数据侧命名修复。若评审要求先修，动作是改 JSON 一处 → 重跑
`tools/icpdf_quarantine.py` → 重出 `manifest.csv`，一个闭环。结构见
`docs/qc/batch100/RUN.json` → `known_risks`。

## 审什么

1. `manifest.csv` / `manifest.json`：逐件字段，含 `final_gate_status` / `admission` /
   `validate_errors` / `core_errs` / `override_reason`。
2. `excluded.csv`：**两种剔除理由分开记** —— `rule_quarantine`（工具判的，板卡结构缺陷
   不豁免）与 `executive_decision`（人判的，`ADS1252EVM` 身份为空）。
3. `quarantine_ledger.json`：93 件全量回放台账，是上面所有结论的唯一证据源。
4. `DIFF.md`：本次回放相对 RUN v4 的逐件差异（唯一改判件 `AFE7900EVM`）+ 三条核心侧待统一项。
5. `CHECKLIST_FINAL.md`：终版清单（v5）。

## 为什么没有 PDF

§16.8 要求正式交付包逐型号带原厂 PDF。本批 93 份合计 403 MB，而本轮判定对象是
「代码修复 + 清单/台账」，PDF 不参与。故 `pdf_included=false`，自检结论降为 WARN。
**正式交付包补齐 PDF 后才能声明 PASS。**

## 边界

本包不得作为客户交付；`release_status` 恒为 `not_approved`，`-eval` 不占用正式 `-Vn` 序列。
""", encoding="utf-8")

    # ---- 包内自检：哈希 + 行数 + 结论（WARN 的原因写在 warnings 里） ----
    for p in OUT.rglob("*"):                     # 先归一到 LF，再算哈希
        if p.is_file() and p.name != "包校验报告.json":
            to_lf(p)
    files = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file() and p.name != "包校验报告.json":
            files.append({"path": str(p.relative_to(OUT)), "sha256": sha(p),
                          "bytes": p.stat().st_size})
    warnings = ["pdf_included=false：本轮盲审包未随 PDF 原件（§16.8 未满足）",
                "release_status=not_approved：本包不得作为客户正式交付使用"]
    if sm.get("withheld_in_allowlist"):
        warnings.append("allowlist 中带扣押行的件需人工确认："
                        + json.dumps(sm["withheld_in_allowlist"], ensure_ascii=False))
    report = {
        "package": NAME,
        "generated": manifest["generated"],
        "selfcheck": {
            "manifest_rows": len(records),
            "allowlist_rows": len(allow),
            "excluded_rows": len(exc),
            "replay_counts": led.get("counts"),
            "rows_match_summary": len(records) == sm["in_package"],
            "admission_match_summary": manifest["admission"] == sm["admission"],
        },
        "verdict": "WARN",
        "warnings": warnings,
        "files": files,
    }
    (OUT / "包校验报告.json").write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                         encoding="utf-8")

    print(json.dumps({"out": str(OUT), "mpn_count": manifest["mpn_count"],
                      "admission": manifest["admission"], "files": len(files),
                      "verdict": report["verdict"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
