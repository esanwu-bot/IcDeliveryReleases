# -*- coding: utf-8 -*-
"""补装件：把裁决补入的件（如 LM3677LE-1.8EV）增量装进正式包。

与 stage_gap 的差别：这里装的是**批次表原本记 failed、经复判改判**的件，
所以要多做一步台账（`_amend_supplement.json`），把"谁改的判定、依据是什么"落纸，
不能让正式包里凭空多出一件却查不到来历。

判据（缺一不可，全部现场重算，不读批次表）：
  1. `parse_datasheets.validate(doc)` 无错；
  2. `DE.check_core + check_acceptance` 无错；
  3. `final_gate` 结论为 ok / thin_accepted（不能是 failed / parsed_core_fail）。
"""
from __future__ import annotations

import csv, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path("/app")
B = ROOT / "data/batch100_20261104"
STAGE = B / "stage"
EXTRA_DIR = B / "stage_extra"
PARSED = ROOT / "data" / "parsed"
sys.path.insert(0, "/tmp/newpd")      # 本地最新 parse_datasheets
sys.path.append("/app")

import parse_datasheets as pd                       # noqa: E402
from app.services.parts import safe_name            # noqa: E402
from qc import deterministic_extract as DE          # noqa: E402

TARGETS = sys.argv[1].split(",") if len(sys.argv) > 1 else ["LM3677LE-1.8EV"]
DRY = "--dry" in sys.argv


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def regate(mpn: str) -> dict:
    hits = sorted(PARSED.glob(safe_name(mpn) + "_*.json"))
    if not hits:
        return {"mpn": mpn, "ok": False, "why": "找不到 JSON"}
    p = hits[-1]
    doc = json.loads(p.read_text(encoding="utf-8"))
    errs = pd.validate(doc)
    core = DE.check_core(doc, {}) + DE.check_acceptance(doc, mpn)
    thin = bool(pd.accept_thin(p.name, ""))
    status, errs_final = pd.final_gate(doc, core, thin_allowed=thin)
    return {"mpn": mpn, "json": p.name, "sha256": sha(p), "validate": errs,
            "core": core, "final_gate": status, "errs_final": errs_final,
            "formal": pd.spec_formal_counts(doc),
            "identity": (doc.get("basic_info") or {}).get("identity"),
            "ok": status in (pd.STATUS_OK, pd.STATUS_THIN_ACCEPTED)}


def amend_results(gates: list[dict]) -> list[dict]:
    src = B / "results.csv"
    bak = B / "results.csv.bak_amend"
    if not bak.exists():
        shutil.copy2(src, bak)
    rows = list(csv.DictReader(open(bak, encoding="utf-8")))
    cols = list(rows[0].keys())
    changes = []
    for g in gates:
        for r in rows:
            if r["mpn"] != g["mpn"]:
                continue
            before = {"status": r["status"], "bad_stages": r["bad_stages"],
                      "json_path": r["json_path"]}
            r["status"] = "done"
            r["bad_stages"] = "amended:final_gate_ok"
            after = {"status": r["status"], "bad_stages": r["bad_stages"],
                     "json_path": r["json_path"]}
            changes.append({"mpn": g["mpn"], "before": before, "after": after,
                            "why": "定向重验 after=OK；用当前闸门对盘上 JSON 现场复判为 "
                                   f"{g['final_gate']}（validate 无错、core 无错）"})
    if not DRY:
        with open(src, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            w.writerows(rows)
        (B / "_amend_supplement.json").write_text(
            json.dumps({"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                        "n": len(changes), "changes": changes, "gates": gates},
                       ensure_ascii=False, indent=2), encoding="utf-8")
    return changes


def main() -> int:
    gates = [regate(m) for m in TARGETS]
    for g in gates:
        print(f"{g['mpn']:<20} gate={g.get('final_gate')} validate={g.get('validate')} "
              f"core={g.get('core')} formal={g.get('formal')}")
    bad = [g for g in gates if not g["ok"]]
    if bad:
        print("复判未过，拒绝补装：", [g["mpn"] for g in bad])
        return 2
    if DRY:
        print("[DRY] 可补装", [g["mpn"] for g in gates])
        return 0

    ch = amend_results(gates)
    print("批次表已改判：", [(c["mpn"], c["before"]["status"], "->", c["after"]["status"]) for c in ch])

    rep = json.loads((STAGE / "_stage_report.json").read_text(encoding="utf-8"))
    have = {r["mpn"] for r in rep["records"]}
    todo = [g["mpn"] for g in gates if g["mpn"] not in have]
    if not todo:
        print("包内已有这些件，无需装配")
        return 0

    if EXTRA_DIR.exists():
        shutil.rmtree(EXTRA_DIR)
    t0 = time.time()
    p = subprocess.run([sys.executable, "qc/stage_release.py",
                        "--src", "data/parsed", "--out", str(EXTRA_DIR), "--force",
                        "--alts-from", "data/alts", "--pdf-dir", "data/pdfs",
                        "--mpns", ",".join(todo)],
                       cwd=str(ROOT), capture_output=True, text=True)
    print(f"--- extra stage_release rc={p.returncode} 用时 {time.time()-t0:.1f}s ---")
    print((p.stdout or "").strip()[-600:])
    if p.returncode != 0:
        print((p.stderr or "")[-600:], file=sys.stderr)
        return 3

    got = [r["mpn"] for r in json.loads(
        (EXTRA_DIR / "_stage_report.json").read_text(encoding="utf-8"))["records"]]
    if set(got) != set(todo):
        print("实得与预期不符，停止合并：实得", got, "预期", todo)
        return 4

    before = {x.name: sha(x) for x in sorted((STAGE / "parsed").glob("*.json"))}
    for sub in ("parsed", "pdfs", "seo"):
        if not (EXTRA_DIR / sub).is_dir():
            continue
        (STAGE / sub).mkdir(parents=True, exist_ok=True)
        for f in (EXTRA_DIR / sub).iterdir():
            if f.is_file():
                shutil.copy2(f, STAGE / sub / f.name)
    rep["records"].extend(json.loads(
        (EXTRA_DIR / "_stage_report.json").read_text(encoding="utf-8"))["records"])
    rep["supplement"] = {"mpns": todo, "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    (STAGE / "_stage_report.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")

    after = {x.name: sha(x) for x in sorted((STAGE / "parsed").glob("*.json"))}
    changed = [n for n, h in before.items() if after.get(n) != h]
    added = sorted(set(after) - set(before))
    ok = not changed and set(added) == {f"{safe_name(m)}.json" for m in todo}
    (B / "_supp_merge_check.json").write_text(json.dumps(
        {"before_n": len(before), "after_n": len(after), "changed": changed,
         "added": added, "verdict": "PASS" if ok else "FAIL"},
        ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"合并核对：变更 {len(changed)}（须 0）/ 新增 {added} -> {'PASS' if ok else 'FAIL'}")
    print(f"正式包现有 {len(rep['records'])} 条记录")
    return 0 if ok else 5


if __name__ == "__main__":
    raise SystemExit(main())
