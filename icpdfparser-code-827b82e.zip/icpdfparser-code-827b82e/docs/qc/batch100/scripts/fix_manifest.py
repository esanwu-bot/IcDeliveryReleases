# -*- coding: utf-8 -*-
"""重写 manifest.csv：修 core_validation 列把字符串当列表 join 的串字问题。"""
import csv, json
from pathlib import Path

ROOT = Path("/app")
B = ROOT / "data/batch100_20261104"
STAGE = B / "stage"

rep = json.loads((STAGE / "_stage_report.json").read_text(encoding="utf-8"))
keep = rep["records"]
allow_mpns = set(rep.get("allowlist_board") or [])
sample = json.loads((B / "sample.json").read_text(encoding="utf-8"))
doc_of = {it["mpn"]: (it.get("doc_mpn") or it["mpn"]) for it in sample["items"]}
enr = {r["mpn"]: r for r in csv.DictReader(open(B / "results_enriched.csv", encoding="utf-8"))}


def cv_text(v):
    if isinstance(v, str):
        return v or "pass"
    if isinstance(v, (list, tuple)):
        return "; ".join(str(x) for x in v) or "pass"
    return "pass"


with open(STAGE / "manifest.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["mpn", "safe_name", "identity", "electrical", "pins", "thermal", "esd",
                "temperature", "verified_rows", "core_validation",
                "admission", "electrical_empty_reason", "carried_over",
                "outcome_source", "prompt_version", "doc_mpn", "pdf_sha256"])
    for r in sorted(keep, key=lambda x: x["mpn"]):
        adm = "allowlist_board" if r["mpn"] in allow_mpns else "normal"
        reason = "board_expected_empty(legacy_pre_guard)" if r["mpn"] in allow_mpns else ""
        e = enr.get(r["mpn"], {})
        w.writerow([r["mpn"], r.get("safe_name"), r.get("identity"), r.get("electrical"),
                    r.get("pins"), r.get("thermal"), r.get("esd"), r.get("temperature"),
                    r.get("verified_rows"), cv_text(r.get("core_validation")),
                    adm, reason, e.get("carried_over", ""), e.get("outcome_source", ""),
                    e.get("prompt_version", ""), doc_of.get(r["mpn"], r["mpn"]),
                    (r.get("pdf") or {}).get("sha256", "")])
print("manifest 重写完成", len(keep), "行；allowlist", len(allow_mpns))
