# -*- coding: utf-8 -*-
"""生成 batch100 正式包终版清单：读 final/ 下的装配产物，输出 CHECKLIST_FINAL.md。

数据源（全部来自服务器快照，不手写任何数字）：
  final/manifest.csv, final/allowlist.csv, final/ledger_core_fail.json,
  final/_finalize_summary.json, final/results.csv, final/_amend_supplement.json
"""
from __future__ import annotations

import csv, datetime as dt, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # docs/qc/batch100
FIN = ROOT / "final"
OUT = ROOT / "CHECKLIST_FINAL.md"


def rows(p: Path) -> list[dict]:
    return list(csv.DictReader(open(p, encoding="utf-8")))


man = rows(FIN / "manifest.csv")
led = json.loads((FIN / "ledger_core_fail.json").read_text(encoding="utf-8"))
fin = json.loads((FIN / "_finalize_summary.json").read_text(encoding="utf-8"))
res = rows(FIN / "results.csv")
amend = json.loads((FIN / "_amend_supplement.json").read_text(encoding="utf-8"))
failed = [r for r in res if (r.get("status") or "").strip() == "failed"]
done = [r for r in res if (r.get("status") or "").strip() == "done"]
allow = [r for r in man if r["admission"] == "allowlist_board"]
normal = [r for r in man if r["admission"] == "normal"]
q = set(fin["quarantined"])
amended = {c["mpn"] for c in amend["changes"]}


def cnt(key: str, rs) -> str:
    d: dict[str, int] = {}
    for r in rs:
        d[r.get(key, "")] = d.get(r.get(key, ""), 0) + 1
    return " / ".join(f"{k or '空'} {v}" for k, v in sorted(d.items()))


L: list[str] = []
A = L.append
A("# batch100 正式包终版清单")
A("")
A(f"生成时间：{dt.datetime.now():%Y-%m-%d %H:%M}　"
  "口径：final_gate_v1 + 身份守卫（`218d11e` 起）+ 2026-11-04 第二次裁决（补入 1 件、放宽板卡判据）")
A("")
A("## 0. 数字总账")
A("")
A("| 项 | 数量 | 说明 |")
A("|---|---|---|")
A(f"| 送样 | {len(res)} | `results.csv` 全部行 |")
A(f"| 解析成功（status=done） | {len(done)} | 其中 1 件经第二次裁决由 failed 改判为 done |")
A(f"| 解析失败（status=failed） | {len(failed)} | 未进装配，见附表 D |")
A(f"| 装配入包 | {len(man)} | `stage/` 内 parsed/pdfs/seo 各 {len(man)} 份 |")
A(f"| 其中普通准入 | {len(normal)} | admission=normal |")
A(f"| 其中带标记准入 | {len(allow)} | admission=allowlist_board，逐件见附表 C |")
A(f"| 隔离待修 | {len(led)} | core 硬错误，见附表 B |")
A(f"| outcome_source | new_parse {fin['outcome_source']['new_parse']} / "
  f"carried_over {fin['outcome_source']['carried_over']} | 见 §2 口径说明 |")
A("")
A(f"结论：**{len(done)} − {len(led)} = {len(man)} 件入包**，"
  f"其中 {len(allow)} 件按裁决带标记准入，不得计入 ok 分母。")
A("")
A("## 1. 正式包逐件")
A("")
A("| # | mpn | identity | elec | pins | thermal | esd | temperature | verified | core | admission |")
A("|---|---|---|---|---|---|---|---|---|---|---|")
for i, r in enumerate(sorted(man, key=lambda x: x["mpn"]), 1):
    mark = " *" if r["mpn"] in amended else ""
    A(f"| {i} | {r['mpn']}{mark} | {r['identity']} | {r['electrical']} | {r['pins']} | "
      f"{r['thermal']} | {r['esd']} | {r['temperature']} | {r['verified_rows']} | "
      f"{r['core_validation']} | {r['admission']} |")
A("")
A("`*` = 第二次裁决补入的件，来历见附表 H。")
A("")
A("## 2. 口径说明")
A("")
A("- **identity 分布**：" + cnt("identity", man) + "。")
A("- **admission 分布**：" + cnt("admission", man) + "。")
A("- **板卡准入判据（第二次裁决后）**：`identity in BOARD_TYPES ∧ electrical == 0`，"
  "不再是 `pins == 0`。理由：板卡有引脚但电气表本来就不存在，同属诚实空；"
  "原判据把这类件漏在 normal 里，等于同一缺陷类一半走标记、一半走普通。")
A("- **outcome_source**：判据是 `metadata.parse_timestamp` 是否落在本批执行日，**不看 mtime**"
  "（整批 JSON 都是当天落盘，mtime 零区分度）。")
A("- **doc_mpn**：与件 mpn 不同名的 5 件按 `sample.json` 回填"
  "（DAC39RFS12ACK→DAC39RFS12、DAC39RFS10ACL→DAC39RFS10、AFE7950EVM→AFE7950、"
  "AFE7900EVM→AFE7900、ADS1252EVM→ADS1252U）。")
A("")
A("## 附表 A：普通准入件的形态分布")
A("")
A("| 形态 | 件数 |")
A("|---|---|")
A(f"| 电气 > 0 且引脚 > 0 | {sum(1 for r in normal if int(r['electrical'] or 0) > 0 and int(r['pins'] or 0) > 0)} |")
A(f"| 电气 > 0 引脚 = 0 | {sum(1 for r in normal if int(r['electrical'] or 0) > 0 and int(r['pins'] or 0) == 0)} |")
A(f"| 电气 = 0 引脚 > 0 | {sum(1 for r in normal if int(r['electrical'] or 0) == 0 and int(r['pins'] or 0) > 0)} |")
A(f"| 电气 = 0 引脚 = 0 | {sum(1 for r in normal if int(r['electrical'] or 0) == 0 and int(r['pins'] or 0) == 0)} |")
A("")
A("## 附表 B：隔离待修件")
A("")
A("| mpn | identity | elec | pins | 装配时判定 | 解析时判定 | 搬出文件 |")
A("|---|---|---|---|---|---|---|")
for x in led["items"]:
    A(f"| {x['mpn']} | {x['identity']} | {x['electrical']} | {x['pins']} | "
      f"{'；'.join(x['core_errs'] or [])} | {'；'.join(x['core_errs_at_parse'] or [])} | "
      f"{len(x['files_moved'])} 个 |")
A("")
A("共同点：`basic_info.datasheet_url` 为空（溯源断链）+ 引脚或电气硬错误。旧链路只 `_CV.stamp` "
  "盖章不阻断，新闸门判 `parsed_core_fail` 并拦在落盘前；本轮按裁决剔出正式包，产物在 "
  "`_quarantine/`，台账 `ledger_core_fail.json`。")
A("")
A("## 附表 C：带标记准入件（板卡电气为空）")
A("")
A("| mpn | identity | elec | pins | core | 标记 |")
A("|---|---|---|---|---|---|")
for r in sorted(allow, key=lambda x: x["mpn"]):
    A(f"| {r['mpn']} | {r['identity']} | {r['electrical']} | {r['pins']} | "
      f"{r['core_validation']} | allowlist_board |")
A("")
A("准入语义：**允许交付，但不得计入 ok 分母**；manifest 内 "
  "`admission=allowlist_board` 且 `electrical_empty_reason=board_expected_empty(legacy_pre_guard)`。"
  "本批这 10 件的电气表本来就不存在，不是解析漏抽。")
A("")
A("## 附表 D：解析失败件（未进装配）")
A("")
A("| # | mpn | family | brand | bad_stages |")
A("|---|---|---|---|---|")
for i, r in enumerate(sorted(failed, key=lambda x: x["mpn"]), 1):
    A(f"| {i} | {r['mpn']} | {r.get('family','')} | {r.get('brand','')} | {r.get('bad_stages','')} |")
A("")
A("## 附表 E：板卡判据升级前后对照")
A("")
A("| 判据版本 | 表达式 | 命中件数 | 谁被漏掉 |")
A("|---|---|---|---|")
A("| v1（第一次裁决） | `identity in BOARD_TYPES ∧ electrical==0 ∧ pins==0` | 9 | BOOSTXL-DRV8320H（elec=0 但 pins=42） |")
A(f"| v2（第二次裁决，现行） | `identity in BOARD_TYPES ∧ electrical==0` | {len(allow)} | 无（`elec=0` 而身份是板卡的件已全部带上标记） |")
A("")
A("升级后复核：正式包里 `electrical==0` 但 `admission!=allowlist_board` 的件 = "
  f"{sum(1 for r in man if int(r['electrical'] or 0) == 0 and r['admission'] != 'allowlist_board')} 件。")
A("")
A("## 附表 F：其它观察项（留待下一批，未擅自处理）")
A("")
A("| mpn | 现象 | 现准入 | 处置建议 |")
A("|---|---|---|---|")
A(f"| ADS1252EVM | `identity` 为空（EVM 但身份未归一），电气 55 行、引脚 8，`verified_rows=0` | "
  f"{next((r['admission'] for r in man if r['mpn'] == 'ADS1252EVM'), '—')} | "
  "下一批把「identity 为空」纳入身份守卫的拒绝条件 |")
A("")
A("`delivery_bundle` 尚未读 `accept_status`：本批以**人工核对 manifest** 兜底，"
  "该工具修好前下一批不允许启动（已记入阻断项）。")
A("")
A("## 附表 G：复核口径与可复现命令")
A("")
A("```bash")
A("# 1) 补 AFE7900EVM 身份字段（改前后 sha256 记在 _identity_fix.json）")
A("docker exec icpdf-server python /tmp/_fix_mpn_field.py")
A("# 2) 只装缺口 3 件，装完对已有 92 件逐个复算 sha256")
A("docker exec icpdf-server python /tmp/_stage_gap.py --dry && docker exec icpdf-server python /tmp/_stage_gap.py")
A("# 3) 定稿：隔离 + allowlist + outcome_source + manifest")
A("docker exec icpdf-server python /tmp/_finalize_pkg.py --dry && docker exec icpdf-server python /tmp/_finalize_pkg.py")
A("docker exec icpdf-server python /tmp/_fix_manifest.py")
A("# 4) 第二次裁决后补装 LM3677LE-1.8EV（现场复判为 ok 才装）")
A("docker exec icpdf-server python /tmp/stage_extra.py LM3677LE-1.8EV --dry")
A("docker exec icpdf-server python /tmp/stage_extra.py LM3677LE-1.8EV")
A("```")
A("")
A("脚本原文见 `scripts/`，产物快照见 `final/`。")
A("")
A("## 附表 H：第二次裁决补入件台账")
A("")
A("| mpn | 批次表原判定 | 改判为 | 复判结论 | 依据 |")
A("|---|---|---|---|---|")
for c in amend["changes"]:
    A(f"| {c['mpn']} | {c['before']['status']} / {c['before']['bad_stages']} | "
      f"{c['after']['status']} / {c['after']['bad_stages']} | validate 无错、core 无错、`final_gate=ok` | "
      "定向重验 after=OK；盘上 JSON 用当前闸门现场复判（`stage_extra.py` 先判后装） |")
A("")
A("装配核对：补装前快照 92 件、合并后 93 件，**changed=0**、added 恰为 "
  "`LM3677LE-1.8EV.json`（`_supp_merge_check.json` verdict=PASS）。"
  "改判前的批次表备份在 `results.csv.bak_amend`。")
A("")
OUT.write_text("\n".join(L) + "\n", encoding="utf-8")
print("written", OUT, len(L), "行")
print(f"包内 {len(man)} = normal {len(normal)} + allowlist {len(allow)}；隔离 {len(led)}；"
      f"失败 {len(failed)}；done {len(done)}")
