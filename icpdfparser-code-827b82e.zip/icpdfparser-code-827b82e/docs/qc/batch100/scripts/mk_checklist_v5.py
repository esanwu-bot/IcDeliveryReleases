# -*- coding: utf-8 -*-
"""生成 batch100 v5 终版清单（CHECKLIST_FINAL.md）。

数据源只有 `final-v5/`（不读 `final/`，避免两版数字混在一张表里）：
  manifest.csv / excluded.csv / allowlist.csv / _refinal_summary.json / quarantine_ledger.json

原则：**数字全部从产物读**，脚本里不写任何件数常量。写死一个数字，改一次忘两次，
上一版清单就这么出现过「表里 93、正文 92」的自相矛盾。
"""
from __future__ import annotations

import csv
import datetime as dt
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]          # docs/qc/batch100
FIN = ROOT / "final-v5"
OUT = ROOT / "CHECKLIST_FINAL.md"


def rows(p: Path) -> list[dict]:
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


man = rows(FIN / "manifest.csv")
exc = rows(FIN / "excluded.csv")
allow = rows(FIN / "allowlist.csv")
sm = json.loads((FIN / "_refinal_summary.json").read_text(encoding="utf-8"))
led = json.loads((FIN / "quarantine_ledger.json").read_text(encoding="utf-8"))
normal = [r for r in man if r["admission"] == "normal"]
flagged = [r for r in allow if int(r["withheld"] or 0) > 0]
by_rule = [r for r in exc if r["excluded_by"] == "rule_quarantine"]
by_exec = [r for r in exc if r["excluded_by"] == "executive_decision"]

L: list[str] = []
A = L.append
A("# batch100 正式包终版清单（v5）")
A("")
A(f"生成时间：{dt.datetime.now():%Y-%m-%d %H:%M}　"
  "口径：`final_gate` + 身份守卫 + **2026-11-04 顶级准入裁定（板卡零电气可豁免、"
  "核心结构错误不可豁免）**")
A("")
A("> **本版与 v4 的差别**：v4 是 93 件（83 normal + 10 allowlist）；本版是 "
  f"**{len(man)} 件（{len(normal)} normal + {len(allow)} allowlist_board）**，"
  f"剔掉 {len(exc)} 件，两种理由分别记账（见附表 A）。"
  "逐件回放差异见 `docs/qc/tools/replay_batch100/DIFF.md`。")
A("")
A("## 0. 数字总账")
A("")
A("| 项 | 数量 | 说明 |")
A("|---|---|---|")
A(f"| 本版入包 | **{len(man)}** | `final-v5/manifest.csv` 行数 |")
A(f"| 其中普通准入 | {len(normal)} | `admission=normal` |")
A(f"| 其中带标记准入 | {len(allow)} | `admission=allowlist_board`，逐件见附表 B |")
A(f"| 本版剔除 | {len(exc)} | 准入裁定 {len(by_rule)} + 总裁裁决 {len(by_exec)}，见附表 A |")
A(f"| 上版（v4）入包 | 93 | 保留在 `final/`，未改写（§16.2 只新增不改写） |")
A("")
A(f"核算：**{sm['arithmetic'].split('；')[0]}**。")
A("")
A("## 1. 正式包逐件")
A("")
A("| # | mpn | identity | 主桶电 | 正式桶 | pins | 闸门 | admission |")
A("|---|---|---|---|---|---|---|---|")
for i, r in enumerate(sorted(man, key=lambda x: x["mpn"]), 1):
    A(f"| {i} | {r['mpn']} | {r['identity'] or '（空）'} | {r['elec_main_v5']} | "
      f"{r['formal_elec_v5']} | {r['pins']} | {r['gate_v5']} | {r['admission']} |")
A("")
A("## 附表 A：本版剔除件（两种理由，不得合并叙述）")
A("")
A("| mpn | 剔除理由 | 闸门 | 旧准入 | 主桶电 | 正式桶 | pins | 证据 |")
A("|---|---|---|---|---|---|---|---|")
for r in sorted(exc, key=lambda x: x["mpn"]):
    tag = "准入裁定隔离" if r["excluded_by"] == "rule_quarantine" else "总裁裁决剔除"
    ev = r["validate_errors_v5"] or r["core_errs_v5"] or r["exclude_reason"]
    A(f"| {r['mpn']} | **{tag}** | {r['gate_v5']} | {r['admission_v4']} | "
      f"{r['elec_main_v5']} | {r['formal_elec_v5']} | {r['pins']} | {ev} |")
A("")
A("- **准入裁定隔离（工具判的）**：板卡身份不豁免结构缺陷。`AFE7900EVM` 缺 "
  "`pin_configuration`、缺 `ordering_info`、`manufacturer` 为空、主桶电气 0、引脚 0、"
  "正式桶 0 —— 旧规则「是板卡 ∧ 电气 0」把它洗进 allowlist，新规则判隔离。"
  "**没有为了凑齐 10 件 allowlist 放水。**")
A("- **总裁裁决剔除（人判的）**：`ADS1252EVM` 的 `identity` 为空，身份契约未成立。"
  "工具判 `ok`（电气 55 行、引脚 8、结构核心均过）—— 闸门按核心设计「身份真值未知时"
  "按芯片对待」，**拦不住它**，只能由交付层裁决剔除。把「identity 为空」写进身份守卫"
  "拒绝条件属下一批改动。")
A("")
A("## 附表 B：带标记准入件（板卡电气为空）")
A("")
A("| mpn | identity | 主桶电 | 正式桶 | 扣押行 | pins | 闸门 | 标记 |")
A("|---|---|---|---|---|---|---|---|")
for r in sorted(allow, key=lambda x: x["mpn"]):
    A(f"| {r['mpn']} | {r['identity']} | {r['elec_main']} | {r['formal_elec']} | "
      f"{r['withheld']} | {r['pins']} | {r['final_gate_status']} | allowlist_board |")
A("")
A("准入语义：**允许交付，但不得计入 ok 分母**。其中 "
  f"{len(allow) - len(flagged)} 件闸门直接 `ok`（有板载器件电气表），"
  f"{len(flagged)} 件闸门 `failed` 后经复核确认「只有板卡零电气这一类错误」才放行。")
A("")
A("## 附表 C：带扣押行的准入件（交付前须人工确认）")
A("")
if flagged:
    A("| mpn | 扣押行 | pins | 风险 |")
    A("|---|---|---|---|")
    for r in sorted(flagged, key=lambda x: -int(x["withheld"] or 0)):
        A(f"| {r['mpn']} | **{r['withheld']}** | {r['pins']} | 主桶为空不是「真空」，"
          "是抽到后被列塌缩闸门扣下 |")
    A("")
    A("结论未改（`final_gate` 把 `withheld_in_quarantine` 与「电气不足」同归薄件类），"
      "但台账 / `allowlist.csv` / 命令行三处都显式写明扣押行数。这批行该不该放回，"
      "需业务侧确认。")
else:
    A("本版无带扣押行的准入件。")
A("")
A("## 附表 D：回放结论（93 件全量，含本版剔除件）")
A("")
A("| 准入 | 件数 |")
A("|---|---|")
for k, v in sorted((led.get("counts") or {}).items()):
    A(f"| {k} | {v} |")
A("")
A(f"回放工具：`{sm['tool']}`；装配根：生产容器 `batch100_20261104/stage`（parsed 93 / pdfs 93）；"
  "核心校验按**装配口径**（带 PDF，源文档无 thermal/ESD 表记 `not_applicable`）。")
A("")
A("## 附表 E：待裁的核心侧问题（不在本版修）")
A("")
A("| 编号 | 问题 | 影响 |")
A("|---|---|---|")
for item in sm["open_items"]:
    A(f"| — | {item} | 见 `DIFF.md` §6 |")
A("")
A("## 附表 F：可复现命令")
A("")
A("```bash")
A("# 1) 回放（容器内，带 PDF 证据）")
A("docker exec icpdf-server sh -c 'cd /app && PYTHONPATH=/tmp/newpd:/tmp/newroot:/app \\")
A("  python /tmp/newpd/icpdf_quarantine.py \\")
A("  --src /app/data/batch100_20261104/stage --out /tmp/replay2 --json'")
A("# 2) 重定稿（本地，读回放台账 → final-v5）")
A("python docs/qc/batch100/scripts/refinal_v5.py")
A("# 3) 出清单")
A("python docs/qc/batch100/scripts/mk_checklist_v5.py")
A("```")
A("")
A("产物快照：`final-v5/`（manifest / excluded / allowlist / 台账 / 摘要）。"
  "上版 `final/` 原样保留。")
A("")

OUT.write_text("\n".join(L) + "\n", encoding="utf-8")
print("written", OUT, len(L), "行")
print(f"{len(man)} 件 = normal {len(normal)} + allowlist {len(allow)}；剔除 {len(exc)}"
      f"（规则 {len(by_rule)} / 裁决 {len(by_exec)}）；带扣押 {len(flagged)}")
