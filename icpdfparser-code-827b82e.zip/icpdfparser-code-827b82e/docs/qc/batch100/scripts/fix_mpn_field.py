# -*- coding: utf-8 -*-
"""补 basic_info.mpn 缺失：AFE7900EVM 的 JSON 里连件身份都没有，装配索引根本收不到它。

只补**身份字段**，不动任何 specs/pins 内容；改前改后各记 sha256 以便复核。
"""
import glob, hashlib, json, shutil, datetime
from pathlib import Path

PARSED = Path("/app/data/parsed")
OUT = Path("/app/data/batch100_20261104/_identity_fix.json")
FIX = {"AFE7900EVM": "AFE7900EVM"}          # 件 mpn -> 应写入的 basic_info.mpn

records = []
for item_mpn, want in FIX.items():
    hits = sorted(PARSED.glob(f"{item_mpn}_*.json"))
    if not hits:
        print("找不到", item_mpn); continue
    p = hits[-1]
    before = hashlib.sha256(p.read_bytes()).hexdigest()
    doc = json.loads(p.read_text(encoding="utf-8"))
    bi = doc.setdefault("basic_info", {})
    old = bi.get("mpn")
    if old == want:
        print(f"{item_mpn}: 已是 {want}，跳过"); continue
    shutil.copy2(p, p.with_suffix(".json.bak"))
    if old:
        bi.setdefault("doc_mpn", old)       # 旧值降级为文档身份，不丢
    bi["mpn"] = want
    meta = doc.setdefault("metadata", {})
    meta["identity_fields_fixed"] = {
        "at": datetime.datetime.now().isoformat(timespec="seconds"),
        "field": "basic_info.mpn", "from": old, "to": want,
        "why": "件身份缺失，stage_release 索引按 basic_info.mpn 建，缺了就无法装配",
    }
    p.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    after = hashlib.sha256(p.read_bytes()).hexdigest()
    records.append({"file": p.name, "mpn_from": old, "mpn_to": want,
                    "sha_before": before, "sha_after": after})
    print(f"{item_mpn}: basic_info.mpn {old!r} -> {want!r}")

OUT.write_text(json.dumps({"n": len(records), "items": records},
                          ensure_ascii=False, indent=2), encoding="utf-8")
print("written", OUT)
