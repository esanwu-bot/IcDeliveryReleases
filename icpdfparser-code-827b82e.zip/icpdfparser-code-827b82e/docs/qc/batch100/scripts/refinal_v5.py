# -*- coding: utf-8 -*-
"""batch100 第三次裁决后重定稿（v5）：把 93 件收成 91 件，并保留两种剔除理由。

为什么要单独一个脚本、而不是改 v4 的 final/
------------------------------------------------
§16.2 / §12.4：交付快照只新增不改写。`final/`（93 件）是本轮之前的既有产物，
一旦被覆盖，「谁在哪一版被剔掉」就再也查不到。所以本脚本只往 `final-v5/` 写，
`final/` 原封不动，两版可并排对照。

两种剔除理由必须分开记（这是本脚本存在的第二个理由）
---------------------------------------------------
1. `rule_quarantine`：**工具判出来**的。`AFE7900EVM` 缺 `pin_configuration` /
   `ordering_info`、`manufacturer` 为空、主桶电气 0、引脚 0、正式桶 0 ——
   旧规则靠「是板卡 ∧ 电气 0」把它放进 allowlist，等于让身份把结构缺陷洗白。
   2026-11-04 顶级准入裁定（零电气可豁免、核心结构错误不可豁免）判它隔离。
2. `executive_decision`：**人判出来**的。`ADS1252EVM` 工具判 `normal`
   （电气 55 行、引脚 8、结构过、核心过 —— 闸门按核心设计「身份未知即按芯片」，
   拦不住它），是总裁第三次裁决要求剔除（`identity` 为空，身份契约未成立）。

把两者写成一列「剔除」会让人以为都是工具拦的，复核方一查就对不上。

数据源：`final/manifest.csv`（93 行，v4）+ 回放台账
`docs/qc/tools/replay_batch100/quarantine_ledger.json`（93 件，`icpdf_quarantine 1.1.1`）。
**不手写任何数字**：件数、准入、扣押行、证据全部从这两份产物里读。
"""
from __future__ import annotations

import csv
import datetime as dt
import json
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]                       # docs/qc/batch100
REPO = HERE.parents[4]                       # 仓库根（scripts → batch100 → qc → docs → 根）
SRC = ROOT / "final"
DST = ROOT / "final-v5"
LEDGER = REPO / "docs/qc/tools/replay_batch100/quarantine_ledger.json"

#: 总裁第三次裁决（2026-11-04）点名剔除的件。工具不拦，靠人判，必须单独记。
EXECUTIVE_EXCLUDE = {
    "ADS1252EVM": "identity 为空（身份契约未成立）；总裁第三次裁决剔除，"
                  "把「identity 为空」纳入身份守卫拒绝条件一事留作下一批",
}


def rows(p: Path) -> list[dict]:
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main() -> int:
    man_v4 = rows(SRC / "manifest.csv")
    led = json.loads(LEDGER.read_text(encoding="utf-8"))
    # 对齐键用**文件茎**（manifest.safe_name ↔ 台账.safe），不用 mpn：
    # `ADS1252EVM` 这件在交付清单里叫 EVM（批次表的请求号），而它 JSON 里的
    # `metadata.requested_mpn` 写的是 `ADS1252U`，工具按「请求号优先」就会把它记成
    # ADS1252U。按 mpn 对账会得到「台账缺 1 件」的假故障，实际是同一件两个名字。
    # 这条分歧本身已记入 DIFF.md（OPEN-2），不在脚本里悄悄抹平。
    live = {str(it.get("safe") or it.get("mpn") or ""): it for it in led.get("items") or []}

    missing = [r["safe_name"] for r in man_v4 if r["safe_name"] not in live]
    if missing:
        print(f"[error] 回放台账缺 {len(missing)} 件：{missing[:5]}")
        return 2

    keep: list[dict] = []
    excluded: list[dict] = []
    for r in man_v4:
        mpn = r["mpn"]
        it = live[r["safe_name"]]
        adm = str(it.get("admission") or "")
        ev = {
            "gate_v5": it.get("final_gate_status", ""),
            "admission_v4": r.get("admission", ""),
            "withheld_v5": it.get("withheld", 0),
            "elec_main_v5": it.get("electrical_main", 0),
            "formal_elec_v5": it.get("formal_elec", 0),
            "validate_errors_v5": "；".join(it.get("validate_errors") or []),
            "core_errs_v5": "；".join(it.get("core_errs") or []),
            "override_reason_v5": it.get("override_reason", ""),
        }
        if mpn in EXECUTIVE_EXCLUDE:
            excluded.append({**r, **ev, "excluded_by": "executive_decision",
                             "exclude_reason": EXECUTIVE_EXCLUDE[mpn]})
            continue
        if adm == "quarantine":
            excluded.append({**r, **ev, "excluded_by": "rule_quarantine",
                             "exclude_reason": "准入裁定：核心结构错误不得豁免 —— "
                                               + (ev["validate_errors_v5"] or ev["core_errs_v5"])})
            continue

        # allowlist 的「为什么空」写清楚：真空 / 带扣押行是两种不同的事
        reason = r.get("electrical_empty_reason", "")
        if adm == "allowlist_board":
            n = int(it.get("withheld", 0) or 0)
            reason = (f"board_expected_empty_with_withheld({n})" if n
                      else "board_expected_empty(legacy_pre_guard)")
        keep.append({**r, **ev, "admission": adm, "electrical_empty_reason": reason})

    normal = [r for r in keep if r["admission"] == "normal"]
    allow = [r for r in keep if r["admission"] == "allowlist_board"]
    by_rule = [r for r in excluded if r["excluded_by"] == "rule_quarantine"]
    by_exec = [r for r in excluded if r["excluded_by"] == "executive_decision"]

    DST.mkdir(parents=True, exist_ok=True)

    cols = list(man_v4[0].keys()) + ["gate_v5", "admission_v4", "withheld_v5",
                                     "elec_main_v5", "formal_elec_v5", "validate_errors_v5",
                                     "core_errs_v5", "override_reason_v5"]
    with open(DST / "manifest.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(sorted(keep, key=lambda x: x["mpn"]))

    ecols = list(man_v4[0].keys()) + ["excluded_by", "exclude_reason", "gate_v5",
                                      "admission_v4", "validate_errors_v5", "core_errs_v5",
                                      "elec_main_v5", "formal_elec_v5", "withheld_v5"]
    with open(DST / "excluded.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=ecols, extrasaction="ignore")
        w.writeheader()
        w.writerows(sorted(excluded, key=lambda x: x["mpn"]))

    with open(DST / "allowlist.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["mpn", "identity", "identity_source", "elec_main", "formal_elec",
                    "withheld", "pins", "final_gate_status", "override_reason", "by", "why"])
        for r in sorted(allow, key=lambda x: x["mpn"]):
            it = live[r["safe_name"]]
            n = int(it.get("withheld", 0) or 0)
            w.writerow([r["mpn"], it.get("identity", ""), it.get("identity_source", ""),
                        it.get("electrical_main", 0), it.get("formal_elec", 0), n,
                        it.get("pins", 0), it.get("final_gate_status", ""),
                        it.get("override_reason", ""),
                        f"icpdf_quarantine {led['runs'][-1]['tool'].split()[-1]}（rule v2）",
                        "板卡件：电气在 onboard_device_specs，主桶空是诚实空"
                        + (f"；但有 {n} 行被扣押，交付前须人工确认" if n else "")])

    summary = {
        "revision": "v5-final（第三次裁决 + 准入三分类回放）",
        "generated": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "source_manifest": str((SRC / "manifest.csv").relative_to(REPO)),
        "source_ledger": str(LEDGER.relative_to(REPO)),
        "tool": led["runs"][-1]["tool"],
        "in_package": len(keep),
        "admission": {"normal": len(normal), "allowlist_board": len(allow)},
        "excluded": {"total": len(excluded),
                     "rule_quarantine": [r["mpn"] for r in by_rule],
                     "executive_decision": [r["mpn"] for r in by_exec]},
        "arithmetic": (f"93（v4 入包）− {len(by_rule)}（准入裁定隔离）"
                       f"− {len(by_exec)}（总裁裁决剔除）= {len(keep)}；"
                       f"{len(keep)} = {len(normal)} normal + {len(allow)} allowlist_board"),
        "withheld_in_allowlist": {r["mpn"]: int(live[r["safe_name"]].get("withheld", 0) or 0)
                                  for r in allow
                                  if int(live[r["safe_name"]].get("withheld", 0) or 0)},
        "replay_counts": led.get("counts"),
        "open_items": [
            "allowlist 中带扣押行的件：结论按核心口径（withheld 归薄件类）保留，"
            "但交付前须人工确认这批行该不该放回",
            "identity 为空（ADS1252EVM 类）目前不被闸门拦截：核心设计「真值未知时按芯片」，"
            "要拦需把空身份纳入身份守卫拒绝条件（下一批）",
            "核心侧两套板卡值域不一致：check_core 认 (evaluation_board, reference_design, "
            "module, board)，BOARD_TYPES 是 (evaluation_board, development_kit)；"
            "development_kit 因此会被判核心错并隔离（本批 0 命中，但逻辑上存在）",
            "delivery_bundle 未读 accept_status，本批仍以人工核对 manifest 兜底",
        ],
    }
    (DST / "_refinal_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # 回放台账原样带入：它是结论的唯一证据源，不能只留摘要
    (DST / "quarantine_ledger.json").write_text(
        json.dumps(led, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({k: summary[k] for k in
                      ("in_package", "admission", "excluded", "arithmetic")},
                     ensure_ascii=False, indent=2))
    print(f"written -> {DST}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
