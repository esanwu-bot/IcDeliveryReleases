# -*- coding: utf-8 -*-
"""把 RUN.json 更新到 v5（第三次裁决 + 准入三分类）。

用法：``python docs/qc/batch100/scripts/update_run_v5.py <head_sha> [zip_path] [zip_sha256]``

为什么要脚本：RUN.json 是三百多行的嵌套 JSON，手改一次就会漏一处（上一版就出现过
`final_package` 改了、`allowlist.items` 没改，正文说 93、数组 10 件）。

按用户指令：**删掉旧的 `45eb578` 记录** —— 那是上一版 ZIP 对应的 commit，
留着会让「HEAD ↔ ZIP」指向两个不同的树。历史事实不丢：改记在 `history` 里。
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
REPO = HERE.parents[4]
RUN = ROOT / "RUN.json"
FIN = ROOT / "final-v5"

REMOVED_SHA = "45eb578"
KEY_COMMITS = {
    "b76d513": "落盘前最终复验 + 核心硬错误阻断 + 板卡不得借 ACCEPT_THIN 放行",
    "218d11e": "补第三条写盘路径(batch) + render 缓存前复核 + accept_status 落盘 + 枚举小写",
    "b7bb1e9": "给 6 个真实 PDF 慢用例补 slow 标记",
}


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    head = argv[0]
    zip_path = argv[1] if len(argv) > 1 else ""
    zip_sha = argv[2] if len(argv) > 2 else ""

    d = json.loads(RUN.read_text(encoding="utf-8"))
    sm = json.loads((FIN / "_refinal_summary.json").read_text(encoding="utf-8"))
    allow = json.loads(json.dumps(sm["admission"]))
    led_counts = sm.get("replay_counts") or {}

    # ---- code：HEAD 与 ZIP 一一对应，旧的 45eb578 记录删掉 ----
    chain = [s for s in (d.get("code", {}).get("commit_chain") or []) if s != REMOVED_SHA]
    if head not in chain:
        chain.append(head)
    key = {k: v for k, v in (d.get("code", {}).get("key_commits") or {}).items()
           if k != REMOVED_SHA}
    key.update(KEY_COMMITS)
    key[head] = "准入三分类（板卡零电气可豁免、核心结构错误不可豁免）+ 回放差异台账 + 91 件重定稿"
    d["code"] = {
        "head_sha": head,
        "commit_chain": chain,
        "key_commits": key,
        "removed_record": {"sha": REMOVED_SHA,
                           "why": "上一版 ZIP 对应的树；任务要求删掉，避免 HEAD 与 ZIP 指向两棵树。"
                                  "该版做的事已并入 v5 说明，历史不改写"},
        "zip": {"path": zip_path, "sha256": zip_sha, "sha256_outside": True,
                "why_no_sha_inside": "ZIP 内写不进自己的哈希（内容变则哈希变）；"
                                     "哈希由 .sha256 文件与本次回执在包外回填"},
    }

    d["revision"] = "v5-final（第三次裁决 + 准入三分类回放）"
    d["status"] = (
        "FINAL — 5 个 P0 已修复并有红先用例锁定；准入三分类在 93 件真实数据上回放通过；"
        "交付物按第三次裁决重定稿为 91 件（82 normal + 9 allowlist_board）；"
        "发布动作本身仍待 Reviewer 签核。下一批开工前必须先修 delivery_bundle 的 accept_status 读取"
    )

    d["final_package"] = {
        "in_package": sm["in_package"],
        "admission": sm["admission"],
        "excluded": sm["excluded"],
        "quarantined": 3,
        "unparsed_failed": 4,
        "arithmetic": sm["arithmetic"],
        "previous_version": {
            "revision": "v4-final（第二次裁决后）",
            "in_package": 93, "admission": {"normal": 83, "allowlist_board": 10},
            "snapshot": "docs/qc/batch100/final/（原样保留，§16.2 只新增不改写）",
        },
    }

    d["allowlist"] = {
        "n": sm["admission"]["allowlist_board"],
        "rule": "v3（2026-11-04 顶级准入裁定）：identity ∈ BOARD_TYPES ∧ 主桶 electrical == 0 ∧ "
                "无核心硬错 ∧ 除板卡零电气外无其他结构错误（由 final_gate 复核判定）",
        "rule_history": {
            "v1": "identity ∈ BOARD_TYPES ∧ electrical==0 ∧ pins==0（命中 9 件，漏 BOOSTXL-DRV8320H）",
            "v2": "去掉 pins==0（命中 10 件，含 AFE7900EVM —— 该件有真实结构错误，v3 已剔除）",
            "v3": "加闸门复核：把身份抹掉再问一次 final_gate，判 thin_accepted 才算只有零电气类错误"
                  "（命中 9 件，AFE7900EVM 出局）",
        },
        "items": [r["mpn"] for r in
                  csv.DictReader(open(FIN / "allowlist.csv", encoding="utf-8"))],
        "withheld_needs_human": sm.get("withheld_in_allowlist") or {},
        "semantics": "允许交付，但不得计入 ok 分母；manifest 标 admission=allowlist_board",
    }

    d["replay"] = {
        "tool": sm["tool"],
        "src": "icpdf-server:/app/data/batch100_20261104/stage（parsed 93 / pdfs 93）",
        "counts": led_counts,
        "vs_v4": {"normal": "83 → 83", "allowlist_board": "10 → 9", "quarantine": "0 → 1",
                  "changed": ["AFE7900EVM：allowlist_board → quarantine（缺 pin_configuration / "
                              "ordering_info、manufacturer 空、主桶电 0、引脚 0、正式桶 0）"]},
        "artifacts": ["docs/qc/tools/replay_batch100/DIFF.md",
                      "docs/qc/tools/replay_batch100/quarantine_ledger.json",
                      "docs/qc/tools/replay_batch100/quarantine.csv"],
        "verdict": "不放水：没有为凑齐 10 件 allowlist 而放宽判据",
    }

    d["decisions_3rd_round"] = {
        "at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "by": "总裁（2026-11-04 晚）",
        "items": [
            {"decision": "剔除 ADS1252EVM（原话「应该是 92 件，因为要剔除 ADS1252EVM」）",
             "effect": "该件 identity 为空，属身份契约未成立；由交付层裁决剔除",
             "note": "⚠️ 与第二次裁决的「ADS1252EVM 留作下一批改进项」相反，本版以最新指令为准；"
                     "改判记录在 final-v5/excluded.csv 的 excluded_by=executive_decision",
             "revert": "若要恢复，删掉 refinal_v5.py 的 EXECUTIVE_EXCLUDE 条目重跑即可"},
            {"decision": "准入裁定落地：板卡零电气可豁免、核心结构错误不可豁免",
             "effect": "AFE7900EVM 被工具隔离，件数由 93 → 91（82 + 9）",
             "note": "这不是「扣件」，是旧规则把它错放进了 allowlist"},
        ],
        "count_change": "93 → 91（−1 规则隔离 −1 裁决剔除）",
    }

    d["open_for_reviewer"] = [
        {"id": "OPEN-1", "topic": "核心侧两套板卡值域不一致",
         "detail": "BOARD_TYPES=(evaluation_board, development_kit) vs check_core 内联 "
                   "(evaluation_board, reference_design, module, board)；development_kit 必被判核心错",
         "owner": "核心口径"},
        {"id": "OPEN-2", "topic": "ADS1252EVM（清单）vs ADS1252U（JSON requested_mpn）命名分歧",
         "detail": "按 mpn 对账会得到「台账缺 1 件」的假故障；本版改用文件茎对齐", "owner": "数据侧"},
        {"id": "OPEN-3", "topic": "withheld_in_quarantine 与「电气不足」同属薄件类",
         "detail": "板卡带扣押行仍可 allowlist（本批 2 件：241 行 / 31 行），需业务拍板",
         "owner": "业务侧"},
        {"id": "BLOCK-1", "topic": "delivery_bundle 未读 accept_status",
         "detail": "下一批开工前必修；本批以人工核对 manifest 兜底", "owner": "工具侧"},
    ]

    # history 在 v4 里是**对象**（stop_and_resume / corrections / rounds），不是数组。
    # 强行 append 会把它覆盖成列表，等于把「上一轮为什么停手」的现场抹掉。
    hist = d.setdefault("history", {})
    if not isinstance(hist, dict):
        hist = {"legacy": hist}
        d["history"] = hist
    rounds = list(hist.get("rounds") or [])
    rounds.append(f"第十三轮：91 件（82 + 9）—— 准入三分类落地，AFE7900EVM 规则隔离、"
                  f"ADS1252EVM 裁决剔除")
    hist["rounds"] = rounds

    RUN.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"RUN.json -> {d['revision']}")
    print(f"  in_package={sm['in_package']} admission={sm['admission']} "
          f"excluded={sm['excluded']}")
    print(f"  head={head} zip={zip_path or '(待回填)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
