# batch100 收网脚本（一次性驱动，供复核用）

这些脚本**不在应用代码路径内**，只在服务器 `icpdf-server` 容器里跑过一次，用来把
解析产物装配成正式包、补缺口、定稿。放进来是为了让 Reviewer 能按同样的步骤复现
数字，而不是信一段描述。

运行环境：容器 `icpdf-server`（`/www/wwwroot/icpdfparser/data` 挂到 `/app/data`），
工作目录 `/app`。宿主机路径与容器路径不同，脚本里凡是从 `results.csv` 读出的
`json_path` 都先做一次 `/www/wwwroot/icpdfparser/` → `/app/` 归一。

执行顺序：

| 步 | 脚本 | 作用 | 产物 | 幂等 |
|---|---|---|---|---|
| 1 | `fix_mpn_field.py` | 给 `AFE7900EVM` 补 `basic_info.mpn`（原为 `None`，装配索引收不到它） | 改前 `.json.bak`、`_identity_fix.json`（含改前后 sha256） | 是（已是目标值则跳过） |
| 2 | `stage_gap.py --dry` | 只验件名能否定位 JSON、缺口几件 | 终端输出 | 是（只读） |
| 3 | `stage_gap.py` | 只装缺口 3 件；装完对已有 92 件逐个复算 sha256 | `stage_gap/`、`_gap_merge_check.json` | 否（重跑会重装缺口目录） |
| 4 | `finalize_pkg.py --dry` | 预演定稿：谁隔离、谁准入 | 终端输出 | 是（不动文件） |
| 5 | `finalize_pkg.py` | 3 件 core 错件移入 `_quarantine/`；9 件板卡写 allowlist；补 `outcome_source`；出 `manifest.csv` | `manifest.csv`、`allowlist.csv`、`ledger_core_fail.json`、`results_enriched.csv`、`_finalize_summary.json` | 否（第二次跑 ledger 为空，脚本有守卫不覆盖） |
| 6 | `fix_manifest.py` | 修 `core_validation` 列把 `"pass"` 当列表逐字符 join 的串字问题 | 覆盖 `manifest.csv` | 是 |
| 7 | `stage_extra.py <mpn>` | 第二次裁决后补装：**先现场复判**（validate + core + final_gate），过了才装；同时把批次表 `failed → done` 并写改判台账 | `stage_extra/`、`_amend_supplement.json`、`_supp_merge_check.json` | 否（重跑会重装补装目录） |
| 8 | `mk_checklist.py` | 从 `final/` 快照生成 `CHECKLIST_FINAL.md`，数字全部读产物、不手写 | `CHECKLIST_FINAL.md` | 是 |

两个坑写在脚本注释里，别踩第二次：

1. `results.csv` 的 `json_path` 是**宿主机绝对路径**，容器内不存在。不归一的话
   `finalize_pkg.py` 会把 95 件全判成 `missing`。
2. `outcome_source` 不能用 mtime 判新旧——整批 JSON 都是当天落盘，mtime 零区分度。
   用 `metadata.parse_timestamp` 与 `prompt_version` 双向核对。
3. `core_validation` 在记录里既可能是 `"pass"` 字符串也可能是错误列表，
   `"; ".join()` 直接套会得到 `p; a; s; s`。
