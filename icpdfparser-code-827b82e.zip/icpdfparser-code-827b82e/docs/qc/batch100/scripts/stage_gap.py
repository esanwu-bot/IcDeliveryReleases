# -*- coding: utf-8 -*-
"""增量装配：只补 3 件缺口，其余 92 件一个字节不动。

前置（Reviewer 要求）：
  1. 键修好 —— `--mpns` 传**件 mpn**（v1 传 doc_mpn，5 件 done 挤成 2 条）。
  2. dry 先验证 95 个件名全部能定位到 JSON，再花时间装。
  3. 只装缺口；装完对 92 件逐个复算 sha256，证明没被这次合并改到。
"""
from __future__ import annotations

import csv, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path("/app")
B = ROOT / "data/batch100_20261104"
STAGE = B / "stage"
GAPDIR = B / "stage_gap"
PARSED = ROOT / "data" / "parsed"
sys.path.insert(0, "/app")
from app.services.parts import safe_name            # noqa: E402

DRY = "--dry" in sys.argv


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    rows = [r for r in csv.DictReader(open(B / "results.csv", encoding="utf-8"))
            if (r.get("status") or "").strip() == "done"]
    expected = [r["mpn"] for r in rows]
    rep = json.loads((STAGE / "_stage_report.json").read_text(encoding="utf-8"))

    # ---- 0. 记录名归一：v1 按 doc_mpn 命名，AFE7950EVM 被记成 AFE7950、
    # ADS1252EVM 被记成 ADS1252U。记录名必须回到**件 mpn**，否则同一个件会被
    # 判成"缺口"再装一遍，正式包里出现两条记录指向同一份产物。
    # 只改 _stage_report.json 里的 mpn 字段，产物文件一个字节不动。
    sample = json.loads((B / "sample.json").read_text(encoding="utf-8"))
    doc_of = {it["mpn"]: (it.get("doc_mpn") or it["mpn"]) for it in sample["items"]}
    by_name = {r["mpn"]: r for r in rep["records"]}
    renamed = []
    for mpn, doc_name in doc_of.items():
        if mpn in by_name or doc_name not in by_name or doc_name == mpn:
            continue
        rec = by_name[doc_name]
        rec["doc_mpn"] = doc_name
        rec["mpn"] = mpn
        renamed.append(f"{doc_name} -> {mpn}")
    if renamed:
        print("记录名归一:", "; ".join(renamed))
        (STAGE / "_stage_report.json").write_text(
            json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    have = {r["mpn"] for r in rep["records"]}

    # ---- 1. dry：95 个件名能不能全部定位到 JSON ----
    unresolved, mapping = [], {}
    for mpn in expected:
        hits = sorted(PARSED.glob(safe_name(mpn) + "_*.json"))
        if hits:
            mapping[mpn] = hits[-1].name
        else:
            unresolved.append(mpn)
    print(f"件 mpn 定位：{len(mapping)}/{len(expected)} 命中，未命中 {len(unresolved)}")
    for m in unresolved:
        print("  未命中:", m)
    if DRY:
        gap = [m for m in expected if m not in have]
        print(f"缺口 {len(gap)} 件: {gap}")
        return 0 if not unresolved else 1
    if unresolved:
        print("有件名定位不到 JSON，拒绝继续（先修键，不是先花 40 分钟）")
        return 2

    gap = [m for m in expected if m not in have]
    print(f"缺口 {len(gap)} 件: {gap}", flush=True)
    if not gap:
        print("无缺口，不需要装配")
        return 0

    # ---- 2. 只装缺口 ----
    if GAPDIR.exists():
        shutil.rmtree(GAPDIR)
    t0 = time.time()
    p = subprocess.run([sys.executable, "qc/stage_release.py",
                        "--src", "data/parsed", "--out", str(GAPDIR), "--force",
                        "--alts-from", "data/alts", "--pdf-dir", "data/pdfs",
                        "--mpns", ",".join(gap)],
                       cwd=str(ROOT), capture_output=True, text=True)
    print(f"--- gap stage_release rc={p.returncode} 用时 {time.time()-t0:.1f}s ---", flush=True)
    print((p.stdout or "").strip()[-800:])
    if p.returncode != 0:
        print((p.stderr or "")[-800:], file=sys.stderr)
        return 3

    gap_rep = json.loads((GAPDIR / "_stage_report.json").read_text(encoding="utf-8"))
    got = [r["mpn"] for r in gap_rep["records"]]
    print(f"缺口装配实得 {len(got)} 件: {got}")
    if set(got) != set(gap):
        print("缺口集合不符，停止合并（缺", sorted(set(gap) - set(got)), "多", sorted(set(got) - set(gap)), "）")
        return 4

    # ---- 3. 合并前快照 92 件的哈希 ----
    before = {p.name: sha(p) for p in sorted((STAGE / "parsed").glob("*.json"))}
    print(f"合并前 92 件快照：{len(before)} 个 JSON")

    for sub in ("parsed", "pdfs", "seo"):
        if not (GAPDIR / sub).is_dir():
            continue
        (STAGE / sub).mkdir(parents=True, exist_ok=True)
        for f in (GAPDIR / sub).iterdir():
            if f.is_file():
                shutil.copy2(f, STAGE / sub / f.name)

    rep["records"].extend(gap_rep["records"])
    rep["gap_assembly"] = {"mpns": gap, "at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                           "wall_s": round(time.time() - t0, 1)}
    (STAGE / "_stage_report.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- 4. 合并后复核：92 件逐个哈希必须一致 ----
    after = {p.name: sha(p) for p in sorted((STAGE / "parsed").glob("*.json"))}
    changed = [n for n, h in before.items() if after.get(n) != h]
    added = sorted(set(after) - set(before))
    check = {"before_n": len(before), "after_n": len(after),
             "changed": changed, "added": added,
             "verdict": "PASS" if not changed and set(added) == set(
                 f"{safe_name(m)}.json" for m in gap) else "FAIL"}
    (B / "_gap_merge_check.json").write_text(
        json.dumps(check, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"合并核对：变更 {len(changed)} 个（必须 0）/ 新增 {len(added)} 个 -> {check['verdict']}")
    print(f"正式包现有 {len(rep['records'])} 条记录")
    return 0 if check["verdict"] == "PASS" else 5


if __name__ == "__main__":
    raise SystemExit(main())
