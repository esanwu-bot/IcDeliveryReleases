# `thin_accepted` 的语义与下游消费约定

适用范围：`parse_datasheets.final_gate()` 产出的四种落盘状态之一。
本文件是**约定**，不是描述现状——凡与本文件冲突的实现，按本文件改。

## 1. 它是什么

`thin_accepted` 只在一个很窄的条件下产生（三条同时成立）：

1. `validate(最终落盘稿)` 有错，但**错只属于**两类："`specs.electrical only`"（电气规格条目不足）
   或 "`withheld_in_quarantine`"（有内容被隔离区扣下）；
2. 该件被判定为「合法薄件」：`ACCEPT_THIN` 打开且 `_thin_doc_ok(doc)`，或文件名/正文命中 `accept_thin()`；
3. **身份不是板卡/开发板**（`_identity_is_board()` 为假）。

换句话说：**"它是真芯片，只是这份 datasheet 里规格少"**。
板卡不再能走这条路——那是 2026-11-04 修的语义错位，守卫在 `parse_datasheets.py:1444`。

## 2. 为什么不能当 `ok`

`ok` 的含义是「结构无错 ∧ 核心字段无错」，下游据此可以宣称"字段齐全"。
`thin_accepted` 明确承认了"电气条目不足"，把它并入 `ok` 等于把已知缺陷洗成合格。

因此三条硬约束：

| # | 约束 | 违反后果 |
|---|---|---|
| 1 | **不得计入 ok 分母**。任何"合格率""字段齐全率"的分母是 `count(accept_status == "ok")` | 合格率虚高，且无法从报表里还原 |
| 2 | **必须逐件标列**。装配产物里每件都要能查到 `accept_status`，不得只写汇总数 | 出了争议无法定位是哪几件 |
| 3 | **不得出现在"字段齐全/可直接对外"的话术里**。对外表述必须写"规格不全" | 客户侧预期错位，属交付事故 |

## 3. 下游消费（按当前代码实况）

| 消费方 | 现状 | 约定 |
|---|---|---|
| `parse_datasheets.parse_one` | 写 `metadata.accept_status`，`thin_accepted` 时不写 `accept_core_errs` | 保持。落盘状态是唯一权威 |
| `app/services/pipeline.parse_pdf` | 同 `parse_one`，同一道 `final_gate` | 保持 |
| `app/services/batch.ingest` | 同闸；`failed` 直接 `touch_status(..., "failed")` 不落盘 | 保持 |
| `app/pipeline/contracts.py` | 状态映射把 `thin_accepted` → `STATUS_OK`（阶段层**不缩面**，避免整条流水线因"规格少"停摆） | 允许，但仅限**阶段推进**用途；不得据此回写 `accept_status` |
| `app/pipeline/stages.py::render_gate` | 带 `parsed_core_fail` 章的拒；`thin_accepted` 放行 | 保持 |
| `qc/stage_release.py` | **不读 status**，只按 `basic_info.mpn` 建索引并自行重算 `core_validation` | 准入标记必须由装配侧**显式写列**（`manifest.csv` 的 `admission` / `electrical_empty_reason`），不能指望 status 自动传下去 |
| `delivery_bundle`（交付打包） | **未显式处理** | 阻断项：下一批开工前必须让它读 `accept_status` 并分开列账，否则 `thin_accepted` 件会被当普通件打进对外包 |

## 4. 与「板卡 allowlist」的区别

两者都"允许交付但不算 ok"，但成因不同，不得混为一谈：

- `thin_accepted`：**判据层面**的结论，来自 `final_gate`，落在 `metadata.accept_status`；
- `allowlist_board`：**装配层面**的人工准入，来自批次裁决，落在 `manifest.csv` 的 `admission`。
  这类件 JSON 里 `accept_status` 通常是 `ok`（板卡的电气表本来就不存在，不构成 `specs.electrical only` 错），
  所以它**绕过了状态机**，只能靠装配侧标列兜住。判据为
  `identity in BOARD_TYPES ∧ electrical == 0`（2026-11-04 第二次裁决把 `pins == 0` 去掉：
  板卡有引脚但电气表不存在，同属诚实空）。

结论：状态机管不了板卡，装配侧必须自己标；状态机管得了薄件，装配侧必须把状态透传出来。
两条路都得有，不能只做一条。

## 5. 本轮（batch100）实况

- `thin_accepted`：**0 件**。93 件里没有一件走这条路，所以 manifest 暂未加 `accept_status` 列；
- `allowlist_board`：**10 件**，见 `final/manifest.csv` 与 `final/allowlist.csv`；
- 本批 `delivery_bundle` 未修，按裁决以**人工核对 manifest** 兜底；修好前下一批不启动。
- 下一批开工前置：`delivery_bundle` 补读 `accept_status`，manifest 增 `accept_status` 列；
  另把「`identity` 为空」纳入身份守卫的拒绝条件（本批 `ADS1252EVM` 即此形态）。
