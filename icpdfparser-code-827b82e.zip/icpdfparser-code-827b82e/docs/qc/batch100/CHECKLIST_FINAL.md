# batch100 正式包终版清单（v5）

生成时间：2026-11-04 18:14　口径：`final_gate` + 身份守卫 + **2026-11-04 顶级准入裁定（板卡零电气可豁免、核心结构错误不可豁免）**

> **本版与 v4 的差别**：v4 是 93 件（83 normal + 10 allowlist）；本版是 **91 件（82 normal + 9 allowlist_board）**，剔掉 2 件，两种理由分别记账（见附表 A）。逐件回放差异见 `docs/qc/tools/replay_batch100/DIFF.md`。

## 0. 数字总账

| 项 | 数量 | 说明 |
|---|---|---|
| 本版入包 | **91** | `final-v5/manifest.csv` 行数 |
| 其中普通准入 | 82 | `admission=normal` |
| 其中带标记准入 | 9 | `admission=allowlist_board`，逐件见附表 B |
| 本版剔除 | 2 | 准入裁定 1 + 总裁裁决 1，见附表 A |
| 上版（v4）入包 | 93 | 保留在 `final/`，未改写（§16.2 只新增不改写） |

核算：**93（v4 入包）− 1（准入裁定隔离）− 1（总裁裁决剔除）= 91**。

## 1. 正式包逐件

| # | mpn | identity | 主桶电 | 正式桶 | pins | 闸门 | admission |
|---|---|---|---|---|---|---|---|
| 1 | 74AC11800DW | chip | 16 | 16 | 24 | ok | normal |
| 2 | 74ACT11011N | chip | 24 | 24 | 16 | ok | normal |
| 3 | 74ACT11020DR | chip | 20 | 20 | 20 | ok | normal |
| 4 | 74ACT11132D | chip | 22 | 22 | 16 | ok | normal |
| 5 | 74AVC4T245DGVRE4 | chip | 35 | 35 | 16 | ok | normal |
| 6 | 74AVC4T245RGYRG4 | chip | 35 | 35 | 16 | ok | normal |
| 7 | 74AVC4T245RSVR-NT | chip | 35 | 35 | 16 | ok | normal |
| 8 | 74AVC4T245RSVRG4 | chip | 35 | 35 | 16 | ok | normal |
| 9 | 74FCT162245CTPVCT | chip | 39 | 39 | 48 | ok | normal |
| 10 | 74FCT16244CTPVCTG4 | chip | 66 | 66 | 48 | ok | normal |
| 11 | ADC07D1520CIYB/NOPB | chip | 76 | 76 | 10 | ok | normal |
| 12 | ADC07D1520RB/NOPB | chip | 67 | 67 | 10 | ok | normal |
| 13 | ADC1061CIWM | chip | 37 | 37 | 20 | ok | normal |
| 14 | ADC12DL1500ACF | chip | 49 | 49 | 136 | ok | normal |
| 15 | ADC12DL2500ACF | chip | 134 | 134 | 136 | ok | normal |
| 16 | ADC32RF80IRMPR | chip | 54 | 54 | 72 | ok | normal |
| 17 | ADC32RF80IRMPT | chip | 46 | 46 | 72 | ok | normal |
| 18 | ADC32RF80IRRHR | chip | 42 | 42 | 72 | ok | normal |
| 19 | ADC32RF83IRMPT | chip | 58 | 58 | 72 | ok | normal |
| 20 | ADC32RF83IRRHR | chip | 42 | 42 | 72 | ok | normal |
| 21 | ADC700JH | chip | 70 | 70 | 28 | ok | normal |
| 22 | ADS1286U | chip | 61 | 61 | 8 | ok | normal |
| 23 | ADS1286U/2K5G4 | chip | 60 | 60 | 8 | ok | normal |
| 24 | ADS1286UB/2K5 | chip | 60 | 60 | 8 | ok | normal |
| 25 | ADS1286UC/2K5 | chip | 62 | 62 | 8 | ok | normal |
| 26 | ADS1286UG4 | chip | 60 | 60 | 8 | ok | normal |
| 27 | ADS1286UK | chip | 60 | 60 | 8 | ok | normal |
| 28 | ADS58J64IRMPR | chip | 25 | 25 | 72 | ok | normal |
| 29 | ADS58J64IRMPT | chip | 31 | 31 | 72 | ok | normal |
| 30 | ADS58J64IRRHR | chip | 31 | 31 | 72 | ok | normal |
| 31 | ADS58J64IRRHT | chip | 33 | 33 | 72 | ok | normal |
| 32 | ADS7815UE4 | chip | 52 | 52 | 28 | ok | normal |
| 33 | ADS7818P | chip | 59 | 59 | 8 | ok | normal |
| 34 | ADS7820P | chip | 55 | 55 | 28 | ok | normal |
| 35 | ADS7820PB | chip | 55 | 55 | 28 | ok | normal |
| 36 | AFE7950EVM | evaluation_board | 0 | 101 | 0 | ok | allowlist_board |
| 37 | BOOSTXL-DRV8320H | evaluation_board | 0 | 0 | 42 | failed | allowlist_board |
| 38 | BQ2201PN | chip | 32 | 32 | 8 | ok | normal |
| 39 | BQ2201PNG4 | chip | 32 | 32 | 8 | ok | normal |
| 40 | BQ2201SN | chip | 33 | 33 | 8 | ok | normal |
| 41 | BQ2201SN-NG4 | chip | 33 | 33 | 8 | ok | normal |
| 42 | BQ2201SNG4 | chip | 28 | 28 | 8 | ok | normal |
| 43 | BQ24261MYFFR | chip | 200 | 200 | 36 | ok | normal |
| 44 | BQ24261MYFFT | chip | 178 | 178 | 36 | ok | normal |
| 45 | BQ24261RGET | chip | 190 | 190 | 20 | ok | normal |
| 46 | BQ24261YFFT | chip | 192 | 192 | 36 | ok | normal |
| 47 | BQ24262RGER | chip | 192 | 192 | 20 | ok | normal |
| 48 | BQ24262YFFR | chip | 64 | 64 | 36 | ok | normal |
| 49 | BQ24450EVM-691 | evaluation_board | 0 | 4 | 0 | ok | allowlist_board |
| 50 | BQ3285LDSS | chip | 13 | 13 | 24 | ok | normal |
| 51 | BQ3285LFSS-A1 | chip | 18 | 18 | 24 | ok | normal |
| 52 | BQ48SH-28X6NSH | chip | 17 | 17 | 2 | ok | normal |
| 53 | BQ76PL455EVM | evaluation_board | 5 | 5 | 0 | ok | normal |
| 54 | CD4021BQDRQ1 | chip | 48 | 48 | 16 | ok | normal |
| 55 | DAC39RF10ACK | chip | 118 | 118 | 27 | ok | normal |
| 56 | DAC39RF10ACLNSP | chip | 116 | 116 | 54 | ok | normal |
| 57 | DAC39RF12ACL | chip | 91 | 91 | 27 | ok | normal |
| 58 | DAC39RFS10ACL | chip | 116 | 116 | 27 | ok | normal |
| 59 | DAC39RFS12ACK | chip | 110 | 110 | 27 | ok | normal |
| 60 | DAC725JP | chip | 33 | 33 | 28 | ok | normal |
| 61 | DAC7541AJUG4 | chip | 52 | 52 | 18 | ok | normal |
| 62 | DAC7541AKPG4 | chip | 29 | 29 | 18 | ok | normal |
| 63 | DAC7541AKU/1K | chip | 26 | 26 | 18 | ok | normal |
| 64 | DAC7541AKU/1KG4 | chip | 26 | 26 | 18 | ok | normal |
| 65 | DRV10963JMDSNT | chip | 35 | 35 | 10 | ok | normal |
| 66 | DRV10963JUDSNR | chip | 29 | 29 | 10 | ok | normal |
| 67 | DRV10963JUDSNT | chip | 35 | 35 | 10 | ok | normal |
| 68 | DRV10963PDSNR | chip | 29 | 29 | 10 | ok | normal |
| 69 | DRV10963PDSNT | chip | 27 | 27 | 10 | ok | normal |
| 70 | DS14C89AM | chip | 30 | 30 | 14 | ok | normal |
| 71 | DS14C89AM/NOPB | chip | 30 | 30 | 14 | ok | normal |
| 72 | DS14C89AMX | chip | 30 | 30 | 14 | ok | normal |
| 73 | DS14C89AMX/NOPB | chip | 30 | 30 | 14 | ok | normal |
| 74 | EKB-UCOS3-EVM | evaluation_board | 0 | 0 | 0 | failed | allowlist_board |
| 75 | LM3208TLEV | chip | 6 | 6 | 8 | ok | normal |
| 76 | LM3352-3.0EVAL | evaluation_board | 0 | 17 | 0 | ok | allowlist_board |
| 77 | LM358 | chip | 48 | 48 | 8 | ok | normal |
| 78 | LM3658SDEV/NOPB | chip | 115 | 115 | 10 | ok | normal |
| 79 | LM3671TL-1.8EV | chip | 12 | 12 | 5 | ok | normal |
| 80 | LM3676SD-ADJEV | chip | 9 | 9 | 8 | ok | normal |
| 81 | LM3677LE-1.8EV | chip | 6 | 6 | 5 | ok | normal |
| 82 | LM3677TL-1.8EV | chip | 4 | 4 | 5 | ok | normal |
| 83 | LM5064EVK/NOPB | evaluation_board | 0 | 10 | 0 | ok | allowlist_board |
| 84 | LM5066EVK/NOPB | evaluation_board | 0 | 12 | 0 | ok | allowlist_board |
| 85 | LMR14206XMKDEMO/NOPB | chip | 18 | 18 | 6 | ok | normal |
| 86 | LMZ10504DEMO/NOPB | chip | 9 | 9 | 8 | ok | normal |
| 87 | LMZ14203DEMO/NOPB | chip | 7 | 7 | 7 | ok | normal |
| 88 | TPS2391EVM | evaluation_board | 0 | 4 | 0 | ok | allowlist_board |
| 89 | TPS65130EVM-063 | evaluation_board | 7 | 7 | 0 | ok | normal |
| 90 | TPS65131EVM-063 | evaluation_board | 0 | 5 | 0 | ok | allowlist_board |
| 91 | TUSB9261DEMO | chip | 38 | 38 | 65 | ok | normal |

## 附表 A：本版剔除件（两种理由，不得合并叙述）

| mpn | 剔除理由 | 闸门 | 旧准入 | 主桶电 | 正式桶 | pins | 证据 |
|---|---|---|---|---|---|---|---|
| ADS1252EVM | **总裁裁决剔除** | ok | normal | 55 | 55 | 8 | identity 为空（身份契约未成立）；总裁第三次裁决剔除，把「identity 为空」纳入身份守卫拒绝条件一事留作下一批 |
| AFE7900EVM | **准入裁定隔离** | failed | allowlist_board | 0 | 0 | 0 | missing key: pin_configuration；missing key: ordering_info；basic_info.manufacturer empty；specs.electrical only 0 items (<3) |

- **准入裁定隔离（工具判的）**：板卡身份不豁免结构缺陷。`AFE7900EVM` 缺 `pin_configuration`、缺 `ordering_info`、`manufacturer` 为空、主桶电气 0、引脚 0、正式桶 0 —— 旧规则「是板卡 ∧ 电气 0」把它洗进 allowlist，新规则判隔离。**没有为了凑齐 10 件 allowlist 放水。**
- **总裁裁决剔除（人判的）**：`ADS1252EVM` 的 `identity` 为空，身份契约未成立。工具判 `ok`（电气 55 行、引脚 8、结构核心均过）—— 闸门按核心设计「身份真值未知时按芯片对待」，**拦不住它**，只能由交付层裁决剔除。把「identity 为空」写进身份守卫拒绝条件属下一批改动。

## 附表 B：带标记准入件（板卡电气为空）

| mpn | identity | 主桶电 | 正式桶 | 扣押行 | pins | 闸门 | 标记 |
|---|---|---|---|---|---|---|---|
| AFE7950EVM | evaluation_board | 0 | 101 | 0 | 0 | ok | allowlist_board |
| BOOSTXL-DRV8320H | evaluation_board | 0 | 0 | 241 | 42 | failed | allowlist_board |
| BQ24450EVM-691 | evaluation_board | 0 | 4 | 0 | 0 | ok | allowlist_board |
| EKB-UCOS3-EVM | evaluation_board | 0 | 0 | 31 | 0 | failed | allowlist_board |
| LM3352-3.0EVAL | evaluation_board | 0 | 17 | 0 | 0 | ok | allowlist_board |
| LM5064EVK/NOPB | evaluation_board | 0 | 10 | 0 | 0 | ok | allowlist_board |
| LM5066EVK/NOPB | evaluation_board | 0 | 12 | 0 | 0 | ok | allowlist_board |
| TPS2391EVM | evaluation_board | 0 | 4 | 0 | 0 | ok | allowlist_board |
| TPS65131EVM-063 | evaluation_board | 0 | 5 | 0 | 0 | ok | allowlist_board |

准入语义：**允许交付，但不得计入 ok 分母**。其中 7 件闸门直接 `ok`（有板载器件电气表），2 件闸门 `failed` 后经复核确认「只有板卡零电气这一类错误」才放行。

## 附表 C：带扣押行的准入件（交付前须人工确认）

| mpn | 扣押行 | pins | 风险 |
|---|---|---|---|
| BOOSTXL-DRV8320H | **241** | 42 | 主桶为空不是「真空」，是抽到后被列塌缩闸门扣下 |
| EKB-UCOS3-EVM | **31** | 0 | 主桶为空不是「真空」，是抽到后被列塌缩闸门扣下 |

结论未改（`final_gate` 把 `withheld_in_quarantine` 与「电气不足」同归薄件类），但台账 / `allowlist.csv` / 命令行三处都显式写明扣押行数。这批行该不该放回，需业务侧确认。

## 附表 D：回放结论（93 件全量，含本版剔除件）

| 准入 | 件数 |
|---|---|
| allowlist_board | 9 |
| normal | 83 |
| quarantine | 1 |

回放工具：`icpdf_quarantine 1.1.1`；装配根：生产容器 `batch100_20261104/stage`（parsed 93 / pdfs 93）；核心校验按**装配口径**（带 PDF，源文档无 thermal/ESD 表记 `not_applicable`）。

## 附表 E：待裁的核心侧问题（不在本版修）

| 编号 | 问题 | 影响 |
|---|---|---|
| — | allowlist 中带扣押行的件：结论按核心口径（withheld 归薄件类）保留，但交付前须人工确认这批行该不该放回 | 见 `DIFF.md` §6 |
| — | identity 为空（ADS1252EVM 类）目前不被闸门拦截：核心设计「真值未知时按芯片」，要拦需把空身份纳入身份守卫拒绝条件（下一批） | 见 `DIFF.md` §6 |
| — | 核心侧两套板卡值域不一致：check_core 认 (evaluation_board, reference_design, module, board)，BOARD_TYPES 是 (evaluation_board, development_kit)；development_kit 因此会被判核心错并隔离（本批 0 命中，但逻辑上存在） | 见 `DIFF.md` §6 |
| — | delivery_bundle 未读 accept_status，本批仍以人工核对 manifest 兜底 | 见 `DIFF.md` §6 |

## 附表 F：可复现命令

```bash
# 1) 回放（容器内，带 PDF 证据）
docker exec icpdf-server sh -c 'cd /app && PYTHONPATH=/tmp/newpd:/tmp/newroot:/app \
  python /tmp/newpd/icpdf_quarantine.py \
  --src /app/data/batch100_20261104/stage --out /tmp/replay2 --json'
# 2) 重定稿（本地，读回放台账 → final-v5）
python docs/qc/batch100/scripts/refinal_v5.py
# 3) 出清单
python docs/qc/batch100/scripts/mk_checklist_v5.py
```

产物快照：`final-v5/`（manifest / excluded / allowlist / 台账 / 摘要）。上版 `final/` 原样保留。

