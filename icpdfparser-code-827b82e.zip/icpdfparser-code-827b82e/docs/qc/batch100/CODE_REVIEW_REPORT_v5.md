# batch100 代码审查报告（v5）

**审查对象**：`parse_datasheets` 最终闸门 / 三条写盘路径 / 准入分流工具
**审查基准**：HEAD 之前的 `b76d513`、`218d11e` + 本轮 `tools/icpdf_quarantine.py`（1.1.1）
**结论**：5 个 P0 全部修复并有红先用例锁定；数据侧按新规则重定稿为 **91 件（82 normal + 9 allowlist_board）**；
4 条未修项已登记待裁（3 条核心侧口径、1 条工具侧阻断项）。

---

## P0-1 `final_gate` 薄件绕过：板卡借 `ACCEPT_THIN` 通道通关

| | |
|---|---|
| **问题** | `ACCEPT_THIN` 的语义是「**芯片**但规格少」（连接器/晶振/无源件），判据却是文件名/正文里的 `EVM`/`EVAL`。于是唯一被它放行的恰恰是板卡 —— 板卡的零电气零引脚是**诚实空**（板卡本来没有器件级电气表），却被当成「低规格芯片」放进 `thin_accepted`，污染下游 `auto_qc` r3、渲染身份列与交付 manifest 的 `identity/scope`。 |
| **证据** | batch100 实物：`BQ24715EVM-115`、`ADS122U04EVM` 的 `core_validation` 记着三条硬错，顶层 `status` 却是 `ok`。 |
| **修法** | `final_gate()` 增加身份守卫 `_identity_is_board(doc)`，读 `basic_info.identity ∈ BOARD_TYPES`。薄件分支加条件 `and not _identity_is_board(doc)` —— 板卡要么有真参数走正常 validate，要么判 `failed` 进隔离。身份缺失时显式 fail-open（按芯片对待），不拿没有证据的猜测拒件。 |
| **锁它的用例** | `tests/test_final_gate.py::test_board_with_zero_elec_and_zero_pins_cannot_go_ok`、`::test_board_identity_guard_is_identity_not_content`、`::test_board_with_real_elec_is_still_ok`、`::test_development_kit_also_guarded`、`::test_unknown_identity_keeps_old_behavior` |
| **变异验证** | 去掉 `and not _identity_is_board(doc)` → 上述用例转红（红先，已在 `b76d513` 落地时验证） |

## P0-2 `thin_accepted` 独立性：它必须自己是一个状态，不能冒充 `ok`

| | |
|---|---|
| **问题** | 旧实现里「薄件放行」与「正常通过」在阶段映射上落进同一档，导致 `thin_accepted` 被当成 `ok` 消费 —— 交付分母被悄悄放大。 |
| **修法** | `thin_accepted` 独立成顶层枚举（全小写 `ok` / `parsed_core_fail` / `thin_accepted` / `failed`）；阶段映射改**白名单**，`parsed_core_fail` 与 `thin_accepted` 都不落进通过集。 |
| **锁它的用例** | `::test_thin_accepted_does_not_shrink_the_pass_set`、`::test_parsed_core_fail_is_distinct_constant`、`::test_parsed_core_fail_maps_to_failed_stage`、`::test_legacy_statuses_unchanged`；下游消费方另见 `tests/test_status_consumption.py` |
| **本轮补充** | 在准入工具里，`thin_accepted` 归 `normal` 但**必须打 `thin` 标、且不计入 ok 分母**（`ADM_NORMAL` 的三值语义写在工具头部与台账 `rules.admission` 里），语义见 `docs/qc/batch100/THIN_ACCEPTED_SEMANTICS.md`。 |

## P0-3 第三条写盘路径 `batch.ingest` 绕过闸门

| | |
|---|---|
| **问题** | `Batch` 回填只跑 `validate` 就写 `data/parsed`，是绕开 `final_gate` 的第二条写盘路径。在线解析与线下解析两道闸，批量回填没有闸。 |
| **修法** | 三条写盘路径（`parse_datasheets.parse_one` / `app/services/pipeline.parse_pdf` / `app/services/batch.ingest`）统一过同一道 `final_gate`；顺序由用例锁死（**闸门必须在 `out.write_text` 之前**）。 |
| **锁它的用例** | `tests/test_final_gate.py::test_both_entrypoints_use_the_same_gate`、`tests/test_backfill_status.py` |

## P0-4 渲染复核排在缓存之后：旧脏产物命中缓存直接 `done`

| | |
|---|---|
| **问题** | `stage_render` 的缓存捷径在闸门上线后不再等价于「仍然合格」：旧产物命中缓存 → `CACHED` → 被写成 `done`，脏数据绕过闸门重新入包。 |
| **修法** | 复核前移到查缓存之前；带 `parsed_core_fail` 章的拒、无章旧件**现场重算** `core_errs`、`thin_accepted` 放行。验收结论随 JSON 落盘（`metadata.accept_status`），下游不必靠「文件存在」推断这件当初是否过关。 |
| **锁它的用例** | `tests/test_status_consumption.py`；工具侧用 `accept_status` 与现场复判对照，冲突即报（`stamp_conflict` 列） |

## P0-5 准入三分类：板卡零电气可豁免，核心结构错误不可豁免

| | |
|---|---|
| **问题** | 旧判据 `identity ∈ BOARD_TYPES ∧ electrical == 0` 一票准入。**身份成了免死金牌**：只要挂在板卡上，缺必需键、缺厂商、电气为空全部被放过。回放 93 件时抓到实物 `AFE7900EVM` —— 缺 `pin_configuration`、缺 `ordering_info`、`manufacturer` 为空、主桶电气 0、引脚 0、正式桶 0，仍被算进 10 件 allowlist。 |
| **修法** | 准入拆成三分类（互斥）：`normal` / `allowlist_board` / `quarantine`。`allowlist_board` **只**豁免「板卡主桶电气为 0」这一项；「是不是只有这一类错误」这个问题**不在工具里重新定义**，而是把身份抹掉后再问一次 `final_gate`（`only_board_empty_exception()`）—— 判 `thin_accepted` 才算只有板卡零电气类错误。判据只有一份，工具不持有副本。 |
| **锁它的用例** | `tests/test_tools_quarantine.py`（28 例）：`test_board_structural_error_is_quarantined_not_allowlisted`（3 个参数化变异：缺 `pin_configuration` / 缺 `ordering_info` / `manufacturer` 为空）、`test_board_with_core_error_is_quarantined_regardless_of_allowlist`、`test_only_board_empty_exception_really_asks_the_gate`（探针：验证它真的调了闸门、传入的稿子身份已抹掉、原稿未被就地改动）、`test_board_guard_is_what_makes_the_exception_necessary` |
| **变异验证** | 两轮变异各被 4 个用例当场打死：①把 `final_gate` 调用替换为直接返回 `thin_accepted`（模拟「在工具里另写判断」）；②在 `judge()` 里塞回 `if is_board and elec_main == 0: allowlist`（裁定明令禁止的捷径）。还原后 28 例全绿。 |

### P0-5 附带的两条口径修正

1. **请求号优先**：件身份取 `metadata.requested_mpn` > `basic_info.mpn` > 文件名前缀。
   理由：`AFE7950EVM` 的 `basic_info.mpn` 是 `AFE7950`，`AFE7900EVM` 的直接是 `None`
   —— 按文档自称为准，同一个件在两张表里叫两个名字，`AFE7900EVM` 那件会整件消失。
2. **源文档证据口径**：核心校验有两条口径 —— 严格口径（缺 thermal/ESD 即报错）与
   装配口径（`DE.source_has_container(fd, k)` 探测源 PDF，源无表 → `not_applicable`）。
   工具按 `qc/stage_release.py::_revalidate` 的调法组装证据喂给 `check_core`，
   **判据仍在 `check_core` 里**。`ADS1252U` 是典型：严格口径 `parsed_core_fail`，
   装配口径 pass —— 交付包里它是对的。

---

## 数据侧：按新规则重定稿

| | v4（旧规则） | **v5（本次）** |
|---|---|---|
| 入包 | 93 | **91** |
| normal | 83 | **82** |
| allowlist_board | 10 | **9** |
| 剔除 | 0（清单外） | **2**：`AFE7900EVM`（准入裁定隔离）、`ADS1252EVM`（总裁裁决剔除） |

- 两种剔除理由**分开记账**（`final-v5/excluded.csv` 的 `excluded_by` 列）：
  `rule_quarantine` 是工具判的，`executive_decision` 是人判的。合并成一列会让复核方
  以为两件都是工具拦的，一查就对不上（`ADS1252EVM` 工具判 `ok`）。
- 逐件回放差异与三条核心侧待统一项：`docs/qc/tools/replay_batch100/DIFF.md`。
- 上版 `final/`（93 件）**原样保留**，未改写（§16.2 只新增不改写）。

## 未修项（登记待裁，不在本批动）

| 编号 | 问题 | 为什么不擅自修 |
|---|---|---|
| OPEN-1 | 核心侧两套板卡值域：`BOARD_TYPES=(evaluation_board, development_kit)`，而 `check_core` 内联 `(evaluation_board, reference_design, module, board)` | 属核心契约统一，改了要重跑全量回归；本批 0 命中，但 `development_kit` 件必被误判核心错 |
| OPEN-2 | `ADS1252EVM`（交付清单）vs `ADS1252U`（JSON `requested_mpn`）命名分歧 | 请求号回填口径属数据侧历史问题，需回溯批次表 |
| OPEN-3 | `withheld_in_quarantine` 与「电气不足」在 `final_gate` 同属薄件类，板卡带扣押行仍可 allowlist（本批 2 件：241 行 / 31 行） | 业务判断，不是代码对错；工具已显式标注，不改判 |
| BLOCK-1 | `delivery_bundle` 未读 `accept_status` | 下一批开工前必修，本批以人工核对 manifest 兜底 |

## 结论

1. 5 个 P0 全部有代码修复 + 红先用例 + 变异验证，`tests/test_tools_quarantine.py` 28 例全绿。
2. 准入三分类在 93 件真实数据上回放通过，唯一改判件 `AFE7900EVM` 方向正确（结构缺陷出局），未为凑数放水。
3. 数据侧重定稿 91 件，两种剔除理由分开记账，可逐件复算。
4. 4 条未修项已登记，其中 OPEN-1/2/3 需业务或核心口径拍板，BLOCK-1 为下一批硬阻断。
