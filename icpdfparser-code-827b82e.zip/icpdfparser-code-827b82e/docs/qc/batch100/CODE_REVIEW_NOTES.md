# final-gate-v1 源码审计说明（Reviewer 阻断条件 1 & 2 的自证材料）

> 面向：外审。所有结论都带 `文件:行号`，可以逐条打开核对；不接受"报告里说过了"。
> 提交：`b76d513` + 工作区未提交改动（代码包 `icpdfparser-code-dirty-b76d513.zip`）。

## 1. 写盘路径：data/parsed 只有三个写入口，全部过同一道闸

| # | 写入口 | 闸门调用 | 写盘 |
|---|---|---|---|
| 1 | `parse_datasheets.py::parse_one`（CLI 单件/批量） | `parse_datasheets.py:1887` `final_gate(doc, core_errs, thin_allowed=…)` | `parse_datasheets.py:1901` |
| 2 | `app/services/pipeline.py::parse_pdf`（V2 五段链的 llm 段） | `app/services/pipeline.py:272` `pd.final_gate(...)` | `app/services/pipeline.py:291` |
| 3 | `app/services/batch.py::ingest`（百炼 Batch 回填） | `app/services/batch.py:271` `pd.final_gate(doc, core_errs)` | `app/services/batch.py:285` |

**第 3 条是本轮补的漏**：此前 `ingest` 只跑 `pd.validate(doc)` 就把 doc 写进
`data/parsed`，等于给 `data/parsed` 留了第二种准入标准。已加闸，且
`tests/test_status_consumption.py::test_batch_ingest_uses_the_same_gate` 断言
`final_gate` 出现在 `out.write_text` **之前**（按源码顺序，不是按文档措辞）。

### 其余 `write_text` 为什么不算解析写盘路径

| 文件 | 作用域 | 为什么不参与准入 |
|---|---|---|
| `qc/fact_status_sync.py:279` | 对已有 JSON 回填事实状态字段 | 输入是已落盘的件，不产生新件 |
| `qc/collapse_quarantine.py:107` | 隔离区结构合并 | 同上，且只动隔离区 |
| `qc/acceptance_rebuild.py:61,66` | 重建验收视图，输出到独立目录 | 不改 `data/parsed` 原件 |
| `app/services/review.py:1157` | 人工复核产物 | 写 `data/review`，不是解析产物 |

## 2. `core_errs` 是**落盘前重算**的，不是沿用模型初稿那一份

`parse_one`：`check_core` 在 1854 行重算（注释写着"唯一 choke point"），
落盘在 1901。中间没有第二次修改 doc 的语句。
`parse_pdf`：264 行重算，落盘 291。中间之后只做 `meta` 赋值，不再改 `doc` 结构。

判据本身（`final_gate`，`parse_datasheets.py:1462`）：

```python
errs = validate(doc)
if errs:
    only_thin = all(e.startswith("specs.electrical only") or e.startswith("withheld_in_quarantine") …)
    if thin_allowed and only_thin and not _identity_is_board(doc):
        return STATUS_THIN_ACCEPTED, []
    return "failed", errs
if core_errs:
    return STATUS_PARSED_CORE_FAIL, []
return STATUS_OK, []
```

顺序要点：**结构先于核心**。结构不过直接 `failed`，不会得到 `parsed_core_fail`
——这是 BQ24715EVM-115 / ADS122U04EVM 重跑后落在 `failed` 而不是
`parsed_core_fail` 的原因，不是漏判。

## 3. 状态枚举只有一个值域

| 常量 | 值 | 语义 |
|---|---|---|
| `STATUS_OK` | `ok` | 最终稿过 validate 且 `core_errs` 为空 |
| `STATUS_PARSED_CORE_FAIL` | `parsed_core_fail` | 结构过、核心有硬错 |
| `STATUS_THIN_ACCEPTED` | `thin_accepted` | 芯片低规格件，解析层明确收下 |
| （字面量） | `failed` | 结构不过，未落盘 |

全部小写。`tests/test_status_consumption.py::test_no_uppercase_status_value_used_anywhere`
扫描 `tests/`、`app/`、`qc/`、`worker/`，断言不存在值为 `"THIN_ACCEPTED"` 的字符串字面量；
`test_thin_status_value_is_lowercase` 断言三个常量值都等于自己的 `lower()`。

## 4. 下游消费：谁会看 status，看完做什么

| 消费者 | 读什么 | 对 `thin_accepted` / `parsed_core_fail` 的行为 |
|---|---|---|
| `app/pipeline/stages.py:335`（llm 段） | 解析返回的 `rec["status"]` | 经 `llm_status_to_stage` 白名单：`ok`/`thin_accepted` → ok；其余 → failed。`parsed_core_fail` **不进** render |
| `app/pipeline/stages.py:477`（render 段，本轮新增） | JSON 的 `metadata.accept_status` | `parsed_core_fail` → FAILED；无章旧件 → 现场重算 `core_errs`，有错即拒；`thin_accepted` → 放行。**位置在查缓存之前**（477 < 483），否则旧件命中缓存会被写成 done |
| `worker/tasks.py:354` | render 返回 CACHED | 只有 render 阶段返回 CACHED 才写 `done`；上面那道复核已经把不合格件挡在 CACHED 之外 |
| `qc/auto_qc.py:184` | `SELECT … WHERE status='done'` | 解析层 `failed` 的件根本不进入统计口径 |
| `delivery_bundle.py:332,603` | `item.status`（DB） | manifest 的 `status` 列取 DB 值，不读解析 JSON 的自述 |
| `qc/stage_release.py` | **不读 status**；只吃 `--mpns` 名单 + 自带 `_revalidate` | 准入必须在**调用方**做 —— 这就是本轮驱动脚本要显式剔除的原因 |
| 重试队列 | `item.status` | `failed` 才会被重试策略捡起；`parsed_core_fail` 落成 `failed`，可重试，符合"模型问题可重来" |

## 5. 本轮**没有**覆盖的，先说清楚

1. `qc/stage_release.py` 内部不读 `accept_status`，它用自己的 `_revalidate`。
   本批 95 件的装配结论因此不随本次改动变化；剔除逻辑放在驱动脚本里显式执行。
2. `qc/auto_qc.py:246` 的 `ELECTRICAL_EMPTY` 仍按 `specs.electrical` 单桶计数，
   与 validate 的双桶口径不一致。按既定边界**只登记不改**，另立任务。
3. 本批 95 件的 JSON 都没有 `accept_status`（它们是改动前产出的）。所以本批
   `thin_accepted` 计数为 0；`render_gate` 对这些旧件走的是"现场重算 core_errs"分支。

## 6. 复现

```bash
# 代码级：闸门与消费契约
python -m pytest tests/test_final_gate.py tests/test_status_consumption.py \
                 tests/test_parse_validate_robust.py -q

# 身份守卫承重证明（拆掉守卫即转红）
python -c "import parse_datasheets as PD; \
d={'basic_info':{'mpn':'X','manufacturer':'TI','identity':'evaluation_board'}, \
'specs':{'electrical':[]},'features':[],'applications':[],'alternatives':[], \
'ordering_info':[],'seo':{},'metadata':{},'pin_configuration':[]}; \
print(PD.final_gate(d,[],thin_allowed=True))"
```
