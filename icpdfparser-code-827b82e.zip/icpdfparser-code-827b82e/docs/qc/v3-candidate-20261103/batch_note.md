## V3 候选批次（V3-CANDIDATE / NOT-APPROVED）

- 8 件在冻结快照 `e23751b` 上重新解析、重新渲染，**未复用旧 V2 JSON**。
- `CDC6CE025000ADLYR` 的模型订货行写成错误变体，已按 PDF p38 订货表修复
  `ordering_info` 后重跑身份；质量报告保留该修复记录。
- G2 引脚修复：`ADS42JB49SEK` 由 33 → **64** 脚；`LM358` 由 2 → **8** 脚，
  修复依据是 PDF 的 `PIN | NAME | NO.` 分组表与 `NAME | LCCC | SOIC | I/O` 多封装表。
- 本包只完成候选装配与 63 项自检，**不设置** `CONTENT_APPROVED` / `RELEASE_APPROVED`。
- 仍然阻断：D2 原始账本复核、D3-UG 复核、`DEPLOY-P171` 服务器同构五阶段。
- 缺失：`alt_json` / `alt_html`、`ja` / `ko` / `de` / `es` 多语（本批只出 `en`）。
