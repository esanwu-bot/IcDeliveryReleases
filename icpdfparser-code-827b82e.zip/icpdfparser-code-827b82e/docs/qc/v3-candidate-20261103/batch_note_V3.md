## V3 候选批次（V3-CANDIDATE / **NOT-APPROVED**）

> **本包是工程构建产物，不是发布授权。**
> Reviewer 2026-11-03 裁决：允许在隔离目录构建 `delivery-batch20-eval-V3-CANDIDATE`，
> 但**不批准 V3 正式发布**；不设 `CONTENT_APPROVED` / `RELEASE_APPROVED`，
> 不改 `release_status`，不覆盖 V2 交付物，不写正式生产数据目录。
> `PIPELINE_PASS` 与 `anchor_gate=pass` **不得**被解释为内容审批通过。

### 一、物料来源与代码基线

| 项 | 值 |
|---|---|
| 物料解析轮次 | 2026-11-03 20:06–21:28（冻结快照 `e23751b` 的解析输出） |
| 装配/确定性复核代码 | **HEAD `948c2c2`**（含 G2 引脚修复） |
| 装配命令 | `qc/stage_release.py --src <解析输出>/parsed --out data/staging_batch20_v3 --mpns <7 件> --normalize --pdf-dir data/pdfs` |
| 事实验收 | `qc/fact_acceptance.py` → `qc/fact_status_sync.py` |
| 型号数 | **7**（见第三节 ADLYR 未产出） |

装配段跑的是当前 HEAD，因此 G2 引脚修复（ADS42JB49SEK 33→64、LM358 2→8）
在本包物料里已生效；解析段的模型输出本身来自上表轮次，未跨轮拼接。

### 二、三个 PENDING 项（**未关闭**，见 README「未完成项」）

| PENDING | 本轮进展 | 结论 |
|---|---|---|
| 服务器 Docker 五阶段同构复跑 | **已执行**：159.89.190.225 上 Redis DB8 + 独立数据根，3 件冻结样本跑完，生产指纹前后一致 | 复跑已完成；但 LM317 引脚出现分歧（见下），需 Reviewer 裁定 |
| 真实 `board_user_guide`（D3-UG） | 真实 UG（SBAU193E）身份识别已验证；**行级归属未验证** | **仍 PENDING** |
| D4 `PIN\|FUNCTION` 独立验收 | 本地 HEAD 复跑 LM317 得 3 脚 ✓；服务器同构复跑得 **4 脚**（模型多出一条重复 `OUTPUT 4`，确定性侧只抽到 3 条却未纠正） | **仍 PENDING**，已给出根因 |

### 三、本批未产出型号：`CDC6CE025000ADLYR`

批次原定 8 件，`CDC6CE025000ADLYR` **未出产物**，因此本包只有 7 件，不做跨轮回填。

- 该件在解析轮次内即为空结果（`electrical=0 / thermal=0 / esd=0`）；
- 本轮又用当前 HEAD 独立重解析 **2 次**（22:11、22:19），两次均为
  `status=ok` 但四个容器全 0 —— 模型未产出可用参数表；
- 按「不用空 JSON 冒充通过」的口径，它不进包，改为在 `skipped.csv`
  与本节留痕。宁可如实少一件。

其余 7 件同源、同轮、同一份装配代码，可复现。

### 四、已知缺失（非阻断，如实记录）

- `alt_json` / `alt_html`：本批未产出替代料侧车；
- `ja` / `ko` / `de` / `es` 多语：只交付 `en`；
- `anchor_gate`：多数件为 `blocked`（存在弱证据行），风险已在
  `risk_queue.csv` 逐条登记 —— `blocked` 不等于参数错误，也不等于已通过。
