# Phase 1.7 灰度样本 2/3 · 板卡（ADS8568EVM-PDK）

**日期**：2026-11-03 · **代码**：`origin/main@d6fc276`
**隔离**：Redis DB8 · `/tmp/p17/data_s2` · 容器 `p17-s2-*`
**冻结样本**：MPN `ADS8568EVM-PDK` · `https://www.ti.com/lit/ds/sbas543c/sbas543c.pdf`
`sha256=79c029913ea9ce5ce0cae2fb12cd22e2598088ed5a58a6c6567062ffb7d9bb76` · 2,140,847 B · 62 页

## 结论

**PIPELINE_PASS / SCOPE_PARTIAL** —— 身份与电气隔离按预期成立（板载器件参数没有冒充整板参数）；
但 `specs.thermal`（11 行）与 `specs.esd`（2 行）**仍留在主容器**，未随
`electrical / absolute_max` 一起搬进 `onboard_device_specs`。属当前代码既有口径缺口（§5-D3）。

## 1. 时间线与任务事件

| 段 | 结果 | 耗时 | 备注 |
|---|---|---|---|
| fetch | ok | — | `manual` 2,140,847 B，sha `79c02991…` |
| preprocess | ok | 1,558ms | 41,893 字符 / 16 页（共 62），`reused=False` |
| llm | ok | 78,782ms | qwen-flash，`llm_calls=1`，confidence 0.95 |
| audit | ok | 38,410ms | `write=false`，findings 1（`identity_unverified`）|
| render | ok | 48ms | errors 0 |

`item.status=done` / `progress=100` / `parse_count=1` / `parse_ms=78,782`。

## 2. 指标

| 指标 | 值 |
|---|---|
| `start` / `download` | **1 / 1** |
| `dedup` / `already_running` | 0 / 0 |
| `tried_at` | `2026-11-03T17:41:34+08:00`（无二次变化）|
| `parse_count` | 1 |
| LLM | 1 次（qwen-flash），prompt_sha `a7330e96…`；`llm_usage` **0 行**（同 D2）|
| audit | findings 1：`identity_unverified`（write=false）|
| 产物 | JSON 38,636 B、TXT 30,410 B、symbol 1,917 B |
| 正式数据副作用 | 无（见 §4）|

## 3. 身份与隔离核对（冻结预期）

| 断言 | 冻结预期 | 实测 | 判定 |
|---|---|---|---|
| `basic_info.identity` | `evaluation_board` | `evaluation_board`（rule `TI_BOARD_SUFFIX_EVM`, state `BOARD_CONFIRMED`）| ✅ |
| `basic_info.document_scope` | `onboard_device_datasheet` | 同 | ✅ |
| `basic_info.device_mpn` | `ADS8568` | `ADS8568` | ✅ |
| `specs.scope` | `onboard_device` | `onboard_device` | ✅ |
| `pin_scope` | `board` | `board`（主容器引脚 0 条）| ✅ |
| 主容器 `specs.electrical` | 0 | **0** | ✅ |
| 主容器 `specs.absolute_max` | 0 | **0** | ✅ |
| `specs.onboard_device_specs` | 非空 | 有：electrical **110**、absolute_max **11**、pin_configuration **38**、package `64-Pin VQFN`、temperature −40…125°C | ✅ |
| 主容器 `specs.thermal` | （未冻结） | **11 行仍留在主容器** | ⚠️ D3 |
| 主容器 `specs.esd` | （未冻结） | **2 行仍留在主容器** | ⚠️ D3 |

主容器 `package` 为 `{"type":"Evaluation Board","onboard_device":"ADS8568",…}`，
`onboard_device_specs.source=onboard_device_datasheet`，说明「芯片参数来自器件手册、不是整板参数」这条
主判据成立。

## 4. 正式数据副作用

与样本 1 相同：灰度前后 `data/parsed` 指纹、生产库 sha/大小、五个生产容器 `RestartCount` 全部未变
（`digest=acf8d167…`，`db sha=d93d6585… size=95834112`）。

## 5. 发现

**D3（P1）板卡分支只搬了两类芯片参数。**
`qc/identity_scope` 的搬移清单覆盖 `electrical / absolute_max / temperature / features /
applications / alternatives / seo`，**不覆盖 `thermal` 与 `esd`**。所以板卡页面主容器仍会出现
11 条热阻 + 2 条 ESD（芯片级数值），仅靠 `specs.scope=onboard_device` 标注区分。
`docs/qc/ads8568_board_ug_20261102` 已指出「UG 才能把身份纠正为 board_user_guide」；
本轮喂的是器件手册（SBAS543），identity 正确走 `onboard_device_datasheet`，
但 thermal/esd 的归属未同步搬移 —— 需要单独裁决（搬进隔离区，或明确标注为主容器芯片参数）。

**D2（P1）** 同样本 1：V2 不落 `llm_usage`，token 指标不可观测。

## 6. 证据位置

```
/tmp/p17/s2.json        /tmp/p17/log_s2-*.log        /tmp/p17/data_s2/
```

## 7. 人工审核结论

身份链路通过、电气隔离通过；热阻/ESD 的口径缺口需在下一轮修复或明确裁决。
`PIPELINE_PASS` 不等于 `CONTENT_APPROVED`。
