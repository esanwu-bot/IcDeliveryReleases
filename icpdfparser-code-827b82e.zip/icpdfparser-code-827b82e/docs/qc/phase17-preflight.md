# Phase 1.7 三件受控灰度 · 启动前冻结单

> 依据：Phase 1.6.1 外审裁决（2026-11-03）——「Phase 1.7 三件受控灰度获批」。
> 本文件只做三件事：**固定样本、固定预期、固定隔离与停止线**。灰度期间不得改样本、
> 不改模型 / Prompt / 算法、不扩容、不改变正式发布状态机。

## 1. 授权边界

- 只跑 **3 件**：芯片 / 板卡 / 异常件，各 1 件。
- 只走正常自动队列入口（`dispatch.submit("fetch_item", …)`）→ 五段链路
  （`fetch → preprocess → llm → audit → render`）。
- **禁止** `POST /items/{key}/reparse`（含 `force=false`）：该入口在投递前无条件写
  `status='queued'`，会绕过本轮去重规则。灰度脚本不调用任何 HTTP 写接口。
- 不碰生产：生产 Redis 用 DB0；灰度用 **DB8** + `/tmp/p17/data_s*`；
  生产五个容器（`icpdf-server/render/llm/fetch/redis`）不重启。
- `write=true` 不打开：audit 段恒为 `write=false`，模型输出与机检补丁不混写。

## 2. 冻结样本（URL 已实测可下载，SHA256 与本地样件逐字节一致）

| # | 类型 | MPN | PDF URL | SHA256 | bytes | pages | is_datasheet |
|---|---|---|---|---|---|---|---|
| 1 | 芯片 | `LM317` | `https://www.ti.com.cn/lit/ds/symlink/lm317.pdf` | `1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3` | 2,578,150 | 45 | True |
| 2 | 板卡 | `ADS8568EVM-PDK` | `https://www.ti.com/lit/ds/sbas543c/sbas543c.pdf` | `79c029913ea9ce5ce0cae2fb12cd22e2598088ed5a58a6c6567062ffb7d9bb76` | 2,140,847 | 62 | True |
| 3 | 异常件 | `DAC8568EVM` | `https://www.ti.com/lit/ug/slau301/slau301.pdf` | `a7e7253da4b38490f8ec548d76c33a20cedd80bca031318fd4ccbfea503afe45` | 266,384 | 10 | **False** |

样本说明：

- 芯片用 LM317：A22 之后热阻表按封装展开（预期 34 行），能同时验证新抽取链路。
- 板卡用 ADS8568EVM-PDK + 原厂器件手册（SBAS543）：验证「板载芯片参数不冒充整板参数」。
  （专项诊断已证明该件的板卡 UG 是 SBAU193E，但 UG 无电气表，交付参数仍来自 SBAS543。）
- 异常件用 DAC8568EVM 的 **User's Guide**：`is_datasheet=False`，链路必须在
  preprocess 段给出 `skipped` 并终止，不得调模型、不得伪造成 `done`。

## 3. 预期结果（可机器判定，与模型方差无关的不变量）

### 样本 1 · LM317（芯片正常链路）

| 断言 | 预期 |
|---|---|
| 五段阶段账 | fetch/preprocess/llm/audit/render 全部存在，`status ∈ {ok, cached}` |
| `item.status` / `progress` | `done` / `100` |
| `basic_info.identity` / `specs.scope` | `chip` / `device` |
| `parse_count` | `1`（缓存命中不得增加；本件冷启动应为 1） |
| `specs.thermal` 行数 | **34**（A22 按封装展开；Legacy DCY/KCS/KCT/KTT + New DCY/KTT） |
| `RθJC(top)` | Legacy-DCY `43.2`、New-KTT `43.6` 同时存在 |
| `pin_configuration` | 3 条（SOT-223 / TO-220 / TO-263 封装） |
| audit | `write=false`，阶段 `ok`；记录 findings 数（不要求为 0，但不得出现 blocking 后仍写 done） |

### 样本 2 · ADS8568EVM-PDK（板卡身份与隔离）

| 断言 | 预期（当前代码 `qc.identity_scope.apply` 的确定结论） |
|---|---|
| `item.status` | `done`（板卡不是异常件；器件手册可解析） |
| `basic_info.identity` | `evaluation_board`（rule `TI_BOARD_SUFFIX_EVM`）|
| `basic_info.document_scope` | `onboard_device_datasheet` |
| `specs.scope` | `onboard_device` |
| `pin_scope` | `board`（板载芯片引脚不冒充整板引脚） |
| 主容器 `specs.electrical` | 0（芯片参数整体搬进隔离区，不得当整板参数） |
| `specs.onboard_device_specs` | 非空（芯片真值保留可查） |
| `parse_count` | 1 |

### 样本 3 · DAC8568EVM（异常状态语义）

| 断言 | 预期 |
|---|---|
| preprocess 阶段 | `status=skipped`，`error` 写明「不是 datasheet」类原因 |
| `item.status` | `skipped`（终态），`progress=100` |
| 下游阶段 | **没有** `llm/audit/render` 阶段账行；`parse_count=0` |
| 模型消耗 | `llm_usage` 该件 0 行 |
| 产物 | 只有 PDF + 切片；无 `data/parsed/*.json`、无 txt/symbols |

## 4. 隔离与可复现

| 维度 | 生产 | 灰度 |
|---|---|---|
| Redis | DB0 | **DB8**（逐件 `flushdb`） |
| 数据根 | `/www/wwwroot/icpdfparser/data` | `/tmp/p17/data_s1` / `s2` / `s3`（每件独立） |
| 代码 | 镜像 `icpdf/app:latest` | 同镜像 + `origin/main`（`d6fc276`）整目录只读挂载 `/app` |
| 容器 | `icpdf-*` | `p17-s{1,2,3}-{fetch,preprocess,llm,audit,render}`，跑完即删 |
| 探针 | — | `/tmp/p17/probe/p17.py`（`seed/submit/status/report`） |

## 5. 每件必须记录的指标

`dedup` 次数、`already_running` 次数、`start` / `download` 次数、`tried_at` 是否变化、
`parse_count`、各阶段最终状态与耗时、`llm_usage`（prompt/completion/total tokens）、
audit findings 与 blocked 原因、正式数据副作用指纹、最终状态与人工结论。

**口径**：`tried_at` 变化而 `parse_count` 不变是**调查信号**，不是重复下载的充分证据；
`already_running` 必须关联原任务最终状态，不得计为业务完成；
`PIPELINE_PASS ≠ CONTENT_APPROVED ≠ RELEASE_APPROVED`。

## 6. 停止线（任一触发即停，保留现场）

1. 已完成任务的 `done` 被降级；
2. 同一任务意图发生非预期重复下载；
3. 缓存命中导致 `parse_count` 增加；
4. `already_running` 没有可追踪的原执行任务；
5. 阶段状态出现无法解释的永久中间态；
6. 板卡与芯片身份发生错误归属；
7. 正式生产数据、页面或交付包发生未经批准的变化。

触发后：保留 worker 日志、Redis 队列、隔离 SQLite 快照、文件指纹，**不先清理容器或重置数据库**。

## 7. 交付

三件各自一份报告：`docs/qc/phase17-sample-1-chip.md`、`-2-board.md`、`-3-abnormal.md`，
外加本冻结单。每份报告至少包含 §5 的全部字段与「最终状态 / 人工审核结论」。
