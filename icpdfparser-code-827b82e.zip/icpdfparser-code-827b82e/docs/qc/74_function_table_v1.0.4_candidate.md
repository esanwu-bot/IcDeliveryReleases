# 74 功能表 · v1.0.4 候选（仅修 scope_note 文案）— 已签核（授权代理）

- 候选文件：`qc/74_function_codes.v1.0.4.candidate.json`
- 版本：`1.0.4` ｜ 状态：**SIGNED**
- 内容哈希：`sha256:6a1784db98937ead65a73c81f01a98de58e30d26dccb6840d96b386c5b555980`
- 前驱：`1.0.3`（`SIGNED`，
  `sha256:81e4191123cf080a2dd623d0a29482671dd5e6ea8fb06b3c22bd15ad6a62b098`）——v1.0.3 保持原样可回溯
- 生成/签核时间：2026-10-29T14:35:07+08:00

## 1. 变更（仅文案 + 版本）

| 项 | v1.0.3 | v1.0.4 |
|---|---|---|
| `scope_note` | 「…候选未签核，不得用于 P0。」（已过时） | 「…本版本经复核签核后可用于 P0 功能等价判定（仍未接入 review 规则）。」 |
| `version` | 1.0.3 | 1.0.4 |
| `functions` / `family_overrides` / `unresolved` / `sources` | — | **逐字节一致**（无任何功能码或证据改动） |

## 2. 签核（按用户长期代理授权）

- 授权依据：用户 2026-10-29「下次还需要核签就授权你代理就行」＋本次指示「由授权审核人重新签核」；
- 签核人 `wuxiaoxian`，`signed_via = agent-delegation`，`reviewed_at = 2026-10-29T14:34:06+08:00`；
- 签核前已跑 `validate` + `verify-evidence`（error=0 / warn=0）。

## 3. 校验

| 检查 | 结果 |
|---|---|
| `validate --table <v1.0.4>` | OK |
| `verify-evidence --table <v1.0.4>` | total=0 / error=0 / warn=0 |
| `is_usable_for_p0` | True (ok) |

## 4. 判定回归（只读）

| 用例 | main 1.0.2 | v1.0.3 | v1.0.4 |
|---|---|---|---|
| `132 vs 11` | `NO_EVIDENCE` | `INCOMPATIBLE` | `INCOMPATIBLE` |
| `132 vs 132` | `NO_CONFLICT_EVIDENCE` | 同 | 同 |
| `125(LVC) vs 125(CBT)` | `INCOMPATIBLE` | 同 | 同 |
| `04(AHC) vs 04(AHC)` | `NO_CONFLICT_EVIDENCE` | 同 | 同 |
| `240(AUC) vs 240(AUC)` | `NO_EVIDENCE` | 同 | 同 |
| `132 vs 999` | `NO_EVIDENCE` | 同 | 同 |
| `char_only_diff` | — | `NO_EVIDENCE` | `NO_EVIDENCE` |

## 5. 边界

- **主表未切换**（仍 v1.0.2）；
- review 规则未接入（`app/`、`worker/` 无引用）；
- 未重生成交付包、未写生产。

## 6. 切换命令（需单独确认）

```powershell
Copy-Item qc\74_function_codes.json qc\74_function_codes.v1.0.2.signed.bak.json
Copy-Item qc\74_function_codes.v1.0.4.candidate.json qc\74_function_codes.json
python qc\function_table.py validate
python qc\function_table.py show
python qc\function_table.py verify-evidence
python -m unittest tests.test_74_function_table -q
```
