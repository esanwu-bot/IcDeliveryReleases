# 兜底 A/B 与隔离区（2026-11-02）

> 本文件是 `data/qc/fallback_ab/README_20261102.md` 的**入库版本**（`data/qc/` 被 .gitignore 忽略，
> 只留在服务器沙箱）。两端内容以本文件为准。

## quarantine：ADC08B200EB（plus 兜底产物）

- 来源：`/root/_trace3/parsed/ADC08B200EB_20951109.json`（沙箱，未进生产）
- 观测：`elec=39 / pins=48 / conf=0.95`，plus usage `25,426 tokens`（prompt 18,579）
- 零成本审计（`qc/step3_zero_cost_audit.py`）：`role_coverage = 0/39`、`valid_conditions = 23/39`、
  `has_power_gnd_pins = Yes`
- **定级：`unverified_pending_reaudit`（未定性，待重审）**
- 隔离动作本身不变：fail-closed、不写生产、不进分母、保留作回归对照

### 理由码更正（2026-11-02 第二轮）

旧理由码「模型幻觉 / 无结构输出」**撤回** —— 它是用 A20 修复前的审计器量出来的：

- `role_coverage = 0/39` 是**审计器读不出 `Limits (3)` 列角色**时算的（坏尺子量出的 0 分）；
- 它不能证明 39 行值是幻觉，只能证明"当时的审计体系产不出列角色"；
- 唯一**不依赖列角色**的独立证据是 `valid_conditions = 23/39`：它只证明 16 行条件不可信，
  不证明全部值都是幻觉。

因此：**39 行既没被证真、也没被证伪** → 定级改为 `unverified_pending_reaudit`。

### 重审闭环任务（登记，待执行）

| 项 | 内容 |
|---|---|
| 触发条件 | A20（`Limits` 列识别 + 表头来源修正）已落地（`5805cc9`） |
| 输入 | 同一 PDF `ADC08B200EB.pdf` + 同一 plus 产物 `/root/_trace3/parsed/ADC08B200EB_20951109.json` |
| 工具 | 修复后的 `qc/table_audit.py`（`audit_electrical` + `num_values`）与 `qc/deterministic_extract.py` |
| 判据 A | plus 值逐一与 deterministic 输出一致（数值 + 侧别） → 改判 **「正确但冗余」** |
| 判据 B | 仍冲突 / 仍有 `LIMITS_COLUMN` 不可判占比 > 30% → 维持 **模型幻觉/无效输出** |
| 输出 | 在本文档追加「重审结论」一节，并更新 `_gray20_run/STALE.md` 的状态行 |

> ⚠️ 在重审完成前，「不得计入命中率」这条禁令仍然有效，但**它的分母是被未定性件操纵的**：
> 不要把 39 行当成"已知无用"的分子，也不要把它们当成"已知有效"的分子。

## 允许的后续用途

1. 作为"换模型不能解决结构问题"的反例样本；
2. `LIMITS` 列修复后，用同一份 PDF + 同一 16 页上下文做**回归对照组**
   （预期：deterministic 抽取能出 `columns`，无需 plus）。

## 禁止

- 不得写入 `data/parsed/`；
- 不得计入 `plus 命中率` 或 `正确率`（分母待重审定性后才能合并）；
- 不得作为"兜底有效"的证据引用。
