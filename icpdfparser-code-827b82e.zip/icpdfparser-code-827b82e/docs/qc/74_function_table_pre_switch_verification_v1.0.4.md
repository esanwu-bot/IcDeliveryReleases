# 74 功能表 · 切换前只读核验（v1.0.4 候选）

- 核验时间：2026-10-29T14:35:07+08:00
- 主表：`qc/74_function_codes.json`（1.0.2 SIGNED）
- 候选：`qc/74_function_codes.v1.0.4.candidate.json`（1.0.4 SIGNED）
- **未切换、未接规则、未写生产**

## 1. 签核完整性

| 表 | 版本 | 状态 | signed_via | 哈希=重算 | usable |
|---|---|---|---|---|---|
| main | 1.0.2 | SIGNED | agent-delegation | True | True |
| v1.0.3 | 1.0.3 | SIGNED | None | True | True |
| v1.0.4 | 1.0.4 | SIGNED | agent-delegation | True | True |

## 2. 差异

- v1.0.3 → v1.0.4 业务字段差异：**无**（仅文案/版本/签核元数据）；
- main(1.0.2) → v1.0.4：新增功能码 `11`，共有 0 个码内容变化
  （列表：无）；`family_overrides` 相同；
  `sources` 除 code=11 外相同；`unresolved: ["11"] → []`；
  其他顶层字段差异：无。

## 3. 校验

- v1.0.4：`validate=OK`、`verify-evidence={'total': 0, 'error': 0, 'warn': 0}`
- main：`validate=OK`

## 4. 判定回归（main / v1.0.3 / v1.0.4）

| 用例 | main | v1.0.3 | v1.0.4 |
|---|---|---|---|
| `132 vs 11` | `NO_EVIDENCE` | `INCOMPATIBLE` | `INCOMPATIBLE` |
| `132 vs 132` | `NO_CONFLICT_EVIDENCE` | `NO_CONFLICT_EVIDENCE` | `NO_CONFLICT_EVIDENCE` |
| `125 LVC vs CBT` | `INCOMPATIBLE` | `INCOMPATIBLE` | `INCOMPATIBLE` |

## 5. 消费链路

- `app/`、`worker/` 对 `function_table` / `74_function_codes` 引用数：**0** → P0 规则仍未接入；
- 因此即便切换主表，review 结论也不会立刻变化（需阶段 ② 接线）。

## 6. 切换 / 回滚（未执行）

见 `docs/qc/74_function_table_v1.0.4_candidate.md` §6；
切换后预期 `version=1.0.4`、`SIGNED`、`hash=sha256:6a1784db98937ead6…`、`judge(132 vs 11)=INCOMPATIBLE`。

## 7. 仍未处理的已知项

- `74LVC1G11` 的 PDF 位于 `data/pdfs/`（gitignore），换机需按 SHA 取回；
- v1.0.2 主表的 `signed_via=agent-delegation`，切换后主表将变为 v1.0.4（代理签核，带授权说明）；
  若要求主表为「本人签核」，可由你本人对 v1.0.4 再签一次（会刷新 reviewed_at）。
