# GH-14 / GH-23 关单与回帖证据（A22）

> 2026-11-03。本目录只存「线上确实关掉了」的可复核证据，不是工单正文的副本。

## 结论

| 项 | #14 LM317 | #23 LM358 |
|---|---|---|
| 线上状态 | `closed` / `completed` | `closed` / `completed` |
| 关单时间（UTC） | 2026-11-03T07:25:49Z | 2026-11-03T07:25:51Z |
| 验收回帖 | [issuecomment-6597892130](https://github.com/esanwu-bot/IcDeliveryReleases/issues/14#issuecomment-6597892130) | [issuecomment-6597893569](https://github.com/esanwu-bot/IcDeliveryReleases/issues/23#issuecomment-6597893569) |
| 评论总数 | 2（修复汇报 + 验收回帖） | 2（修复汇报 + 验收回帖） |

两张单的验收回帖正文相同：

```text
A22 修复已由 Trae 提交 (d5ab14c / 7e57397) 并推送。WB 独立验收：
LM317 抽取 34 行，LM358 抽取 42 行（原 0 行），双 Qwen 质审均通过 accept。
```

## 截图

| 文件 | 内容 |
|---|---|
| `issue-14-state.png` | #14 标题 + `Closed` 徽章 + 缺陷数抬头 |
| `issue-14-comments.png` | #14 评论区：修复汇报、验收回帖、`closed this as completed` |
| `issue-23-state.png` | #23 标题 + `Closed` 徽章 + 缺陷数抬头 |
| `issue-23-comments.png` | #23 评论区：修复汇报、验收回帖、`closed this as completed` |

截图由无头 Edge 直接抓公开页面（仓库 `esanwu-bot/IcDeliveryReleases` 为 public），
不是手工拼的示意图：

```powershell
& 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' `
  --headless=new --disable-gpu --no-sandbox --ignore-certificate-errors `
  --hide-scrollbars --user-data-dir=$env:TEMP\edge-shot `
  --window-size=1280,7200 --virtual-time-budget=25000 `
  --screenshot=docs\qc\gh-issues\issue-14-full.png `
  https://github.com/esanwu-bot/IcDeliveryReleases/issues/14
# 再按内容区裁出 state / comments 两张（PIL），避免整页缩略后看不清字
```

## 复核命令（只读）

```powershell
python -m app.integrations.github_issues reply --id 14 --body "" --dry-run   # 仅看请求形状
# 线上真实状态（只读 GET，不写）：
python -c "from app.integrations.github_issues import reply_issue, _cfg; import requests; \
r,t=_cfg(); s=requests.Session(); h={'Authorization':f'Bearer {t}','Accept':'application/vnd.github+json'}; \
print([s.get(f'https://api.github.com/repos/{r}/issues/{n}',headers=h,timeout=30).json()['state'] for n in (14,23)])"
```

写入入口是两个函数（CLI 分别对应 `reply` / `close` 分支）：

- `github_issues.comment_issue(n, body)` → `POST /repos/{repo}/issues/{n}/comments`
- `github_issues.close_issue(n)` → `PATCH /repos/{repo}/issues/{n}`，`state=closed`、`state_reason=completed`

## 已知边界

`sync` 只拉 `state=open`，所以已关闭的 #14/#23 不会被重写：本地镜像仍显示
`OPEN` / 评论 0 条。这是刻意设计（不自动删除历史记录），不是同步失败 ——
判断「还在不在队列里」看 `_index.md` 的「本地有、本次未返回」一节。
