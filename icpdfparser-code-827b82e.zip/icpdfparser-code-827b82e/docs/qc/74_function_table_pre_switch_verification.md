# 74 功能表 · 主表切换前只读核验（未切换）

- 核验时间：2026-10-29（只读；**主表未切换、规则未接线**）
- 主体：`qc/74_function_codes.json`（**v1.0.2 SIGNED**）ｖｓ
  `qc/74_function_codes.v1.0.3.candidate.json`（**v1.0.3 SIGNED**）

## 0. 三个状态必须分开

| 状态 | 当前 | 依据 |
|---|---|---|
| 候选表已签核 | ✅ 是 | `status=SIGNED`，哈希与内容匹配 |
| 主表已切换为 v1.0.3 | ❌ 否 | 主表仍是 v1.0.2 |
| P0 规则已消费新表 | ❌ 否 | `app/`、`worker/` 中**无**任何 `function_table` / `74_function_codes` 引用 |

## 1. 签核完整性

| 表 | 版本 | 状态 | 签核人 | 签核时间 | 绑定哈希 = 重算 | `usable_for_p0` |
|---|---|---|---|---|---|---|
| main | 1.0.2 | SIGNED | wuxiaoxian | 2026-10-29T14:07:37+08:00 | ✅ `c575a174…` | True |
| cand | 1.0.3 | SIGNED | wuxiaoxian | 2026-10-29T14:25:14+08:00 | ✅ `81e41911…` | True |

- candidate 的 `signed_via = None` → **本人签核**（非代理）；
- main 的 `signed_via = agent-delegation`（v1.0.2 上一轮由代理执行，已记授权说明）。

## 2. 双表差异（只读结构化对比）

| 项 | 结果 |
|---|---|
| 新增功能码 | `11` |
| 删除功能码 | 无 |
| 24 个共有功能码内容 | **逐字节相同**（无口径改动） |
| `family_overrides`（CBT/CBTD 125） | 完全相同 |
| `sources` | 除新增 1 条（code=11）外完全相同 |
| `unresolved` | `["11"]` → `[]` |
| 顶层元数据变化 | `version`、`status` 字段无关的 `change_reason`、`content_hash`、`reviewed_at`、`signed_via`、新增 `predecessor`、`scope_note` |

**结论**：变更面仅限「新增已审核的 11 + 溯源元数据」，未触碰其他功能码或判定口径。

## 3. 判定回归（两表分别跑）

| 用例 | main (1.0.2) | cand (1.0.3) | 说明 |
|---|---|---|---|
| `132 vs 11` | `NO_EVIDENCE` | **`INCOMPATIBLE`** | 唯一预期差异（11 由缺证→有证） |
| `132 vs 132` | `NO_CONFLICT_EVIDENCE` | 同 | 永不返回 PASS |
| `125(LVC) vs 125(CBT)` | `INCOMPATIBLE` | 同 | 三态缓冲 ≠ FET 总线开关 |
| `04(AHC) vs 04(AHC)` | `NO_CONFLICT_EVIDENCE` | 同 | `schmitt=UNKNOWN` 不参与比较 |
| `240(AUC) vs 240(AUC)` | `NO_EVIDENCE` | 同 | 极性冲突降级 |
| `132 vs 999`（缺码） | `NO_EVIDENCE` | 同 | — |
| `char_only_diff` | `NO_EVIDENCE` | 同 | 字符差不定 P0 |
| 未签核副本 | `NO_EVIDENCE` | 同 | G1 门禁 |

## 4. 结构 / 证据校验

| 表 | `validate` | `verify-evidence` |
|---|---|---|
| main | OK | total=0 / error=0 / warn=0 |
| cand | OK | total=0 / error=0 / warn=0 |

- `tests.test_74_function_table`：**25/25 OK**（含候选两态断言）。

## 5. 核验发现（不阻断，但需知会）

| # | 发现 | 影响 / 建议 |
|---|---|---|
| F1 | candidate 的 `scope_note` 仍写「候选未签核，不得用于 P0」，已过时 | `scope_note` **不在 `content_hash` 字段内**，改它不会破坏签名；但它是签核产物的一部分，切换时应随新版本一并修正（需重新签核），或保留并在切换记录里说明 |
| F2 | main `signed_via=agent-delegation`、cand `signed_via=None` | 切换后主表将显示「本人签核」，属更权威状态；审计记录里保留两代签名即可 |
| F3 | `74LVC1G11` 的 PDF 在 `data/pdfs/`（被 `.gitignore` 排除） | 证据重放依赖该文件；已在 `SN74LVC1G11__sn74lvc1g11.source.json` 记录 URL/SHA。若换机或清库，需按 SHA 重新取回后才能 `verify-evidence` |

## 6. 切换 / 回滚方案（**未执行**，需逐次授权）

```powershell
# ① 备份已签核主表（保留原件）
Copy-Item qc\74_function_codes.json qc\74_function_codes.v1.0.2.signed.bak.json

# ② 切换（把已签核候选提升为主表）
Copy-Item qc\74_function_codes.v1.0.3.candidate.json qc\74_function_codes.json

# ③ 切换后自检（版本/签名/哈希 + 证据 + 门禁）
python qc\function_table.py validate
python qc\function_table.py show
python qc\function_table.py verify-evidence
python -m unittest tests.test_74_function_table -q

# ④ 回滚（任一项不符）
Copy-Item qc\74_function_codes.v1.0.2.signed.bak.json qc\74_function_codes.json
python qc\function_table.py validate
```

切换后预期：`version=1.0.3`、`status=SIGNED`、`hash=sha256:81e41911…`、
`usable_for_p0=True`、`judge(132 vs 11)=INCOMPATIBLE`。

## 7. 阶段隔离

| 变更 | 内容 | 是否与切换合并 |
|---|---|---|
| A. 主表切换 | 仅文件替换 + 自检 | 单独一步，单独提交 |
| B. 阶段 ② | 规范化数据集 / 页面两段式 / 两条 P0 判据接线 | **必须另起**，不混入切换提交 |

## 8. 结论

- 只读核验**全部通过**（签核可绑定、变更面最小、回归符合预期、两张表校验干净、规则未消费）；
- **主表未切换**，P0 判定保持 v1.0.2 现状（`132 vs 11` 仍为 `NO_EVIDENCE`）；
- 是否执行 §6 的切换，需你逐次确认；F1 建议在切换时一并处理（会触发重新签核）。
