# 50 件灰度写盘逐条核对（2026-10-31）

**口径**：`data/qc/grey_write50_v3/result.jsonl` 记 `write_cols = 44`。`write_sample`
只留前 8 条，所以**不以 `write_sample` 为核对对象** —— 从沙箱
`box/*.json` 里按 `e["columns"]` 取全量，每条回它的 `source.page / table / row`
打开原 PDF 该页，比对 `columns_raw` 与原文词。

取证工具：`.sandbox/show_page.py <pdf> <page> [--grep 词]`，走
`qc/page_evidence.extract_pages`（指定页、限时、带缓存），不扫整份 PDF。

## 结论：44 条全部核完，43 条数值正确，1 条数值错

| 料号 | 写盘条数 | 数值 | 备注 |
|---|---|---|---|
| DRV81620-Q1EVM | 10 | 10/10 | 含此前被 `write_sample` 截断的 TJ −40/150、Tstg −55/150（p6） |
| DS90LV011ATMF | 11 | 11/11 | 含被截断的 tTLH/tTHL 0.2/0.5/1.0 ns、fMAX 200/250 MHz（p3 t1） |
| CY74FCT163245CPACT | 8 | 8/8 | VOH 在 y=540（VCC=3.0V，IOH=–24 mA → 2.0/3.0），非 y=511 那条 |
| ADS5203IPFBG4 | 4 | 4/4 | Zero/Gain Error 的 `±` 见下文缺陷 3 |
| ADS7945SRTER | 3 | 3/3 | 数值对，但引用了 ADS7946 的表，见缺陷 2 |
| BQ2003PNG4 | 4 | 4/4 | 表头是 Minimum/Maximum（不是 MIN/TYP/MAX），落列正确 |
| **74FCT162H245CTPVCT** | 2 | **1/2** | **VOH 取错表**，见缺陷 1 |
| ADS8371IBPFBT | 1 | 1/1 | condition 混入脚注，见缺陷 2b |
| BQ29411PW | 1 | 1/1 | `I(CD_dis)` MIN 5 / MAX 12 µA |
| **合计** | **44** | **43/44** | |

## 缺陷 1（真错）：74FCT162H245 VOH 取到了另一颗料的表

`74FCT162H245CTPVCT__CY74FCT162_28H_29245T.pdf` 第 3 页并列三张同构表，标题分别是
`for CY74FCT16245T`（y=92）、`for CY74FCT162245T, CY74FCT162H245T`（y=200）。

- 实际写入：`MIN 2.4 / TYP 3.5`，`cond="VCC=Min, IOH=–15 mA"` → 取自**第一张表**
  （CY74FCT16245T，y=142 行）
- 本颗料应按**第二张表**（y=265）：`VCC=Min, IOH=–24 mA` → `MIN 2.4 / **TYP 3.3**`

两处都错：`TYP 3.5` 应为 `3.3`，测试条件 `–15 mA` 应为 `–24 mA`（162H245 是平衡驱动，
驱动能力 –24 mA）。MIN 恰好都是 2.4，所以肉眼与数值闸门都看不出异常。

**为什么 A12/A16/A17 抓不到**：值确实干净、确实没跨列、确实是那张真表 MIN/TYP 列里的
数字 —— 三道闸门校验的是「值有没有落到列里」，不校验「这张表属不属于这颗料」。

## 缺陷 2：取证口径 —— `source.table_title` 与料号不符

**2a. ADS7945SRTER（3 条）**：`source` 指向 p6 `ELECTRICAL CHARACTERISTICS: ADS7946
(Single-Ended)`，而本颗是 ADS7945（差分）。ADS7945 自己的表在 p4。两表 IDYNAMIC/ISTATIC
三行数值**恰好同值**（3.5/4、4/5、2.5/3 mA），所以这次没写错数 —— 但这是 TI 恰好同值，
不是管线校验过型号。同类情形换颗料就会串值。

**2b. ADS8371IBPFBT（1 条）**：`condition="750-kHz sample rate (includes only +VA current)"`。
括号里那句是表格脚注 (1)（p5 y=314「This includes only +VA current…」），不是测试条件。
数值 26/28 mA 正确，但 `condition` 被脚注污染，下游渲染会把它当条件展示。

## 缺陷 3：`±` 在 `columns` 里丢失（5 条，渲染无影响）

`±1.5` → `1.5`、`±1` → `1.0`，符号只留在 `columns_raw`：

- ADS5203IPFBG4：Zero Error `MAX ±1.5`、Gain Error `MAX ±1.5`
- DS90LV011ATMF：Power-off Leakage `TYP ±1 / MAX ±10`、Input High Current `±2/±10`、
  Input Low Current `±1/±10`

**影响面已查**：`json_to_txt.py:663` 是 `raws = entry.get("columns_raw") or entry.get("columns")`，
渲染优先读 `columns_raw`，所以产物里的 `±` 还在。风险只在**按 `columns` 做数值消费**的下游
（比较、取区间、告警）—— 那里 `±1.5` 会退化成单边上界 `1.5`。本次未改。

## 根因（缺陷 1 与 2a 是同一个）

同一 PDF 里多张同构表时，表标题中的**型号/变体没有参与消歧**，取「第一张命中的表」。
三张表结构完全一样（VOH/VOL/IODL…），只有标题里的料号与驱动电流不同，纯结构匹配必然
选第一张。修法方向：把 `table_title` 里出现的型号与 `basic_info.mpn` 做一致性校验，
不一致的表降权或直接 abstain；`source` 也必须带上这个校验结果。

## 未做的事

- 缺陷 1 未修（属新发现，不在本轮授权范围）。当前状态：`74FCT162H245CTPVCT` 的 VOH
  在产物里是 `TYP 3.5`，**错的**。要不要先对这类「同 PDF 多表」的件统一 abstain，需定夺。
- 缺陷 3 未修：改 `columns` 的符号会动写盘格式，需先确认没有下游按 `columns` 做数值比较。
