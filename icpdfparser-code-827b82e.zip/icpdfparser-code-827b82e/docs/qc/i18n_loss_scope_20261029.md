# 生产 `multi_language` 丢失范围核实（2026-10-29，只读）

> 触发：首批 10 件写回预检出现「现网无多语言 / 基线有多语言」。本条只做**范围核实**，
> 不写生产、不改代码、不重跑翻译。以下全部为磁盘与交付包的实测事实，脚本自证与工具输出均经第二路复核。

## 一、结论

| 项 | 数值 |
|---|---|
| 生产 `data/parsed/*.json` 总数 | **13,516** |
| 含顶层 `multi_language` | 13,281（98.26%） |
| **不含 `multi_language`** | **235**（1.74%） |
| 其中可证「曾有后丢失」 | **235**（100%） |
| 不可判定的 | **0** |
| 涉及不同型号（MPN） | **230**（5 个 MPN 在现网各存新旧两份 JSON） |

**所以「现网文件已经没有多语言了」需要收紧为：现网 1.74%（235/13,516）的件丢了多语言，
其余 98.26% 正常。** 丢失的这 235 件不是「从来没有」，而是**交付时有过、10-28 被覆盖掉了**。

丢失时间窗：**2026-10-28 11:12:13–11:57:03**（235 件的 mtime 全部落在这 45 分钟内，无例外；
其中 24 件在 11:53 之后，含 `TMDXOSKL138BET`、`LM358`、`F28P650*` 等，见第八节复核）。

## 二、三方基线对照（互为独立证据）

| 基线 | 位置 | 规模 | 带 `multi_language` | 与 235 件的交集 |
|---|---|---:|---|---:|
| 订货重解析前备份 | `data/parsed_backup_ordering/` | 231 | **231 / 231** | 230 |
| 多语言交付包 | `E:\workspace\delivery-20261026-i18n`（14 卷 zip + manifest） | 13,504 型号 | 命中型号 **230 / 230** 的 JSON 全带四语 | **230 / 230 型号全覆盖** |
| i18n 步前备份 | `data/parsed/parsed_backup_i18n/` | 20 | 0 | 0（与本批无关，是另一批「加 i18n 之前」的存档） |

- `parsed_backup_ordering` 的 231 件**全部**是 `ja/ko/de/es` 四语齐全（语言数分布：`{4: 231}`）。
- 交付包除 JSON 外还有 `<MPN>/<MPN>.{ja,ko,de,es}.html` 渲染变体：235 件中 **234 件**有四个变体，
  唯一无变体的是 `COP8-PGMA-44QFP`——但它的交付 JSON **仍带 `multi_language`**，只是渲染时没出语言版。
- 抽样比对 `2U3820-50QDBVRG4Q1`：`parsed_backup_ordering` 与交付包的 `ja.title` 逐字相同
  （`TPS3820-50-Q1 電圧モニタ 25ms リセット、SOT-23`），两基线同源。

## 三、逐件差异定性（不是「顺手改了点别的」）

现网 235 件与 `parsed_backup_ordering` 的 **230 件共有件**逐件比对顶层键：

```
缺失键:multi_language   230
```

即 **230/230 件唯一丢失的顶层键就是 `multi_language`**，没有别的键消失。
（共有键里 `ordering_info` 等字段值有更新——那是这轮订货重解析的预期产物，不是丢失。）

5 个 MPN 在现网各有两个 JSON（新旧 `pdf_hash` 各一份），两份都丢了多语言：

```
ADS1254E           ADS1254E_171641f0.json, ADS1254E_33559a06.json
D9LVRA2DEMR        D9LVRA2DEMR_6671b416.json, D9LVRA2DEMR_bbcc321b.json
F28P550SG8RSHR     F28P550SG8RSHR_3e85d26d.json, F28P550SG8RSHR_59c34897.json
F28P550SG9RSHR     F28P550SG9RSHR_3e85d26d.json, F28P550SG9RSHR_59c34897.json
F28P559SJ2PMRQ1    F28P559SJ2PMRQ1_3e85d26d.json, F28P559SJ2PMRQ1_59c34897.json
```

## 四、根因（代码级，且缺陷仍在 HEAD）

`qc/reparse_ordering.py` 的写回路径：

```python
old  = json.loads(f.read_text())          # 读旧档
shutil.copy2(f, backup / f.name)          # 先备份到 parsed_backup_ordering
rec  = pipeline.parse_pdf(t["pdf"], mpn)  # 重新解析，产出全新 doc
new  = rec["doc"]                         # 全新 doc，不含 multi_language
row["kept"] = ",".join(_carry_over(old, new))   # 只回带部分字段
(data_dir / f.name).write_text(json.dumps(new, ...))   # 整体覆盖写
```

`_carry_over()` 只回带两组白名单：

```python
KEEP_BASIC = ("identity", "datasheet_scope", "requested_mpn", "datasheet_url")
KEEP_PKG   = ("onboard_device", "form_factor")
```

**`multi_language` 不在任何白名单里**，而 `pipeline.parse_pdf` 只产出英文字段
（多语言是之后由 `translate_i18n.py` 原地回写的）。因此**任何一次重解析都会静默抹掉多语言**。

- 规模吻合：`165cabc` 提交说明「228 件重解析」，`parsed_backup_ordering` 有 231 件。
- **该缺陷在 HEAD 仍存在**：`git log -- qc/reparse_ordering.py` 三个提交（`99baf4d`/`8b50dc3`/`165cabc`）
  均未涉及字段回带；当前 `_carry_over` 仍无 `multi_language`。**再跑一次就会再丢一批。**

`qc/json_merge.py` 不受影响：它显式处理 `multi_language`（新 JSON 没有该键时保留旧值，
有则按语言合并），所以 V4 合并产物带着多语言，也解释了预检里「合并产物含多语言=是」而「现网=否」。

## 五、对首批 10 件写回的影响

10 件**全部**落在 235 内（逐件核验：现网 `multi_language=False`、`parsed_backup_ordering=True`）。
预检的两条多语言断言必然失败：

- 「合并产物含多语言」→ 是
- 「合并多语言 == 现网多语言」→ 否（合并有四语，现网没有）

**这不是合并产物的问题，是现网在 10-28 就已经丢了。** 在这 235 件恢复之前，
首批写回无法通过预检；若绕过预检直接写回，会把「现网无多语言」的状态继续固化，并把
`parsed_backup_ordering` 里最后一处同源多语言也覆盖掉（batch1 备份与现网同内容，不含多语言，救不回来）。

## 六、恢复选项（均未执行，等你授权）

| 方案 | 覆盖 | 成本 | 风险 / 说明 |
|---|---|---:|---|
| A 从 `parsed_backup_ordering` 回填 `multi_language` | 230 件 | 0 | 译文基于订货更新前的英文正文；需逐件确认英文侧改动不至于让译文失准 |
| B 从交付包 `<MPN>/<MPN>.json` 回填 | **235 件（全覆盖）** | 0 | 同 A 的时效问题；样本比对显示 A/B 内容一致 |
| C `translate_i18n.py translate` 重翻 | 235 件 | LLM/API 成本 | 译文会与既有交付不一致，需重渲染与人工抽检 |

建议：**先按 B 回填并逐件比对 A/B 差异**，差异件再决定是否走 C；不要直接 C 全量重翻
（会与已交付的 13,504 型号译文产生风格漂移）。

方案 B 的逐件映射表已生成（只读、本地）：`data/qc/i18n_restore_plan_20261029.csv`，
235 行 = 235 个生产文件 → `交付包分卷 / 包内成员 / 语言集合`，状态全部 `READY`
（`NO_DELIVERY`、`DELIVERY_NO_ML` 均为 0）。10 个首批件也都在表内，可直接逐行审阅。
注意：`data/parsed_backup_ordering` 只存在于生产机，本地 `data/parsed` 是 8,990 件的旧子集，
**真实回填必须在生产侧按本表执行**，不能用本地文件覆盖生产。

## 七、待你定

1. **是否执行恢复**（写生产，需单独授权；建议按 B，先 dry-run 出逐件 CSV 再写）。
2. **是否修 `qc/reparse_ordering.py`**：给 `_carry_over` 补 `multi_language`，
   并加一条守卫——重写前比对顶层键，**发现任何键丢失即整件回滚并报错**（本次事故正是无守卫所致）。
   这是本地代码改动，不碰生产。
3. 恢复完成后再走首批 10 件写回（原双开关流程不变）。
4. 是否需要把「顶层键不得丢失」做成 `qc_regression` 的常驻断言，覆盖后续所有重解析类脚本。

## 八、同日复核（2026-10-29 02:0x，只读重跑，不沿用初稿数字）

| 复核项 | 命令/方法 | 结果 |
|---|---|---|
| 现网重新全扫 | 逐文件 `'"multi_language"' not in bytes` | 13,516 / **235** / 230 MPN，与初稿一致 |
| 与回填计划表比对 | `plan.csv` ↔ 现网 235 名 | 双向差集 **0 / 0**，计划表即现网全集 |
| 丢失时间窗 | 235 件 mtime 极值 | **11:12:13 – 11:57:03**；初稿写 11:53 有误，**已更正**。晚于 11:53 的有 24 件，含 `TMDXOSKL138BET`、`LM358`、`F28P650*`、`FCT162*` 等 |
| 首批 10 件是否漂移 | 现网 vs `parsed_backup_batch1` SHA-256 | **0 件不一致**、0 件缺失 |
| 首批 10 件多语言 | 现网 / ordering 备份 | 现网 10/10 无；ordering 备份 10/10 有 |
| ordering 备份完整性 | 231 件逐件解析 | **231/231 带 `multi_language`**，解析失败 0；mtime 10-25 22:48 ~ 10-28 11:17 |
| ordering 覆盖 | 与 235 集求交 | 命中 **230**，缺 5 件；ordering 另有 1 件 `F280049PZQ` 不在 235 内 |
| HEAD 缺陷是否已修 | `grep -n "multi_language\|KEEP_" qc/reparse_ordering.py` | `KEEP_BASIC`/`KEEP_PKG` 仍无 `multi_language`，**未修** |

补充：`data/qc/` 在 `.gitignore` 内，`i18n_restore_plan_20261029.csv` 是本地工件，不进仓库。

## 九、回填源的结构校验（2026-10-29 02:0x，本地只读）

原先按"四语 × 五字段"卡的闸门只放过 176/235，调查后确认不是交付包残缺，而是**校验口径比实际约定更严**：

| 口径 | 结果 |
|---|---|
| 语言集合 | 235/235 均为 `de,es,ja,ko`，无缺语 |
| 每语言字段集合 | **176 件**为 `applications,description,features,meta,title`；**59 件**为 `description,meta,title`（按语言计 704 = 176×4、236 = 59×4） |
| 与 ordering 备份交叉验证 | 230 件共有文件名逐个比对，`multi_language` 结构**一致 230 / 不一致 0** |

结论：`features` / `applications` 本就是**选填**，59 件从交付时就只有三字段，不是丢失。闸门据此放宽为"`title`/`description`/`meta` 必填且非空，`features`/`applications` 出现时必须是列表"，235/235 通过。

这同时说明 **B 方案（交付包）与 A 方案（ordering 备份）在结构上等价**，B 只是多覆盖 5 件，不引入新形态。

## 十、回填工具（已提交，未对生产执行）

`qc/i18n_restore.py`（提交 `1895cfa`），默认 dry-run，只补一个顶层键：

| 机制 | 实现 |
|---|---|
| 范围锁定 | 必须传已审阅的 `--plan-csv`，不重新筛选；`--expect-count` 可再钉死件数 |
| 双开关 | 写生产必须 `--do-write --i-understand` 同时给出；与 `--verify-only` 互斥 |
| 顶层键守卫 | 写入前断言 `键集合 = 旧键集合 ∪ {multi_language}`，且所有旧键值深度相等，否则该件不写 |
| 备份不覆盖 | 备份目录已有同名文件即该件 FAIL，需 `--overwrite-backup` |
| 哈希三份 | 源 / 备份 / 写后新文件全部记账；备份哈希必须等于写前源哈希 |
| 原子写 | 临时文件 + `os.replace`，写后重新解析并复查 |
| 失败即失败 | 任一件 FAIL 退出码 1；单件异常也会保留已采到的源哈希 |

验证（全部在临时目录，未触碰生产）：

- `tests/test_i18n_restore.py` 9 例 unittest 全通过（`python -m unittest tests.test_i18n_restore`），包括"只新增一个键""旧键改动即拒写""备份冲突不动文件""幂等 SKIP_ALREADY""件数不符拒绝"；
- 交付包 235 行按放宽后的闸门校验 **235 / 235** 通过；
- 该脚本**从未**带 `--do-write` 指向生产目录运行过。

## 十一、并发写入面（2026-10-29 02:11，生产只读核查）

**更正**：此前"容器内只有 `run_server.py`、无 worker/celery 进程"的结论**作废**。实测：

| 容器 | 进程 |
|---|---|
| icpdf-server | `python run_server.py --host 0.0.0.0 --port 8000` |
| icpdf-render | `python run_worker.py --role render -l info` |
| icpdf-fetch | `python run_worker.py --role fetch -l info` |
| icpdf-llm | `python run_worker.py --role llm -l info` |

四个容器均以 **rw** 挂载 `/www/wwwroot/icpdfparser/data -> /app/data`，理论上任一容器都能写 `parsed/`。

| 写入面 | 结论 |
|---|---|
| 宿主 cron | root 共 13 条，`grep -i icpdf` **0 条命中**；`/etc/cron.d` 仅 `e2scrub_all`、`sysstat` |
| systemd timer | 仅 `droplet-agent-update`、`sysstat-collect`，与业务无关 |
| HTTP 写路由 | 存在 `items/parse`、`items/{key}/parse`、`pkgs/backfill`、`qc/rerender`、`qc/audit-log/{id}/revert`、`batches/{id}/export` —— 需人工/接口触发，非定时 |
| 实际写入 | `parsed/*.json` 最后写入 **2026-10-28 11:57:03**，此后 14 小时 **0 件**；worker 存活并有心跳（18:29），render 任务 17:11 成功但未改任何 parsed JSON |

### 波次归因（决定性证据）

| 写入时段 | 件数 | 是否带 `multi_language` |
|---|---|---|
| 10-27 23 时 | 1 | 是 |
| 10-28 08 时 | 1 | 是 |
| **10-28 10 时** | **438** | **全部保留** |
| **10-28 11 时** | **236** | **235 件丢失 / 1 件保留** |

两波同一天、相隔一小时、结果截然不同：10 时那波（走 `qc/json_merge.py`）全部保住，11 时那波（走 `qc/reparse_ordering.py`）恰好丢 235 件。**丢字段不是"写文件"这件事导致的，而是 `reparse_ordering` 这一条路径导致的**，与第四节代码级根因互相印证。

### 对写回窗口的要求

不能凭"没有 worker 进程"假定无竞争。写回前需满足其一：

1. 停掉 render/fetch/llm 三个 worker（`docker compose stop icpdf-render icpdf-fetch icpdf-llm`）并确认无在跑任务；或
2. 写回前后各采一次 `parsed/*.json` 的 mtime + 行数指纹，证明窗口内除脚本外无人写入。

两者都属于生产动作，需单独授权；本次未执行。

## 十二、根因修复：`reparse_ordering` 不再丢顶层键（2026-10-29，本地代码，未部署）

### 为什么必须修在写入路径上

`parse_datasheets.py` 里 `REQUIRED` 只在 `LANGS`（`ICPDF_LANGS`）非空时插入
`multi_language`，`LANG_RULE` 在未设置时**明确要求模型「不要输出 multi_language」**。
生产四个容器都没设该变量，所以重解析结果**必然**没有这个字段——这不是「确认无内容」，
是「这个运行时根本不生成」。任何「用新 doc 整体覆盖旧 doc」的路径都会因此丢字段。

### 改动（`qc/reparse_ordering.py`）

| 机制 | 行为 |
|---|---|
| `KEEP_TOP = ("multi_language",)` | 新 doc 没有 → 整块深拷贝带回；新 doc 只有部分语言 → 按语种补齐，新值优先 |
| `REQUIRED_TOP`（九个顶层键） | 新 doc 缺任意一个即判定「顶层键丢失」 |
| `top_key_loss(old, new)` | 只查「必须齐备」与「必须带回」两组；旧 doc 本来没有的键不算丢失，不凭空补造 |
| 守卫 | 带回后仍缺 → 把旧内容写回文件，状态 `key_loss`，明细记错误原因 |
| 退出码 | 出现任一 `key_loss` 整批返回 1，不混在 0 里 |

`REQUIRED_TOP` 取九个键，依据是本地 8,990 份生产快照的抽样：400 份里只有两种键集合，
391 份为九键、9 份为九键 +`multi_language`，没有出现杂项顶层键——按固定清单判，
不会误报人工追加的字段。

### 同类暴露面（已登记，本次未改）

`app/services/batch.py:263` 也是「新 doc 整体写盘」。batch 回填若命中同名文件，
同样会丢 `multi_language`。它属于解析主干，改动需另行评估与授权。

### 验证

- `tests/test_reparse_carry.py` 11 例：整块回带、深拷贝隔离、部分语言补齐、
  旧无则不造、丢失检出与回滚（端到端跑 `main()`，断言文件还原 + 退出码 1）。
- 全量 `python -m unittest discover -s tests`：480 例通过，1 例 skip。
- 边界：只改本地代码。未构建镜像、未部署、未触碰生产 `parsed/`、未动数据库。

## 十三、回填前逐件预检（2026-10-29 02:2x，只读，未写生产）

针对第四节「拆阶段」的第 1 步——**回填 235 件之前的最终预检**。全程只从生产读，
服务端不落临时文件（`tar -cf - -T -` 直接把 235 个目标文件流到本地暂存区），
生产 `parsed/`、备份目录、数据库均未改动。

| 预检项 | 方法 | 结果 |
|---|---|---|
| 计划表 ↔ 现网双向差集 | 现网 `grep -L '"multi_language"'` 全扫 13,516 件 vs `plan.csv` | 两边各 **235**，差集 **0 / 0** |
| 暂存副本可信 | 服务端 `sha256sum` 逐件 vs 本地 `sha256sum` 逐件 | **235 / 235 一致**，0 件不符 |
| 丢失时间窗复核 | 暂存件 mtime 极值 | 11:12:13 – 11:57:03（UTC），与第八节一致 |
| 回填工具 dry-run | `qc/i18n_restore.py`（默认 dry-run，`--expect-count 235`） | **PLAN=235，FAIL=0**；报告 `data/qc/i18n_restore_dryrun_20261029.csv` |
| 第二路独立核对 | `E:\workspace\.tmp_i18n\indep_check.py`（**不 import 回填工具**，自己开 zip、自己合并、自己哈希） | **235/235 OK**，见下 |
| A/B 基线等价 | 交付包 `multi_language` vs `parsed_backup_ordering` 同名件 | **SAME 230 / DIFF 0 / 无 A 基线 5** |
| 首批 10 件未漂移 | `parsed_backup_batch1` 10 件 vs 现网 SHA-256 | **10/10 一致**，合计 146,959 字节 |

第二路独立核对的逐件断言（全部 235 件通过）：

- 现网件可解析，**顶层键恰为 9 个**，无未知顶层键、无 `multi_language`；
- 交付包对应成员可解析，`multi_language` 语言集合为 `de,es,ja,ko`，每语 `title`/`description`/`meta` 均为非空字符串，`features`/`applications` 出现时必须是列表，无多余语言；
- 计划表 `delivery_langs` 与实际语言集合逐件相符；
- 合并后 `键集合 = 旧键集合 ∪ {multi_language}`，且 9 个旧键**深度相等**（回填只会新增一个顶层键）；
- `multi_language` 体积 2,434 – 20,161 字节/件，无空壳。

结论：**235 件的回填输入、范围、合并语义均已逐件核验通过**，不存在「计划里有、现网已变」或
「交付包缺语」的件。剩下的风险只剩写动作本身（并发窗口 + 写后校验），
按第四节仍是**未授权**状态。本节的暂存副本只用于预检，不作为写回源。

## 十四、首批 10 件合并产物的内容级核对（2026-10-29 02:3x，只读）

第四节要求预检「检查合并产物及多语言字段」。容器内 `/tmp/v4_writeback2/merged/`
共 223 个合并件，首批 10 件逐件核对如下（全部只读，未写生产）。

### 先说清楚两件事

1. **合并件与产物清单只在容器 `/tmp`**：容器重建/重启即丢。宿主机 `/tmp` 是 tmpfs
   且未重启（up 275 天），此前在宿主机上找不到 `/tmp/v4_batch1`、`/tmp/v4_writeback2`
   不是被清理，而是**根本在容器里**。写回前若重建镜像，需先确认这两处仍在。
2. **清单里的 `elec_delta` / `gate` 不能当证据**：这两列来自上游 `v4_final_safe_subset.csv`，
   `build_plan()` 只是原样搬运（`qc/v4_writeback_plan.py:71-148`），并不是
   「合并产物 vs 现网」的判定。本节的数字是自己重新算的。

### 逐件结果（值对/条目级，非仅计数）

| MPN | 电气条数 | 旧电气值对覆盖 | 订货行数 | 旧订货行覆盖 | 旧 feature 全文消失 | 结论 |
|---|---|---|---:|---:|---:|---|
| ADS1271IPW | 33→78 | 33/33 | 13→13 | 13/13 | 0 | 干净 |
| 5962-8868504HA | 24→27 | 24/24 | 32→32 | 32/32 | 0 | 干净 |
| 2U3820-50QDBVRG4Q1 | 50→54 | 50/50 | 24→25 | 23/24 | 0 | 订货 1 行被替换 |
| CC1000YZ | 11→14 | 10/11 | 6→6 | 6/6 | 0 | 1 条电气值对变动 |
| BQ2003S | 14→25 | 8/14 | 11→11 | 11/11 | 0 | 6 条电气值对变动 |
| CC2530F32RHAR | 18→36 | 17/18 | 6→6 | 6/6 | **4** | 4 条 feature 消失 |
| 2U3824-33QDBVRG4Q1 | 30→30 | 21/30 | 4→5 | **0/4** | **3** | 订货全替换 + 3 feature 消失 |
| CC1000-RTB1 | 11→23 | 7/11 | 4→8 | **0/4** | 0 | 订货全替换 + 4 值对变动 |
| CC3200-LAUNCHXL | 28→35 | 16/28 | 6→7 | **0/6** | **10** | 订货全替换 + 10 feature 消失 |
| TMDXOSKL138BET | **23→20** | **0/23** | 12→12 | 12/12 | **4** | **唯一净减：23 条电气全被换掉** |

### 判定口径（避免误报）

- 「旧电气值对覆盖」按 `(value, unit)` 归一后比对。名称不同但数值相同（如
  `High-Level Input Voltage` → `High-level input voltage`、`High-Level Output Source Current`
  → `High-level source current`）算保留——**改名不算丢失**，CC3200 的多数差异属此类。
- 「旧 feature 全文消失」是把旧 feature 归一后在**整份合并件**里搜，搜不到才是真丢。
  这类命中为 0 的项没有别的字段兜底。

### 结论与建议（未执行，等授权）

- **TMDXOSKL138BET 有明确回归**：电气 23→20 且旧 23 条一条不剩（19 条在整份文档里也找不到：
  主频、L1/L2 缓存、EDMA 通道、USB OTG、SATA、定时器、eCAP、GPIO、MDIO 时序），
  features 38→33 另有 4 条消失。按第四节第 3 步的「电气/订货未丢失」标准，
  写回后该件必然 FAIL。
- **CC3200-LAUNCHXL**：电气条数在涨，但 10 条 feature（RAM 容量、μDMA、定时器、
  TX 功率、RX 灵敏度、吞吐、时钟源、封装等）在合并件里**完全不存在**，属实打实的信息减少。
- **3 件订货行被整组替换**（CC1000-RTB1 / CC3200-LAUNCHXL / 2U3824-33QDBVRG4Q1）：
  条数都在涨，但旧行一条不剩。「条数不减」这一条闸门**验不出**内容替换。
- 建议二选一：把 TMDXOSKL138BET（以及 CC3200-LAUNCHXL）**剔出首批**再写回；
  或对这两件重做合并（旧电气/feature 取并集而不是替换），再按同一套方法复核。
  这属于范围变更，等明确授权。

## 十五、两条任务线的重叠：首批 10 件全部落在 235 件里（2026-10-29 02:4x，只读）

（这里指 V4 首批写回与 235 件多语言回填两条线。）

- **范围完全重叠**：首批 10 个目标文件名在 235 件清单里**10/10 命中**；10 件现网件
  均为 9 个顶层键、无 `multi_language`。所以「首批写回」与「多语言回填」落的是同一批文件。
- **多语言内容无分歧**：把 10 件合并产物里的 `multi_language` 与交付包同名 JSON 的
  `multi_language` 按规范化 JSON 取 SHA-256 比对，**10/10 逐字相同**（四语 `de/es/ja/ko`）。
  合并件显然是从同一份交付包取的该字段。
- **由此得出的顺序结论**（属范围/流程变更，未执行）：
  - 若先回填再写回：回填成果会被写回件覆盖。内容相同，无净损失，但多语一次白做，
    且 235 件的哈希账在写回后又变一次。
  - 若先写回再回填：回填工具对已含 `multi_language` 的件返回 `SKIP_ALREADY`，
    计划表里这 10 行必然不再是 `PLAN`，`--expect-count` 与「235 件全部写入」的账口径都要改。
  - 更省事的做法：**回填按 225 件执行**（235 减首批 10），10 件的多语言由首批写回带入。
    前提是首批写回件本身通过第十四节的复核。
  - 若按第十四节建议把 TMDXOSKL138BET / CC3200-LAUNCHXL 剔出首批，**这两件必须留在
    235（或 225）回填范围内**——剔出首批不等于它们可以不要多语言。

## 十六、并集补救路线实测，并修正第十四节的一处漏检（2026-10-29 02:3x，只读）

第十四节给的建议是「剔出首批」或「重做合并取并集」。为让这个选择有数可依，
拿本地副本做了一次离线并集实验：`b1/`（生产备份）+ `merged10/`（容器内合并件）
→ `union10/`（全部列表字段并集）与 `union10_core/`（只并 features / applications /
electrical / ordering_info）。脚本 `E:\workspace\.tmp_i18n\union_fix.py`，
只写本地目录，不连生产、不改计划表。指标落 `union_metrics.csv`。

### 先修正一处漏检：pin_configuration 没人查过

第十四节只核了电气、订货、feature，**没核 `pin_configuration`**。补查 10 件
（按「针号 + 名称」整行比对）：其余 8 件新旧逐行一致，两件不是：

| MPN | pin 行数 | 旧行仍在新件 | 针号集合 |
|---|---|---|---|
| TMDXOSKL138BET | **95 → 6** | **0/95** | 95 → 6 |
| CC3200-LAUNCHXL | 87 → 64 | 4/87 | 64 → 64 |

TMDX 那份合并件的引脚表只剩 6 行（`EMA_WE / GP3[11]` 起头），旧表 95 行一行不剩——
和电气 23 条全被换掉是同一种现象：**新解析取到的不是同一段/同一份内容**。
CC3200 则是把「一个针号多行」重排成「一个针号一行」，行数降、针号集合不变，
性质不同但同样是整表重写。

### 并集实验的两个结果

1. **结构上成立**：10 件并集候选都通过校验——旧行全在、合并行全在、顶层键与
   `multi_language` 与合并件逐字相同。也就是说「并集」这条路在机制上走得通。
2. **但不能机械地并**：`pin_configuration` 一并就把两套行结构拼在一起，
   CC3200 +8,713 行、TMDX +950 行、2U3824 +223 行，文件体积翻倍且表意混乱；
   所以 core 版把这几个字段排除在外。
   更要紧的是**整行相等会大量重复「改写」而非丢失的内容**：TMDX 旧 feature 38 条里
   26 条「整行不在合并件」，逐条看才发现多数只是把逗号换成分号、补了 the/of——
   真正丢的仍是第十四节那 4 条；2U3824 电气补进来的 25 行里有 23 行与新表同参数名。
   所以「取并集」不是 append 一下就行，必须是**改名感知 + 归一去重**的合并。

### 结论（未执行，等授权）

- **TMDXOSKL138BET 证据已足够定性**：电气 23 条全被替换、pin 95→6、feature 38→33。
  建议直接**剔出首批**，不必再为这一件重做合并。
- **CC3200-LAUNCHXL**：pin 87→64 属整表重写、另有 10 条 feature 在合并件里找不到，
  是否可接受要人来判；倾向同样剔出首批，留待单件复核。
- 并集候选件（`union10_core/`）留档，作为将来做改名感知合并的基线，**不作写回源**。
- 若仍要走「重做合并」，需要改 `qc/json_merge.py` 的合并语义（当前
  `features/applications` 是整体替换、`specs` 子键整体替换），属代码变更，另行授权。

## 十七、DB 侧实证：谁在写、写了多少、派生产物已经不同步

前面十四～十六节都只看文件。这一节补 DB 侧，回答三个写回前必须先答的问题：
**（1）这 10 件的六类产物是否真的存在；（2）丢失那一波到底是不是解析/渲染流水线干的；
（3）丢失范围是不是就是 235 件。** 全部只读（`mode=ro`）查询，未写一行。

### 1. 路径解析：DB 存容器路径，六类产物全部可解析

`item` 表里存的是 `/app/data/parsed/...`，宿主机必须映射 `/app/data` →
`/www/wwwroot/icpdfparser/data`（`config.resolve_artifact` 做的就是这件事）。
按此映射，10 件**全部** `status=done`、`stage=交付物已生成`，且
`json / txt / alt_json / alt_html / symbol / seo` **六条路径 10/10 全部 stat 成功**：

| item.id | MPN | json | txt | alt_json | alt_html | symbol | seo | 六件合计字节 |
|---|---|---|---|---|---|---|---|---|
| 3351 | ADS1271IPW | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 48,499 |
| 15036 | 5962-8868504HA | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 43,647 |
| 15024 | 2U3820-50QDBVRG4Q1 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 51,963 |
| 15872 | CC1000-RTB1 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 32,473 |
| 19130 | TMDXOSKL138BET | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 50,980 |
| 1618 | CC3200-LAUNCHXL | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 58,513 |
| 13114 | BQ2003S | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 43,573 |
| 15728 | CC2530F32RHAR | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 36,806 |
| 15678 | CC1000YZ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 32,500 |
| 15027 | 2U3824-33QDBVRG4Q1 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | 39,747 |

**推论（对写回边界的影响）**：只覆盖 `json_path` 的写回，会让这 10 件各留下
**5 个未更新的派生产物，合计 50 个文件**。渲染不是"可选打磨"，而是这批货要落地
就必须做的第二步——但它属于第四阶段，需单独授权。

### 2. 派生产物**现在就已经不同步**（不是写回后才不同步）

同一批 JSON 与其余五类产物的 mtime 分成三代（UTC）：

| 产物 | mtime（UTC） | 对应 +08:00 |
|---|---|---|
| `alt_json / alt_html / symbol / seo` | 2026-10-24 03:30–05:03 | 10-24 11:30–13:03 |
| `txt` | 2026-10-26 02:30–02:38 | 10-26 10:30–10:38 |
| `json` | 2026-10-28 11:27–11:57 | **10-28 19:27–19:57** |

也就是说 10-28 改完 JSON 之后**没有任何下游产物被重算**。线上详情页/SEO/结构化数据
目前基于的是 10-26 与 10-24 的旧 JSON。这一点独立于"要不要写回"——**现状本身已经不一致**，
应当作为第四阶段的输入，而不是等写回完成才发现。

### 3. 丢失那一波**没有走解析/渲染流水线**（事件表为空）

| 查询 | 结果 |
|---|---|
| 全表 `event` 行数 / 最大 `created_at` | 100,104 / **2026-10-28T17:11:45+08:00** |
| 10-28 按小时分布（+08:00） | 06:1、07:4、16:680、17:1,036，**17 点之后为 0** |
| 19:00–20:30（+08:00）全表事件 | **0** |
| 这 10 件的历史事件 | 68 条，最后一条 **2026-10-24T13:03:51+08:00**（kind=`done`） |
| 这 10 件事件构成 | start 19 / download 10 / nodata 8 / parse 10 / render 10 / done 10 / error 1 |
| 这 10 件 `updated_at` | 全部 2026-10-24（11:30–13:03） |
| 这 10 件 `last_parsed_at` | 全部 2026-10-24（11:24–13:03） |

**结论**：文件在 10-28 19:27–19:57（+08:00）被整体重写，但
**没有 `parse` / `render` / `done` 事件，`last_parsed_at` 与 `updated_at` 一动没动**。
正常流水线每写一次都会落事件并抬 `last_parsed_at`，所以这一波是**绕过流水线的批量文件写入**
（脚本 / 手工 / 容器外操作），不是 parse 也不是 render。

这条对第六节"并发写入"的直接意义：**事件表不能用来判断有没有别人在写文件**——
这一波就是"写了 236 个文件、事件表零记录"的现成反例。写回前后必须靠
`parsed/*.json` 的 mtime/哈希指纹自证窗口空闲，不能拿 `event` 或进程列表当证据。

### 4. 范围核实：这一波就是 236 个文件 = 235 件 + 1 个越界文件

按 mtime 落窗（2026-10-28 11:12–11:57 UTC）逐个 stat `parsed/*.json`：

| 指标 | 结果 |
|---|---|
| 窗口内 JSON 总数 | **235**（11:15–12:05 严格窗）；放宽到 11:12 起为 236 |
| 其中属于 235 件清单 | 234（严格窗）/ **235**（含 11:12:13Z 的 `5962-8868505HA_93cfdea9.json`） |
| 其中**不在** 235 件清单 | **1**：`F280049PZQ_7a0c759c.json`（11:53:32Z） |
| 235 件里文件缺失 | 0 |
| 窗口内其他 `parsed/*.json` | 无 |

逐分钟分布 11:27→11:57 连续（每分钟 5–12 个），加上 11:17、11:19 两个零星点，
形态是**单线程顺序重写**，不是多进程并发。

两个必须记下的细节：

- **越界 1 件**：`F280049PZQ_7a0c759c.json` 落在同一波里、但**仍然保留
  `multi_language`（de/es/ja/ko），顶层 10 键**。所以这一波不是"无差别剥掉 multi_language"
  的机械脚本，至少有一条分支会把 ml 写回去。回填范围要不要把它算进来，需要人来定。
- **`5962-8868505HA` 与首批的 `5962-8868504HA` 共用文件名后缀 `93cfdea9`**：
  后缀哈希不能当 MPN 唯一键，任何按名匹配都必须用**完整文件名**，不能截后缀。

### 5. 235 件当前多语言状态（写完这一波之后）

逐件解析 235 个 JSON：**有 `multi_language` 的 0 件，没有的 235 件**。
这与第十四节的 10 件、以及更早的"现网文件已经没有多语言"完全一致，
范围**没有扩散到 235 件以外**（越界那 1 件反而还在）。

### 6. 现在有没有人在写（写回前的现场检查）

- `parsed/*.json` 近 1 小时修改数：**0**；近 24 小时 675 个
  ——**此处原写「约 439 个属正常流水线」是错的，已由第十八节更正**：
  实测 675 = 438（10:22:46Z 整批复制）+ 236（11:12–11:57Z 重写）+ 1。
- `/proc/*/fd` 扫描：**没有进程**在 `icpdfparser/data` 下持有句柄。
- 容器：`icpdf-llm` / `icpdf-server`（16h）、`icpdf-render` / `icpdf-fetch`（18h）、
  `icpdf-redis`（5d）在跑；同机还有 `tqx-*` / `xgwl_*` 共 9 个与本事无关的容器。
  **容器在跑 ≠ 有写入**，如第三节所述，判断依据只能是文件指纹。

### 结论（仍未执行任何写生产动作）

1. 这 10 件的六类产物齐备、路径全部可解析；一旦只写 JSON，会留下 50 个过期派生产物。
2. 丢失那一波是**流水线之外的批量文件写**，事件表零记录、`last_parsed_at` 未抬；
   所以写回窗口的并发判定不能依赖 `event`/进程列表，必须用文件指纹。
3. 丢失范围 = **235 件整**，外加 1 个越界的 `F280049PZQ`（它仍带 ml）。
   越界件是否纳入回填/写回范围，属范围变更，等授权。
4. 派生产物**当前已不同步**（json 10-28、txt 10-26、其余 10-24），渲染的必要性与
   写回无关地已经成立。

## 十八、修正第十七节：10-28 是**两次**批量写，ml 丢失仍锁定 235 件

第十七节第 6 小节的 24 小时口径**写错了**，此处更正并补上漏掉的一次批量写。
错在：我先用「24h 675 个」减去「波内 236 个」得出「约 439 个属正常流水线」，
但**没有实测**那个流水线窗口。实测结果与推断相反。

### 实测：72 小时内所有 JSON 的 mtime 分布（UTC）

| 小时桶（UTC） | 对应 +08:00 | 文件数 |
|---|---|---|
| 10-27 23Z | 10-28 07:00 | 1 |
| 10-28 08Z | 10-28 16:00 | **1** |
| 10-28 10Z | 10-28 18:00 | **438** |
| 10-28 11Z | 10-28 19:00 | **236** |

即 24 小时内的 675 个 = 438 + 236 + 1。**16:00–17:11（+08:00）那批事件
并没有对应任何 `parsed/*.json` 的写入**（08Z 只有 1 个文件），
所以「近 24h 其余都是正常流水线」的说法不成立。

### 两次批量写的性质完全不同

| | 第一波 | 第二波 |
|---|---|---|
| 时间（UTC） | **10:22:46 单秒内全部完成** | 11:12:13 – 11:57:03（逐分钟 5–12 个） |
| 文件数 | 438 | 236 |
| 在 235 件清单内 | **0** | 235（+ 越界 1 件） |
| 当前带 `multi_language` | **438/438 全带** | **235 件不带**，越界件带 |
| 与交付清单 `manifest.csv` 的关系 | 405/438 可对上，`last_parsed_at` **全部是 2026-10-23** | 属 10-24 解析的 235 件 |

判定：

1. **第一波是"整批复制"**：438 个文件落在同一秒，是 `cp`/解包类批量写入的特征
   （正常解析不可能 438 件同一秒完成）。它们**全部保留 ml**，说明写入源本身带 ml，
   即操作方当时手里**确实有带 ml 的批量源**。
2. **第二波是"逐件重写"**：跨 45 分钟、逐分钟数个，形态与单线程解析/写入循环一致，
   结果 235 件**全部丢 ml**。
3. **ml 丢失范围仍精确锁在 235 件**：438 件带 ml、越界 1 件带 ml、235 件不带。
   第十七节「范围未扩散」的结论成立，但依据换成上面这张表，而不是原来的减法。

### 对结论的影响

- 「写回范围 = 首批 10 件」不变；「ml 回填范围 = 235 件」不变。
- **新增一条可用线索**：10:22:46 那一波证明操作者当时持有带 ml 的批量源，
  与本地交付包 `delivery-20261026-i18n` 口径一致。回填源的选择因此不只有交付包一种，
  但交付包仍是唯一**已核对**的来源。
- **写错数字这件事本身要记**：这是本轮第二次「先推后验」导致的口径错误
  （第一次是第十六节的 exact-row 匹配）。凡「总数减去已知部分」得来的数，
  必须单独实测后再写进文档。

## 十九、关键发现：交付包的 `multi_language` **不能直接搬到现网 JSON 上**

这一节回答「回填是不是把交付包的 ml 塞回去就行」。**不是。** 证据如下。

### 1. 基线可信：本地 `prod235/` 与生产逐字一致

用远端 `sha256sum`（235 个文件）× 本地 `sha256` 比对：**235/235 逐字相同**。
（顺带确认生产自 10-28 那波之后没有再变。）

### 2. 去掉 ml 之后，交付包与现网**仍然 235/235 不相等**

对每一件：取交付包 JSON，删掉 `multi_language`，与现网 JSON 做去格式化规范化比较。

| 结果 | 件数 |
|---|---|
| 相等（即"现网 = 交付包减 ml"） | **0** |
| 不等 | **235** |

不等的顶层键：`basic_info / features / specs / seo / ordering_info / metadata` 几乎每件都有，
另有部分件的 `alternatives / pin_configuration / applications`。
举例（2N7001TQDCKRQ1）：

- 现网 `basic_info`：`category` = "Integrated Circuits (ICs)"，`subcategory` = "Logic - Buffer, Driver, Transceiver"
- 交付包：`category` = "Integrated Circuits (ICs) / Logic"，`subcategory` = "Signal Converters"
- description / features 均有措辞差异（"up and down translation across 1.65 V to 3.6 V supply rails"
  vs "up/down translation across 1.65 V to 3.6 V"）

**结论：现网与交付包是两套不同的构建，不是同一份文件少了个 ml。**

### 3. 数量级：交付包**不是**现网的超集

按字段计行数，逐件比较（prod_more = 现网更多 / deliv_more = 交付包更多 / same）：

| 字段 | 现网更多 | 交付包更多 | 相同 |
|---|---|---|---|
| `ordering_info` | **196** | **0** | 39 |
| `specs.electrical` | 76 | 117 | 42 |
| `features` | 59 | 40 | 136 |
| `pin_configuration` | 38 | 23 | 174 |
| `alternatives` | 58 | 50 | 127 |
| `applications` | 10 | 22 | 203 |
| `basic_info.description` 长度 | 114 | 116 | 5 |
| `multi_language` | 0 | **235** | 0 |

`ordering_info` 一行最能说明问题：**196 件的现网订货行比交付包多，0 件更少**。
所以「整件用交付包覆盖」会**删掉 196 件里现网独有的订货行**，属于内容损失，不可取。

### 4. `multi_language` 的结构决定了它绑死在交付包自己的英文源上

```
multi_language = { ja, ko, de, es } × { title, description, meta, features[], applications[] }
```

即 ml 是**交付包那份** `basic_info`/`seo`/`features`/`applications` 的译文。
而这两份英文源本身不同：

| 比对项 | 集合相同 | 集合不同 |
|---|---|---|
| `features` | 96 / 235 | **139 / 235** |
| `applications` | 172 / 235 | 63 / 235 |

`features` 差异多数是 1–2 条（如 (1,1) 26 件、(2,2) 9 件），但存在极端：
`3530ECUSAGRM` 现网 12 条 vs 交付包 49 条（差 43 条）。
description 长度在 230/235 件上不同。

**所以把 ml 直接注入现网 = 让 139 件的日/韩/德/西译文对应不上现网英文的 feature 列表**
（英文列 N 条、译文列 N±k 条；description 也是按另一份英文翻的）。
这正是"文案全量一致性"上不能接受的那类错位。

### 5. 还有 5 个 MPN 的对应关系本身不确定

235 个文件名只对应 **230 个唯一 MPN**——5 个 MPN 各有两个文件，且内容不同：

| MPN | 两个文件 | 内容 |
|---|---|---|
| ADS1254E | `_171641f0` / `_33559a06` | 不同 |
| D9LVRA2DEMR | `_6671b416` / `_bbcc321b` | 不同 |
| F28P550SG8RSHR | `_3e85d26d` / `_59c34897` | 不同 |
| F28P550SG9RSHR | `_3e85d26d` / `_59c34897` | 不同 |
| F28P559SJ2PMRQ1 | `_3e85d26d` / `_59c34897` | 不同 |

交付包每个 MPN 只有一份 `<MPN>/<MPN>.json`，**这 10 个文件该配哪份 ml 无法从数据判定**，
必须先人工确认（对应的是不同数据手册/不同封装时，译文也会不同）。

### 6. 因此回填只有三条路，且都不是"照抄"

| 方案 | 做法 | 代价 |
|---|---|---|
| **A 只注入 ml** | 保留现网全部内容，从交付包取 `multi_language` 加入 | 139 件 feature 译文与英文条数/内容对不上，63 件 applications 对不上，230 件 description 依据不同 |
| **B 整件覆盖** | 用交付包整份文件覆盖现网 | **删除 196 件的多余订货行**、76 件多余电气行等，内容损失 |
| **C 用现网内容重翻** | 以现网 JSON 为源，重跑翻译生成 ml | 语义最干净；要动翻译流水线，成本与授权另计 |

**建议 C**；若走 A，必须先逐件确认那 139+63 件的译文抽换是否可接受；
**B 不建议**。5 个双文件 MPN 无论走哪条都要先人工定对应关系。

### 未做

- 未写生产、未注入 ml、未覆盖任何文件、未渲染、未改数据库、未启停容器。
- 未对 5 个双文件 MPN 做对应关系判定。
- 未评估方案 C 的翻译成本（件数 × 语言数的实际 token 量需另测）。

## 二十、翻译流水线审查、235 件逐件计划与 5 件隔离样本

本节全部为只读审查 + 隔离目录样本：生产文件未写、未渲染、未改库、未启停容器、未动 checkpoint。

### 1. 生产实际用的翻译入口（实证，不是推断）

| 项 | 实证 |
|---|---|
| 入口脚本 | `/www/wwwroot/icpdfparser/translate_i18n.py`，sha256 `f731ef987b09219c…` |
| 与仓库版关系 | 逐字节比较仅在行尾不同（服务器 LF / 仓库 CRLF），内容一致 |
| provider | 日志：`[provider] LLM qwen-flash @ https://dashscope.aliyuncs.com/compatible-mode/v1` |
| 密钥来源 | `DASHSCOPE_API_KEY` 在 `icpdf-server` 容器环境里；宿主机 `.env` 无 `ICPDF_TRANSLATE_*` |
| 并发 | `concurrency=16`（命令行传入，脚本默认 8） |
| 触发方式 | 人工 CLI。`crontab -l` 与 systemd timer 里都没有 translate_i18n 条目 |
| 提示词版本 | `LLMProvider.SYSTEM` sha256 前 16 位 `7b955dca23b029a4` |

两代 checkpoint 都在：

| 文件 | 行数 | 结束时间 | 说明 |
|---|---|---|---|
| `data/translate_state.jsonl` | 13,298 | Oct 25 23:01 | 初版，seo 三字段 |
| `data/translate_state_full.jsonl` | 11,458 | Oct 26 02:28 | `scope=full`，首条 `2026-10-25T23:04:18` |

注意 `data/translate_full.log` 其实是 **v1(seo)** 的日志：开头「待翻译 13,279 型号 × 4 语种」，结尾「完成 13,278，失败 1。state: data/translate_state.jsonl」。full 那一轮的日志没有留存。

没有 Google provider 的痕迹（用户也已确认无翻译 API key，只走百炼 qwen-flash）。

### 2. 语言与字段范围

- 语言：`ja,ko,de,es`（`LANGS_DEFAULT`，`--langs` 可覆盖）。
- 字段只有 5 个：

| ml 键 | 源 |
|---|---|
| `title` | `seo.title_en` |
| `meta` | `seo.meta_description_en` |
| `description` | `basic_info.description` |
| `features[]` | 顶层 `features[]` |
| `applications[]` | 顶层 `applications[]` |

`basic_info` 的其它字段、`specs`、`pin_configuration`、`ordering_info` **不在翻译范围**。所以「四语完整」只能指这 5 个字段，不能表述为整页四语。

### 3. 写入与覆盖语义

- 读整文件 → 只改 `multi_language` → 整文件 `json.dumps(indent=2, ensure_ascii=False)` 写 `.json.tmp` → `os.replace()` 原子替换。除 `multi_language` 外顶层键不增不减，但**整文件会被重新格式化**。
- 合并：`ml[lang] = {**existing, **entry}`，且已有字段不重翻 → 中途失败可续跑，不会覆盖已恢复的语种。
- 备份：`backup_once` 只在目标不存在时复制。现有 `data/parsed/parsed_backup_i18n/` 只有 **20 个文件**（Oct 25 20:18，dry-run 遗留），**不能**当作这 235 件的旧译文恢复源。
- 互斥：`_check_no_other_instance()` 只 `pgrep translate_i18n.py translate`，拦不住 `qc/json_merge.py`、手工 `cp` 或其它脚本 → 写回窗口仍要靠文件指纹检查（第十七节第 6 小节），不能只看进程。

### 4. Checkpoint 陷阱：按原命令跑会静默只恢复 59 件

用生产 checkpoint 在 235 件快照上跑 `scan`：

```
--state-file state_full.jsonl   → 完全缺失 59， 本次待翻译 59
--state-file 不存在.jsonl        → 完全缺失 235，本次待翻译 235
```

原因是 235 件里有 **232 件在 seo checkpoint**、**176 件在 full checkpoint** 中被记为已完成。真实执行时不指定 `--state-file`，176 件会被算成 `skipped_done`，从统计里直接消失，命令照样报成功。执行时必须显式给独立状态文件（如 `data/translate_state_restore235.jsonl`），原有 checkpoint 一律不动。

### 5. 235 件逐件计划

计划文件：`docs/qc/i18n_restore_plan_20261029.csv`（235 行）。

| 项 | 数 |
|---|---|
| 文件 / 不同 stem | 235 / 230 |
| 双文件 stem（各 2 个文件，共 10 件） | 5 |
| MPN 与文件名硬不一致 | 6 |
| 同 MPN 多文件组 | 6 组（`D9LVRA2DEMRQ1` 一组 3 个文件） |
| **建议排除，待人工定归属** | **17** |
| 可直接进入翻译 | 218（源字符 426,522） |
| 5 个源字段缺失 | 0 件（title/meta/description/features/applications 全部非空） |

每行记录：`mpn`、`stem`、`prod_filename`、`prod_sha256`、`src_version`（5 字段规范化哈希）、各字段哈希、`n_features`、`n_apps`、`src_chars`、`src_missing`、`ml_now`、`seo_ckpt`、`full_ckpt`、`target_langs`、`identity_flags`、`exclude_recommended`。`src_version` 就是「翻译结果对应的源内容版本」，英文再变时可比对。

`prod_sha256` 在本次计划生成前已用生产侧实时 `sha256sum` 重算比对：**235/235 与本地快照一致**，快照仍然有效。

### 6. 隔离样本：5 件、20 次调用、0 问题

选样覆盖小件、中位、最大件、双文件 MPN、MPN 与文件名不一致件：

| 文件 | 源字符 | 特征 | 耗时 |
|---|---|---|---|
| `74AHC1G126DCKTG4_6824188e.json` | 728 | 最小 | 20.2s |
| `5962-8404701VCA_bba29f13.json` | 729 | 军用编号 | 18.6s |
| `74LVCH8T245NSRG4_30d0c1c8.json` | 1,368 | 中位 | 34.7s |
| `F28P550SG9RSHR_3e85d26d.json` | 5,892 | 85 条 features、双文件 | 105.9s |
| `TMDXOSKL138BET_91a3bef2.json` | 6,178 | 最大件、MPN 与文件名不一致 | 105.9s |

做法：把 5 个文件复制到服务器 `/tmp/i18n_sample/data/`，用**与生产同版本**的脚本、同 provider/模型，输出只落 `/tmp/i18n_sample/out/`；生产目录没有任何写入。

| 检查项 | 结果 |
|---|---|
| 顶层键 | 5/5 件只**新增** `multi_language`，无删除、无改名 |
| 语言 × 字段 | 5 件 × 4 语种，每语种 5 字段齐全 |
| features / applications 条数 | 5/5 与源一致（85/18、38/9 等） |
| 元器件编号丢失（独立复核，不采信脚本自证） | **0** |
| 空值 | **0** |
| ko/de/es 混入中日文字符 | **0** |
| 整句英文回退 | **0** |
| 台账 | usage prompt 24,000 / completion 28,638 |

译文抽查与英文源逐句对应，未发现凭空补写：例如 `74LVCH8T245NSRG4` 的 ja `meta` 出现「映像監視、スマートメーター、産業用途」，英文源 `meta_description_en` 确有 “video surveillance, smart meters, and industrial applications”。

### 7. 费用（qwen-flash ≤128K 档：输入 ¥0.15/M、输出 ¥1.5/M）

| 范围 | prompt | completion | 估算 |
|---|---|---|---|
| 235 件 | ≈1.128M | ≈1.346M | ¥0.17 + ¥2.02 ≈ **¥2.19** |
| 218 件（排除 17 件后） | ≈1.046M | ≈1.249M | ≈ **¥2.03** |
| 本次 5 件样本（20 次调用） | 0.024M | 0.029M | ≈ ¥0.047 |

按件均推算（5 件样本）：4,800 prompt + 5,728 completion tokens/件，235 件耗时约 14 分钟（concurrency 16）。Batch 接口 5 折可到约 ¥1.1，但要改调度，不建议为这点钱动架构。以上为估算，实际以账单为准。

### 未做

- 未写生产、未注入 ml、未覆盖任何文件、未渲染、未改数据库、未启停容器。
- 未执行 235 件全量翻译；样本只存在于服务器 `/tmp/i18n_sample/` 与本地 `.tmp_i18n/sample_out/`。
- 未修改、未移动、未重建生产 checkpoint 文件。
- 未对 17 件身份存疑项做归属判定，也未把它们移出范围（只是在计划里标 `exclude_recommended=yes`）。
- 未更换 `qc/json_merge.py` 的合并语义，也未改 `parse_datasheets.py` 的 `ICPDF_LANGS` 默认值。

## 二十一、阶段 1–2 执行记录：冻结 218 件、隔离环境 10 件候选

生产侧仍只读：只从生产复制了 10 个文件到 `/tmp/i18n_pilot_10/data/`，写入全部落在 `/tmp`。

### 1. 冻结范围与哈希复核（阶段 1）

- 范围以 `docs/qc/i18n_restore_plan_20261029.csv` 为准：`exclude_recommended` 为空 = **218 件**，合计 426,522 源字符；17 件身份存疑项不进入任务。
- 生产侧对这 218 件实时重算 SHA-256，与计划 CSV 逐件比对：**218/218 一致**，无缺失文件。
- 冻结文件：`names218.txt`（文件名）+ `names218.sha`（哈希），供后续批次直接复用，脚本不再扫描目录取范围。

### 2. 试点选样规则（固定、可复现）

从 218 件里取 10 件，规则写死在 `pick_pilot10.py`：

- 按 `src_chars` 排序取 8 个等距分位（0%、14%、…、100%），覆盖 728–5,769 字符；
- 追加 1 件 `identity_flags=mpn_variant`（`74CBTLV3257RGYRG4`）；
- 追加 1 件不在 full checkpoint 里的最小件（`FCT162H245ATPVCTG4`），用来同时验证"续跑"和"新翻"两条路径；
- 去重后补齐到 10 件。

结果是 10 件里 **7 件在旧 full checkpoint 中、3 件不在**，两条路径都走到了。

### 3. 隔离试跑（阶段 2）

| 项 | 值 |
|---|---|
| 入口 | 生产同款 `translate_i18n.py translate --scope full --provider llm` |
| 模型 | `qwen-flash` @ DashScope compatible-mode（与生产一致） |
| 隔离目录 | `/tmp/i18n_pilot_10/data/`（10 个生产文件副本） |
| 独立 checkpoint | `/tmp/i18n_pilot_10/state.jsonl`（新文件，未复用旧状态） |
| 备份 | `--backup` 落在 `/tmp/i18n_pilot_10/data/parsed_backup_i18n/`，10 个原件齐全 |
| 并发 | 5 |
| 结果 | 10/10 成功、失败 0；`EXIT=0`，耗时 157s |
| 日志 | 「待翻译 10 型号」，没有出现 checkpoint 跳过 |

试跑前后生产侧核对：

| 检查 | 结果 |
|---|---|
| 生产 `parsed/*.json` 文件数 | 13,516 → 13,516 |
| 10 个试点文件生产 SHA-256 | 前后一致 |
| `data/translate_state*.jsonl` | mtime 仍为 Oct 25 23:01 / Oct 26 02:28，未被读写 |
| 残留锁文件 | 无 |

### 4. 候选复核（独立脚本，不采信脚本自证）

40 行 = 10 件 × 4 语种：

| 检查项 | 结果 |
|---|---|
| 5 字段齐全（title/meta/description + features/applications 非空） | 40/40 |
| features / applications 条数与源一致 | 40/40 |
| 顶层键 | 10/10 只新增 `multi_language` |
| 非 ml 内容与源逐字节等价（规范化 JSON 比较） | 10/10 |
| `src_version` 与计划 CSV 一致（译文绑定的源版本） | 40/40 |
| 元器件编号丢失 | 39/40，1 例见下 |
| ko/de/es 混入中日文字符 | 0 |
| 整句英文回退 | 0（有 5 处元素与源相同，均为 `JTAGLOCK`、`ESD > 2000V`、`VCC = 5V ± 10%` 这类标识/参数串，属正常） |

**元素对齐**（本轮新增的检查）：对每条 features/applications，取源元素里的「数值+单位」锚点，要求出现在同下标译文里。de/es 会把小数点写成逗号、单位加空格（`4.6-V` → `4,6-V`），归一化后统计：**216/216 锚点全部保位**。`BQ2003S` 本身无数值锚点，不计入。

**唯一告警**：`74AHCT1G08DCKTG4` 的 es `meta` 把 `SN74AHCT1G08DCKTG4` 缩成 `SN74AHCT1G08`（丢了封装后缀），脚本已记 `[warn]` 并保留译文；同件 `title` 的完整 MPN 未丢。这是"要不要修 meta 里的 MPN"的策略问题，不是流水线故障。

### 5. 费用与耗时

| 范围 | 估算 |
|---|---|
| 本次 10 件（18,622 源字符） | ≈ **¥0.085** |
| 218 件（426,522 源字符） | ≈ ¥1.95–2.03 |
| 耗时 | 10 件 157s（并发 5）；218 件按并发 16 约 **18 分钟** |

估算沿用第二十节的 qwen-flash ≤128K 档单价与实测 token/字符比，实际以账单为准。

### 6. 产物位置

| 内容 | 位置 |
|---|---|
| 10 件候选 JSON | 服务器 `/tmp/i18n_pilot_10/data/`；本地 `.tmp_i18n/pilot_out/` |
| 试点清单（源哈希、候选哈希、src_version、checkpoint 记录、告警） | `docs/qc/i18n_pilot10_manifest_20261029.csv` |
| 逐语种复核结果 | `docs/qc/i18n_pilot10_verify_20261029.csv` |
| 独立 checkpoint | `/tmp/i18n_pilot_10/state.jsonl`（未进生产） |
| 日志 | `/tmp/i18n_pilot_10/pilot.log` |

候选**不是**生产数据，未进入 `data/parsed`。

### 未做

- 未写生产、未渲染、未改数据库、未启停容器。
- 未启动 218 件全量任务。
- 未修改、未复用、未重建生产 checkpoint。
- 未对 17 件身份存疑项做归属判定。
- 未给候选做人工语义通读（只做了锚点对齐与结构复核）；这一步属于阶段 3 的审核范围。

## 二十二、阶段 3：MPN 保号门禁 + 定点修复 + 复核（候选 v1 → v2）

生产侧仍只读；所有改动作业只发生在隔离候选目录。

### 1. 门禁规则（`mpn_gate.py`，四语 × 三字段统一）

1. **身份串来源**：`basic_info.mpn`、文件名 stem，以及源文里**以它们结尾的完整订货码**（例：`basic_info.mpn` 是 `74AHCT1G08DCKTG4`，源文写的是 `SN74AHCT1G08DCKTG4`，后者也必须保号）。
2. **判定**（`title` / `meta` / `description` 逐字段，`ja/ko/de/es` 逐语种）：
   - `PASS`：源里出现的每个身份串，在译文里完整出现（去分隔符、大写归一后比较）；
   - `FAIL_ABBREV`：只保留了前缀（≥8 位）；
   - `FAIL`：只剩片段或完全缺失；
   - `INFO_NO_MPN_IN_SOURCE`：源字段本身没有 MPN，不做要求（不判失败）。
3. **阻断语义**：任一 `FAIL` → 脚本 `exit 1`，该件不得进入下一阶段，直到修复或人工批准。
4. 只用标准库、不依赖翻译脚本内部状态，可直接接进发布前检查。

### 2. v1 门禁结果：1 条 FAIL

| 版本 | PASS | INFO | FAIL | 说明 |
|---|---|---|---|---|
| v1（原始候选） | 75 | 44 | **1** | `74AHCT1G08DCKTG4` es `meta`：`SN74AHCT1G08DCKTG4` → `SN74AHCT1G08`（保留前 12 位） |

其余 44 条 `INFO` 都是"该源字段本来就没写 MPN"，不是问题。

### 3. 定点修复（v1 不动，写入 v2）

- 只替换被门禁判 `FAIL` 的那个字段里的缩写 token，采用**字节级 JSON 字面量替换**（不是整文件重新序列化）。
- 修改后：`El SN74AHCT1G08 es una compuerta…` → `El SN74AHCT1G08DCKTG4 es una compuerta…`（+6 字节）。
- 10 个文件里**只有 1 个字节发生变化**，其余 9 个与 v1 逐字节相同：

| 文件 | v1 sha256(16) | v2 sha256(16) | 状态 |
|---|---|---|---|
| `74AHCT1G08DCKTG4_55734085.json` | `31bf530b648b9847` | `317c55db8b940c2c` | 已修（17,157 → 17,163 字节） |
| 其余 9 件 | 同左列 | 与 v1 相同 | 未变 |

### 4. v2 复核

| 检查 | 结果 |
|---|---|
| MPN 门禁 | **0 FAIL**（76 PASS / 44 INFO） |
| 五字段齐全、条数一致 | 40/40 |
| `src_version` 与冻结计划一致 | 40/40 |
| 非 ml 内容与源逐字节等价 | 10/10 |
| 顶层键 | 仍只新增 `multi_language` |
| 数值+单位锚点 | 216/216 |
| 中日文泄漏 / 整句英文回退 | 0 / 0 |

### 5. 放行条件对照

| 条件 | 对应证据 | 状态 |
|---|---|---|
| 源版本一致 | `src_version` 40/40 | 通过 |
| 结构完整（四语五字段、条数） | 复核 CSV | 通过 |
| 数值与单位锚点 | 216/216 | 通过 |
| 产品标识（MPN、完整订货后缀） | `mpn_gate` 0 FAIL | 通过（v2） |
| 无中文泄漏 / 无整句英文回退 | 0 / 0，技术标识 5 处已列明 | 通过 |
| 内容语义逐件抽查 | `pilot10_review.csv`（298 行 × en/ja/ko/de/es） | **待人工** |
| 隔离性 | 生产 13,516 文件未变、10 件哈希未变、checkpoint mtime 未变 | 通过 |
| 续跑与审计 | 独立 `state.jsonl`、失败件不写 checkpoint、v1/v2 哈希留档 | 通过 |

### 6. 产物

| 内容 | 位置 |
|---|---|
| 门禁脚本 / 修复脚本 | `.tmp_i18n/mpn_gate.py`、`.tmp_i18n/fix_mpn_v2.py` |
| 门禁结果（v1+v2，240 行） | `docs/qc/i18n_pilot10_mpn_gate_20261029.csv` |
| v2 候选 | `.tmp_i18n/pilot_out_v2/`（服务器 `/tmp/i18n_pilot_10/data/` 仍是 v1） |
| 五语对照审查表 | `.tmp_i18n/pilot10_review.csv`（298 行，未提交） |
| 版本哈希 | `.tmp_i18n/candidate_versions.json` |

### 未做

- 未写生产、未渲染、未改库、未启停容器；未启动 218 件全量。
- 未把门禁接进 `qc_regression` / CI（建议后续加，但属于另一处改动）。
- 未做人工语义通读（审查表已备好，等人工完成）。
- 未同步 v2 到服务器隔离目录（服务器 `/tmp` 里仍是 v1；同步与否不影响生产）。

## 二十三、阶段 3b：人工语义审查 P0/P1 缺陷 → 候选 v3（2026-10-29）

生产侧仍只读。本节只记录隔离候选目录 `.tmp_i18n/pilot_out_v3/` 的修订与复核；v1、v2 均保持原样。

### 1. 人工审查结论：不接受"结构全绿=可交付"

第二十二节的六项结构门禁（字段齐全、条数一致、`src_version`、正文不变、MPN 保号、数值锚点）在 v1/v2 上全部通过，但人工通读 `pilot10_review.csv` 后判定 **不能整体标记为验收通过**，并列出以下缺陷（原文归类）：

| 级别 | 器件 | 语种/字段 | 问题 |
|---|---|---|---|
| P0 | `BQ2003S` | de description / features[0] | `Nickelmanganhydrid-Akkus`（镍锰氢化物）→ 应为镍氢 |
| P0 | `74AHC1G126DCKTG4` | ko meta / description | `3상`（三相）→ 3-state 应为 `3상태`（三态） |
| P0 | `74AVCH8T245RHLRG4` | ko meta / description | 同上 |
| P0 | `F280034SPT` | de applications[18] | `Solarspannungsschutz, Schnellschaltung`（过压保护/快速开关）语义错位 |
| P1 | `F280034SPT` | ja applications[16] | `ピール`（pile 音译） |
| P1 | `F280034SPT` | ko features[50] | `사각파`（方波）≠ 正交 |
| P1 | `F280034SPT` | ja features[50] / [55] | `準位エンコーダー` / `可編集ロジックブロック` |
| P1 | `FCT162H245ATPVCTG4` | ja meta / applications[0] | 简体字形 `双向` 混入日文 |
| 其他 | `74AVCH8T245RHLRG4` | ja meta | `デュアルスアップ電源` |
| 其他 | `F280034SPT` | ja applications[15] | `パスティブバランス` |
| 其他 | `74CBTLV3257RGYRG4` | de meta | `Spannungsbereich von GND bis VCC` 是否保留 rail-to-rail 原意 |
| 其他 | `F280034SPT` | de features[48] | `Drei erweiterte Erfassungsmodul` 单复数 |

结论：**结构等价 ≠ 语义正确**。门禁能挡住 MPN 截断和条数漂移，挡不住术语误译，必须有人工语义抽检这一层。

### 2. v3 修订规则（24 条规则 → 23 个叶子 → 19 行对照）

全部采用**按字段整值字节替换**：读出当前字段值 → 做子串替换 → 只把该字段的 JSON 字面量换掉，并要求 `raw.count(old_literal) == 1`，否则拒绝执行。不做整文件重新序列化，不碰其它字节。

| 规则 | 器件 | 语种 | 字段 | 旧 | 新 | 依据 |
|---|---|---|---|---|---|---|
| P0-1a | BQ2003S | de | description | `Nickelkadmium- oder Nickelmanganhydrid-Akkus` | `Nickelkadmium- oder Nickel-Metallhydrid-Akkus` | 镍氢电池德语术语错误：Nickelmanganhydrid（镍锰氢化物）→ Nickel-Metallhydrid（镍氢） |
| P0-1b | BQ2003S | de | features[0] | 同上 | 同上 | 同一错词 |
| P0-2a | 74AHC1G126DCKTG4 | ko | meta | `단일 3상 버퍼 게이트` | `단일 3상태 버퍼 게이트` | 3-state 误译为 3상（三相） |
| P0-2b | 74AHC1G126DCKTG4 | ko | description | `3상 출력을 갖춘` | `3상태 출력을 갖춘` | 同上 |
| P0-3a | 74AVCH8T245RHLRG4 | ko | meta | `3상 출력을 갖춘` | `3상태 출력을 갖춘` | 同源缺陷 |
| P0-3b | 74AVCH8T245RHLRG4 | ko | description | `3상 출력을 갖춘` | `3상태 출력을 갖춘` | 同上 |
| P0-4 | F280034SPT | de | applications[18] | `Solarspannungsschutz, Schnellschaltung` | `Lichtbogenschutz für Solaranlagen, Schnellabschaltung` | Solar arc protection→Lichtbogenschutz；Rapid shutdown→Schnellabschaltung |
| P1-1 | F280034SPT | ja | applications[16] | `交流充電（ピール）ステーション、直流充電（ピール）ステーション` | `交流充電スタンド、直流充電スタンド` | charging pile=充电桩→充電スタンド |
| P1-2a | F280034SPT | ko | features[50] | `고급 사각파 인코더 펄스` | `고급 직교 인코더 펄스` | quadrature encoder→직교 인코더 |
| P1-2b | F2800155SPHPR | ko | features[40] | `강화 사각형 인코더 펄스` | `강화 직교 인코더 펄스` | 同源缺陷 |
| P1-3 | F280034SPT | ja | features[50] | `拡張準位エンコーダーパルス` | `拡張直交エンコーダーパルス` | quadrature→直交 |
| P1-4 | F280034SPT | ja | features[55] | `可編集ロジックブロック` | `構成可能ロジックブロック` | Configurable→構成可能 |
| P1-5a | FCT162H245ATPVCTG4 | ja | meta | `高速双向通信` | `高速双方向通信` | 简中字形混入 |
| P1-5b | FCT162H245ATPVCTG4 | ja | applications[0] | `双向同期通信` | `双方向同期通信` | 同上 |
| P1-6 | F280034SPT | ja | applications[15] | `パスティブバランス`（4 处） | `パッシブバランス` | passive 误拼 |
| P1-7a | 74AVCH8T245RHLRG4 | ja | meta | `デュアルスアップ電源バストランシーバー` | `デュアル電源バストランシーバー` | dual-supply→デュアル電源 |
| P1-7b | 74AVCH8T245RHLRG4 | ja | description | 同上 | 同上 | 人工清单只点了 meta，description 同病 |
| P1-8a | 74CBTLV3257RGYRG4 | de | meta | `Spannungsbereich von GND bis VCC` | `Rail-to-Rail-Schalten (GND bis VCC)` | 恢复原厂术语并保留 GND..VCC 限定 |
| P1-8b | 74CBTLV3257RGYRG4 | de | description | 同上 | 同上 | 同上 |
| P1-8c | 74CBTLV3257RGYRG4 | de | features[1] | `Spannungsbereich von GND bis VCC an Daten-E/A-Ports` | `Rail-to-Rail-Schalten an den Daten-E/A-Ports (GND bis VCC)` | 同上 |
| P1-9a | F280034SPT | de | features[48] | `Drei erweiterte Erfassungsmodul (eCAP)` | `Drei erweiterte Erfassungsmodule (eCAP)` | 数词后名词复数 |
| P1-9b | F2800155SPHPR | de | features[39] | 同上 | 同上 | 同源缺陷 |
| P1-10 | FCT162H245ATPVCTG4 | ja | meta | `データ入力にバスホールド機能を搭載、24mA出力駆動力、5V電源、SSOPパッケージ。` | `データ入力にバスホールド機能を備えた16ビットトランシーバー、24mA出力駆動、5V電源、SSOPパッケージ。` | **门禁新发现**：源文 `16-bit transceiver` 整段丢失 |
| P1-X | F280034SPT | ko | applications[16] | `AC 충전(기둥) 스테이션, DC 충전(기둥) 스테이션` | `AC 충전소, DC 충전소` | 与 P1-1 同根因（pile→기둥/柱子），人工清单未列 |

超出人工清单的 4 条（P1-7b、P1-2b、P1-9b、P1-X、P1-10）都是**同一错词在同一器件的其他字段/其他器件复现**，或门禁独立发现的内容丢失；无一条是自由发挥式改写。

### 3. 作用域控制：为什么不能全局替换

`3상` 在候选里出现 4 类语义：

| 位置 | 含义 | 处置 |
|---|---|---|
| `74AHC1G126DCKTG4` ko meta/description | 3-state（三态） | **改** → `3상태` |
| `74AVCH8T245RHLRG4` ko meta/description | 3-state（三态） | **改** → `3상태` |
| `F280034SPT` ko applications[9] `3상 UPS` | three-phase（三相） | **不改**（正确） |
| `F2800155SPHPR` ko applications[1] `3상 UPS` | three-phase（三相） | **不改**（正确） |
| `74LVC2G126DCURG4` ko | 已经是 `3상태` | 不动 |

同理 `パスティブ` 只在 F280034SPT 的 applications[15] 出现 4 次，`ピール` 只在该件 applications[16]，`双向` 只在 FCT162H245ATPVCTG4；一旦做全局替换，会把合法用法一起改坏或污染其他器件。因此 v3 只接受"件 + 语种 + 字段 + 下标"四元组定位。

### 4. 独立门禁补位：数值锚点抓到人工漏掉的整段丢失

`anchor_check.py`（源文每个数字都必须在译文出现，允许德语逗号小数与各语数词写法）对 v2 报 1 条：

```
MISS FCT162H245ATPVCTG4_cf842545.json ja.meta: ['16']
```

核对源文 `16-bit transceiver with bus hold, 24mA output drive, 5V supply, SSOP package`：日文 meta 只写了"数据输入带总线保持、24mA 输出驱动、5V 电源、SSOP 封装"，**整段主语 16 位收发器丢失**，ko/de/es 三语都保留了 16。已按 P1-10 修复。

这说明人工通读与机器门禁是互补关系：P0/P1 术语全靠人眼，整段漏译靠锚点。建议把 `anchor_check.py` 与 `mpn_gate.py` 一起作为 218 件批量放行的前置门禁。

### 5. v2 → v3 逐件哈希（v1/v2 目录均未改动）

| 文件 | v2 字节 | v3 字节 | v2 sha256(16) | v3 sha256(16) | 变更叶子 |
|---|---|---|---|---|---|
| `74AHC1G126DCKTG4_6824188e.json` | 12,958 | 12,964 | `dff50dd4da58920a` | `ccb2a509111aa872` | 2 |
| `74AVCH8T245RHLRG4_6252cb6a.json` | 19,331 | 19,313 | `e7262dbc74b30ba6` | `81f364909ff7323e` | 4 |
| `74CBTLV3257RGYRG4_ddb143a7.json` | 16,385 | 16,398 | `093afdf7ce9a9cc3` | `075bbc9af6a06efe` | 3 |
| `BQ2003S_54f3e246.json` | 14,967 | 14,969 | `89517534a1638fae` | `baf23de975004eb9` | 2 |
| `F2800155SPHPR_e5e9c14e.json` | 35,832 | 35,830 | `e89e861d3f2a0d0d` | `b14ffe1d3302f7a3` | 2 |
| `F280034SPT_c9f41b10.json` | 46,595 | 46,522 | `af4319b11242318f` | `9d81b24aa0b0abb3` | 8 |
| `FCT162H245ATPVCTG4_cf842545.json` | 15,991 | 16,029 | `51348638ad4f3d9b` | `df7bafc6e2f0e2f8` | 2 |
| 其余 3 件（`74AHCT1G08DCKTG4`、`74LVC2G126DCURG4`、`CC1000YZ`） | — | 不变 | 同 v2 | 同 v2 | 0 |

结构级比对（`diff_v2_v3.py` 递归到叶子）确认：**全 10 件共 23 个叶子变化，全部落在上表点名的字段上，没有任何非 ml 字段被改动**。v1 哈希仍为第二十二节记录值，未被覆盖。

### 6. v3 复核结果

| 检查 | 命令 | 结果 |
|---|---|---|
| MPN 保号门禁 | `mpn_gate.py pilot_out_v3 pilot_out/before` | **0 FAIL**（76 PASS / 44 INFO），exit 0 |
| 结构复核（字段/条数/对齐/源绑定/正文不变） | `verify_pilot10.py pilot_out_v3` | `PROBLEMS: none`；`src_version_all_match: True`；`body_unchanged_all: True` |
| 数值锚点 | `anchor_check.py pilot_out_v3` | **1192/1192**（v2 为 1191/1192，缺的正是 P1-10） |
| 术语残留扫描 | `scan_terms_v3.py pilot_out_v3` | **0 命中**（13 类错词模式全部归零，合法"三相 UPS"已白名单） |
| 生产只读 | `sha256sum` 10 件 vs 试点前 | **10/10 未变** |
| 隔离性 | 生产 JSON 总数 | 仍为 13,516 |

注：`verify_pilot10.py` 输出的 `script_warnings_total: 1` 来自 v1 生成日志里历史记录的 `SN74AHCT1G08` es-meta 缩写告警（第二十二节已修），不是 v3 的新问题；脚本读的是 `pilot.log` 而不是候选目录。

### 7. 仍开放、需人工裁决的项

1. **德语 rail-to-rail**：v3 采用 `Rail-to-Rail-Schalten (GND bis VCC)`，理由是源字段本身就在讲"数据 I/O 口上从 GND 到 VCC 的满轨导通"，Rail-to-Rail 在德语数据手册里直接沿用。若要求严格沿用原厂德语版措辞，可再换。
2. **充电桩译法**：ja 用 `充電スタンド`，ko 用 `충전소`；两者都是当地惯例，但不是逐字对应 "charging pile station"。
3. **BQ2003S 的 `Nickelkadmium`**：Duden 同时收录 Nickelcadmium，未改；只改了更明确的 `Nickelmanganhydrid`。
4. **`74AVCH8T245RHLRG4` ja meta 里仍有英文 `3-state出力`**：属混语问题（P2），人工清单未点名，v3 未改，登记待裁决。
5. **`F2800155SPHPR` ko features[39]/[40] 的 `강화` vs `F280034SPT` 的 `고급`**：同一个 "Enhanced" 两种译法，属一致性（P2），未改。

### 8. 未做

- 未写生产、未渲染、未改库、未启停容器；10 件生产哈希复核仍与试点前一致。
- 未启动 218 件全量翻译（仍需单独授权）。
- 未把 v3 同步到服务器 `/tmp/i18n_pilot_10/data/`（服务器仍是 v1；不影响生产，也不影响本机复核）。
- 未把 `mpn_gate.py` / `anchor_check.py` 接进 `qc_regression` 或 CI。
- 未解决第二十一节遗留的 17 件身份可疑项与 6 件 stem/MPN 不一致项。

### 9. 产物

| 内容 | 位置 |
|---|---|
| v3 候选 | `.tmp_i18n/pilot_out_v3/`（10 件） |
| 修订脚本 / 规则表 | `.tmp_i18n/fix_v3.py`、`.tmp_i18n/v3_rules.csv` |
| 修订日志（规则 + 逐件哈希） | `.tmp_i18n/v3_revision_log.json` |
| v2↔v3 结构差异 | `.tmp_i18n/diff_v2_v3.py`（输出 23 叶子） |
| 数值锚点检查 | `.tmp_i18n/anchor_check.py` |
| 术语残留扫描 | `.tmp_i18n/scan_terms_v3.py` |
| 四语对照复审表（298 行，带 `changed_vs_v2` 列） | `docs/qc/i18n_pilot10_review_v3_20261029.csv` |
| 修订规则表（24 行） | `docs/qc/i18n_pilot10_v3_rules_20261029.csv` |
| 逐件哈希清单 | `docs/qc/i18n_pilot10_v3_manifest_20261029.csv` |

## 附：复现命令

```bash
# 235 件清单（生产侧，只读）
ssh root@159.89.190.225 "python3 -" < /tmp/list235.py     # 脚本见本次会话记录
# 交付包核对（本地）
python E:\workspace\.tmp_i18n\check.py            # 235 件 × 交付包语言变体
python E:\workspace\.tmp_i18n\verify_delivery.py  # 235 件 × 交付包 JSON 的 multi_language
# 第十七节 DB/文件实证（只读）
ssh root@159.89.190.225 "python3 -" < E:\workspace\.tmp_i18n\probe_v15.py
# 丢失波范围：按 mtime 落窗比对 names235.txt（见本节第 4 小节）
# 第十八节：72h mtime 小时分布 + 10Z/11Z 逐件 ml 判定（脚本见本次会话记录）
# 第十九节：交付包 ml 与现网内容比对（本地，只读交付包与 prod235 快照）
python E:\workspace\.tmp_i18n\ml_only_check.py   # 去 ml 后逐件比较
python E:\workspace\.tmp_i18n\gap_metrics.py     # 逐字段行数 现网 vs 交付包
# 第二十节：翻译流水线审查（只读）
ssh root@159.89.190.225 'cd /www/wwwroot/icpdfparser; sha256sum translate_i18n.py; wc -l data/translate_state*.jsonl; tail -3 data/translate_full.log'
ssh root@159.89.190.225 'crontab -l | grep -c translate_i18n'   # 0
# 第二十节：checkpoint 陷阱（本地，对 235 快照跑 scan，不调 API）
python translate_i18n.py scan --scope full --data-dir E:\workspace\.tmp_i18n\prod235 --state-file E:\workspace\.tmp_i18n\state_full.jsonl
python translate_i18n.py scan --scope full --data-dir E:\workspace\.tmp_i18n\prod235 --state-file E:\workspace\.tmp_i18n\state_empty_never.jsonl
# 第二十节：计划与样本
python E:\workspace\.tmp_i18n\build_plan235.py    # 生成 plan235.csv（需先有 remote235_v2.sha 与 state_*.jsonl）
python E:\workspace\.tmp_i18n\flag_plan.py        # 身份标记
ssh root@159.89.190.225 "python3 -" < E:\workspace\.tmp_i18n\remote_audit.py   # 235 件实时哈希 + 双文件 stem
scp E:\workspace\.tmp_i18n\run_samples.py root@159.89.190.225:/tmp/i18n_run_samples.py && ssh root@159.89.190.225 'python3 /tmp/i18n_run_samples.py'   # 5 件样本，写 /tmp
python E:\workspace\.tmp_i18n\verify_samples.py   # 独立复核样本译文
# 第二十一节：冻结 218 件 + 哈希复核（只读）
python E:\workspace\.tmp_i18n\pick_pilot10.py                      # 生成 names218.* 与 pilot10.*
scp E:\workspace\.tmp_i18n\names218.txt root@159.89.190.225:/tmp/ && ssh root@159.89.190.225 "python3 -" < E:\workspace\.tmp_i18n\hash218.py
diff <(sort live218.sha) <(sort names218.sha)                      # 应为空
# 隔离试跑（只写 /tmp）
scp E:\workspace\.tmp_i18n\{pilot10.txt,run_pilot10.sh} root@159.89.190.225:/tmp/ && ssh root@159.89.190.225 'bash /tmp/run_pilot10.sh'
python E:\workspace\.tmp_i18n\build_manifest.py                    # 试点清单
python E:\workspace\.tmp_i18n\verify_pilot10.py                    # 逐语种复核
# 第二十二节：MPN 门禁与定点修复（隔离目录）
python E:\workspace\.tmp_i18n\mpn_gate.py pilot_out pilot_out\before --json mpn_gate_v1.json      # v1: exit 1
python E:\workspace\.tmp_i18n\fix_mpn_v2.py                                                       # 写 pilot_out_v2
python E:\workspace\.tmp_i18n\mpn_gate.py pilot_out_v2 pilot_out\before --json mpn_gate_v2.json   # v2: exit 0
python E:\workspace\.tmp_i18n\verify_pilot10.py pilot_out_v2                                      # 结构复核
# 第二十三节：人工审查 P0/P1 → 候选 v3（全部本地，不触生产）
python E:\workspace\.tmp_i18n\fix_v3.py                          # v2 -> v3，24 条定点规则
python E:\workspace\.tmp_i18n\diff_v2_v3.py                      # 逐叶子差异，应为 23
python E:\workspace\.tmp_i18n\mpn_gate.py pilot_out_v3 pilot_out\before --json mpn_gate_v3.json
python E:\workspace\.tmp_i18n\verify_pilot10.py pilot_out_v3     # PROBLEMS: none
python E:\workspace\.tmp_i18n\anchor_check.py pilot_out_v3       # 1192/1192
python E:\workspace\.tmp_i18n\anchor_check.py pilot_out_v2       # 对照：1191/1192（ja.meta 缺 16）
python E:\workspace\.tmp_i18n\scan_terms_v3.py pilot_out_v3      # 0 residual
python E:\workspace\.tmp_i18n\build_review.py pilot_out_v3 pilot10_review_v3.csv pilot_out_v2
ssh root@159.89.190.225 "cd /www/wwwroot/icpdfparser/data/parsed && sha256sum <10 个文件名>"   # 与 prod_pilot_before.sha 比对
```
