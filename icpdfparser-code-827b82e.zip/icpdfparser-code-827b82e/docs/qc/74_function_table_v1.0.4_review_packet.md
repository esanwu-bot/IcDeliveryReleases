# 74 功能表 · 待复核包（阶段 ①）

- 版本：`1.0.4`
- 状态：`SIGNED`
- Owner：`esan`
- Reviewer：wuxiaoxian
- 内容哈希：`sha256:6a1784db98937ead65a73c81f01a98de58e30d26dccb6840d96b386c5b555980`
- 变更原因：文案修正：scope_note 原写「候选未签核，不得用于 P0」，与 v1.0.3 已签核事实不符；本版仅改该文案与版本号，功能码/证据/族覆盖均与 v1.0.3 逐字节一致。
- 来源：[{'code': '00', 'mpn': '74AHCT1G00DBVRG4', 'device_mpn': '74AHCT1G00DBVRG4', 'pdf_name': '74AHCT1G00DBVRG4__sn74ahct1g00.pdf', 'page': 1}, {'code': '02', 'mpn': '74AHCT1G02DBVRG4', 'device_mpn': '74AHCT1G02DBVRG4', 'pdf_name': '74AHCT1G02DBVRG4__sn74ahct1g02.pdf', 'page': 1}, {'code': '04', 'mpn': '1A1G04QDBVRG4Q1', 'device_mpn': 'SN74AHC1G04-Q1', 'pdf_name': '1A1G04QDBVRG4Q1__sn74ahc1g04-q1.pdf', 'page': 1}, {'code': '04', 'mpn': '74AHCT1G04DBVRE4', 'device_mpn': 'SN74AHCT1G04', 'pdf_name': '74AHCT1G04DBVRE4__sn74ahct1g04.pdf', 'page': 1}, {'code': '07', 'mpn': '74LVC1G07MDCKREPG4', 'device_mpn': '74LVC1G07MDCKREPG4', 'pdf_name': '74LVC1G07MDCKREPG4__sn74lvc1g07-ep.pdf', 'page': 1}, {'code': '08', 'mpn': '1P1G08MDBVREP', 'device_mpn': 'SN74LVC1G08MDBVREP', 'pdf_name': '1P1G08MDBVREP__sn74lvc1g08-ep.pdf', 'page': 1}, {'code': '08', 'mpn': '74AHCT1G08DBVRE4', 'device_mpn': 'SN74AHCT1G08DBVRE4', 'pdf_name': '74AHCT1G08DBVRE4__sn74ahct1g08.pdf', 'page': 1}, {'code': '14', 'mpn': '74AHCT1G14DBVRE4', 'device_mpn': 'SN74AHCT1G14DBVRE4', 'pdf_name': '74AHCT1G14DBVRE4__sn74ahct1g14.pdf', 'page': 1}, {'code': '32', 'mpn': '74AHCT1G32DBVRG4', 'device_mpn': '74AHCT1G32DBVRG4', 'pdf_name': '74AHCT1G32DBVRG4__sn74ahct1g32.pdf', 'page': 1}, {'code': '66', 'mpn': '1P1G66QDBVRG4Q1', 'device_mpn': 'SN74LVC1G66-Q1', 'pdf_name': '1P1G66QDBVRG4Q1__sn74lvc1g66-q1.pdf', 'page': 1}, {'code': '86', 'mpn': '74AHCT1G86DBVRG4', 'device_mpn': '74AHCT1G86DBVRG4', 'pdf_name': '74AHCT1G86DBVRG4__sn74ahct1g86.pdf', 'page': 1}, {'code': '123', 'mpn': '74LVC1G123DCTRE4', 'device_mpn': '74LVC1G123DCTRE4', 'pdf_name': '74LVC1G123DCTRE4__sn74lvc1g123.pdf', 'page': 1}, {'code': '125', 'mpn': '74AHC1G125DBVRE4', 'device_mpn': '74AHC1G125DBVRE4', 'pdf_name': '74AHC1G125DBVRE4__sn74ahc1g125.pdf', 'page': 1}, {'code': '125', 'mpn': '74AHCT1G125DBVRE4', 'device_mpn': '74AHCT1G125DBVRE4', 'pdf_name': '74AHCT1G125DBVRE4__sn74ahct1g125.pdf', 'page': 1}, {'code': '125', 'mpn': '74AUC1G125DBVRE4', 'device_mpn': '74AUC1G125DBVRE4', 'pdf_name': '74AUC1G125DBVRE4__sn74auc1g125.pdf', 'page': 1}, {'code': '125', 'mpn': '74AUP1G125DCKRG4', 'device_mpn': '74AUP1G125DCKRG4', 'pdf_name': '74AUP1G125DCKRG4__sces595n.pdf', 'page': 1}, {'code': '125', 'mpn': '74LVC1G125DBVRG4', 'device_mpn': '74LVC1G125DBVRG4', 'pdf_name': '74LVC1G125DBVRG4__sn74lvc1g125.pdf', 'page': 1}, {'code': '126', 'mpn': '74AHC1G126DBVRG4', 'device_mpn': '74AHC1G126DBVRG4', 'pdf_name': '74AHC1G126DBVRG4__sn74ahc1g126.pdf', 'page': 1}, {'code': '126', 'mpn': '74AHCT1G126DBVRE4', 'device_mpn': '74AHCT1G126DBVRE4', 'pdf_name': '74AHCT1G126DBVRE4__sn74ahct1g126.pdf', 'page': 1}, {'code': '126', 'mpn': '74AUC1G126DCKRG4', 'device_mpn': '74AUC1G126DCKRG4', 'pdf_name': '74AUC1G126DCKRG4__sn74auc1g126.pdf', 'page': 1}, {'code': '126', 'mpn': '74AUP1G126DRLRG4', 'device_mpn': '74AUP1G126DRLRG4', 'pdf_name': '74AUP1G126DRLRG4__sn74aup1g126.pdf', 'page': 1}, {'code': '126', 'mpn': '74LVC1G126DBVRE4', 'device_mpn': 'SN74LVC1G126DBVRE4', 'pdf_name': '74LVC1G126DBVRE4__sn74lvc1g126.pdf', 'page': 1}, {'code': '132', 'mpn': '74LVC1G132DBVRG4', 'device_mpn': '74LVC1G132DBVRG4', 'pdf_name': '74LVC1G132DBVRG4__sn74lvc1g132.pdf', 'page': 1}, {'code': '139', 'mpn': '74LVC1G139DCTRE4', 'device_mpn': '74LVC1G139DCTRE4', 'pdf_name': '74LVC1G139DCTRE4__sn74lvc1g139.pdf', 'page': 1}, {'code': '175', 'mpn': '74LVC1G175DBVRE4', 'device_mpn': '74LVC1G175DBVRE4', 'pdf_name': '74LVC1G175DBVRE4__sn74lvc1g175.pdf', 'page': 1}, {'code': '240', 'mpn': '74AUC1G240DBVRG4', 'device_mpn': '74AUC1G240DBVRG4', 'pdf_name': '74AUC1G240DBVRG4__sn74auc1g240.pdf', 'page': 1}, {'code': '240', 'mpn': '74LVC1G240DBVRG4', 'device_mpn': 'SN74LVC1G240DBVRG4', 'pdf_name': '74LVC1G240DBVRG4__sn74lvc1g240.pdf', 'page': 1}, {'code': '315', 'mpn': '1P1G3157QDBVRQ1', 'device_mpn': 'SN74LVC1G3157-Q1', 'pdf_name': '1P1G3157QDBVRQ1__sn74lvc1g3157-q1.pdf', 'page': 1}, {'code': '320', 'mpn': '74LVC1G3208DBVRE4', 'device_mpn': '74LVC1G3208DBVRE4', 'pdf_name': '74LVC1G3208DBVRE4__sn74lvc1g3208.pdf', 'page': 1}, {'code': '332', 'mpn': '74LVC1G332DBVRG4', 'device_mpn': '74LVC1G332DBVRG4', 'pdf_name': '74LVC1G332DBVRG4__sn74lvc1g332.pdf', 'page': 1}, {'code': '373', 'mpn': '74LVC1G373DBVRE4', 'device_mpn': '74LVC1G373DBVRE4', 'pdf_name': '74LVC1G373DBVRE4__sn74lvc1g373.pdf', 'page': 1}, {'code': '374', 'mpn': '74LVC1G374DCKRG4', 'device_mpn': '74LVC1G374DCKRG4', 'pdf_name': '74LVC1G374DCKRG4__sn74lvc1g374.pdf', 'page': 1}, {'code': '384', 'mpn': '74CBT1G384DBVRG4', 'device_mpn': '74CBT1G384DBVRG4', 'pdf_name': '74CBT1G384DBVRG4__SN74CBT1G384_Rev2006.pdf', 'page': 1}, {'code': '386', 'mpn': '74LVC1G386DCKRG4', 'device_mpn': '74LVC1G386DCKRG4', 'pdf_name': '74LVC1G386DCKRG4__sn74lvc1g386.pdf', 'page': 1}, {'code': 'CBT:125', 'mpn': '74CBT1G125DBVRE4', 'device_mpn': '74CBT1G125DBVRE4', 'pdf_name': '74CBT1G125DBVRE4__sn74cbt1g125.pdf', 'page': 1}, {'code': 'CBTD:125', 'mpn': '74CBTD1G125DCKRG4', 'device_mpn': '74CBTD1G125DCKRG4', 'pdf_name': '74CBTD1G125DCKRG4__sn74cbtd1g125.pdf', 'page': 1}, {'code': '11', 'mpn': 'SN74LVC1G11', 'device_mpn': 'SN74LVC1G11', 'pdf_name': 'SN74LVC1G11__sn74lvc1g11.pdf', 'page': 1}]

> 签核必须绑定上面这个 `content_hash`；任何内容变化都会让它失效，需重新复核。

## 条目

| 功能码 | 功能 | 输入 | Schmitt | 输出 | OE | 族范围 | 状态 |
|---|---|---|---|---|---|---|---|
| `00` | NAND | 2 | False | PUSH_PULL | NONE | AHCT | EVIDENCE_BACKED |
| `02` | NOR | 2 | False | PUSH_PULL | NONE | AHCT | EVIDENCE_BACKED |
| `04` | INVERTER | 1 | UNKNOWN | PUSH_PULL | NONE | AHC/AHCT | EVIDENCE_BACKED |
| `07` | BUFFER | 1 | False | OPEN_DRAIN | NONE | LVC | EVIDENCE_BACKED |
| `08` | AND | 2 | False | PUSH_PULL | NONE | AHCT/LVC | EVIDENCE_BACKED |
| `11` | AND | 3 | False | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |
| `14` | INVERTER | 1 | True | PUSH_PULL | NONE | AHCT | EVIDENCE_BACKED |
| `32` | OR | 2 | False | PUSH_PULL | NONE | AHCT | EVIDENCE_BACKED |
| `66` | ANALOG_SWITCH | — | False | ANALOG | UNKNOWN | LVC | EVIDENCE_BACKED |
| `86` | XOR | 2 | False | PUSH_PULL | NONE | AHCT | EVIDENCE_BACKED |
| `123` | MONOSTABLE | — | True | UNKNOWN | UNKNOWN | LVC | EVIDENCE_BACKED |
| `125` | BUFFER_3STATE | 1 | False | THREE_STATE | UNKNOWN | AHC/AHCT/AUC/AUP/LVC | EVIDENCE_BACKED |
| `126` | BUFFER_3STATE | 1 | False | THREE_STATE | UNKNOWN | AHC/AHCT/AUC/AUP/LVC | EVIDENCE_BACKED |
| `132` | NAND | 2 | True | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |
| `139` | DECODER_2TO4 | 2 | False | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |
| `175` | FLIPFLOP_D | — | False | PUSH_PULL | UNKNOWN | LVC | EVIDENCE_BACKED |
| `240` | UNRESOLVED | — | False | THREE_STATE | UNKNOWN | AUC/LVC | CONFLICT |
| `315` | ANALOG_SWITCH_SPDT | — | False | ANALOG | UNKNOWN | LVC | EVIDENCE_BACKED |
| `320` | OR_AND | 3 | False | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |
| `332` | OR | 3 | False | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |
| `373` | LATCH_D | — | False | THREE_STATE | UNKNOWN | LVC | EVIDENCE_BACKED |
| `374` | FLIPFLOP_D | — | False | THREE_STATE | UNKNOWN | LVC | EVIDENCE_BACKED |
| `384` | ANALOG_SWITCH_FET | — | False | ANALOG | UNKNOWN | CBT | EVIDENCE_BACKED |
| `386` | XOR | 3 | False | PUSH_PULL | NONE | LVC | EVIDENCE_BACKED |

## 证据（每条的 PDF 页与原文）

### `00` — NAND （EVIDENCE_BACKED）
- `74AHCT1G00DBVRG4` · p.1 · sha `37ed4656545c518f`
  - 「SN74AHCT1G00 Single 2-Input Positive-NAND Gate 1 Features」

### `02` — NOR （EVIDENCE_BACKED）
- `74AHCT1G02DBVRG4` · p.1 · sha `5cc7a05fa66442b9`
  - 「SN74AHCT1G02 Single 2-Input Positive-NOR Gate」

### `04` — INVERTER （EVIDENCE_BACKED）
- `1A1G04QDBVRG4Q1` · p.1 · sha `50b1cbe01b3eb113`
  - 「SN74AHC1G04-Q1 Automotive Single Inverter Gate 1 Features」
- `74AHCT1G04DBVRE4` · p.1 · sha `05199cf2c623cc8b`
  - 「SN74AHCT1G04 Single Inverter Gate 1 Features」

### `07` — BUFFER （EVIDENCE_BACKED）
- `74LVC1G07MDCKREPG4` · p.1 · sha `0de2de7bf9e17e71`
  - 「SN74LVC1G07-EP SINGLE BUFFER/DRIVER WITH OPEN-DRAIN OUTPUT SCES685」

### `08` — AND （EVIDENCE_BACKED）
- `1P1G08MDBVREP` · p.1 · sha `d9026ca0342c3325`
  - 「SN74LVC1G08-EP SINGLE 2-INPUT POSITIVE-AND GATE SCES454C」
- `74AHCT1G08DBVRE4` · p.1 · sha `557340852460f440`
  - 「The SN74AHCT1G08 device is a single 2-input positive-AND gate.」

### `11` — AND （EVIDENCE_BACKED）
- `SN74LVC1G11` · p.1 · sha `ffd953703273b438`
  - 「SN74LVC1G11 Single 3-Input Positive-AND Gate」

### `14` — INVERTER （EVIDENCE_BACKED）
- `74AHCT1G14DBVRE4` · p.1 · sha `5657941b4f3173e4`
  - 「SN74AHCT1G14 Single Schmitt-Trigger Inverter Gate 1 Features」

### `32` — OR （EVIDENCE_BACKED）
- `74AHCT1G32DBVRG4` · p.1 · sha `bbee63463a8fd4cb`
  - 「The SN74AHCT1G32 device is a single 2-input positive-OR gate.」

### `66` — ANALOG_SWITCH （EVIDENCE_BACKED）
- `1P1G66QDBVRG4Q1` · p.1 · sha `70fb36f40a56e368`
  - 「SN74LVC1G66-Q1 Single Bilateral Analog Switch 1 Features」

### `86` — XOR （EVIDENCE_BACKED）
- `74AHCT1G86DBVRG4` · p.1 · sha `9ab8e6347668ef0c`
  - 「The SN74AHCT1G86 is a single 2-input exclusive-OR gate.」

### `123` — MONOSTABLE （EVIDENCE_BACKED）
- `74LVC1G123DCTRE4` · p.1 · sha `7248ef0ff62af4d2`
  - 「SN74LVC1G123 Single Retriggerable Monostable Multivibrator With Schmitt-Trigger Inputs」

### `125` — BUFFER_3STATE （EVIDENCE_BACKED）
- `74AHC1G125DBVRE4` · p.1 · sha `96f44735da317d4b`
  - 「The SN74AHC1G125 device is a single bus buffer gate/line driver with 3-state output.」
- `74AHCT1G125DBVRE4` · p.1 · sha `386389b623620d89`
  - 「The SN74AHCT1G125 device is a single bus buffer gate/line driver with 3-state output.」
- `74AUC1G125DBVRE4` · p.1 · sha `e8693a6a99c92537`
  - 「SN74AUC1G125 Single Bus Buffer Gate With 3-State Output 1 Features」
- `74AUP1G125DCKRG4` · p.1 · sha `a0d166e5d974254a`
  - 「SN74AUP1G125 Low-Power Single Bus Buffer Gate With 3-State Output 1 1 Features 1」
- `74LVC1G125DBVRG4` · p.1 · sha `1098d46e4565695e`
  - 「The SN74LVC1G125 device is a single bus buffer gate/line driver with 3-state output.」

### `126` — BUFFER_3STATE （EVIDENCE_BACKED）
- `74AHC1G126DBVRG4` · p.1 · sha `6824188e88dcff51`
  - 「The SN74AHC1G126 device is a single bus buffer gate/line driver with 3-state output.」
- `74AHCT1G126DBVRE4` · p.1 · sha `dd59e32da9012c14`
  - 「The SN74AHCT1G126 device is a single bus buffer gate/line driver with 3-state output.」
- `74AUC1G126DCKRG4` · p.1 · sha `fd5cb7424b0d6c55`
  - 「SN74AUC1G126 Single Bus Buffer Gate With Tri-state Output 1 1 Features 1」
- `74AUP1G126DRLRG4` · p.1 · sha `f2929c99c6d29c18`
  - 「SN74AUP1G126 Low-Power Single Bus Buffer Gate With Tri-State Output 1 1 Features 1」
- `74LVC1G126DBVRE4` · p.1 · sha `c73611ec7322b956`
  - 「The SN74LVC1G126 device is a single bus buffer gate/line driver with 3-state output.」

### `132` — NAND （EVIDENCE_BACKED）
- `74LVC1G132DBVRG4` · p.1 · sha `fae33d78fe46834a`
  - 「The SN74LVC1G132 device is a single 2-input positive NAND gate with Schmitt-trigger inputs.」

### `139` — DECODER_2TO4 （EVIDENCE_BACKED）
- `74LVC1G139DCTRE4` · p.1 · sha `5642f177f015aabf`
  - 「SN74LVC1G139 2-to-4 Line Decoder 1 1 Features 1」

### `175` — FLIPFLOP_D （EVIDENCE_BACKED）
- `74LVC1G175DBVRE4` · p.1 · sha `6f19e0a69062e117`
  - 「SN74LVC1G175 Single D-Type Flip-Flop With Asynchronous Clear 1 Features 3 Description」

### `240` — UNRESOLVED （CONFLICT）
- `74AUC1G240DBVRG4` · p.1 · sha `f626bbc7b9017ef2`
  - 「SN74AUC1G240 SINGLE BUFFER/DRIVER WITH 3-STATE OUTPUT SCES384I」
- `74LVC1G240DBVRG4` · p.1 · sha `44c6414940caef3c`
  - 「SN74LVC1G240 Single Inverting Buffer/Driver With 3-State Output 1 Features」
- **冲突项**：['function']（已降级为不可用于 P0）

### `315` — ANALOG_SWITCH_SPDT （EVIDENCE_BACKED）
- `1P1G3157QDBVRQ1` · p.1 · sha `30bd5f12e5bc517f`
  - 「SN74LVC1G3157-Q1 Automotive Single-Pole Double-Throw Analog Switch 1 Features」

### `320` — OR_AND （EVIDENCE_BACKED）
- `74LVC1G3208DBVRE4` · p.1 · sha `6fe29a86acaaa4e8`
  - 「The SN74LVC1G3208 device is a single 3-input • Supports 5-V VCC Operation positive OR-AND gate.」

### `332` — OR （EVIDENCE_BACKED）
- `74LVC1G332DBVRG4` · p.1 · sha `5ecad3180cb93664`
  - 「Single 3-Input Positive-OR Gate Check for Samples」

### `373` — LATCH_D （EVIDENCE_BACKED）
- `74LVC1G373DBVRE4` · p.1 · sha `d33c16c3d219a30c`
  - 「The SN74LVC1G373 device is a single D-type latch designed for 1.」

### `374` — FLIPFLOP_D （EVIDENCE_BACKED）
- `74LVC1G374DCKRG4` · p.1 · sha `f641a061071feb1e`
  - 「Single D-Type Flip-Flop With 3-State Output Check for Samples」

### `384` — ANALOG_SWITCH_FET （EVIDENCE_BACKED）
- `74CBT1G384DBVRG4` · p.1 · sha `a6ce551a66a2df6b`
  - 「SN74CBT1G384 SINGLE FET BUS SWITCH SCDS065G」

### `386` — XOR （EVIDENCE_BACKED）
- `74LVC1G386DCKRG4` · p.1 · sha `3f4a2bc1675c1e6a`
  - 「Single 3-Input Positive-XOR Gate Check for Samples」

## 未解决（缺证据，不得用于 P0）


## 复核要点（Reviewer）

1. 每条功能码的 `function / inputs / schmitt` 是否与所引 PDF 页原文一致；
2. 标 `CONFLICT` 的条目是否确实存在证据冲突（不得把「不知道」写成冲突）；
3. `family_scope` 是否覆盖了该码在逻辑族中的适用家族（CBT/CBTD 等开关族见 overrides）；
4. `unresolved` 条目是否确无可靠来源；
5. 签核前重算 `content_hash`，并与本文件顶部一致。
