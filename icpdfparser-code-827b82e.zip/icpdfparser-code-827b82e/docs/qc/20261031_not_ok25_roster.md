# 剩余 25 件 `not_ok` 逐件名单

> 2026-10-31 · 数据来自 `.sandbox/rr_v11.json`（上划线 2028 件覆盖 + 降级判据修正后）
> 全部 25 件**不建议批量处理**：三类各有各的根因，逐件人看。

## 总览

| 桶 | 件数 | 根因 | 建议 |
|---|---|---|---|
| A2 真信号 | 5 | 渲染器 `canon_pkg` 与状态层 `_canon` 派生不一致 | 改代码，不改数据 |
| 换型号 / 封装 key | 16 | 旧页整页是别的型号或旧封装 key | 重解析源 JSON 或逐件裁决 |
| 符号异类 | 4 | 线条增删或混合改动，机器判不了 | 逐件看图 |

---

## 桶一：A2 真信号（5 件）

门禁 finding 全部是 `symbol_page_3d_node_without_state`。根因是渲染器用
`canon_pkg(pkg, declared or len(pins))`、状态层用 `_canon(pkg, declared)`：
`declared=0` 时一个补脚数、一个不补，于是同一页的两份状态对不上。

| mpn | 渲染器 key | 状态层 key | 类型 |
|---|---|---|---|
| `5962-85155012A` | `DIP-20` | 无 | `package_type_missing` |
| `8103611RA` | `20PIN-20` | 无 | `package_type_missing` |
| `8405601CA` | `SOIC-14` | 无 | `package_type_missing` |
| `BQ25898EVM-730` | `PWR730-15` | `PWR730-730` | `template_not_indexed` |
| `CD74HCU04M96G4` | `UNKNOWN-14` | `UNKNOWN-UNK` | `template_not_indexed` |

**裁决：改代码，绝不放行、绝不改数据**（替厂商补封装名是造假）。
影响面（引用共享 `.3d.svg` 的页面）：`template` 6334 / `template_not_indexed` 109 /
`grid_geometry_not_signed` 22 / `package_type_missing` 3。
注：`8405601CA` 同时是 `overbar_only`，即使修了符号判据也仍被 findings 拦。

---

## 桶二：换型号 / 封装 key（16 件）

两类混在一起，处置方式不同：

**A. 旧页整页是别的型号（`mpn_renamed`，14 件）**
旧页标题/符号里是旧型号，新页按当前 JSON 的 mpn 重画，所以标题与符号都变了。

| mpn | 旧页标题里的型号 |
|---|---|
| `1A1G04QDBVRG4Q1` | `SN74AHC1G04-Q1` |
| `1P1G3157QDBVRQ1` | `SN74LVC1G3157-Q1` |
| `1P1G3157QDCKRQ1` | `SN74LVC1G3157-Q1` |
| `1P1G66QDBVRG4Q1` | `SN74LVC1G66-Q1` |
| `1P1G66QDBVRQ1` | `SN74LVC1G66-Q1` |
| `1P2GU04QDRYRQ1` | `SN74LVC2GU04-Q1` |
| `74LVC1G132DCKTG4` | `SN74LVC1G132DCKTG4` |
| `551013276-001_NOPB` | `LMP7708` |
| `551600000-001A_NOPB` | `LM3402` |
| `1P1G126QDRYRQ1` / `1P1G14MDBVREPG4` / `3656BG` / `3656HG` / `BUF634PG4` | 符号里的引脚数据换了（文本无差异） |

处置：确认 `data/parsed` 里这件的 JSON 是不是真的属于这个 mpn。
是 → 新页是对的，可逐件放行；否 → 该 JSON 要重解析。

**B. 封装 key 回退 + 字符归一（2 件）**

| mpn | 旧页 | 新页 |
|---|---|---|
| `3656AG` | `20LEADISOOMN-20（共享封装图）` | `CDIPJND-20` |
| `3656KG` | `20LEADISOOMN-20（共享封装图）` | `CDIPCERAMICD-20` |

同时引脚名 `P–`（en dash）归一成 `P-`。不是退化：新页不再挂共享图、改用解析出的封装。

---

## 桶三：符号异类（4 件）

机器判据到此为止，这 4 件只能看图：

| mpn | 扫描分类 | 说明 |
|---|---|---|
| `LM317` | `line_added_not_overbar` | 新增了一条**不是**上划线的线；标题脚数文案也从「已…」变了 |
| `551013277-001_NOPB` | `line_removed` | 少了一条线；标题里的 `551013277-001/NOPB`（斜杠）变成下划线形式，封装 `SOIC-8` → `SOT-5` |
| `DRV81004-Q1EVM` | `line_removed` | 少了一条线；标题封装文案有变 |
| `AM26C32IDG4` | `overbar_plus_other` | 加了上划线，还改了别的地方 —— 不属于纯上划线批次 |

---

## 不在本名单里的「大数」

这几类数量更大，但都不在 `not_ok` 里，各自另有归处：

| 类 | 件数 | 状态 |
|---|---|---|
| `downgrade` | 609 | 硬阻断。含新判据从 `collapse`/`not_ok` 归位进来的 211 + 46 件（见下） |
| `mpn_mismatch` | 545 | 页面主语与 JSON 不一致，改了会换标题 |
| `collapse` | 11 | 真·塌缩（不含被归位到 downgrade 的那 211 件） |
| `empty_render` | 1 | |

### 附：降级判据修正带出的 257 件

`is_downgrade` 原先只看 `old_sym and not new_sym`，旧页没有原理图符号块时根本不触发：

- **46 件**：旧页是 PDF 无引脚表的三视图（有封装图与 3D），新页因 `data/parsed`
  缺球位映射被渲染成「BGA 球位待核」说明页 → 整页内容消失却被记成 `not_ok`。
  而 `not_ok` 是**可以**被 allowlist 放行的类 —— 一次人工特批就会让 46 页静默变空。
- **211 件**：同类现象原先被记成 `collapse`（87 KB → 1.3 KB），现归到 `downgrade`，
  更贴近真实性质。两者都在 `HARD_BLOCK` 里，**安全等级没变**。
