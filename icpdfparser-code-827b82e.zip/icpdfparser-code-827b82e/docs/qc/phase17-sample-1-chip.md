# Phase 1.7 灰度样本 1/3 · 芯片（LM317）

**日期**：2026-11-03 · **代码**：`origin/main@d6fc276`（镜像 `icpdf/app:latest` + 整目录挂载）
**隔离**：Redis DB8 · `/tmp/p17/data_s1` · 容器 `p17-s1-*`（跑完即删，日志保留）
**冻结样本**：MPN `LM317` · `https://www.ti.com.cn/lit/ds/symlink/lm317.pdf`
`sha256=1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3` · 2,578,150 B · 45 页

## 结论

**PIPELINE_PASS / CONTENT_NOT_APPROVED** —— 五段链路与去重机制正常，但**内容与冻结预期不一致**：
热阻 36 行（预期 34）、引脚 4 条（预期 3）。根因已定位为 **V2 的 `pipeline.parse_pdf` 没有调用
`apply_deterministic`**（见 §5），不是模型随机波动。按裁决口径，本件不得计入 CONTENT_APPROVED。

## 1. 时间线与任务事件

| 段 | 队列 | 结果 | 耗时 | 备注 |
|---|---|---|---|---|
| fetch | `icpdf_fetch` | ok | 0.868s | `manual` 2,578,150 B，sha `1646fb2e…` |
| preprocess | `icpdf_preprocess` | ok | 1,501ms | 27,999 字符 / 16 页（共 45），`reused=False` |
| llm | `icpdf` | ok | 56,657ms | qwen-flash，`llm_calls=1`，confidence 0.95 |
| audit | `icpdf_audit` | ok | 19,905ms | `write=false`，findings 14 |
| render | `icpdf_render` | ok | 185ms | errors 0 |

`item.status=done` / `progress=100` / `parse_count=1` / `parse_ms=56,657`。
幂等键前缀 `1646fb2e…`（PDF 哈希），各段 `attempts=1`。

## 2. 指标（外审 §5 清单）

| 指标 | 值 |
|---|---|
| `start` / `download` | **1 / 1** |
| `dedup` | 0 |
| `already_running` | 0 |
| `tried_at` / PDF mtime | `2026-11-03T17:36:08+08:00` / 1,793,698,568（各 1 次，无二次变化）|
| `parse_count` | 1 |
| LLM 调用 | 1 次（qwen-flash），prompt_sha `c42a22f1…` |
| `llm_usage` 台账 | **0 行**（V2 未落账，见 §5-D2）|
| audit findings | 14（`row_ambiguous_unresolved` 8、`footnote_missing` 3、`unit_dimension_unresolved` 1、`package_mismatch` 1、`pin_table_unresolved` 1）|
| 产物 | JSON 15,053 B、TXT 28,556 B、symbol 4,256 B |
| 正式数据副作用 | 无（见 §4）|

## 3. 内容核对（与冻结预期）

| 断言 | 冻结预期 | 实测 | 判定 |
|---|---|---|---|
| `basic_info.identity` / `specs.scope` | chip / device | chip / device | ✅ |
| 五段阶段账 | 全部 ok | 全部 ok（attempts=1） | ✅ |
| `parse_count` | 1 | 1 | ✅ |
| `specs.thermal` 行数 | **34** | **36** | ❌ |
| `RθJC(top)` | Legacy-DCY 43.2 / New-KTT 43.6 | 43.2 / 43.6（两者都在） | ✅ |
| `pin_configuration` | 3 | **4**（`1 ADJUST / 2 OUTPUT / 3 INPUT / 4 OUTPUT`，第 4 条重复 OUTPUT） | ❌ |
| audit | 无 blocking | ok（14 findings，无 blocking） | ✅（但 finding 数异常偏高） |

热阻 36 行的形态：**模型输出**（按封装分组，含 `RθJC(bot) NA @ Legacy DCY` 与 `— @ New DCY`），
而不是 A22 实现的确定性结果（按参数分组、占位符不落行、34 行）。
这与「占位符占列不落行：宁可缺、不许错列」的纪律相反 —— `NA`/`—` 作为数值写进了正式容器。

## 4. 正式数据副作用

灰度前后生产指纹**逐字节一致**：

```
parsed files=13539 bytes=281419444 digest=acf8d167bb360afc933f0468840c08af2ec4fe410a93069c89deb808c9a1a6c4
db sha256=d93d65851f773169cace5754defdb326af616500d69cbda430adfb8c2bfa074c size=95834112
容器 restarts=0（server/render/llm/fetch/redis，started 时间未变）
```

## 5. 发现（阻断 V2 提升）

**D1（P0）V2 LLM 阶段漏掉确定性抽取。**
`app/services/pipeline.py::parse_pdf` 全文没有 `apply_deterministic`；
legacy 的 `parse_datasheets.py` 在 1572 / 1605 行调用它。后果：
- 热阻/ESD/引脚回到**模型原始输出**，出现 `NA`/`—` 行与重复引脚；
- 同一件在 legacy 与 V2 两条链路上给出不同的交付 JSON；
- audit 14 findings（legacy 路径下这些会被确定性结果消解或改判）。

**D2（P1）V2 不落 `llm_usage`。**
`_log_calls` 只在 `pipeline.llm_stage`（legacy 全链路）里调用；V2 的 `stage_llm` 直接调
`parse_pdf`，所以 token 台账为空 —— 「灰度必须记录 LLM Token」这一项在 V2 下**不可观测**。

## 6. 证据位置

```
/tmp/p17/s1.json            # 本报告的数据源（probe report）
/tmp/p17/log_s1-*.log       # 五个 worker 的完整日志
/tmp/p17/data_s1/           # 隔离数据根（pdfs / slices / parsed / txt / symbols / workbench.sqlite3）
```

## 7. 人工审核结论

机制层通过；**内容层不通过**。在 D1/D2 修复并用同一冻结样本复跑之前，本件不可作为
V2 推广依据；也不得据此判定算法准确率。
