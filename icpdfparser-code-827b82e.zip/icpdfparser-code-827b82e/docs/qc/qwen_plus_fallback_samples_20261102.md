# qwen3.7-plus 兜底重抽：首批实验样本（1102-V3.4）

> 用途：这三条是「**选页已修好、模型仍抽不出**」的硬证据样本。
> 只有当样本同时满足 ①电气表页确认进入上下文 ②模型仍交空/残缺，才允许升级模型重抽。
> 反例：`ADC12QJ1600ALREP`（151 页）属于「空电气」，但归因是长文档截断/选页，不能直接算模型账。

## 样本 1：ADC08B200EB（**已证实为模型短板**）

| 项 | 证据 |
|---|---|
| PDF | 42 页，SNAS388F（2013-04 修订），8-Bit 200 MSPS ADC with Capture Buffer |
| 型号性质 | **纯芯片 Datasheet**；`EB` 是订货/封装代码，不是 EVM（已用前两页文本实锤） |
| 电气表页 | p6 / p7 / p8（另 p22、p26、p28 也有该标题） |
| 选页结果（方案①落地后） | `selected=16 pages`：`[1‑10, 21, 22, 26, 30, 36, 37]`，**含 6/7/8**，`electrical header in context = True`，43,249 字符 |
| 模型结果 | `PARSE_FAILED: empty_electrical`（多次复跑一致，117.8s / 264.7s） |
| 结论 | **上下文里有电气表，flash 仍交空卷** → 模型能力问题，不是选页问题 |

## 样本 2：ADC12QJ1600ALREP（长文档，待复核归因）

- 151 页；deterministic 抽到 thermal 3 / esd 2，但模型 electrical 为空（12→0，被守卫拒收）。
- 首轮归因「长文档截断」；方案①后需重跑一次，确认 16 页预算下电气起始页是否在列。
- 若已进入上下文仍空 → 归入模型短板样本；否则继续修选页。

## 样本 3：ADS1286U（**不是模型问题，是源无表**）

- 13 页 / 23,103 字符，`Thermal Information`、`ESD Ratings`、`°C/W` 命中均为 **0**。
- 判定 `not_applicable`（源文档确实没有这两张表），**不得计入空表率**，也不进兜底样本。

## 兜底触发口径（建议）

1. 仅对 `chip` 层、且「电气表页在上下文」却仍 `empty_electrical` 的件触发 plus 重抽；
2. 每件只重抽 1 次，结果仍空则落 `PARSE_FAILED`，绝不写盘覆盖旧数据（守卫已强制）；
3. 触发记录写 `metadata.fallback = {"model": "qwen3.7-plus", "reason": "empty_electrical_with_context"}`，便于 A/B 统计。
