# Phase 1.7.1 集成验收（D1–D3）

**验收对象**：`origin/main@88d023e`（2026-11-03）
**验收范围**：V2 五段链路中的 **preprocess + llm** 真实运行路径；外加五段接力的代码级回归。
**不在本轮范围**：容器级灰度重跑（fetch/render 真实投递）、生产库写入、V3 打包。
**结论先行**：

| 项 | 裁决 | 依据（不只看测试） |
|---|---|---|
| D1 · V2 接入确定性后处理 | **PASS**（88d023e 修复后） | 真实 LM317 复跑：模型原样 36 行 → 34 行；同一份 `apply_deterministic`；落盘带 `deterministic_extract` / `core_validation` |
| D2 · `stage_llm` 落 `llm_usage` | **PASS** | 隔离 sqlite 实写：2 次真实调用 2 行（含失败重试）；缓存命中 `cached` 且 0 新增 |
| D3 · 板卡字段主体归属 | **PASS（字段级）** | 真实 ADS8568EVM-PDK：thermal 11 / esd 2 全部 `subject=onboard_device`；electrical/absmax 已在隔离区 |
| 三件冻结样本复跑 | **PASS**（preprocess+llm） | MPN/URL/PDF SHA 与冻结单逐字节一致；三件终态符合预期 |
| 五段接力 / 隔离 | **PASS（代码级）** | 174 项阶段/接线回归 + 16 项 fetch 去重用例 |
| V3 解锁 | **仍未批准** | 见 §6 |

---

## 1. D1 · V2 的 `parse_pdf` 是否真实调用确定性后处理

### 代码位置与调用链

| 环节 | 位置 | 说明 |
|---|---|---|
| V2 入口 | `app/pipeline/stages.py::stage_llm` L317 | 最终调用 `PL.parse_pdf(...)`，没有第二套 prompt/后处理 |
| V2 后处理 | `app/services/pipeline.py::parse_pdf` L188–262 | L207 首次 `_apply_deterministic()`；L217 修复稿替换 doc 后 L221 **再覆盖一次** |
| 确定性实现 | `qc/deterministic_extract.py::apply_deterministic` | **与 Legacy 同一份**，未复制判据 |
| 核心校验 | `qc/core_validation.stamp`（L259 附近） | 落 `metadata.core_validation` |
| Legacy 对照 | `parse_datasheets.py` L1572 / L1605 / L1693 | 同一 `apply_deterministic`、同一 metadata 重取口径 |

调用链：

```text
stage_llm
  └─ app.services.pipeline.parse_pdf
       ├─ pd.chat(parse)
       ├─ qc.deterministic_extract.apply_deterministic        # 首次覆盖
       ├─ qc.deterministic_extract.check_core / check_acceptance
       ├─ pd.chat(repair)  （仅核心字段不达标时）
       ├─ parse_doc_clean → 重新绑定 meta                     # 修复稿是新的 doc
       ├─ apply_deterministic                                # 二次覆盖
       ├─ qc.identity_scope.apply                            # D3
       └─ meta 重新绑定并写 deterministic_extract / core_validation
```

### 验收中发现并已修复的真实缺陷

`main@35d4e62` 上，真实 LM317 复跑（未加任何桩）触发了修复重试，结果是：

| 指标 | 35d4e62 实测 |
|---|---|
| `llm_calls` | 2（多烧一次修复调用，36,512 tokens） |
| `specs.thermal` | 34 行（内容正确） |
| `metadata.pdf_hash` | **空** |
| `metadata.deterministic_extract` | **丢失** |
| `metadata.core_validation` | **丢失** |

根因不是抽取错，而是 **`IS.apply()` 内部 `canonical_view` 会 `doc.clear(); doc.update(view)`，把 `metadata` 换成新 dict**，旧的 `meta` 变量变成孤儿；重试替换 doc 时同样。确定性内容对了，但审计痕迹和 SHA 溯源没了 —— 这正是「测试全绿、真实路径掉证据」的典型。

修复提交：`88d023e fix(pipeline): D1 复核修正 —— 早落 datasheet_url、重试后重取 metadata`。
新增红先用例：`tests/test_phase171_d1_deterministic.py::test_repair_retry_keeps_deterministic_metadata`。

### 实际输出（修复后，真实 LLM）

| 断言 | 实测 |
|---|---|
| `status` | `ok` |
| `llm_calls` / tokens | **1 / 16,903**（不再白烧修复调用） |
| `metadata.pdf_hash` | `1646fb2e…`（与冻结 SHA 一致） |
| `specs.thermal` | **34** 行 |
| `metadata.deterministic_extract.thermal` | **`from=36 → to=34`**（正好消掉 Phase 1.7 记录的 36 行脏数据） |
| `pin_configuration` | **3** 条（ADJUST / OUTPUT / INPUT） |
| `RθJC(top)` | Legacy-DCY `43.2`、New-KTT `43.6` 同时存在 |
| `core_validation` | `pass` |

证据：`docs/qc/phase171/evidence/e2e-lm317-fixed.json`、`e2e-lm317-before-88d023e.json`、`d1-lm317-v2.json`。

---

## 2. D2 · `stage_llm` 是否真实记账（tokens / 耗时 / 重试 / 缓存）

### 代码位置

| 环节 | 位置 |
|---|---|
| 记账入口 | `app/pipeline/stages.py::_record_llm_calls` L250–270，在 L322 `_run` 内调用 |
| 复用 Legacy | `app/services/pipeline.py::_log_calls` L904–917（同一实现、同一张表） |
| 表定义 | `app/db.py::DDL` `llm_usage` L118–137 |
| 写入 SQL | `app/services/usage.py::record` L45–58 |
| 缓存早返回 | `stages.py` L297–307，**在 `_run` 之前**，因此不会产生假记录 |

### 实际输出（隔离 sqlite，真实 `_log_calls`）

`ICPDF_WORKBENCH_DB=<tmp>/workbench.sqlite3`，跑两次 `stage_llm`（第一次 miss、第二次命中）：

| 项 | 实测 |
|---|---|
| 第一次 | `ok`，写入 **2** 行 |
| 行 1 | `stage=parse`、`attempt=1`、`ok=1`、`total_tokens=1300` |
| 行 2 | `stage=repair`、`attempt=2`、`ok=0`、`error=JSONDecodeError: truncated`、`total_tokens=1600` |
| 第二次 | `cached`，`llm_usage` 仍 **2** 行（0 新增） |
| 无 `llm_calls` 的返回 | 0 行（不凭空造账） |

证据：`docs/qc/phase171/evidence/d2-llm-usage.json`；用例：`tests/test_phase171_d2_usage.py`（3 项）。

---

## 3. D3 · 板卡 `thermal` / `esd` 的字段级主体归属

### 代码位置与调用链

| 环节 | 位置 |
|---|---|
| V2 调用 | `app/services/pipeline.py` L247–248：`IS.apply(doc, mpn, pdf_text=text, pdf_path=pdf)` |
| Legacy 对照 | `parse_datasheets.py` L1652–1653：同一 `IS.apply` |
| 行级标注 | `qc/identity_scope.py::_stamp_row_subjects` L229–263，调用点 L416 |
| 证据口径 | `onboard_device_datasheet → onboard_device`；`board_user_guide → board`；判不出 → `ambiguous + needs_human` |
| 容器策略 | **不搬 thermal/esd 容器**，只给每一行补 `subject` / `subject_source`；`electrical/absolute_max` 仍按原逻辑进隔离区 |

### 实际输出（真实 ADS8568EVM-PDK）

| 断言 | 实测 |
|---|---|
| `status` / `pdf_sha256` | `ok` / `79c02991…`（冻结 SHA 一致） |
| `basic_info.identity` | `evaluation_board` |
| `basic_info.document_scope` | `onboard_device_datasheet` |
| `specs.scope` / `pin_scope` | `onboard_device` / `board` |
| 主容器 `specs.thermal` | **11 行，全部 `subject=onboard_device`、`subject_source=onboard_device_datasheet`** |
| 主容器 `specs.esd` | **2 行，同为 `onboard_device`** |
| `specs.electrical` / `absolute_max` | **0 / 0**（已搬入隔离区） |
| `specs.onboard_device_specs` | electrical **153** / absolute_max **11** / pin_configuration **40** |
| `subject_summary` | `{"thermal":{"onboard_device":11},"esd":{"onboard_device":2}}` |
| `core_validation` | `pass` |
| LLM 消耗 | 1 次调用 / 27,379 tokens / 200.6 s |

证据：`docs/qc/phase171/evidence/d3-ads8568-scope.json`、`e2e-ads-dac-fixed.json`；用例：`tests/test_phase171_d3_subject.py`（5 项，含 ambiguous 与幂等）。

**口径提醒**：D3 交付的是「每行可复算的主体标注」，不是「把容器整体搬走」。如果产品要求物理隔离容器，这是另一个裁决；当前实现满足外审提出的「消费者不能只凭容器位置猜主体」。

---

## 4. 三件冻结样本复跑

PDF 先做逐字节复核，全部 MATCH（未改 MPN / URL / SHA）：

| # | MPN | SHA 实收 | 结果 |
|---|---|---|---|
| 1 | LM317 | `1646fb2e…` ✅ | `ok`；thermal **34**；pins **3**；`RθJC(top)` 43.2(DCY) + 43.6(KTT)；det **36→34**；core pass；1 call / 16,903 tokens |
| 2 | ADS8568EVM-PDK | `79c02991…` ✅ | `ok`；thermal **11** / esd **2** 全部 onboard_device；electrical/absmax 0；ods 153/11；identity/scope 正确；1 call / 27,379 tokens |
| 3 | DAC8568EVM（UG） | `a7e7253d…` ✅ | `skipped`；`NOT_A_DATASHEET`；**0 次模型调用 / 0 tokens / 无 JSON**；0.2 s 短路 |

证据：`docs/qc/phase171/evidence/e2e-frozen-3samples.json`。

**范围声明**：本轮从 `preprocess`（真实切文本）跑到 `parse_pdf`（真实模型），产物只写系统临时目录；**fetch 下载与 render 渲染没有重跑**，因此不把本次结果表述为「五段容器级灰度通过」。`parse_count` 是需要队列才能观测的指标，本轮未测。

---

## 5. 五段接力与隔离（代码级）

| 命令 | 结果 |
|---|---|
| `pytest tests/test_pipeline_stages.py tests/test_pipeline_wiring.py tests/test_deterministic_extract.py tests/test_identity_scope.py tests/test_board_scope.py -q` | **174 passed / 104.98 s** |
| `pytest tests/test_phase171_d1_deterministic.py tests/test_phase171_d2_usage.py tests/test_phase171_d3_subject.py tests/test_fetch_dedup.py -q` | **29 passed / 28.27 s** |

覆盖到的关键不变量（用例名）：

- 五段接力：`test_run_chain_full_path`、`test_run_chain_stops_on_skipped`、`test_preprocess_skipped_stops_chain`
- 缓存不涨计数：`test_llm_v2_cached_does_not_bump_parse_count`、`test_p1_08_duplicate_submit_does_not_call_llm_twice`
- 审计不写回：`test_audit_never_asks_for_write`、`test_audit_never_writes`
- 影子不污染正式产物：`test_p1_12_shadow_does_not_write_formal_outputs`
- fetch 幂等 / 原子领取：`tests/test_fetch_dedup.py`（16 项）

本轮所有探针产物均在 `%TEMP%`，D2 记账显式指向隔离 sqlite；未向生产 `workbench.sqlite3` 写一行。

---

## 6. V3 仍未解锁

本次只回答「D1–D3 是否真的进入 V2 运行路径」。V3 的顺序不变：

1. D1–D3 验收通过 ✅（本报告）
2. 三件冻结样本复跑通过 ✅（preprocess+llm 范围）
3. 对计划进入 V3 的 8 件重新解析
4. 重新渲染交付物并更新 staging
5. `delivery_bundle.py` 63 项自检
6. 独立交付验收

`PIPELINE_PASS`（链路/内容不变量）≠ `CONTENT_APPROVED`（全部内容）≠ `RELEASE_APPROVED`（可发布）。

---

## 7. 复核命令

```powershell
git rev-parse HEAD            # 应为 88d023e 或其后包含该修复的提交

# D1 / D2 / D3 红先用例
python -m pytest tests/test_phase171_d1_deterministic.py `
                 tests/test_phase171_d2_usage.py `
                 tests/test_phase171_d3_subject.py -q

# 阶段/接线/身份/去重回归
python -m pytest tests/test_pipeline_stages.py tests/test_pipeline_wiring.py `
                 tests/test_deterministic_extract.py tests/test_identity_scope.py `
                 tests/test_board_scope.py tests/test_fetch_dedup.py -q
```

证据文件（均在 `docs/qc/phase171/evidence/`）：

| 文件 | 内容 |
|---|---|
| `d1-lm317-v2.json` | 桩模型输出下的 V2 确定性覆盖（7→34，占位符 0 行） |
| `e2e-lm317-before-88d023e.json` | 修复前真实运行：内容对、审计痕迹丢（缺陷证据） |
| `e2e-lm317-fixed.json` | 修复后真实运行：36→34、SHA、core pass |
| `d2-llm-usage.json` | 隔离 sqlite 的 `llm_usage` 两行 + 缓存命中 0 新增 |
| `d3-ads8568-scope.json` | ADS 真实输出的行级 subject 与隔离区计数 |
| `e2e-ads-dac-fixed.json` | ADS 真实运行 + DAC 短路 |
| `e2e-frozen-3samples.json` | 三件冻结样本汇总（含 SHA 校验） |
