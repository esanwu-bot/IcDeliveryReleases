# Phase 1.6 最小生产接线 · 验收报告

**日期**：2026-11-03
**范围**：五段链路（fetch → preprocess → llm → audit → render）的队列与 Celery 任务接线、`ICPDF_PIPELINE_V2` 灰度开关
**红线**：只接线，不改算法、不加并发、不动老链路语义
**提交**：`9e2668d`（阶段层）+ `bff31f5`（接线与开关）

---

## 0. 结论

四道关全部通过：

| 关 | 内容 | 结果 |
|---|---|---|
| G1 | 路由：一件货依次被 5 个队列的 5 个 worker 消费 | **PASS** |
| G2 | 幂等：同一件重复投递，不重复下载、不重复调模型 | **PASS**（判定口径见 §5，另附更严口径下发现的既有缺陷）|
| G3 | 隔离：正式数据零污染 | **PASS**（`data/parsed` 13,539 个文件指纹逐字节一致，生产库指纹一致）|
| G4 | 兼容：旧任务仍由旧 worker 接单，没被新链路抢走 | **PASS** |

但**不建议直接开 3 件灰度**：接线过程中发现 1 个既有缺陷（`fetch_item` 的去重判据被自己的状态写入踩掉，第三次投递会真的重下），不在本轮授权范围内，需要裁决后单独修。详见 §9。

---

## 1. 改了什么

只动 6 个文件，加 1 个测试文件。**没有一行算法改动**。

| 文件 | 改动 |
|---|---|
| `app/config.py` | 新增 `PREPROCESS_QUEUE` / `AUDIT_QUEUE`；`TASK_QUEUE` 加 4 个 kind；新增 `PIPELINE_V2`（默认 `False`）|
| `worker/celery_app.py` | 显式声明 5 个队列 + `task_routes`（任务名 → 队列）作为第二道保险 |
| `app/services/dispatch.py` | `queue_depths()` 改按 `TASK_QUEUE` 的值集合推导（新队列自动进监控，不再手抄队列名）|
| `worker/tasks.py` | 4 个新任务 + `fetch_item` 的接力目标分叉（1 行）+ 3 处接线期发现的修正（见 §8）|
| `run_worker.py` | `--role` 增加 `preprocess` / `audit`，并发档沿用 render 的 8，**不新增并发参数** |
| `tests/test_pipeline_wiring.py` | 新增 21 条，守住路由/开关/分叉/接力/不静默重抽/不写回/旧任务体 |

### 任务链

```
fetch_item ──(PIPELINE_V2=1)──> preprocess_item ──> llm_item_v2 ──> audit_item_v2 ──> render_item_v2
     └───────(PIPELINE_V2=0)──> llm_item ─────────────────────────> render_item          （原样）
```

两条链**共用 `fetch_item`**，分叉点只有一处：`fetch_item` 里决定"接力给谁"的那一行。
开关关着时，代码路径与接线前逐字节相同（`app.pipeline` 全部惰性 import，worker 进程的导入面都没变）。

### 为什么新任务名带 `_v2`

Celery 按**任务名**注册。若新任务沿用 `icpdf.llm_item`，旧 worker 会把新消息当成自己的活接下来，
执行到一半才发现语义不同。带 `_v2` 后缀 = 新旧消息即使落进同一个 Redis 队列，也不会串。

---

## 2. 验收环境（以及为什么不在这台 Windows 上跑）

本机没有 Redis（`redis-py` 未安装、无 `redis-server`、无 Docker），
`dispatch.submit` 会直接退化到进程内线程池 —— 那样根本不存在"五个队列被五个 worker 消费"这回事，
G1 无从谈起。所以四道关在生产服务器 `159.89.190.225` 上跑，但做了**三重隔离**：

| 维度 | 生产 | 验收 | 为什么必须分开 |
|---|---|---|---|
| Redis | DB 0 | **DB 5**（G1–G3）/ **DB 6**（G4）| 队列名相同。共用 DB 会被生产 worker 抢走探针消息 |
| 数据根 | `/www/wwwroot/icpdfparser/data` | `/tmp/p16/data`（G1–G3）/ `/tmp/p16/legacy/data`（G4）| 挂在容器 `/app/data`。`config` 的所有路径都由它派生，换根即换全部产物目录 |
| 代码 | 镜像 `icpdf/app:latest` | 同镜像 + **只挂载本次改动的 8 个文件**（`:ro`）| 镜像烘焙于 `app/pipeline/` 之前，不挂就是 `ModuleNotFoundError`；只挂 diff 才能回答"跑的到底是哪份代码" |

探针容器名 `p16-*`，全部 `docker rm -f` 收尾，生产五个容器（`icpdf-fetch/llm/render/server/redis`）全程未重启。

> 为什么要独立数据根，而不是"跑完再检查有没有被改"：五段链路的 render 段会写
> `data/txt`、`data/alts`、`data/seo`、`data/symbols` 并 `touch_status("done")`。
> 在一份真数据上跑，即使事后能复原，也已经污染过。隔离是**构造性**的，事后核验是补充证据 —— 两者都做了（§6）。

---

## 3. G1 路由：一件货穿过五个队列

**投递**：`dispatch.submit("fetch_item", "LM317", False, <TI 官方 PDF>)` → Redis DB5 / `icpdf_fetch`
**环境**：`ICPDF_PIPELINE_V2=1`，五个 worker 各 `-c 1`，冷启动（库、切片、产物、PDF 全部清空）

### 3.1 五个 worker 的接单日志（时间戳首尾相接）

```
########## p16-v2-fetch ##########          [15:22:56] fetch@1 ready.
[15:23:13,771] Task icpdf.fetch_item[769f037c] received
[15:23:16,007] Task icpdf.fetch_item[769f037c] succeeded in 2.235s
########## p16-v2-preprocess ##########     [15:22:57] preprocess@1 ready.
[15:23:16,006] Task icpdf.preprocess_item[7f0d5925] received        ← 比上一段收尾早 1ms
[15:23:17,622] Task icpdf.preprocess_item[7f0d5925] succeeded in 1.615s  next=llm_item_v2
########## p16-v2-llm ##########            [15:22:57] llm@1 ready.
[15:23:17,622] Task icpdf.llm_item_v2[0eb6c1c6] received
[15:23:53,913] Task icpdf.llm_item_v2[0eb6c1c6] succeeded in 36.289s   next=audit_item_v2
########## p16-v2-audit ##########          [15:22:57] audit@1 ready.
[15:23:53,912] Task icpdf.audit_item_v2[6fcc42bf] received
[15:24:19,011] Task icpdf.audit_item_v2[6fcc42bf] succeeded in 25.098s next=render_item_v2
########## p16-v2-render ##########         [15:22:58] render@1 ready.
[15:24:19,016] Task icpdf.render_item_v2[9307c5de] received
[15:24:20,625] Task icpdf.render_item_v2[9307c5de] succeeded in 1.606s  next=''
```

每一段都在**自己的队列**里被**自己的进程**消费，`next` 字段即下一段的接力目标，
收尾与下一个 `received` 相差 1–5ms —— 这是接力而不是并行猜测。

### 3.2 冷启动的最终一轮（含全部修正）

| 段 | 队列 | 状态 | 耗时 | attempts | 关键产物 |
|---|---|---|---|---|---|
| fetch | `icpdf_fetch` | ok | 1.49s | —（走老 `item` 表）| `data/pdfs/LM317__lm317.pdf` 2,518,150 B，sha `1646fb2e…` |
| preprocess | `icpdf_preprocess` | ok | 1.31s | 1 | 切片 27,399 字符 / 16 页（共 45 页），`text_sha256=701bd7a5…` |
| llm | `icpdf` | ok | 30.92s | 1 | 12 条电气 / 3 个引脚，confidence 0.95，`prompt_sha256=92475826…` |
| audit | `icpdf_audit` | ok | 18.50s | 1 | findings 10（`write=false`）|
| render | `icpdf_render` | ok | 1.28s | 1 | `data/txt/LM317.txt`、`data/symbols/LM317.html`，errors 0 |

终态：`item.status=done`，`progress=100`，`parse_count=1`。

阶段账 `pipeline_stage` 四行、`attempts` 全为 1，幂等键形如
`1646fb2e…:llm:1:92475826…:qwen-flash:f20a579a…`（PDF 哈希 + 阶段 + 版本 + prompt 指纹 + 模型 + 配置指纹）。

> **fetch 段没有 `pipeline_stage` 行**，这是设计而非遗漏：本轮按裁决复用老 `fetch_item`，
> 下载逻辑（各平台重试/反爬/UA）一行没动，所以它的账还在 `item` + `doc_source` 里。
> 把 fetch 挪进阶段层等于重写下载，属于后续阶段。

---

## 4. 队列归属的交叉验证

按任务名统计两条链路**实际执行过**的任务（不是 worker 启动时的注册清单）：

| worker 组 | 实际执行 |
|---|---|
| `p16-legacy-*`（V2=0）| `icpdf.fetch_item`、`icpdf.llm_item`、`icpdf.render_item` —— **零个 `_v2`** |
| `p16-v2-*`（V2=1）| `icpdf.fetch_item`、`icpdf.preprocess_item`、`icpdf.llm_item_v2`、`icpdf.audit_item_v2`、`icpdf.render_item_v2` —— **零个老 `llm_item`/`render_item`** |

两侧都是零串台。

---

## 5. G2 幂等：同一件重复投递

**判定口径**：一件已完成（`done`）的货，再投一次同样的消息。

| 观测点 | 重复投递前 | 重复投递后 | 判定 |
|---|---|---|---|
| `item.status` | `done` | `done` | 未被降级 |
| `parse_count` | 1 | 1 | 模型没被再调一次 |
| `parse_ms` | 30,921 | 30,921 | 未被改写 |
| PDF `mtime` / `size` | 1793691516 / 2,578,150 | 1793691516 / 2,578,150 | 没重新下载 |
| `doc_source.tried_at` | `15:38:36` | `15:38:36` | 没有新的采集尝试 |
| `pipeline_stage.attempts` | 1 / 1 / 1 / 1 | 1 / 1 / 1 / 1 | 阶段账没虚增 |

事件流（按发生顺序）：

```
dedup: 已解析过，按去重规则跳过          ← fetch_item 0.004s 返回 skipped，未投下游
stage: 模型解析完成：cached 3ms          ← 直接投 llm_item_v2 也命中缓存，不调模型
stage: 确定性复核完成：cached 2ms
stage: 交付物渲染完成：cached 2ms
```

### 这条关是怎么"卡住"的（值得记）

第一次做 G2 时传了 `manual_url`，两次投递都真的重下了。查下来是 `fetch_stage` 的去重判据本身就写着
`and not manual_url` —— **手工链接是显式的重新下载意图，按设计绕过去重**。测试口径错了，不是代码错了。
改成不传链接后，才是这条关该有的样子。

---

## 6. G3 隔离：正式数据零污染

在 G1/G2 之前采集基线，四关跑完再采一次。**主键是 SHA256 汇总**，不是 mtime ——
mtime 只能证明"文件被碰过"，证明不了"内容没变"。

| 对象 | 基线 | 四关之后 | 判定 |
|---|---|---|---|
| `data/parsed`（13,539 文件 / 281,419,444 B）| `acf8d167bb360afc933f0468840c08af2ec4fe410a93069c89deb808c9a1a6c4` | 同一串 | **逐字节一致** |
| `data/workbench.sqlite3`（95,834,112 B）| `d93d65851f773169cace5754defdb326af616500d69cbda430adfb8c2bfa074c` | 同一串，mtime 仍是 `2026-11-01 10:51:53` | **未被写过** |

计算方式：`find <dir> -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum`
（按路径排序后再汇总，避免 `find` 顺序影响结果）。

为了不让"没变化"是空集造成的假象，同一条命令在隔离根上跑出的是：

- `/tmp/p16/data/parsed` → 新增 `LM317_1646fb2e.json`（本次唯一的正式产物）
- `/tmp/p16/data/{txt,symbols,slices}` → 对应产物

即：产物**产生了**，只是产生在隔离根里。

---

## 7. G4 兼容：旧 worker 还能接单

**环境**：Redis DB6 + 独立数据根 + `ICPDF_PIPELINE_V2=0`，三个 worker（fetch/llm/render）。
**投递**：`fetch_item(NE555, manual_url=…)`

```
########## p16-legacy-fetch ##########
[15:42:58,607] Task icpdf.fetch_item[f149943d] received
[15:42:59,487] Task icpdf.fetch_item[f149943d] succeeded in 0.878s
########## p16-legacy-llm ##########
[15:42:59,488] Task icpdf.llm_item[d2c2d80c] received            ← 老任务名，不是 _v2
[15:44:01,272] Task icpdf.llm_item[d2c2d80c] succeeded in 61.783s
########## p16-legacy-render ##########
[15:44:01,270] Task icpdf.render_item[3ceb936d] received
[15:44:03,088] Task icpdf.render_item[3ceb936d] succeeded in 1.817s  errors: []
```

落库结果：`('NE555', 'done', 100, 1, '')` —— 状态、进度、解析次数、错误全正常。

两条额外证据：

1. 该库里**根本没有 `pipeline_stage` 表**（`has pipeline_stage: False`）—— 老链路连阶段层的建表都没触发。
2. DB6 的 `icpdf_preprocess` / `icpdf_audit` 两个队列全程无消费者、无消息。

同一份代码、同一个镜像，只把 `ICPDF_PIPELINE_V2` 从 1 改成 0，行为就回到接线前 —— 这就是回滚路径。

---

## 8. 接线过程中发现并已修掉的三处

这三处不修，链路根本跑不完或会写脏账；都属于"接线适配"，不改变任何判定口径。

### 8.1 audit 段在 Celery 下 import 即崩（第一轮 G1 卡在这里）

```
audit  failed 1225ms  AttributeError: 'LoggingProxy' object has no attribute 'buffer'
```

`qc/table_audit.py` 在**模块级**把 `sys.stdout` 重包成 UTF-8 的 `TextIOWrapper`，需要 `sys.stdout.buffer`；
而 Celery 默认（`worker_redirect_stdouts=True`）把 stdout 换成 `LoggingProxy`，没有 `buffer`。

三个选项里取了最窄的一个：**在 `audit_item_v2` 里局部补一个带 `buffer` 的 stdout，用完换回**
（`_qc_stdout_guard`）。没有改 `qc/table_audit.py`（它同时服务工作台/命令行/批处理，且 `qc/` 当轮有并行线未提交改动），
也没有关掉全局 stdouts 重定向（那会让所有任务的日志消失）。

> **遗留风险**：老的 `qc_audit_item` 是同一个坑，只是它跑在别的路径上没被触发。同一个 `qc` 模块，
> 同样会在 worker 里崩。建议由 QC 侧把 stdout 包装改成只在 `__main__` 下生效（§10）。

### 8.2 render 命中缓存时不写 `done`

`stage_render` 缓存命中会直接返回 `CACHED`，不调用 `finish_item` —— 而 `done` 恰恰是 `finish_item` 在结尾写的。
后果：一件已经交付完的货，被一条重复消息带到 render 后状态停在 `rendering`（工作台像卡住，统计少一件）。
已在 `render_item_v2` 补一行：缓存命中即补写 `done`（缓存判据本身已核过产物文件存在，不算假装成功）。

### 8.3 缓存命中还在累加 `parse_count`

`llm_item_v2` 最初无条件 `parse_count += 1`。缓存命中时这等于把"没花钱"记成"花了一次，而且特别快（24ms）"。
灰度期判断有没有重复烧 token 就看这两个数，指标一旦做假就失去意义。已改为**只有 `status==ok` 才更新** `parse_ms` / `parse_count` / `last_parsed_at`，`json_path` 仍然每次都落库。

---

## 9. 发现但**没有**修的一处（需要裁决）

> **已由 Phase 1.6.1 修复（`dce426e`）。** 本节保留当时的判断与实测证据，
> 修复设计、F1–F8 验收与修复前后 A/B 见 [phase161-fetch-dedup.md](phase161-fetch-dedup.md)。
> 当初推荐的补丁 C（`item_was_done` 参数）**没有采用** —— 它只解决"状态被踩掉"，
> 解决不了"两个任务同时读到 pending"的竞争；实际采用的是"顺序 + 原子领取 + 租约"。

### `fetch_item` 的去重判据被自己的状态写入踩掉

```python
# worker/tasks.py::fetch_item（既有代码，非本轮引入）
item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))   # 快照：status="done"
db.touch_status(item["id"], "queued", "任务已入队", 2)            # 库里改成 "queued"
r = pipeline.fetch_stage(item, force=force, manual_url=manual_url)  # 判定用的是**旧快照**
```

`fetch_stage` 的第一句是 `if item["status"] == "done" and not force and not manual_url: 跳过`。
它拿到的是 touch 之前的旧字典，所以：

| 第几次投递 | 读到的 status | 结果 | 库里的状态 |
|---|---|---|---|
| 第 1 次（首跑）| `pending` | 正常下载 | `done` |
| 第 2 次 | `done` | **跳过**（正确）| 被改成 `queued` |
| 第 3 次 | `queued` | **真的重新下载** | `queued → done` |

实测已验证：第 2 次 `succeeded in 0.004s {'skipped': True, 'reason': 'already_parsed'}`，
第 3 次 `succeeded in 0.840s` 且 `doc_source.tried_at` 从 `15:33:40` 变成 `15:33:49`。

**影响面**：

- 正常交付（每件只投一次）不受影响；
- 但 `acks_late=True` + worker 意外中断时消息会被重投，重复投递是设计内会出现的情形；
- 重复投递还会把 `done` 降级成 `queued` —— 若这次重投随后失败，货明明已交付却显示失败。

**没有当场改的理由**：这是**老链路**的语义（`touch_status("queued")` 是给工作台"已入队"进度看的），
改它超出"只接线"的授权，而且这段代码在灰度时两条链共用。按纪律：报，不改。

**建议补丁**（三选一，推荐 C）：

- A. 把 `touch_status("queued")` 挪到 `fetch_stage` 返回非 skipped 之后 —— "已入队"其实发生在 `fetch_stage`
  写 `resolving` 之前，本来就没存在多久，删掉几乎无感；
- B. 在 `fetch_item` 里复制一份去重判据（`status=="done" and not force and not manual_url`）判断后再 touch —— 快，但规则出现两份；
- C. 给 `pipeline.fetch_stage` 增加形参 `item_was_done: bool`，由调用方传"touch 之前"的结论 —— 规则仍只有一份，改动 4 行。

---

## 10. 明确不在本轮范围内的（不要当成已做）

| 项 | 现状 | 归属 |
|---|---|---|
| `fetch` 段未进 `pipeline_stage` | 复用老 `fetch_item`，账在 `item` + `doc_source` | 需要重写下载逻辑，后续阶段 |
| `llm_usage` 未记账 | v2 链路不写 `llm_usage`（`_log_calls` 在 `llm_stage`/`finish_item` 里，`stage_llm` 没回传 calls）| 改 `stages.py` 会动到已冻结的阶段层，建议与双 Qwen 一起做；灰度期 token 以网关侧为准 |
| `fact_status_sync` 未接 | 它会改 JSON，属算法变更 | Phase 1.8 |
| 双 Qwen 事实复核 | 未接 | Phase 1.8 |
| `qc_audit_item` 的 stdout 坑 | 未修（同一根因，见 §8.1）| QC 侧 |
| `fetch_item` 去重顺序缺陷 | **已修**（Phase 1.6.1，`dce426e`，见 [phase161-fetch-dedup.md](phase161-fetch-dedup.md)）| 已完成 |

---

## 11. 回归测试

- `tests/test_pipeline_wiring.py`：**21 passed**（新增）
  - 队列：五段落在五个不同队列、新队列不与老三队列撞名、celery 声明与路由齐全、v2 任务名不与旧名冲突
  - 开关：默认关、`1/true/yes/on` 才开、`config.PIPELINE_V2 is False`
  - 分叉：关→`llm_item`、开→`preprocess_item`、skipped 不投下游
  - 接力：preprocess→llm_v2、llm_v2→audit_v2、audit_v2→render_v2、render 无下游（不成环）
  - 纪律：**缺切片不许静默重抽**（断言 `parse_pdf` 调用次数为 0）、audit 不许传 `write=True`、
    缓存命中不许累加 `parse_count`、render 命中缓存要补 `done`、老任务体里不许出现阶段层调用
- `tests/test_pipeline_stages.py`：**70 passed**（Phase 1.2 的 P1-01/02/03/06/07/08/12）
- 全量：**19 failed / 1841 passed / 1 skipped**。19 条全部是既有环境问题，与本次改动无关：

  | 类别 | 条数 | 原因 |
  |---|---|---|
  | `test_cheatsheet.py` | 11 | 环境缺 `python-multipart` |
  | `test_bundle_selfcheck.py` | 5 | 并行线未提交的 `qc/bundle_selfcheck.py` 改动 |
  | `test_qc_analyzer.py` | 2 | 环境缺 `openpyxl` |
  | `test_table_cell_num.py`（ICC）| 1 | 样本漂移（既有）|

  单独跑 `test_pipeline_stages.py + test_pipeline_wiring.py + test_qc_analyzer.py`
  → `2 failed, 94 passed`，失败的就是上面那 2 条 openpyxl。

- 21 条新用例里有 6 条曾只在**全量**运行时失败，根因是 `test_attach_worklist` /
  `test_cheatsheet` / `test_evidence_*` 会 `del sys.modules["app*"]`，导致测试模块顶部缓存的
  `app.pipeline.stages` 变成"旧对象"、patch 打空（症状是 `AttributeError: 'SimpleNamespace'
  object has no attribute 'require_pdf'`，看起来像接线写错）。已改为在用例内
  `importlib.import_module` 取当前对象，并把这个陷阱写进注释。
- 期间另有一次全量出现 3 条热阻用例失败，时序上与并行线提交
  `d5ab14c fix(qc): 修复热阻多列塌缩` 重合；单跑该文件 82 passed，最终全量也回到绿。
  **归属并行线，不计入本轮**（工作区在同一时段被另一条线持续提交，HEAD 从 `634ce1f` 走到 `adf7c85`）。

---

## 12. 回滚

```
ICPDF_PIPELINE_V2=0   # 默认值
```

- 已进 `icpdf_preprocess` / `icpdf_audit` 的消息仍会跑完，但它们的产物与旧链一致（同一份 `parse_pdf`），
  不会留下两种口径的 JSON；
- 不需要回退代码、不需要重建镜像、不需要清队列。

---

## 13. 开 3 件灰度前的建议

1. **先裁决 §9 的去重缺陷**。它不影响 3 件的首跑，但 `acks_late` 重投 + 人工重试会踩到，且症状是"已交付的货显示 queued/failed"，比跑不动更难查。
2. 3 件选**两种形态**：一件标准芯片（如 LM317 这类已有交付物的）、一件板卡（`ADC12D1600RB_NOPB`）、一件空表/异常件（`COP8-PGMA-28SO`）—— 让 `skipped`/`blocked` 路径也过一次真队列。
3. 盯四个数：`pipeline_stage` 里各段 `attempts` 是否全为 1、`item.parse_count` 是否等于真实模型调用次数、`icpdf_preprocess` / `icpdf_audit` 队列深度是否回落到 0、`data/slices` 是否一件一份。
4. 灰度期间**不要**同时跑 `qc` 的批量任务：`qc/table_audit.py` 的 stdout 包装在 Celery 下是已知雷（§8.1），v2 已兜住，老的 `qc_audit_item` 没兜。

---

## 附：证据文件位置

服务器 `/tmp/p16/`（不在仓库内，避免污染）：

- `logs/p16-v2-*.log`、`logs/p16-legacy-*.log` —— 八个 worker 的完整日志
- `g2_a.json` / `g2_b.json` —— G2 前后的完整状态快照（item + 阶段账 + 采集轨迹 + 事件）
- `p16.py` / `p16.sh` —— 探针与编排脚本（可重跑）
- `code/` —— 挂载进容器的 8 个文件（与 `9e2668d`+`bff31f5` 一致）
