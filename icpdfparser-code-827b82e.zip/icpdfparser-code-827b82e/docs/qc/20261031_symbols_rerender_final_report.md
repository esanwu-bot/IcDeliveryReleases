# 存量符号页重渲染：终局报告

> 2026-10-31 · 覆盖 **6531** / 7725 件 · `not_ok` **25** 件逐件定性
> 上划线 2028 件已分四批覆盖；4246 笔上划线全量机器核验 **4246/4246 命中**
> 本报告只记录**可机器复核**的结论；每个数字都附复现命令或判据，不放「估计」。

---

## 1. 摘要

### 覆盖情况

| 指标 | 数值 | 说明 |
|---|---|---|
| 页面总数 | 7725 | 其中 3 件无对应 `data/parsed` JSON（`_preview` / `ADC12DJ5200SE` / `ADS7953`） |
| 参与测量 | 7722 | |
| **已覆盖生产** | **6531** | 4406（上轮）+ 97（文案批）+ **2028**（上划线批） |
| `not_ok` | **25** | 逐件名单见 `20261031_not_ok25_roster.md` |
| `collapse` | 11 | 真·塌缩（另 211 件已归位到 `downgrade`） |
| `downgrade` | 609 | 三视图退化为「球位待核」说明页，含新判据归位的 257 件 |
| `mpn_mismatch` | 545 | 页面主语与 JSON 不一致，改了会换标题 |
| `empty_render` | 1 | |
| `boundary_drift` | 0 | 边界小节与 `render_notes(state)` 逐条一致 |
| `with_findings` | 9 | A1–A5 门禁非空 |

### `symbol_status` 三态字段

`symbol_same=False` 曾同时代表两件完全不同的事：「图真的变了」和「这页本来就没有
原理图符号块」。读报表的人必须再用 `no_anchor` 二次推断，漏看一次就会把 414 件
说明页当成图被破坏，或者反过来把真差异当空真放过去。

新增 `symbol_status`，**`symbol_same` 语义与 `decide` 口径一律不动**：

```json
{"mpn": "1A1G04QDBVRG4Q1", "status": "not_ok",
 "symbol_same": false, "no_anchor": false, "symbol_status": "diff"}
```

```json
{"mpn": "BQ24150AEVM", "status": "ok", "text_lost": 0,
 "symbol_same": false, "no_anchor": true, "symbol_status": "no_anchor"}
```

全量分布（`.sandbox/rr_v8.json`）：

| `symbol_status` | 件数 | 含义 |
|---|---|---|
| `same` | 4361 | 有符号块且逐字节相同 |
| `no_anchor` | 414 | 两侧都没有符号块（比较是空真） |
| `overbar_only` | **2029** | 只多了低有效引脚上划线（剥离后逐字节复原） |
| `diff` | 20 | 有符号块且真有差异，等于 `symbol_drift` |
| `not_measured` | 898 | `downgrade` / `mpn_mismatch` / `empty_render` 在比符号前就早退了 |

覆盖上划线之后（`.sandbox/rr_v11.json`）：`same` 6389 / `no_anchor` 157 /
`overbar_only` 1 / `diff` 20 / `not_measured` 1155 —— 那 2028 件变成了 `same`，
因为生产页与新渲染结果已经一致。

`not_measured` 这一档是修出来的：第一版兜底用 `symbol_status(False, False)` 补，把
898 件**没测过**的件谎报成 `diff`，比不统计更糟 —— 会让人去追 898 起不存在的图形差异。
已用 `test_summary_does_not_count_unmeasured_rows_as_diff` 钉住。

---

## 2. 判据演进与关键修正

### 2.1 空真（vacuous truth）：19 件

第一批 97 件里有 19 件的 `symbol_same` 是 `False` 却判 `ok`，因为 `no_anchor=True`。
放行前补了两条**更硬的旁证**，不靠 `"" == ""`：

1. 全页**所有** `<svg>` 块（不止原理图符号，还有封装图与 3D 占位图）逐字节相同：19/19；
2. 剥掉旧副标题后可见文本**逐条**相同：19/19。

结论：这 19 件是 PDF 无引脚表的说明页，两侧都没有那张图，「图被破坏」这个风险不存在。

### 2.2 几何变化的真相：不是 `aria-label`，是上划线

156 件预期里 59 件没转绿。原本的猜想是「旧型号写在 `aria-label` 里，换个名字而已」。
逐行 diff 之后这个猜想被推翻：

| 件数 | 真实差异 | 证据 |
|---|---|---|
| 49 | 符号块**新增** `<line stroke="#1f6f5c" stroke-width="1.4">` —— 低有效引脚的上划线 | 只增不删；`rect/path/circle/text` 计数 54/54 全同；相似度 0.974–0.9998 |
| 3 | 旧页**整页是别的型号**（`1P2GU04QDRYRQ1` 旧页标题 `SN74LVC2GU04-Q1`、`551013276-001_NOPB` 旧页 `LMP7708`、`551600000-001A_NOPB` 旧页 `LM3402`） | 标题与引脚名整页对不上 |
| 2 | `3656AG/KG` 封装 key 从「共享图 `20LEADISOOMN-20`」回到 `CDIPJND-20`，引脚名 `P–`→`P-` | 仅字符归一，几何相同 |
| 5 | A2 真信号（`5962-85155012A` / `8103611RA` / `8405601CA` / `BQ25898EVM-730` / `CD74HCU04M96G4`） | 门禁 findings 非空 |

`aria-label` 在这 59 件里**没有一件**是唯一差异。倒是在另外 16 件（`no_line_delta`）
上它确实是差异来源 —— 所以「aria-label 会变」这个现象存在，只是不在这批里。

### 2.3 `_visible` 的两个缺陷（上一轮修的，这里存档）

| 缺陷 | 后果 | 修法 |
|---|---|---|
| 剥 `<svg>` 时用**空串**替换 | `>A<svg/>` + `>B<` 粘成 `>AB<`，全库误判 `collapse`（`ok` 从 4406 掉到 0/6824） | 换成占位 `<i></i>`，保留标签边界 |
| 只剥**新页**的边界小节 | 旧页自带边界小节时凭空多出 3 条「被删文本」，`1P1G08MDBVREPG4` 由 `ok` 变 `not_ok` | 两侧都剥 |

---

## 3. 上划线扫描器的加固（本轮核心）

### 3.1 判据：三条同时成立，逐字节

| # | 条件 | 挡住什么 |
|---|---|---|
| 1 | 新旧两侧都有 `schematic symbol` 块 | `no_anchor` 说明页混进来 |
| 2 | 旧块里的 `<line>` 一条都没少 | 「删线 + 加线」的混合改动 |
| 3 | 把新增的 `<line>` 删掉后，新块与旧块**逐字节相同** | 「上划线加了、别处也动了」 |

不用 `difflib` 相似度做判据：0.98 的相似度里可以藏一条坐标变化。相似度只用于**报告**。

### 3.2 踩过的两个坑

**坑一（扫描器）：只删标签、没删换行。** 渲染器每条图元后跟一个 `\n`，只删
`<line/>` 会留下空行，剥离结果永远比旧块多一个 `\n` —— 于是 **2030 件「纯上划线」
全被判成 `overbar_plus_other`**，结论差点变成「几乎没有纯上划线的件」。
修法：按 `line+"\n"` → `"\n"+line` → `line` 的顺序删。

**坑二（抽样核对脚本）：启发式抓错了对象。** 第一版用「正下方 14px 内、水平范围
重叠的文字」找上划线归属，抓到的全是**脚号**（脚号画在引脚线上方，紧贴上划线），
于是一片 `False`，看起来像「上划线全画错了」。

没有去打补丁调阈值，而是换用**结构**：渲染器在 `draw()` 里先输出引脚名 `<text>`、
再输出上划线 `<line>`，所以「上划线在文档顺序上的前一个 `<text>`」就是它的名字。
改用文档顺序后，6 件 10 笔 **10/10** 命中 `active_low_of(doc)` 集合。

### 3.3 测试固化

`tests/test_symbols_overbar_scan.py` 7 项：纯上划线（单笔/多笔）、完全相同、
加了线但不是上划线、少了一条线、上划线 + 其他改动、无符号块。
其中「换行」那条是回归测试，删掉修复就会红。

---

## 4. `--only` 窄口闸门与版本控制

### 4.1 为什么需要

全量 `ok` 是 4503 件，其中 4406 件早就是当前渲染器的产物。为了 97 件新绿的页面
跑一次 `--apply`，会把整库 4503 件重写一遍 —— 爆炸半径从 97 放大到 4503。

### 4.2 三条规矩（都有红先测试）

1. **只收窄**：`target = (ok ∪ allowlist) ∩ only`，交集外一件都不写；
2. **整批拒绝**：清单里有一件不在放行集合（含 `collapse` / `downgrade`），整批不执行、
   退出码非 0 —— 不做「跳过不合格的、照写合格的」，那种静默缩水最危险；
3. **空交集拒写**：清单全是注释或全是陌生 mpn 时，不能「覆盖 0 件」还返回成功。

### 4.3 入库策略与那个坑

`data/symbols/` 整目录在 `.gitignore` 里，7725 件中只有 **445 件**在忽略规则之前入库。
所以覆盖完 `git status` 只看得见 **12 件**，另外 85 件 git 根本看不见 —— 覆盖结果
在版本控制里近乎不可见。

改成 `data/symbols/*` + 逐件 `!` 例外（97 行）：目录整体 **106 MB** 仍不入库，
但这批进版本、可 diff、可回溯。以后每批覆盖同步加一段例外，`.gitignore` 就成了
「哪些页进过版本」的账本。其余 7628 件零触碰。

---

## 5. 规模数据与待办

### 5.1 上划线规模：2029 件

`symbol_drift` 2463 件的分解（`qc/symbols_overbar_scan.py`）：

| 分类 | 件数 | 能不能批量 |
|---|---|---|
| `overbar_only` | **2029** | 可以，但要按批 |
| `no_symbol_block` | 414 | 与本议题无关（空真） |
| `no_line_delta` | 16 | 符号里的型号/引脚名变了，`mpn_renamed` 家族，逐件 |
| `line_removed` | 2 | `551013277-001_NOPB`、`DRV81004-Q1EVM`，不许批量 |
| `line_added_not_overbar` | 1 | `LM317`，不许批量 |
| `overbar_plus_other` | 1 | `AM26C32IDG4`，不许批量 |

这 2029 件的成色：

- 状态**全部 `not_ok`**，无一落在 `collapse` / `downgrade` / `mpn_mismatch`；
- 可见文本**零差异**：`n_removed_extra = n_added_extra = 0`，2029/2029；
- 边界小节全部正确，2029/2029；
- 门禁 findings 只有 1 件（`8405601CA`，A2 家族）；
- 上划线合计 **4246 笔**，中位数 2 笔；≤2 笔占 75%，最多 26 笔，≥10 笔只 22 件。

**若把 `overbar_only` 认作符号通过，`not_ok` 会从 2099 掉到 71。**

### 5.2 建议（未执行，等你拍板）

1. 2029 件 > 1000，按「渲染器代际对齐」单独立项，每批 500 件走同一套 `--only`；
2. ≥3 笔的 498 件先抽 20 件出截图人工确认，≤2 笔的 1531 件靠机器判据直接走；
3. **不要开 allowlist 后门**：把 `overbar_only` 作为显式判据写进 `decide`
   （`symbol_ok = symbol_same or no_anchor or overbar_only`），可测可回归；
   塞进 allowlist 就成了一条没人复核的旁路。

### 5.3 其余待办

| 事项 | 规模 | 性质 |
|---|---|---|
| A2：封装 key 两条派生路径 | ✅ **已修**（见 §8）：`pkg_key` + `pkg_type_of` 单一入口，findings 5 → 0，`ok` 6531 零变化 |
| 剩余 25 件 | ✅ **已解剖**（见 `docs/qc/20261031_notok25_anatomy.md`）：分五族，无一件是上划线 |
| `collapse` 11 / `downgrade` 609 的球位映射根因 | 620 件 | 数据层缺失（未授权，未开工） |
| `mpn_mismatch` 545 | 545 件 | 同上 |

---

## 6. 验证清单

| 项 | 结果 |
|---|---|
| `pytest tests/test_symbols_rerender_gate.py` | **51 passed**（三态 4 项参数化、`--only` 3 项、白名单 3 项、`overbar_only` 6 项、降级 3 项、A2 7 项等） |
| `pytest tests/test_symbols_overbar_scan.py` | **7 passed** |
| `pytest tests/test_engineering_model.py` | **44 passed** |
| 五件护栏 `symbols_render_diff.py --base b623249` | **5/5** |
| 全量 `pytest` | **1068 passed / 14 failed / 1 skipped**；14 项与基线同集合（`test_cheatsheet` 11 / `test_qc_analyzer` 2 / `test_table_cell_num` 1），逐行 diff 失败集合完全一致，根因是本机依赖版本（fastapi 0.162 / starlette 1.10、pandas 3.1、pymupdf 1.24.14） |
| 收集阶段的 `import file mismatch` | 来自 `data/code_backup_scope/test_identity_scope.py` 与 `tests/` 同名，加 `--ignore=data/code_backup_scope` 后正常；该目录非本轮产物，未删 |

### 复现

```bash
python qc/symbols_rerender.py --json .sandbox/rr_v14.json --out .sandbox/rr_v14   # 全量测量（只写沙箱）
python qc/symbols_overbar_scan.py --json .sandbox/rr_v6.json                     # 上划线规模
python qc/symbols_render_diff.py --base b623249                                  # 五件护栏
python -m pytest tests/test_symbols_rerender_gate.py tests/test_symbols_overbar_scan.py -q
```

回滚：`.sandbox/symbols_backup_batch1.zip`（覆盖前全量 7725 件）。

---

## 7. 补记：2028 件上划线已覆盖（本节在首批报告之后追加）

### 7.1 判据写进 `decide`，不是写进 allowlist

```python
RELEASABLE_SYMBOL = ("same", "no_anchor", "overbar_only")

def symbol_ok_of(status: str) -> bool:
    return status in RELEASABLE_SYMBOL
```

`_one` 里符号块不同时再调一次 `classify_pair`（复用扫描器的判据，不在两处各写一份），
得到 `symbol_status`，再由 `symbol_ok_of` 转成放行与否。红先测试 6 条钉住：
`overbar_only` 放行、可放行/不可放行集合、以及**只解符号这一条闸** ——
塌缩、边界、门禁、文本越界仍然各自拦（`test_overbar_only_releases_symbol_but_not_other_gates`）。

反悔成本：改 `RELEASABLE_SYMBOL` 一行 + 删对应测试，不用清理一份两千行的清单。

### 7.2 全量机器核验：4246 / 4246

原本计划的「抽 20 件看截图」升级成全量机器核验（`--verify-active-low`）：
按**文档顺序**取每条上划线的前一个 `<text>`，比对 `symbol_svg.active_low_of(doc)`。

```
bars_hit: 4246   bars_missed: 0   pages_with_miss: 0
```

2029 件、4246 笔，逐笔命中，0 笔未命中。比肉眼看几十张截图覆盖面大两个数量级，
而且结论是确定性的：这批图形变化是依据 PDF 的 "Active Low" 描述精准补上的，不是瞎画。

### 7.3 四批覆盖与正交性

| 批 | 件数 | 筛选 | 备份 |
|---|---|---|---|
| 2a | 497 | ≥3 笔（含 26 笔那种） | `.sandbox/symbols_backup_2a.zip` |
| 2b | 500 | ≤2 笔 · 第 1 段 | `.sandbox/symbols_backup_2b.zip` |
| 2c | 500 | ≤2 笔 · 第 2 段 | `.sandbox/symbols_backup_2c.zip` |
| 2d | 531 | ≤2 笔 · 第 3 段 | `.sandbox/symbols_backup_2d.zip` |

- 四批合计 2028 件（2029 件里 `8405601CA` 有 A2 findings，仍拦）；
- **正交性**：覆盖前 `ok` 4503 件是覆盖后 `ok` 6531 件的**子集**，一件没丢；
  新增的 2028 件全部是 `overbar_only`，零文本越界、零塌缩、零降级；
- `ok` 4503 → **6531**，`not_ok` 2099 → 71（降级判据修正后 → **25**）。

### 7.4 顺手补上的闸门漏洞：46 件「伪文本越界」

拆 71 件时发现 46 件的「文本越界」其实是**整页降级**：旧页是 PDF 无引脚表的三视图，
新页因 `data/parsed` 缺球位映射被渲染成「BGA 球位待核」说明页。

原判据 `downgrade = old_sym and not new_sym` 在**旧页没有符号块时根本不触发**，
于是这 46 件被记成 `not_ok` —— 而 `not_ok` 是**可以**被 allowlist 放行的类。
一次人工特批就会让 46 页静默变空。

`is_downgrade` 现在认两条路：旧页有符号块而新页没有；或新页是说明页而旧页不是。
连带把原先记成 `collapse` 的同类 211 件（87 KB → 1.3 KB）也归位到 `downgrade`：
两者都在 `HARD_BLOCK`，安全等级没变，但性质写得更准。

### 7.5 版本控制策略（第二批起改口径）

`data/symbols/` 保持整目录 ignore，**不再逐行加 `!` 例外** —— 2029 行会让
`.gitignore` 变成灾难，且几万件 HTML 进 git objects 会把仓库撑爆。
可追溯性改由两份产物保证，二者都入库：

- `docs/qc/manifests_symbols/batch*.json`：逐件 `mpn` / `before_bytes` / `after_bytes` /
  `via` / `status_before` / `symbol_status`，共 2125 件（97 + 497 + 500 + 500 + 531）；
- `.sandbox/symbols_backup_batch*.zip`：每批覆盖前的全量 7725 件快照（本地回滚用，
  zip 被 `*.zip` 规则忽略，不进仓库）。

第一批那 97 行例外保留：已入库、无成本，且让「覆盖过什么」在 `git log` 里可见。


---

## 8. 补记：A2 封装 key 收敛（本节在四批覆盖之后追加）

### 8.1 根因：同一页的封装 key 有两条派生路径

| 调用方 | 改动前 | 改动后 |
|---|---|---|
| 渲染器 `render_page` | `canon_pkg(package_of(doc, len(pins)), declared or len(pins))` | `pkg_key(pkg_type_of(doc), declared)` |
| 渲染器 `preview_page` | `canon_pkg(package_of(doc, len(pins)), declared or len(pins))` | 同上 |
| 状态层 `EM._canon` | `canon_pkg(raw_pkg, pins)` | `pkg_key(raw_pkg, pins)` |
| 状态层 `EM.derive_state` | `str(pkg.get("type") or "")` | `pkg_type_of(doc)` |

两条路径差异各埋一个雷：

1. `declared=0`（规格书没声明脚数）时，渲染器拿**引脚表长度**补脚数、状态层不补
   —— 同一页算出 `DIP-20` 与 `DIP-UNK` 两个 key。
2. `specs.package.type` 缺失时，`package_of` 会去 SEO 标题里**正则捞**一个族名
   （甚至编出 `{n}-Pin`），状态层只看声明值 —— 一侧猜、一侧不猜。

后果：页面引用 `DIP-20.3d.svg`，状态却说本件 key 是 `DIP-UNK`，门禁 A2 报
「引用了不是本件封装 key 的 3D 图」。全库实测两侧不一致 **9 件**（0 件是已覆盖页）。

### 8.2 改法：两个入口，三处收敛

- **`pkg_key(raw, declared_pins)`** —— key 的唯一派生点。**不拿引脚表长度兜底**：
  引脚表可能只解析到一半（实测 14 行 vs 声明 20 脚），拿它反推等于替厂商猜。
- **`pkg_type_of(doc)`** —— 只取 `specs.package.type` 的声明值，**不做 SEO 正则兜底**，
  也**不在这里拆 `"A or B"`**：拆了会把二选一的声明当成确定结论（实测 `EKI-LM3S9B92`
  据此认定「有签核共享模板 LQFP-100」，文案退回旧副标题，该件由 `ok` 掉回 `not_ok`）。
  多封装写法的拆分交给 `canon_pkg` 内部，两侧 key 仍然一致。

兜底去掉的影响面已量化：**SEO/引脚表兜底仅 4 件**（7718 件 `type` 有值），
**0 件是已覆盖页**。

### 8.3 副作用与收口

统一 key 后，4 件 type 缺失的页 key 落 `PKG-UNK`，这个**内部记号被印进了 `<h1>`**
（`5962-85155012A · PKG-UNK · 20 脚`）。改为印「封装未声明」，正式页与预览页同处理，
并加测试 `test_missing_package_type_is_not_printed_as_an_internal_key` 钉死。

顺带发现 `preview_page` 仍留在 `package_of`：同一件在预览里是 `DIP-UNK`、正式页是
`PKG-UNK`。预览页不过门禁，但 QA 拿它横向比对 —— 两边 key 不同则比对结论是假的。
一并收敛，并加 `test_preview_page_derives_the_same_key_as_render_page`。

### 8.4 验证：状态零变化，findings 归零

全量测量 7722 行，`v11 → v14` 逐件比对：

| 指标 | v11 | v14 | Δ |
|---|---|---|---|
| `ok` | 6531 | 6531 | **0** |
| `not_ok` | 25 | 25 | 0 |
| `downgrade` / `mpn_mismatch` / `collapse` / `empty_render` | 609 / 545 / 11 / 1 | 同 | 0 |
| 逐件状态变化 | — | — | **0 件** |
| `ok` 集合双向差集 | — | — | **0 / 0** |
| `with_findings` | 5 | **0** | −5 |
| `symbol_status` 五档 | 6389/157/1/20/1155 | 同 | 0 |

即：**2028 件带 `overbar_only` 的已覆盖页一件没掉出来**，A2 五件 findings 全部消失。

### 8.5 剩余 25 件的解剖

见 `docs/qc/20261031_notok25_anatomy.md`。关键结论：**25 件里没有一件是上划线差异**。
按「符号块差在哪」分五族：纯改名 5 / 改名+换封装 2 / 破折号归一 5 / 真变化 8 /
A2 五件（符号 `identical`，卡在边界）5。

其中 A2 五件去掉兜底后，封装从**引用共享模板**改为**内联现画**（页字节约翻倍、
「取自共享封装图库」整句消失），是**实质内容变化**，不属于可批量放行的妆容级差异。


---

## 9. 补记：`label_only` / `dash_only` 两种妆容级判据（8 件放行并覆盖）

### 9.1 为什么不是 allowlist

§8.5 解剖出剩余 25 件里**没有一件**是上划线差异，真正的形态是另外两种：

| 判据 | 形态 | 件 |
|---|---|---|
| `label_only` | 符号块**只**是 `aria-label` 里的型号名不同，剥掉标签后逐字节相同 | 7 |
| `dash_only` | 符号块**只**是破折号写法不同（`V–` → `V-`） | 5 |

跟 `overbar_only` 一样写进 `decide` 而不是 allowlist —— 是规则不是特批。

### 9.2 判据（都要求归一化后**逐字节相同**，不是相似度）

`label_only_of(old, new, mpn)` 三条全成立：

1. 两侧都有符号块（缺一侧是 `no_anchor` / `downgrade` 的活）；
2. 剥掉 `aria-label` 后**逐字节相同** —— 几何、引脚名、线数全一致；
3. 新 aria-label 里的型号名 == 本件 mpn。

第 3 条防的是「旧页 A、新页 B、都不是文件名 C」的脏数据被当成改名放行。
不在这里折叠破折号 —— 否则「换了标签 + 换了破折号」的件会混进来。

`dash_only_of(old, new)`：`–`(U+2013) / `—`(U+2014) / `−`(U+2212) 归一成 `-` 后逐字节相同。

### 9.3 一个必须一起改的地方：文本侧折叠

只让 `symbol_ok=True` **不够**：这 5 件的 `<h1>` 与副标题里也写着型号名，
`removed_extra` / `added_extra` 非空，`decide` 照样判 `not_ok` —— 判据写了等于没写。

所以 `label_only` 成立时把旧侧文本里的旧型号名换成新 mpn 再比差集；`dash_only`
成立时两侧文本都折叠破折号。型号名/破折号之外的任何差异不会被抹掉，仍然照拦。

### 9.4 正交性：符号放行 ≠ 放行

判据落地后有 7 件 `label_only`、5 件 `dash_only`，但**只放行 8 件** ——
`1P1G3157QDCKRQ1` / `1P2GU04QDRYRQ1` / `3656AG` / `3656KG` 的**边界**也变了
（副标题封装 key 从 SOT-6→SC70-6、20LEADISOOMN-20→CDIPJND-20 等），
`boundary_ok=False` 在符号之外又拦了一次。测试 `test_dash_only_does_not_cover_the_two_package_key_cases` 钉这条。

### 9.5 验证

| 项 | 结果 |
|---|---|
| v14 → v15 变化件 | **恰好 8 件**，全部 `not_ok → ok`，无一反向 |
| `ok` | 6531 → **6539** |
| `not_ok` | 25 → **17** |
| `ok` 集合掉出 | **0** |
| findings 新增 | 0 |
| 覆盖后重测 v16 | `ok` 6539 稳定；8 件已从妆容级转为 `same`（6389 → 6397） |
| 五件护栏 `--base b623249` | 5/5 |
| 单测 | gate 65 + scan 7 + EM 44 = 116 全绿（新增 13 项） |

覆盖 8 件，备份 `.sandbox/symbols_backup_batch3.zip`，
manifest `docs/qc/manifests_symbols/batch3_cosmetic_8.json`。

### 9.6 剩余 17 件：人工裁决

族 B 2 / 族 C 封装 key 2 / 族 D 真变化 8 / 族 E A2 五件 5。
裁决页 `.sandbox/review_notok17.html`：逐件并排预览旧页与新页、diff 摘要、
分类说明，默认全 Reject，选完导出 `manual_review_17.json` 交回即可按裁决覆盖。
