# `icpdf_quarantine` 回放验收：用工具重判 batch100 已交付的 93 件

> **本文件的结论已被 `DIFF.md` 取代（2026-11-04 晚）。**
> 下文记的是**旧宽松规则**（`is_board ∧ electrical==0` 即准入）的回放结果：83 + 10 + 0。
> 按顶级准入裁定改成三分类后，同一批数据回放为 **83 + 9 + 1**（`AFE7900EVM` 因结构缺陷出局）。
> 保留本文件只为留痕「旧规则当时是怎么得出 10 件的」，**不要按本文的数字做交付**。
> 现行结论与逐件差异见同目录 `DIFF.md`，台账见 `quarantine_ledger.json`（已被新版覆盖写入）。

目的：证明工具不是"又写了一遍判据"，而是**与生产同一道闸**。
做法：拿 batch100 已交付的装配目录（`stage/`，93 件，已剔除 3 件隔离件）原样喂给工具，看它能不能得出同一组结论。

## 命令

```bash
# 生产镜像里的代码停在 a259da3（闸门未部署），所以回放时把当前核心模块挂到前面：
#   /tmp/newpd    当前 parse_datasheets.py
#   /tmp/newroot  当前 qc/（含 deterministic_extract 的 source_has_container 等）
PYTHONPATH=/tmp/newpd:/tmp/newroot:/app \
  python tools/icpdf_quarantine.py \
    --src /app/data/batch100_20261104/stage \
    --out /tmp/replay/out --json
```

## 结果（2026-11-04 17:34 +08:00）

| 项 | 工具有结论 | 交付包（RUN v4） | 一致 |
|---|---|---|---|
| 入包件数 | 93 | 93 | 是 |
| ok | 83 | 83 | 是 |
| 板卡准入 | 10 | 10 | 是 |
| 隔离 | 0 | 0（3 件此前已移出） | 是 |
| 薄件 | 0 | 0 | 是 |

allowlist 名单逐件一致（AFE7900EVM / AFE7950EVM / BOOSTXL-DRV8320H / BQ24450EVM-691 /
EKB-UCOS3-EVM / LM3352-3.0EVAL / LM5064EVK/NOPB / LM5066EVK/NOPB / TPS2391EVM / TPS65131EVM-063）。

台账见 `quarantine_ledger.json`（93 条 items，含每件的 identity、主桶/正式桶电气行、
引脚数、验收章与现场复判的对照、core_basis）。

## 回放暴露的三件事（都已写进工具）

1. **件名必须取请求号**。93 件的 `mpn_source` 全是 `metadata.requested_mpn`；
   `AFE7950EVM` 的 `basic_info.mpn` 是 `AFE7950`，台账里记 `name_conflict=true`。
   若按文档自称为准，这一件会在清单上换个名字，对账时得靠人猜。
2. **核心校验要带源文档证据**。93 件全部命中 `assembly(源文档证据)` 分支。
   退回严格口径（不读 PDF）时，`ADS1252U`（源文档确实没有 thermal/ESD 表）会被
   误报成 `parsed_core_fail`。
3. **板卡准入与状态机是两层**。这批 10 件里有多件状态仍是 `failed`
   （结构上电气 0 条），按裁决准入；工具把它们标成 `allowlist` 并在
   `override_reason` 里写明"状态仍记 failed，结构缺陷未消除"，不伪装成 ok。

## 未覆盖

- 回放用的是"当前核心模块 + 旧镜像数据"，生产镜像本身仍停在 `a259da3`，
  闸门是复核态（与 RUN v4 的口径一致）。
- 没有回放那 3 件隔离件（AFE/BOARD 均已移出 `stage/`）；它们的判据由
  `tests/test_tools_quarantine.py` 的合成用例覆盖。
