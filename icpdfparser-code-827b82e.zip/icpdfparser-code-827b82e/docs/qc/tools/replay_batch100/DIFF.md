# batch100 回放差异台账（准入规则 v2）

**一句话结论**：新规则（板卡零电气可豁免、核心结构错误不可豁免）回放 93 件，得
**83 normal + 9 allowlist_board + 1 quarantine**。相对 RUN v4 的「83 + 10」，只差一件：
`AFE7900EVM` 由 allowlist 改判隔离 —— 它缺 `pin_configuration`、缺 `ordering_info`、
`manufacturer` 为空、主桶电气 0、引脚 0、正式桶 0，**是结构缺陷被「是板卡」洗白**，
不是诚实空。**没有为凑齐 10 件 allowlist 放水。**

## 1. 回放口径

| 项 | 值 |
|---|---|
| 工具 | `icpdf_quarantine 1.1.1`（rule v2：admission 三分类） |
| 代码 | 本地工作树 `parse_datasheets.py` md5 `2b1b2b80…`、`qc/deterministic_extract.py` md5 `29b3d395…`、`qc/scope_contract.py` md5 `ea9eace8…`（与容器内副本逐字节一致） |
| 装配根 | 生产容器 `icpdf-server:/app/data/batch100_20261104/stage`（parsed 93 / pdfs 93） |
| 证据 | **带 PDF**：核心校验按装配口径（`source_has_container` 探测源文档），非严格口径 |
| 薄件开关 | `ICPDF_ACCEPT_THIN=1`（与生产一致） |
| 命令 | `PYTHONPATH=/tmp/newpd:/tmp/newroot:/app python /tmp/newpd/icpdf_quarantine.py --src /app/data/batch100_20261104/stage --out /tmp/replay2 --json` |
| 产物 | `quarantine_ledger.json`（93 件逐件字段）、`quarantine.csv`（20 列，含裁定点名的 13 个字段） |

## 2. 总账对照

| | RUN v4（旧规则） | 本次回放（v2） | 差异 |
|---|---|---|---|
| normal | 83 | **83** | — |
| allowlist_board | 10 | **9** | −1 |
| quarantine | 0 | **1** | +1 |
| 合计 | 93 | 93 | — |

旧规则表达式 `identity in BOARD_TYPES ∧ electrical == 0`；新规则是「三分类 + 例外必须
经闸门复核」，即 `allowlist` 只豁免「板卡主桶电气为 0」这一项，其余结构/核心错误一律隔离。

## 3. 唯一改判件：`AFE7900EVM`

| 字段 | 值 |
|---|---|
| identity / identity_state | `evaluation_board` / `IDENTITY_REVIEW` |
| 主桶电气 / 正式桶电气 / 引脚 | **0 / 0 / 0** |
| 扣押行 withheld | 0 |
| `validate_errors` | `missing key: pin_configuration`；`missing key: ordering_info`；`basic_info.manufacturer empty`；`specs.electrical only 0 items (<3)` |
| `core_errs` | 空（板卡在 `check_core` 里只过溯源链与 AC 闸门，不受 thermal/ESD 约束） |
| `final_gate_status` | **failed** |
| v4 准入 | `allowlist_board`（旧规则：是板卡 ∧ 电气 0 → 放） |
| v5 准入 | **`quarantine`** |

**为什么这不叫「工具变严了」，叫「工具把洞堵上了」**：
`AFE7900EVM` 三处结构事实都不成立 —— 连 `pin_configuration` 与 `ordering_info` 两个
必需键都不在文档里，厂商字段为空。旧规则里「板卡」这个身份一票通过，等于让身份
替结构缺陷背书。裁定原文「板卡的『零电气』可以豁免，但『核心结构错误』绝对不能豁免」
堵的就是这一件。回放前它被算进 10 件 allowlist；回放后它出局。

## 4. 需要人工确认的两件（结论不改，风险已标注）

这两件都是**板卡 + 主桶电气 0 + 带扣押行**。核心 `final_gate` 的可放行类里
「电气条数不足」与 `withheld_in_quarantine` 同属一档，所以它们仍走 allowlist。
**工具不改判**（改判就是在工具里另写一份判据，正是裁定禁止的），但把它们标出来了：

| mpn | 主桶电 | 正式桶 | 扣押行 | 引脚 | 闸门 | 准入 | 说明 |
|---|---|---|---|---|---|---|---|
| `BOOSTXL-DRV8320H` | 0 | 0 | **241** | 42 | failed | allowlist_board | 有 42 个引脚说明板卡结构是抽到了的；241 行电气被列塌缩闸门扣下 |
| `EKB-UCOS3-EVM` | 0 | 0 | **31** | 0 | failed | allowlist_board | 同上，量级小 |

**「主桶真空」和「抽到了被扣下」是两件事**：前者是板卡诚实空（电气表本来不存在），
后者是解析抽到了合格不了的脏行。两者在交付质检里该不该同等对待，需要人工拍板；
台账、`allowlist.csv`、命令行输出三处都会显式写明 `withheld_in_quarantine=N`。
批量文本输出里会打一行：

```
[须人工确认] 2 件板卡准入带扣押行（withheld_in_quarantine）：BOOSTXL-DRV8320H(241行)、EKB-UCOS3-EVM(31行)
```

## 5. 闸门拦不住、只能靠裁决的一件：`ADS1252EVM`

| 字段 | 值 |
|---|---|
| 台账里的名字 | **`ADS1252U`**（`metadata.requested_mpn`），交付清单里叫 `ADS1252EVM` |
| identity / identity_source | 空 / **`missing`** |
| 主桶电气 / 引脚 | 55 / 8 |
| `validate_errors` / `core_errs` | 空 / 空 |
| `final_gate_status` | **ok** |
| 准入 | `normal` |

它**不是被闸门拦下的，是总裁第三次裁决剔除的**。原因必须说清，否则复核方会以为
工具漏判：

- 核心设计是「身份真值未知时按芯片对待，不拿没有证据的猜测去拒件」
  （`parse_datasheets._identity_is_board` 注释原文），所以空身份不会触发任何拦截；
- 它的结构（55 行电气、8 个引脚）与核心校验都过，闸门只能判 `ok`；
- 要拦它，得把「`identity` 为空」写成身份守卫的**拒绝条件** —— 那是核心改动，
  属下一批（已记 `open_items`）。

同时暴露一个**命名分歧**（OPEN-2）：交付清单按批次表请求号叫 `ADS1252EVM`，
而它 JSON 里的 `metadata.requested_mpn` 写的是 `ADS1252U`。工具「请求号优先」没错，
错的是这两个"请求号"本身不一致。按 mpn 对账会得到「台账缺 1 件」的假故障 ——
本次重定稿改用**文件茎**（`manifest.safe_name` ↔ 台账 `safe`）对齐，并在生成脚本里
写明了原因。

## 6. 回放暴露的三条核心侧待统一项（不在本批修，登记待裁）

| 编号 | 现象 | 影响 | 建议 |
|---|---|---|---|
| **OPEN-1** | 两套板卡值域不一致：`qc.scope_contract.BOARD_TYPES = (evaluation_board, development_kit)`，而 `qc.deterministic_extract.check_core` 内部写的是 `(evaluation_board, reference_design, module, board)` | `development_kit` 在核心校验里不被当板卡 → 被判「引脚/电气为空」核心错 → 必然隔离 | 让 `check_core` 直接 import `BOARD_TYPES`，消灭第三套板卡判据。**本批 0 命中**，但逻辑上是个雷 |
| **OPEN-2** | `ADS1252EVM`（交付清单）vs `ADS1252U`（JSON `requested_mpn`） | 按 mpn 对账假故障；两份表同一件两个名字 | 请求号回填时以批次表为准，或在 manifest 增 `requested_mpn` 原始列 |
| **OPEN-3** | `withheld_in_quarantine` 与「电气不足」在 `final_gate` 同属薄件类 | 板卡带扣押行仍可 allowlist（见 §4） | 需业务拍板：扣押行是否应升为隔离理由 |

这三条都是**核心口径/契约层**的问题。工具侧的处理原则是：**如实反映 + 显式标注**，
不在工具里私自放宽或加严。

## 7. 结论

1. 三分类准入在 93 件真实数据上跑通，与 v4 的唯一差异是 `AFE7900EVM`，且方向正确。
2. 板卡「零电气」豁免仍在（9 件 allowlist，其中 7 件闸门直接 `ok`、2 件经闸门复核 `failed→allowlist`）。
3. 板卡「结构错误」不再被豁免（`AFE7900EVM` 出局）。
4. 重定稿结果：**91 件 = 82 normal + 9 allowlist_board**（另 2 件出局：`AFE7900EVM` 规则隔离、
   `ADS1252EVM` 裁决剔除）。见 `docs/qc/batch100/final-v5/`。
