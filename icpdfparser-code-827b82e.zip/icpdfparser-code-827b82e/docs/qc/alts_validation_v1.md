# Alts Validation v1.2 · 替代料数据一致性与功能校验（判据草案）

> **v1.2（2026-10-29 二次评审后修订）**：定稿三个实现期问题——74 表治理（责任人/签核门禁/审计字段）、
> `related_orderables` 五分类（含 `PIN_COUNT_MISMATCH`）、候选等价性五层证据卡；
> 另加「`verified` 是派生结果」（§4.3）与「MIN/TYP/MAX 保留原始语义」（§6.2）；
> §8 改为带通过条件的 8 阶段门禁，夹具 10→12 条。**仍然不改引擎、不重生成交付物、不写生产数据**。
>
> **v1.1（2026-10-29 评审后修订）**：补 §2.1 事实源第 1.5 层（74 系列标准功能表）、
> §2.2 `dropped[]` 五分类判定规则、§3 `ordering_info` 同封装边界与 `related_orderables`、
> §4 数据流一致性只判「候选集合」且禁止混段、§6 两条配套门禁的证据结构、§12 决策记录。
> 修订依据见 §12。
>
> 状态：仅判据确认，不含代码改动。
> 事实源：**官方 PDF 的订购信息（Package Addendum / Ordering Information）与功能定义**
> ＋ **74 系列标准功能表（第 1.5 层，见 §2.2）**。
> 主 HTML / 主页面表格**不是**权威：它本身也可能丢列（本例 tpd/Ioff 丢 MAX），
> 因此不得因「某张表看起来对」就把整页提升为事实源。

---

## 一、这两件样本暴露的是三层缺口，不能用一个 WARN/FAIL 兜住

| 层 | 缺口 | 样本 | 现在谁在管 |
|---|---|---|---|
| 功能安全 | 替代料核心功能不同，仍被标 `functional-equivalent` / `verified=true` | `74LVC1G132DCKTG4`（6 条 `74LVC1G11`） | **无人管**（`alts_json_has_miss` 只滤 miss） |
| 数据一致性 | 同一器件的合法订购变体被当 `miss` 丢弃；`json`/`alts.json`/HTML/主页面四份不同源 | `5962-9053801PA` | **无人管** |
| 参数完整性 | 源表 MIN/MAX 列被压缩成单值（tpd/Ioff） | `74LVC1G132DCKTG4` | 只有「字段是否为空」判据 |
| 交付状态真实性 | `WARN` 被当成「已修复可交付」 | 两件 | 旧 `REVIEWED_FIXED` 定义 |

结论：**四条独立门禁**，任何一条不过都不得进入可交付集合。

---

## 二、事实源与数据流（决策 1）

### 2.1 权威顺序

1. 原厂 PDF 的 **Ordering Information / Package Addendum**（订购码、封装、温度、状态、Qty）；
2. 原厂 PDF 的**功能定义**（如 "single 2-input positive NAND gate with Schmitt-trigger inputs"）；
3. 原厂 PDF 的**表格结构与列角色**（MIN/TYP/MAX、条件列、单位列）；
**（第 1.5 层）74 系列标准功能表**：用于「目标与候选都只有料号、都没有候选 PDF」时的功能核验，
见 §2.2；它只解决 74 系列逻辑门的**功能码语义**，不解决电气/引脚/寿命；
4. 站内目录：只能给出**候选线索**，不能作为「等价」证据；
5. 主 HTML / 主页面：**产物**，永远不是事实源。

### 2.2 74 系列标准功能表（第 1.5 层）的定位与审计

**为什么需要这一层**：`74LVC1G132` 与 `74LVC1G11` 的判定，既不应用「132 vs 11」字符差
（违反 §10.5），也不能等候选 PDF（§10.4 说候选 PDF 通常不在包内）。缺了这一层，
`alts_function_mismatch` 就无法在无候选 PDF 时给出 P0——这是 v1 的逻辑缺口。

**存放**：`qc/74_function_codes.json`（入库、带版本），结构示例：

```json
{
  "version": "74fn-2026-10-29",
  "content_hash": "sha256:…",
  "updated_at": "2026-10-29",
  "sources": ["JEDEC 74 系列功能编号惯例", "TI / Nexperia 单门器件命名"],
  "owner": "器件数据负责人（具名）",
  "reviewed_by": ["复核签核人（具名）"],
  "reviewed_at": "2026-10-29",
  "change_reason": "首版：覆盖 1G0x/1G1xx 单门与本次涉及功能码",
  "codes": {
    "11":  {"function": "AND",  "inputs": 3, "schmitt": false},
    "132": {"function": "NAND", "inputs": 2, "schmitt": true},
    "04":  {"function": "NOT",  "inputs": 1, "schmitt": false},
    "08":  {"function": "AND",  "inputs": 2, "schmitt": false}
  }
}
```

**可判 P0 的三个必要条件（缺一即降级）**：
1. 目标与候选**都命中**表内功能码（`1G` 单门与多门各自成立）；
2. 冲突落在**核心属性**：`function` 类别 / `inputs` 数量 / `schmitt` 关键特性；
3. finding 带 `table_version` + `content_hash`，且表已 `reviewed_by` 复核签核。

**治理（v1.2 定稿）**：
- **责任人**：一名具名的器件数据负责人维护；**另一名具备器件知识的审核人**复核签核；
- **节奏**：按需更新——新增器件系列、发现误判、规则变更时触发；不设定期刷新（关键在可追溯，
  不在于刷频率）；
- **发布门禁**：**没有审核人签核的版本不得用于 P0 判定**（自动阻断权限不随编辑扩大）；
- **审计字段**：`version / sources / owner / reviewed_by / reviewed_at / change_reason / content_hash`；
- 新增功能码时同步补一条回归样例。

**必须降级为 `NO_EVIDENCE` 的情形（v1.2 明列）**：
1. 表未签核（`reviewed_by` 为空或 `reviewed_at` 缺失）；
2. 候选型号不在表内；
3. 型号字符映射存在**歧义**（如 `1G132` 与多门 `132` 的族归并无法唯一确定）；
4. 只有前缀/字符位置不同、无法映射到明确功能字段。
上述四种一律不得判 `INCOMPATIBLE`；PDF 中的明确功能证据**优先于表**。

**冲突与例外**：候选自带官方 PDF 且与表冲突 → **PDF 优先**，记 `CONFLICT`，输出 P1 待人工。
**边界**：该表只覆盖逻辑门（74 系列）；ADC/DAC/运放/二极管/电源等**另建类别表**，
不得把逻辑门的判据套到模拟器件上。

### 2.3 单一规范化数据集（canonical）

`json.alternatives`、`.alts.json`、`.alts.html`、主页面 `#equivalent` **必须由同一份规范化数据集渲染**，
禁止各自筛选、各自生成、各自改写。规范化数据集至少包含：

```
alts_canonical.json
  mpn, manufacturer, doc_rev, pdf_sha256, generated_at, rule_version
  ordering_info[]        # 本器件 + 同封装的官方订购码（见 §3）
  related_orderables[]   # 本器件但不同封装的订购码（展示但不可互换）
  candidates[]           # 待验证候选
  verified[]             # 已核验替代料（证据门槛见 §4）
  dropped[]              # 审计记录：为什么排除，不是垃圾桶
```

`dropped[]` 每条必须有：
`mpn / 分类 / 原因 / 证据（pdf 页/表格/引用）/ rule_version / decided_at`

**五分类判定规则（v1.1 新增，依赖 §2.2 的 74 表落地）：**

| 分类 | 判定条件（满足即归此类，按顺序优先） |
|---|---|
| `SELF_VARIANT` | 出现在**本 PDF 订购表**，且**同器件、同封装族**，仅温度/包装/筛选等级不同 |
| `RELATED_ORDERABLE` | 出现在**本 PDF 订购表**，同器件但**封装族不同**（如 CDIP→LCCC） |
| `INCOMPATIBLE` | 有权威证据证明冲突：候选官方 PDF 明文，或 §2.2 74 表命中且核心属性（function/inputs/schmitt）冲突 |
| `OTHER_DEVICE` | 不在本 PDF 订购表；同厂商不同料号或不同功能类别（如二极管），且未证实冲突 |
| `NO_EVIDENCE` | 以上都不成立，或证据不足（无候选 PDF、表内无该码） |

**优先级说明**：`SELF_VARIANT` / `RELATED_ORDERABLE` 只看**本 PDF 订购表**，不看候选池；
`INCOMPATIBLE` 必须带证据；「不知道」一律 `NO_EVIDENCE`，不得借用 `INCOMPATIBLE` 表达。

---

## 三、四个数据集必须分开（决策 2 · v1.1 定为「同封装」口径）

| 集合 | 含义 | 允许出现在页面吗 |
|---|---|---|
| `ordering_info` | **本器件 + 同封装族**的官方订购码（温度/包装/筛选等级可不同） | 是，作为「订购信息」段 |
| `related_orderables` | **本器件但不同封装族**的官方订购码（如 CDIP→LCCC） | 是，且必须单独成段并标注「不同封装、不可互换」 |
| `alternative_candidates` | 尚待验证的候选 | 只能标「待审」，**不得**标已验证/等价 |
| `verified_alternatives` | 满足证据门槛、可替换的候选 | 是，且必须带核验记录 |

### 3.1 封装边界与 related 分类（v1.1 拍板同封装；v1.2 补五分类）

`ordering_info` **只收同封装族**。理由：客户选料时封装是首要决定因素，
把 LCCC 与 CDIP 混进同一张「订购信息」会让客户误以为可互换。

- 本例 `5962-9053801PA`（CDIP JG 8）的 `ordering_info` 应为
  `5962-9053801PA / 5962-9053801VPA / UC1611J / UC1611J883B` —— **现有 4 条即完整**；
- `5962-90538012A` / `5962-9053801V2A` / `UC1611L883B` 是 **LCCC FK 20 脚**，
  进 `related_orderables`，页面单独成段，绝不与 CDIP 并列成「可订购替代」。
- 页面口径（v1.1 拍板 #4 = B）：`#equivalent` 拆两段
  —— **Orderable（ordering_info + related_orderables）** 与 **Candidates（candidates / verified）**。
  隔离时只清空 **Candidates** 段；Orderable 段是该器件的事实，保留。

**`related_orderables` 的封装/引脚分类（v1.2 定稿，按表中顺序取第一个匹配）**：

| 分类 | 判定条件（必须有证据） |
|---|---|
| `SAME_PACKAGE_PIN_COMPATIBLE` | 封装相同，且**逐脚定义/方向/电气类型已验证兼容** |
| `SAME_PACKAGE_PIN_UNVERIFIED` | 封装相同，但引脚兼容性尚未确认 |
| `DIFFERENT_PACKAGE` | 封装族不同（如 CDIP → LCCC） |
| `PIN_COUNT_MISMATCH` | 引脚数不同（与封装分类并存时记在 `pin_count` 字段） |
| `PACKAGE_UNKNOWN` | 封装证据不足 |

规则：
- **同封装不自动等于引脚兼容**：必须逐脚比对后才可升到 `SAME_PACKAGE_PIN_COMPATIBLE`；
- 不同封装的合法订购变体**不得**被当作可直接替换器件；
- 每条记录 `class / package_target / package_candidate / pin_count_target / pin_count_candidate / evidence`；
- 本例三条 LCCC：`class = DIFFERENT_PACKAGE`，`pin_count_candidate = 20`（目标 8），`interchangeable = false`。

### 3.2 候选等价性：分层证据卡（v1.2 定稿）

**不用单一相似度分数决定兼容性**，按五层独立取证；每项记录
`结论 / 证据位置（pdf_sha256+page+table/row+quote）/ 比较条件 / rule_version`：

| 层 | 必查项 |
|---|---|
| 1 身份与功能 | 器件身份、功能类别、输入/输出数量、逻辑极性、特殊功能（Schmitt/开漏/使能/隔离） |
| 2 引脚与封装 | 引脚数量、逐脚定义、方向、电气类型、封装尺寸 |
| 3 电气 | 工作电压、输入阈值、输出驱动、漏电流、温度范围、绝对最大额定值 |
| 4 时序 | MIN/TYP/MAX、测试条件、负载条件、频率/传播延迟 |
| 5 应用约束 | 目标设计实际需要的工作条件与限制 |

**判定纪律**：关键项缺失 → 整体只能 `UNVERIFIED`，**不得**「其他项通过就整体通过」；
每层可单独标 PASS / FAIL / UNVERIFIED，汇总取最严；`verified=true` 只在五层全部 PASS 时由
规范化数据集验证器写入（见 §4.2）。

**边界（写进代码注释与文档）：**
- 同一器件的合法订购变体 **≠** 替代料（`5962-9053801VPA` 属于 `ordering_info`）；
- 不同封装的订购码 **≠** 同封装变体（`5962-90538012A` 属于 `related_orderables`）；
- 替代料候选 **≠** 已验证可替换（`UC3611` 只能是候选）；
- `match=miss` **只能**表示「经身份核验后确认不属于目标器件」，不能表示「catalog 没匹配到」。

---

## 四、规则 kind（先定判据，后接引擎）

| Rule kind | 级别 | 判据 | 动作 |
|---|---|---|---|
| `alts_dataflow_consistency` | P0 | **候选集合**（`candidates` + `verified`）在 `json` / `alts.json` / `alts.html` / 主页面四处不一致；或ordering 段与 candidate 段**混段**（候选出现在订购段、或`ordering_info`码出现在候选段）；或同一 `ordering_info` 码在四处出现时字段不一致 | 阻断交付 |
| `alts_orderable_misclassified` | P0 | 官方订购表中确认属于目标器件的订购码（同封装或不同封装），被标 `miss` / 混进候选 / 被删除 | 阻断交付 |
| `alts_function_mismatch` | P0 | 候选与目标存在**已证实**的核心功能冲突（§2.2 三条件全满足，或候选 PDF 明文） | 阻断候选发布 |
| `alts_identity_conflict` | P0 | 候选完整 MPN / 制造商对应关系存在**已证实**冲突（如封装引脚数矛盾、同码不同器件） | 阻断候选发布 |
| `alts_evidence_missing` | P1 | 候选缺官方数据手册 / 订购信息 / 关键参数 / 引脚表，且 §2.2 表内也无该码 | 禁止标 `verified` |
| `alts_compatibility_unverified` | P1 | 功能相近，但电气 / 引脚 / 时序 / 使用条件尚未核验 | 保留为待审候选，不得作为已验证替代展示 |

### 4.1 数据流一致性的判定边界（v1.1 更正）

- **判的是候选集合**，不是「四处逐字相同」：`ordering_info` / `related_orderables` 允许在
  Orderable 段出现，它的存在**不算**不一致；
- 但 **ordering 段与 candidate 段不得混**：候选出现在 Orderable 段（或反之）即 P0；
- 同一 `ordering_info` 码若在四处出现，`package / moq / packaging / marking` 必须一致；
- 隔离场景：只清空 candidate 段；Orderable 段保留——这不再被判为不一致。

### 4.2 证据门槛（防止把「不知道」判成「确定错误」）

- P0 必须能落到：原厂 PDF 原文 / 订购表 / §2.2 74 表（已签核）；
- 抽不到证据 → `alts_evidence_missing`（P1）或 `NO_EVIDENCE`，**不得** P0；
- **P1 也要可追溯**（v1.1 新增）：至少 `rule / pdf_sha256 / page / table / columns 或 field / quote`，
  否则视为「凭感觉」，不得写入报告（见 §6.1）；
- LLM 只能产出「可疑点」与证据定位，**不能**覆盖规则层 P0，也不能单凭生成的描述批准替代料；
- `verified=true` 必须同时具备 `evidence{pdf_sha256, page, table/row, quote}` 与 `rule_version`，
  否则一律降为 `UNVERIFIED`（与 `app/services/review.py` 的 LLM 证据闸同口径）。

### 4.3 `verified` 是派生结果，不是可写字段（v1.2 定稿）

- **禁止**翻译、候选生成、模板渲染、LLM review 任一步骤自行写入 `verified=true` /
  `functional-equivalent`；
- 只有**规范化数据集的验证器**能产该字段，且要求 §3.2 五层全部 PASS 并附证据；
- **失效条件**：来源变更、数据手册版本/`pdf_sha256` 变更、关键参数或引脚数据变更、
  规则版本升级 → 原验证结果**立即失效**，回到 `UNVERIFIED` 重新核验；
- 验证记录必须留 `verified_at / verifier / rule_version / evidence_digest`，
  便于失效时定位需要重跑的项。

---

## 五、两件样本的判定（可直接做成回归夹具）

### 5.1 `74LVC1G132DCKTG4`

| 项 | 判定 | 证据 |
|---|---|---|
| 目标功能 | 单路、2 输入、正逻辑 NAND、Schmitt 触发输入 | PDF p.1 `single 2-input positive NAND gate with Schmitt-trigger inputs` |
| 候选功能 | 6 条均为 `74LVC1G11` = **3 输入 AND、无 Schmitt** | §2.2 74 表：`11` = `{AND, inputs:3, schmitt:false}`（表版本 `74fn-2026-10-29`，已签核） |
| 判定 | 核心属性双冲突（NAND vs AND、2 vs 3 输入、Schmitt 有 vs 无）→ `alts_function_mismatch` **P0**，6 条全部阻断，`dropped[]` 分类 = **`INCOMPATIBLE`** | 74 表命中 + 目标 PDF p.1 |
| 附带问题 | 候选 `feature` 文案写 "Schmitt-trigger NAND gate"（错模板） | 描述不得作为证据；无候选 PDF 时只能靠 74 表，故 `feature` 文案一律不采信 |
| 数据流 | `json.alternatives=[]` vs `alts.json` 6 条（候选集合不一致） | `alts_dataflow_consistency` P0 |
| tpd | 源表 MIN/MAX 四组（4/16、2.5/7、2/5.3、1.5/4.4），产物只留 MIN | `switching_spec_max_missing`（P1，误导设计时升 P0）；证据见 §6.1 |
| Ioff | 源表 `0 / ±10 / ±10 µA`，产物只留 `0` | `electrical_typmax_partial`（P1）；证据见 §6.1 |

### 5.2 `5962-9053801PA`

| 项 | 判定 | 证据 |
|---|---|---|
| 订购变体（同封装） | `5962-9053801VPA` / `UC1611J` / `UC1611J883B` 是**本器件、CDIP JG 8** 的合法订购码，被标 miss 并删除 | PDF p.5（三者 ACTIVE、CDIP JG 8、-55 to 125）→ `alts_orderable_misclassified` **P0**，分类 = `SELF_VARIANT` |
| 订购完整性（同封装） | `ordering_info` 现有 4 条（`…PA` / `…VPA` / `UC1611J` / `UC1611J883B`）**即完整** | PDF p.5 CDIP JG 段 |
| 不同封装 | `5962-90538012A` / `5962-9053801V2A` / `UC1611L883B` 为 **LCCC FK 20 脚** | 归 `related_orderables`，页面单独成段、标「不同封装、不可互换」；**不属 `ordering_info`** |
| 候选 `UC3611` | 不同商用器件（0~70°C、3A vs 1A、封装不同），只能是候选 | `alts_compatibility_unverified` **P1**（不得标已验证），分类 ≠ `SELF_VARIANT` |
| 数据流 | 主页面 `#equivalent` 现有 5 行把 4 条订购码与 `UC3611` 候选**混在一段** | `alts_dataflow_consistency` P0（混段）；修复后应为 Orderable 4 + LCC 3（另一段）+ Candidates 1（待审段） |

> 注：`UC3611` 能否在某设计中替代 `UC1611`，不能由「3A vs 1A」或描述相似判定，
> 必须核验电压、动态特性、封装、引脚与目标设计约束。

---

## 六、两条配套门禁（与 alts 独立，但同一批次一起验）

| Rule kind | 级别 | 判据 |
|---|---|---|
| `switching_spec_max_missing` | P1（误导设计时 P0） | 源表存在 MIN/MAX（或 MIN/TYP/MAX）列，而产物只保留 MIN/TYP 时触发；必须比对「源表列角色 vs 产物字段」 |
| `electrical_typmax_partial` | P1 | 源表某行有 TYP 与 MAX 两列，产物只留其一（如 `Ioff` TYP=0 不代表 MAX=0）；缺列必须显式标「未提取」而不是填单值 |

这两条不能退化成「有没有值 / 有没有 condition」，必须做**列角色映射校验**。

### 6.1 证据结构（v1.1 新增：P1 也必须可追溯）

```json
{
  "rule": "switching_spec_max_missing",
  "pdf_sha256": "fae33d78…",
  "page": 7,
  "table": "Switching Characteristics",
  "source_columns": ["MIN", "MAX"],
  "product_fields": ["tpd"],
  "missing_columns": ["MAX"],
  "evidence_quote": "VCC = 3.3V ±0.3V | MIN 2 | MAX 5.3",
  "rule_version": "alts-v1.1"
}
```

`electrical_typmax_partial` 同构：`table = "Electrical Characteristics"`、
`product_fields = ["Ioff"]`、`missing_columns = ["MAX"]`、
`evidence_quote = "Ioff | VI or VO = 5.5V | 0 | ±10 | ±10 | µA"`。

**没有 `page + table + evidence_quote` 的这类结论不得进报告**——否则就是「我看到表里只有 4 个单值，猜的」。
P1 不要求定 P0，但要求能让人回到 PDF 该页该表核对。

### 6.2 MIN/TYP/MAX 必须保留原始语义（v1.2 定稿）

电气参数**同时保存原始表格信息与规范化字段**，不得在提取阶段就把三列压成区间：

```json
{
  "name": "Ioff",
  "raw_columns": ["MIN", "TYP", "MAX"],
  "raw_values": {"MIN": null, "TYP": "0", "MAX": "±10"},
  "unit": "µA",
  "condition": "VI or VO = 5.5V",
  "source": {"pdf_sha256": "…", "page": 6, "table": "Electrical Characteristics", "row": "Ioff"},
  "normalized": {"min": null, "typ": "0", "max": "±10"}
}
```

纪律：
- **禁止**把 `0.3 / 0.4 / 0.7 V` 只存成 `0.3 to 0.7 V` 再期待渲染层恢复 TYP；
- 单值行必须写明「源表只有一列」（`raw_columns: ["TYP"]`），而不是省略；
- 渲染层只读 `normalized` + `raw_columns` 决定显示；缺列显示「未提取」，不得用单值冒充。

---

## 七、状态推导（不靠状态名，靠独立门禁）

```
P0 > 0                                  → REVIEWED_BLOCKED
P0 = 0 且 P1 > 0                        → REVIEWED_STILL_WARN
P0 = 0 且 P1 = 0（规则全过，未人工）      → REVIEWED_QA_PASS   （REVIEWED_FIXED 仅表示「修复动作已执行」）
人工批准                                → HUMAN_ACCEPTED
发布授权                                → RELEASE_APPROVED
```

要点：`REVIEWED_FIXED` 只能表示「修过」，不能表示「质量清零」。
这解释了本次为什么标 `REVIEWED_FIXED` 是错的：修了 3 处，但 P0 仍在、P1 仍在。

---

## 八、实现顺序与阶段门禁（v1.2 定稿 · 本轮不做）

| 阶段 | 工作内容 | 通过条件 |
|---|---|---|
| ⓪ | ✅ 隔离两件、保留原件与前后哈希（`data/qc/quarantine/20261029/`） | 已完成 |
| ① | 建立并签核 74 功能表（`qc/74_function_codes.json`） | `version / sources / owner / reviewed_by / reviewed_at / change_reason / content_hash` 齐全；未签核不得用于 P0 |
| ② | 规范化数据集 + 页面两段式（Orderable / Candidates） | 两个数组完全分离、四处同源、禁止混段 |
| ③ | 实现 2 条 P0 判据 + 10 条夹具（`alts_dataflow_consistency` 含混段、`alts_function_mismatch`） | 明确冲突可阻断；证据不足不误判（用例 #5/#10 必须过） |
| ④ | 两件样本回归（74LVC / 5962） | 不再出现错料放行、合法订购变体误删、数据流分叉 |
| ⑤ | 其余 alts 规则（`alts_orderable_misclassified` / `alts_identity_conflict` / 两条 P1） | 每条规则有独立正例 + 反例 + 证据要求 |
| ⑥ | 电气完整性门禁（`switching_spec_max_missing` / `electrical_typmax_partial`）+ §6.2 原始列语义 | MIN/TYP/MAX、条件与单位均可追溯；缺列显式标「未提取」 |
| ⑦ | 状态机改造（`derive()` 接 P0/P1 计数） | 状态与门禁结果一致；**不允许 WARN 被包装成可发布** |
| ⑧ | 重生成交付物 | 先过独立审计，再讨论生产写回；生产操作另行授权 |

**阶段门禁纪律**：上一阶段未过，不许开下一阶段；每阶段的通过条件要有可执行断言（测试/脚本），
不写「人工看一下就行」。

### 8.1 判据测试用例（先写测试再写实现）

| # | 输入 | 期望 |
|---|---|---|
| 1 | 目标 `74LVC1G132DCKTG4`，候选 6 条 `74LVC1G11*`（74 表已签核） | `alts_function_mismatch` P0，6 条 `fail_mpns`，`dropped[]` 分类 `INCOMPATIBLE` |
| 2 | 目标 `5962-9053801PA`，`dropped_miss` 含 `5962-9053801VPA` / `UC1611J` / `UC1611J883B` | `alts_orderable_misclassified` P0；三者归 `SELF_VARIANT` 并回填 `ordering_info` |
| 3 | 主页面 `#equivalent` 把 4 条订购码与 `UC3611` 混在同一段 | `alts_dataflow_consistency` P0（混段），指向「Orderable / Candidates 应分两段」 |
| 4 | 目标 `74LVC1G132DCKTG4`，候选 `SN74LVC1G132DBVR`（同功能不同前缀） | 74 表命中且核心属性一致 → 不报 P0；仍走 §4.2 证据门槛给 PASS 或 P1 |
| 5 | 候选无可提取证据（非 74 系列、无候选 PDF） | `alts_evidence_missing` P1，**不得** P0 |
| 6 | 源表 tpd 四组 MIN/MAX，产物只 4 个单值 | `switching_spec_max_missing` P1，证据含 p.7/表名/缺失列/原文 |
| 7 | 源表 `Ioff` 0/±10/±10，产物 `0` | `electrical_typmax_partial` P1，证据含 p.6/表名/缺失列/原文 |
| 8 | `5962-9053801PA`，LCC 三码（`…2A` / `…V2A` / `UC1611L883B`） | **不**进 `ordering_info`；`related_orderables` 分类 `DIFFERENT_PACKAGE`（20 vs 8 脚）；不进候选段 |
| 9 | 隔离件：`alts.json` 候选=[]、`alts.html` 空态、主页面 Candidates 段空 | `alts_dataflow_consistency` **不报**（Orderable 段保留不算不一致） |
| 10 | 目标 `74LVC1G132DCKTG4`，候选 `74LVC1G11*` 但 74 表**未签核**（`reviewed_by` 空） | 降为 P1（`alts_evidence_missing`），不得 P0 |
| 11 | 候选五层证据卡中「引脚层」缺失、其余四层 PASS | 整体 `UNVERIFIED`（不得因四项通过而整体 PASS） |
| 12 | 已 `verified` 的候选，其 `pdf_sha256` 或关键参数变更 | `verified` 立即失效回 `UNVERIFIED`，并记录失效原因 |

---

## 九、注册与动作（实现时改动清单，本轮不执行）

- `qc/finding_kinds.py::REVIEW_KINDS` 增 6 个 kind，`LOWER_BOUNDS["review"]` 同步 +6；
  `test_engine_source_kinds_registered` 会自动扫源码覆盖。
- `worker/tasks.py::ACTION_TEMPLATES`：**6 个 kind 全部只登记 `manual_review`**，
  不加自动 fixer —— 删候选 / 改归类 / 重建订购表都是判断题，自动化会制造新事故。
- `worker/tasks.py::_KIND_CATEGORY`：`alts_*` → `IDENTITY_PACKAGE`（本次已顺手补了
  `pin_count_mismatch → PIN_MAPPING` 的遗漏）。
- `qc/review_fix.py::derive()`：接入 P0/P1 计数，产出 §7 的状态。

---

## 十、已知边界（判据做不到的，写清楚不装懂）

1. **同功能码不同厂商的实际差异**：需要候选原厂 PDF；缺证据只能 P1。
2. **电气等价性**：功能相同但速度/驱动/精度不同，属证据卡职责。
3. **生命周期**：需订购表 Status 列（ACTIVE/NRND/OBSOLETE）。
4. **候选 PDF 通常不在交付包内**：v1.1 的 P0 落在**目标 PDF + 订购表 + 74 表（§2.2）**上；
   非 74 系列涉及候选时必须引候选官方文档，否则一律 P1。
5. **字符级判据不可用于定 P0**：料号分位、系列码、封装后缀因厂商而异；
   字符差异只能作**筛查信号**。功能是否等价由 §2.2 的 74 表（已签核）或候选 PDF 判定，
   共享前缀同样不能证明等价。
6. **74 表本身的局限**：只覆盖逻辑门功能码语义，不覆盖电气、引脚、寿命；
   「同码不同厂商实际功能不同」仍属已知盲区（见第 1 条）。

---

## 十一、本轮边界

- 只做：两件样本隔离、原件与哈希留存、本判据文档（v1.2 修订）。
- 不做：引擎改动、交付物重生成、生产数据写回、状态码上线。
- v1.2 本轮补充均为**设计约束**：74 表治理、`related_orderables` 五分类、五层证据卡、
  `verified` 派生、MIN/TYP/MAX 原始语义、8 阶段门禁。没有任何文件被实现代码消费。

---

## 十二、决策记录（v1.1 / v1.2 · 2026-10-29）

> 评审提出 5 处待明确（v1.1）＋ 3 个实现期问题（v1.2）；本节是拍板结果，后续实现以本节为准
> （冲突时以本节优先）。

| # | 问题 | 拍板 | 理由 / 影响 |
|---|---|---|---|
| 1 | `alts_function_mismatch` 的「已证实」来源（与 §10.5 冲突） | **方案 A：新增 74 系列标准功能表为第 1.5 层**（`qc/74_function_codes.json`，人工签核 + 版本） | 无候选 PDF 时仍能判 P0；字符差只作筛查，不直接定 P0；表未签核 → 降 P1（用例 #10） |
| 2 | `ordering_info` 是「所有封装」还是「同封装」 | **方案 B：同封装**；不同封装 → 新增 `related_orderables` | 客户选料首看封装，混排会让 LCCC 与 CDIP 看似可互换。**更正**：`5962-9053801PA` 的 `ordering_info` 现有 4 条 CDIP 即完整，此前「漏 3 码」的表述作废（那 3 条是 LCCC） |
| 3 | 隔离后主页面 `#equivalent` 怎么处理 | **方案 B：两段式**（Orderable = `ordering_info` + `related_orderables`；Candidates = `candidates`/`verified`）；隔离只清空 Candidates | 合法订购码属事实，不该因隔离被抹掉；`alts_dataflow_consistency` 相应只判候选集合 + 禁止混段（§4.1） |
| 4 | `74LVC1G11` 6 条算 `INCOMPATIBLE` 还是 `NO_EVIDENCE` | **`INCOMPATIBLE`**（因 #1 选 A：74 表命中且四项核心属性冲突） | 与 P0 级别一致；`NO_EVIDENCE` 只留给「表无该码 / 无候选 PDF」 |
| 5 | 两条配套门禁的 P1 证据结构 | **采纳评审建议**（§6.1 schema：`pdf_sha256/page/table/source_columns/missing_columns/evidence_quote`） | P1 不要求定 P0，但必须能回到 PDF 该页该表核对，杜绝「看起来只有单值」的猜 |
| 6 | 74 表维护责任人与节奏（v1.2） | **定稿**：具名负责人维护 + 另一名复核签核；**按需更新**（新增系列/误判/规则变更触发）；**未签核版本不得用于 P0**；审计字段 `version/sources/owner/reviewed_by/reviewed_at/change_reason/content_hash` | 关键不在刷新频率，而在「每次变更可追溯、自动阻断权限不随编辑扩大」（§2.2） |
| 7 | `related_orderables` 是否细分封装与引脚数（v1.2） | **定稿**：五分类 `SAME_PACKAGE_PIN_COMPATIBLE / SAME_PACKAGE_PIN_UNVERIFIED / DIFFERENT_PACKAGE / PIN_COUNT_MISMATCH / PACKAGE_UNKNOWN`，**同封装不自动等于引脚兼容** | 本例 3 条 LCCC = `DIFFERENT_PACKAGE`（20 vs 8 脚），`interchangeable=false`（§3.1） |
| 8 | 候选电气/引脚等价性的判定粒度（v1.2） | **定稿**：五层证据卡（身份功能 / 引脚封装 / 电气 / 时序 / 应用约束），**不用单一相似度分数**；关键项缺失整体 `UNVERIFIED` | 每层独立 PASS/FAIL/UNVERIFIED 取最严；`verified` 只在五层全 PASS 时由验证器派生（§3.2、§4.3） |

**由此产生的实现约束（写进代码注释）：**
1. `verified=true` 与 `functional-equivalent` 这两个字段只能由规范化数据集写入，
   候选来源（站内目录 / 相似度 / 描述模板）**无权**写这两个值；
2. 页面 `#equivalent` 的 Orderable 段与 Candidates 段必须由两个独立数组渲染，禁止合并排序；
3. 隔离操作只能清空 Candidates 段与 `candidates/verified`，不得改动 `ordering_info`；
4. 每条 P0/P1 finding 必须带 `rule_version`；74 表相关 finding 另带 `table_version` + `content_hash`；
5. `verified` 失效联动：`pdf_sha256`、数据手册版本、关键参数/引脚数据、规则版本任一变更即失效重验；
6. 电气提取阶段必须同时落 `raw_columns / raw_values / normalized`，渲染层不得「从区间反推 TYP」。

**三个实现期问题（v1.2 已全部定稿，无遗留待定项）：**
- 74 表治理 → §2.2；`related_orderables` 分类 → §3.1；候选等价性粒度 → §3.2。
- 实现期仍需落地、但不属「待定」的事：负责人/复核人**具名**、74 表首批功能码清单、
  五层证据卡的字段 schema（由实现阶段产出后评审）。
