# 阶段三 · qwen 产物后处理与 63 件重解析实测（2026-10-30）

> 结论先行：**「把 name 拆成 symbol + name」这个方案作废** —— 前提不成立。
> 符号不在 `name` 里，在 PDF 表格独立的 `Symbol` 列。三语料实测「符号+描述」这种可拆形态
> 只占 0.8%~3.7%，对 qwen 新产物是 0/30。正则拆出来还会把 22.8% 的纯符号条目拆成
> `symbol=VIH, name=""`，把 `name` 拆空。
>
> 真正需要的是一个**合并**脚本（同一条 PDF 规格行被 MIN/TYP/MAX 拆成多条），而且它必须
> 由 PDF 裁决「是不是同一行」，不能靠字符串规则。已落地 `qc/postprocess_qwen.py`。

---

## 1. 前提纠错：符号在 PDF 的 Symbol 列

`BQ2003PNG4__bq2003.pdf` 第 10 页原文（`Recommended DC Operating Conditions`）：

```
Symbol | Parameter      | Minimum | Typical | Maximum | Unit | Notes
VCC    | Supply voltage | 4.5     | 5.0     | 5.5     | V
VBAT   | Battery input  | 0       | -       | VCC     | V
VMCV   | Maximum cell voltage | 0.2 ∗VCC | - | 0.4 ∗VCC | V
```

同一份 PDF、同一个模型（`qwen-flash`），两边落点不同：

| | `name` | `condition` | 条数 |
|---|---|---|---|
| 交付包 `BQ2003S`（2026-10-24 解析） | `VCC` / `VSNSHI` / `VLTF`（Symbol 列） | `±10%`、`High threshold at SNS…` | 8 |
| 本次 qwen 探针（2026-10-30 解析） | `Supply Voltage` / `High Threshold at SNS`（Parameter 列） | `TA = 0 to +70°C` | 30 |

**两者都是「7 列压 4 字段」的丢信息方案，不是口径之争。** 差异只在丢了哪一半。
交付包在 `DC Thresholds`（`Rating/Tolerance` 两列）那张表上更露馅 —— 它把 Parameter 文本
挤进了 `condition`（`"High threshold at SNS resulting in MOD = Low"`）。

### 三态口径实测

按 `name` 的形态分三类（纯符号 / 符号+描述 / 纯描述）：

| 语料 | 条目 | 纯符号 | 符号+描述 | 纯描述 |
|---|---:|---:|---:|---:|
| 生产 `data/parsed` 300 件 | 10 536 | 2 405（22.8%） | **389（3.7%）** | 7 742（73.5%） |
| 交付包 400 件 | 4 228 | 778（18.4%） | **33（0.8%）** | 3 417（80.8%） |
| 本次 qwen 探针 | 30 | 0 | **0** | 30（100%） |

「符号+描述」是唯一能用正则拆开的形态，占 0.8%~3.7%；对 qwen 新产物 0/30。
**正则拆分方案的实际产出是 0 条**，而副作用是把 22.8% 的纯符号条目拆空。

---

## 2. 真正要解决的问题：MIN/TYP/MAX 拆成多条

qwen 把一行的三列当成三条参数：

```
Supply Voltage  4.5 / 5.0 / 5.5    condition 全是 "TA = 0 to +70°C"
```

下游 `qc/table_audit.py::audit_electrical` 有「冲突消解」：同一 `(表, 行)` 被多个条目认领时
**全部判 `ambiguous_collision`，谁都不写**。所以 30 条跑出来是
`findings=32 / unresolved=30 / patched=0` —— 一条都没修上。

这不是 qwen 独有：生产语料 300 件抽样，**526 组**是这种重复（组大小 2: 435 / 3: 91），
折算约 9.5% 的电气条目是重复行。`BQ2000PWG4` 生产产物里就是
`Supply Voltage 4 / 5 / 6` 三条同 condition。

---

## 3. `qc/postprocess_qwen.py` 与它的职责变更

### 变更前（原设想）

文本后处理：正则从 `name` 拆 `symbol`、洗 `value` 格式。**作废**，理由见第 1 节。

### 变更后

**合并提案 + PDF 行验证。** 它 import `qc/table_audit.py` 当定位器，输出「这几条其实是
同一行」的结论；真正把 `columns` / `value` 填进去的仍然是 `table_audit.patch_cols`。

接口约定（**没有新增 JSON 字段口径**）：

- 只在被合并的条目上加 `postprocess: {rule, merged_from, value_pick, merged_values, merged_conditions}`
- `symbol` **不由本脚本写**，等 `table_audit` 从 Symbol 列回填
- 写盘前备份 `.pre_pp.json`，默认只读

### 判据演进了三版，前两版都是错的

| 版本 | 判据 | 结果 |
|---|---|---|
| v0 | `(nsym(symbol), nsym(name), nsym(condition), nsym(unit))` 相同即合 | 生产样本 526 组，但含假阳性 |
| v1 | 加「组内数值必须同号」刹车 | 526 → 398 组，但**误伤 50 组** |
| v2（现行） | 组内每条先用 `locate_candidates` 落到 `(page, table, row)`，**全部同一行才合** | 精确率 100%，召回率下降 |

#### v0/v1 的假阳性：DAC0800LCM

`DAC0800LCMX_NOPB__snas538c.pdf` 第 3 页：

```
I+   2.3   3.8  mA   Power Supply Current   VS = ±5V, IREF = 1 mA
I−  -4.3  -5.8  mA   Power Supply Current   VS = ±5V, IREF = 1 mA
```

**两行独立参数**，同 name / 同 condition / 同 unit，靠 Symbol 列的 `I+`/`I−` 区分 ——
而 qwen 把 symbol 丢了，键上完全一样。合了会造出 `-4.3 ~ 2.3` 这个不存在的区间。

v1 的「同号」刹车能拦住它，但立刻误伤更常见的跨零合法 MIN/MAX：

```
Integral linearity          -6  | 6
Absolute input voltage    -0.2  | 0.2
Differential linearity      -1  | 3
```

一次拦掉 50 组真合并。**所以「数值同号」不是判据。**

#### v2：让 PDF 裁决

上述两个 case 在 PDF 里的差别是结构性的：DAC 的 `Power Supply Current` 对应**两行**，
`locate_candidates` 返回并列候选；INL 的 `-6`/`+6` 对应**同一行**的 MIN/MAX。
所以判据是「是否同一行」，不是「数值关系」。

复用 `table_audit.locate_candidates` 而不另写一套匹配，是为了避免
「后处理认为是一行、审计认为是两行」的分裂。

### A/B 实测（6 件）

| 模式 | 合并组 | 假阳性 | 说明 |
|---|---:|---:|---|
| `--no-verify`（按键） | 7 | 3（DAC 的 I+/I−） | 精确率 4/7 |
| 默认（PDF 同一行） | 3 | **0** | 精确率 3/3 |

`BQ2003PNG4` 30 → 26（合 3 组，拦 1 组）；拦掉的是 `Temperature Cutoff Voltage`，
原因是它 `locate` 未唯一命中（`temperature` 同时命中绝对最大额定值表的 TOPR/TSTG/TSOLDER）
—— 这正是已知的「`_decide_match` 缺表类型过滤」缺陷。**PDF 验证把这个缺陷的后果
从「误修」变成了「不修」，方向是对的。**

### 端到端效果（BQ2003PNG4）

| 阶段 | findings | unresolved | patched |
|---|---:|---:|---:|
| 原始 qwen 输出 | 32 | 30 | 0 |
| 合并后（PDF 验证） | 25 | 23 | 2 |
| 合并后 + 第 4 节的单元格修复 | 27 | 23 | **4**（3 条 columns 全部正确） |

**仍然有 23 条 unresolved**，因为 `row_ambiguous_unresolved` 的主因没动：
符号（`VCC`）在 value / condition 里反复出现（`0.2 ∗VCC`、`VCC - 1.0`），
`locate_candidates` 的「符号命中 100 分」在多行上同时成立 → 并列。
这条要动打分函数（`MATCH_RULE` 版本升级），不在本次范围。

---

## 4. 已修：`find_tables().extract()` 重排数值单元格字符

### 现象

BQ2003PNG4 合并后跑 `--write`，`Tri-state Open Detection Current` 被写成
`20 MIN / 20 MAX`，而 PDF 原文是 `-2.0 / 2.0`。

### 三层取证（根因在最后一层）

```
① page.get_text("words")       IIZ 行：x=267.0 '-2.0'  x=316.4 '-'  x=352.8 '2.0'  x=390.3 'µA'
② Table.extract() 同一格        '20\n- .'      /  '-'  /  '20\n.'        ← 字符被重排
③ clean() → to_num()           '20 - .' → 20.0                          ← 差 10 倍还不报错
```

原文正确、`to_num` 的正则也正确（`[±+-]?\d+(?:[.,]\d+)?` 能吃 `-2.0`）。
**问题在 ① 与 ② 之间**：`extract()` 重建单元格文本时，把负号和小数点挪到了数字后面，
而且拆成三行（`20` / `- ` / `.`）。`clean()` 把三行拍平成一行，证据就没了。

同类破坏在全表普遍：`'4.5'→'45 .'`、`'5.0'→'50 .'`、`'0.75'→'075 .'`、`'-5.0'→'50 - .'`。

### 修法（ADAPT A10）

不整体抛弃 `extract()`（多行单元格、合并单元格都靠它），只做**定向修复**：

1. `bad_number_cell(s)` 判定「被重排」的三种形态（去空白后）：
   - `^[±+\-−]?\d+[-−]?\.$` —— 小数点被拆成独立 token（`45.`、`20-.`、`075.`）
   - `\d[-−]` 且首字符不是负号 —— 符号被挪到数字后（`VCC1.0-`）
   - 公式格（`0 .2 ∗VCC`）与占位符（`-`）**不判可疑**，不动
2. 命中则用该行的 cell bbox 从 `get_text("words", clip=bbox)` 按 `(y, x)` 重拼
3. 重拼结果若仍被判可疑 → 保持原样，不瞎改

### 验证

同一份 PDF 的表抽取：

| 行 | 修复前 | 修复后 |
|---|---|---|
| VCC | `'45 .' / '50 .' / '55 .'` | `'4.5' / '5.0' / '5.5'` |
| IIZ | `'20 - .' / '-' / '20 .'` | `'-2.0' / '-' / '2.0'` |
| ICC | `'075 .'` / `'22 .'` | `'0.75'` / `'2.2'` |
| IOH | `'50 - .'` | `'-5.0'` |

端到端（合并 3 组 → audit `--write`）：

```
Supply Voltage                    value="4.5 MIN / 5 TYP / 5.5 MAX"   columns={4.5, 5.0, 5.5}
Supply Current                    value="0.75 TYP / 2.2 MAX"          columns={TYP:0.75, MAX:2.2}
Tri-state Open Detection Current  value="-2 MIN / 2 MAX"              columns={-2.0, 2.0}   ← 修复前是 20/20
```

`patched` 从 2 升到 4，且**原来那 1 条错补丁消失了**。

回归：`tests/test_table_cell_repair.py` 18 条（判据矩阵 15 + 真 PDF 复现 2 + 负号不误判 1），
连同既有 `test_table_audit_unique.py` / `test_pdf_pin_table.py` 共 42 条全绿。

**生产未受影响**：`data/parsed` 8990 件里 `columns` / `value_raw_original` 匹配数为 0
—— `table_audit --write` 从未成功污染生产。属**已修掉的潜伏缺陷**。

---

## 5. 线 B：63 件批量重解析实测

按 `stage3_reparse_probe_20261030.csv` 的 STRONG 判定，跑掉 5 件
（`BQ2003S` 早前已跑）：`ADS1271IPW`、`ADS1271IPWR`、`BQ2000SN-B5TR`、
`CC2530F32RHAR`、`DAC0800LCM`。

**解析本身：5/5 成功**，25.1~83.6 秒/件，confidence 0.90~0.95。

**但产出不能进生产，三个硬阻塞：**

### 阻塞 1：料号由 PDF 文件名决定，不是订货号

| 交付 MPN | PDF | 产出 `basic_info.mpn` |
|---|---|---|
| ADS1271IPWR | `ADS1271IBPWR__ads1271.pdf` | `ADS1271IBPWR` |
| ADS1271IPW | `ADS1271IPWG4__ads1271.pdf` | `ADS1271IPWG4` |
| BQ2000SN-B5TR | `BQ2000PWG4__bq2000.pdf` | `BQ2000PWG4` |
| CC2530F32RHAR | `CC2530DK__CC2530F32_…Rev2011.pdf` | `CC2530DK` |
| DAC0800LCM | `DAC0800LCMX_NOPB__snas538c.pdf` | `DAC0800LCMX/NOPB` |

`mpn_from_name()`（`parse_datasheets.py:838`）只用 PDF 文件名。**5/5 全错。**
`metadata.requested_mpn` 则 **5/5 缺失** —— 这个字段由
`app/services/pipeline.py:167` / `batch.py:255` 写，`parse_datasheets.py` 这条路径不写。
而身份映射的 A 级判据正是 `requested_mpn`。

### 阻塞 2：产出的文件名在生产里已经存在

5 件的输出文件名（`{mpn}_{pdf_hash[:8]}.json`）**全部命中了生产已有文件**：

```
data/parsed/BQ2000PWG4_41f12aef.json
data/parsed/ADS1271IBPWR_e557bad6.json
data/parsed/ADS1271IPWG4_e557bad6.json
data/parsed/DAC0800LCMX_NOPB_4e11cf77.json
data/parsed/CC2530DK_bc0cbf05.json
```

即「重解析」并没有产生任何新产物，只是把已存在的产物重写一遍。
`63` 件缺的**不是产物，是「产物 ↔ 交付包」的映射**。

### 阻塞 3：重解析不可复现

同一模型（`qwen-flash`）、同一 PDF，两次解析的电气条数：

| 文件 | 新 | 生产已有 |
|---|---:|---:|
| BQ2000PWG4 | 24 | 32 |
| ADS1271IBPWR | 63 | 35 |
| DAC0800LCMX_NOPB | 31 | 57 |

最大差 28 条。**重解析结果不能当作「同一份产物的更好版本」直接覆盖。**

---

## 6. 63 件的真实可解范围

| 子类 | 件数 | 有 PDF | 重解析能解决吗 |
|---|---:|---|---|
| `D_ambiguous`（同 pdf_hash 多产物） | 33 | STRONG 5 / WEAK 18 / NONE 10 | ❌ 产出名已在生产，不产生新信息 |
| `E_absent`（生产无产物） | 25 | STRONG 1 / WEAK 1 / NONE 23 | ⚠️ 只那 2 件有 PDF，且料号仍会错 |
| `F_dup_target`（与另一件抢同一目标） | 5 | STRONG 2 / WEAK 3 | ✅ 唯一真正受益的一类 |

**真正能靠重解析推进的是 `F_dup_target` 5 件** —— 它们的问题是「两个来源抢同一个目标文件」，
给其中一件造一个独立产物就解开了。其余 58 件要么没有 PDF（33 件），要么重解析产出的名字
已经在生产里（所以不解决归属）。

---

## 7. 下一步

| 优先级 | 事项 | 理由 |
|---|---|---|
| ~~P0~~ | ~~修 `scan_tables` 小数点被吞~~ | **已完成（ADAPT A10）**，见第 4 节 |
| P0 | `locate_candidates` 打分纳入「value 落在该行 MIN/TYP/MAX」 | 解 `row_ambiguous` 最高杠杆；`Logic Input High Voltage` 靠它可唯一化 |
| P0 | `_decide_match` 加表类型过滤（跳过无 TYP 列的绝对最大额定值表） | 22/23 条 unresolved 里的表选错 |
| P1 | 提示词加 `symbol` 字段（取 Symbol 列），`name` 保留 Parameter | `table_audit` 第 254 行已支持 `e.get("symbol")`，加字段即刻恢复 100 分命中 |
| P1 | `parse_datasheets.py` 支持 `--requested-mpn` | 修复阻塞 1，让重解析产出能挂到交付订货号上 |
| P2 | `PROMPT_VERSION=v2` 的 10 件门禁重跑 | v2 的 MIN/TYP/MAX 塌缩规则才是 A2 的根解 |
