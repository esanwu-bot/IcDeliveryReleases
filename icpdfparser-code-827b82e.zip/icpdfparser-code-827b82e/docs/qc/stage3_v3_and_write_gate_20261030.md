# 阶段三 · unique-v3 与写盘闸门（2026-10-30 晚）

> 结论先行：**核心管线的「匹配」打通了，「写盘」没打通 —— 而且这一轮证明了它现在不该打通。**
> 13 件真实灰度写盘结果：合并 0 条、写 `columns` **2 条**、脏格拦截 2 条、`unresolved` 234。
> 那 2 条经逐字核对**是对的**（修复的是 qwen 把「抽头比」和「延迟」抽反的字段）。
> 闸门把其余「带病硬上」全部拦住了。可以灰度**只读**（跑诊断出报告），
> 不能灰度**写盘**（写盘命中率 2/308 ≈ 0.6%，不构成收益）。
>
> **追加（同日深夜，A13 融合列切分落地后）：上面这条结论被推翻了。**
> 单件 DAC8555 从「写列 0」变成「写列 **10**」，逐条回填核对全部正确；
> 写盘从「不构成收益」变成「**可以小批量灰度**」。详见 §7。

---

## 1. 「10 行 VT+」这个前提是错的

用户判断 74LVC1G132 的 `VT+` 在 PDF 里是 **10 行**、10 条 JSON 是 1:1 映射。
实测（第 6 页 t0）是 **5 行 × 2 个温度列组**：

```
PARAMETER            | TEST CONDITIONS | VCC  | –40~+85°C        | –40~+125°C       | UNIT
                     |                 |      | MIN  TYP  MAX    | MIN  TYP  MAX    |
VT+ Positive-going…  |                 | 1.65 | 0.79             | 1.16             | V
                     |                 | 2.3  | 1.11             | 1.56             |
                     |                 | 3    | 1.50             | 1.87             |
                     |                 | 4.5  | 2.16             | 2.74             |
                     |                 | 5.5  | 2.61             | 3.33             |
```

三条推论全部与直觉相反：

1. **温度不是行，是列**。所以 10 条永远压到 5 行上，每行 2 条 → 稳定 collision，
   靠调打分**不可能**清零。
2. **这一列没有 MIN/TYP/MAX 角色**。`extract()` 只给了第一行表头（`V` / 空 / `UNIT`），
   第二个表头行 `MIN TYP MAX MIN TYP MAX` 被当成数据行吞掉了。
   `role_map` 结果只有 `{2: 'COND', 10: 'UNIT'}` → **`patch_cols` 无从下手**，
   就算匹配成功也写不了。
3. **数据格本身是坏的**：`'079 116 . .'`（= 0.79 / 1.16）、`'165V .'`（= 1.65 V）。
   ADAPT A10 的 bbox 修复只认「尾随小数点」和「数字后跟负号」两种形态，这两种它没修。

**所以 74LVC1G132 是结构性不可回填件**，不是算法没调好。对它正确的期望是
「如实报 ambiguous，一个字节都不写」。

---

## 2. 唯一有效的两处改造（unique-v3）

### 2.1 合并单元格 → 按列继承标签（`row_labels`）

`VT+` 占 5 行，`PARAMETER` 列只在第一行有字，第 3~6 行是空格。
`locate_candidates` 的 `blob` 只含本行文本 → 第 3~6 行一个 `vt` 都没有 → 分数 0，
**只有第 2 行是候选**，10 条全抢它。

**踩过的坑**：第一版按「整行是否为空」决定继承，一次都没触发 ——
因为第 3~6 行的 `VCC` 列有字（`'23V .'`），整行非空。
必须**按列**继承：空的那一列继承上一行，有字的列保持自己的。

```python
text_cols = [ci for ci in range(len(header)) if rm.get(ci) is None]
last = {ci: "" for ci in text_cols}
for row in tbl["rows"]:
    for ci in text_cols:
        if clean(row[ci]): last[ci] = clean(row[ci])
    labels.append(" ".join(last[ci] for ci in text_cols if last[ci]))
```

只继承**文本列**。MIN/TYP/MAX/UNIT 一律不继承 —— 继承别人的数值比漏匹配严重得多。

第二个坑：`ov`（共同词命中）原来用原始行文本，于是第 2 行靠自己的
`positive-going / going / voltage` 白拿 75 分，继承后的行只拿 0 分，
**继承反而让正确的行分更低**。v3 里 `ov` 也走 `labels` 视图。

### 2.2 condition 的数值参与打分（`cond_num_hit`）

`cond_overlap` 只数 `[a-z]{3,}` 的词 —— `VCC = 1.65V` 只贡献一个 `vcc`，
五行的 VCC 不同但全都命中 `vcc` → **打平**。区分力全在 `1.65` 这个数上。

```python
def num_tokens(s):        # '1.65V' → '165'，'165V .' → '165'
    return {re.sub(r"[.,]", "", t) for t in _COND_DIGITS.findall(clean(s) or "")}

def cond_num_hit(row_text, cond, table_nums):
    obs = num_tokens(cond) & table_nums    # 只算本表数据行真的出现过的数
    return 100 * len(obs & num_tokens(row_text)) // len(obs)
```

- **按数字串比对而不是 float**：ADAPT A10 已证小数点会被挪位（`'1.65 V'`→`'165V .'`），
  数字顺序不变、分隔符位置乱，去分隔符后两种形态自然等价。
- **分母只算本表出现过的数**：`−40°C to +85°C` 在表头不在行里，计入分母会永久扣分。
- **加分只给已经是候选的行**（`score >= 50`）：一个数字翻盘等于用弱证据压过强证据。
- 权重 +50 = 150 × 命中比例，实测足以让 VCC=2.3 的行压过 VCC=1.65 的行（96 → 171）。

### 2.3 A/B 实测（13 件 / 308 条电气条目）

| 版本 | findings | unresolved | patched | ambiguous | 并列 | 抢同一行 |
|---|---|---|---|---|---|---|
| v1 | 350 | 318 | 32 | 295 | 84 | 211 |
| v2 | 341 | 309 | 32 | 285 | 52 | 233 |
| **v3** | **314** | **277** | **37** | **246** | 58 | 188 |

v3 的 `patched` 首次真正上涨（32 → 37），ambiguous 掉 39 条。
单件看：DAC8555 的 collision 37 → 21，ADC3910 的 ambiguous 16 → 8。

但**「patched 从 0 猛增到 10+」这个门槛达不到**，原因是结构性的（见 §1），
不是调参没到位。13 件里单件最高是 ADC3910 的 6 条。

---

## 3. 写盘闸门（ADAPT A12）：这一轮真正的收获

### 3.1 抓到的两条证据级坏写盘

DAC8555 第一次端到端写盘，2 条 `columns` 全是错的：

| 原始格 | `to_num` | 写进 JSON 的值 | 真值 |
|---|---|---|---|
| `'0 .7 × IOVDD'` | 0.0 | `"0 MIN"` | 0.7×IOVDD（公式） |
| `'10 20'` | 10.0 | `"10 MIN"` | 20（两格并一格） |

根因：`patch_cols` 用 `to_num`（从任意文本捞第一个数）取列值。
诊断时捞一个数够用，**写盘时捞一个数就是伪造**。

### 3.2 两道闸门

```python
def cell_num(s):            # 整格必须是一个数
    if len(_COND_DIGITS.findall(t)) != 1: return None   # '10 20' / '-0.3 to +7.0'
    core = 去尾随单位; 归一 −/–
    if not _RE_NUM_ONLY.match(core): return None        # '0.7×' / 'VCC-1.0'
    return to_num(core)

def fused_cols(header):     # 一列装了多个 MIN/TYP/MAX → 竖线丢了
    return {i for i,h in enumerate(header)
            if sum(1 for r in ("MIN","TYP","MAX") if _ROLE_RX[r].search(h.lower())) > 1}
```

- `cell_num` 拦「脏格子」（公式、多值、范围），产出 `cell_unparsable_unresolved`
- `fused_cols` 拦「融合列」（DAC8555 表头就是 `'MIN TYP MAX'` 一格），
  产出 `cell_unparsable_unresolved` 且 `table="FUSED_COLUMN"`
- 占位符（`-` / `—` / `N/A` / `TBD`）走 `is_blank_cell`，算「这列没值」，**不算脏**
  （否则 `TYP='-'` 会把整表判脏）
- 写盘失败时**原值一个字都不动**，只多一条 unresolved

设计要点：`cvals`（诊断「这一行有几个值」）仍然用 `to_num`，
`cols`（写盘）才用 `cell_num`。两者故意不同 —— 用 `cell_num` 算 `cvals`
会让「格子脏」把该报的 `range_collapse` 一起吞掉，报告里就看不到「本该回填但被拦」。

### 3.3 合并侧的第二道闸门：`SKIP_VALUES_NOT_IN_ROW`

`merge_duplicate_rows` 只保留组内第一条 value，其余降级进 `merged_values`。
若下游没能写成 `columns`，主线 value 就变成 `180` 而真值是 `180/250` —— **静默丢数据**。

所以合并前先验证「组内每个数值都能在这一行找到」：

```python
lost = [v for v in vals if T.to_num(v) is not None
        and all(abs(T.to_num(v)-c) > 1e-9 for c in row_cell_nums(tables, ref))]
if lost: SKIP_VALUES_NOT_IN_ROW
```

实测 DAC8555 7 组里 6 组、CY74FCT245 1 组、CDC4211 2 组被此闸门拦下。

---

## 4. 13 件真实灰度（沙箱 `data/_e2e13/`，真写盘）

```
MATCH_RULE=locate_row/unique-v3  cell_num=on  件数=12
74LVC1G132DCKTG4   47→47 合并0 丢值拦0 写列0 脏格拦0 unresolved 46
BQ2003PNG4          8→ 8 合并0 丢值拦0 写列0 脏格拦0 unresolved  4
5962-9053801PA     12→12 合并0 丢值拦0 写列0 脏格拦0 unresolved 12
ADC3910S065IRSMT   25→25 合并0 丢值拦0 写列2 脏格拦0 unresolved  9
ADS7812B/1K        40→40 合并0 丢值拦0 写列0 脏格拦0 unresolved 44
AM26C32IDG4        15→15 合并0 丢值拦0 写列0 脏格拦0 unresolved  8
BQ24300DSGR        25→25 合并0 丢值拦0 写列0 脏格拦0 unresolved  9
BUF634PG4          17→17 合并0 丢值拦0 写列0 脏格拦0 unresolved 13
CD74FCT244SM96     14→14 合并0 丢值拦0 写列0 脏格拦0 unresolved  9
CDC421106RGER      20→20 合并0 丢值拦2 写列0 脏格拦0 unresolved 17
CY74FCT245ATSOCT   29→29 合并0 丢值拦1 写列0 脏格拦0 unresolved 29
DAC8555IPWG4       56→56 合并0 丢值拦7 写列0 脏格拦2 unresolved 34
合计：合并 0 条；丢值拦截 10 组；写 columns 2 条；脏格拦截 2 条；unresolved 234
```

### 那 2 条写盘是人核对过的（唯一成功样本）

`ADC3910S065IRSMT` 的 `Add. Latency (Real Decimation)`：

```
输入:  name="Add. Latency (Real Decimation)"  value="4"  condition="60"
PDF :  ['', '', '4', '60', '', '']
输出:  value="60 MIN"  condition="4"  columns={"MIN": 60}  value_raw_original="4"
```

qwen 把「抽头比 4」和「延迟 60」抽反了（比值进了 value、真值进了 condition），
`condition_leak` 拿 condition 的数值反查本行 → 命中 → 用 PDF 的 MIN 纠正。
**这是全套里唯一一次「写入即纠错」**，也正是 `condition_leak` 这个分支的价值所在。

**没有一条脏写盘。** 但有 10 组本该合并的条目被迫留人工。

被拦的行逐字核对过（确认不是误杀）：

| 件 | 原始格 | 实际含义 |
|---|---|---|
| DAC8555 p3/t0/r29 | `'18 55 . .'` | 1.8 / 5.5 |
| CY74FCT245 p4/t0/r6 | `'24 33 . .'` | 2.4 / 3.3 |
| CDC4211 p3/t2/r1 | `'–0 .5 to 4 .6'` | −0.5 to 4.6 |

前两条正是 ADAPT A10 的字符重排，但**多值形态（`'18 55 . .'`）没有被 `bad_number_cell` 识别**，
所以 bbox 重拼也没触发。这是下一个该补的洞。

---

## 4.1 补的两处（本轮末尾）

### ① 一条只准写一次（`value_raw_original` 不被覆盖）

ADC3910 上发现 `row_mispair` 与 `condition_leak` **同时成立** → `patch_cols` 跑两遍，
第二次把 `value_raw_original` 覆盖成「已修好的值」：

```
第一遍: value_raw_original="4",  value="60 MIN"
第二遍: value_raw_original="60 MIN", value="60 MIN"   ← 原始值 4 永久丢失
```

修法两道：`_writable()` 里 `if e.get("columns"): return False`（同轮锁），
外加 `patch_cols` 里 `if "value_raw_original" not in e`（幂等兜底）。

### ② 多值重排识别（`_RE_MULTI_TAIL`）

```
'18 55 . .'  → True   → bbox 重拼 → '1.8 5.5'
'24 33 . .'  → True   → '2.4 3.3'
'079 116 . .'→ True   → '0.79 1.16'
'0.2 ∗VCC'   → False  （公式格没有尾巴点）
'18 55'      → False  （可能是正常范围，不猜）
```

重拼后文本**人可读了**，但 `cell_num` 仍然拒绝（两个数）—— 诊断改善，写盘照旧不放行。

## 5. 结论与下一步

### 可以做的

- **只读灰度**（500 件跑诊断、出报告、不写盘）：现在就可以，v3 + 闸门是安全的。
- 把 13 件结果整理成基线报告。

### 不能做的

- **写盘灰度**。理由：13 件里 0 条电气条目能安全回填，说明这一批表
  （合并列、多值格、重复角色组）还没有被正确理解。现在放开写盘 = 0 收益 + 风险。

### 下一步优先级

| P | 事项 | 为什么 |
|---|---|---|
| ~~P0~~ | ~~`bad_number_cell` 识别「多值重排」~~ | **已完成**：`_RE_MULTI_TAIL`，重拼后 `'1.8 5.5'` / `'2.4 3.3'` / `'0.79 1.16'` |
| ~~P0~~ | ~~融合列（`'MIN TYP MAX'`）的**列切分**~~ | **已完成**：ADAPT A13，见 §7。DAC8555 写列 0 → 10 |
| P1 | 重复角色组（同一表头出现两组 MIN/TYP/MAX）→ `patch_cols` 支持 `MIN#1/MIN#2` | 74LVC1G132 的 10 条属于此 |
| P1 | 提示词加 `symbol` 字段（取 Symbol 列） | `table_audit.py` 已支持 `e.get("symbol")` |
| P2 | `locate_candidates` 表类型过滤（跳过无 TYP 列的 Absolute Maximum 表） | 残留 58 条并列里有一部分死在这里 |

---

## 6. 回滚开关

- `ICPDF_MATCH_RULE=v3`（默认）/ `v2` / `v1` —— 三臂可 A/B。
- `cell_num` 闸门无开关：**它是安全边界，不是可调参数**。
  真要临时放开，改 `audit_electrical` 里 `_writable()` 的返回值，并在报告里写明原因。

---

## 7. ADAPT A13 融合列切分 · A14 乱码护栏 · A15 原子写（补记）

### 7.1 切分：为什么"中心点"一定错、"重叠"才对

融合列一格装三列（`'180 250'`、`'1.8 5.5'`、`'18 55 . .'`）。要还原成 MIN/TYP/MAX，
只能靠 words 的 x 坐标。但归位判据试过两版都不行：

| 判据 | 反例 | 结果 |
|---|---|---|
| 区间中点距离 | 首尾区间用 ±1e9 兜底，中点飘到 ±5e8 | 所有值掉进中间列 |
| 到区间距离 | `'180'` 中心点偏右（右对齐，字宽窄） | `180` 被分进 TYP |
| **重叠长度优先** | —— | 正确 |

```python
overlaps = [max(0.0, min(w[2], hi) - max(w[0], lo)) for lo, hi in bounds]
best = max(overlaps)
if best > 0:
    return overlaps.index(best)      # 有重叠，按重叠长度定
return 近者                          # 零重叠才退回距离
```

真实坐标验证（DAC8555 p3）：`w180=(448.9,460.6)` 零重叠于 MIN → TYP；
`w18=(421.1,430.8)` 落在 MIN → MIN。

**锚点 + 自校验**：子列区间由表头词的位置决定（表头比数值稳定），切完再用
「数值右边缘贴不贴表头右边缘」自校验，`hit/tot < 0.8` 直接返回 `None` 交人工
—— **绝不硬切**。

### 7.2 乱码护栏：格子文本会骗人

`extract()` 对多行 TEST CONDITIONS 会做字符交织，产出的文本既**乱**又**残缺**：

```
格子：'T 0po ± 0 <. 0 C0 L3 <% F 0S 0pR F, 0200h to FD00h , RL = 2kΩ , F 2'   ← 尾部被截
模型：'To ±0.003% FSR, 0200h to FD00h, RL = 2kΩ, 0pF < CL < 200pF'            ← 完整正确
```

这时候「以表格为准」是错的。判据用**长词占比**（≥4 字符的 token 占含字母 token 的比例）：

| 文本 | 长词占比 | 判定 |
|---|---|---|
| `AVDD = 5V, VREF = 4.99V` | 0.60 | 干净 |
| `VREFL = GND , VREFH = AVDD = 5V` | 0.43 | 干净 |
| `M (Ae Va Ds Du =re 5d b ...` | 0.07 | 乱码 |
| `T 0po ± 0 <. 0 C0 L3 ...` | 0.10 | 乱码 |

阈值 0.2。早退条件：token < 8 或含字母 token < 4 → 不判（`0 to 70` 这类纯数字条件不受影响）。

**留痕**：拒绝覆盖时写 `condition_cell_garbled: true`。不留痕的话，日后回查
「这条为什么没跟单元格走」只能靠猜。

### 7.3 原子写

`audit_json(write=True)` 原来直写 `json.dumps`。多进程写盘 + 进程可能被杀 =
半截 JSON → 下次读入 `JSONDecodeError`，看起来像"数据坏了"，实际是"上次没写完"。

改成同目录 `.tmp` + `flush` + `fsync` + `os.replace()`：只有「旧内容」或「新内容」
两种终态。（`postprocess_qwen` 早先已是这个写法。）

### 7.4 DAC8555 单件复测（切分开）

```
写列 10 条（此前 0 条）／脏格拦 1 条／unresolved 27／合并 6 条
```

| 参数 | 写入 | 原始格 | 核对 |
|---|---|---|---|
| Relative accuracy | TYP 4, MAX 12 | `±4` / `±12` | ✅ |
| Differential nonlinearity | TYP 0.25, MAX 1 | `±0.25` / `±1` | ✅ |
| Zero-scale error | TYP 2, MAX 12 | `±2` / `±12` | ✅ |
| Full-scale error | TYP 0.3, MAX 0.5 | `±0.3` / `±0.5` | ✅（condition 乱码被拦，保留模型空值） |
| Gain error | TYP 0.05, MAX 0.15 | `±0.05` / `±0.15` | ✅ |
| Output voltage settling time | TYP 8, MAX 10 | `8` / `10` | ✅（condition 保留模型原文） |
| Reference input current ×2 | TYP 180/120, MAX 250/200 | 同行 | ✅（180 归 TYP 不再归 MIN） |
| IOVDD | MIN 1.8, MAX 5.5 | `1.8` / `5.5` | ✅ 无 TYP |
| IOIDD | TYP 10, MAX 20 | `10` / `20` | ✅ |

唯一被拦的脏格是 `VREFL Voltage` 的 `AVDD/2`（公式格）—— **不是融合列侧漏**。
这说明开切分后 `fused_cols()` 为空，`FUSED_COLUMN` 这一支不再被触发，
审计口径自洽。

---

## 8. 排障记录：两个"看起来像故障"的正常现象

写盘灰度要跑几小时、要开多进程，最容易误判的不是数据错，而是**把正常现象当成故障**
去"修"，结果改坏了本来对的东西。这一轮遇到两个。

### 8.1 日志一直是 0 字节 —— 不是卡死，是缓冲

**现象**：`python -u xxx.py > logs/a.log` 起的长任务，跑十几分钟 `a.log` 还是 0 字节。
第一反应是"死锁了 / 卡在某个 IO 上"。

**真因**：`table_audit.py` 为了 Windows 控制台中文输出，在导入时重包了 stdout：

```python
_w = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
```

`TextIOWrapper` 默认**按块（8KB）缓冲**，命令行 `-u` 设的是原 stream 的属性，
新 wrapper 不继承 —— 于是 `-u` 被彻底吃掉，所有 print 攒够 8KB 才落盘。

**修法**：`line_buffering=True`。

```python
_w = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace",
                       line_buffering=True)
```

**判据**：进程 CPU 时间在涨（`Get-Process python | select Id,CPU`）就是活着。
CPU 不涨才是真卡死。以后看到"日志为空"，先查 CPU、再怀疑缓冲，最后才怀疑死锁。

### 8.2 写盘灰度会从 FACTS 目录侧漏

**现象**：以为"把 `src_json` 指到沙箱副本就安全了"。

**真因**：`audit_json(write=True)` 写两个地方：

```python
atomic_write(jp, ...)                                    # 源 JSON（可控，已指向沙箱）
atomic_write(FACTS / f"{safe_name(req)}.facts.json", ...) # ← 模块级常量，永远指真目录
```

第二个用的是模块级 `FACTS`，跟 `src_json` 无关。只重定向 `src_json` 的话，
**沙箱跑一遍写盘灰度，真 `data/facts/` 就被改了 50 份**。

**修法**：worker initializer 里连 `FACTS` 一起改：

```python
def _init(write=False, box=None):
    from qc import table_audit as T
    global _WRITE, _BOX
    _WRITE, _BOX = bool(write), (Path(box) if box else None)
    if _WRITE and _BOX:
        T.FACTS = _BOX / "facts"      # 写盘不外溢
```

**教训**：凡是"写盘"函数，要**逐个列出它写到哪里**，而不是盯着传进去的那个路径。
一个 `write=True` 背后可能有三处 `open(...,'w')`。

### 8.3 附带的第三个坑：验证脚本自己会撒谎

回填核对里原来这么判"写进去的值是不是真在表里"：

```python
flat = " ".join(str(x) for x in raw.values())
if any(part not in " ".join(map(str, row)) for part in flat.split("|")):
    flag = "!!"
```

把三列的值拼成一串，再去行文本里找**连续子串**。可 `IOVDD` 那一行是
`['IOVDD','','1.8','','5.5','']` —— 中间隔着空列，`"1.8 5.5"` 永远不是连续子串，
于是**正确写盘被标成错误**。

改成**逐列成员判定**（不要求相邻，只要求"这列的值确实在这一行的某一格里"）：

```python
for k, v in raw.items():
    if not any(str(v).strip() == c or str(v).strip() in c for c in cells):
        bad.append(f"{k}='{v}'")
```

**这个坑的代价**：如果把假警报当真，会去回滚一条**本来就对**的写盘数据，
把正确的 `MIN 1.8 / MAX 5.5` 换成旧的单值 `1.8` —— 验证脚本反而成了污染源。
