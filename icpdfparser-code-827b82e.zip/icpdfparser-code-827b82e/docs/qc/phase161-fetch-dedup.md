# Phase 1.6.1 验收：fetch 段去重的状态保护与并发领取

> 裁决来源：Phase 1.6 外审（G1–G4 有条件通过，暂不批准灰度）。
> 本文只回答一件事：**"重复投递会不会重复干活、会不会把 `done` 改坏"** 这个问题现在是否有结论。
> 结论：**有。F1–F8 全绿，含并发（F6）在真 Celery 多线程 worker 上的实测。**

| 项 | 结果 |
|---|---|
| 状态保护（`done` 不被降级） | 已修，A/B 实测通过 |
| 并发保护（同一条消息两个任务） | 已修，跨线程实测只有一条取得执行权 |
| F1–F8 | 8/8 通过（16 条新用例 + 服务器 A/B） |
| 回归 | 19 failed / 1901 passed / 1 skipped，**失败集与修复前逐条相同** |
| 生产影响 | 零：验收在 Redis DB7 + `/tmp/p16/f61/data_*`，生产库与 `data/parsed` 的 mtime/文件数未变 |
| 提交 | `dce426e fix(fetch): 去重判据先于状态写入 + 原子领取` |

---

## 1. 缺陷：判定用的是"改状态之前"的快照

```python
# worker/tasks.py::fetch_item（修复前，第 42-47 行）
item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))   # 快照：status="done"
db.touch_status(item["id"], "queued", "任务已入队", 2)            # 库里改成 "queued"
r = pipeline.fetch_stage(item, ...)                              # 判定用旧快照 → 跳过
```

`fetch_stage` 第一句是 `if item["status"] == "done" and not force and not manual_url: 跳过`。
跳过本身是对的，但**跳过的同时把库里的 `done` 改成了 `queued`** —— 下一次投递读到 `queued`，
去重判据再也认不出这件货已经交付过。

| 第几次投递 | 快照里的 status | 结果 | 库里的状态 |
|---|---|---|---|
| 第 1 次（首跑）| `pending` | 正常下载 | `done` |
| 第 2 次 | `done` | 跳过（正确）| 被改成 `queued`（错）|
| 第 3 次 | `queued` | **真的重新下载** | `downloading → done` |

第二条通道是并发：两个重复任务同时读到 `pending`，都会进入下载。
`item_was_done` 这类"把判断结果当参数传进去"的补丁对这条通道无效 —— 两边读到的是同一个 `pending`。

## 2. 修复：两层，都不引入新调度系统

### 2.1 状态保护（顺序）

- `fetch_item` / `parse_item` 里那句抢在阶段函数之前的 `touch_status("queued")` **删掉**。
  "已入队"本来就由 API 投递处写（`routes._queue` / `routes.reparse`），worker 拿到消息时已经在跑了，
  再写一次没有任何信息量，只会踩掉 `done`。
- `fetch_stage` 保持"先判 `done`、再谈其它"，规则**只有一份**（不再往调用方复制一份判据）。

### 2.2 并发保护（竞争）

```python
def _claim_fetch(item_id: int, *, redo: bool) -> int:
    return db.x_count(
        "UPDATE item SET status='resolving', stage=?, progress=5, error='', updated_at=? "
        "WHERE id=? AND ("
        "  status IN ('pending','queued','failed','nodata','skipped')"
        "  OR (status='done' AND ?)"                                  # 人工显式重跑
        "  OR (status IN ('resolving','downloading','parsing','rendering')"
        "      AND (? OR julianday(updated_at) < julianday('now', ?)))"  # 显式重跑 / 租约过期
        ")",
        (...))
```

- **判断和改状态压进同一条 UPDATE**，由 SQLite 行锁保证只有一个任务的 `rowcount == 1`；
  抢不到的直接返回 `skipped/already_running`，**不下载、也不往下游投**（下游投了就是重复调模型）。
- 新增 `db.x_count()`：`x()` 为了兼容 INSERT 会优先返回 `lastrowid`，用它判断条件更新改到几行不可靠。
- **在跑态默认不许抢**：否则一条重复消息会把正在下载的货的状态覆盖掉。
  但 worker 被杀会留下永久 `resolving`，所以加**租约**：`updated_at` 超过 `FETCH_LEASE_SEC`（默认 900s）
  即可重新领取 —— 没有一个新调度系统，只是一个时间戳条件。
- `force` / `manual_url` 是人工显式重跑，**连在跑态都覆盖**。否则点"强制重跑"要等 15 分钟才动，
  操作员会以为按钮坏了。

### 2.3 顺带修掉的两个坑（同一条路上）

| 坑 | 现象 | 处置 |
|---|---|---|
| `run_item` 把 skipped 结果当成功往下走 | 取 `r["pdf"]` → `KeyError` → 被 except 兜底写成 `failed`。**已交付的货显示成失败** | `if not r.get("ok") or r.get("skipped"): return r` |
| `parse_item`（旧全链路入口）| 重复投递 `done` 的件走的就是上面这条崩溃路径，且先把 `done` 踩成 `queued` | 同批去掉前置状态写入，崩溃路径随 `run_item` 一起修掉 |

## 3. A/B 实测（同一套动作，只换 fetch 段那 4 个文件）

环境：Redis DB7（生产 DB0）+ 独立数据根 `/tmp/p16/f61/data_{before,after}` +
`--role fetch -c 2`（**两个线程 = 生产实际的 threads pool 形态**）。真实下载
`https://www.ti.com.cn/lit/ds/symlink/lm317.pdf`（2,578,150 B）。

事件口径：`start` = 真正进 `fetch_stage` 干活，`download` = 真的下到了 PDF，`dedup` = 被判定跳过。

### 阶段 2：`done` 上连投两次（F2/F3/F4）

| | BEFORE（`dce426e^`） | AFTER（`dce426e`） |
|---|---|---|
| 基线 | `done` / `tried_at=16:50:00` | `done` / `tried_at=16:52:09` |
| dup1 | status=**queued** progress=2<br>start=1 download=1 dedup=1 | status=**done** progress=100<br>start=1 download=1 dedup=1 |
| dup2 | status=downloading<br>`tried_at=16:50:32`（变了）mtime 变了<br>**start=2 download=2** | status=**done**<br>`tried_at` 不变 mtime 不变<br>**start=1 download=1** |

BEFORE 的 dup1 就是外审指出的那一行：**跳过了，但把 `done` 改成 `queued`**；dup2 于是真重下了一遍。
AFTER 两次都停在 `done`，`tried_at` / PDF mtime / `parse_count` 一个都没动。

### 阶段 3：并发投递 2 条（F6，关键）

`queued` 起始 + 已存链接（与 `routes._queue` 的真实形态一致），两条消息同时被两个线程取走：

| | BEFORE | AFTER |
|---|---|---|
| 结果 | **start=2 download=2** —— 两条各下了一遍 | **start=1 download=1** |
| 事件 | 无 dedup | `已有任务在执行（resolving），本次重复投递跳过` |

这一条是外审明确点名的"不要拿串行测试冒充并发幂等"。实测在**两个线程、两条独立 sqlite 连接**下，
只有一个任务的 `rowcount == 1`。

### 阶段 4：已交付的货被并发重投 2 条

| | BEFORE | AFTER |
|---|---|---|
| 下载次数 | download 2 → **3**（又下了一遍） | download 1 → **1** |
| 终态 | `downloading`（已交付的货看起来在下载） | **`done`** |

### 证据位置

```
/tmp/p16/f61/log_before.txt   /tmp/p16/f61/log_after.txt     # 逐阶段 state 输出
/tmp/p16/f61/worker_before.log /tmp/p16/f61/worker_after.log  # 两个 worker 的完整日志
/tmp/p16/f61/code_{before,after}/                             # 两侧挂进去的代码（可复跑）
/tmp/p16/f61/f61.sh  /tmp/p16/f61/probe/f61.py                # 编排与探针
```

复跑：`cd /tmp/p16/f61 && ./f61.sh before|after`（自带 flushdb / 清数据根 / 起停容器 / 落日志）。

## 4. F1–F8 验收表

| 测试 | 操作 | 要求 | 本地用例 | 服务器 A/B |
|---|---|---|---|---|
| F1 | `pending` 首次投递 | 正常下载 | ✅ `test_f1_*` | ✅ start=1 download=1 |
| F2 | `done` 第二次投递 | skipped，状态仍 `done` | ✅ `test_f2_*` | ✅ status=done |
| F3 | `done` 第三次投递 | skipped，不重下 | ✅ `test_f3_*`（连投 3 次）| ✅ dup2 不重下 |
| F4 | `done` 重复投递 | `tried_at`/PDF mtime/`parse_count` 不变 | ✅ `test_f4_*`（4 次）| ✅ 全不变 |
| F5 | `manual_url` 投递 | 保留显式重下 | ✅ `test_f5_*` / `test_f5b_*`（force）| 设计未改，`redo` 分支覆盖 |
| F6 | 两条相同任务并发 | 不重复下载、不覆盖状态 | ✅ `test_f6_*` / `test_f6b_*` | ✅ start=1（跨线程）|
| F7 | 下载中异常/重投 | 状态可恢复，不产生永久错态 | ✅ `test_f7_*` / `f7b` / `f7c` | — |
| F8 | 旧任务入口 | 原调用语义不回归 | ✅ `test_f8_*` / `f8b` / `run_item` | — |

补充守卫：

- `test_fetch_item_no_longer_writes_queued_before_stage`：静态守住"顺序"本身，
  防以后有人再在阶段函数之前插一次状态写入。
- `test_x_count_returns_rowcount_not_lastrowid`：守住 CAS 的判据不被 `lastrowid` 顶掉。

**F6 的灵敏度是验证过的**：把 `_claim_fetch` 换回"永远返回 1"的旧行为，同一用例下载 2 次；换回新实现 1 次。
不是"写完就算过了"。

## 5. 19 条失败：逐类核实，不打包成"环境问题"

| 类别 | 条数 | 根因（已核实） | 干净 HEAD 上的复核 | 是否影响真实业务路径 |
|---|---|---|---|---|
| `test_cheatsheet.py` | 11 | 本机缺 `python-multipart`，FastAPI 表单依赖直接 `RuntimeError` | 同样失败（环境级） | **否**：生产容器 `multipart 0.0.33`，`requirements.txt:15` 已声明 |
| `test_bundle_selfcheck.py` | 5 | 工作区**未提交**的并行线改动（`qc/bundle_selfcheck.py` + 新增 `qc/pipeline_stamp.py`） | `git worktree add ... HEAD` 上 **32 passed** | **否**：与 fetch 段零交集，且不进本次提交 |
| `test_qc_analyzer.py` | 2 | 本机缺 `openpyxl` | 同样失败 | **否**：生产容器 `openpyxl 3.1.5`，`requirements.txt:8` 已声明 |
| `test_table_cell_num.py::TestIccRowRealPdf` | 1 | **样本文本漂移**：第 5 页电气表首列实际是 `"I CC"`（空格来自下标切分），断言写的是 `"ICC"` → 找不到行 | 干净树无 `data/pdfs` 样本 → skipped，无法直接对照 | **是，归 QC 侧**：表找到了、ICC 行也在（MIN 列是 `1`），但断言匹配不到 → 这一行的"跨列保护"实际没被测到。**不影响 fetch 段** |

核实手法（可复现）：

```bash
docker exec icpdf-server python -c "import multipart, openpyxl; print(multipart.__version__, openpyxl.__version__)"
# → 0.0.33 3.1.5
git worktree add /tmp/wt HEAD && cd /tmp/wt && python -m pytest tests/test_bundle_selfcheck.py -q
# → 32 passed
python -m pytest "tests/test_table_cell_num.py::TestIccRowRealPdf" -q
# → assert cand, "第 5 页电气表应含 ICC 行"  ← 首列是 "I CC"
```

## 6. 已登记、本轮不修（不要当成已做）

| 项 | 现状 | 归属 / 理由 |
|---|---|---|
| `qc_audit_item` 的 stdout `.buffer` | 老入口同一个坑（Celery 把 `sys.stdout` 换成 `LoggingProxy`），跑在别的路径上还没被触发 | **单独登记**。V2 里是局部兜底，不等于老入口已修 |
| `routes.reparse` 无条件写 `status='queued'` | `force` 默认 True（点击即重跑，符合直觉）；但显式传 `force=false` 时，状态已被改写 → worker 认不出 `done`，会重下 | 窄范围授权不含 route；建议加 `AND status<>'done'`（一行）。本次只登记 |
| `collector.fetch_datasheet` 无 per-mpn 锁 | 现在由 `_claim_fetch` 挡在阶段入口，采集器本身仍不防并发（别的调用方直接调它就绕过了） | 后续阶段；当前调用面只有 `fetch_stage` |
| `fetch` 段未进 `pipeline_stage` | 账仍记在 `item` + `doc_source` | 要重写下载逻辑，属后续阶段 |

## 7. 已知限制（灰度时要盯的）

1. **租约 900s**：一条重复消息若在别人下载中途到达且对方已静默超过 900s，会抢走执行权重下。
   900s 远大于实测最长采集（40s 量级），但如果灰度里出现超长下载，这条要重新评估（`ICPDF_FETCH_LEASE_SEC` 可调）。
2. **`force`/`manual_url` 可覆盖在跑态**：这是刻意保留的人工覆盖权。它不是并发保护的后门 ——
   并发保护针对的是"同一条消息被重复投递"，而 `force` 是人明确点了重跑。
3. **租约依赖 `updated_at`**：判据是 `julianday()`，SQLite 会按时区归一化；
   但若同一库被**时钟不同步的机器**同时写，租约判断会偏。
4. **`already_running` 是"跳过"不是"排队"**：抢不到的那条消息直接终止，不会在对方结束后自动续跑。
   对方失败时状态是 `failed`（可重试），对方的**消息**若已丢失则需要重新投递一次。

## 8. 回归与回滚

- 新增 `tests/test_fetch_dedup.py`：**16 passed**。
- `test_pipeline_wiring.py` 21 + `test_pipeline_stages.py` 70 + 新增 16 = **107 passed**。
- 全量：**19 failed / 1901 passed / 1 skipped**；失败集与修复前逐条相同（见 §5）。
- 回滚：`git revert dce426e` 即可。开关 `ICPDF_PIPELINE_V2` 与本次修复无关（本次两条链共用）。

## 9. 下一步（等裁决）

Phase 1.7 的 3 件受控灰度（芯片 / 板卡 / 异常件各一）观察项不变，另加两条：

- **重复投递计数**：灰度期把 `dedup/already_running` 事件数打出来。非零说明队列侧确实有重复投递，
  正好验证这次修的不是假问题；
- **`tried_at` 是否出现与 `parse_count` 不匹配的增长**：`tried_at` 变了但 `parse_count` 没变 =
  下载重来过而模型没重跑（说明有重复下载），这是灰度里最容易发现"还有第三处状态写入"的信号。
