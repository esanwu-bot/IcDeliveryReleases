# Phase 1.7 灰度样本 3/3 · 异常件（DAC8568EVM User's Guide）

**日期**：2026-11-03 · **代码**：`origin/main@d6fc276`
**隔离**：Redis DB8 · `/tmp/p17/data_s3` · 容器 `p17-s3-*`
**冻结样本**：MPN `DAC8568EVM` · `https://www.ti.com/lit/ug/slau301/slau301.pdf`
`sha256=a7e7253da4b38490f8ec548d76c33a20cedd80bca031318fd4ccbfea503afe45` · 266,384 B · 10 页
`is_datasheet=False`（正文首页 `User's Guide / SLAU301`）

## 结论

**PASS** —— 异常语义正确：preprocess 判 `skipped` 并终止，**没有调用模型**、**没有进入
llm/audit/render**、**没有伪造成 `done`**。这是三件里唯一内容层也完全符合预期的一件。

## 1. 时间线与任务事件

| 段 | 结果 | 耗时 | 说明 |
|---|---|---|---|
| fetch | ok | — | `manual` 266,384 B，sha `a7e7253d…` |
| preprocess | **skipped** | 1,319ms | `NOT_A_DATASHEET: 无参数表特征词（User Guide / Quick Start），跳过 LLM` |
| llm / audit / render | **未执行** | — | 无阶段账行、无队列消息 |

事件流（完整）：

```
start:    开始处理 DAC8568EVM
download: PDF 就绪：manual 260 KB
stage:    文本切片完成：skipped 1319ms
skip:     文本切片终止：skipped
```

`item.status=skipped` / `progress=100` / `parse_count=0` / `parse_ms=0`。

## 2. 指标

| 指标 | 值 |
|---|---|
| `start` / `download` | **1 / 1** |
| `dedup` / `already_running` | 0 / 0 |
| `tried_at` | `2026-11-03T17:45:25+08:00`（单次）|
| `parse_count` | **0**（未调模型）|
| `llm_usage` | 0 行 |
| 阶段账 | 仅 `preprocess` 一行（`attempts=1, status=skipped`）|
| 产物 | 仅 PDF（266,384 B）；`json_path` / `txt_path` / `symbol_path` 均空 |
| audit findings | 无（未进入 audit）|
| 正式数据副作用 | 无（见 §4）|

## 3. 冻结预期核对

| 断言 | 冻结预期 | 实测 | 判定 |
|---|---|---|---|
| preprocess 状态 | `skipped` + 原因 | `skipped` + NOT_A_DATASHEET | ✅ |
| `item.status` | `skipped`（终态）| `skipped` / progress 100 | ✅ |
| 下游阶段 | 无 llm/audit/render | 无 | ✅ |
| `parse_count` | 0 | 0 | ✅ |
| `llm_usage` | 0 行 | 0 行 | ✅ |
| 产物 | 只有 PDF + 切片 | 只有 PDF（切片在 `data_s3/slices/`）| ✅ |

## 4. 正式数据副作用

同前两件：生产 `data/parsed` 指纹、生产库 sha/大小、生产容器重启次数全部未变。

## 5. 证据位置

```
/tmp/p17/s3.json        /tmp/p17/log_s3-*.log        /tmp/p17/data_s3/
```

## 6. 人工审核结论

异常状态语义正确：**`skipped` 不是 `done`**，且没有为「看起来跑完」而调用模型。
本件通过；它同时证明 `preprocess` 的 `is_datasheet` 判据在 V2 下与 legacy 同源。
