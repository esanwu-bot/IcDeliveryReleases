# batch20 重解析冒烟 + 13k 产线策略（2026-11-02）

> 结论先行：**工作台漏包已修好**（V3.1 已置顶、自证链 42/42 PASS）。
> **batch20 重解析冒烟尚未跑完，但已经出现一个重要负面信号**：
> thermal / esd 的补齐并非「重解析必然长出」——已完成的 3 件成功解析里只有
> **1 件**（ADC12DJ5200SE）长出 thermal=5 / esd=2，另 1 件（ADS1286U）仍是 0/0。
> 因此**现在还不具备 13k 全量重解析的放行条件**，先修 thermal/esd 抽取，再放量。

## 一、工作台漏包（已修复，实测）

| 环节 | 事实 | 处置 |
| --- | --- | --- |
| 物理文件 | 服务器 `data/` 下**没有** `delivery-20261102-V3.1`（包只在本地与 GitHub 发布仓库） | 服务器从 GitHub 稀疏拉取（`--filter=blob:none --sparse`，27 MB）落到 `data/` |
| 扫描代码 | 服务器 HEAD `de84666` 仍是旧正则 `-V(\d+)`，`_VERSION_RE` 也只认整数 | 本地 `4e0d1fd` 经增量 bundle（69 KB）→ `fetch` → `merge --ff-only` |
| 服务进程 | 容器内跑的是旧镜像 | `docker compose -f deploy/docker-compose.yml build server` + `up -d server` |

容器内实测（`qc.delivery_history.list_batches()`）：

```
共 459 个批次；前 4 条（按 date/version 倒序）：
  delivery-20261102-V3.1     version=3.1   gen=gen3  gate=PASS   verdict=PASS
  delivery-20261102-V3       version=3     gen=gen3  gate=PASS   verdict=PASS
  delivery-20261102-V2       version=2     gen=gen3  gate=PASS   verdict=PASS
  delivery-20261101-V10      version=10    gen=gen3  gate=PASS   verdict=PASS

V3.1 明细：
  verdict     : PASS | 包内自检 42 项全绿（自证链逐项重算）
  zip         : part-0001-of-0001.zip 12116587 B
  zip_sha256  : 02eb787fc1052f6cc18525f0c7455ee15712572c4239e8aa45fca7b4d14c9825
  mpns        : 5 (ADC12DJ5200SE, ADS1201U-1/1K, ADS8568EVM-PDK, BOOST-DRV8711, BOOSTXL-C2KLED)
  release     : NOT_CHECKED {PACKAGE_PASS: PASS, PROVENANCE_PASS: PASS,
                DATA_SEMANTICS_PASS: PASS, DOWNSTREAM_PASS: NOT_CHECKED,
                RELEASE_APPROVED: NOT_CHECKED}
```

`release=NOT_CHECKED` 与元宝结论一致：**数据三类门禁 PASS，人工签核尚未落库**（§2.2 人工专属红线）。

## 二、batch20 重解析冒烟（进行中，已完成 6/20）

> **⚠️ 2026-11-02 追加纠正（文本层取证后）**：初版把「thermal 0→0」一律当缺陷，
> 这是**错判**。逐件读 PDF 文本层后确认：
> - `ADS1286U`（13 页 / 23,103 字符）**没有** `Thermal Information` / `RθJA` /
>   `ESD Ratings` / `°C/W` 任何一处 → 0/0 是**正确结果**（老 TI datasheet 不印这两张表）；
> - `BQ48SH-28X6NSH` 全文无 thermal/esd 词 → 同理合法为空；
> - `ADC12QJ1600ALREP`（151 页）有这两张表，确定性抽取**成功**产出 thermal=3 / esd=2，
>   但模型电气表为空 → 真缺陷在**模型侧**，不在抽取侧。
>
> 结论修正：**「重解析必然补齐 thermal/esd」不成立，但原因分两类**——
> 一类是源文档没有（不可补齐，也不该伪造）；一类是模型空表/非法 JSON（必须守住）。
> 因此禁止把「每件必须长出 thermal+esd」写成验收线：对源文档无表的件，那等于要求编造。

命令（服务器容器内，隔离输出，绝不碰 `data/parsed`）：

```
docker run --rm --cpus=3 --memory=4g --env-file deploy/.env \
  -v /root/_batch20_v3/stage/src_pdfs:/pdfs:ro \
  -v /root/_b20_reparse:/app/data/_b20_reparse -w /app icpdf/app:latest \
  python3 parse_datasheets.py --dir /pdfs \
  --out-dir /app/data/_b20_reparse/parsed --workers 2 --backend dashscope
```

已完成件（实测，逐件日志）：

| 型号 | 耗时 | 结果 | thermal | esd | elec | pins |
| --- | --- | --- | --- | --- | --- | --- |
| ADC12DJ5200SE | 432.8s | OK conf=0.95 | **0 → 5** | **0 → 2** | 18 → 23 | 144 |
| ADS1286U | 99.9s | OK conf=0.95 | **0 → 0** | **0 → 0** | 57 → 47 | 8 |
| 74FCT16244CTPVCTG4 | 126.3s | OK conf=0.85，但电气为空、MPN 误读为 `74FCT162244CTPVCT` | 0 → 0 | 0 → 0 | 19 → 0 | 0 |
| ADC12QJ1600-SP | 256.1s | **PARSE_FAILED: invalid_json** | — | — | — | — |
| ADS7815UE4 | 147.9s | **AttributeError: 'str' object has no attribute 'get'** | — | — | — | — |
| ADC12QJ1600ALREP | 318.3s | `OK` 但 conf=0.0 / 电气为空 | 0 → 0 | 0 → 0 | 12 → 0 | 0 |

**6 次尝试的真实分布（截至本段）**：
- 真正拿到「非空电气」的只有 **2/6**（ADC12DJ5200SE、ADS1286U）；
- 真正长出 thermal/esd 的只有 **1/6**（ADC12DJ5200SE）；
- 硬失败 **2/6**（`invalid_json`、`AttributeError`），空产物 **2/6**（电气整表为空）。

### 对 13k 的三个结论（必须先解决，再谈放量）

1. **「重解析 = thermal/esd 必然补齐」不成立。** `ADS1286U` 重解析后仍是 0/0 ——
   说明瓶颈不在「老 JSON 没有这个键」，而在**抽取侧没取到 Thermal Information / ESD Ratings 页**
   （`parse_datasheets.py` 的 thermal/esd 走确定性抽取，模型不参与）。
   放量前必须先用这 20 件定位：是选页没选中、还是表头识别失败、还是表格解析失败。
2. **模型侧失败率不低。** 4 件里 1 件 `invalid_json`（256s 白跑）、1 件电气整表为空
   （还把 MPN 读错一位）。13k 放量前必须补齐 **JSON 校验失败重试 + 空电气拒收**，
   否则重解析会把「可用的旧数据」换成「空的坏数据」——这是比不重解析更坏的结果。
3. **成本量级（实测外推）**：单件 100–430s（含重试），2 workers 有效吞吐约
   **6–10 件/小时**。13,504 件 → **1,350–2,250 机时**；按 8 核并行 4 workers 估
   **17–28 天**，按 16 并发（需先压测 429）估 **9–14 天**。
   当前吞吐**不足以支撑「今天跑 13k」**。

## 三、产线门禁调整（方案，待评审后实现）

### 3.1 `anchor_gate` 从「唯一红线」改为分级指标

现状：`anchor_gate=pass` 要求**每一条**有数值的参数都达到自身载体的门槛；V10 千件样本
实测通过率 **0.7%**。把它当产线红线，等于 99% 型号不能交付。

建议（三层，全部可机器计算，不改证据口径）：

| 层 | 指标 | 判据 | 处置 |
| --- | --- | --- | --- |
| **核心闸门** | `core_anchor_gate` | `specs.electrical` + `absolute_max` 里**表格类**参数，必须达 `row_anchor` | 不达标 → 阻断该型号（真红线） |
| **外围指标** | `peripheral_anchor_ratio` | 其余容器（`thermal` / `esd` / `ac_performance` / 板载桶）达各自门槛的比例 | 低于阈值（建议 0.6）→ 该型号进 `risk_queue` 人工复核，**不阻断** |
| **完整度** | `anchor_gate`（保留原义） | 全量逐行达标 | 只作「可宣称完整验收」的标志，不作用于发布 |

实现要点：
- 复用 `qc/fact_acceptance.py::gate_summary()` 既有 `kind`（table / prose）判据，
  **不新增第二套证据规则**（§10.3 单一事实源）；
- 新增字段写入 manifest（`core_anchor_gate` / `peripheral_anchor_ratio`），`anchor_gate` 原值保留，
  `release_state` 仍只认 `anchor_gate`（即：**分级不放松 `DATA_VALIDATED`，只放松「能不能发布」**）；
- 新增单测：核心表格行 blocked → `core_anchor_gate=blocked`；只有外围弱证据 →
  `peripheral_anchor_ratio<1` 但 `core_anchor_gate=pass`，型号可进 `review_candidate`。

### 3.2 `not_found` 永久不许自动排除（V7 假阴性教训）

现状核对（`qc/fact_acceptance.py`）：`not_found` 只进 `risk_queue.csv`，`suggested_action`
是人工队列动作；代码中**没有**任何按 `not_found` 删除/排除参数的路径（本轮实测确认）。
为防止未来回退，建议加一条硬断言测试：

- 造一份含 `not_found` 行的 fixture，跑 `main()` 后断言：JSON 条目数不变、参数未被删除、
  `risk_queue.csv` 出现该行且 `suggested_action` 属于人工复核类；
- 断言 `verdict=fail` 只作用于**报告**，不作用于**数据处置**。

## 四、下一步（按优先级）

1. **修 thermal/esd 抽取**（先这 20 件定位选页/表头/解析三个环节），达标线：
   ≥ 80% 的件重解析后 thermal 与 esd 至少各 1 行。
2. **补失败重试与空电气拒收**（invalid_json 重试 1 次；`electrical==0` 且 `features<3` 判解析失败，不落盘）。
3. 上述两项达标后再放量：先 200 件灰度（4 并发）→ 对比 `thermal/esd 补齐率` 与
   `gate=UNRESOLVED 占比` → 再决定 13k 分批（每批 ≤ 500 件、每批独立 staging）。
4. 分级门禁实现与单测（可与第 1 项并行，互不改写同一文件）。

## 五、本次实测产物位置

- 重解析输出（隔离目录，未进生产）：`/root/_b20_reparse/parsed/`、日志 `/root/_b20_reparse/run.log`
- 旧基线：`/root/_batch20_v3/stage/parsed`（20 件，thermal/esd 全 0）
- 统计脚本（服务器 `/tmp`）：`b20_stats.py`
