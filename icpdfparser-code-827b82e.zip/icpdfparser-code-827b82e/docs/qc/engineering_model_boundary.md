# 符号页「工程模型边界」：状态字典 · 文案映射 · 门禁清单

> 一句话：符号页的三件产物（原理图符号 / 封装轮廓 2D / 3D 球阵几何）各自有独立状态，
> 状态由 `qc/engineering_model.py::derive_state` 从既有事实**派生**（不落库），
> 文案只由 `render_notes` 生成，页面由 `check` 的 A1–A5 断言。
> 旧的「封装/3D 两卡各印一遍『几何与视角未核验』」已删除。

代码：`qc/engineering_model.py`（derive_state / render_notes / panel_captions / check）
渲染：`symbol_svg.py::render_page`（唯一入口，worker 与 CLI 都走它）
门禁：`app/services/review.py::_rule_engineering_model`（规则层，零 token）

---

## 1. 状态枚举

### 1.1 `symbol`（原理图符号）

| 状态 | 含义 | 触发条件 |
| --- | --- | --- |
| `pass` | 球位映射已核验且仍然完整 | `metadata.pin_validation.status=pass` **且** `expected_balls == covered_balls == pin_configuration` 且条数一致 |
| `fail` | 映射校验明确失败 | `status=fail` |
| `not_checked` | 未核验 / 缺失 / 非法 / 板卡主体 | 其余全部（fail-closed） |

非 BGA、又没有 `pin_validation` 的芯片（如 BUF634PG4）→ `not_checked`。本轮不给它
造一个「看起来核验过」的状态：符号真值链是 `pin_validation`，缺就是缺。

### 1.2 `package_outline`（封装轮廓 2D）

| 状态 | 含义 | 触发条件 |
| --- | --- | --- |
| `template` | 命中签核共享轮廓 | `data/pkgs/index.csv` 命中 key（`canon_pkg` 归一）**且** `{key}.svg` 存在**且**非网格族 |
| `not_checked` | 未绘制 / 无签核模板 | 索引未命中、文件缺失、封装名缺失、网格族（见 §4.1）、**脚数未确认** |
| `not_applicable` | 板卡/模块件不适用 | `identity ∈ {evaluation_board, development_kit}`，或渲染器已按 `_is_board_name` 进入板卡页 |

`template_sha256` 在读取模板文件时**现算**（`index.csv` 没有版本列，也不该有）。

### 1.3 `geometry_3d`（3D / 球阵几何）

| 状态 | 含义 | 触发条件 |
| --- | --- | --- |
| `not_generated` | 未生成，`reason=no_trusted_source` | 本轮默认；`required_source=机械 CAD（STEP/IBIS）或原厂球阵图` |
| `generated` | 有可信来源 | 仅当调用方传入 `source_hash`（本轮无此类调用方） |
| `not_applicable` | 板卡/模块件不适用 | 同 outline |

---

## 2. 文案映射（唯一事实源：`render_notes`）

| 状态 | 文案 |
| --- | --- |
| outline=`template` | 封装轮廓按共享模板 `{template_id}` 绘制（内容哈希 `{sha[:8]}`）；模板为共享轮廓，不含球阵坐标。 |
| outline=`not_checked` | 封装轮廓未绘制：该封装在库中无签核共享模板。 |
| outline/3d=`not_applicable` | 板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。（两组只印一次） |
| 3d=`not_generated` | 3D 模型与球阵几何未生成：无可信来源（机械 CAD（STEP/IBIS）或原厂球阵图），不猜测。 |
| 3d=`generated` | 无文案（画出来了就没有边界要声明）。 |

- 顺序固定：先轮廓、后 3D；同句去重。
- 渲染器**禁止**手写这些字样；`tests/test_engineering_model.py::test_renderer_has_no_handwritten_boundary_text`
  扫 `symbol_svg.py` 源码守住这一条。
- 卡片副标题（`panel_captions`）只给「非默认臂」短标签，其余沿用渲染器默认文案：

  | 状态 | 副标题 |
  | --- | --- |
  | outline=`not_checked` | `轮廓未绘制` |
  | outline=`not_applicable` | `不适用` |
  | 3d=`not_generated`（无示意图，如 BGA） | `未生成` |
  | 3d=`not_applicable` | `不适用` |
  | 3d=`not_generated`（**有**内联/共享示意图） | `示意（按封装类型程序化绘制）` |

  最后一行是 7725 页批量测量时补的：旧副标题 `按封装类型程序化绘制` 与标题连起来读作
  「3D 模型 · 按封装类型程序化绘制」，而同一页的边界小节写着「3D 模型与球阵几何未生成」——
  **两句话在同一个页面上打架**。图是插图，就该在副标题里说「示意」。

- **卡内图形文字 ≠ 边界断言**：卡片**副标题**由 `panel_captions` 派生；卡内图形里的说明文字
  由渲染器写，但它只能描述「这一格是什么」，不得下结论 —— 不写「未核验/待核」、
  不含数值+单位、不打 `data-em-geometry`。BGA 占位图曾经两张卡画同一张图、印同一句话
  （那句的主语还是「封装几何」，却挂在 3D 格上），等于一条断言在页面上印三遍；现已改成
  `_bga_placeholder(pkg, role)`：封装卡说「封装占位图」、3D 卡说「3D 占位图」，
  理由一律指向下方小节。`tests/test_engineering_model.py` §8 三条守住这一点。

---

## 3. 门禁 A1–A5

只对带 `data-em-page="symbols"` 的页面断言（旧页面是旧文案+旧状态的组合，重渲染前逐条报没有意义）。

| 编号 | kind | 判据 | 严重度 |
| --- | --- | --- | --- |
| A1 | `symbol_page_geometry_unsupported` | 页面可见文本出现「pitch/间距/球径/高度/厚度/视角/尺寸 + 数值+单位(mm/µm/°…)」，但 outline≠template 且 3d≠generated | P1 |
| A2 | `symbol_page_3d_node_without_state` | 3d≠generated，页面却含 `data-em-geometry="3d"/"ball-grid"` 节点，或引用了**不是本件自己封装 key** 的 `.3d.svg` | P1 |
| A3 | `symbol_page_outline_text_conflict` | outline=template，页面仍在「封装/轮廓/外形」附近印「未核验/未验证/待核」 | P1 |
| A4 | `symbol_page_board_state_mismatch` | 板卡身份（或页面自述 `data-em-subject="board"`）但状态非 not_applicable；或板卡页出现芯片几何文案 | P0（身份）/ P1（页面-状态） |
| A5 | `symbol_page_boundary_text_drift` | 缺「工程模型边界」小节，或小节逐条文案 ≠ `render_notes(state)` | P1 |

几何节点标记（A2 依据，渲染器本轮不产出）：

```html
<svg data-em-geometry="3d">…</svg>        <!-- 3D 工程几何 -->
<svg data-em-geometry="ball-grid">…</svg> <!-- 球阵几何 -->
```

新增任何几何渲染必须同步打标记，否则 A2 抓不到（已知边界，见 §5）。

**A2 曾经用「页面出现 3D 模型 / 球阵字样」兜底，两次都错**，已删除：

1. 芯片页 3D 卡里印的是 `… · 3D 示意`（插图，不是模型）→ 所有非模板臂页面恒报；
2. 模板臂说明句 `封装轮廓按共享模板 … 不含球阵坐标` 也命中「球阵」→ 模板臂页面恒报。

文本里区分「声称有」和「说明没有」需要语义理解，正则做不到。判据只留结构证据：
几何标记 + 3D 图引用是否属于本件自己的封装（`template_id` 或 `package_key`）。

**页面自述主体**（A4/A5 依据）：`data-em-subject="board"` 与 `data-em-pins="unconfirmed"`
分别对应渲染器的 `board_subject=True` / `pins_unconfirmed=True` 分支。审查侧必须用
`derive_state_for_page(doc, pkgs_dir, page)` 派生状态，而不是 `derive_state(doc, pkgs_dir)`——
否则同一份文档会算出两份状态（实测 7725 页里 77 页 A5 + 9 页 A4 假阳，全是 `*_NOPB` /
`*EVM` 这类**没有 identity 字段**的评估板）。

kind 注册：`qc/finding_kinds.py::ENGINEERING_KINDS`（独立来源 `engineering_model`，
由 AST 扫描 `qc/engineering_model.py::_finding` 校验）；消费侧
`worker/tasks.py::ACTION_TEMPLATES` 全为 `manual_review`（先定状态来源，不能自动改文案），
`_KIND_CATEGORY=RENDER_ASSET`。

---

## 4. 实测事实（2026-10-30）

### 4.1 `data/pkgs` 索引与模板

`index.csv` 599 行（含 1 行表头），列：`key,family,pins,n_models,raw_types,sample_models,footprint,model3d`。
**没有签核/版本列**，所以「签核」只能靠「索引命中 + 文件存在 + 内容哈希」表达。

| 封装 | 索引命中 | 模板文件 | 本模块判定 | 原因 |
| --- | --- | --- | --- | --- |
| `FCBGA-144` | 是 | `FCBGA-144.svg` (8586 B, sha `d6b538f8…`) | **not_checked** | 网格族：该文件由 `_grid_svg` 按 `ceil(sqrt(144))=12` 生成 12×12 圆点，球间距/球径全是程序算的典型值，不是签核轮廓 |
| `SOIC-16` | 是 | `SOIC-16.svg` (sha `c104dedc…`) | template | 两侧轮廓 + 焊盘，标准 JEDEC |
| `TSSOP-16` | 是 | `TSSOP-16.svg` (sha `35a39ed3…`) | template | 同上 |
| `SOIC-8` | 是 | `SOIC-8.svg` (sha `fe2ee720…`) | template | 同上 |
| `PDIP-8` | 是 | `PDIP-8.svg` | template | 同上（本轮无此件样本） |
| `Evaluation Board` | 否（`PCB-UNK`） | — | not_applicable | 板卡身份 |

### 4.2 生产数据断层（重要）

`data/parsed` 下 8990 份 JSON **全部**没有 `metadata.pin_validation`、也没有
`basic_info.identity`（`identity=None` 8990/8990）；有 BGA 封装 591 份，`pin_validation=pass` **0** 份。
契约字段只存在于 `data/staging_20261030_fixed/parsed`（5 件）等新产物里。

后果与处置：

- 用 `data/parsed` 渲染时，本模块一律 fail-closed（`not_checked` / `not_generated`）——
  这是**正确**的：那份 JSON 里确实没有核验证据。
- 板卡件在旧库里没有 identity，只能靠 `_is_board_name` 走板卡页；此时渲染器显式传
  `board_subject=True` 记录「本页已按板卡渲染」，状态随之 `not_applicable`，不出现
  「页说板卡、状态说缺模板」的自相矛盾页。
- 存量 `data/symbols/*.html`（7725 份，多为 10-22/10-23 产出）没有页面标记，
  不受 A1–A5 约束；重渲染后自动纳入。

---

## 5. 已知边界与后续

1. **A2 依赖标记**：几何渲染必须打 `data-em-geometry`，否则门禁看不见。
   兜底只覆盖 aria-label 与 `.3d.svg` 引用。
2. **BGA 模板臂关闭**：要有带球坐标签核的来源（原厂球阵图 / 机械 CAD）才能升
   `template`；在那之前 ADC12DJ5200SE 的轮廓状态就是 `not_checked`。
3. ~~**BGA 占位图仍印「封装几何未核验」**~~ → **已修（2026-10-31）**：两卡原来画同一张图、
   印同一句话，现在按卡分工（封装卡「封装占位图」/ 3D 卡「3D 占位图」），卡内不复述断言，
   理由指向边界小节。顺带查清：这条代码路径在生产数据上**一次都走不到** ——
   `data/parsed` 591 件 BGA 的 `pin_validation=pass` 是 **0** 件，BGA 全部先短落到
   「BGA 球位待核」说明页（`_bga_unverified_page`），只有 staging 的 `ADC12DJ5200SE` 走得到。
   所以本次是**代码一致性修复，生产页面零改动**（`git status data/symbols` 干净）。
4. **模板页仍有共享 3D 示意图**，而状态是 `not_generated`：示意图按约定不是工程模型
   （aria-label 自带「3D 示意」），小节文案说的是「工程几何未生成」。若客户侧仍嫌歧义，
   应新建一个「示意 vs 工程模型」的枚举，而不是在文案上打补丁。
5. **脚数未确认时模板臂关闭**（`pins_unconfirmed=True`）：渲染器 `uncertain_pins` 分支按
   封装族典型脚数猜 key，此时 key 本身不可信；若仍报 template，文案会声称「按共享模板绘制」
   而页面其实是内联绘制。属 fail-closed，`evidence.reason=pin_count_unconfirmed`。
6. **CLI 未传 `--pkg-lib`** 时状态仍是「无签核共享模板」（文案只有那几句），
   但 `evidence.reason` 会区分 `template_library_not_provided` 与 `template_not_indexed`，
   排查时别把「没加载库」当成「库里没有」。生产链路（worker / `app/cli.py`）都传 `config.PKGS`。
7. **非 BGA 芯片没有 `pin_validation`**：`symbol` 恒 `not_checked`。若要把非 BGA 也纳入，
   需要定义「数字脚号引脚表」的核验形态，属新判据，另行授权。
