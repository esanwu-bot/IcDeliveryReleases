# 上划线代际差异的规模：2029 件，占 `not_ok` 的 96.7%

> 2026-10-31 · 只读测量，未改生产
> 复现：`python qc/symbols_overbar_scan.py --json .sandbox/rr_v6.json --out .sandbox/overbar_scan.json`

## 一、为什么突然要算这个

第一批 97 页覆盖时，156 件里拦下 59 件。其中 49 件的差异是「符号块只多了一笔
`<line stroke="#1f6f5c" stroke-width="1.4">`」—— 低有效引脚的上划线。

49 件只是**「旧封装副标题」这一个筛子**捞到的交集，不是上划线现象的全量。
要判断这批怎么合入，先得知道全库到底有多少件是这个形态。

## 二、判据：三条同时成立，逐字节，不看相似度

| # | 条件 | 挡住了什么 |
|---|---|---|
| 1 | 新旧两侧都有 `schematic symbol` 块 | `no_anchor` 的说明页（空真）不混进来 |
| 2 | 旧块里的 `<line>` 一条都没少 | 「删线 + 加线」的混合改动 |
| 3 | 把新增的 `<line>` 从新块删掉后，新块与旧块 **逐字节相同** | 「上划线加了、别处也动了」 |

用 `difflib` 相似度会放过第 3 类：0.98 的相似度里可能藏着一条坐标变化。

**踩过的坑**：第一版只删 `<line/>` 标签、没删它独占的那一行换行，剥离结果永远比旧块
多一个 `\n`，于是 **2030 件「纯上划线」全被判成 `overbar_plus_other`**，结论差点变成
「几乎没有纯上划线的件」。已写进 `tests/test_symbols_overbar_scan.py` 钉住。

## 三、全库分解：`symbol_drift` 2463 件

| 分类 | 件数 | 含义 | 能不能批量 |
|---|---|---|---|
| `overbar_only` | **2029** | 只多低有效引脚上划线，剥离后逐字节复原 | 可以，但要按批 |
| `no_symbol_block` | 414 | 两侧都没有原理图符号块（说明页） | 与本议题无关 |
| `no_line_delta` | 16 | 差异不在线上：符号里的型号/引脚名变了（如旧页 `SN74LVC1G3157-Q1` → 新页 `1P1G3157QDBVRQ1`） | `mpn_renamed` 家族，逐件 |
| `line_removed` | 2 | 少了一条线：`551013277-001_NOPB`、`DRV81004-Q1EVM` | 不许批量 |
| `line_added_not_overbar` | 1 | `LM317`：加了线但不是上划线 | 不许批量 |
| `overbar_plus_other` | 1 | `AM26C32IDG4`：加了上划线，还改了别的 | 不许批量 |

## 四、这 2029 件的成色

- **状态全部是 `not_ok`**，没有一件落在 `collapse` / `downgrade` / `mpn_mismatch`；
- **可见文本零差异**：2029/2029 的 `n_removed_extra = n_added_extra = 0`；
- **边界小节全部正确**：`boundary_ok` 2029/2029；
- **门禁 findings 只有 1 件**（`8405601CA`，属 A2 家族）；
- 上划线合计 **4246 笔**，每件中位数 2 笔；75% 的件 ≤ 2 笔，最多 26 笔，≥10 笔的只有 22 件。

**这意味着**：这 2029 件除了「符号块多了上划线」之外，其它判据本来就全绿。
若把 `overbar_only` 认作符号通过，`not_ok` 会从 **2099 掉到 71**（2028 件放行，`8405601CA`
仍被 findings 拦）。

## 五、上划线本身对不对：抽样 10/10 命中

取 6 件（≤2 笔）共 10 笔，按文档顺序找上划线前一个 `<text>`，比对
`symbol_svg.active_low_of(doc)`：

| 件 | 上划线归属 | 在低有效集合 |
|---|---|---|
| `1P1G125QDCKRG4Q1` | `OE` | ✔ |
| `1P1G125QDCKRQ1` | `OE` | ✔ |
| `5962-8681201EA` | `1OE` / `2OE` | ✔ ✔ |
| `5962-86839012A` | `1OE` / `2OE` | ✔ ✔ |
| `5962-8683901SA` | `1OE` / `2OE` | ✔ ✔ |
| `5962-8768301FA` | `1G` / `2G` | ✔ ✔ |

`active_low_of` 的三个来源（显式 `active_low` 字段 > 名称前缀 `~INT`/`/INT` > 描述里的
"Active Low"），所以这一笔是**从 PDF 证据推出来的**，不是猜的。它是正确性修复，
不是渲染回归 —— 但**仍然是图形变化**，不该混在文案批次里静默发生。

## 六、建议（等你拍板）

1. **单独立项，按批推进**：2029 件 > 1000，属渲染器代际对齐。建议每批 500 件，
   走同一套 `--only` 闸门（整批拒绝、空交集拒写），每批一份 manifest + 一份备份。
2. **每批先看图再写盘**：`≥3 笔` 的 498 件（含 26 笔那种）先抽 20 件出截图人工确认
   上划线位置；`≤2 笔` 的 1531 件可以靠机器判据直接走。
3. **不要开「overbar 例外」后门**：宁可把 `overbar_only` 作为**显式判据**写进 `decide`
   （例如 `symbol_ok = symbol_same or no_anchor or overbar_only`），也不要塞进 allowlist。
   前者可测、可回归；后者是一条没人复核的旁路。
4. `line_removed` 2 件、`line_added_not_overbar` 1 件、`overbar_plus_other` 1 件，
   共 4 件单独人看，永远不进批量。

## 七、附带产物：`symbol_status` 三态字段

`symbol_same=False` 以前同时代表「图真的变了」和「这页本来就没图」，读报表要靠
`no_anchor` 二次推断，漏看一次就把 414 件说明页当成图被破坏。

新增 `symbol_status ∈ {same, no_anchor, diff}`，`symbol_same` 语义不动：

| `symbol_same` | `no_anchor` | `symbol_status` |
|---|---|---|
| `True` | `False` | `same` |
| `*` | `True` | `no_anchor` |
| `False` | `False` | `diff` |

`_summarize` 输出 `symbol_status` 计数，apply 的 `manifest.json` 逐件记该字段。
`decide` 口径未变（`symbol_same or no_anchor`），所以这次改动对生产零影响。
