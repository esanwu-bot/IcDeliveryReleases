# 1102-V3 弱证据定点清除：before / after 页面证据

## 场景与采集口径

- 同一渲染器（`json_to_txt.render(doc, "en")`）、同一语言（en）、同一字段口径。
- **before** = V2 交付包内 JSON（`delivery-20261102-V2/part-0001-of-0001`）；
  **after** = V3 staging 重渲染（`data/staging_20261102_v3/parsed` + 2026-11-02
  授权的 ADS8568 两条语义错名改名；已挂 `facts_verdicts.json`）。
- 本目录提交的是**实际渲染出的 HTML**，不是 mockup。执行环境没有 headless
  browser / HTML→PNG 工具，因此没有截图；下面的文本片段与计数均从这两个
  HTML 文件直接提取（`grep`/Python 计数），复核方可打开 HTML 对同一处。

## ADS8568EVM-PDK：THD / SNR 从误杀中平反

| 证据 | before（V2） | after（V3） |
| --- | --- | --- |
| `Total Harmonic Distortion` 在页面出现 | 0 次 | 1 次 |
| `Signal-to-Noise Ratio` 在页面出现 | 0 次 | 1 次 |
| `Spurious-Free` / `Channel-to-Channel` | 0 / 0 次 | 0 / 0 次（仍在隔离桶） |
| 电气表 † 行 | —（4 条全扣） | 0 条 |
| 语义错名行 | `Input Common-Mode Voltage (RANGE bit=0/1)` | `Bipolar Full-Scale Range (RANGE bit=0/1)`（p10 原表名） |

after 的实际片段（`after_ads8568.html`）：

```html
<td>Signal-to-Noise Ratio (SNR)</td>
<td>91.5 dB</td>
<td>At fIN = 10 kHz</td>
...
<td>Total Harmonic Distortion (THD)</td>
<td>-94 dB</td>
<td>At fIN = 10 kHz</td>
```

`facts_audit.csv` 对应行：

- `Signal-to-Noise Ratio (SNR)`：`verified_paragraph` / `paragraph_anchor`，
  bbox `[83.9, 257.3, 250.7, 290.7]`，`paragraph_sha256=4616f050…`（p1 汇总段落）。
- `Total Harmonic Distortion (THD)`：`verified_row` / `row_anchor`，
  bbox `[102.3, 443.9, 509.4, 456.6]`，`row_sha256=782f30c5…`（p15 行带）。

after 页面中 `Bipolar Full-Scale Range (RANGE bit=0/1)` 各出现 1 次，
`Input Common-Mode Voltage` 出现 0 次；两条 `audited_row_anchored`，
bbox `[54.1,147.4,557.7,159.6]` / `[54.1,159.6,557.7,171.9]`，
`row_sha256=a1a936ad…` / `00f570a6…`。

**仍 withheld**：`Spurious-Free Dynamic Range (SFDR)` 与
`Channel-to-Channel Isolation` 在 V11 事实表里就是 `value_on_label_page`，
没有独立坐标；隔离理由已改为「事实表未取得独立坐标（bbox）」，不再笼统写
「没有证据 / 疑似复制」。页面只披露 withheld 计数，不印这两条。

## ADS1201U-1/1K：3 条未达门槛项清零

| 行 | before（V2） | after（V3） |
| --- | --- | --- |
| `Differential Input Voltage Range (With VBIAS)` | `verified_value` / coord（缺 min/max） | `verified_row` / row_anchor |
| `Analog Input: Current` | `value_on_label_page` / weak | `verified_paragraph` / paragraph_anchor |
| `Analog Input: Voltage` | `value_on_label_page` / weak | `verified_paragraph` / paragraph_anchor |

页面 † 计数：before 6（含 2 条 `unchecked` 的 Offset/Gain、2 条 amax、
以及表头/说明句里的 2 个 † 字符）→ after 3（同一句说明 + 2 条 `unchecked`）。
`after_ads1201u.html` 中 `Analog Input: Current` / `Analog Input: Voltage`
两行已不再带 †；`Differential Input Voltage Range` 也不再降级为坐标级。

## 不能声称的部分

- 截图缺失（环境无浏览器/HTML→PNG），本目录只交实际 HTML + 文本片段；
  不把 mockup 冒充 before。
- ADS8568EVM-PDK 的 2 条语义错名已按用户 2026-11-02 授权、按原表 p10
  `Bipolar full-scale range` 改名并锚定；值/条件/单位一字未动，原标签留在
  `source.label_original`。改名后 `anchor_gate=pass`（40 row + 1 para，0 weak）。
- `manifest.gate` 对 ADS8568 仍是 `UNRESOLVED`，原因是
  `core_validation=pass_with_quarantine(8)`：6 条 AC 脏行（MAX='dB'，独立抽取缺陷）
  + 2 条 SFDR/Isolation withheld。THD/SNR 已不在其中；五件 `anchor_gate` 全 pass。
- 本目录的 after HTML 基于改名后的代码路径重新渲染；V3 交付包尚未按新代码重打，
  出包由 WorkBuddy 接手。
