# 629 件异常证据卡汇总

生成时间：2026-10-28T11:40:03+08:00  
规则版本：`issue-matrix-2026-10-28-v1`  
范围：**629 件 FAIL**（来自 451 批 / 13,504 件自动 QC）；品牌：Texas Instruments。

> 边界：本文件只做只读汇总；`human_verdict/reviewer/reviewed_at/evidence_pdf_page/evidence_quote` 全部保持为空；`machine_pdf_*` 是机器 PDF 文本探针，不是人工证据。未修改 facts / Gold / item。

## 1. 分组统计

| 分组 | 数量 | 涉及批次 | 首要处理方向 |
|---|---:|---:|---|
| A3_型号错配（可能 PDF/关联错误） | 266 | 105 | P0 · HUMAN_SOURCE_RECOVERY |
| A2_可订购型号/封装变体（JSON 用基础型号） | 129 | 67 | P1 · RULE_APPROVAL_THEN_TARGETED_RERUN |
| E_PDF 文件被替换/版本漂移 | 97 | 54 | P0 · HUMAN_VERIFY_THEN_METADATA_FIX |
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | 81 | 33 | P1 · HUMAN_BUSINESS_DECISION |
| I_解析结构缺陷（电气表行） | 56 | 38 | P1 · PARSER_FIX_THEN_TARGETED_REGRESSION |
| **合计** | **629** | — | — |

## 2. 问题码

| 错误码 | 器件 |
|---|---:|
| `MPN_MISMATCH` | 476 |
| `PDF_SHA_MISMATCH` | 97 |
| `ELECTRICAL_ROW_BAD` | 46 |
| `ELECTRICAL_EMPTY` | 10 |

## 3. 集中度

| 维度 | Top |
|---|---|
| 品牌 | Texas Instruments×629 |
| 型号家族 | CD×82；DS×57；F280×39；74AH×30；BQ×24；ADS×22；DAC×19；AM×18；CAHCT×17；DRV×16；5962×15；DP×13；74CB×13；F28P×11；74LV×11 |

### 3.1 各分组最集中批次

| 分组 | Top 批次 |
|---|---|
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | qc30-20261028-0013×11；qc30-20261028-0005×8；qc30-20261028-0011×6；qc30-20261028-0012×6；qc30-20261028-0001×5 |
| E_PDF 文件被替换/版本漂移 | qc30-20261028-0313×8；qc30-20261028-0314×6；qc30-20261028-0328×5；qc30-20261028-0310×4；qc30-20261028-0169×3 |
| A3_型号错配（可能 PDF/关联错误） | qc30-20261028-0166×12；qc30-20261028-0393×12；qc30-20261028-0168×11；qc30-20261028-0449×11；qc30-20261028-0448×10 |
| A2_可订购型号/封装变体（JSON 用基础型号） | qc30-20261028-0211×11；qc30-20261028-0216×9；qc30-20261028-0212×8；qc30-20261028-0208×5；qc30-20261028-0215×5 |
| I_解析结构缺陷（电气表行） | qc30-20261028-0373×3；qc30-20261028-0380×3；qc30-20261028-0442×3；qc30-20261028-0041×2；qc30-20261028-0042×2 |

## 4. 机器 PDF 探针覆盖

| 状态 | 件数 |
|---|---:|
| `ITEM_AND_JSON` | 261 |
| `JSON_ONLY` | 158 |
| `ITEM_ONLY` | 121 |
| `NONE` | 42 |
| `ITEM_ONLY_EC` | 40 |
| `NONE_EC` | 7 |

### 4.1 I 组细分（机器探针）

| 子类 | 件数 | 涉及批次 | 说明 |
|---|---:|---:|---|
| I1_EC文本存在 | 40 | 29 | PDF 含 Electrical Characteristics 文本，优先查表格结构/解析规则 |
| I2_EC文本未找到 | 16 | 12 | PDF 未命中 EC 文本，先核对源/版本/型号，不能硬修解析器 |

## 5. 人工字段完成度

| 字段 | 已填 | 总数 |
|---|---:|---:|
| `human_verdict` | 0 | 629 |
| `human_reviewer` | 0 | 629 |
| `human_reviewed_at` | 0 | 629 |
| `evidence_pdf_page` | 0 | 629 |
| `evidence_quote` | 0 | 629 |

→ 当前人工裁决 **0/629**；不能把机器探针或分组标签当作人工结论。

## 6. 样例（每类前 3，完整见 `evidence_cards.csv`）

| 分组 | item -> JSON / PDF | 机器探针 |
|---|---|---|
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | 2MTR-DYNO -> TMS320F2806x / 2MTR-DYNO__tms320f28062f.pdf | JSON_ONLY |
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | COP8-PGMA-28CSP -> COP8SAB7 / COP8-PGMA-28CSP__COP8SA_Family.pdf | ITEM_AND_JSON |
| A1_板卡/模块映射到组件 PDF（源关联/业务口径） | COP8-PGMA-44QFP -> COP8SAC744V9 / COP8-PGMA-44QFP__COP8SA_Family.pdf | ITEM_AND_JSON |
| E_PDF 文件被替换/版本漂移 | DAC81416EVM -> — / DAC81416EVM__dac81416.pdf | ITEM_ONLY |
| E_PDF 文件被替换/版本漂移 | DRV81620-Q1EVM -> — / DRV81620-Q1EVM__drv81620-q1.pdf | NONE |
| E_PDF 文件被替换/版本漂移 | DRV81602-Q1EVM -> — / DRV81602-Q1EVM__drv81602-q1.pdf | NONE |
| A3_型号错配（可能 PDF/关联错误） | CLC730145/NOPB -> LMH6560MA / CLC730145_NOPB__LMH6560.pdf | JSON_ONLY |
| A3_型号错配（可能 PDF/关联错误） | CC2567PAN1327ANTBT -> MSP430BT5190 / CC2567PAN1327ANTBT__msp430bt5190.pdf | JSON_ONLY |
| A3_型号错配（可能 PDF/关联错误） | COP8-EMFLASH-00 -> COP8CFE9 / COP8-EMFLASH-00__COP8CFE9.pdf | ITEM_AND_JSON |
| A2_可订购型号/封装变体（JSON 用基础型号） | CDC208N -> CDC208DW / CDC208N__scas109f.pdf | ITEM_AND_JSON |
| I_解析结构缺陷（电气表行） | BQ3285S-SB2 -> — / BQ3285S-SB2__bq3285.pdf | ITEM_ONLY_EC |
| I_解析结构缺陷（电气表行） | BQ3285LFSS-A1 -> — / BQ3285LFSS-A1__BQ3285LF.pdf | NONE_EC |
| I_解析结构缺陷（电气表行） | BQ4850YMA-85N -> — / BQ4850YMA-85N__BQ4850Y.pdf | NONE_EC |
| A2_可订购型号/封装变体（JSON 用基础型号） | AFE539F1RTERQ1 -> AFE539F1-Q1 / AFE539F1RTERQ1__afe539f1-q1.pdf | ITEM_AND_JSON |
| A2_可订购型号/封装变体（JSON 用基础型号） | ADS7952QDBTRQ1 -> ADS7952-Q1 / ADS7952QDBTRQ1__ads7952-q1.pdf | ITEM_AND_JSON |

## 7. 产物

- `evidence_cards.csv`：629 张证据卡（人工字段留空）
- `repair_worklist.csv`：按根因分组的任务级修复清单
- `regression_plan.md`：定向回归与审计计划
- 原始输入：`qc/auto_qc_evidence_review_worklist.csv`、`auto_qc_issue_matrix.csv/.json`
