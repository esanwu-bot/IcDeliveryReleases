#!/usr/bin/env python
"""实测百炼 DashScope qwen-flash 的并发速率上限与 429 阈值（临时脚本）。

用途：GLM 已把主力网关切到百炼，但 worker 并发数该定多少还没有依据。
本脚本用「真实体量」的短请求（带 JSON 输出）按阶梯并发压测，
统计：成功率、p50/p90 延迟、429/限流次数、实际达成 RPM。

不改任何生产文件，不写 llm_usage，不动 data/parsed。
用法: python tmp_probe_dashscope.py
"""
from __future__ import annotations

import json
import os
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
for name in (".env.local", ".env"):
    p = ROOT / name
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"
KEY = os.getenv("DASHSCOPE_API_KEY", "")
MODEL = os.getenv("DASHSCOPE_MODEL", "qwen-flash")
TIMEOUT = 120

# 与生产 prompt 体量接近的小载荷：让它输出一个固定结构的 JSON，
# 目的是测「速率 + 首字延迟 + 输出速度」，而不是测内容质量。
SYS = "You are a JSON emitter. Output ONLY valid JSON matching the schema."
USER = (
    "Generate a technical datasheet fragment for a buck converter IC. "
    "Output JSON with keys: mpn(str), manufacturer(str), description(str), "
    "features(list of 6 str), electrical(dict of 6 key->num), "
    "package(str), pins(list of 14 obj {num:int,name:str,description:str}). "
    "Each pin description must be 12-25 words of realistic engineering prose. "
    "Each feature must be 12-20 words. The description must be 80-120 words."
)


def one(_i: int, thinking: bool) -> dict:
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYS}, {"role": "user", "content": USER}],
        "temperature": 0.1,
        "max_tokens": 4000,
        "response_format": {"type": "json_object"},
    }
    if thinking:
        payload["enable_thinking"] = True
    else:
        payload["enable_thinking"] = False
    t0 = time.perf_counter()
    try:
        r = requests.post(f"{BASE}/chat/completions",
                          headers={"Authorization": f"Bearer {KEY}",
                                   "Content-Type": "application/json"},
                          json=payload, timeout=TIMEOUT)
        dt = time.perf_counter() - t0
        if r.status_code != 200:
            return {"ok": False, "code": r.status_code, "secs": dt,
                    "err": r.text[:200], "ct": 0}
        u = r.json().get("usage", {})
        return {"ok": True, "code": 200, "secs": dt,
                "pt": u.get("prompt_tokens", 0), "ct": u.get("completion_tokens", 0),
                "err": ""}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "code": 0, "secs": time.perf_counter() - t0,
                "err": f"{type(e).__name__}: {e}"[:200], "ct": 0}


def run(n: int, label: str, thinking: bool = False) -> dict:
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=n) as pool:
        futs = [pool.submit(one, i, thinking) for i in range(n)]
        for f in as_completed(futs):
            res.append(f.result())
    wall = time.time() - t0
    ok = [x for x in res if x["ok"]]
    bad = [x for x in res if not x["ok"]]
    limited = [x for x in bad if x["code"] == 429 or "429" in x["err"]
               or "rate" in x["err"].lower() or "throttl" in x["err"].lower()]
    secs = sorted(x["secs"] for x in ok)
    p50 = statistics.median(secs) if secs else 0
    p90 = secs[int(len(secs) * 0.9)] if secs else 0
    ct = sum(x.get("ct", 0) for x in ok)
    print(f"\n[{label}] 并发={n} 墙钟={wall:.1f}s")
    print(f"  成功 {len(ok)}/{n}  限流 {len(limited)}  其他失败 {len(bad)-len(limited)}")
    print(f"  延迟 p50={p50:.1f}s p90={p90:.1f}s  max={max(secs) if secs else 0:.1f}s")
    print(f"  达成 RPM={len(ok)/wall*60:.1f}  输出token合计={ct} 均值={ct//max(1,len(ok))}")
    if limited:
        print(f"  429 样本: {limited[0]['err'][:160]}")
    if bad and not limited:
        print(f"  失败样本: {bad[0]['err'][:160]}")
    return {"n": n, "ok": len(ok), "limited": len(limited), "p50": p50, "p90": p90,
            "wall": wall, "rpm": len(ok) / wall * 60, "ct_avg": ct // max(1, len(ok))}


if __name__ == "__main__":
    assert KEY, "DASHSCOPE_API_KEY 未配置"
    print(f"model={MODEL} base={BASE}")
    print("=== 阶梯压测：每档并发发起 N 个请求 ===")
    rows = []
    for n in (4, 8, 12, 16):
        rows.append(run(n, f"并发{n}"))
        time.sleep(5)
    print("\n=== 汇总 ===")
    for r in rows:
        print(f"  并发{r['n']:>3}  成功{r['ok']:>3}  限流{r['limited']:>3}  "
              f"p50={r['p50']:>6.1f}s  p90={r['p90']:>6.1f}s  RPM={r['rpm']:>5.1f}")
    print(json.dumps(rows, ensure_ascii=False))
