# IcPdfParser 服务器部署方案（Docker）

目标：把工作台从 Windows 本机迁到生产服务器（tqx_2026 所在那台）常驻运行，
域名 `icpg.0668xgwl.com`，带登录，llm 并发 64 档。

---

## 1. 架构与容器规划

```
宝塔 nginx (icpg.0668xgwl.com, SSL)
        │ 反代
        ▼
icpdf-server   127.0.0.1:8300   FastAPI 工作台（登录拦截）
icpdf-fetch    worker --role fetch   (32 并发，下载纯网络 IO)
icpdf-llm      worker --role llm     (ICPDF_WORKERS=64，贵槽位只跑模型)
icpdf-render   worker --role render  (8 并发，本地产物渲染)
icpdf-redis    队列 + AOF 持久化（每秒落盘，容器重启不丢消息）
```

- 代码镜像 `icpdf/app:latest` 四个容器共用（server + 三角色 worker）。
- 数据全在宿主机目录挂载进容器（`data/`、`uploads/`），镜像无状态，随时重建。
- 服务器目录：`/www/wwwroot/icpdfparser/`（git 仓库根），compose 在 `deploy/` 子目录，
  与 tqx_2026 的 compose 项目完全隔离（`name: icpdf`），互不影响。

## 2. 首次部署步骤

```bash
# (1) 拉代码
cd /www/wwwroot
git clone https://codeup.aliyun.com/5f0af04d5fd102f22f6b747c/IcPdfParser.git icpdfparser
cd icpdfparser

# (2) 配环境
cd deploy
cp .env.example .env
vim .env        # 填 DASHSCOPE_API_KEY、ICPDF_AUTH_PASSWORD、ICPDF_AUTH_SECRET

# (3) 迁移数据（见下节，先把本机 data/ 上传到服务器 /www/wwwroot/icpdfparser/data/）
# (4) 构建并启动
docker compose build
docker compose up -d
docker compose ps          # 五个容器应全部 Up (healthy)

# (5) 冒烟
curl -s http://127.0.0.1:8300/api/health | head -c 300
# 未登录应拿不到数据（登录拦截已开）：
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8300/api/overview   # 期望 401
```

## 3. 数据迁移清单（Windows 本机 -> 服务器）

> 原则：**SQLite 库 + 产物目录配套整体搬**；代码/依赖不搬（镜像内装）。

| 本机路径 | 去向 | 说明 |
|---|---|---|
| `data/workbench.sqlite3*` | `data/` | 任务库（含 -wal/-shm 一起拷；已在 10-23 做过 backup，直接用备份文件更稳：`data/workbench.sqlite3-backup-20261023` 重命名为 `workbench.sqlite3`） |
| `data/products.sqlite3*` | `data/` | 内链索引库（用 backup 文件） |
| `data/pdfs/` | `data/` | 已下载 Datasheet（llm_item 直接复用，不重新下载） |
| `data/parsed/` | `data/` | 解析 JSON |
| `data/txt/ alts/ symbols/ seo/` | `data/` | 交付产物 |
| `data/pkgs/ templates/ img/` | `data/` | 封装图库 / 模板 / 配图 |
| `uploads/` | `uploads/` | 上传的型号表、目录表（catalog 重建索引用） |
| `.env.local` | **不搬** | 密钥走 `deploy/.env`（已 gitignore） |
| `tools/redis/` | **不搬** | Windows 版 Redis，服务器用容器版 |

> 库里的产物路径是 Windows 绝对路径（`E:\workspace\...`），跨机后由
> `config.resolve_artifact()` 按「目录 + 文件名」自动回退解析，**无需清洗数据库**。

传输方式：本机打包（排除不需要的目录）后 scp/rsync 上去：

```powershell
# 本机（PowerShell，停 worker 后执行，保证 sqlite 一致）
cd E:\workspace\IcPdfParser
tar -a -c -f icpdf-data.zip data uploads
scp icpdf-data.zip root@服务器IP:/www/wwwroot/icpdfparser/
```

```bash
# 服务器
cd /www/wwwroot/icpdfparser && unzip -o icpdf-data.zip && rm icpdf-data.zip
```

## 4. 宝塔反代 + SSL

1. 宝塔 -> 网站 -> 添加站点：域名 `icpg.0668xgwl.com`，纯静态（不建库）。
2. SSL 证书：站点设置 -> SSL -> Let's Encrypt 申请（域名需先解析 A 记录到本机）。
3. 反代：站点设置 -> 反向代理 -> 添加：
   - 目标 URL：`http://127.0.0.1:8300`
   - 发送域名：`$host`
4. 验证：浏览器打开 `https://icpg.0668xgwl.com` 应见登录页；
   登录后进入工作台，`运行状态` 页 `mode` 应显示 `celery`。

## 5. 明天（以及任何时候）停机后怎么继续跑

**本机今天收工：**

```powershell
# 优雅停 worker（不要 taskkill /F；server 可以最后停）
cd E:\workspace\IcPdfParser
python -c "from worker.celery_app import app; app.control.broadcast('shutdown')"
# 确认三个 run_worker 进程退出后再关机；Redis 无持久化，重启后队列消息会清空 —— 没关系
```

**服务器续跑（每天的标准动作）：**

```bash
cd /www/wwwroot/icpdfparser
docker compose -f deploy/docker-compose.yml ps    # 容器自动重启（unless-stopped），通常无需操作

# 仅当队列消息丢失（redis 数据卷被清 / 首次迁移）时，重投一次：
docker compose -f deploy/docker-compose.yml exec server python requeue_all.py --dry   # 先看分布
docker compose -f deploy/docker-compose.yml exec server python requeue_all.py        # 执行重投
```

- `requeue_all.py` 按件的实际进度智能路由：有 JSON 投 render、有 PDF 投 llm、
  其余投 fetch，不重复消耗已完成的阶段；执行前会清空三条队列防重复。
- failed / nodata 属终态不自动重跑；需要时在工作台 UI 点「解析未完成」
  （口径已扩为全部非终态 + failed + nodata）。

## 6. llm 并发 64 档：上线与回退

| 项 | 48 档（已实测） | 64 档（明天上） |
|---|---|---|
| 吞吐 | 46~54 件/分钟 | 预期 +15%（约 55~62 件/分钟） |
| p90 | 84.8s | **警戒线 90s** |
| 429 | 0 | 出现即回退 |

上线后头 30 分钟观察：

```bash
docker compose -f deploy/docker-compose.yml logs -f worker-llm | grep -Ei '429|error' 
```

p90 / 吞吐看工作台「运行状态」页（llm_usage 记账）。
触发任一条件 -> `deploy/.env` 改 `ICPDF_WORKERS=48` ->
`docker compose -f deploy/docker-compose.yml up -d worker-llm`。

## 7. 日常运维

```bash
cd /www/wwwroot/icpdfparser/deploy

docker compose logs -f server            # 看工作台日志
docker compose logs -f worker-llm        # 看解析日志
docker compose restart server            # 只重启某个服务
docker compose up -d --build server      # 改代码后重建镜像并滚动更新
# 注意：up -d --build server 只更新 server；worker 复用同一镜像 tag，
# 更新代码后需要一并重建：docker compose build && docker compose up -d

# 备份（建议宝塔计划任务每日执行）
sqlite3 /www/wwwroot/icpdfparser/data/workbench.sqlite3 ".backup /www/icpdf-backup/workbench-$(date +%F).sqlite3"
```

升级代码：`cd /www/wwwroot/icpdfparser && git pull && cd deploy && docker compose build && docker compose up -d`。

## 8. 已知约束与注意

- **禁止**在 `/www/wwwroot/tqx_2026/deploy` 执行任何 `docker compose down`；
  本项目所有 compose 命令都在 `/www/wwwroot/icpdfparser/deploy` 执行。
- Redis 容器开了 AOF（everysec）：容器重启不丢队列消息；但 `requeue_all.py`
  幂等安全，误跑也只是重投（任务落库，重复执行结果一致）。
- llm worker 内存随并发线性（64 并发约 4~6GB 峰值），服务器内存紧张时先回 48。
- 上传型号表走浏览器（登录后），单批上限 2 万行（`ICPDF_MAX_UPLOAD`）。
- 服务器出网访问 ti.com 等采集源需与本机同等网络条件；若大面积
  transient 网络失败，先排查服务器出网（与 L2 阶段本机 VPN 问题同性质）。
