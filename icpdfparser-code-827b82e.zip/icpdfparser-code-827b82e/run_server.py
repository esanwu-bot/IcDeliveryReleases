#!/usr/bin/env python
"""启动工作台（FastAPI）。

    python run_server.py                 # http://127.0.0.1:8000
    python run_server.py --port 8080 --reload

生产/多进程场景请关掉 --reload，并用 run_worker.py 单独拉起 Celery worker。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--reload", action="store_true")
    a = ap.parse_args()

    import uvicorn
    from app import db
    db.conn()                                     # 先建库，避免首个请求卡在建表
    uvicorn.run("app.main:app", host=a.host, port=a.port, reload=a.reload,
                log_level="info")


if __name__ == "__main__":
    main()
