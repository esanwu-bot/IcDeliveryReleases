#!/usr/bin/env python
"""生成《单个详情页交付清单.md》——逐型号盘点站点详情页所需的全部产物。

不是手写文档：每次都从 data/ 下的实际文件重算，所以清单和磁盘永远一致。

    python delivery_report.py
    python delivery_report.py --out 单个详情页交付清单.md
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
PARSED, TXT, ALTS, SYMBOLS = (DATA / "parsed", DATA / "txt", DATA / "alts", DATA / "symbols")

# 详情页片段应有的段落（id -> 中文名）
SECTIONS = [
    ("product-introduction", "产品简介"),
    ("key-benefits", "核心特性"),
    ("specifications", "规格参数"),
    ("package", "封装信息"),
    ("pinout", "引脚定义"),
    ("equivalent", "替代型号"),
    ("manufacturer-information", "厂商信息"),
    ("application", "应用领域"),
    ("faq", "常见问题"),
    ("disclaimer", "免责声明"),
]

# 交付产物定义：(键, 名称, 用途)
ARTIFACTS = [
    ("pdf", "Datasheet 原件", "归档 / 复核 / 重新解析"),
    ("json", "结构化 JSON", "唯一事实来源，渲染与二次加工都读它"),
    ("txt", "详情页 HTML 片段", "直接注入站点详情页正文"),
    ("alt_json", "替代型号 JSON", "内链候选 + 审核队列"),
    ("alt_html", "替代型号 HTML 片段", "详情页 #equivalent 段"),
    ("symbol", "三视图 HTML", "原理图符号 / 封装 / 3D 示意"),
    ("img", "应用领域图片", "详情页 #application 段配图（站内已有素材）"),
]


def kb(p: Path | None) -> str:
    if not p or not p.exists():
        return "—"
    n = p.stat().st_size
    return f"{n / 1024:.1f} KB" if n < 1024 * 1024 else f"{n / 1048576:.1f} MB"


def safe(mpn: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", mpn or "")


def load_manifest() -> tuple[dict[str, dict], dict[str, dict]]:
    """返回 (按请求型号索引, 按 pdf sha256 索引)。

    JSON 里的 mpn 可能被模型改写（2MTR-DYNO → TMS320F28062），
    所以关联原件必须走 pdf_hash，不能走型号字符串。
    """
    f = DATA / "manifest.csv"
    by_mpn: dict[str, dict] = {}
    by_hash: dict[str, dict] = {}
    if not f.exists():
        return by_mpn, by_hash
    with open(f, encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            m = r["mpn"].strip()
            by_mpn[m] = r
            h = (r.get("sha256") or "").strip()
            if h:
                by_hash[h] = r
    return by_mpn, by_hash


def missing_links() -> dict[str, int]:
    f = ALTS / "_missing_links.csv"
    out: dict[str, int] = {}
    if not f.exists():
        return out
    with open(f, encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            k = (r.get("referenced_by") or "").strip()
            out[k] = out.get(k, 0) + 1
    return out


def collect() -> list[dict]:
    man, man_by_hash = load_manifest()
    miss = missing_links()
    rows = []
    for f in sorted(PARSED.glob("*.json")):
        doc = json.loads(f.read_text(encoding="utf-8"))
        bi = doc.get("basic_info") or {}
        meta = doc.get("metadata") or {}
        mpn = (bi.get("mpn") or f.stem).strip()
        stem = safe(mpn)
        specs = doc.get("specs") or {}
        pkg = specs.get("package") or {}
        pins = doc.get("pin_configuration")
        pins = pins if isinstance(pins, list) else []
        txt = TXT / f"{stem}.txt"
        alt_json, alt_html = ALTS / f"{stem}.json", ALTS / f"{stem}.html"
        symbol = SYMBOLS / f"{stem}.html"

        # 用 pdf_hash 找原件（型号可能被模型改写）
        m = man_by_hash.get(meta.get("pdf_hash") or "") or man.get(mpn) or {}
        req_mpn = (m.get("mpn") or "").strip()
        pdf = None
        if m.get("local_path"):
            p = ROOT / m["local_path"].replace("\\", "/")
            pdf = p if p.exists() else None

        # 详情页实际包含哪些段落
        secs, imgs = [], []
        if txt.exists():
            body = txt.read_text(encoding="utf-8")
            secs = [sid for sid, _ in SECTIONS if f'id="{sid}"' in body]
            imgs = sorted(set(re.findall(r'/upload/img/([\w.-]+\.(?:png|jpe?g|webp|svg))', body)))

        alt = {}
        if alt_json.exists():
            alt = json.loads(alt_json.read_text(encoding="utf-8"))
        alts = alt.get("alternatives") or []

        # 0 字节片段视为未交付
        def real(p: Path | None) -> Path | None:
            return p if (p and p.exists() and p.stat().st_size > 0) else None

        rows.append({
            "mpn": mpn, "stem": stem, "req_mpn": req_mpn,
            "doc": doc, "bi": bi, "specs": specs, "pkg": pkg, "pins": pins,
            "txt": real(txt), "alt_json": real(alt_json), "alt_html": real(alt_html),
            "symbol": real(symbol), "pdf": pdf, "man": m, "secs": secs, "imgs": imgs,
            "alts": alts, "n_alt": len(alts),
            "n_linked": sum(1 for a in alts if a.get("internal")),
            "n_verified": sum(1 for a in alts if a.get("verified")),
            "missing": miss.get(mpn, 0) or miss.get(req_mpn, 0),
            "conf": float(meta.get("confidence") or 0),
            "mpn_mismatch": bool(req_mpn and req_mpn != mpn),
        })
    return rows


def status_of(r: dict) -> tuple[str, list[str]]:
    """上线判定 + 缺口说明。

    阻塞 = 页面根本拼不出来（缺 PDF 原件 / 缺详情页片段）。
    缺段落、缺内链、型号被改写都只是内容缺口，页面照样能上线。
    """
    gaps = []
    if not r["pdf"]:
        gaps.append("缺 PDF 原件")
    if not r["txt"]:
        gaps.append("缺详情页片段")

    lack = [cn for sid, cn in SECTIONS if sid not in r["secs"]]
    # 无引脚数据时 pinout 段本来就不该有；无可用内链时 equivalent 段也不该有
    if not r["pins"] and "引脚定义" in lack:
        lack.remove("引脚定义")
    if not r["n_linked"] and "替代型号" in lack:
        lack.remove("替代型号")
    if lack:
        gaps.append("缺段落：" + "、".join(lack))
    if not r["pins"]:
        gaps.append("无 pin_configuration → 三视图未生成、引脚段跳过")
    if not (r["doc"].get("ordering_info") or []):
        gaps.append("无 ordering_info → 替代型号全靠 AI 提案，内链率低")
    if r["conf"] and r["conf"] < 0.85:
        gaps.append(f"置信度偏低 {r['conf']:.2f}")
    if r["mpn_mismatch"]:
        gaps.append(f"JSON 型号 `{r['mpn']}` ≠ 请求型号 `{r['req_mpn']}`（EVM 类 PDF 常见，页面主键须用请求型号）")
    if not r["bi"].get("datasheet_url"):
        gaps.append("缺 datasheet_url")
    if r["missing"]:
        gaps.append(f"{r['missing']} 条候选未命中站内目录")

    if not r["txt"] or not r["pdf"]:
        return "阻塞", gaps
    return ("齐备" if not gaps else "可上线（带缺口）"), gaps


def build(rows: list[dict]) -> str:
    ok = sum(1 for r in rows if status_of(r)[0] == "齐备")
    warn = sum(1 for r in rows if status_of(r)[0] == "可上线（带缺口）")
    block = sum(1 for r in rows if status_of(r)[0] == "阻塞")
    tot_missing = sum(r["missing"] for r in rows)

    o: list[str] = []
    a = o.append
    a("# 单个详情页交付清单")
    a("")
    a("> 本文由 `delivery_report.py` 从 `data/` 实际产物重算生成，不是手写稿。")
    a("> 重新生成：`python delivery_report.py`")
    a("")
    a(f"**当前样本 {len(rows)} 个型号**：齐备 {ok} / 可上线（带缺口）{warn} / 阻塞 {block}。"
      f"待补内链 {tot_missing} 条。")
    a("")

    # ---------------------------------------------------------------- 1
    a("## 1. 一个型号要交付什么")
    a("")
    a("| # | 产物 | 落盘路径 | 命名规则 | 用途 |")
    a("|---|---|---|---|---|")
    a("| 1 | Datasheet 原件 | `data/pdfs/` | `{型号}__{原文件名}.pdf` | 归档、复核、重新解析 |")
    a("| 2 | 结构化 JSON | `data/parsed/` | `{型号}_{hash8}.json` | **唯一事实来源**，渲染与二次加工都读它 |")
    a("| 3 | 详情页 HTML 片段 | `data/txt/` | `{型号}.txt` | 直接注入站点详情页正文 |")
    a("| 4 | 替代型号 JSON | `data/alts/` | `{型号}.json` | 内链候选 + 审核队列 |")
    a("| 5 | 替代型号 HTML 片段 | `data/alts/` | `{型号}.html` | 详情页 `#equivalent` 段（无替代则不落文件） |")
    a("| 6 | 三视图 | `data/symbols/` | `{型号}.html` | 原理图符号 / 封装 / 3D 示意 |")
    a("| 7 | 应用领域图片 | 站内 `/upload/img/` | `app-*.png` | 详情页 `#application` 段配图，复用现有素材 |")
    a("")
    a("型号里的 `/`、`#`、空格在文件名中替换为 `_`（如 `ADS1201U-1/1K` → `ADS1201U-1_1K`），"
      "页面主键仍用原始型号。")
    a("")
    a("### 1.1 详情页片段必须包含的 10 个段落")
    a("")
    a("| 顺序 | `id` | 中文名 |")
    a("|---|---|---|")
    for i, (sid, cn) in enumerate(SECTIONS, 1):
        a(f"| {i} | `{sid}` | {cn} |")
    a("")
    a("### 1.2 上线判定")
    a("")
    a("- **齐备**：7 项产物齐全、10 个段落齐全、无缺口。")
    a("- **可上线（带缺口）**：正文可用，但缺三视图/替代型号内链等增强项，见各型号「缺口」。")
    a("- **阻塞**：缺 PDF 原件或详情页片段，不可上线。")
    a("")

    # ---------------------------------------------------------------- 2
    a("## 2. 总览")
    a("")
    a("| # | 型号 | 厂商 | PDF | 详情页 | 段落 | 替代(内链/总) | 三视图 | 状态 |")
    a("|---|---|---|---|---|---|---|---|---|")
    for i, r in enumerate(rows, 1):
        st, _ = status_of(r)
        mark = {"齐备": "✅", "可上线（带缺口）": "⚠️", "阻塞": "❌"}[st]
        a(f"| {i} | `{r['mpn']}` | {r['bi'].get('manufacturer') or '—'} "
          f"| {kb(r['pdf'])} | {kb(r['txt'])} | {len(r['secs'])}/{len(SECTIONS)} "
          f"| {r['n_linked']}/{r['n_alt']} "
          f"| {'✅' if r['symbol'] else '—'} | {mark} {st} |")
    a("")

    # 缺口统计：看清这批样本的共性短板
    def cat(g: str) -> str:
        for key, label in (
            ("缺 PDF 原件", "缺 PDF 原件"),
            ("缺详情页片段", "缺详情页片段"),
            ("缺段落", "段落不全"),
            ("无 pin_configuration", "缺引脚数据（三视图/引脚段不可用）"),
            ("无 ordering_info", "缺订购信息（替代型号内链率低）"),
            ("置信度偏低", "置信度偏低"),
            ("JSON 型号", "型号被模型改写（EVM/整机类）"),
            ("缺 datasheet_url", "缺 datasheet_url"),
        ):
            if g.startswith(key):
                return label
        if "未命中站内目录" in g:
            return "有候选未命中站内目录"
        return g

    tally: dict[str, int] = {}
    for r in rows:
        for g in status_of(r)[1]:
            k = cat(g)
            tally[k] = tally.get(k, 0) + 1
    if tally:
        a("**缺口统计**（按出现型号数排序，用来判断下一批该优先补什么）")
        a("")
        a("| 缺口 | 涉及型号数 | 影响 |")
        a("|---|---|---|")
        impact = {
            "缺 PDF 原件": "不可上线",
            "缺详情页片段": "不可上线",
            "段落不全": "页面缺内容块",
            "缺引脚数据（三视图/引脚段不可用）": "少一个详情页模块",
            "缺订购信息（替代型号内链率低）": "内链覆盖差",
            "置信度偏低": "需人工复核",
            "型号被模型改写（EVM/整机类）": "页面主键错误风险",
            "缺 datasheet_url": "合规/溯源信息缺",
            "有候选未命中站内目录": "内链待补",
        }
        for k, v in sorted(tally.items(), key=lambda x: -x[1]):
            a(f"| {k} | {v}/{len(rows)} | {impact.get(k, '—')} |")
        a("")

    # ---------------------------------------------------------------- 3
    a("## 3. 逐型号明细")
    a("")
    for i, r in enumerate(rows, 1):
        st, gaps = status_of(r)
        bi, specs = r["bi"], r["specs"]
        a(f"### 3.{i} `{r['mpn']}`")
        a("")
        if r["mpn_mismatch"]:
            a(f"> ⚠️ 该 PDF 的请求型号是 `{r['req_mpn']}`，模型把 `basic_info.mpn` 改写成了 "
              f"`{r['mpn']}`。**页面主键必须用 `{r['req_mpn']}`**，`{r['mpn']}` 只能当器件型号展示。")
            a("")
        a(f"- 厂商：{bi.get('manufacturer') or '—'}　"
          f"分类：{bi.get('category') or '—'}")
        a(f"- 封装：`{(r['pkg'].get('type') or '—')}`　引脚：{r['pkg'].get('pins') or len(r['pins'])}"
          f"　尺寸：{r['pkg'].get('dimensions') or '—'}")
        a(f"- 解析模型：{(r['doc'].get('metadata') or {}).get('model_version') or '—'}"
          f"　置信度：{r['conf']:.2f}"
          + (f"　来源：{r['man'].get('source')}" if r["man"].get("source") else ""))
        a("")
        a("| 产物 | 文件 | 大小 | 内容 |")
        a("|---|---|---|---|")
        a(f"| Datasheet | `{Path(str(r['pdf'])).name if r['pdf'] else '—'}` | {kb(r['pdf'])} "
          f"| sha256 `{str(r['man'].get('sha256') or '')[:8]}` |")
        a(f"| 结构化 JSON | `data/parsed/{r['stem']}*.json` | — "
          f"| 电气参数 {len(specs.get('electrical') or [])} 项 / 绝对最大值 "
          f"{len(specs.get('absolute_max') or [])} 项 / 特性 {len(r['doc'].get('features') or [])} 条 "
          f"/ 应用 {len(r['doc'].get('applications') or [])} 条 / 引脚 {len(r['pins'])} / "
          f"订购型号 {len(r['doc'].get('ordering_info') or [])} |")
        a(f"| 详情页片段 | `data/txt/{r['stem']}.txt` | {kb(r['txt'])} "
          f"| {len(r['secs'])}/{len(SECTIONS)} 段落 |")
        a(f"| 替代型号 JSON | `data/alts/{r['stem']}.json` | {kb(r['alt_json'])} "
          f"| 候选 {r['n_alt']} / 已内链 {r['n_linked']} / 已校验 {r['n_verified']} |")
        a(f"| 替代型号片段 | `data/alts/{r['stem']}.html` | {kb(r['alt_html'])} "
          f"| {'可直接用' if r['alt_html'] else '无可用内链，未生成'} |")
        a(f"| 三视图 | `data/symbols/{r['stem']}.html` | {kb(r['symbol'])} "
          f"| {'符号 + 封装 + 3D' if r['symbol'] else '未生成（缺引脚数据）'} |")
        a(f"| 应用图片 | — | — "
          f"| {('、'.join('`' + x + '`' for x in r['imgs'])) if r['imgs'] else '—'} |")
        a("")
        a(f"**状态：{st}**")
        if gaps:
            a("")
            a("缺口：")
            for g in gaps:
                a(f"- {g}")
        else:
            a("")
            a("无缺口。")
        a("")

    # ---------------------------------------------------------------- 4
    a("## 4. 待补内链")
    a("")
    f = ALTS / "_missing_links.csv"
    if f.exists():
        with open(f, encoding="utf-8-sig") as fh:
            items = list(csv.DictReader(fh))
        a(f"共 {len(items)} 条：AI 提案但站内目录未命中。**不要直接上线**，"
          "先补商品或人工确认，确认后回填 `data/products.sqlite3` 重跑即可自动内链。")
        a("")
        a("| 型号 | 厂商 | 相似度 | 被哪个页面引用 |")
        a("|---|---|---|---|")
        for r in items:
            a(f"| `{r.get('mpn','')}` | {r.get('manufacturer','')} "
              f"| {r.get('similarity','')} | `{r.get('referenced_by','')}` |")
    else:
        a("无。")
    a("")

    # ---------------------------------------------------------------- 5
    a("## 5. 样本说明")
    a("")
    cats: dict[str, int] = {}
    for r in rows:
        c = r["bi"].get("category") or "未分类"
        cats[c] = cats.get(c, 0) + 1
    boards = sum(v for k, v in cats.items() if "Board" in k or "Evaluation" in k)
    a(f"本批 {len(rows)} 个型号里，评估板/开发板 **{boards}** 个，芯片 **{len(rows) - boards}** 个。"
      "评估板 PDF 通常没有引脚表、没有订购信息，型号还容易被模型改写，"
      "所以本批的「缺引脚数据」「型号被改写」「内链率低」大部分来自这 "
      f"{boards} 个板子，不代表芯片类页面的真实水平。")
    a("")
    a("| 分类 | 型号数 |")
    a("|---|---|")
    for k, v in sorted(cats.items(), key=lambda x: -x[1]):
        a(f"| {k} | {v} |")
    a("")

    # ---------------------------------------------------------------- 6
    a("## 6. 已知限制")
    a("")
    a("1. **站内目录被导出上限截断**：`Integrated Circuits (ICs).xls` 是 Excel 97 格式，"
      "10 sheet × 65,536 = 655,360 行上限，去重后 598,891。实测有线上真页查不到，"
      "需换不截断的导出（DB 直出 CSV / 分页 API）。")
    a("2. **三视图的 3D 是示意**：PDF 里没有 3D 数据，只能按封装类型程序化绘制；"
      "要真模型需接 EDA 供应商（SnapEDA / Ultra Librarian，注意授权）。")
    a("3. **EVM/整机类 PDF 会改写型号**：`basic_info.mpn` 可能与请求型号不一致，"
      "页面主键必须保留请求型号（`device_mpn` 字段待加）。")
    a("4. **替代型号有幻觉风险**：AI 会编料号，生产口径只输出站内目录命中的型号。")
    a("")
    a("---")
    a("")
    a(f"生成时间：{__import__('time').strftime('%Y-%m-%d %H:%M')}　"
      f"数据源：`data/parsed`、`data/txt`、`data/alts`、`data/symbols`、`data/manifest.csv`")
    return "\n".join(o) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "单个详情页交付清单.md"))
    a = ap.parse_args()
    rows = collect()
    Path(a.out).write_text(build(rows), encoding="utf-8")
    print(f"{len(rows)} 个型号 -> {a.out}")


if __name__ == "__main__":
    main()
