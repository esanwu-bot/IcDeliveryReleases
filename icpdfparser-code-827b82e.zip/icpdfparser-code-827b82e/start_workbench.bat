@echo off
chcp 65001 >nul
setlocal
set "ROOT=%~dp0"
set "PY=C:\Users\Administrator\.workbuddy-ai\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
cd /d "%ROOT%"

echo [1/3] 启动 Redis ...
"%ROOT%tools\redis\redis-cli.exe" -p 6379 ping >nul 2>&1
if errorlevel 1 (
    start "icpdf-redis" /min "%ROOT%tools\redis\redis-server.exe" "%ROOT%tools\redis\icpdf.conf"
    timeout /t 2 >nul
) else (
    echo       Redis 已在运行
)

echo [2/3] 启动 Celery worker ...
start "icpdf-worker" cmd /k ""%PY%" run_worker.py"

echo [3/3] 启动工作台 ...
start "icpdf-web" cmd /k ""%PY%" run_server.py"
timeout /t 3 >nul
start http://127.0.0.1:8000

echo.
echo 已启动：Redis + worker + web（三个独立窗口，关窗口即停对应进程）
