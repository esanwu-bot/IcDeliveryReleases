#!/usr/bin/env python
"""启动 Celery worker（消费 icpdf 队列）。

    python run_worker.py                 # 默认 threads 池、并发取 ICPDF_WORKERS(2)
    python run_worker.py -c 3 -l debug

Windows 说明：Celery 的 prefork 池在 Windows 不可靠，这里默认线程池。
本链路的耗时几乎全在「等网络 + 等模型」，线程池足够。
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config                                     # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--role", choices=["llm", "fetch", "render", "preprocess", "audit"],
                    default="llm",
                    help="槽位角色：fetch=下载队列(默认32并发) llm=解析队列(默认) "
                         "render=渲染队列(默认8并发) preprocess=切片队列 audit=复核队列"
                         "（后两个是五段链路新增的 CPU 段，默认沿用 render 的并发档）")
    ap.add_argument("-c", "--concurrency", type=int, default=0, help="默认按角色取 config 配置")
    ap.add_argument("-P", "--pool", default=os.getenv("ICPDF_POOL", "threads"))
    ap.add_argument("-l", "--loglevel", default="info")
    ap.add_argument("-Q", "--queue", default="",
                    help="默认按角色路由（llm=icpdf / fetch=icpdf_fetch / render=icpdf_render "
                         "/ preprocess=icpdf_preprocess / audit=icpdf_audit）")
    a = ap.parse_args()

    from worker.celery_app import app

    # L1 槽位分离：各类队列独立并发 —— 下载纯等网络(32)、LLM 是贵槽位、渲染纯本地。
    # preprocess / audit 是 PyMuPDF 的 CPU 活，既不吃网络也不烧 token，所以并发档
    # 沿用 render 那一档（8）；本次接线**不新增并发参数**，避免灰度期多出一组没人
    # 观察过的旋钮。要临时压高就用 -c。
    if a.role == "fetch":
        queue = a.queue or config.FETCH_QUEUE
        conc = a.concurrency or config.FETCH_WORKERS
    elif a.role == "render":
        queue = a.queue or config.RENDER_QUEUE
        conc = a.concurrency or config.RENDER_WORKERS
    elif a.role == "preprocess":
        queue = a.queue or config.PREPROCESS_QUEUE
        conc = a.concurrency or config.RENDER_WORKERS
    elif a.role == "audit":
        queue = a.queue or config.AUDIT_QUEUE
        conc = a.concurrency or config.RENDER_WORKERS
    else:
        queue = a.queue or config.CELERY_QUEUE
        conc = a.concurrency or config.LLM_WORKERS

    # app 实例已经加载，不要再传 -A（否则会二次导入并可能用错配置）
    argv = ["worker", "-Q", queue, "-P", a.pool, "-c", str(conc),
            "-l", a.loglevel, "-n", f"{a.role}@{os.getpid()}"]
    app.worker_main(argv)


if __name__ == "__main__":
    main()
