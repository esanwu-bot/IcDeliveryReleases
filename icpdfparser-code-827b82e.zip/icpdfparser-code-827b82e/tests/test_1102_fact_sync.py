#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1102-V2 P1：事实表结论必须同步进 `onboard_device_specs` 的 `verification`。

V11 的 `qc/fact_status_sync.py` 只遍历 `specs` 主表的五个容器。板卡件的电气行
被合同层整锅搬进 `specs.onboard_device_specs.electrical` 后，事实表的强/弱结论
一条都回写不到 —— 页面按事实表打 `†`，JSON 的 `verification` 却是 `None`。
复审看到的「SNR 没 †、SFDR 有 †，JSON 两行都是 None」就是两个口径各说各话。

口径：
* 强结论（verified_row 等）→ 升级为 `audited_*`；
* 状态为空时，弱结论也如实补写（`value_on_label_page` → `label_value_same_page`），
  空着不等于「已核验」；
* 已有状态不降级，`model_unverified` / `unresolved` 永远不被洗白；
* 主表 / `onboard_device_specs` / `unresolved_specs` 三处同一套匹配（label + cond）。

用例全部手写假 JSON（不依赖 data/ 产物），形态按 V11 交付件：同名的 SNR/SFDR
按 `conditions` 区分。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import json_to_txt as J                                       # noqa: E402
from qc import fact_status_sync as FSS                         # noqa: E402


def _dirty_ac(i: int) -> dict:
    return {"symbol": "SNR", "parameter": "SNR Signal-to-noise ratio",
            "conditions": f"At fIN = 10 kHz; QROW{i}",
            "min": f"{70 + i}.5", "typ": "", "max": "dB", "unit": "",
            "row_sha256": f"dirty-row-{i}"}


def _board_doc(elec: list[dict] | None = None) -> dict:
    """最小可同步的板卡件：芯片参数在板载器件桶，主表为空。"""
    return {
        "basic_info": {"mpn": "ADS8568EVM-PDK",
                       "identity": "evaluation_board",
                       "identity_state": "BOARD_CONFIRMED",
                       "device_datasheet_url":
                           "https://www.ti.com/lit/ds/symlink/ads8568.pdf"},
        "specs": {"scope": "onboard_device",
                  "electrical": [], "absolute_max": [],
                  "ac_performance": [], "thermal": [], "esd": [],
                  "onboard_device_specs": {
                      "device_mpn": "ADS8568", "scope": "onboard_device",
                      "electrical": list(elec or [])}},
        "pin_configuration": [],
    }


#: 独立溯源：跨容器隔离（`qc/ac_quarantine.py` V11+）只扣「没有自己的
#: bbox + row_sha256、无法证明不是原数据盲复制」的 AC 行。这里给夹具补上，
#: 让它们留在正式容器里被同步 —— 两个主题合并后不会把这些行先搬走。
PROVENANCE = {"bbox": [12.0, 34.0, 56.0, 78.0], "row_sha256": "fixture-row-sha"}

SNR_OK = {"parameter": "SNR Signal-to-noise ratio", "symbol": "SNR",
          "conditions": "At fIN = 10 kHz", "min": "91.5", "typ": "",
          "max": "", "unit": "dB", **PROVENANCE}
SFDR_WEAK = {"parameter": "SFDR Spurious-free dynamic range", "symbol": "SFDR",
             "conditions": "At fIN = 10 kHz", "value": "91.5", "unit": "dB",
             **PROVENANCE}
THD_MODEL = {"parameter": "THD Total harmonic distortion", "symbol": "THD",
             "condition": "fIN = 1 kHz", "value": "-94", "unit": "dB",
             "verification": {"status": "model_unverified",
                              "reason": "模型抽取"}, **PROVENANCE}

VERDICTS = {
    ("SNR Signal-to-noise ratio", "At fIN = 10 kHz"): "verified_row",
    ("SFDR Spurious-free dynamic range", "At fIN = 10 kHz"):
        "value_on_label_page",
    ("THD Total harmonic distortion", "fIN = 1 kHz"): "verified_row",
}


def test_sync_writes_strong_verdict_into_onboard_device_bucket():
    doc = _board_doc(elec=[dict(SNR_OK)])
    FSS.sync_doc(doc, VERDICTS)

    ver = doc["specs"]["onboard_device_specs"]["electrical"][0]["verification"]
    assert isinstance(ver, dict)
    assert ver["fact_verdict"] == "verified_row"
    assert ver["status"] == "audited_row_anchored"
    assert ver["status_source"] == "qc/fact_status_sync.py"
    assert ver["status_prev"] == ""


def test_sync_writes_weak_verdict_as_weak_status():
    """弱结论也要落成可渲染的状态，不能只留一个 fact_verdict。"""
    doc = _board_doc(elec=[dict(SFDR_WEAK)])
    FSS.sync_doc(doc, VERDICTS)

    ver = doc["specs"]["onboard_device_specs"]["electrical"][0]["verification"]
    assert ver["fact_verdict"] == "value_on_label_page"
    assert ver["status"] == "label_value_same_page"
    assert J._is_unverified({"verification": {"status": ver["status"]}})


def test_sync_does_not_wash_model_unverified_provenance():
    doc = _board_doc(elec=[dict(THD_MODEL)])
    FSS.sync_doc(doc, VERDICTS)

    ver = doc["specs"]["onboard_device_specs"]["electrical"][0]["verification"]
    assert ver["status"] == "model_unverified"
    assert ver["fact_verdict"] == "verified_row"


def test_sync_matches_verdict_by_label_and_condition():
    rows = [dict(SNR_OK),
            {"parameter": "SNR Signal-to-noise ratio", "symbol": "SNR",
             "conditions": "At fIN = 1 MHz", "min": "88.0", "typ": "",
             "max": "", "unit": "dB", **PROVENANCE}]
    doc = _board_doc(elec=rows)
    verdicts = {("SNR Signal-to-noise ratio", "At fIN = 10 kHz"): "verified_row",
                ("SNR Signal-to-noise ratio", "At fIN = 1 MHz"):
                    "value_on_label_page"}
    FSS.sync_doc(doc, verdicts)

    got = [r["verification"]["status"]
           for r in doc["specs"]["onboard_device_specs"]["electrical"]]
    assert got == ["audited_row_anchored", "label_value_same_page"]


def test_sync_reaches_unresolved_specs_bucket():
    row = dict(SFDR_WEAK)
    doc = _board_doc()
    doc["specs"]["unresolved_specs"] = {"electrical": [row]}
    FSS.sync_doc(doc, VERDICTS)

    assert row["verification"]["fact_verdict"] == "value_on_label_page"
    assert row["verification"]["status"] == "label_value_same_page"


def test_sync_still_reaches_main_container():
    row = dict(SFDR_WEAK)
    doc = _board_doc()
    doc["specs"]["electrical"] = [row]
    FSS.sync_doc(doc, VERDICTS)

    assert row["verification"]["status"] == "label_value_same_page"


def test_sync_does_not_invent_status_without_fact_verdict():
    row = dict(SFDR_WEAK)
    doc = _board_doc(elec=[row])
    FSS.sync_doc(doc, {})

    assert "verification" not in row


def test_sync_does_not_downgrade_stronger_existing_status():
    row = dict(SFDR_WEAK)
    row["verification"] = {"status": "audited_row_anchored"}
    doc = _board_doc(elec=[row])
    FSS.sync_doc(doc, VERDICTS)

    ver = row["verification"]
    assert ver["status"] == "audited_row_anchored"
    assert ver["fact_verdict"] == "value_on_label_page"


def test_sync_keeps_core_validation_in_step_with_new_quarantine():
    """同步阶段又搬走脏行时，metadata 不能停在装配时的 `pass`。"""
    doc = _board_doc()
    doc["metadata"] = {"core_validation": "pass"}
    doc["specs"]["onboard_device_specs"]["ac_performance"] = [
        _dirty_ac(i) for i in range(3)]

    res = FSS.sync_doc(doc, {})

    assert res["ac_quarantined"] == 3
    assert doc["metadata"]["core_validation"] == "pass_with_quarantine"
    assert doc["metadata"]["quarantine_count"] == 3


def test_sync_status_vocabulary_is_renderable():
    """同步写出的状态名必须能被页面识别，否则 JSON 和页面又分叉。"""
    known = J._AUDITED_STATUSES | J._UNVERIFIED_STATUSES
    missing = {v for v in FSS.STATUS_OF.values() if v not in known}
    assert not missing, f"同步状态不在渲染词表里：{sorted(missing)}"
