#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""受控分类表（1102 复审 P2-7）。

模型的 `subcategory` 是自由文本：`Data Converters` / `Data Acquisition Converters` /
`Analog to Digital Converters` / `ADC` 四种写法会在站内裂成四个类目，
ADC 就永远落不到 `Data Acquisition / ADCs` 这个细粒度节点上。

这里断言的是**收敛规则**，不是某个型号的具体分类：
命中受控表才改写，命中不了返回空（不猜、不新造类目）。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import taxonomy as T                                       # noqa: E402

ADC_PATH = ["Integrated Circuits (ICs)", "Data Acquisition", "ADCs"]
DAC_PATH = ["Integrated Circuits (ICs)", "Data Acquisition", "DACs"]


def _doc(sub, mpn="X1", desc="", features=None):
    return {"basic_info": {"subcategory": sub, "mpn": mpn, "description": desc},
            "features": features or []}


def test_coarse_data_converters_refined_to_adc_by_mpn_prefix():
    """`Data Converters` 太粗，靠型号前缀就能判成 ADC。"""
    assert T.canonical_path(_doc("Data Converters", "ADC12DJ5200SE")) == ADC_PATH
    assert T.canonical_path(_doc("Data Converters", "ADS1201U")) == ADC_PATH


def test_coarse_data_converters_refined_to_dac_by_mpn_prefix():
    assert T.canonical_path(_doc("Data Converters", "DAC3151IRGCR")) == DAC_PATH


def test_description_evidence_used_when_mpn_is_ambiguous():
    d = _doc("Data Converters", "X123", "12-bit analog-to-digital converter, 10 GSPS")
    assert T.canonical_path(d) == ADC_PATH


def test_both_adc_and_dac_mentioned_is_not_guessed():
    """描述里 ADC 与 DAC 都出现 → 不做判断，保留笼统层，绝不硬猜。"""
    d = _doc("Data Converters", "X123", "ADC front end followed by a DAC loopback")
    path = T.canonical_path(d)
    assert path[-1] == "Data Converters", path


def test_unknown_subcategory_returns_empty():
    """判不出来就返回空 —— 不新造类目名。"""
    assert T.canonical_path(_doc("Evaluation Boards", "BOOST-DRV8711")) == []
    assert T.canonical_path(_doc("", "SOMETHING")) == []


def test_apply_writes_path_but_not_subcategory():
    """`subcategory` 已进 H1 句子，改它会把 `is a {sub} from` 写坏。"""
    d = _doc("Data Converters", "ADC12DJ5200SE")
    rep = T.apply_taxonomy(d)
    assert rep["category_path"] == ADC_PATH
    assert d["basic_info"]["category_leaf"] == "ADCs"
    assert d["basic_info"]["subcategory"] == "Data Converters", "不许改 subcategory"


def test_apply_is_idempotent():
    d = _doc("Data Converters", "ADC12DJ5200SE")
    T.apply_taxonomy(d)
    rep = T.apply_taxonomy(d)
    assert rep["changed"] is False


def test_apply_noop_on_unknown():
    d = _doc("Evaluation Boards", "BOOST-DRV8711")
    assert T.apply_taxonomy(d) == {}
    assert "category_path" not in d["basic_info"]
