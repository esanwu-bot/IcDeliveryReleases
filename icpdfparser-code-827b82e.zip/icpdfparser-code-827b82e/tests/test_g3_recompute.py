"""G3 复算脚本单测：核心是防「静默漏件」。

背景（踩过的坑）
---------------
`qc/g3_recompute.py --all` 原本取 `prompt_dryrun.SAMPLES`（硬编码 10 件），
而 6a 只重解了 AFE4490 / AM6421 两件，其中 **AM6421 根本不在 SAMPLES 里**。
后果有两层，且都很难从输出看出来：

1. `--all` 静默少跑一件——没有报错，只是清单里没有；
2. 补跑单件时结果文件被整份覆盖，先后拿到两份件数不一致的结果，
   两份看起来都"合理"，于是结论可以在两份之间来回漂。

更要命的是第三层：**其余 10 件的 v2 产物与 `v2_pre6a_backup` 字节级相同**
（6a 没动过它们），所以以 `pre6a` 为基线时它们是「自己比自己」，
改善/退化/消失全为 0，PASS 是**空转**，不携带任何信息——
但它同样打印 PASS，和真跑过的 AFE4490 长得一模一样。

修法：`--all` 改为扫描 `v2/*.json` 实际产物，自动跟上后续扩样本（6c）。
本文件锁死这个行为，并顺带锁住「空转要能被识别」这件事。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import g3_recompute as GR                            # noqa: E402
from qc import prompt_dryrun as PG                           # noqa: E402


class AllMpnsTest(unittest.TestCase):
    """`--all` 的样本集必须等于 v2 目录实际产物，不能是硬编码清单。"""

    def test_covers_every_v2_artifact(self):
        v2dir = PG.OUT / "v2"
        if not v2dir.is_dir():
            self.skipTest("无 v2 产物目录（本机未跑过 dry-run）")
        on_disk = sorted(p.stem for p in v2dir.glob("*.json"))
        self.assertEqual(GR._all_mpns(), on_disk)

    def test_includes_am6421_when_present(self):
        """6a 新增件必须被 --all 覆盖——本次漏件正是出在这里。"""
        if not (PG.OUT / "v2" / "AM6421BSEFHAALVR.json").is_file():
            self.skipTest("无 AM6421 v2 产物")
        self.assertIn("AM6421BSEFHAALVR", GR._all_mpns())

    def test_falls_back_to_samples_without_dir(self):
        """目录不存在时退回 SAMPLES，而不是返回空清单。"""
        orig = PG.OUT
        try:
            PG.OUT = Path(orig) / "__nonexistent__"
            self.assertEqual(GR._all_mpns(), list(PG.SAMPLES))
        finally:
            PG.OUT = orig


class NoopRunTest(unittest.TestCase):
    """「空转」的本质：v1 与 v2 同源时，四项迁移计数全为 0。

    这一条的意义在于量级判断：11 件里有 9 件是这样的（6a 只重解了 2 件），
    它们的 PASS 不代表任何结论。测试固化这个特征，是为了让人在看到
    "全 0 + PASS" 时能立刻认出这是空转，而不是"改动很干净"。
    """

    def _doc(self):
        return {"specs": {"electrical": [
            {"name": "Supply Voltage", "value": "3.3", "unit": "V"},
            {"name": "Operating Temperature", "value": "", "unit": ""},
        ]}}

    def test_identical_docs_yield_zero_movement(self):
        stats = PG.g3_migration(self._doc(), self._doc(), ctx_v2="")
        self.assertEqual(stats["improved"], [])
        self.assertEqual(stats["regressed"], [])
        self.assertEqual(stats["new"], [])
        self.assertEqual(stats["disappeared"], [])
        self.assertEqual(len(stats["unchanged"]), 2)

    def test_missing_v2_artifact_is_reported(self):
        r = GR.run_one("__NO_SUCH_MPN__")
        self.assertFalse(r["ok"])
        self.assertEqual(r["error"], "v2 产物缺失")


class BaselinePickTest(unittest.TestCase):
    """基线口径：pre6a 优先（受控对照），退回生产 v1。"""

    def test_prefers_pre6a_backup(self):
        # `v2_pre6a_backup` 是 G3 实验产物目录，**不随仓库分发**（只在做过 6a
        # 对照实验的机器上有）。目录不在时 `_pick_baseline` 会顺着 fallback 命中
        # `data/parsed/AFE4490RHAT_*.json` —— 那不是 pre6a 基线，断言必然失败。
        # 这条要锁的是「备份存在时优先用备份」的**优先级**，备份不存在就没有
        # 可验证的对象，属于环境缺件（A/B 类），如实 skip，不把红叉当绿灯。
        if not (PG.OUT / "v2_pre6a_backup").is_dir():
            self.skipTest("无 v2_pre6a_backup 实验目录（G3 对照产物未随仓库分发）")
        p = GR._pick_baseline("AFE4490RHAT", prefer="pre6a")
        if p is None:
            self.skipTest("本机无 pre6a 备份产物")
        self.assertIn("v2_pre6a_backup", str(p))

    def test_prod_prefers_parsed(self):
        p = GR._pick_baseline("AFE4490RHAT", prefer="prod")
        if p is None or "v2_pre6a_backup" in str(p):
            # 服务器上有 pre6a 备份时，prod 口径会先命中它；
            # 只有在没有备份的场景才需要断言 data/parsed。
            self.skipTest("存在 pre6a 备份，prod 口径会先命中它")
        self.assertIn("data/parsed", str(p))

    def test_unknown_mpn_returns_none(self):
        self.assertIsNone(GR._pick_baseline("__NO_SUCH_MPN__"))


if __name__ == "__main__":
    unittest.main()
