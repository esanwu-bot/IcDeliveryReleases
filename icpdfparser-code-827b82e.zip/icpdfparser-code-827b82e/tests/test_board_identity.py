"""料号身份状态机 + 规则注册表回归（对应 docs/规则库落地参考.md 第 4 项）。

覆盖五类，防止「词表命中就判板」与「不在订货表就判死」两种过头：
    芯片 / 评估板（有证据）/ 评估板（无证据→待核验）/ 冲突 / 证据不全
"""
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import board_identity as BI                      # noqa: E402


def doc_with(orderables, mpn="X"):
    return {"ordering_info": [{"mpn": o} for o in orderables],
            "basic_info": {"mpn": mpn, "manufacturer": "Texas Instruments"}}


class RuleRegistryTest(unittest.TestCase):
    def test_registry_loads_and_has_source(self):
        rs = BI.rules()
        self.assertGreaterEqual(len(rs), 5)
        for r in rs:
            self.assertTrue(r.get("id"), r)
            self.assertIn(r.get("status"), ("active", "candidate", "deprecated"), r)
            # 每条规则必须能追溯来源，否则不允许进注册表
            self.assertTrue(r.get("source"), r["id"])
            self.assertIn(r.get("confidence"), ("low", "medium", "high"), r["id"])

    def test_selftest_cases_all_green(self):
        from qc import identity_rules as IR
        ok, bad = IR.selftest(verbose=False)
        self.assertGreater(ok, 0)
        self.assertEqual(0, bad)

    def test_candidate_rule_is_advisory_only(self):
        r = BI.match_rule("ADC128D818EB/NOPB", "Texas Instruments")
        self.assertEqual("TI_BOARD_SUFFIX_EB", r.get("id"))
        self.assertEqual("candidate", r.get("status"))
        self.assertEqual("low", r.get("confidence"))


class StateMachineTest(unittest.TestCase):
    """五态回归：任何一态判错都会让门禁失准。"""

    def test_chip_in_orderables_is_supported(self):
        doc = doc_with(["LM358DR", "LM358P"])
        info = BI.classify("LM358DR", doc, "SOIC-8", "Texas Instruments")
        self.assertEqual(BI.SUPPORTED, info["state"])
        self.assertEqual("chip", info["identity"])
        self.assertFalse(info["requires_human"])
        self.assertFalse(info["blocks_release"])

    def test_board_suffix_without_evidence_is_review_not_fail(self):
        """ADC128D818EB/NOPB 的正解：WARN + 阻断 + 人工，不是 FAIL。"""
        doc = doc_with(["ADC128D818CIMT/NOPB", "ADC128D818CIMTX/NOPB",
                        "ADC128D818CIMT/NO.A"])
        info = BI.classify("ADC128D818EB/NOPB", doc, "16-TSSOP", "Texas Instruments")
        self.assertEqual(BI.REVIEW, info["state"])
        self.assertEqual("evaluation_board", info["identity"])
        self.assertTrue(info["blocks_release"])
        self.assertTrue(info["requires_human"])
        self.assertEqual("TI_BOARD_SUFFIX_EB", info["rule_id"])

    def test_board_suffix_with_datasheet_evidence_is_confirmed(self):
        doc = doc_with([])
        pdf = "This user's guide describes the ADC128D818 evaluation board (EVM)."
        info = BI.classify("ADC128D818EB/NOPB", doc, "16-TSSOP",
                           "Texas Instruments", pdf)
        self.assertEqual(BI.CONFIRMED, info["state"])
        self.assertEqual("PASS", info["verdict"])

    def test_chip_absent_from_table_but_same_family_is_supported(self):
        """13,511 件回放：不在订货表 100% 是同族写法差异，不是冲突。

        BOM 常写族根（INA117）、旧封装（74ACT11244NSR）、军标（5962-9450901XA），
        订货表里列的是可订购全码。这类必须判 PASS，否则 641 件全成 FAIL。
        """
        doc = doc_with(["LM358DR", "LM358P", "LM358D"])
        info = BI.classify("LM358XX", doc, "SOIC-8", "Texas Instruments")
        self.assertEqual(BI.SUPPORTED, info["state"])
        self.assertEqual("medium", info["confidence"])
        self.assertEqual("PASS", info["verdict"])
        self.assertFalse(info["blocks_release"])

    def test_packaging_variant_is_supported_not_board(self):
        """ADS7822EB 里 EB 是封装代号，订货表里有这个可订购号 -> 芯片。

        这是「证据优先于词表」的核心用例：EB 规则确实命中了，
        但第 2 步的包装变体判定要先把结论定成芯片。
        """
        doc = doc_with(["ADS7822EB", "ADS7822EB250", "ADS7822EB2K5"])
        info = BI.classify("ADS7822EB/250G4", doc, "SOIC-8", "Texas Instruments")
        self.assertEqual(BI.SUPPORTED, info["state"])
        self.assertEqual("chip", info["identity"])
        self.assertFalse(BI.is_board(info))

    def test_board_suffix_remainder_is_not_packaging(self):
        """ADS1254EVM 减去 ADS1254E 剩 VM -> 绝不能当包装后缀。"""
        doc = doc_with(["ADS1254E", "ADS1254E2K5"])
        info = BI.classify("ADS1254EVM", doc, "", "Texas Instruments")
        self.assertEqual(BI.REVIEW, info["state"])
        self.assertTrue(BI.is_board(info))

    def test_short_root_does_not_swallow_other_family(self):
        """LM35 不能被 LM358 认成同族（后接数字 = 另一颗芯片）。"""
        self.assertEqual("", BI.pkg_variant("LM35", ["LM358DR"]))
        self.assertEqual([], BI._same_family("LM35", ["LM358DR"]))

    def test_family_root_falls_back_for_digit_ending_mpn(self):
        """料号以数字结尾时 family_root 会失效，必须靠公共前缀兜住。

        ADS6225IRGZ25 的家族根被算成整串，主判据拿不到同族；
        回放里这类 188 件，缺这条退路就全掉进「身份未知」。
        """
        self.assertEqual([], [o for o in ["ADS6225IRGZT", "ADS6225IRGZR"]
                              if o.startswith(BI.family_root("ADS6225IRGZ25"))])
        same = BI._same_family("ADS6225IRGZ25", ["ADS6225IRGZT", "ADS6225IRGZR"])
        self.assertEqual(["ADS6225IRGZT", "ADS6225IRGZR"], same)

    def test_common_prefix_guard_rejects_digit_gap(self):
        """公共前缀够长、但断点两边都是数字 -> 不同型号，不能算同族。"""
        # 公共前缀 ABCD1234（8 位），断点是 5 vs 7，两边都是数字
        self.assertEqual([], BI._same_family("ABCD123456", ["ABCD123478"]))
        # 断点是字母 vs 数字 -> 同族的封装差异，收
        self.assertEqual(["ABCD1234X7"], BI._same_family("ABCD12345X7",
                                                        ["ABCD1234X7"]))

    def test_boostpack_is_review_not_chip(self):
        """AWR2243BOOST 是 BoosterPack，订货表里只有板载芯片。"""
        doc = doc_with(["AWR2243ABGABLQ1", "AWR2243ABGABLRQ1"])
        info = BI.classify("AWR2243BOOST", doc, "", "Texas Instruments")
        self.assertEqual(BI.REVIEW, info["state"])
        self.assertTrue(BI.is_board(info))

    def test_board_with_own_order_code_is_confirmed(self):
        """板卡自己也有订购码（ADS122C04EVM）-> 在表内就是「可订购的板卡」。

        304 件真实数据属这类；判成芯片会把板卡按裸芯片渲染（封装/引脚全错）。
        """
        doc = doc_with(["ADS122C04EVM", "ADS112C04EVM"])
        info = BI.classify("ADS122C04EVM", doc, "", "Texas Instruments")
        self.assertEqual(BI.CONFIRMED, info["state"])
        self.assertTrue(BI.is_board(info))
        self.assertEqual("PASS", info["verdict"])
        self.assertFalse(info["blocks_release"])

    def test_conflict_requires_positive_evidence(self):
        """CONFLICT 只能由正面矛盾触发，缺匹配永远不是矛盾。"""
        doc = doc_with(["LM358DR", "LM358P"])
        info = BI.classify("LM358DR", doc, "", "Texas Instruments",
                           contradiction="PDF 首页标题写的是 TLV2372")
        self.assertEqual(BI.CONFLICT, info["state"])
        self.assertEqual("FAIL", info["verdict"])
        self.assertTrue(info["blocks_release"])

    def test_missing_table_without_section_is_advisory(self):
        """老 datasheet 本来就没有订货表 → 只提示，不阻断（否则上万件误报）。"""
        info = BI.classify("NE555P", {"ordering_info": []}, "PDIP-8", "")
        self.assertEqual(BI.INCOMPLETE, info["state"])
        self.assertTrue(info.get("advisory"))
        self.assertFalse(info["blocks_release"])

    def test_missing_table_with_section_is_blocking(self):
        """正文真有订货表（标题后面跟着料号行）却没抽到 -> 阻断，先修提取。"""
        pdf = ("PACKAGING INFORMATION\nOrderable part number\n"
               "NE555P\tPDIP-8\tTUBE OF 50\nNE555DR\tSOIC-8\tLARGE T&R\n")
        info = BI.classify("NE555P", {"ordering_info": []}, "PDIP-8", "",
                           pdf_text=pdf)
        self.assertEqual(BI.INCOMPLETE, info["state"])
        self.assertFalse(info.get("advisory") or False)
        self.assertTrue(info["blocks_release"])

    def test_section_mentioned_in_toc_is_not_a_table(self):
        """DDC118IRTCT 那种「见文档末尾 POA」只是目录句，不算有订货表 -> 仅提示。

        否则这类会被误判成「该抽到却没抽到」而无谓阻断。
        """
        pdf = ("TABLE OF CONTENTS\n"
               "ordering information, see the Package Option Addendum located at "
               "the end of this data sheet.\n")
        self.assertFalse(BI.has_ordering_section(pdf))
        info = BI.classify("DDC118IRTCT", {"ordering_info": []}, "VQFN-48", "",
                           pdf_text=pdf)
        self.assertEqual(BI.INCOMPLETE, info["state"])
        self.assertTrue(info.get("advisory"))
        self.assertFalse(info["blocks_release"])

    def test_kit_suffix_with_trailer_still_matches(self):
        """DRV2667EVM-CT / CC1020EMK-868：后缀后面还跟套件编号。"""
        for mpn in ("DRV2667EVM-CT", "CC1020EMK-868", "CC1020-CC1070DK868"):
            info = BI.classify(mpn, doc_with([]), "", "Texas Instruments")
            self.assertTrue(BI.is_board(info), mpn)

    def test_plain_chip_with_eb_like_end_is_not_board(self):
        """词表不能越过订货表：...EB 结尾但确实在订货表内的芯片仍是芯片。"""
        doc = doc_with(["ACME123EB"])
        info = BI.classify("ACME123EB", doc, "SOIC-8", "Acme")
        self.assertEqual(BI.SUPPORTED, info["state"])
        self.assertFalse(BI.is_board(info))

    def test_device_mpn_uses_family_root(self):
        doc = doc_with(["ADC128D818CIMT/NOPB", "ADC128D818CIMTX/NOPB"])
        info = BI.classify("ADC128D818EB/NOPB", doc, "", "Texas Instruments")
        self.assertEqual("ADC128D818", info["device_mpn"])


class SuffixBoundaryTest(unittest.TestCase):
    """后缀 token 的边界（`_suffix_tail` 按 token 长度分流）。

    背景：2026-10-29 回放里 12 件板卡被判 chip/PASS，5 件漏网全部出在尾部形态；
    同时 `TMS320F28P650DK6` 的 DK 被当成开发套件后缀（真误伤）。
    这两类互相牵制——放宽会误伤芯片，收紧会漏掉套件，所以按 token 长度分流：

        长 token（EVM/EVK/EMK）：`数字 + 可选分隔符尾巴` 都收（EMK868-915）
        短 token（DK/EB）：只收 >=3 位频段码（DK868），拒绝单数字（DK6）
    """

    def test_separator_tail_on_long_token(self):
        """DRV2667EVM-CT / DAC8760EMC-EVM：EVM 后面跟 -CT / 前面多一层 -。"""
        for mpn in ("DRV2667EVM-CT", "DAC8760EMC-EVM", "ADS8568EVM-PDK"):
            rule = BI.match_rule(mpn, "Texas Instruments")
            self.assertEqual("TI_BOARD_SUFFIX_EVM", rule.get("id"), mpn)

    def test_cross_vendor_generic_rule(self):
        """National Semiconductor / Silicon Labs 的套件不吃 TI 规则，靠 GENERIC 兜底。"""
        rule = BI.match_rule("DS50PCI401EVK", "National Semiconductor")
        self.assertEqual("GENERIC_BOARD_SUFFIX_EVK", rule.get("id"))
        rule = BI.match_rule("CC1101CC1190EMK915", "Silicon Labs")
        self.assertEqual("GENERIC_BOARD_SUFFIX_EMK", rule.get("id"))

    def test_long_token_frequency_variant(self):
        """CC1111EMK868-915：`\\d+` 只吃到 868，`-915` 尾巴曾被截断判成 chip/PASS。"""
        rule = BI.match_rule("CC1111EMK868-915", "Texas Instruments")
        self.assertEqual("TI_BOARD_SUFFIX_EMK", rule.get("id"))
        # 且它在订货表内 -> 精确命中 + 板卡后缀 = BOARD_CONFIRMED（不是 REVIEW）
        info = BI.classify("CC1111EMK868-915",
                           doc_with(["CC1111EMK868-915"]), "", "Texas Instruments")
        self.assertEqual(BI.CONFIRMED, info["state"])
        self.assertFalse(info["blocks_release"])

    def test_dk_with_separator_or_band_code(self):
        """DK 的真套件四种写法都要命中：结尾 / -433 / 频段码 868 / 频段码+变体。"""
        for mpn in ("CC2420ZDK", "CC1100-1150DK-433", "CC1020-CC1070DK868",
                    "CC1101DK868-915"):
            rule = BI.match_rule(mpn, "")
            self.assertEqual("GENERIC_BOARD_SUFFIX_DK", rule.get("id"), mpn)

    def test_dk_bare_single_digit_is_chip(self):
        """TMS320F28P650DK6：DK 后跟单个数字是 C2000 封装代字，不是套件。

        曾经因为 `\\d+` 收尾 + 该规则 when_orderable=board，
        在订货表精确命中时被判成 BOARD_CONFIRMED/development_kit。
        """
        self.assertEqual({}, BI.match_rule("TMS320F28P650DK6", "Texas Instruments"))
        doc = doc_with(["TMS320F28P650DK6", "TMS320F28P650DK6Z"])
        info = BI.classify("TMS320F28P650DK6", doc, "", "Texas Instruments")
        self.assertEqual(BI.SUPPORTED, info["state"])
        self.assertEqual("chip", info["identity"])
        self.assertFalse(info["blocks_release"])
        self.assertFalse(BI.is_board(info))

    def test_dk_digits_then_letters_is_chip(self):
        """F28P650DK6NMRR：`数字+字母` 从来就不是套件尾巴，必须继续拒。"""
        self.assertEqual({}, BI.match_rule("F28P650DK6NMRR", "Texas Instruments"))


class RenderLayerTest(unittest.TestCase):
    def test_sentinel_unit_not_rendered(self):
        """`12-bit not_specified` 曾随 5 个语种一起发出去。"""
        import json_to_txt as J
        self.assertEqual("12-bit", J.spec_value({"value": "12-bit",
                                                "unit": "not_specified"}))
        self.assertEqual("2.56 V", J.spec_value({"value": "2.56", "unit": "V"}))

    def test_active_low_pin_gets_overline(self):
        import symbol_svg as S
        doc = {"pin_configuration": [
            {"pin": 1, "name": "INT", "description": "Interrupt. Active Low."},
            {"pin": 2, "name": "SDA", "description": "Serial data."}]}
        low = S.active_low_of(doc)
        self.assertEqual({"INT"}, low)
        svg = S.symbol_svg([(1, "INT"), (2, "SDA")], "t", active_low=low)
        self.assertEqual(1, svg.count('stroke-width="1.4"'))


if __name__ == "__main__":
    unittest.main()
