"""`qc/i18n_restore.py` 端到端守则测试。

只做一件事：把交付包的 `multi_language` 补回生产 JSON 同名文件。
这些用例锁定"只补一个键、其余不动"和四道刹车（双开关、备份不覆盖、
件数钉死、单件失败即整批失败），全程在临时目录里跑。
"""
import contextlib
import csv
import io
import json
import tempfile
import shutil
import unittest
import zipfile
from pathlib import Path

from qc import i18n_restore as R

LANGS = ("ja", "ko", "de", "es")
PROD_KEYS = {"basic_info", "specs", "ordering_info", "seo", "metadata"}


def ml_body(full=True):
    out = {}
    for lang in LANGS:
        body = {"title": f"{lang}-t", "description": f"{lang}-d", "meta": f"{lang}-m"}
        if full:
            body["features"] = [f"{lang}-f"]
            body["applications"] = [f"{lang}-a"]
        out[lang] = body
    return out


def prod_doc(mpn):
    return {
        "basic_info": {"mpn": mpn, "requested_mpn": mpn},
        "specs": {"pins": [{"name": "VDD"}]},
        "ordering_info": {"rows": []},
        "seo": {"title": mpn},
        "metadata": {"parser_version": "v4"},
    }


class RestoreToolTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="i18n_restore_test_"))
        self.parsed = self.tmp / "parsed"
        self.delivery = self.tmp / "delivery"
        self.backup = self.tmp / "backup"
        self.parsed.mkdir()
        self.delivery.mkdir()
        self._build()
        self.plan = self.tmp / "plan.csv"
        self._write_plan(self.plan, [("A_11111111.json", "A"), ("B_22222222.json", "B"),
                                     ("C_33333333.json", "C")])

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # --- 夹具 ---------------------------------------------------------------
    def _build(self):
        with zipfile.ZipFile(self.delivery / "part-0001-of-0001.zip", "w") as zf:
            for mpn, full in (("A", True), ("B", False), ("C", True)):
                ml = ml_body(full)
                if mpn == "C":
                    del ml["ja"]["meta"]
                zf.writestr(f"{mpn}/{mpn}.json",
                            json.dumps({"basic_info": {"mpn": mpn}, "multi_language": ml},
                                       ensure_ascii=False))
        for name, mpn in (("A_11111111.json", "A"), ("B_22222222.json", "B"),
                          ("C_33333333.json", "C")):
            (self.parsed / name).write_text(json.dumps(prod_doc(mpn), ensure_ascii=False, indent=2),
                                            encoding="utf-8")

    @staticmethod
    def _write_plan(path, pairs):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=["prod_json", "mpn", "delivery_zip",
                                              "delivery_member", "delivery_langs", "status"])
            w.writeheader()
            for name, mpn in pairs:
                w.writerow({"prod_json": name, "mpn": mpn, "delivery_zip": "part-0001-of-0001.zip",
                            "delivery_member": f"{mpn}/{mpn}.json",
                            "delivery_langs": "de,es,ja,ko", "status": "READY"})

    # --- 工具 ---------------------------------------------------------------
    def argv(self, *extra, plan=None):
        return ["--plan-csv", str(plan or self.plan), "--delivery-dir", str(self.delivery),
                "--parsed-dir", str(self.parsed)] + list(extra)

    def run_main(self, *extra, plan=None):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = R.main(self.argv(*extra, plan=plan))
        return rc, buf.getvalue()

    def statuses(self, report):
        with open(report, newline="", encoding="utf-8-sig") as f:
            return {r["prod_json"]: r for r in csv.DictReader(f)}

    def sha(self, name):
        return R.sha256_file(str(self.parsed / name))

    def doc(self, name):
        return json.loads((self.parsed / name).read_text(encoding="utf-8"))

    # --- 用例 ---------------------------------------------------------------
    def test_dry_run_only_plans(self):
        report = self.tmp / "dry.csv"
        before = {n: self.sha(n) for n in ("A_11111111.json", "B_22222222.json", "C_33333333.json")}
        rc, _ = self.run_main("--report-csv", str(report))
        st = self.statuses(report)
        self.assertEqual(st["A_11111111.json"]["status"], "PLAN")
        self.assertEqual(st["B_22222222.json"]["status"], "PLAN")
        self.assertEqual(st["C_33333333.json"]["status"], "FAIL")
        self.assertEqual(rc, 1, "存在失败件时退出码必须非 0")
        self.assertEqual(before, {n: self.sha(n) for n in before}, "dry-run 不得改文件")
        self.assertFalse(self.backup.exists(), "dry-run 不得建备份目录")

    def test_write_requires_double_switch(self):
        before = self.sha("A_11111111.json")
        with self.assertRaises(SystemExit):
            self.run_main("--do-write")
        self.assertEqual(self.sha("A_11111111.json"), before)

    def test_verify_only_and_write_are_exclusive(self):
        with self.assertRaises(SystemExit):
            self.run_main("--verify-only", "--do-write", "--i-understand")

    def test_write_adds_only_multi_language(self):
        report = self.tmp / "w.csv"
        rc, out = self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup),
                                "--report-csv", str(report))
        st = self.statuses(report)
        self.assertEqual(st["A_11111111.json"]["status"], "DONE", out)
        self.assertEqual(st["B_22222222.json"]["status"], "DONE", "仅三字段的交付件应通过")
        self.assertEqual(st["C_33333333.json"]["status"], "FAIL")
        self.assertIn("meta", st["C_33333333.json"]["error"])
        self.assertEqual(rc, 1, "一件失败即整批失败")

        for name in ("A_11111111.json", "B_22222222.json"):
            doc = self.doc(name)
            self.assertEqual(set(doc), PROD_KEYS | {"multi_language"}, "只允许新增一个顶层键")
            self.assertEqual(sorted(doc["multi_language"]), ["de", "es", "ja", "ko"])
            self.assertEqual(doc["specs"]["pins"][0]["name"], "VDD", "旧字段必须原样保留")
            self.assertEqual(doc["basic_info"]["requested_mpn"], doc["basic_info"]["mpn"])
            bpath = self.backup / name
            self.assertTrue(bpath.exists())
            self.assertNotIn("multi_language", json.loads(bpath.read_text(encoding="utf-8")))
            self.assertEqual(R.sha256_file(str(bpath)), st[name]["src_sha256"],
                             "备份必须与写前源文件逐字节一致")

        self.assertEqual(self.sha("C_33333333.json"), st["C_33333333.json"]["src_sha256"],
                         "失败件不得被改写")

    def test_second_run_is_idempotent(self):
        self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup))
        after = {n: self.sha(n) for n in ("A_11111111.json", "B_22222222.json")}
        report = self.tmp / "w2.csv"
        self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup),
                      "--report-csv", str(report))
        st = self.statuses(report)
        self.assertEqual(st["A_11111111.json"]["status"], "SKIP_ALREADY")
        self.assertEqual(st["B_22222222.json"]["status"], "SKIP_ALREADY")
        self.assertEqual(after, {n: self.sha(n) for n in after}, "重跑不得改动已回填文件")

    def test_existing_backup_blocks_write(self):
        self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup))
        doc = self.doc("A_11111111.json")
        doc.pop("multi_language")
        (self.parsed / "A_11111111.json").write_text(json.dumps(doc, ensure_ascii=False, indent=2),
                                                     encoding="utf-8")
        before = self.sha("A_11111111.json")
        one = self.tmp / "plan_one.csv"
        self._write_plan(one, [("A_11111111.json", "A")])
        report = self.tmp / "collide.csv"
        rc, out = self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup),
                                "--report-csv", str(report), plan=one)
        self.assertEqual(rc, 1)
        self.assertIn("备份已存在", self.statuses(report)["A_11111111.json"]["error"], out)
        self.assertEqual(self.sha("A_11111111.json"), before, "备份冲突时不得动生产文件")

    def test_verify_only_reports_language_coverage(self):
        self.run_main("--do-write", "--i-understand", "--backup-dir", str(self.backup))
        report = self.tmp / "v.csv"
        self.run_main("--verify-only", "--report-csv", str(report))
        st = self.statuses(report)
        self.assertEqual(st["A_11111111.json"]["status"], "OK")
        self.assertEqual(st["B_22222222.json"]["status"], "OK")
        self.assertEqual(st["C_33333333.json"]["status"], "FAIL")
        self.assertIn("ja", st["C_33333333.json"]["error"])

    def test_expect_count_guard(self):
        with self.assertRaises(SystemExit):
            self.run_main("--expect-count", "5")

    def test_schema_gate(self):
        cache = {}
        zip_name = "part-0001-of-0001.zip"
        self.assertEqual(sorted(R.read_delivery_ml(cache, str(self.delivery), zip_name, "A/A.json")),
                         ["de", "es", "ja", "ko"])
        R.read_delivery_ml(cache, str(self.delivery), zip_name, "B/B.json")  # 三字段版应通过
        with self.assertRaises(ValueError):
            R.read_delivery_ml(cache, str(self.delivery), zip_name, "C/C.json")
        for zf in cache.values():
            zf.close()


class EmptyListWarningTest(unittest.TestCase):
    """空列表 vs 缺键，必须是两种处置。

    背景：2026-10-30 阶段二摸底时，172 件里有 31 件没有 `features`/`applications` 键。
    这些是**合法的三字段交付**（现有契约与 `test_write_adds_only_multi_language` 都这么定）。
    真正该报警的是「给了个空数组」——那说明上游抽取没抽到东西，写进去就是空壳。
    两条路径必须分开，否则要么误杀合法件，要么放过空壳。
    """

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="i18n_empty_"))
        self.zip = self.tmp / "part-0001-of-0001.zip"
        with zipfile.ZipFile(self.zip, "w") as zf:
            zf.writestr("ABSENT/ABSENT.json",
                        json.dumps({"multi_language": ml_body(full=False)}, ensure_ascii=False))
            body = ml_body(full=True)
            for lang in LANGS:
                body[lang]["features"] = []
                body[lang]["applications"] = []
            zf.writestr("EMPTY/EMPTY.json",
                        json.dumps({"multi_language": body}, ensure_ascii=False))
        self.cache = {}

    def tearDown(self):
        for zf in self.cache.values():
            zf.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def read(self, member):
        return R.read_delivery_ml_checked(self.cache, str(self.tmp), self.zip.name, member)

    def test_missing_optional_keys_is_legal_and_silent(self):
        ml, warns = self.read("ABSENT/ABSENT.json")
        self.assertEqual(sorted(ml), sorted(LANGS))
        self.assertEqual(warns, [], "可选字段缺键是合法的，不该报警")

    def test_empty_lists_warn_but_still_pass(self):
        ml, warns = self.read("EMPTY/EMPTY.json")
        self.assertEqual(sorted(ml), sorted(LANGS), "空列表不该被当成硬错丢掉")
        self.assertIn("features 为空", warns)
        self.assertIn("applications 为空", warns)

    def test_empty_required_field_still_hard_fails(self):
        body = ml_body(full=True)
        body["ko"]["title"] = ""
        with zipfile.ZipFile(self.tmp / "bad.zip", "w") as zf:
            zf.writestr("BAD/BAD.json", json.dumps({"multi_language": body}, ensure_ascii=False))
        with self.assertRaises(ValueError) as ctx:
            R.read_delivery_ml_checked(self.cache, str(self.tmp), "bad.zip", "BAD/BAD.json")
        self.assertIn("title", str(ctx.exception), "空标题是真空壳，必须硬拦")


if __name__ == "__main__":
    unittest.main()
