#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""料号 → PDF 的解析口径（`qc/postprocess_qwen.resolve_pdf`）。

为什么单独立一个测试文件
------------------------
2026-10-31 实跑暴露：交付 JSON 的主键是**请求型号**（`ADC12DJ5200SE`），而线上
PDF 按**可订购号**命名（`ADC12DJ5200SEAAV__adc12dj5200se.pdf`）。旧的
`_find_pdf_in` 只做精确前缀 glob，于是匹配失败 → 后处理静默降级成「未验证按键
合并」→ Reviewer #5 要求的条件钳制**一次都没在真实件上跑过**，而日志里只是一行
不显眼的 ⚠。这里把降级顺序钉死：

    exact（原名命中） > hash（pdf_hash 字节级核验） > prefix（前缀推测，必须告警）

红线（写死，不要放宽）
--------------------
1. `ADS1201U` **绝不能**匹配到 `ADS1201U-1__*.pdf` —— `-1`/`1K` 是不同档位，
   型号不同、规格不同，拿错 PDF 做「核验」比不核验更糟。
2. `ADC12DJ5200SE` 不能匹配到 `ADC12DJ5200SEEVM__*.pdf` —— EVM 手册是整机说明。
3. 有 `pdf_hash` 且能命中时，**不得**退化成按名字猜。
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from qc import postprocess_qwen as PP  # noqa: E402


def _touch(d: Path, name: str, payload: bytes = b"%PDF-1.4\n") -> Path:
    p = d / name
    p.write_bytes(payload)
    return p


def _doc(pdf_hash: str = "") -> dict:
    return {"metadata": {"pdf_hash": pdf_hash} if pdf_hash else {}}


class TestExactStillFirst:
    def test_exact_name_wins_over_others(self, tmp_path):
        exact = _touch(tmp_path, "ADC12DJ5200SE__adc12dj5200se.pdf")
        _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf")
        got, how = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"))
        assert how == "exact"
        assert got == exact


class TestOrderablePrefix:
    def test_orderable_suffix_is_resolved_by_prefix(self, tmp_path):
        """线上真实形态：文件名前缀是可订购号，JSON 主键是请求型号。"""
        body = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf")
        got, how = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"))
        assert got == body
        assert how == "prefix", how

    def test_evm_manual_is_never_picked(self, tmp_path):
        """EVM 手册排掉 —— 哪怕它是唯一候选，也不能当成器件本体。"""
        _touch(tmp_path, "ADC12DJ5200SEEVM__slau640a.pdf")
        got, how = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"))
        assert got is None, got
        assert how == "none"

    def test_dash_suffix_is_a_different_part(self, tmp_path):
        """`ADS1201U-1` 是另一档，`ADS1201U` 不得吃它。"""
        _touch(tmp_path, "ADS1201U-1__ads1201u.pdf")
        _touch(tmp_path, "ADS1201U-1K__ads1201u.pdf")
        got, how = PP.resolve_pdf(tmp_path, Path("ADS1201U.json"))
        assert got is None, f"跨档位误配：{got}"
        assert how == "none"

    def test_shortest_suffix_preferred(self, tmp_path):
        """多个可订购号共用同一份手册时，取后缀最短的（最贴近请求型号）。"""
        _touch(tmp_path, "ADC12DJ5200RFAAVT__adc12dj5200rf.pdf")
        near = _touch(tmp_path, "ADC12DJ5200RFA__adc12dj5200rf.pdf")
        got, _ = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200RF.json"))
        assert got == near, got


class TestHashBeatsName:
    def test_hash_verified_candidate_wins(self, tmp_path):
        """两个候选都合前缀，只有哈希对得上的那份才是同一文档。"""
        wrong = _touch(tmp_path, "ADC12DJ5200SEAA__adc12dj5200se.pdf", b"not-it")
        right = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"the-one")
        want = hashlib.sha256(b"the-one").hexdigest()
        got, how = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"), _doc(want))
        assert got == right, f"哈希核验没生效，选了 {got and got.name}"
        assert how == "hash"
        assert wrong != got

    def test_hash_mismatch_falls_back_to_prefix_with_warning_state(self, tmp_path):
        """哈希对不上任何候选时，仍允许前缀命中，但 how 必须是 prefix（可告警）。"""
        p = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"the-one")
        got, how = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"),
                                 _doc("0" * 64))
        assert got == p
        assert how == "prefix"


class TestNoPdf:
    def test_missing_dir_is_none(self, tmp_path):
        got, how = PP.resolve_pdf(tmp_path / "nope", Path("ADC12DJ5200SE.json"))
        assert (got, how) == (None, "none")

    def test_empty_dir_is_none(self, tmp_path):
        assert PP.resolve_pdf(tmp_path, Path("X1.json")) == (None, "none")


class TestFindPdfCompat:
    def test_legacy_signature_returns_path_only(self, tmp_path):
        p = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf")
        assert PP.find_pdf(tmp_path, Path("ADC12DJ5200SE.json")) == p


@pytest.mark.parametrize("board", ["ADC12DJ5200SEEVMPDK", "DEM-DAI1608", "BOOSTXL-C2KLED"])
def test_board_suffixes_excluded(tmp_path, board):
    _touch(tmp_path, f"{board}__x.pdf")
    got, _ = PP.resolve_pdf(tmp_path, Path("ADC12DJ5200SE.json"))
    assert got is None, got


class TestGateUsesSameResolver:
    """闸门 `locate_paths` 必须用同一套解析 —— 否则「找不到 PDF 就跳过」= 静默失效。

    取证：5 件验收里 `ADC12DJ5200SE` 的 PDF 是可订购号命名，旧 `_find_pdf_in` 找不到，
    `locate_paths` 直接返回 None，`main()` 打印「缺 JSON/PDF，跳过」并计为 missing。
    闸门没报错、也没判定，等于这件根本没审计过。
    """

    def test_find_pdf_tolerant_exact_then_hash(self, tmp_path):
        from qc import table_audit as TA

        p = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"body")
        want = hashlib.sha256(b"body").hexdigest()
        assert TA.find_pdf_tolerant(tmp_path, "ADC12DJ5200SE", want) == (p, "hash")

    def test_locate_paths_falls_back_to_tolerant(self, tmp_path, monkeypatch):
        from qc import table_audit as TA

        pdfs, parsed = tmp_path / "pdfs", tmp_path / "parsed"
        pdfs.mkdir(), parsed.mkdir()
        body = _touch(pdfs, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"body")
        want = hashlib.sha256(b"body").hexdigest()
        (parsed / "ADC12DJ5200SE.json").write_text(
            '{"metadata": {"pdf_hash": "%s"}}' % want, encoding="utf-8")

        monkeypatch.setattr(TA, "PDFS", pdfs)
        monkeypatch.setattr(TA, "PARSED", parsed)
        monkeypatch.setattr(TA, "QC_PDFS", tmp_path / "none")
        monkeypatch.setattr(TA, "QC_JSON", tmp_path / "none")
        monkeypatch.setattr(TA, "DB", tmp_path / "none.sqlite3")

        loc = TA.locate_paths("ADC12DJ5200SE")
        assert loc, "闸门仍然判「缺 PDF」——降级没接上"
        assert loc["pdf"] == body


class TestGateUsesSameResolver:
    """闸门 `locate_paths` 必须用同一套解析 —— 否则「找不到 PDF 就跳过」= 静默失效。

    取证：5 件验收里 `ADC12DJ5200SE` 的 PDF 是可订购号命名，旧 `_find_pdf_in` 找不到，
    `locate_paths` 直接返回 None，`main()` 打印「缺 JSON/PDF，跳过」并计为 missing。
    闸门没报错、也没判定，等于这件根本没审计过。
    """

    def test_find_pdf_tolerant_exact_then_hash(self, tmp_path):
        from qc import table_audit as TA

        p = _touch(tmp_path, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"body")
        want = hashlib.sha256(b"body").hexdigest()
        assert TA.find_pdf_tolerant(tmp_path, "ADC12DJ5200SE", want) == (p, "hash")

    def test_locate_paths_falls_back_to_tolerant(self, tmp_path, monkeypatch):
        from qc import table_audit as TA

        pdfs, parsed = tmp_path / "pdfs", tmp_path / "parsed"
        pdfs.mkdir(), parsed.mkdir()
        body = _touch(pdfs, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", b"body")
        want = hashlib.sha256(b"body").hexdigest()
        (parsed / "ADC12DJ5200SE.json").write_text(
            '{"metadata": {"pdf_hash": "%s"}}' % want, encoding="utf-8")

        monkeypatch.setattr(TA, "PDFS", pdfs)
        monkeypatch.setattr(TA, "PARSED", parsed)
        monkeypatch.setattr(TA, "QC_PDFS", tmp_path / "none")
        monkeypatch.setattr(TA, "QC_JSON", tmp_path / "none")
        monkeypatch.setattr(TA, "DB", tmp_path / "none.sqlite3")

        loc = TA.locate_paths("ADC12DJ5200SE")
        assert loc, "闸门仍然判「缺 PDF」——降级没接上"
        assert loc["pdf"] == body
