#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A22：热阻表多封装列（DSH Issue #14 LM317 / #15 NE555）。

背景（外审 V1 一票否决项）
-------------------------
TI 的热阻表按封装**分列**：LM317 4 列（DCY/KCS/KCT/KTT），NE555 6 列
（D/FK/JG/P/PS/PW）。旧实现「遇到参数名后向下找第一个数值」等于只读第一列，
交付 JSON 里剩下一个**没有适用封装的裸数字** —— 客户拿 66.8 去算 TO-263 的
结温会烧板子。

这里守三件事：
1. **列定义解析**：`码` 与 `(封装名)` 可能同一行多个，也可能一码一行
   （NE555 的 `D` / `(SOIC)`），单字母码不许被当成噪声；
2. **值↔封装配对**：N 个值必须按文本顺序落到 N 个封装列，占位符（`NA`/`—`）
   占列但不落行 —— 错列比缺行更难查；
3. **审计判据同源**：`table_audit.package_columns` / `audit_column_collapse`
   必须能认同一张表（否则判据说 4 列、抽取器说 1 列，两边永远对不上）。

夹具用的是**原件文本层行序**，不是 mock：本模块的全部价值就是「同一份 PDF
跑一百次结果一样」。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D                          # noqa: E402
from qc import table_audit as TA                                   # noqa: E402


class _Page:
    """够 `extract_thermal` 用的最小页对象（只吃 `get_text()`）。"""

    def __init__(self, lines):
        self._text = "\n".join(lines)

    def get_text(self):
        return self._text


# ---------------------------------------------------------------- 夹具
#: LM317 p7 文本层行序（TI SLVS044Z）。**两张表在同一页**：
#: 6.4 Legacy Chip（4 封装）与 6.5 New Chip（2 封装），同一个 DCY 的 RθJA
#: 在两张表里是 66.8 与 59.6 —— 不记表名就会变成「同名同封装两个值」。
LM317_PAGE = [
    "6.4 Thermal Information (Legacy Chip)",
    "THERMAL METRIC(1)",
    "LM317",
    "UNIT",
    "DCY", "(SOT-223)", "KCS", "(TO-220)", "KCT", "(TO-220)", "KTT", "(TO-263)",
    "4 PINS", "3 PINS", "3 PINS", "3 PINS",
    "Rθ(JA)", "Junction-to-ambient thermal resistance",
    "66.8", "23.5", "37.9", "38.0", "°C/W",
    "RθJC(top)", "Junction-to-case (top) thermal resistance",
    "43.2", "15.9", "51.1", "36.5", "°C/W",
    "RθJB", "Junction-to-board thermal resistance",
    "16.9", "7.9", "23.2", "18.9", "°C/W",
    "ψJT", "Junction-to-top characterization parameter",
    "3.6", "3.0", "13.0", "6.9", "°C/W",
    "ψJB", "Junction-to-board characterization parameter",
    "16.8", "7.8", "22.8", "17.9", "°C/W",
    "RθJC(bot)", "Junction-to-case (bottom) thermal resistance",
    "NA", "0.1", "4.2", "1.1", "°C/W",
    "(1)",
    "For more information about traditional and new thermal metrics, see the "
    "Semiconductor and IC package thermal metrics application",
    "note.",
    "6.5 Thermal Information (New Chip)",
    "THERMAL METRIC (1) (2)",
    "LM317",
    "UNIT",
    "DCY", "(SOT-223)", "KTT", "(TO-263)",
    "4 PINS", "3 PINS",
    "Rθ(JA)", "Junction-to-ambient thermal resistance",
    "59.6", "41.0", "°C/W",
    "RθJC(top)", "Junction-to-case (top) thermal resistance",
    "39.3", "43.6", "°C/W",
    "RθJB", "Junction-to-board thermal resistance",
    "8.4", "23.6", "°C/W",
    "ψJT", "Junction-to-top characterization parameter",
    "1.8", "10.4", "°C/W",
    "ψJB", "Junction-to-board characterization parameter",
    "8.3", "22.6", "°C/W",
    "RθJC(bot)", "Junction-to-case (bottom) thermal resistance",
    "—", "0.9", "°C/W",
    "(1)",
    "For more information about traditional and new thermal metrics, see the "
    "Semiconductor and IC package thermal metrics application",
    "note.",
    "(2)",
    "When surface-mount packages are used (SOT-223), the junction to ambient "
    "thermal resistance is reduced by increasing the PCB",
    "copper area that is thermally connected to the package. See the Heat Sink "
    "Requirements section for heat sink techniques.",
    "www.ti.com",
    "LM317",
    "SLVS044Z – SEPTEMBER 1997 – REVISED APRIL 2025",
    "Copyright © 2025 Texas Instruments Incorporated",
    "Submit Document Feedback",
    "7",
    "Product Folder Links: LM317",
]

#: NE555 p5 文本层行序。六个封装码里 `D` 与 `P` 是**单字母**，
#: 旧的正则 `[A-Z]{2,4}` 会把它们整列丢掉（6 列只认 4 列）。
NE555_PAGE = [
    "5.4 Thermal Information",
    "THERMAL METRIC",
    "(1)",
    "NA556,", "NE556,", "SA555,", "SE555",
    "SE555", "NA555,", "NE555", "NE555",
    "UNIT",
    "D", "(SOIC)", "FK", "(LCCC)", "JG", "(CDIP)",
    "P", "(PDIP)", "PS", "(SO)", "PW", "(TSSOP)",
    "8 PINS", "20 PINS", "8 PINS", "8 PINS", "8 PINS", "8 PINS",
    "RθJA", "Junction-to-ambient thermal resistance",
    "125.4", "92.2", "125.0", "98.5", "124.5", "164.2", "°C/W",
    "RθJC(top)", "Junction-to-case (top) thermal resistance",
    "64.9", "67.6", "73.3", "77.8", "61.2", "70.5", "°C/W",
    "RθJB", "Junction-to-board thermal resistance",
    "73.2", "66.7", "114.9", "61.0", "79.3", "104.8", "°C/W",
    "ψJT", "Junction-to-top characterization",
    "parameter",
    "14.3", "61.6", "44.4", "43.9", "16.5", "8.2", "°C/W",
    "ψJB", "Junction-to-board characterization",
    "parameter",
    "72.1", "66.5", "106.6", "60.3", "77.8", "103.1", "°C/W",
    "RθJC(bot)", "Junction-to-case (bottom) thermal",
    "resistance",
    "N/A", "14.2", "29.3", "N/A", "N/A", "N/A", "°C/W",
]


#: LM358 p5 文本层行序（TI SLOS068AB）。八个封装列，且**脚注标记**
#: `LM2904V(2)` 与封装列长得一模一样：`V(2)` 会被当成第 1 列，
#: 于是八列整体左移、`JG (CDIP)` 被 `start+40` 窗口挤出（Issue #23）。
LM358_PAGE = [
    "5.4 Thermal Information",
    "THERMAL METRIC(1)",
    "LM258, LM258A, LM358, LM358A, LM358B, LM358BA, LM2904, LM2904B,",
    "LM2904BA, LM2904V(2)",
    "LM158, LM158A",
    "UNIT",
    "D", "(SOIC)", "DGK", "(VSSOP)", "P", "(PDIP)", "PS", "(SO)",
    "PW", "(TSSOP)", "DDF", "(SOT-23)", "FK", "(LCCC)", "JG", "(CDIP)",
    "8 PINS", "8 PINS", "8 PINS", "8 PINS", "8 PINS", "8PINS", "20 PINS", "8 PINS",
    "RθJA", "Junction-to-ambient", "thermal resistance",
    "124.7", "181.4", "80.9", "116.9", "171.7", "164.3", "84.0", "112.4", "°C/W",
    "RθJC(top)", "Junction-to-case (top)", "thermal resistance",
    "66.9", "69.4", "70.4", "62.5", "68.8", "98.1", "56.9", "63.6", "°C/W",
    "RθJB", "Junction-to-board thermal", "resistance",
    "67.9", "102.9", "57.4", "68.6", "99.2", "82.1", "57.5", "100.3", "°C/W",
    "ψJT", "Junction-to-top", "characterization", "parameter",
    "19.2", "11.8", "40", "21.9", "11.5", "11.4", "51.7", "35.7", "°C/W",
    "ψJB", "Junction-to-board", "characterization", "parameter",
    "67.2", "101.2", "56.9", "67.6", "97.9", "81.7", "57.1", "93.3", "°C/W",
    "RθJC(bot)", "Junction-to-case (bottom)", "thermal resistance",
    "—", "—", "—", "—", "—", "—", "10.6", "22.3", "°C/W",
    "(1)",
    "For more information about traditional and new thermal metrics, see "
    "Semiconductor and IC Package Thermal Metrics.",
    "(2)",
    "For a listing of which devices are available in what packages, see Section 3.",
    "www.ti.com",
    "SLOS068AB – JUNE 1976 – REVISED OCTOBER 2024",
]


def _idx(lines, prefix):
    return next(i for i, s in enumerate(lines) if s.startswith(prefix))


# ---------------------------------------------------------------- 列定义
def test_lm317_package_columns_reads_two_tables():
    """一张页两张热阻表，列定义各自独立：Legacy 4 列、New 2 列。"""
    legacy, _ = D.thermal_package_columns(LM317_PAGE, _idx(LM317_PAGE, "THERMAL METRIC(1)"))
    assert [c["code"] for c in legacy] == ["DCY", "KCS", "KCT", "KTT"]
    assert [c["package"] for c in legacy] == ["SOT-223", "TO-220", "TO-220", "TO-263"]
    assert [c["pins"] for c in legacy] == [4, 3, 3, 3]

    new, _ = D.thermal_package_columns(LM317_PAGE, _idx(LM317_PAGE, "THERMAL METRIC (1) (2)"))
    assert [c["code"] for c in new] == ["DCY", "KTT"]
    assert [c["pins"] for c in new] == [4, 3]


def test_ne555_package_columns_keeps_single_letter_codes():
    """`D` / `P` 是单字母封装码，必须认出来 —— 认不出就只剩 4 列（Issue #15）。"""
    cols, _ = D.thermal_package_columns(NE555_PAGE, _idx(NE555_PAGE, "THERMAL METRIC"))
    assert [c["code"] for c in cols] == ["D", "FK", "JG", "P", "PS", "PW"]
    assert [c["package"] for c in cols] == ["SOIC", "LCCC", "CDIP", "PDIP", "SO", "TSSOP"]
    assert [c["pins"] for c in cols] == [8, 20, 8, 8, 8, 8]


def test_lm358_package_columns_ignores_footnote_marker():
    """脚注 `LM2904V(2)` 不是封装列：认成 `V (2)` 会让八列整体左移（Issue #23）。"""
    cols, _ = D.thermal_package_columns(LM358_PAGE, _idx(LM358_PAGE, "THERMAL METRIC(1)"))
    assert [c["code"] for c in cols] == ["D", "DGK", "P", "PS", "PW", "DDF", "FK", "JG"]
    assert [c["package"] for c in cols] == [
        "SOIC", "VSSOP", "PDIP", "SO", "TSSOP", "SOT-23", "LCCC", "CDIP"]
    # 引脚数必须跟列对齐：DDF(SOT-23)=8、FK(LCCC)=20、JG(CDIP)=8
    assert [c["pins"] for c in cols] == [8, 8, 8, 8, 8, 8, 20, 8]


def test_lm358_pairs_every_value_with_the_right_package():
    """8 封装 × 5 参数 + RθJC(bot) 的 2 个非空值 = 42 行，错一列就是烧板子。"""
    rows = D.extract_thermal([_Page(LM358_PAGE)])
    assert len(rows) == 42, f"实得 {len(rows)} 行"
    ja = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJA"}
    assert ja == {
        "D (SOIC) 8 PINS": "124.7",
        "DGK (VSSOP) 8 PINS": "181.4",
        "P (PDIP) 8 PINS": "80.9",
        "PS (SO) 8 PINS": "116.9",
        "PW (TSSOP) 8 PINS": "171.7",
        "DDF (SOT-23) 8 PINS": "164.3",
        "FK (LCCC) 20 PINS": "84.0",
        "JG (CDIP) 8 PINS": "112.4",
    }
    # `—` 占列不落行：RθJC(bot) 只留 FK / JG 两条
    # 真实 PDF p5 的该行是 `— ×6` 后接 `10.6@451 22.3@494`，而表头
    # `FK (LCCC)@446 | JG (CDIP)@490`，所以 10.6 属 FK、22.3 属 JG。
    # 这一条**按列坐标核对过**，不是按「第七/第八列」猜的。
    bot = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJC(bot)"}
    assert bot == {"FK (LCCC) 20 PINS": "10.6", "JG (CDIP) 8 PINS": "22.3"}


def test_one_line_with_many_packages_is_split_not_truncated():
    """一行并排多个封装（`DCY (SOT-223)  KTT (TO-263)`）必须 findall 全取。"""
    lines = ["THERMAL METRIC", "DCY (SOT-223)  KCS (TO-220)  KTT (TO-263)",
             "4 PINS 3 PINS 3 PINS", "RθJA", "Junction-to-ambient thermal resistance",
             "66.8", "23.5", "38.0", "°C/W"]
    cols, _ = D.thermal_package_columns(lines, 0)
    assert [c["code"] for c in cols] == ["DCY", "KCS", "KTT"]
    assert [c["pins"] for c in cols] == [4, 3, 3]


# ---------------------------------------------------------------- 逐列展开
def test_lm317_expands_all_packages_and_keeps_table_name():
    """34 行 = Legacy(5×4 + RθJC(bot) 3) + New(5×2 + RθJC(bot) 1)。"""
    rows = D.extract_thermal([_Page(LM317_PAGE)])
    assert len(rows) == 34, f"实得 {len(rows)} 行"
    ja = [r for r in rows if r["name"] == "RθJA"]
    assert len(ja) == 6, "Legacy 4 列 + New 2 列，每列一条"
    by_cond = {r["condition"]: r["value"] for r in ja}
    assert by_cond["Legacy Chip; DCY (SOT-223) 4 PINS"] == "66.8"
    assert by_cond["Legacy Chip; KTT (TO-263) 3 PINS"] == "38.0"
    assert by_cond["New Chip; DCY (SOT-223) 4 PINS"] == "59.6"
    # Issue #14 的原话：漏掉的那一列就是它
    top = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJC(top)"}
    assert top["New Chip; KTT (TO-263) 3 PINS"] == "43.6"
    assert top["Legacy Chip; DCY (SOT-223) 4 PINS"] == "43.2"


def test_lm317_placeholder_occupies_column_without_emitting_row():
    """`RθJC(bot)` 的 DCY 印 `NA`：可以缺这一行，**不许**把 KCS 的 0.1 写成 DCY。"""
    rows = [r for r in D.extract_thermal([_Page(LM317_PAGE)]) if r["name"] == "RθJC(bot)"]
    assert not any("DCY" in r["condition"] and "Legacy" in r["condition"] for r in rows)
    kcs = [r for r in rows if "KCS" in r["condition"] and "Legacy" in r["condition"]]
    assert kcs and kcs[0]["value"] == "0.1", "KCS 的 0.1 必须落在 KCS 列"
    # New Chip 的 DCY 是 `—`，同样不落行
    assert not any("New Chip; DCY" in r["condition"] for r in rows)


def test_ne555_pairs_every_value_with_the_right_package():
    """6 封装 × 5 参数 + RθJC(bot) 的 2 个非空值 = 32 行，且值↔封装不许错位。"""
    rows = D.extract_thermal([_Page(NE555_PAGE)])
    assert len(rows) == 32, f"实得 {len(rows)} 行"
    ja = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJA"}
    assert ja == {
        "D (SOIC) 8 PINS": "125.4",
        "FK (LCCC) 20 PINS": "92.2",
        "JG (CDIP) 8 PINS": "125.0",
        "P (PDIP) 8 PINS": "98.5",
        "PS (SO) 8 PINS": "124.5",
        "PW (TSSOP) 8 PINS": "164.2",
    }
    bot = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJC(bot)"}
    assert bot == {"FK (LCCC) 20 PINS": "14.2", "JG (CDIP) 8 PINS": "29.3"}


def test_single_package_table_without_column_header_still_extracts():
    """单封装表没有封装列定义 —— 退化成单列，**不许整张表丢成 0 行**。

    这是 A22 改动带来的回归风险：`cols` 为空时直接 `continue` 会让所有
    一封装手册的热阻全部消失（比只抽第一列更糟）。
    """
    lines = ["5.4 Thermal Information", "THERMAL METRIC", "XYZ", "UNIT",
             "RθJA", "Junction-to-ambient thermal resistance", "23.9", "°C/W"]
    rows = D.extract_thermal([_Page(lines)])
    assert len(rows) == 1
    assert rows[0]["value"] == "23.9" and rows[0]["unit"] == "°C/W"
    assert rows[0]["condition"] == "", "没有封装就没有封装条件，不许编造"


# ---------------------------------------------------------------- 审计判据
def test_package_columns_detects_single_letter_codes():
    """`table_audit.package_columns` 必须与抽取器同源认出 6 列。"""
    lines = [["", "", "D (SOIC)", "FK (LCCC)", "P (PDIP)", "PW (TSSOP)", ""]]
    tbl = {"rows": lines}
    assert [c["code"] for c in TA.package_columns(tbl)] == ["D", "FK", "P", "PW"]


def test_package_columns_rejects_unit_cells():
    """封装尺寸表 `L(mm) | W(mm) | B(mm)` 不是封装列 —— 单字母码不许误判。

    这是放宽到 `{1,4}` 后冒出来的真实误报（LM317 末页 / NE555 末页）：
    误判会让审计凭空报一张塌缩表，把已经正确的件判成阻断。
    """
    tbl = {"rows": [["Device", "PackageName", "L(mm)", "W(mm)", "T(µm)", "B(mm)"]]}
    assert TA.package_columns(tbl) == []


def test_names_package_uses_word_boundary():
    """单字母码不能靠子串判：`PDIP` 里的 p 不等于「写了封装 P」。"""
    assert TA._names_package("D (SOIC) 8 PINS", ["d", "p"])
    assert not TA._names_package("PDIP 8 PINS", ["d", "p"])
    assert not TA._names_package("Legacy chip", ["d"])
    assert TA._names_package("Legacy Chip; KTT (TO-263) 3 PINS", ["dcy", "ktt"])


def test_audit_flags_collapsed_ne555_json():
    """只取第一列、condition 全空 → 必须报 `column_collapse`（阻断）。"""
    tables = [{"page": 5, "rows": [
        ["", "", "D (SOIC)", "FK (LCCC)", "JG (CDIP)", "P (PDIP)", "PS (SO)", "PW (TSSOP)", ""],
        ["RθJA", "Junction-to-ambient thermal resistance",
         "125.4", "92.2", "125.0", "98.5", "124.5", "164.2", "°C/W"],
        ["RθJC(top)", "Junction-to-case (top) thermal resistance",
         "64.9", "67.6", "73.3", "77.8", "61.2", "70.5", "°C/W"],
        ["RθJB", "Junction-to-board thermal resistance",
         "73.2", "66.7", "114.9", "61.0", "79.3", "104.8", "°C/W"],
        ["ψJT", "Junction-to-top characterization parameter",
         "14.3", "61.6", "44.4", "43.9", "16.5", "8.2", "°C/W"],
        ["ψJB", "Junction-to-board characterization parameter",
         "72.1", "66.5", "106.6", "60.3", "77.8", "103.1", "°C/W"],
    ]}]
    collapsed = {"thermal": [
        {"name": "RθJA", "value": "125.4", "condition": ""},
        {"name": "RθJC(top)", "value": "64.9", "condition": ""},
        {"name": "RθJB", "value": "73.2", "condition": ""},
        {"name": "ψJT", "value": "14.3", "condition": ""},
        {"name": "ψJB", "value": "72.1", "condition": ""},
    ]}
    finds = TA.audit_column_collapse(tables, collapsed)
    assert finds and finds[0]["kind"] == "column_collapse"
    assert finds[0]["table"]["rows_collapsed"] == 5
    assert finds[0]["table"]["packages"] == ["D", "FK", "JG", "P", "PS", "PW"]


def test_audit_accepts_expanded_ne555_json():
    """按封装展开、condition 写明封装 → 不是塌缩，不许误杀。"""
    tables = [{"page": 5, "rows": [
        ["", "", "D (SOIC)", "FK (LCCC)", "JG (CDIP)", "P (PDIP)", "PS (SO)", "PW (TSSOP)", ""],
        ["RθJA", "Junction-to-ambient thermal resistance",
         "125.4", "92.2", "125.0", "98.5", "124.5", "164.2", "°C/W"],
        ["RθJC(top)", "Junction-to-case (top) thermal resistance",
         "64.9", "67.6", "73.3", "77.8", "61.2", "70.5", "°C/W"],
    ]}]
    expanded = {"thermal": D.extract_thermal([_Page(NE555_PAGE)])}
    assert TA.audit_column_collapse(tables, expanded) == []


# ---------------------------------------------------------------- 评审上下文
def test_sibling_rows_gives_all_expanded_entries():
    """同参数的全部 JSON 行必须一起送评委 —— 只给一条必然被判「只抽第一列」。"""
    from app.qa import controller as CT

    doc = {"specs": {"thermal": [
        {"name": "Rθ(JA)", "value": "66.8", "unit": "°C/W",
         "condition": "Legacy Chip; DCY (SOT-223) 4 PINS"},
        {"name": "RθJA", "value": "23.5", "unit": "°C/W",
         "condition": "Legacy Chip; KCS (TO-220) 3 PINS"},
        {"name": "RθJA", "value": "37.9", "unit": "°C/W",
         "condition": "Legacy Chip; KCT (TO-220) 3 PINS"},
        {"name": "RθJB", "value": "16.9", "unit": "°C/W",
         "condition": "Legacy Chip; DCY (SOT-223) 4 PINS"},
    ]}}
    sib = CT._sibling_rows(doc, {"label": "RθJA"})
    assert len(sib) == 3, "Rθ(JA) 与 RθJA 归一后是同参数，RθJB 不许混进来"
    assert {s["value"] for s in sib} == {"66.8", "23.5", "37.9"}


def test_coverage_line_counts_expansion_not_collapse():
    """原文 6 个值 / JSON 6 条 → 6/6；只有 1 条且无 condition → 1/6 且 condition 0 个。"""
    from app.reviewers import qwen_reviewer as QR

    snip = QR.Snippet(page=5, bbox=[0, 0, 0, 0], header="", row="",
                      values=[{"text": v, "x": 0} for v in
                              ("125.4", "92.2", "125.0", "98.5", "124.5", "164.2")])
    vals = ("125.4", "92.2", "125.0", "98.5", "124.5", "164.2")
    full = [{"value": v, "condition": f"pkg{i}"} for i, v in enumerate(vals)]
    line = QR.coverage_line(snip, full)
    assert "命中 6/6" in line and "condition 6 个" in line
    collapsed = [{"value": "125.4", "condition": ""}]
    line = QR.coverage_line(snip, collapsed)
    assert "命中 1/6" in line and "condition 0 个" in line
    assert "D (SOIC) 8 PINS" in QR.sibling_block(full + [{"value": "x",
                                                         "condition": "D (SOIC) 8 PINS"}])


def test_machine_column_check_verifies_expansion():
    """值↔列由坐标算：6 值 6 列对得上 → matched=6；错一列必须返回 None（交模型）。"""
    from app.reviewers import qwen_reviewer as QR

    cols = [{"code": c, "x": x} for c, x in
            zip(("D", "FK", "JG", "P", "PS", "PW"), (267, 310, 355, 403, 445, 489))]
    vals = [{"text": v, "x": x} for v, x in zip(
        ("125.4", "92.2", "125.0", "98.5", "124.5", "164.2"),
        (263, 308, 353, 398, 443, 488))]
    snip = QR.Snippet(page=5, bbox=[0, 0, 0, 0], header="", row="",
                      values=vals, columns=cols)
    sibs = [{"value": v, "condition": cond} for v, cond in zip(
        ("125.4", "92.2", "125.0", "98.5", "124.5", "164.2"),
        ("D (SOIC) 8 PINS", "FK (LCCC) 20 PINS", "JG (CDIP) 8 PINS",
         "P (PDIP) 8 PINS", "PS (SO) 8 PINS", "PW (TSSOP) 8 PINS"))]
    chk = QR.machine_column_check(snip, sibs)
    assert chk and chk["matched"] == 6
    # 错列（把 FK 的 92.2 写成 D）→ 机器不下结论，交回模型
    bad = [dict(s) for s in sibs]
    bad[0]["value"] = "92.2"
    assert QR.machine_column_check(snip, bad) is None
    # 漏列（少一条）→ 同样不下结论
    assert QR.machine_column_check(snip, sibs[:5]) is None


def test_code_in_condition_uses_word_boundary():
    """单字母码同样按词边界：`PDIP` 里的 p 不算点了 `P`。"""
    from app.reviewers import qwen_reviewer as QR

    assert QR._code_in_condition("D (SOIC) 8 PINS", ["D", "P"]) == "D"
    assert QR._code_in_condition("PDIP 8 PINS", ["D", "P"]) == ""
    assert QR._code_in_condition("Legacy Chip; KTT (TO-263) 3 PINS", ["DCY", "KTT"]) == "KTT"


def test_reconcile_drops_only_provably_false_issues():
    """被 JSON 事实否证的判词剔出结论（留痕），真问题必须留下。"""
    from app.qa import controller as CT

    doc = {"specs": {
        "thermal": [{"name": "RθJC(bot)", "value": "0.9",
                     "condition": "New Chip; KTT (TO-263) 3 PINS"}],
        "electrical": [
            {"name": "THRES current", "value": "1", "condition": ""},
            {"name": "RESET voltage level", "value": "1", "condition": ""},
        ],
    }}
    res = {"verdict": "suspect", "issues": [
        {"kind": "missing_key_param", "severity": "P0", "label": "RθJC(bot)"},
        {"kind": "condition_missing", "severity": "P1",
         "label": "THRES current, RESET voltage level"},
        {"kind": "column_collapse_suspect", "severity": "P1", "label": "RθJC(bot)"},
        {"kind": "column_collapse_suspect", "severity": "P1", "label": "RθJA"},
    ]}
    out = CT.reconcile_logic_issues(doc, res)
    assert [i["kind"] for i in out["issues"]] == ["column_collapse_suspect"], \
        "真问题不许被剔掉"
    assert len(out["filtered_issues"]) == 3
    assert all(i["rejected_by"] == "json_lookup" for i in out["filtered_issues"])
    # 整块缺失的判词只有在 JSON 里**确实没有**时才保留
    empty = {"verdict": "suspect", "issues": [
        {"kind": "missing_key_param", "severity": "P0", "label": "RθJA"}]}
    assert CT.reconcile_logic_issues({"specs": {}}, empty)["issues"]


# ---------------------------------------------------------------- 真实 PDF
LM317_PDF = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"
NE555_PDF = ROOT / "data" / "pdfs" / "NE555__ne555.pdf"
LM358_PDF = ROOT / "data" / "pdfs" / "LM358__lm358.pdf"


@pytest.mark.skipif(not LM317_PDF.exists(), reason="缺少 LM317 原件")
@pytest.mark.slow
def test_real_lm317_pdf_extracts_34_rows():
    import pymupdf
    with pymupdf.open(str(LM317_PDF)) as doc:
        rows = D.extract_thermal(doc)
        assert len(rows) == 34
        tables = TA.scan_tables(doc)
    multi = [TA.package_columns(t) for t in tables if len(TA.package_columns(t)) >= 2]
    assert sorted({tuple(c["code"] for c in cols) for cols in multi}) == [
        ("DCY", "KCS", "KCT", "KTT"), ("DCY", "KTT")]
    assert TA.audit_column_collapse(tables, {"thermal": rows}) == []


@pytest.mark.skipif(not NE555_PDF.exists(), reason="缺少 NE555 原件")
@pytest.mark.slow
def test_real_ne555_pdf_extracts_32_rows():
    import pymupdf
    with pymupdf.open(str(NE555_PDF)) as doc:
        rows = D.extract_thermal(doc)
        assert len(rows) == 32
        tables = TA.scan_tables(doc)
    codes = sorted({tuple(c["code"] for c in TA.package_columns(t))
                    for t in tables if len(TA.package_columns(t)) >= 2})
    assert codes == [("D", "FK", "JG", "P", "PS", "PW")]
    assert TA.audit_column_collapse(tables, {"thermal": rows}) == []


@pytest.mark.skipif(not LM358_PDF.exists(), reason="缺少 LM358 原件")
@pytest.mark.slow
def test_real_lm358_pdf_extracts_42_rows():
    """真实 PDF：8 封装列，脚注 `LM2904V(2)` 不得被读成封装列（Issue #23）。"""
    import pymupdf
    with pymupdf.open(str(LM358_PDF)) as doc:
        rows = D.extract_thermal(doc)
        tables = TA.scan_tables(doc)
    assert len(rows) == 42, f"实得 {len(rows)} 行"
    ja = {r["condition"]: r["value"] for r in rows if r["name"] == "RθJA"}
    assert ja["D (SOIC) 8 PINS"] == "124.7"
    assert ja["FK (LCCC) 20 PINS"] == "84.0"
    assert ja["JG (CDIP) 8 PINS"] == "112.4"
    codes = sorted({tuple(c["code"] for c in TA.package_columns(t))
                    for t in tables if len(TA.package_columns(t)) >= 2})
    assert codes == [("D", "DGK", "P", "PS", "PW", "DDF", "FK", "JG")]
    assert TA.audit_column_collapse(tables, {"thermal": rows}) == []
