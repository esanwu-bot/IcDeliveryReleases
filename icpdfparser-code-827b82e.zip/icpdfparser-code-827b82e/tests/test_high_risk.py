"""qc/high_risk.py 离线单测：批量准入清单（高风险禁批量）。"""
import io
import contextlib
import importlib
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import high_risk as H                          # noqa: E402


class HighRiskTest(unittest.TestCase):
    def test_identity_package(self):
        self.assertTrue(H.is_high_risk("basic_info.mpn"))
        self.assertTrue(H.is_high_risk("basic_info.manufacturer"))
        self.assertTrue(H.is_high_risk("specs.package.type"))
        self.assertTrue(H.is_high_risk("specs.package.pins"))

    def test_current_dim(self):
        self.assertIn("current_dim",
                      H.classify("electrical[5].value", param_name="IOIDD", unit="µA"))
        self.assertIn("current_dim",
                      H.classify("specs.electrical[5].value", param_name="Supply current"))
        self.assertNotIn("current_dim",
                         H.classify("electrical[9].value", param_name="SCL frequency",
                                    unit="kHz"))

    def test_key_elec_and_footnote(self):
        self.assertIn("key_electrical",
                      H.classify("electrical[0].value", param_name="Resolution", unit="Bits"))
        self.assertIn("footnote_link",
                      H.classify("electrical[4].value", param_name="Gain error", footnotes=[2]))

    def test_supply_range_and_abs(self):
        self.assertIn("supply_range",
                      H.classify("electrical[30].value", param_name="VDD range"))
        self.assertIn("abs_limit",
                      H.classify("specs.absolute_max[0].value", param_name="VDD max"))

    def test_pins(self):
        # 线上路径 pin[i].name，引脚名在草稿值里
        self.assertIn("power_pin", H.classify("pin[4].name", draft_name="AVDD"))
        self.assertIn("power_pin", H.classify("pin[3].name", draft_name="VREFH"))
        self.assertIn("direction_pin", H.classify("pin[8].name", draft_name="SYNC"))
        self.assertIn("direction_pin", H.classify("pin_configuration[0].name",
                                                 draft_name="T/R", draft_desc="B→A"))
        self.assertEqual(H.classify("pin[1].name", draft_name="VOUTA"), [])   # 非电源/方向 → 可批量

    def test_batchable(self):
        self.assertEqual(H.classify("features[2]"), [])
        self.assertEqual(H.classify("basic_info.category"), [])
        self.assertEqual(H.classify("electrical[9].value", param_name="SCL frequency",
                                    unit="kHz"), [])

    def test_policy_text(self):
        self.assertIn("禁止", H.HIGH_RISK_BATCH_POLICY)
        self.assertIn("quote", H.reason_text(["current_dim"]))

    def test_import_pure(self):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            importlib.reload(H)
        self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()