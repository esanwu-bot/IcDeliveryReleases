"""qc/freeze_precheck.py 离线单测：G1–G10 绿红判定 + 服务端复核行 + 退出码 + 只读性。

临时 SQLite（复用 app/db.py DDL）；不发网络请求；PDF 无需真实文件（G 系列只看元数据）。
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import freeze_precheck as FP                  # noqa: E402


class PrecheckTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="fp_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                             # noqa: E402
        self.db = db
        db.q1("SELECT 1")

    def tearDown(self):
        try:
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    # ---------- 夹具 ----------
    def _mk(self, *, mpn="BUF634PG4", status="field_review", identity="verified",
            reviewer="esan", tier="P0", official=1, sha_doc="aa", sha_gold="aa",
            tf=None, covered=None, fields=None, gold_status="review", risk_open=0):
        """fields: [(path, expected, gold_status, fe_status, page, reviewer)]"""
        db = self.db
        ev = db.x("INSERT INTO source_evidence(mpn,manufacturer,target_fields_json,status,"
                  "identity_status,verified_by,created_at,updated_at)"
                  " VALUES(?,'TI',?,?,?,?,?,?)",
                  (mpn, json.dumps(tf or [], ensure_ascii=False), status, identity, reviewer,
                   db.qc_now(), db.qc_now()))
        doc = db.x("INSERT INTO source_document(source_tier,source_type,source_url,is_official,"
                   "pdf_sha256,page_count,covered_mpn_json,identity_status,created_at,updated_at)"
                   " VALUES(?,?,?,?,?,40,?,?,?,?)",
                   (tier, "datasheet_pdf", "https://www.ti.com/x.pdf", official,
                    sha_doc, json.dumps(covered if covered is not None else [mpn]),
                    identity, db.qc_now(), db.qc_now()))
        db.x("UPDATE source_evidence SET document_id=? WHERE id=?", (doc, ev))
        gid = db.x("INSERT INTO gold_set(version,mpn,manufacturer,pdf_sha256,status,"
                   "created_at,updated_at) VALUES('v1',?,'TI',?,?,?,?)",
                   (mpn, sha_gold, gold_status, db.qc_now(), db.qc_now()))
        for p, exp, gst, fest, pg, rev in (fields or []):
            gfid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                        "cond,status) VALUES(?,?,?,?,'','',?)", (gid, p, p, exp, gst))
            if fest is not None:
                db.x("INSERT INTO source_field_evidence(evidence_id,document_id,gold_field_id,"
                     "field_path,page_number,evidence_quote,verification_status,reviewer,"
                     "created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                     (ev, doc, gfid, p, pg, "quote", fest, rev, db.qc_now()))
        for _ in range(risk_open):
            db.x("INSERT INTO risk_case(mpn,kind,priority,reason,score,status,operator,"
                 "created_at,updated_at) VALUES(?,'identity_unverified','P0','x',70,"
                 "'open','esan',?,?)", (mpn, db.qc_now(), db.qc_now()))
        return ev, gid, doc

    @staticmethod
    def _by_no(r):
        return {c["no"]: c for c in r["checks"]}

    def _allgreen(self):
        """一份 10 项全绿的夹具：2 个工作，全部 verified + 页码 + 核验人 + target 覆盖 + SHA 一致。"""
        fields = [("basic_info.mpn", "BUF634PG4", "verified", "verified", 1, "esan"),
                  ("features[0]", "portable", "verified", "verified", 1, "esan")]
        return self._mk(tf=["basic_info.mpn", "features[0]"], fields=fields)

    # ---------- 全绿 ----------
    def test_all_green_ready(self):
        ev, gid, _ = self._allgreen()
        r = FP.run(self.db, evidence_id=ev)
        by = self._by_no(r)
        bad = [c["no"] for c in r["checks"] if not c["ok"]]
        self.assertEqual(bad, [], [by[n]["detail"] for n in bad])
        self.assertEqual(len(r["checks"]), 10)
        self.assertTrue(r["server_can_freeze"], r["server_message"])
        self.assertEqual(r["missing_fe"], [])
        self.assertEqual(r["missing_tf"], [])
        txt = FP.render_text(r)
        self.assertIn("10/10 绿", txt)
        self.assertIn("冻结就绪: YES", txt)

    def test_exit_code_zero_when_green(self):
        ev, _, _ = self._allgreen()
        rc = FP.main(["--evidence-id", str(ev)])
        self.assertEqual(rc, 0)

    # ---------- 各红项 ----------
    def test_g1_source_unresolved(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, status="source_unresolved")
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[1]["ok"])
        self.assertIn("source_unresolved", by[1]["detail"])

    def test_g2_identity_not_verified(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, identity="pending")
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[2]["ok"])

    def test_g2_reviewer_missing(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, identity="verified", reviewer="")
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[2]["ok"])
        self.assertIn("null", by[2]["detail"])

    def test_g3_not_official(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, tier="P3", official=0)
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[3]["ok"])

    def test_g4_open_identity_risk(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, risk_open=1)
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[4]["ok"])
        self.assertIn("open_risk=1", by[4]["detail"])

    def test_g4_covered_mpn_required(self):
        """覆盖型号必须人工确认：covered 不含目标 MPN → 红（与服务端守卫同口径）。"""
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, covered=["OTHER"])
        r = FP.run(self.db, evidence_id=ev)
        self.assertFalse(self._by_no(r)[4]["ok"])
        self.assertFalse(r["server_can_freeze"])          # 不产生口径漂移

    def test_g5_missing_evidence_and_conflict(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan"),
                  ("features[1]", "q", "verified", None, 0, None),
                  ("features[2]", "r", "verified", "conflict_draft", 3, "esan")]
        ev, _, _ = self._mk(tf=["features[0]", "features[1]", "features[2]"], fields=fields)
        r = FP.run(self.db, evidence_id=ev)
        by = self._by_no(r)
        self.assertFalse(by[5]["ok"])
        self.assertEqual(sorted(r["missing_fe"]), ["features[1]", "features[2]"])
        self.assertIn("features[1]", FP.render_text(r))

    def test_g5_unverified_evidence_not_enough(self):
        """有证据行但未核验 → G5 红（与服务端「缺少已核验证据」同口径）。"""
        fields = [("features[0]", "p", "verified", "ready", 1, "")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields)
        r = FP.run(self.db, evidence_id=ev)
        self.assertFalse(self._by_no(r)[5]["ok"])
        self.assertIn("未核验=1", self._by_no(r)[5]["detail"])
        self.assertFalse(r["server_can_freeze"])

    def test_g6_page_zero(self):
        fields = [("features[0]", "p", "verified", "verified", 0, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields)
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[6]["ok"])

    def test_g7_reviewer_missing_on_verified(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields)
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[7]["ok"])

    def test_g8_sha_mismatch(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields, sha_doc="aa", sha_gold="bb")
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[8]["ok"])

    def test_g9_target_fields_incomplete(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan"),
                  ("features[1]", "q", "verified", "verified", 2, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields)
        r = FP.run(self.db, evidence_id=ev)
        by = self._by_no(r)
        self.assertFalse(by[9]["ok"])
        self.assertEqual(r["missing_tf"], ["features[1]"])

    def test_g10_pending_remains(self):
        fields = [("features[0]", "p", "verified", "verified", 1, "esan"),
                  ("features[1]", "q", "pending", "ready", 2, "")]
        ev, _, _ = self._mk(tf=["features[0]", "features[1]"], fields=fields)
        by = self._by_no(FP.run(self.db, evidence_id=ev))
        self.assertFalse(by[10]["ok"])
        self.assertIn("1/2", by[10]["detail"])

    # ---------- 复核行 / 退出码 / 只读 ----------
    def test_server_line_flags_divergence(self):
        """G 全绿但服务端拒绝 → 末行必须标注「不一致」（口径漂移自检的渲染）。"""
        ev, _, _ = self._allgreen()
        from qc import source_evidence as SE
        old = SE.can_freeze
        SE.can_freeze = lambda *a, **k: (False, "模拟守卫拒绝")
        try:
            r = FP.run(self.db, evidence_id=ev)
        finally:
            SE.can_freeze = old
        self.assertTrue(all(c["ok"] for c in r["checks"]))
        self.assertFalse(r["server_can_freeze"])
        txt = FP.render_text(r)
        self.assertIn("不一致", txt)
        self.assertIn("模拟守卫拒绝", json.dumps(r, ensure_ascii=False))

    def test_server_line_aligned_no_flag(self):
        """一致时不标注漂移。"""
        ev, _, _ = self._allgreen()
        txt = FP.render_text(FP.run(self.db, evidence_id=ev))
        self.assertIn("服务端can_freeze=True", txt)
        self.assertNotIn("不一致", txt)

    def test_exit_one_when_red(self):
        fields = [("features[0]", "p", "verified", "verified", 0, "esan")]
        ev, _, _ = self._mk(tf=["features[0]"], fields=fields)
        self.assertEqual(FP.main(["--evidence-id", str(ev)]), 1)

    def test_exit_three_when_missing(self):
        self.assertEqual(FP.main(["--evidence-id", "999999"]), 3)

    def test_all_batch_triage(self):
        self._allgreen()
        fields = [("features[0]", "p", "verified", "verified", 0, "esan")]
        self._mk(mpn="CD74FCT244SM96", tf=["features[0]"], fields=fields, sha_gold="bb",
                 sha_doc="bb")                                # 第二件有红（页码）
        rc = FP.main(["--all"])
        self.assertEqual(rc, 1)                              # 有红件 → 非 0
        reps = json.loads(self._out_all_json())
        self.assertEqual(len(reps), 2)

    def _out_all_json(self):
        import io
        import contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            FP.main(["--all", "--json"])
        return buf.getvalue()

    def test_readonly_no_writes(self):
        ev, gid, _ = self._allgreen()
        before = {t: self.db.q1(f"SELECT count(*) n FROM {t}")["n"] for t in
                  ("source_evidence", "source_document", "source_field_evidence",
                   "gold_field", "risk_case")}
        FP.run(self.db, evidence_id=ev)
        after = {t: self.db.q1(f"SELECT count(*) n FROM {t}")["n"] for t in before}
        self.assertEqual(before, after)
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_verification_log")["n"], 0)

    def test_import_pure(self):
        import contextlib
        import importlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            importlib.reload(FP)
        self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()