#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""D4 硬闸（Reviewer 2026-11-04 裁决契约）：`pin_validation` 字段级验证。

裁决原文契约：

    pin_validation = {
        "status": "failed",   # passed / failed / unverified
        "reason": "count_mismatch",
        "expected_count": 3,
        "actual_count": 4,
        "source": "datasheet_package_pin_table",
    }

规则（Reviewer 表，逐条锁死）：

| 情况                     | 处理                          |
|--------------------------|-------------------------------|
| 脚号重复                 | PIN 字段验证失败               |
| 脚号不连续               | PIN 字段验证失败               |
| 脚名重复且无法解释       | PIN 字段验证失败               |
| 与可信原厂封装引脚数不符 | PIN 字段验证失败               |
| 没有可信预期脚数         | `count_unverified`，不冒称通过 |
| PIN 验证失败但其他字段有效 | 其他字段照常落盘，PIN 隔离   |

三条工程红线（同源裁决）：

1. **expected 只认原厂证据**：`datasheet_package_pin_table`（热阻信息表的
   封装列，`thermal_package_columns` 同一份实现），不拿模型自抽数量、
   不拿历史冻结 JSON 当真值；
2. **多封装脚数不唯一 → 不猜**：LM317 实测 {DCY:4, KCS:3, KCT:3, KTT:3}、
   LM358 实测 8 脚群里混着 FK(LCCC)=20 —— 无法唯一对账就是
   `count_unverified`，绝不挑一个说「对上了」；
3. **字段级隔离**：PIN 失败不清空、不阻断整份 JSON，渲染（符号页）与
   打包闸门（`delivery_bundle._gate`）只隔离 PIN 字段本身。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                   # noqa: E402
from qc import engineering_model as EM                       # noqa: E402
from delivery_bundle import _gate                            # noqa: E402

LM317 = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"
LM358 = ROOT / "data" / "pdfs" / "LM358__lm358.pdf"
CDC6C = ROOT / "data" / "pdfs" / "CDC6CE025000ADLER__cdc6c.pdf"

LM317_SERVER_MODEL_BUG = [
    {"pin": "1", "name": "ADJUST", "description": "Output voltage adjustment pin."},
    {"pin": "2", "name": "OUTPUT", "description": "Output voltage pin."},
    {"pin": "3", "name": "INPUT", "description": "Input voltage pin."},
    {"pin": "4", "name": "OUTPUT", "description": "Output voltage pin."},   # ← 多编的
]


def _rows(names, first_pin=1):
    return [{"pin": str(first_pin + i), "name": n, "description": ""}
            for i, n in enumerate(names)]


# ─────────────────────────────────────────────────────────────────────
# 1. pin_field_validation —— Reviewer 契约（纯函数）
# ─────────────────────────────────────────────────────────────────────

def test_passed_against_unique_datasheet_package_pin_count():
    """唯一可信脚数且对上 → passed，契约四件套齐全。"""
    pv = DE.pin_field_validation(_rows(["IN1", "IN2", "OUT"]), {"D": 3})
    assert pv["status"] == "passed"
    assert pv["expected_count"] == 3
    assert pv["actual_count"] == 3
    assert pv["source"] == "datasheet_package_pin_table"


def test_reviewer_example_count_mismatch_is_failed():
    """裁决书原例：expected 3 / actual 4 → failed/count_mismatch。"""
    rows = _rows(["A", "B", "C", "D"])
    assert len(rows) == 4
    pv = DE.pin_field_validation(rows, {"DCY": 3})
    assert pv["status"] == "failed"
    assert pv["reason"] == "count_mismatch"
    assert pv["expected_count"] == 3
    assert pv["actual_count"] == 4
    assert pv["source"] == "datasheet_package_pin_table"


def test_multiple_package_counts_cannot_pick_one_is_unverified():
    """LM317 真实形态：DCY=4 / KCS=3 脚数不唯一 → 不猜，count_unverified。"""
    pv = DE.pin_field_validation(_rows(["A", "B", "C"]),
                                 {"DCY": 4, "KCS": 3, "KCT": 3, "KTT": 3})
    assert pv["status"] == "unverified"
    assert pv["reason"] == "count_unverified"
    assert pv["expected_counts"] == {"DCY": 4, "KCS": 3, "KCT": 3, "KTT": 3}


def test_multiple_package_counts_matching_none_is_failed():
    """脚数不唯一且一个都对不上 → failed/count_mismatch（对账信息全留）。

    注意判序：名字必须全唯一 —— 脚名重复（duplicate_pin_name）先于数量对账触发。
    """
    pv = DE.pin_field_validation(_rows(["A", "B", "C", "D", "E"]),
                                 {"DCY": 4, "KCS": 3})
    assert pv["status"] == "failed"
    assert pv["reason"] == "count_mismatch"
    assert pv["expected_count"] is None          # 无唯一期望值，不挑一个冒充
    assert pv["expected_counts"] == {"DCY": 4, "KCS": 3}


def test_no_trusted_expected_count_is_unverified_not_passed():
    """无可信预期脚数：count_unverified，绝不冒称通过。"""
    pv = DE.pin_field_validation(_rows(["A", "B", "C"]), {})
    assert pv["status"] == "unverified"
    assert pv["reason"] == "count_unverified"


def test_duplicate_pin_number_is_failed():
    rows = [{"pin": "1", "name": "A"}, {"pin": "2", "name": "B"},
            {"pin": "2", "name": "B"}]
    pv = DE.pin_field_validation(rows, {"D": 3})
    assert pv["status"] == "failed"
    assert pv["reason"] == "duplicate_pin_number"


def test_incomplete_numbering_is_failed():
    rows = [{"pin": "1", "name": "A"}, {"pin": "2", "name": "B"},
            {"pin": "4", "name": "C"}]
    pv = DE.pin_field_validation(rows, {"D": 3})
    assert pv["status"] == "failed"
    assert pv["reason"] == "incomplete_numbering"


def test_duplicate_pin_name_is_failed():
    rows = _rows(["ADJUST", "OUTPUT", "INPUT", "OUTPUT"])      # D4 服务器实跑形态
    pv = DE.pin_field_validation(rows, {"D": 4})
    assert pv["status"] == "failed"
    assert pv["reason"] == "duplicate_pin_name"
    assert pv["dup_names"] == ["OUTPUT"]


def test_repeatable_names_do_not_fail_the_name_check():
    """GND/NC/EP 天然可重复（`_REPEATABLE_PIN_NAMES` 白名单），不判失败。"""
    rows = _rows(["VCC", "GND", "IN", "GND"])
    pv = DE.pin_field_validation(rows, {})
    assert pv["status"] == "unverified"            # 没有可信脚数，仍不冒称通过
    assert pv["reason"] == "count_unverified"     # 但绝不是 duplicate_pin_name


def test_ball_numbered_rows_are_unverified_not_failed():
    """球位编号（A1/M12）是另一套编号规则，核验属于 pin_repair，这里只隔离。"""
    rows = [{"pin": "A1", "name": "VDD"}, {"pin": "B2", "name": "VSS"}]
    pv = DE.pin_field_validation(rows, {"D": 8})
    assert pv["status"] == "unverified"
    assert pv["reason"] == "ball_numbering"


def test_no_pins_at_all_is_unverified():
    assert DE.pin_field_validation([], {"D": 8})["status"] == "unverified"


# ─────────────────────────────────────────────────────────────────────
# 2. expected_pin_counts —— 可信脚数只来自 datasheet 封装表（真 PDF）
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not LM317.exists(), reason="缺少 LM317 原件")
def test_lm317_expected_counts_from_thermal_tables():
    import pymupdf
    with pymupdf.open(str(LM317)) as fd:
        got = DE.expected_pin_counts(fd)
    assert got == {"DCY": 4, "KCS": 3, "KCT": 3, "KTT": 3}


@pytest.mark.skipif(not LM358.exists(), reason="缺少 LM358 原件")
def test_lm358_expected_counts_include_the_20_pin_lccc_oddball():
    import pymupdf
    with pymupdf.open(str(LM358)) as fd:
        got = DE.expected_pin_counts(fd)
    assert got["D"] == 8
    assert got["FK"] == 20                          # 混着的怪封装，必须如实保留


@pytest.mark.skipif(not CDC6C.exists(), reason="缺少 CDC6C 原件")
def test_cdc6c_expected_counts_all_four():
    import pymupdf
    with pymupdf.open(str(CDC6C)) as fd:
        got = DE.expected_pin_counts(fd)
    assert got == {"DLE": 4, "DLF": 4, "DLX": 4, "DLY": 4}


# ─────────────────────────────────────────────────────────────────────
# 3. apply_deterministic 端到端：写 metadata.pin_validation（真 PDF）
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not LM317.exists(), reason="缺少 LM317 原件")
def test_lm317_bug_draft_gets_gate_fix_and_honest_pin_validation():
    """服务器实跑 bug 稿 → 闸门纠正 3 脚；多封装脚数不唯一 → count_unverified。

    同时锁「字段级隔离」：PIN 不冒称通过，但 3 脚数据留在 doc 里，
    整份 JSON 不因 PIN 判定失败被丢弃。
    """
    import pymupdf
    doc = {"basic_info": {"mpn": "LM317"},
           "pin_configuration": [dict(r) for r in LM317_SERVER_MODEL_BUG],
           "specs": {}}
    with pymupdf.open(str(LM317)) as fd:
        rep = DE.apply_deterministic(doc, fd)
    # 闸门（D4 已验）：
    assert [p["name"] for p in doc["pin_configuration"]] == ["ADJUST", "OUTPUT", "INPUT"]
    assert rep["pins"]["why"] == "model_pins_duplicate_name"
    # 新硬闸（Reviewer 契约）：
    pv = doc["metadata"]["pin_validation"]
    assert pv["status"] == "unverified"
    assert pv["reason"] == "count_unverified"
    assert pv["actual_count"] == 3
    assert pv["model_count"] == 4                       # 模型原稿 4 条，留证
    assert pv["expected_counts"] == {"DCY": 4, "KCS": 3, "KCT": 3, "KTT": 3}
    assert pv["gate_reason"] == "model_pins_duplicate_name"


@pytest.mark.skipif(not LM317.exists(), reason="缺少 LM317 原件")
def test_lm317_clean_draft_also_gets_unverified_count():
    """干净 3 脚稿同样不冒称通过：脚数没有唯一可信对账。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "LM317"},
           "pin_configuration": [
               {"pin": "1", "name": "ADJUST"}, {"pin": "2", "name": "OUTPUT"},
               {"pin": "3", "name": "INPUT"}],
           "specs": {}}
    with pymupdf.open(str(LM317)) as fd:
        DE.apply_deterministic(doc, fd)
    pv = doc["metadata"]["pin_validation"]
    assert pv["status"] == "unverified"
    assert pv["reason"] == "count_unverified"
    assert pv["model_count"] == 3


@pytest.mark.skipif(not LM358.exists(), reason="缺少 LM358 原件")
def test_lm358_matches_one_of_the_trusted_counts_still_unverified():
    """8 ∈ {8, …, 20}：对上其中一个封装脚数也不冒称 passed（不知道是哪个封装）。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "LM358"},
           "pin_configuration": [{"pin": "1", "name": "OUT1"}],
           "specs": {}}
    with pymupdf.open(str(LM358)) as fd:
        DE.apply_deterministic(doc, fd)
    assert len(doc["pin_configuration"]) == 8
    pv = doc["metadata"]["pin_validation"]
    assert pv["status"] == "unverified"
    assert pv["reason"] == "count_unverified"


@pytest.mark.skipif(not CDC6C.exists(), reason="缺少 CDC6C 原件")
def test_cdc6c_real_count_mismatch_is_failed_and_field_isolated():
    """真 failed 路径：CDC6C 封装表四列全 4 脚（唯一），模型给了干净的 5 条
    → count_mismatch / failed；但 5 条数据原样留在 doc，不阻断落盘（字段级隔离）。

    （确定性侧这份 PDF 只抽得到 3/4 两脚 → 缺 1/2，闸门不动模型稿，
    由硬闸对唯一可信脚数 4 对账判 failed —— 正是 Reviewer 契约原例的
    expected=4 / actual=5 形态。）
    """
    import pymupdf
    doc = {"basic_info": {"mpn": "CDC6CE025000ADLER"},
           "pin_configuration": _rows(["E1", "E2", "E3", "E4", "VDD"]),
           "specs": {}}
    with pymupdf.open(str(CDC6C)) as fd:
        rep = DE.apply_deterministic(doc, fd)
    pv = doc["metadata"]["pin_validation"]
    assert pv["status"] == "failed"
    assert pv["reason"] == "count_mismatch"
    assert pv["expected_count"] == 4
    assert pv["source"] == "datasheet_package_pin_table"
    assert pv["actual_count"] == 5 == len(doc["pin_configuration"])
    assert doc["pin_configuration"], "failed 也不许清空数据（字段级隔离）"
    assert rep["pins"]["pin_validation"]["status"] == "failed"


# ─────────────────────────────────────────────────────────────────────
# 4. 消费端：渲染符号页与打包闸门只认 pass/passed，其余 fail-closed
# ─────────────────────────────────────────────────────────────────────

_PINS8 = [{"pin": str(i), "name": f"P{i}"} for i in range(1, 9)]


def test_symbol_state_passed_means_pass():
    st = EM._symbol_state({"pin_validation": {"status": "passed"}}, _PINS8, False, "SOIC-8")
    assert st["status"] == "pass"


def test_symbol_state_failed_is_fail():
    st = EM._symbol_state({"pin_validation": {"status": "failed",
                                              "reason": "count_mismatch"}},
                         _PINS8, False, "SOIC-8")
    assert st["status"] == "fail"


def test_symbol_state_unverified_is_not_checked():
    st = EM._symbol_state({"pin_validation": {"status": "unverified",
                                              "reason": "count_unverified"}},
                         _PINS8, False, "SOIC-8")
    assert st["status"] == "not_checked"


def test_symbol_state_legacy_pass_and_fail_unchanged():
    """BGA 老契约（pass/fail/unresolved）不许被这次改动打坏。"""
    assert EM._symbol_state({"pin_validation": {"status": "pass"}},
                            _PINS8, False, "SOIC-8")["status"] == "pass"
    assert EM._symbol_state({"pin_validation": {"status": "fail"}},
                            _PINS8, False, "SOIC-8")["status"] == "fail"
    assert EM._symbol_state({"pin_validation": {"status": "unresolved"}},
                            _PINS8, False, "SOIC-8")["status"] == "not_checked"


def _gated_doc(pv_status):
    return {"basic_info": {"mpn": "X", "datasheet_url": "https://example.com/ds.pdf"},
            "metadata": {"pin_validation": {"status": pv_status}}}


def test_gate_accepts_passed_and_legacy_pass():
    assert "pin_validation" not in _gate(_gated_doc("passed"))[1]
    assert "pin_validation" not in _gate(_gated_doc("pass"))[1]


def test_gate_blocks_failed_and_unverified():
    assert "pin_validation=failed" in _gate(_gated_doc("failed"))[1]
    assert "pin_validation=unverified" in _gate(_gated_doc("unverified"))[1]


# ─────────────────────────────────────────────────────────────────────
# 1b. 可重复脚名的**族**判据（2026-11-04 重跑 V3 实测补）
#
# 起因：用 D4 硬闸重审计 V3 七件时，ADS42JB49SEK 被判
# `duplicate_pin_name`，dup_names 里躺着 `DRVDD` / `AVDD3V`；ADS1675REF 的
# 名单里躺着 `VREFP` / `VREFN`。这些都是**原厂就这么布**的多球电源/参考脚，
# 判失败等于把正常芯片打死 —— 白名单不能只枚举 `AVDD`，得按族认。
#
# 但**不能顺手把差分对也放行**：ADS42 的 `DA1P/M` 在 51/52 两脚各出现一次，
# 是模型把 P 与 M 合并成一行的真实缺陷（应为 `DA1P` / `DA1M`）。放行它
# 就把「抽取错误」洗成「合法重复」，正是这轮外审最恨的那种洗白。
# ─────────────────────────────────────────────────────────────────────

def test_power_rail_family_names_are_repeatable():
    """`AVDD3V` / `DRVDD` / `VDDIO` 这类多球电源脚按族放行，不判重名。"""
    rows = _rows(["AVDD3V", "AVDD3V", "DRVDD", "DRVDD", "DRVDD", "IOVDD"])
    pv = DE.pin_field_validation(rows, {})
    assert pv["status"] == "unverified"            # 无可信脚数 → 不冒称通过
    assert pv["reason"] == "count_unverified"
    assert "dup_names" not in pv


def test_voltage_reference_family_is_repeatable():
    """`VREFP` / `VREFN` 多球是原厂布法（ADS1675 各 2 球）。"""
    rows = _rows(["VREFP", "VREFP", "VREFN", "VREFN", "REFIN"])
    pv = DE.pin_field_validation(rows, {})
    assert pv["reason"] == "count_unverified"
    assert "dup_names" not in pv


def test_merged_differential_pair_is_still_a_failure():
    """`DA1P/M` 重复 = 模型把差分对两脚写成一行，必须判失败（不许洗白）。"""
    rows = _rows(["DA1P/M", "DA1P/M", "DA0P/M", "DA0P/M"])
    pv = DE.pin_field_validation(rows, {"RGC": 4})
    assert pv["status"] == "failed"
    assert pv["reason"] == "duplicate_pin_name"
    assert set(pv["dup_names"]) == {"DA0P/M", "DA1P/M"}


def test_single_spi_clock_duplicated_is_a_failure():
    """单组 SPI 不该有两根 SCLK：重复即模型多编，判失败。"""
    rows = _rows(["SCLK", "DOUT", "SCLK", "DOUT"])
    pv = DE.pin_field_validation(rows, {"D": 4})
    assert pv["status"] == "failed"
    assert pv["reason"] == "duplicate_pin_name"


def test_gate_blocks_when_pin_validation_is_missing():
    """**缺失 ≠ 放行**（2026-11-04 补）。

    V3-CANDIDATE 的 7 件 `metadata.pin_validation` 全为空，`_gate` 却全判
    `CLEAN` —— 「没有这道闸的记录」被读成了「这道闸放行了」。这是本轮外审
    最不能接受的那种反向误报，必须锁死。
    """
    doc = {"basic_info": {"mpn": "X", "datasheet_url": "https://example.com/ds.pdf"},
           "metadata": {}}
    gate, why = _gate(doc)
    assert gate == "BLOCKED"
    assert "pin_validation=missing" in why
