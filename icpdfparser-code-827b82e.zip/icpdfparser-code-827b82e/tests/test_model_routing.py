"""model_for() 环节级模型路由测试。"""
import os
import unittest
from parse_datasheets import model_for


class ModelForTest(unittest.TestCase):
    def setUp(self):
        # 保存原始环境变量
        self._orig = {}
        for k in list(os.environ):
            if k.startswith("ICPDF_MODEL_") or k == "DASHSCOPE_MODEL":
                self._orig[k] = os.environ[k]

    def tearDown(self):
        # 恢复原始环境变量
        for k in list(os.environ):
            if k.startswith("ICPDF_MODEL_") or k == "DASHSCOPE_MODEL":
                del os.environ[k]
        for k, v in self._orig.items():
            os.environ[k] = v

    def test_default_fallback(self):
        """不设环节变量时回退到 DASHSCOPE_MODEL。"""
        os.environ["DASHSCOPE_MODEL"] = "qwen-flash"
        self.assertEqual("qwen-flash", model_for("parse"))
        self.assertEqual("qwen-flash", model_for("review"))
        self.assertEqual("qwen-flash", model_for("alternatives"))

    def test_stage_override(self):
        """环节级变量优先。"""
        os.environ["DASHSCOPE_MODEL"] = "qwen-flash"
        os.environ["ICPDF_MODEL_PARSE"] = "qwen3.7-flash"
        os.environ["ICPDF_MODEL_REVIEW"] = "qwen3.7-plus"
        self.assertEqual("qwen3.7-flash", model_for("parse"))
        self.assertEqual("qwen3.7-plus", model_for("review"))
        self.assertEqual("qwen-flash", model_for("alternatives"))  # 未覆盖

    def test_empty_string_fallback(self):
        """空字符串视为未设置，回退到默认。"""
        os.environ["DASHSCOPE_MODEL"] = "qwen-flash"
        os.environ["ICPDF_MODEL_PARSE"] = ""
        self.assertEqual("qwen-flash", model_for("parse"))

    def test_whitespace_stripped(self):
        """前后空白被去除。"""
        os.environ["DASHSCOPE_MODEL"] = "qwen-flash"
        os.environ["ICPDF_MODEL_REVIEW"] = "  qwen3.7-plus  "
        self.assertEqual("qwen3.7-plus", model_for("review"))

    def test_case_insensitive_stage(self):
        """stage 参数大小写不敏感（内部转大写）。"""
        os.environ["DASHSCOPE_MODEL"] = "qwen-flash"
        os.environ["ICPDF_MODEL_ALTERNATIVES"] = "qwen3.7-plus"
        self.assertEqual("qwen3.7-plus", model_for("alternatives"))
        self.assertEqual("qwen3.7-plus", model_for("ALTERNATIVES"))


if __name__ == "__main__":
    unittest.main()
