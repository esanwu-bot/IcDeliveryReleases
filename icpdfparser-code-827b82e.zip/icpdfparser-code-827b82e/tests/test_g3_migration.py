"""G3 迁移判据单测：核心是锁死「跨版本行匹配」这个最容易漂移的环节。

背景（见 data/qc/gates/g3_v2.json）
----------------------------------
旧判据「v2 not_specified < v1 编数行数」口径错误，已作废。新判据改为
**按行名匹配同一批行、统计状态迁移**，不再比总数。

本文件重点防御两类回归：

1. **行名归一化过头**（实测踩过）：v2 行名常带 section 前缀——
   `Power Dissipation, PD(q)` / `Performance, Total integrated noise current`。
   若只保留「去前缀」形态，前者被剥成 `PD(q)`、后者被剥成 `Total integrated
   noise current`，与 v1 的全名/无前缀形态对不上 → 精确匹配 0 命中 →
   全部退化成「消失」，判据直接失真。

2. **改善判定过窄**：G3b 要测的正是 `GOOD_NOT_SPECIFIED → GOOD_VALUE`
   这一迁移；若只认 `BAD_* → GOOD_*` 算改善，这条会被归进 `unchanged`，
   于是「尾部保底救回了真值」这件唯一重要的事实被判据自己吞掉。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import prompt_dryrun as PG                           # noqa: E402


def _rows(*specs):
    """`specs` = `(name, value, unit)` 三元组。"""
    return [{"name": n, "value": v, "unit": u} for n, v, u in specs]


class NormNameTest(unittest.TestCase):
    """行名归一化：必须能同时容纳「带前缀」与「不带前缀」两种写法。"""

    def test_strips_non_alnum_and_case(self):
        self.assertEqual(PG._norm_name("  V-IH (max) "), "vihmax")

    def test_keys_include_prefixed_and_unprefixed_forms(self):
        """关键：两种形态都要在候选集合里，否则跨版本匹配 0 命中。"""
        keys = PG._name_keys("Power Dissipation, PD(q)")
        self.assertIn("powerdissipationpdq", keys)     # 不去前缀的全名
        self.assertIn("pdq", keys)                     # 去前缀后的符号

    def test_v1_and_v2_power_dissipation_intersect(self):
        """v1 `Power Dissipation` 与 v2 `Power Dissipation, PD(q)` 必须匹配。"""
        self.assertTrue(PG._name_keys("Power Dissipation")
                        & PG._name_keys("Power Dissipation, PD(q)"))

    def test_performance_prefix(self):
        self.assertTrue(PG._name_keys("Total integrated noise current")
                        & PG._name_keys(
                            "Performance, Total integrated noise current"))

    def test_empty_name_gives_empty_keys(self):
        self.assertEqual(PG._name_keys(""), set())


class MatchElectricalTest(unittest.TestCase):
    """三级匹配：精确 → 双向包含 → 未匹配。"""

    def test_exact_match_pairs_rows(self):
        v1 = _rows(("ICC", "5", "mA"))
        v2 = _rows(("ICC", "5.2", "mA"))
        pairs, new = PG._match_electrical(v1, v2)
        self.assertEqual(pairs, [(0, 0)])
        self.assertEqual(new, [])

    def test_one_v1_does_not_consume_multiple_v2(self):
        """一个 v1 行只占一个 v2 行，避免多行重复计入迁移。"""
        v1 = _rows(("ICC", "5", "mA"))
        v2 = _rows(("ICC", "5", "mA"), ("ICC", "7", "mA"))
        pairs, new = PG._match_electrical(v1, v2)
        self.assertEqual(len(pairs), 1)
        self.assertEqual(len(new), 1)

    def test_prefixed_v2_name_matches_v1_full_name(self):
        v1 = _rows(("Power Dissipation", "2.3", "mW"))
        v2 = _rows(("Power Dissipation, PD(q)", "2.84", "mW"))
        pairs, new = PG._match_electrical(v1, v2)
        self.assertEqual(pairs, [(0, 0)])
        self.assertEqual(new, [])

    def test_disappeared_and_new(self):
        v1 = _rows(("OLD", "1", "V"))
        v2 = _rows(("NEW", "2", "V"))
        pairs, new = PG._match_electrical(v1, v2)
        self.assertEqual(pairs, [(0, None)])       # v1 行无对应 → 消失
        self.assertEqual(new, [0])                  # v2 第 0 行未被占用 → 新增


class RowStateTest(unittest.TestCase):
    """行级状态：无取证源时**不得**指控编数（防奖惩颠倒）。"""

    def test_not_specified_is_honest_downgrade(self):
        self.assertEqual(PG._row_state({"name": "X", "value": "not_specified",
                                        "unit": "V"}), PG.GOOD_NOT_SPECIFIED)

    def test_blank(self):
        self.assertEqual(PG._row_state({"name": "X", "value": "", "unit": "V"}),
                         'BLANK')

    def test_echo_name(self):
        self.assertEqual(PG._row_state(
            {"name": "Sinx/x Correction Filters",
             "value": "Sinx/x Correction Filters", "unit": ""}),
            PG.BAD_ECHO_NAME)

    def test_no_ctx_never_accuses_fabrication(self):
        """没有上下文就不能说人家编数——这是旧判据翻车的地方。"""
        st = PG._row_state({"name": "ICC", "value": "1.234", "unit": "mA"})
        self.assertNotEqual(st, PG.BAD_FABRICATED_VALUE)

    def test_fabricated_when_number_absent_from_ctx(self):
        st = PG._row_state({"name": "ICC", "value": "9.87", "unit": "mA"},
                           ctx_text="ICC typical 1.0 mA at 25 C")
        self.assertEqual(st, PG.BAD_FABRICATED_VALUE)

    def test_good_value_when_number_present_in_ctx(self):
        st = PG._row_state({"name": "ICC", "value": "1.0", "unit": "mA"},
                           ctx_text="ICC typical 1.0 mA at 25 C")
        self.assertEqual(st, PG.GOOD_VALUE)


class CtxSnippetTest(unittest.TestCase):
    """取证必须留原文片段——否则「真值丢失」没法人工裁决。

    实测踩过：AFE4490 有 4 行 v1 值在新上下文里**都命中了数字**，按
    「数字在不在上下文」判会全部算成「真值丢失/退化」。但核对原文才发现，
    那 4 行的名字都出现在 **Features 项目符号段落**（`–` 分隔的散文），
    不是电气表行——它们消失正是 4c 规则要达到的效果，属于清理而非退化。
    所以判据输出必须带原文，由人确认，不能只给布尔值。
    """

    def test_returns_empty_when_no_text_or_name(self):
        self.assertEqual(PG._ctx_snippet("", "ICC"), "")
        self.assertEqual(PG._ctx_snippet("some text", ""), "")

    def test_returns_empty_when_name_absent(self):
        self.assertEqual(PG._ctx_snippet("nothing here at all", "ICC"), "")

    def test_snippet_includes_following_text(self):
        ctx = "ICC typical 1.0 mA at 25 C"
        sn = PG._ctx_snippet(ctx, "ICC")
        self.assertIn("ICC", sn)
        self.assertIn("mA", sn)

    def test_snippet_collapses_whitespace(self):
        ctx = "ICC\n  typical   1.0 mA"
        self.assertNotIn("\n", PG._ctx_snippet(ctx, "ICC"))


class G3MigrationTest(unittest.TestCase):
    """迁移统计：行集守恒 + 改善/退化归类。"""

    def test_notspec_to_value_is_improvement(self):
        v1 = _rows(("Power Dissipation", "not_specified", "mW"))
        v2 = _rows(("Power Dissipation, PD(q)", "2.84", "mW"))
        st = PG.g3_migration({"specs": {"electrical": v1}},
                              {"specs": {"electrical": v2}}, ctx_v2="2.84 mW")
        self.assertEqual(len(st["improved"]), 1)
        self.assertEqual(st["improved"][0]["kind"], "notspec_to_value")

    def test_real_value_disappearing_is_regression(self):
        v1 = _rows(("ICC", "5", "mA"))
        v2 = _rows(("ICC", "5", "mA"))
        # 上下文里没有 5，但 v2 与 v1 同值 → 仍判 GOOD（有 unit+数值）
        st = PG.g3_migration({"specs": {"electrical": v1}},
                             {"specs": {"electrical": v2}}, ctx_v2="")
        self.assertEqual(len(st["regressed"]), 0)

    def test_row_count_conservation(self):
        """不变量：improved + regressed + unchanged + disappeared == len(v1_rows)。"""
        v1 = _rows(("A", "1", "V"), ("B", "not_specified", "V"),
                   ("C", "", "V"))
        v2 = _rows(("A", "1", "V"), ("D", "9", "V"))
        st = PG.g3_migration({"specs": {"electrical": v1}},
                             {"specs": {"electrical": v2}}, ctx_v2="")
        total = (len(st["improved"]) + len(st["regressed"])
                 + len(st["unchanged"]) + len(st["disappeared"]))
        self.assertEqual(total, len(v1))

    def test_new_rows_recorded(self):
        v1 = _rows(("A", "1", "V"))
        v2 = _rows(("A", "1", "V"), ("NEW", "3", "V"))
        st = PG.g3_migration({"specs": {"electrical": v1}},
                             {"specs": {"electrical": v2}}, ctx_v2="")
        self.assertEqual(len(st["new"]), 1)
        self.assertEqual(st["new"][0]["v2_name"], "NEW")

    def test_empty_docs_do_not_explode(self):
        st = PG.g3_migration({}, {})
        self.assertEqual(sum(len(v) for v in st.values()), 0)


class GateG3Test(unittest.TestCase):
    """门禁判定：pass 由 G3a/G3c + 适用时的 G3b/G3e 决定，G3d 已降级为 INFO。"""

    def test_clean_migration_passes(self):
        v1 = _rows(("Power Dissipation", "not_specified", "mW"))
        v2 = _rows(("Power Dissipation, PD(q)", "2.84", "mW"))
        g = PG.gate_g3(PG.g3_migration({"specs": {"electrical": v1}},
                                        {"specs": {"electrical": v2}},
                                        ctx_v2="2.84 mW"))
        self.assertTrue(g["pass"])
        self.assertTrue(g["G3a"] and g["G3b"] and g["G3c"])

    def test_real_value_loss_fails_g3c(self):
        """真值丢失必须 FAIL——这是不可接受的退化。"""
        v1 = _rows(("ICC", "5", "mA"), ("GONE", "7", "mA"))
        v2 = _rows(("ICC", "5", "mA"))
        ctx = "ICC 5 mA"
        st = PG.g3_migration({"specs": {"electrical": v1}},
                             {"specs": {"electrical": v2}}, ctx_v2=ctx)
        # 人工构造：把 GONE 行标成 BAD，模拟真值退化
        st["regressed"].append({"v1_name": "GONE", "v2_name": None,
                                "v1_state": PG.GOOD_VALUE,
                                "v2_state": PG.BAD_MISSING_VALUE,
                                "v1_value": "7", "v2_value": None})
        g = PG.gate_g3(st)
        self.assertFalse(g["G3c"])
        self.assertFalse(g["pass"])

    def test_g3d_lost_good_value_not_fail(self):
        """G3d 降级后：消失含 GOOD_VALUE 也不得让 pass 变 False。

        实测 AFE4490 的 4 行消失值经原文核对全部出自 Features 项目符号段落，
        正是 4c 要清除的对象。若按「消失 GOOD_VALUE → FAIL」判，等于把要清的
        垃圾当资产保护——奖惩颠倒。
        """
        stats = {'improved': [], 'regressed': [], 'unchanged': [],
                 'disappeared': [{'v1_name': 'Low Power', 'v1_value': '< 2.3 mW',
                                   'v1_state': PG.GOOD_VALUE}], 'new': []}
        g = PG.gate_g3(stats, "Low Power: < 2.3 mW at 3.0-V Supply")
        self.assertTrue(g['pass'])
        self.assertEqual(g['G3d']['status'], 'INFO')
        self.assertEqual(g['G3d']['count'], 1)

    def test_g3d_rows_carry_snippet(self):
        """INFO 行必须带 `ctx_snippet`——防「只给布尔不给证据」重演。"""
        stats = {'improved': [], 'regressed': [], 'unchanged': [],
                 'disappeared': [{'v1_name': 'LED Current',
                                   'v1_value': '50 mA~200 mA',
                                   'v1_state': PG.GOOD_VALUE}], 'new': []}
        g = PG.gate_g3(stats, "LED Current: 50 mA to 200 mA")
        rows = g['G3d']['rows']
        self.assertEqual(len(rows), 1)
        self.assertIn("LED Current", rows[0].get('ctx_snippet') or '')

    def test_g3a_fabrication_still_blocks(self):
        """降级 G3d 不等于放松：编数/回灌残留仍必须 FAIL。"""
        stats = {'improved': [], 'regressed': [], 'unchanged': [],
                 'disappeared': [],
                 'new': [{'v2_name': 'X', 'v2_value': 'X',
                          'v2_state': PG.BAD_ECHO_NAME}]}
        g = PG.gate_g3(stats, "")
        self.assertFalse(g['G3a'])
        self.assertFalse(g['pass'])

    def test_g3c_still_catches_regression(self):
        """G3d 降级不等于放弃保护：真退化仍由 G3c 兜住。"""
        stats = {'improved': [], 'unchanged': [], 'new': [],
                 'disappeared': [],
                 'regressed': [{'v1_name': 'ICC', 'v2_name': 'ICC',
                                'v1_state': PG.GOOD_VALUE,
                                'v2_state': PG.BAD_MISSING_VALUE,
                                'v1_value': '5', 'v2_value': ''}]}
        g = PG.gate_g3(stats, "anything")
        self.assertFalse(g['G3c'])
        self.assertFalse(g['pass'])

    def test_no_baseline_not_specified_marks_g3b_na(self):
        """AM6421 形态：基线无占位行 → G3b 不适用，不误报 FAIL。"""
        v1 = _rows(("Supply Voltage", "", ""),
                   ("Operating Temp", "", ""))
        v2 = _rows(("Input slew rate", "2~8.5", "V/ns"))
        g = PG.gate_g3(PG.g3_migration({"specs": {"electrical": v1}},
                                        {"specs": {"electrical": v2}},
                                        ctx_v2="2 8.5"))
        self.assertIn("不适用", g["G3b_note"])
        self.assertTrue(g["G3b"])
        self.assertTrue(g["G3d"])


if __name__ == "__main__":
    unittest.main()
