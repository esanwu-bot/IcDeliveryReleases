#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`content-signoff/v2` 的契约：11 个字段、决策常量、以及**不写自指哈希**。

复核方要的是「谁签、何时签、接受了什么风险、放弃了哪些维度、证据在 PDF 哪一页」。
这四件事缺一条，签核文件就退回成一个布尔值 —— 而布尔值无法承担法律合规效力。
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import signoff_v2 as SV                                 # noqa: E402

MPN = "LM317"


def _staging(tmp: Path) -> Path:
    st = tmp / "staging"
    (st / "parsed").mkdir(parents=True)
    (st / "facts_audit.json").write_text(json.dumps({
        "mpns": {MPN: {
            "n_rows": 3, "verdict": "pass", "anchor_gate": "blocked",
            "by_kind": {"table": {"required": "row_anchor", "ok": 1, "total": 3}},
            "blocked": ["RθJA (have=container_verified, need=row_anchor)",
                        "RθJA (have=container_verified, need=row_anchor)"],
        }}}, ensure_ascii=False), encoding="utf-8")
    # 逐行事实（含 container）：维度划分只认这份，`by_kind` 只有 table/prose 两桶。
    # 这里刻意让 absolute_max 全数到坐标级、thermal 一条都没到，好验证
    # approved/excluded 两侧都非空 —— 空批复是外审 P1，必须能被用例区分出来。
    with (st / "facts_audit.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["mpn", "container", "label", "verdict"])
        w.writeheader()
        w.writerow({"mpn": MPN, "container": "absolute_max",
                    "label": "VIN", "verdict": "verified_row"})
        w.writerow({"mpn": MPN, "container": "thermal",
                    "label": "RθJA", "verdict": "verified"})
        w.writerow({"mpn": MPN, "container": "thermal",
                    "label": "RθJA", "verdict": "verified"})
    with (st / "risk_queue.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["mpn", "container", "label", "value",
                                          "unit", "source", "verdict",
                                          "suggested_action", "note", "page"])
        w.writeheader()
        w.writerow({"mpn": MPN, "label": "RθJA", "page": "4", "verdict": "verified"})
        w.writerow({"mpn": MPN, "label": "RθJA", "page": "5", "verdict": "verified"})
    (st / "parsed" / f"{MPN}.json").write_text(json.dumps({
        "metadata": {"pin_validation": {"status": "unverified",
                                        "reason": "count_unverified"}}}),
        encoding="utf-8")
    return st


def test_required_fields_are_eleven():
    assert len(SV.REQUIRED_FIELDS) == 11
    for k in ("mpn", "reviewer", "reviewed_at", "decision", "machine_anchor_gate",
              "risk_accepted", "approved_dimensions", "excluded_dimensions",
              "evidence_refs", "reason", "package_sha256"):
        assert k in SV.REQUIRED_FIELDS


def test_build_emits_all_fields(tmp_path):
    st = _staging(tmp_path)
    out = st / "signoff.json"
    assert SV.build(st, out, out) == 0
    doc = json.loads(out.read_text(encoding="utf-8"))
    rec = doc["mpns"][MPN]
    for k in SV.REQUIRED_FIELDS:
        assert k in rec, f"缺字段 {k}"
    assert rec["decision"] == "APPROVED_WITH_WARNINGS"
    assert rec["machine_anchor_gate"] == "BLOCKED"
    # 与打包器兼容的四个键仍在（否则状态机会把签核读成 NONE）
    assert rec["content_approved"] is True
    assert rec["release_approved"] is False


def test_package_sha256_inside_zip_is_null():
    """ZIP 内的签核文件不可能知道自己所在 ZIP 的哈希 —— 写 `null` 才是诚实的。"""
    st = _staging(Path(__file__).parent / "_tmp_signoff")
    try:
        out = st / "signoff.json"
        SV.build(st, out, out)
        doc = json.loads(out.read_text(encoding="utf-8"))
        assert doc["mpns"][MPN]["package_sha256"] is None
        assert doc["binding"]["package_sha256"] is None
        assert "自指" in doc["mpns"][MPN]["package_sha256_note"]
    finally:
        import shutil
        shutil.rmtree(st.parent, ignore_errors=True)


def test_evidence_refs_point_to_pdf_pages(tmp_path):
    st = _staging(tmp_path)
    out = st / "signoff.json"
    SV.build(st, out, out)
    rec = json.loads(out.read_text(encoding="utf-8"))["mpns"][MPN]
    ev = rec["evidence_refs"]
    assert ev and ev[0]["pdf"] == f"{MPN}.pdf"
    assert ev[0]["pages"] == ["4", "5"]
    assert ev[0]["page_unresolved"] is False
    # 指不到页码时必须显式标记，不许拿一个看起来合理的数字凑
    assert rec["excluded_dimensions"], "未达标维度必须被写出来"


def test_dimensions_split_per_container(tmp_path):
    """维度划分必须逐容器算，不能退回 table/prose 聚合口径。

    聚合口径下「table 54/60 ok」会被读成「这个维度没批准」，于是签核人明明
    逐字段审过、`approved_dimensions` 却是空数组 —— 外审 P1 的原形。
    """
    st = _staging(tmp_path)
    out = st / "signoff.json"
    SV.build(st, out, out)
    rec = json.loads(out.read_text(encoding="utf-8"))["mpns"][MPN]
    ap, ex = rec["approved_dimensions"], rec["excluded_dimensions"]
    assert ap, "全数到坐标级的容器必须进 approved，空批复即自相矛盾"
    assert any("container:absolute_max (1/1 anchored)" in x for x in ap)
    assert any("container:thermal (0/2 anchored)" in x for x in ex)
    # 引脚接线级可用性永远进 excluded，不管 pin_validation 是哪一档
    assert any("electrical_pin_mapping_unverified" in x for x in ex)
    # 容器行加前缀，免得和 electrical_pin_mapping 混为一谈
    assert all(x.startswith(("container:", "identity ")) for x in ap + ex
               if "pin_mapping" not in x)


def test_empty_approval_is_rejected(tmp_path):
    """approve 了却一个维度都没批 —— 构建期就该炸，不许打进包里。"""
    st = _staging(tmp_path)
    with (st / "facts_audit.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["mpn", "container", "label", "verdict"])
        w.writeheader()
        w.writerow({"mpn": MPN, "container": "thermal",
                    "label": "RθJA", "verdict": "verified"})
    try:
        SV.build(st, st / "signoff.json", st / "signoff.json")
    except SystemExit as e:
        assert "approved_dimensions 为空" in str(e)
    else:
        raise AssertionError("空批复必须被拒绝")


def test_binding_covers_facts_and_risk(tmp_path):
    """双口径并存：raw 与 normalized 各自有值，且都能被重算出来。

    只测一个口径的话，首版那种「两处报告各用一个口径、读起来像绑错文件」的
    问题会再次漏过 —— 这两种哈希**都必须**在 binding 里出现且各自正确。
    """
    import hashlib
    st = _staging(tmp_path)
    out = st / "signoff.json"
    SV.build(st, out, out)
    b = json.loads(out.read_text(encoding="utf-8"))["binding"]
    for path, stem in ((st / "facts_audit.json", "facts_audit"),
                       (st / "risk_queue.csv", "risk_queue")):
        raw = path.read_bytes()
        assert b[f"{stem}_sha256_raw"] == hashlib.sha256(raw).hexdigest()
        assert (b[f"{stem}_sha256_normalized"]
                == hashlib.sha256(raw.replace(b"\r\n", b"\n")).hexdigest())
        # 两个口径同名不同值会出合规事故，命名必须能区分开
        assert f"{stem}_sha256_raw" != f"{stem}_sha256_normalized"
