import hashlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from qc import delivery_history as DH


MANIFEST = ("mpn,gold_id,fields,not_specified,pdf_sha256\n"
            "ABC123,1,36/36,5," + "a" * 64 + "\n"
            "XYZ789,2,69/69,1," + "b" * 64 + "\n")


def make_batch(base: Path, bid="r6-20260102", with_zip=True, dir_manifest=True,
               report_name="核验报告.md"):
    p = base / bid
    p.mkdir(parents=True)
    if dir_manifest:
        (p / "manifest.csv").write_text(MANIFEST, encoding="utf-8-sig")
    (p / report_name).write_text("# 报告\n\n| a | b |\n|---|---|\n| 1 | 2 |\n",
                                 encoding="utf-8")
    (p / "r6_quality_audit.json").write_text(json.dumps({
        "audit_version": 2,
        "package": "r6 两件",
        "release_approved": False,
        "layers": {"L1": {"status": "PASS", "PASS": 3, "FAIL": 0, "NOT_CHECKED": 0},
                   "L2": {"status": "NOT_CHECKED", "PASS": 2, "FAIL": 0, "NOT_CHECKED": 1},
                   "L3": {"status": "PASS", "PASS": 3, "FAIL": 0, "NOT_CHECKED": 0},
                   "L4": {"status": "FAIL", "PASS": 1, "FAIL": 1, "NOT_CHECKED": 0}},
        "release_gates": {
            "PACKAGE_PASS": {"status": "PASS"},
            "PROVENANCE_PASS": {"status": "NOT_CHECKED"},
            "DATA_SEMANTICS_PASS": {"status": "NOT_CHECKED"},
            "DOWNSTREAM_PASS": {"status": "FAIL"},
            "RELEASE_APPROVED": {"status": "FAIL", "approved": False},
        },
        "supplemental_summary": {"total": 7, "PASS": 2, "FAIL": 2, "NOT_CHECKED": 3},
        "summary": {"PASS": 9, "FAIL": 1, "NOT_CHECKED": 1},
    }), encoding="utf-8")
    if with_zip:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("manifest.csv", MANIFEST)
        (p / (bid + ".zip")).write_bytes(buf.getvalue())
    return p


class DeliveryHistoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        make_batch(self.base)
        (self.base / "not-a-batch").mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def test_list_and_fields(self):
        bs = DH.list_batches(self.base)
        self.assertEqual(len(bs), 1)
        b = bs[0]
        self.assertEqual(b["id"], "r6-20260102")
        self.assertEqual(b["date"], "2026-01-02")
        self.assertEqual(b["mpns"], ["ABC123", "XYZ789"])
        self.assertEqual(b["sample_count"], 2)
        self.assertEqual(b["fields_total"], 105)
        self.assertEqual(b["verdict"], "PARTIAL")
        self.assertIn("L2", b["verdict_note"])
        self.assertTrue(b["report"]["available"])
        self.assertTrue(b["report"]["json"])
        self.assertEqual(b["audit_version"], 2)
        self.assertEqual(b["release"]["approved"], False)
        self.assertEqual(b["release"]["status"], "FAIL")
        self.assertEqual(b["release"]["gates"]["PACKAGE_PASS"], "PASS")
        self.assertEqual(b["release"]["gates"]["DOWNSTREAM_PASS"], "FAIL")
        self.assertEqual(b["supplemental"]["total"], 7)
        self.assertEqual(b["manual_review"]["count"], 0)
        self.assertEqual(b["zip"]["name"], "r6-20260102.zip")
        self.assertEqual(b["zip"]["sha256"],
                         hashlib.sha256((self.base / "r6-20260102" /
                                         "r6-20260102.zip").read_bytes()).hexdigest())

    def test_get_batch_and_invalid(self):
        self.assertIsNotNone(DH.get_batch("r6-20260102", self.base))
        for bad in ("..", "../r6-20260102", "x/y", "", "not-a-batch"):
            self.assertIsNone(DH.get_batch(bad, self.base))

    def test_report_and_zip(self):
        got = DH.report_md("r6-20260102", self.base)
        self.assertIsNotNone(got)
        self.assertIn("报告", got[0])
        self.assertTrue(got[1].endswith(".md"))
        self.assertTrue(DH.zip_path("r6-20260102", self.base).is_file())
        self.assertIsNone(DH.report_md("missing", self.base))
        self.assertIsNone(DH.zip_path("missing", self.base))

    def test_no_zip_still_listed(self):
        make_batch(self.base, bid="r7-20260203", with_zip=False)
        ids = {b["id"] for b in DH.list_batches(self.base)}
        self.assertNotIn("r7-20260203", ids)     # 无 ZIP 不算交付批次

    def test_manifest_only_in_zip(self):
        """真实批次目录没有 manifest.csv，清单只打包在 ZIP 内。"""
        bid = "r8-20260304"
        make_batch(self.base, bid=bid, dir_manifest=False)
        self.assertFalse((self.base / bid / "manifest.csv").exists())
        b = DH.get_batch(bid, self.base)
        self.assertIsNotNone(b)                  # ZIP 内有 manifest → 算批次
        self.assertEqual(b["mpns"], ["ABC123", "XYZ789"])
        self.assertEqual(b["fields_total"], 105)
        self.assertEqual(b["zip"]["name"], bid + ".zip")

    def test_prefixed_report_preferred(self):
        """服务器上的报告名为 r6核验报告.md：应优先于 ACCEPTANCE.md 渲染。"""
        bid = "r9-20260405"
        make_batch(self.base, bid=bid, report_name="r6核验报告.md")
        (self.base / bid / "ACCEPTANCE.md").write_text("# 验收\n", encoding="utf-8")
        b = DH.get_batch(bid, self.base)
        self.assertEqual(b["report"]["name"], "r6核验报告.md")
        self.assertIn("报告", DH.report_md(bid, self.base)[0])

    def test_manual_review_screenshots(self):
        bid = "r6-20260102"
        png = b"\x89PNG\r\n\x1a\n" + b"fake-png-body"
        info = DH.save_manual(bid, "人工核对截图.png", png, self.base)
        self.assertTrue(info["name"].endswith(".png"))
        self.assertEqual(info["size"], len(png))
        items = DH.list_manual(bid, self.base)
        self.assertEqual(len(items), 1)
        self.assertIn("/manual-review/", items[0]["url"])
        self.assertIsNotNone(DH.manual_path(bid, info["name"], self.base))
        self.assertEqual(DH.get_batch(bid, self.base)["manual_review"]["count"], 1)
        for bad in ("../x.png", "x.svg", "a/b.png", ""):
            self.assertIsNone(DH.manual_path(bid, bad, self.base))
        with self.assertRaises(ValueError):
            DH.save_manual(bid, "x.svg", b"<svg/>", self.base)
        with self.assertRaises(ValueError):
            DH.save_manual(bid, "x.png", b"not-an-image", self.base)


class DeliveryPackageScanTest(unittest.TestCase):
    """`data/delivery-YYYYMMDD-VX/` 必须被扫到（工作台「最新批次停在一周前」）。

    事故：工作台只扫 `data/qc/`，而 1101 起的正式包全在 `data/delivery-*`。
    页面上最新批次是 10-28，V1…V3 一个都不在 —— 不是数据丢了，是扫描根
    和产出根不是同一个。
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.qc = self.root / "qc"
        self.data = self.root
        self.qc.mkdir()
        make_batch(self.qc, "r6-20260102")           # 老四层批次
        self._saved = (DH.BASES, DH.DELIVERY_BASE)
        DH.BASES = (self.qc, self.data)
        DH.DELIVERY_BASE = self.data
        self._make_pkg("delivery-20260202-V3")

    def tearDown(self):
        DH.BASES, DH.DELIVERY_BASE = self._saved
        self.tmp.cleanup()

    def _make_pkg(self, bid: str):
        p = self.data / bid
        p.mkdir(parents=True)
        (p / "manifest.csv").write_text(MANIFEST, encoding="utf-8-sig")
        (p / "交付说明.md").write_text("# 交付说明\n\n本包含原厂 PDF。\n",
                                       encoding="utf-8")
        (p / "包校验报告.json").write_text(json.dumps({
            "packaging_validation": "pass",
            "self_check": "pass",
            "selfcheck": {"n_items": 42, "n_failed": 0, "passed": True},
            "zip_crc": "pass",
            "source_hashes_unchanged": True,
            "engineering_validation": "not_approved",
            "zip_sha256": "c" * 64,
            "zip_size": 1234,
        }), encoding="utf-8")
        with zipfile.ZipFile(p / "part-0001-of-0001.zip", "w",
                             zipfile.ZIP_STORED) as zf:
            zf.writestr("manifest.csv", MANIFEST)

    def test_delivery_dir_is_scanned(self):
        ids = [b["id"] for b in DH.list_batches()]
        self.assertIn("delivery-20260202-V3", ids)
        self.assertIn("r6-20260102", ids)
        # 日期新的排前面
        self.assertEqual(ids[0], "delivery-20260202-V3")

    def test_patch_version_is_scanned_and_sorted_above_base(self):
        """1102-V3.1：补丁版号必须被扫到，且排在它所修补的 V3 之前。

        `DELIVERY_NAME_RE` 只认 `-V\\d+` 时 V3.1 目录整个被跳过 ——
        工作台「查无此包」，复核方按 V 号找版本也落空。
        排序必须按**语义版本**（V3.1 > V3），字符串排序会把 V3.1 排到 V3 前面
        纯属巧合，V3.10 就会排到 V3.2 前面。
        """
        self._make_pkg("delivery-20260202-V3.1")
        ids = [b["id"] for b in DH.list_batches()]
        self.assertIn("delivery-20260202-V3.1", ids)
        self.assertLess(ids.index("delivery-20260202-V3.1"),
                        ids.index("delivery-20260202-V3"))
        b = DH.get_batch("delivery-20260202-V3.1")
        self.assertEqual(b["base_id"], "delivery-20260202")
        self.assertEqual(b["version"], 3.1)

    def test_delivery_batch_fields(self):
        b = DH.get_batch("delivery-20260202-V3")
        self.assertIsNotNone(b)
        self.assertEqual(b["verdict"], "PASS")
        self.assertEqual(b["status"]["code"], "PASS")
        self.assertIn("42", b["verdict_note"])
        self.assertEqual(b["report"]["name"], "交付说明.md")
        self.assertEqual(b["zip"]["name"], "part-0001-of-0001.zip")
        # size 取磁盘实际字节，不信报告里自述的 zip_size（自述值可能过期）
        self.assertEqual(b["zip"]["size"],
                         (self.data / "delivery-20260202-V3"
                          / "part-0001-of-0001.zip").stat().st_size)
        gates = b["release"]["gates"]
        self.assertEqual(gates["PACKAGE_PASS"], "PASS")
        self.assertEqual(gates["PROVENANCE_PASS"], "PASS")
        self.assertEqual(gates["DATA_SEMANTICS_PASS"], "PASS")
        # 工程验收不是自动门禁能签的，必须如实 NOT_CHECKED
        self.assertEqual(gates["RELEASE_APPROVED"], "NOT_CHECKED")
        self.assertFalse(b["release"]["approved"])

    def test_non_delivery_dir_under_data_is_ignored(self):
        """`data/parsed`、`data/pdfs` 这类目录不许被当成批次。"""
        junk = self.data / "parsed"
        junk.mkdir()
        (junk / "manifest.csv").write_text(MANIFEST, encoding="utf-8-sig")
        with zipfile.ZipFile(junk / "x.zip", "w", zipfile.ZIP_STORED) as zf:
            zf.writestr("manifest.csv", MANIFEST)
        ids = [b["id"] for b in DH.list_batches()]
        self.assertNotIn("parsed", ids)

    def test_explicit_base_still_wins(self):
        """显式给 base 时只扫那一个根（老调用方不受影响）。"""
        ids = [b["id"] for b in DH.list_batches(self.qc)]
        self.assertEqual(ids, ["r6-20260102"])


if __name__ == "__main__":
    unittest.main()
