# -*- coding: utf-8 -*-
"""发布作用域契约回归：脏事实留档、对象隔离与重复调用严格幂等。"""
import copy
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc.scope_contract import canonical_view, normalize_scope, validate_contract


def contract_doc(identity="evaluation_board", scope="board"):
    return {
        "basic_info": {"mpn": "BOOST-DRV8711", "identity": identity,
                       "device_mpn": "DRV8711", "document_scope": "board_user_guide"},
        "specs": {
            "scope": scope,
            "package": {"type": "Evaluation Board", "pins": 0,
                        "dimensions": "1.75 in × 2.00 in", "onboard_device": "DRV8711"},
            "electrical": [{"parameter": "Power supply input", "value": "8.2–52",
                            "unit": "V", "condition": "Board power input",
                            "source": {"scope": scope, "page": 4, "table": 1, "row": 1}}],
            "absolute_max": [{"parameter": "Input maximum", "value": "52", "unit": "V"}],
            "temperature": {"operating": "0 to 50°C", "storage": "-20 to 70°C"},
        },
        "pin_configuration": [], "pin_scope": "board", "metadata": {},
    }


def canonical_checked(doc):
    original = copy.deepcopy(doc)
    view = canonical_view(doc)
    assert doc == original, "发布视图不得原地修改输入候选"
    snapshot = json.dumps(view, sort_keys=True, ensure_ascii=False)
    for _ in range(3):
        view = canonical_view(view)
        assert json.dumps(view, sort_keys=True, ensure_ascii=False) == snapshot, \
            "数据、隔离历史及报警顺序都必须真正幂等"
    return view


def finding_kinds(doc):
    return {item["kind"] for item in validate_contract(doc)}


@pytest.mark.parametrize("raw, expected", [
    ("chip", "device"), (" device ", "device"), ("BOARD", "board"),
    ("onboard_device", "onboard_device"), ("subcircuit", "subcircuit"),
    (None, "unresolved"), ("", "unresolved"), ("illegal", "unresolved"),
])
def test_scope_normalization(raw, expected):
    assert normalize_scope(raw) == expected


@pytest.mark.parametrize("identity", ["evaluation_board", "development_kit", "chip", "device"])
@pytest.mark.parametrize("scope", [None, "illegal"])
def test_missing_or_invalid_scope_blocks_main_facts(identity, scope):
    doc = contract_doc(identity)
    if scope is None:
        doc["specs"].pop("scope")
        expected = "missing_scope"
    else:
        doc["specs"]["scope"] = scope
        expected = "invalid_scope"
    original = copy.deepcopy(doc["specs"])
    assert expected in finding_kinds(doc)
    view = canonical_checked(doc)
    assert view["specs"]["scope"] == "unresolved"
    assert view["specs"]["electrical"] == view["specs"]["absolute_max"] == []
    assert view["specs"]["temperature"] == {
        "operating": "not_specified", "storage": "not_specified"}
    isolated = view["specs"]["unresolved_specs"]
    for key in ("electrical", "absolute_max", "temperature"):
        assert isolated[key] == original[key], "缺/非法作用域的事实不能静默丢失"
    assert {expected, "quarantined_residual"} <= finding_kinds(view)
    if scope is not None:
        assert {"path": "specs.scope", "value": scope} in view["contract_legacy"]["scope_values"]


@pytest.mark.parametrize("owner, key", [
    ("specs", "device_scope"), ("basic_info", "datasheet_scope"),
    ("basic_info", "device_scope"), ("root", "datasheet_scope"), ("root", "device_scope"),
])
def test_conflicting_scope_aliases_are_preserved_and_blocked(owner, key):
    doc = contract_doc()
    target = doc if owner == "root" else doc[owner]
    target[key] = "device"
    view = canonical_checked(doc)
    assert view["specs"]["scope"] == "unresolved"
    assert view["specs"]["electrical"] == []
    assert "scope_conflict" in finding_kinds(view)
    path = key if owner == "root" else f"{owner}.{key}"
    assert {"path": path, "value": "device"} in view["contract_legacy"]["scope_values"]
    assert key not in (view if owner == "root" else view[owner])


def test_basic_alias_conflict_does_not_create_new_conflicts_on_second_call():
    doc = contract_doc()
    doc["basic"] = {"mpn": "ADS8568EVM-PDK", "identity": "chip"}
    legacy = copy.deepcopy(doc["basic"])
    view = canonical_checked(doc)
    assert view["basic_info"]["mpn"] == "BOOST-DRV8711"
    assert view["contract_legacy"]["basic"] == legacy
    assert "basic" not in view
    assert view["specs"]["scope"] == "unresolved"
    assert "alias_conflict" in finding_kinds(view)


def test_device_alias_conflict_keeps_authority_history_and_alarm():
    doc = contract_doc()
    doc["specs"]["package"]["onboard_device"] = "ADS8568"
    view = canonical_checked(doc)
    assert view["basic_info"]["device_mpn"] == "DRV8711"
    assert view["specs"]["package"]["onboard_device"] == "DRV8711"
    assert view["specs"]["package"]["onboard_device_history"] == ["ADS8568"]
    assert "device_conflict" in finding_kinds(view)


@pytest.mark.parametrize("identity", ["evaluation_board", "development_kit"])
def test_named_mosfet_row_moves_to_device_without_moving_board_dimensions(identity):
    doc = contract_doc(identity)
    mosfet = {"parameter": "MOSFET on-resistance", "value": "12.5", "unit": "mΩ",
              "condition": "CSD88537ND Dual 60-V N-Channel NexFET",
              "source": {"scope": "board", "page": 5, "table": 2, "row": 3}}
    doc["specs"]["electrical"].append(mosfet)
    view = canonical_checked(doc)
    assert view["specs"]["scope"] == "board"
    assert view["specs"]["electrical"] == doc["specs"]["electrical"][:1]
    device = view["specs"]["onboard_device_specs"]["devices"]["CSD88537ND"]
    assert device["device_mpn"] == "CSD88537ND"
    assert device["scope"] == "onboard_device"
    row = device["electrical"][0]
    assert row["subject_mpn"] == "CSD88537ND" and row["subject_kind"] == "device"
    for key in ("value", "unit", "condition", "source"):
        assert row[key] == mosfet[key]
    assert view["specs"]["package"]["dimensions"] == "1.75 in × 2.00 in"
    assert "onboard_dimensions" not in view["specs"]["package"]
    assert {"row_quarantined", "row_scope_conflict"} <= finding_kinds(view)


def test_row_scope_alias_conflict_is_not_published():
    doc = contract_doc()
    doc["specs"]["electrical"][0]["device_scope"] = "device"
    view = canonical_checked(doc)
    assert view["specs"]["electrical"] == []
    assert view["specs"]["unresolved_specs"]["electrical"] == doc["specs"]["electrical"]
    assert "row_scope_conflict" in finding_kinds(view)


@pytest.mark.parametrize("identity", ["evaluation_board", "development_kit"])
def test_published_board_pin_scope_is_stable_after_residual_pins_are_archived(identity):
    doc = contract_doc(identity)
    doc["pin_configuration"] = [{"pin": 1, "name": "VDD", "source": {"page": 8}}]
    doc["pin_scope"] = "device"
    view = canonical_checked(doc)
    assert view["pin_configuration"] == []
    assert view["pin_scope"] == "board"
    assert view["specs"]["onboard_device_specs"]["pin_configuration"] == doc["pin_configuration"]
    assert "pins_quarantined" in finding_kinds(view)


@pytest.mark.parametrize("identity", [None, "unknown", "invalid_identity"])
def test_unknown_identity_never_defaults_to_chip_and_package_is_not_rearchived(identity):
    doc = contract_doc(identity, "device")
    doc["specs"]["package"] = {"type": "FCBGA", "pins": 144, "dimensions": "10 mm"}
    doc["pin_configuration"] = [{"pin": "F1", "name": "CLK+", "source": {"page": 12}}]
    doc["pin_scope"] = "device"
    original = copy.deepcopy(doc)
    view = canonical_checked(doc)
    assert view["basic_info"]["identity"] == identity
    assert view["specs"]["scope"] == view["pin_scope"] == "unresolved"
    assert view["pin_configuration"] == []
    assert view["specs"]["package"] == {"type": "", "pins": 0, "dimensions": ""}
    isolated = view["specs"]["unresolved_specs"]
    assert isolated["package"] == original["specs"]["package"]
    assert "package_history" not in isolated, "不能把自身生成的空封装二次归档"
    assert isolated["pin_configuration"] == original["pin_configuration"]
    assert {"unknown_identity", "quarantined_residual", "pins_quarantined"} <= finding_kinds(view)


@pytest.mark.parametrize("package", [{}, {"type": "", "pins": 0, "dimensions": ""}])
def test_unknown_identity_empty_package_does_not_create_isolation_history(package):
    doc = contract_doc("unknown", "unresolved")
    doc["specs"]["package"] = package
    view = canonical_checked(doc)
    assert "package" not in view["specs"]["unresolved_specs"]
    assert "package_history" not in view["specs"]["unresolved_specs"]


def test_new_residual_facts_merge_with_existing_isolation():
    doc = contract_doc(scope="onboard_device")
    first = canonical_checked(doc)
    added = {"parameter": "Aperture jitter", "value": "1", "unit": "ps",
             "source": {"scope": "device", "page": 9}}
    first["specs"]["electrical"] = [added]
    view = canonical_checked(first)
    isolated = view["specs"]["onboard_device_specs"]["electrical"]
    assert isolated == doc["specs"]["electrical"] + [added]
    assert view["specs"]["electrical"] == []
    assert "quarantined_residual" in finding_kinds(view)


@pytest.mark.parametrize("scope", ["device", "chip"])
def test_confirmed_chip_keeps_device_scoped_facts(scope):
    doc = contract_doc("chip", scope)
    doc["pin_scope"] = "chip"
    doc["pin_configuration"] = [{"pin": 1, "name": "VDD"}]
    view = canonical_checked(doc)
    assert view["specs"]["scope"] == view["pin_scope"] == "device"
    assert view["specs"]["electrical"] == doc["specs"]["electrical"]
    assert view["pin_configuration"] == doc["pin_configuration"]
