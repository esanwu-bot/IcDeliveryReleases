"""重解析脚本的回归：原件选择与落盘判定。

起因（本轮 228 件批次实测出来的两个错）：
  * `_pdf_for` 用前缀兜底，`ADS1254E` 命中 `ADS1254EVM__…`（评估板用户指南）、
    `D9LVRA2DEMR` 命中 `D9LVRA2DEMRQ1__…`（另一个可订购型号）——订货行看着涨了，
    抽的却是别的产品。
  * 回滚判据用 `<`，39 件 1→1 的持平记录被无条件覆盖，属无收益改写。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import reparse_ordering as R                        # noqa: E402


class PdfForTest(unittest.TestCase):
    """前缀只能生成候选，不能当原件选择的依据。"""

    def setUp(self):
        import tempfile
        self.dir = Path(tempfile.mkdtemp())
        for n in ("ADS1254E__ads1254.pdf",
                  "ADS1254EVM__ADS1254-Rev2006.pdf",
                  "ADS1254E_2K5G4__ads1254.pdf",
                  "D9LVRA2DEMR__ds90lvra2.pdf",
                  "D9LVRA2DEMRQ1__ds90lvra2-q1.pdf",
                  "F28P550SG9RSHR__tms320f28p550sg.pdf",
                  "F28P550SJ6RSHR__tms320f28p550sj.pdf"):
            (self.dir / n).write_bytes(b"x")

    def test_exact_name_wins(self):
        p = R._pdf_for(self.dir, "ADS1254E")
        self.assertIsNotNone(p)
        self.assertEqual(p.name, "ADS1254E__ads1254.pdf")

    def test_evm_variant_is_not_picked(self):
        """评估板用户指南不能被当成芯片手册（'V' < '_' 曾让它排到前面）。"""
        p = R._pdf_for(self.dir, "ADS1254E")
        self.assertNotIn("EVM", p.name.upper())

    def test_q1_variant_is_not_picked(self):
        """车规 Q1 版是另一个可订购型号，不能拿来给基础型号抽订货行。"""
        p = R._pdf_for(self.dir, "D9LVRA2DEMR")
        self.assertEqual(p.name, "D9LVRA2DEMR__ds90lvra2.pdf")

    def test_reel_variant_is_not_picked(self):
        """卷带变体（_2K5G4）同样不是本料号的原件。"""
        p = R._pdf_for(self.dir, "ADS1254E")
        self.assertNotIn("2K5G4", p.name)

    def test_same_family_other_suffix_is_not_picked(self):
        p = R._pdf_for(self.dir, "F28P550SG9RSHR")
        self.assertEqual(p.name, "F28P550SG9RSHR__tms320f28p550sg.pdf")

    def test_missing_pdf_returns_none(self):
        self.assertIsNone(R._pdf_for(self.dir, "NOPE1234"))

    def test_plain_named_pdf_still_found(self):
        (self.dir / "ABC123.pdf").write_bytes(b"x")
        p = R._pdf_for(self.dir, "ABC123")
        self.assertEqual(p.name, "ABC123.pdf")


class WorthWritingTest(unittest.TestCase):
    def test_improvement_is_written(self):
        self.assertTrue(R.is_worth_writing(0, 4))
        self.assertTrue(R.is_worth_writing(1, 2))

    def test_tie_is_not_written(self):
        """持平不算收益——旧判据会把 1→1 的件无条件覆盖。"""
        self.assertFalse(R.is_worth_writing(1, 1))
        self.assertFalse(R.is_worth_writing(0, 0))

    def test_regression_is_not_written(self):
        self.assertFalse(R.is_worth_writing(4, 2))
        self.assertFalse(R.is_worth_writing(1, 0))


if __name__ == "__main__":
    unittest.main()
