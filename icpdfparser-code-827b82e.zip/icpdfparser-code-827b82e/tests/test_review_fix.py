"""review → fix 状态推导 + 分批物化 的单测。

四个必须守住的点：
  1. **状态只看复审的 P0/P1**：修过但仍有 P1 只能算「警告」，不能算通过；
  2. **`changed=[]` 不算修复**：fixer 尝试过但没改动（NE555 的真实形态）不算修好；
  3. **复审必须晚于修复**：修完没重审要标「判定滞后」（status_stale）；
  4. **批次不允许被证据缺口变绿**：缺报告/缺 severity → INCOMPLETE，整批也非通过。
"""
import csv
import io
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import review_fix as RF       # noqa: E402


def write_review(base: Path, mpn: str, verdict: str, at: str,
                 findings: int = 1, sev: str = "P1") -> None:
    d = base / "reviews"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{RF.safe_stem(mpn)}.review.json").write_text(json.dumps({
        "mpn": mpn, "verdict": verdict, "generated_at": at,
        "rule_findings": [{"kind": "x", "severity": sev}] * findings,
        "llm_findings": [],
    }, ensure_ascii=False), encoding="utf-8")


def write_log(base: Path, mpn: str, records: list[dict]) -> None:
    d = base / "fix_plans"
    d.mkdir(parents=True, exist_ok=True)
    with (d / f"{RF.safe_stem(mpn)}.fix_plan.log.jsonl").open("a",
                                                              encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def dispatch(ts: str, verdict: str = "WARN") -> dict:
    return {"ts": ts, "round": 1, "event": "dispatch", "verdict": verdict,
            "actions": 1, "ready": 1}


def apply_(ts: str, changed: list[str]) -> dict:
    return {"ts": ts, "round": 1, "event": "apply", "action_id": "A1",
            "kind": "unit_duplicated", "worker": "fix_unit_duplicated",
            "changed": changed}


class DeriveTest(unittest.TestCase):
    def test_fixed_but_p1_remains_is_still_warn(self):
        """修过且复审通过不代表没 P1：残留 P1 只能算「警告」。"""
        base = Path(tempfile.mkdtemp())
        write_log(base, "U1", [dispatch("2026-10-28T10:00:00+08:00"),
                               apply_("2026-10-28T10:05:00+08:00",
                                      ["specs.electrical[0].value"])])
        write_review(base, "U1", "WARN", "2026-10-28T10:10:00+08:00")
        r = RF.derive(base, "U1")
        self.assertEqual(r["status_code"], RF.STATUS_STILL_WARN)
        self.assertEqual(r["status"], r["status_code"])
        self.assertEqual(r["p1"], 1)
        self.assertEqual(r["p0"], 0)
        self.assertTrue(r["fix_applied"])
        self.assertEqual(r["fixes"], 1)
        self.assertEqual(r["verdict_before"], "WARN")
        self.assertEqual(r["verdict_after"], "WARN")

    def test_clean_pass_after_fix_is_qa_pass(self):
        base = Path(tempfile.mkdtemp())
        write_log(base, "U7", [apply_("2026-10-28T10:05:00+08:00", ["a.b"])])
        write_review(base, "U7", "PASS", "2026-10-28T10:10:00+08:00", findings=0)
        r = RF.derive(base, "U7")
        self.assertEqual(r["status_code"], RF.STATUS_QA_PASS)
        self.assertEqual(r["internal"], "")

    def test_changed_empty_is_not_fixed(self):
        """NE555 真实形态：apply 了但 changed=[]，不算修好。"""
        base = Path(tempfile.mkdtemp())
        write_log(base, "NE555", [dispatch("2026-10-28T10:00:00+08:00"),
                                  apply_("2026-10-28T10:05:00+08:00", [])])
        write_review(base, "NE555", "WARN", "2026-10-28T10:10:00+08:00")
        r = RF.derive(base, "NE555")
        self.assertEqual(r["status_code"], RF.STATUS_STILL_WARN)
        self.assertEqual(r["internal"], RF.REVIEWED_NEEDS_FIX)
        self.assertFalse(r["fix_applied"])
        self.assertEqual(r["fixes"], 0)

    def test_fixed_without_recheck_is_stale(self):
        base = Path(tempfile.mkdtemp())
        write_log(base, "U2", [dispatch("2026-10-28T10:00:00+08:00"),
                               apply_("2026-10-28T10:20:00+08:00", ["a.b"])])
        write_review(base, "U2", "WARN", "2026-10-28T10:10:00+08:00")   # 早于修复
        r = RF.derive(base, "U2")
        self.assertEqual(r["internal"], RF.FIXED_UNVERIFIED)
        self.assertTrue(r["status_stale"])

    def test_recheck_still_fail_is_blocked(self):
        base = Path(tempfile.mkdtemp())
        write_log(base, "U3", [apply_("2026-10-28T10:05:00+08:00", ["a.b"])])
        write_review(base, "U3", "FAIL", "2026-10-28T10:10:00+08:00", sev="P0")
        r = RF.derive(base, "U3")
        self.assertEqual(r["status_code"], RF.STATUS_BLOCKED)
        self.assertEqual(r["internal"], RF.FIXED_STILL_FAIL)

    def test_promoted_is_not_converged_not_unverified(self):
        """跑满轮次转人工反馈的，不能显示成「等待重审」。"""
        base = Path(tempfile.mkdtemp())
        rec = apply_("2026-10-28T10:05:00+08:00", ["a.b"])
        fin = {"ts": "2026-10-28T10:06:00+08:00", "round": 2, "event": "finalize",
               "promoted": {"ok": True, "issue_key": "CF-FIX-X-R2"},
               "reason": "max_rounds_reached"}
        write_log(base, "U6", [rec, fin])
        write_review(base, "U6", "FAIL", "2026-10-28T10:04:00+08:00", sev="P0")
        r = RF.derive(base, "U6")
        self.assertEqual(r["status_code"], RF.STATUS_BLOCKED)
        self.assertEqual(r["internal"], RF.FIXED_NOT_CONVERGED)
        self.assertEqual(r["promoted_issue"], "CF-FIX-X-R2")

    def test_clean_review_is_qa_pass_from_clean(self):
        """review 过且无需修（PASS、0 finding）→ 机器检查通过。"""
        base = Path(tempfile.mkdtemp())
        write_review(base, "U4", "PASS", "2026-10-28T10:10:00+08:00", findings=0)
        r = RF.derive(base, "U4")
        self.assertEqual(r["status_code"], RF.STATUS_QA_PASS)
        self.assertEqual(r["internal"], RF.REVIEWED_CLEAN)

    def test_not_reviewed_is_incomplete_not_pass(self):
        base = Path(tempfile.mkdtemp())
        r = RF.derive(base, "U5")
        self.assertEqual(r["status_code"], RF.STATUS_INCOMPLETE)
        self.assertEqual(r["internal"], RF.NOT_REVIEWED)
        self.assertEqual(r["incomplete_checks"], 1)

    def test_status_labels_cover_the_gate(self):
        self.assertEqual(set(RF.DELIVERY_STATUSES),
                         {RF.STATUS_BLOCKED, RF.STATUS_STILL_WARN,
                          RF.STATUS_QA_PASS, RF.STATUS_INCOMPLETE,
                          RF.STATUS_LEGACY_UNRESOLVED})
        self.assertEqual(RF.label(RF.STATUS_BLOCKED), "阻断（P0 未清）")
        self.assertEqual(RF.label(RF.STATUS_STILL_WARN), "警告（P1 未清）")


class BatchTest(unittest.TestCase):
    def _seed(self, base: Path, n: int) -> None:
        for i in range(n):
            mpn = "P%03d" % i
            write_log(base, mpn, [apply_("2026-10-28T10:%02d:00+08:00" % i,
                                         ["specs.electrical[0].value"])])
            write_review(base, mpn, "WARN", "2026-10-28T11:%02d:00+08:00" % i)

    def test_chunk_size_is_30(self):
        base = Path(tempfile.mkdtemp())
        self._seed(base, 95)
        self.assertEqual(RF.summary(base)["reviewed"], 95)
        self.assertEqual(RF.summary(base)["still_warn"], 95)
        self.assertEqual([len(g) for g in RF.chunk(RF.pending(base), 30)],
                         [30, 30, 30, 5])

    def test_build_next_one_batch(self):
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 45)
        out = RF.build_next(base, size=30, max_batches=1, data_dir=data,
                            date="2026-10-28")
        self.assertEqual(len(out["built"]), 1)
        bid = out["built"][0]["batch"]
        self.assertRegex(bid, r"^rf-20261028-001$")
        nxt = RF.summary(base)
        self.assertEqual(nxt["batched"], 30)
        self.assertEqual(nxt["pending"], 15)

    def test_batch_dir_is_a_delivery_batch(self):
        """物化结果必须能被 delivery_history 认成批次（zip + manifest + 报告）。"""
        from qc import delivery_history as DH
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 3)
        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        bid = out["built"][0]["batch"]
        d = base / bid
        for name in ("manifest.csv", "核验报告.md", "rf_quality_audit.json",
                     RF.ZIP_NAME):
            self.assertTrue((d / name).is_file(), name)
        with zipfile.ZipFile(d / RF.ZIP_NAME) as zf:
            names = zf.namelist()
        self.assertTrue(any(n.startswith("review/") for n in names))
        self.assertIn("manifest.csv", names)
        b = DH.get_batch(bid, base)
        self.assertIsNotNone(b)
        self.assertEqual(b["kind"], "review_fix")
        self.assertEqual(b["status"]["code"], "REVIEWED_STILL_WARN")
        self.assertEqual(b["status"]["label"], "警告（P1 未清）")
        self.assertEqual(b["status"]["source"], "audit")
        self.assertEqual(b["sample_count"], 3)
        self.assertEqual(b["review_fix_derived"]["p1_total"], 3)

    def test_zip_is_per_mpn_dir_with_pdf(self):
        """工作台 ZIP 必须是「每型号一目录 + 含 PDF」，不能是 artifacts/<类型>/。"""
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 2)
        for sub in ("pdfs", "parsed", "txt", "alts", "symbols", "seo"):
            (data / sub).mkdir(parents=True)
        for i in range(2):
            mpn = "P%03d" % i
            (data / "pdfs" / ("%s__slug.pdf" % mpn)).write_bytes(b"%PDF-1.4\n")
            (data / "parsed" / ("%s_ab12cd34.json" % mpn)).write_text(
                '{"mpn": "%s"}' % mpn, encoding="utf-8")
            for fx in ("txt/%s.txt", "alts/%s.json", "alts/%s.html",
                       "symbols/%s.html", "seo/%s.json"):
                (data / (fx % mpn)).write_text("x", encoding="utf-8")
            (data / "txt" / ("%s.ja.txt" % mpn)).write_text("x", encoding="utf-8")

        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        bid = out["built"][0]["batch"]
        d = base / bid
        with zipfile.ZipFile(d / RF.ZIP_NAME) as zf:
            names = set(zf.namelist())
            pdf_info = zf.getinfo("P000/P000.pdf")
        self.assertFalse([n for n in names if n.startswith("artifacts/")])
        for n in ("P000/P000.pdf", "P000/P000.json", "P000/P000.txt",
                  "P000/P000.ja.txt", "P000/P000.alts.json", "P000/P000.alts.html",
                  "P000/P000.symbols.html", "P000/P000.seo.json",
                  "P000/P000.provenance.json"):
            self.assertIn(n, names)
        # PDF 本身已压缩，不再 deflate
        self.assertEqual(zipfile.ZIP_STORED, pdf_info.compress_type)
        # provenance 带真实 PDF 留痕，且不 green-light 发布
        prov = json.loads((d / "P000" / "P000.provenance.json").read_text("utf-8"))
        self.assertEqual("P000.pdf", prov["pdf"]["file"])
        self.assertEqual(len(b"%PDF-1.4\n"), prov["pdf"]["bytes"])
        self.assertIs(False, prov["human_accepted"])
        self.assertIs(False, prov["release_approved"])
        audit = json.loads((d / "rf_quality_audit.json").read_text("utf-8"))
        self.assertEqual("per_mpn_dir", audit["layout"])
        self.assertEqual([], audit["review_fix"]["missing_pdf"])

    def test_missing_pdf_recorded_in_audit(self):
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 1)
        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        d = base / out["built"][0]["batch"]
        audit = json.loads((d / "rf_quality_audit.json").read_text("utf-8"))
        self.assertEqual(["P000"], audit["review_fix"]["missing_pdf"])

    def test_rebuild_refreshes_layout_and_drops_stale_artifacts(self):
        """老批次（artifacts/<类型>/）重打后必须是每型号一目录，旧目录不留。"""
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 1)
        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        bid = out["built"][0]["batch"]
        d = base / bid
        # 模拟上一版留下的结构
        (d / "artifacts" / "txt").mkdir(parents=True)
        (d / "artifacts" / "txt" / "P000.txt").write_text("old", encoding="utf-8")
        (data / "pdfs").mkdir(parents=True)
        (data / "pdfs" / "P000__slug.pdf").write_bytes(b"%PDF-1.4\n")

        name, rows = RF.read_batch(d)
        self.assertEqual(bid, name)
        self.assertEqual(["P000"], [r["mpn"] for r in rows])
        RF.build_batch(base, rows, batch=bid, data_dir=data, force=True)

        self.assertFalse((d / "artifacts").exists())
        self.assertTrue((d / "P000" / "P000.pdf").is_file())
        self.assertTrue((d / "P000" / "P000.provenance.json").is_file())
        self.assertTrue((d / "review" / "P000.review.json").is_file())
        with zipfile.ZipFile(d / RF.ZIP_NAME) as zf:
            names = zf.namelist()
        self.assertIn("P000/P000.pdf", names)
        self.assertFalse([n for n in names if n.startswith("artifacts/")])

    def test_idempotent_no_duplicate(self):
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 40)
        RF.build_next(base, size=30, max_batches=5, data_dir=data, date="2026-10-28")
        second = RF.build_next(base, size=30, max_batches=5, data_dir=data,
                               date="2026-10-28")
        self.assertEqual(second["candidates"], 0)
        self.assertEqual(second["skipped_reason"], "no_pending_reviewed")
        # 同一型号不会进两个批次
        idx = RF.load_index(base)
        self.assertEqual(len(idx["assigned"]), 40)

    def test_dry_run_writes_nothing(self):
        base = Path(tempfile.mkdtemp())
        self._seed(base, 35)
        out = RF.build_next(base, size=30, dry_run=True, date="2026-10-28")
        self.assertTrue(out["dry_run"])
        self.assertEqual([len(p["mpns"]) for p in out["plan"]], [30, 5])
        self.assertFalse((base / "rf-20261028-001").exists())
        self.assertFalse(RF.index_path(base).exists())

    def test_manifest_has_status_columns(self):
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 1)
        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        d = base / out["built"][0]["batch"]
        rows = list(csv.DictReader(io.StringIO(
            (d / "manifest.csv").read_text(encoding="utf-8-sig"))))
        self.assertEqual(rows[0]["status_code"], "REVIEWED_STILL_WARN")
        self.assertEqual(rows[0]["status_label"], "警告（P1 未清）")
        self.assertEqual(rows[0]["p1"], "1")
        self.assertEqual(rows[0]["status_rule_version"], "rs-1")

    def test_batch_rollup_blocked_wins(self):
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 2)
        write_review(base, "P000", "FAIL", "2026-10-28T11:00:00+08:00", sev="P0")
        out = RF.build_next(base, size=30, data_dir=data, date="2026-10-28")
        d = base / out["built"][0]["batch"]
        audit = json.loads((d / "rf_quality_audit.json").read_text("utf-8"))
        self.assertEqual(audit["status_code"], "REVIEWED_BLOCKED")
        self.assertEqual(audit["review_fix"]["blocked_mpns"], ["P000"])
        self.assertEqual(audit["p0_total"], 1)

    def test_derived_sidecar_overrides_audit_status(self):
        """盘点工具写的 sidecar 优先展示；audit 不动。"""
        from qc import delivery_history as DH
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 2)
        bid = RF.build_next(base, size=30, data_dir=data,
                            date="2026-10-28")["built"][0]["batch"]
        d = base / bid
        audit_before = (d / "rf_quality_audit.json").read_bytes()
        (d / "rf_status_derived.json").write_text(json.dumps({
            "status_code": "REVIEWED_BLOCKED", "status_label": "阻断（P0 未清）",
            "status_rule_version": "rs-1", "p0_total": 2, "p1_total": 0,
            "status_counts": {}, "mpns_detail": {}}, ensure_ascii=False),
            encoding="utf-8")
        b = DH.get_batch(bid, base)
        self.assertEqual("REVIEWED_BLOCKED", b["status"]["code"])
        self.assertEqual("derived", b["status"]["source"])
        self.assertEqual(2, b["review_fix_derived"]["p0_total"])
        self.assertEqual(audit_before, (d / "rf_quality_audit.json").read_bytes())

    def test_version_chain_listed(self):
        """rf-...-001 与 -V2 视为同一批次线的两个版本。"""
        import shutil

        from qc import delivery_history as DH
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        self._seed(base, 1)
        bid = RF.build_next(base, size=30, data_dir=data,
                            date="2026-10-28")["built"][0]["batch"]
        v2 = base / (bid + "-V2")
        shutil.copytree(base / bid, v2)
        audit = json.loads((v2 / "rf_quality_audit.json").read_text("utf-8"))
        audit["status_code"] = "REVIEWED_QA_PASS"
        audit["status_label"] = "机器检查通过（待人工验收）"
        (v2 / "rf_quality_audit.json").write_text(
            json.dumps(audit, ensure_ascii=False), encoding="utf-8")
        b = DH.get_batch(bid + "-V2", base)
        self.assertEqual(2, b["version"])
        self.assertEqual(bid, b["base_id"])
        self.assertEqual([1, 2], [v["version"] for v in b["versions"]])

    def test_batch_with_missing_report_is_not_green(self):
        """29 件通过 + 1 件缺报告 → 整批不得标成机器检查通过。"""
        base = Path(tempfile.mkdtemp())
        data = Path(tempfile.mkdtemp())
        for i in range(3):
            write_review(base, "Q%03d" % i, "PASS", "2026-10-28T11:00:00+08:00",
                         findings=0)
        rows = [RF.derive(base, "Q%03d" % i) for i in range(3)]
        rows.append(RF.derive(base, "Q999"))          # 没有 review 报告
        out = RF.build_batch(base, rows, data_dir=data,
                             batch="rf-20261028-009")
        audit = json.loads((Path(out["path"]) / "rf_quality_audit.json")
                           .read_text("utf-8"))
        self.assertEqual(audit["status_code"], "INCOMPLETE")
        self.assertEqual(audit["review_fix"]["incomplete_mpns"], ["Q999"])
        self.assertNotEqual(audit["status_code"], "REVIEWED_QA_PASS")


class ArtifactPathTest(unittest.TestCase):
    """型号带 `/` 时产物名用的是清洗后的 stem（实测 ADC128D818EB/NOPB 漏产物）。

    交付口径是「每型号一个目录」：`<stem>/<stem>.<后缀>`，PDF 原件同目录。
    """

    def test_slash_mpn_falls_back_to_safe_stem(self):
        data = Path(tempfile.mkdtemp())
        for sub in ("txt", "parsed", "pdfs"):
            (data / sub).mkdir(parents=True)
        (data / "txt" / "ADC128D818EB_NOPB.txt").write_text("x", encoding="utf-8")
        (data / "txt" / "ADC128D818EB_NOPB.ja.txt").write_text("x", encoding="utf-8")
        (data / "parsed" / "ADC128D818EB_NOPB_ab12cd34.json").write_text(
            "{}", encoding="utf-8")
        (data / "pdfs" / "ADC128D818EB_NOPB__adc128d818.pdf").write_bytes(b"%PDF-1.4\n")
        got = RF._item_files(data, "ADC128D818EB/NOPB")
        rels = sorted(r for _s, _p, r in got)
        self.assertIn("ADC128D818EB_NOPB/ADC128D818EB_NOPB.txt", rels)
        self.assertIn("ADC128D818EB_NOPB/ADC128D818EB_NOPB.ja.txt", rels)
        self.assertIn("ADC128D818EB_NOPB/ADC128D818EB_NOPB.json", rels)
        self.assertIn("ADC128D818EB_NOPB/ADC128D818EB_NOPB.pdf", rels)

    def test_plain_mpn_still_works(self):
        data = Path(tempfile.mkdtemp())
        (data / "txt").mkdir(parents=True)
        (data / "txt" / "NE555.txt").write_text("x", encoding="utf-8")
        got = RF._item_files(data, "NE555")
        self.assertEqual([r for _s, _p, r in got], ["NE555/NE555.txt"])

    def test_layout_is_per_mpn_dir_with_pdf(self):
        """十二件套：pdf/json/txt/4 语种/alts×2/symbols/seo。"""
        data = Path(tempfile.mkdtemp())
        for sub in ("pdfs", "parsed", "txt", "alts", "symbols", "seo"):
            (data / sub).mkdir(parents=True)
        (data / "pdfs" / "NE555__ne555.pdf").write_bytes(b"%PDF-1.4\n")
        (data / "parsed" / "NE555_a3756e59.json").write_text("{}", encoding="utf-8")
        for fx in ("txt/NE555.txt", "txt/NE555.ja.txt", "txt/NE555.ko.txt",
                   "txt/NE555.de.txt", "txt/NE555.es.txt",
                   "alts/NE555.json", "alts/NE555.html",
                   "symbols/NE555.html", "seo/NE555.json"):
            (data / fx).write_text("x", encoding="utf-8")
        got = RF._item_files(data, "NE555")
        self.assertEqual(
            {".pdf", ".json", ".txt", ".ja.txt", ".ko.txt", ".de.txt", ".es.txt",
             ".alts.json", ".alts.html", ".symbols.html", ".seo.json"},
            {s for s, _p, _r in got})
        # 全部落在同一型号目录下，没有按产物类型分的目录
        self.assertTrue(all(r.startswith("NE555/") for _s, _p, r in got))
        self.assertIn("NE555/NE555.alts.json", [r for _s, _p, r in got])

    def test_missing_pdf_is_reported(self):
        data = Path(tempfile.mkdtemp())
        (data / "txt").mkdir(parents=True)
        (data / "txt" / "NE555.txt").write_text("x", encoding="utf-8")
        rels = [r for _s, _p, r in RF._item_files(data, "NE555")]
        self.assertEqual(["NE555/NE555.txt"], rels)


class HardRuleTest(unittest.TestCase):
    def test_hard_rules_cover_evk_lessons(self):
        from worker import fix_memory as FM
        txt = FM.hard_rules()
        for kw in ("视觉行序", "find_tables", "自证", "身份先行", "不猜值"):
            self.assertIn(kw, txt)

    def test_load_experience_semantics_unchanged(self):
        """硬规则是独立入口，不能把 load_experience 的「检索不到就空」改掉。"""
        from worker import fix_memory as FM
        tmp = Path(tempfile.mkdtemp())
        self.assertFalse(FM.load_experience("X", [], root=tmp)["ok"])


if __name__ == "__main__":
    unittest.main()
