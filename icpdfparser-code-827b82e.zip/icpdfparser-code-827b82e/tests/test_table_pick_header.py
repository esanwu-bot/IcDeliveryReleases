# -*- coding: utf-8 -*-
"""A19：融合表头格让 `pick_header` 认不出表头 / 说明性段落冒充列名。

背景（真实事故）：`ADS7945SRTER` 的 p4/p5 两张 `ELECTRICAL CHARACTERISTICS:
ADS7945 (Differential)` 表，**真表头就在第 0 行**：

    ['PARAMETER', '', 'TESTCONDITIONS', 'MIN TYP MAX', 'UNITS']

但第 4 页词坐标显示这就是三个独立子列（竖线丢了，不是合并单元格）：

    MIN@420-435   TYP@454-470   MAX@497-515

`extract()` 把三列挤成一格，于是踩到两个各自独立的坑：

* **坑一（`pick_header`）**：`role_map` 一格只给一个角色，
  `'MIN TYP MAX'` 只算 1 个数值角色 → `>= 2` 的判据不成立 → 返回 `([], rows)`。
  表头位置是对的，**是"数角色"数错了**。
* **坑二（`scan_tables`）**：表头行**上方**那三行说明文字
  （`Minimum/maximum specifications at TA = ...`）被 `extract()` 切成了 4~5 个碎片，
  而 `t.header.names` 恰好也是这么多片、长度正好等于列数 ——
  于是 `names 优先` 的规则让这段说明文字当了表头，真正在 row0 的表头反而成了数据。

坑二比坑一更隐蔽：`names` 里 `'Typical specifications ...'` 带着 `typical`，
`role_map(names)` 非空，看上去"像表头"，任何"有没有角色词"的弱判据都会放过它。

**两条红先声明**：

* `test_fused_cell_counts_all_three_roles` —— 修复前 `pick_header` 返回 `([], rows)`。
* `test_note_fragments_do_not_beat_a_real_header` —— 修复前 `choose_header` 返回
  说明文字当表头（`from_names=True`）。

为什么**不**顺着"表头被挤到第 2 行"的思路去扩大扫描窗口：本项目实测表头在这两份
PDF 里就在第 0 行，往下多扫只会把数据行里的 `MIN`/`MAX` 字样当表头。
`test_header_beyond_the_window_is_not_guessed` 把"窗口 3 行"这个决定钉在测试里。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

#: p4/p5 的真实表头行：MIN/TYP/MAX 挤在一格（竖线丢失）
FUSED_HDR = ["PARAMETER", "", "TESTCONDITIONS", "MIN TYP MAX", "UNITS"]

#: 竖线没丢时的同构表头（用来守"不许改坏正常表"）
SPLIT_HDR = ["PARAMETER", "SYMBOL", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNITS"]

#: 表头上方那段说明文字被 extract() 切成 4 片的原样（p4 实测）
NOTE_FRAGS = [
    "Minimum/maximum specifications at TA = -40°C to +125°C, AVDD",
    "= 2.7 V to 5.25 V, DVDD = 1.65 V to AVDD, input",
    "common-mode = VREF/2 ± 0.2, and fSAMPLE =",
    "= 2 MSPS.",
]

BODY = [
    ["Logic family", "", "CMOS", "3.5", "V"],
    ["Logic level", "VIH", "", "0.7 DVDD", "V"],
]


class TestPickHeader:
    def test_fused_cell_counts_all_three_roles(self):
        """红先：`'MIN TYP MAX'` 一格里有 3 个角色，必须按 3 个算。"""
        rows = [list(FUSED_HDR)] + [list(r) for r in BODY]
        header, data = TA.pick_header(rows)
        assert header == FUSED_HDR, f"表头没认出来：{header}"
        assert data == BODY

    def test_split_roles_still_found(self):
        """守住原有能力：MIN/TYP/MAX 各占一列时照样认得出。"""
        rows = [list(SPLIT_HDR), ["Logic level", "VIH", "", "0.7", "", "", "V"]]
        header, data = TA.pick_header(rows)
        assert header == SPLIT_HDR
        assert data == [["Logic level", "VIH", "", "0.7", "", "", "V"]]

    def test_single_numeric_role_is_not_a_header(self):
        """只有一个数值角色（TYP）不算表头 —— 门槛不降低。"""
        rows = [["PARAMETER", "TYPICAL VALUE", "UNITS"], ["Logic family", "CMOS", "V"]]
        assert TA.pick_header(rows) == ([], rows)

    def test_skips_note_rows_above_the_header(self):
        """表头上方有说明行时要跳过去（说明行不带数值角色，本来就跳得过）。"""
        rows = [["Minimum/maximum specifications", "", "", ""],
                list(FUSED_HDR)] + [list(r) for r in BODY]
        header, data = TA.pick_header(rows)
        assert header == FUSED_HDR
        assert data == BODY

    def test_header_beyond_the_window_is_not_guessed(self):
        """窗口刻意只有 3 行：再往下就是数据，`MIN`/`MAX` 出现在数据里不算表头。

        这条不是"缺陷"，是**决定**。写在这里，免得以后有人顺手把 `[:3]` 改成 `[:8]`
        以为在提高召回 —— 那只会把数据行升级成表头。
        """
        rows = [["note 1", "", "", ""], ["note 2", "", "", ""],
                ["note 3", "", "", ""], list(FUSED_HDR)] + [list(r) for r in BODY]
        assert TA.pick_header(rows) == ([], rows)


class TestHeaderLike:
    def test_real_header_names_are_header_like(self):
        assert TA.header_like(SPLIT_HDR) is True
        assert TA.header_like(FUSED_HDR) is True          # 'MIN TYP MAX' + 'UNITS' 两列

    def test_note_paragraph_fragments_are_not_header_like(self):
        """说明性段落：只有 `typical` 一个角色词，落不到"两个格子各有角色"的门槛。"""
        assert TA.header_like(NOTE_FRAGS) is False

    def test_plain_column_names_are_not_header_like(self):
        """`PRODUCT / RESOLUTION / INPUT` 没有角色词 —— 但也不会被抢（下面有用例）。"""
        assert TA.header_like(["PRODUCT", "RESOLUTION(Bits)", "INPUT"]) is False


class TestChooseHeader:
    def test_note_fragments_do_not_beat_a_real_header(self):
        """红先：`names` 是说明文字碎片时，必须让位给 row0 上真正的表头。"""
        rows = [list(FUSED_HDR)] + [list(r) for r in BODY]
        header, data, from_names, _meta = TA.choose_header(list(NOTE_FRAGS), rows)
        assert from_names is False, "又让说明文字当了表头"
        assert header == FUSED_HDR
        assert data == BODY, "真表头行还留在数据里"

    def test_real_names_are_kept(self):
        """`names` 确实是表头时维持原行为：表头用它，数据保留首行（不改历史语义）。"""
        rows = [list(FUSED_HDR)] + [list(r) for r in BODY]
        header, data, from_names, _meta = TA.choose_header(list(FUSED_HDR), rows)
        assert from_names is True
        assert header == FUSED_HDR
        assert data[0] == FUSED_HDR

    def test_plain_names_survive_when_no_header_row_found(self):
        """`names` 无角色词、但表里也找不到表头行 → 不许翻脸，仍用 names。"""
        names = ["PRODUCT", "RESOLUTION(Bits)", "INPUT"]
        rows = [list(names), ["ADS7945", "14", "Differential"]]
        header, data, from_names, _meta = TA.choose_header(names, rows)
        assert from_names is True
        assert header == names

    def test_wrong_length_names_are_ignored(self):
        rows = [list(FUSED_HDR)] + [list(r) for r in BODY]
        header, data, from_names, _meta = TA.choose_header(["PARAMETER", "MIN TYP MAX"], rows)
        assert from_names is False
        assert header == FUSED_HDR

    def test_no_names_and_no_header_returns_all_rows(self):
        rows = [["foo", "bar"], ["baz", "qux"]]
        header, data, from_names, _meta = TA.choose_header(None, rows)
        assert (header, data, from_names) == ([], rows, False)


class TestScanWritesFusedTable:
    """端到端：表头认出来之后，融合列表**仍然不能写**，但理由要诚实。"""

    def _tbl(self):
        return {"page": 4, "ti": 0, "title": "ELECTRICAL CHARACTERISTICS: ADS7945 (Differential)",
                "header": list(FUSED_HDR),
                "rows": [list(FUSED_HDR), ["Logic level", "", "", "0.7 DVDD", "V"]],
                "hx": [], "xr": []}

    @pytest.fixture(autouse=True)
    def _clean_page(self):
        TA._PAGE.set(None)
        yield
        TA._PAGE.set(None)

    def test_fused_column_is_reported_as_fused_not_as_wrong_table(self):
        """融合列 → `cell_unparsable_unresolved` + `FUSED_COLUMN`，且不写任何列。"""
        e = {"name": "Logic level", "value": "0.7", "unit": "V", "condition": ""}
        finds = TA.audit_electrical([e], [self._tbl()], "specs.electrical")
        assert "columns" not in e, f"不该写盘：{e.get('columns')}"
        kinds = [(f["kind"], f.get("table")) for f in finds]
        assert ("cell_unparsable_unresolved", "FUSED_COLUMN") in kinds, kinds
