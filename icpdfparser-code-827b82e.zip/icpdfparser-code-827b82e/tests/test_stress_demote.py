#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""应力额定值归位：Abs Max 的值不许留在 electrical 里。

**取证**（2026-10-31，`data/_reparse_v5/ADC12DJ5200SEAAV_398fd1f1.json`）：

    absolute_max: {"name": "Peak RF Input Power (INA, INB)", "value": "26.25", "unit": "dBm"}
    electrical  : {"name": "Peak RF Input Power", "value": "26.25", "unit": "dBm",
                   "condition": "ZS = 50 Ω, up to 21 days"}

同一个值出现在两个容器里。页面上 electrical 是「推荐工作条件」，
读起来就是「输入 26.25 dBm 是正常工况」—— 而它实际是 ±26.25 dBm 的**应力上限**，
照着做会烧器件。PROMPT 3d 已经明令禁止，qwen-flash 仍然犯，所以必须落到代码。

判据刻意收窄到「名字主干 + value + unit 三条全中」，因为只看名字会误杀：
`Supply Voltage (VA19)` 在 ROC 是 `1.8 to 2.0`、在 Abs Max 是 `-0.3 to 2.35`，
是同名的两个**不同**行，都必须留。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import postprocess_qwen as PP                            # noqa: E402


def _row(name, value, unit, **kw):
    return {"name": name, "value": value, "unit": unit, **kw}


def test_duplicate_stress_row_moves_out_of_electrical():
    elec = [_row("Peak RF Input Power", "26.25", "dBm", condition="ZS = 50 Ω, up to 21 days"),
            _row("Resolution", "12", "Bits")]
    absmax = [_row("Peak RF Input Power (INA, INB)", "26.25", "dBm")]

    acts = PP.demote_stress_rows(elec, absmax)

    assert [e["name"] for e in elec] == ["Resolution"], "应力行必须从 electrical 移出"
    assert acts and acts[0]["action"] == "MOVE_TO_ABSMAX"
    assert acts[0]["value"] == "26.25"


def test_moved_row_keeps_audit_trail():
    """删除要留痕：值本身没错，错的是位置。"""
    elec = [_row("Peak RF Input Power", "26.25", "dBm")]
    absmax = [_row("Peak RF Input Power (INA, INB)", "26.25", "dBm")]

    moved = elec[0]
    PP.demote_stress_rows(elec, absmax)

    assert moved["verification"]["status"] == "moved_to_absolute_max"
    assert "应力" in moved["verification"]["reason"]


def test_same_name_different_value_is_kept():
    """ROC 的推荐电压与 Abs Max 的应力电压是同名不同行，不能当重复删掉。"""
    elec = [_row("Supply Voltage (VA19)", "1.8 to 2.0", "V")]
    absmax = [_row("Supply Voltage (VA19)", "-0.3 to 2.35", "V")]

    acts = PP.demote_stress_rows(elec, absmax)

    assert acts == []
    assert len(elec) == 1


def test_unit_mismatch_is_kept():
    elec = [_row("Peak RF Input Power", "26.25", "dBm")]
    absmax = [_row("Peak RF Input Power (INA, INB)", "26.25", "W")]

    assert PP.demote_stress_rows(elec, absmax) == []
    assert len(elec) == 1


def test_no_absmax_is_noop():
    elec = [_row("Resolution", "12", "Bits")]
    assert PP.demote_stress_rows(elec, []) == []
    assert len(elec) == 1


def test_bare_name_strips_parentheticals():
    assert PP._bare_name("Peak RF Input Power (INA, INB)") == "peak rf input power"
    assert PP._bare_name("Input Common-Mode Voltage (CLK±)") == "input common mode voltage"
