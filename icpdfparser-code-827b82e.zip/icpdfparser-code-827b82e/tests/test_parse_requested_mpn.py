#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`parse_datasheets.py --requested-mpn` 的回归测试。

背景：`mpn_from_name()` 只能从 PDF 文件名推料号，而同族手册共用一份 PDF
（`ADS1271IPWG4__ads1271.pdf` 里同时有 ADS1271IPW / ADS1271IPWR）。
实测重解析 63 件缺文件时，5/5 产出的料号都是文件名那个，挂不到交付包的行上；
`metadata.requested_mpn` 更是 5/5 缺失（只有 app/services/pipeline.py 写）。
"""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as P  # noqa: E402


@pytest.fixture(autouse=True)
def _clean_map():
    P.REQ_MPN_MAP.clear()
    yield
    P.REQ_MPN_MAP.clear()


class TestRequestedMpnFor:

    def test_empty_map_falls_back_to_empty(self):
        assert P.requested_mpn_for(Path("ADS1271IPWG4__ads1271.pdf"), "ADS1271IPWG4") == ""

    def test_match_by_pdf_filename(self):
        P.REQ_MPN_MAP[P._req_key("ADS1271IPWG4__ads1271.pdf")] = "ADS1271IPW"
        assert P.requested_mpn_for(Path("ADS1271IPWG4__ads1271.pdf"), "ADS1271IPWG4") == "ADS1271IPW"

    def test_match_by_derived_mpn(self):
        """只写派生料号也能命中（用户不必记 PDF 全名）。"""
        P.REQ_MPN_MAP[P._req_key("ADS1271IPWG4")] = "ADS1271IPWR"
        assert P.requested_mpn_for(Path("ADS1271IPWG4__ads1271.pdf"), "ADS1271IPWG4") == "ADS1271IPWR"

    def test_match_by_stem(self):
        P.REQ_MPN_MAP[P._req_key("BQ2000PWG4__bq2000")] = "BQ2000SN-B5TR"
        assert P.requested_mpn_for(Path("BQ2000PWG4__bq2000.pdf"), "BQ2000PWG4") == "BQ2000SN-B5TR"

    def test_case_insensitive(self):
        P.REQ_MPN_MAP[P._req_key("DAC0800LCMX_NOPB")] = "DAC0800LCM"
        assert P.requested_mpn_for(Path("DAC0800LCMX_NOPB__snas538c.pdf"), "DAC0800LCMX/NOPB") == "DAC0800LCM"


class TestLoadRequestedMpn:

    def test_inline_spec(self):
        P.load_requested_mpn("ADS1271IPWG4=ADS1271IPW, BQ2000PWG4=BQ2000SN-B5TR", "")
        assert P.REQ_MPN_MAP[P._req_key("ADS1271IPWG4")] == "ADS1271IPW"
        assert P.REQ_MPN_MAP[P._req_key("BQ2000PWG4")] == "BQ2000SN-B5TR"

    def test_fullwidth_comma_tolerated(self):
        P.load_requested_mpn("A=1，B=2", "")
        assert P.REQ_MPN_MAP == {P._req_key("A"): "1", P._req_key("B"): "2"}

    def test_bad_item_raises(self):
        with pytest.raises(SystemExit):
            P.load_requested_mpn("没有等号的项", "")

    def test_csv_file_skips_header(self, tmp_path):
        f = tmp_path / "map.csv"
        f.write_text("pdf,mpn\nCC2530DK__x.pdf,CC2530F32RHAR\n", encoding="utf-8")
        P.load_requested_mpn("", str(f))
        assert P.REQ_MPN_MAP[P._req_key("CC2530DK__x.pdf")] == "CC2530F32RHAR"
        assert "pdf" not in P.REQ_MPN_MAP
