# -*- coding: utf-8 -*-
"""`fact_acceptance --mpns` 的键口径与「缺件必须吭声」。

踩过的坑：batch20 灰度里 `--mpns DS38EP100SD/NOPB`（`basic_info.mpn` 原文）
对不上文件名主干 `DS38EP100SD_NOPB`，主循环一句 `continue` 就把整件吞了 ——
20 件批次静默出 19 条结论，报告上看不出少了谁。
"""
from __future__ import annotations

import json
from pathlib import Path

from qc import fact_acceptance as FA


def _stage(tmp_path: Path) -> Path:
    parsed = tmp_path / "parsed"
    parsed.mkdir(parents=True)
    doc = {"basic_info": {"mpn": "DS38EP100SD/NOPB"},
           "specs": {"electrical": []}, "metadata": {"pdf_hash": "0" * 64}}
    (parsed / "DS38EP100SD_NOPB.json").write_text(
        json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return tmp_path


def test_missing_mpn_is_reported_not_swallowed(tmp_path, capsys):
    stage = _stage(tmp_path)
    # 传 basic_info.mpn 原文（带斜杠）—— 找不到文件，必须打告警
    rc = FA.main(["--staging", str(stage), "--pdf-dir", str(stage),
                  "--mpns", "DS38EP100SD/NOPB"])
    err = capsys.readouterr().err
    assert rc == 0
    assert "跳过" in err and "DS38EP100SD/NOPB" in err
    assert "文件名主干" in err
    # 告警不是错误：结论文件照样要落盘
    assert (stage / "facts_audit.json").is_file()


def test_safe_stem_key_matches_file(tmp_path, capsys):
    stage = _stage(tmp_path)
    rc = FA.main(["--staging", str(stage), "--pdf-dir", str(stage),
                  "--mpns", "DS38EP100SD_NOPB"])
    err = capsys.readouterr().err
    assert rc == 0
    assert "跳过" not in err
    audit = json.loads((stage / "facts_audit.json").read_text(encoding="utf-8"))
    assert "DS38EP100SD_NOPB" in audit["mpns"]
