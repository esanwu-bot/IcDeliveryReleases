#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""条件串与数值「同源」钳制的红先用例（Reviewer #5）。

**取证**（`qc/evidence_20261031/二次确认_取证报告_ADC12DJ5200SE.md` §1）：
ADC12DJ5200SE 的 `Full-scale input power` 交付成

    value = -1.25 dBm    condition = fIN = 4.5GHz, FS_RANGE = 0xA000

而原厂 PDF 里：`-1.25 dBm` 只在 **p1 Features** 段落，条件串 `fIN=4.5GHz,
FS_RANGE=0xA000` 在 **p10 推荐工作条件表** 对应的数值是 **-1.5 dBm**。
两个不同定义被缝成一行，增益链预算会算错 0.25 dB。

这类错误的特征是「单看 JSON 完全合法」——value 是数、condition 是字符串，
只能回到原表比数值才能发现。本用例就是这道钳制的标尺。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import postprocess_qwen as PP                            # noqa: E402


def _tbl(rows, page=10, ti=0,
         header=("PARAMETER", "DESCRIPTION", "TEST CONDITIONS", "MIN", "TYP", "MAX", "UNIT")):
    """真表结构：`locate_candidates` 依赖 header 做角色映射，缺 header 会 KeyError。"""
    return {"page": page, "ti": ti, "header": list(header), "rows": rows}


#: 模拟 p10 推荐工作条件表：PIN 行只有 -1.5 dBm
ROC_TABLE = _tbl([
    ["VCMI", "Input common-mode voltage", "CLK+, CLK-", "0", "0.3", "0.55", "V"],
    ["PIN", "Input power for fullscale at minimum balun loss",
     "fIN = 4.5GHz, FS_RANGE_A = FS_RANGE_B = 0xA000", "-1.5", "", "", "dBm"],
    ["VA19", "analog 1.9-V supply", "", "1.8", "1.9", "2.0", "V"],
])


def test_cross_table_condition_is_dropped(monkeypatch):
    """数值不在该行 → 条件串不可信。**开删除开关**时才真删。"""
    monkeypatch.setattr(PP, "CLAMP_DELETE", True)
    entries = [{"name": "Full-scale input power", "value": "-1.25", "unit": "dBm",
                "condition": "fIN = 4.5GHz, FS_RANGE = 0xA000"}]
    rowrefs = [(10, 0, 1)]                    # 落到 PIN 行（该行数值是 -1.5）
    out, acts = PP.clamp_conditions(entries, rowrefs, [ROC_TABLE])

    assert out[0]["condition"] == "", "跨表缝合的条件没有被丢掉"
    assert out[0]["value"] == "-1.25", "数值不该被改（改数值是另一类修复）"
    assert out[0]["verification"]["status"] == "condition_unverified"
    assert acts and acts[0]["action"] == "CLAMP_CONDITION"


def test_default_marks_instead_of_dropping():
    """默认口径：强证据也**只标记不删**，条件原文保留、证据写进 verification。

    为什么默认不删：这三份 PDF 的表格抽取精度撑不起「证明数值缺失」——
    实跑时 ADC12DJ5200SE 有 5 条参数同时命中同一行 p4 t0 r6（row_nums [0,1,100]，
    是表头/注释行），ADS1201U 的 `5.25` 被抽成 `525`。宁可漏检，不可假阳。
    """
    entries = [{"name": "Full-scale input power", "value": "-1.25", "unit": "dBm",
                "condition": "fIN = 4.5GHz, FS_RANGE = 0xA000"}]
    out, acts = PP.clamp_conditions(entries, [(10, 0, 1)], [ROC_TABLE])
    assert out[0]["condition"] == "fIN = 4.5GHz, FS_RANGE = 0xA000", "默认不得删条件"
    v = out[0]["verification"]
    assert v["status"] == "condition_unverified"
    assert v["reason"] == "condition_value_mismatch"
    assert v["condition_pending_drop"] == "fIN = 4.5GHz, FS_RANGE = 0xA000"
    assert v["evidence"]["row_nums"] and v["evidence"]["value_nums"] == [-1.25]
    assert acts[0]["action"] == "MARK_CONDITION"


def test_same_row_value_kept():
    """数值确实在该行 → 不许动，避免误伤。"""
    entries = [{"name": "VA19", "value": "1.8 to 2.0", "unit": "V",
                "condition": "Recommended Operating Conditions"}]
    out, acts = PP.clamp_conditions(entries, [(10, 0, 2)], [ROC_TABLE])
    assert out[0]["condition"] == "Recommended Operating Conditions"
    assert not acts


def test_value_only_in_prose_is_not_used_to_delete_data():
    """回归（2026-10-31 实跑）：**不许**用「全表找不到这个数」当证据删条件。

    第一版钳制有一条弱证据分支：整个 PDF 的表里都没有这个数 → 判来自 Features。
    5 件实跑时它误删了 12 条**正确**条件 —— ADS1201U 的 `4.75 to 5.25`、
    BOOSTXL-C2KLED 的 `@ 1.2A` 全中招，因为这些表本来就抽不全
    （板卡指南只有 4 张表 / 6 个干净数）。「表里没抽到」≠「原文没有」。

    现在的口径：**行定位不到**（连条件都回找不到行）→ 保留条件原文，只标待核。
    """
    entries = [{"name": "Zq Unrelated Parameter", "value": "123.456", "unit": "V",
                "condition": "some cond"}]
    out, acts = PP.clamp_conditions(entries, [None], [ROC_TABLE])
    assert out[0]["condition"] == "some cond", "弱证据不得删条件"
    assert out[0]["verification"]["status"] == "condition_unverified"
    assert out[0]["verification"]["reason"] == "row_not_located"
    assert acts and acts[0]["action"] == "MARK_CONDITION"


def test_row_located_by_condition_then_value_must_match(monkeypatch):
    """行能按条件回找到，且该行数值解释不了 value → 强证据（开开关才删）。"""
    monkeypatch.setattr(PP, "CLAMP_DELETE", True)
    entries = [{"name": "Input power for fullscale", "value": "-1.25", "unit": "dBm",
                "condition": "fIN = 4.5GHz, FS_RANGE_A = FS_RANGE_B = 0xA000"}]
    out, acts = PP.clamp_conditions(entries, [None], [ROC_TABLE])
    assert out[0]["condition"] == ""
    assert out[0]["verification"]["reason"] == "condition_value_mismatch"
    assert acts[0]["action"] == "CLAMP_CONDITION"


def test_fused_cell_numbers_count_as_present():
    """融合格 `'4.75 5.25'` 里的数**在表里**，不能因为读不出列就判缺失。

    严格口径（`cell_num`）只认干净单值；证明缺失必须用容差口径（`_row_tokens`），
    否则融合列会把正确条件判成「原文没有」——实跑误删 ADS1201U 就是这条。
    """
    tbl = {"page": 3, "ti": 0,
           "header": ["PARAMETER", "MIN TYP MAX", "UNIT"],
           "rows": [["Power Supply Voltage", "4.75 5.25", "V"]]}
    entries = [{"name": "Power Supply Voltage", "value": "4.75 to 5.25", "unit": "V",
                "condition": "Specified Performance"}]
    out, acts = PP.clamp_conditions(entries, [None], [tbl])
    assert out[0]["condition"] == "Specified Performance"
    assert not acts


def test_unlocated_row_but_value_in_table_untouched():
    """行没定位到、但表格里确有这个数 → 保守放行（宁可漏检，不可假阳）。"""
    entries = [{"name": "VA19", "value": "1.8", "unit": "V", "condition": "some cond"}]
    out, acts = PP.clamp_conditions(entries, [None], [ROC_TABLE])
    assert out[0]["condition"] == "some cond"
    assert not acts


def test_no_pdf_means_no_clamp():
    """没 PDF（--no-verify）时不能瞎改，原样返回。"""
    entries = [{"name": "x", "value": "-1.25", "unit": "dBm", "condition": "c"}]
    out, acts = PP.clamp_conditions(entries, None, None)
    assert out[0]["condition"] == "c"
    assert not acts


def test_empty_condition_never_touched():
    entries = [{"name": "Resolution", "value": "12", "unit": "bit", "condition": ""}]
    out, acts = PP.clamp_conditions(entries, [(10, 0, 0)], [ROC_TABLE])
    assert out[0]["condition"] == ""
    assert not acts


def test_range_normalize_must_not_erase_clamp_evidence(monkeypatch):
    """回归：`normalize_ranges` 跑在钳制之后，**不得**覆写钳制证据。

    实跑暴露（`qc/evidence_20261031/postprocess_write.json`）：条件先被钳掉、
    写 `condition_unverified`，随后区间规范化无条件改成
    `unresolved / column_roles_not_verified` —— 条件已经没了，为什么没的证据也没了。
    """
    monkeypatch.setattr(PP, "CLAMP_DELETE", True)
    entries = [{"name": "VA19, analog 1.9-V supply", "value": "1.05 - 1.15", "unit": "V",
                "condition": "Recommended Operating Conditions"}]
    out, acts = PP.clamp_conditions(entries, [None], [ROC_TABLE])
    assert acts and out[0]["condition"] == ""
    assert out[0]["verification"]["status"] == "condition_unverified"

    PP.normalize_ranges(out)

    v = out[0]["verification"]
    assert v["status"] == "condition_unverified", v
    assert v["reason"] == "condition_value_mismatch", v
    assert v["dropped_condition"] == "Recommended Operating Conditions", v
    assert v["secondary_reason"] == "column_roles_not_verified", v


def test_range_normalize_still_marks_plain_entries():
    """没有钳制证据的条目，行为不变（仍标 column_roles_not_verified）。"""
    entries = [{"name": "Gain", "value": "2 to 6", "unit": "dB"}]
    PP.normalize_ranges(entries)
    assert entries[0]["verification"] == {"status": "unresolved",
                                         "reason": "column_roles_not_verified"}
