"""全量问题交叉矩阵（只读）离线单测。"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import issue_matrix as IM             # noqa: E402


def audit(batch, items):
    return {"batch_id": batch, "items": items}


def item(iid, mpn, status="PASS", fail=None, warn=None):
    fs = []
    for c in fail or []:
        detail = ""
        if c == "MPN_MISMATCH":
            detail = "JSON mpn=OTHER%s，item mpn=%s" % (iid, mpn)
        fs.append({"severity": "FAIL", "stage": "r1", "code": c, "detail": detail})
    for c in warn or []:
        fs.append({"severity": "WARN", "stage": "r3", "code": c, "detail": ""})
    return {"item_id": iid, "mpn": mpn, "brand": "TI", "status": status,
            "fail_count": len(fail or []), "warn_count": len(warn or []),
            "findings": fs, "pdf_sha256": "a" * 64, "gold_id": 0, "gold_status": "",
            "artifacts": {"pdf": mpn + ".pdf"}}


class IssueMatrixTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        (self.data / "parsed").mkdir()
        (self.data / "pdfs").mkdir()
        facts = {"metadata": {"pdf_hash": "a" * 64, "parse_timestamp": "x",
                              "model_version": "m"}}
        (self.data / "parsed" / "T1_abc.json").write_text(json.dumps(facts),
                                                          encoding="utf-8")
        self.items = {
            1: {"id": 1, "mpn": "T1", "brand": "TI", "pdf_path": "T1__x.pdf",
                "pdf_sha256": "a" * 64, "json_path": "T1_abc.json", "provider": "p"},
            2: {"id": 2, "mpn": "T2EVM", "brand": "TI", "pdf_path": "389__x.pdf",
                "pdf_sha256": "b" * 64, "json_path": "T1_abc.json", "provider": "p"},
            3: {"id": 3, "mpn": "T3", "brand": "TI", "pdf_path": "T3__x.pdf",
                "pdf_sha256": "c" * 64, "json_path": "T1_abc.json", "provider": "p"},
        }
        self.audits = [audit("b1", [
            item(1, "T1"),
            item(2, "T2EVM", "FAIL", ["MPN_MISMATCH", "PDF_SHA_MISMATCH"]),
            item(3, "T3", "FAIL", ["ELECTRICAL_EMPTY"]),
        ])]

    def tearDown(self):
        self.tmp.cleanup()

    def test_matrix_counts_and_groups(self):
        led = IM.build_matrix(self.audits, self.items, {}, self.data, probe_pdf=False)
        self.assertEqual(led["scope"]["items"], 3)
        self.assertEqual(led["scope"]["issue_items"], 2)
        self.assertEqual(led["code_counts"]["MPN_MISMATCH"], 1)
        self.assertEqual(led["code_counts"]["PDF_SHA_MISMATCH"], 1)
        self.assertEqual(led["pairwise"]["MPN_MISMATCH+PDF_SHA_MISMATCH"], 1)
        self.assertEqual(led["code_counts"]["ELECTRICAL_EMPTY"], 1)
        self.assertEqual(led["status"]["PASS"], 1)
        self.assertIn("A1_", "".join(led["group_counts"].keys()))
        row = [r for r in led["rows"] if r["mpn"] == "T2EVM"][0]
        self.assertTrue(row["mpn_mismatch"])
        self.assertTrue(row["pdf_sha_mismatch"])
        self.assertEqual(row["pdf_sha256_item"], "b" * 64)
        self.assertEqual(row["pdf_sha256_file"], "a" * 64)
        self.assertTrue(row["root_cause_groups"])

    def test_outputs(self):
        led = IM.build_matrix(self.audits, self.items, {}, self.data, probe_pdf=False)
        csv_text = IM._csv_text(led["rows"])
        self.assertIn("root_cause_group", csv_text.splitlines()[0])
        md = IM._md(led)
        self.assertIn("未修改生产 facts", md)
        self.assertIn("MPN 不一致同时 SHA 不一致", md)
        self.assertIn("建议执行顺序", md)


class BoardAndEcKeywordTest(unittest.TestCase):
    """① 统一 EC 标题关键词 + ⑤ 评估板移出 I 组。

    背景：矩阵侧 `_pdf_has_ec` 只认 "Electrical Characteristics"，分析包侧
    `pdf_signals` 还认 "Electrical Specifications"，同一件给出相反答案
    （CC1070 三件：NO vs YES）。评估板（EVAL 后缀）的用户指南本来就没有 EC 表，
    算进 I 组会把「改 parser」的优先级抬错。
    """
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.dir = Path(self.tmp.name)

    # ---------------------------------------------------------- ⑤ board 判名
    def test_board_by_name(self):
        for m in ("LM27402SQEVAL/NOPB", "LM20145EVAL", "LM10500SQ-1.0EV/NOPB",
                  "DS80PCI402EVK/NOPB", "LM3671TL-1.8EV", "ADC128S102EVAL"):
            self.assertTrue(IM._board_by_name(m), m)
        for m in ("CY74FCT245ATSOCT", "AM26C32IDG4", "CC1070RGWR", "LM358",
                  "BQ4016YMC-70"):
            self.assertFalse(IM._board_by_name(m), m)

    def test_eval_board_without_ec_moves_to_k(self):
        row = {"mpn": "LM27402SQEVAL/NOPB",
               "fail_codes": ["ELECTRICAL_ROW_BAD"], "pdf_has_ec_text": False}
        primary, _all, fix = IM._classify(row)
        self.assertTrue(primary.startswith("K_"), primary)
        self.assertEqual(fix, "board_scope_no_ec_requirement")

    def test_board_with_ec_table_stays_in_i(self):
        """名字像板但 PDF 里真有 EC 表 → 仍是解析缺陷，不能按名字放行。

        LM3671TL-1.8EV 就是这个形态；只按名字移出会把真缺陷藏起来。
        """
        row = {"mpn": "LM3671TL-1.8EV",
               "fail_codes": ["ELECTRICAL_ROW_BAD"], "pdf_has_ec_text": True}
        primary, _all, fix = IM._classify(row)
        self.assertTrue(primary.startswith("I_"), primary)
        self.assertEqual(fix, "parser_fix_then_rerun_item_batch")

    def test_normal_chip_with_ec_stays_in_i(self):
        row = {"mpn": "BQ4016YMC-70",
               "fail_codes": ["ELECTRICAL_ROW_BAD"], "pdf_has_ec_text": True}
        self.assertTrue(IM._classify(row)[0].startswith("I_"))

    # --------------------------------------------------- ① 关键词表统一
    def _pdf(self, text: str) -> Path:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        doc = fitz.open()
        doc.new_page().insert_text((72, 72), text)
        p = self.dir / "t.pdf"
        doc.save(str(p))
        doc.close()
        return p

    def test_unified_keyword_accepts_specifications(self):
        """统一后 "Electrical Specifications" 也算 EC 标题（旧实现返回 False）。"""
        if IM._unified_signals is None:
            self.skipTest("pdf_signals 不可用")
        p = self._pdf("Electrical Specifications\nParameter Min Typ Max Unit\nICC 1 2 3 uA")
        old = IM._USE_UNIFIED_EC
        try:
            IM._USE_UNIFIED_EC = True
            self.assertTrue(IM._pdf_has_ec(p))
            IM._USE_UNIFIED_EC = False
            self.assertFalse(IM._pdf_has_ec(p))             # 旧词表：不认
        finally:
            IM._USE_UNIFIED_EC = old

    def test_missing_pdf_returns_none(self):
        self.assertIsNone(IM._pdf_has_ec(self.dir / "nope.pdf"))


if __name__ == "__main__":
    unittest.main()
