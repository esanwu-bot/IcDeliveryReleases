#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""符号页「工程模型状态分层」：derive_state / render_notes / check（A1–A5）。

红先纪律（AGENT.md §6.5）：F3/F4/F5 是**脏输入**，必须先在它们上面红过，
F1/F2 的绿才算证据。本文件把两者都固定下来，任何一侧退回都会失败。
"""
import copy
import json
import re
from pathlib import Path

import pytest

import symbol_svg as S
from qc import engineering_model as EM
from qc import pin_repair as PR

ROOT = Path(__file__).resolve().parents[1]
BALLS = {f"{r}{c}" for r in "ABCDEFGHJKLM" for c in range(1, 13)}   # 12×12 = 144


# ─────────────────────────────────────────────────────────────────────
# 夹具：复现生产形态（BGA 144 球 pass / 板卡 / 模板臂）
# ─────────────────────────────────────────────────────────────────────

def _ball_pins():
    rows = []
    for i, ball in enumerate(sorted(BALLS, key=PR._ball_key)):
        rows.append({
            "pin": ball, "name": f"SIG_{ball}", "function": "I",
            "description": f"PDF input {ball}.",
            "source": {"pdf_sha256": "a" * 64, "page": 4, "page_base": 1,
                       "table": 0, "table_index": 0, "row": i + 2, "index_base": 0,
                       "bbox": [10, 20 + i, 400, 21 + i], "scope": "device",
                       "subject_mpn": "ADC12DJ5200SE", "package_ball_count": 144,
                       "table_name": "Table 4-1"},
        })
    return rows


def bga_doc(validation_status: str = "pass"):
    """ADC12DJ5200SE 形态：FCBGA-144、144 球、identity=chip。"""
    pins = _ball_pins()
    balls = sorted((p["pin"] for p in pins), key=PR._ball_key)
    pv = {"action": "rebuilt", "status": validation_status, "pins": 144, "balls": 144,
          "expected_count": 144, "actual_count": 144, "covered_count": 144,
          "expected_balls": balls, "covered_balls": balls,
          "expected_origin": "verified_device_package"}
    if validation_status == "pass":
        pv["mapping_sha256"] = PR._mapping_hash(pins)
    return {"basic_info": {"mpn": "ADC12DJ5200SE", "identity": "chip",
                           "identity_state": "IDENTITY_REVIEW"},
            "specs": {"scope": "device", "package": {"type": "FCBGA (144)", "pins": 144}},
            "pin_configuration": copy.deepcopy(pins), "pin_scope": "device",
            "metadata": {"pin_validation": pv}}


def board_doc():
    """评估板形态：ADS8568EVM-PDK（staging 实测同形）。"""
    return {"basic_info": {"mpn": "ADS8568EVM-PDK", "identity": "evaluation_board",
                           "identity_state": "IDENTITY_REVIEW"},
            "specs": {"scope": "onboard_device",
                      "package": {"type": "Evaluation Board", "pins": 0}},
            "pin_configuration": []}


def soic_doc():
    """模板臂：SOIC-8，引脚表数字脚号（非 BGA）。"""
    return {"basic_info": {"mpn": "BUF634PG4", "identity": "chip"},
            "specs": {"scope": "device", "package": {"type": "SOIC-8", "pins": 8}},
            "pin_configuration": [{"pin": i, "name": f"P{i}", "description": "d"}
                                  for i in range(1, 9)]}


@pytest.fixture
def pkgs(tmp_path):
    """共享封装图库：SOIC-8 有签核轮廓，FCBGA-144 有「程序化球阵」但没有签核。"""
    d = tmp_path / "pkgs"
    d.mkdir()
    (d / "index.csv").write_text(
        "key,family,pins,footprint,model3d\n"
        "SOIC-8,dual,8,SOIC-8.svg,SOIC-8.3d.svg\n"
        "FCBGA-144,grid,144,FCBGA-144.svg,FCBGA-144.3d.svg\n",
        encoding="utf-8")
    (d / "SOIC-8.svg").write_text("<svg>SOIC-8 outline</svg>", encoding="utf-8")
    (d / "SOIC-8.3d.svg").write_text("<svg>SOIC-8 3D</svg>", encoding="utf-8")
    (d / "FCBGA-144.svg").write_text("<svg>12x12 programmatic balls</svg>", encoding="utf-8")
    (d / "FCBGA-144.3d.svg").write_text("<svg>FCBGA 3D</svg>", encoding="utf-8")
    return d


# ─────────────────────────────────────────────────────────────────────
# 1. derive_state 全分支
# ─────────────────────────────────────────────────────────────────────

def test_bga_pass_and_grid_outline_is_not_a_signed_template(pkgs):
    st = EM.derive_state(bga_doc(), pkgs)
    assert st["symbol"]["status"] == "pass"
    assert st["package_outline"]["status"] == "not_checked"
    assert st["package_outline"]["evidence"]["reason"] == "grid_geometry_not_signed"
    assert st["geometry_3d"]["status"] == "not_generated"
    assert st["geometry_3d"]["required_source"] == EM.REQUIRED_SOURCE_3D


def test_missing_pin_validation_is_not_checked(pkgs):
    doc = bga_doc()
    doc["metadata"].pop("pin_validation")
    assert EM.derive_state(doc, pkgs)["symbol"]["status"] == "not_checked"


@pytest.mark.parametrize("status", ["fail", "maybe", "", None, "unresolved"])
def test_illegal_or_failed_validation_is_fail_closed(pkgs, status):
    doc = bga_doc()
    doc["metadata"]["pin_validation"]["status"] = status
    st = EM.derive_state(doc, pkgs)["symbol"]
    assert st["status"] in ("fail", "not_checked")
    assert st["status"] != "pass"


def test_pass_but_ball_set_changed_is_not_checked(pkgs):
    doc = bga_doc()
    doc["pin_configuration"].pop()                    # 143 球，与 expected 不再一致
    assert EM.derive_state(doc, pkgs)["symbol"]["status"] == "not_checked"


def test_template_arm_hits_signed_outline_and_hashes_content(pkgs):
    st = EM.derive_state(soic_doc(), pkgs)["package_outline"]
    assert st["status"] == "template"
    assert st["template_id"] == "SOIC-8"
    assert len(st["template_sha256"]) == 64
    # 内容改了哈希就得变（不是索引里的版本列）
    (pkgs / "SOIC-8.svg").write_text("<svg>changed</svg>", encoding="utf-8")
    st2 = EM.derive_state(soic_doc(), pkgs)["package_outline"]
    assert st2["template_sha256"] != st["template_sha256"]


def test_template_miss_and_index_missing(pkgs, tmp_path):
    doc = soic_doc()
    doc["specs"]["package"]["type"] = "TSSOP-38"      # 索引里没有
    assert EM.derive_state(doc, pkgs)["package_outline"]["evidence"]["reason"] == \
        "template_not_indexed"
    empty = tmp_path / "no_lib"
    empty.mkdir()
    assert EM.derive_state(soic_doc(), empty)["package_outline"]["status"] == "not_checked"
    assert EM.derive_state(soic_doc(), None)["package_outline"]["status"] == "not_checked"


def test_index_hit_but_file_missing_is_not_checked(pkgs):
    (pkgs / "SOIC-8.svg").unlink()
    ev = EM.derive_state(soic_doc(), pkgs)["package_outline"]
    assert ev["status"] == "not_checked" and ev["evidence"]["reason"] == "template_file_missing"


def test_board_identity_is_not_applicable(pkgs):
    st = EM.derive_state(board_doc(), pkgs)
    assert st["package_outline"]["status"] == "not_applicable"
    assert st["geometry_3d"]["status"] == "not_applicable"
    # 板卡没有本型号引脚表：符号状态不冒充 pass
    assert st["symbol"]["status"] == "not_checked"


def test_board_subject_override_only_when_caller_decided(pkgs):
    doc = board_doc()
    doc["basic_info"].pop("identity")
    # 没有 identity 时不自行判板（AGENT §9.2：封装名不授予身份）
    assert EM.derive_state(doc, pkgs)["package_outline"]["status"] != "not_applicable"
    # 渲染器已按既有 _is_board_name 进入板卡页时，才允许显式记录
    assert EM.derive_state(doc, pkgs, board_subject=True)["package_outline"]["status"] == \
        "not_applicable"


def test_generated_geometry_needs_source_hash(pkgs):
    st = EM.derive_state(soic_doc(), pkgs, source_hash="f" * 64)["geometry_3d"]
    assert st["status"] == "generated" and st["source_hash"] == "f" * 64


def test_uncertain_pins_close_the_template_arm(pkgs):
    """脚数按族名猜出来时，封装 key 不可信 —— 不许声称「按模板绘制」。"""
    (pkgs / "index.csv").write_text(
        "key,family,pins,footprint,model3d\n"
        "QFN-32,qfn,32,QFN-32.svg,QFN-32.3d.svg\n", encoding="utf-8")
    (pkgs / "QFN-32.svg").write_text("<svg>QFN-32</svg>", encoding="utf-8")
    (pkgs / "QFN-32.3d.svg").write_text("<svg>QFN-32 3D</svg>", encoding="utf-8")
    # 封装名自带脚数（32-QFN）但 specs.pins 缺 → key 靠名字猜出来，正是不该充当模板证据的形态
    doc = {"basic_info": {"mpn": "X"}, "specs": {"package": {"type": "32-QFN", "pins": 0}},
           "pin_configuration": []}
    assert EM.derive_state(doc, pkgs)["package_outline"]["status"] == "template"
    st = EM.derive_state(doc, pkgs, pins_unconfirmed=True)
    assert st["package_outline"]["status"] == "not_checked"
    assert st["package_outline"]["evidence"]["reason"] == "pin_count_unconfirmed"
    page = S.render_page(doc, pkg_dir=pkgs)
    assert not any("按共享模板" in n for n in EM.render_notes(
        EM.derive_state(doc, pkgs, pins_unconfirmed=True)))
    assert "封装轮廓未绘制" in page


def test_no_top_level_key_added_and_no_write(pkgs, tmp_path):
    doc = bga_doc()
    before = set(doc)
    snapshot = copy.deepcopy(doc)
    files_before = sorted(p.name for p in tmp_path.rglob("*"))
    EM.derive_state(doc, pkgs)
    assert set(doc) == before and doc == snapshot          # 只读
    assert sorted(p.name for p in tmp_path.rglob("*")) == files_before   # 不写盘


# ─────────────────────────────────────────────────────────────────────
# 2. render_notes 映射
# ─────────────────────────────────────────────────────────────────────

def _state(outline, geometry="not_generated", **kw):
    return {"symbol": {"status": "not_checked"},
            "package_outline": dict({"status": outline}, **kw),
            "geometry_3d": {"status": geometry}}


def test_render_notes_template_carries_sha_prefix():
    notes = EM.render_notes(_state("template", template_id="SOIC-8",
                                   template_sha256="abcdef1234567890"))
    assert notes[0] == ("封装轮廓按共享模板 SOIC-8 绘制（内容哈希 abcdef12）；"
                        "模板为共享轮廓，不含球阵坐标。")


def test_render_notes_not_checked_and_not_generated():
    notes = EM.render_notes(_state("not_checked"))
    assert notes == ["封装轮廓未绘制：该封装在库中无签核共享模板。",
                     "3D 模型与球阵几何未生成：无可信来源"
                     "（机械 CAD（STEP/IBIS）或原厂球阵图），不猜测。"]


def test_render_notes_board_group_is_deduplicated():
    notes = EM.render_notes(_state("not_applicable", "not_applicable"))
    assert notes == ["板卡/模块件：芯片三视图与封装轮廓不适用，本页为板卡/模块说明页。"]


def test_render_notes_generated_has_nothing_to_declare():
    assert EM.render_notes(_state("template", "generated", template_id="SOIC-8",
                                  template_sha256="a" * 64)) == [
        "封装轮廓按共享模板 SOIC-8 绘制（内容哈希 aaaaaaaa）；模板为共享轮廓，不含球阵坐标。"]


def test_render_notes_mapping_is_exhaustive():
    for outline in EM.OUTLINE_STATUSES:
        for geom in EM.GEOMETRY_STATUSES:
            notes = EM.render_notes(_state(outline, geom, template_id="K",
                                           template_sha256="0" * 64))
            assert isinstance(notes, list) and all(isinstance(n, str) for n in notes)
            assert outline == "template" or geom == "generated" or notes


# ─────────────────────────────────────────────────────────────────────
# 3. 渲染器：标记、小节、文案单一来源
# ─────────────────────────────────────────────────────────────────────

def test_all_page_shapes_carry_marker_and_boundary(pkgs):
    pages = {
        "chip": S.render_page(soic_doc(), pkg_dir=pkgs),
        "board": S.render_page(board_doc(), pkg_dir=pkgs),
        "bga_unverified": S.render_page(bga_doc("fail"), pkg_dir=pkgs),
    }
    for name, page in pages.items():
        assert EM.PAGE_MARKER in page, f"{name} 缺页面标记"
        assert EM.BOUNDARY_MARKER in page, f"{name} 缺工程模型边界小节"


def test_page_renders_exactly_render_notes(pkgs):
    doc = bga_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert EM._boundary_items(page) == EM.render_notes(state)


def test_renderer_has_no_handwritten_boundary_text():
    """文案单一事实源：渲染器源码里不得出现这五句。"""
    src = (ROOT / "symbol_svg.py").read_text(encoding="utf-8")
    for note in ("封装轮廓按共享模板", "封装轮廓未绘制", "芯片三视图与封装轮廓不适用",
                 "3D 模型与球阵几何未生成", "模板为共享轮廓，不含球阵坐标"):
        assert note not in src, f"symbol_svg.py 仍手写：{note}"
    assert "几何与视角未核验" not in src


def test_bga_page_has_no_fake_shared_geometry(pkgs):
    """既有红线：BGA 页不得引用共享封装图/3D 图，也不得画球阵。"""
    page = S.render_page(bga_doc(), pkg_dir=pkgs)
    assert "<img" not in page
    assert "封装占位图" in page and "3D 占位图" in page
    # 旧文案「封装几何未核验」已从卡内移除：它是一条边界断言，只能在边界小节里出现一次。
    assert "封装几何未核验" not in page


# ─────────────────────────────────────────────────────────────────────
# 4. 门禁 A1–A5（红先：F3/F4/F5）
# ─────────────────────────────────────────────────────────────────────

def _kinds(findings):
    return [f["kind"] for f in findings]


def test_f1_bga_page_is_green(pkgs):
    doc = bga_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert state["symbol"]["status"] == "pass"
    assert state["geometry_3d"]["status"] == "not_generated"
    assert EM.check(doc, page, state) == []


def test_f2_board_page_is_green(pkgs):
    doc = board_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert state["package_outline"]["status"] == "not_applicable"
    assert state["geometry_3d"]["status"] == "not_applicable"
    assert EM.check(doc, page, state) == []


def test_f3_injected_pitch_and_3d_node_turns_red(pkgs):
    """F3 脏：页面手工注入一个 pitch 数值 + 一个 3D SVG 节点 → A1/A2 必红。"""
    doc = bga_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert EM.check(doc, page, state) == []                    # 注入前是绿的
    dirty = page.replace("</body>",
                         '<p>球间距 0.8 mm pitch，球径 0.35 mm。</p>'
                         '<svg data-em-geometry="3d" viewBox="0 0 10 10"></svg></body>')
    kinds = _kinds(EM.check(doc, dirty, state))
    assert "symbol_page_geometry_unsupported" in kinds
    assert "symbol_page_3d_node_without_state" in kinds


def test_f4_template_state_with_leftover_unverified_text_turns_red(pkgs):
    """F4 脏：state=template 但页面保留旧「未核验」文案 → A3 必红。"""
    doc = soic_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert state["package_outline"]["status"] == "template"
    assert EM.check(doc, page, state) == []
    dirty = page.replace("</body>", "<p>封装轮廓几何与视角未核验，不生成工程模型</p></body>")
    assert "symbol_page_outline_text_conflict" in _kinds(EM.check(doc, dirty, state))


def test_f5_board_state_downgraded_turns_red(pkgs):
    """F5 脏：F2 的 state 改成 not_checked → A4 必红。"""
    doc = board_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    assert EM.check(doc, page, state) == []
    state["package_outline"] = {"status": "not_checked"}
    assert "symbol_page_board_state_mismatch" in _kinds(EM.check(doc, page, state))


def test_a5_detects_renderer_private_text(pkgs):
    doc = soic_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    state = EM.derive_state(doc, pkgs)
    dirty = page.replace("<li>", "<li>渲染器自己加的一句</li><li>", 1)
    assert "symbol_page_boundary_text_drift" in _kinds(EM.check(doc, dirty, state))


def test_legacy_page_without_marker_is_out_of_scope(pkgs):
    """存量页面（旧文案 + 旧状态）不参与 A1–A5，重渲染后才受约束。"""
    legacy = "<!DOCTYPE html><html><body><p>球间距 0.8 mm</p></body></html>"
    assert EM.check(soic_doc(), legacy, EM.derive_state(soic_doc(), pkgs)) == []


def test_checker_never_raises(pkgs):
    assert EM.check(None, None, None) == []
    assert EM.check({}, "<html></html>", {"bad": "state"}) == []


def test_review_rule_layer_is_wired(pkgs):
    """规则层接线：review 的 _rule_engineering_model 必须真的调用 check。"""
    R = pytest.importorskip("app.services.review")
    doc = soic_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    snap = {"json": doc, "symbols_html": page, "pkgs_dir": str(pkgs)}
    assert R._rule_engineering_model(snap) == []
    dirty = page.replace("</body>", "<p>该封装轮廓仍未核验</p></body>")
    assert "symbol_page_outline_text_conflict" in _kinds(
        R._rule_engineering_model({**snap, "symbols_html": dirty}))
    # 没页面就不报（不伪造通过，也不制造噪声）
    assert R._rule_engineering_model({**snap, "symbols_html": ""}) == []


# ─────────────────────────────────────────────────────────────────────
# 6. 示意图臂：副标题不得冒充「3D 模型」（A2 旧判据的误报根因）
# ─────────────────────────────────────────────────────────────────────

def test_illustration_arm_caption_never_claims_a_model(pkgs):
    """有内联/共享 3D **示意**图时，副标题要么写「未生成」，要么把「示意」写出来。

    为什么钉这一条：旧副标题是 `按封装类型程序化绘制`，整行读作
    「3D 模型 · 按封装类型程序化绘制」，而同一页的边界小节写着
    「3D 模型与球阵几何未生成：无可信来源」—— 两句话在页面上打架。
    这条矛盾是 7725 页批量重渲染时由 A2 抓出来的（五件夹具恰好都不在这个臂）。
    """
    doc = soic_doc()                       # 8 脚非 BGA → renders_3d_illustration=True
    state = EM.derive_state(doc, pkgs)
    assert state["geometry_3d"]["status"] == "not_generated"
    cap = EM.panel_captions(state, renders_3d_illustration=True)["model3d"]
    assert "示意" in cap and "未生成" not in cap

    page = S.render_page(doc, pkg_dir=pkgs)
    assert f"3D 模型 · {cap}" in page
    assert "3D 模型 · 按封装类型程序化绘制" not in page      # 旧文案必须消失
    assert EM.check(doc, page, state) == []


def test_nullable_arm_keeps_un_generated_caption(pkgs):
    """没有示意图时（BGA / 无共享图）仍然是「未生成」——两条臂不能混。"""
    state = EM.derive_state(bga_doc(), pkgs)
    assert EM.panel_captions(state, renders_3d_illustration=False)["model3d"] == "未生成"


def test_ball_grid_wording_in_notes_is_not_a_claim(pkgs):
    """边界小节写「球阵几何未生成」是**自述没有**，不是声称有。

    旧 A2 用 aria 正则搜「球阵」兜底，把模板臂这句说明也判成越界
    （`封装轮廓按共享模板 … 不含球阵坐标` / `球阵几何未生成：无可信来源`），
    于是所有模板臂页面恒报。判据现在只认结构证据。
    """
    doc = soic_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    assert "球阵" in page                    # 说明句确实在页面上
    assert EM.check(doc, page, EM.derive_state(doc, pkgs)) == []


def test_cross_key_3d_reference_is_flagged(pkgs):
    """A 件页面挂 B 封装的 3D 图 → 越界。**这条才是 A2 能可靠判断的东西**。"""
    doc = soic_doc()
    state = EM.derive_state(doc, pkgs)
    page = S.render_page(doc, pkg_dir=pkgs)
    assert EM.check(doc, page, state) == []
    tampered = page.replace("SOIC-8.3d.svg", "FCBGA-144.3d.svg")
    assert "FCBGA-144.3d.svg" in tampered
    assert _kinds(EM.check(doc, tampered, state)) == ["symbol_page_3d_node_without_state"]


# ─────────────────────────────────────────────────────────────────────
# 7. 页面自述主体：门禁必须用**同一份**派生参数，否则 A4/A5 假阳
# ─────────────────────────────────────────────────────────────────────

def test_board_page_self_declares_its_subject(pkgs):
    """板卡页自带 `data-em-subject="board"`；门禁按它派生，A4/A5 才不假阳。

    背景（7725 页批量重渲染实测）：77 页 A5 + 9 页 A4 命中，全部是
    `*_NOPB` / `*EVM` / `*RB` 这类**没有 identity 字段**的评估板。
    渲染器按封装名判了板卡分支（`board_subject=True`），审查侧却用默认参数派生 ——
    同一份文档算出两份状态，「页面文案」对不上「审查状态」。这不是页面写错。
    """
    doc = board_doc()
    doc["basic_info"].pop("identity")            # 生产语料就是这种形态：没有契约字段
    page = S.render_page(doc, pkgs)
    assert 'data-em-subject="board"' in page

    kinds_default = _kinds(EM.check(doc, page, EM.derive_state(doc, pkgs)))
    assert "symbol_page_boundary_text_drift" in kinds_default     # 旧接线的表现
    assert EM.check(doc, page, EM.derive_state_for_page(doc, pkgs, page)) == []


def test_unconfirmed_pins_page_self_declares_it(pkgs):
    """脚数按族名猜的页面自带 `data-em-pins="unconfirmed"`，模板臂不得回张。"""
    doc = {"basic_info": {"mpn": "X"}, "specs": {"package": {"type": "32-QFN", "pins": 0}},
           "pin_configuration": []}
    (pkgs / "index.csv").write_text(
        "key,family,pins,footprint,model3d\n"
        "QFN-32,qfn,32,QFN-32.svg,QFN-32.3d.svg\n", encoding="utf-8")
    (pkgs / "QFN-32.svg").write_text("<svg>QFN-32</svg>", encoding="utf-8")
    page = S.render_page(doc, pkg_dir=pkgs)
    assert EM.PINS_UNCONFIRMED_MARKER in page
    assert EM.flags_from_page(page) == {"board_subject": False, "pins_unconfirmed": True}
    # 按页面自述派生 → 模板臂关闭；用默认参数派生会误以为「按共享模板 QFN-32 绘制」
    assert EM.derive_state(doc, pkgs)["package_outline"]["status"] == "template"
    st = EM.derive_state_for_page(doc, pkgs, page)
    assert st["package_outline"]["status"] == "not_checked"
    assert st["package_outline"]["evidence"]["reason"] == "pin_count_unconfirmed"


def test_flags_from_page_is_empty_for_plain_chip_page(pkgs):
    """普通芯片页不带任何主体标记 —— 退回默认派生，行为与改造前一致。"""
    page = S.render_page(soic_doc(), pkg_dir=pkgs)
    assert EM.flags_from_page(page) == {"board_subject": False, "pins_unconfirmed": False}
    assert EM.derive_state_for_page(soic_doc(), pkgs, page) == EM.derive_state(soic_doc(), pkgs)


# ─────────────────────────────────────────────────────────────────────
# 8. BGA 占位图：每张卡只说自己那句，断言只在边界小节说一次
# ─────────────────────────────────────────────────────────────────────

def _bga_placeholder_svgs() -> tuple[str, str]:
    pins = [(i, f"PIN{i}") for i in range(1, 145)]
    return (S.footprint_svg(pins, "FCBGA (144)", 144),
            S.model3d_svg(pins, "FCBGA (144)"))


def test_bga_two_cards_no_longer_share_one_picture():
    """旧版两卡是**同一张图、同一句话**，而 3D 卡上那句的主语还是「封装几何」。

    后果有两个：① 读者在一个标着 3D 的格子里读到封装结论；② 一条断言印了三遍
    （两张卡 + 下方边界小节），任何一处改口径就会不同步。
    """
    fp, m3 = _bga_placeholder_svgs()
    assert fp != m3
    assert "封装占位图" in fp and "封装占位图" not in m3
    assert "3D 占位图" in m3 and "3D 占位图" not in fp


def test_bga_placeholder_repeats_no_boundary_claim(pkgs):
    """卡内不印边界断言：不写「未核验」，也不逐字复述 `render_notes` 的任何一句。

    这条守的是 A5 的设计前提 —— 边界文案**只有一个**来源（`EM.render_notes`）。
    卡内文字由渲染器写，所以它只能描述「这一格是什么」，不能下结论。
    """
    fp, m3 = _bga_placeholder_svgs()
    for svg in (fp, m3):
        for word in ("未核验", "未验证", "待核", "无可信来源", "不生成猜测"):
            assert word not in svg, f"占位图仍在断言：{word}"
        assert "data-em-geometry" not in svg            # A2 的结构标记
        assert not EM._NUM_UNIT_RE.search(svg)          # A1 的「数值 + 单位」  # noqa: SLF001
    for note in EM.render_notes(EM.derive_state(bga_doc(), pkgs)):
        for svg in (fp, m3):
            assert note not in svg


def test_bga_placeholder_points_to_the_single_source(pkgs):
    """占位图把理由**指向**边界小节，同一句断言整页只出现一次。"""
    doc = bga_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    assert page.count("工程模型边界") >= 3          # 两张卡各指一次 + 小节标题
    assert page.count("封装轮廓未绘制") == 1        # 只在边界小节里出现
    assert page.count("3D 模型与球阵几何未生成") == 1
    assert EM.check(doc, page, EM.derive_state(doc, pkgs)) == []


# ─────────────────────────────────────────────────────────────────────
# 8. BGA 占位图：每张卡只说自己那句，断言只在边界小节说一次
# ─────────────────────────────────────────────────────────────────────

def _bga_placeholder_svgs() -> tuple[str, str]:
    pins = [(i, f"PIN{i}") for i in range(1, 145)]
    return (S.footprint_svg(pins, "FCBGA (144)", 144),
            S.model3d_svg(pins, "FCBGA (144)"))


def test_bga_two_cards_no_longer_share_one_picture():
    """旧版两卡是**同一张图、同一句话**，而 3D 卡上那句的主语还是「封装几何」。

    后果有两个：① 读者在一个标着 3D 的格子里读到封装结论；② 一条断言印了三遍
    （两张卡 + 下方边界小节），任何一处改口径就会不同步。
    """
    fp, m3 = _bga_placeholder_svgs()
    assert fp != m3
    assert "封装占位图" in fp and "封装占位图" not in m3
    assert "3D 占位图" in m3 and "3D 占位图" not in fp


def test_bga_placeholder_repeats_no_boundary_claim(pkgs):
    """卡内不印边界断言：不写「未核验」，也不逐字复述 `render_notes` 的任何一句。

    这条守的是 A5 的设计前提 —— 边界文案**只有一个**来源（`EM.render_notes`）。
    卡内文字由渲染器写，所以它只能描述「这一格是什么」，不能下结论。
    """
    fp, m3 = _bga_placeholder_svgs()
    for svg in (fp, m3):
        for word in ("未核验", "未验证", "待核", "无可信来源", "不生成猜测"):
            assert word not in svg, f"占位图仍在断言：{word}"
        assert "data-em-geometry" not in svg            # A2 的结构标记
        assert not EM._NUM_UNIT_RE.search(svg)          # A1 的「数值 + 单位」  # noqa: SLF001
    for note in EM.render_notes(EM.derive_state(bga_doc(), pkgs)):
        for svg in (fp, m3):
            assert note not in svg


def test_bga_placeholder_points_to_the_single_source(pkgs):
    """占位图把理由**指向**边界小节，同一句断言整页只出现一次。"""
    doc = bga_doc()
    page = S.render_page(doc, pkg_dir=pkgs)
    assert page.count("工程模型边界") >= 3          # 两张卡各指一次 + 小节标题
    assert page.count("封装轮廓未绘制") == 1        # 只在边界小节里出现
    assert page.count("3D 模型与球阵几何未生成") == 1
    assert EM.check(doc, page, EM.derive_state(doc, pkgs)) == []
