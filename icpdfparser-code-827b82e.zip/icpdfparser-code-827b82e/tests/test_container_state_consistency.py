# -*- coding: utf-8 -*-
"""红先测试：自检 `_container_state()` 必须与权威 AC 容器判据逐件一致。

背景（2026-11-05 batch100 出包事故）
------------------------------------
`delivery_bundle.container_state()` 用权威判据
`qc/ac_quarantine.formal_container_integrity(doc)` 写清单，把
`AFE7950` 里 64 行「无独立溯源的疑似逃逸 AC 行」判成 `fail`。
而 `qc/bundle_selfcheck._container_state()` 自己另写了一套宽松判据，
只认 `quarantine_reason` / `quarantined_from` / `escaped_from` 三个隔离标记，
于是同一份包内 JSON 被重算成 `pass`，打包器在最后一道自证链断言拒绝出包。

实证：91 件清单与权威判据 0 不一致，仅 `AFE7950` 一件分叉；
带上事实表坐标证据后仍有 60 行逃逸，`fail` 是真风险，不是假阳性。
因此正确修法是**收敛自检判据**，绝不允许把台账 `fail` 改成 `pass` 洗白。

这组用例锁死两件事：
1. 自检判据对四类 JSON 的结论必须与权威判据完全相同（含逃逸行这类无标记脏行）；
2. `ac_data_state` 的隔离桶判定必须一致。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest                                              # noqa: E402
from qc import ac_quarantine as AQ                         # noqa: E402
from qc import bundle_selfcheck as SC                      # noqa: E402

SAFE = "TESTBOARD"


def _board_doc(*, electrical=None, isolated=None):
    """板卡形态 JSON：`scope=board` 让权威判据扫主表与板载桶。

    板载桶刻意留空：两个容器放同一批行会让 `escaped_rows` 被重复计数，
    测试里的计数就不再是「一份行」的口径（数字口径审查要求）。
    """
    return {
        "basic_info": {"mpn": SAFE, "identity": "evaluation_board"},
        "specs": {
            "scope": "board",
            "electrical": electrical or [],
            "onboard_device_specs": {"electrical": []},
            "unresolved_ac_rows": isolated or [],
        },
    }


def _write(out: Path, doc: dict) -> None:
    p = out / "part-0001-of-0001" / SAFE / f"{SAFE}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")


def _authority(doc: dict) -> dict:
    """权威口径，与 delivery_bundle.container_state() 的 recomputed 分支一致。"""
    specs = doc.get("specs") or {}
    isolated = specs.get(AQ.ISOLATION)
    return {
        "integrity": AQ.formal_container_integrity(doc),
        "state": ("withheld" if isinstance(isolated, list) and isolated
                  else "not_withheld"),
    }


CLEAN_ROW = {"name": "Supply current", "value": "12", "unit": "mA",
             "condition": "VCC=5V"}
# AC 类、无 bbox / row_sha256 —— 权威判据认定的「疑似逃逸」行，
# 但**不带**任何隔离标记，正是旧自检漏判的形态。
ESCAPED_ROW = {"name": "Signal-to-Noise Ratio (SNR)", "value": "91.5",
               "unit": "dB", "condition": "At fIN = 10 kHz"}
MARKED_ROW = {"name": "THD", "value": "-94", "unit": "dB",
              "quarantine_reason": "copied from AC container"}


@pytest.mark.parametrize("case,doc", [
    ("clean", _board_doc(electrical=[CLEAN_ROW])),
    ("escaped_no_mark", _board_doc(electrical=[CLEAN_ROW, ESCAPED_ROW])),
    ("quarantine_mark", _board_doc(electrical=[MARKED_ROW])),
    ("withheld", _board_doc(isolated=[ESCAPED_ROW])),
])
def test_selfcheck_container_state_matches_authority(tmp_path: Path, case, doc):
    """自检与权威判据必须同结论；旧实现在 escaped_no_mark 上判 pass 而权威判 fail。"""
    _write(tmp_path, doc)
    got = SC._container_state(tmp_path, SAFE)
    want = _authority(doc)
    assert got["integrity"] == want["integrity"], (
        f"{case}: 自检 {got['integrity']!r} ≠ 权威 {want['integrity']!r}")
    assert got["state"] == want["state"], (
        f"{case}: 自检 state {got['state']!r} ≠ 权威 {want['state']!r}")


def test_escaped_row_is_real_risk_not_false_positive():
    """红先护栏：确认测试样例本身确实被权威判据判成 fail（不是空测试）。"""
    assert AQ.formal_container_integrity(
        _board_doc(electrical=[CLEAN_ROW, ESCAPED_ROW])) == "fail"
    assert AQ.formal_container_integrity(_board_doc(electrical=[CLEAN_ROW])) == "pass"


# ── SSOT 三条红先 + 签核护栏（2026-11-05 裁决 + 架构师审查）──────────
# 纪律：清单生成器与权威校验器必须调用**同一个底层函数**，且必须把事实表
# 证据（evidence）传进去。三条 SSOT 覆盖「无证据 / 部分平反 / 全平反」，
# 加一条签核护栏，共 4 条新增，使总账本从 67 变成 71。
#
# 红因审查：每条都必须红在**语义二元组**（旧实现值 vs 权威值），不许红在
# KeyError / 缺键这类接口形状。`_ssot_diff()` 把旧实现缺失的维度按「它没发现
# 任何问题」折算成语义默认值，因此差集里只会出现具体数值/结论，不会出现
# `<未上报>`。修复后同一个差集必须是空集 `{}`。
#
# 第 2/3 条防假绿：全平反时旧实现与权威**同判 pass**，只比 status 必假绿。
# 统一按「三件全等」比对：status + escaped_count + reasons/容器来源/证据来源。
# 证据 fixture 严格对齐 1102-V3 口径：bbox + row_sha256，或
# bbox + paragraph_sha256；部分平反与全平反各一条独立用例。
#
# 裁决模板里的 `formal_container_integrity(...)["status"]`、
# `load_evidence(doc)`、`_container_state(doc)` 与本仓实测签名不符，按真实
# 接口落地（模板是假设，实测是证据）：
#   AQ.formal_container_integrity(doc, evidence=None) -> "pass" | "fail"（字符串）
#   FSS.load_evidence(csv_path) -> {mpn: {(label, cond): {verdict,bbox,...}}}
#   SC._container_state(out, safe) -> 六项机器侧状态
AC_SNR = {"name": "Signal-to-Noise Ratio (SNR)", "value": "91.5",
          "unit": "dB", "condition": "At fIN = 10 kHz"}
AC_THD = {"name": "Total Harmonic Distortion (THD)", "value": "-94",
          "unit": "dB", "condition": "fIN = 10 kHz"}
FACTS_HEAD = "mpn,label,cond,verdict,bbox,row_sha256,paragraph_sha256\n"


def _ev_line(row: dict, *, by: str) -> str:
    """1102-V3 坐标级证据行：bbox + 行指纹，或 bbox + 段落指纹。"""
    sha, para = ("abc", "") if by == "row" else ("", "def")
    return (f'{SAFE},"{row["name"]}","{row["condition"]}",'
            f'verified_row,"[1,2,3,4]",{sha},{para}\n')


def _write_facts(out: Path, lines=()) -> None:
    """包内事实表：`FSS.load_evidence()` 只认坐标级证据。"""
    shard = out / "part-0001-of-0001"
    shard.mkdir(parents=True, exist_ok=True)
    (shard / "facts_audit.csv").write_text(
        FACTS_HEAD + "".join(lines), encoding="utf-8")


def _evidence(out: Path) -> dict:
    from qc import fact_status_sync as FSS                       # noqa: PLC0415
    ev = FSS.load_evidence(out / "part-0001-of-0001" / "facts_audit.csv")
    return ev.get(SAFE) or {}


def _authority_state(doc: dict, ev: dict) -> dict:
    """权威输出。判据本体只在 `qc/ac_quarantine.py`，测试侧不重写任何一条。"""
    f = AQ.container_findings(doc, ev)
    return {
        "integrity": AQ.formal_container_integrity(doc, evidence=ev),
        "state": AQ.ac_data_state(doc),
        "escaped_rows": len(f["escaped"]),
        "reasons": tuple(f["reasons"]),
        "sources": tuple(f["sources"]),
        "evidence_source": "facts_audit.csv" if ev else "none",
    }


#: 旧实现没有后四个维度时，按「它没发现任何问题」折算的**语义默认值**。
#: 绝不写 `<未上报>` —— 那是接口形状，不是语义。
_LEGACY_DEFAULT = {
    "integrity": "pass", "state": "not_withheld", "escaped_rows": 0,
    "reasons": (), "sources": (), "evidence_source": "none",
}


def _ssot_diff(got: dict, want: dict) -> dict:
    """语义二元组差集 `{字段: (旧实现值, 权威值)}`；修复后必须为空集。"""
    return {k: (got.get(k, _LEGACY_DEFAULT[k]), want[k])
            for k in want if got.get(k, _LEGACY_DEFAULT[k]) != want[k]}


def test_ssot_no_evidence_escape(tmp_path: Path):
    """红先 1：2 行 AC 逃逸、零证据 —— 权威 fail / 2 条理由。"""
    doc = _board_doc(electrical=[CLEAN_ROW, AC_SNR, AC_THD])
    _write(tmp_path, doc)
    _write_facts(tmp_path)
    want = _authority_state(doc, _evidence(tmp_path))
    assert want["integrity"] == "fail"
    assert want["escaped_rows"] == 2
    got = SC._container_state(tmp_path, SAFE)
    assert not _ssot_diff(got, want), _ssot_diff(got, want)


def test_ssot_partial_restoration(tmp_path: Path):
    """红先 2「部分平反」：1 行拿到 bbox+paragraph_sha256，另 1 行仍逃逸。

    权威仍 fail、计数从 2 降到 1、理由/来源各剩一条 —— 三件必须同时对齐。
    AFE7950 的实证正是这种形态：4937 条全库证据只平反 4 行、仍余 60 行。
    """
    doc = _board_doc(electrical=[CLEAN_ROW, AC_SNR, AC_THD])
    _write(tmp_path, doc)
    _write_facts(tmp_path, [_ev_line(AC_SNR, by="paragraph")])
    want = _authority_state(doc, _evidence(tmp_path))
    assert want["integrity"] == "fail"
    assert want["escaped_rows"] == 1
    got = SC._container_state(tmp_path, SAFE)
    assert not _ssot_diff(got, want), _ssot_diff(got, want)


def test_ssot_full_restoration(tmp_path: Path):
    """红先 3「全平反」：bbox+row_sha256 让唯一 AC 行平反，两边同为 pass。

    只比 status 必假绿 —— 旧实现在这里也判 pass。靠第三件（证据来源标记）
    才能把它抓出来。同时跑无标记 / 带标记两种 fixture，后者是 1102-V3
    THD/SNR 的真实形态：标记还在、证据已平反。
    """
    for marked in (False, True):
        out = tmp_path / f"m{int(marked)}"
        row = dict(AC_SNR)
        if marked:
            row["quarantine_reason"] = "AC 类参数出现在电气正式容器"
        doc = _board_doc(electrical=[CLEAN_ROW, row])
        _write(out, doc)
        _write_facts(out, [_ev_line(AC_SNR, by="row")])
        want = _authority_state(doc, _evidence(out))
        assert want["integrity"] == "pass"
        assert want["escaped_rows"] == 0
        assert want["evidence_source"] == "facts_audit.csv"
        got = SC._container_state(out, SAFE)
        assert not _ssot_diff(got, want), (marked, _ssot_diff(got, want))


def test_signoff_does_not_whitewash_container_divergence(tmp_path: Path):
    """签核是独立的人工维度，不得洗白机器侧的 AC 容器分叉。

    正向：注入 `CONTENT_APPROVED` 之后，容器仍判 fail、清单谎报 pass 时
    `container_state_match` 仍为 False（gate 仍 BLOCKED），且 SSOT 差集仍须
    消除。反向：签核前后 machine 侧六项字段逐键全等，不许因签核改一个比特。
    """
    plain_out, signed_out = tmp_path / "plain", tmp_path / "signed"
    doc = _board_doc(electrical=[CLEAN_ROW, AC_SNR])
    _write(plain_out, doc)
    _write_facts(plain_out)
    plain_got = SC._container_state(plain_out, SAFE)
    plain_want = _authority_state(doc, _evidence(plain_out))

    signed = json.loads(json.dumps(doc))
    signed["metadata"] = {"content_signoff": "APPROVED (with warnings)",
                          "signoff_by": "reviewer"}
    _write(signed_out, signed)
    _write_facts(signed_out)
    signed_got = SC._container_state(signed_out, SAFE)
    signed_want = _authority_state(signed, _evidence(signed_out))

    # 反向：签核不改变机器侧任何字段
    assert signed_got == plain_got
    assert signed_want == plain_want
    # 正向：容器分叉仍被识别，且 SSOT 仍须一致（旧实现在这里会红）
    assert signed_want["integrity"] == "fail"
    assert not _ssot_diff(signed_got, signed_want), \
        _ssot_diff(signed_got, signed_want)
    # gate 仍 BLOCKED：清单若谎报 pass，交叉核对必须判不一致
    from delivery_bundle import container_state as bundle_cs     # noqa: PLC0415
    signed["metadata"]["formal_container_integrity"] = "pass"
    signed["metadata"]["ac_data_state"] = "not_withheld"
    assert bundle_cs(signed, {})["container_state_match"] is False
