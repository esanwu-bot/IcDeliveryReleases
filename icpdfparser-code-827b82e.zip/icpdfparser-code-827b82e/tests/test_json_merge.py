"""json_merge 合并器的边界用例。

覆盖需求里点名的五种情况：空值、旧字段缺失、新字段缺失、语言集合不同、
结构不兼容。外加「白名单外字段必须保留」这条最容易回归的规则。

本地跑：python -m unittest tests.test_json_merge -v
容器跑：python -m pytest tests/test_json_merge.py -q
"""
from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.json_merge import merge_doc, merge_multi_language      # noqa: E402


def _actions(rows, field=None):
    if field is None:
        return [r["action"] for r in rows]
    return [r["action"] for r in rows if r["field"] == field]


def _base_old():
    return {
        "basic_info": {"mpn": "OLD-MPN", "manufacturer": "TI",
                       "category": "", "subcategory": "",
                       "description": "旧描述", "datasheet_url": ""},
        "specs": {"electrical": [{"name": "icc", "value": "1", "unit": "mA",
                                  "condition": "vcc=3.3v"}],
                  "absolute_max": [], "package": {}, "temperature": {}},
        "features": ["旧特性"],
        "applications": [],
        "pin_configuration": [{"pin": "1", "name": "A", "description": "旧",
                               "device_scope": "board"}],
        "ordering_info": [{"mpn": "OLD-MPN", "package": "SOIC", "marking": "",
                           "moq": "", "packaging": ""}],
        "alternatives": [],
        "seo": {"title_en": "旧", "title_zh": "", "meta_description_en": "",
                "meta_description_zh": "", "keywords": []},
        "metadata": {"pdf_hash": "oldhash", "parse_timestamp": "2026-01-01",
                     "model_version": "qwen-flash", "confidence": 0.9,
                     "requested_mpn": "OLD-MPN"},
        "multi_language": {
            "ja": {"title": "旧日文", "description": "旧", "meta": "旧"},
            "ko": {"title": "旧韩文", "description": "旧", "meta": "旧"},
        },
    }


class MultiLanguageTest(unittest.TestCase):
    """multi_language 的五种边界。"""

    def test_new_missing_keeps_old(self):
        """新解析没生成 -> 保留旧值。原因必须是「未生成」而不是「为空」。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new.pop("multi_language")
        merged, rows, blocked = merge_doc(old, new, "T1")
        self.assertEqual(blocked, [])
        self.assertEqual(merged["multi_language"], old["multi_language"])
        self.assertIn("kept_legacy", _actions(rows, "multi_language"))
        note = [r["note"] for r in rows if r["field"] == "multi_language"][0]
        self.assertIn("ICPDF_LANGS", note)

    def test_old_missing_takes_new(self):
        """旧没有、新有 -> 采用新值，不报阻断。"""
        old = _base_old()
        old.pop("multi_language")
        new = copy.deepcopy(_base_old())
        merged, rows, blocked = merge_doc(old, new, "T2")
        self.assertEqual(blocked, [])
        self.assertIn("multi_language", merged)
        self.assertIn("added", _actions(rows, "multi_language"))

    def test_both_missing_todo(self):
        """两边都没有 -> 不凭空补造，标记待补充。"""
        old = _base_old()
        old.pop("multi_language")
        new = copy.deepcopy(old)
        merged, rows, blocked = merge_doc(old, new, "T3")
        self.assertNotIn("multi_language", merged)
        self.assertIn("todo_missing", _actions(rows, "multi_language"))

    def test_new_has_more_langs(self):
        """新语言更多 -> 旧语言保留旧值，新增语言用新值。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"]["ja"] = {"title": "新日文", "description": "新", "meta": "新"}
        new["multi_language"]["de"] = {"title": "新德文", "description": "新", "meta": "新"}
        merged, rows, blocked = merge_doc(old, new, "T4")
        self.assertEqual(blocked, [])
        self.assertEqual(merged["multi_language"]["ja"]["title"], "旧日文")
        self.assertEqual(merged["multi_language"]["de"]["title"], "新德文")
        self.assertIn("lang_added", _actions(rows))

    def test_new_has_fewer_langs(self):
        """新语言更少 -> 旧语言一个都不能少。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"] = {"ja": {"title": "新日文", "description": "新", "meta": "新"}}
        merged, rows, blocked = merge_doc(old, new, "T5")
        self.assertEqual(set(merged["multi_language"].keys()), {"ja", "ko"})
        self.assertEqual(merged["multi_language"]["ko"]["title"], "旧韩文")

    def test_content_diff_keeps_old(self):
        """内容不同 -> 保留旧值，并把差异键写进 note 供审计。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"]["ja"]["title"] = "新日文"
        merged, rows, blocked = merge_doc(old, new, "T6")
        self.assertEqual(merged["multi_language"]["ja"]["title"], "旧日文")
        note = [r["note"] for r in rows if r["field"] == "multi_language.ja"][0]
        self.assertIn("title", note)

    def test_type_incompatible_blocks(self):
        """dict vs list -> 阻断，不静默取舍。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"] = ["ja"]
        merged, rows, blocked = merge_doc(old, new, "T7")
        self.assertTrue(blocked)
        self.assertIn("conflict_blocked", _actions(rows, "multi_language"))
        self.assertEqual(merged["multi_language"], old["multi_language"])

    def test_lang_body_not_dict_blocks(self):
        """语言体不是 dict -> 阻断。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"]["ja"] = "字符串"
        merged, rows, blocked = merge_doc(old, new, "T8")
        self.assertTrue(blocked)
        self.assertIn("conflict_blocked", _actions(rows, "multi_language.ja"))

    def test_empty_dict_treated_as_missing(self):
        """空 dict 视同缺失，不能当成「确认为空」。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["multi_language"] = {}
        merged, rows, blocked = merge_doc(old, new, "T9")
        self.assertEqual(merged["multi_language"], old["multi_language"])
        self.assertIn("kept_legacy", _actions(rows, "multi_language"))


class WhitelistTest(unittest.TestCase):
    """字段白名单：白名单内更新，白名单外保留。"""

    def test_whitelist_field_updated(self):
        old = _base_old()
        new = copy.deepcopy(old)
        new["basic_info"]["description"] = "新描述"
        merged, rows, blocked = merge_doc(old, new, "W1")
        self.assertEqual(merged["basic_info"]["description"], "新描述")

    def test_legacy_top_field_kept(self):
        """白名单外的顶层历史字段必须留下。"""
        old = _base_old()
        old["人工备注"] = {"by": "qa", "note": "人工维护"}
        new = copy.deepcopy(old)
        new.pop("人工备注")
        merged, rows, blocked = merge_doc(old, new, "W2")
        self.assertEqual(merged["人工备注"]["note"], "人工维护")
        self.assertIn("kept_legacy", _actions(rows, "人工备注"))

    def test_new_field_outside_whitelist_skipped(self):
        """新解析带来的白名单外字段不写入。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["实验字段"] = {"x": 1}
        merged, rows, blocked = merge_doc(old, new, "W3")
        self.assertNotIn("实验字段", merged)
        self.assertIn("new_field_skipped", _actions(rows, "实验字段"))

    def test_sub_field_outside_whitelist_skipped(self):
        """白名单父子字段里的非白名单子键不写入。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["basic_info"]["identity"] = "BOARD_CONFIRMED"
        merged, rows, blocked = merge_doc(old, new, "W4")
        self.assertNotIn("identity", merged["basic_info"])
        self.assertIn("new_field_skipped", _actions(rows, "basic_info.identity"))

    def test_pin_extra_key_kept(self):
        """pin_configuration 按 pin 对齐，device_scope 这类历史键要留下。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["pin_configuration"] = [{"pin": "1", "name": "A", "description": "新"}]
        merged, rows, blocked = merge_doc(old, new, "W5")
        self.assertEqual(merged["pin_configuration"][0]["description"], "新")
        self.assertEqual(merged["pin_configuration"][0]["device_scope"], "board")

    def test_orphan_item_kept(self):
        """旧有而新无的列表项保留，不因为新解析少抽就丢。"""
        old = _base_old()
        old["pin_configuration"].append({"pin": "2", "name": "B",
                                         "description": "旧2"})
        new = copy.deepcopy(old)
        new["pin_configuration"] = [{"pin": "1", "name": "A", "description": "新"}]
        merged, rows, blocked = merge_doc(old, new, "W6")
        pins = {p["pin"] for p in merged["pin_configuration"]}
        self.assertEqual(pins, {"1", "2"})
        self.assertIn("orphan_kept", _actions(rows, "pin_configuration"))

    def test_empty_old_doc(self):
        """旧文档为空：不崩，全部按新值走。"""
        merged, rows, blocked = merge_doc({}, _base_old(), "W7")
        self.assertIn("basic_info", merged)
        self.assertIn("multi_language", merged)

    def test_empty_new_doc(self):
        """新文档为空：不该把旧文档清空。"""
        old = _base_old()
        merged, rows, blocked = merge_doc(old, {}, "W8")
        self.assertEqual(merged["basic_info"]["description"], "旧描述")
        self.assertEqual(merged["multi_language"]["ja"]["title"], "旧日文")

    def test_metadata_updated(self):
        """metadata 属白名单，应更新为新解析的哈希与时间戳。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["metadata"]["pdf_hash"] = "newhash"
        merged, rows, blocked = merge_doc(old, new, "W9")
        self.assertEqual(merged["metadata"]["pdf_hash"], "newhash")

    def test_no_silent_override_on_structure_conflict(self):
        """顶层字段 dict vs list -> 阻断而不是任选一个。"""
        old = _base_old()
        new = copy.deepcopy(old)
        new["basic_info"] = ["not a dict"]
        merged, rows, blocked = merge_doc(old, new, "W10")
        self.assertTrue(blocked)
        self.assertEqual(merged["basic_info"]["description"], "旧描述")


if __name__ == "__main__":
    unittest.main(verbosity=2)
