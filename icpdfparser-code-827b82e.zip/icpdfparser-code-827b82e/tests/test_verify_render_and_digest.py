# -*- coding: utf-8 -*-
"""核验状态必须渲染到页面 + 核心字段指纹必须可复现。

守两道闸：

1. **Reviewer V3 新-1**：`verification.status != audited` 的行，页面必须能看见。
   V3 交付件 17 条电气行全是未核验态，页面实测这些字样出现 0 次 —— 读者拿到的
   是一张「看起来都对」的规格表。这组用例把「页面可见」写成断言。
2. **用户 2026-10-31 拍板**：「不可复现比算错更致命」。凡代码抽出来的核心字段，
   两次运行必须逐字节一致，且产物自带 `metadata.core_sha256` 供客户复跑比对。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import json_to_txt as J                                   # noqa: E402
from qc import deterministic_extract as DE                # noqa: E402
from qc import determinism_check as DC                    # noqa: E402


def _doc(elec=None, amax=None) -> dict:
    """最小可渲染的器件页。

    `specs.scope` / `basic_info.identity` 不能省：`canonical_view()` 会把
    scope 判不出来的行整批搬进 `unresolved_specs`，页面就成了空壳
    （第一次写这组用例时正是这样，断言失败但原因跟核验标记无关）。
    """
    return {
        "basic_info": {"mpn": "ADC12DJ5200SE", "category": "Data Converter",
                       "subcategory": "Analog to Digital Converter",
                       "identity": "chip"},
        "specs": {"scope": "device", "electrical": elec or [], "absolute_max": amax or []},
        "pin_configuration": [],
    }


# ─────────────────────────────────────────────────────────────────────
# 1. † 的判据：谁该打、谁绝不能打
# ─────────────────────────────────────────────────────────────────────

def test_unverified_statuses_are_marked():
    for st in ("condition_unverified", "unresolved", "not_checked",
               "column_roles_not_verified", "row_ambiguous"):
        assert J._is_unverified({"verification": {"status": st}}), st


def test_audited_rows_are_never_marked():
    """确定性抽出来的 VCMI 必须**不**打标，否则代码抽的干净数据被自己的标记反咬。"""
    for st in ("audited", "audited_manual", "audited_deterministic",
               "verified", "pass"):
        assert not J._is_unverified({"verification": {"status": st}}), st


def test_row_without_verification_is_not_marked():
    """没表态 ≠ 说没核过。管线没写状态的行不臆断。"""
    assert not J._is_unverified({})
    assert not J._is_unverified({"verification": None})
    assert not J._is_unverified({"verification": {"status": ""}})


def test_future_status_name_is_auto_marked():
    """兜底：将来新增的未核验状态只要名字带 unverified/unresolved 就自动可见，
    不必回来改渲染层。"""
    assert J._is_unverified({"verification": {"status": "condition_unverified_v2"}})
    assert J._is_unverified({"verification": {"status": "row_unresolved"}})


def test_mark_is_plain_text():
    """`table()` 只对以标签开头的整格放行 HTML；角标拼在值后面，
    塞 `<span>` 会被转义成字面量（双层实体事故）。"""
    assert J._verify_mark({"verification": {"status": "unresolved"}}) == " †"
    assert J._verify_mark({"verification": {"status": "audited"}}) == ""


# ─────────────────────────────────────────────────────────────────────
# 2. 渲染：提示条 + 角标真的出现在页面里
# ─────────────────────────────────────────────────────────────────────

def test_page_shows_note_and_dagger():
    doc = _doc(elec=[
        {"name": "Resolution", "value": "12", "unit": "Bits"},
        {"name": "Input Common-Mode Voltage (CLK±)", "value": "0 to 0.55", "unit": "V",
         "verification": {"status": "condition_unverified"}},
    ])
    html = J.render(doc, "en")
    assert "pd-verify-note" in html
    assert "1 of 2 entries below are marked unverified" in html
    assert "†" in html


def test_page_has_no_note_when_all_audited():
    doc = _doc(elec=[
        {"name": "Resolution", "value": "12", "unit": "Bits",
         "verification": {"status": "audited"}},
    ])
    html = J.render(doc, "en")
    assert "pd-verify-note" not in html
    assert "†" not in html


def test_note_is_localized():
    """非英文页面不能出现整句英文 —— review 的 `i18n_english_residue` 会抓。"""
    doc = _doc(elec=[{"name": "Resolution", "value": "12", "unit": "Bits",
                      "verification": {"status": "unresolved"}}])
    for lang in ("ja", "ko", "de", "es"):
        html = J.render(doc, lang)
        assert "marked unverified (†)" not in html, lang
        assert "pd-verify-note" in html, lang


# ─────────────────────────────────────────────────────────────────────
# 2b. en 页 <h1> 必须用 seo.json 标题（Reviewer V3 新-5）
# ─────────────────────────────────────────────────────────────────────

def test_en_h1_uses_seo_title():
    """交付说明声称「片段 <h1> 已使用 seo.json 对应语种标题」，实测只对
    ja/ko/de/es 成立 —— en 页写的是 `{mpn} {subcategory}`。声明与事实不符，
    要么改文案要么改渲染，这里选后者。"""
    doc = _doc()
    doc["seo"] = {"title_en": "ADC12DJ5200SE 10.4GSPS 12-bit RF-Sampling ADC by TI"}
    html = J.render(doc, "en")
    assert "<h1 class=\"pd-hero-title\">" in html
    assert "10.4GSPS 12-bit RF-Sampling ADC by TI" in html


def test_en_h1_falls_back_without_seo():
    """老 JSON 没有 seo 节点时不能渲染成空 h1。"""
    doc = _doc()
    html = J.render(doc, "en")
    assert "ADC12DJ5200SE" in html.split("pd-hero-title")[1][:200]


# ─────────────────────────────────────────────────────────────────────
# 2c. 热阻 / ESD 必须真的出现在页面上（Reviewer V3 P1-8）
# ─────────────────────────────────────────────────────────────────────

def test_thermal_and_esd_render_on_page():
    """V3 的失败是「JSON 里没有」；修好 JSON 之后还有第二半 —— 渲染层从来
    没输出过 `specs.thermal` / `specs.esd`，页面实测 `23.9` / `±2000` 出现 0 次。
    JSON 有了页面看不见，和没有一样。"""
    doc = _doc(elec=[{"name": "Resolution", "value": "12", "unit": "Bits"}])
    doc["specs"]["thermal"] = [
        {"name": "RθJA", "value": "23.9", "unit": "°C/W"},
        {"name": "RθJC(top)", "value": "0.8", "unit": "°C/W"},
        {"name": "ψJT", "value": "0.23", "unit": "°C/W"},
    ]
    doc["specs"]["esd"] = [
        {"name": "HBM", "value": "±2000", "unit": "V"},
        {"name": "CDM", "value": "±500", "unit": "V"},
    ]
    html = J.render(doc, "en")
    for token in ("23.9", "0.8", "0.23", "±2000", "±500",
                  "Thermal resistance", "ESD ratings"):
        assert token in html, token


def test_thermal_esd_titles_are_localized():
    doc = _doc(elec=[{"name": "Resolution", "value": "12", "unit": "Bits"}])
    doc["specs"]["thermal"] = [{"name": "RθJA", "value": "23.9", "unit": "°C/W"}]
    doc["specs"]["esd"] = [{"name": "HBM", "value": "±2000", "unit": "V"}]
    for lang, title in (("ja", "熱抵抗"), ("ko", "열 저항"),
                        ("de", "Wärmewiderstand"), ("es", "Resistencia térmica")):
        html = J.render(doc, lang)
        assert title in html, lang


# ─────────────────────────────────────────────────────────────────────
# 3. 核心指纹：同一份 JSON 算两次必须一样，且只覆盖代码抽的字段
# ─────────────────────────────────────────────────────────────────────

def _core_doc(value="0 to 0.55", pins=None) -> dict:
    return {
        "pin_configuration": pins if pins is not None else [
            {"pin": "A1", "name": "AGND", "description": "Ground"},
            {"pin": "A2", "name": "AGND", "description": "Ground"},
        ],
        "specs": {
            "thermal": [{"name": "RθJA", "value": "23.9", "unit": "°C/W"}],
            "esd": [{"name": "HBM", "value": "±2000", "unit": "V"}],
            "electrical": [
                {"name": "Input Common-Mode Voltage (CLK±)", "value": value, "unit": "V"},
                {"name": "Power Consumption", "value": "4.01", "unit": "W"},
            ],
        },
    }


def test_core_digest_is_stable_across_calls():
    d = _core_doc()
    assert DE.core_digest(d) == DE.core_digest(d)


def test_core_digest_ignores_non_core_electrical_rows():
    """模型抽的行（Power Consumption）漂了不影响指纹 —— 否则指纹永远对不上，
    失去「可自证一致」的意义。"""
    a = _core_doc()
    b = _core_doc()
    b["specs"]["electrical"][1]["value"] = "4"
    assert DE.core_digest(a)["vcmi_vid"] == DE.core_digest(b)["vcmi_vid"]
    assert DE.core_digest(a)["pins"] == DE.core_digest(b)["pins"]


def test_core_digest_catches_core_drift():
    a = _core_doc()
    b = _core_doc(value="0.3 to 0.55")
    assert DE.core_digest(a)["vcmi_vid"] != DE.core_digest(b)["vcmi_vid"]

    c = _core_doc(pins=[{"pin": "1", "name": "AGND", "description": "Ground"}])
    assert DE.core_digest(a)["pins"] != DE.core_digest(c)["pins"]


# ─────────────────────────────────────────────────────────────────────
# 4. 闸门：compare() 的判决口径
# ─────────────────────────────────────────────────────────────────────

def test_compare_green_when_core_same():
    rep = DC.compare(_core_doc(), _core_doc())
    assert rep["ok"] is True
    assert rep["elec"]["identical"] is True


def test_compare_red_when_core_differs():
    rep = DC.compare(_core_doc(), _core_doc(value="0.3 to 0.55"))
    assert rep["ok"] is False
    assert rep["core"]["vcmi_vid"]["same"] is False


def test_compare_reports_label_drift_without_failing():
    """行名措辞变了（`(Single Channel)` ↔ `- Single Channel Mode`）只算漂移，
    不判红 —— 那部分是模型抽的，判红等于要求模型绝对稳定。"""
    a = _core_doc()
    b = _core_doc()
    b["specs"]["electrical"][1]["name"] = "Power Consumption (Typ)"
    rep = DC.compare(a, b)
    assert rep["ok"] is True
    assert rep["elec"]["identical"] is False
