"""review（单型号交付物红线审查）离线单测：合成产物 + 临时 SQLite + mock LLM。"""
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import review as RV            # noqa: E402

ITEM_DDL = """
CREATE TABLE IF NOT EXISTS item (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id       INTEGER,
    mpn            TEXT NOT NULL,
    mpn_key        TEXT NOT NULL UNIQUE,
    brand          TEXT NOT NULL DEFAULT '',
    status         TEXT NOT NULL DEFAULT 'pending',
    stage          TEXT NOT NULL DEFAULT '',
    pdf_path       TEXT NOT NULL DEFAULT '',
    pdf_sha256     TEXT NOT NULL DEFAULT '',
    pdf_bytes      INTEGER NOT NULL DEFAULT 0,
    json_path      TEXT NOT NULL DEFAULT '',
    txt_path       TEXT NOT NULL DEFAULT '',
    alt_json_path  TEXT NOT NULL DEFAULT '',
    seo_path       TEXT NOT NULL DEFAULT '',
    last_parsed_at TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS qc_run (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mode TEXT NOT NULL DEFAULT '', scope TEXT NOT NULL DEFAULT '',
    dry INTEGER NOT NULL DEFAULT 1, parts INTEGER NOT NULL DEFAULT 0,
    parts_done INTEGER NOT NULL DEFAULT 0, findings INTEGER NOT NULL DEFAULT 0,
    patched INTEGER NOT NULL DEFAULT 0, unresolved INTEGER NOT NULL DEFAULT 0,
    duration_s REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'running',
    operator TEXT NOT NULL DEFAULT 'auto', report_path TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qc_audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL, mpn TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT '', path TEXT NOT NULL DEFAULT '',
    json_val TEXT NOT NULL DEFAULT '', table_val TEXT NOT NULL DEFAULT '',
    action TEXT NOT NULL DEFAULT '', tool TEXT NOT NULL DEFAULT '',
    operator TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS llm_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER, mpn_key TEXT NOT NULL DEFAULT '',
    stage TEXT NOT NULL DEFAULT 'parse', provider TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT '', prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0, total_tokens INTEGER NOT NULL DEFAULT 0,
    latency_ms INTEGER NOT NULL DEFAULT 0, attempt INTEGER NOT NULL DEFAULT 1,
    ok INTEGER NOT NULL DEFAULT 1, error TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
"""

CFG = {"key": "test-key", "base": "https://dashscope.example.com/compatible-mode/v1",
       "model": "qwen-flash", "max_tokens": 6000, "enable_thinking": False}


class FakeDB:
    def __init__(self, path: Path):
        self.c = sqlite3.connect(str(path))
        self.c.row_factory = sqlite3.Row
        self.c.executescript(ITEM_DDL)
        self.c.commit()

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None

    def x(self, sql, args=()):
        cur = self.c.execute(sql, args)
        self.c.commit()
        return cur.lastrowid if cur.lastrowid else cur.rowcount


def _board_json() -> dict:
    """EVK 型号、身份未判板、MPN 被改写、转义残留、单位重复、多语英文残留。"""
    return {
        "basic_info": {
            "mpn": "DS80PCI402",                       # 被改写成板载器件
            "manufacturer": "Texas Instruments",
            "description": "The DS80PCI402 is a dual-channel repeater V &amp;gt; 0.5 V",
        },
        "specs": {
            "package": {"type": "54-Pin WQFN", "pins": 54},
            "electrical": [
                {"name": "VOD", "value": "10 mA", "unit": "mA",
                 "condition": "VCC = 3.3 V"},           # value 已带单位
                {"name": "ICC", "value": "120", "unit": ""},   # 缺 unit
            ],
        },
        "pin_configuration": [{"pin": 1, "name": "VDD", "description": "Supply"}],
        "features": ["Low power", "Redriver"],
        "multi_language": {
            "ja": {"title": "DS80PCI402", "description":
                   "This is a fully English description that was never translated."},
            "de": {"title": "DS80PCI402", "description":
                   "This description was never translated and is still in English "
                   "with all the stopwords of the English language."},
        },
        "metadata": {"confidence": 0.95, "requested_mpn": "DS80PCI402EVK/NOPB",
                     "model_version": "qwen-flash"},
    }


def _clean_json() -> dict:
    return {
        "basic_info": {"mpn": "LM358", "manufacturer": "Texas Instruments",
                       "description": "Industry standard dual operational amplifier."},
        "specs": {
            "package": {"type": "8-SOIC", "pins": 8},
            "electrical": [
                {"name": "VOH", "value": "VCC – 0.1", "unit": "V",
                 "condition": "IOH = –100 µA, VCC = 1.65 V to 5.5 V"},
            ],
        },
        "pin_configuration": [{"pin": 1, "name": "OUT1", "description": "Output"}],
        "features": ["Low power", "Single supply"],
        "multi_language": {
            "ja": {"title": "LM358", "description":
                   "LM358 は、業界標準の二重オペアンプです。単一電源で動作します。"},
            "de": {"title": "LM358", "description":
                   "Der LM358 ist ein industrieüblicher Doppel-Operationsverstärker, "
                   "der mit einer einzelnen Versorgungsspannung arbeitet."},
            "es": {"title": "LM358", "description":
                   "El LM358 es un amplificador operacional dual estándar de la "
                   "industria que funciona con una sola fuente de alimentación."},
        },
        "metadata": {"confidence": 0.9, "model_version": "qwen-flash"},
    }


HERO_INTRO_DUP = """<!DOCTYPE html><html><body>
<h1 class="pd-hero-title">DS80PCI402 Dual Channel Repeater</h1>
<section id="product-introduction"><p>DS80PCI402 Dual Channel Repeater.</p></section>
</body></html>"""

HERO_INTRO_DIFF = """<!DOCTYPE html><html><body>
<h1 class="pd-hero-title">LM358 Operational Amplifiers</h1>
<section id="product-introduction"><p>The LM358 series consists of two independent,
high gain, internally frequency compensated operational amplifiers which were designed
specifically to operate from a single power supply.</p></section>
</body></html>"""


class ReviewTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.base = Path(self.tmp.name)
        self.data = self.base / "data"
        self.out = self.base / "reviews"
        for sub in ("parsed", "txt", "alts", "seo", "pdfs"):
            (self.data / sub).mkdir(parents=True)
        self.db = FakeDB(self.base / "wb.sqlite3")

    def _add_item(self, mpn: str, jdict: dict, txt: str) -> None:
        safe = RV._safe_stem(mpn)
        jp = self.data / "parsed" / f"{safe}_ab12cd34.json"
        tp = self.data / "txt" / f"{safe}.txt"
        ap = self.data / "alts" / f"{safe}.json"
        sp = self.data / "seo" / f"{safe}.json"
        jp.write_text(json.dumps(jdict, ensure_ascii=False), encoding="utf-8")
        tp.write_text(txt, encoding="utf-8")
        ap.write_text(json.dumps({"mpn": mpn, "alternatives": []}), encoding="utf-8")
        sp.write_text(json.dumps({"mpn": mpn, "images": []}), encoding="utf-8")
        self.db.x("INSERT INTO item(mpn,mpn_key,batch_id,status,json_path,txt_path,"
                   "alt_json_path,seo_path,pdf_sha256,pdf_bytes,last_parsed_at) "
                   "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   (mpn, mpn.replace("/", ""), 7, "done", str(jp), str(tp),
                    str(ap), str(sp), "a" * 64, 12345, "2026-10-28 10:00:00"))

    def _run(self, mpn, **kw):
        kw.setdefault("cfg", CFG)
        return RV.run_review(self.db, mpn, data_dir=self.data, out_dir=self.out, **kw)

    # ---------------------------------------------------------------- 规则层

    def test_rule_layer_and_dry_run(self):
        self._add_item("DS80PCI402EVK/NOPB", _board_json(), HERO_INTRO_DUP)
        res = self._run("DS80PCI402EVK/NOPB", dry_run=True)
        kinds = {f["kind"] for f in res["rule_findings"]}
        self.assertIn("identity_review", kinds)   # 板卡后缀命中但缺原厂证据 → 待核验
        self.assertIn("mpn_rewritten", kinds)               # basic_info.mpn 被改写
        self.assertIn("escape_entity_in_json", kinds)       # JSON 里 V &amp;gt; 0
        self.assertIn("electrical_field_missing", kinds)    # 缺 unit
        self.assertIn("unit_duplicated", kinds)             # 10 mA + mA
        self.assertIn("i18n_english_residue", kinds)        # ja 仍为英文
        self.assertIn("hero_overview_duplicate", kinds)     # hero/intro 重复
        self.assertEqual(res["verdict"], "FAIL")
        self.assertEqual(res["model"], "rule-only")
        self.assertEqual(res["llm_findings"], [])
        # dry_run 不落报告
        self.assertFalse((self.out / "DS80PCI402EVK_NOPB.review.json").exists())

    def test_board_package_mismatch(self):
        j = _board_json()
        j["basic_info"]["identity"] = "evaluation_board"
        j["specs"]["package"] = {"type": "8-SOIC", "pins": 8}
        self._add_item("BOOST-XYZ-EVM", j, HERO_INTRO_DIFF)
        res = self._run("BOOST-XYZ-EVM", dry_run=True)
        kinds = {f["kind"] for f in res["rule_findings"]}
        self.assertIn("board_package_mismatch", kinds)
        self.assertNotIn("identity_review", kinds)

    def test_clean_item_pass_with_llm(self):
        self._add_item("LM358", _clean_json(), HERO_INTRO_DIFF)
        llm_out = {"content": json.dumps(
            {"verdict": "PASS", "findings": [], "notes": "looks fine"}),
            "usage": {"total_tokens": 900, "prompt_tokens": 600,
                      "completion_tokens": 300}}
        with mock.patch.object(RV, "_chat", return_value=llm_out) as ch:
            res = self._run("LM358")
            ch.assert_called_once()
        self.assertEqual(res["rule_findings"], [])
        self.assertEqual(res["llm_findings"], [])
        self.assertEqual(res["verdict"], "PASS")
        self.assertEqual(res["model"], "qwen-flash")

    # ---------------------------------------------------------------- 持久化 / 报告

    def test_full_review_persist_md_html_and_cache(self):
        self._add_item("DS80PCI402EVK/NOPB", _board_json(), HERO_INTRO_DUP)
        llm_out = {"content": json.dumps({
            "verdict": "WARN",
            "findings": [{"kind": "features_boilerplate", "severity": "P1",
                          "message": "features 只有标题无实质信息",
                          "evidence": {"field": "features", "quote": "Low power",
                                       "page_hint": 3}}],
            "notes": "ok"}),
            "usage": {"total_tokens": 1234}}
        with mock.patch.object(RV, "_chat", return_value=llm_out):
            res = self._run("DS80PCI402EVK/NOPB", write_db=False)
        self.assertEqual(res["verdict"], "FAIL")
        # page_hint 被强制抹掉（LLM 没看 PDF 不能给页码）
        self.assertIsNone(res["llm_findings"][0]["evidence"]["page_hint"])
        files = RV.report_paths(self.out, "DS80PCI402EVK_NOPB")
        for p in files.values():
            self.assertTrue(p.is_file(), p)
        md = files["md"].read_text(encoding="utf-8")
        self.assertIn("交付物 review — FAIL", md)
        self.assertIn("identity_review", md)
        self.assertIn("features_boilerplate", md)
        html = files["html"].read_text(encoding="utf-8")
        self.assertIn("<!DOCTYPE html>", html)
        self.assertIn("identity_review", html)
        self.assertIn("边界声明", html)
        # 缓存：不 force 直接返回
        again = self._run("DS80PCI402EVK/NOPB")
        self.assertTrue(again.get("cached"))
        self.assertEqual(again["verdict"], "FAIL")
        # force 重算
        with mock.patch.object(RV, "_chat", return_value=llm_out):
            forced = self._run("DS80PCI402EVK/NOPB", force=True)
        self.assertFalse(forced.get("cached"))
        # 报告列表
        items = RV.list_reports(self.out)
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["mpn"], "DS80PCI402EVK/NOPB")
        self.assertEqual(items[0]["verdict"], "FAIL")
        got = RV.get_report(self.out, "DS80PCI402EVK_NOPB")
        self.assertEqual(got["mpn"], "DS80PCI402EVK/NOPB")
        self.assertFalse(RV.get_report(self.out, "../etc/passwd"))   # 路径穿越拦截

    def test_audit_and_usage_ledger(self):
        self._add_item("LM358", _clean_json(), HERO_INTRO_DIFF)
        llm_out = {"content": json.dumps({"verdict": "PASS", "findings": []}),
                   "usage": {"total_tokens": 800, "prompt_tokens": 500,
                             "completion_tokens": 300}}
        with mock.patch.object(RV, "_chat", return_value=llm_out):
            self._run("LM358", write_db=True, operator="user:admin")
        run = self.db.q1("SELECT * FROM qc_run WHERE mode='review'")
        self.assertIsNotNone(run)
        self.assertEqual(run["operator"], "user:admin")
        audit = self.db.q1("SELECT * FROM qc_audit_log WHERE kind='llm_review'")
        self.assertIsNotNone(audit)
        self.assertEqual(audit["mpn"], "LM358")
        self.assertEqual(audit["tool"], "review.py")
        usage = self.db.q1("SELECT * FROM llm_usage WHERE stage='review'")
        self.assertIsNotNone(usage)
        self.assertEqual(usage["total_tokens"], 800)

    def test_missing_artifacts(self):
        self.db.x("INSERT INTO item(mpn,mpn_key,status) VALUES('NODATA','NODATA','nodata')")
        with self.assertRaises(RV.ReviewError) as ctx:
            self._run("NODATA")
        self.assertEqual(ctx.exception.code, "ARTIFACTS_MISSING")
        with self.assertRaises(RV.ReviewError) as ctx2:
            self._run("NOT-EXIST")
        self.assertEqual(ctx2.exception.code, "ITEM_NOT_FOUND")

    def test_llm_key_missing(self):
        self._add_item("LM358", _clean_json(), HERO_INTRO_DIFF)
        with self.assertRaises(RV.ReviewError) as ctx:
            RV.run_review(self.db, "LM358", data_dir=self.data, out_dir=self.out,
                          cfg={"key": "", "base": "x", "model": "m",
                               "max_tokens": 10, "enable_thinking": False})
        self.assertEqual(ctx.exception.code, "LLM_KEY_MISSING")

    def test_parse_json_lenient(self):
        fenced = "```json\n{\"verdict\": \"WARN\", \"findings\": []}\n```"
        self.assertEqual(RV._parse_json_lenient(fenced)["verdict"], "WARN")
        noisy = '前置解释 {"verdict": "PASS", "findings": []} 后置解释'
        self.assertEqual(RV._parse_json_lenient(noisy)["verdict"], "PASS")
        bad = RV._parse_json_lenient("not json at all")
        self.assertTrue(bad.get("_parse_failed"))
        self.assertEqual(bad["verdict"], "WARN")

    # ------------------------------------------------------- 转义判据（防假阳性）

    def test_single_entity_in_html_is_not_residue(self):
        """HTML 里单层 &lt; / &amp; 是正确转义（浏览器显示 < / &），不是残留。

        回归用例：NE555 的 `TRIG &lt; 1/2 CONT` 曾被判成 mixed_escape，
        导致所有含比较符的页面全量 WARN，进而污染自动修复队列。
        """
        html_txt = ('<p>TRIG &lt; 1/2 CONT sets output; V &gt; 0.7 V; '
                    'T&amp;R packaging</p>')
        self.assertEqual(RV._find_double_escape({}, html_txt), [])

    def test_double_entity_in_html_is_residue(self):
        """渲染层出现 &amp;amp; / &amp;gt; 才是真残留。"""
        out = RV._find_double_escape({}, "<p>V &amp;gt; 0.5 V and T&amp;amp;R</p>")
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["kind"], "double_escape_multi")
        self.assertIn("&amp;gt;", out[0]["evidence"]["quote"])

    def test_json_entity_wins_over_html_symptom(self):
        """JSON 文本层有实体就只报根因，不重复报渲染层症状。"""
        j = {"basic_info": {"description": "V &amp;gt; 0.5 V"}}
        out = RV._find_double_escape(j, "<p>V &amp;amp;gt; 0.5 V</p>")
        self.assertEqual([f["kind"] for f in out], ["escape_entity_in_json"])
        self.assertEqual(out[0]["evidence"]["fields"], ["basic_info.description"])

    def test_entity_scan_covers_lists_and_nested(self):
        j = {"specs": {"electrical": [{"condition": "T&amp;R only"}]}}
        out = RV._find_double_escape(j, "")
        self.assertEqual(out[0]["evidence"]["fields"], ["specs.electrical[0].condition"])

    def test_bare_ampersand_is_not_entity(self):
        """裸 & （如 T&R）是合法纯文本，不该命中。"""
        j = {"basic_info": {"description": "T&R packaging, R&D samples"}}
        self.assertEqual(RV._find_double_escape(j, "<p>T&amp;R</p>"), [])


if __name__ == "__main__":
    unittest.main()
