"""多语言质量中心 LQA 引擎不变量测试（内存 SQLite，不调模型、不碰生产库）。

锁住的是「规则判定的口径」和「硬门禁不可绕过」两件事：
  * 规则误报会把人工审校淹没，所以规格短句、纯汉字名词短语必须放行；
  * 有 FAIL 的候选不能被批准，未批准的候选不能进 approved 记忆库。
"""
import sqlite3
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import i18n_qa as Q       # noqa: E402


class FakeDB:
    """只实现 i18n_qa 实际用到的接口，避免连工作台库。"""

    def __init__(self):
        self.c = sqlite3.connect(":memory:")
        self.c.row_factory = sqlite3.Row
        self.c.executescript(Q.DDL)
        self.c.commit()
        self.kv = {}

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, tuple(args)).fetchall()]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, tuple(args)).fetchone()
        return dict(r) if r else None

    def x(self, sql, args=()):
        cur = self.c.execute(sql, tuple(args))
        self.c.commit()
        return cur.lastrowid if cur.lastrowid else cur.rowcount

    def xmany(self, sql, rows):
        cur = self.c.executemany(sql, rows)
        self.c.commit()
        return cur.rowcount

    def now(self):
        return "2026-10-29 12:00:00"

    def kv_get(self, k, default=""):
        return self.kv.get(k, default)

    def kv_set(self, k, v):
        self.kv[k] = v


def make_doc(mpn="SN74AHCT1G08DCKTG4", *, title_en="3-state single gate buffer",
             meta_en="Low power single gate buffer with 3-state output for consumer systems",
             desc_en="The device is a single gate buffer with 3-state output.",
             features=("3-state output",), applications=("Consumer electronics",),
             ml=None):
    return {
        "seo": {"title_en": title_en, "meta_description_en": meta_en},
        "basic_info": {"mpn": mpn, "description": desc_en},
        "features": list(features),
        "applications": list(applications),
        "multi_language": ml or {},
    }


def translations(**over):
    """4 语默认全对，over 用 "lang.field" 覆盖。"""
    base = {
        "ja": {"title": "3状態出力シングルゲートバッファ",
               "meta": "民生機器向けの3状態出力付き低消費電力シングルゲートバッファ",
               "description": "本デバイスは3状態出力を備えたシングルゲートバッファです。",
               "features": ["3状態出力"], "applications": ["民生用電子機器"]},
        "ko": {"title": "3상태 출력 단일 게이트 버퍼",
               "meta": "소비자 가전용 3상태 출력 저전력 단일 게이트 버퍼",
               "description": "이 장치는 3상태 출력을 갖춘 단일 게이트 버퍼입니다.",
               "features": ["3상태 출력"], "applications": ["소비자 가전"]},
        "de": {"title": "Single-Gate-Puffer mit 3-State-Ausgang",
               "meta": "Stromsparender Single-Gate-Puffer mit 3-State-Ausgang für Consumer-Systeme",
               "description": "Das Bauteil ist ein Single-Gate-Puffer mit 3-State-Ausgang.",
               "features": ["3-State-Ausgang"], "applications": ["Unterhaltungselektronik"]},
        "es": {"title": "Búfer de puerta única con salida de 3 estados",
               "meta": "Búfer de puerta única de bajo consumo con salida de 3 estados",
               "description": "El dispositivo es un búfer de puerta única con salida de 3 estados.",
               "features": ["Salida de 3 estados"], "applications": ["Electrónica de consumo"]},
    }
    for k, v in over.items():
        lang, field = k.split(".")
        base[lang][field] = v
    return base


class Base(unittest.TestCase):
    def setUp(self):
        self.db = FakeDB()
        self._orig = Q.db
        Q.db = self.db
        Q.ensure_seed("test")

    def tearDown(self):
        Q.db = self._orig

    def run_doc(self, doc, rev="v1", base_doc=None):
        c = Q.import_candidate("t", rev, "X.json", doc, mpn=doc["basic_info"]["mpn"],
                               base_doc=base_doc, operator="test")
        return c, Q.run_lqa(c["id"], "test")

    def finds(self, res, severity=None):
        return [f for f in Q.lqa_findings(run_id=res["run_id"])
                if severity is None or f["severity"] == severity]


class TestRuleCalibration(Base):
    def test_clean_translation_passes(self):
        _, res = self.run_doc(make_doc(ml=translations()))
        self.assertEqual(res["verdict"], "PASS", self.finds(res))

    def test_ja_spec_bullet_without_kana_is_not_a_leak(self):
        ml = translations(**{"ja.features": ["5V時最大tpd 6ns"]})
        doc = make_doc(features=("5V max tpd 6ns",), ml=ml)
        _, res = self.run_doc(doc)
        self.assertEqual([f for f in self.finds(res) if f["rule"] == "R-LANG"], [])

    def test_ja_kanji_only_noun_phrase_is_not_a_leak(self):
        ml = translations(**{"ja.applications": ["電子決済端末"]})
        doc = make_doc(applications=("Electronic Points of Sale",), ml=ml)
        _, res = self.run_doc(doc)
        self.assertEqual([f for f in self.finds(res) if f["rule"] == "R-LANG"], [])

    def test_ja_chinese_description_is_a_leak(self):
        ml = translations(**{"ja.description": "该器件是具有三态输出的单门缓冲器，适用于消费电子系统。"})
        _, res = self.run_doc(make_doc(ml=ml))
        rules = {f["rule"] for f in self.finds(res, "FAIL")}
        self.assertIn("R-LANG", rules)

    def test_de_cjk_is_a_leak(self):
        ml = translations(**{"de.meta": "Stromsparender Puffer 三态 Ausgang für Systeme"})
        _, res = self.run_doc(make_doc(ml=ml))
        self.assertIn("R-LANG", {f["rule"] for f in self.finds(res, "FAIL")})

    def test_truncated_mpn_fails(self):
        doc = make_doc(meta_en="The SN74AHCT1G08DCKTG4 is a low power gate buffer.",
                       ml=translations(**{"es.meta": "El SN74AHCT1G0 es un búfer de puerta única."}))
        _, res = self.run_doc(doc)
        fails = [f for f in self.finds(res, "FAIL") if f["rule"] == "R-ID"]
        self.assertTrue(fails)
        self.assertTrue(any("只保留前" in f["detail"] for f in fails), fails)

    def test_full_ordering_code_accepted(self):
        doc = make_doc(mpn="74AHCT1G08DCKTG4",
                       meta_en="The SN74AHCT1G08DCKTG4 is a single gate buffer.")
        ml = translations(**{"de.meta": "Der SN74AHCT1G08DCKTG4 ist ein Single-Gate-Puffer."})
        ml["ja"]["meta"] = "SN74AHCT1G08DCKTG4は単一ゲートバッファです。"
        ml["ko"]["meta"] = "SN74AHCT1G08DCKTG4는 단일 게이트 버퍼입니다."
        ml["es"]["meta"] = "El SN74AHCT1G08DCKTG4 es un búfer de puerta única."
        _, res = self.run_doc(dict(doc, multi_language=ml))
        self.assertEqual([f for f in self.finds(res) if f["rule"] == "R-ID"], [])

    def test_big_number_missing_fails_small_number_warns(self):
        ml = translations(**{
            "de.meta": "Versorgungsspannung 2 V, Durchlaufverzögerung 6 ns.",
            "de.description": "Betrieb ab 2 V."})
        doc = make_doc(meta_en="Supply voltage from 2V to 5.5V with 6ns propagation delay.",
                       desc_en="Operates from 2V to 5.5V.", ml=ml)
        _, res = self.run_doc(doc)
        num = [f for f in self.finds(res) if f["rule"] == "R-NUM"]
        self.assertTrue(any(f["severity"] == "FAIL" for f in num), num)   # 5.5V 缺失
        self.assertTrue(any(f["severity"] == "WARN" for f in num), num)   # 2V 小数字

    def test_decimal_comma_is_equal(self):
        doc = make_doc(meta_en="Operates from 4.5V to 5.5V.", desc_en="Operates from 4.5V to 5.5V.")
        ml = translations(**{"de.meta": "Betrieb von 4,5 V bis 5,5 V.",
                             "de.description": "Betrieb von 4,5 V bis 5,5 V.",
                             "es.meta": "Funciona de 4,5 V a 5,5 V.",
                             "es.description": "Funciona de 4,5 V a 5,5 V.",
                             "ja.meta": "4.5V～5.5Vで動作します。",
                             "ja.description": "4.5V～5.5Vで動作します。",
                             "ko.meta": "4.5V~5.5V에서 동작합니다.",
                             "ko.description": "4.5V~5.5V에서 동작합니다."})
        _, res = self.run_doc(make_doc(meta_en="Operates from 4.5V to 5.5V.",
                                       desc_en="Operates from 4.5V to 5.5V.", ml=ml))
        self.assertEqual([f for f in self.finds(res) if f["rule"] == "R-NUM"], [])

    def test_banned_variant_fails_and_suppresses_preferred_warning(self):
        doc = make_doc(meta_en="Battery charger for nickel-metal hydride cells.",
                       desc_en="Supports nickel-metal hydride batteries.")
        ml = translations(**{
            "de.meta": "Ladegerät für Nickelmanganhydrid-Zellen.",
            "de.description": "Unterstützt Nickelmanganhydrid-Akkus."})
        _, res = self.run_doc(doc)
        term = [f for f in self.finds(res) if f["rule"] == "R-TERM"]
        self.assertTrue(all(f["severity"] == "FAIL" for f in term), term)
        self.assertFalse(any("未使用批准译法" in f["detail"] for f in term), term)

    def test_missing_preferred_term_is_warn_not_fail(self):
        doc = make_doc(features=("Rail-to-rail output",), applications=("Consumer electronics",))
        ml = translations(**{"de.features": ["Rail-to-Rail-Ausgang"]})
        _, res = self.run_doc(doc)
        term = [f for f in self.finds(res) if f["rule"] == "R-TERM"]
        # 「Rail-to-Rail」是批准的 de 变体之一 → 不报警
        self.assertEqual(term, [])

    def test_list_count_mismatch_fails(self):
        ml = translations(**{"de.features": []})
        _, res = self.run_doc(make_doc(features=("3-state output", "Low power"), ml=ml))
        details = [f["detail"] for f in self.finds(res, "FAIL") if f["rule"] == "R-LIST"]
        self.assertTrue(any("条数不一致" in d for d in details), details)

    def test_duplicate_list_item_warns(self):
        ml = translations(**{"de.features": ["3-State-Ausgang", "3-State-Ausgang"]})
        doc = make_doc(features=("3-state output", "Low power"), ml=ml)
        _, res = self.run_doc(doc)
        dup = [f for f in self.finds(res) if f["rule"] == "R-LIST" and f["severity"] == "WARN"]
        self.assertTrue(any("重复" in f["detail"] for f in dup), dup)

    def test_echo_title_warns_meta_fails(self):
        en_title = "SN74AHCT1G08DCKTG4 MCU 120MHz 256KB Flash"
        en_meta = "A long English sentence that was copied verbatim into the target language field."
        ml = translations(**{"de.title": en_title, "de.meta": en_meta})
        _, res = self.run_doc(make_doc(title_en=en_title, meta_en=en_meta, ml=ml))
        echo = [f for f in self.finds(res) if f["rule"] == "R-ECHO"]
        sev = {(f["field"], f["severity"]) for f in echo}
        self.assertIn(("title", "WARN"), sev)
        self.assertIn(("meta", "FAIL"), sev)

    def test_empty_translation_fails(self):
        ml = translations(**{"ko.description": ""})
        _, res = self.run_doc(make_doc(ml=ml))
        self.assertTrue(any(f["rule"] == "R-LIST" and "漏译" in f["detail"]
                            for f in self.finds(res, "FAIL")))


class TestGateAndMemory(Base):
    def test_approval_blocked_while_fail(self):
        ml = translations(**{"de.meta": "Ladegerät für Nickelmanganhydrid-Zellen."})
        doc = make_doc(meta_en="Charger for nickel-metal hydride cells.", ml=ml)
        c, res = self.run_doc(doc)
        self.assertEqual(res["verdict"], "FAIL")
        with self.assertRaises(ValueError):
            Q.decide_candidate(c["id"], True, "tester")

    def test_approval_allowed_when_clean_and_tm_approved(self):
        c, res = self.run_doc(make_doc(ml=translations()))
        self.assertEqual(res["verdict"], "PASS")
        # 未批准时进候选区
        out = Q.tm_from_candidate(c["id"], "ja", "tester")
        self.assertFalse(out["approved"])
        self.assertEqual(Q.tm_list(status="approved"), [])
        Q.decide_candidate(c["id"], True, "tester", "人工复核通过")
        out = Q.tm_from_candidate(c["id"], "ja", "tester")
        self.assertTrue(out["approved"])
        self.assertTrue(Q.tm_list(status="approved"))

    def test_rejected_candidate_cannot_promote_approved(self):
        c, _ = self.run_doc(make_doc(ml=translations()))
        Q.decide_candidate(c["id"], False, "tester", "术语不对")
        Q.tm_from_candidate(c["id"], "de", "tester")
        self.assertEqual(Q.tm_list(status="approved"), [])

    def test_revision_keeps_changed_flag(self):
        Q.import_candidate("t", "v1", "X.json", make_doc(ml=translations()), mpn="M")
        v2 = translations(**{"ja.features": ["3状態出力（改）"]})
        c2 = Q.import_candidate("t", "v2", "X.json", make_doc(ml=v2), mpn="M")
        rows = {r["field"] + r["lang"]: r for r in
                Q.candidate_detail(c2["id"])["fields"] if r["lang"] == "ja"}
        self.assertEqual(rows["featuresja"]["changed"], 1)
        self.assertEqual(rows["titleja"]["changed"], 0)

    def test_seed_idempotent_and_glossary_rule_scoped(self):
        self.assertEqual(Q.ensure_seed("test"), {"glossary": 0, "banned": 0})
        # 源文没出现术语时，术语规则不得越权命中
        g = Q.db.q1("SELECT * FROM i18n_glossary WHERE term_en='nickel-metal hydride'")
        self.assertIsNotNone(g)
        _, res = self.run_doc(make_doc(ml=translations()))
        hits = [f for f in self.finds(res) if f["rule"] == "R-TERM"]
        self.assertEqual(hits, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
