#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""板卡参数归属三态（`qc/board_scope.py`）。

为什么要测：这套分类**决定一行会不会出现在页面上**。第一版把 `board_level`
写进 `row["scope"]`（合同层已占用的键），`normalize_scope()` 不认识这个词 →
归一成 `unresolved` → `canonical_view()` 判定与文档 scope 冲突 →
两行全被搬进 `unresolved_specs`，BOOST-DRV8711 唯一一条真整板参数
（`Voltage Range 8.2 to 52 V`）从页面上消失，且不报错。
"""
from __future__ import annotations

import unittest

from qc import board_scope as BS
from qc import scope_contract as SC


def _board(mpn="BOOST-DRV8711", identity="evaluation_board",
           doc_type="user_guide", device="DRV8711", rows=None,
           container="electrical"):
    return {
        "basic_info": {"mpn": mpn, "identity": identity,
                       "doc_type": doc_type, "device_mpn": device},
        "specs": {"scope": "board",
                  "package": {"onboard_device": device},
                  container: rows or []},
    }


class ClassifyTest(unittest.TestCase):
    def test_device_datasheet_makes_every_row_onboard(self):
        """判据 1：源文件是器件手册 → 表里没有整板参数。"""
        doc = _board(mpn="ADS8568EVM-PDK", doc_type="datasheet",
                     device="ADS8568",
                     rows=[{"name": "Voltage Range", "condition": "External power"}])
        BS.apply_board_scope(doc)
        self.assertEqual(doc["specs"]["electrical"][0]["attribution"],
                         "onboard_device")

    def test_board_interface_row_is_board_level(self):
        doc = _board(rows=[{"name": "Voltage Range",
                            "condition": "External power supply input"}])
        BS.apply_board_scope(doc)
        self.assertEqual(doc["specs"]["electrical"][0]["attribution"],
                         "board_level")

    def test_onchip_block_is_onboard_device(self):
        """`Continuous Current per H-Bridge` 是 DRV8711 的片内 H 桥，不是整板。"""
        doc = _board(rows=[{"name": "Continuous Current per H-Bridge",
                            "condition": "Max continuous"}])
        BS.apply_board_scope(doc)
        self.assertEqual(doc["specs"]["electrical"][0]["attribution"],
                         "onboard_device")

    def test_board_word_wins_over_device_word(self):
        """`Power Input Voltage` 里也有 voltage —— 板级判据必须先过。"""
        self.assertEqual(
            BS.classify_row({"name": "Power Input Voltage Minimum"}, False),
            "board_level")

    def test_unknown_row_stays_unresolved(self):
        doc = _board(rows=[{"name": "Signal-to-Noise Ratio"}])
        BS.apply_board_scope(doc)
        self.assertEqual(doc["specs"]["electrical"][0]["attribution"],
                         "unresolved")


class ContractInteractionTest(unittest.TestCase):
    """归属必须**不撞**合同层的 `scope` 键。"""

    def test_attribution_does_not_archive_board_rows(self):
        """整板参数不能被搬出主表。

        这是第一版的真实故障：`attribution` 写成 `scope: board_level`
        → `normalize_scope()` 归一成 `unresolved` → 行被归档。
        """
        doc = _board(rows=[{"name": "Voltage Range",
                            "condition": "External power supply input"}])
        BS.apply_board_scope(doc)
        view = SC.canonical_view(doc)
        self.assertEqual(len(view["specs"]["electrical"]), 1)
        self.assertEqual(view["specs"]["electrical"][0]["name"], "Voltage Range")

    def test_scope_key_is_not_written_by_board_scope(self):
        doc = _board(rows=[{"name": "Voltage Range"}])
        BS.apply_board_scope(doc)
        self.assertNotIn("scope", doc["specs"]["electrical"][0])

    def test_attribution_survives_canonical_view(self):
        """合同层搬走行时，`attribution` 要跟着走 —— 渲染层靠它分组。"""
        doc = _board(mpn="ADS8568EVM-PDK", doc_type="datasheet",
                     device="ADS8568",
                     rows=[{"name": "SNR", "symbol": "SNR"}],
                     container="ac_performance")
        BS.apply_board_scope(doc)
        view = SC.canonical_view(doc)
        rows = view["specs"]["ac_performance"]
        self.assertTrue(rows)
        self.assertEqual(rows[0]["attribution"], "onboard_device")


class ScopeTest(unittest.TestCase):
    def test_chip_page_is_untouched(self):
        """芯片页没有「归属」问题，一个键都不加。"""
        doc = {"basic_info": {"mpn": "ADC12DJ5200SE", "identity": "chip"},
               "specs": {"scope": "device",
                         "electrical": [{"name": "SNR"}]}}
        self.assertEqual(BS.apply_board_scope(doc), {})
        self.assertNotIn("attribution", doc["specs"]["electrical"][0])
        self.assertNotIn("board_attribution", doc.get("metadata") or {})

    def test_metadata_lists_three_arrays(self):
        doc = _board(rows=[
            {"name": "Voltage Range", "condition": "External power supply input"},
            {"name": "Continuous Current per H-Bridge"},
            {"name": "Some Metric"},
        ])
        acts = BS.apply_board_scope(doc)
        meta = doc["metadata"]["board_attribution"]
        self.assertEqual(len(meta["board_level"]), 1)
        self.assertEqual(len(meta["onboard_device"]), 1)
        self.assertEqual(len(meta["unresolved"]), 1)
        self.assertEqual(acts["counts"],
                         {"board_level": 1, "onboard_device": 1, "unresolved": 1})


if __name__ == "__main__":
    unittest.main()
