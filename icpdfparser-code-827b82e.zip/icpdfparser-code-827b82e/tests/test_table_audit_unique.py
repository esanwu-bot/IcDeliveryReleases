# -*- coding: utf-8 -*-
"""`table_audit` 候选匹配唯一性闸门（`locate_row/unique-v2`）的回归测试。

本轮范围（与授权一致）：
  * 候选唯一性：恰好一个候选才允许进入后续处理；
  * 多候选 / 多条目抢同一行 → `row_ambiguous_unresolved`，一个字段都不写；
  * 0 候选 → 维持 `table_unresolved`，不改目标行。

**不在本轮范围**：限定词解析（`(OVP)`/`(OCP)`、无表头 Mode 列）、
值覆盖策略、`mode` schema、生产写入。

为什么要专门测「唯一候选 ≠ 语义正确」：实测 9 行坏匹配里**没有一行是并列候选**，
唯一性只能消除「两个条目抢同一行」这一类（9 行里的 2 行）。
把它当成限定词问题的解药会误判风险，故用
`test_unique_match_can_still_be_semantically_wrong` 把这个边界钉死。
"""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TA = pytest.importorskip("qc.table_audit")


# ── 造表：与 scan_tables 产出同形（header 与 rows 分离，rows 已去表头）──
HDR7 = ["Symbol", "Parameter", "Condition", "Min", "Typ", "Max", "Unit"]


def tbl(rows, page=1, ti=0, header=None):
    return {"page": page, "ti": ti, "header": header or HDR7, "rows": rows}


def entry(name, value, unit="V", **kw):
    e = {"name": name, "value": value, "unit": unit}
    e.update(kw)
    return e


def kinds(finds):
    return [f["kind"] for f in finds]


def untouched(e):
    """断言目标行一个字段都没被写（patch_cols 的痕迹一个都不能有）。"""
    return ("value_raw_original" not in e and "columns" not in e
            and "source" not in e and "columns_raw" not in e)


# ── ① 0 个候选 ──
def test_no_candidate_leaves_row_untouched():
    tables = [tbl([["VCC", "Supply voltage", "TA = 25", "4", "5", "6", "V"]])]
    e = entry("Totally Unrelated Parameter", "5")
    finds = TA.audit_electrical([e], tables, "specs.electrical")

    assert kinds(finds) == ["table_unresolved"], kinds(finds)
    assert untouched(e), "无候选时不允许写任何字段"


# ── ② 恰好 1 个候选：维持原有行为 ──
def test_single_candidate_is_matched_and_patched():
    tables = [tbl([["VCC", "Supply voltage", "TA = 25", "4", "5", "6", "V"]])]
    e = entry("Supply voltage", "5")
    finds = TA.audit_electrical([e], tables, "specs.electrical")

    assert "qualifier_loss" in kinds(finds), kinds(finds)
    assert e["value"] == "4 MIN / 5 TYP / 6 MAX"
    assert e["value_raw_original"] == "5"
    assert e["source"] == {"page": 1, "table": 0, "row": 0}


# ── ③ 并列候选：ambiguous，不静默选第一个 ──
def _tie_table():
    # 两行文字完全相同、只有 Condition 与 TYP 不同 → 总分并列。
    # 注意：v2 起 condition / value 会参与**并列裁决**（见 _break_tie），
    # 所以想造「真·无法判定」的并列，测试里的 entry 必须给一个
    # 既不命中 condition、也不落在两行数值格里的 value（用 "120"）。
    return tbl([
        ["BW", "Bandwidth -3dB", "Low quiescent current mode", "", "30", "", "MHz"],
        ["BW", "Bandwidth -3dB", "Wide bandwidth mode", "", "180", "", "MHz"],
    ])


def test_tie_yields_ambiguous_and_writes_nothing():
    tables = [_tie_table()]
    e = entry("Bandwidth -3dB", "120", unit="MHz")   # 120 不在 30/180 里，裁决不了
    finds = TA.audit_electrical([e], tables, "specs.electrical")

    assert kinds(finds) == ["row_ambiguous_unresolved"], kinds(finds)
    f = finds[0]
    assert f["ambiguous_reason"] == "ambiguous_tie"
    assert f["candidate_count"] == 2
    assert f["match_rule"] == TA.MATCH_RULE
    assert [c["row"] for c in f["candidates"]] == [0, 1]
    # 诊断契约：每个候选都要带得出符号/条件/三列/单位
    assert f["candidates"][0]["condition"] == "Low quiescent current mode"
    assert f["candidates"][1]["condition"] == "Wide bandwidth mode"
    assert f["candidates"][1]["typ"] == "180"
    assert f["candidates"][1]["unit"] == "MHz"
    assert untouched(e), "ambiguous 时不允许写任何字段"


def test_ambiguous_kind_is_counted_as_unresolved():
    """`audit_json` 用 `kind.endswith('unresolved')` 分流，名字必须守这个约定。"""
    f = TA.audit_electrical([entry("Bandwidth -3dB", "120", unit="MHz")],
                            [_tie_table()], "specs.electrical")[0]
    assert f["kind"].endswith("unresolved"), "否则会被算成 patched，静默通过"


# ── ④ 候选顺序改变，结论不变 ──
def test_tie_verdict_stable_when_rows_reordered():
    t = _tie_table()
    t["rows"] = list(reversed(t["rows"]))
    e = entry("Bandwidth -3dB", "120", unit="MHz")
    finds = TA.audit_electrical([e], [t], "specs.electrical")

    assert kinds(finds) == ["row_ambiguous_unresolved"]
    conds = {c["condition"] for c in finds[0]["candidates"]}
    assert conds == {"Low quiescent current mode", "Wide bandwidth mode"}
    assert untouched(e)


def test_unique_verdict_stable_when_rows_reordered():
    rows = [["VCC", "Supply voltage", "TA = 25", "4", "5", "6", "V"],
            ["IDD", "Quiescent current", "VIN = 5 V", "", "1", "2", "mA"]]
    outs = []
    for rs in (rows, list(reversed(rows))):
        e = entry("Supply voltage", "5")
        TA.audit_electrical([e], [tbl(rs)], "specs.electrical")
        outs.append((e.get("value"), e.get("source", {}).get("row")))
    assert outs[0][0] == outs[1][0] == "4 MIN / 5 TYP / 6 MAX"
    assert outs[0][1] != outs[1][1], "行号应随顺序变，但结论（值）不变"


# ── ⑤ 多个条目抢同一张表行（ADC3910 历史冲突）──
# 下面两行文字转录自 ADC3910S065IRSMT 的 `page=9, table=0` row[17] / row[21]，
# 保留 PDF 抽出的「无空格粘连」形态（正是它让共同词计分失真）。
ADC_ROWS = [
    ["SFDR", "Spurfreedynamicrangeincluding secondandthirdharmonic", "f IN = 1 .1 MHz", "63"],
    ["SPUR", "Spurfreedynamicrange(excluding DC HD2 HD3) , ,", "f IN = 1 .1 MHz", "83"],
]
ADC_HDR = ["Symbol", "Parameter", "Condition", "Typ"]


def _adc_tables():
    return [tbl([list(r) for r in ADC_ROWS], page=9, ti=0, header=ADC_HDR)]


def test_collision_marks_all_claimants_ambiguous():
    """两个条目都指向同一表行 → 全部 ambiguous，谁都不写。

    只惩罚「后来者」等于把先到先得当成隐式优先级，而先到的那条未必对。
    """
    entries = [entry("Spur Free Dynamic Range", "63", unit="dBFS"),
               entry("Spur Free Dynamic Range (excluding DC, HD2, HD3)", "85", unit="dBFS")]
    finds = TA.audit_electrical(entries, _adc_tables(), "specs.electrical")

    assert kinds(finds) == ["row_ambiguous_unresolved"] * 2, kinds(finds)
    for f in finds:
        assert f["ambiguous_reason"] == "ambiguous_collision"
        assert f["candidate_count"] == 1
        assert f["candidates"][0]["row"] == 1
        assert len(f["claimants"]) == 2, "必须记录是谁在抢，否则无法人工裁决"
    for e in entries:
        assert untouched(e), "冲突时不允许任何一方写入（含「先到」的那条）"


def test_unique_match_is_blocked_by_value_outside_gate():
    """边界：唯一性不等于语义正确，但 A17/D1g 不允许拿隔壁列值顶掉原值。

    只保留 ADC row[5] 一条时，匹配是**唯一**的（无并列、无冲突），
    但 row21 的 TYP 是 83，本条 value 是 63（真正来源是 row17）。
    旧实现会把 63 改写成 `83 TYP`；A17 的「值必须在即将写入的列里」闸门
    会判 cells_ok=False，D1g 也会把它标成 unresolved —— 改错值不再静默放行。
    """
    e = entry("Spur Free Dynamic Range", "63", unit="dBFS")
    finds = TA.audit_electrical([e], _adc_tables(), "specs.electrical")

    assert "row_ambiguous_unresolved" not in kinds(finds)
    assert e.get("source", {}).get("row") == 1, "仍会选中 row21"
    assert e["value"] == "63", "不允许把 63 改写成隔壁行的 83"
    assert any(k.endswith("_unresolved") for k in kinds(finds)), kinds(finds)


# ── ⑥ 兼容入口不改语义 ──
def test_locate_row_returns_first_of_ties():
    t = _tie_table()
    ri, rm = TA.locate_row(t, "", "Bandwidth -3dB")
    assert ri == 0, "兼容入口取并列中的第一个（与原实现等价）"
    assert rm


def test_locate_candidates_returns_all_ties():
    ties, _ = TA.locate_candidates(_tie_table(), "", "Bandwidth -3dB")
    assert ties == [0, 1]


# ── ⑦ 只读：audit_electrical 不改表结构 ──
def test_tables_are_not_mutated():
    t = _tie_table()
    before = json.dumps(t, ensure_ascii=False, sort_keys=True)
    TA.audit_electrical([entry("Bandwidth -3dB", "180", unit="MHz")], [t], "specs.electrical")
    assert json.dumps(t, ensure_ascii=False, sort_keys=True) == before


# ── ⑧ ADAPT D1g：matched 但行内不支持该值 → 必须报，不许静默放行 ──
def test_value_unsupported_is_reported():
    """ADS1201 类静默洞：行内有 4/5/6，JSON 值却是 7。

    旧实现 matched、写 source、报告全绿；D1g 要求它变成 unresolved。
    """
    e = entry("Supply voltage", "7")
    finds = TA.audit_electrical(
        [e], [tbl([["VCC", "Supply voltage", "TA = 25", "4", "5", "6", "V"]])],
        "specs.electrical")
    assert "value_unsupported_unresolved" in kinds(finds), kinds(finds)
    assert e["value"] == "7", "D1g 只报不写，原值保留给人工裁决"
    assert e.get("source", {}).get("row") == 0


# ── ⑨ ADAPT P0：两组 MIN/TYP/MAX 并存 → 不可分就不写 ──
def test_grouped_num_roles_is_blocked():
    """同一表里并排两组 MIN/TYP/MAX 时，role_map 只取第一组 → 必须拦下。"""
    hdr = ["Symbol", "Parameter", "Condition", "Min", "Typ", "Max",
           "Min", "Typ", "Max", "Unit"]
    row = ["VCC", "Supply voltage", "TA = 25", "4", "5", "6", "7", "8", "9", "V"]
    e = entry("Supply voltage", "5")
    finds = TA.audit_electrical([e], [tbl([row], header=hdr)], "specs.electrical")

    assert any(f["kind"] == "cell_unparsable_unresolved"
               and f["table"] == "GROUPED_COLUMNS" for f in finds), finds
    assert untouched(e), "两组列并存时一个字段都不能写"


# ── ⑩ ADAPT P1：BGA 表头 `BALL` 必须识别 ──
def test_bga_ball_header_is_recognized():
    rm = TA.pin_role_map(["BALL", "NAME", "I/O", "DESCRIPTION"])
    assert rm["PIN"] == 0, "旧正则只认 pin/no.，BALL 会被静默跳过"


def test_bga_ball_pins_match_table():
    """球号 A1/B2 必须能落到表行；伪脚号 1..15 在 BGA 表里找不到 → 报 unresolved。"""
    t = {"page": 1, "ti": 0,
         "header": ["BALL", "NAME", "I/O", "DESCRIPTION"],
         "rows": [["A1", "AGND", "—", "Analog supply ground"],
                  ["B2", "CLK+", "I", "Clock positive input"]]}
    doc = {"pin_configuration": [{"pin": "A1", "name": "AGND", "description": ""},
                                 {"pin": "B2", "name": "CLK+", "description": ""}]}
    assert TA.audit_pins(doc, [t]) == []

    bad = {"pin_configuration": [{"pin": 1, "name": "AGND", "description": ""},
                                 {"pin": "Z9", "name": "CLK+", "description": ""}]}
    finds = TA.audit_pins(bad, [t])
    assert "pin_table_unresolved" in kinds(finds), kinds(finds)
