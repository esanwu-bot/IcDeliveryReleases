#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""区间端点的「小数位形态对齐原文」（`qc/postprocess_qwen.py::align_decimal_form`）。

为什么需要这条
--------------
`ADC12DJ5200SE` 第 17 页 `BW-3dB` 两行原文印的是 ``2.0`` 与 ``6.3``，
模型摘出来写成 ``2 - 6.3``，`normalize_ranges` 忠实地拆成 ``min=2, max=6.3``。
**数值没变**，但页面读成 ``2 to 6.3``，与数据手册并排看就是「两个数不同源」——
复核方会按外观判「摘抄不忠实」，而自证链又证明不了它其实是同一个数。

这条只做**形态**对齐：数值必须相等，找不到原文的带小数点写法就保持原样。
所以用例的重点不是「能不能改」，而是**「什么情况下必须不改」** ——
把 `2` 改成 `2.0` 是补形态，改成 `2.5` 就是编造，两者差一个字符。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import postprocess_qwen as P                            # noqa: E402

fitz = pytest.importorskip("pymupdf")


def _pdf(tmp_path: Path, lines: list[tuple[str, float]]) -> Path:
    """造一页 PDF：每行一段文字，y 坐标由调用方给，便于框出 bbox。"""
    doc = fitz.open()
    page = doc.new_page(width=600, height=800)
    for text, y in lines:
        page.insert_text((60, y), text, fontsize=10)
    p = tmp_path / "demo.pdf"
    doc.save(str(p))
    doc.close()
    return p


def _row(rng: dict, page: int = 1, bbox=(50, 90, 560, 130)) -> dict:
    return {"name": "Analog Input Frequency Range", "unit": "GHz",
            "value": f"{rng['min']} to {rng['max']}", "range": dict(rng),
            "verification": {"status": "audited_row_anchored",
                             "page": page, "bbox": list(bbox)}}


def test_integer_endpoint_restores_printed_decimal(tmp_path):
    """原文印 `2.0`，JSON 写 `2` → 补回 `2.0`。数值不变。"""
    pdf = _pdf(tmp_path, [("Low frequency", 100), ("2.0", 112),
                          ("High frequency", 120), ("6.3", 132)])
    row = _row({"min": "2", "max": "6.3"})
    acts = P.align_decimal_form([row], pdf)
    assert row["range"] == {"min": "2.0", "max": "6.3"}
    assert row["value"] == "2.0 to 6.3"
    assert acts and acts[0]["before"] == {"min": "2.0"}


def test_value_never_changes_numerically(tmp_path):
    """形态对齐**不许**改数 —— 改出 `2.5` 就是编造，不是对齐。"""
    pdf = _pdf(tmp_path, [("Low frequency", 100), ("2.0", 112),
                          ("High frequency", 120), ("6.3", 132)])
    row = _row({"min": "2", "max": "6.3"})
    P.align_decimal_form([row], pdf)
    assert float(row["range"]["min"]) == 2.0
    assert float(row["range"]["max"]) == 6.3


def test_no_decimal_in_region_keeps_integer(tmp_path):
    """区域里根本没有 `2.0` → 保持 `2`。那种情况下 `2` 本来就是原文。"""
    pdf = _pdf(tmp_path, [("Low frequency", 100), ("2", 112),
                          ("High frequency", 120), ("6", 132)])
    row = _row({"min": "2", "max": "6"})
    assert P.align_decimal_form([row], pdf) == []
    assert row["range"] == {"min": "2", "max": "6"}


def test_ambiguous_region_is_left_alone(tmp_path):
    """同一块区域里有两个不同写法的同值小数（`2.0` 与 `2.00`）→ 不动。"""
    pdf = _pdf(tmp_path, [("2.0", 100), ("2.00", 112), ("6.3", 124)])
    row = _row({"min": "2", "max": "6.3"})
    assert P.align_decimal_form([row], pdf) == []
    assert row["range"]["min"] == "2"


def test_endpoint_already_decimal_is_untouched(tmp_path):
    pdf = _pdf(tmp_path, [("2.0", 100), ("6.3", 112)])
    row = _row({"min": "2.0", "max": "6.3"})
    assert P.align_decimal_form([row], pdf) == []


def test_row_without_bbox_is_skipped(tmp_path):
    """没有坐标就没有「那一小块区域」—— 全页搜索会把别处的 `2.0` 认过来。"""
    pdf = _pdf(tmp_path, [("2.0", 100), ("6.3", 112)])
    row = _row({"min": "2", "max": "6.3"})
    row["verification"] = {"status": "audited_row_anchored", "page": 1}
    assert P.align_decimal_form([row], pdf) == []
    assert row["range"]["min"] == "2"


def test_no_pdf_is_a_noop(tmp_path):
    row = _row({"min": "2", "max": "6.3"})
    assert P.align_decimal_form([row], None) == []
    assert row["range"]["min"] == "2"


def test_accepts_path_like_process_passes(tmp_path):
    """`process()` 传进来的是**路径**（`resolve_pdf` 的返回值），不是文档对象。

    直接下标会抛 TypeError 并被 except 吞掉 —— 那就变成「永远 0 条」的哑弹。
    这条用例专门锁住这个接口差异。
    """
    pdf = _pdf(tmp_path, [("2.0", 100), ("6.3", 112)])
    row = _row({"min": "2", "max": "6.3"})
    acts = P.align_decimal_form([row], pdf)          # Path，不是 Document
    assert acts and row["range"]["min"] == "2.0"


def test_negative_endpoint(tmp_path):
    """`-3` vs 原文 `-3.0` 同样要对齐（负号不能被当成区间分隔符）。"""
    pdf = _pdf(tmp_path, [("-3.0", 100), ("6.3", 112)])
    row = _row({"min": "-3", "max": "6.3"})
    assert P.align_decimal_form([row], pdf)
    assert row["range"]["min"] == "-3.0"


def test_unverified_candidate_is_aligned_without_formal_range(tmp_path):
    """V11 P0-2：unresolved 行只有候选，不许借「对齐小数位」把正式 range 加回来。"""
    pdf = _pdf(tmp_path, [("2.0", 100), ("6.3", 112)])
    row = {"name": "Analog Input Frequency Range", "unit": "GHz",
           "value": "2 to 6.3",
           "unverified_range_candidate": {"min": "2", "max": "6.3"},
           "range_origin": "column_roles_unverified",
           "verification": {"status": "unresolved", "page": 1,
                            "bbox": [50, 90, 560, 130]}}
    acts = P.align_decimal_form([row], pdf)
    assert acts
    assert "range" not in row, "候选对齐不得生成正式 range"
    assert row["unverified_range_candidate"] == {"min": "2.0", "max": "6.3"}
    assert row["value"] == "2.0 to 6.3"


def test_staging_artifact_is_aligned():
    """真实产物回归：ADC 那一行已经是 `2.0 to 6.3`，别被后续改动改回去。"""
    p = ROOT / "data" / "staging_20261101_v6" / "parsed" / "ADC12DJ5200SE.json"
    if not p.is_file():
        pytest.skip("staging 产物不在本机")
    doc = json.loads(p.read_text(encoding="utf-8"))
    hits = [e for e in (doc.get("specs") or {}).get("electrical") or []
            if "Frequency Range" in str(e.get("name") or "")]
    assert hits, "找不到 Analog Input Frequency Range"
    assert hits[0]["range"]["min"] == "2.0", hits[0]["range"]
