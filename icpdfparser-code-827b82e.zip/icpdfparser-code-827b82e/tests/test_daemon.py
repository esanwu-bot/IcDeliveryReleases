"""`algorithm_lab/daemon.py` 的离线用例。

三件事必须钉死，任何一件错了都比「不通知」更糟：

1. **不能自激**：同一 sha 只叫醒一次；日志写入、编辑器打开文件都会再触发事件。
2. **不能误报**：没有待修工单（`issue=none`）或文件为空时保持安静。
3. **不能越红线**：源码里不允许出现任何远端写操作，连字面量都不许有。

全部不真开窗口、不真弹 Toast、不真等 1.5 秒 —— 动作与计时器都可注入。
"""

from __future__ import annotations

import hashlib
import logging
import subprocess
from pathlib import Path

import pytest

from algorithm_lab import daemon as D


def _log() -> logging.Logger:
    log = logging.getLogger("daemon-test")
    log.addHandler(logging.NullHandler())
    log.propagate = False
    return log


def _task(issue: str = "23", sha: str = "abc123def4567890", body: str = "# 待修任务：#23 LM358 · 10 项缺陷\n") -> str:
    return (f"<!-- next-task: issue={issue} sha={sha} at=2026-11-03T06:12:09Z "
            f"mirror=x.md url=https://example/23 -->\n\n{body}")


@pytest.fixture()
def workspace(tmp_path):
    """仓库形状：<root>/algorithm_lab/next_task.md（Bus 靠上两级找 repo 根）。"""
    (tmp_path / "algorithm_lab").mkdir()
    p = tmp_path / "algorithm_lab" / "next_task.md"
    p.write_text(_task(), encoding="utf-8")
    return p


class FakeTimer:
    def __init__(self, delay, fn):
        self.delay, self.fn, self.cancelled, self.ran = delay, fn, False, False

    def cancel(self):
        self.cancelled = True

    def run(self):
        if not self.cancelled:
            self.ran = True
            self.fn()


class FakeScheduler:
    """替掉 threading.Timer：不等待，手动决定什么时候「到点」。"""

    def __init__(self):
        self.timers: list[FakeTimer] = []

    def __call__(self, delay, fn):
        t = FakeTimer(delay, fn)
        self.timers.append(t)
        return t

    @property
    def last(self) -> FakeTimer:
        return self.timers[-1]


def _bus(task, **kw):
    """默认全注入，测试里不会真的碰系统。"""
    kw.setdefault("trae_cli", r"C:\fake\trae-cn.cmd")
    kw.setdefault("open_fn", lambda cli, p: True)
    kw.setdefault("clipboard_fn", lambda text: True)
    kw.setdefault("toast_fn", lambda title, msg: True)
    kw.setdefault("logger", _log())
    return D.Bus(task, **kw)


# ---------------------------------------------------------------- 红线
def test_source_holds_no_remote_write_literal():
    """代码里绝对不能出现远端写操作 —— 连字面量都不许（单测直接扫源码）。"""
    src = Path(D.__file__).read_text(encoding="utf-8").lower()
    assert "push" not in src, "源码里出现了 push"
    assert "--force" not in src
    assert "-f origin" not in src


def test_redline_guard_passes_on_clean_source():
    assert D._redline_violation() == ""


def test_redline_guard_catches_injected_violation():
    """自检必须真的能拦住 —— 拿一段带违规操作的可疑源码试（拆写形式）。"""
    bad = "subprocess.run(['git', 'pu' + 'sh', 'origin', 'main'])"
    assert D._redline_violation(bad)


def test_redline_guard_catches_plain_call():
    """老老实实写全的调用更要拦得住 —— 不能只认拆写这一种形态。"""
    bad = "import subprocess\nsubprocess.run(['git', 'push', 'origin', 'main'])\n"
    assert D._redline_violation(bad)


def test_redline_guard_ignores_explanatory_text():
    """注释与 docstring 里写「不要 push」是人话，不该被当违规拦下。"""
    ok = (
        '"""说明：本模块不做远端写，也不会强推。"""\n'
        "# 这里绝不调用 git push，历史教训见 HANDOFF\n"
        "VALUE = 1\n"
    )
    assert D._redline_violation(ok) == ""


def test_prepare_branch_only_switches(monkeypatch, tmp_path):
    """建分支只允许 `switch -c fix/GH-N`：不提交、不碰远端。"""
    calls = []

    class R:
        returncode = 0
        stdout = "main\n"
        stderr = ""

    def fake_run(args, **kw):
        calls.append(args)
        return R()

    monkeypatch.setattr(subprocess, "run", fake_run)
    res = D.prepare_branch(tmp_path, 23, logger=_log())

    assert res["branch"] == "fix/GH-23" and res["created"] is True
    assert ["git", "-C", str(tmp_path), "switch", "-c", "fix/GH-23"] in calls
    flat = " ".join(" ".join(c) for c in calls)
    assert "commit" not in flat and "pull" not in flat


# ---------------------------------------------------------------- 幂等
def test_first_change_notifies_once(workspace):
    bus = _bus(workspace)
    res = bus.fire()
    assert res["action"] == "notified" and res["issue"] == "23"
    assert bus.fired == 1


def test_same_sha_never_notifies_twice(workspace):
    """核心防自激：同一份内容第二次必须安静。"""
    bus = _bus(workspace)
    first = bus.fire()
    second = bus.fire()
    assert first["action"] == "notified"
    assert second["action"] == "ignored" and second["reason"] == "same-sha"
    assert bus.fired == 1


def test_new_sha_notifies_again(workspace):
    bus = _bus(workspace)
    bus.fire()
    workspace.write_text(_task(issue="19", sha="ffff0000ffff0000"), encoding="utf-8")
    res = bus.fire()
    assert res["action"] == "notified" and res["issue"] == "19"
    assert bus.fired == 2


def test_no_task_marker_stays_silent(workspace):
    """`next` 在没活干时写 issue=none —— 这时候叫人起床纯属骚扰。"""
    workspace.write_text(_task(issue="none", sha="0000aaaabbbbcccc", body="# 待修任务：无\n"),
                         encoding="utf-8")
    res = _bus(workspace).fire()
    assert res["action"] == "ignored" and res["reason"] == "no-task"


def test_missing_file_is_ignored(tmp_path):
    res = _bus(tmp_path / "nope.md").fire()
    assert res["action"] == "ignored" and res["reason"] == "empty"


def test_sha_falls_back_to_content_hash(tmp_path):
    """没有标记（人手工写的文件）时按内容自算，不能因为格式不同就彻底静默。"""
    p = tmp_path / "t.md"
    p.write_text("# 随便写的任务\n", encoding="utf-8")
    got = D.read_task(p)
    assert got["sha"] == hashlib.sha256("# 随便写的任务\n".encode()).hexdigest()[:16]
    assert got["issue"] == ""


# ---------------------------------------------------------------- 防抖
def test_debounce_keeps_only_the_last_event(workspace):
    """一次保存会连发多个事件：前两次必须被取消，只处理最后一次。"""
    sch = FakeScheduler()
    bus = _bus(workspace, schedule=sch)

    bus.on_event()
    bus.on_event()
    bus.on_event()

    assert len(sch.timers) == 3
    assert sch.timers[0].cancelled and sch.timers[1].cancelled
    assert not sch.last.cancelled
    assert bus.fired == 0, "还没到点就不该动手"

    sch.last.run()
    assert bus.fired == 1


def test_debounce_delay_is_one_and_a_half_seconds(workspace):
    sch = FakeScheduler()
    _bus(workspace, schedule=sch).on_event()
    assert sch.last.delay == pytest.approx(1.5)


# ---------------------------------------------------------------- 动作
def test_notify_does_clipboard_open_toast(workspace):
    seen = []
    bus = _bus(workspace,
               clipboard_fn=lambda text: (seen.append(("clip", "待修任务" in text)), True)[1],
               open_fn=lambda cli, p: (seen.append(("open", Path(p).name)), True)[1],
               toast_fn=lambda t, m: (seen.append(("toast", t, m)), True)[1])
    res = bus.fire()

    assert [x[0] for x in seen] == ["clip", "open", "toast"]
    assert dict(seen[:1].__iter__())  # noqa: B015 - 占位，避免误读
    assert seen[0][1] is True, "剪贴板里必须是文件全文"
    assert seen[1][1] == "next_task.md"
    assert res["clipboard"] and res["opened"] and res["toast"]


def test_missing_trae_degrades_but_still_warns(workspace):
    """没装 Trae 也要提醒人：降级为「请手动打开」，而不是一声不响。"""
    msgs = []
    bus = _bus(workspace, trae_cli="", toast_fn=lambda t, m: (msgs.append(m), True)[1])
    res = bus.fire()
    assert res["opened"] is False
    assert msgs and "没找到 Trae" in msgs[0]


def test_toast_failure_does_not_block(workspace):
    """Toast 弹不出来（系统策略/通知被关）不该影响剪贴板与开窗口。"""
    bus = _bus(workspace, toast_fn=lambda t, m: False)
    res = bus.fire()
    assert res["action"] == "notified" and res["toast"] is False
    assert res["clipboard"] is True


def test_relative_defaults_resolve_against_repo_root(monkeypatch, tmp_path):
    """开机自启时 CWD 往往是 system32：相对路径必须按仓库根解析，不能按 CWD。

    这一条错了，守护进程会「正常启动、永远静默」—— 最难查的那种坏法。
    """
    monkeypatch.chdir(tmp_path)
    got = D._resolve("algorithm_lab/next_task.md")
    assert got.is_absolute()
    assert got == D._REPO_ROOT / "algorithm_lab" / "next_task.md"
    assert D._REPO_ROOT == Path(D.__file__).resolve().parent.parent


# ---------------------------------------------------------------- 命令行
def test_once_mode_prints_json_and_exits(workspace, capsys):
    code = D.main(["--task", str(workspace), "--log", str(workspace.parent / "d.log"),
                   "--once", "--dry-run"])
    assert code == 0
    out = capsys.readouterr().out
    assert '"action": "notified"' in out


def test_verbose_flags_do_not_crash_on_missing_watchdog(workspace):
    """--once 不该依赖 watchdog：没装也能跑完（常驻模式才需要）。"""
    assert D.main(["--task", str(workspace), "--log", str(workspace.parent / "d2.log"),
                   "--once", "--dry-run"]) == 0
