#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GH-15 / GH-18：MIN/TYP/MAX 角色塌缩（电气表）。

缺陷形态
--------
模型把 **MIN 列与 MAX 列**连写成 `8.8 to 11.2 V`。读者会以为「区间内任意值
都合规」，而原文 8.8 是 MIN、11.2 是 MAX —— 中间值不是原厂保证的规格。
ADS1675REF 更进一步：`Dynamic range` 的 100（MIN）与 103.5（TYP）来自**两行**，
连写出来的区间在原文里根本不存在。

守三件事
--------
1. **拆**：`split_role_rows()` 把连写行按原文角色拆回多条，`condition` 补角色词；
2. **标**：单值行（`2.5 V` 属 TYP）角色唯一时才补，唯一性不成立就不猜；
3. **判**：`table_audit.audit_role_collapse()` 把没拆干净的连写行判阻断，
   且**原文原样印着 `a to b`** 的单格区间值必须豁免（防误杀）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D          # noqa: E402
from qc import table_audit as TA                   # noqa: E402

NE555_PDF = ROOT / "data" / "pdfs" / "NE555__ne555.pdf"
ADS_PDF = ROOT / "data" / "pdfs" / "ADS1675REF__ads1675.pdf"

#: 缺陷表在很靠前的页（NE555 p5 / ADS p3），限页让测试可重复且不慢。
_TEST_PAGES = 8


def _doc(rows):
    return {"specs": {"electrical": rows}}


# ---------------------------------------------------------------- 纯函数
@pytest.mark.parametrize("value,expect", [
    ("8.8 to 11.2", (8.8, 11.2)),
    ("100 to 103.5", (100.0, 103.5)),
    ("±0.3 to ±3.0", (0.3, 3.0)),
    ("3 to 36", (3.0, 36.0)),
    ("±0.3", None),                 # 单值，不是区间
    ("3.63", None),
    ("See Table 1", None),
    ("0.7AVDD", None),
])
def test_range_pair_only_accepts_numeric_ab(value, expect):
    assert D._range_pair(value) == expect


def test_with_role_appends_once_and_is_idempotent():
    assert D._with_role("", "typ") == "TYP"
    assert D._with_role("TA = 25°C", "min") == "TA = 25°C; MIN"
    # 已写过角色就不再重复追加（否则条件会越改越长）
    assert D._with_role("TA = 25°C; MAX", "max") == "TA = 25°C; MAX"


def test_has_role_detects_existing_label():
    assert D._has_role("VCC = 15V; MIN")
    assert not D._has_role("VCC = 15V")
    # `MINIMUM` 里的 MIN 不算已标（词边界）
    assert not D._has_role("VCC minimum operating")


# ---------------------------------------------------------------- 真实 PDF
@pytest.mark.skipif(not NE555_PDF.exists(), reason="缺少 NE555 原件")
def test_ne555_split_thres_voltage_into_three_roles():
    """`8.8 to 11.2 V` → MIN 8.8 / TYP 10 / MAX 11.2（GH-15 的 P0）。"""
    import pymupdf
    doc = _doc([{"name": "THRES voltage level", "value": "8.8 to 11.2", "unit": "V",
                 "condition": "VCC = 15V; NA555, NE555, SA555"}])
    with pymupdf.open(str(NE555_PDF)) as fd:
        rep = D.split_role_rows(doc, fd, max_pages=_TEST_PAGES)
    out = doc["specs"]["electrical"]
    assert rep.get("role_split") == 1, rep
    assert [(r["value"], r["condition"].split(";")[-1].strip()) for r in out] == [
        ("8.8", "MIN"), ("10", "TYP"), ("11.2", "MAX")]


@pytest.mark.slow
@pytest.mark.skipif(not NE555_PDF.exists(), reason="缺少 NE555 原件")
def test_ne555_audit_flags_unfixed_merged_range():
    """没拆干净的 `8.8 to 11.2 V` 必须判 `role_collapse`（阻断）。"""
    specs = {"electrical": [{"name": "THRES voltage level", "value": "8.8 to 11.2",
                             "unit": "V", "condition": "VCC = 15V"}]}
    finds = TA.audit_role_collapse(NE555_PDF, specs)
    assert finds and finds[0]["kind"] == "role_collapse"
    assert finds[0]["table"]["page"] == 5
    assert finds[0]["table"]["roles"] == {"MIN": 8.8, "MAX": 11.2}


@pytest.mark.skipif(not NE555_PDF.exists(), reason="缺少 NE555 原件")
def test_ne555_audit_passes_after_split():
    """拆完之后同一条不得再被判塌缩（判据与修法同源，不许自相矛盾）。"""
    import pymupdf
    rows = [{"name": "THRES voltage level", "value": "8.8 to 11.2", "unit": "V",
             "condition": "VCC = 15V; NA555, NE555, SA555"}]
    doc = _doc(rows)
    with pymupdf.open(str(NE555_PDF)) as fd:
        D.split_role_rows(doc, fd, max_pages=_TEST_PAGES)
    assert TA.audit_role_collapse(NE555_PDF, doc["specs"]) == []


@pytest.mark.skipif(not ADS_PDF.exists(), reason="缺少 ADS1675REF 原件")
def test_ads_split_dynamic_range_and_label_single_typ():
    """Dynamic range 拆成 MIN/TYP；Common-mode 2.5 V 补 `TYP`（GH-18 第 1/2 项）。"""
    import pymupdf
    doc = _doc([
        {"name": "Dynamic range", "value": "100 to 103", "unit": "dB",
         "condition": "fDATA = 4MSPS"},
        {"name": "Common-mode input voltage", "value": "2.5", "unit": "V",
         "condition": ""},
    ])
    with pymupdf.open(str(ADS_PDF)) as fd:
        rep = D.split_role_rows(doc, fd, max_pages=_TEST_PAGES)
    out = doc["specs"]["electrical"]
    assert rep.get("role_split") == 1, rep
    assert rep.get("role_labeled") == 1, rep
    dr = [(r["value"], r["condition"]) for r in out if r["name"] == "Dynamic range"]
    assert dr == [("100", "fDATA = 4MSPS; MIN"), ("103", "fDATA = 4MSPS; TYP")]
    vcm = [r for r in out if r["name"] == "Common-mode input voltage"]
    assert vcm and vcm[0]["condition"] == "TYP"


@pytest.mark.slow
@pytest.mark.skipif(not ADS_PDF.exists(), reason="缺少 ADS1675REF 原件")
def test_ads_cross_row_merge_is_flagged_by_audit():
    """跨行错并（100 来自 4MSPS 行、103.5 来自 2MSPS 行）拆不出来，但**审计必须拦**。"""
    specs = {"electrical": [{"name": "Dynamic range", "value": "100 to 103.5",
                             "unit": "dB", "condition": "fDATA = 4MSPS"}]}
    finds = TA.audit_role_collapse(ADS_PDF, specs)
    assert finds and finds[0]["kind"] == "role_collapse"


@pytest.mark.skipif(not ADS_PDF.exists(), reason="缺少 ADS1675REF 原件")
def test_ads_genuine_range_is_not_split():
    """原文**单格**印着区间的值不许拆：`VS = 3 to 36 V` 这类照抄是对的。

    夹具用一个原文里不存在区间写法的 `3 to 36` —— 若被判成塌缩，
    说明判据只看形态、没回原文核对。
    """
    specs = {"electrical": [{"name": "Supply voltage", "value": "3 to 36",
                             "unit": "V", "condition": "Recommended"}]}
    import pymupdf
    doc = _doc(specs["electrical"])
    with pymupdf.open(str(ADS_PDF)) as fd:
        rep = D.split_role_rows(doc, fd, max_pages=_TEST_PAGES)
    # 3 与 36 若恰好落在不同角色列，才允许拆；否则必须原样保留
    if not rep.get("role_split"):
        assert doc["specs"]["electrical"][0]["value"] == "3 to 36"
