"""fix_plan 并发读改写的单测。

线上实测到的缺陷（TMDXDOCK28377D）：`fix_dispatch` 一次投 8 个 ready action，
worker 多进程并发执行。每个 `fix_apply` 原来是「读 plan → 改自己那条 → 整份写回」，
后写的人用旧快照覆盖前写的人 —— A1/A4/A9 明明 apply 成功了，plan 里却回退成
`pending`，于是「全部终结」永远不成立，`fix_finalize` 不触发、重审不跑，
状态停在「修了未验」。

这两条是回归锁：
  1. 并发补丁不丢更新（每条状态都落盘）；
  2. 被前置条件阻塞的动作，在前置完成后会被补投，不留永久 pending。
"""
import sys
import tempfile
import threading
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from worker import tasks as T       # noqa: E402


def make_plan(path: Path, actions: list[dict], mpn: str = "X1") -> None:
    T._write_plan(path, {"mpn": mpn, "round": 1, "verdict": "WARN",
                         "actions": actions})


def act(aid: str, status: str = "pending", **kw) -> dict:
    d = {"id": aid, "kind": "unit_duplicated", "worker": "fix_unit_duplicated",
         "preconditions": [], "status": status}
    d.update(kw)
    return d


class PatchActionTest(unittest.TestCase):
    def test_concurrent_patches_do_not_lose_updates(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.round1.fix_plan.json"
        ids = ["A%d" % i for i in range(1, 9)]
        make_plan(pp, [act(i) for i in ids])

        barrier = threading.Barrier(len(ids))
        errs: list[str] = []

        def work(aid: str):
            try:
                barrier.wait(timeout=10)
                T._patch_action(pp, aid, {"status": "done", "changed": ["x"]})
            except Exception as e:                               # noqa: BLE001
                errs.append(f"{aid}: {type(e).__name__}")

        ts = [threading.Thread(target=work, args=(i,)) for i in ids]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        self.assertEqual(errs, [])
        plan = T._read_plan(pp)
        self.assertEqual([a["status"] for a in plan["actions"]], ["done"] * len(ids))

    def test_all_terminal_flag(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.round1.fix_plan.json"
        make_plan(pp, [act("A1"), act("A2")])
        _p, done1 = T._patch_action(pp, "A1", {"status": "done"})
        self.assertFalse(done1)
        _p, done2 = T._patch_action(pp, "A2", {"status": "manual"})
        self.assertTrue(done2)

    def test_patch_only_touches_named_action(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.round1.fix_plan.json"
        make_plan(pp, [act("A1", note="orig"), act("A2", note="orig")])
        T._patch_action(pp, "A1", {"status": "done"})
        plan = T._read_plan(pp)
        by = {a["id"]: a for a in plan["actions"]}
        self.assertEqual(by["A1"]["status"], "done")
        self.assertEqual(by["A2"]["status"], "pending")
        self.assertEqual(by["A2"]["note"], "orig")


class ReleaseBlockedTest(unittest.TestCase):
    def setUp(self):
        self.sent: list[tuple] = []
        self._orig = T.dispatch.submit
        T.dispatch.submit = lambda kind, *a, **kw: self.sent.append((kind,) + a)

    def tearDown(self):
        T.dispatch.submit = self._orig

    def test_blocked_action_released_after_identity_done(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.round1.fix_plan.json"
        make_plan(pp, [
            act("A1", worker="fix_identity"),
            act("A2", worker="fix_pin_rebuild", preconditions=["identity_resolved"]),
        ])
        T._patch_action(pp, "A1", {"status": "done", "changed": ["basic_info.identity"]})
        fired = T._release_blocked(pp, T._read_plan(pp))
        self.assertEqual(fired, ["A2"])
        self.assertTrue(any(s[0] == "fix_apply" and s[2] == "A2" for s in self.sent))
        # 第二次不应重复投递
        self.assertEqual(T._release_blocked(pp, T._read_plan(pp)), [])

    def test_still_blocked_when_identity_pending(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.round1.fix_plan.json"
        make_plan(pp, [
            act("A1", worker="fix_identity"),
            act("A2", worker="fix_pin_rebuild", preconditions=["identity_resolved"]),
        ])
        # A1 无前置 → 会被投；A2 仍被身份卡住，只能记原因、不能投
        self.assertEqual(T._release_blocked(pp, T._read_plan(pp)), ["A1"])
        by = {a["id"]: a for a in T._read_plan(pp)["actions"]}
        self.assertEqual(by["A2"]["note"], "identity_not_resolved")
        self.assertFalse(by["A2"].get("dispatched"))
        self.assertTrue(by["A1"].get("dispatched"))


class PlanLockTest(unittest.TestCase):
    def test_lock_is_exclusive_and_released(self):
        d = Path(tempfile.mkdtemp())
        pp = d / "p.json"
        with T._plan_lock(pp):
            self.assertTrue(Path(str(pp) + ".lock").exists())
        self.assertFalse(Path(str(pp) + ".lock").exists())
        with T._plan_lock(pp):        # 释放后可再次获取
            pass


if __name__ == "__main__":
    unittest.main()
