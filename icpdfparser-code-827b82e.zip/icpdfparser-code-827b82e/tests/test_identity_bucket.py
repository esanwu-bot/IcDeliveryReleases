"""身份分桶器回归：保证 A/B/C/D 判据「有牙」，不是恒空。

背景：这张人工复核表是交付门的最后一道人工关口，分桶错了会有两种后果 ——
漏报（假 A=0，板卡以 chip 身份进交付）与误报（几十件 EB 芯片把人耗光）。
所以除了「当前回放 A=0」，还必须证明**喂进缺陷形态时它会报警**。
"""
import csv
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import identity_bucket as IB                    # noqa: E402


def row(mpn, state, identity, verdict, rule_id="", same_family="0", **kw):
    r = {"mpn": mpn, "state": state, "identity": identity, "verdict": verdict,
         "rule_id": rule_id, "same_family_n": same_family, "file": mpn + ".json",
         "manufacturer": "Texas Instruments", "evidence": ""}
    r.update(kw)
    return r


class BucketTeethTest(unittest.TestCase):
    """每个桶都要能被真实缺陷形态触发。"""

    def test_leaked_board_goes_to_A(self):
        """规则漏网的板卡：chip/PASS + 高置信 token + 规则空。"""
        self.assertEqual(IB.BUCKET_A, IB.bucket_of(
            row("CC1111EMK868-915", "IDENTITY_SUPPORTED", "chip", "PASS")))

    def test_family_fallback_goes_to_C(self):
        """同一形态但结论来自同族回退 -> C（不是 A）。"""
        self.assertEqual(IB.BUCKET_C, IB.bucket_of(
            row("CC1111EMK868-915", "IDENTITY_SUPPORTED", "chip", "PASS",
                same_family="7")))

    def test_low_conf_board_goes_to_D(self):
        self.assertEqual(IB.BUCKET_D, IB.bucket_of(
            row("CC2420ZDK", "BOARD_CONFIRMED", "development_kit", "PASS",
                "GENERIC_BOARD_SUFFIX_DK")))

    def test_blocked_review_goes_to_B(self):
        self.assertEqual(IB.BUCKET_B, IB.bucket_of(
            row("ADC12020EVAL/NOPB", "IDENTITY_REVIEW", "evaluation_board", "WARN",
                "GENERIC_BOARD_SUFFIX_EVAL")))


class BucketFalsePositiveTest(unittest.TestCase):
    """三类实测过的假阳性，必须不入桶。"""

    def test_eb_package_code_is_not_board_shape(self):
        """`EB` 是芯片封装代号（DAC081C08XEB 不是板卡）。"""
        self.assertEqual("", IB.bucket_of(
            row("DAC081C08XEB", "IDENTITY_SUPPORTED", "chip", "PASS")))

    def test_pdk_is_not_dk(self):
        """`EVM-PDK` 是板卡，不能因为字符串里含 DK 就进 D。"""
        self.assertEqual("", IB.bucket_of(
            row("ADS1246EVM-PDK", "BOARD_CONFIRMED", "evaluation_board", "PASS",
                "TI_BOARD_SUFFIX_EVM")))

    def test_chip_with_rule_hit_is_not_leak(self):
        """规则命中但因 `when_orderable=chip` 判成芯片 —— 设计如此，不是漏网。"""
        self.assertEqual("", IB.bucket_of(
            row("ADS8320EB/250", "IDENTITY_SUPPORTED", "chip", "PASS",
                "TI_BOARD_SUFFIX_EB")))


class OutputSchemaTest(unittest.TestCase):
    """输出表头必须覆盖 apply_manual_review.py 读的每一列，否则人填了也白填。"""

    def test_columns_cover_merge_inputs(self):
        for col in ("mpn", "proposed_action", "proposed_identity", "notes", "file",
                    "reviewer"):
            self.assertIn(col, IB.COLUMNS)

    def test_legal_actions_match_merge_script(self):
        # apply_manual_review.py 认识的三组取值
        self.assertEqual({"BOARD_CONFIRMED", "chip", "identity_review"},
                         set(IB.LEGAL_ACTIONS))

    def test_build_roundtrip(self):
        cols = ["file", "mpn", "manufacturer", "state", "identity", "confidence",
                "verdict", "blocks_release", "advisory", "rule_id", "orderables",
                "same_family_n", "head_orderables", "evidence"]
        rows = [
            dict(zip(cols, ["a.json", "ADC12020EVAL/NOPB", "TI", "IDENTITY_REVIEW",
                            "evaluation_board", "medium", "WARN", "1", "0",
                            "GENERIC_BOARD_SUFFIX_EVAL", "", "0", "", "缺证据"])),
            dict(zip(cols, ["b.json", "LM358", "TI", "IDENTITY_SUPPORTED", "chip",
                            "high", "PASS", "0", "0", "", "", "0", "", ""])),
        ]
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "replay.csv"
            dst = Path(td) / "review.csv"
            with open(src, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=cols)
                w.writeheader()
                w.writerows(rows)
            stat = IB.build(src, dst, Path(td) / "no_pdfs")
            self.assertEqual(1, stat["入表件数"])          # 只出 REVIEW 那件
            got = list(csv.DictReader(open(dst, encoding="utf-8-sig")))
            self.assertEqual(list(IB.COLUMNS), list(got[0].keys()))
            self.assertEqual("", got[0]["proposed_action"])  # 不替人做判断


if __name__ == "__main__":
    unittest.main()
