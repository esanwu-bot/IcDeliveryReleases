"""页选择回归：订货表能不能被送到模型面前。

背景：`extract_pdf_text` 旧实现是 `if i >= max_pages: break`，只读前 12 页。
而 TI/ADI 的订货表几乎总在文档末尾（实测 284 页的 F280037CSPTR 在第 246 页），
于是 ordering_info 只能从封面那一行小表里挤一条，271 件落进「证据不全」。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import parse_datasheets as P                              # noqa: E402


def pages(n, *, order_at=None, pin_at=2, elec_at=4, filler="generic text " * 40):
    """造 pages 生成器：第 order_at 页放订货表，其余为普通页（0 基）。"""
    def gen():
        for i in range(n):
            if order_at is not None and i == order_at:
                yield i, ("ORDERING INFORMATION\nOrderable part number\n"
                          "ABC1234XYZ  SOIC-8  LARGE T&R\nABC1234ABC  TSSOP-8  TUBE\n")
            elif i == pin_at:
                yield i, "PIN FUNCTIONS\n1 VIN 2 GND 3 OUT\n" + filler
            elif i == elec_at:
                yield i, "ELECTRICAL CHARACTERISTICS\n" + filler
            else:
                yield i, filler
    return gen()


class SelectPagesTest(unittest.TestCase):
    def test_ordering_table_beyond_page_cap_is_included(self):
        """订货表在第 246 页（284 页文档）也必须进上下文。"""
        text, used, _ = P.select_pages(pages(284, order_at=245), max_pages=12,
                                      max_chars=32000)
        self.assertIn("ABC1234XYZ", text)
        self.assertIn("ORDERING INFORMATION", text)
        self.assertLessEqual(used, 12)

    def test_head_pages_always_kept(self):
        """前 3 页（封面/要点/引脚图）无条件保留。"""
        text, _, _ = P.select_pages(pages(60, order_at=50), max_pages=12,
                                    max_chars=32000)
        for n in (1, 2, 3):
            self.assertIn("--- Page %d ---" % n, text)

    def test_no_half_page_truncation(self):
        """预算不够就整页丢，不能把排后面的订货表切成半个表。

        关键点：旧实现 `out[:max_chars]` 会留下列表页的前半截（含表头、丢料号行），
        比整页不给更糟——模型会照着半个表编。
        """
        big = "filler " * 6000            # 单页 ~42000 字符，必然超预算
        def gen():
            yield 0, "COVER"
            yield 1, "PIN FUNCTIONS"
            yield 2, "ELECTRICAL CHARACTERISTICS"
            yield 20, "ORDERING INFORMATION\nABC1234XYZ\nABC1234ABC\n" + big
        text, _, dropped = P.select_pages(gen(), max_pages=12, max_chars=32000)
        self.assertTrue(dropped)
        # 要么完整给出料号，要么整页不给；绝不能只有表头
        self.assertNotIn("ORDERING INFORMATION", text)

    def test_page_cap_respected(self):
        _, used, _ = P.select_pages(pages(200, order_at=150), max_pages=8,
                                    max_chars=32000)
        self.assertLessEqual(used, 8)

    def test_ordering_page_has_priority_over_filler(self):
        """有预算冲突时先保订货表，普通页让位。"""
        text, _, _ = P.select_pages(pages(80, order_at=70), max_pages=5,
                                    max_chars=32000)
        self.assertIn("ABC1234XYZ", text)


class PageBudgetTest(unittest.TestCase):
    """页预算竞争回归。

    起因：228 件重解析把订货行补上了，但电气参数去重签名净减 769。诊断发现
    221/228 触发字符预算裁剪、71 件电气页直接落选 —— `RANK_QUOTA` 只限页数不限
    字符，长页照样吃满 `MAX_CHARS`，而电气档排在 rank 3 只能捡剩余。
    修法是「电气档字符保底 + 分档配额」，额度由 `qc/tune_page_budget.py` 在
    同一批 228 份真实 PDF 上横比得出，不是拍脑袋。
    """

    def _page_nums(self, text):
        import re
        return [int(n) for n in re.findall(r"--- Page (\d+) ---", text)]

    def test_ordering_at_page_30_60_and_electrical_in_head(self):
        """订货表在 30~60 页、电气表在前 12 页：两者都要进上下文。"""
        def gen():
            for i in range(80):
                if i == 45:
                    yield i, ("ORDERING INFORMATION\nOrderable part number\n"
                              "ABC1234XYZ  SOIC-8\n")
                elif i in (4, 5):
                    yield i, "ELECTRICAL CHARACTERISTICS\nVCC 3.0 3.3 3.6 V\n"
                else:
                    yield i, "generic text " * 40
        text, _, _ = P.select_pages(gen())
        self.assertIn("ABC1234XYZ", text)
        self.assertIn("ELECTRICAL CHARACTERISTICS", text)

    def test_continuous_poa_pages_do_not_exhaust_budget(self):
        """连续十几页 POA 不能把预算吃光，电气页仍要进来。"""
        def gen():
            for i in range(120):
                if 60 <= i < 78:
                    yield i, "PACKAGE OPTION ADDENDUM\n" + "row " * 3000
                elif i in (4, 5, 6):
                    yield i, "ELECTRICAL CHARACTERISTICS\nIQ 1.0 mA\n"
                else:
                    yield i, "generic " * 40
        text, used, _ = P.select_pages(gen())
        self.assertIn("ELECTRICAL CHARACTERISTICS", text)
        # 配额仍在：POA 不能独占
        self.assertLessEqual(sum(1 for _ in text.split("--- Page ")
                                 if "PACKAGE OPTION ADDENDUM" in text), 20)
        self.assertLessEqual(used, P.MAX_PAGES)

    def test_long_pin_page_does_not_squeeze_out_electrical(self):
        """一页超长引脚表不能挤掉电气特性页（这是本轮最主要退化形态）。"""
        def gen():
            yield 0, "COVER"
            yield 1, "FEATURES"
            yield 2, "PIN FUNCTIONS\n" + "pin row " * 4000      # 单页约 3.2 万字符
            yield 5, "ELECTRICAL CHARACTERISTICS\nVCC 3.3 V\nIQ 1 mA\n"
            yield 6, "ELECTRICAL CHARACTERISTICS (cont.)\nVIL 0.8 V\n"
            yield 50, "ORDERING INFORMATION\nABC1234XYZ\n"
        text, _, _ = P.select_pages(gen())
        self.assertIn("ELECTRICAL CHARACTERISTICS", text)
        self.assertIn("IQ 1 mA", text)

    def test_electrical_continuation_pages_are_not_treated_as_filler(self):
        """电气续表页没有重复标题，但仍是电气内容；至少保证带标题的页入选。"""
        def gen():
            for i in range(60):
                if i == 5:
                    yield i, "ELECTRICAL CHARACTERISTICS\nVCC 3.3 V\n"
                elif i in (6, 7, 8):
                    yield i, "IQ 1.0 mA\nVIL 0.8 V\nVIH 2.0 V\n"   # 续表，无标题
                elif i == 40:
                    yield i, "ORDERING INFORMATION\nABC1234XYZ\n"
                else:
                    yield i, "generic " * 40
        text, _, _ = P.select_pages(gen())
        self.assertIn("VCC 3.3 V", text)
        self.assertIn("ABC1234XYZ", text)

    def test_short_document_selects_all_useful_pages(self):
        """5 页短文档：不报错、不超上限，关键页都在。"""
        def gen():
            yield 0, "COVER"
            yield 1, "ELECTRICAL CHARACTERISTICS\nIQ 1 mA\n"
            yield 2, "PIN FUNCTIONS\n1 VIN\n"
            yield 3, "ORDERING INFORMATION\nABC1234XYZ\n"
            yield 4, "PACKAGE OPTION ADDENDUM\n"
        text, used, _ = P.select_pages(gen())
        for kw in ("ELECTRICAL CHARACTERISTICS", "PIN FUNCTIONS", "ABC1234XYZ"):
            self.assertIn(kw, text)
        self.assertLessEqual(used, 5)

    def test_very_long_document_respects_scan_cap(self):
        """700 页超长文档：不超页数上限，仍能选到末尾的订货表。

        注意 `PAGE_SCAN_CAP = 800`：超过 800 页之后的页根本不进候选，
        订货表在 800 页之外是扫不到的（既有限制，不在本轮修复范围）。
        """
        text, used, _ = P.select_pages(pages(700, order_at=690))
        self.assertIn("ABC1234XYZ", text)
        self.assertLessEqual(used, P.MAX_PAGES)

    def test_electrical_floor_is_not_wasted_on_short_docs(self):
        """短文档攒不满电气保底时，剩余额度要回到全局预算给别的档用。"""
        def gen():
            yield 0, "COVER"
            yield 1, "ELECTRICAL CHARACTERISTICS\nIQ 1 mA\n"     # 很短
            yield 2, "PIN FUNCTIONS\n"
            yield 30, "ORDERING INFORMATION\nABC1234XYZ\n"
        text, used, _ = P.select_pages(gen())
        self.assertIn("ABC1234XYZ", text)
        self.assertIn("IQ 1 mA", text)
        self.assertLessEqual(used, P.MAX_PAGES)

    def test_electrical_quota_allows_more_than_three_pages(self):
        """电气档页数配额已放宽：旧配额 (3,3,3) 把电气页压到最多 3 页。"""
        self.assertGreaterEqual(P.RANK_QUOTA[2], 6)
        self.assertGreaterEqual(P.MAX_PAGES, P.RANK_QUOTA[2] + 3)


class ElectricalTailFloorTest(unittest.TestCase):
    """电气续表尾页保底。

    起因：AFE4490RHAT 的 EC 表从 p8 续到 p14，功耗参数（POWER DISSIPATION
    2.84 mW）在 **p14**。按页号升序取前 6 页只能拿到 p4~p11，p14 必然落选。
    实测后果：v1 因此编造 `2.3 mW`、v2 因此标 `not_specified`——两者都不是
    模型取值能力问题，是压根没看到那张表。

    修法：把**最长连续 EC 块的尾页**提到取页顺序最前，其余仍按页号升序。
    之所以不是简单「全表首尾各半」，见 `test_long_doc_tail_is_main_table`。
    """

    def _page_nums(self, text):
        import re
        return [int(n) for n in re.findall(r"--- Page (\d+) ---", text)]

    def _ec_doc(self):
        """AFE4490 形态：短块(2 页) + 长块(7 页) + 两个散页 + 末尾订货表。"""
        def gen():
            for i in range(80):
                if i in (3, 4):
                    yield i, "ELECTRICAL CHARACTERISTICS\nIQ 1 mA\n" + "x " * 1800
                elif 7 <= i <= 13:
                    # 续表页：真实 PDF 里也带 "(continued)" 标题，否则会被判成普通页
                    yield i, ("ELECTRICAL CHARACTERISTICS (continued)\n"
                              "IQ %d mA\n" % i + "x " * 1800)
                elif i in (38, 71):
                    yield i, "ELECTRICAL CHARACTERISTICS\nIQ 9 mA\n" + "x " * 1800
                elif i == 50:
                    yield i, "ORDERING INFORMATION\nABC1234XYZ\n"
                else:
                    yield i, "generic " * 40
        return gen()

    def test_electrical_continuation_tail_is_selected(self):
        """最长 EC 块的尾页（p14）必须进上下文——这是本轮的核心回归。"""
        text, _, _ = P.select_pages(self._ec_doc())
        self.assertIn(14, self._page_nums(text))

    def test_tail_floor_does_not_break_ordering(self):
        """尾页保底只改顺序不改配额，不能把订货表挤掉。"""
        text, _, _ = P.select_pages(self._ec_doc())
        self.assertIn("ABC1234XYZ", text)

    def test_single_block_document_keeps_coverage(self):
        """单块文档（所有 EC 页连成一片）退化为「整块尾页优先」，覆盖度不降。"""
        def gen():
            for i in range(40):
                if 6 <= i <= 15:                       # 连续 10 页 EC
                    yield i, ("ELECTRICAL CHARACTERISTICS (continued)\n"
                              "IQ %d mA\n" % i + "x " * 900)
                else:
                    yield i, "generic " * 40
        text, used, _ = P.select_pages(gen())
        nums = self._page_nums(text)
        self.assertIn(16, nums, "单块的尾页 p16 应入选")
        self.assertGreaterEqual(len(nums), 4, "覆盖度不能塌")
        self.assertLessEqual(used, P.MAX_PAGES)

    def test_long_doc_tail_is_main_table_not_appendix(self):
        """超长文档的"尾部"取最长 EC 块的尾页，不是**文档末尾**的散页。

        AM5746ABZXEA 有 81 个 rank3 候选，简单「全表首尾各半」会取到
        p420 / p449 这类文档末尾附录，把真表区（p183~194）的预算抢走。
        """
        def gen():
            for i in range(300):
                if 180 <= i <= 193:                    # 真 EC 主表：14 页连续
                    yield i, ("ELECTRICAL CHARACTERISTICS (continued)\n"
                              "IQ %d mA\n" % (i - 180) + "x " * 900)
                elif i in (250, 280, 295):             # 文档末尾散页
                    yield i, "ELECTRICAL CHARACTERISTICS\nIQ 9 mA\n" + "x " * 900
                else:
                    yield i, "generic " * 40
        text, _, _ = P.select_pages(gen())
        nums = self._page_nums(text)
        self.assertTrue(any(181 <= n <= 194 for n in nums),
                        "真表区（p181~p194）必须有页入选，实际选中 %s" % nums)

    def test_tail_floor_cost_is_neutral(self):
        """只换取页顺序、不放宽任何上限：页数与字符数都不该变多。"""
        gen1, gen2 = self._ec_doc(), self._ec_doc()
        t1, u1, _ = P.select_pages(gen1)
        t2, u2, _ = P.select_pages(gen2)
        self.assertEqual(u1, u2)
        self.assertEqual(len(t1), len(t2))


class PerMpnBudgetOverrideTest(unittest.TestCase):
    """按 mpn 覆盖页/字符预算（步 3）。

    为什么需要：为照顾少数超长文档（AM5746ABZXEA 474 页）抬高全局
    `MAX_PAGES`，会让**全库每一件**都多花钱；全局收紧又救不了那些件。
    所以例外要按件给，走 `ICPDF_MAX_PAGES_OVERRIDE="MPN=32,..."`。
    """

    def test_parse_int_map_basic(self):
        self.assertEqual(P._parse_int_map("ABC=32, DEF=60"),
                         {"ABC": 32, "DEF": 60})

    def test_parse_int_map_ignores_garbage(self):
        """空串、非数字、缺 key 一律丢弃，不能让脏配置把预算改坏。"""
        self.assertEqual(P._parse_int_map("ABC=,=32,DEF=abc,GHI=0, JKL =-5,"),
                         {})
        self.assertEqual(P._parse_int_map("ABC=40"), {"ABC": 40})

    def test_override_reaches_select_pages(self):
        """覆盖值必须真正传到 select_pages，而不是只在常量里躺着。"""
        import parse_datasheets as PD
        captured = {}
        orig = PD.select_pages

        def spy(pages, max_pages, max_chars):
            captured["pages"], captured["chars"] = max_pages, max_chars
            return "", 0, False

        PD.select_pages = spy
        PD.MAX_PAGES_OVERRIDE = {"ABC123": 7}
        PD.MAX_CHARS_OVERRIDE = {"ABC123": 5000}
        orig_iter = PD._iter_pages          # 必须一起还原：漏还原会让后续用例读到空文本
        PD._iter_pages = lambda path: (10, iter([]))
        try:
            PD.extract_pdf_text(Path("ABC123__datasheet.pdf"))
        finally:
            PD.select_pages = orig
            PD._iter_pages = orig_iter
            PD.MAX_PAGES_OVERRIDE, PD.MAX_CHARS_OVERRIDE = {}, {}
        self.assertEqual(captured, {"pages": 7, "chars": 5000})

    def test_no_override_uses_global_default(self):
        """没命中覆盖表的件，必须走全局默认值——不能被上一件的覆盖污染。"""
        import parse_datasheets as PD
        captured = {}
        orig = PD.select_pages

        def spy(pages, max_pages, max_chars):
            captured["pages"] = max_pages
            return "", 0, False

        PD.select_pages = spy
        PD.MAX_PAGES_OVERRIDE = {"OTHER": 99}
        orig_iter = PD._iter_pages          # 同上：不还原会污染后续用例
        PD._iter_pages = lambda path: (10, iter([]))
        try:
            PD.extract_pdf_text(Path("ZZZ999__datasheet.pdf"))
        finally:
            PD.select_pages = orig
            PD._iter_pages = orig_iter
            PD.MAX_PAGES_OVERRIDE = {}
        self.assertEqual(captured["pages"], P.MAX_PAGES)


class ContinuedTableTest(unittest.TestCase):
    """跨页续表：只给前半页 = 静默失效（模型会照着半张表交「完整」结果）。

    事故标尺：ADC12DJ5200SE 的 `Table 4-1. Pin Functions` 横跨 p4–p8 共 5 页，
    引脚档配额 2 页 → 只喂 p4/p5 → 模型交出 32 条引脚；
    而 p4–p8 的球位并集正好 144 条（真值）。旧实现按「前 12 页」取，天然含全，
    所以这是 2026-10-28 选页重写引入的回归，不是模型变差。
    """

    @staticmethod
    def _doc(n: int, span: tuple[int, int], cont_span=None):
        """第 span 区间放一张引脚表，续页以 `(continued)` 开头。"""
        lo, hi = span
        cont_lo, cont_hi = cont_span or (lo + 1, hi)

        def gen():
            for i in range(n):
                if i == lo:
                    yield i, "PIN FUNCTIONS\nPIN1 VIN\n" + "fill " * 80
                elif cont_lo <= i <= cont_hi:
                    yield i, f"Table 4-1. Pin Functions (continued)\nBALL{i}\n" + "fill " * 80
                elif i % 5 == 4:
                    yield i, "ELECTRICAL CHARACTERISTICS\n" + "fill " * 80
                else:
                    yield i, "generic text " * 40
        return gen()

    def test_continuation_pages_are_included(self):
        """续页必须跟着它的前页一起入列。"""
        text, used, _ = P.select_pages(self._doc(40, (3, 7)), max_pages=16,
                                       max_chars=200_000)
        for i in range(4, 8):
            self.assertIn(f"BALL{i}", text, f"续页 p{i + 1} 没进上下文")

    def test_continuation_capped(self):
        """续页不能无限追加，否则会吃光预算（POA 那种连续十几页）。"""
        text, used, _ = P.select_pages(self._doc(60, (3, 30)), max_pages=16,
                                       max_chars=400_000)
        # 近处的续页该进；远处的（超出封顶 + 档位配额能覆盖的范围）不该进。
        self.assertIn("BALL5", text)
        self.assertNotIn("BALL20", text)

    def test_continuation_respects_page_budget(self):
        """加续页不能突破 max_pages —— 名额不够时踢页，不是超发。"""
        _, used, _ = P.select_pages(self._doc(60, (3, 30)), max_pages=16,
                                    max_chars=400_000)
        self.assertLessEqual(used, 16)

    def test_continuation_requires_chosen_predecessor(self):
        """前页没入列时，孤立的 `(continued)` 页不该被硬塞进来。"""
        def gen():
            for i in range(40):
                if i == 25:
                    yield i, "Table 9-9. Register Map (continued)\nORPHAN\n" + "fill " * 80
                else:
                    yield i, "generic text " * 40
        text, _, _ = P.select_pages(gen(), max_pages=16, max_chars=200_000)
        self.assertNotIn("ORPHAN", text)


if __name__ == "__main__":
    unittest.main()
