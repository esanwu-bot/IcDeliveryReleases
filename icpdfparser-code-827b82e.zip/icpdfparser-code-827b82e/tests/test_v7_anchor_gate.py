# -*- coding: utf-8 -*-
"""V7 P0-1：`data_anchor` 口径拆分与 `DATA_VALIDATED` 精度闸。

复审原话（8.9 分）：「`verified` 是容器级确定性复现，表示参数名和数值能在
PDF 中复现，但没有行坐标」，「不能让 `verified` 直接被计入 `data_anchor`，
再用 `data_anchor=100%` 宣称全部工程参数已锚定」。

本文件把那句话变成 7 条硬断言。任何一条变红，打包必须阻断。

1. 无坐标的参数不得计入 `row_anchor`。
2. 正文段落证据只能计 `paragraph_anchor`，不得冒充 `row_anchor`。
3. 同页多个相同数值，不得仅凭数值命中判定参数归属。
4. 芯片手册被用于评估板时，板载芯片参数不得计为整板参数。
5. PDF 表含 MIN/TYP/MAX 时，不能只因为 MIN/MAX 匹配就丢掉 TYP。
6. `i18n_coverage=1.0` 不得自动触发人工语言审核通过。
7. 没有人工签核，不得输出 `RELEASE_APPROVED`。
"""
from __future__ import annotations

import pytest

import delivery_bundle as DB
from qc import fact_acceptance as FA

ALL_ART = ["json", "html", "symbol", "pdf"]


def _row(verdict: str, kind: str = "table", label: str = "X", **kw) -> dict:
    r = {"mpn": "M", "container": "electrical", "label": label, "value": "1",
         "unit": "V", "verdict": verdict, "kind": kind}
    r.update(kw)
    return r


# ── 反例 1：无坐标不得计入 row_anchor ───────────────────────────────
def test_container_verified_is_not_row_anchor():
    assert FA.grade_of("verified") == "container_verified"
    assert FA.grade_of("verified") != "row_anchor"


def test_row_without_coord_cannot_be_row_anchor():
    """同样的 verdict、缺 bbox 的行，不许算进 row_anchor。"""
    rows = [_row("verified_row", kind="table", bbox="", row_sha256="")]
    g = FA.gate_summary(rows)
    # 字段与结论错配 → 由 `_check_consistency` 拦下，闸门本身也不认
    assert g["anchor_gate"] == "blocked"
    assert g["counts"]["row_anchor"] == 0 or g["inconsistent"]


def test_container_only_table_row_blocks_gate():
    rows = [_row("verified_row", label="A", bbox="[1,2,3,4]", row_sha256="aa"),
            _row("verified", label="B")]          # 容器级：无坐标
    g = FA.gate_summary(rows)
    assert g["anchor_gate"] == "blocked"
    assert g["counts"]["row_anchor"] == 1
    assert g["counts"]["container_verified"] == 1
    assert [b["label"] for b in g["blocked"]] == ["B"]


# ── 反例 2：正文证据只计 paragraph_anchor ──────────────────────────
def test_paragraph_counts_as_paragraph_only():
    assert FA.grade_of("verified_paragraph") == "paragraph_anchor"
    g = FA.gate_summary([_row("verified_paragraph", kind="prose",
                              bbox="[1,2,3,4]", paragraph_sha256="bb")])
    assert g["counts"]["paragraph_anchor"] == 1
    assert g["counts"]["row_anchor"] == 0


def test_paragraph_cannot_satisfy_table_row():
    """表格参数只有正文段落证据 → 不达标（弱证据不许顶强门槛）。"""
    g = FA.gate_summary([_row("verified_paragraph", kind="table",
                              bbox="[1,2,3,4]", paragraph_sha256="bb")])
    assert g["anchor_gate"] == "blocked"
    assert g["blocked"][0]["have"] == "paragraph_anchor"
    assert g["blocked"][0]["need"] == "row_anchor"


def test_paragraph_is_enough_for_prose_row():
    g = FA.gate_summary([_row("verified_paragraph", kind="prose",
                              bbox="[1,2,3,4]", paragraph_sha256="bb")])
    assert g["anchor_gate"] == "pass"


# ── 反例 3：同页多个相同数值，不得凭数值命中判定归属 ────────────────
def test_tie_on_numbers_is_not_an_anchor():
    """三条数值完全相同的候选行 → `_locate_row` 必须返回 None（不猜）。"""
    cands = [{"min": "1", "typ": "", "max": "", "value": "1",
              "name": "Input Common-Mode Voltage", "bbox": [0, 0, 1, 1]},
             {"min": "1", "typ": "", "max": "", "value": "1",
              "name": "Input Common-Mode Voltage", "bbox": [0, 2, 1, 3]}]
    assert FA._locate_row(cands, "Input Common-Mode Voltage", {"1"}, "") is None


def test_single_number_hit_without_name_is_not_enough():
    """名字毫无关系时，数值命中也不能认领（`_name_score < 0.6` 直接丢）。"""
    cands = [{"min": "1", "typ": "", "max": "", "value": "1",
              "name": "Operating Temperature Range", "bbox": [0, 0, 1, 1]}]
    assert FA._locate_row(cands, "Analog Input Voltage", {"1"}, "") is None


# ── 反例 4：芯片手册用于评估板，参数不得被算成整板 ──────────────────
def test_board_row_scope_must_be_declared():
    doc = {"metadata": {"core_validation": "pass", "pdf_hash": "x"},
           "basic_info": {"identity": "evaluation_board",
                          "identity_state": "IDENTITY_REVIEW",
                          "mpn": "ADS8568EVM-PDK",
                          "document_subject": "ADS8568",
                          "data_subject": "ADS8568",
                          "document_scope": "onboard_device_datasheet"}}
    subj = DB._subject_fields(doc)
    assert subj["data_subject"] == "ADS8568"
    assert subj["subject_match"] is False
    # 主体不一致时，即使数据全部锚定，也不得越过 DATA_VALIDATED
    facts = {"verdict": "pass", "anchor_gate": "pass"}
    st = DB._release_state(doc, ALL_ART, True, facts)
    assert st == "DATA_VALIDATED"
    # 再补上身份审核也不许把它当作「整板已核验」
    doc["basic_info"]["identity_state"] = "IDENTITY_SUPPORTED"
    assert DB._release_state(doc, ALL_ART, True, facts) == "IDENTITY_APPROVED"
    # 但签核缺位时永不越过 CONTENT_APPROVED
    assert DB._release_state(doc, ALL_ART, True, facts, {}) != "RELEASE_APPROVED"


def test_subject_match_true_when_same_mpn():
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE",
                          "document_subject": "ADC12DJ5200SE",
                          "data_subject": "ADC12DJ5200SE"}}
    assert DB._subject_fields(doc)["subject_match"] is True


# ── 反例 5：MIN/TYP/MAX 不得因 MIN/MAX 匹配就丢 TYP ─────────────────
def test_missing_typ_column_is_flagged():
    """原表印了 typ、JSON 只存 min/max → 必须进风险队列，不许静默通过。"""
    json_row = {"min": "1.8", "max": "2.0", "value": "", "typ": ""}
    pdf_row = {"min": "1.8", "typ": "1.9", "max": "2.0", "value": ""}
    assert FA.missing_columns(json_row, pdf_row) == ["typ"]
    ok = {"min": "1.8", "typ": "1.9", "max": "2.0", "value": ""}
    assert FA.missing_columns(ok, pdf_row) == []


def test_range_from_multiple_typ_is_not_a_minmax_range():
    """`2.0 to 6.3 GHz` 由多个 TYP 拼成 → 语义必须写成 typ_span。"""
    assert FA.range_semantics({"value": "2.0 to 6.3", "min": "", "max": ""},
                              {"value_shape": "range_typ_span"}) == "typ_span"


# ── 反例 6：i18n 覆盖率不得触发人工审校通过 ────────────────────────
def test_i18n_coverage_does_not_approve_content():
    doc = {"basic_info": {"identity_state": "IDENTITY_SUPPORTED"},
           "metadata": {"core_validation": "pass"}}
    facts = {"verdict": "pass", "anchor_gate": "pass",
             "i18n_coverage": "1.0000", "i18n_complete": "true",
             "i18n_content_review": "not_reviewed"}
    assert DB._release_state(doc, ALL_ART, True, facts, {}) == "IDENTITY_APPROVED"


# ── 反例 7：没有签核不得 RELEASE_APPROVED ─────────────────────────
def test_no_signoff_never_release_approved():
    doc = {"basic_info": {"identity_state": "IDENTITY_SUPPORTED"},
           "metadata": {"core_validation": "pass"}}
    facts = {"verdict": "pass", "anchor_gate": "pass"}
    assert DB._release_state(doc, ALL_ART, True, facts, {}) == "IDENTITY_APPROVED"
    assert DB._release_state(doc, ALL_ART, True, facts,
                             {"content_approved": True}) == "CONTENT_APPROVED"
    assert DB._release_state(doc, ALL_ART, True, facts,
                             {"content_approved": True,
                              "release_approved": True}) == "RELEASE_APPROVED"


# ── 清单列：弱证据不得混进坐标列 ──────────────────────────────────
def test_manifest_columns_separate_grades():
    facts = {"n_rows": 10,
             "counts": {"verified_row": 6, "verified_paragraph": 2,
                        "verified_value": 1, "verified": 1,
                        "value_on_label_page": 0},
             "anchor_gate": "blocked"}
    cols = DB._anchor_columns(facts)
    assert cols["row_anchor"] == "6/10"
    assert cols["paragraph_anchor"] == "2/10"
    assert cols["container_verified"] == "1/10"
    # 坐标级（含无指纹的 verified_value），**不含**容器级
    assert cols["coord_anchor"] == "9/10"
    assert cols["anchor_gate"] == "blocked"
    # 单一口径已废弃：不许再出现把容器级算进去的 data_anchor
    assert "data_anchor" not in cols


@pytest.mark.parametrize("verdict,grade", [
    ("verified_row", "row_anchor"),
    ("verified_paragraph", "paragraph_anchor"),
    ("verified_value", "coord_no_fingerprint"),
    ("verified", "container_verified"),
    ("value_on_label_page", "weak"),
    ("value_in_pdf", "weak"),
    ("partial", "weak"),
    ("not_found", "weak"),
    ("unchecked", "no_value"),
])
def test_grade_table(verdict, grade):
    assert FA.grade_of(verdict) == grade
