#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.6 最小生产接线的守卫用例。

这一层不测算法（算法在 `app/pipeline/stages.py`，由 test_pipeline_stages.py 守），
只测**接线本身没有接错**。四种接错方式，每一种都会在压测里变成"跑完了但数不对"：

  1. 队列接错：切片任务落进 llm 队列 —— 不报错，只是贵槽位在等 CPU。
  2. 开关接反：`PIPELINE_V2` 默认开 —— 灰度还没开始就已经全量切换。
  3. 分叉接漏：V2 开着仍投 `llm_item` —— 日志显示五段链路在跑，实际没跑。
  4. 静默补跑：LLM 阶段自己重抽切片 —— 阶段账上查不到这次抽取，
     事后无法回答"模型当时看到的文本是哪次抽的"。

四条都对应一个用例，且都断言在**行为**上而不是源码文本上（除第 5 条明确是静态守卫）。
"""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config                                      # noqa: E402
from app.pipeline import contracts as C                     # noqa: E402
from worker import tasks as T                               # noqa: E402


def _ST():
    """取**当前**的 `app.pipeline.stages` 模块。

    不能在模块顶部 import 后一直用同一个引用：`test_attach_worklist` /
    `test_cheatsheet` / `test_evidence_*` 会在用例里把 `sys.modules` 里所有
    `app*` 删掉（它们要换环境变量重新导入配置）。删完之后 `worker/tasks.py`
    里那句 `from app.pipeline import stages` 拿到的是**重新导入的新对象**，
    而本模块顶部保存的旧引用仍然指向老对象 —— patch 老对象等于没 patch，
    于是真实阶段函数被调用，测试以 `AttributeError: 'SimpleNamespace' ...`
    的形式失败，看起来像接线写错了，其实是测试之间互相拆了模块缓存。
    """
    import importlib                                        # noqa: PLC0415
    return importlib.import_module("app.pipeline.stages")


# ------------------------------------------------------------------ 夹具

def _item(**kw) -> dict:
    """一条最小可用的 item 行（字段取真实 DDL 的子集）。"""
    base = {"id": 7, "mpn": "LM317", "mpn_key": "LM317", "pdf_path": "/tmp/x.pdf",
            "pdf_sha256": "a" * 64, "pdf_url": "http://example/x.pdf",
            "json_path": "", "parse_count": 0, "status": "queued"}
    base.update(kw)
    return base


@pytest.fixture
def wire(monkeypatch):
    """把 item 读写、投递、阶段实现全部换成可观测的替身。"""
    calls = {"status": [], "events": [], "set_item": [], "submit": []}

    def q1(sql, args=()):                                     # noqa: ANN001
        return calls.get("item")

    monkeypatch.setattr(T.db, "q1", q1)
    monkeypatch.setattr(T.db, "touch_status",
                        lambda *a, **k: calls["status"].append(a))
    monkeypatch.setattr(T.db, "add_event",
                        lambda *a, **k: calls["events"].append((a, k)))
    monkeypatch.setattr(T.db, "set_item",
                        lambda *a, **k: calls["set_item"].append((a, k)))
    monkeypatch.setattr(T.dispatch, "submit",
                        lambda kind, *a, **k: calls["submit"].append((kind, a, k)))
    monkeypatch.setattr(T, "_v2_ctx", lambda item: SimpleNamespace(
        mpn=item["mpn"], mpn_key=item["mpn_key"], pdf_path=Path("/tmp/x.pdf"),
        pdf_sha256=item.get("pdf_sha256") or "", url=item.get("pdf_url") or "",
        item=item, json_path="", doc=None, slice=None, slice_root=None, out_dir=None))
    monkeypatch.setattr(T, "_v2_attach_slice", lambda ctx: True)
    return calls


def _res(stage: str, status: str, **kw) -> C.StageResult:
    return C.StageResult(stage=stage, status=status, ms=kw.pop("ms", 12),
                         detail=kw.pop("detail", {}), **kw)


# ------------------------------------------------------------------ 1. 队列

def test_five_stages_map_to_five_queues():
    """五段链路必须落在五个**不同**的队列上（这就是"槽位分离"的定义）。"""
    kinds = ["fetch_item", "preprocess_item", "llm_item_v2", "audit_item_v2",
             "render_item_v2"]
    queues = [config.TASK_QUEUE[k] for k in kinds]
    assert queues == [config.FETCH_QUEUE, config.PREPROCESS_QUEUE,
                      config.CELERY_QUEUE, config.AUDIT_QUEUE, config.RENDER_QUEUE]
    assert len(set(queues)) == 5, f"五段有队列复用：{queues}"


def test_new_queues_are_distinct_from_old_three():
    """新队列名不能和老的三个撞（撞了等于没加，还会把 CPU 活塞进贵槽位）。"""
    old = {config.FETCH_QUEUE, config.CELERY_QUEUE, config.RENDER_QUEUE}
    assert config.PREPROCESS_QUEUE not in old
    assert config.AUDIT_QUEUE not in old
    assert config.PREPROCESS_QUEUE != config.AUDIT_QUEUE


def test_celery_declares_all_five_queues_and_routes():
    """celery_app 里必须显式声明五个队列 + 四条 v2 路由。"""
    from worker.celery_app import app
    names = {q.name for q in app.conf.task_queues}
    assert names == {config.FETCH_QUEUE, config.PREPROCESS_QUEUE,
                     config.CELERY_QUEUE, config.AUDIT_QUEUE, config.RENDER_QUEUE}
    for kind in ("preprocess_item", "llm_item_v2", "audit_item_v2", "render_item_v2"):
        route = app.conf.task_routes.get(f"icpdf.{kind}")
        assert route and route["queue"] == config.TASK_QUEUE[kind], f"{kind} 没有路由"


def test_v2_task_names_do_not_collide_with_old_ones():
    """v2 任务名带 _v2 后缀：旧 worker 的按名注册表里不能出现它。"""
    from worker.celery_app import app
    names = set(app.tasks)
    for old in ("icpdf.llm_item", "icpdf.render_item"):
        assert old in names, f"旧任务 {old} 丢了 —— 老队列会立刻哑火"
    assert "icpdf.llm_item_v2" in names and "icpdf.llm_item" != "icpdf.llm_item_v2"
    # 四个新任务全部注册
    for kind in ("preprocess_item", "llm_item_v2", "audit_item_v2", "render_item_v2"):
        assert f"icpdf.{kind}" in names


# ------------------------------------------------------------------ 2. 开关

def test_switch_defaults_off():
    """默认必须是关的：灰度没批之前，任何环境的默认行为都只能是老单链。"""
    assert C.v2_enabled({}) is False
    assert C.v2_enabled({"ICPDF_PIPELINE_V2": "0"}) is False
    for on in ("1", "true", "TRUE", "yes", "on"):
        assert C.v2_enabled({"ICPDF_PIPELINE_V2": on}) is True
    # 本机 .env.local 没有这一项 -> config 里必须是 False
    assert config.PIPELINE_V2 is False


# ------------------------------------------------------------------ 3. 分叉

def test_fetch_fork_off_dispatches_old_llm(wire, monkeypatch):
    wire["item"] = _item()
    monkeypatch.setattr(config, "PIPELINE_V2", False)
    monkeypatch.setattr(T.pipeline, "fetch_stage",
                        lambda item, **k: {"ok": True, "pdf": "/tmp/x.pdf",
                                           "url": "u", "sheet_url": ""})
    out = T.fetch_item("LM317")
    assert out["ok"] is True
    assert [c[0] for c in wire["submit"]] == ["llm_item"], \
        "开关关着却没走老单链 —— 灰度回滚会失效"


def test_fetch_fork_on_dispatches_preprocess(wire, monkeypatch):
    wire["item"] = _item()
    monkeypatch.setattr(config, "PIPELINE_V2", True)
    monkeypatch.setattr(T.pipeline, "fetch_stage",
                        lambda item, **k: {"ok": True, "pdf": "/tmp/x.pdf",
                                           "url": "u", "sheet_url": ""})
    T.fetch_item("LM317")
    assert [c[0] for c in wire["submit"]] == ["preprocess_item"]


def test_fetch_fork_does_not_dispatch_when_skipped(wire, monkeypatch):
    """去重跳过是终态，不能往下游投 —— 否则重投一次就多烧一次模型。"""
    wire["item"] = _item(status="done")
    monkeypatch.setattr(config, "PIPELINE_V2", True)
    monkeypatch.setattr(T.pipeline, "fetch_stage",
                        lambda item, **k: {"ok": True, "skipped": True,
                                           "reason": "already_parsed"})
    T.fetch_item("LM317")
    assert wire["submit"] == []


# ------------------------------------------------------------------ 4. 接力

def test_preprocess_success_dispatches_llm_v2(wire, monkeypatch):
    wire["item"] = _item()
    ST = _ST()
    monkeypatch.setattr(ST, "stage_preprocess",
                        lambda ctx: _res("preprocess", C.STATUS_OK,
                                         detail={"text_sha256": "b" * 64}))
    out = T.preprocess_item("LM317")
    assert out["ok"] is True and out["next"] == "llm_item_v2"
    assert [c[0] for c in wire["submit"]] == ["llm_item_v2"]


def test_preprocess_skipped_stops_chain(wire, monkeypatch):
    """不是 datasheet -> skipped 且链路立即停，不投 LLM。"""
    ST = _ST()
    wire["item"] = _item()
    monkeypatch.setattr(ST, "stage_preprocess",
                        lambda ctx: _res("preprocess", C.STATUS_SKIPPED,
                                         error="NOT_A_DATASHEET"))
    out = T.preprocess_item("LM317")
    assert out["ok"] is False and out["next"] == ""
    assert wire["submit"] == []
    assert wire["status"][-1][1] == "skipped"


def test_preprocess_blocked_marks_failed(wire, monkeypatch):
    """无文本层 -> blocked，业务态记 failed（老链同样的口径）。"""
    ST = _ST()
    wire["item"] = _item()
    monkeypatch.setattr(ST, "stage_preprocess",
                        lambda ctx: _res("preprocess", C.STATUS_BLOCKED,
                                         error="PDF_UNREADABLE"))
    T.preprocess_item("LM317")
    assert wire["status"][-1][1] == "failed"
    assert wire["submit"] == []


def test_llm_v2_persists_json_path(wire, monkeypatch):
    """JSON 路径必须落库：audit/render 是另一个进程，只能从 item 行拿。"""
    ST = _ST()
    wire["item"] = _item()

    def fake(ctx):
        ctx.json_path = "/data/parsed/LM317_deadbeef.json"
        return _res("llm", C.STATUS_OK, detail={"model": "qwen-flash"})

    monkeypatch.setattr(ST, "stage_llm", fake)
    out = T.llm_item_v2("LM317")
    assert out["ok"] is True and out["next"] == "audit_item_v2"
    assert wire["set_item"], "没把 json_path 写回 item 行"
    assert wire["set_item"][-1][1]["json_path"].endswith(".json")
    assert [c[0] for c in wire["submit"]] == ["audit_item_v2"]


def test_llm_v2_cached_does_not_bump_parse_count(wire, monkeypatch):
    """缓存命中不许累加 `parse_count` / 覆盖 `parse_ms`。

    灰度期就是靠这两个数判断「有没有重复烧 token」。命中缓存却记一次 24ms 的
    解析，等于把"没花钱"写成"花了一次、而且特别快"，指标从此不可用。
    """
    wire["item"] = _item(parse_count=2)
    ST = _ST()

    def fake(ctx):
        ctx.json_path = "/data/parsed/LM317_deadbeef.json"
        return _res("llm", C.STATUS_CACHED)

    monkeypatch.setattr(ST, "stage_llm", fake)
    T.llm_item_v2("LM317")
    fields = wire["set_item"][-1][1]
    assert fields["json_path"].endswith(".json")
    assert "parse_count" not in fields and "parse_ms" not in fields, \
        "缓存命中却把解析次数/耗时写成了新记录"


def test_llm_v2_missing_slice_does_not_reextract(wire, monkeypatch):
    """缺切片时**不许**静默重抽，也不许调模型 —— 只能 blocked 让上游补投。"""
    wire["item"] = _item()
    monkeypatch.setattr(T, "_v2_attach_slice", lambda ctx: False)
    called = {"llm": 0}
    monkeypatch.setattr(T.pipeline, "parse_pdf",
                        lambda *a, **k: called.__setitem__("llm", called["llm"] + 1))
    out = T.llm_item_v2("LM317")
    assert out["status"] == "blocked" and out["reason"] == "no_slice"
    assert called["llm"] == 0, "缺切片却调了模型 —— 阶段账会算不出来"
    assert wire["submit"] == []


def test_audit_success_dispatches_render_v2(wire, monkeypatch):
    wire["item"] = _item(json_path="/tmp/x.json")
    ST = _ST()
    monkeypatch.setattr(T, "_v2_json", lambda item: (Path("/tmp/x.json"), "/tmp/x.json"))
    monkeypatch.setattr(ST, "stage_audit",
                        lambda ctx: _res("audit", C.STATUS_OK,
                                         detail={"findings": 3, "write": False}))
    out = T.audit_item_v2("LM317")
    assert out["ok"] is True and out["next"] == "render_item_v2"
    assert wire["submit"][-1][0] == "render_item_v2"


def test_audit_never_asks_for_write():
    """链路里 audit 恒 write=False：自动打补丁会让两种 JSON 混在一起。

    只扫 V2 那一段代码 —— 老 `qc_audit_item` 的 `write=True` 是人工/QC 流程的
    显式入口，本来就该保留，不能被这条守卫误伤。
    """
    src = (ROOT / "worker" / "tasks.py").read_text(encoding="utf-8")
    v2 = src.split("五段链路（V2）", 1)[1].split("\ndef parse_many", 1)[0]
    code = "\n".join(ln for ln in v2.splitlines()
                     if not ln.lstrip().startswith("#"))
    assert "write=True" not in code, "任务层打开了 audit 的写回 —— 必须人工/QC 流程发起"
    body = code.split("def audit_item_v2", 1)[1]
    assert "write=" not in body, "audit_item_v2 自己传了 write，应交给阶段层默认值"


def test_render_v2_without_json_keeps_status(wire, monkeypatch):
    """没有 JSON 时不改状态（等重跑），与老 render_item 同一处置。"""
    wire["item"] = _item()
    monkeypatch.setattr(T, "_v2_json", lambda item: (None, ""))
    out = T.render_item_v2("LM317")
    assert out["status"] == "blocked" and out["reason"] == "no_json"
    assert wire["status"] == []


def test_render_v2_cached_restores_done(wire, monkeypatch):
    """render 命中缓存时补写 done。

    缓存命中意味着这次没跑 `finish_item`，而 `done` 是它写的。不补的话，
    一件已交付的货会因为一条重复消息永久停在 `rendering` —— 工作台像卡住，
    统计少一件。这是「重复投递」在业务态上唯一能造成真实伤害的地方。
    """
    wire["item"] = _item(json_path="/tmp/x.json", status="rendering")
    ST = _ST()
    monkeypatch.setattr(T, "_v2_json", lambda item: (Path("/tmp/x.json"), "/tmp/x.json"))
    monkeypatch.setattr(ST, "stage_render",
                        lambda ctx: _res("render", C.STATUS_CACHED,
                                         artifact="/data/txt/x.txt"))
    out = T.render_item_v2("LM317")
    assert out["ok"] is True
    assert wire["status"][-1][1] == "done", "缓存命中没把状态补回 done"


def test_render_v2_terminal_state(wire, monkeypatch):
    """最后一段不投任何下游，避免链路自己接成环。"""
    ST = _ST()
    wire["item"] = _item(json_path="/tmp/x.json")
    monkeypatch.setattr(T, "_v2_json", lambda item: (Path("/tmp/x.json"), "/tmp/x.json"))
    monkeypatch.setattr(ST, "stage_render",
                        lambda ctx: _res("render", C.STATUS_OK, artifact="/data/txt/x.txt"))
    out = T.render_item_v2("LM317")
    assert out["ok"] is True and out["next"] == ""
    assert wire["submit"] == []


# ------------------------------------------------------------------ 5. 旧链路仍在

def test_old_functions_untouched():
    """老三个纯函数仍在 FUNCS 里（inline 降级路径靠它）。"""
    for k in ("fetch_item", "llm_item", "render_item", "parse_item"):
        assert k in T.FUNCS and k in T.CELERY_TASKS


def test_v2_does_not_change_old_task_bodies():
    """`llm_item` / `render_item` 的函数体必须还是老三步的样子。

    做法：读源码，确认这两个函数里没有出现任何阶段层的调用 —— 老队列的语义
    一旦掺进新链路，出问题时连"是哪条链跑坏的"都分不清。
    """
    src = (ROOT / "worker" / "tasks.py").read_text(encoding="utf-8")
    for name in ("def llm_item(", "def render_item("):
        body = src.split(name, 1)[1].split("\ndef ", 1)[0]
        # 只看代码行：紧跟其后的 V2 说明性注释里本来就会提到 app.pipeline
        code = "\n".join(ln for ln in body.splitlines()
                         if not ln.lstrip().startswith("#"))
        assert "app.pipeline" not in code and "stage_" not in code, \
            f"{name} 被新链路污染了"
