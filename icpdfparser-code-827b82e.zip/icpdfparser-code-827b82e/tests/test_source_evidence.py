"""原厂证据卡（Source Evidence Registry）离线单测。

覆盖方案 §9 的验收点：
  * 文件名/域名正确 ≠ 身份已验证（官方 PDF 未覆盖目标 MPN → source_unresolved）
  * 第三方来源即使给出数值也不得通过身份核验
  * 身份已确认但字段缺页码 / 缺核验人 → 不得冻结
  * 冻结守卫（来源/身份/覆盖/字段证据/哈希一致性）
不发网络请求；DB 用临时 SQLite（DDL 复用 SOURCE_DDL 单一来源）。
"""
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import source_evidence as se                 # noqa: E402

MINI_DDL = """
CREATE TABLE IF NOT EXISTS gold_set (
    id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT NOT NULL DEFAULT 'v1',
    mpn TEXT NOT NULL, manufacturer TEXT NOT NULL DEFAULT '',
    pdf_name TEXT NOT NULL DEFAULT '', pdf_sha256 TEXT NOT NULL DEFAULT '',
    doc_rev TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'draft',
    risk_tags TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gold_field (
    id INTEGER PRIMARY KEY AUTOINCREMENT, gold_id INTEGER NOT NULL,
    field_path TEXT NOT NULL, field_name TEXT NOT NULL DEFAULT '',
    expected TEXT NOT NULL DEFAULT '', unit TEXT NOT NULL DEFAULT '',
    cond TEXT NOT NULL DEFAULT '', page_no INTEGER NOT NULL DEFAULT 0,
    evidence TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending',
    verified_by TEXT NOT NULL DEFAULT '', verified_at TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS gold_review_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, gold_id INTEGER NOT NULL,
    field_id INTEGER NOT NULL DEFAULT 0, action TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '', operator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS risk_case (
    id INTEGER PRIMARY KEY AUTOINCREMENT, mpn TEXT NOT NULL, kind TEXT NOT NULL DEFAULT '',
    finding_id INTEGER NOT NULL DEFAULT 0, priority TEXT NOT NULL DEFAULT 'P2',
    reason TEXT NOT NULL DEFAULT '', score REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'open', operator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
"""


class FakeDB:
    """只实现 qc/source_evidence.py 用到的 q/q1/x 三个接口。"""

    def __init__(self, path: Path):
        self.c = sqlite3.connect(str(path))
        self.c.row_factory = sqlite3.Row
        self.c.executescript(se.SOURCE_DDL + MINI_DDL)
        self.c.commit()

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args)]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None

    def x(self, sql, args=()):
        cur = self.c.execute(sql, args)
        self.c.commit()
        return cur.lastrowid


def _sample_pdf() -> Path:
    for p in sorted((ROOT / "qc" / "pdfs").glob("*.pdf")):
        return p
    raise unittest.SkipTest("qc/pdfs 下没有样本 PDF")


class DomainTest(unittest.TestCase):
    def test_official_domain_hit(self):
        self.assertTrue(se.is_official_url("https://www.ti.com/lit/ds/symlink/buf634.pdf", "TI"))
        self.assertTrue(se.is_official_url("https://ti.com/x.pdf", "Texas Instruments"))
        self.assertTrue(se.is_official_url("https://www.analog.com/x.pdf", "ADI"))

    def test_evil_subdomain_rejected(self):
        self.assertFalse(se.is_official_url("https://ti.com.evil.com/x.pdf", "TI"))
        self.assertFalse(se.is_official_url("https://www.ti-cn.com/x.pdf", "TI"))

    def test_third_party_rejected(self):
        self.assertFalse(se.is_official_url("https://www.alldatasheet.com/view.jsp?x=BUF634", "TI"))
        # 品牌名出现在 URL 路径里不算官方
        self.assertFalse(se.is_official_url("https://example.com/TI/BUF634.pdf", "TI"))

    def test_unknown_manufacturer_rejected(self):
        self.assertFalse(se.is_official_url("https://www.ti.com/x.pdf", "未知厂商"))


class InspectTest(unittest.TestCase):
    def test_missing_file_is_unresolved(self):
        with tempfile.TemporaryDirectory() as td:
            out = se.inspect_pdf(Path(td) / "nope.pdf", "https://www.ti.com/x.pdf", "TI")
        self.assertEqual(out["identity_status"], "unresolved")
        self.assertIn("不存在", out["identity_notes"])

    def test_real_pdf_pending_not_verified(self):
        out = se.inspect_pdf(_sample_pdf(), "https://www.ti.com/x.pdf", "TI")
        self.assertTrue(out["ok"])
        self.assertEqual(len(out["pdf_sha256"]), 64)
        self.assertGreater(out["page_count"], 0)
        self.assertTrue(out["is_official"])
        # 关键：官方来源也只是 pending，必须人工确认覆盖范围
        self.assertEqual(out["identity_status"], "pending")

    def test_non_official_url_note(self):
        out = se.inspect_pdf(_sample_pdf(), "https://example.com/x.pdf", "TI")
        self.assertFalse(out["is_official"])
        self.assertIn("不在官方白名单", out["identity_notes"])


class ConfirmIdentityTest(unittest.TestCase):
    def test_requires_reviewer(self):
        with self.assertRaises(ValueError):
            se.confirm_identity("BUF634PG4", ["BUF634PG4"], True, "  ")

    def test_requires_official(self):
        with self.assertRaises(ValueError):
            se.confirm_identity("BUF634PG4", ["BUF634PG4"], False, "esan")

    def test_not_covered_goes_unresolved(self):
        """官方 PDF 覆盖系列但无法确认目标后缀 → source_unresolved。"""
        res = se.confirm_identity("BUF634PG4", ["BUF634"], True, "esan", "系列页未列 PG4 后缀")
        self.assertEqual(res["identity_status"], "unresolved")
        self.assertIn("未能确认", res["identity_notes"])

    def test_covered_verified(self):
        res = se.confirm_identity("BUF634PG4", ["buf634pg4", "BUF634"], True, "esan", "P0 文档")
        self.assertEqual(res["identity_status"], "verified")
        self.assertEqual(json.loads(res["covered_mpn_json"]), ["BUF634PG4", "BUF634"])


class FreezeGuardTest(unittest.TestCase):
    def setUp(self):
        self.ev = {"mpn": "BUF634PG4", "status": "field_review", "gold_pdf_sha256": "abc"}
        self.doc = {"identity_status": "verified", "is_official": 1,
                    "covered_mpn_json": '["BUF634PG4"]', "pdf_sha256": "abc"}
        self.fields = [{"field_path": "pins.V_PLUS.pin_number", "page_number": 12,
                        "reviewer": "esan", "verification_status": "verified"}]
        self.gold = [{"field_path": "pins.V_PLUS.pin_number"}]

    def test_pass(self):
        ok, why = se.can_freeze(self.ev, self.doc, self.fields, self.gold)
        self.assertTrue(ok, why)

    def test_source_unresolved_blocked(self):
        ev = dict(self.ev, status="source_unresolved")
        ok, why = se.can_freeze(ev, self.doc, self.fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("source_unresolved", why)

    def test_identity_not_verified_blocked(self):
        doc = dict(self.doc, identity_status="pending")
        ok, why = se.can_freeze(self.ev, doc, self.fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("身份", why)

    def test_non_official_blocked(self):
        doc = dict(self.doc, is_official=0)
        ok, why = se.can_freeze(self.ev, doc, self.fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("官方", why)

    def test_not_covered_blocked(self):
        doc = dict(self.doc, covered_mpn_json='["BUF634"]')
        ok, why = se.can_freeze(self.ev, doc, self.fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("覆盖范围", why)

    def test_no_field_evidence_blocked(self):
        ok, why = se.can_freeze(self.ev, self.doc, [], self.gold)
        self.assertFalse(ok)
        self.assertIn("字段级证据", why)

    def test_missing_page_blocked(self):
        fields = [dict(self.fields[0], page_number=0)]
        ok, why = se.can_freeze(self.ev, self.doc, fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("页码", why)

    def test_missing_reviewer_blocked(self):
        fields = [dict(self.fields[0], reviewer="")]
        ok, why = se.can_freeze(self.ev, self.doc, fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("核验人", why)

    def test_unverified_field_blocked(self):
        fields = [dict(self.fields[0], verification_status="pending")]
        ok, why = se.can_freeze(self.ev, self.doc, fields, self.gold)
        self.assertFalse(ok)

    def test_gold_field_without_evidence_blocked(self):
        gold = self.gold + [{"field_path": "specs.package.type"}]
        ok, why = se.can_freeze(self.ev, self.doc, self.fields, gold)
        self.assertFalse(ok)
        self.assertIn("缺少已核验证据", why)

    def test_sha_mismatch_blocked(self):
        ev = dict(self.ev, gold_pdf_sha256="deadbeef")
        ok, why = se.can_freeze(ev, self.doc, self.fields, self.gold)
        self.assertFalse(ok)
        self.assertIn("哈希", why)


class RegistryFlowTest(unittest.TestCase):
    """DB 编排：建卡 → 登记文档 → 身份未通过 → 风险任务 → 补证据 → 冻结。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = FakeDB(Path(self.tmp.name) / "t.sqlite3")
        self.pdf = _sample_pdf()

    def tearDown(self):
        try:
            self.db.c.close()          # Windows 下不关连接会锁住临时库文件
        finally:
            self.tmp.cleanup()

    def test_flow_unresolved_then_verified(self):
        eid = se.create_evidence("BUF634PG4", "TI", ["pins.V_PLUS.pin_number"], "esan", self.db)
        self.assertEqual(eid, se.create_evidence("BUF634PG4", "TI", [], "esan", self.db))

        out = se.add_document(eid, "P0", "https://www.ti.com/lit/x.pdf", str(self.pdf),
                              "datasheet_pdf", "esan", self.db)
        self.assertTrue(out["inspection"]["is_official"])
        self.assertFalse(out["reused"])

        # 覆盖型号不含目标 → source_unresolved + 风险任务
        res = se.verify_identity(eid, "esan", ["BUF634"], "系列页", "esan", self.db)
        self.assertEqual(res["identity_status"], "unresolved")
        self.assertEqual(self.db.q1("SELECT status FROM source_evidence WHERE id=?", (eid,))["status"],
                         "source_unresolved")
        self.assertEqual(self.db.q1("SELECT count(*) n FROM risk_case")["n"], 1)
        self.assertEqual(self.db.q1("SELECT kind FROM risk_case")["kind"], "identity_unverified")

        # 重新人工确认通过 → field_review
        res2 = se.verify_identity(eid, "esan", ["BUF634PG4"], "P0 datasheet 明确列 PG4", "esan", self.db)
        self.assertEqual(res2["identity_status"], "verified")

        # 字段证据：无页码不得核验
        fe0 = se.add_field_evidence(eid, "pins.V_PLUS.pin_number", 0, operator="esan", db_mod=self.db)
        with self.assertRaises(ValueError):
            se.verify_field(fe0, "esan", self.db)

        gid = self.db.x("INSERT INTO gold_set(version,mpn,pdf_sha256,status,created_at,updated_at)"
                        " VALUES('v1','BUF634PG4',?, 'review',?,?)",
                        (out["inspection"]["pdf_sha256"], se.now(), se.now()))
        gfid = self.db.x("INSERT INTO gold_field(gold_id,field_path,expected,status) "
                         "VALUES(?,?,'7','pending')", (gid, "pins.V_PLUS.pin_number"))
        fe1 = se.add_field_evidence(eid, "pins.V_PLUS.pin_number", 12,
                                    "Table 5-1 Pin Functions", "V+", "D (SOIC)", "7",
                                    gold_field_id=gfid, operator="esan", db_mod=self.db)
        se.verify_field(fe1, "esan", self.db)
        self.assertEqual(self.db.q1("SELECT status FROM gold_field WHERE id=?", (gfid,))["status"],
                         "verified")

        out = se.freeze(eid, gid, "esan", self.db)
        self.assertTrue(out["ok"])
        self.assertEqual(self.db.q1("SELECT status FROM gold_set WHERE id=?", (gid,))["status"],
                         "frozen")
        self.assertEqual(self.db.q1("SELECT status FROM source_evidence WHERE id=?", (eid,))["status"],
                         "frozen")
        logs = [r["action"] for r in self.db.q("SELECT action FROM source_verification_log")]
        self.assertIn("gold_frozen", logs)

    def test_same_sha_reused_within_evidence(self):
        eid = se.create_evidence("CD74FCT244SM96", "TI", [], "esan", self.db)
        a = se.add_document(eid, "P0", "https://www.ti.com/a.pdf", str(self.pdf), "datasheet_pdf",
                            "esan", self.db)
        b = se.add_document(eid, "P0", "https://www.ti.com/b.pdf", str(self.pdf), "datasheet_pdf",
                            "esan", self.db)
        self.assertFalse(a["reused"])
        self.assertTrue(b["reused"])
        self.assertEqual(a["document_id"], b["document_id"])
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_document")["n"], 1)

    def test_status_change_requires_reason(self):
        eid = se.create_evidence("DAC8555IPWG4", "TI", [], "esan", self.db)
        with self.assertRaises(ValueError):
            se.set_evidence_status(eid, "conflict", "", "esan", self.db)
        out = se.set_evidence_status(eid, "conflict", "两份原厂 PDF 参数不一致", "esan", self.db)
        self.assertEqual(out["status"], "conflict")
        self.assertEqual(out["risk_added"], 1)

    def test_partial_target_fields_blocked(self):
        """target_fields 只覆盖部分字段时，不得冻结整件 Gold。"""
        eid = se.create_evidence("BUF634PG4", "TI", ["pins.V_PLUS.pin_number"], "esan", self.db)
        out = se.add_document(eid, "P0", "https://www.ti.com/lit/x.pdf", str(self.pdf),
                              "datasheet_pdf", "esan", self.db)
        se.verify_identity(eid, "esan", ["BUF634PG4"], "", "esan", self.db)
        gid = self.db.x("INSERT INTO gold_set(version,mpn,pdf_sha256,status,created_at,updated_at)"
                        " VALUES('v1','BUF634PG4',?, 'review',?,?)",
                        (out["inspection"]["pdf_sha256"], se.now(), se.now()))
        self.db.x("INSERT INTO gold_field(gold_id,field_path,expected,status) "
                  "VALUES(?,?,'7','pending')", (gid, "pins.V_PLUS.pin_number"))
        self.db.x("INSERT INTO gold_field(gold_id,field_path,expected,status) "
                  "VALUES(?,?,'SOIC','pending')", (gid, "specs.package.type"))
        fe = se.add_field_evidence(eid, "pins.V_PLUS.pin_number", 12, operator="esan",
                                   db_mod=self.db)
        se.verify_field(fe, "esan", self.db)
        with self.assertRaises(ValueError) as cm:
            se.freeze(eid, gid, "esan", self.db)
        self.assertIn("未覆盖整件", str(cm.exception))
        self.assertEqual(self.db.q1("SELECT status FROM gold_set WHERE id=?", (gid,))["status"],
                         "review")


if __name__ == "__main__":
    unittest.main()
