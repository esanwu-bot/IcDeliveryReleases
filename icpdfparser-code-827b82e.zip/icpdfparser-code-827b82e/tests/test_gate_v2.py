#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v2 门禁判据的单测（判据本身的可信度靠这些用例钉死）。

为什么必须先测判据：门禁是用来判定 prompt 的，判据自己错了就会
「用没验证过的判据判定样本」，结论看着像对的但方向可能相反——
本项目实证过一次：初版判据拿 PDF 全文取证，导致 v1 编数拿高分、
v2 承认看不到被扣分。

用法：D:/Program Files (x86)/python/python.exe -m pytest tests/test_gate_v2.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "qc"))

import prompt_dryrun as G                                    # noqa: E402

NOT_SPEC = "not_specified"


# ── 模式 A：人工三列（不依赖 PDF，最纯粹的分类逻辑）──────────────────────

def test_all_placeholder_v2_notspec():
    """三列全占位符 + 标 not_specified = 正确降级，不计坏行。"""
    assert G.classify("X", "Power Dissipation", NOT_SPEC, ["-", "—", ""]) == \
        G.GOOD_NOT_SPECIFIED


def test_all_placeholder_v2_empty():
    """三列全占位符却只留空 = 该标没标。"""
    assert G.classify("X", "Power Dissipation", "", ["-", "—", ""]) == \
        G.BAD_MISSING_NOT_SPEC


def test_all_placeholder_v2_fabricated():
    """三列全占位符却给了数 = 编数，最严重。"""
    assert G.classify("X", "Power Dissipation", "2.3 mW", ["-", "—", ""]) == \
        G.BAD_FABRICATED_VALUE


def test_has_value_v2_empty():
    """三列有值却留空 = 塌缩规则没生效。"""
    assert G.classify("X", "VIL", "", ["-", "-", "0.8"]) == G.BAD_MISSING_VALUE


def test_has_value_v2_notspec_is_bad():
    """三列有值却标 not_specified = 有值没抽到，同样是坏行。"""
    assert G.classify("X", "VIL", NOT_SPEC, ["-", "-", "0.8"]) == G.BAD_MISSING_VALUE


def test_has_value_v2_value():
    """三列有值且抽到了其中一列的原文 = 好值。"""
    assert G.classify("X", "VIL", "0.8", ["-", "-", "0.8"]) == G.GOOD_VALUE


def test_min_only_value_matches_min():
    """下限约束（只有 MIN 有值）必须取 MIN，不能取 MAX —— 3b 修正的核心动机。"""
    assert G.classify("X", "VIH", "2.0", ["2.0", "-", "-"]) == G.GOOD_VALUE


def test_range_value_contains_both_bounds():
    """范围型（MIN+MAX）的 `a~b` 形态，两端都能对上原文。"""
    assert G.classify("X", "Vpp", "1.0~3.0", ["1.0", "-", "3.0"]) == \
        G.GOOD_VALUE


def test_has_value_but_no_match():
    """给了值但三列里对不上 = 存疑，需要人工看。"""
    assert G.classify("X", "VIL", "1.7", ["-", "-", "0.8"]) == \
        G.VALUE_PROVIDED_BUT_NO_EXACT_MATCH


def test_missing_row_is_bad():
    """v2 整行缺失按漏值计。"""
    assert G.classify("X", "VIL", "<MISSING_ROW>", ["-", "-", "0.8"]) == \
        G.BAD_MISSING_VALUE


def test_tbd_treated_as_placeholder():
    """TBD 与 n/a 一样算占位符，不能当成有值。"""
    assert G.classify("X", "PD", NOT_SPEC, ["TBD", "TBD", "N/A"]) == \
        G.GOOD_NOT_SPECIFIED


# ── 模式 B：上下文自动取证（mock 掉上下文，测判定分支）────────────────────

@pytest.fixture
def ctx(monkeypatch):
    """替换上下文取证：给一段固定正文，避免依赖真实 PDF。"""
    def _set(text: str):
        monkeypatch.setattr(G, "_ctx_text", lambda mpn: text)
        G._CTX_CACHE.clear()
    return _set


def test_ctx_no_evidence_is_unknown(ctx):
    """取不到上下文时不判坏，避免误伤。"""
    ctx("")
    assert G.classify("X", "Gain", "0 dB~12 dB") == G.UNKNOWN_ORIG


def test_value_equals_name_is_bad(ctx):
    """value 回灌 name：DAC37J84 实证，Features 条目被误当电气行。"""
    ctx("anything here")
    assert G.classify("X", "On-Chip Very Low Jitter PLL",
                      "On-Chip Very Low Jitter PLL") == G.BAD_ECHO_NAME


def test_value_from_condition_is_good(ctx):
    """值不在表内但数字在 condition 里有出处 = 不是编数。

    AFE4490RHAT 的实证：condition 写 "Programmable to 0 dB, 3.5 dB, 6 dB,
    9.5 dB, and 12 dB"，value 取 "0 dB~12 dB"。
    """
    ctx("Ambient Cancellation Stage, Gain parameter in Electrical "
        "Characteristics table .... 11")
    assert G.classify(
        "X", "Ambient Cancellation Stage, Gain", "0 dB~12 dB",
        condition="Programmable to 0 dB, 3.5 dB, 6 dB, 9.5 dB, and 12 dB",
    ) == G.GOOD_VALUE_IN_COND


def test_ctx_has_number_but_value_empty(ctx):
    """上下文有数值却留空 = 漏抽。"""
    ctx("Quiescent Current ICC — 5 500 µA")
    assert G.classify("X", "Quiescent Current", "") == G.BAD_MISSING_VALUE


def test_ctx_has_number_and_value_present(ctx):
    """上下文有数值且抽到了 = 好值。"""
    ctx("Quiescent Current ICC — 5 500 µA")
    assert G.classify("X", "Quiescent Current", "500 µA") == G.GOOD_VALUE


def test_ctx_no_number_and_notspec(ctx):
    """上下文确无数值 + 标 not_specified = 正确降级。"""
    ctx("Power Dissipation After reset LED_DRV_SUP typical")
    assert G.classify("X", "Power Dissipation", NOT_SPEC) == \
        G.GOOD_NOT_SPECIFIED


def test_revision_history_dots_not_counted_as_value(ctx):
    """修订记录里的点线数字是页码，不能当作数值证据。"""
    ctx("Changed Power Dissipation .......... 14")
    # 名字出现但数值被点线过滤 → 有名无值 → 标 not_specified 是对的
    assert G.classify("X", "Power Dissipation", NOT_SPEC) == \
        G.GOOD_NOT_SPECIFIED


# ── gate 汇总口径 ──────────────────────────────────────────────────────

def _doc(rows):
    return {"specs": {"electrical": rows,
                      "absolute_max": [{"name": "Tstg", "value": "-55~150"}]}}


def test_gate_pass_when_no_bad(monkeypatch):
    monkeypatch.setattr(G, "classify", lambda *a, **k: G.GOOD_VALUE)
    g = G.gate_v2_sample("X", _doc([{"name": "a", "value": "1"}]),
                         _doc([{"name": "a", "value": "1"}]))
    assert g["verdict"] == "PASS" and g["bad_total"] == 0


def test_gate_fail_on_fabricated(monkeypatch):
    monkeypatch.setattr(G, "classify", lambda *a, **k: G.BAD_FABRICATED_VALUE)
    g = G.gate_v2_sample("X", _doc([{"name": "a", "value": "1"}]),
                         _doc([{"name": "a", "value": "9"}]))
    assert g["verdict"] == "FAIL" and g["bad_total"] >= 1


def test_gate_warn_on_missing_only(monkeypatch):
    monkeypatch.setattr(G, "classify", lambda *a, **k: G.BAD_MISSING_VALUE)
    g = G.gate_v2_sample("X", _doc([{"name": "a", "value": "1"}]),
                         _doc([{"name": "a", "value": ""}]))
    assert g["verdict"] == "WARN"


def test_gate_all_rows_uses_electrical_plus_abs_max(monkeypatch):
    """行数按 electrical + absolute_max 合并算：v2 把 abs_max 归位不该算丢表。"""
    monkeypatch.setattr(G, "classify", lambda *a, **k: G.GOOD_VALUE)
    g = G.gate_v2_sample("X", _doc([{"name": "a", "value": "1"}]),
                         _doc([{"name": "a", "value": "1"}]))
    assert g["all_rows_v1"] == 2 and g["all_rows_v2"] == 2


def test_gate_counts_dropped_rows(monkeypatch):
    """v1 有、v2 没有的行要单独计数，不能静默吞掉。"""
    monkeypatch.setattr(G, "classify", lambda *a, **k: G.GOOD_VALUE)
    v1 = _doc([{"name": "a", "value": "1"}, {"name": "b", "value": "2"}])
    v2 = _doc([{"name": "a", "value": "1"}])
    g = G.gate_v2_sample("X", v1, v2)
    assert g["counts"]["_DROPPED_ROWS"] == 1
