"""qc/cheatsheet.py 离线单测 + Gold 核验口径守卫（手册硬约束）。

不发网络请求；DB 用临时 SQLite（复用 app/db.py 的 DDL 单一来源）。
"""
import io
import contextlib
import importlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import cheatsheet as C                        # noqa: E402


def F(p, **kw):
    return {"field_path": p, **kw}


class RiskTest(unittest.TestCase):
    def test_identity_package_high(self):
        for p in ("basic_info.mpn", "basic_info.manufacturer",
                  "specs.package.type", "specs.package.pins"):
            self.assertEqual(C.risk_of(p), "高·quote", p)

    def test_current_electrical_high(self):
        self.assertEqual(C.risk_of("electrical[10].value", "IDD normal", "µA"), "高·quote")
        self.assertEqual(C.risk_of("electrical[11].value", "Supply current", ""), "高·quote")
        self.assertEqual(C.risk_of("electrical[0].value", "Resolution", "Bits"), "中")

    def test_pin_and_narrative(self):
        self.assertEqual(C.risk_of("pin[1].name", expected="VOUTA"), "中")
        # 电源脚 / 基准脚名 → 高（手册 §3.1；VREFH/VREFL 错接即设计失败）
        self.assertEqual(C.risk_of("pin[4].name", expected="AVDD"), "高·quote")
        self.assertEqual(C.risk_of("pin[6].name", expected="GND"), "高·quote")
        self.assertEqual(C.risk_of("pin[12].name", expected="IOVDD"), "高·quote")
        self.assertEqual(C.risk_of("pin[3].name", expected="VREFH"), "高·quote")
        self.assertEqual(C.risk_of("features[2]"), "低")
        self.assertEqual(C.risk_of("basic_info.category"), "低")

    def test_has_quote(self):
        self.assertTrue(C.has_quote('p.7 Table 7-3 IDD 行 MAX 列，原文 "10 µA"'))
        self.assertTrue(C.has_quote('EC 表 原文 0.65mA'))
        self.assertTrue(C.has_quote('p.7 Table 7-3, "10 µA"'))
        self.assertFalse(C.has_quote("p.7 见 PDF 表格"))
        self.assertFalse(C.has_quote(""))


class LocateTest(unittest.TestCase):
    """路径形状对齐线上实测（electrical[i].value / pin[i].name 1-based）。"""

    def test_pass_mapping(self):
        self.assertEqual(C.locate(F("basic_info.mpn"), "X")["pass_"], 1)
        self.assertEqual(C.locate(F("specs.package.type"), "X")["pass_"], 1)
        self.assertEqual(C.locate(F("electrical[3].value", field_name="IDD"), "X")["pass_"], 2)
        self.assertEqual(C.locate(F("pin[4].name"), "X")["pass_"], 2)
        self.assertEqual(C.locate(F("features[2]"), "X")["pass_"], 3)

    def test_pin_number_is_one_based(self):
        """pin[4].name 是 4 号脚（不是第 5 脚）。"""
        L = C.locate(F("pin[4].name", expected="AVDD"), "DAC8555IPWG4")
        self.assertIn("pin 4 行", L["row"])
        self.assertEqual(L["risk"], "高·quote")          # 电源脚 → 高
        L2 = C.locate(F("pin[5].name", expected="VREFL"), "DAC8555IPWG4")
        self.assertIn("pin 5 行", L2["row"])

    def test_legacy_pin_configuration_offset(self):
        self.assertIn("pin 5 行", C.locate(F("pin_configuration[4].name"), "X")["row"])

    def test_electrical_index_matches_json(self):
        doc = {"specs": {"electrical": [{"name": "Resolution", "condition": ""},
                                        {"name": "IDD", "condition": "VA=5V"}]}}
        L = C.locate(F("electrical[1].value", field_name="IDD", unit="µA"), "X", doc)
        self.assertIn("IDD", L["row"])
        self.assertEqual(L["cond"], "VA=5V")

    def test_fsr_row_asks_footnote(self):
        L = C.locate(F("electrical[6].value", field_name="Gain error", unit="% of FSR"), "X")
        self.assertIn("脚注", L["tpl"])
        self.assertIn("footnote_missing", L["sig"])

    def test_unknown_path_falls_back(self):
        L = C.locate(F("ordering_info[3].package"), "X")
        self.assertEqual(L["pass_"], 3)
        self.assertEqual(L["risk"], "低")


class RenderTest(unittest.TestCase):
    def test_groups_and_counts(self):
        fields = [F("basic_info.mpn", expected="DAC8555IPWG4"),
                  F("specs.package.pins", expected="16"),
                  F("electrical[0].value", field_name="IDD", unit="µA", expected="10"),
                  F("pin[4].name", expected="AVDD"),
                  F("features[0]", expected="16-bit")]
        md = C.render_from_fields(fields, "DAC8555IPWG4", signals={"unit_dimension_unresolved"})
        self.assertIn("Pass 1", md) and self.assertIn("Pass 2", md) and self.assertIn("Pass 3", md)
        self.assertIn("高风险 4", md)      # mpn + package.pins + IDD(µA) + pin4 AVDD(电源脚)
        self.assertIn("unit_dimension_unresolved", md)
        self.assertIn("not_specified", md)
        self.assertIn("D1：", md)

    def test_no_signal_no_badge(self):
        md = C.render_from_fields([F("basic_info.category", expected="IC")], "X", signals=set())
        line = [l for l in md.splitlines() if l.startswith("- [ ]")][0]
        self.assertNotIn("信号:", line)
        self.assertIn("（本件无 QC 信号）", md)

    def test_draft_is_marked_p4(self):
        md = C.render_from_fields([F("basic_info.category", expected="Integrated Circuit")],
                                  "X")
        self.assertIn("草稿(P4)", md)

    def test_page_convention_documented(self):
        md = C.render_from_fields([F("basic_info.mpn")], "X")
        self.assertIn("PDF 物理页", md)


class ImportPurityTest(unittest.TestCase):
    def test_import_no_stdout(self):
        """server 进程安全：import 不得往 stdout 写任何东西。"""
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            importlib.reload(C)
        self.assertEqual(buf.getvalue(), "")


class GoldGuardTest(unittest.TestCase):
    """Gold 核验口径：verified 需页码+证据；高风险需 quote；补录可直达 verified。"""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="cheattest_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                             # noqa: E402
        self.db = db
        db.q1("SELECT 1")
        gid = db.x("INSERT INTO gold_set(version,mpn,status,created_at,updated_at)"
                   " VALUES('v1','DAC8555IPWG4','draft',?,?)", (db.qc_now(), db.qc_now()))
        self.gid = gid
        self.fid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                        "cond,page_no,evidence,status) VALUES(?,?,?,?,?,?,0,'','pending')",
                        (gid, "electrical[10].value", "IDD normal", "10", "µA", ""))
        self.pid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                        "cond,page_no,evidence,status) VALUES(?,?,?,?,?,?,0,'','pending')",
                        (gid, "basic_info.category", "category", "IC", "", ""))
        from app.api import qe
        self.qe = qe
        from fastapi import HTTPException
        self.HTTPException = HTTPException

    def tearDown(self):
        try:
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def _upd(self, fid, body):
        return self.qe.gold_field_update(fid, body)

    def test_verified_needs_both_page_and_evidence(self):
        with self.assertRaises(self.HTTPException) as cm:
            self._upd(self.pid, {"status": "verified", "page_no": 0, "evidence": "x"})
        self.assertIn("页码", str(cm.exception.detail))
        with self.assertRaises(self.HTTPException) as cm:
            self._upd(self.pid, {"status": "verified", "page_no": 7, "evidence": "  "})
        self.assertIn("证据定位", str(cm.exception.detail))

    def test_high_risk_requires_quote(self):
        with self.assertRaises(self.HTTPException) as cm:
            self._upd(self.fid, {"status": "verified", "page_no": 7, "evidence": "见 PDF 表格"})
        self.assertIn("quote", str(cm.exception.detail))
        out = self._upd(self.fid, {"status": "verified", "page_no": 7,
                                   "evidence": 'Table 7-3 IDD 行 MAX 列，原文 "10 µA"'})
        self.assertTrue(out["ok"])
        r = self.db.q1("SELECT status, page_no, verified_by FROM gold_field WHERE id=?", (self.fid,))
        self.assertEqual(r["status"], "verified")
        self.assertEqual(r["page_no"], 7)
        self.assertTrue(r["verified_by"])

    def test_low_risk_no_quote_needed(self):
        out = self._upd(self.pid, {"status": "verified", "page_no": 2, "evidence": "封面标题行"})
        self.assertTrue(out["ok"])

    def test_conflict_can_write_pdf_value(self):
        out = self._upd(self.fid, {"status": "conflict", "expected": "0.65",
                                   "page_no": 7, "evidence": "行归属错误，PDF 为 0.65 mA"})
        self.assertTrue(out["ok"])
        r = self.db.q1("SELECT status, expected FROM gold_field WHERE id=?", (self.fid,))
        self.assertEqual(r["status"], "conflict")
        self.assertEqual(r["expected"], "0.65")

    def test_conflict_needs_reason(self):
        with self.assertRaises(self.HTTPException) as cm:
            self._upd(self.fid, {"status": "conflict", "evidence": ""})
        self.assertIn("冲突", str(cm.exception.detail))

    def test_addfield_direct_verified(self):
        r = self.qe.gold_field_add(self.gid, {"field_path": "electrical[48].value",
                                             "field_name": "FSR", "expected": "2.5", "unit": "V",
                                             "page_no": 9, "evidence": "EC 表 FSR 行"})
        self.assertEqual(r["status"], "verified")
        row = self.db.q1("SELECT status, page_no, verified_by FROM gold_field WHERE id=?",
                         (r["field_id"],))
        self.assertEqual(row["status"], "verified")
        self.assertTrue(row["verified_by"])

    def test_addfield_verified_needs_evidence(self):
        with self.assertRaises(self.HTTPException) as cm:
            self.qe.gold_field_add(self.gid, {"field_path": "electrical[49].value",
                                             "status": "verified", "page_no": 9,
                                             "evidence": ""})
        self.assertIn("证据定位", str(cm.exception.detail))

    def test_addfield_high_risk_needs_quote(self):
        # 封装字段恒为高风险
        with self.assertRaises(self.HTTPException) as cm:
            self.qe.gold_field_add(self.gid, {"field_path": "specs.package.type",
                                             "expected": "TSSOP-16", "page_no": 14,
                                             "evidence": "Ordering 表 Package 列"})
        self.assertIn("quote", str(cm.exception.detail))
        # 电源脚名同样高风险
        with self.assertRaises(self.HTTPException) as cm:
            self.qe.gold_field_add(self.gid, {"field_path": "pin[17].name", "expected": "VDD",
                                             "page_no": 4, "evidence": "引脚表"})
        self.assertIn("quote", str(cm.exception.detail))
        # 非电源脚（中风险）不强制 quote
        r = self.qe.gold_field_add(self.gid, {"field_path": "pin[18].name", "expected": "NC",
                                             "page_no": 4, "evidence": "引脚表 pin18 行 NAME 列"})
        self.assertEqual(r["status"], "verified")

    def test_addfield_pending_when_no_page(self):
        r = self.qe.gold_field_add(self.gid, {"field_path": "applications[9]"})
        self.assertEqual(r["status"], "pending")

    def test_cheatsheet_md_endpoint_renders(self):
        md = C.render_gold(gold_id=self.gid, include_json=False, db_mod=self.db)
        self.assertIn("DAC8555IPWG4", md)
        self.assertIn("electrical[10].value", md)
        # 线上路径形状必须能定位到 Pass 2（电气）
        self.assertIn("Pass 2", md)

    def test_review_log_written(self):
        self._upd(self.pid, {"status": "verified", "page_no": 2, "evidence": "封面"})
        logs = self.db.q("SELECT action FROM gold_review_log WHERE gold_id=?", (self.gid,))
        self.assertTrue(any(r["action"] == "verified" for r in logs))


if __name__ == "__main__":
    unittest.main()