#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""哈希跨换行符可复现 + 片段契约声明的用例（Reviewer D2-2 / C2）。

**取证**（可逐字节复现）：
`包校验报告.json` 自报 `ADC12DJ5200SE.html = 752afff8…`，而仓库同名散文件是
`df10bcd6…`。追查结果 —— **内容逐行完全相同**，差异 100% 来自 CRLF/LF：

    磁盘散文件（本机）  38476 B / 776 CRLF → 752afff8…（= 报告值）
    ZIP 成员            38476 B / 776 CRLF → 752afff8…
    归一化为 LF         37700 B /   0 CRLF → df10bcd6…（= 仓库 clone 后的值）

也就是说：报告对 ZIP 是准的，但「源文件/独立目录/ZIP 三处一致」这句话
**跨平台取件时不成立**——`git clone` 默认 LF 就校验失败。

修法二选一：统一按 LF 归档，或算哈希前归一化。这里取后者（不动已有产物字节），
并在报告里显式声明口径。同时把「HTML 是片段、SEO 在侧车」写成成文契约，
把 Reviewer 的挑刺变成交付说明的一部分。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as B                                     # noqa: E402


def test_crlf_and_lf_hash_identically(tmp_path):
    body = "<div class=\"pd-wrap\">\n<p>ADC12DJ5200SE</p>\n</div>\n"
    lf = tmp_path / "lf.html"
    crlf = tmp_path / "crlf.html"
    lf.write_bytes(body.encode("utf-8"))
    crlf.write_bytes(body.replace("\n", "\r\n").encode("utf-8"))

    assert lf.stat().st_size != crlf.stat().st_size, "夹具本身没造出字节差异"
    assert B._sha256(lf) == B._sha256(crlf), "换行符仍在影响哈希，跨平台不可复现"


def test_hash_rule_is_declared():
    """口径必须写进报告，否则下次复核还是会当成哈希错误。"""
    assert "CRLF" in B.HASH_RULE and "LF" in B.HASH_RULE


def test_readme_states_fragment_contract():
    """HTML 是 div.pd-wrap 片段、SEO 在 seo.json 侧车 —— 要成文，别让复核方猜。"""
    text = B.README
    assert "pd-wrap" in text
    assert "seo.json" in text
    assert "片段" in text


# ── 交付目录命名纪律（AGENT.md §16.1）────────────────────────────
def test_delivery_dir_rejects_future_date(tmp_path):
    """1101 那天真的产出过 `delivery-20261102` —— 日期不许写成次日。"""
    from datetime import date
    bad = B.check_delivery_name(tmp_path / "delivery-20261102", date(2026, 11, 1))
    assert bad and "未来日期" in bad
    assert B.check_delivery_name(tmp_path / "delivery-20261101-V3", date(2026, 11, 1)) is None
    # 历史例外目录不判，避免误伤已发布的包
    assert B.check_delivery_name(tmp_path / "delivery-20261030-fixed",
                                 date(2026, 11, 1)) is None


def test_delivery_dir_rejects_test_packages_in_release_series(tmp_path):
    """§16.1a：`delivery-<日期>-batchXX` 这类测试包不许占用正式序列。

    只写进 AGENT.md 不拦，等于没拦 —— 灰度包一旦排进 `-V4`，复核方按 V 号
    找版本就会拿到一个内部测试包。
    """
    from datetime import date
    bad = B.check_delivery_name(tmp_path / "delivery-20261102-batch20",
                                 date(2026, 11, 2))
    assert bad and "16.1a" in bad
    # 没有日期段的自由名字不判（历史用例里出现过 delivery-demo）
    assert B.check_delivery_name(tmp_path / "delivery-demo",
                                 date(2026, 11, 2)) is None
    # 正规的测试包前缀照常放行
    assert B.check_delivery_name(tmp_path / "test-20261102-batch20",
                                 date(2026, 11, 2)) is None
    assert B.check_delivery_name(tmp_path / "staging-gray-20261102",
                                 date(2026, 11, 2)) is None


def test_delivery_version_accepts_minor(tmp_path):
    """§16.1 补丁版号：`delivery-YYYYMMDD-V3.1` 是对外正式序列里的补丁版。

    只认 `-V<整数>` 时，「重打 V3 + 只修一处」既不能叫 V3.1（被拒），
    又只能占 V4 —— 对外说明里的「V3 的补丁」语义就丢了。
    这条只放开**点分补丁位**；测试包/灰度包的后缀照旧拒绝（§16.1a）。
    """
    from datetime import date
    assert B.check_delivery_name(tmp_path / "delivery-20261102-V3.1",
                                 date(2026, 11, 2)) is None
    # 未来日期依旧拦（补丁位不是绕过日期纪律的后门）
    assert B.check_delivery_name(tmp_path / "delivery-20261103-V3.1",
                                 date(2026, 11, 2))
    # 测试包后缀仍不许占用正式序列
    assert B.check_delivery_name(tmp_path / "delivery-20261102-batch20",
                                 date(2026, 11, 2))


def test_candidate_suffix_is_only_allowed_on_eval_packages(tmp_path):
    """Reviewer 2026-11-03：V3 候选包用 `-CANDIDATE` 明示「未批准」。

    该后缀只能挂在 `-eval` 包上；正式序列的 `-V3` 不许靠加 `-CANDIDATE`
    改名为「候选」，否则正式版本号与候选标记会混在一起。
    """
    from datetime import date
    assert B.is_eval_package("delivery-batch20-eval-V3-CANDIDATE")
    assert B.check_delivery_name(
        tmp_path / "delivery-batch20-eval-V3-CANDIDATE",
        date(2026, 11, 3)) is None
    assert B.check_delivery_name(
        tmp_path / "delivery-20261103-eval-V3-CANDIDATE",
        date(2026, 11, 3)) is None
    bad = B.check_delivery_name(
        tmp_path / "delivery-20261103-V3-CANDIDATE", date(2026, 11, 3))
    assert bad and "16.1a" in bad


def test_next_delivery_dir_bumps_version_same_day(tmp_path):
    """同日迭代只加 -Vn：首版 → V2 → V3，不换日期。"""
    from datetime import date
    d = date(2026, 11, 1)
    assert B.next_delivery_dir(tmp_path, d).name == "delivery-20261101"
    (tmp_path / "delivery-20261101").mkdir()
    assert B.next_delivery_dir(tmp_path, d).name == "delivery-20261101-V2"
    (tmp_path / "delivery-20261101-V2").mkdir()
    assert B.next_delivery_dir(tmp_path, d).name == "delivery-20261101-V3"
