# -*- coding: utf-8 -*-
"""1102-V3：弱证据定点清除的两个现场锁。

1. **AC 误杀**（元宝终审）：`ADS8568EVM-PDK` 的 THD / SNR 在事实表里分别拿到
   `verified_row` / `verified_paragraph`（V11 `facts_audit.csv` 实测），但
   `ac_quarantine` 只看 JSON 行内自述字段，把它们当“无独立溯源”扣进隔离桶。
   现在隔离逻辑要能接收事实表证据：有坐标级证据的行不隔离；真正缺坐标的
   （SFDR / Isolation）继续隔离，但理由必须写明“缺独立坐标”，不再笼统写
   “没有证据 / 疑似复制”。
2. **ADS1201U 合并单元格**：`Differential Input Voltage Range | With VBIAS(1)` 的
   TYP 格是脚注 `See Note 2`，行指纹本来就能从 PDF 重放；卡住它的是 JSON 只留
   `value`、没留 MIN/MAX 两列，事实表因此记 `missing_cols=min,max` 并降级。
   把同一条确定性抽取出来的 MIN/MAX 列补回行上（仍不生成正式 `range`），
   行指纹才可发。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from qc import ac_quarantine as AQ                      # noqa: E402
from qc import deterministic_extract as DE              # noqa: E402
from qc import fact_acceptance as FA                    # noqa: E402


# ── 1. AC 隔离：事实表有坐标级证据就不许扣 --------------------------
def _ac_row(name: str, value: str, cond: str = "At fIN = 10 kHz") -> dict:
    return {"name": name, "value": value, "unit": "dB", "condition": cond}


def _board_doc(rows: list[dict]) -> dict:
    return {
        "basic_info": {"mpn": "ADS8568EVM-PDK", "identity": "evaluation_board"},
        "specs": {
            "scope": "onboard_device",
            "electrical": [],
            "onboard_device_specs": {
                "device_mpn": "ADS8568", "scope": "onboard_device",
                "electrical": [dict(r) for r in rows],
            },
        },
    }


#: 与 V11 facts_audit.csv 的 4 条实测结论同形。
EVIDENCE = {
    ("Total Harmonic Distortion (THD)", "At fIN = 10 kHz"): {
        "verdict": "verified_row", "bbox": "[102.3, 443.9, 509.4, 456.6]",
        "row_sha256": "782f30c54f16ed653393c6f547865508ddafae520e80569bc6413a630a6ef0fc",
    },
    ("Signal-to-Noise Ratio (SNR)", "At fIN = 10 kHz"): {
        "verdict": "verified_paragraph", "bbox": "[83.9, 257.3, 250.7, 290.7]",
        "paragraph_sha256":
            "4616f0509a4909a5b0b6adf5f1b3337a76574714c2beeb2ac0456d842c39ced0",
    },
    ("Spurious-Free Dynamic Range (SFDR)", "At fIN = 10 kHz"): {
        "verdict": "value_on_label_page",
    },
    ("Channel-to-Channel Isolation", "At fIN = 10 kHz"): {
        "verdict": "value_on_label_page",
    },
}


def test_thd_with_facts_row_fingerprint_is_never_quarantined():
    """元宝点名的反例：THD 有 verified_row 行指纹，绝不能被隔离。"""
    doc = _board_doc([_ac_row("Total Harmonic Distortion (THD)", "-94")])
    rep = AQ.quarantine(doc, evidence=EVIDENCE)
    names = [r["name"] for r in doc["specs"]["onboard_device_specs"]["electrical"]]
    assert names == ["Total Harmonic Distortion (THD)"], names
    assert rep["n_quarantined"] == 0, rep
    assert not doc["specs"].get("unresolved_ac_rows")


def test_snr_with_facts_paragraph_fingerprint_is_never_quarantined():
    doc = _board_doc([_ac_row("Signal-to-Noise Ratio (SNR)", "91.5")])
    rep = AQ.quarantine(doc, evidence=EVIDENCE)
    assert rep["n_quarantined"] == 0, rep
    assert len(doc["specs"]["onboard_device_specs"]["electrical"]) == 1


def test_sfdr_without_coords_is_quarantined_with_precise_reason():
    """SFDR 确实缺独立坐标：继续扣，但理由要写明缺的是坐标。"""
    doc = _board_doc([_ac_row("Spurious-Free Dynamic Range (SFDR)", "92")])
    rep = AQ.quarantine(doc, evidence=EVIDENCE)
    assert rep["n_quarantined"] == 1, rep
    moved = doc["specs"]["unresolved_ac_rows"][0]
    assert "缺" in moved["quarantine_reason"]
    assert "坐标" in moved["quarantine_reason"]
    assert "bbox" in moved["quarantine_reason"]
    assert moved["value"] == "92"


def test_row_with_inline_row_sha_is_never_quarantined_even_without_evidence():
    row = _ac_row("Total Harmonic Distortion (THD)", "-94")
    row.update({"bbox": [1, 2, 3, 4], "row_sha256": "a" * 64})
    doc = _board_doc([row])
    rep = AQ.quarantine(doc)
    assert rep["n_quarantined"] == 0, rep


def test_filter_electrical_rows_keeps_facts_verified_rows():
    """渲染出口同一口径：事实表说 THD/SNR 有坐标级证据，页面就不许吞。"""
    thd = _ac_row("Total Harmonic Distortion (THD)", "-94")
    sfdr = _ac_row("Spurious-Free Dynamic Range (SFDR)", "92")
    facts = {
        "Total Harmonic Distortion (THD)\x1fAt fIN = 10 kHz": "verified_row",
        "Signal-to-Noise Ratio (SNR)\x1fAt fIN = 10 kHz": "verified_paragraph",
        "Spurious-Free Dynamic Range (SFDR)\x1fAt fIN = 10 kHz":
            "value_on_label_page",
    }
    kept = AQ.filter_electrical_rows([thd, sfdr], facts=facts)
    assert [r["name"] for r in kept] == ["Total Harmonic Distortion (THD)"]


# ── 2. ADS1201U：脚注 TYP 的合并行，列证据要留、正式 range 仍不发 ----
def test_input_range_row_keeps_min_max_for_footnote_typ():
    src = {"cond": "With VBIAS(1)", "page": 2, "bbox": [36.7, 142.8, 540.8, 152.8],
           "row_sha256": "959ed04e48f167fcae9a02f78e11c94564257b00e00f722e03758c6cf7df0282",
           "min": "-20", "max": "+20", "typ": "See Note 2", "unit": "V"}
    row = DE._input_range_row("Differential Input Voltage Range", src, "V")
    # 两条同时成立：列证据留档；正式 range 仍不主张。
    assert row["min"] == "-20"
    assert row["max"] == "+20"
    assert row["typ"] == "See Note 2"
    assert "range" not in row
    assert row["range_origin"] == "column_roles_unverified"
    assert FA.missing_columns(row, src) == []
    # 重放行本身有 MIN/MAX/UNIT；结论必须是行级，不再降坐标级。
    verdict, note = FA._downgrade_for_missing_cols(
        "verified_row", FA.missing_columns(row, src))
    assert (verdict, note) == ("verified_row", "")


def test_input_range_row_without_numeric_min_max_does_not_invent_them():
    src = {"cond": "With VBIAS(1)", "page": 2, "bbox": [0, 0, 1, 1],
           "row_sha256": "x" * 64,
           "min": "HVSS - 0.3", "max": "HVDD + 0.3", "typ": "", "unit": "V"}
    row = DE._input_range_row("Differential Input Voltage Range", src, "V")
    assert "min" not in row and "max" not in row
    assert "range" not in row


# ── 3. 点线表：续行与共享前缀 ----------------------------------------
def _lines_for_dot_rows():
    """ADS1201U p3 实测排版（文字 + 坐标，纯数据，不依赖 PDF 文件）。"""
    return [
        ("Analog Input: Current ................................................ ±100mA, Momentary",
         [78.0, 52.5, 306.0, 62.1]),
        ("±10mA, Continuous", [244.6, 61.5, 306.0, 71.1]),
        ("Voltage ................................... AGND –0.3V to AVDD +0.3V",
         [122.0, 70.5, 306.0, 81.2]),
        ("AVDD to DVDD ...........................................................................–0.3V to 6V",
         [78.0, 79.5, 305.9, 90.8]),
        ("NOTE: (1) Stresses above those listed under “Absolute Maximum Ratings” may",
         [72.0, 100.0, 400.0, 108.0]),
    ]


def test_dot_lines_merge_continuation_value():
    rows = DE._amax_dot_lines(_lines_for_dot_rows())
    current = rows[0]
    assert current["param"] == "Analog Input: Current"
    assert "±100mA" in current["val_raw"] and "±10mA" in current["val_raw"]
    # bbox 必须覆盖两行，复核方翻过去能看到整条复合值。
    assert current["bbox"][1] == 52.5 and current["bbox"][3] == 71.1
    # NOTE 行不是续行，不许被吞进上一条。
    assert all("NOTE" not in r["param"] for r in rows)


def test_dot_lines_inherit_merged_parameter_prefix():
    rows = DE._amax_dot_lines(_lines_for_dot_rows())
    assert rows[1]["param"] == "Analog Input: Voltage"
    assert rows[1]["val_raw"] == "AGND -0.3V to AVDD +0.3V"


def test_para_fingerprint_is_shared_between_extractor_and_audit():
    text = "Analog Input: Current ................ ±100mA, Momentary\n±10mA, Continuous\n"
    assert DE.para_fingerprint(3, text) == FA._para_fingerprint(3, text)
    assert DE.para_input(3, text) == FA._para_input(3, text)


# ── 4. ADS8568：隔离桶里的行也要有锚定机会 ---------------------------
class _FakePage:
    def __init__(self, text: str):
        self._text = text
        self.number = 0

    def get_text(self, *a, **k):
        return self._text


class _FakeDoc:
    page_count = 1

    def __init__(self, page):
        self._page = page

    def __getitem__(self, i):
        return self._page


def test_fill_row_anchors_reaches_onboard_device_bucket(monkeypatch):
    """板卡件的电气行被搬进隔离桶后，旧实现只看主表，永远锚不上。"""
    row = {"name": "Digital I/O Supply Voltage (DVDD)", "value": "2.7 to 5.5",
           "unit": "V", "condition": ""}
    doc = {"specs": {"electrical": [],
                     "onboard_device_specs": {"electrical": [row]}}}
    cand = {"param": "Buffer I/O supply voltage", "cond": "", "desc": "",
            "min": "2.7", "typ": "3.3", "max": "5.5", "unit": "V",
            "page": 1, "bbox": [1, 2, 3, 4], "row_sha256": "a" * 64}
    monkeypatch.setattr(DE, "extract_spec_rows", lambda page: [dict(cand)])
    monkeypatch.setattr(DE, "extract_roc_rows", lambda page: [])
    res = DE.fill_row_anchors(
        doc, _FakeDoc(_FakePage("Digital I/O Supply Voltage (DVDD) 2.7 3.3 5.5")))
    assert res["anchored"] == 1
    assert row["source"]["row_sha256"] == "a" * 64
    assert row["verification"]["status"] == "audited_row_anchored"


def test_unit_key_ignores_stray_numbers_but_not_prefixes():
    # `mW0.6` 是 find_tables 把下一行数值并进单位格；`mA` vs `A` 仍必须不同。
    assert DE._unit_ok("mW", "mW0.6") is True
    assert DE._unit_ok("4.54.43.62.6mA", "mA") is True
    assert DE._unit_ok("mA", "A") is False
    assert DE._unit_ok("MHz", "Hz") is False


def test_clean_unit_keeps_normal_units_verbatim():
    for u in ("V", "mA", "°C/W", "μs", "dBFS/Hz", "Cycles"):
        assert DE._clean_unit(u) == u
    assert DE._clean_unit("mW0.6") == "mW"
    assert DE._clean_unit("4.54.43.62.6mA") == "mA"


# ── 5. 事实表证据写回：THD 表格行 / SNR 汇总段落 ----------------------
def test_apply_ac_evidence_declares_true_carrier():
    from qc import normalize_doc as ND
    doc = _board_doc([
        _ac_row("Total Harmonic Distortion (THD)", "-94"),
        _ac_row("Signal-to-Noise Ratio (SNR)", "91.5"),
    ])
    n = ND._apply_ac_evidence(doc, EVIDENCE)
    assert n == 2
    rows = {r["name"]: r for r in
            doc["specs"]["onboard_device_specs"]["electrical"]}
    thd, snr = rows["Total Harmonic Distortion (THD)"], rows["Signal-to-Noise Ratio (SNR)"]
    assert thd["verification"]["status"] == "audited_row_anchored"
    assert thd["source"]["row_sha256"]
    assert FA.param_kind(thd) == "table"
    # SNR 的独立来源是 p1 汇总段落：段落指纹 → prose，才不会被 row_anchor 卡住。
    assert snr["verification"]["status"] == "audited_paragraph"
    assert snr["source"]["paragraph_sha256"]
    assert thd["source"]["bbox"] == [102.3, 443.9, 509.4, 456.6]
    assert FA.param_kind(snr) == "prose"


# ── 6. 语义错名：按原表真实参数名改名（用户 2026-11-02 授权） --------
def test_fill_row_anchors_renames_condition_identified_mismatch(monkeypatch):
    """`Input Common-Mode Voltage` 原表 p10 实为 `Bipolar full-scale range`。

    条件/数值/单位完全一致、且辨识词不重叠时，按原表参数名改名并锚定；
    原标签留在 `source.label_original`，值/条件/单位一个字不动。
    """
    row = {"name": "Input Common-Mode Voltage (RANGE bit=0)",
           "value": "-4 VREF to 4 VREF", "unit": "V",
           "condition": "RANGE pin, RANGE bit = 0"}
    doc = {"specs": {"electrical": [],
                     "onboard_device_specs": {"electrical": [row]}}}
    cand = {"param": "Bipolar full-scale range",
            "cond": "RANGE pin, RANGE bit = 0", "desc": "",
            "min": "-4 VREF", "typ": "", "max": "4 VREF", "unit": "V",
            "page": 10, "bbox": [1, 2, 3, 4], "row_sha256": "b" * 64}
    monkeypatch.setattr(DE, "extract_spec_rows", lambda page: [dict(cand)])
    monkeypatch.setattr(DE, "extract_roc_rows", lambda page: [])
    res = DE.fill_row_anchors(
        doc, _FakeDoc(_FakePage(
            "Input Common-Mode Voltage (RANGE bit=0) -4 VREF to 4 VREF")))
    assert res["anchored"] == 1
    assert row["name"] == "Bipolar Full-Scale Range (RANGE bit=0)"
    assert row["condition"] == "RANGE pin, RANGE bit = 0"
    assert row["value"] == "-4 VREF to 4 VREF"
    assert row["unit"] == "V"
    assert row["source"]["label_original"] == "Input Common-Mode Voltage (RANGE bit=0)"
    assert "改名" in row["verification"]["label_note"]
    assert row["verification"]["status"] == "audited_row_anchored"


def test_rename_refuses_when_label_shares_distinctive_token(monkeypatch):
    """同义改写（共享 `power` 等辨识词）不自动改名 —— 只处理真正对不上的错名。"""
    row = {"name": "Power Consumption", "value": "1.2", "unit": "W",
           "condition": "At 25C"}
    doc = {"specs": {"onboard_device_specs": {"electrical": [row]}}}
    cand = {"param": "Power Dissipation", "cond": "At 25C", "desc": "",
            "min": "", "typ": "", "max": "1.2", "unit": "W",
            "page": 10, "bbox": [1, 2, 3, 4], "row_sha256": "c" * 64}
    monkeypatch.setattr(DE, "extract_spec_rows", lambda page: [dict(cand)])
    monkeypatch.setattr(DE, "extract_roc_rows", lambda page: [])
    DE.fill_row_anchors(doc, _FakeDoc(_FakePage("Power Consumption 1.2 W")))
    assert row["name"] == "Power Consumption"
