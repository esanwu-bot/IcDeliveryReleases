# -*- coding: utf-8 -*-
"""热阻逐列展开的**数量对齐校验**：数不出来就不许落行。

背景：文本层是「一个单元格一行」，某个格子完全空白时那一行根本不存在，
`zip(cols, vals)` 会把后面的值整体左移一格 —— KCS 的 `0.1` 被贴到 DCY 名下，
页面上看不出任何异常，客户拿它算结温就是错的。

位置式配对**没有任何办法**证明对齐（空格子已经消失），所以判据只能是数量：
`len(vals) == len(cols)` 才落行，否则整行拒收并记进 `unresolved_rows()`。
宁可缺一条，也不许把数值安到错误的封装上。
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D     # noqa: E402


class _Page:
    """够 `extract_thermal` 用的最小页对象（只吃 `get_text()`）。"""

    def __init__(self, lines, number=7):
        self._text = "\n".join(lines)
        self.number = number

    def get_text(self):
        return self._text


HEAD = [
    "6.4 Thermal Information (Legacy Chip)",
    "THERMAL METRIC(1)",
    "LM317",
    "UNIT",
    "DCY", "(SOT-223)", "KCS", "(TO-220)", "KCT", "(TO-220)", "KTT", "(TO-263)",
    "4 PINS", "3 PINS", "3 PINS", "3 PINS",
]


def _page(values, name="Rθ(JA)", desc="Junction-to-ambient thermal resistance"):
    return _Page(HEAD + [name, desc] + list(values) + ["°C/W"])


# ─────────────────────────────────────────────────────────────────────
# 1. 对齐：正常抽出 4 个封装
# ─────────────────────────────────────────────────────────────────────

def test_aligned_row_extracts_every_package():
    rows = D.extract_thermal([_page(["66.8", "23.5", "37.9", "38.0"])])

    assert len(rows) == 4
    assert [r["value"] for r in rows] == ["66.8", "23.5", "37.9", "38.0"]
    # 值必须和封装一一对上，顺序也要对
    assert rows[0]["condition"].startswith("Legacy Chip; DCY (SOT-223)")
    assert rows[3]["condition"].startswith("Legacy Chip; KTT (TO-263)")
    assert D.unresolved_rows() == []


# ─────────────────────────────────────────────────────────────────────
# 2. 错列：中间缺一个值 → 整行拒收
# ─────────────────────────────────────────────────────────────────────

def test_missing_middle_cell_is_refused_instead_of_shifted():
    """`23.5` 那一格空白（文本层没有这一行）→ 3 个值配 4 列。

    旧实现会让 `37.9` 落到 KCS、`38.0` 落到 KCT，KTT 凭空消失 —— 三个封装
    的数值全错，且页面上完全看不出来。现在必须整行拒收。
    """
    rows = D.extract_thermal([_page(["66.8", "37.9", "38.0"])])

    assert rows == [], "数量对不上时一条都不许落 —— 落一条就是错一条"
    bad = D.unresolved_rows()
    assert len(bad) == 1
    assert bad[0]["name"] == "RθJA"
    assert bad[0]["expected"] == 4
    assert bad[0]["got"] == 3
    assert bad[0]["values"] == ["66.8", "37.9", "38.0"]


def test_unresolved_entry_carries_enough_to_locate_the_row():
    """拒收要能被人查到「哪张表的哪条」—— 只留一个数字等于没留。"""
    D.extract_thermal([_page(["66.8", "37.9", "38.0"])])
    e = D.unresolved_rows()[0]

    assert e["container"] == "thermal"
    assert e["table_variant"] == "Legacy Chip"
    assert e["page"] == 7
    assert "错位" in e["reason"] or "左移" in e["reason"]


def test_a_bad_row_does_not_kill_the_rest_of_the_table():
    """一条数不出来，不许连累后面的参数 —— 否则一个空格子毁掉整张热阻表。"""
    page = _Page(HEAD + [
        "Rθ(JA)", "Junction-to-ambient thermal resistance",
        "66.8", "37.9", "38.0", "°C/W",          # 错列：只 3 个
        "RθJB", "Junction-to-board thermal resistance",
        "16.9", "7.9", "23.2", "18.9", "°C/W",   # 齐整：4 个
    ])
    rows = D.extract_thermal([page])

    assert [r["name"] for r in rows] == ["RθJB"] * 4
    assert len(D.unresolved_rows()) == 1


# ─────────────────────────────────────────────────────────────────────
# 3. 占位符：占列但不算错列
# ─────────────────────────────────────────────────────────────────────

def test_placeholder_counts_as_a_cell_so_the_row_stays_aligned():
    """`NA` 是**印出来的空值**，它占一格。跳过它落行 ≠ 错列。"""
    rows = D.extract_thermal([_page(["NA", "0.1", "4.2", "1.1"])])

    assert len(rows) == 3, "NA 那一列不落行，其余三列照落"
    assert [r["value"] for r in rows] == ["0.1", "4.2", "1.1"]
    assert rows[0]["condition"].startswith("Legacy Chip; KCS (TO-220)")
    assert D.unresolved_rows() == [], "有占位符不等于错列，不许记 unresolved"


# ─────────────────────────────────────────────────────────────────────
# 4. 状态不串味
# ─────────────────────────────────────────────────────────────────────

def test_unresolved_is_reset_between_calls():
    """上一份 PDF 的拒收记录不许留到下一份 —— 否则复核方永远看到一批陈年错列。"""
    D.extract_thermal([_page(["66.8", "37.9", "38.0"])])
    assert D.unresolved_rows()

    D.extract_thermal([_page(["66.8", "23.5", "37.9", "38.0"])])
    assert D.unresolved_rows() == []


def test_unresolved_rows_returns_a_copy():
    """外部改返回值不许污染模块状态。"""
    D.extract_thermal([_page(["66.8", "37.9", "38.0"])])
    got = D.unresolved_rows()
    got.clear()
    assert len(D.unresolved_rows()) == 1
