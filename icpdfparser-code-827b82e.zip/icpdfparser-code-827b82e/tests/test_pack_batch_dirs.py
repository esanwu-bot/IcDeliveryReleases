"""pack_batch_dirs.py 离线单测：每型号一目录的交付树契约。

锁住三件事（都是真实踩过的坑）：
1. 目录内文件名统一为 `<safe_stem>.<后缀>`，源 JSON 带 hash 后缀（`<stem>_ab12.json`）
   也必须落成 `<stem>.json`。
2. provenance 的 `pdf` 段必须带真实 bytes/sha256 —— files 是按「目标后缀」做键的，
   曾用 `files.get("pdf")` 取到空 dict。
3. `files` 列的是**落盘后**的文件名，不是库里的源路径。
4. 型号含 `/`（ADC128D818EB/NOPB）按 safe_name 归一，页面主键保留原始型号。
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PDF_BYTES = b"%PDF-1.4 fake datasheet for test\n"


class PackBatchDirsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="pb_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                             # noqa: E402
        self.db = db
        db.q1("SELECT 1")

        from app import config                         # noqa: E402
        self.config = config
        self.dirs = {}
        for name in ("pdfs", "parsed", "txt", "alts", "symbols", "seo", "exports"):
            d = self.tmp / name
            d.mkdir(parents=True, exist_ok=True)
            self.dirs[name] = d

        import pack_batch_dirs as P                    # noqa: E402
        self.P = P
        # SPEC 在导入期就绑定了 config 目录，测试里换成临时目录
        P.SPEC = (
            ("pdf", "pdf_path", self.dirs["pdfs"], ".pdf"),
            ("json", "json_path", self.dirs["parsed"], ".json"),
            ("txt", "txt_path", self.dirs["txt"], ""),
            ("alt_json", "alt_json_path", self.dirs["alts"], ".alts.json"),
            ("alt_html", "alt_html_path", self.dirs["alts"], ".alts.html"),
            ("symbol", "symbol_path", self.dirs["symbols"], ".symbols.html"),
            ("seo", "seo_path", self.dirs["seo"], ".seo.json"),
        )
        self._orig_resolve = config.resolve_artifact
        config.resolve_artifact = lambda stored, sub: sub / Path(stored).name

    def tearDown(self):
        self.config.resolve_artifact = self._orig_resolve
        try:
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    # ---------- 夹具 ----------
    def _seed(self, mpn="NE555", stem="NE555", *, with_pdf=True, langs=("ja", "ko")):
        for name, fn in (
            ("pdfs", "%s__%s.pdf" % (stem, stem.lower())),
            ("parsed", "%s_ab12cd34.json" % stem),
            ("txt", "%s.txt" % stem),
            ("alts", "%s.json" % stem),
            ("alts", "%s.html" % stem),
            ("symbols", "%s.html" % stem),
            ("seo", "%s.json" % stem),
        ):
            p = self.dirs[name] / fn
            if name == "pdfs":
                # PDF 必须按字节写：文本模式在 Windows 会把 \n 译成 \r\n，sha256 就不是真值了
                p.write_bytes(PDF_BYTES)
            else:
                p.write_text("x", encoding="utf-8")
        for lg in langs:
            (self.dirs["txt"] / ("%s.%s.txt" % (stem, lg))).write_text("x", encoding="utf-8")
        self.db.x(
            "INSERT INTO item(mpn, mpn_key, pdf_path, json_path, txt_path, alt_json_path,"
            " alt_html_path, symbol_path, seo_path, status, created_at, updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,'parsed',?,?)",
            (mpn, stem,
             str(self.dirs["pdfs"] / ("%s__%s.pdf" % (stem, stem.lower()))) if with_pdf else "",
             str(self.dirs["parsed"] / ("%s_ab12cd34.json" % stem)),
             str(self.dirs["txt"] / ("%s.txt" % stem)),
             str(self.dirs["alts"] / ("%s.json" % stem)),
             str(self.dirs["alts"] / ("%s.html" % stem)),
             str(self.dirs["symbols"] / ("%s.html" % stem)),
             str(self.dirs["seo"] / ("%s.json" % stem)),
             self.db.qc_now(), self.db.qc_now()))

    # ---------- 用例 ----------
    def test_collect_maps_all_seven_kinds(self):
        self._seed()
        files, missing = self.P.collect("NE555")
        self.assertEqual([], missing)
        self.assertEqual({".pdf", ".json", ".txt", ".alts.json", ".alts.html",
                          ".symbols.html", ".seo.json",
                          ".ja.txt", ".ko.txt"}, set(files))

    def test_hash_suffixed_json_resolves(self):
        """库里的 json_path 为空时，靠 `<stem>_*.json` 兜底找到带 hash 的产物。"""
        self._seed()
        self.db.x("UPDATE item SET json_path='' WHERE mpn_key='NE555'")
        files, missing = self.P.collect("NE555")
        self.assertNotIn("json", missing)
        self.assertEqual("NE555_ab12cd34.json", files[".json"].name)

    def test_pack_one_names_files_by_stem(self):
        self._seed()
        out = self.tmp / "out"
        r = self.P.pack_one("NE555", out, "b1", {}, True)
        names = set(r["files"])
        self.assertIn("NE555.json", names)          # 不是 NE555_ab12cd34.json
        self.assertIn("NE555.pdf", names)
        self.assertIn("NE555.ja.txt", names)
        self.assertIn("NE555.provenance.json", names)
        self.assertEqual(10, len(names))            # 7 类 + 2 语言 + provenance
        self.assertTrue(r["pdf"])
        self.assertEqual([], r["missing"])

    def test_provenance_pdf_carries_real_sha256(self):
        """pdf 段曾因按错键取值（'pdf' vs '.pdf'）而恒为空。"""
        self._seed()
        out = self.tmp / "out"
        self.P.pack_one("NE555", out, "b1", {"status_code": "REVIEWED_FIXED"}, True)
        prov = json.loads((out / "NE555" / "NE555.provenance.json").read_text("utf-8"))
        self.assertEqual("NE555.pdf", prov["pdf"]["file"])
        self.assertEqual(len(PDF_BYTES), prov["pdf"]["bytes"])
        self.assertEqual(hashlib.sha256(PDF_BYTES).hexdigest(), prov["pdf"]["sha256"])
        self.assertEqual("REVIEWED_FIXED", prov["status_code"])

    def test_provenance_files_are_landed_names(self):
        self._seed()
        out = self.tmp / "out"
        self.P.pack_one("NE555", out, "b1", {}, True)
        prov = json.loads((out / "NE555" / "NE555.provenance.json").read_text("utf-8"))
        self.assertIn("NE555.json", prov["files"])
        self.assertIn("NE555.ko.txt", prov["files"])
        self.assertFalse([f for f in prov["files"] if "_ab12cd34" in f])
        self.assertTrue(all(f.startswith("NE555.") for f in prov["files"]))

    def test_provenance_never_green_lights_release(self):
        self._seed()
        out = self.tmp / "out"
        self.P.pack_one("NE555", out, "b1", {}, True)
        prov = json.loads((out / "NE555" / "NE555.provenance.json").read_text("utf-8"))
        self.assertIs(False, prov["human_accepted"])
        self.assertIs(False, prov["release_approved"])

    def test_slash_mpn_uses_safe_dir_keeps_raw_mpn(self):
        self._seed(mpn="ADC128D818EB/NOPB", stem="ADC128D818EB_NOPB")
        out = self.tmp / "out"
        r = self.P.pack_one("ADC128D818EB/NOPB", out, "b1", {}, True)
        self.assertEqual("ADC128D818EB_NOPB", Path(r["dir"]).name)
        prov = json.loads((out / "ADC128D818EB_NOPB"
                           / "ADC128D818EB_NOPB.provenance.json").read_text("utf-8"))
        self.assertEqual("ADC128D818EB/NOPB", prov["mpn"])   # 页面主键保留原始型号

    def test_no_pdf_flag_marks_missing(self):
        self._seed()
        out = self.tmp / "out"
        r = self.P.pack_one("NE555", out, "b1", {}, False)
        self.assertFalse(r["pdf"])
        self.assertNotIn("NE555.pdf", r["files"])

    def test_zip_stores_pdf_undeflated(self):
        import zipfile
        self._seed()
        out = self.tmp / "out"
        self.P.pack_one("NE555", out, "b1", {}, True)
        z = self.P.write_zip(out, self.tmp / "out.zip")
        self.assertEqual(10, z["files"])
        with zipfile.ZipFile(self.tmp / "out.zip") as zf:
            self.assertEqual(zipfile.ZIP_STORED, zf.getinfo("NE555/NE555.pdf").compress_type)
            self.assertEqual(zipfile.ZIP_DEFLATED,
                             zf.getinfo("NE555/NE555.json").compress_type)

    def test_read_batch_skips_blank_mpn(self):
        b = self.tmp / "rf-x"
        b.mkdir()
        (b / "manifest.csv").write_text(
            "\ufeffmpn,status_code\nNE555,REVIEWED_FIXED\n,REVIEWED_FIXED\nLM358,PASS\n",
            encoding="utf-8")
        name, rows = self.P.read_batch(b)
        self.assertEqual("rf-x", name)
        self.assertEqual(["NE555", "LM358"], [r["mpn"] for r in rows])

    def test_read_batch_requires_manifest(self):
        with self.assertRaises(SystemExit):
            self.P.read_batch(self.tmp / "nope")


if __name__ == "__main__":
    unittest.main()
