"""qc/evidence_chain.py 离线单测：E1–E4 机器起草（确定性、幂等、不越界）。

PDF 用 fitz 现场生成；DB 用临时 SQLite；parsed JSON 用临时文件（monkeypatch 路径解析）。
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import evidence_chain as EC                    # noqa: E402
from qc import evidence_verify as EV                   # noqa: E402


def _pdf(path: Path, texts: dict) -> Path:
    import fitz
    d = fitz.open()
    for _ in range(max(texts) if texts else 1):
        d.new_page()
    for pno, t in texts.items():
        d[pno - 1].insert_text((72, 72), t)
    d.save(path)
    d.close()
    return path


class ChainTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="chaintest_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                              # noqa: E402
        self.db = db
        db.q1("SELECT 1")
        EV.ensure_cols(db)
        self.pdf = _pdf(self.tmp / "BUF634PG4.pdf",
                        {1: "BUF634PG4 High-Speed Buffer Texas Instruments SLOS123 Rev C "
                            "wide bandwidth low power monolithic operational buffer",
                         2: "V+ 7 SOIC D package pin functions IOIDD 10 uA MAX quiescent"})
        self.jdoc = self.tmp / "BUF634PG4.json"
        self.jdoc.write_text(json.dumps({
            "basic_info": {"mpn": "BUF634PG4", "manufacturer": "Texas Instruments"},
            "specs": {"electrical": [{"name": "IOIDD", "value": "10", "unit": "uA",
                                      "condition": ""}]},
            "pin_configuration": [{"pin": 7, "name": "V+"}],
            "metadata": {"audit": {"findings": [{"path": "electrical[0].value",
                                                 "source": {"page": 2}}]}},
        }, ensure_ascii=False), encoding="utf-8")
        self._old = (EC._pdf, EC._json_doc)
        EC._pdf = lambda mpn: self.pdf
        EC._json_doc = lambda mpn: json.loads(self.jdoc.read_text(encoding="utf-8"))
        gid = db.x("INSERT INTO gold_set(version,mpn,manufacturer,pdf_sha256,status,"
                   "created_at,updated_at) VALUES('v1','BUF634PG4','TI','', 'draft',?,?)",
                   (db.qc_now(), db.qc_now()))
        self.gid = gid
        self.f0 = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                       "cond,status) VALUES(?,?,?,?,?,'','pending')",
                       (gid, "electrical[0].value", "IOIDD", "10", "uA"))
        self.f1 = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                       "cond,status) VALUES(?,?,?,?,?,'','pending')",
                       (gid, "basic_info.mpn", "mpn", "BUF634PG4", ""))
        self.f2 = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                       "cond,status) VALUES(?,?,?,?,?,'','pending')",
                       (gid, "features[5]", "feature", "ZZZ_NOT_IN_PDF", ""))

    def tearDown(self):
        try:
            EC._pdf, EC._json_doc = self._old
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def test_e1_register_document(self):
        rep = EC.e1_register(self.db, "BUF634PG4")
        self.assertTrue(rep["ok"], rep)
        self.assertEqual(len(rep["sha256"]), 64)
        self.assertEqual(rep["tier"], "P1")               # 无官方 URL → P1
        doc = self.db.q1("SELECT * FROM source_document WHERE id=?", (rep["document_id"],))
        self.assertEqual(doc["page_count"], 2)
        ev = self.db.q1("SELECT * FROM source_evidence WHERE id=?", (rep["evidence_id"],))
        self.assertEqual(ev["document_id"], rep["document_id"])
        self.assertEqual(ev["manufacturer"], "TI")        # 从 Gold 取

    def test_e1_missing_pdf(self):
        EC._pdf = lambda mpn: None
        rep = EC.e1_register(self.db, "BUF634PG4")
        self.assertFalse(rep["ok"])

    def test_e2_precheck_report_only(self):
        ev = EC.e1_register(self.db, "BUF634PG4")["evidence_id"]
        rep = EC.e2_precheck(self.db, ev, "BUF634PG4")
        self.assertIn(rep["verdict"], ("green", "yellow", "red"))
        self.assertTrue(rep["checks"]["cover_title"])
        self.assertTrue(rep["checks"]["text_layer"])
        # 预检不得把身份置 verified
        evr = self.db.q1("SELECT identity_status FROM source_evidence WHERE id=?", (ev,))
        self.assertNotEqual(evr["identity_status"], "verified")
        saved = self.db.q1("SELECT precheck_json FROM source_evidence WHERE id=?", (ev,))
        self.assertIn(rep["verdict"], saved["precheck_json"])

    def test_e3_locates_and_marks_ambiguous_or_ready(self):
        ev = EC.e1_register(self.db, "BUF634PG4")["evidence_id"]
        rep = EC.e3_locate(self.db, ev, "BUF634PG4")
        by = {f["path"]: f for f in rep["fields"]}
        self.assertEqual(by["electrical[0].value"]["status"], "ready")     # "10" 命中
        self.assertEqual(by["basic_info.mpn"]["status"], "ready")          # 型号字面命中
        self.assertEqual(by["features[5]"]["status"], "ocr_pending")       # 找不到
        rows = self.db.q("SELECT * FROM source_field_evidence WHERE evidence_id=?", (ev,))
        self.assertEqual(len(rows), 2)                                     # 只有定位到的落库
        for r in rows:
            self.assertFalse((r["reviewer"] or "").strip())                # 机器不写 reviewer
            self.assertIn(r["verification_status"], ("ready", "ambiguous"))
            self.assertTrue(r["candidates_json"])

    def test_e3_idempotent(self):
        ev = EC.e1_register(self.db, "BUF634PG4")["evidence_id"]
        EC.e3_locate(self.db, ev, "BUF634PG4")
        n1 = self.db.q1("SELECT count(*) n FROM source_field_evidence WHERE evidence_id=?",
                        (ev,))["n"]
        EC.e3_locate(self.db, ev, "BUF634PG4")
        n2 = self.db.q1("SELECT count(*) n FROM source_field_evidence WHERE evidence_id=?",
                        (ev,))["n"]
        self.assertEqual(n1, n2)                                           # 幂等：不重复插

    def test_e3_skips_human_touched(self):
        ev = EC.e1_register(self.db, "BUF634PG4")["evidence_id"]
        EC.e3_locate(self.db, ev, "BUF634PG4")
        row = self.db.q1("SELECT id FROM source_field_evidence WHERE evidence_id=? AND "
                         "field_path='electrical[0].value'", (ev,))
        self.db.x("UPDATE source_field_evidence SET reviewer='esan', evidence_quote='10 uA' "
                  "WHERE id=?", (row["id"],))
        EC.e3_locate(self.db, ev, "BUF634PG4")
        after = self.db.q1("SELECT reviewer, evidence_quote FROM source_field_evidence "
                           "WHERE id=?", (row["id"],))
        self.assertEqual(after["reviewer"], "esan")                        # 人工结果不被覆盖

    def test_e4_crosscheck_marks_conflict(self):
        ev = EC.e1_register(self.db, "BUF634PG4")["evidence_id"]
        EC.e3_locate(self.db, ev, "BUF634PG4")
        rep = EC.e4_crosscheck(self.db, ev, "BUF634PG4")
        self.assertGreaterEqual(rep["ready"], 1)
        # 造一个冲突：quote 与 Gold expected 数值不符
        row = self.db.q1("SELECT id FROM source_field_evidence WHERE evidence_id=? AND "
                         "field_path='electrical[0].value'", (ev,))
        self.db.x("UPDATE source_field_evidence SET evidence_quote='99 uA' WHERE id=?",
                  (row["id"],))
        rep2 = EC.e4_crosscheck(self.db, ev, "BUF634PG4")
        self.assertGreaterEqual(rep2["conflict"], 1)
        st = self.db.q1("SELECT verification_status FROM source_field_evidence WHERE id=?",
                        (row["id"],))["verification_status"]
        self.assertEqual(st, "conflict_draft")
        # 机器不改 Gold 标准值
        gf = self.db.q1("SELECT expected FROM gold_field WHERE id=?", (self.f0,))
        self.assertEqual(gf["expected"], "10")

    def test_run_all_and_freeze_readiness(self):
        rep = EC.run_all(self.db, "BUF634PG4")
        self.assertEqual(rep["mpn"], "BUF634PG4")
        self.assertTrue(rep["e1"]["ok"])
        ev = rep["evidence_id"]
        r = EC.freeze_readiness(self.db, ev)
        self.assertFalse(r["ready"])                        # 身份未人工确认 → 不得就绪
        keys = {c["key"] for c in r["checks"]}
        self.assertIn("identity_verified", keys)
        self.assertIn("official_source", keys)
        self.assertIn("all_gold_fields", keys)
        bad = [c for c in r["checks"] if not c["ok"]]
        self.assertTrue(bad)

    def test_path_get(self):
        doc = {"electrical": [{"value": "10"}, {"value": "20"}],
               "pin": [{"name": "V+"}], "basic_info": {"mpn": "X"}}
        self.assertEqual(EC._path_get(doc, "electrical[1].value"), "20")
        self.assertEqual(EC._path_get(doc, "pin[0].name"), "V+")
        self.assertEqual(EC._path_get(doc, "basic_info.mpn"), "X")
        self.assertIsNone(EC._path_get(doc, "nope[9].x"))

    def test_import_pure(self):
        import contextlib
        import importlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            importlib.reload(EC)
        self.assertEqual(buf.getvalue(), "")


class ValueSearchGuardTest(unittest.TestCase):
    """E3 值定位守卫：数字变体剥符号 + token 边界 + 裸数字行不作证据。

    事故：expected="SOIC-8" 的数字变体被抽成 "-8"（连字符当负号），命中图号
    "Figure 6-8" 并把图注当封装证据（BUF634PG4 specs.package.type）。
    """

    def test_variants_strip_sign_and_gate_digits(self):
        self.assertIn("soic-8", EC._variants("SOIC-8"))
        self.assertNotIn("-8", EC._variants("SOIC-8"))
        self.assertNotIn("8", EC._variants("SOIC-8"))      # 单位数不进数字变体
        self.assertIn("15", EC._variants("±15 V"))
        self.assertIn("3.3", EC._variants("3.3V"))         # 小数点保留
        self.assertNotIn("33", EC._variants("3.3V"))
        self.assertEqual(EC._variants(""), set())
        self.assertEqual(EC._variants(None), set())

    def test_match_token_boundary(self):
        fig = EC._norm("Figure 6-8. Power Supply Rejection vs Frequency")
        self.assertFalse(EC._match(fig, "8"))              # 图号里的 8
        self.assertFalse(EC._match(fig, "6"))
        self.assertFalse(EC._match(fig, "soic-8"))
        self.assertTrue(EC._match(EC._norm("IOIDD 10 uA MAX"), "10"))
        self.assertTrue(EC._match(EC._norm("Output current 250 mA"), "250"))
        self.assertFalse(EC._match(EC._norm("Output current 150 mA"), "15"))   # 不做裸子串
        self.assertTrue(EC._match(EC._norm("Temperature −40 to 125 °C"), "40"))
        self.assertFalse(EC._match(EC._norm("Range 1-25 V"), "25"))            # 区间尾部
        self.assertFalse(EC._match(EC._norm("1.2.3"), "1.2"))
        self.assertTrue(EC._match(EC._norm("Packages include SOIC-8 surface-mount"), "soic-8"))

    def _search(self, pages: dict, expected: str, path: str = "specs.package.type") -> list:
        import fitz
        tmp = Path(tempfile.mkdtemp(prefix="e3guard_"))
        try:
            p = tmp / "x.pdf"
            d = fitz.open()
            for _ in range(max(pages)):
                d.new_page()
            for pno, txt in pages.items():
                d[pno - 1].insert_text((72, 72), txt)
            d.save(p)
            d.close()
            with fitz.open(p) as dz:
                return EC._value_search(dz, {}, {"field_path": path, "expected": expected})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_figure_number_never_becomes_evidence(self):
        cands = self._search({2: "Figure 6-8. Power Supply Rejection vs Frequency"}, "SOIC-8")
        self.assertEqual(cands, [])

    def test_bare_number_line_not_evidence(self):
        self.assertEqual(self._search({1: "8"}, "8"), [])
        # 真的值行仍能命中（非结构字段允许文本行兜底）
        cands = self._search({1: "Packages include SOIC-8 surface-mount"}, "SOIC-8",
                             path="features[0]")
        self.assertEqual(len(cands), 1)
        self.assertEqual(cands[0]["page"], 1)
        self.assertIn("SOIC-8", cands[0]["quote"])

    def test_structural_field_skips_text_lines(self):
        """G4：封装/引脚只认表格单元格，文本行里的短数字（–20 mA）不得当 pins 证据。"""
        self.assertEqual(self._search(
            {1: "DC input clamp current IIK (VI < –0.5 V) –20 mA"}, "20"), [])
        self.assertEqual(self._search(
            {1: "Packages include SOIC-8 surface-mount"}, "SOIC-8"), [])

    def test_structural_long_cell_numeric_hit_rejected(self):
        """G5：结构字段的长单元格里出现纯数字（整句里的 –20 mA）不算命中。"""
        long_cell = EC._norm("DC input clamp current IIK (VI < –0.5 V) –20 mA , . . .")
        self.assertEqual(EC._cell_hits(long_cell, EC._variants("20"), True), [])
        self.assertTrue(EC._cell_hits(EC._norm("20 PINS"), EC._variants("20"), True))
        self.assertTrue(EC._cell_hits(EC._norm("SOIC(DW)|20"), EC._variants("SOIC-20"), True))
        # 非结构字段不受此限
        self.assertTrue(EC._cell_hits(long_cell, EC._variants("20"), False))

    def test_negative_value_still_found(self):
        # 生成 PDF 的标准字体没有 U+2212，插入后可能变成 "·"；这里只校验“能定位到该行”
        cands = self._search({1: "Operating temperature −40 to 125 °C"}, "−40",
                             path="electrical[0].value")
        self.assertTrue(cands)
        self.assertEqual(cands[0]["page"], 1)
        self.assertIn("40 to 125", cands[0]["quote"])
        # 归一化层面负号不影响 token 命中
        self.assertTrue(EC._match(EC._norm("Operating temperature −40 to 125 °C"), "40"))

    def test_prefers_figure_free_page(self):
        cands = self._search({1: "Figure 6-8. Power Supply Rejection vs Frequency",
                              2: "SOIC-8 surface-mount plastic package"}, "SOIC-8",
                             path="features[0]")
        self.assertEqual(len(cands), 1)
        self.assertEqual(cands[0]["page"], 2)
        self.assertNotIn("Figure", cands[0]["quote"])


if __name__ == "__main__":
    unittest.main()