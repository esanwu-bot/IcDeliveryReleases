# -*- coding: utf-8 -*-
"""`qc/identity_scope` 回归：评估板身份落库 + 板卡口径归一。

背景（2026-10-29 用户验收反馈）
--------------------------------
`LMK04131EVAL/NOPB` 被交付成「48 脚 WQFN 封装的芯片」：`.alts.json` 明明写了
`board: true`，主 JSON 却归到 `Integrated Circuits (ICs) / Oscillators`，
引脚表是从通用模板编的，`symbols.html` 据此画了原理图符号。

根因不在渲染器，而在**没人把身份写回去**：`board_identity.classify()` 早就
判得出评估板，结论只被 `alternatives.py` 用来跳过找替代芯片，
`basic_info.identity` 从未被写入，于是 `json_to_txt` / `symbol_svg` 的
`is_board` 永远 False。实测 `data/rebuilt` 10 件（含 3 块板）identity 全为 None。

本测试钉住的四件事
------------------
1. 身份写回 `basic_info`，且板卡/芯片两路都写（下游才能区分「判过」与「没判」）。
2. 板卡的封装、尺寸、引脚、订购表必须**搬家**而不是原样保留。
3. 板卡 + 引脚表定位不到 → 丢引脚（否则又会画出错误符号）。
4. 板载器件名推不出来时留空，**绝不**用 `family_root` 截断出来的噪声
   （`BOOSTXLC2KLED` → `BOOSTXLC2` 就是这么来的）。
"""
import copy
import json
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

IS = pytest.importorskip("qc.identity_scope")
J = pytest.importorskip("json_to_txt")


def doc_chip(mpn="ADC3910S065IRSMT", **over):
    d = {
        "basic_info": {"mpn": mpn, "manufacturer": "Texas Instruments",
                       "category": "Integrated Circuits (ICs) / Data Acquisition",
                       "subcategory": "Analog to Digital Converters",
                       "description": "test"},
        "specs": {"electrical": [], "absolute_max": [],
                  "package": {"type": "32-VQFN", "pins": 32,
                              "dimensions": "5.00 mm x 5.00 mm"},
                  "temperature": {"operating": "-40°C to 85°C"}},
        "pin_configuration": [{"pin": i, "name": f"P{i}", "description": ""}
                              for i in range(1, 33)],
        "ordering_info": [{"mpn": mpn, "package": "32-VQFN",
                           "packaging": "Tape & Reel"}],
        "features": [], "applications": [], "alternatives": [],
        "seo": {}, "metadata": {},
    }
    d.update(over)
    return d


def doc_board(mpn="ADS8568EVM-PDK", orderables=None):
    d = doc_chip(mpn)
    d["specs"]["package"] = {"type": "64-VQFN or 64-LQFP", "pins": 64,
                             "dimensions": "9.00 mm x 9.00 mm (VQFN)"}
    d["pin_configuration"] = [{"pin": i, "name": f"P{i}", "description": ""}
                              for i in range(1, 65)]
    d["ordering_info"] = orderables if orderables is not None else [
        {"mpn": "ADS8568IPAG", "package": "64-LQFP", "packaging": "Tray"},
        {"mpn": "ADS8568IPAGR", "package": "64-LQFP", "packaging": "Tape & Reel"},
    ]
    return d


# ── 1. 身份写回 ────────────────────────────────────────────────
def test_board_suffix_writes_identity():
    d = doc_board("ADS8568EVM-PDK")
    rep = IS.apply(d, "ADS8568EVM-PDK")
    assert rep["identity"] == "evaluation_board", rep
    assert d["basic_info"]["identity"] == "evaluation_board"
    assert d["basic_info"]["identity_state"], "状态也要落库，否则无法区分判过/没判"
    assert d["basic_info"]["identity_evidence"], "证据必须留档"


def test_board_prefix_boost_writes_identity():
    """BOOST 在词首时后缀规则不命中，靠 TI_BOARD_PREFIX_BOOST 兜住。"""
    d = doc_board("BOOSTXL-C2KLED", orderables=[
        {"mpn": "BOOSTXL-C2KLED", "package": "BoosterPack Module", "packaging": "Kit"}])
    rep = IS.apply(d, "BOOSTXL-C2KLED")
    assert rep["identity"] == "evaluation_board", rep
    assert rep["rule_id"] == "TI_BOARD_PREFIX_BOOST", rep


def test_chip_keeps_package_and_pins():
    d = doc_chip("ADC3910S065IRSMT")
    d["specs"]["package"] = {"type": "32-VQFN", "pins": 32, "dimensions": "5 mm"}
    d["pin_configuration"] = [{"pin": 1, "name": "VDD", "description": ""}]
    d["ordering_info"] = [{"mpn": "ADC3910S065IRSMT", "package": "32-VQFN",
                           "packaging": "Tape & Reel"}]
    rep = IS.apply(d, "ADC3910S065IRSMT")
    assert rep["identity"] == "chip"
    assert d["specs"]["package"]["type"] == "32-VQFN"
    assert d["specs"]["package"]["pins"] == 32
    assert len(d["pin_configuration"]) == 1, "芯片引脚不能被动"
    assert d["specs"]["scope"] == "device"


# ── 2. 封装 / 尺寸 / 分类 归一 ─────────────────────────────────
def test_board_package_moved_to_onboard():
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    pkg = d["specs"]["package"]
    assert pkg["type"] == "Evaluation Board", pkg
    assert pkg["pins"] == 0, "评估板没有「64 脚」这回事"
    assert pkg["dimensions"] == ""
    assert pkg["onboard_package"] == "64-VQFN or 64-LQFP"
    assert pkg["onboard_dimensions"].startswith("9.00 mm")


def test_board_category_leaves_ic_taxonomy():
    d = doc_board()
    assert d["basic_info"]["category"].startswith("Integrated Circuits")
    IS.apply(d, "ADS8568EVM-PDK")
    bi = d["basic_info"]
    assert "integrated" not in bi["category"].lower(), bi["category"]
    assert bi["device_category"].startswith("Integrated Circuits"), "原分类要留档"


def test_board_electrical_scope_declared():
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    assert d["specs"]["scope"] == "onboard_device", "电气表是板载器件参数，必须声明"


# ── 3. 订购表切分 ──────────────────────────────────────────────
def test_board_ordering_splits_chip_rows():
    d = doc_board()          # 两条都是板载芯片的卷带型号
    rep = IS.apply(d, "ADS8568EVM-PDK")
    assert d["ordering_info"] == [], "芯片订购行不能留在板卡页上"
    assert len(d["onboard_ordering_info"]) == 2
    assert rep["ordering_split"] == 2


def test_board_keeps_its_own_orderable():
    d = doc_board("BOOSTXL-C2KLED", orderables=[
        {"mpn": "BOOSTXL-C2KLED", "package": "BoosterPack Module", "packaging": "Kit"}])
    rep = IS.apply(d, "BOOSTXL-C2KLED")
    assert [o["mpn"] for o in d["ordering_info"]] == ["BOOSTXL-C2KLED"]
    assert rep["ordering_split"] == 0


# ── 4. 引脚闸门 ────────────────────────────────────────────────
def test_board_drops_pins_when_table_unlocatable():
    d = doc_board()
    rep = IS.apply(d, "ADS8568EVM-PDK")          # 不传 pdf_path -> 定位不到
    assert d["pin_configuration"] == [], "定位不到引脚表就不能发布引脚"
    assert d["pin_scope"] == "board", "发布视图已无引脚，归属应稳定为 board"
    assert rep["pins_dropped"] == 64
    assert d["metadata"]["pin_scope_reason"]


def test_chip_pins_never_dropped():
    d = doc_chip("ADC3910S065IRSMT")
    d["pin_configuration"] = [{"pin": 1, "name": "VDD", "description": ""}]
    IS.apply(d, "ADC3910S065IRSMT")
    assert len(d["pin_configuration"]) == 1
    assert d["pin_scope"] == "device"


# ── 5. 板载器件名：宁空勿错 ────────────────────────────────────
@pytest.mark.parametrize("mpn,expect", [
    ("ADS8568EVM-PDK", "ADS8568"),
    ("BOOST-DRV8711", "DRV8711"),
    ("BOOSTXL-C2KLED", ""),          # 板名不是器件名
])
def test_device_guess(mpn, expect):
    assert IS._guess_device(mpn) == expect


def test_device_not_truncated_from_own_orderable():
    """订货表里唯一一行就是自己时，family_root 会截出 BOOSTXLC2 这种噪声。"""
    d = doc_board("BOOSTXL-C2KLED", orderables=[
        {"mpn": "BOOSTXL-C2KLED", "package": "BoosterPack Module", "packaging": "Kit"}])
    rep = IS.apply(d, "BOOSTXL-C2KLED")
    assert rep["device_mpn"] == "", rep
    assert not (d["specs"]["package"].get("onboard_device") or ""), \
        "不能把料号截断当成板载器件"


# ── 6. 幂等 ────────────────────────────────────────────────────
@pytest.mark.parametrize("mpn", ["ADS8568EVM-PDK", "BOOSTXL-C2KLED", "ADC3910S065IRSMT"])
def test_apply_is_idempotent(mpn):
    d = doc_chip(mpn) if mpn == "ADC3910S065IRSMT" else doc_board(mpn)
    IS.apply(d, mpn)
    once = json.dumps(d, sort_keys=True, ensure_ascii=False)
    IS.apply(d, mpn)
    assert json.dumps(d, sort_keys=True, ensure_ascii=False) == once, \
        "重复回填不能把 onboard_package 再套一层"


# ── 7. 渲染口径 ────────────────────────────────────────────────
def test_board_page_has_no_pinout_section():
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    html = J.render(d, "en")
    assert 'id="pinout"' not in html, "板卡不该有引脚段"
    assert "evaluation module" in html.lower()
    assert "uses the" not in html or "package with 64 pins" not in html


def test_chip_page_keeps_pinout_section():
    d = doc_chip("ADC3910S065IRSMT")
    d["specs"]["package"] = {"type": "32-VQFN", "pins": 32, "dimensions": ""}
    IS.apply(d, "ADC3910S065IRSMT")
    html = J.render(d, "en")
    assert 'id="pinout"' in html
    assert "32-VQFN" in html


def test_board_notice_drops_pinout_wording():
    """板卡页脚不该再让用户去核对 pinout——它根本没有引脚段。

    同一句话还出现在 `sr_only`（读屏摘要）里，那是无障碍文本，一样不能承诺
    一个不存在的段落，所以整页扫。
    """
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    html = J.render(d, "en")
    assert 'id="pinout"' not in html
    assert "pinout" not in html.lower(), "板卡页面上不该再出现 pinout 字样"
    assert "board interfaces" in html.lower(), "免责声明应换成板卡口径"


def test_scope_sentence_not_duplicated():
    """`onboard onboard device device` 是模板占位符与兜底词叠加造成的语病。

    用 IDENTITY_REVIEW 的板（源 PDF 是芯片 datasheet）验证：只有这一路会渲染
    「values describe the onboard device」scope 声明；BOARD_CONFIRMED 的板
    （BOOST）现在走板级 scope，不再输出这句话。
    """
    d = doc_board("ADS8568EVM-PDK")
    IS.apply(d, "ADS8568EVM-PDK")
    html = J.render(d, "en")
    assert "onboard onboard" not in html
    assert "device device" not in html
    assert "board-level electrical specifications are not stated" in html.lower()


def test_unknown_device_says_so_instead_of_blank():
    """板载器件未知时不能留空、也不能把芯片封装硬套上去。

    这里刻意用一个**板卡形态**的封装（BoosterPack Module），所以没有
    `onboard_package` 可搬——正是 BOOSTXL-C2KLED 的真实形态。
    """
    d = doc_board("BOOSTXL-C2KLED", orderables=[
        {"mpn": "BOOSTXL-C2KLED", "package": "BoosterPack Module", "packaging": "Kit"}])
    d["specs"]["package"] = {"type": "BoosterPack Module", "pins": 0, "dimensions": ""}
    d["pin_configuration"] = []
    rep = IS.apply(d, "BOOSTXL-C2KLED")
    assert rep["device_mpn"] == ""
    assert not d["specs"]["package"].get("onboard_package"), "板卡形态的封装不该被当成芯片封装搬走"
    html = J.render(d, "en")
    assert "more than one device" in html, "板载器件未知时要说清楚，不能留空"
    assert "onboard device <strong>device</strong>" not in html, "不能留下占位符"


# ── 8. 回归：模板里不许再出现具体器件名 ────────────────────────
@pytest.mark.parametrize("lang", ["en", "ja", "ko", "de", "es"])
def test_scope_template_has_no_hardcoded_device(lang):
    """`scope_onboard` 曾把 DS80PCI402 写死在五语模板里，换块板就印错器件名。"""
    tpl = J.STATIC_I18N[lang]["scope_onboard"]
    assert "{device}" in tpl, tpl
    assert not re.search(r"[A-Z]{2,}[0-9]{3,}", tpl), f"模板里还有具体型号: {tpl}"


@pytest.mark.parametrize("lang", ["en", "ja", "ko", "de", "es"])
def test_board_keys_present_in_all_languages(lang):
    for k in ("board_fact_plain", "scope_onboard_plain",
              "notice_eng_post_board", "board_device_unknown", "sr_only_board"):
        assert k in J.STATIC_I18N[lang], f"{lang} 缺 {k}"


# ── 9. 技术洞察兜底必须分流 ────────────────────────────────────
def test_board_insight_has_no_footprint_advice():
    """`Lock the Package and Pinout Early` 对买评估板的人是纯噪声。

    而且板卡的 `pkg_type` 恒为 `Evaluation Board`，`if pins or pkg_type`
    这个条件**每次都会命中**，所以每块板都会印上「锁定封装和引脚」。
    """
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    html = J.render(d, "en")
    assert "Lock the Package and Pinout Early" not in html
    assert "defines the footprint" not in html, "板卡不该谈 PCB footprint"
    insight = re.search(r"pd-expert-insight(.{0,1500})", html, re.S)
    assert insight, "找不到技术洞察段"
    assert "pinout" not in insight.group(1).lower(), "板卡的技术洞察里不能提引脚"
    assert "Jumper Settings" in html
    assert "Clocking Inputs" not in html, "没有板级时钟证据时不能授予时钟检查点"
    assert "Thermal Relief and Grounding" in html


def test_chip_insight_keeps_package_advice():
    d = doc_chip("ADC3910S065IRSMT")
    d["specs"]["package"] = {"type": "32-VQFN", "pins": 32, "dimensions": "5 mm"}
    d["pin_configuration"] = [{"pin": 1, "name": "VDD", "description": ""}]
    IS.apply(d, "ADC3910S065IRSMT")
    html = J.render(d, "en")
    assert "Lock the Package and Pinout Early" in html, "芯片页仍需要这条建议"
    assert "Jumper Settings" not in html


# ── 10. 描述：LLM 是照着芯片写的 ───────────────────────────────
def test_board_description_rewritten():
    """`ADS8568EVM-PDK` 的描述原文是「…available in 64-pin VQFN and LQFP packages」，
    页面 hero 第一句就说这块板是 64 脚 QFN 封装——正是用户报的那条。"""
    d = doc_board()
    d["basic_info"]["description"] = (
        "The ADS8568 is a 16-bit SAR ADC available in 64-pin VQFN and LQFP packages.")
    rep = IS.apply(d, "ADS8568EVM-PDK")
    bi = d["basic_info"]
    assert rep["description_rewritten"] is True
    assert "evaluation board" in bi["description"]
    assert "ADS8568" in bi["description"]
    assert "VQFN" not in bi["description"], "描述里不能再说芯片封装"
    assert "VQFN" in bi["device_description"], "原文要留档，不能丢"


def test_chip_description_untouched():
    d = doc_chip()
    d["basic_info"]["description"] = "32-bit ADC in a 32-VQFN package."
    IS.apply(d, "ADC3910S065IRSMT")
    assert d["basic_info"]["description"] == "32-bit ADC in a 32-VQFN package."
    assert "device_description" not in d["basic_info"]


def test_description_rewrite_is_idempotent():
    d = doc_board()
    d["basic_info"]["description"] = "Chip prose in a 64-pin VQFN package."
    IS.apply(d, "ADS8568EVM-PDK")
    once = d["basic_info"]["description"]
    IS.apply(d, "ADS8568EVM-PDK")
    assert d["basic_info"]["description"] == once, "二次回填不能把板卡描述再包一层"


def test_multilang_chip_description_cleared():
    """多语种描述会盖掉英文描述，只改英文等于没改。"""
    d = doc_board()
    d["multi_language"] = {
        "ja": {"description": "ADS8568 は 64 ピン VQFN パッケージで供給されます。"},
        "de": {"description": "Ein Evaluationsboard für Laboruntersuchungen."},
    }
    rep = IS.apply(d, "ADS8568EVM-PDK")
    assert "description" not in d["multi_language"]["ja"], "含芯片封装的译文必须搬走"
    assert "description" in d["multi_language"]["de"], "正常描述不要动"
    assert rep["multilang_desc_cleared"] == 1


def test_board_hero_has_no_chip_package():
    d = doc_board()
    d["basic_info"]["description"] = (
        "The ADS8568 is a 16-bit SAR ADC available in 64-pin VQFN and LQFP packages.")
    IS.apply(d, "ADS8568EVM-PDK")
    html = J.render(d, "en")
    hero = re.search(r"pd-hero-desc.*?</p>", html, re.S)
    assert hero, "找不到 hero 描述"
    assert "VQFN" not in hero.group(0), "hero 里还在说芯片封装"


# ── 渲染层证据门控：板卡话术必须有源数据支持 ──────────────────────
def _board_html(mpn, features, applications=None, connectors=None):
    d = doc_board(mpn, orderables=[{"mpn": mpn, "package": "Kit", "packaging": "Kit"}])
    d["features"] = features
    d["applications"] = applications or []
    d["specs"]["connectors"] = connectors or []
    d["basic_info"].update(identity="evaluation_board", identity_state="BOARD_CONFIRMED",
                           device_mpn="")
    d["specs"]["scope"] = "board"
    return J.render(d, "en")


def test_board_insight_skips_sma_without_evidence():
    """步进驱动板没有 SMA/时钟证据 → 不许印 SMA/oscillator 套话（客户反馈③）。"""
    h = _board_html("BOOST-DRV8711", [
        "Complete stepper motor drive stage in a small form factor",
        "Supports 8.2-52 V and up to 4.5 A continuous for each H-Bridge"])
    assert "SMA" not in h and "oscillator" not in h, "无证据却渲染了 SMA/时钟话术"
    assert "Motor Outputs" in h, "有 motor 证据时应给出电机相关检查点"


def test_board_insight_keeps_sma_with_evidence():
    """合成 SMA＋clock input 正例：保留真正时钟检查，不冒充原厂证据。"""
    h = _board_html("ADS54J60EVM",
                    ["Dual-channel 16-bit 1-GSPS ADC evaluation module"],
                    connectors=["SMA connectors for analog inputs and clock input"])
    assert "Check the Interface and Clocking Inputs" in h
    assert "Check the documented clock input and its stated frequency and termination" in h
    assert "before connecting a clock source" in h


def test_board_insight_no_boilerplate_when_no_evidence_at_all():
    """连用途词都没有的板：只保留电源/散热，不编接口。"""
    h = _board_html("UNKNOWN-EVM", ["Evaluation board"])
    assert "SMA" not in h and "oscillator" not in h
    assert "Thermal Relief" in h and "Power Rails" in h


# ── 契约入口与反向订购对象隔离 ──────────────────────────────────────
def test_board_guide_named_mosfet_isolated_by_canonical_view():
    mpn = "BOOST-DRV8711"
    d = doc_board(mpn, orderables=[
        {"mpn": mpn, "package": "Evaluation Board", "packaging": "Kit"}])
    d["specs"]["package"] = {"type": "Evaluation Board", "pins": 0,
                              "dimensions": "1.75 in × 2.00 in"}
    d["pin_configuration"] = []
    power = {"parameter": "Power supply input", "value": "8.2–52", "unit": "V",
             "source": {"scope": "board", "page": 4, "table": 1, "row": 1}}
    mosfet = {"parameter": "MOSFET on-resistance", "value": "12.5", "unit": "mΩ",
              "condition": "CSD88537ND Dual 60-V N-Channel NexFET",
              "source": {"scope": "board", "page": 5, "table": 2, "row": 3}}
    d["specs"]["electrical"] = [power, mosfet]
    text = "User's Guide\nBOOST-DRV8711 BoosterPack\nBoard specifications"
    rep = IS.apply(d, mpn, pdf_text=text)
    assert d["basic_info"]["document_scope"] == "board_user_guide"
    assert d["specs"]["scope"] == rep["scope_state"] == "board"
    assert d["specs"]["electrical"] == [power]
    device = d["specs"]["onboard_device_specs"]["devices"]["CSD88537ND"]
    assert device["electrical"][0]["source"] == mosfet["source"]
    assert device["electrical"][0]["condition"] == mosfet["condition"]
    assert device["scope"] == "onboard_device"
    assert d["specs"]["package"]["dimensions"] == "1.75 in × 2.00 in"
    assert "onboard_dimensions" not in d["specs"]["package"]
    assert {"row_quarantined", "row_scope_conflict"} <= {f["kind"] for f in rep["findings"]}
    once = copy.deepcopy(d)
    IS.apply(d, mpn, pdf_text=text)
    assert d == once
    assert IS.canonical_view(d) == once


@pytest.mark.parametrize("board_mpn, package", [
    ("ADC12DJ5200SEEVM", "FCBGA (144)"),
    ("ADC12DJ5200SEEVAL", "FCBGA (144)"),
    ("ADC12DJ5200SE-EVK", "FCBGA (144)"),
    ("ASSY-123", "Evaluation Board"),
])
def test_chip_ordering_separates_related_evaluation_boards_with_source(board_mpn, package):
    mpn = "ADC12DJ5200SE"
    d = doc_chip(mpn)
    chip_order = copy.deepcopy(d["ordering_info"][0])
    board_order = {"mpn": board_mpn, "package": package, "packaging": "Tape & Reel",
                   "source": {"page": 2, "table": 1, "row": 3, "pdf_sha256": "source-hash"}}
    d["ordering_info"].append(board_order)
    existing = {"mpn": "EXISTING-EVM", "source": {"page": 1}}
    d["related_evaluation_boards"] = [existing]
    rep = IS.apply(d, mpn)
    assert rep["identity"] == "chip"
    assert rep["ordering_split"] == 1
    assert d["ordering_info"] == [chip_order]
    assert d["specs"]["scope"] == "device"
    related = d["related_evaluation_boards"]
    assert related[0] == existing, "已有关联板卡不能被覆盖"
    board = related[1]
    assert board["mpn"] == board_mpn
    assert board["scope"] == "board" and board["subject_kind"] == "evaluation_board"
    assert board["source"] == board_order["source"]
    assert board["scope_reason"]
    assert "package" not in board and "packaging" not in board
    assert board["original_ordering_row"] == board_order, "被隔离的错误封装也必须可追溯"
    once = copy.deepcopy(d)
    IS.apply(d, mpn)
    assert d == once, "反向切分不能令二次分类证据计数改变"
    d["ordering_info"].append(copy.deepcopy(board_order))
    IS.apply(d, mpn)
    assert d == once, "同一订购行重新进入时必须合并去重"


def test_related_board_without_source_records_origin_not_chip_package():
    mpn = "ADC12DJ5200SE"
    d = doc_chip(mpn)
    d["ordering_info"].append({"mpn": "ADC12DJ5200SEEVM", "package": "FCBGA (144)"})
    IS.apply(d, mpn, pdf_path="data/pdfs/adc12dj5200se.pdf")
    board = d["related_evaluation_boards"][0]
    assert board["source"] == {"field": "ordering_info", "requested_mpn": mpn,
                                "pdf_path": "data/pdfs/adc12dj5200se.pdf"}
    assert "package" not in board
    assert board["original_ordering_row"]["package"] == "FCBGA (144)"


@pytest.mark.parametrize("orders", [[], [{"mpn": "ADC12DJ5200SEEVM", "package": "FCBGA (144)"}]])
def test_unknown_identity_does_not_default_to_chip(orders):
    mpn = "ADC12DJ5200SE"
    d = doc_chip(mpn, ordering_info=copy.deepcopy(orders))
    d["specs"]["electrical"] = [{"parameter": "Resolution", "value": "12", "unit": "bit"}]
    original_package = copy.deepcopy(d["specs"]["package"])
    original_pins = copy.deepcopy(d["pin_configuration"])
    rep = IS.apply(d, mpn)
    assert rep["identity"] == d["basic_info"]["identity"] == "unknown"
    assert d["specs"]["scope"] == d["pin_scope"] == "unresolved"
    assert d["specs"]["electrical"] == [] and d["pin_configuration"] == []
    isolated = d["specs"]["unresolved_specs"]
    assert isolated["package"] == original_package
    assert isolated["pin_configuration"] == original_pins
    assert "unknown_identity" in {f["kind"] for f in rep["findings"]}
    if orders:
        assert d["ordering_info"] == []
        assert d["related_evaluation_boards"][0]["original_ordering_row"] == orders[0]
    once = copy.deepcopy(d)
    IS.apply(d, mpn)
    assert d == once, "未知身份重复回填不得把空封装二次新增到隔离历史"
    assert IS.canonical_view(d) == once


def test_board_reintroduced_chip_ordering_merges_instead_of_overwriting():
    d = doc_board()
    IS.apply(d, "ADS8568EVM-PDK")
    previous = copy.deepcopy(d["onboard_ordering_info"])
    new_order = {"mpn": "ADS8568IRGCR", "package": "64-VQFN", "packaging": "Tape & Reel"}
    d["ordering_info"] = [new_order]
    IS.apply(d, "ADS8568EVM-PDK")
    assert d["onboard_ordering_info"] == previous + [new_order]
    once = copy.deepcopy(d)
    IS.apply(d, "ADS8568EVM-PDK")
    assert d == once
