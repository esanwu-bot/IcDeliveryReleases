# -*- coding: utf-8 -*-
"""重解析防呆守卫的回归测试（batch20 实测形态）。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import reparse_guard as G  # noqa: E402


def doc(elec=0, thermal=0, esd=0, pins=0):
    return {
        "specs": {
            "electrical": [{"name": f"e{i}"} for i in range(elec)],
            "thermal": [{"name": f"t{i}"} for i in range(thermal)],
            "esd": [{"name": f"d{i}"} for i in range(esd)],
        },
        "pin_configuration": [{"pin": i} for i in range(pins)],
    }


def test_invalid_new_is_rejected():
    r = G.guard(doc(elec=20), None)
    assert r["accept"] is False and r["reason"] == "invalid_json"
    # JSON 里是字符串（模型吐了非对象）同样算非法
    r2 = G.guard(doc(elec=20), "not-a-doc")
    assert r2["accept"] is False and r2["reason"] == "invalid_json"


def test_empty_electrical_is_rejected():
    """ADC12QJ1600ALREP 实测：新产物 electrical=0，旧的有 12 行。"""
    r = G.guard(doc(elec=12, thermal=0, esd=0), doc(elec=0, thermal=3, esd=2))
    assert r["accept"] is False and r["reason"] == "electrical_empty"


def test_shrunk_electrical_is_rejected():
    r = G.guard(doc(elec=57), doc(elec=47))
    assert r["accept"] is False and r["reason"] == "electrical_shrunk"


def test_lost_container_is_rejected():
    """旧有 thermal 5 行，新产物 0 行 —— 不能因为「新解析」就丢掉已有数据。"""
    r = G.guard(doc(elec=20, thermal=5, esd=2), doc(elec=25, thermal=0, esd=2))
    assert r["accept"] is False and r["reason"] == "container_lost:thermal"


def test_same_quality_is_accepted():
    r = G.guard(doc(elec=20, thermal=0, esd=0), doc(elec=20, thermal=0, esd=0))
    assert r["accept"] is True


def test_better_is_accepted():
    r = G.guard(doc(elec=18, thermal=0, esd=0), doc(elec=23, thermal=5, esd=2))
    assert r["accept"] is True


def test_source_without_tables_is_not_a_reject_reason():
    """ADS1286U / BQ48SH 实测：源 PDF 文本层没有 Thermal/ESD 表。

    「新产物 thermal 仍为 0」不是覆盖坏数据的理由 —— 它和旧数据同质，
    守卫必须放行（否则所有老 datasheet 都会被永久锁死在旧版本）。
    """
    r = G.guard(doc(elec=57, thermal=0, esd=0), doc(elec=57, thermal=0, esd=0))
    assert r["accept"] is True, r
