"""qc/ds_cloud.py 离线单测：云端开关、来源白名单、敏感路径、凭据校验、dry-run。

原则：**不发任何网络请求**、不写生产库、不改仓库文件（全部在临时目录）。
"""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import ds_cloud as ds                       # noqa: E402


class CloudBoundaryTest(unittest.TestCase):
    def setUp(self):
        self._env = dict(os.environ)
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.pdf = self.dir / "ABC123.pdf"
        self.pdf.write_bytes(b"%PDF-1.4\n% fake\n")

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._env)
        self.tmp.cleanup()

    def _allow(self):
        os.environ["ICPDF_DS_CLOUD"] = "1"
        os.environ["ICPDF_DS_ALLOW_DIRS"] = str(self.dir)

    # ---------------- 开关 ----------------
    def test_switch_off_rejects(self):
        os.environ.pop("ICPDF_DS_CLOUD", None)
        with self.assertRaises(SystemExit) as cm:
            ds.check_source(self.pdf)
        self.assertIn("云端开关未开启", str(cm.exception))

    def test_allow_dir_ok(self):
        self._allow()
        self.assertEqual(ds.check_source(self.pdf), self.pdf.resolve())

    # ---------------- 来源白名单 ----------------
    def test_outside_whitelist_rejected(self):
        os.environ["ICPDF_DS_CLOUD"] = "1"
        os.environ.pop("ICPDF_DS_ALLOW_DIRS", None)
        with self.assertRaises(SystemExit) as cm:
            ds.check_source(self.pdf)
        self.assertIn("白名单", str(cm.exception))

    def test_sensitive_marker_rejected(self):
        sub = self.dir / "uploads"
        sub.mkdir()
        p = sub / "ABC123.pdf"
        p.write_bytes(b"%PDF-1.4\n")
        self._allow()                     # 目录已进白名单，但 uploads 标记必须挡住
        with self.assertRaises(SystemExit) as cm:
            ds.check_source(p)
        self.assertIn("敏感标记", str(cm.exception))

    def test_missing_file(self):
        self._allow()
        with self.assertRaises(SystemExit) as cm:
            ds.check_source(self.dir / "nope.pdf")
        self.assertIn("文件不存在", str(cm.exception))

    # ---------------- 凭据 ----------------
    def test_token_missing(self):
        os.environ.pop("NANONETS_API_KEY", None)
        os.environ["ICPDF_DS_CRED"] = str(self.dir / "nope.json")
        with self.assertRaises(SystemExit) as cm:
            ds._token()
        self.assertIn("未认证", str(cm.exception))

    def test_token_expired(self):
        cred = self.dir / "cred.json"
        cred.write_text(json.dumps({"access_token": "t", "expires_at": 1}), encoding="utf-8")
        os.environ["ICPDF_DS_CRED"] = str(cred)
        os.environ.pop("NANONETS_API_KEY", None)
        with self.assertRaises(SystemExit) as cm:
            ds._token()
        self.assertIn("已过期", str(cm.exception))

    def test_api_key_env_wins(self):
        os.environ["NANONETS_API_KEY"] = "env-key"
        self.assertEqual(ds._token(), "env-key")

    # ---------------- dry-run / CLI ----------------
    def test_dry_run_no_network(self):
        self._allow()
        out = self.dir / "out.md"
        ds.convert(self.pdf, out, dry_run=True)    # 无 token 也不应报错
        self.assertFalse(out.exists())

    def test_cli_allow_cloud_flag(self):
        out = self.dir / "out.md"
        os.environ["ICPDF_DS_ALLOW_DIRS"] = str(self.dir)   # --allow-cloud 不放宽来源白名单
        with mock.patch.object(sys, "argv",
                               ["ds_cloud.py", str(self.pdf), str(out),
                                "--allow-cloud", "--dry-run"]):
            self.assertEqual(ds.main(), 0)
        self.assertFalse(out.exists())

    def test_cli_allow_cloud_still_checks_source(self):
        """--allow-cloud 只开总开关；白名单不含该目录时仍拒绝（安全底线不可绕过）。"""
        out = self.dir / "out.md"
        os.environ.pop("ICPDF_DS_ALLOW_DIRS", None)
        os.environ.pop("ICPDF_DS_CLOUD", None)
        with mock.patch.object(sys, "argv",
                               ["ds_cloud.py", str(self.pdf), str(out),
                                "--allow-cloud", "--dry-run"]):
            with self.assertRaises(SystemExit) as cm:
                ds.main()
        self.assertIn("白名单", str(cm.exception))

    def test_cli_usage_error(self):
        with mock.patch.object(sys, "argv", ["ds_cloud.py", "only-one"]):
            self.assertEqual(ds.main(), 2)


if __name__ == "__main__":
    unittest.main()
