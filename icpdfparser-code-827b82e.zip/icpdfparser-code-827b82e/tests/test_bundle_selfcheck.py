#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付包自证链自检（`qc/bundle_selfcheck.py`）的用例。

为什么这组用例必须存在
----------------------
V5 被判「自证链断裂」的真实经过：侧车说 ``i18n_coverage = 1.0``，清单说
``0.9837``，两边哈希都对不上 —— 不是数据错，是**同一天修订重出包时人漏了一步**。
修法不是「下次记得」，而是打包末尾逐项重算、对不上就中断。

于是这里要证明两件事：
1. 干净包必须**零告警**通过（否则告警会被当噪音，闸门失效）；
2. 每一类「人漏一步」都必须被**单独**抓出来（否则闸门只在理论上有用）。

第 2 条刻意做成**逐项独立**用例而不是一个大用例：一个大用例只会在第一个断言
处停下，后面几类坏法就永远没被验证过。
"""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as B                                     # noqa: E402
from qc import bundle_selfcheck as S                            # noqa: E402

MPN = "DEMO-1"
TEXT = "<div class=\"pd-wrap\">\n<p>DEMO-1</p>\n</div>\n"
PDF = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<<>>\nendobj\n"


# ── 夹具 ─────────────────────────────────────────────────────────
def _sha_text(p: Path) -> str:
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def _sha_raw(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def build(tmp_path: Path) -> Path:
    """造一个「各处都对得上」的最小包。返回包根目录。"""
    out = tmp_path / "delivery-demo"
    shard = out / "part-0001-of-0001"
    base = shard / MPN
    base.mkdir(parents=True)

    # HTML 刻意写成 CRLF —— 文本口径必须是「归一后哈希」，否则跨平台复核必红。
    (base / f"{MPN}.html").write_bytes(TEXT.replace("\n", "\r\n").encode("utf-8"))
    (base / f"{MPN}.pdf").write_bytes(PDF)
    # 侧车必须**五语齐全**：V2 起 `i18n_complete=true` 的唯一条件是
    # `set(langs) >= REQUIRED_LANGS`，只写 ja/ko 会被重算成 false。
    (base / f"{MPN}.i18n.json").write_text(json.dumps({
        "languages": {
            "en": {"i18n_complete": True, "i18n_coverage": {"ratio": 1.0}},
            "ja": {"i18n_complete": True, "i18n_coverage": {"ratio": 1.0}},
            "ko": {"i18n_complete": True, "i18n_coverage": {"ratio": 0.91}},
            "de": {"i18n_complete": True, "i18n_coverage": {"ratio": 1.0}},
            "es": {"i18n_complete": True, "i18n_coverage": {"ratio": 1.0}},
        }
    }, ensure_ascii=False), encoding="utf-8")
    (shard / "facts_audit.csv").write_text(
        "mpn,label,verdict,kind,value,bbox,row_sha256,paragraph_sha256\n"
        f'{MPN},A,verified_row,table,1,"[1,2,3,4]",abc,\n'
        f'{MPN},B,verified_paragraph,prose,2,"[1,2,3,5]",,def\n'
        f"{MPN},C,unchecked,table,,,,\n",
        encoding="utf-8")

    members = []
    for p in sorted(shard.rglob("*")):
        if not p.is_file():
            continue
        arc = p.relative_to(shard).as_posix()
        is_pdf = arc.endswith(".pdf")
        members.append({
            "member": arc, "key": "pdf" if is_pdf else "artifact",
            # size 与 sha256 同一口径：文本按 CRLF→LF 归一后计长，PDF 取原始字节。
            "size": len(p.read_bytes()) if is_pdf
                    else len(p.read_bytes().replace(b"\r\n", b"\n")),
            "sha256": _sha_raw(p) if is_pdf else _sha_text(p),
            "source": str(p),
        })

    present = ["json", "txt", "html", "symbols", "seo", "alts"]
    manifest = {
        "schema_version": "acceptance-delivery/v1",
        "shard": "part-0001-of-0001.zip",
        "members": members,
        "records": [{
            "requested_mpn": MPN, "safe_name": MPN,
            # V7：一列 `data_anchor` 拆成四列 + 闸门结论
            # V9：交付说明实测表多一列 `facts_verdict`，清单这边必须同时有，
            # 否则「说明印了、清单没有」会被判不一致（这正是要拦的那类错）。
            "facts_verdict": "pass",
            "row_anchor": "1/3",
            "paragraph_anchor": "1/3",
            "container_verified": "0/3",
            "coord_anchor": "2/3",
            "anchor_gate": "pass",
            "i18n_complete": "true",
            # 取**最低**的那个语言（0.91），不是最好看的 1.0。
            "i18n_coverage": "0.9100",
            "pdf_included": True,
            "pdf_sha256_recorded": _sha_raw(base / f"{MPN}.pdf"),
            "pdf_sha256_packaged": _sha_raw(base / f"{MPN}.pdf"),
            "pdf_hash_match": True,
            "artifacts": f"{len(present)}/8",
            "present": present,
            "release_state": "IDENTITY_APPROVED",
        }],
    }
    (out / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    # ZIP 用 STORED：DEFLATED 会把 CRLF 压掉，用例会假通过（V4 踩过这个坑）。
    zpath = out / "part-0001-of-0001.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:
        for m in members:
            z.write(shard / m["member"], m["member"])

    # 《交付说明.md》由打包器渲染，自检逐格比对（V7 的 P0）。
    (out / "交付说明.md").write_text(
        f"# 交付说明（{out.name}）\n\n"
        + S.NOTE_TABLE_HEAD + "\n|---|---|---|---|---|---|---|---|\n"
        + f"| `{MPN}` | 3 | 1 | 1 | 1 | pass | pass | IDENTITY_APPROVED | NONE |\n",
        encoding="utf-8")

    (out / "包校验报告.json").write_text(json.dumps({
        "zip_sha256": _sha_raw(zpath),
        "verified_members": [{"member": m["member"], "sha256": m["sha256"]}
                             for m in members],
        "i18n_validation": "measured",
    }, ensure_ascii=False), encoding="utf-8")
    return out


def _man(out: Path) -> dict:
    return json.loads((out / "manifest.json").read_text(encoding="utf-8"))


def _save_man(out: Path, man: dict) -> None:
    (out / "manifest.json").write_text(
        json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")


# ── 契约：两份 ANCHORED_VERDICTS 必须相等 ────────────────────────
def test_anchored_verdicts_are_identical():
    """自检不复用打包器的函数，但**口径必须同一份契约**。

    两边各写一份常量是故意的（共用函数写错了自检也跟着错）；代价是它们会漂。
    这条用例就是防漂的钉子：任何一边加了新结论而另一边没加，立刻红。
    """
    assert S.ANCHORED_VERDICTS == B.ANCHORED_VERDICTS


def test_verified_paragraph_counts_as_anchored():
    """`verified_paragraph` 是坐标级结论，必须计入坐标级分子。"""
    assert "verified_paragraph" in B.ANCHORED_VERDICTS
    assert "verified_paragraph" in S.ANCHORED_VERDICTS


def test_container_level_verified_is_not_anchored():
    """V7 P0：容器级 `verified` 没有坐标，**不得**计入锚定。

    V6 把它算进去，于是 ADS8568EVM-PDK 零坐标却 `14/14` 进 `DATA_VALIDATED`。
    """
    assert "verified" not in B.ANCHORED_VERDICTS
    assert "verified" not in S.ANCHORED_VERDICTS


# ── 干净包必须零告警 ─────────────────────────────────────────────
def test_clean_bundle_passes(tmp_path):
    bad = S.check(build(tmp_path))
    assert bad == [], f"干净包被判不一致：{bad}"


def test_text_member_hashed_after_newline_normalization(tmp_path):
    """CRLF 的 HTML 必须按 LF 归一后比对 —— 否则 git clone 后必红。"""
    out = build(tmp_path)
    raw = (out / "part-0001-of-0001" / MPN / f"{MPN}.html").read_bytes()
    assert b"\r\n" in raw, "夹具本身没造出 CRLF"
    assert _sha_text(out / "part-0001-of-0001" / MPN / f"{MPN}.html") \
        != _sha_raw(out / "part-0001-of-0001" / MPN / f"{MPN}.html")
    assert S.check(out) == []


def test_pdf_member_hashed_as_raw_bytes(tmp_path):
    """PDF 按原始字节 —— 归一一次哈希就变了，复核方 `sha256sum` 永远对不上。"""
    out = build(tmp_path)
    man = _man(out)
    pdf_m = next(m for m in man["members"] if m["member"].endswith(".pdf"))
    assert pdf_m["sha256"] == _sha_raw(out / "part-0001-of-0001" / MPN / f"{MPN}.pdf")


def test_member_size_uses_same_normalization_as_hash(tmp_path):
    """`size` 必须与 `sha256` 同一口径：文本按 CRLF→LF 归一后计长。

    实测故障：`core.autocrlf=true` 的 Windows 上 `git clone` 交付仓库，
    三个 `.md` 被写成 CRLF（11653 → 11856），哈希仍匹配而大小不匹配 ——
    复核方看到「哈希对、大小不对」会当成数据被改，白查一轮。
    """
    out = build(tmp_path)
    man = _man(out)
    html = out / "part-0001-of-0001" / MPN / f"{MPN}.html"
    raw = html.read_bytes()
    assert b"\r\n" in raw, "夹具本身没造出 CRLF"
    m = next(x for x in man["members"] if x["member"].endswith(f"{MPN}.html"))
    # 记录值 = 归一后长度，不是磁盘上的原始字节数
    assert m["size"] == len(raw.replace(b"\r\n", b"\n"))
    assert m["size"] != len(raw)
    # 模拟 autocrlf 把 LF 全写成 CRLF 的对端：哈希与大小都仍应通过
    html.write_bytes(raw.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
    assert S.check(out) == [], "CRLF 环境下 clone 出来的包被误判"
    # PDF 仍按原始字节计长
    pdf_m = next(x for x in man["members"] if x["member"].endswith(".pdf"))
    assert pdf_m["size"] == len((out / "part-0001-of-0001" / MPN / f"{MPN}.pdf")
                                .read_bytes())


# ── 每类「人漏一步」都要被单独抓到 ───────────────────────────────
def test_stale_i18n_coverage_is_caught(tmp_path):
    """清单停在修订前的覆盖率（V5 的真实故障）。"""
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["i18n_coverage"] = "0.9837"
    _save_man(out, man)
    bad = S.check(out)
    assert any("i18n_coverage" in x for x in bad), bad


def test_stale_i18n_complete_is_caught(tmp_path):
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["i18n_complete"] = "false"
    _save_man(out, man)
    assert any("i18n_complete" in x for x in S.check(out))


def test_missing_sidecar_but_claimed_complete_is_caught(tmp_path):
    """没有侧车却写了 `i18n_complete=true` —— 无凭据的主张。"""
    out = build(tmp_path)
    (out / "part-0001-of-0001" / MPN / f"{MPN}.i18n.json").unlink()
    bad = S.check(out)
    assert any("无侧车" in x for x in bad), bad


def test_member_hash_drift_is_caught(tmp_path):
    """成员文件被改过（或清单忘了重算）。"""
    out = build(tmp_path)
    p = out / "part-0001-of-0001" / MPN / f"{MPN}.html"
    p.write_bytes(p.read_bytes() + b"<!-- drift -->\n")
    bad = S.check(out)
    assert any("成员哈希不符" in x for x in bad), bad


def test_member_size_drift_is_caught(tmp_path):
    out = build(tmp_path)
    p = out / "part-0001-of-0001" / MPN / f"{MPN}.html"
    p.write_bytes(p.read_bytes() + b"<!-- size -->\n")
    assert any("成员大小不符" in x for x in S.check(out))


def test_missing_member_is_caught(tmp_path):
    out = build(tmp_path)
    (out / "part-0001-of-0001" / MPN / f"{MPN}.pdf").unlink()
    bad = S.check(out)
    assert any("成员缺失" in x for x in bad), bad


def test_anchor_column_mismatch_is_caught(tmp_path):
    """清单自述行级 2/3，随包 CSV 重算是 1/3 —— 弱证据不许被写成强证据。"""
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["row_anchor"] = "2/3"
    _save_man(out, man)
    bad = S.check(out)
    assert any("row_anchor" in x for x in bad), bad


def test_anchor_gate_with_only_container_evidence_is_blocked(tmp_path):
    """三行全是容器级复现（无坐标）→ 重算的闸门必须是 blocked。

    这正是 8.9 分复审的 P0 现场：ADS8568EVM-PDK 14 行零坐标，清单写 `14/14`。
    """
    out = build(tmp_path)
    csv_path = out / "part-0001-of-0001" / "facts_audit.csv"
    csv_path.write_text(
        "mpn,label,verdict,kind,value,bbox,row_sha256,paragraph_sha256\n"
        f"{MPN},A,verified,table,1,,,\n"
        f"{MPN},B,verified,table,2,,,\n",
        encoding="utf-8")
    # 成员哈希变了，这里只关心锚定列的重算结果：直接断言重算函数
    got = S._anchor_from_csv(csv_path, MPN)
    assert got["row_anchor"] == "0/2"
    assert got["container_verified"] == "2/2"
    assert got["anchor_gate"] == "blocked"


def test_artifacts_count_mismatch_is_caught(tmp_path):
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["artifacts"] = "8/8"
    _save_man(out, man)
    assert any("artifacts" in x for x in S.check(out))


def test_pdf_hash_match_false_when_files_differ(tmp_path):
    """随包 PDF 与被解析的那份不是同一份 —— 这是 `gate=BLOCKED` 的判据。"""
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["pdf_sha256_recorded"] = "0" * 64
    _save_man(out, man)
    bad = S.check(out)
    assert any("pdf_hash_match" in x for x in bad), bad


def test_pdf_claimed_but_absent_is_caught(tmp_path):
    out = build(tmp_path)
    (out / "part-0001-of-0001" / MPN / f"{MPN}.pdf").unlink()
    man = _man(out)
    man["members"] = [m for m in man["members"] if not m["member"].endswith(".pdf")]
    _save_man(out, man)
    assert any("pdf_included=true 但包内无 PDF" in x for x in S.check(out))


# ── ZIP 侧：复核方拿到的就是这一份 ───────────────────────────────
def test_zip_member_hash_mismatch_is_caught(tmp_path):
    out = build(tmp_path)
    zpath = out / "part-0001-of-0001.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:
        z.writestr(f"{MPN}/{MPN}.html", "<div>tampered</div>\n")
    bad = S.check(out)
    assert any("ZIP 内缺成员" in x or "ZIP 成员哈希" in x for x in bad), bad


def test_zip_illegal_path_is_caught(tmp_path):
    """绝对路径 / `..` / 反斜杠 —— 解压会写到包外。"""
    out = build(tmp_path)
    zpath = out / "part-0001-of-0001.zip"
    with zipfile.ZipFile(zpath, "a", zipfile.ZIP_STORED) as z:
        z.writestr("../escape.txt", "x")
    assert any("ZIP 非法路径" in x for x in S.check(out))


# ── 校验报告侧：`zip_sha256` 与 `i18n_validation` ────────────────
def test_zip_sha256_drift_is_caught(tmp_path):
    out = build(tmp_path)
    rep = json.loads((out / "包校验报告.json").read_text(encoding="utf-8"))
    rep["zip_sha256"] = "f" * 64
    (out / "包校验报告.json").write_text(
        json.dumps(rep, ensure_ascii=False), encoding="utf-8")
    assert any("zip_sha256" in x for x in S.check(out))


def test_i18n_validation_not_checked_is_caught(tmp_path):
    """清单已给实测覆盖率，报告却写 `not_checked` —— 口径自相矛盾。

    V5 就是被这条抓出来的：自检跑起来才发现报告字段还停在旧名字上。
    """
    out = build(tmp_path)
    rep = json.loads((out / "包校验报告.json").read_text(encoding="utf-8"))
    rep["i18n_validation"] = "not_checked"
    (out / "包校验报告.json").write_text(
        json.dumps(rep, ensure_ascii=False), encoding="utf-8")
    assert any("i18n_validation" in x for x in S.check(out))


def test_verified_members_drift_is_caught(tmp_path):
    out = build(tmp_path)
    rep = json.loads((out / "包校验报告.json").read_text(encoding="utf-8"))
    rep["verified_members"][0]["sha256"] = "a" * 64
    (out / "包校验报告.json").write_text(
        json.dumps(rep, ensure_ascii=False), encoding="utf-8")
    assert any("verified_members" in x for x in S.check(out))


# ── 缺件与坏件：不能抛异常，只能报出来 ───────────────────────────
def test_missing_manifest_is_reported_not_raised(tmp_path):
    out = tmp_path / "empty"
    out.mkdir()
    bad = S.check(out)
    assert bad and "manifest.json" in bad[0]


def test_missing_shard_dir_is_reported(tmp_path):
    out = build(tmp_path)
    import shutil
    shutil.rmtree(out / "part-0001-of-0001")
    assert any("缺分卷目录" in x for x in S.check(out))


def test_cli_exit_codes(tmp_path, capsys):
    out = build(tmp_path)
    assert S.main(["--out", str(out)]) == 0
    man = _man(out)
    man["records"][0]["i18n_coverage"] = "0.0001"
    _save_man(out, man)
    assert S.main(["--out", str(out)]) == 1
    assert "自证链不一致" in capsys.readouterr().err


# ── 交付说明与清单一致性（V7 的 P0：说明停在上一版）─────────────
def test_delivery_note_stale_version_is_caught(tmp_path):
    """标题还写着上一版 —— V7 真实故障（包是 V7，说明是 V6）。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace(out.name, "delivery-20260101-V0"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("标题" in x for x in bad), bad


def test_delivery_note_state_mismatch_is_caught(tmp_path):
    """说明里写 DATA_VALIDATED，清单里是 PACKAGING_PASSED。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace("IDENTITY_APPROVED",
                                                       "DATA_VALIDATED"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("release_state" in x for x in bad), bad


def test_delivery_note_counts_mismatch_is_caught(tmp_path):
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace("| 3 | 1 | 1 |",
                                                       "| 3 | 2 | 1 |"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("row_anchor" in x for x in bad), bad


def test_delivery_note_retired_metric_is_caught(tmp_path):
    """说明里还引用已废止的 `data_anchor`。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n看看 data_anchor 就知道\n",
                 encoding="utf-8")
    bad = S.check(out)
    assert any("data_anchor" in x for x in bad), bad


def test_delivery_note_stale_signoff_sentence_is_caught(tmp_path):
    """已签核的包仍写着「未申请」—— 外审 V3.1 抓的就是这种「说明比数据旧」。

    这条禁用词**只在已签核包生效**：未申请签核的包写这句是事实陈述，而且正是
    `render_delivery_note()` 的模板原文。2026-11-05 batch100 自检把未签核包的
    这句误判成红，是模板/自检契约冲突；条件化判据后仍锁死本护栏 —— 已签核
    包敢写这句，必须红。
    """
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["content_signoff"] = "APPROVED (with warnings)"
    _save_man(out, man)
    p = out / "交付说明.md"
    txt = p.read_text(encoding="utf-8").replace(
        "| IDENTITY_APPROVED | NONE |",
        "| IDENTITY_APPROVED | APPROVED (with warnings) |")
    p.write_text(txt
                 + "\n- `CONTENT_APPROVED` / `RELEASE_APPROVED` 未申请，需人工签核\n",
                 encoding="utf-8")
    bad = S.check(out)
    assert any("未申请" in x for x in bad), bad
    # 合法的单行表述不能被误伤：`RELEASE_APPROVED` 本来就该写未申请
    assert not any("RELEASE_APPROVED` 未申请，需人工签核" == f for f in S.NOTE_FORBIDDEN)
    # 反向护栏（同一用例内，不另增测试数量）：同一句在**未签核**包里是合法
    # 表述。batch100 的 364MB 包内《交付说明.md》就是这句模板原文，被
    # manifest.members 哈希锁住且已在 ZIP 内，绝不能为了过检去改包内文档。
    out2 = build(tmp_path / "unsigned")
    p2 = out2 / "交付说明.md"
    p2.write_text(p2.read_text(encoding="utf-8")
                  + "\n- `CONTENT_APPROVED` / `RELEASE_APPROVED` 未申请，需人工签核\n",
                  encoding="utf-8")
    assert not any("未申请" in x for x in
                   S._check_delivery_note(out2, _man(out2)))


def test_missing_delivery_note_is_caught(tmp_path):
    out = build(tmp_path)
    (out / "交付说明.md").unlink()
    bad = S.check(out)
    assert any("缺交付说明" in x for x in bad), bad


def test_report_has_delivery_note_item(tmp_path):
    out = build(tmp_path)
    rep = S.report(out)
    assert any(x["item"] == "delivery_note.consistency" and x["ok"]
               for x in rep["items"]), [x["item"] for x in rep["items"]]


# ── 交付说明与清单一致性（V7 的 P0：说明停在上一版）─────────────
def test_delivery_note_stale_version_is_caught(tmp_path):
    """标题还写着上一版 —— V7 真实故障（包是 V7，说明是 V6）。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace(out.name, "delivery-20260101-V0"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("标题" in x for x in bad), bad


def test_delivery_note_state_mismatch_is_caught(tmp_path):
    """说明里写 DATA_VALIDATED，清单里是 PACKAGING_PASSED。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace("IDENTITY_APPROVED",
                                                       "DATA_VALIDATED"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("release_state" in x for x in bad), bad


def test_delivery_note_counts_mismatch_is_caught(tmp_path):
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8").replace("| 3 | 1 | 1 |",
                                                       "| 3 | 2 | 1 |"),
                 encoding="utf-8")
    bad = S.check(out)
    assert any("row_anchor" in x for x in bad), bad


def test_delivery_note_retired_metric_is_caught(tmp_path):
    """说明里还引用已废止的 `data_anchor`。"""
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n看看 data_anchor 就知道\n",
                 encoding="utf-8")
    bad = S.check(out)
    assert any("data_anchor" in x for x in bad), bad


def test_missing_delivery_note_is_caught(tmp_path):
    out = build(tmp_path)
    (out / "交付说明.md").unlink()
    bad = S.check(out)
    assert any("缺交付说明" in x for x in bad), bad


def test_report_has_delivery_note_item(tmp_path):
    out = build(tmp_path)
    rep = S.report(out)
    assert any(x["item"] == "delivery_note.consistency" and x["ok"]
               for x in rep["items"]), [x["item"] for x in rep["items"]]


# ── 2026-11-05：batch100 step5 拒绝出包的两处自检缺陷 ────────────────
def _pkg_with_json(tmp_path: Path, doc: dict) -> Path:
    """只造「包内一份 JSON」，够 `_container_state()` 用。

    不套 `build()`：这里要验的是容器状态的**重算**，与清单/哈希/ZIP 无关；
    把无关物料拖进来只会让用例失败时看不出是哪一层坏的。
    """
    out = tmp_path / "delivery-probe"
    d = out / "part-0001-of-0001" / MPN
    d.mkdir(parents=True)
    (d / f"{MPN}.json").write_text(json.dumps(doc, ensure_ascii=False),
                                   encoding="utf-8")
    return out


def test_nested_onboard_electrical_escaped_ac_row_is_fail(tmp_path):
    """板卡件的 AC 逃逸行躲在**二级容器**里，重算也必须判 `fail`。

    实测来源：AFE7950 的 `specs.onboard_device_specs.electrical` 有 64 条
    SNR/THD 之类无 `bbox + row_sha256` 的行。清单如实记 `fail`，旧的自检只扫
    `specs` 第一层 list，算出 `pass`，于是「清单 fail / 自检 pass」把 step5
    顶死在「包内自证链不一致」。判松了，不是判严了。
    """
    doc = {
        "basic_info": {"mpn": MPN, "identity": "evaluation_board"},
        "specs": {
            "scope": "board",
            "electrical": [{"name": "VDD", "value": "3.3", "unit": "V"}],
            "onboard_device_specs": {"electrical": [
                {"name": "SNR", "value": "73.9", "unit": "dB"},
            ]},
        },
    }
    out = _pkg_with_json(tmp_path, doc)
    assert S._container_state(out, MPN)["integrity"] == "fail"


def test_escaped_row_with_own_provenance_is_not_fail(tmp_path):
    """同一条 AC 行若自带 `bbox + row_sha256`，它就是独立取证的，不算逃逸。"""
    doc = {
        "basic_info": {"mpn": MPN, "identity": "evaluation_board"},
        "specs": {
            "scope": "board",
            "onboard_device_specs": {"electrical": [
                {"name": "SNR", "value": "73.9", "unit": "dB",
                 "bbox": [1, 2, 3, 4], "row_sha256": "a" * 64},
            ]},
        },
    }
    out = _pkg_with_json(tmp_path, doc)
    assert S._container_state(out, MPN)["integrity"] == "pass"


def test_chip_main_electrical_ac_row_is_not_escape(tmp_path):
    """芯片页主电气表里的 SNR/THD 是**原表内容**，不是跨容器逃逸。

    判据里「只扫板卡件主表」是刻意的：把芯片页的 AC 行也当逃逸，等于把真实
    规格判成脏数据。这条用例防的是「为了抓住 AFE7950 而把范围放大到全库」。
    """
    doc = {
        "basic_info": {"mpn": MPN, "identity": "device"},
        "specs": {"scope": "device", "electrical": [
            {"name": "SNR", "value": "73.9", "unit": "dB"}]},
    }
    out = _pkg_with_json(tmp_path, doc)
    assert S._container_state(out, MPN)["integrity"] == "pass"


def test_dirty_ac_cell_in_nested_container_is_fail(tmp_path):
    """AC 容器里 `MAX` 格写成单位（`dB`）—— 列角色错位，必须判 `fail`。"""
    doc = {
        "basic_info": {"mpn": MPN, "identity": "device"},
        "specs": {"scope": "device", "ac_performance": [
            {"symbol": "SNR", "min": "73", "typ": "73.9", "max": "dB"}]},
    }
    out = _pkg_with_json(tmp_path, doc)
    assert S._container_state(out, MPN)["integrity"] == "fail"


def test_isolation_bucket_sets_withheld(tmp_path):
    """隔离桶非空 → `withheld`；桶里的行不参与「正式容器是否干净」的扫描。"""
    doc = {
        "basic_info": {"mpn": MPN, "identity": "device"},
        "specs": {"scope": "device",
                  "unresolved_ac_rows": [{"symbol": "SNR", "max": "dB"}]},
    }
    out = _pkg_with_json(tmp_path, doc)
    got = S._container_state(out, MPN)
    assert got["state"] == "withheld"
    assert got["integrity"] == "pass"


def test_unsigned_package_may_say_not_requested(tmp_path):
    """**没有签核**的包写「未申请」是正确表述，不得判成过期口径。

    旧实现把这句写进 `NOTE_FORBIDDEN` 无条件禁用；batch100 的 91 件根本没有
    `signoff.json`，生成器按实况写、自检按词表禁，两边把对方判死。
    """
    out = build(tmp_path)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n" + S.STALE_SIGNOFF_CLAIM + "\n",
                 encoding="utf-8")
    bad = S._check_delivery_note(out, _man(out))
    assert not any("未申请" in x for x in bad), bad


def test_signed_package_saying_not_requested_is_caught(tmp_path):
    """**有签核**却还写「未申请」→ 说明比数据旧，必须红。"""
    out = build(tmp_path)
    man = _man(out)
    man["records"][0]["content_signoff"] = "APPROVED (with warnings)"
    _save_man(out, man)
    p = out / "交付说明.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n" + S.STALE_SIGNOFF_CLAIM + "\n",
                 encoding="utf-8")
    bad = S._check_delivery_note(out, man)
    assert any("未申请" in x for x in bad), bad
