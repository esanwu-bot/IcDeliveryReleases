"""qc/risk_guide.py 单测：分组归并、表格内容、冲突/未定位单列、只读性、CLI 退出码。"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import risk_guide as RG                       # noqa: E402


class RiskGuideTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="rg_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                             # noqa: E402
        self.db = db
        db.q1("SELECT 1")

    def tearDown(self):
        try:
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def _mk(self, mpn="DAC8555IPWG4"):
        """fields: (path, name, expected, unit, fe_status, page, quote)"""
        db = self.db
        ev = db.x("INSERT INTO source_evidence(mpn,manufacturer,target_fields_json,status,"
                  "identity_status,created_at,updated_at)"
                  " VALUES(?,'TI','[]','field_review','verified',?,?)",
                  (mpn, db.qc_now(), db.qc_now()))
        doc = db.x("INSERT INTO source_document(source_tier,source_type,source_url,is_official,"
                   "pdf_sha256,page_count,covered_mpn_json,identity_status,created_at,updated_at)"
                   " VALUES('P0','datasheet_pdf','https://www.ti.com/x.pdf',1,'aa',31,?,"
                   "'verified',?,?)", (json.dumps([mpn]), db.qc_now(), db.qc_now()))
        db.x("UPDATE source_evidence SET document_id=? WHERE id=?", (doc, ev))
        gid = db.x("INSERT INTO gold_set(version,mpn,manufacturer,pdf_sha256,status,"
                   "created_at,updated_at) VALUES('v1',?,'TI','aa','review',?,?)",
                   (mpn, db.qc_now(), db.qc_now()))
        for p, name, exp, unit, st, pg, q in [
            ("basic_info.mpn", "MPN", "DAC8555IPWG4", "", "ready", 18, "DAC8555IPWG4"),
            ("specs.package.type", "Package", "TSSOP", "", "ready", 18, "PW (TSSOP)"),
            ("pin[10].name", "Power pin", "IOVDD", "", "ready", 2, "IOVDD"),
            ("electrical[10].value", "IOIDD", "10", "µA", "ready", 6, "10 uA"),
            ("electrical[12].value", "Gain error", "0.3", "%", "ready", 7, "0.3"),
            ("features[0]", "便携", "portable", "", "ready", 1, "portable"),
            ("electrical[20].value", "VDD", "2.7", "V", "conflict_draft", 9, "4.5"),
            ("features[9]", "x", "y", "", "pending", 0, ""),
        ]:
            gfid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                        "cond,status) VALUES(?,?,?,?,?,'','pending')",
                        (gid, p, name, exp, unit))
            db.x("INSERT INTO source_field_evidence(evidence_id,document_id,gold_field_id,"
                 "field_path,page_number,evidence_quote,verification_status,created_at)"
                 " VALUES(?,?,?,?,?,?,?,?)",
                 (ev, doc, gfid, p, pg, q, st, db.qc_now()))
        return ev, gid

    def test_groups_by_field_type(self):
        ev, _ = self._mk()
        d = RG.build(self.db, ev_id=ev)
        self.assertEqual(d["mpn"], "DAC8555IPWG4")
        self.assertEqual(d["counts"].get("identity"), 1)
        self.assertEqual(d["counts"].get("package"), 1)
        self.assertEqual(d["counts"].get("power_pin"), 1)
        self.assertEqual(d["counts"].get("current_dim"), 1)     # µA 行
        self.assertEqual(d["counts"].get("key_electrical"), 1)  # gain error
        self.assertEqual(d["a_total"], 5)                       # features[0] 非高风险→B
        self.assertEqual(d["batch"], 1)
        self.assertEqual(len(d["conflicts"]), 1)
        self.assertEqual(len(d["unlocated"]), 1)

    def test_render_has_tables_and_guidance(self):
        ev, _ = self._mk()
        md = RG.render_md(RG.build(self.db, ev_id=ev))
        self.assertIn("# 高风险字段对照表 · DAC8555IPWG4", md)
        self.assertIn("Ordering Information", md)               # 身份该翻哪张表
        self.assertIn("Electrical Characteristics", md)         # 电流量纲
        self.assertIn("`pin[10].name`", md)
        self.assertIn("p6「10 uA」", md)
        self.assertIn("## 冲突待裁决（F 组）", md)
        self.assertIn("## 未定位（C 组", md)
        self.assertIn("绝不补 0", md)
        self.assertIn("物理页", md)

    def test_group_order_identity_first(self):
        ev, _ = self._mk()
        md = RG.render_md(RG.build(self.db, ev_id=ev))
        self.assertLess(md.index("## 身份（型号/厂商）"), md.index("## 电流量纲行"))

    def test_missing_card(self):
        self.assertIsNone(RG.build(self.db, mpn="NOPE"))
        self.assertEqual(RG.main(["--mpn", "NOPE"]), 3)

    def test_cli_out_dir(self):
        ev, _ = self._mk()
        out = self.tmp / "rg"
        rc = RG.main(["--evidence-id", str(ev), "--out", str(out)])
        self.assertEqual(rc, 0)
        f = out / "risk_guide_DAC8555IPWG4.md"
        self.assertTrue(f.exists())
        self.assertIn("高风险字段对照表", f.read_text(encoding="utf-8"))

    def test_readonly(self):
        ev, _ = self._mk()
        before = self.db.q1("SELECT count(*) n FROM source_field_evidence")["n"]
        RG.build(self.db, ev_id=ev)
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_field_evidence")["n"], before)
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_verification_log")["n"], 0)

    def test_import_pure(self):
        import contextlib
        import importlib
        import io
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            importlib.reload(RG)
        self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()