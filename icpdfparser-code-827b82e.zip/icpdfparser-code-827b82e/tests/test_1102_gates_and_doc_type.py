#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1102 新增口径的回归：文档类型 / TI 直链 / 句号 / 发布阶梯 / 身份硬门禁。

这些规则的共同点是「看起来只是措辞，实际会改变结论」：
`CLEAN` 被读成已签核、`user guide` 被写成 datasheet、`user guide..` 双句点 ——
1101 包被复审逐条点名的就是这一类。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as DB                                  # noqa: E402
import json_to_txt as J                                       # noqa: E402
from qc import source_url as SU                               # noqa: E402


# ---------------------------------------------------------------- 文档类型
def test_doc_type_from_url_path():
    assert SU.doc_type("https://www.ti.com/lit/ds/symlink/x.pdf") == "datasheet"
    assert SU.doc_type("https://www.ti.com/lit/ug/spruhh9/spruhh9.pdf") == "user_guide"
    assert SU.doc_type("https://www.ti.com/lit/an/sbaa123/sbaa123.pdf") == "application_note"


def test_doc_type_from_filename_when_url_is_mirror():
    # 第三方镜像没有 /lit/ 路径，退回文档号前缀
    assert SU.doc_type("https://source.z2data.com/x/ads1201.pdf", "ads1201.pdf") == ""
    assert SU.doc_type("https://x/sbas543c.pdf", "sbas543c.pdf") == "datasheet"


def test_doc_type_unknown_is_empty_not_guessed():
    # 判不出就返回空串，页面用中性词；不能硬说成 datasheet
    assert SU.doc_type("https://example.com/a.pdf", "a.pdf") == ""


def test_fill_doc_type_uses_device_url_for_board():
    doc = {"basic_info": {"device_datasheet_url":
                          "https://www.ti.com/lit/ug/slvu967a/slvu967a.pdf"}}
    assert SU.fill_doc_type(doc)["to"] == "user_guide"


# ---------------------------------------------------------------- TI 直链
def test_ti_rule_uses_filename_when_it_is_mpn_prefix():
    # 订货号带斜杠，直接拼会得到无效 URL
    doc = {"basic_info": {"mpn": "ADS1201U-1/1K"}}
    url = SU._ti_rule_url(doc, "ADS1201U-1_1K__ads1201.pdf")
    assert url == "https://www.ti.com/lit/ds/symlink/ads1201.pdf"


def test_ti_rule_ignores_unrelated_filename():
    # 文件名与型号无关时不能采信（抓取名可能是 whatever.pdf）
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE"}}
    assert SU._ti_rule_url(doc, "whatever.pdf") == \
        "https://www.ti.com/lit/ds/symlink/adc12dj5200se.pdf"


def test_override_only_for_non_ti_host():
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE", "manufacturer": "Texas Instruments",
                          "identity_state": "IDENTITY_SUPPORTED"}}
    text = "SLVSGH5C"
    assert SU._should_override(doc, "https://source.z2data.com/a.pdf", text, "a.pdf")
    # ti.com 自身的链接不动：板卡的 /lit/ug/ 是用户指南
    assert not SU._should_override(
        doc, "https://www.ti.com/lit/ug/spruhh9/spruhh9.pdf", text, "spruhh9.pdf")


def test_override_requires_approved_identity():
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE", "manufacturer": "Texas Instruments",
                          "identity_state": "IDENTITY_REVIEW"}}
    assert not SU._should_override(doc, "https://mirror/x.pdf", "SLVSGH5C", "x.pdf")


# ---------------------------------------------------------------- 句号
def test_sentence_does_not_double_period():
    assert J._sentence("ends with a dot.") == "ends with a dot."
    assert J._sentence("no dot") == "no dot."
    assert J._sentence("日本語です。") == "日本語です。"
    assert J._sentence("  padded  ") == "padded."


# ---------------------------------------------------------------- 发布阶梯
def _doc(**kw):
    d = {"basic_info": {"identity_state": "IDENTITY_SUPPORTED",
                        "datasheet_url": "https://www.ti.com/lit/ds/symlink/x.pdf"},
         # D4（2026-11-04）：装配产物必须带 `pin_validation`，缺失即
         # `pin_validation=missing` → BLOCKED。夹具模拟**真实产物**，不是
         # 模拟「闸门还没上线时的老产物」—— 后者正是 V3-CANDIDATE 的错误形态。
         "metadata": {"core_validation": "pass",
                      "pin_validation": {"status": "passed"}}}
    d["basic_info"].update(kw)
    return d


ALL_ART = ["json", "html", "symbol", "pdf"]

#: V7 起 `DATA_VALIDATED` 要求 `anchor_gate=pass`（精度闸：每条有数值的参数都达到
#: 自己载体要求的证据等级）。只给 `verdict=pass` 不再够 ——
#: 见 test_data_validated_needs_row_anchor。
ANCHORED = {"verdict": "pass", "anchor_gate": "pass"}


def test_release_state_requires_pdf_hash_match():
    d = _doc()
    assert DB._release_state(d, ALL_ART, True, ANCHORED) == "IDENTITY_APPROVED"
    # 哈希不一致连第一级都过不去
    assert DB._release_state(d, ALL_ART, False, ANCHORED) == "NOT_PACKAGED"


def test_release_state_needs_facts_for_data_validated():
    d = _doc()
    assert DB._release_state(d, ALL_ART, True, {"verdict": "partial"}) == "PACKAGING_PASSED"
    assert DB._release_state(d, ALL_ART, True, {}) == "PACKAGING_PASSED"


def test_data_validated_needs_row_anchor():
    """`verdict=pass` 不等于参数全对（V5 收紧，V7 换成精度闸）。

    `pass` 只表示「没有编造的数值」；同页命中（`value_on_label_page`）也算 pass，
    而 180 页手册里「同页」几乎是必然的。所以 `pass` + 闸门未过 → 停在打包级，
    缺口由 manifest 的 `row_anchor` / `paragraph_anchor` / `container_verified`
    三列如实展示。
    """
    d = _doc()
    assert DB._release_state(d, ALL_ART, True,
                             {"verdict": "pass", "anchor_gate": "blocked"}
                             ) == "PACKAGING_PASSED"
    assert DB._release_state(d, ALL_ART, True, {"verdict": "pass"}
                             ) == "PACKAGING_PASSED"
    assert DB._release_state(d, ALL_ART, True, ANCHORED) == "IDENTITY_APPROVED"


def test_anchor_columns_separate_container_from_coord():
    """V7 口径：容器级 `verified` 不进坐标列，只进自己那一列。"""
    facts = {"n_rows": 10, "counts": {"verified_row": 6, "verified_value": 1,
                                      "verified": 1, "value_on_label_page": 2}}
    cols = DB._anchor_columns(facts)
    assert cols["row_anchor"] == "6/10"
    assert cols["container_verified"] == "1/10"
    assert cols["coord_anchor"] == "7/10"      # 6 行级 + 1 有坐标无指纹
    # 缺 n_rows 就不写 —— 不猜分母
    assert DB._anchor_columns({"counts": {"verified_row": 3}})["row_anchor"] == ""


def test_release_state_never_self_approves_content():
    d = _doc()
    assert DB._release_state(d, ALL_ART, True, ANCHORED) == "IDENTITY_APPROVED"
    # 只有人工签核文件才能往上走
    assert DB._release_state(d, ALL_ART, True, ANCHORED,
                             {"content_approved": True}) == "CONTENT_APPROVED"


def test_release_state_stops_at_identity_review():
    d = _doc(identity_state="IDENTITY_REVIEW")
    assert DB._release_state(d, ALL_ART, True, ANCHORED) == "DATA_VALIDATED"


# ---------------------------------------------------------------- 身份硬门禁
def test_identity_review_is_not_clean():
    d = _doc(identity_state="IDENTITY_REVIEW")
    gate, why = DB._gate(d, True)
    assert gate == "UNRESOLVED"
    assert "IDENTITY_REVIEW" in why


def test_identity_approved_can_be_clean():
    d = _doc()
    gate, _ = DB._gate(d, True)
    assert gate == "CLEAN"


def test_pdf_hash_mismatch_blocks():
    d = _doc()
    gate, why = DB._gate(d, False)
    assert gate == "BLOCKED"
    assert "pdf_hash_mismatch" in why


# ---------------------------------------------------------------- 二进制哈希
def test_raw_hash_differs_from_normalized_on_crlf(tmp_path):
    p = tmp_path / "x.bin"
    p.write_bytes(b"a\r\nb")
    assert DB._sha256_raw(p) != DB._sha256(p)


def test_zip_sha256_recorded_as_raw_bytes(tmp_path):
    """`zip_sha256` 必须按原始字节算。

    1102 打包时这里漏改过：ZIP 走了文本的 CRLF→LF 归一，
    报告里的值在本地就与 `sha256sum` 对不上（实测
    `5f30439d…` vs 记录的 `ae9e953c…`）。复核方第一件事就是核这个哈希，
    对不上等于「无法独立重算」——正是复审点名的那一条。
    """
    import zipfile

    z = tmp_path / "p.zip"
    # 必须 ZIP_STORED：DEFLATED 会把 CRLF 压掉，夹具就造不出字节差异
    with zipfile.ZipFile(z, "x", zipfile.ZIP_STORED) as f:
        f.writestr("a.txt", "x\r\ny\r\n")
        f.writestr("b.txt", "p\r\nq\r\n")

    raw = DB._sha256_raw(z)
    assert raw != DB._sha256(z), "夹具里的 ZIP 没有 CRLF，用例失去意义"
    import hashlib
    assert raw == hashlib.sha256(z.read_bytes()).hexdigest()

    # 报告生成处必须用 raw 版本（这处曾误写成 _sha256，一个 token 的差别）。
    # 1102-V2 起取值收口到 `final_zip_metrics()`：报告不再直接调哈希函数，
    # 所以断言跟着搬到「取值函数内部 + 报告确实引用它」两处 ——
    # 保护的语义没变（ZIP 必须是原始字节哈希），只是换了实现位置。
    import inspect
    fn_src = inspect.getsource(DB.final_zip_metrics)
    assert "_sha256_raw(" in fn_src, "final_zip_metrics 必须按原始字节算哈希"
    assert "_sha256(" not in fn_src.replace("_sha256_raw(", ""), \
        "final_zip_metrics 里混进了文本归一哈希"
    src = (ROOT / "delivery_bundle.py").read_text(encoding="utf-8")
    assert "_zip_sha, _zip_size = final_zip_metrics(out, zip_path)" in src
    assert '"zip_sha256": _zip_sha' in src


def test_hash_rule_declares_binary_exception():
    """口径说明要区分文本与二进制，否则复核方仍会拿归一值去对原始字节。"""
    assert "原始字节" in DB.HASH_RULE
    assert "ZIP" in DB.HASH_RULE


def test_readme_promises_pdf_is_included():
    """README 必须有一句可以直接引用的承诺，而不是让复核方自己推断「有没有 PDF」。

    1101 被判「不能视为重新核验」时，包内确实没有原件；
    1102 有了，但如果只在物料表里列一行 `<型号>.pdf`，复审方仍可能读漏。

    注：分卷 README 的模板是 `bundle_acceptance()` 内的局部字符串（不是模块级
    `DB.README`），所以这里对模板源做断言 —— 断言的对象是「这句承诺有没有被删」，
    不是函数实现细节。
    """
    src = (ROOT / "delivery_bundle.py").read_text(encoding="utf-8")
    assert "本包已包含全部原厂 PDF 原件" in src


def test_readme_pdf_section_states_both_hashes():
    src = (ROOT / "delivery_bundle.py").read_text(encoding="utf-8")
    for key in ("pdf_sha256_recorded", "pdf_sha256_packaged", "pdf_hash_match"):
        assert key in src
