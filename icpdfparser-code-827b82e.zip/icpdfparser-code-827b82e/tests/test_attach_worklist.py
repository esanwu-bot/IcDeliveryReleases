"""补挂接 + 必须人工量清单 离线单测。

覆盖：attach_list（含 tpl/风险）、apply 幂等、target 并集不删现有、dry 零写入、
worklist 分组 A/B/C/D/F/E + clicks_est、只读性、import 零 stdout。
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import attach_missing as AM                    # noqa: E402
from qc import freeze_precheck as FP                   # noqa: E402
from qc import verify_worklist as VW                   # noqa: E402


class AttachWorklistTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="attach_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                              # noqa: E402
        self.db = db
        db.q1("SELECT 1")

    def tearDown(self):
        try:
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def _mk(self, fields, tf=None, covered=None, mpn="DAC8555IPWG4"):
        """fields: [(path, expected, unit, gold_status, fe_status, page, quote, reviewer)]"""
        db = self.db
        ev = db.x("INSERT INTO source_evidence(mpn,manufacturer,target_fields_json,status,"
                  "identity_status,verified_by,created_at,updated_at)"
                  " VALUES(?,'TI',?,'field_review','verified','esan',?,?)",
                  (mpn, json.dumps(tf or [], ensure_ascii=False), db.qc_now(), db.qc_now()))
        doc = db.x("INSERT INTO source_document(source_tier,source_type,source_url,is_official,"
                   "pdf_sha256,page_count,covered_mpn_json,identity_status,created_at,updated_at)"
                   " VALUES('P0','datasheet_pdf','https://www.ti.com/x.pdf',1,'aa',31,?,"
                   "'verified',?,?)",
                   (json.dumps(covered if covered is not None else [mpn]),
                    db.qc_now(), db.qc_now()))
        db.x("UPDATE source_evidence SET document_id=? WHERE id=?", (doc, ev))
        gid = db.x("INSERT INTO gold_set(version,mpn,manufacturer,pdf_sha256,status,"
                   "created_at,updated_at) VALUES('v1',?,'TI','aa','review',?,?)",
                   (mpn, db.qc_now(), db.qc_now()))
        for p, exp, unit, gst, fest, pg, quote, rev in fields:
            gfid = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                        "cond,status) VALUES(?,?,?,?,?,'',?)", (gid, p, p, exp, unit, gst))
            if fest is not None:
                db.x("INSERT INTO source_field_evidence(evidence_id,document_id,gold_field_id,"
                     "field_path,page_number,evidence_quote,verification_status,reviewer,"
                     "created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                     (ev, doc, gfid, p, pg, quote, fest, rev, db.qc_now()))
        return ev, gid

    # ---------------- 补挂接清单 ----------------
    def test_attach_list_has_locator_and_tpl(self):
        ev, _ = self._mk([
            ("basic_info.mpn", "DAC8555IPWG4", "", "verified", "verified", 18,
             "DAC8555IPWG4", "esan"),
            ("electrical[12].value", "2.5", "V", "verified", None, 0, "", ""),
            ("pin[9].name", "SYNC", "", "verified", None, 0, "", ""),
        ], tf=["basic_info.mpn"])
        r = FP.run(self.db, evidence_id=ev)
        rows = FP.attach_list(self.db, r)
        fe = [x for x in rows if x["gap"] == "field_evidence"]
        tf = [x for x in rows if x["gap"] == "target_fields"]
        self.assertEqual({x["field_path"] for x in fe}, {"electrical[12].value", "pin[9].name"})
        self.assertEqual({x["field_path"] for x in tf}, {"electrical[12].value", "pin[9].name"})
        for x in fe:
            self.assertTrue(x["tpl"], x)                       # 证据模板非空
            self.assertTrue(x["locator"], x)                   # 翻表定位非空
            self.assertIn(x["risk"], ("高·quote", "中", "低"))
        txt = FP.render_attach(rows)
        self.assertIn("缺字段证据 G5", txt)
        self.assertIn("缺 target_fields G9", txt)
        self.assertIn("electrical[12].value", txt)

    def test_attach_list_empty_when_green(self):
        ev, _ = self._mk([("features[0]", "p", "", "verified", "verified", 1, "p", "esan")],
                         tf=["features[0]"])
        r = FP.run(self.db, evidence_id=ev)
        self.assertEqual(FP.attach_list(self.db, r), [])
        self.assertIn("无缺失", FP.render_attach([]))

    def test_emit_attach_writes_jsonl(self):
        ev, _ = self._mk([("pin[9].name", "SYNC", "", "verified", None, 0, "", "")],
                         tf=[])
        out = self.tmp / "a.jsonl"
        rc = FP.main(["--evidence-id", str(ev), "--emit-attach", str(out), "--no-attach"])
        self.assertEqual(rc, 1)                                 # 仍有红项
        rows = [json.loads(x) for x in out.read_text(encoding="utf-8").splitlines() if x.strip()]
        self.assertEqual(len(rows), 2)                           # fe + tf
        self.assertEqual(rows[0]["field_path"], "pin[9].name")

    # ---------------- 执行器 ----------------
    def test_apply_creates_draft_and_target_union(self):
        ev, _ = self._mk([("electrical[12].value", "2.5", "V", "verified", None, 0, "", ""),
                          ("pin[9].name", "SYNC", "", "verified", None, 0, "", "")],
                         tf=["basic_info.mpn"])
        rows = [{"evidence_id": ev, "gap": "field_evidence", "field_path": "electrical[12].value"},
                {"evidence_id": ev, "gap": "field_evidence", "field_path": "pin[9].name"},
                {"evidence_id": ev, "gap": "target_fields", "field_path": "electrical[12].value"},
                {"evidence_id": ev, "gap": "target_fields", "field_path": "pin[9].name"}]
        out = AM.apply_rows(self.db, rows, dry=False)
        self.assertEqual(out["field_evidence"], 2)
        self.assertEqual(out["target_fields"], 2)
        n = self.db.q1("SELECT count(*) n FROM source_field_evidence WHERE evidence_id=?",
                       (ev,))["n"]
        self.assertEqual(n, 2)
        for r in self.db.q("SELECT * FROM source_field_evidence WHERE evidence_id=?", (ev,)):
            self.assertEqual(r["verification_status"], "pending")   # 只起草
            self.assertFalse((r["reviewer"] or "").strip())         # 机器不写核验人
            self.assertEqual(r["page_number"], 0)                   # page 待人工
        tf = json.loads(self.db.q1("SELECT target_fields_json t FROM source_evidence WHERE id=?",
                                   (ev,))["t"])
        self.assertIn("basic_info.mpn", tf)                     # 并集：不删现有
        self.assertEqual(sorted(tf), sorted(["basic_info.mpn", "electrical[12].value",
                                             "pin[9].name"]))
        acts = [x["action"] for x in self.db.q("SELECT action FROM source_verification_log")]
        self.assertIn("attach_draft", acts)
        self.assertIn("target_extend", acts)

    def test_apply_idempotent(self):
        ev, _ = self._mk([("pin[9].name", "SYNC", "", "verified", None, 0, "", "")], tf=[])
        rows = [{"evidence_id": ev, "gap": "field_evidence", "field_path": "pin[9].name"},
                {"evidence_id": ev, "gap": "target_fields", "field_path": "pin[9].name"}]
        first = AM.apply_rows(self.db, rows, dry=False)
        self.assertEqual((first["field_evidence"], first["target_fields"], first["skipped"]),
                         (1, 1, 0))
        second = AM.apply_rows(self.db, rows, dry=False)
        self.assertEqual((second["field_evidence"], second["target_fields"]), (0, 0))
        self.assertEqual(second["skipped"], 2)                   # 二次全跳过

    def test_dry_no_write(self):
        ev, _ = self._mk([("pin[9].name", "SYNC", "", "verified", None, 0, "", "")], tf=[])
        rows = [{"evidence_id": ev, "gap": "field_evidence", "field_path": "pin[9].name"},
                {"evidence_id": ev, "gap": "target_fields", "field_path": "pin[9].name"}]
        out = AM.apply_rows(self.db, rows, dry=True)
        self.assertEqual((out["field_evidence"], out["target_fields"]), (1, 1))
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_field_evidence "
                                    "WHERE evidence_id=?", (ev,))["n"], 0)
        self.assertEqual(json.loads(self.db.q1(
            "SELECT target_fields_json t FROM source_evidence WHERE id=?", (ev,))["t"]), [])
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_verification_log")["n"], 0)

    def test_apply_skips_bad_rows(self):
        ev, _ = self._mk([("pin[9].name", "SYNC", "", "verified", None, 0, "", "")], tf=[])
        out = AM.apply_rows(self.db, [
            {"evidence_id": 0, "gap": "field_evidence", "field_path": "x"},
            {"evidence_id": 999999, "gap": "field_evidence", "field_path": "y"},
            {"evidence_id": ev, "gap": "field_evidence", "field_path": ""},
        ], dry=False)
        self.assertEqual(out["field_evidence"], 0)
        self.assertEqual(out["skipped"], 3)

    # ---------------- 挂接后 G5/G9 转绿、G6/G7 仍红 ----------------
    def test_attach_turns_g5_g9_green_but_g6_g7_still_red(self):
        ev, _ = self._mk([("electrical[12].value", "2.5", "V", "verified", None, 0, "", ""),
                          ("pin[9].name", "SYNC", "", "verified", None, 0, "", "")], tf=[])
        AM.apply_rows(self.db, [                                   # 挂接（草稿）
            {"evidence_id": ev, "gap": "field_evidence", "field_path": "electrical[12].value"},
            {"evidence_id": ev, "gap": "field_evidence", "field_path": "pin[9].name"},
            {"evidence_id": ev, "gap": "target_fields", "field_path": "electrical[12].value"},
            {"evidence_id": ev, "gap": "target_fields", "field_path": "pin[9].name"},
        ], dry=False)
        by = {c["no"]: c for c in FP.run(self.db, evidence_id=ev)["checks"]}
        self.assertTrue(by[9]["ok"], by[9])          # G9 target 粒度转绿
        self.assertFalse(by[5]["ok"])                # G5 仍红：草稿未核验（设计如此）
        self.assertIn("未核验=2", by[5]["detail"])
        # G6/G7 对"未 verified 行"不适用（红在 G5），此即"草稿 ≠ 核验"

    # ---------------- 必须人工量清单 ----------------
    def test_worklist_groups_and_clicks(self):
        ev, _ = self._mk([
            ("basic_info.mpn", "DAC8555IPWG4", "", "verified", "verified", 18, "x", "esan"),
            ("electrical[10].value", "10", "µA", "verified", "ready", 6, "10 uA", ""),
            ("features[1]", "便携", "", "verified", "ready", 2, "portable", ""),
            ("features[2]", "低功耗", "", "verified", "pending", 0, "", ""),
            ("features[3]", "x", "", "verified", "ambiguous", 3, "q", ""),
            ("features[4]", "y", "", "verified", "conflict_draft", 3, "q", ""),
            ("features[5]", "z", "", "verified", "ocr_pending", 0, "", ""),
        ], tf=[])
        r = VW.build(self.db, ev_id=ev)
        self.assertEqual(r["total"], 7)
        self.assertEqual(r["verified"], 1)
        c = r["counts"]
        self.assertEqual(c["A"], 1)                 # µA 电流行 → 高风险逐条
        self.assertEqual(c["B"], 1)                 # features[1] 非高风险且有 page+quote
        self.assertEqual(c["C"], 1)                 # features[2] 无 page/quote → 待判定
        self.assertEqual(c["D"], 1)
        self.assertEqual(c["F"], 1)
        self.assertEqual(c["E"], 1)
        self.assertEqual(r["clicks_est"], 1 + 1 + 1 + 1 + 1)      # A + B(1) + C + D + F
        self.assertEqual(len(r["batch_ids"]), 1)
        txt = VW.render(r)
        self.assertIn("必须人工量清单", txt)
        self.assertIn("预计点击", txt)
        self.assertIn("1/7", txt)

    def test_worklist_all_closed_clicks_zero(self):
        ev, _ = self._mk([("features[0]", "p", "", "verified", "verified", 1, "p", "esan")],
                         tf=[])
        r = VW.build(self.db, ev_id=ev)
        self.assertEqual(r["clicks_est"], 0)
        self.assertEqual(r["progress"], 1.0)

    def test_worklist_readonly(self):
        ev, _ = self._mk([("features[1]", "p", "", "verified", "ready", 2, "q", "")], tf=[])
        before = self.db.q1("SELECT count(*) n FROM source_field_evidence")["n"]
        VW.build(self.db, ev_id=ev)
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_field_evidence")["n"], before)
        self.assertEqual(self.db.q1("SELECT count(*) n FROM source_verification_log")["n"], 0)

    def test_worklist_missing_card(self):
        self.assertIsNone(VW.build(self.db, mpn="NOPE"))
        self.assertEqual(VW.main(["--mpn", "NOPE"]), 3)

    def test_import_pure(self):
        import contextlib
        import importlib
        import io
        for mod in (AM, VW):
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                importlib.reload(mod)
            self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()