#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`locate_row/unique-v2` 并列裁决（condition / value）的回归测试。

v1 的做法：总分并列就 `row_ambiguous_unresolved`，一条都不写。
实测 13 件 / 355 条上有 68 条恰并列，其中相当一部分**其实有证据可分**：

  `Logic Input High Voltage` 值 `VCC - 1.0` 只出现在 VIH 行；同名的 TM1/TM2
  续行是 `VCC - 0.3`，IIH 行是 `-70`。三行总分相同（都是「Logic input high」
  前 12 位命中 + 3 个共同词），但值一票定了归属。

v2 的裁决顺序：先按 condition 词命中，仍并列再比 value 落不落在该行数值格。
**只做并列裁决，不进总分** —— value 直接进总分（尤其 `0` 这种高频值）会把
原本 unmatched 的条目变成大面积 ambiguous，实测变负优化。

实测（11 件回归基线 + 74LVC1G132 + BQ2003，355 条）：
    v1         matched 278 / 恰并列 68 / value 命中本行 142
    v2         matched 307 / 恰并列 39 / value 命中本行 156
"""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TA = pytest.importorskip("qc.table_audit")

HDR7 = ["Symbol", "Parameter", "Condition", "Min", "Typ", "Max", "Unit"]


def tbl(rows, header=None):
    return {"page": 1, "ti": 0, "header": header or HDR7, "rows": rows}


def entry(name, value, unit="V", **kw):
    e = {"name": name, "value": value, "unit": unit}
    e.update(kw)
    return e


def kinds(finds):
    return [f["kind"] for f in finds]


# 两行文字相同、总分必然并列，只有 Condition 与 Typical 不同
def tie_rows():
    return [
        ["BW", "Bandwidth -3dB", "Low quiescent current mode", "", "30", "", "MHz"],
        ["BW", "Bandwidth -3dB", "Wide bandwidth mode", "", "180", "", "MHz"],
    ]


class TestBackwardCompat:

    def test_without_cond_and_val_still_reports_both(self):
        """不传 cond/val 的调用方（locate_row / audit_missing_rows）行为不变。"""
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB")
        assert ties == [0, 1]

    def test_locate_row_still_returns_first(self):
        ri, _ = TA.locate_row(tbl(tie_rows()), "", "Bandwidth -3dB")
        assert ri == 0


class TestValueBreaksTie:

    def test_value_picks_the_matching_row(self):
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB",
                                       "", "180")
        assert ties == [1], "180 只落在第二行的 Typical 列"

    def test_value_numeric_equivalence_not_substring_only(self):
        # 30.0 与单元格 '30' 数值相等
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB", "", "30.0")
        assert ties == [0]

    def test_value_matching_neither_row_leaves_tie(self):
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB", "", "120")
        assert ties == [0, 1], "无证据时必须保持并列，不许猜"

    def test_value_matching_both_rows_leaves_tie(self):
        rows = [
            ["BW", "Bandwidth -3dB", "mode A", "", "180", "", "MHz"],
            ["BW", "Bandwidth -3dB", "mode B", "", "180", "", "MHz"],
        ]
        ties, _ = TA.locate_candidates(tbl(rows), "", "Bandwidth -3dB", "", "180")
        assert ties == [0, 1], "两行都解释得通 → 仍然无法判定"


class TestConditionBreaksTie:

    def test_condition_words_pick_the_row(self):
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB",
                                       "wide bandwidth at 5V", "")
        assert ties == [1], "condition 里的 wide/bandwidth 只命中第二行"

    def test_condition_wins_before_value(self):
        """condition 唯一命中时不再看 value —— 顺序是 condition → value。"""
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB",
                                       "wide bandwidth", "30")
        assert ties == [1]

    def test_condition_hitting_both_falls_through_to_value(self):
        ties, _ = TA.locate_candidates(tbl(tie_rows()), "", "Bandwidth -3dB",
                                       "bandwidth", "180")
        assert ties == [1], "condition 平手 → 交给 value"


class TestAuditIntegration:

    def test_resolved_tie_sets_source_row(self):
        """真实形态：VIH 行只有 Min 一列有值，靠 value 拿到唯一归属。"""
        rows = [["VIH", "Logic input high", "", "VCC - 1.0", "-", "-", "V"],
                ["", "Logic input high", "", "VCC - 0.3", "-", "-", "V"]]
        e = entry("Logic Input High Voltage", "VCC - 1.0",
                  condition="TA = TOPR; VCC ±10%")
        finds = TA.audit_electrical([e], [tbl(rows)], "specs.electrical")

        assert "row_ambiguous_unresolved" not in kinds(finds), kinds(finds)
        assert e.get("source", {}).get("row") == 0, "靠 value 落到第一行"
        # 只有一列有数值时 cvals 长度不足 2，按设计不走 patch_cols（不是缺陷）

    def test_resolved_tie_allows_column_patch(self):
        """裁决成功 + 该行有两列数值 → 后续 D1b 能正常回填 columns。"""
        rows = [["GBW", "Gain bandwidth", "mode A", "10", "-", "20", "MHz"],
                ["GBW", "Gain bandwidth", "mode B", "30", "-", "40", "MHz"]]
        e = entry("Gain bandwidth", "30", unit="MHz")
        finds = TA.audit_electrical([e], [tbl(rows)], "specs.electrical")

        assert "row_ambiguous_unresolved" not in kinds(finds), kinds(finds)
        assert e.get("source", {}).get("row") == 1
        assert e.get("columns") == {"MIN": 30.0, "MAX": 40.0}, e.get("columns")

    def test_unresolvable_tie_still_writes_nothing(self):
        e = entry("Bandwidth -3dB", "120", unit="MHz")
        finds = TA.audit_electrical([e], [tbl(tie_rows())], "specs.electrical")

        assert kinds(finds) == ["row_ambiguous_unresolved"], kinds(finds)
        assert finds[0]["match_rule"] == TA.MATCH_RULE
        for k in ("value_raw_original", "columns", "columns_raw", "source"):
            assert k not in e, f"ambiguous 时不允许写 {k}"

    def test_two_entries_claiming_same_row_is_still_collision(self):
        """裁决把两条都指到同一行 → 仍按 ambiguous_collision 处理，不是静默覆盖。"""
        e1 = entry("Bandwidth -3dB", "180", unit="MHz", condition="wide bandwidth")
        e2 = entry("Bandwidth -3dB", "180", unit="MHz", condition="wide bandwidth")
        finds = TA.audit_electrical([e1, e2], [tbl(tie_rows())], "specs.electrical")

        assert kinds(finds) == ["row_ambiguous_unresolved"] * 2, kinds(finds)
        assert finds[0]["ambiguous_reason"] == "ambiguous_collision"
        assert finds[0]["candidate_count"] == 1
