# -*- coding: utf-8 -*-
"""JEV 语义裁判客户端：**不可用 / 抖动 / 幻觉 时必须 abstain**（ADAPT JEV-BAILIAN）。

这个客户端的唯一职责是「不确定就闭嘴」。它一旦在异常路径上返回值，
调用方会把它当成有效裁决去选行 —— 那是把数据质量押在一次 HTTP 请求上。
"""
import io
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import jev_client as J  # noqa: E402


class _Resp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False


def _patch_urlopen(monkeypatch, payload=None, exc=None, calls=None):
    def fake(req, timeout=None):
        if calls is not None:
            calls.append(req)
        if exc is not None:
            raise exc
        return _Resp(json.dumps(payload).encode("utf-8"))
    monkeypatch.setattr(J.urllib.request, "urlopen", fake)


@pytest.fixture
def env(monkeypatch):
    monkeypatch.setenv("ICPDF_BAILIAN_WORKSPACE", "ws-test")
    monkeypatch.setenv("DASHSCOPE_API_KEY", "sk-test")
    monkeypatch.setenv("ICPDF_JEV_TIMEOUT", "5")
    return monkeypatch


CRIT = {"row_0": "Row 0: Param Name=ICC", "row_1": "Row 1: Param Name=IDD"}


class TestAbstain:
    def test_no_workspace(self, monkeypatch):
        monkeypatch.delenv("ICPDF_BAILIAN_WORKSPACE", raising=False)
        monkeypatch.setenv("DASHSCOPE_API_KEY", "sk-test")
        assert J.available() is False
        assert J.decide_choice("s", "i", CRIT) is None

    def test_no_key(self, monkeypatch):
        monkeypatch.setenv("ICPDF_BAILIAN_WORKSPACE", "ws-test")
        monkeypatch.delenv("DASHSCOPE_API_KEY", raising=False)
        assert J.available() is False
        assert J.decide_choice("s", "i", CRIT) is None

    def test_network_error(self, env):
        _patch_urlopen(env, exc=OSError("boom"))
        assert J.decide_choice("s", "i", CRIT) is None

    def test_unknown_choice_is_rejected(self, env):
        _patch_urlopen(env, payload={"answers": {"choice": {"choice": "row_99",
                                                            "confidence": 0.99}}})
        assert J.decide_choice("s", "i", CRIT) is None, "选了不在选项里的 id 必须拒"

    def test_missing_field(self, env):
        _patch_urlopen(env, payload={"answers": {}})
        assert J.decide_choice("s", "i", CRIT) is None

    def test_low_confidence_is_rejected(self, env):
        _patch_urlopen(env, payload={"answers": {"choice": {"choice": "row_0",
                                                            "confidence": 0.4}}})
        assert J.decide_choice("s", "i", CRIT) is None, "置信度不足应当 abstain 而不是赌"


class TestAccept:
    def test_returns_choice_and_conf(self, env):
        _patch_urlopen(env, payload={"answers": {"choice": {"choice": "row_1",
                                                            "confidence": 0.93}}})
        assert J.decide_choice("s", "i", CRIT) == ("row_1", 0.93)

    def test_payload_shape(self, env):
        calls = []
        _patch_urlopen(env, payload={"answers": {"choice": {"choice": "row_0",
                                                            "confidence": 0.9}}}, calls=calls)
        J.decide_choice("state-x", "instr-y", CRIT)
        body = json.loads(calls[0].data.decode("utf-8"))
        assert body["model"] == J.MODEL
        assert body["state"] == "state-x"
        assert body["questions"]["choice"]["type"] == "choice"
        assert body["questions"]["choice"]["criteria"] == CRIT
        assert calls[0].headers.get("Authorization") == "Bearer sk-test"


class TestRetry:
    def test_429_then_ok(self, env, monkeypatch):
        import urllib.error
        seq = [urllib.error.HTTPError("u", 429, "too many", {}, None),
               _Resp(json.dumps({"answers": {"choice": {"choice": "row_0",
                                                        "confidence": 0.9}}}).encode())]

        def fake(req, timeout=None):
            item = seq.pop(0)
            if isinstance(item, Exception):
                raise item
            return item
        monkeypatch.setattr(J.urllib.request, "urlopen", fake)
        monkeypatch.setattr(J.time, "sleep", lambda s: None)      # 不真等
        assert J.decide_choice("s", "i", CRIT) == ("row_0", 0.9)

    def test_non_retryable_4xx_stops_immediately(self, env, monkeypatch):
        import urllib.error
        n = {"c": 0}

        def fake(req, timeout=None):
            n["c"] += 1
            raise urllib.error.HTTPError("u", 400, "bad", {}, None)
        monkeypatch.setattr(J.urllib.request, "urlopen", fake)
        assert J.decide_choice("s", "i", CRIT) is None
        assert n["c"] == 1, "400 重试没有意义，应当立刻放弃"
