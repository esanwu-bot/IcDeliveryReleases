"""只读盘点工具：默认不写批次文件，--apply 只写 sidecar，audit 永不被覆盖。"""
import csv
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import backfill_delivery_status as BF      # noqa: E402


def review(verdict, rule=(), llm=()):
    return {"mpn": "X", "verdict": verdict, "rule_findings": list(rule),
            "llm_findings": list(llm), "rule_version": "rv-1"}


def f(sev, advisory=False):
    return {"kind": "k", "severity": sev, "advisory": advisory,
            "evidence": {"quote": "q"}}


def make_batch(base: Path, bid="rf-20261028-001", quarantined=()) -> Path:
    d = base / bid
    (d / "review").mkdir(parents=True)
    audit = {"audit_version": 2, "delivery_kind": "review_fix",
             "status_code": "REVIEWED_PARTIAL",
             "status_label": "已 review（部分未收敛，待人工）",
             "generated_at": "2026-10-28T12:00:00+08:00"}
    if quarantined:
        audit["quarantined"] = {"count": len(quarantined),
                                "mpns": list(quarantined), "reason": {}}
    (d / "rf_quality_audit.json").write_text(json.dumps(audit, ensure_ascii=False),
                                            encoding="utf-8")
    rows = [("MPN-A", "REVIEWED_FIXED", review("FAIL", [f("P0"), f("P1")])),
            ("MPN-B", "REVIEWED_FIXED", review("WARN", [f("P1")])),
            ("MPN-C", "REVIEWED_FIXED", None)]          # 缺报告
    lines = ["mpn,status_code,status_label"]
    for mpn, code, rv in rows:
        lines.append("%s,%s,旧标签" % (mpn, code))
        if rv is not None:
            (d / "review" / ("%s.review.json" % mpn)).write_text(
                json.dumps(rv, ensure_ascii=False), encoding="utf-8")
    (d / "manifest.csv").write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    return d


class BackfillTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.d = make_batch(self.base, quarantined=["MPN-B"])

    def tearDown(self):
        self.tmp.cleanup()

    def test_dry_run_writes_report_but_not_batches(self):
        audit_before = (self.d / "rf_quality_audit.json").read_bytes()
        out = self.base / "diff.csv"
        self.assertEqual(0, BF.main(["--base", str(self.base),
                                     "--out", str(out)]))
        rows = {r["mpn"]: r for r in csv.DictReader(
            out.open(encoding="utf-8-sig"))}
        self.assertEqual("REVIEWED_BLOCKED", rows["MPN-A"]["new_status"])
        self.assertEqual("REVIEWED_STILL_WARN", rows["MPN-B"]["new_status"])
        self.assertEqual("INCOMPLETE", rows["MPN-C"]["new_status"])
        self.assertEqual("1", rows["MPN-A"]["p0"])
        self.assertEqual("1", rows["MPN-C"]["incomplete_checks"])
        sha = hashlib.sha256((self.d / "review" / "MPN-A.review.json")
                             .read_bytes()).hexdigest()
        self.assertEqual(sha, rows["MPN-A"]["review_sha256"])
        self.assertEqual("rv-1", rows["MPN-A"]["rule_version"])
        self.assertFalse((self.d / "rf_status_derived.json").exists())
        self.assertEqual(audit_before,
                         (self.d / "rf_quality_audit.json").read_bytes())

    def test_quarantine_conflict_is_flagged_not_forced_to_blocked(self):
        out = self.base / "diff.csv"
        BF.main(["--base", str(self.base), "--out", str(out)])
        rows = {r["mpn"]: r for r in csv.DictReader(
            out.open(encoding="utf-8-sig"))}
        # 隔离是人工结论：review 里没有 P0 就不能替它判阻断，只标冲突
        self.assertEqual("True", rows["MPN-B"]["quarantine_conflict"])
        self.assertEqual("REVIEWED_STILL_WARN", rows["MPN-B"]["new_status"])

    def test_batch_rollup_and_summary(self):
        out = self.base / "diff.csv"
        BF.main(["--base", str(self.base), "--out", str(out)])
        summ = json.loads(out.with_suffix(".json").read_text(encoding="utf-8"))
        b = summ["batches"][0]
        self.assertEqual("REVIEWED_PARTIAL", b["old_status"])
        self.assertEqual("REVIEWED_BLOCKED", b["new_status"])
        self.assertEqual(1, b["p0_total"])
        self.assertEqual(["MPN-B"], b["quarantine_conflicts"])
        self.assertEqual(3, summ["totals"]["changed_rows"])
        self.assertEqual(1, summ["totals"]["blocked"])
        self.assertEqual(1, summ["totals"]["incomplete"])

    def test_apply_writes_sidecar_only(self):
        audit_before = (self.d / "rf_quality_audit.json").read_bytes()
        BF.main(["--base", str(self.base), "--apply",
                 "--out", str(self.base / "diff.csv")])
        side = json.loads((self.d / "rf_status_derived.json")
                          .read_text(encoding="utf-8"))
        self.assertEqual("REVIEWED_BLOCKED", side["status_code"])
        self.assertEqual(3, side["status_counts"]["REVIEWED_BLOCKED"]
                         + side["status_counts"]["REVIEWED_STILL_WARN"]
                         + side["status_counts"]["INCOMPLETE"])
        self.assertEqual(audit_before,
                         (self.d / "rf_quality_audit.json").read_bytes())


if __name__ == "__main__":
    unittest.main()
