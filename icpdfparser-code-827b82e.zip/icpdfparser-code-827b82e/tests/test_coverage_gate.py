# -*- coding: utf-8 -*-
"""源文档覆盖率闸门：源里有表、JSON 里空 → 报警；源里没有 → 不许报警。

**这个盲区是真实的**：`audit_column_collapse` 要容器里先有条目才能逐行比对，
整表一行没抽出来时它连比对对象都没有，直接放行 —— 「源有表、页面空」这种
最严重的情况反而是唯一不被拦的。

两个真实样本必须一直是回归的一部分：
- `CDC6CE025000ADLYR`：有热阻表，JSON 空 → **必须报警**
- `ADS1675REF`：40 页全文没有 thermal / θ / junction-to，JSON 空 → **不许报警**

第二条不是凑数的：为了追求「非空」而制造数据，比缺数据更糟。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import coverage_gate as CG      # noqa: E402

CDC_PDF = ROOT / "data" / "pdfs" / "CDC6CE025000ADLYR__cdc6c.pdf"
ADS_PDF = ROOT / "data" / "pdfs" / "ADS1675REF__ads1675.pdf"


# ─────────────────────────────────────────────────────────────────────
# 1. 纯函数：三态表逐格验证
# ─────────────────────────────────────────────────────────────────────

def _state(s):
    return {s: {"state": s, "pages": [1], "why": "测试"}} if s else {}


@pytest.mark.parametrize("state,rows,expect", [
    ("present", [{"name": "RθJA"}], []),                      # 有表 + 有数据 → 通过
    ("present", [], ["source_container_not_extracted"]),      # 有表 + 空 → 报警
    ("absent", [], []),                                       # 没表 + 空 → 通过
    ("unknown", [], ["source_container_state_unknown"]),      # 判不出 + 空 → review
    ("absent", [{"name": "RθJA"}], []),                       # 没表却有数据 → 不在本闸范围
])
def test_the_three_state_table(state, rows, expect):
    findings = CG.check({"specs": {"thermal": rows}}, {"thermal": _state(state)["thermal"]})
    assert [f["code"] for f in findings] == expect


def test_absent_and_unknown_are_not_the_same_thing():
    """把 False 和 Unknown 混为一谈，就会在「读不到字」的件上放行。

    `absent` 是「我确认源文档没有」；`unknown` 是「我判断不了」。
    前者通过，后者必须留痕给人工 —— 这是本次实现的核心要求。
    """
    absent = CG.check({"specs": {"thermal": []}}, {"thermal": _state("absent")["thermal"]})
    unknown = CG.check({"specs": {"thermal": []}}, {"thermal": _state("unknown")["thermal"]})

    assert absent == []
    assert len(unknown) == 1
    assert unknown[0]["severity"] == "review", "判不出来不许报 high，会制造噪音"


def test_the_missing_code_carries_severity_and_field():
    f = CG.check({"specs": {"thermal": []}}, {"thermal": _state("present")["thermal"]})[0]

    assert f["code"] == "source_container_not_extracted"
    assert f["severity"] == "high"
    assert f["field"] == "thermal"
    assert "抽取遗漏" in f["detail"]


def test_code_is_not_named_thermal_missing():
    """`thermal_missing` 无法区分「源文档没有」与「有表没抽到」，名字必须说清楚。"""
    assert CG.CODE_MISSING == "source_container_not_extracted"
    assert "missing" not in CG.CODE_MISSING


# ─────────────────────────────────────────────────────────────────────
# 2. 真实 PDF：两个必须长期存在的样本
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not ADS_PDF.exists(), reason="缺少 ADS1675REF 原件")
def test_ads1675ref_without_a_thermal_table_is_not_flagged():
    """40 页全文没有 thermal / θ / junction-to → absent，0 行是正确结果。"""
    with __import__("pymupdf").open(str(ADS_PDF)) as doc:
        st = CG.source_container_state(doc, "thermal")

    assert st["state"] == CG.ABSENT, f"应判「确认没有」，实际 {st}"
    assert CG.run(ADS_PDF, {"specs": {"thermal": []}}) == []


@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_cdc6c_with_empty_thermal_is_flagged():
    """有真实热阻表、JSON 却一行没有 → 必须 high。"""
    with __import__("pymupdf").open(str(CDC_PDF)) as doc:
        st = CG.source_container_state(doc, "thermal")

    assert st["state"] == CG.PRESENT, f"应判「有表」，实际 {st}"
    findings = CG.run(CDC_PDF, {"specs": {"thermal": []}})
    codes = [f["code"] for f in findings if f["field"] == "thermal"]
    assert codes == ["source_container_not_extracted"]


@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_cdc6c_with_twenty_rows_passes():
    """同一份 PDF，JSON 里有 20 行 → 不许报警（闸门不是「必须永远有事发生」）。"""
    rows = [{"name": "RθJA", "value": "151.8", "condition": "DLE 4 PINS"}] * 20
    findings = CG.run(CDC_PDF, {"specs": {"thermal": rows}})
    assert [f for f in findings if f["field"] == "thermal"] == []


# ─────────────────────────────────────────────────────────────────────
# 3. 不许把「正文提到 thermal」当成「有参数表」
# ─────────────────────────────────────────────────────────────────────

def _pdf_with_text(tmp_path, text: str, name="sut.pdf"):
    import pymupdf
    p = tmp_path / name
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), text, fontsize=9)
    doc.save(str(p))
    doc.close()
    return p


def test_prose_mentioning_thermal_is_unknown_not_present(tmp_path):
    """应用说明里写「热阻取决于布板」很常见 —— 那不是参数表。

    判成 present 会在每一份「正文提过热」的手册上误报 high，闸门立刻失去可信度；
    判成 absent 又会把这个件永久放行。所以只标 review。
    """
    p = _pdf_with_text(
        tmp_path,
        "The thermal resistance of the package depends heavily on the PCB layout "
        "and the copper area connected to the exposed pad. See the application "
        "note for details about junction-to-ambient measurements. " * 3)
    with __import__("pymupdf").open(str(p)) as doc:
        st = CG.source_container_state(doc, "thermal")

    assert st["state"] == CG.UNKNOWN, f"正文提及不该判成有表：{st}"
    findings = CG.run(p, {"specs": {"thermal": []}})
    assert [f["code"] for f in findings] == ["source_container_state_unknown"]
    assert findings[0]["severity"] == "review"


def test_an_unreadable_pdf_is_unknown(tmp_path):
    """扫描件读不到字 → 不是「源文档没有」，是「我们看不见」。"""
    import pymupdf
    p = tmp_path / "empty.pdf"
    doc = pymupdf.open()
    doc.new_page()
    doc.save(str(p))
    doc.close()

    with pymupdf.open(str(p)) as d:
        st = CG.source_container_state(d, "thermal")
    assert st["state"] == CG.UNKNOWN
    assert "扫描件" in st["why"] or "文本层" in st["why"]


def test_a_text_layer_table_is_still_present(tmp_path):
    """纯文本排版的表 find_tables 会漏，靠「标题 + 参数名成行」兜住。"""
    body = "\n".join([
        "6.5 Thermal Information",
        "THERMAL METRIC(1)",
        "RθJA", "Junction-to-ambient thermal resistance", "66.8", "23.5",
        "RθJB", "Junction-to-board thermal resistance", "16.9", "7.9",
    ])
    p = _pdf_with_text(tmp_path, body + "\n" + "filler " * 40)
    with __import__("pymupdf").open(str(p)) as doc:
        st = CG.source_container_state(doc, "thermal")

    assert st["state"] == CG.PRESENT, f"标题 + 两条参数名应判有表：{st}"


# ─────────────────────────────────────────────────────────────────────
# 4. 别的容器不受影响
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_containers_are_checked_independently():
    """CDC6C 有热阻表也有 ESD 表。thermal 有 20 行、esd 空 →
    只允许报 esd，thermal 一条都不许有。"""
    rows = [{"name": "RθJA", "value": "151.8"}] * 20
    findings = CG.run(CDC_PDF, {"specs": {"thermal": rows, "esd": []}})

    fields = [f["field"] for f in findings]
    assert "thermal" not in fields, "thermal 有数据，不许被 esd 的状态带累"
    assert fields == ["esd"]


@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_unknown_container_name_does_not_crash():
    with __import__("pymupdf").open(str(CDC_PDF)) as doc:
        st = CG.source_container_state(doc, "pins")
    assert st["state"] == CG.UNKNOWN


# ─────────────────────────────────────────────────────────────────────
# 5. CLI
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_cli_exits_nonzero_on_a_high_finding(tmp_path, capsys):
    p = tmp_path / "CDC.json"
    p.write_text(json.dumps({"specs": {"thermal": [], "esd": []}}), encoding="utf-8")

    rc = CG.main(["--json", str(p), "--pdf", str(CDC_PDF), "--container", "thermal"])
    out = json.loads(capsys.readouterr().out)

    assert rc == 1, "有 high 必须非零退出，否则流水线当没事"
    assert out["count"] == 1


@pytest.mark.skipif(not ADS_PDF.exists(), reason="缺少 ADS1675REF 原件")
def test_cli_exits_zero_when_the_source_has_nothing(tmp_path, capsys):
    p = tmp_path / "ADS.json"
    p.write_text(json.dumps({"specs": {"thermal": [], "esd": []}}), encoding="utf-8")

    rc = CG.main(["--json", str(p), "--pdf", str(ADS_PDF), "--container", "thermal"])
    out = json.loads(capsys.readouterr().out)

    assert rc == 0
    assert out["count"] == 0
