# -*- coding: utf-8 -*-
"""merge_patch（旧电气 + 新 thermal/esd）与自适应选页预算的回归测试。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from qc import merge_patch as M  # noqa: E402
from qc import reparse_guard as G  # noqa: E402

PD = pytest.importorskip("parse_datasheets")


def _doc(elec, thermal=0, esd=0):
    return {
        "basic_info": {"mpn": "BQ79614PAPRQ1"},
        "specs": {
            "electrical": [{"name": f"e{i}"} for i in range(elec)],
            "thermal": [{"name": f"t{i}"} for i in range(thermal)],
            "esd": [{"name": f"d{i}"} for i in range(esd)],
        },
        "metadata": {},
    }


def test_merge_keeps_old_electrical_and_adds_new_containers():
    """BQ79614 实测形态：旧 57 行电气 + 新 6 热阻 / 2 ESD。"""
    old, new = _doc(57), _doc(22, thermal=6, esd=2)
    merged, rep = M.merge_docs(old, new)
    sp = merged["specs"]
    assert len(sp["electrical"]) == 57, "旧电气被覆盖了"
    assert len(sp["thermal"]) == 6
    assert len(sp["esd"]) == 2
    assert rep["taken_new"]["thermal"] == 6
    assert merged["metadata"]["merge_patch"]["rule"].startswith("keep_old_electrical")


def test_merge_is_guard_safe():
    """合并结果必须能过防呆守卫（否则灰度批处理会被自己拦掉）。"""
    old, new = _doc(57), _doc(22, thermal=6, esd=2)
    merged, _ = M.merge_docs(old, new)
    assert G.guard(old, merged)["accept"] is True


def test_merge_does_not_overwrite_existing_thermal():
    old, new = _doc(57, thermal=4, esd=1), _doc(22, thermal=6, esd=2)
    merged, _ = M.merge_docs(old, new)
    assert len(merged["specs"]["thermal"]) == 4, "已有热阻被新数据覆盖了"


def test_adaptive_budget_default_is_flat():
    """1102-V3.3 回退：**默认不放大**。

    历史：V3.2 对 >100 页放宽到 32 页 / 100k（BQ79614 222 页丢 56 行的对策），
    但 100 件灰度证明 flash 在 32 页上下文里注意力涣散、`empty_electrical` 激增。
    这条用例把"默认退回 16/50k"这个**决定**钉住 —— 别再把环境变量当默认值。
    """
    assert PD.adaptive_budget(222) == (PD.MAX_PAGES, PD.MAX_CHARS)
    assert PD.adaptive_budget(13) == (PD.MAX_PAGES, PD.MAX_CHARS)


def test_adaptive_budget_widens_only_when_opted_in(monkeypatch):
    """需要复现 V3.2 行为时必须显式置 `ICPDF_ADAPTIVE_BUDGET=1`（A/B 臂）。"""
    monkeypatch.setenv("ICPDF_ADAPTIVE_BUDGET", "1")
    assert PD.adaptive_budget(222) == (32, 100_000)
    assert PD.adaptive_budget(13) == (PD.MAX_PAGES, PD.MAX_CHARS)
