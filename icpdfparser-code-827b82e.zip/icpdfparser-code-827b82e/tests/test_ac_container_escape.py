# -*- coding: utf-8 -*-
"""1102V2 P0：AC 参数跨容器逃逸（Bypass）的拦截与机器可读状态。

背景（Reviewer 复审原话）
--------------------------
V11 把 `ADS8568EVM-PDK` 的 6 条 `max="dB"` 脏行从 `specs.ac_performance`
搬进了 `specs.unresolved_ac_rows`，页面上的 AC 表于是变成空表 + 一句
「数据已扣押」。但同一份 JSON 的 `specs.onboard_device_specs.electrical`
里仍留着 4 条 SNR/SFDR/THD/隔离度数据 —— 它们是合同层把整张电气表搬进
板载器件桶时**顺带复制**过去的，没有自己独立的 `bbox` / `row_sha256`。
结果：AC 表说「扣押」，电气表照常把同一个数印给客户。同一件事两种状态。

修法
----
`qc/ac_quarantine.py` 的扫描不能只认 `specs.ac_performance`：

1. 全局扫描板卡件的正式电气容器（主表 + `onboard_device_specs` /
   `unresolved_specs`，含 `devices.<MPN>` 次级器件桶）；
2. 命中 AC 类参数、且没有独立 `bbox` + `row_sha256`（无法证明与原数据独立）
   的行，一并搬进 `specs.unresolved_ac_rows`，保留原字段与来源路径；
3. `metadata` 落两个机器可读状态：`formal_container_integrity`
   （"pass" 只代表没有脏行）与 `ac_data_state`（"withheld" = 主动扣押）；
4. 渲染层兜底：旧 JSON 没跑隔离时也不许把逃逸行印出来。

**芯片页主电气表不在扫描范围**：芯片手册的 `electrical` 里 SNR/THD/ENOB
本来就是原表内容（生产库里有数千行 dB 量纲参数），不是「从 AC 容器逃逸」。
把它也扣押会把芯片页的真实规格删掉 —— 那是数据丢失，不是治理。

用例全部手写假 JSON，形态与 V11 生产 JSON 对齐（板卡身份 + 板载器件桶 +
隔离桶），不依赖任何真实交付文件。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import json_to_txt as J                                    # noqa: E402
from qc import ac_quarantine as AQ                         # noqa: E402
from qc import fact_acceptance as FA                       # noqa: E402
from qc import fact_status_sync as FSS                     # noqa: E402
from qc import normalize_doc as ND                         # noqa: E402


#: 与 V11 生产 JSON 逐字段对齐的 4 条逃逸行：`value`/`unit`/`condition`
#: 是电气表形态，`unit="dB"` 是 AC（频域）量纲。它们都没有 bbox / row_sha256。
ESCAPED = [
    {"name": "Signal-to-Noise Ratio (SNR)", "value": "91.5", "unit": "dB",
     "condition": "At fIN = 10 kHz"},
    {"name": "Total Harmonic Distortion (THD)", "value": "-94", "unit": "dB",
     "condition": "At fIN = 10 kHz"},
    {"name": "Spurious-Free Dynamic Range (SFDR)", "value": "92", "unit": "dB",
     "condition": "At fIN = 10 kHz"},
    {"name": "Channel-to-Channel Isolation", "value": "120", "unit": "dB",
     "condition": "At fIN = 10 kHz"},
]

CLEAN_ELEC = [
    {"name": "Resolution", "value": "16", "unit": "Bits", "condition": ""},
    {"name": "Analog Supply Voltage (AVDD)", "value": "4.5 to 5.5",
     "unit": "V", "condition": ""},
    {"name": "Power Dissipation", "value": "259.7 to 389.4", "unit": "mW",
     "condition": "fDATA = maximum"},
    {"name": "Conversion Time", "value": "1.7", "unit": "μs",
     "condition": "CLKSEL = 0"},
]

#: V11 已扣押的 6 行（AC 表形态）；用来验证新搬走的行是追加、不是覆盖。
EXISTING_ISOLATED = [
    {"symbol": "SNR", "parameter": "SNR Signal-to-noise ratio",
     "conditions": f"At fIN = 10 kHz; {70 + i}", "min": f"{70 + i}.5",
     "typ": "", "max": "dB", "unit": "", "row_sha256": f"iso-{i}",
     "quarantined_from": "ac_performance",
     "quarantine_reason": "MAX 格不是数值（'dB'）"}
    for i in range(6)
]


def _board_doc(rows=None, isolated=None, electrical=None) -> dict:
    """生产形态的板卡 JSON：主表空，板载器件行在桶里，AC 隔离区有历史行。"""
    return {
        "basic_info": {"mpn": "ADS8568EVM-PDK", "identity": "evaluation_board",
                       "manufacturer": "Texas Instruments",
                       "device_mpn": "ADS8568"},
        "specs": {
            "scope": "onboard_device",
            "package": {"onboard_device": "ADS8568"},
            "electrical": electrical or [],
            "absolute_max": [],
            "ac_performance": [],
            "onboard_device_specs": {
                "device_mpn": "ADS8568",
                "scope": "onboard_device",
                "source": "onboard_device_datasheet",
                "electrical": [dict(r) for r in (rows if rows is not None
                                                 else ESCAPED + CLEAN_ELEC)],
            },
            "unresolved_ac_rows": [dict(r) for r in
                                   (isolated if isolated is not None
                                    else EXISTING_ISOLATED)],
        },
    }


# ─────────────────────────────────────────────────────────────────────
# 一、跨容器拦截：逃逸行必须离开正式容器
# ─────────────────────────────────────────────────────────────────────

def test_escaped_ac_rows_leave_onboard_electrical():
    doc = _board_doc()
    rep = AQ.quarantine(doc)

    assert rep["n_quarantined"] == 4, rep
    names = [r["name"] for r in doc["specs"]["onboard_device_specs"]["electrical"]]
    assert names == [r["name"] for r in CLEAN_ELEC], names

    isolated = doc["specs"]["unresolved_ac_rows"]
    assert len(isolated) == len(EXISTING_ISOLATED) + 4
    moved = isolated[len(EXISTING_ISOLATED):]
    assert [r["name"] for r in moved] == [r["name"] for r in ESCAPED]
    for row in moved:
        assert row["quarantined_from"] == "onboard_device_specs.electrical"
        assert "bbox" in row["quarantine_reason"]
        assert "row_sha256" in row["quarantine_reason"]
        # 原字段原样保留：隔离是为了人工复核，不是把证据洗掉。
        assert row["value"] == next(r["value"] for r in ESCAPED
                                    if r["name"] == row["name"])
        assert row["unit"] == "dB"


def test_quarantine_reports_source_path():
    doc = _board_doc()
    rep = AQ.quarantine(doc)
    moved = [q for q in rep["quarantined"]
             if q["from"] == "onboard_device_specs.electrical"]
    assert {q["name"] for q in moved} == {r["name"] for r in ESCAPED}


def test_quarantine_is_idempotent_on_bucket_rows():
    doc = _board_doc()
    first = AQ.quarantine(doc)
    second = AQ.quarantine(doc)
    assert first["n_quarantined"] == 4
    assert second["n_quarantined"] == 0
    assert len(doc["specs"]["unresolved_ac_rows"]) == 10


def test_nested_device_bucket_is_scanned():
    """`onboard_device_specs.devices.<MPN>.electrical` 也是正式容器。"""
    doc = _board_doc(rows=[dict(CLEAN_ELEC[0])])
    doc["specs"]["onboard_device_specs"]["devices"] = {
        "CSD88537ND": {"electrical": [
            {"name": "Crosstalk", "value": "80", "unit": "dB",
             "condition": "f = 1 MHz"},
            {"name": "Drain-to-Source Voltage", "value": "30", "unit": "V",
             "condition": ""},
        ]}}
    rep = AQ.quarantine(doc)
    assert rep["n_quarantined"] == 1
    dev = doc["specs"]["onboard_device_specs"]["devices"]["CSD88537ND"]
    assert [r["name"] for r in dev["electrical"]] == ["Drain-to-Source Voltage"]
    moved = doc["specs"]["unresolved_ac_rows"][-1]
    assert moved["name"] == "Crosstalk"
    assert moved["quarantined_from"] == \
        "onboard_device_specs.devices.CSD88537ND.electrical"


def test_board_main_electrical_is_scanned_before_contract_move():
    """合同层会把主表整锅搬进桶：搬之前就要扣下 AC 行，否则换个容器继续逃。"""
    doc = _board_doc()
    doc["specs"]["electrical"] = [dict(r) for r in ESCAPED + CLEAN_ELEC]
    doc["specs"]["onboard_device_specs"]["electrical"] = []
    rep = AQ.quarantine(doc)
    assert rep["n_quarantined"] == 4
    assert [r["name"] for r in doc["specs"]["electrical"]] == \
        [r["name"] for r in CLEAN_ELEC]
    assert doc["specs"]["unresolved_ac_rows"][-1]["quarantined_from"] == "electrical"


def test_anchored_ac_row_with_independent_provenance_stays():
    """有独立 bbox + row_sha256 = 能证明不是原数据的无证据复制，不扣。"""
    anchored = {"name": "Total Harmonic Distortion (THD)", "value": "-94",
                "unit": "dB", "condition": "At fIN = 10 kHz",
                "bbox": [54.1, 342.6, 557.8, 354.9],
                "row_sha256": "a" * 64}
    doc = _board_doc(rows=[dict(anchored)] + [dict(r) for r in CLEAN_ELEC])
    rep = AQ.quarantine(doc)
    assert rep["n_quarantined"] == 0
    assert doc["specs"]["onboard_device_specs"]["electrical"][0]["row_sha256"] == \
        "a" * 64


def test_chip_main_electrical_is_not_swallowed():
    """芯片页主电气表里的 SNR/THD 是原表内容，不是跨容器逃逸 —— 不得误伤。"""
    doc = {
        "basic_info": {"mpn": "ADC12DJ5200SE", "identity": "chip"},
        "specs": {"scope": "device",
                  "electrical": [dict(r) for r in ESCAPED],
                  "ac_performance": []},
    }
    rep = AQ.quarantine(doc)
    assert rep["n_quarantined"] == 0
    assert len(doc["specs"]["electrical"]) == 4
    assert not doc["specs"].get("unresolved_ac_rows")


# ─────────────────────────────────────────────────────────────────────
# 二、机器可读状态：metadata 两个字段
# ─────────────────────────────────────────────────────────────────────

def test_metadata_marks_formal_container_clean_and_ac_withheld():
    doc = _board_doc()
    rep = AQ.quarantine(doc)
    meta = doc["metadata"]
    assert meta["formal_container_integrity"] == "pass"
    assert meta["ac_data_state"] == "withheld"
    assert rep["formal_container_integrity"] == "pass"
    assert rep["ac_data_state"] == "withheld"


def test_metadata_without_ac_data_is_not_withheld():
    doc = _board_doc(rows=[dict(r) for r in CLEAN_ELEC], isolated=[])
    AQ.quarantine(doc)
    meta = doc["metadata"]
    assert meta["formal_container_integrity"] == "pass"
    assert meta["ac_data_state"] == "not_withheld"


def test_integrity_fails_only_when_dirty_ac_row_remains():
    """`pass` 只代表「没脏行」：拿一份不跑隔离的脏 JSON 直接算，必须是 fail。"""
    doc = _board_doc(rows=[dict(r) for r in ESCAPED] + [dict(r) for r in CLEAN_ELEC],
                     isolated=[])
    assert AQ.formal_container_integrity(doc) == "fail"
    AQ.quarantine(doc)
    assert AQ.formal_container_integrity(doc) == "pass"


# ─────────────────────────────────────────────────────────────────────
# 三、渲染层兜底：旧 JSON 没跑隔离也不许印
# ─────────────────────────────────────────────────────────────────────

def test_renderer_hides_escaped_rows_after_quarantine():
    doc = _board_doc()
    AQ.quarantine(doc)
    html = J.render(doc, "en")
    assert "Signal-to-Noise Ratio (SNR)" not in html
    assert "91.5" not in html
    assert "Channel-to-Channel Isolation" not in html
    assert "Analog Supply Voltage (AVDD)" in html
    assert "withheld from this page" in html


def test_renderer_filters_escaped_rows_before_json_is_rewritten():
    """老 JSON 只被渲染、没被隔离时，页面同样不许出现逃逸行。"""
    html = J.render(_board_doc(), "en")
    assert "Signal-to-Noise Ratio (SNR)" not in html
    assert "91.5" not in html
    assert "withheld from this page" in html
    # 干净行不受影响
    assert "Analog Supply Voltage (AVDD)" in html


def test_renderer_discloses_escaped_rows_without_isolation_bucket():
    """隔离桶为空时，渲染兜底扣下的行也必须披露 —— 否则就是无声丢数据。

    上一条用例的夹具本来就带 `unresolved_ac_rows`，那句 "withheld from this
    page" 由 AC 段触发，证明不了电气兜底自己会披露：老 JSON 只被渲染、没跑过
    `qc/ac_quarantine.py` 时，隔离桶是空的，`specs_ac_withheld` 的 n 是 0、
    整句不出现，4 条 AC 行就这么从页面上消失了（G0 无静默）。这条用例把隔离桶
    清空，单独验电气兜底这条路径。
    """
    doc = _board_doc(isolated=[])
    html = J.render(doc, "en")
    assert "Signal-to-Noise Ratio (SNR)" not in html
    assert "91.5" not in html
    assert "Analog Supply Voltage (AVDD)" in html
    assert "4 AC rows in the on-board device electrical table were withheld" in html


# ─────────────────────────────────────────────────────────────────────
# 四、管线入口：normalize / 状态同步 / 事实表都吃同一套判据
# ─────────────────────────────────────────────────────────────────────

def test_normalize_pipeline_quarantines_bucket_rows():
    doc = _board_doc()
    acts = ND.normalize(doc, None)
    assert acts["ac_quarantine"]["n_quarantined"] == 4
    assert len(doc["specs"]["unresolved_ac_rows"]) == 10
    assert doc["metadata"]["ac_data_state"] == "withheld"


def test_status_sync_quarantines_bucket_rows():
    doc = _board_doc()
    res = FSS.sync_doc(doc, {})
    assert res["ac_quarantined"] == 4
    assert len(doc["specs"]["unresolved_ac_rows"]) == 10


def test_fact_acceptance_audits_escaped_rows_before_quarantine():
    """事实表在隔离前必须看到逃逸行：靠删行让分母缩水 = 反向假绿。

    页面/正式容器要干净，但 `facts_audit` / `risk_queue` 仍应点名这些行，
    供人工复核；隔离是"搬到可见的隔离区"，不是"从账本上抹掉"。
    """
    res = FA.audit_one("ADS8568EVM-PDK", _board_doc(), None)
    labels = {r["label"] for r in res["rows"]}
    assert "Signal-to-Noise Ratio (SNR)" in labels
    assert "Analog Supply Voltage (AVDD)" in labels


# ─────────────────────────────────────────────────────────────────────
# 五、CLI：原子写 + 行来源可见
# ─────────────────────────────────────────────────────────────────────

def test_cli_writes_bucket_quarantine_atomically(tmp_path):
    p = tmp_path / "ADS8568EVM-PDK.json"
    p.write_text(json.dumps(_board_doc(), ensure_ascii=False), encoding="utf-8")
    assert AQ.main([str(p)]) == 0
    got = json.loads(p.read_text(encoding="utf-8"))
    assert len(got["specs"]["onboard_device_specs"]["electrical"]) == \
        len(CLEAN_ELEC)
    assert len(got["specs"]["unresolved_ac_rows"]) == 10
    assert got["metadata"]["ac_data_state"] == "withheld"
    assert got["metadata"]["formal_container_integrity"] == "pass"
    assert not list(tmp_path.glob("*.tmp")), "原子写留下了临时文件"
