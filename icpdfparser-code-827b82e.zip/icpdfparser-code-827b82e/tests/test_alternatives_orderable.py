#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""替代料「可订购号精确匹配」门禁的用例（Reviewer B1）。

**取证**：`ADC12DJ5200SE.alts.json` 里三条候选全部 `internal=false /
verified=false / match=miss`，却照样写进了交付包：

| 候选 | 主张 | 实际 |
|---|---|---|
| `ADC12DJ5200RF` | pin-to-pin 兼容 | RF 版 A5 = `INA−`，SE 版 A5 = `AGND`（两份原厂 PDF 自证） |
| `AD9680-1000` | 12-bit / LFBGA-144 | ADI 原文：**14-bit**、**64-lead LFCSP (CP-64-15)**；可订购号是 `AD9680BCPZ-1000` |
| `ADS8V11` | TI 12-bit / 1.2GSPS | TI 三种标准 URL 全 404 → 该产品不存在 |

共同错法：**把「系列名 / 速度档」当成可订购号**。而站内目录里
`AD9680BCPZ-1000`、`ADC12DJ5200RFAAVT` 本来就有 —— 不是缺料，是命名不规范。
所以门禁必须落在「字符串能否在目录里精确命中」这一步。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import alternatives as A                                        # noqa: E402


class StubIndex:
    """只实现 match()：exact / family / miss 三态。"""

    def __init__(self, hits: dict[str, tuple[str, str]]):
        self.hits = hits

    def match(self, mpn: str):
        rec = self.hits.get(A.norm(mpn))
        if not rec:
            return None, "miss"
        catalog_mpn, url = rec
        return {"mpn": catalog_mpn, "url": url}, "exact"


def _rows(*mpns):
    return [{"mpn": m, "manufacturer": "TI", "similarity": 0.9, "basis": "pin-compatible"}
            for m in mpns]


def test_hallucinated_candidates_are_dropped():
    idx = StubIndex({"AD9680BCPZ1000": ("AD9680BCPZ-1000", "/p/1")})
    kept, rejected = A.enforce_orderable(
        _rows("AD9680-1000", "ADC12DJ5200RF", "ADS8V11", "AD9680BCPZ-1000"), idx)

    assert [r["mpn"] for r in kept] == ["AD9680BCPZ-1000"]
    assert {r["mpn"] for r in rejected} == {"AD9680-1000", "ADC12DJ5200RF", "ADS8V11"}
    assert all(r["reject_reason"] == "not_in_catalog_exact" for r in rejected)


def test_kept_row_carries_catalog_link():
    idx = StubIndex({"AD9680BCPZ1000": ("AD9680BCPZ-1000", "/p/1")})
    kept, _ = A.enforce_orderable(_rows("AD9680BCPZ-1000"), idx)
    assert kept[0]["internal"] is True and kept[0]["verified"] is True
    assert kept[0]["url"] == "/p/1"


def test_family_only_match_is_rejected():
    """目录只有同族变体（无精确码）→ 也不能当可订购号发布。"""
    class FamilyIdx(StubIndex):
        def match(self, mpn):
            return {"mpn": "AD9680BCPZ-1250", "url": "/p/2"}, "family"

    kept, rejected = A.enforce_orderable(_rows("AD9680-1000"), FamilyIdx({}))
    assert not kept
    assert rejected[0]["reject_reason"] == "family_only"


def test_prompt_demands_full_orderable_number():
    assert "可订购" in A.SYS
    assert "后缀" in A.SYS
    assert "禁止输出基础系列名" in A.SYS


def test_prompt_requires_explicit_na_instead_of_silent_drop():
    """认不准时必须写 `N/A`，不许悄悄丢行。

    悄悄丢行 = 静默失效：模型认不准的次数不可观测，运营侧也就拿不到
    「该补哪些料号」的工单。这是 2026-10-31 定下的口径。
    """
    assert "`N/A`" in A.SYS
    assert "不要省略该行" in A.SYS


def test_undetermined_is_reported_not_blacklisted():
    """`N/A` 走 mpn_undetermined，不和幻觉混为一类。"""
    idx = StubIndex({"AD9680BCPZ1000": ("AD9680BCPZ-1000", "/p/1")})
    kept, rejected = A.enforce_orderable(
        _rows("N/A", "AD9680-1000", "AD9680BCPZ-1000"), idx)

    assert [r["mpn"] for r in kept] == ["AD9680BCPZ-1000"]
    reasons = {r["mpn"]: r["reject_reason"] for r in rejected}
    assert reasons == {"N/A": "mpn_undetermined",
                       "AD9680-1000": "not_in_catalog_exact"}


def test_undetermined_never_touches_index():
    """`N/A` 不应触发目录查询（否则 'NA' 可能撞上真实料号）。"""
    class Boom(StubIndex):
        def match(self, mpn):
            raise AssertionError("N/A 不该进目录查询")

    kept, rejected = A.enforce_orderable(_rows("N/A"), Boom({}))
    assert kept == [] and rejected[0]["reject_reason"] == "mpn_undetermined"


def test_empty_rows_safe():
    kept, rejected = A.enforce_orderable([], StubIndex({}))
    assert kept == [] and rejected == []
