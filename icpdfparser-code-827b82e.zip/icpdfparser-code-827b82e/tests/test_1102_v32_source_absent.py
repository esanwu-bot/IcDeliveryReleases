# -*- coding: utf-8 -*-
"""1102-V3.2：源文档无 thermal/ESD 表 → not_applicable，不判 UNRESOLVED。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import deterministic_extract as DE  # noqa: E402


def _doc():
    return {
        "basic_info": {"datasheet_url": "https://www.ti.com/x.pdf"},
        "specs": {"electrical": [{"name": "Supply voltage", "value": "5"}],
                  "thermal": [], "esd": []},
        "pin_configuration": [{"pin": "A1", "name": "VDD"}],
    }


def test_without_source_evidence_still_reports():
    """没有文本层证据时保持严格口径（老行为不许被这次改动放松）。"""
    errs = DE.check_core(_doc(), None)
    assert any("specs.thermal 为空" in e for e in errs), errs
    assert any("specs.esd 为空" in e for e in errs), errs


def test_source_absent_is_not_applicable():
    """ADS1286U / BQ48SH 实测形态：源 PDF 文本层没有这两张表。"""
    errs = DE.check_core(_doc(), None, frozenset({"thermal", "esd"}))
    assert not any("specs.thermal" in e or "specs.esd" in e for e in errs), errs


def test_source_absent_does_not_excuse_electrical():
    """豁免只针对 thermal/esd；电气为空永远是错。"""
    doc = _doc()
    doc["specs"]["electrical"] = []
    errs = DE.check_core(doc, None, frozenset({"thermal", "esd"}))
    assert any("specs.electrical 为空" in e for e in errs), errs
