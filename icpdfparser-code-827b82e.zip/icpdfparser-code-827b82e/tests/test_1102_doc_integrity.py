#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1102-V2：文档层两处失误的回归用例（ZIP 字节数 / 隔离脚注）。

这两条都不是数据错，是**文档与机器值脱钩**：

1. V11 的发布仓库根 README 把 ZIP 写成 `12,123,616 B`，包内
   `包校验报告.json` 是 `12,124,048` —— 差 432 字节。前者是 `.part`
   阶段的中间值，后者才是最终落盘值。复核方一算就对不上。
2. ADS8568EVM-PDK 的 6 条 AC 脏行被物理隔离后，交付说明的实测表少了几行，
   却没有任何一句话解释差额 —— 复核方会把它读成「漏审计」。

两条都按「先证明闸门能红，再证明干净包不红」写：
每个用例都先造出缺陷，断言它被抓到；再修好，断言告警消失。
只测「通过」的用例是没有价值的 —— 它连闸门有没有接上都证明不了。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as B                                     # noqa: E402
from qc import bundle_selfcheck as S                            # noqa: E402
from test_bundle_selfcheck import MPN, build                    # noqa: E402

NOTE = "交付说明.md"


# ── 夹具工具 ─────────────────────────────────────────────────────
def _add_json(out: Path, *, quarantined: int) -> None:
    """往包内塞一份带隔离行的型号 JSON（自检要从**包内 JSON**数隔离行）。"""
    base = out / "part-0001-of-0001" / MPN
    specs: dict = {"electrical": [{"name": "AVDD", "value": "5"}]}
    if quarantined:
        specs["ac_performance"] = []
        specs["unresolved_ac_rows"] = [
            {"symbol": "SNR", "parameter": "SNR", "max": "dB", "page": 13}
            for _ in range(quarantined)
        ]
    (base / f"{MPN}.json").write_text(
        json.dumps({"basic_info": {"mpn": MPN}, "specs": specs},
                   ensure_ascii=False), encoding="utf-8")


def _note_text(out: Path) -> str:
    return (out / NOTE).read_text(encoding="utf-8")


def _append_note(out: Path, text: str) -> None:
    p = out / NOTE
    p.write_text(p.read_text(encoding="utf-8") + text, encoding="utf-8")


def _note_bad(out: Path) -> list[str]:
    return S._check_delivery_note(out, json.loads(
        (out / "manifest.json").read_text(encoding="utf-8")))


def _pad_zip(out: Path, n: int = 2000) -> int:
    """把 ZIP 撑到四位数以上，返回真实字节数。

    夹具里的 ZIP 只有几百字节，而「文档里的字节数」这条规则只认带千分位的写法
    （不带千分位的裸数字在正文里到处都是，抓它必然误报）。撑大之后
    `f"{n:,}"` 才会真的出现逗号，用例才验得到东西。
    """
    zp = out / "part-0001-of-0001.zip"
    with zp.open("ab") as fh:
        fh.write(b"\0" * n)
    return zp.stat().st_size


# ── 一、隔离行计数 ───────────────────────────────────────────────
def test_isolation_rows_reads_unresolved_containers():
    doc = {"specs": {"electrical": [{"name": "AVDD"}],
                     "unresolved_ac_rows": [{}, {}, {}],
                     "unresolved_specs": [{}]}}
    assert B.isolation_rows(doc) == [("unresolved_ac_rows", 3),
                                     ("unresolved_specs", 1)]


def test_isolation_rows_ignores_empty_and_normal_containers():
    doc = {"specs": {"electrical": [{"name": "AVDD"}],
                     "unresolved_ac_rows": []}}
    assert B.isolation_rows(doc) == []


def test_isolation_note_carries_mpn_container_and_count():
    txt = B.isolation_note("ADS8568EVM-PDK", [("unresolved_ac_rows", 6)])
    assert "ADS8568EVM-PDK" in txt
    assert "6 行" in txt
    assert "specs.unresolved_ac_rows" in txt
    assert txt.startswith("注：")


# ── 二、交付说明必须自动生成脚注 ─────────────────────────────────
def test_render_note_adds_footnote_when_quarantined():
    rows = [{"mpn": MPN, "n_rows": 43, "row": 22, "para": 1, "weak": 20,
             "gate": "blocked", "verdict": "partial_pass",
             "state": "PACKAGING_PASSED",
             "isolated": [("unresolved_ac_rows", 6)]}]
    text = B.render_delivery_note("delivery-demo", rows, {})
    assert "注：" in text
    assert "6 行 AC 数据" in text
    # 脚注必须在表**下方**：读者是先看到「43 行」再问「为什么少了 6 行」。
    assert text.index("注：") > text.index("| `" + MPN + "`")


def _note_row(mpn: str, gate: str) -> dict:
    return {"mpn": mpn, "n_rows": 1, "row": 0, "para": 0, "weak": 0,
            "gate": gate, "verdict": "pass", "state": "PACKAGING_PASSED",
            "isolated": [], "approved_dims": [], "excluded_dims": [],
            "signoff": "", "i18n": "", "cov": ""}


def test_render_note_anchor_counts_follow_manifest_rows():
    """2026-11-05 DSH：`5/5 件` 是硬编码遗留；必须按本包行数现算。

    真实 batch100 是 79 blocked / 12 pass（91 件）。说明文档一旦写死旧数字，
    复核方会把 91 件读成 5 件。
    """
    rows = ([_note_row(f"B{i:02d}", "blocked") for i in range(79)]
            + [_note_row(f"P{i:02d}", "pass") for i in range(12)])
    text = B.render_delivery_note("delivery-demo", rows, {})
    assert "5/5" not in text
    assert "79 blocked / 12 pass，共 91 件" in text
    assert "anchor_gate=blocked（79" not in text


def test_render_note_anchor_counts_when_all_pass():
    rows = [_note_row(f"P{i:02d}", "pass") for i in range(6)]
    text = B.render_delivery_note("delivery-demo", rows, {})
    assert "`anchor_gate=pass`（6 pass / 6 件）" in text
    assert "blocked" not in text.split("## 受限数据发布")[0]


def test_render_note_omits_footnote_when_clean():
    rows = [{"mpn": MPN, "n_rows": 3, "row": 1, "para": 1, "weak": 0,
             "gate": "pass", "verdict": "pass",
             "state": "IDENTITY_APPROVED", "isolated": []}]
    assert "注：" not in B.render_delivery_note("delivery-demo", rows, {})


def test_selfcheck_flags_missing_isolation_footnote(tmp_path):
    out = build(tmp_path)
    _add_json(out, quarantined=6)
    bad = _note_bad(out)
    assert any("缺隔离脚注" in x and MPN in x for x in bad), bad


def test_selfcheck_accepts_isolation_footnote(tmp_path):
    out = build(tmp_path)
    _add_json(out, quarantined=6)
    _append_note(out, "\n" + B.isolation_note(MPN, [("unresolved_ac_rows", 6)]) + "\n")
    assert not [x for x in _note_bad(out) if "隔离脚注" in x]


def test_selfcheck_flags_wrong_isolation_count(tmp_path):
    """脚注写了、但条数是旧的（改了隔离数没改文档）—— 这条最容易漏。"""
    out = build(tmp_path)
    _add_json(out, quarantined=6)
    _append_note(out, "\n" + B.isolation_note(MPN, [("unresolved_ac_rows", 4)]) + "\n")
    bad = _note_bad(out)
    assert any("条数与 JSON 不符" in x for x in bad), bad


# ── 三、文档里的 ZIP 字节数 ──────────────────────────────────────
def test_zip_size_claim_mismatch_is_caught(tmp_path):
    """V11 的 432 字节差：文档写中间值，报告写终值。"""
    out = build(tmp_path)
    real = _pad_zip(out)
    wrong = f"{real - 432:,}"
    _append_note(out, f"\n| 分卷 ZIP | `part-0001-of-0001.zip`，{wrong} B |\n")
    bad = S._check_doc_byte_claims(out)
    assert any(wrong in x for x in bad), bad


def test_zip_size_claim_correct_passes(tmp_path):
    out = build(tmp_path)
    real = _pad_zip(out)
    _append_note(out, f"\n| 分卷 ZIP | `part-0001-of-0001.zip`，{real:,} B |\n")
    assert S._check_doc_byte_claims(out) == []


def test_zip_size_claim_ignored_when_line_is_not_about_zip(tmp_path):
    """PDF 大小也是带千分位的字节数 —— 不在 ZIP 那行就不该被抓。"""
    out = build(tmp_path)
    real = _pad_zip(out)
    _append_note(out, f"\n| 原厂 PDF | `{MPN}.pdf`，{real - 432:,} B |\n")
    assert S._check_doc_byte_claims(out) == []


def test_report_zip_size_mismatch_is_caught(tmp_path):
    """报告里的 `zip_size` 也必须等于磁盘上那个 ZIP。"""
    out = build(tmp_path)
    rep_p = out / "包校验报告.json"
    rep = json.loads(rep_p.read_text(encoding="utf-8"))
    rep["zip_size"] = (out / "part-0001-of-0001.zip").stat().st_size - 432
    rep_p.write_text(json.dumps(rep, ensure_ascii=False), encoding="utf-8")
    assert any("zip_size" in x for x in S.check(out))


# ── 四、打包器只认最终落盘的 ZIP ─────────────────────────────────
def test_final_zip_metrics_returns_on_disk_values(tmp_path):
    out = tmp_path / "pkg"
    out.mkdir()
    zp = out / "part-0001-of-0001.zip"
    zp.write_bytes(b"PK\x03\x04demo")
    sha, size = B.final_zip_metrics(out, zp)
    assert size == zp.stat().st_size == 8
    assert sha == S._sha_raw(zp)


def test_final_zip_metrics_refuses_when_part_left(tmp_path):
    """残留 `.part` = 打包没走完，此时任何大小都不可信。"""
    out = tmp_path / "pkg"
    out.mkdir()
    (out / "part-0001-of-0001.zip").write_bytes(b"PK\x03\x04")
    (out / "part-0001-of-0001.zip.part").write_bytes(b"PK\x03\x04half")
    with pytest.raises(RuntimeError, match="临时 ZIP"):
        B.final_zip_metrics(out, out / "part-0001-of-0001.zip")


def test_final_zip_metrics_refuses_when_zip_absent(tmp_path):
    out = tmp_path / "pkg"
    out.mkdir()
    with pytest.raises(RuntimeError, match="未落盘"):
        B.final_zip_metrics(out, out / "part-0001-of-0001.zip")


# ── 四、AC 容器状态（`formal_container_integrity` / `ac_data_state`）──────
# 复审方点名要求这两个机器可读字段。它们进了 manifest 就不能是装饰：
# 自检必须能从**包内 JSON** 把两个值重算出来，重算不出或对不上就红。
def _rec(out: Path) -> dict:
    man = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    return man["records"][0]


def _set_rec(out: Path, **kv) -> None:
    p = out / "manifest.json"
    man = json.loads(p.read_text(encoding="utf-8"))
    man["records"][0].update(kv)
    p.write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")


def test_container_state_prefers_recorded_metadata():
    """源文件自带的值优先，并标明来源可追溯（`metadata`）。"""
    doc = {"metadata": {"formal_container_integrity": "pass",
                        "ac_data_state": "withheld"},
           "specs": {"unresolved_ac_rows": [{"name": "SNR"}]}}
    cs = B.container_state(doc)
    assert cs["formal_container_integrity"] == "pass"
    assert cs["ac_data_state"] == "withheld"
    assert cs["container_state_source"] == "metadata"
    assert cs["container_state_match"] is True


def test_container_state_recomputes_when_metadata_absent():
    """老 JSON 没跑过隔离 → 补算，但来源必须标 `recomputed`（本身就是缺口）。"""
    doc = {"metadata": {}, "specs": {"unresolved_ac_rows": [{"name": "SNR"}]}}
    cs = B.container_state(doc)
    assert cs["ac_data_state"] == "withheld"
    assert cs["container_state_source"] == "recomputed"


def test_container_state_flags_contradiction():
    """清单说「没扣押」而源文件里躺着隔离行 —— 这种自相矛盾必须能被发现。

    这是本组用例里最要紧的一条：`ac_data_state=not_withheld` 配着非空隔离桶，
    复核方会读成「没有数据被藏起来」，而实际藏了。
    """
    doc = {"metadata": {"formal_container_integrity": "pass",
                        "ac_data_state": "not_withheld"},
           "specs": {"unresolved_ac_rows": [{"name": "SNR"}]}}
    assert B.container_state(doc)["container_state_match"] is False


def test_container_state_flags_dirty_ac_row_in_formal_container():
    """正式 AC 容器里还有列角色错位的行 → integrity 不能是 pass。"""
    doc = {"metadata": {}, "specs": {"ac_performance": [
        {"symbol": "SNR", "parameter": "SNR", "min": "", "typ": "dB", "max": "91.5"}]}}
    assert B.container_state(doc)["formal_container_integrity"] == "fail"


def test_render_note_has_ac_state_section():
    rows = [{"mpn": MPN, "n_rows": 43, "row": 22, "para": 1, "weak": 20,
             "gate": "blocked", "verdict": "partial_pass",
             "state": "PACKAGING_PASSED", "isolated": [("unresolved_ac_rows", 6)],
             "integrity": "pass", "ac_state": "withheld",
             "cs_source": "metadata", "cs_match": True}]
    text = B.render_delivery_note("delivery-demo", rows, {})
    assert "AC 脏行隔离状态" in text
    # 表格行必须带两个值，自检按这一行核对
    row = next(ln for ln in text.splitlines() if f"`{MPN}`" in ln and "withheld" in ln)
    assert "pass" in row and "metadata" in row and "ok" in row
    # 「不等于放行」这句话是字段语义的边界，删了就会被读成质量结论
    assert "不等于放行" in text


def test_render_note_tolerates_rows_without_state(tmp_path):
    """手搓 rows（老调用方）不该 KeyError，缺就印 `-`。"""
    rows = [{"mpn": MPN, "n_rows": 3, "row": 1, "para": 1, "weak": 0,
             "gate": "pass", "verdict": "pass",
             "state": "IDENTITY_APPROVED", "isolated": []}]
    text = B.render_delivery_note("delivery-demo", rows, {})
    assert "AC 脏行隔离状态" in text
    assert "| `-` |" in text or "-" in text


def test_selfcheck_recomputes_container_state_from_json(tmp_path):
    """清单写的值能被包内 JSON 重算出来 → 不红。"""
    out = build(tmp_path)
    _add_json(out, quarantined=6)
    _set_rec(out, formal_container_integrity="pass", ac_data_state="withheld",
             container_state_source="metadata", container_state_match=True)
    bad = [x for x in S.check(out) if "container" in x or "ac_data_state" in x]
    assert not bad, bad


def test_selfcheck_flags_container_state_mismatch(tmp_path):
    """清单写 not_withheld、包内 JSON 有隔离行 → 必须红（这是最危险的一种）。"""
    out = build(tmp_path)
    _add_json(out, quarantined=6)
    _set_rec(out, formal_container_integrity="pass", ac_data_state="not_withheld",
             container_state_source="metadata", container_state_match=True)
    bad = S.check(out)
    assert any("ac_data_state" in x and "重算" in x for x in bad), bad


def test_selfcheck_flags_quarantine_mark_left_in_formal_container(tmp_path):
    """隔离行搬了一半：正式容器里还留着 `quarantine_reason` → integrity 必须红。

    判据统一到 `qc/ac_quarantine.py` 之后，权威定义识别的是「AC 逃逸行」而不再
    是私有隔离标记；芯片页主表本来就不在逃逸判据的扫描范围（见该模块头），
    所以夹具改成板卡形态，让权威判据确实覆盖这份主表。断言强度不变。
    """
    out = build(tmp_path)
    base = out / "part-0001-of-0001" / MPN
    (base / f"{MPN}.json").write_text(json.dumps({
        "basic_info": {"mpn": MPN, "identity": "evaluation_board"},
        "specs": {"electrical": [{"name": "SNR", "value": "91.5",
                                  "quarantine_reason": "列角色错位"}]},
    }, ensure_ascii=False), encoding="utf-8")
    _set_rec(out, formal_container_integrity="pass", ac_data_state="not_withheld",
             container_state_source="metadata", container_state_match=True)
    bad = S.check(out)
    assert any("formal_container_integrity" in x and "重算" in x for x in bad), bad


def test_selfcheck_flags_missing_ac_state_row_in_note(tmp_path):
    """清单有这两列、说明里却没有对应行 → 复核方读不到，等于没写。"""
    out = build(tmp_path)
    _set_rec(out, formal_container_integrity="pass", ac_data_state="not_withheld",
             container_state_source="metadata", container_state_match=True)
    bad = _note_bad(out)
    assert any("缺 AC 容器状态行" in x and MPN in x for x in bad), bad


def test_selfcheck_accepts_ac_state_row_in_note(tmp_path):
    out = build(tmp_path)
    _set_rec(out, formal_container_integrity="pass", ac_data_state="not_withheld",
             container_state_source="metadata", container_state_match=True)
    _append_note(out, f"\n| `{MPN}` | pass | not_withheld | metadata | ok |\n")
    assert not [x for x in _note_bad(out) if "AC 容器状态行" in x]


# ── 五、多轮 README：字节数声明按小节归属 ─────────────────────────
# 发布仓库根 README 是**多轮累计**的：同一份文件里同时写着 V11 与 V2 的 ZIP 大小。
# 拿本包大小去卡历史那一段，只会逼着人把历史数字删掉 —— 那是毁证据，不是修错。
def test_byte_claim_in_other_round_section_is_ignored(tmp_path):
    out = build(tmp_path)
    n = _pad_zip(out)
    other = n + 432
    doc = tmp_path / "README.md"
    doc.write_text(
        "### 上一轮：delivery-20261102（V11）\n"
        f"| 分卷 ZIP | part-0001-of-0001.zip，{other:,} B |\n",
        encoding="utf-8")
    assert not S._check_doc_byte_claims(out, extras=[doc])


def test_byte_claim_in_current_round_section_is_checked(tmp_path):
    """同一份文件里、讲本包的那一段，写错照样要红。"""
    out = build(tmp_path)
    n = _pad_zip(out)
    doc = tmp_path / "README.md"
    doc.write_text(
        f"### 本轮：{out.name}\n"
        f"| 分卷 ZIP | part-0001-of-0001.zip，{n + 432:,} B |\n",
        encoding="utf-8")
    bad = S._check_doc_byte_claims(out, extras=[doc])
    assert any("写 ZIP 为" in x for x in bad), bad


def test_byte_claim_without_any_round_token_is_checked(tmp_path):
    """没点明哪一轮 = 默认在说本包，照查（宁可严，不可漏）。"""
    out = build(tmp_path)
    n = _pad_zip(out)
    doc = tmp_path / "README.md"
    doc.write_text(f"| 分卷 ZIP | part-0001-of-0001.zip，{n + 432:,} B |\n",
                   encoding="utf-8")
    assert S._check_doc_byte_claims(out, extras=[doc])


# ── 五、多轮 README：字节数声明按小节归属 ─────────────────────────
# 发布仓库根 README 是**多轮累计**的：同一份文件里同时写着 V11 与 V2 的 ZIP 大小。
# 拿本包大小去卡历史那一段，只会逼着人把历史数字删掉 —— 那是毁证据，不是修错。
def test_byte_claim_in_other_round_section_is_ignored(tmp_path):
    out = build(tmp_path)
    n = _pad_zip(out)
    other = n + 432
    doc = tmp_path / "README.md"
    doc.write_text(
        "### 上一轮：delivery-20261102（V11）\n"
        f"| 分卷 ZIP | part-0001-of-0001.zip，{other:,} B |\n",
        encoding="utf-8")
    assert not S._check_doc_byte_claims(out, extras=[doc])


def test_byte_claim_in_current_round_section_is_checked(tmp_path):
    """同一份文件里、讲本包的那一段，写错照样要红。"""
    out = build(tmp_path)
    n = _pad_zip(out)
    doc = tmp_path / "README.md"
    doc.write_text(
        f"### 本轮：{out.name}\n"
        f"| 分卷 ZIP | part-0001-of-0001.zip，{n + 432:,} B |\n",
        encoding="utf-8")
    bad = S._check_doc_byte_claims(out, extras=[doc])
    assert any("写 ZIP 为" in x for x in bad), bad


def test_byte_claim_without_any_round_token_is_checked(tmp_path):
    """没点明哪一轮 = 默认在说本包，照查（宁可严，不可漏）。"""
    out = build(tmp_path)
    n = _pad_zip(out)
    doc = tmp_path / "README.md"
    doc.write_text(f"| 分卷 ZIP | part-0001-of-0001.zip，{n + 432:,} B |\n",
                   encoding="utf-8")
    assert S._check_doc_byte_claims(out, extras=[doc])
