#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""人工内容审批是**独立维度** —— 与机器闸门 `gate` / `anchor_gate` 并列记录。

2026-11-04 用户裁决：`anchor_gate=blocked`（机器没拿到坐标证据）与
`CONTENT_APPROVED`（专家逐字段看过）量的不是一件事。允许后者跨过前者的档位，
但**必须留痕**：`release_state` 升到 `CONTENT_APPROVED` 的同时，
`content_signoff` 写 `APPROVED (with warnings)`，`gate` 照旧 `BLOCKED`。

这些用例守的就是「跨级三边界」：
  ① 底层 `anchor_gate` / `facts` 一个字都不改（不许造假）；
  ② 身份门禁不可跨（身份错了，内容审得再细也是白审）；
  ③ 跨级必须在 manifest / README 里可见（否则下游读成「机器也验过了」）。
"""
from __future__ import annotations

import copy
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as DB                                    # noqa: E402

ALL_ART = ["json", "html", "symbol", "pdf"]


def _doc(*, identity_state: str = "IDENTITY_SUPPORTED",
         core: str = "pass") -> dict:
    return {"metadata": {"core_validation": core, "pdf_hash": "x"},
            "basic_info": {"mpn": "LM317", "identity": "chip",
                           "identity_state": identity_state,
                           "manufacturer": "Texas Instruments"}}


def _facts(*, gate: str = "blocked", verdict: str = "pass") -> dict:
    return {"n_rows": 62, "verdict": verdict, "anchor_gate": gate,
            "grades": {"row_anchor": 55, "paragraph_anchor": 0,
                       "coord_no_fingerprint": 0, "container_verified": 1,
                       "weak": 6, "no_value": 0},
            "blocked": ["RθJA (have=container_verified, need=row_anchor)"]}


SIGNED = {"content_approved": True, "release_approved": False,
          "signoff_by": "wuxiaoxian", "signed_at": "2026-11-04",
          "waiver": "热阻 6 条无行坐标，数值已逐行对齐，人工强签放行"}


# ── 边界 ①：没有签核文件时，一切照旧 ─────────────────────────────
def test_no_signoff_keeps_machine_rung():
    """没有 `signoff.json` 时不得凭空升档，且 `content_signoff=NONE`。"""
    st = DB._release_state(_doc(), ALL_ART, True, _facts(), {})
    assert st == "PACKAGING_PASSED"
    info = DB._content_signoff(_doc(), _facts(), {})
    assert info["content_signoff"] == "NONE"
    assert info["content_signoff_by"] == ""


def test_signoff_without_true_flag_is_not_a_signoff():
    """`content_approved` 必须严格是 `True`；字符串 "true" 不算。"""
    so = {"content_approved": "true", "signoff_by": "wuxiaoxian"}
    assert DB._content_signoff(_doc(), _facts(), so)["content_signoff"] == "NONE"
    assert DB._release_state(_doc(), ALL_ART, True, _facts(), so) == "PACKAGING_PASSED"


# ── 核心：允许跨过机器档位，但留痕 ────────────────────────────────
def test_crosses_blocked_anchor_gate_with_warnings():
    st = DB._release_state(_doc(), ALL_ART, True, _facts(), SIGNED)
    assert st == "CONTENT_APPROVED"
    info = DB._content_signoff(_doc(), _facts(), SIGNED)
    assert info["content_signoff"] == "APPROVED (with warnings)"
    assert info["content_signoff_by"] == "wuxiaoxian"
    # 注脚必须写明「机器没拿到坐标证据」这件事，不能只写「已批准」
    assert "机器审计未获坐标证据" in info["content_signoff_note"]
    assert "2026-11-04" in info["content_signoff_note"]


def test_waiver_overrides_default_note():
    """签核人自己写的豁免理由优先于默认措辞 —— 逐件的理由才是复核方要看的。"""
    info = DB._content_signoff(_doc(), _facts(), SIGNED)
    assert info["content_signoff_note"].startswith("热阻 6 条无行坐标")


def test_default_note_used_when_no_waiver():
    so = {"content_approved": True, "signoff_by": "wuxiaoxian"}
    info = DB._content_signoff(_doc(), _facts(), so)
    assert info["content_signoff"] == "APPROVED (with warnings)"
    assert "机器审计未获坐标证据（anchor_gate=blocked），由人工专家强签放行" \
        in info["content_signoff_note"]


# ── 边界 ①：跨级不得篡改机器结论 ─────────────────────────────────
def test_machine_verdicts_are_not_mutated():
    """`_content_signoff` / `_release_state` 只读：facts 与 doc 必须逐字节不变。"""
    facts = _facts()
    doc = _doc()
    f0, d0 = copy.deepcopy(facts), copy.deepcopy(doc)
    DB._release_state(doc, ALL_ART, True, facts, SIGNED)
    DB._content_signoff(doc, facts, SIGNED)
    assert facts == f0, "机器闸门结论被签核逻辑改写了"
    assert doc == d0, "文档对象被签核逻辑改写了"


def test_gate_stays_blocked_in_manifest_columns():
    """`gate` 与 `content_signoff` 必须同时出现在清单列里且互不覆盖。"""
    doc = _doc()
    gate, _why = DB._gate(doc, True)
    assert gate != "CLEAN"
    info = DB._content_signoff(doc, _facts(), SIGNED)
    row = {**info, "gate": gate}
    assert row["gate"] == gate and row["content_signoff"].startswith("APPROVED")


# ── 边界 ②：身份门禁不可跨 ───────────────────────────────────────
def test_identity_gate_is_not_crossable():
    doc = _doc(identity_state="IDENTITY_REVIEW")
    st = DB._release_state(doc, ALL_ART, True, _facts(), SIGNED)
    assert st == "PACKAGING_PASSED", "身份未审核却升到了 CONTENT_APPROVED"
    info = DB._content_signoff(doc, _facts(), SIGNED)
    assert info["content_signoff"] == "APPROVED (blocked: identity)"
    assert "不可跨" in info["content_signoff_note"]


# ── 发布放行是第三个维度，不能由内容签核代替 ──────────────────────
def test_content_approved_alone_never_release_approved():
    assert DB._release_state(_doc(), ALL_ART, True, _facts(), SIGNED) \
        == "CONTENT_APPROVED"
    both = {**SIGNED, "release_approved": True}
    assert DB._release_state(_doc(), ALL_ART, True, _facts(), both) \
        == "RELEASE_APPROVED"


# ── 机器本来就过了：不该出现 (with warnings) ─────────────────────
def test_no_warning_when_machine_already_passed():
    facts = _facts(gate="pass")
    doc = _doc()
    info = DB._content_signoff(doc, facts, SIGNED)
    assert info["content_signoff"] == "APPROVED"
    assert info["content_signoff_note"] == ""
    assert DB._release_state(doc, ALL_ART, True, facts, SIGNED) == "CONTENT_APPROVED"


# ── 留痕的载体：manifest.csv 列 ──────────────────────────────────
@pytest.mark.parametrize("col", ["content_signoff", "content_signoff_by",
                                 "content_signoff_note"])
def test_manifest_csv_columns_include_signoff(col):
    """漏列不会报错，只会让跨级放行「只在 JSON 里可见」。"""
    assert col in DB.MANIFEST_COLUMNS


def test_signoff_columns_adjacent_to_gate():
    """两维必须相邻，复核方一眼能对照「机器判了什么 / 人判了什么」。"""
    cols = list(DB.MANIFEST_COLUMNS)
    i = cols.index("content_signoff")
    assert cols[i + 3] == "gate"
    assert cols[i - 1] == "release_state"
