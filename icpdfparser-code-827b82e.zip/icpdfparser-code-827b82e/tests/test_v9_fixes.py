"""V9：9.4 分复审的 P0/P1 修复锁 —— 三个反例 + 四项一致性。

复审原话：「别再改功能，把状态歧义消掉」。所以这里的每一条都是
**已经发生过一次的具体错误**，不是假想场景：

【P0-1】`range` 结构投毒 —— JSON 写 `column_roles_verified`，
        事实表判 `verified_value` + `missing_cols` 非空。
【P0-1b】ADS8568EVM 的 24 行板载电气「审了、算进分母、卡住闸门，但读者看不见」。
【P1-1】`facts_verdict=pass` 与 `anchor_gate=blocked` 并存，读起来自相矛盾。
【P1-2】正向提示条只覆盖 37/108 行，AC/热阻/ESD 落在「没告警也没说没问题」的灰区。
【P2-1】自检不查 `risk_queue` 行数与事实表分母。

三条反例测试（复审点名要的）：
    test_verified_value_forbids_column_roles_verified
    test_onboard_device_forbids_board_level_claim
    test_anchor_gate_pass_does_not_approve_content
"""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import json_to_txt as J                      # noqa: E402
from qc import range_guard as RG             # noqa: E402
from qc import deterministic_extract as DE   # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
STAGING = ROOT / "data" / "staging_20261101_v9"


# ── 反例一：verified_value 不许再声称列角色已核验 ─────────────────
def test_verified_value_forbids_column_roles_verified():
    """复审 P0-1 的原样记录：`range` 看起来已核验，事实表说只到坐标级。

    两条断言各管一头：
    * `is_trusted` 必须拒绝 —— 读的时候拿不到区间；
    * `enforce` 必须物理删掉 —— 写的时候也不许留。
    """
    poisoned = {
        "name": "Differential Input Voltage Range",
        "condition": "With VBIAS(1)",
        "value": "-20 to +20",
        "range": {"min": "-20", "max": "+20"},
        "range_origin": "column_roles_verified",
        "verification": {"status": "audited_coord",
                         "fact_verdict": "verified_value"},
    }
    assert RG.is_trusted(poisoned) is False
    assert RG.safe_range(poisoned) is None

    doc = {"specs": {"electrical": [dict(poisoned)]}}
    rep = RG.enforce(doc)
    assert rep["n_stripped"] == 1
    row = doc["specs"]["electrical"][0]
    assert "range" not in row, "`range` 没被物理抹除，下游照样能读到"
    assert row["range_origin"] == RG.UNVERIFIED
    assert "range_note" in row
    # 值本身不许丢：抹的是结构，不是事实
    assert row["value"] == "-20 to +20"


def test_row_anchored_keeps_verified_range():
    """反向：证据够了就必须保留 —— 否则这条守卫变成"一律不信任"。"""
    good = {"name": "V", "value": "0 to 5",
            "range": {"min": "0", "max": "5"},
            "range_origin": "column_roles_verified",
            "verification": {"fact_verdict": "verified_row"}}
    assert RG.is_trusted(good) is True
    doc = {"specs": {"electrical": [dict(good)]}}
    assert RG.enforce(doc)["n_stripped"] == 0
    assert doc["specs"]["electrical"][0]["range"] == {"min": "0", "max": "5"}


def test_single_ended_range_is_not_readable():
    """`{"min": "", "max": "26.25"}` 只剩一端 —— 读出来就是 `to 26.25` 残句。

    实测 ADC 页上真的印出过 `to 26.25 dBm`。`safe_range` 挡在这里，
    `spec_value` 才会回退到 `value`。
    """
    row = {"name": "Peak RF Input Power", "value": "26.25", "unit": "dBm",
           "range": {"min": "", "max": "26.25"},
           "range_origin": "column_roles_verified",
           "verification": {"fact_verdict": "verified_row"}}
    assert RG.safe_range(row) is None
    assert J.spec_value(row) == "26.25 dBm"
    assert "to " not in J.spec_value(row)


def test_input_range_row_refuses_range_when_typ_is_a_footnote():
    """源头就不产出：`TYP` 格印脚注时，MIN/MAX 是从剩下的两格推出来的。"""
    r = {"min": "-20", "max": "+20", "typ": "See Note 2", "cond": "With VBIAS(1)",
         "unit": "V", "page": 2, "bbox": [0, 0, 1, 1], "row_sha256": "x" * 64}
    row = DE._input_range_row("Differential Input Voltage Range", r, "V")
    assert "range" not in row
    assert row["range_origin"] == "column_roles_unverified"
    assert row["typ"] == "See Note 2"

    ok = DE._input_range_row("Abs Input", {"min": "0", "max": "+5", "typ": "",
                                          "cond": "", "unit": "V", "page": 2,
                                          "bbox": [0, 0, 1, 1],
                                          "row_sha256": "y" * 64}, "V")
    assert ok["range"] == {"min": "0", "max": "+5"}
    assert ok["range_origin"] == "column_roles_verified"


# ── 反例二：板载器件的参数不许说成整板能力 ───────────────────────
def _board_doc_with_onboard_rows() -> dict:
    """造一块「源文档是芯片 datasheet」的板子：主表空，行全在隔离桶里。"""
    rows = [{"name": f"PRM{i:02d}", "value": str(i), "unit": "V",
             "condition": ""} for i in range(1, 25)]
    rows[0] = {"name": "Power Dissipation", "value": "259.7", "unit": "mW",
               "condition": ""}
    rows[1] = {"name": "IAVDD", "value": "36.6", "unit": "mA", "condition": ""}
    return {
        "basic_info": {"mpn": "ADS-TEST-EVM", "identity": "evaluation_board",
                       "manufacturer": "Test"},
        "specs": {"scope": "onboard_device", "electrical": [],
                  # 器件名从 `specs.package.onboard_device` 读 —— 没它标题会退成
                  # 「(onboard device)」，页面上就看不出这一坨数值是谁的。
                  "package": {"onboard_device": "ADS8568"},
                  "onboard_device_specs": {
                      "device_mpn": "ADS8568", "scope": "onboard_device",
                      "electrical": rows}},
    }


def test_onboard_device_forbids_board_level_claim():
    """24 行必须上页面，但**必须**同时声明「这不是整板限值」。

    复审 新-1 的两难在这里收口：不渲染是内容缺失，渲染而不声明是身份混淆。
    两个都要，缺一个都算失败。
    """
    html = J.render(_board_doc_with_onboard_rows(), "en")
    # ① 行必须在 —— 复审搜了 `259.7` / `36.6` 两个数，全 0 命中
    assert "259.7" in html and "36.6" in html
    assert "Power Dissipation" in html and "IAVDD" in html
    # ② 归属必须声明 —— 否则读者把芯片能力当整板能力
    assert "On-board Device Electrical Specifications (ADS8568)" in html
    assert "not limits for the assembled board" in html
    # ③ 整板限值没给这件事也要说，不能拿芯片参数顶替
    assert "Board-level electrical specifications are not stated" in html
    # ④ 24 行全在（前两条被替换成功耗/IAVDD，从 03 起）
    for i in range(3, 25):
        assert f"PRM{i:02d}" in html, f"缺行 PRM{i:02d}"


def test_chip_page_ignores_onboard_bucket():
    """芯片页不吃隔离桶 —— 隔离桶是治理层，不是内容层。"""
    doc = {"basic_info": {"mpn": "ADS1201U", "identity": "device"},
           "specs": {"scope": "device", "electrical": [],
                     "onboard_device_specs": {"electrical": [
                         {"name": "ONBOARD_SHOULD_NOT_APPEAR",
                          "value": "999", "unit": "V"}]}}}
    html = J.render(doc, "en")
    assert "ONBOARD_SHOULD_NOT_APPEAR" not in html


# ── 反例三：anchor_gate=pass 不等于内容审核通过 ──────────────────
def test_anchor_gate_pass_does_not_approve_content():
    """`anchor_gate=pass` 只说明「证据载体达门槛」，四件事它一概不管。

    复审反复强调的是这条语义：闸门管的是**证据等级**，不是内容对不对。
    """
    import delivery_bundle as DB

    doc = {"basic_info": {"mpn": "X", "identity": "device",
                          "identity_state": "IDENTITY_SUPPORTED"},
           "metadata": {"core_validation": "pass"}}
    facts = {"verdict": "pass", "anchor_gate": "pass"}
    have = ["json", "html", "symbol", "pdf"]

    state = DB._release_state(doc, have, True, facts, signoff=None)
    # 证据齐 → 只能到 IDENTITY_APPROVED，不许自己走到 CONTENT_APPROVED
    assert state == "IDENTITY_APPROVED"
    # 内容审校与发布放行**只认签核文件**，代码不代签
    assert DB._release_state(doc, have, True, facts,
                             signoff={"content_approved": False}) == "IDENTITY_APPROVED"
    assert DB._release_state(doc, have, True, facts,
                             signoff={"content_approved": True,
                                      "release_approved": False}) == "CONTENT_APPROVED"
    # 没有签核就永远到不了 RELEASE_APPROVED
    assert state != "RELEASE_APPROVED"


def test_anchor_gate_blocked_stops_at_packaging():
    """闸门 blocked 时必须停在 PACKAGING_PASSED —— 身份再好也不许越级。"""
    import delivery_bundle as DB

    doc = {"basic_info": {"mpn": "X", "identity": "device",
                          "identity_state": "IDENTITY_SUPPORTED"},
           "metadata": {"core_validation": "pass"}}
    facts = {"verdict": "pass", "anchor_gate": "blocked"}
    state = DB._release_state(doc, ["json", "html", "symbol", "pdf"], True,
                              facts, signoff=None)
    assert state == "PACKAGING_PASSED"


# ── P1-1：pass + blocked 必须显式写成 partial_pass ───────────────
def test_partial_pass_replaces_pass_when_gate_blocked():
    """复审判定的「容易误读」：同一型号同时写 pass 与 blocked。

    现在 `facts_verdict` 会降成 `partial_pass`，并附一句人话 `facts_note`。
    这里直接跑打包器的推导函数，避免"文档里改了、代码没改"。
    """
    import delivery_bundle as DB

    src = (ROOT / "delivery_bundle.py").read_text(encoding="utf-8")
    # 推导必须在打包器里，而不是靠人手写 manifest
    assert "partial_pass" in src
    assert "facts_note" in src
    # 列名也要在，否则 CSV 里看不到这句解释
    assert '"facts_note"' in src
    # 语义：pass + blocked 才有这个注脚
    blk = ["Differential Input Voltage Range (have=coord_no_fingerprint, need=row_anchor)"]
    assert len(blk) == 1


# ── P1-2：正向提示条必须覆盖全页，不能只覆盖前两张表 ─────────────
def _all_anchored_doc() -> dict:
    el = [{"name": f"E{i}", "value": str(i), "unit": "V", "condition": "",
           "verification": {"fact_verdict": "verified_row"}} for i in range(22)]
    amax = [{"name": f"A{i}", "value": str(i), "unit": "V",
             "verification": {"fact_verdict": "verified_row"}} for i in range(15)]
    ac = [{"symbol": f"S{i}", "min": "1", "typ": "2", "max": "3",
           "unit": "dB", "conditions": "c",
           "verification": {"fact_verdict": "verified_row"}} for i in range(64)]
    th = [{"name": f"R{i}", "value": str(i), "unit": "C/W", "condition": "",
           "verification": {"fact_verdict": "verified_row"}} for i in range(5)]
    esd = [{"name": f"V{i}", "value": "2000", "unit": "V", "condition": "",
            "verification": {"fact_verdict": "verified_row"}} for i in range(2)]
    doc = {"basic_info": {"mpn": "ADC-TEST", "identity": "device"},
           "specs": {"scope": "device", "electrical": el, "absolute_max": amax,
                     "ac_performance": ac, "thermal": th, "esd": esd}}
    doc["metadata"] = {"facts_verdicts": {
        f"{r.get('name') or r.get('symbol')}\x1f"
        f"{r.get('condition') or r.get('conditions') or ''}": "verified_row"
        for r in el + amax + ac + th + esd}}
    return doc


def test_positive_note_is_page_wide_not_per_table():
    """108 行必须一句盖全，且把 AC 的 64 条数进去（复审 新-3）。"""
    html = J.render(_all_anchored_doc(), "en")
    assert "All 108 entries on this page are anchored" in html
    assert "AC 64" in html
    assert "electrical 22" in html
    # 全页干净时不再每张表重复一句 "All N entries below"
    assert "entries below are anchored" not in html


def test_partial_page_keeps_per_table_note():
    """只有部分表干净时，正向提示要落回**干净的那张表**上。"""
    doc = _all_anchored_doc()
    doc["specs"]["electrical"][0]["verification"] = {"fact_verdict": "value_in_pdf"}
    # 事实表结论优先于 JSON 自述 —— 两处都要改，否则守卫读的还是 verified_row
    doc["metadata"]["facts_verdicts"][f"E0\x1f"] = "value_in_pdf"
    html = J.render(doc, "en")
    assert "All 108 entries on this page" not in html
    assert "of 22 entries below are marked unverified" in html
    # 干净的最大值表仍有自己的正向结论
    assert "All 15 entries below are anchored" in html


# ── P2-1：自检必须查行数口径 ────────────────────────────────────
def test_selfcheck_has_facts_and_risk_row_counts():
    """自检要能重算 `facts_summary`，否则「审了多少行」只能靠说明文本自证。"""
    src = (ROOT / "qc" / "bundle_selfcheck.py").read_text(encoding="utf-8")
    assert "facts_summary" in src
    assert "risk_queue_rows" in src
    assert "facts_audit_rows" in src
    assert "_count_csv_rows" in src

    bsrc = (ROOT / "delivery_bundle.py").read_text(encoding="utf-8")
    assert '"facts_summary": facts_summary' in bsrc
    assert "risk_queue_rows" in bsrc


def test_selfcheck_count_csv_rows_matches_dictreader(tmp_path):
    """`_count_csv_rows` 的口径必须与打包器写计数时一致（表头不算行）。"""
    from qc.bundle_selfcheck import _count_csv_rows

    p = tmp_path / "x.csv"
    p.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")
    assert _count_csv_rows(p) == 2
    assert _count_csv_rows(tmp_path / "missing.csv") == -1


# ── 真实包：五页实测不再出现空表 / 隐形行 ────────────────────────
@pytest.mark.skipif(not (STAGING / "parsed" / "ADS8568EVM-PDK.json").is_file(),
                    reason="缺 V9 staging 数据")
def test_ads8568_page_renders_onboard_electrical_table():
    doc = json.loads((STAGING / "parsed" / "ADS8568EVM-PDK.json")
                     .read_text(encoding="utf-8"))
    fv = json.loads((STAGING / "facts_verdicts.json").read_text(encoding="utf-8"))
    doc.setdefault("metadata", {})["facts_verdicts"] = fv["mpns"]["ADS8568EVM-PDK"]
    html = J.render(doc, "en")
    # 本用例的立意是「板载电气表不许被整锅吞掉」，不是「24 行必须全印」。
    # 1102V2 起，逃逸进板载桶、又没有独立 bbox/row_sha256 的 4 条 AC 行
    # （SNR/THD/SFDR/Channel-to-Channel Isolation）在渲染出口被扣下，
    # 剩下的 20 行仍必须逐条可见。
    for probe in ("259.7", "36.6", "Power Dissipation", "IAVDD"):
        assert probe in html, f"页面缺 {probe}，板载电气表又没渲染"
    assert "On-board Device Electrical Specifications (ADS8568)" in html
    # 扣下 ≠ 静默：AC 行不在表里，但页面必须写明扣了几条、为什么扣。
    # 1102-V3 起 THD / SNR 被平反（有了独立溯源），扣下的从 4 条降到 2 条，
    # 分母随之 20 → 22。这里断的是「披露机制还在」，不是固定条数。
    assert "Channel-to-Channel Isolation" not in html, "逃逸 AC 行又印回电气表了"
    assert "2 AC rows in the on-board device electrical table were withheld" in html
    # 弱证据必须在页面上看到 † 与计数，读者才知道闸门为什么 blocked
    assert "11 of 22 entries below are marked unverified" in html


@pytest.mark.skipif(not (STAGING / "parsed" / "ADS1201U-1_1K.json").is_file(),
                    reason="缺 V9 staging 数据")
def test_staged_ads1201_row_has_no_poisoned_range():
    doc = json.loads((STAGING / "parsed" / "ADS1201U-1_1K.json")
                     .read_text(encoding="utf-8"))
    hits = [r for r in (doc["specs"]["electrical"] or [])
            if str(r.get("name") or "").startswith("Differential Input Voltage Range")
            and "VBIAS" in str(r.get("condition") or "")]
    assert hits, "目标行不见了 —— 这条用例就失去意义"
    row = hits[0]
    assert "range" not in row
    assert row["range_origin"] == RG.UNVERIFIED
    assert (row.get("verification") or {}).get("fact_verdict") == "verified_value"
