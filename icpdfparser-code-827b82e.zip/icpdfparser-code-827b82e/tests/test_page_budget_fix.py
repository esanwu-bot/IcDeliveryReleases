#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""选页预算与整页截断的红先用例（2026-10-31 Reviewer 复盘 #15/#16 衍生）。

**背景（取证见 qc/evidence_20261031/二次确认_取证报告_ADC12DJ5200SE.md）**：
ADC12DJ5200SE 的交付 JSON 是 2026-10-22 的产物，当时取页逻辑是
`i >= MAX_PAGES(12): break` + `out[:32000]` 字符串硬切，后果可逐字定位：

* 订货表在 **p175** → 从未进 prompt → `ordering_info=0` / `IDENTITY_REVIEW`；
* 热阻表 `RθJA` 的绝对偏移是 **32006**，截断点 **32000**，正好切在
  `RθJA Junction-to-ambient thermal resi` 三个字母上 → 热阻全丢；
* `SNR/SFDR` 在 **p14**，超出 12 页上限 → AC 性能零覆盖。

本文件的断言就是这三件事的标尺：**跑一把提取，必须能看见 RθJA 的数值、
必须能看见可订购号**。这三条绿了，同类「截断惨案」才算翻篇。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as P                                  # noqa: E402

PDF = ROOT / "data" / "pdfs" / "ADC12DJ5200SEAAV__adc12dj5200se.pdf"

needs_pdf = pytest.mark.skipif(not PDF.exists(), reason="缺 ADC12DJ5200SE 标尺 PDF")


# ---------------------------------------------------------------- 预算常量
def test_max_chars_raised_to_50k():
    """32000 的预算会把热阻表切掉；抬到 50000 才装得下 p1-10 全部关键表。"""
    assert P.MAX_CHARS >= 50_000, f"MAX_CHARS={P.MAX_CHARS}，热阻表仍会被切"


# ---------------------------------------------------------------- 强制关键页
def _synthetic_pages(n: int = 30) -> list[tuple[int, str]]:
    """造一份「关键表在很后面」的文档：p25 热阻、p28 订货表。"""
    pages = [(i, f"page {i + 1} body text " + "x" * 1200) for i in range(n)]
    pages[24] = (24, "5.4 Thermal Information\nRθJA Junction-to-ambient 23.9 °C/W " + "y" * 1200)
    pages[27] = (27, "PACKAGE OPTION ADDENDUM\nOrderable part number ADC0000AAV " + "z" * 1200)
    return pages


def test_mandatory_pages_survive_tight_budget():
    """预算紧张、页数配额也紧张时，热阻页与订货页仍必须入列。"""
    text, used, _ = P.select_pages(_synthetic_pages(), max_pages=6, max_chars=12_000)
    assert "RθJA" in text, "热阻页被预算挤掉了"
    assert "Orderable part number" in text, "订货页被预算挤掉了"


def test_mandatory_pages_displace_non_mandatory():
    """强制页不能靠「超额」实现：总页数仍要守住 max_pages。"""
    text, used, _ = P.select_pages(_synthetic_pages(), max_pages=6, max_chars=12_000)
    assert used <= 6, f"选页数 {used} 超了配额 6"
    assert text.count("--- Page ") == used


# ---------------------------------------------------------------- 整页截断
@needs_pdf
def test_thermal_table_recovered_from_real_pdf():
    """标尺一：热阻数值必须到模型眼前（旧实现切在 RθJA 行首）。"""
    text, _, _, _ = P.extract_pdf_text(PDF)
    assert "RθJA" in text, "热阻表仍被截断"
    for v in ("23.9", "0.8", "8.4"):
        assert v in text, f"热阻数值 {v} 缺失"


@needs_pdf
def test_ordering_part_number_recovered_from_real_pdf():
    """标尺二：可订购号必须到模型眼前（旧实现被 12 页上限挡在门外）。"""
    text, _, _, _ = P.extract_pdf_text(PDF)
    assert "ADC12DJ5200SEAAV" in text, "订货表仍未进入 prompt"


@needs_pdf
def test_esd_ratings_present_from_real_pdf():
    """标尺三：ESD 是硬件工程师必查项，必须在上下文里。"""
    text, _, _, _ = P.extract_pdf_text(PDF)
    assert "Human-body model" in text and "Charged device model" in text


@needs_pdf
def test_pages_are_never_cut_mid_page():
    """整页截断：每个 `--- Page N ---` 块都必须是该页全文，不许半页。"""
    import pymupdf

    doc = pymupdf.open(str(PDF))
    try:
        full = {i + 1: doc[i].get_text() for i in range(len(doc))}
    finally:
        doc.close()

    text, _, _, _ = P.extract_pdf_text(PDF)
    blocks = text.split("\n--- Page ")[1:]
    assert blocks, "没有解析出任何页块"
    for b in blocks:
        num, _, body = b.partition(" ---\n")
        body = body.split("\n...[Truncated]")[0]
        n = int(num)
        assert body.strip() == full[n].strip(), f"第 {n} 页被切成了半页"


def test_md_pick_does_not_cut_mid_block():
    """markdown 后端同样不许半块截断（旧实现 out[:max_chars] 会切句子）。"""
    md = "\n".join([
        "# Electrical Characteristics",
        "Resolution 12 bit " + "a" * 3000 + " END1",
        "# Thermal Information",
        "RθJA 23.9 °C/W " + "b" * 3000 + " END2",
    ])
    out, _ = P._md_pick(md, max_chars=3500)
    assert out.rstrip().endswith(("END1", "END2")), "输出在块中间被切断"
