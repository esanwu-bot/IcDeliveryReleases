# -*- coding: utf-8 -*-
"""`tools/icpdf_quarantine.py` 的单元测试。

原则：**用合成 JSON，不依赖 data/**。这样在任何机器上都能复现，
不会出现「本机能过、CI 全 skip」这种假绿。

覆盖的行为（对应 2026-11-04 顶级准入裁定）：
  1. 三分类准入各有一条：`normal` / `allowlist_board` / `quarantine`；
  2. **板卡的零电气可以豁免，核心结构错误绝对不能豁免** —— 缺键、缺厂商、
     核心硬错，一件都不许因为「是板卡」而被 allowlist 救回来（红先）；
  3. `only_board_empty_exception()` 必须真的去问闸门：抹掉身份、不改原稿、
     有核心错时连问都不问（红先 + 探针）；
  4. 板卡不借薄件通道；`thin_accepted` 归 `normal` 但打 thin 标；
  5. 允许看**主桶**电气而不是正式桶（板载器件桶很富的板卡仍要标 allowlist）；
  6. 带扣押行的板卡：结论按核心口径走，但必须被标出来（不改判、不放水）；
  7. `development_kit` 与核心 `check_core` 板卡元组不一致 → 如实隔离，记 OPEN-1；
  8. 行为：默认干跑不动文件、`--apply` 只移隔离件、台账跨运行合并、退出码；
  9. 身份三级回退（`basic_info.mpn` 为空 / 与请求号冲突时不能整件消失）。
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import tools.icpdf_quarantine as Q  # noqa: E402

ADM_N = "normal"
ADM_A = "allowlist_board"
ADM_Q = "quarantine"


# ---------------------------------------------------------------- 夹具
def doc(mpn: str = "TESTPART", **over) -> dict:
    """一份能过 validate + check_core 的最小芯片稿。"""
    d = {
        "basic_info": {"mpn": mpn, "manufacturer": "TI",
                       "datasheet_url": "https://www.ti.com/x.pdf", "identity": "chip"},
        "specs": {
            "electrical": [{"name": f"p{i}", "value": "1"} for i in range(4)],
            "thermal": [{"name": "RθJA", "value": "23.9"}],
            "esd": [{"name": "HBM", "value": "±2000"}],
        },
        "features": [{"name": "f"}],
        "applications": [],
        "pin_configuration": [{"pin": "1", "name": "VCC"}],
        "ordering_info": [],
        "alternatives": [],
        "seo": {},
        "metadata": {},
        "multi_language": {},
    }
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(d.get(k), dict):
            d[k] = {**d[k], **v}
        else:
            d[k] = v
    return d


def board_doc(mpn: str, onboard_rows: int = 0, **over) -> dict:
    """板卡稿：主桶电气为空；`onboard_rows` 控制板载器件桶行数。"""
    d = doc(mpn, **over)
    d["basic_info"]["identity"] = "evaluation_board"
    d["specs"] = {"electrical": [], "thermal": [], "esd": []}
    if onboard_rows:
        d["specs"]["onboard_device_specs"] = {
            "electrical": [{"name": f"b{i}", "value": "1"} for i in range(onboard_rows)]}
    d["pin_configuration"] = []
    return d


def stage(tmp_path: Path) -> Path:
    """每个用例一个独立装配根：默认输出目录 = 它的父目录，互不干扰。"""
    root = tmp_path / "stage"
    root.mkdir(parents=True, exist_ok=True)
    return root


def write(root: Path, name: str, d: dict, *, pdf: bool = False, seo: bool = False) -> Path:
    (root / "parsed").mkdir(parents=True, exist_ok=True)
    p = root / "parsed" / f"{name}.json"
    p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    if pdf:
        (root / "pdfs").mkdir(parents=True, exist_ok=True)
        (root / "pdfs" / f"{name}.pdf").write_bytes(b"%PDF-1.4 fake")
    if seo:
        (root / "seo").mkdir(parents=True, exist_ok=True)
        (root / "seo" / f"{name}.seo.json").write_text("{}", encoding="utf-8")
    return p


@pytest.fixture()
def env_thin():
    """薄件通道开着，才谈得上「板卡能不能借道」。"""
    old = os.environ.get("ICPDF_ACCEPT_THIN")
    os.environ["ICPDF_ACCEPT_THIN"] = "1"
    yield
    if old is None:
        os.environ.pop("ICPDF_ACCEPT_THIN", None)
    else:
        os.environ["ICPDF_ACCEPT_THIN"] = old


def scan(root: Path, read_text: bool = False) -> list[dict]:
    return Q.scan(Q.Layout.detect(root), Q._core(), read_text=read_text)


# ---------------------------------------------------------------- 三分类
def test_clean_chip_is_normal(tmp_path: Path):
    write(stage(tmp_path), "TESTPART_aaaa1111", doc())
    items = scan(stage(tmp_path))
    assert [i["admission"] for i in items] == [ADM_N]
    assert items[0]["final_gate_status"] == "ok"
    assert items[0]["mpn"] == "TESTPART"
    assert items[0]["override_reason"] == ""


def test_core_hard_error_is_quarantined(tmp_path: Path):
    """datasheet_url 空 = 溯源断链：结构过、核心硬错 → parsed_core_fail → 隔离。"""
    write(stage(tmp_path), "TESTPART_bbbb2222", doc(basic_info={"datasheet_url": ""}))
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "parsed_core_fail"
    assert rec["admission"] == ADM_Q
    assert any("datasheet_url" in e for e in rec["core_errs"])
    assert rec["validate_errors"] == []          # 结构是过的，拦它的是核心
    assert rec["reasons"]


def test_board_without_main_electrical_goes_allowlist_even_if_formal_is_rich(tmp_path: Path):
    """板卡主桶 0、板载器件桶 4 → validate 过（final_gate=ok），仍必须进 allowlist。

    这条锁的是口径：allowlist 问的是「有没有器件级电气表」（主桶），
    不是「validate 能不能过」（正式桶）。用正式桶当判据会把这件漏成普通 normal。
    """
    write(stage(tmp_path), "SOMEEVM_cccc3333", board_doc("SOMEEVM", onboard_rows=4))
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "ok", rec
    assert rec["electrical_main"] == 0
    assert rec["formal_elec"] == 4
    assert rec["admission"] == ADM_A


def test_board_zero_electrical_is_failed_never_thin(tmp_path: Path, env_thin):
    """板卡 + 零电气 + 零引脚：即便薄件开关开着、名字命中 EVM，状态机也只能判 failed。

    注意区分两件事：**状态机**判 failed（拆掉身份守卫这里会变 thin_accepted，红先），
    **准入层**按裁决给 allowlist。两者不能互相冒充：状态不许写成 ok/thin，
    准入也必须单独标列并写明理由。
    """
    write(stage(tmp_path), "BARE-EVM_dddd4444", board_doc("BARE-EVM"))
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "failed", rec
    assert rec["thin"] is False
    assert rec["admission"] == ADM_A
    assert rec["override_reason"], rec
    assert "板卡" in rec["override_reason"]


def test_board_with_core_error_is_quarantined_regardless_of_allowlist(tmp_path: Path):
    """裁决不替核心硬错背书：板卡缺 datasheet_url 照样隔离（哪怕主桶电气就是 0）。"""
    d = board_doc("BROKEN-EVM", onboard_rows=4)
    d["basic_info"]["datasheet_url"] = ""
    write(stage(tmp_path), "BROKEN-EVM_8888cccc", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "parsed_core_fail", rec
    assert rec["core_errs"]
    assert rec["admission"] == ADM_Q, rec
    assert "核心硬错" in rec["reasons"][0]


# ---------------------------------------------------------------- 铁律：结构错不得豁免
@pytest.mark.parametrize("mutate,expect", [
    (lambda d: d.pop("pin_configuration"), "missing key: pin_configuration"),
    (lambda d: d.pop("ordering_info"), "missing key: ordering_info"),
    (lambda d: d["basic_info"].update(manufacturer=""), "basic_info.manufacturer empty"),
])
def test_board_structural_error_is_quarantined_not_allowlisted(tmp_path: Path, mutate, expect):
    """**红先**：板卡主桶电气为 0，但另有结构错 → 必须 quarantine，绝不能 allowlist。

    这是 2026-11-04 裁定要堵的那个洞：`is_board and elec_main == 0` 直接给 allowlist，
    等于用「板卡」一个身份把缺键、缺厂商这类结构缺陷全部洗白。
    本用例用**板载器件桶 4 行**（validate 本来能过）的板卡，只注入一个结构错，
    因此失败原因只可能是那一条 —— 结论只能是隔离。
    """
    d = board_doc("PARTIAL-EVM", onboard_rows=4)
    mutate(d)
    write(stage(tmp_path), "PARTIAL-EVM_abcd1234", d)
    rec = scan(stage(tmp_path))[0]
    assert any(expect in e for e in rec["validate_errors"]), rec
    assert rec["final_gate_status"] == "failed", rec
    assert rec["admission"] == ADM_Q, rec
    assert rec["override_reason"] == ""            # 没走 allowlist 豁免
    assert "板卡" in rec["reasons"][0]             # 理由里说清了「是板卡但……」

    # 同一份稿，身份换回芯片 → 结论同样是隔离（说明拦它的不是身份，是结构错）
    d2 = board_doc("PARTIAL-CHIP", onboard_rows=4)
    d2["basic_info"]["identity"] = "chip"
    mutate(d2)
    write(stage(tmp_path), "PARTIAL-CHIP_abcd5678", d2)
    chip = [r for r in scan(stage(tmp_path)) if r["mpn"] == "PARTIAL-CHIP"][0]
    assert chip["admission"] == ADM_Q, chip


def test_only_board_empty_exception_really_asks_the_gate(tmp_path: Path, monkeypatch):
    """**红先**：这个函数必须真的去问 `final_gate`，而不是在工具里抄一遍前缀匹配。

    探针检查三件事：①闸门被调用；②传进去的稿子身份已被抹掉（否则板卡永远不 thin）；
    ③原稿没有被就地改动（deepcopy 才安全，否则会污染落盘对象）。
    """
    import parse_datasheets as pd

    d = board_doc("PROBE-EVM")
    seen: dict = {}
    real = pd.final_gate

    def spy(doc_, core_errs, *, thin_allowed=False):
        seen["identity"] = (doc_.get("basic_info") or {}).get("identity")
        seen["thin_allowed"] = thin_allowed
        seen["core_errs"] = list(core_errs)
        return real(doc_, core_errs, thin_allowed=thin_allowed)

    monkeypatch.setattr(pd, "final_gate", spy)
    ok, why = Q.only_board_empty_exception(pd, d, [])
    assert ok is True, why
    assert seen["identity"] is None                 # 身份被抹掉后才问
    assert seen["thin_allowed"] is True             # 按薄件口径问
    assert d["basic_info"]["identity"] == "evaluation_board"   # 原稿未被改动


def test_only_board_empty_exception_refuses_when_core_errs(tmp_path: Path, monkeypatch):
    """有核心硬错时连问都不问：核心错不在这条例外里，问也白问。"""
    import parse_datasheets as pd

    called: list = []
    monkeypatch.setattr(pd, "final_gate", lambda *a, **k: called.append(1) or ("ok", []))
    ok, why = Q.only_board_empty_exception(pd, board_doc("X-EVM"), ["基本硬错"])
    assert ok is False and "核心硬错" in why
    assert called == []


def test_board_guard_is_what_makes_the_exception_necessary(tmp_path: Path):
    """机制钉子：同一份板卡稿，**带身份**问闸门是 failed，**抹掉身份**问才是 thin_accepted。

    这就是「板卡零电气豁免」与「状态机不许判 thin」两件事的交点：
    守卫在（带身份）→ 永远拿不到 thin；例外能成立，正是因为探针抹掉了身份。
    """
    import parse_datasheets as pd

    d = board_doc("MECH-EVM")
    assert pd.final_gate(d, [], thin_allowed=True)[0] == "failed"
    assert Q.only_board_empty_exception(pd, d, [])[0] is True


def test_development_kit_is_quarantined_under_current_core_contract(tmp_path: Path):
    """OPEN-1：核心侧两套板卡值域不一致 —— 工具如实隔离，不放水。

    `qc.scope_contract.BOARD_TYPES = ("evaluation_board", "development_kit")`，
    而 `qc.deterministic_extract.check_core` 内部写的是
    `("evaluation_board", "reference_design", "module", "board")`：
    `development_kit` 在核心校验里**不被当板卡**，于是被判「引脚/电气为空」核心错。

    工具的裁定是「核心错一律隔离」，所以这类件会被拦。**这不是工具的 bug，是核心侧
    待统一项**（记 `docs/qc/tools/replay_batch100/DIFF.md` OPEN-1）。等核心侧改成
    同一份值域后，本用例应改为断言 allowlist —— 届时这条会红，红得正是地方。
    """
    d = board_doc("KIT-EVM")
    d["basic_info"]["identity"] = "development_kit"
    write(stage(tmp_path), "KIT-EVM_1234ffff", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "failed"
    assert rec["core_errs"], "核心侧若已统一值域，core_errs 会空 → 本用例需要改判"
    assert rec["admission"] == ADM_Q


def test_board_with_withheld_rows_stays_allowlist_but_is_flagged(tmp_path: Path):
    """带扣押行的板卡：结论跟核心口径走（allowlist），但必须被标出来。

    `final_gate` 的可放行类里「电气不足」与 `withheld_in_quarantine` 同档，
    所以工具不改判 —— 改判就是在工具里另写一份判据。但「主桶真空」与
    「抽到了被拦下」业务含义不同，台账要写、文本要喊，逼人交付前看一眼。
    """
    d = board_doc("WITHHELD-EVM")
    d["specs"]["unresolved_specs"] = {
        "electrical": [{"name": f"w{i}", "value": "1"} for i in range(5)]}
    write(stage(tmp_path), "WITHHELD-EVM_5678dddd", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "failed", rec
    assert rec["withheld"] == 5, rec
    assert rec["admission"] == ADM_A, rec
    assert any("扣押" in r for r in rec["reasons"]), rec["reasons"]


# ---------------------------------------------------------------- 薄件
def test_thin_chip_is_flagged_but_not_quarantined(tmp_path: Path, env_thin):
    """低规格芯片：解析时已判薄件（metadata.accept_thin）→ thin_accepted，归 normal 带标。"""
    d = doc("THINCHIP")
    d["specs"]["electrical"] = [{"name": "p0", "value": "1"}]     # 少于 3 条
    d["metadata"] = {"accept_thin": True}
    write(stage(tmp_path), "THINCHIP_eeee5555", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "thin_accepted", rec
    assert rec["admission"] == ADM_N
    assert rec["thin"] is True


def test_board_kit_name_without_pdf_text_is_not_thin(tmp_path: Path, env_thin):
    """名字像板卡套件但取不到正文时，不许走薄件（无证据不放行）。"""
    d = doc("FOO-EVAL")                        # 芯片身份 + 板卡式命名
    d["specs"]["electrical"] = [{"name": "p0", "value": "1"}]
    write(stage(tmp_path), "FOO-EVAL_ffff6666", d)   # 故意不给 PDF
    rec = scan(stage(tmp_path), read_text=True)[0]
    assert rec["final_gate_status"] == "failed", rec
    assert "取不到正文" in rec["thin_why"]
    assert rec["admission"] == ADM_Q


# ---------------------------------------------------------------- 身份
def test_mpn_falls_back_when_basic_info_mpn_is_null(tmp_path: Path):
    """basic_info.mpn 为 None 时必须回退，否则整件从台账里消失（AFE7900EVM 同款）。"""
    d = doc()
    d["basic_info"]["mpn"] = None
    d["metadata"]["requested_mpn"] = "FALLBACK-1"
    write(stage(tmp_path), "FALLBACK-1_9999aaaa", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["mpn"] == "FALLBACK-1"
    assert rec["mpn_source"] == "metadata.requested_mpn"


def test_requested_mpn_wins_over_doc_name(tmp_path: Path):
    """请求号优先：文档自称 AFE7950、请求号 AFE7950EVM → 台账用请求号，并标名冲突。"""
    d = doc()
    d["basic_info"]["mpn"] = "AFE7950"
    d["metadata"]["requested_mpn"] = "AFE7950EVM"
    write(stage(tmp_path), "AFE7950EVM_aaaa1111", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["mpn"] == "AFE7950EVM"
    assert rec["doc_mpn"] == "AFE7950"
    assert rec["name_conflict"] is True
    assert rec["mpn_source"] == "metadata.requested_mpn"


def test_unresolvable_mpn_is_quarantined(tmp_path: Path):
    d = doc()
    d["basic_info"]["mpn"] = ""
    write(stage(tmp_path), "_1234abcd", d)     # 文件名词干为空
    rec = scan(stage(tmp_path))[0]
    assert rec["mpn"] == ""
    assert rec["admission"] == ADM_Q


def test_stamp_conflict_is_reported(tmp_path: Path):
    """JSON 章写 ok，现场复判 parsed_core_fail → 以现场为准，并标冲突。"""
    d = doc(basic_info={"datasheet_url": ""})
    d["metadata"] = {"accept_status": "ok"}
    write(stage(tmp_path), "CONFLICT_7777bbbb", d)
    rec = scan(stage(tmp_path))[0]
    assert rec["final_gate_status"] == "parsed_core_fail"
    assert rec["accept_status"] == "ok"
    assert rec["stamp_conflict"] is True
    assert rec["admission"] == ADM_Q


def test_thermal_absent_in_source_is_not_a_core_error(tmp_path: Path):
    """源 PDF 通篇没有 thermal/ESD 表时，装配口径判 not_applicable —— 不能误报 hard error。

    这是 `qc/stage_release.py::_revalidate` 的口径，本工具只是把证据找出来喂给
    `check_core()`。batch100 的 ADS1252U 就是这形态：严格口径判 parsed_core_fail，
    装配口径判 pass，交付包里它是对的。
    """
    pymupdf = pytest.importorskip("pymupdf")
    pdf = tmp_path / "src.pdf"
    with pymupdf.open() as fd:
        page = fd.new_page()
        page.insert_text((72, 72), "GENERAL DESCRIPTION\nNo thermal or ESD table here.")
        fd.save(str(pdf))

    d = doc("NOSPEC")
    d["specs"].pop("thermal")
    d["specs"].pop("esd")
    root = stage(tmp_path)
    write(root, "NOSPEC_1234abcd", d)
    (root / "pdfs").mkdir(parents=True, exist_ok=True)
    (root / "pdfs" / "NOSPEC_1234abcd.pdf").write_bytes(pdf.read_bytes())

    hit = scan(root, read_text=True)[0]        # 带 PDF：源无表 → 不判失败
    assert hit["final_gate_status"] == "ok", hit
    assert hit["core_basis"].startswith("assembly")
    assert hit["admission"] == ADM_N

    strict = scan(root, read_text=False)[0]    # 不带 PDF：严格口径 → 报 hard error
    assert strict["final_gate_status"] == "parsed_core_fail"
    assert strict["core_basis"].startswith("strict")
    assert strict["admission"] == ADM_Q


# ---------------------------------------------------------------- 行为（文件与台账）
def test_dry_run_touches_nothing(tmp_path: Path):
    root = stage(tmp_path)
    write(root, "BAD_0000aaaa", doc(basic_info={"datasheet_url": ""}), pdf=True, seo=True)
    before = sorted(p.name for p in (root / "parsed").iterdir())
    assert Q.main(["--src", str(root)]) == 1          # 有隔离件
    assert sorted(p.name for p in (root / "parsed").iterdir()) == before
    assert (tmp_path / "_quarantine" / "quarantine_ledger.json").is_file()


def test_apply_moves_only_quarantined(tmp_path: Path):
    root = stage(tmp_path)
    write(root, "BAD_0000aaaa", doc(basic_info={"datasheet_url": ""}), pdf=True, seo=True)
    write(root, "GOOD_1111bbbb", doc("GOOD"), pdf=True)
    out = tmp_path / "_quarantine"
    assert Q.main(["--src", str(root), "--apply"]) == 1
    assert sorted(p.name for p in (root / "parsed").iterdir()) == ["GOOD_1111bbbb.json"]
    assert (out / "parsed" / "BAD_0000aaaa.json").is_file()
    assert (out / "pdfs" / "BAD_0000aaaa.pdf").is_file()
    assert (out / "seo" / "BAD_0000aaaa.seo.json").is_file()
    assert not (out / "parsed" / "GOOD_1111bbbb.json").exists()


def test_ledger_survives_second_run(tmp_path: Path):
    """第二次运行（件已被移走）不能把隔离台账洗成空。"""
    root = stage(tmp_path)
    write(root, "BAD_0000aaaa", doc(basic_info={"datasheet_url": ""}))
    out = tmp_path / "_quarantine"
    assert Q.main(["--src", str(root), "--apply"]) == 1
    led1 = json.loads((out / "quarantine_ledger.json").read_text(encoding="utf-8"))
    assert len(led1["items"]) == 1
    assert Q.main(["--src", str(root), "--apply", "--allow-quarantine"]) == 0
    led2 = json.loads((out / "quarantine_ledger.json").read_text(encoding="utf-8"))
    assert len(led2["items"]) == 1, led2["items"]
    assert len(led2["runs"]) == 2
    assert led2["counts"][ADM_Q] == 1


def test_ledger_is_deterministic(tmp_path: Path):
    root = stage(tmp_path)
    for name in ("B_0000aaaa", "A_1111bbbb"):
        write(root, name, doc(name.split("_")[0], basic_info={"datasheet_url": ""}))
    Q.main(["--src", str(root), "--out", str(tmp_path / "o1")])
    Q.main(["--src", str(root), "--out", str(tmp_path / "o2")])
    a = json.loads((tmp_path / "o1" / "quarantine_ledger.json").read_text(encoding="utf-8"))
    b = json.loads((tmp_path / "o2" / "quarantine_ledger.json").read_text(encoding="utf-8"))
    assert [x["mpn"] for x in a["items"]] == [x["mpn"] for x in b["items"]] == ["A", "B"]


def test_allowlist_csv_written(tmp_path: Path):
    root = stage(tmp_path)
    write(root, "SOMEEVM_cccc3333", board_doc("SOMEEVM", onboard_rows=4))
    assert Q.main(["--src", str(root), "--allow-quarantine"]) == 0
    rows = (tmp_path / "_quarantine" / "allowlist.csv").read_text(encoding="utf-8").strip().splitlines()
    assert rows[0].startswith("mpn,identity,identity_source,elec_main")
    assert len(rows) == 2 and "SOMEEVM" in rows[1]


def test_ledger_csv_carries_the_reviewer_fields(tmp_path: Path):
    """裁定点名的字段必须一个不少地出现在台账 CSV 表头里（机器消费靠它）。"""
    root = stage(tmp_path)
    write(root, "SOMEEVM_cccc3333", board_doc("SOMEEVM", onboard_rows=4))
    write(root, "BAD_0000aaaa", doc(basic_info={"datasheet_url": ""}))
    Q.main(["--src", str(root), "--allow-quarantine"])
    head = (tmp_path / "_quarantine" / "quarantine.csv").read_text(
        encoding="utf-8").splitlines()[0].split(",")
    for col in ("mpn", "identity", "identity_source", "formal_elec", "pins",
                "validate_errors", "core_errs", "accept_status", "final_gate_status",
                "admission", "override_reason", "source_pdf_hash", "stamp_conflict"):
        assert col in head, f"台账缺列 {col}"


def test_json_mode_stdout_is_pure_json(tmp_path: Path, capsys):
    write(stage(tmp_path), "GOOD_1111bbbb", doc("GOOD"))
    assert Q.main(["--src", str(stage(tmp_path)), "--json",
                   "--out", str(tmp_path / "q")]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["counts"][ADM_N] == 1
    assert payload["quarantine"] == []


def test_out_equal_src_is_rejected(tmp_path: Path):
    root = stage(tmp_path)
    write(root, "GOOD_1111bbbb", doc("GOOD"))
    assert Q.main(["--src", str(root), "--out", str(root), "--apply"]) == 2
