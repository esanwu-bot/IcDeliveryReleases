#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.2 阶段契约与五段链路的验收用例。

对应用户冻结的验收清单（编号沿用裁决书），逐条落地：

    P1-01  新旧路径抽出来的文本逐字节相同
    P1-02  最终 LLM Prompt 的 SHA256 相同（含 pages_used / pages_total / system prompt）
    P1-03  `is_datasheet` 判定逐件一致
    P1-06  切片可追溯（切片哈希 == PDF 哈希 == JSON 里的 pdf_hash）
    P1-07  失败重试不重复下载 / 不重复抽取
    P1-08  重复投递不重复调 LLM
    P1-12  Shadow Comparison：只比结果，新链路不接管正式状态

**为什么这里坚持读真实 PDF**：本模块防的是「拆成两段之后，文本悄悄变了」。
用 mock 喂字符串测等于把要防的风险重新假设掉了 —— 真 PDF 才可能暴露
`select_pages()` 的页预算、`MAX_PAGES_OVERRIDE` 白名单、OPENDATALOADER 分支
这些只在真文件上才走到的路径。

标尺样本（覆盖五种形态）：
    LM317__lm317.pdf                 —— 三端稳压，短手册，160 页以内常规预算
    ADS1675REF__ads1675.pdf          —— 评估板（BOARD_PROFILE），batch20 用件
    ADS8568EVM-PDK__sbas543c.pdf     —— 板卡，AC 空表 + 事实表结论的样本
    ADS1201U-1_1K__ads1201.pdf       —— V11 修过 range 回退的型号
    1A1G04QDBVRG4Q1__sn74ahc1g04-q1.pdf  —— 小型逻辑门，几页的手册
"""
from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.pipeline import contracts as C                      # noqa: E402
from app.pipeline import preprocess as PP                    # noqa: E402
from app.pipeline import slice_store as SS                   # noqa: E402
from app.pipeline import stages as S                         # noqa: E402
from app.pipeline.stage_state import StageStateStore         # noqa: E402

PDF_DIR = ROOT / "data" / "pdfs"

SAMPLES = [
    ("LM317", "LM317__lm317.pdf"),
    ("ADS1675REF", "ADS1675REF__ads1675.pdf"),
    ("ADS8568EVM-PDK", "ADS8568EVM-PDK__sbas543c.pdf"),
    ("ADS1201U-1_1K", "ADS1201U-1_1K__ads1201.pdf"),
    ("1A1G04QDBVRG4Q1", "1A1G04QDBVRG4Q1__sn74ahc1g04-q1.pdf"),
]


def _pdf(name: str) -> Path:
    p = PDF_DIR / name
    if not p.exists():
        pytest.skip(f"样本缺失: {p}")
    return p


@pytest.fixture(scope="module")
def pd():
    import parse_datasheets as m
    return m


@pytest.fixture(scope="module")
def extracted(pd):
    """每份样本只抽一次（抽取是本文件里最贵的一步），跨用例复用。"""
    cache: dict[str, tuple] = {}

    def get(mpn: str, fname: str) -> tuple[str, int, int, bool]:
        if mpn not in cache:
            cache[mpn] = pd.extract_pdf_text(_pdf(fname))
        return cache[mpn]

    return get


# ====================================================================== P1-01

@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES, ids=[s[0] for s in SAMPLES])
def test_p1_01_slice_text_is_byte_identical(pd, extracted, mpn, fname):
    """P1-01：切片文本与老路径 `extract_pdf_text()` 的返回逐字节相同。

    这是整条改造的地基。文本只要差一个字符，后面 prompt 指纹、模型输出、
    † 标记判据全部跟着漂，而且漂得很隐蔽（页面看起来还是对的）。
    """
    pdf = _pdf(fname)
    old_text, old_total, old_used, old_has = extracted(mpn, fname)
    slc = PP.build_slice(pdf, mpn, pd_module=pd)

    assert slc.text == old_text, "切片文本与老路径不一致（逐字节）"
    assert C.sha256_text(slc.text) == C.sha256_text(old_text)
    assert len(slc.text) == len(old_text)
    assert (slc.pages_used, slc.pages_total) == (old_used, old_total)
    assert slc.has_text == old_has


@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES, ids=[s[0] for s in SAMPLES])
def test_p1_01_extractor_called_without_kwargs(pd, extracted, mpn, fname, monkeypatch):
    """P1-01 的加固：抽取必须**无参数**调用。

    传 `max_pages=16` 看起来等价，实际会绕过 `select_pages()` 里
    `max_pages == MAX_PAGES` 才触发的自适应预算（百页级手册自动放宽到 32 页）。
    这类差异在短文上完全看不出来，只在长手册上悄悄少两页。
    """
    seen: list[tuple] = []
    real = pd.extract_pdf_text

    def spy(path, *args, **kwargs):
        seen.append((args, kwargs))
        return real(path, *args, **kwargs)

    monkeypatch.setattr(pd, "extract_pdf_text", spy)
    PP.build_slice(_pdf(fname), mpn, pd_module=pd)

    assert seen, "没有调用抽取器"
    for args, kwargs in seen:
        assert args == () and kwargs == {}, f"抽取器被传了参数: args={args} kwargs={kwargs}"


# ====================================================================== P1-02

@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES, ids=[s[0] for s in SAMPLES])
def test_p1_02_prompt_messages_and_sha_match(pd, extracted, mpn, fname):
    """P1-02：整条 messages（含 system prompt 与页数）与老路径逐字符相同。

    刻意在这里**独立复刻**一遍 `pipeline.parse_pdf()` 的拼装（而不是调它），
    因为这段代码就是要被替换的那段 —— 用被测代码产基准，等于自己证明自己。
    """
    pdf = _pdf(fname)
    old_text, old_total, old_used, _ = extracted(mpn, fname)
    old_msgs = [
        {"role": "system", "content": pd.SYSTEM_PROMPT},
        {"role": "user", "content": pd.USER_TMPL.format(
            mpn=mpn, fname=pdf.name, pages_used=old_used,
            pages_total=old_total, text=old_text)},
    ]

    slc = PP.build_slice(pdf, mpn, pd_module=pd)
    new_msgs = C.prompt_messages(mpn=mpn, pdf_name=slc.pdf_name,
                                 pages_used=slc.pages_used, pages_total=slc.pages_total,
                                 text=slc.text, pd_module=pd)

    assert new_msgs == old_msgs, "messages 不一致（system prompt / 页数 / 正文）"
    assert C.prompt_sha256(new_msgs) == C.prompt_sha256(old_msgs)
    # prompt 里必须真有页数，否则「页数一致」这条验收就是空的
    assert f"{old_used}/{old_total}" in new_msgs[1]["content"]


def test_p1_02_sha_covers_pages_not_only_text(pd):
    """P1-02 的加固：指纹必须覆盖页数，不能只哈希正文。

    只哈希 `text` 时，「页预算改了但选中的文本碰巧一样」这种改动会被判成
    无变化 —— 而它恰恰是 `select_pages()` 改版最常见的表现。
    """
    base = dict(mpn="X", pdf_name="x.pdf", text="hello", pd_module=pd)
    a = C.prompt_messages(pages_used=3, pages_total=100, **base)
    b = C.prompt_messages(pages_used=3, pages_total=99, **base)
    c = C.prompt_messages(pages_used=4, pages_total=100, **base)

    assert C.prompt_sha256(a) != C.prompt_sha256(b)
    assert C.prompt_sha256(a) != C.prompt_sha256(c)
    # 正文相同、页数相同 → 必须同一个指纹（否则缓存永远不命中）
    assert C.prompt_sha256(a) == C.prompt_sha256(C.prompt_messages(pages_used=3, pages_total=100, **base))


def test_p1_02_prompt_sha_is_order_insensitive_to_key_order(pd):
    """指纹按排序后的键序列化，不受 dict 插入顺序影响。"""
    a = C.prompt_messages(mpn="X", pdf_name="p.pdf", pages_used=1, pages_total=2,
                          text="t", pd_module=pd)
    b = [{"content": a[0]["content"], "role": a[0]["role"]},
         {"content": a[1]["content"], "role": a[1]["role"]}]
    assert C.prompt_sha256(a) == C.prompt_sha256(b)


# ====================================================================== P1-03

@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES, ids=[s[0] for s in SAMPLES])
def test_p1_03_is_datasheet_matches(pd, extracted, mpn, fname):
    """P1-03：datasheet 判定与老路径逐件一致（不能抄一份 DS_MARKERS）。"""
    text, *_ = extracted(mpn, fname)
    slc = PP.build_slice(_pdf(fname), mpn, pd_module=pd)
    assert slc.is_datasheet == bool(pd.is_datasheet(text))


@pytest.mark.parametrize("text,expect", [
    ("ELECTRICAL CHARACTERISTICS VDD = 5V", True),
    ("Absolute Maximum Ratings over operating free-air temperature", True),
    ("Recommended Operating Conditions table", True),
    ("This Quick Start Guide shows how to plug in the board", False),
    ("", False),
])
def test_p1_03_is_datasheet_delegates_to_pd(pd, text, expect):
    """小样本快测：判定逻辑必须原样来自 `parse_datasheets.is_datasheet`。"""
    assert bool(pd.is_datasheet(text)) is expect


# ====================================================================== P1-06

@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES, ids=[s[0] for s in SAMPLES])
def test_p1_06_slice_traceability(pd, mpn, fname):
    """P1-06：切片可追溯 —— 哈希三方对齐，路径与文件名可反查。"""
    pdf = _pdf(fname)
    slc = PP.build_slice(pdf, mpn, pd_module=pd)

    assert slc.pdf_sha256 == pd.sha256(pdf) == C.sha256_file(pdf)
    assert slc.pdf_path == str(pdf)
    assert slc.pdf_name == pdf.name
    assert slc.extractor_version == C.EXTRACTOR_VERSION
    assert slc.schema_version == C.SLICE_SCHEMA_VERSION
    assert slc.created_at, "切片必须带创建时间，否则无法与发布批次对时"
    assert slc.text_sha256 == C.sha256_text(slc.text)
    # selected_pages 按约束只占位，不假装有页码
    assert slc.selected_pages == []


def test_p1_06_slice_path_naming():
    p = SS.slice_path("LM317", "abc123def456")
    assert p.name == "LM317_abc123de.json"
    assert "LM317" in p.name


# ====================================================================== 切片仓库

def test_slice_roundtrip(tmp_path):
    slc = C.Slice(mpn="LM317", pdf_sha256="a" * 64, pdf_path="/x/LM317__lm317.pdf",
                  text="hello 世界", pages_used=3, pages_total=200,
                  created_at="2026-11-03T10:00:00+08:00")
    path = SS.write_slice(slc, root=tmp_path)
    assert path.exists()

    back = SS.read_slice(path)
    assert back == slc
    assert back.pdf_name == "LM317__lm317.pdf"
    assert back.text_sha256 == C.sha256_text("hello 世界")


def test_slice_write_is_idempotent(tmp_path):
    slc = C.Slice(mpn="A", pdf_sha256="b" * 64, pdf_path="/p/A.pdf", text="t",
                  created_at="2026-11-03T10:00:00+08:00")
    p1 = SS.write_slice(slc, root=tmp_path)
    m1 = p1.stat().st_mtime_ns
    p2 = SS.write_slice(slc, root=tmp_path)
    assert p1 == p2
    assert p2.stat().st_mtime_ns == m1, "逐字节相同的内容不应重写文件"


def test_corrupt_slice_is_not_deleted(tmp_path):
    """读坏返回 None，文件必须原地留着 —— 那是唯一的现场。"""
    p = tmp_path / "BAD_deadbeef.json"
    p.write_text("{ this is not json", encoding="utf-8")

    assert SS.read_slice(p) is None
    assert p.exists(), "损坏的切片被删了，现场丢失"
    assert p.read_text(encoding="utf-8").startswith("{ this is not json")


def test_slice_backup_on_version_change(tmp_path):
    """换版重写时旧文件改名留档，不静默覆盖。"""
    old = C.Slice(mpn="A", pdf_sha256="c" * 64, pdf_path="/p/A.pdf", text="v1",
                  extractor_version="extract_pdf_text/v0", created_at="2026-11-01T00:00:00+08:00")
    SS.write_slice(old, root=tmp_path)

    new = C.Slice(mpn="A", pdf_sha256="c" * 64, pdf_path="/p/A.pdf", text="v2",
                  created_at="2026-11-03T00:00:00+08:00")
    p = SS.write_slice(new, root=tmp_path)

    baks = list(tmp_path.glob("*.bak"))
    assert len(baks) == 1, f"未留档旧切片: {list(tmp_path.iterdir())}"
    assert "v0" in baks[0].name
    assert json.loads(baks[0].read_text(encoding="utf-8"))["text"] == "v1"
    assert SS.read_slice(p).text == "v2"


def test_slice_from_dict_rejects_missing_and_bad_version():
    with pytest.raises(ValueError, match="缺字段"):
        C.Slice.from_dict({"schema_version": 1, "mpn": "A"})
    full = C.Slice(mpn="A", pdf_sha256="d" * 64, pdf_path="/p/A.pdf", text="t").to_dict()
    with pytest.raises(ValueError, match="schema_version"):
        C.Slice.from_dict({**full, "schema_version": 99})


# ====================================================================== P1-07

class FakePd:
    """只实现 preprocess 用到的三个符号，用来数「抽了几次」。"""

    def __init__(self, text: str = "ELECTRICAL CHARACTERISTICS"):
        self.text = text
        self.extract_calls = 0
        self.sha_calls = 0

    def extract_pdf_text(self, path, *a, **kw):
        self.extract_calls += 1
        return self.text, 120, 16, bool(self.text.strip())

    def is_datasheet(self, text):
        return "electrical characteristics" in text.lower()

    def sha256(self, path):
        self.sha_calls += 1
        return "e" * 64


@pytest.mark.slow
def test_p1_07_retry_does_not_reextract(tmp_path):
    """P1-07：同一份 PDF 重跑，落盘切片被复用，不再读 PDF。"""
    pdf = _pdf("LM317__lm317.pdf")
    fake = FakePd()

    slc1, reused1 = PP.load_or_build(pdf, "LM317", root=tmp_path, pd_module=fake)
    assert reused1 is False
    assert fake.extract_calls == 1

    slc2, reused2 = PP.load_or_build(pdf, "LM317", root=tmp_path, pd_module=fake)
    assert reused2 is True, "第二次仍重新抽了文本"
    assert fake.extract_calls == 1, f"抽取被调用了 {fake.extract_calls} 次"
    assert slc2.text == slc1.text

    # force=True 是人工重跑的口子，必须真的重抽
    _, reused3 = PP.load_or_build(pdf, "LM317", root=tmp_path, pd_module=fake, force=True)
    assert reused3 is False
    assert fake.extract_calls == 2


@pytest.mark.slow
def test_p1_07_slice_invalidated_when_extractor_version_changes(tmp_path, monkeypatch):
    """抽取器换版 → 旧切片必须作废，不能把一次代码升级伪装成缓存命中。"""
    pdf = _pdf("LM317__lm317.pdf")
    fake = FakePd()
    PP.load_or_build(pdf, "LM317", root=tmp_path, pd_module=fake)
    assert fake.extract_calls == 1

    monkeypatch.setattr(C, "EXTRACTOR_VERSION", "extract_pdf_text/v2")
    _, reused = PP.load_or_build(pdf, "LM317", root=tmp_path, pd_module=fake)
    assert reused is False, "换版后仍命中了旧切片"
    assert fake.extract_calls == 2


@pytest.mark.slow
def test_p1_07_preprocess_stage_cached(tmp_path):
    """P1-07 在 stage 层的表现：第二次调用返回 cached，仍然只抽一次。"""
    pdf = _pdf("LM317__lm317.pdf")
    fake = FakePd()
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="LM317", mpn_key="lm317", pdf_path=pdf,
                    slice_root=tmp_path / "slices", state=st)

        r1 = S.stage_preprocess(ctx, pd_module=fake)
        assert r1.status == C.STATUS_OK
        assert fake.extract_calls == 1

        r2 = S.stage_preprocess(ctx, pd_module=fake)
        assert r2.status == C.STATUS_CACHED
        assert fake.extract_calls == 1, "缓存命中却又抽了一次"


def test_p1_07_preprocess_blocks_on_missing_pdf(tmp_path):
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="X", pdf_path=None, state=st, slice_root=tmp_path)
        r = S.stage_preprocess(ctx, pd_module=FakePd())
        assert r.status == C.STATUS_BLOCKED
        assert "PDF" in r.error


def test_p1_07_unreadable_pdf_is_blocked_not_failed(tmp_path):
    """无文本层 = 需要 OCR 这件外部干预，不是「下次可能成功」。

    记 failed 会让重试策略反复把它捡起来空转，日志里堆一堆假失败。
    """
    pdf = tmp_path / "blank.pdf"
    pdf.write_bytes(b"%PDF-1.4\n%%EOF\n")
    fake = FakePd(text="")
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="BLANK", pdf_path=pdf, slice_root=tmp_path / "s", state=st)
        r = S.stage_preprocess(ctx, pd_module=fake)
    assert r.status == C.STATUS_BLOCKED
    assert "PDF_UNREADABLE" in r.error
    assert r.detail.get("has_text") is False


def test_p1_07_user_guide_is_skipped_and_stops_chain(tmp_path):
    """不是 datasheet → skipped，链路立即停（下游不该再烧 LLM）。"""
    pdf = tmp_path / "ug.pdf"
    pdf.write_bytes(b"%PDF-1.4\n%%EOF\n")
    fake = FakePd(text="Quick start guide. Plug the board in.")
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="UG", mpn_key="ug", pdf_path=pdf,
                    slice_root=tmp_path / "s", state=st)
        r = S.stage_preprocess(ctx, pd_module=fake)
        assert r.status == C.STATUS_SKIPPED
        assert "NOT_A_DATASHEET" in r.error
        assert S.stage_llm(ctx, pd_module=fake).status == C.STATUS_SKIPPED


# ====================================================================== P1-08

def _fake_llm(counter: dict, out_dir_holder: dict):
    def fn(pdf, mpn, url, *, text=None, pages_used=None, pages_total=None, out_dir=None):
        counter["calls"] = counter.get("calls", 0) + 1
        out_dir_holder["text"] = text
        out_dir_holder["pages"] = (pages_used, pages_total)
        out_dir_holder["out_dir"] = out_dir
        target = Path(out_dir or ROOT / "data" / "parsed") / f"{mpn}_fake0000.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps({
            "basic_info": {"mpn": mpn}, "specs": {"electrical": [{"a": 1}]},
            "pin_configuration": [], "features": [], "ordering_info": [],
            "alternatives": [], "metadata": {"pdf_hash": "e" * 64},
        }), encoding="utf-8")
        return {"status": "ok", "json_path": str(target), "doc": None, "ms": 5,
                "confidence": 0.9, "electrical": 1, "pins": 0, "llm_calls": [{}], "error": ""}
    return fn


@pytest.mark.slow
def test_p1_08_duplicate_submit_does_not_call_llm_twice(tmp_path, pd):
    """P1-08：同一件重复投递，第二次命中缓存，模型只调一次。"""
    pdf = _pdf("LM317__lm317.pdf")
    slc, _ = PP.load_or_build(pdf, "LM317", root=tmp_path / "slices", pd_module=pd)
    counter, holder = {}, {}
    fn = _fake_llm(counter, holder)

    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="LM317", mpn_key="lm317", pdf_path=pdf, pdf_sha256=slc.pdf_sha256,
                    slice=slc, out_dir=tmp_path / "out", state=st)

        r1 = S.stage_llm(ctx, llm_fn=fn, pd_module=pd)
        assert r1.status == C.STATUS_OK
        assert counter["calls"] == 1
        # 接缝正确性：模型拿到的是切片里的文本，不是重新抽的
        assert holder["text"] == slc.text
        assert holder["pages"] == (slc.pages_used, slc.pages_total)

        r2 = S.stage_llm(ctx, llm_fn=fn, pd_module=pd)
        assert r2.status == C.STATUS_CACHED
        assert counter["calls"] == 1, f"重复投递又调了模型（{counter['calls']} 次）"
        assert r2.artifact == r1.artifact


@pytest.mark.slow
def test_p1_08_changed_prompt_invalidates_cache(tmp_path, pd):
    """换了页数（= 换了 prompt）必须换键，不能复用旧结果。"""
    pdf = _pdf("LM317__lm317.pdf")
    slc, _ = PP.load_or_build(pdf, "LM317", root=tmp_path / "slices", pd_module=pd)
    counter, holder = {}, {}
    fn = _fake_llm(counter, holder)

    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="LM317", pdf_path=pdf, pdf_sha256=slc.pdf_sha256,
                    slice=slc, out_dir=tmp_path / "out", state=st)
        S.stage_llm(ctx, llm_fn=fn, pd_module=pd)

        bumped = C.Slice(**{**slc.to_dict(), "pages_used": slc.pages_used + 1})
        ctx.slice = bumped
        r = S.stage_llm(ctx, llm_fn=fn, pd_module=pd)
    assert r.status == C.STATUS_OK
    assert counter["calls"] == 2, "prompt 变了却复用了旧结果"


def test_p1_08_llm_blocks_without_slice(tmp_path):
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="X", state=st)
        r = S.stage_llm(ctx, llm_fn=lambda *a, **k: {})
    assert r.status == C.STATUS_BLOCKED
    assert "切片" in r.error


# ====================================================================== 阶段状态

def test_stage_state_lifecycle(tmp_path):
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        key = C.idem_key("f" * 64, C.STAGE_PREPROCESS)
        assert st.get(key) is None
        assert st.cached(key) is None

        st.begin(idem_key=key, stage=C.STAGE_PREPROCESS, mpn="A", mpn_key="a")
        row = st.get(key)
        assert row["status"] == C.STATUS_RUNNING and row["attempts"] == 1

        st.finish(key, status=C.STATUS_OK, artifact="", detail={"chars": 10}, ms=7)
        row = st.get(key)
        assert row["status"] == C.STATUS_OK
        assert row["detail"] == {"chars": 10}
        assert row["ms"] == 7
        assert st.cached(key) is not None


def test_stage_state_failed_is_retryable(tmp_path):
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        key = C.idem_key("f" * 64, C.STAGE_LLM)
        st.begin(idem_key=key, stage=C.STAGE_LLM)
        st.finish(key, status=C.STATUS_FAILED, error="boom")
        assert st.cached(key) is None, "失败态不该被当成缓存"

        st.begin(idem_key=key, stage=C.STAGE_LLM)
        assert st.get(key)["attempts"] == 2, "重试次数必须累加"
        assert st.get(key)["error"] == "", "重试开始时应清掉上一次的错误"


def test_stage_state_cache_requires_artifact_on_disk(tmp_path):
    """记录说成功、文件被删了 —— 这是最容易骗过缓存的情形。"""
    art = tmp_path / "x.json"
    art.write_text("{}", encoding="utf-8")
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        key = C.idem_key("f" * 64, C.STAGE_LLM)
        st.begin(idem_key=key, stage=C.STAGE_LLM)
        st.finish(key, status=C.STATUS_OK, artifact=str(art))
        assert st.cached(key) is not None

        art.unlink()
        assert st.cached(key) is None, "产物没了仍报命中"


def test_stage_state_key_uniqueness(tmp_path):
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        k = C.idem_key("a" * 64, C.STAGE_PREPROCESS)
        st.begin(idem_key=k, stage=C.STAGE_PREPROCESS)
        st.finish(k, status=C.STATUS_OK)
        st.begin(idem_key=k, stage=C.STAGE_PREPROCESS)      # 同键再 begin 不能插第二行
        assert len(st.of_mpn("")) == 1


def test_stage_state_does_not_touch_workbench_ddl(tmp_path):
    """阶段表是自带 schema 的独立表，不能让 `app/db.py` 的 DDL 跟着变。"""
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        tables = {r["name"] for r in
                  st._conn().execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "pipeline_stage" in tables
    assert "item" not in tables, "阶段库串到了工作台库，隔离失效"


# ====================================================================== 幂等键

def test_idem_key_shape():
    assert C.idem_key("a" * 64, C.STAGE_PREPROCESS) == f"{'a'*64}:preprocess:1"
    assert C.idem_key("", C.STAGE_FETCH) == "-:fetch:1"
    assert C.idem_key("a" * 64, C.STAGE_PREPROCESS, extra=("x", "")) == f"{'a'*64}:preprocess:1:x"


def test_llm_idem_key_varies_with_every_component():
    base = C.llm_idem_key("a" * 64, "p" * 64, "m1", "c" * 64)
    assert base != C.llm_idem_key("b" * 64, "p" * 64, "m1", "c" * 64)   # PDF 变
    assert base != C.llm_idem_key("a" * 64, "q" * 64, "m1", "c" * 64)   # prompt 变
    assert base != C.llm_idem_key("a" * 64, "p" * 64, "m2", "c" * 64)   # 模型变
    assert base != C.llm_idem_key("a" * 64, "p" * 64, "m1", "d" * 64)   # 配置变
    assert base.count(":") == 5


def test_v2_switch_defaults_off():
    assert C.v2_enabled({}) is False
    assert C.v2_enabled({"ICPDF_PIPELINE_V2": "0"}) is False
    assert C.v2_enabled({"ICPDF_PIPELINE_V2": "1"}) is True
    assert C.v2_enabled({"ICPDF_PIPELINE_V2": " true "}) is True


# ====================================================================== 链路编排

def test_run_chain_stops_on_skipped(tmp_path, monkeypatch):
    calls: list[str] = []

    def mk(name: str, status: str):
        def _f(ctx, **_kw):
            calls.append(name)
            return C.StageResult(stage=name, status=status)
        return _f

    for name, status in ((C.STAGE_FETCH, C.STATUS_OK),
                         (C.STAGE_PREPROCESS, C.STATUS_SKIPPED),
                         (C.STAGE_LLM, C.STATUS_OK)):
        monkeypatch.setitem(S.STAGE_FUNCS, name, mk(name, status))

    ctx = S.Ctx(mpn="X")
    out = S.run_chain(ctx)
    assert [r.stage for r in out] == [C.STAGE_FETCH, C.STAGE_PREPROCESS]
    assert calls == [C.STAGE_FETCH, C.STAGE_PREPROCESS], "跳过后仍继续跑下游"
    assert [r.stage for r in ctx.trace] == [C.STAGE_FETCH, C.STAGE_PREPROCESS]


def test_run_chain_full_path(tmp_path, monkeypatch):
    def ok(name):
        def _f(ctx, **_kw):
            return C.StageResult(stage=name, status=C.STATUS_OK)
        return _f

    for name in C.STAGE_ORDER:
        monkeypatch.setitem(S.STAGE_FUNCS, name, ok(name))

    out = S.run_chain(S.Ctx(mpn="X"))
    assert [r.stage for r in out] == list(C.STAGE_ORDER)


def test_run_chain_filters_kwargs_per_stage(tmp_path, monkeypatch):
    """注入参数按各阶段形参过滤。

    五个阶段的注入点不同（`fetch_fn` / `llm_fn` / `audit_fn` / `finish_fn` /
    `pd_module`），无脑全传会让只接 `audit_fn` 的 `stage_audit` 直接 TypeError，
    而报错看起来像「审计阶段有 bug」—— 生产上这种错最难查，因为调用点看着很无辜。
    """
    got: dict[str, set[str]] = {}

    def mk(name):
        def _f(ctx, **kw):
            got[name] = set(kw)
            return C.StageResult(stage=name, status=C.STATUS_OK)
        return _f

    def no_kw(ctx):
        return C.StageResult(stage=C.STAGE_AUDIT, status=C.STATUS_OK)

    for name in C.STAGE_ORDER:
        monkeypatch.setitem(S.STAGE_FUNCS, name, mk(name))
    monkeypatch.setitem(S.STAGE_FUNCS, C.STAGE_AUDIT, no_kw)

    out = S.run_chain(S.Ctx(mpn="X"), pd_module=object())
    assert len(out) == len(C.STAGE_ORDER)
    # 收 **kw 的阶段拿到全部注入项；只收 ctx 的阶段被过滤成零参数
    assert got[C.STAGE_FETCH] == {"pd_module"}


def test_stage_exception_becomes_failed_result(tmp_path):
    """阶段内部炸了要变成 FAILED 记录，不能把异常穿出去留僵尸行。"""
    pdf = tmp_path / "a.pdf"
    pdf.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class Boom(FakePd):
        def extract_pdf_text(self, path, *a, **kw):
            raise RuntimeError("抽取器炸了")

    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="A", mpn_key="a", pdf_path=pdf, slice_root=tmp_path / "s", state=st)
        r = S.stage_preprocess(ctx, pd_module=Boom())
        assert r.status == C.STATUS_FAILED
        assert "RuntimeError" in r.error
        assert st.get(r.idem_key)["status"] == C.STATUS_FAILED


# ====================================================================== AUDIT

def test_audit_never_writes(tmp_path):
    """AUDIT 只取证。`write=True` 永远不能在链路里触发。"""
    pdf = tmp_path / "a.pdf"
    pdf.write_bytes(b"%PDF-1.4\n%%EOF\n")
    js = tmp_path / "a.json"
    js.write_text(json.dumps({"specs": {}, "metadata": {}}), encoding="utf-8")
    seen: dict = {}

    def fake_audit(doc, pdf_path, **kw):
        seen.update(kw)
        return {"findings": [{"kind": "x"}, {"kind": "x"}, {"kind": "y"}]}

    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="A", pdf_path=pdf, json_path=str(js), state=st)
        r = S.stage_audit(ctx, audit_fn=fake_audit)

    assert r.status == C.STATUS_OK
    assert seen.get("write") is False, "审计阶段试图写回 JSON"
    assert r.detail["findings"] == 3
    assert r.detail["by_kind"] == {"x": 2, "y": 1}


def test_audit_blocks_without_pdf(tmp_path):
    js = tmp_path / "a.json"
    js.write_text("{}", encoding="utf-8")
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        r = S.stage_audit(S.Ctx(mpn="A", json_path=str(js), pdf_path=None, state=st),
                          audit_fn=lambda *a, **k: {"findings": []})
    assert r.status == C.STATUS_BLOCKED
    assert "PDF" in r.error


# ====================================================================== RENDER

def test_render_is_skipped_in_shadow(tmp_path):
    """shadow 里渲染必须跳过：它会改 item.status 并写正式产物目录。"""
    with StageStateStore(tmp_path / "s.sqlite3") as st:
        ctx = S.Ctx(mpn="A", shadow=True, state=st)
        r = S.stage_render(ctx, finish_fn=lambda *a, **k: pytest.fail("shadow 不该渲染"))
    assert r.status == C.STATUS_SKIPPED
    assert r.detail["reason"] == "shadow_no_render"


# ====================================================================== P1-12 Shadow

@pytest.mark.slow
@pytest.mark.parametrize("mpn,fname", SAMPLES[:3], ids=[s[0] for s in SAMPLES[:3]])
def test_p1_12_shadow_compare_identical(mpn, fname, tmp_path):
    """P1-12：同一份 PDF 上，新旧两条路在确定性部分完全一致。"""
    res = S.shadow_compare(_pdf(fname), mpn, out_root=tmp_path)
    assert res["mismatch"] == {}, f"新旧链路出现差异: {res['mismatch']}"
    assert res["verdict"] in {"identical", "inconclusive"}
    assert res["checks"]["text_sha256"]["old"] == res["checks"]["text_sha256"]["new"]
    assert res["checks"]["prompt_sha256"]["old"] == res["checks"]["prompt_sha256"]["new"]
    assert res["checks"]["is_datasheet"]["old"] == res["checks"]["is_datasheet"]["new"]


@pytest.mark.slow
def test_p1_12_shadow_does_not_write_formal_outputs(tmp_path):
    """P1-12 的核心约束：对照跑完，正式产物目录一个字节都不能变。"""
    parsed = ROOT / "data" / "parsed"
    before = {p.name: p.stat().st_mtime_ns for p in parsed.glob("*.json")}
    slices_before = set(SS.list_slices())

    res = S.shadow_compare(_pdf("LM317__lm317.pdf"), "LM317", out_root=tmp_path)

    after = {p.name: p.stat().st_mtime_ns for p in parsed.glob("*.json")}
    assert after == before, "对照过程改写了正式 data/parsed"
    assert set(SS.list_slices()) == slices_before, "对照过程往正式 data/slices 写了切片"
    assert res["verdict"] in {"identical", "inconclusive"}


@pytest.mark.slow
def test_p1_12_shadow_compares_structure_against_baseline(tmp_path):
    """有基准 JSON 时给出结构差异；无基准时必须说 inconclusive，不许报 identical。"""
    pdf = _pdf("LM317__lm317.pdf")
    base = S._default_json("LM317", C.sha256_file(pdf))
    if not base.exists():
        pytest.skip(f"缺少基准 JSON: {base}")

    res = S.shadow_compare(pdf, "LM317", out_root=tmp_path)
    assert res["baseline"], "没有识别到基准 JSON"
    assert res["verdict"] in {"identical", "differs"}
    assert isinstance(res["struct_diff"], dict)


def test_shadow_verdict_never_upgrades_inconclusive():
    """没有基准、没跑 LLM → 只能是 inconclusive（P1-12 结论口径）。"""
    src = (ROOT / "app" / "pipeline" / "stages.py").read_text(encoding="utf-8")
    assert '"inconclusive"' in src
    assert 'result["verdict"] = "differs"' in src


# ====================================================================== 兼容性

def test_parse_pdf_signature_stays_backward_compatible():
    """`parse_pdf` 新增的四个参数必须全是可选的，且默认值与旧行为一致。"""
    import inspect
    from app.services.pipeline import parse_pdf

    sig = inspect.signature(parse_pdf)
    for name in ("text", "pages_used", "pages_total", "out_dir"):
        assert name in sig.parameters, f"缺少接缝参数 {name}"
        assert sig.parameters[name].default is None, f"{name} 默认值必须是 None"

    for name in ("pdf", "mpn"):
        assert sig.parameters[name].default is inspect.Parameter.empty
    assert sig.parameters["datasheet_url"].default == ""


def test_no_production_wiring_changed():
    """Phase 1.2 的守卫已过期，改为守住「Phase 1.6 只加了两条分叉」这件事。

    接线前这条断言的是「worker 里根本没有 app.pipeline」。Phase 1.6 合法地接线
    之后那句话就不成立了，但它的**意图**（旧链路不被悄悄改变）仍然要守：
    现在只允许在 `worker/tasks.py` 里出现惰性 import，且接力分叉必须由
    `config.PIPELINE_V2` 决定；`dispatch.py` 仍然不许碰阶段层。
    """
    tasks = (ROOT / "worker" / "tasks.py").read_text(encoding="utf-8")
    assert "from app.pipeline" in tasks, "五段链路的接线不见了"
    # 必须惰性 import：V2 关着的时候 worker 的导入面不应该变
    assert "\nfrom app.pipeline" not in tasks, "app.pipeline 不允许在模块顶层 import"
    assert "config.PIPELINE_V2" in tasks, "接力分叉必须由灰度开关决定"
    dispatch = (ROOT / "app" / "services" / "dispatch.py").read_text(encoding="utf-8")
    assert "app.pipeline" not in dispatch, "投递层不该知道阶段的存在"
