#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""2026-11-05 DSH 质审：QC 控制器必须递归消费容器完整性。

AFE7950 的 64 条 AC 逃逸行全在 `specs.onboard_device_specs.electrical`，
旧控制器只扫第一层 `specs.thermal/electrical`，双 Qwen 看不到这些行，
于是把 `formal_container_integrity=fail` 的件判成 `accept`。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.qa import controller as C                          # noqa: E402

PDF = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"


def _doc(integrity: str = "fail", *, ac: bool = True) -> dict:
    rows = [
        {"name": (f"SNR{i}" if ac else f"VOUT{i}"),
         "value": "70" if ac else "1.2",
         "unit": "dB" if ac else "V",
         "condition": "fIN=100MHz" if ac else "no load"}
        for i in range(64 if ac else 2)
    ]
    return {
        "metadata": {"pdf_hash": "deadbeef", "formal_container_integrity": integrity},
        "specs": {
            "thermal": [],
            "electrical": [],
            "onboard_device_specs": {"electrical": rows},
            "devices": {
                "AFE7950": {
                    "electrical": [
                        {"name": "VCMI", "value": "1.2", "unit": "V",
                         "condition": "internal bias"},
                    ],
                },
            },
        },
    }


def test_pick_items_recurses_onboard_and_devices():
    doc = _doc()
    items = C.pick_items(doc, "AFE7950", None, "thermal,electrical", limit=0)
    paths = {it["container"] for it in items}
    assert "onboard_device_specs.electrical" in paths, paths
    assert "devices.AFE7950.electrical" in paths, paths
    assert len(items) == 65, len(items)


def test_label_rows_sees_nested_containers():
    doc = _doc()
    assert C._label_rows(doc, "SNR0")
    assert C._label_rows(doc, "VCMI")


@pytest.mark.skipif(not PDF.exists(), reason="缺少 LM317 原件")
def test_integrity_fail_forces_reject_even_if_qwen_accepts(tmp_path):
    p = tmp_path / "AFE7950.json"
    p.write_text(json.dumps(_doc("fail"), ensure_ascii=False), encoding="utf-8")
    rep = C.run_qa(mpn="AFE7950", json_path=p, pdf_path=PDF,
                   skip_logic=True, limit=4)
    assert rep.decision == "reject", rep
    assert rep.severity == "P0"
    assert any("formal_container_integrity=fail" in r for r in rep.reasons), rep.reasons
    assert rep.deterministic["formal_container_integrity"] == "fail"
    assert rep.deterministic["formal_container_integrity_recorded"] == "fail"


@pytest.mark.skipif(not PDF.exists(), reason="缺少 LM317 原件")
def test_integrity_pass_does_not_force_reject(tmp_path):
    p = tmp_path / "AFE7950.json"
    p.write_text(json.dumps(_doc("pass", ac=False), ensure_ascii=False), encoding="utf-8")
    rep = C.run_qa(mpn="AFE7950", json_path=p, pdf_path=PDF,
                   skip_logic=True, limit=2)
    assert rep.decision == "accept", rep
    assert rep.deterministic["formal_container_integrity"] == "pass"
