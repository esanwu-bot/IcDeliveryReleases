# -*- coding: utf-8 -*-
"""A21 两级表头合并（红先）。

背景（2026-11-03 A/B 停止线）：`74LVC1G132DCKTG4` 的真电气表 p6/t0 得分 171 却
被 v4 资格闸门判 False —— `t.header.names` 只给了第一级
（`PARAMETER | TEST CONDITIONS | V | … | UNIT`），MIN/TYP(1)/MAX 全在**下一行**。

本文件的 5 组用例对应验收条件：
  1. 74LVC 的 VT+ / VT– / VOH / VOL 必须精确命中 p6/t0；
  2. 反例：p4/p5 供电电压表不得因合并而"获得" TYP（它们本来只有 MIN/MAX）；
  3. 反例：BUF634 的同分不同行重复表必须保持 ambiguous（A22 再修）；
  4. 回归：A19 融合表头 / A20 Limits / 单级表头 / 无角色表 全部保持原状。

用法：python -m pytest tests/test_table_header_two_level.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pytest                                              # noqa: E402

from qc import table_audit as TA                           # noqa: E402


@pytest.fixture(autouse=True)
def _v4_on():
    """A21 的收益只在 v4 臂上体现；v4 目前仍 experimental（默认 v3）。"""
    old = TA.MATCH_V4
    TA.MATCH_V4 = True
    try:
        yield
    finally:
        TA.MATCH_V4 = old


# ── 74LVC1G132 p6/t0 的真实两级表头（11 列）──
LV_TOP = ["PARAMETER", "", "TESTCONDITIONS", "V", "–40°C to +85°C",
          "", "", "–40°C to +125°C", "", "", "UNIT"]
LV_SECOND = ["", "", "", "CC", "MIN", "TYP(1)", "MAX", "MIN", "TYP(1)", "MAX", ""]
LV_ROWS = [
    ["V T+ Positive-going input threshold voltage", "", "", "165V .", "079 116 . .", "",
     "", "079 116 . .", "", "", "V"],
    ["V T– Negative-going input threshold voltage", "", "", "13V .", "034 05 . .", "",
     "", "034 053 . .", "", "", "V"],
    ["V OH High-level output voltage", "", "", "", "IOH = –100 µA", "", "", "", "", "", "V"],
    ["V OL Low-level output voltage", "", "", "", "IOL = 100 µA", "", "", "", "", "", "V"],
]
# ── p4 / p5：供电电压表（真实的单级表头，只有 MIN/MAX）──
SUP_HDR = ["", "", "MIN", "MAX", "UNIT"]
SUP_ROWS = [["", "", "MIN", "MAX", "UNIT"],
            ["VCC Supply voltage", "", "05 65 – . .", "", "V"],
            ["V Input voltage(2) I", "", "05 65 – . .", "", "V"]]


def _tbl(page, ti, header, rows, **kw):
    t = {"page": page, "ti": ti, "header": header, "rows": rows, "title": "",
         "xr": [], "hx": [], "split": False, "words_fixed": False,
         "header_source_rows": [0], "header_level_count": 1}
    t.update(kw)
    return t


def _lvc_tables():
    hdr, data, from_names, meta = TA.choose_header(LV_TOP, [LV_TOP, LV_SECOND] + LV_ROWS)
    assert from_names is True
    p6 = _tbl(6, 0, hdr, data, **meta)
    p4 = _tbl(4, 0, SUP_HDR, SUP_ROWS[1:])
    p5 = _tbl(5, 1, SUP_HDR, SUP_ROWS[1:])
    return [p4, p5, p6], meta


def test_two_level_header_merge_meta():
    hdr, data, from_names, meta = TA.choose_header(LV_TOP, [LV_TOP, LV_SECOND] + LV_ROWS)
    assert meta == {"header_source_rows": [0, 1], "header_level_count": 2}, meta
    assert from_names is True
    assert len(data) == len(LV_ROWS)                      # 两行表头都被吃掉
    roles = sorted({r for h in hdr for r in TA.header_roles(h)})
    assert roles == ["MAX", "MIN", "TYP"], roles
    # 列位置：MIN 必须在第 4/7 列（按列合并，绝不跨列继承）
    assert hdr[4].endswith("MIN") and hdr[7].endswith("MIN")
    assert hdr[5].endswith("TYP(1)") and hdr[6].endswith("MAX")
    assert TA.table_has_value_roles(_tbl(6, 0, hdr, data, **meta)) is True


def test_lvc_four_parameters_hit_p6():
    tables, _ = _lvc_tables()
    for name, val in [
        ("VT+ Positive-going input threshold voltage", "0.79"),
        ("VT– Negative-going input threshold voltage", "0.34"),
        ("VOH High-level output voltage", "2.4"),
        ("VOL Low-level output voltage", "0.4"),
    ]:
        st, info = TA.decide_table(tables, "", name, "", val)
        assert st == "matched", (name, st)
        assert (info["table"]["page"], info["table"]["ti"]) == (6, 0), (name, info["table"])


def test_supply_tables_must_not_gain_roles():
    """反例：p4/p5 是单级表头（MIN/MAX），不得因合并而"长出" TYP。"""
    hdr, data, from_names, meta = TA.choose_header(SUP_HDR, SUP_ROWS)
    assert meta == {"header_source_rows": [0], "header_level_count": 1}
    assert "TYP" not in {r for h in hdr for r in TA.header_roles(h)}
    assert len(hdr) == 5 and hdr[2] == "MIN" and hdr[3] == "MAX"


def test_buf634_duplicate_tables_stay_ambiguous():
    """反例：同分、不同行的重复表保持 ambiguous（A22 处理，本轮不许修好它）。"""
    elec = ["", "PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]
    a = _tbl(5, 0, elec, [["", "Short-Circuit Current", "", "", "", "15", "mA"]])
    b = _tbl(7, 0, elec, [["", "Short-Circuit Current", "", "", "15", "", "mA"]])
    st, info = TA.decide_table([a, b], "", "Short-Circuit Current", "", "15")
    assert st == "ambiguous_tie"
    assert info.get("reason") == "table_tie"


def test_regression_a19_fused_header_unchanged():
    names = ["Parameter", "Test Conditions", "MIN TYP MAX", "Unit"]
    rows = [["INL", "After gain error", "-3.9 0 5.5", "LSB"]]
    hdr, data, from_names, meta = TA.choose_header(names, rows)
    assert meta["header_level_count"] == 1
    assert hdr == names and data == rows


def test_regression_a20_limits_unchanged():
    names = ["Parameter", "Test Conditions", "Typ(3)", "Limits (3)", "Units (Limits)"]
    rows = [["INL", "After gain error", "0.5", "−1.3 1.3", "LSB"]]
    hdr, data, from_names, meta = TA.choose_header(names, rows)
    assert meta["header_level_count"] == 1
    assert TA.table_has_value_roles(_tbl(1, 0, hdr, data, **meta)) is True


def test_regression_single_level_and_no_role_unchanged():
    names = ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]
    rows = [["INL", "After gain error", "", "0.5", "", "LSB"]]
    hdr, data, _, meta = TA.choose_header(names, rows)
    assert meta["header_level_count"] == 1 and hdr == names

    # 无角色表：names 无角色，第二行也没有 → 不许合出伪表头
    names2 = ["PRODUCT", "RESOLUTION", "INPUT"]
    rows2 = [["PRODUCT", "RESOLUTION", "INPUT"], ["ADS42", "14", "LVDS"]]
    hdr2, data2, _, meta2 = TA.choose_header(names2, rows2)
    assert meta2["header_level_count"] == 1
    assert hdr2 == names2 and data2 == rows2


def test_regression_switch_off_restores_old_behavior(monkeypatch):
    """`ICPDF_HEADER_MERGE=0` 时必须回到 A21 之前的行为（红先/回滚臂）。"""
    monkeypatch.setattr(TA, "HEADER_MERGE", False)
    hdr, data, from_names, meta = TA.choose_header(LV_TOP, [LV_TOP, LV_SECOND] + LV_ROWS)
    assert meta["header_level_count"] == 1
    assert data == [LV_TOP, LV_SECOND] + LV_ROWS


@pytest.mark.skipif(
    not list((ROOT / "data/pdfs").glob("74LVC1G132DCKTG4__*.pdf")),
    reason="本地无 74LVC1G132DCKTG4 PDF（数据目录不入库）")
def test_real_pdf_p6_now_eligible():
    """集成验证：真实 PDF 的 p6/t0 合并后必须获得资格，且可审计。"""
    import pymupdf as fitz
    pdf = sorted((ROOT / "data/pdfs").glob("74LVC1G132DCKTG4__*.pdf"))[0]
    tables = TA.scan_tables(fitz.open(pdf))
    t = next(x for x in tables if (x["page"], x["ti"]) == (6, 0))
    assert t["header_level_count"] == 2
    assert t["header_source_rows"] == [0, 1]
    assert TA.table_has_value_roles(t) is True


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
