"""质审流水线（双 Qwen 评委 + 调度 + 工单）的离线用例。

**全部不联网**：所有模型调用都注入 `chat_fn` 假函数，GitHub 走 dry-run。
这是刻意的 —— 质审是自动流水线，用例若依赖真实网关，红灯就分不清是
「判据错了」还是「今天配额没了」。
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

from app.integrations import github_issues as GH
from app.qa import controller as C
from app.reviewers import qwen_reviewer as QR

ROOT = Path(__file__).resolve().parents[1]
PDF = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"
JSON = ROOT / "data" / "staging_batch20_delivery" / "parsed" / "LM317.json"
FACTS = ROOT / "data" / "staging_batch20_delivery" / "facts_audit.csv"

#: LM317 p7 的 RθJC(top) 行：两列（DCY 39.3 / KTT 43.6），bbox 来自事实表。
ROW_BBOX = [58.9, 352.0, 469.6, 362.1]


def _need_pdf():
    if not PDF.is_file():
        pytest.skip("缺 LM317 PDF 夹具")


def _fake_chat(long_payload=None, max_payload=None):
    """按模型名分流，返回预设裁决。"""
    long_payload = long_payload or {"verdict": "agree", "reason": "一致", "confidence": 0.9}
    max_payload = max_payload or {"verdict": "pass", "reason": "无问题", "issues": []}

    def fn(messages, model=None, **kw):
        body = long_payload if model == QR.MODEL_EVIDENCE else max_payload
        return {"content": json.dumps(body, ensure_ascii=False), "usage": {}}
    return fn


# ── 一、证据切片：必须带列坐标 ────────────────────────────────────
def test_slice_row_keeps_package_columns_and_values():
    _need_pdf()
    s = QR.slice_row(PDF, 7, ROW_BBOX)
    # 行文本干净：不能把上一行的残字（θ(J )）带进来
    assert "RθJC(top)" in s.row
    assert "θ(J )" not in s.row
    # 两个封装列都在表头里，且带列左边界
    assert "DCY@" in s.header and "KTT@" in s.header
    assert "(SOT-223)" in s.header and "(TO-263)" in s.header
    # 机器计数把两列数值都数出来 —— 这是「多列塌缩」判据的输入
    assert [v["text"] for v in s.values] == ["39.3", "43.6"]
    assert s.values[0]["x"] < s.values[1]["x"]


def test_slice_row_rejects_bad_bbox():
    _need_pdf()
    with pytest.raises(QR.ReviewerError):
        QR.slice_row(PDF, 7, [1.0, 2.0])


def test_slice_row_page_out_of_range():
    _need_pdf()
    with pytest.raises(QR.ReviewerError):
        QR.slice_row(PDF, 9999, ROW_BBOX)


def test_thermal_hints_normalize_parentheses():
    """`Rθ(JA)` 与 `RθJA` 是同一个参数：不归一化就会判成「原文没有 RθJA」。"""
    _need_pdf()
    hints = QR.thermal_labels_in_pdf(PDF)
    joined = "".join(hints).replace("(", "").replace(")", "")
    assert "RθJA" in joined


# ── 二、qwen-long：没有 bbox 不许调模型 ──────────────────────────
def test_review_row_without_bbox_skips_model():
    called = {"n": 0}

    def fn(*a, **k):
        called["n"] += 1
        return {"content": "{}"}

    r = QR.review_row({"mpn": "LM317", "label": "RθJA", "value": "66.8",
                       "unit": "°C/W", "page": 7, "bbox": []},
                      PDF, chat_fn=fn)
    assert r["verdict"] == "unsure" and r["skipped"] is True
    assert called["n"] == 0, "没有证据就不许调模型（会把配额烧在猜上）"


def test_review_row_parses_mismatch():
    _need_pdf()
    fn = _fake_chat({"verdict": "mismatch", "expected_value": "39.3",
                     "expected_unit": "°C/W", "expected_column": "TYP",
                     "json_column": "TYP", "reason": "只抽了第一列", "confidence": 0.92})
    r = QR.review_row({"mpn": "LM317", "label": "RθJC(top)", "value": "43.2",
                       "unit": "°C/W", "page": 7, "bbox": ROW_BBOX}, PDF, chat_fn=fn)
    assert r["verdict"] == "mismatch" and r["confidence"] == 0.92
    assert r["kind"] == "qwen_long_mismatch"
    assert r["evidence"]["page"] == 7


def test_review_row_unknown_verdict_falls_back_to_unsure():
    """模型回了个没见过的词，不许当成 agree 放过去。"""
    _need_pdf()
    fn = _fake_chat({"verdict": "好像对", "confidence": 0.9})
    r = QR.review_row({"mpn": "LM317", "label": "RθJB", "value": "16.9",
                       "unit": "°C/W", "page": 7, "bbox": ROW_BBOX}, PDF, chat_fn=fn)
    assert r["verdict"] == "unsure"


def test_review_row_handles_fenced_json():
    _need_pdf()

    def fn(messages, model=None, **kw):
        return {"content": "```json\n{\"verdict\":\"agree\",\"reason\":\"ok\",\"confidence\":0.8}\n```"}

    r = QR.review_row({"mpn": "LM317", "label": "ψJT", "value": "3.6",
                       "unit": "°C/W", "page": 7, "bbox": [58.9, 379.9, 469.6, 390.0]},
                      PDF, chat_fn=fn)
    assert r["verdict"] == "agree"


# ── 三、qwen-max：结构审查 ────────────────────────────────────────
def _doc_with_thermal(rows):
    return {"basic_info": {"mpn": "LM317"},
            "specs": {"thermal": rows, "electrical": []},
            "pin_configuration": []}


def test_review_doc_normalizes_severity():
    fn = _fake_chat(max_payload={"verdict": "suspect", "reason": "缺 RθJA", "issues": [
        {"kind": "missing_key_param", "severity": "critical", "label": "RθJA",
         "detail": "原文有，JSON 无"}]})
    r = QR.review_doc(_doc_with_thermal([]), mpn="LM317", chat_fn=fn)
    assert r["verdict"] == "suspect"
    assert r["issues"][0]["severity"] == "P1", "非法严重度要收敛到 P1，不能凭空升 P0"


def test_review_doc_payload_omits_pin_bodies():
    """引脚描述不进上下文：几百条会把热阻/电气表挤出窗口。"""
    doc = _doc_with_thermal([])
    doc["pin_configuration"] = [{"pin": f"{i}", "name": "x"} for i in range(200)]
    payload = QR._logic_payload(doc)
    assert "pin_configuration_count" in payload
    assert payload.count('"name": "x"') <= 12


# ── 四、判断：否决 / 分歧 / 通过 ─────────────────────────────────
def test_decide_veto_on_confident_mismatch():
    d, sev, why = C.decide([{"verdict": "mismatch", "confidence": 0.9, "label": "RθJA"}],
                           {"issues": []}, {"verdict": "pass"})
    assert (d, sev) == ("reject", "P0") and why


def test_decide_low_confidence_mismatch_is_disputed_not_veto():
    d, sev, _ = C.decide([{"verdict": "mismatch", "confidence": 0.4, "label": "RθJA"}],
                         {"issues": []}, {"verdict": "pass"})
    assert d == "disputed"


def test_decide_p0_issue_vetoes_even_if_rows_agree():
    d, sev, _ = C.decide([{"verdict": "agree", "confidence": 0.9}],
                         {"issues": [{"kind": "absmax_in_operating", "severity": "P0"}]},
                         {"verdict": "pass"})
    assert (d, sev) == ("reject", "P0")


def test_decide_all_green_is_accept_but_not_approval():
    d, _, why = C.decide([{"verdict": "agree", "confidence": 0.9}],
                         {"issues": []}, {"verdict": "pass"})
    assert d == "accept"
    assert any("不代表放行" in w for w in why)


# ── 五、工单：一件一单 + Checklist ───────────────────────────────
def _defect(**kw):
    base = dict(source="qwen-long", kind="qwen_long_mismatch", category="多列塌缩",
                severity="P0",
                label="RθJC(top)", page=7, bbox=ROW_BBOX,
                detail="只抽一列，原文有 2 列（39.3@392、43.6@454）",
                expected="39.3 °C/W（TYP）", current="43.2 °C/W（TYP）",
                evidence={"header": "DCY@391 KTT@454", "row": "RθJC(top) 39.3 43.6"},
                confidence=0.92)
    base.update(kw)
    return base


def _issue(**kw):
    base = dict(mpn="LM317", pdf_sha256="a" * 64,
                defects=[_defect()],
                decision="reject",
                models={"qwen-long": "qwen-long-2024-09-19", "qwen-max": "qwen-max"},
                reasons=["qwen-long 判 mismatch（confidence=0.92）"])
    base.update(kw)
    return GH.build_issue(**base)


@pytest.mark.parametrize("field", ["mpn", "pdf_sha256", "defects"])
def test_build_issue_requires_item_fields(field):
    kw = {field: "" if field != "defects" else []}
    with pytest.raises(ValueError):
        _issue(**kw)


@pytest.mark.parametrize("bad", [{"page": None}, {"detail": "", "label": ""}])
def test_build_issue_rejects_incomplete_defect(bad):
    """单条缺陷缺页码/缺原因同样不许混进来 —— 否则就是 Checklist 里的死条目。"""
    with pytest.raises(ValueError):
        _issue(defects=[_defect(**bad)])


def test_three_defects_become_one_issue_with_three_checkboxes():
    """核心用例：3 个缺陷 → 1 张单、3 个 `- [ ]`，不是 3 张单。"""
    issue = _issue(defects=[
        _defect(),
        _defect(source="qwen-max", kind="missing_key_param", category="", severity="P1",
                label="RθJA", page=7, bbox=[], detail="原文有 RθJA，JSON 无",
                expected="66.8/23.5/37.9/38.0", current="缺失"),
        _defect(source="deterministic", kind="fused_column_blocking", category="",
                severity="P0", label="VCMI", page=10, bbox=[],
                detail="MIN/TYP/MAX 挤在一格"),
    ])
    body = issue["body"]
    assert body.count("- [ ]") == 3, body
    assert issue["title"] == "[质审/P0] LM317 · 发现 3 项严重缺陷"
    assert issue["severity"] == "P0"
    # 抬头三件套：MPN / PDF SHA / 模型版本
    for token in ("MPN", "PDF SHA-256", "模型版本", "qwen-long-2024-09-19"):
        assert token in body, token
    # 三路缺陷都在同一张单里，且各带级别与类别
    for token in ("[P0/多列塌缩]", "[P1/关键参数缺失]", "[P0/列融合（阻断）]"):
        assert token in body, token


def test_title_takes_worst_severity_not_first_defect():
    issue = _issue(defects=[
        _defect(severity="P1", label="A"),
        _defect(severity="P0", label="B", kind="fused_column_blocking", category=""),
    ])
    assert issue["severity"] == "P0"
    assert issue["title"].startswith("[质审/P0] LM317 · 发现 2 项")


def test_issue_body_has_all_required_sections():
    body = _issue()["body"]
    for token in ("MPN", "PDF SHA-256", "模型版本", "缺陷清单", "逐条详情",
                  "期望结果", "当前结果", "错误原因", "复现"):
        assert token in body, token


def test_same_defect_from_two_sources_is_merged():
    """qwen-long 与 qwen-max 同时指出「多列塌缩」是**一个**毛病，不该列两条。"""
    issue = _issue(defects=[
        _defect(source="qwen-long", category="多列塌缩", severity="P0"),
        _defect(source="qwen-max", kind="column_collapse_suspect", category="",
                severity="P1", detail="热阻表该行只有一条且 condition 为空"),
    ])
    assert issue["body"].count("- [ ]") == 1
    d = issue["defects"][0]
    assert set(d["sources"]) == {"qwen-long", "qwen-max"}
    assert d["severity"] == "P0", "合并后取更严重的级别"
    assert "发现 1 项" in issue["title"]


def test_dedup_key_is_per_item_not_per_defect():
    """去重键只看 MPN + PDF SHA：同件的不同缺陷组合必须落到同一个键。"""
    k1 = GH.dedup_key("LM317", "A" * 64)
    assert k1 == GH.dedup_key("lm317", "a" * 64)
    assert GH.dedup_key("LM317", "b" * 64) != k1
    a = _issue(defects=[_defect()])
    b = _issue(defects=[_defect(), _defect(label="RθJA", kind="missing_key_param")])
    assert a["dedup_key"] == b["dedup_key"]


def test_create_issue_dry_run_makes_no_request(tmp_path):
    issue = _issue()

    class Boom:
        def post(self, *a, **k):        # 任何网络调用都算失败
            raise AssertionError("dry-run 不该发请求")

        def get(self, *a, **k):
            raise AssertionError("dry-run 不该发请求")

    res = GH.create_issue(issue, dry_run=True, session=Boom(), out_dir=tmp_path)
    assert res["dry_run"] is True
    assert res["request"]["method"] == "POST"
    assert res["request"]["json"]["title"] == issue["title"]
    assert Path(res["written"]).is_file()


# ── 六、端到端（离线）──────────────────────────────────────────
def test_controller_end_to_end_offline():
    if not (JSON.is_file() and FACTS.is_file()):
        pytest.skip("缺 LM317 夹具")
    _need_pdf()
    long_p = {"verdict": "mismatch", "expected_value": "39.3", "expected_unit": "°C/W",
              "expected_column": "TYP", "json_column": "TYP",
              "reason": "原文该行有 DCY/KTT 两列，JSON 只取一列且无 condition",
              "confidence": 0.9}
    max_p = {"verdict": "suspect", "reason": "缺 RθJA",
             "issues": [{"kind": "missing_key_param", "severity": "P0",
                         "label": "RθJA", "detail": "原文有 RθJA，JSON 无",
                         "expected": "66.8/23.5/37.9/38.0", "current": "缺失"}]}
    rep = C.run_qa(mpn="LM317", json_path=JSON, pdf_path=PDF, facts_csv=FACTS,
                   focus="thermal", limit=2, chat_fn=_fake_chat(long_p, max_p))
    assert rep.decision == "reject"
    assert rep.issue is not None
    assert rep.issue["pdf_sha256"]
    # 一件一单：mismatch 与缺失类问题收进同一张单的两条 Checklist
    body = rep.issue["body"]
    assert body.count("- [ ]") >= 2
    assert "RθJA" in body and "只取一列" in body
    assert rep.issue["models"]["qwen-long"] and rep.issue["models"]["qwen-max"]


def test_controller_accept_emits_no_issue():
    if not (JSON.is_file() and FACTS.is_file()):
        pytest.skip("缺 LM317 夹具")
    _need_pdf()
    rep = C.run_qa(mpn="LM317", json_path=JSON, pdf_path=PDF, facts_csv=FACTS,
                   focus="thermal", limit=1, chat_fn=_fake_chat())
    assert rep.decision == "accept"
    assert rep.issue is None


# ── 七、缺陷归一：三路结论 → 一个清单 ────────────────────────────
def _report(**kw):
    base = dict(mpn="LM317", pdf_sha256="a" * 64, decision="reject", severity="P0")
    base.update(kw)
    return C.QAReport(**base)


def test_collect_defects_reads_deterministic_findings():
    """机器审计 findings 必须在清单里，评委没提不代表不存在。"""
    doc = {"specs": {"electrical": [{"name": "VCMI", "value": "0.3 to 0.55"}]},
           "metadata": {"audit": {"findings": [
               {"path": "electrical[3].VCMI", "kind": "fused_column_blocking",
                "json": "0.3 to 0.55", "table": "FUSED_COLUMN", "page": 10}]}}}
    rep = _report(deterministic=C.load_deterministic("LM317", None, doc))
    out = C.collect_defects(rep, doc=doc, pdf_path="nope.pdf")
    assert len(out) == 1
    d = out[0]
    assert d["severity"] == "P0", "列融合会让 MIN 被丢掉，必须 P0"
    assert d["label"] == "VCMI", "path 里的点号后缀才是参数名"
    assert d["page"] == 10
    assert "列融合" in d["detail"] and "FUSED_COLUMN" in d["detail"]


def test_collect_defects_flags_anchor_gate_blocked():
    det = {"verdict": "partial_pass", "anchor_gate": "blocked", "findings": [],
           "finding_kinds": {},
           "weak_rows": [{"label": "RθJA", "container": "thermal", "page": "7"},
                         {"label": "RθJC", "container": "thermal", "page": "7"}]}
    out = C.collect_defects(_report(deterministic=det), doc={}, pdf_path="nope.pdf")
    assert len(out) == 1
    assert out[0]["kind"] == "anchor_gate_blocked" and out[0]["page"] == 7
    assert "2 行证据未达门槛" in out[0]["detail"]
    assert "thermal 2" in out[0]["detail"]


def test_collect_defects_keeps_veto_threshold_consistent():
    """工单级别必须和 `decide()` 用同一个门槛：0.4 的 mismatch 只算 P1。"""
    rows = [{"verdict": "mismatch", "confidence": 0.4, "label": "RθJA",
             "evidence": {"page": 7, "values": []}},
            {"verdict": "mismatch", "confidence": 0.9, "label": "RθJB",
             "evidence": {"page": 7, "values": []}}]
    out = C.collect_defects(_report(qwen_long=rows), doc={}, pdf_path="nope.pdf")
    sev = {d["label"]: d["severity"] for d in out}
    assert sev == {"RθJA": "P1", "RθJB": "P0"}
    assert C.decide(rows, {"issues": []}, {"verdict": "pass"})[1] == "P0"


# ── 八、--facts 兼容 CSV / JSON ──────────────────────────────────
_CSV = ("mpn,container,label,cond,verdict,page,bbox\n"
        "X,thermal,RθJA,,verified_row,7,\"1,2,3,4\"\n"
        "X,thermal,RθJC(top),,unchecked,7,\n")

_JSON = {"mpns": {"X": {
    "n_rows": 7, "counts": {"verified_row": 6, "unchecked": 1},
    "verdict": "partial", "anchor_gate": "blocked",
    "blocked": ["RθJA (have=weak, need=paragraph_anchor)"]}}}


def _facts_csv(tmp_path):
    p = tmp_path / "facts_audit.csv"
    p.write_text(_CSV, encoding="utf-8")
    return p


def test_facts_accepts_csv(tmp_path):
    f = C.resolve_facts(_facts_csv(tmp_path))
    assert f.csv_path and not f.rows
    d = C.load_deterministic("X", f)
    assert d["n_rows"] == 2 and len(d["weak_rows"]) == 1
    assert C._fact_coords("X", f)[("RθJA", "")]["page"] == 7


def test_facts_accepts_json_with_sibling_csv(tmp_path):
    """传 JSON 时优先找同名 CSV —— 只有 CSV 才带 bbox/页码。"""
    _facts_csv(tmp_path)
    js = tmp_path / "facts_audit.json"
    js.write_text(json.dumps(_JSON, ensure_ascii=False), encoding="utf-8")
    f = C.resolve_facts(js)
    assert f.csv_path and f.csv_path.name == "facts_audit.csv"
    assert f.json_path == js
    d = C.load_deterministic("X", f)
    assert d["verdict"] == "partial" and d["anchor_gate"] == "blocked"


def test_facts_json_only_degrades_but_reports(tmp_path):
    """没有同名 CSV：行数/分布取 JSON 汇总，弱行只能来自 blocked 清单。"""
    js = tmp_path / "facts_audit.json"
    js.write_text(json.dumps(_JSON, ensure_ascii=False), encoding="utf-8")
    f = C.resolve_facts(js)
    assert f.csv_path is None
    assert "没有同名 CSV" in f.note
    d = C.load_deterministic("X", f)
    assert d["n_rows"] == 7, "行数要用 JSON 的汇总，不能数成 1"
    assert d["counts"] == {"verified_row": 6, "unchecked": 1}
    assert [w["label"] for w in d["weak_rows"]] == ["RθJA"]
    assert C._fact_coords("X", f)[("RθJA", "")]["page"] is None


def test_facts_missing_file_raises(tmp_path):
    for name in ("nope.csv", "nope.json"):
        with pytest.raises(FileNotFoundError):
            C.resolve_facts(tmp_path / name)


# ── 九、CLI 双参数 ──────────────────────────────────────────────
def test_cli_has_explicit_dry_run_and_push():
    import argparse
    src = Path(C.__file__).read_text(encoding="utf-8")
    assert '"--dry-run"' in src and '"--push"' in src
    # 互斥：同时给要报错，不能静默按某一个执行
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true")
    g.add_argument("--push", action="store_true")
    with pytest.raises(SystemExit):
        ap.parse_args(["--dry-run", "--push"])


# ── 十、去重加固：标签被静默丢弃也不能重复建单 ──────────────────
class _Resp:
    def __init__(self, code, payload):
        self.status_code = code
        self._p = payload
        self.text = json.dumps(payload)

    def json(self):
        return self._p


class FakeGH:
    """模拟真实仓库的两种坑：① 标签不存在（GitHub 静默丢弃）；② 无 label 写权限。

    这两个是**不同成因、同一个症状**（201 但 labels 为空）：
    - 仓库里没有 `auto-trigger` 这个标签 —— 建单时它被丢掉，不会自动创建；
    - token 只有 issues:write，建标签 403，同样写不进去。
    两种情况下按标签查重都会永远查不到，所以查重必须靠正文 marker。
    """

    def __init__(self, *, drop_labels=True, server_issues=None,
                 repo_labels=("qa-audit", "auto-generated", "severity:P0"),
                 label_read_status=200, label_write_status=201):
        self.drop_labels = drop_labels
        self.server_issues = list(server_issues or [])
        self.repo_labels = set(repo_labels)
        self.label_read_status = label_read_status
        self.label_write_status = label_write_status
        self.posts = []            # 建单请求
        self.label_posts = []      # 建标签请求
        self.issue_label_posts = []  # 建单后补打标签的请求
        self.get_params = []       # [{"url":..., "params": {...}}]

    def get(self, url, params=None, headers=None, timeout=None):
        self.get_params.append({"url": url, "params": dict(params or {})})
        if url.endswith("/labels"):
            if self.label_read_status != 200:
                return _Resp(self.label_read_status, {"message": "forbidden"})
            return _Resp(200, [{"name": x} for x in sorted(self.repo_labels)])
        return _Resp(200, list(self.server_issues))

    def post(self, url, json=None, headers=None, timeout=None):
        # 建单后补打标签：POST /repos/{o}/{r}/issues/{n}/labels
        if re.search(r"/issues/\d+/labels$", url):
            self.issue_label_posts.append(json["labels"])
            if self.label_write_status not in (200, 201):
                return _Resp(self.label_write_status, {"message": "forbidden"})
            return _Resp(200, [{"name": x} for x in json["labels"]])
        if url.endswith("/labels"):                     # 建标签：POST /repos/{o}/{r}/labels
            self.label_posts.append(json)
            if self.label_write_status not in (200, 201):
                return _Resp(self.label_write_status, {"message": "forbidden"})
            if json["name"] in self.repo_labels:
                return _Resp(422, {"message": "already exists"})
            self.repo_labels.add(json["name"])
            return _Resp(201, json)
        self.posts.append(json)
        n = 100 + len(self.posts)
        labels = [] if self.drop_labels else [{"name": x} for x in json["labels"]]
        issue = {"number": n, "html_url": f"https://example/{n}",
                 "body": json["body"], "labels": labels}
        self.server_issues.append(issue)
        return _Resp(201, issue)


def test_create_issue_survives_dropped_labels(tmp_path):
    """标签被丢弃 → 记 labels_dropped → 写台账 → 第二次不重复建单。"""
    issue = _issue()
    ledger = tmp_path / "ledger.json"

    s1 = FakeGH(drop_labels=True, label_write_status=403)   # 建单忽略 + 补打也无权限
    r1 = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                         session=s1, ledger=ledger)
    assert r1.get("created") and r1["number"] == 101
    assert r1["labels_dropped"], "响应里没有标签必须被发现"
    assert "去重" in r1["labels_warning"]
    assert ledger.is_file()

    # 第二次：即便云端「什么都查不到」（get 返回空列表），台账也要挡住
    s2 = FakeGH(drop_labels=True, label_write_status=403, server_issues=[])
    r2 = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                         session=s2, ledger=ledger)
    assert r2.get("skipped") and r2["dedup_source"] == "ledger"
    assert s2.posts == [], "台账命中后不许再发 POST"


def test_existing_does_not_filter_by_label(tmp_path):
    """查重走正文 marker：请求里不能带 labels 过滤（标签可能根本写不进去）。"""
    s = FakeGH()
    GH._existing(s, "o/r", "t", "abc")
    issue_lists = [c for c in s.get_params if c["url"].endswith("/issues")]
    assert issue_lists, "没查过 issue 列表"
    assert "labels" not in issue_lists[0]["params"]


def test_missing_labels_are_created_before_create(tmp_path):
    """仓库里没有的标签要先补建 —— 否则 GitHub 静默丢弃，标签形同虚设。

    真实形态：发布仓库有 `qa-audit`，但没有 `auto-trigger`（§17 要求的）。
    """
    issue = _issue()
    s = FakeGH(drop_labels=False, repo_labels=("qa-audit", "severity:P1"))
    r = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                        session=s, ledger=tmp_path / "ledger.json")

    ensured = r["labels_ensured"]
    assert "qa-audit" in ensured["present"]
    assert set(ensured["created"]) == set(issue["labels"]) - {"qa-audit", "severity:P1"}
    assert {p["name"] for p in s.label_posts} == set(ensured["created"])
    assert not r.get("labels_dropped"), "补齐之后不该再有被丢弃的标签"


def test_label_creation_failure_does_not_block_create(tmp_path):
    """token 建不了标签（403）：单照样要建出来，只记告警 —— 标签不是建单前提。"""
    issue = _issue()
    s = FakeGH(drop_labels=True, repo_labels=(), label_write_status=403)
    r = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                        session=s, ledger=tmp_path / "ledger.json")

    assert r.get("created"), "标签失败不该把建单带下水"
    assert r["labels_ensured"]["failed"], "要记下哪些标签没建成"
    assert r["labels_dropped"] and "补齐失败" in r["labels_warning"]


def test_label_read_failure_skips_label_work(tmp_path):
    """连标签都读不到就别再试创建：那种情况下建标签只会白挨 403。"""
    issue = _issue()
    s = FakeGH(drop_labels=True, label_read_status=403)
    r = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                        session=s, ledger=tmp_path / "ledger.json")

    assert r.get("created")
    assert s.label_posts == [], "读标签失败后不该再发建标签请求"
    assert "读标签失败" in r["labels_ensured"]["error"]


def test_dedup_falls_back_to_remote_marker_when_ledger_missing(tmp_path):
    """台账丢了也要靠云端正文 marker 挡住（第二层）。"""
    issue = _issue()
    s = FakeGH(drop_labels=True)
    GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                    session=s, ledger=tmp_path / "l1.json")
    r = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                        session=s, ledger=tmp_path / "l2.json")
    assert r.get("skipped") and r["dedup_source"] == "remote"
    assert len(s.posts) == 1


def test_default_issues_repo_does_not_need_env(monkeypatch):
    monkeypatch.delenv("GITHUB_ISSUES_REPO", raising=False)
    repo, _ = GH._cfg(env={})
    assert repo == GH.DEFAULT_ISSUES_REPO == "esanwu-bot/IcDeliveryReleases"


def test_trigger_auto_qa_is_the_section17_entry():
    """AGENT.md §17 要求有一个统一入口，不要各脚本自己拼 Issue。"""
    assert callable(GH.trigger_auto_qa)
    import inspect
    sig = inspect.signature(GH.trigger_auto_qa)
    assert "pkg" in sig.parameters and "dry_run" in sig.parameters
    assert sig.parameters["dry_run"].default is True, "默认必须 dry-run"


def test_cmd_issue_matches_section17_template(tmp_path):
    from app.integrations import release_notify as RN
    fp = {"name": "delivery-20261103-V1", "path": str(tmp_path), "files": 3,
          "bytes": 1024, "zip": "delivery-20261103-V1.zip", "zip_bytes": 1024,
          "zip_sha256": "a" * 64, "n_zips": 1}
    st = {"head": "b" * 40, "branch": "main", "pushed": True, "dirty": [],
          "remote_head": "b" * 40}
    issue = RN.build_cmd_issue(fp, st, rel_path="delivery-20261103-V1")
    assert issue["title"] == "[CMD] 质审自动化 - delivery-20261103-V1"
    assert issue["labels"] == ["qa-audit", "auto-trigger"]
    body = issue["body"]
    assert body.startswith("@esanwu-bot 检测到新包发布。")
    assert "包名：delivery-20261103-V1" in body
    assert "路径：delivery-20261103-V1" in body
    assert "dry-run 和 --push" in body


def test_fingerprint_to_body_contract(tmp_path):
    """`pkg_fingerprint()` 的产出必须能直接喂给 `render_body()`。

    这条用例是被一次实战戳出来的：手搓 dict 写用例时漏了 `path` 键，
    `render_body` 直接 `KeyError` 崩在建单路上 —— 而手搓的 dict 永远是
    「渲染需要的字段正好齐全」，契约缺口在单测里根本显不出来。所以这里
    走真实指纹，命令集只断「不崩 + 关键值真的进了正文」。
    """
    import zipfile

    from app.integrations import release_notify as RN

    pkg = tmp_path / "delivery-20261103-V1"
    pkg.mkdir()
    (pkg / "manifest.json").write_text('{"n": 1}', encoding="utf-8")
    with zipfile.ZipFile(pkg / "delivery-20261103-V1.zip", "w") as z:
        z.writestr("a.txt", "hello")

    fp = RN.pkg_fingerprint(pkg)                      # 真指纹，不是手搓
    assert fp["path"] == str(pkg.resolve()), "render_body 依赖 path，指纹必须给"
    assert fp["zip_sha256"], "主 ZIP 必须算出哈希，否则去重键退化成只有包名"

    st = {"head": "b" * 40, "branch": "main", "pushed": True, "dirty": [],
          "remote_head": "b" * 40}
    body = RN.render_body(fp, st, rel_path="delivery-20261103-V1")

    assert fp["path"] in body, "绝对路径要落进正文，否则对方机器找不到包"
    assert fp["zip_sha256"] in body
    assert f"<!-- {RN.DEDUP_MARKER}: {RN.dedup_key(fp)} -->" in body


def test_notify_refuses_when_package_not_pushed(tmp_path):
    """包还没推就建单 = 让 DSH 去拉一个不存在的目录。必须硬失败。"""
    from app.integrations import release_notify as RN

    pkg = tmp_path / "delivery-20261103-V1"
    pkg.mkdir()
    (pkg / "manifest.json").write_text("{}", encoding="utf-8")

    with pytest.raises(RN.NotifyError) as ei:
        RN.notify(releases_dir=tmp_path, pkg=pkg.name, dry_run=True)
    assert "不是一个 git 仓库" in str(ei.value)


def test_notify_skips_push_check_when_disabled(tmp_path):
    """`require_pushed=False` 是给离线演练留的口子：只渲染、不校验 git。"""
    from app.integrations import release_notify as RN

    pkg = tmp_path / "delivery-20261103-V1"
    pkg.mkdir()
    (pkg / "manifest.json").write_text("{}", encoding="utf-8")

    # tmp_path 不是 git 仓库 —— 关掉校验后不该再碰 git
    res = RN.notify(releases_dir=tmp_path, pkg=pkg.name, dry_run=True,
                    require_pushed=False)
    assert res["issue"]["title"] == "[CMD] 质审自动化 - delivery-20261103-V1"
    # 拿不到 git 事实时正文要老实写「未校验」，不能渲染成 ``（）``
    assert "—（未校验）" in res["issue"]["body"]


def test_labels_are_reapplied_when_create_ignores_them(tmp_path):
    """建单接口整批忽略 labels 时，必须靠 POST /issues/{n}/labels 补打回来。

    实测（#16/#17）：`POST /issues` 带 labels 返回 201 但 labels 为空，
    而 `POST /issues/{n}/labels` 返回 200 且真的打上去了。只告警不补打，
    §17 要求的两个标签就永远落不到单上。
    """
    issue = _issue()
    s = FakeGH(drop_labels=True)            # 建单忽略标签，补打端点正常
    r = GH.create_issue(issue, dry_run=False, repo="o/r", token="t",
                        session=s, ledger=tmp_path / "ledger.json")

    assert r.get("created")
    assert s.issue_label_posts, "没尝试补打标签"
    assert set(r["labels_applied"]) == set(issue["labels"])
    assert not r.get("labels_dropped"), "补打成功后不该再报告标签丢失"


def test_first_line_must_mention_the_dsh_account(tmp_path):
    """首行必须 @ 到 DSH 的真实账号 —— 这是全链路唯一开关。

    踩过的坑：模板写 `@agent-dsh`（GitHub 上 404），DSH 的准入判据
    `body.includes('@' + login)` 永远不成立，工单被静默 ignore，
    看起来建单成功、其实没人接。这里把常量、首行、护栏三处一起钉住。
    """
    from app.integrations import release_notify as RN

    assert RN.MENTION == "@esanwu-bot"
    issue = _issue()
    fp = {"name": "delivery-20261103-V1", "path": str(tmp_path), "files": 1,
          "bytes": 10, "zip": "x.zip", "zip_bytes": 10,
          "zip_sha256": "b" * 64, "n_zips": 1}
    st = {"head": "c" * 40, "branch": "main", "pushed": True, "dirty": [],
          "remote_head": "c" * 40}
    cmd = RN.build_cmd_issue(fp, st, rel_path="delivery-20261103-V1")

    assert cmd["body"].splitlines()[0] == f"{RN.MENTION} 检测到新包发布。"
    assert "agent-dsh" not in cmd["body"], "不许再出现不存在的账号"
    assert "agent-dsh" not in issue["body"]         # 质审单也不该带


def test_first_line_must_mention_the_dsh_account(tmp_path):
    """首行必须 @ 到 DSH 的真实账号 —— 这是全链路唯一开关。

    踩过的坑：模板写 `@agent-dsh`（GitHub 上 404），DSH 的准入判据
    `body.includes('@' + login)` 永远不成立，工单被静默 ignore，
    看起来建单成功、其实没人接。这里把常量、首行、护栏三处一起钉住。
    """
    from app.integrations import release_notify as RN

    assert RN.MENTION == "@esanwu-bot"
    issue = _issue()
    fp = {"name": "delivery-20261103-V1", "path": str(tmp_path), "files": 1,
          "bytes": 10, "zip": "x.zip", "zip_bytes": 10,
          "zip_sha256": "b" * 64, "n_zips": 1}
    st = {"head": "c" * 40, "branch": "main", "pushed": True, "dirty": [],
          "remote_head": "c" * 40}
    cmd = RN.build_cmd_issue(fp, st, rel_path="delivery-20261103-V1")

    assert cmd["body"].splitlines()[0] == f"{RN.MENTION} 检测到新包发布。"
    assert "agent-dsh" not in cmd["body"], "不许再出现不存在的账号"
    assert "agent-dsh" not in issue["body"]         # 质审单也不该带
