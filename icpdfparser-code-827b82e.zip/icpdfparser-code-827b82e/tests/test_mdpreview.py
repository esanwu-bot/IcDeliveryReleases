"""qc/mdpreview.py 单测：浏览器渲染态所需的最小 Markdown 子集 + 转义安全 + 零 stdout。

背景：浏览器对 `text/markdown` 不渲染（Edge/Chrome 均显示源码），核验单/对照表
必须走 HTML 渲染态。本模块自包含（无第三方依赖），所以边界要自己兜住：
  1 表格（本项目产物主体）：`|` 分隔、分隔行识别、`\\|` 还原、首尾竖线
  2 结构：标题 1–4、列表、引用、分隔线、代码块
  3 行内：粗体、行内代码、http 链接
  4 **安全**：原文先转义，`<script>` 不得成为标签
  5 `to_html` 产出完整文档（`<style>`/`<table>`/打印按钮），import 零 stdout
"""
import contextlib
import io
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import mdpreview as MP                       # noqa: E402


class EscTest(unittest.TestCase):
    def test_esc(self):
        self.assertEqual(MP.esc('<a href="x">&</a>'), '&lt;a href="x"&gt;&amp;&lt;/a&gt;')

    def test_script_not_tag(self):
        h = MP.to_html('<script>alert(1)</script>')
        self.assertNotIn("<script>", h)
        self.assertIn("&lt;script&gt;", h)


class InlineTest(unittest.TestCase):
    def test_bold_and_code(self):
        s = MP.inline(MP.esc("**粗** 与 `x=1`"))
        self.assertIn("<strong>粗</strong>", s)
        self.assertIn("<code>x=1</code>", s)

    def test_link_only_http(self):
        self.assertIn('href="https://www.ti.com/x.pdf"',
                      MP.inline(MP.esc("[PDF](https://www.ti.com/x.pdf)")))
        # 非 http 协议不生成 <a>
        self.assertNotIn("<a ", MP.inline(MP.esc("[x](javascript:alert(1))")))


class CellsTest(unittest.TestCase):
    def test_strip_pipes(self):
        self.assertEqual(MP._cells("| a | b |"), ["a", "b"])

    def test_escaped_pipe(self):
        self.assertEqual(MP._cells("| a\\|b | c |"), ["a|b", "c"])


class ToHtmlTest(unittest.TestCase):
    def test_headings(self):
        h = MP.to_html("# 一\n## 二\n### 三\n#### 四")
        for lvl, txt in ((1, "一"), (2, "二"), (3, "三"), (4, "四")):
            self.assertIn(f"<h{lvl}>{txt}</h{lvl}>", h)

    def test_table(self):
        md = ("| # | 字段 | 页 |\n"
              "|---|------|---:|\n"
              "| 1 | `electrical[0].value` | 6 |\n"
              "| 2 | VDD | 9 |\n")
        h = MP.to_html(md)
        self.assertIn("<table><thead><tr>", h)
        self.assertIn("<th>字段</th>", h)
        self.assertIn("<td><code>electrical[0].value</code></td>", h)
        self.assertIn("<td>VDD</td>", h)
        self.assertEqual(h.count("<tr>"), 3)

    def test_table_without_sep_is_paragraph(self):
        h = MP.to_html("| a | b |\n| c | d |")
        self.assertNotIn("<table>", h)
        self.assertIn("<p>", h)

    def test_list_and_quote_and_hr(self):
        h = MP.to_html("- 甲\n- 乙\n\n> 已确认\n\n---")
        self.assertIn("<ul><li>甲</li><li>乙</li></ul>", h)
        self.assertIn("<blockquote>已确认</blockquote>", h)
        self.assertIn("<hr>", h)

    def test_ordered_list(self):
        h = MP.to_html("1. 身份\n2. 电气")
        self.assertIn("<ol><li>身份</li><li>电气</li></ol>", h)

    def test_task_list_checkbox(self):
        """核验单主体是 `- [ ] 字段` 清单：渲染成只读 checkbox，不显示字面 `[ ]`。"""
        h = MP.to_html("- [ ] `basic_info.mpn`　风险: **高**\n- [x] 已核\n- 普通项")
        self.assertIn('<li class="task"><input type="checkbox" disabled> ', h)
        self.assertIn('<input type="checkbox" disabled checked>', h)
        self.assertNotIn("[ ]", h)
        self.assertIn("<li>普通项</li>", h)

    def test_control_chars_removed(self):
        """PDF 文本里带 NUL：不得进 HTML（浏览器会当二进制、吞字符）。"""
        h = MP.to_html("| a |\n|---|\n| p1「\x00Input/Output」 |")
        self.assertNotIn("\x00", h)
        self.assertIn("p1「Input/Output」", h)
        self.assertNotIn("\x00", MP.to_html("正文\x07\x1f x"))

    def test_code_fence_escaped(self):
        h = MP.to_html("```\n<script>x</script>\n```")
        self.assertIn("<pre><code>&lt;script&gt;x&lt;/script&gt;</code></pre>", h)
        self.assertNotIn("<script>", h)

    def test_full_document(self):
        h = MP.to_html("| a |\n|---|\n| 1 |", title="核验单 · DAC8555",
                       subtitle="三遍法")
        self.assertTrue(h.startswith("<!DOCTYPE html>"))
        self.assertIn("<title>核验单 · DAC8555</title>", h)
        self.assertIn("<style>", h)
        self.assertIn("window.print()", h)
        self.assertIn('class="sub">三遍法</p>', h)
        self.assertIn("@media print", h)

    def test_title_escaped(self):
        h = MP.to_html("x", title="<b>t</b>")
        self.assertNotIn("<title><b>", h)


class SideEffectTest(unittest.TestCase):
    def test_import_and_render_silent(self):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            __import__("qc.mdpreview")
            MP.to_html("# x\n| a |\n|---|\n| 1 |")
        self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
