#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.6.1 验收：fetch 段去重的状态保护 + 并发领取（F1–F8）。

修的是什么
----------
`fetch_item` 曾经在调用 `fetch_stage` **之前**就把状态写成 `queued`，而
`fetch_stage` 的去重判据读的是调用方传进来的**旧快照**：

    第 1 次投递：读到 pending → 真下载 → done
    第 2 次投递：读到 done    → 跳过（对）→ 但库里被改成 queued（错）
    第 3 次投递：读到 queued  → 又真下载一遍（错，且没能拦住）

顺带还有第二条通道：两个重复任务同时读到 `pending`，都会进下载。

为什么用**真 sqlite 临时库**
--------------------------
这次修复的核心是条件更新（`UPDATE ... WHERE status=...` 的 rowcount 判定）。
用替身 `db` 只能验证"调用了什么"，验证不了"两个并发调用里只有一个抢到"。
所以夹具是临时库 + 真 `db`，只把网络采集（`collector.fetch_datasheet`）和
下游投递（`dispatch.submit`）换成可观测替身。

域名对照（F1–F8 = 外审裁决里的验收表）
--------------------------------------
F1 首次投递下载 / F2 第二次跳过且仍是 done / F3 第三次仍不重下 /
F4 重复投递不动审计字段 / F5 manual_url 仍能显式重下 /
F6 并发重复只下载一次 / F7 异常与残留态可恢复 / F8 旧入口不回归
"""
from __future__ import annotations

import inspect
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


# ------------------------------------------------------------------ 夹具
@pytest.fixture
def env(tmp_path, monkeypatch):
    """换一个临时库重新导入 app/worker，测试结束后把模块表恢复原样。

    必须恢复：`test_attach_worklist` / `test_cheatsheet` / `test_evidence_*`
    会靠 `del sys.modules["app*"]` 换环境重导模块，谁留在 sys.modules 里
    谁就决定后面那些用例拿到的是新对象还是旧对象。本夹具只借用这个手法，
    用完把原来的对象放回去，避免污染同一次 pytest 进程里的其它文件。
    """
    def _mine(name: str) -> bool:
        return name == "app" or name.startswith("app.") or \
               name == "worker" or name.startswith("worker.")

    saved = {k: v for k, v in list(sys.modules.items()) if _mine(k)}
    monkeypatch.setenv("ICPDF_WORKBENCH_DB", str(tmp_path / "t.sqlite3"))
    monkeypatch.setenv("ICPDF_FETCH_LEASE_SEC", "900")
    for k in saved:
        sys.modules.pop(k, None)

    import importlib                                        # noqa: PLC0415
    db = importlib.import_module("app.db")
    cfg = importlib.import_module("app.config")
    pl = importlib.import_module("app.services.pipeline")
    T = importlib.import_module("worker.tasks")
    db.conn()                                               # 建库 + DDL

    submits: list[tuple] = []
    monkeypatch.setattr(T.dispatch, "submit",
                        lambda kind, *a, **k: submits.append((kind, a, k)))
    monkeypatch.setattr(T.config, "PIPELINE_V2", False)

    yield SimpleNamespace(db=db, cfg=cfg, pl=pl, T=T, submits=submits, tmp=tmp_path)

    try:
        c = getattr(db._local, "c", None)
        if c is not None:
            c.close()
    except Exception:                                       # noqa: BLE001
        pass
    for k in [k for k in list(sys.modules) if _mine(k)]:
        sys.modules.pop(k, None)
    sys.modules.update(saved)


def _mk(db, *, mpn_key="LM317", status="pending", **kw) -> int:
    """插一条最小可用 item 行，返回 id。"""
    row = {"mpn": "LM317", "mpn_key": mpn_key, "brand": "TI", "status": status,
           "meta": "{}", "pdf_url": "", "pdf_path": "", "parse_count": 0,
           "error": "", "stage": "", "progress": 0}
    row.update(kw)
    t = db.now()
    cols = ",".join(row)
    marks = ",".join("?" * len(row))
    return db.x(f"INSERT INTO item({cols},created_at,updated_at) VALUES({marks},?,?)",
                (*row.values(), t, t))


def _get(db, item_id: int) -> dict:
    return db.q1("SELECT * FROM item WHERE id=?", (item_id,))


class FakeCollector:
    """可观测的采集替身：记录每次调用、可选延时（撑开并发窗口）、可选抛错。"""

    def __init__(self, pdf: Path, *, delay: float = 0.0):
        self.pdf = pdf
        self.delay = delay
        self.calls: list[dict] = []
        self.boom: BaseException | None = None
        self._lock = threading.Lock()

    def __call__(self, mpn, mpn_key, brand="", sheet_url="", cached_url="", manual_url=""):
        with self._lock:
            self.calls.append({"mpn": mpn, "manual_url": manual_url,
                               "cached_url": cached_url, "at": time.time()})
        if self.delay:
            time.sleep(self.delay)
        if self.boom:
            raise self.boom
        self.pdf.parent.mkdir(parents=True, exist_ok=True)
        self.pdf.write_bytes(b"%PDF-1.4 fake datasheet")
        return {"ok": True, "path": str(self.pdf),
                "url": manual_url or "http://example.com/ds.pdf",
                "sha256": "d" * 64, "bytes": self.pdf.stat().st_size,
                "provider": "fake"}


@pytest.fixture
def sink(env, monkeypatch):
    """把采集换成替身，返回 (collector, run_one)。"""
    fake = FakeCollector(env.tmp / "pdfs" / "LM317.pdf")
    monkeypatch.setattr(env.pl.collector, "fetch_datasheet", fake)

    def run_one(mpn_key="LM317", **kw):
        return env.T.fetch_item(mpn_key, **kw)

    return SimpleNamespace(fake=fake, run=run_one, env=env)


# ------------------------------------------------------------------ F1
def test_f1_first_delivery_on_pending_downloads(sink):
    """F1：pending 首次投递 —— 正常下载，并接力到下游。"""
    db = sink.env.db
    iid = _mk(db, status="pending")

    r = sink.run()

    assert r.get("ok") and not r.get("skipped"), r
    assert len(sink.fake.calls) == 1
    row = _get(db, iid)
    assert row["status"] == "downloading", row["status"]
    assert row["pdf_path"].endswith("LM317.pdf")
    assert row["pdf_sha256"] == "d" * 64
    # 接力：V2 关着 → llm_item
    assert [s[0] for s in sink.env.submits] == ["llm_item"]


# ------------------------------------------------------------------ F2 / F3
def test_f2_second_delivery_on_done_skips_and_keeps_done(sink):
    """F2：done 第二次投递 —— 跳过，且状态**仍然**是 done（不许降级成 queued）。"""
    db = sink.env.db
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf), pdf_url="http://example.com/ds.pdf")
    before = _get(db, iid)

    r = sink.run()

    assert r.get("ok") and r.get("skipped"), r
    assert r.get("reason") == "already_parsed"
    assert sink.fake.calls == [], "被跳过的投递不该碰网络"
    row = _get(db, iid)
    assert row["status"] == "done", f"跳过把 done 改成了 {row['status']}"
    assert row["updated_at"] == before["updated_at"], "跳过不该产生任何状态写入"
    assert sink.env.submits == [], "跳过的投递不该往下游投"


def test_f3_third_delivery_still_does_not_redownload(sink):
    """F3：done 连续第三次投递 —— 也不许重下（这就是修复前会翻车的那一次）。"""
    db = sink.env.db
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf), pdf_url="http://example.com/ds.pdf")

    for _ in range(3):
        r = sink.run()
        assert r.get("skipped"), f"第 N 次投递没被跳过：{r}"

    assert sink.fake.calls == [], f"重复投递触发了 {len(sink.fake.calls)} 次下载"
    assert _get(db, iid)["status"] == "done"


# ------------------------------------------------------------------ F4
def test_f4_repeat_delivery_leaves_audit_fields_untouched(sink):
    """F4：重复投递不动 tried_at / PDF mtime / parse_count / updated_at。

    `tried_at` 在 `doc_source` 里，采集替身不写那张表 —— 用"采集根本没被调用"
    来等价证明它没变；其余三项直接比对库和文件。
    """
    db = sink.env.db
    sink.fake.pdf.parent.mkdir(parents=True, exist_ok=True)
    sink.fake.pdf.write_bytes("%PDF-1.4 原始文件".encode("utf-8"))
    mtime = sink.fake.pdf.stat().st_mtime
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf),
              pdf_url="http://example.com/ds.pdf", parse_count=1, parse_ms=30921)
    before = _get(db, iid)

    for _ in range(4):
        sink.run()

    after = _get(db, iid)
    assert sink.fake.calls == [], "重复投递不该重新采集（tried_at 会因此变化）"
    assert sink.fake.pdf.stat().st_mtime == mtime, "PDF 文件被改写了"
    for col in ("parse_count", "parse_ms", "last_parsed_at", "status", "progress",
                "error", "updated_at", "pdf_sha256"):
        assert after[col] == before[col], f"{col} 被重复投递改动了：{before[col]} → {after[col]}"


# ------------------------------------------------------------------ F5
def test_f5_manual_url_still_forces_redownload(sink):
    """F5：manual_url 是显式的重下意图 —— done 也必须真的重下。"""
    db = sink.env.db
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf), pdf_url="http://old/x.pdf")

    r = sink.run(manual_url="http://new/y.pdf")

    assert not r.get("skipped"), r
    assert len(sink.fake.calls) == 1
    assert sink.fake.calls[0]["manual_url"] == "http://new/y.pdf"
    row = _get(db, iid)
    # 采集链里 manual 排第一位（cached_url 只是后备），落库的 url 能证明是谁赢的
    assert row["pdf_url"] == "http://new/y.pdf", row["pdf_url"]
    assert row["status"] == "downloading"


def test_f5b_force_still_forces_redownload(sink):
    """F5 附：force=True 与 manual_url 同义。"""
    db = sink.env.db
    _mk(db, status="done", pdf_path=str(sink.fake.pdf), pdf_url="http://old/x.pdf")

    r = sink.run(force=True)

    assert not r.get("skipped"), r
    assert len(sink.fake.calls) == 1


# ------------------------------------------------------------------ F6
def test_f6_concurrent_duplicate_delivery_downloads_once(sink):
    """F6（关键）：两个相同任务并发投递 —— 只下载一次，状态不被覆盖。

    两个线程各自持有独立的 sqlite 连接（db 是线程局部），同时在同一个
    时间窗里读到同一条 item。串行跑两次是测不出来的。
    """
    db = sink.env.db
    sink.fake.delay = 0.30                      # 撑开窗口：让两边都进得去
    iid = _mk(db, status="pending")

    barrier = threading.Barrier(2)
    out: list[dict] = []
    err: list[BaseException] = []
    lock = threading.Lock()

    def work():
        try:
            barrier.wait(timeout=10)
            r = sink.run()
            with lock:
                out.append(r)
        except BaseException as e:                          # noqa: BLE001
            with lock:
                err.append(e)

    ts = [threading.Thread(target=work, name=f"dup{i}") for i in range(2)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(timeout=30)

    assert not err, f"并发投递抛异常：{err!r}"
    assert len(out) == 2
    assert len(sink.fake.calls) == 1, \
        f"并发重复投递下载了 {len(sink.fake.calls)} 次，只允许 1 次"
    skipped = [r for r in out if r.get("skipped")]
    done = [r for r in out if not r.get("skipped")]
    assert len(done) == 1 and len(skipped) == 1, out
    assert skipped[0].get("reason") in {"already_running", "already_parsed"}, skipped
    assert len(sink.env.submits) == 1, "只有拿到执行权的那次才该往下游投"
    assert _get(db, iid)["status"] == "downloading"


def test_f6b_concurrent_from_done_state_downloads_zero(sink):
    """F6 附：从 done 并发的两次投递，一次都不该下载。"""
    db = sink.env.db
    _mk(db, status="done", pdf_path=str(sink.fake.pdf), pdf_url="http://example.com/ds.pdf")
    barrier = threading.Barrier(2)
    out: list[dict] = []
    lock = threading.Lock()

    def work():
        barrier.wait(timeout=10)
        r = sink.run()
        with lock:
            out.append(r)

    ts = [threading.Thread(target=work) for _ in range(2)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(timeout=30)

    assert sink.fake.calls == []
    assert all(r.get("skipped") for r in out), out


# ------------------------------------------------------------------ F7
def test_f7_exception_in_download_is_retryable(sink):
    """F7：下载中异常 → failed（不是永久中间态），重投能恢复。"""
    db = sink.env.db
    iid = _mk(db, status="pending")
    sink.fake.boom = RuntimeError("connection reset")

    r = sink.run()
    assert not r.get("ok")
    assert _get(db, iid)["status"] == "failed"

    sink.fake.boom = None
    r2 = sink.run()
    assert r2.get("ok") and not r2.get("skipped"), r2
    assert _get(db, iid)["status"] == "downloading"
    assert len(sink.fake.calls) == 2


def test_f7b_stuck_inflight_state_is_skipped_then_reclaimable_when_stale(sink):
    """F7 附：worker 被杀留下的中间态 —— 新鲜时被挡，租约过期后可重领。

    既不把「有人正在下」误判成重复（会双下），也不把残留态变成永久死锁
    （15 分钟后 / 显式重跑时可以重新领取）。
    """
    db = sink.env.db
    iid = _mk(db, status="downloading")

    r = sink.run()
    assert r.get("skipped") and r.get("reason") == "already_running", r
    assert sink.fake.calls == [], "在跑的任务不该被重复投递抢走"
    assert _get(db, iid)["status"] == "downloading"

    # 模拟租约过期：把 updated_at 拨回两小时前
    db.x("UPDATE item SET updated_at=? WHERE id=?",
         ("2020-01-01T00:00:00+00:00", iid))
    r2 = sink.run()
    assert not r2.get("skipped"), f"租约过期后应该能重新领取：{r2}"
    assert len(sink.fake.calls) == 1


def test_f7c_force_can_reclaim_fresh_inflight_state(sink):
    """F7 附：人工强制重跑是显式覆盖 —— 不被租约挡住（否则点了没反应）。"""
    db = sink.env.db
    iid = _mk(db, status="downloading")

    r = sink.run(force=True)

    assert not r.get("skipped"), r
    assert len(sink.fake.calls) == 1
    assert _get(db, iid)["status"] == "downloading"


# ------------------------------------------------------------------ F8
def test_f8_legacy_parse_item_entry_still_runs_the_chain(env, monkeypatch):
    """F8：旧全链路入口仍能接单，语义不变。"""
    db = env.db
    iid = _mk(db, status="pending")
    seen: list[dict] = []
    monkeypatch.setattr(env.T.pipeline, "run_item",
                        lambda item, **kw: (seen.append(dict(item)) or
                                            {"ok": True, "legacy": True}))

    r = env.T.parse_item("LM317")

    assert r == {"ok": True, "legacy": True}
    assert len(seen) == 1 and seen[0]["id"] == iid
    assert _get(db, iid)  # 行还在，没被异常处理器打成 failed


def test_f8b_legacy_entry_does_not_downgrade_done(env, sink):
    """F8：旧入口重复投递 done 的件 —— 不崩、不降级。

    修复前这条路更糟：`touch_status("queued")` 先把 done 踩掉，然后
    `run_item` 拿到 skipped 结果去取 `r["pdf"]` → KeyError → 被 except
    兜底写成 `failed`。明明是已交付的货，显示成失败。
    """
    db = env.db
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf),
              pdf_url="http://example.com/ds.pdf")
    before = _get(db, iid)

    r = env.T.parse_item("LM317")

    assert r.get("ok") and r.get("skipped"), r
    row = _get(db, iid)
    assert row["status"] == "done", f"旧入口把 done 改成了 {row['status']}"
    assert row["updated_at"] == before["updated_at"]
    assert sink.fake.calls == []


def test_run_item_skip_result_does_not_explode(env, sink):
    """`run_item` 收到 skipped 结果时必须原样返回，不能去取 `r["pdf"]`。"""
    db = env.db
    iid = _mk(db, status="done", pdf_path=str(sink.fake.pdf),
              pdf_url="http://example.com/ds.pdf")
    called: list[int] = []

    monkey = pytest.MonkeyPatch()
    try:
        monkey.setattr(env.pl, "llm_stage", lambda *a, **k: called.append(1) or {"ok": True})
        item = db.q1("SELECT * FROM item WHERE id=?", (iid,))
        r = env.pl.run_item(item)
    finally:
        monkey.undo()

    assert r.get("skipped"), r
    assert called == [], "跳过时不该进 LLM 段"


# ------------------------------------------------------------------ 机制守卫
def test_fetch_item_no_longer_writes_queued_before_stage(env):
    """静态守卫：`fetch_item` 函数体里不许再出现任何 `queued` 写入。

    这条守护的是"顺序"本身 —— 只要有人在 `fetch_stage` 之前再插一次状态写，
    done 就会被踩掉，F2/F3 会重新变成"第二次跳过但降级、第三次重下"。
    """
    src = inspect.getsource(env.T.fetch_item)
    body = "\n".join(ln for ln in src.splitlines() if not ln.strip().startswith("#"))
    assert "queued" not in body, "fetch_item 又在阶段函数之前改状态了：\n" + body


def test_x_count_returns_rowcount_not_lastrowid(env):
    """`x_count` 必须返回受影响行数（CAS 的判据），不能被 lastrowid 顶掉。"""
    db = env.db
    iid = _mk(db, status="pending")
    sql = "UPDATE item SET status='resolving' WHERE id=? AND status=?"
    assert db.x_count(sql, (iid, "pending")) == 1
    assert db.x_count(sql, (iid, "pending")) == 0, "第二次同条件更新应该抢不到"
    assert db.x_count("UPDATE item SET status='x' WHERE id=?", (999999,)) == 0
