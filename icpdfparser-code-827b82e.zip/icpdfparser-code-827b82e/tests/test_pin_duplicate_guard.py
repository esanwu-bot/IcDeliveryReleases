#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""D4 回归：编号连续不等于引脚集合正确，重名/总数必须过闸。

2026-11-03 服务器同构复跑实测（`docs/qc/phase171/g1_server/s1.json`）：
LM317 模型稿给了 `1 ADJUST / 2 OUTPUT / 3 INPUT / 4 OUTPUT` —— 编号 1..4 连续，
旧 `_pins_complete` 判「完整」直接保留，`kept=4`；而真实脚表是 3 脚，
确定性侧明明抽到了 3 条（`det_pins=3`）却没有纠正。

旧判据只回答「有没有缺号」，不回答「有没有多编」。本文件锁住三个方向：
缺号（G2 已有）、多编重名（D4 本次）、总数不一致留痕（不盲动，防 G2 复发）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                   # noqa: E402

LM317 = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"
LM358 = ROOT / "data" / "pdfs" / "LM358__lm358.pdf"

LM317_SERVER_MODEL_BUG = [
    {"pin": "1", "name": "ADJUST", "description": "Output voltage adjustment pin."},
    {"pin": "2", "name": "OUTPUT", "description": "Output voltage pin."},
    {"pin": "3", "name": "INPUT", "description": "Input voltage pin."},
    {"pin": "4", "name": "OUTPUT", "description": "Output voltage pin."},   # ← 服务器实跑多出来的
]
LM317_TRUTH = [
    {"pin": "1", "name": "ADJUST", "description": "Adjust"},
    {"pin": "2", "name": "OUTPUT", "description": "Output"},
    {"pin": "3", "name": "INPUT", "description": "Input"},
]


def _det(names, first_pin=1):
    return [{"pin": str(first_pin + i), "name": n, "description": "", "page": 1}
            for i, n in enumerate(names)]


# ─────────────────────────────────────────────────────────────────────
# 1. 判据本身（纯函数）
# ─────────────────────────────────────────────────────────────────────

def test_duplicate_name_with_enough_det_pins_replaces():
    """LM317 服务器实跑形态：编号连续 + OUTPUT 重复 + 确定性侧 3 条对得上账 → 替换。"""
    g = DE._pin_gate(LM317_SERVER_MODEL_BUG, _det(["ADJUST", "OUTPUT", "INPUT"]))
    assert g["replace"] is True
    assert g["reason"] == "model_pins_duplicate_name"
    assert g["dup_names"] == ["OUTPUT"]


def test_clean_model_rows_are_kept():
    g = DE._pin_gate(LM317_TRUTH, _det(["ADJUST", "OUTPUT", "INPUT"]))
    assert g["replace"] is False
    assert g["reason"] == "model_pins_complete"


def test_repeatable_names_do_not_trigger_replacement():
    """多 GND / 多 NC 是真实器件形态，不是模型多编。

    真实样本：LM358 类双运放的 `GND`、BGA 的 `NC`。没有重复名嫌疑 → 不替换。
    """
    rows = _det(["VCC", "GND", "IN", "GND", "OUT"])
    g = DE._pin_gate(rows, [])
    assert g["replace"] is False
    assert g["dup_names"] == []


def test_det_side_must_be_complete_to_replace_on_duplicates():
    """确定性侧自己编号不完整时，不拿它去覆盖 —— G2 就是这么炸出来的。"""
    det_bad = [{"pin": "2", "name": "ADJUST"}, {"pin": "5", "name": "INPUT"}]
    g = DE._pin_gate(LM317_SERVER_MODEL_BUG, det_bad)
    assert g["replace"] is False, "确定性侧乱号时覆盖等于二次降级"


def test_det_side_must_account_for_the_extra_rows():
    """确定性 3 条对不上 4 条里除重复外的 4 个位置 → 不替换，只留痕。

    防误伤：模型 8 脚带一个可疑重复名、确定性只抽到 5 条的场景，
    覆盖会丢真脚。此时宁可不换，交人工。
    """
    rows = _det(["A", "B", "C", "B", "D", "E", "F", "G"])   # 8 条，B 重复 → dup_extra=1
    det5 = _det(["A", "B", "C", "D", "E"])                   # 确定性漏抽，5 条 < 7
    g = DE._pin_gate(rows, det5)
    assert g["replace"] is False
    assert g["dup_names"] == ["B"]
    assert g["count_mismatch"] is True


def test_count_mismatch_without_duplicates_only_records():
    """总数对不上但编号连续、无重名：不换数据，但必须留痕，不许静默通过。"""
    rows = _det(["A", "B", "C", "D", "E"])                   # 模型 5 条（编号完整）
    det4 = _det(["A", "B", "C", "D"])                         # 确定性 4 条
    g = DE._pin_gate(rows, det4)
    assert g["replace"] is False
    assert g["count_mismatch"] is True
    assert g["reason"] == "model_pins_count_mismatch"


def test_incomplete_numbering_still_replaces_as_before():
    """G2 方向不许回退：编号乱（缺号/跳号）+ 确定性非空 → `_pin_gate` 判替换。

    （「确定性比模型多」的 G2 规则在 apply_deterministic 调用点另行触发，
    LM358 8 脚集成用例锁的就是它。）
    """
    rows = [{"pin": "2", "name": "OUT2"}, {"pin": "5", "name": "OUT1"}]   # 乱号
    g = DE._pin_gate(rows, _det(["OUT1", "OUT2", "V+", "V-"]))
    assert g["replace"] is True
    assert g["reason"] == "model_pins_incomplete_numbering"


def test_det_more_than_model_is_the_g2_rule_not_the_gate():
    """编号完整、无重名、只是确定性侧更多 → 由 G2 规则替换，`_pin_gate` 不背书。"""
    rows = _det(["OUT1", "OUT2"])
    g = DE._pin_gate(rows, _det(["OUT1", "OUT2", "V+", "V-"]))
    assert g["replace"] is False
    assert g["count_mismatch"] is True


def test_dash_variants_of_the_same_name_count_as_duplicates():
    """`V–` 与 `V-` 是同一个名字：键归一化必须吃掉 Unicode 破折号。"""
    rows = [{"pin": "1", "name": "V–"}, {"pin": "2", "name": "V−"},
            {"pin": "3", "name": "OUT"}]
    g = DE._pin_gate(rows, _det(["V-", "OUT"]))
    assert g["dup_names"] == ["V-"]


# ─────────────────────────────────────────────────────────────────────
# 2. 真 PDF 集成：apply_deterministic 端到端
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not LM317.exists(), reason="缺少 LM317 原件")
def test_lm317_duplicate_output_row_is_corrected_on_real_pdf():
    """服务器实跑形态的 doc + 真 LM317 PDF → 必须收敛到 3 脚。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "LM317"},
           "pin_configuration": [dict(r) for r in LM317_SERVER_MODEL_BUG],
           "specs": {}}
    with pymupdf.open(str(LM317)) as fdoc:
        rep = DE.apply_deterministic(doc, fdoc)
    pins = doc["pin_configuration"]
    assert len(pins) == 3, f"实得 {len(pins)} 脚：{pins}"
    assert [p["name"] for p in pins] == ["ADJUST", "OUTPUT", "INPUT"]
    assert rep["pins"]["why"] == "model_pins_duplicate_name"
    assert rep["pins"]["to"] == 3


@pytest.mark.skipif(not LM317.exists(), reason="缺少 LM317 原件")
def test_lm317_clean_three_pins_unchanged_on_real_pdf():
    """干净的 3 脚稿不许被这次改动误伤。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "LM317"},
           "pin_configuration": [dict(r) for r in LM317_TRUTH],
           "specs": {}}
    with pymupdf.open(str(LM317)) as fdoc:
        rep = DE.apply_deterministic(doc, fdoc)
    assert [p["name"] for p in doc["pin_configuration"]] == ["ADJUST", "OUTPUT", "INPUT"]
    assert rep["pins"]["skipped"] == "model_pins_complete"


@pytest.mark.skipif(not LM358.exists(), reason="缺少 LM358 原件")
def test_lm358_regression_still_eight_pins():
    """G2 的 LM358 8 脚不许被这次改动打回 2 脚。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "LM358"},
           "pin_configuration": [{"pin": "1", "name": "OUT1"}],   # 模型残稿：2→8 的起点
           "specs": {}}
    with pymupdf.open(str(LM358)) as fdoc:
        DE.apply_deterministic(doc, fdoc)
    assert len(doc["pin_configuration"]) == 8
