#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""提示词 v3 三条安全规则的守卫用例。

三条规则各自对应一条**已取证**的事故（证据见
`qc/evidence_20261031/二次确认_取证报告_ADC12DJ5200SE.md` §1）：

| 规则 | 事故 |
|---|---|
| 不得用 TYP/NOM 顶替 MIN | VCMI `0/0.3/0.55` → 写成 `0.3 to 0.55`；VID `0.4/1.0/2.0` → 写成 `1.0 to 2.0` |
| 条件与数值同源 | `-1.25 dBm`（p1 Features）+ `fIN=4.5GHz, FS_RANGE=0xA000`（p10，对应 **-1.5 dBm**） |
| Abs Max 与 electrical 分家 | `+26.25 dBm` 是 `PMAX(INx)` 应力值（Zs=50Ω, up to 21 days），被当成工作参数 |

这些断言很"笨"，但价值在于**防止有人把默认版本悄悄改回 v1**——v1 时
`ELEC_RULES` 是空串，三条规则一条都不进 prompt，事故会原样复发。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import parse_datasheets as P                                  # noqa: E402


def test_default_prompt_version_is_v3():
    assert P.PROMPT_VERSION == "v3", f"默认版本是 {P.PROMPT_VERSION}，安全规则不会进 prompt"


def test_min_never_replaced_by_typ():
    assert "顶替 MIN" in P.SYSTEM_PROMPT
    assert "MIN 与 MAX 都有值" in P.SYSTEM_PROMPT


def test_condition_must_be_same_row():
    assert "同源（同一行）" in P.SYSTEM_PROMPT
    assert "严禁把 Features" in P.SYSTEM_PROMPT


def test_abs_max_not_in_electrical():
    assert "absolute_max 只收 Absolute Maximum Ratings" in P.SYSTEM_PROMPT
    assert "严禁把应力额定值" in P.SYSTEM_PROMPT


def test_v3_does_not_inherit_v2_pin_column_rule():
    """v3 刻意不带 v2 的「多封装选列」——那是 v2 门禁栽掉的那一块。"""
    assert "取错列会表现为脚号超出" not in P.ELEC_RULES_V3


def test_v1_is_still_available_for_rollback():
    """回滚通道必须在：ICPDF_PROMPT_VERSION=v1 时规则为空。"""
    assert P.ELEC_RULES_V1 == ""
