# -*- coding: utf-8 -*-
"""GitHub → 本地 Issue 同步：文件名、渲染、增量、错误分类。

这组用例守的是「脚本跑完之后，本地 Markdown 就是 issue 的完整镜像」这件事。
容易糊弄过去的几处，逐条钉死：

1. **PR 混进 issues**。GitHub 的 `/issues` 端点**同时返回 Pull Request**，
   不过滤的话本地会凭空多出几个 `GH-*` 文件，且正文是 PR 描述。
2. **标题变了旧文件还在**。文件名带标题 slug，issue 改标题后新文件生成、
   旧文件残留，同一个编号出现两份内容不同的记录。
3. **每次都重写**。同步时间戳写进正文的话，内容没变也天天产生 git diff。
4. **私有仓库 404 被当成「仓库不存在」**。GitHub 对无权限的私有仓库返回
   404 而不是 403，直接照抄状态码会让人去查一个根本不存在的拼写错误。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.integrations import github_issues as GI      # noqa: E402


# ─────────────────────────────────────────────────────────────────────
# 假 GitHub：只实现 get，按 URL 分派
# ─────────────────────────────────────────────────────────────────────

class FakeResp:
    def __init__(self, status: int = 200, payload=None, headers: dict | None = None):
        self.status_code = status
        self._payload = [] if payload is None else payload
        self.headers = headers or {}
        self.text = json.dumps(self._payload, ensure_ascii=False)

    def json(self):
        return self._payload


class FakeSession:
    """把请求交给 handler(url, params) -> FakeResp，并记下所有调用。"""

    def __init__(self, handler):
        self.handler = handler
        self.calls: list[dict] = []

    def get(self, url, params=None, headers=None, timeout=None):
        p = dict(params or {})
        self.calls.append({"url": url, "params": p, "headers": headers or {}})
        return self.handler(url, p)


def _issue(number: int, title: str, body: str = "正文", labels=("qa-audit",),
           state: str = "open", updated: str = "2026-11-03T04:30:00Z",
           user: str = "dsh-bot") -> dict:
    return {
        "number": number,
        "title": title,
        "body": body,
        "state": state,
        "labels": [{"name": n} for n in labels],
        "user": {"login": user},
        "created_at": "2026-11-03T02:11:00Z",
        "updated_at": updated,
        "html_url": f"https://github.com/o/r/issues/{number}",
    }


def _comment(cid: int, body: str, user: str = "alice",
             created: str = "2026-11-03T03:00:00Z") -> dict:
    return {"id": cid, "body": body, "user": {"login": user}, "created_at": created}


def _route(issues, comments=None, *, per_page_cap: int = 100):
    """issues / comments 两个端点。comments 以 issue 编号为键。"""
    comments = comments or {}

    def handler(url, params):
        if url.endswith("/comments"):
            num = int(url.rstrip("/").split("/")[-2])
            return FakeResp(200, comments.get(num, []))
        page = int(params.get("page", 1))
        start = (page - 1) * per_page_cap
        chunk = list(issues)[start:start + per_page_cap]
        return FakeResp(200, chunk)

    return handler


# ─────────────────────────────────────────────────────────────────────
# 1. 文件名
# ─────────────────────────────────────────────────────────────────────

def test_slug_drops_the_leading_tag_block():
    """`[质审/P0] LM317 · 多列塌缩` → `LM317-多列塌缩`。

    工单标题前面常带 `[质审/P0]` 这类分类标签，它属于标签不属于标题；
    带进文件名会变成 `GH-14-质审-P0-LM317-…`，在目录里一列全是 `质审` 开头。
    """
    assert GI.issue_slug("[质审/P0] LM317 · 多列塌缩") == "LM317-多列塌缩"
    assert GI.issue_slug("[qa-audit] [P0] LM317 多列塌缩") == "LM317-多列塌缩"


def test_slug_keeps_chinese_and_squashes_illegal_chars():
    """中文原样保留；路径非法字符统一变 `-`，且不出现连续或首尾的 `-`。"""
    assert GI.issue_slug("LM317: 多列/塌缩?") == "LM317-多列-塌缩"
    assert GI.issue_slug("A   B") == "A-B"
    assert GI.issue_slug("---") == "issue"


def test_filename_shape_matches_the_example():
    assert GI.issue_filename(14, "LM317 多列塌缩") == "GH-14-LM317-多列塌缩.md"


def test_slug_is_length_capped_for_windows_paths():
    """Windows 路径总长 260，文件名不截断迟早撞墙。"""
    name = GI.issue_filename(14, "很长的标题" * 40)
    assert len(name) <= GI.SLUG_MAX + len("GH-14-.md")


# ─────────────────────────────────────────────────────────────────────
# 2. 渲染
# ─────────────────────────────────────────────────────────────────────

def test_rendered_markdown_carries_everything_needed():
    """标题 / 编号 / 标签 / 正文 / 评论，一个都不能少 —— 少一个就得回 GitHub 查。"""
    it = _issue(14, "LM317 多列塌缩", body="## 现象\n\nRθJC 只抽到一列")
    md = GI.render_issue_md(it, [_comment(1, "确认是塌缩，已修")])

    assert "GH-14" in md
    assert "LM317 多列塌缩" in md
    assert "#14" in md
    assert "qa-audit" in md
    assert "RθJC 只抽到一列" in md
    assert "确认是塌缩，已修" in md
    assert "alice" in md
    # 机器标记：靠它把文件反查回编号，不依赖文件名解析
    assert f"<!-- {GI.SYNC_MARKER}: 14 -->" in md


def test_rendered_markdown_does_not_embed_a_sync_timestamp():
    """正文里不能有「本次同步时间」。

    有它的话，内容一个字没变也每次同步都产生 diff —— 增量判断立刻失效，
    而且 git log 会被「同步于 XX:XX」刷满。同步时间只出现在 `_index.md`。
    """
    it = _issue(14, "LM317 多列塌缩")
    md = GI.render_issue_md(it, [])
    assert "gh-sync-at" not in md
    # 但要保留源数据的更新时间，读者才知道这页有多旧
    assert "2026-11-03 04:30 UTC" in md


def test_rendered_markdown_says_do_not_edit_by_hand():
    """落盘文件是镜像，手改会被下次同步覆盖 —— 必须在文件里写清楚。"""
    md = GI.render_issue_md(_issue(15, "X"), [])
    assert "不要手工编辑" in md or "不要手改" in md


def test_empty_body_and_no_comments_render_cleanly():
    md = GI.render_issue_md(_issue(16, "X", body=""), [])
    assert "（正文为空）" in md
    assert "评论" in md          # 明确写 0 条，而不是整节省略


# ─────────────────────────────────────────────────────────────────────
# 3. 拉取：PR 过滤与分页
# ─────────────────────────────────────────────────────────────────────

def test_pull_requests_are_filtered_out(tmp_path):
    """`/issues` 会同时返回 PR —— 不过滤就会凭空多出几个 `GH-*` 文件。"""
    pr = _issue(99, "PR: 修一下")
    pr["pull_request"] = {"url": "https://api.github.com/..."}
    ses = FakeSession(_route([_issue(14, "LM317 多列塌缩"), pr]))

    res = GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")

    assert res["fetched"] == 1
    names = sorted(p.name for p in tmp_path.glob("GH-*.md"))
    assert names == ["GH-14-LM317-多列塌缩.md"]


def test_pagination_is_followed_until_a_short_page(tmp_path):
    """分页没跟到位，第 101 张单就永远同步不下来。"""
    items = [_issue(n, f"件{n}") for n in range(1, 151)]     # 150 条 → 2 页
    ses = FakeSession(_route(items))

    res = GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")

    assert res["fetched"] == 150
    pages = {c["params"].get("page") for c in ses.calls if "comments" not in c["url"]}
    assert pages == {1, 2}           # 第 1 页满 100 页 → 再探；第 2 页 50 条不满 → 停
    assert len(list(tmp_path.glob("GH-*.md"))) == 150


def test_comments_are_pulled_for_each_issue(tmp_path):
    """「人工回复更新了也要同步最新」—— 回复在 comments 里，不在 body 里。"""
    ses = FakeSession(_route(
        [_issue(14, "LM317 多列塌缩")],
        {14: [_comment(1, "已确认，按 A2 方案处理"), _comment(2, "补充：还影响 3656AG")]},
    ))
    res = GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")

    md = (tmp_path / "GH-14-LM317-多列塌缩.md").read_text(encoding="utf-8")
    assert "已确认，按 A2 方案处理" in md
    assert "还影响 3656AG" in md
    assert res["written"][0]["comments"] == 2


# ─────────────────────────────────────────────────────────────────────
# 4. 增量与覆盖
# ─────────────────────────────────────────────────────────────────────

def test_sync_overwrites_and_removes_the_stale_filename(tmp_path):
    """issue 改标题后，旧文件名必须删掉。

    文件名带标题 slug，改标题 = 换文件名。只写新文件不删旧的，同一编号就在
    目录里留两份内容不同的记录，读的人不知道该信哪个。
    """
    GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "旧标题")])),
                            out_dir=tmp_path, repo="o/r", token="t")
    assert (tmp_path / "GH-14-旧标题.md").exists()

    res = GI.sync_issues_to_local(
        session=FakeSession(_route([_issue(14, "LM317 多列塌缩")])),
        out_dir=tmp_path, repo="o/r", token="t")

    names = sorted(p.name for p in tmp_path.glob("GH-14-*.md"))
    assert names == ["GH-14-LM317-多列塌缩.md"]
    assert res["written"][0]["action"] == "created"


def test_unchanged_content_is_not_rewritten(tmp_path):
    """内容没变就不碰文件 —— 否则每次同步都产生一次无意义的 mtime/git 变更。"""
    handler = _route([_issue(14, "LM317 多列塌缩")])
    GI.sync_issues_to_local(session=FakeSession(handler), out_dir=tmp_path,
                            repo="o/r", token="t")
    p = tmp_path / "GH-14-LM317-多列塌缩.md"
    before = p.stat().st_mtime_ns

    res = GI.sync_issues_to_local(session=FakeSession(handler), out_dir=tmp_path,
                                  repo="o/r", token="t")

    assert res["written"] == []
    assert res["unchanged"] == ["GH-14-LM317-多列塌缩.md"]
    assert p.stat().st_mtime_ns == before


def test_comment_edits_do_not_leave_a_stale_copy(tmp_path):
    """同一条评论被编辑过（内容变了、id 不变）也要刷新到最新。"""
    GI.sync_issues_to_local(
        session=FakeSession(_route([_issue(14, "X")], {14: [_comment(1, "旧回复")]})),
        out_dir=tmp_path, repo="o/r", token="t")
    GI.sync_issues_to_local(
        session=FakeSession(_route([_issue(14, "X")], {14: [_comment(1, "改过的新回复")]})),
        out_dir=tmp_path, repo="o/r", token="t")

    md = (tmp_path / "GH-14-X.md").read_text(encoding="utf-8")
    assert "改过的新回复" in md
    assert "旧回复" not in md


# ─────────────────────────────────────────────────────────────────────
# 5. 本地残留（已关闭 / 已删标签）
# ─────────────────────────────────────────────────────────────────────

def test_locally_present_but_not_returned_is_reported_not_deleted(tmp_path):
    """本地有、远端这次没返回的件：**报出来但不删**。

    远端没返回有两种原因：issue 关了，或者只是不再带 `qa-audit` 标签。
    后者仍然是有价值的记录，脚本没资格替人做删除决定 —— 交给人看到再处理。
    """
    GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "甲"), _issue(15, "乙")])),
                            out_dir=tmp_path, repo="o/r", token="t")

    res = GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "甲")])),
                                  out_dir=tmp_path, repo="o/r", token="t")

    assert res["stale"] == ["GH-15-乙.md"]
    assert (tmp_path / "GH-15-乙.md").exists()      # 没被删


def test_dry_run_writes_nothing(tmp_path):
    res = GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "甲")])),
                                  out_dir=tmp_path, repo="o/r", token="t",
                                  dry_run=True)
    assert list(tmp_path.glob("*.md")) == []
    assert res["planned"]


# ─────────────────────────────────────────────────────────────────────
# 6. 索引
# ─────────────────────────────────────────────────────────────────────

def test_index_lists_every_issue_with_state_and_link(tmp_path):
    """`_index.md` 是给人一眼看全的入口；下划线开头，不和 `GH-*` 混在一起。"""
    GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "甲"), _issue(15, "乙")])),
                            out_dir=tmp_path, repo="o/r", token="t")
    idx = (tmp_path / GI.INDEX_NAME).read_text(encoding="utf-8")

    assert "GH-14" in idx and "GH-15" in idx
    assert "https://github.com/o/r/issues/14" in idx
    assert "open" in idx.lower()
    assert not (tmp_path / GI.INDEX_NAME).name.startswith("GH-")


def test_index_rows_are_ordered_by_number_not_by_api_order(tmp_path):
    """索引顺序按编号升序，不跟 API 的 `updated` 倒序。

    API 按「最近更新」倒序返回，直接照抄的话：昨天回复了 #14，今天 #15 就排到
    后面去了 —— 每次同步顺序都在变，diff 里全是无意义的行移动。
    """
    GI.sync_issues_to_local(
        session=FakeSession(_route([_issue(15, "乙"), _issue(14, "甲")])),
        out_dir=tmp_path, repo="o/r", token="t")
    idx = (tmp_path / GI.INDEX_NAME).read_text(encoding="utf-8")

    assert idx.index("#14") < idx.index("#15")


def test_rendered_files_end_with_a_newline(tmp_path):
    """文件必须以 `\\n` 结尾，否则 git 标 "No newline at end of file"。"""
    GI.sync_issues_to_local(session=FakeSession(_route([_issue(14, "甲")])),
                            out_dir=tmp_path, repo="o/r", token="t")
    raw = (tmp_path / "GH-14-甲.md").read_text(encoding="utf-8")

    assert raw.endswith("\n")
    assert not raw.endswith("\n\n")      # 也别空一行出来


# ─────────────────────────────────────────────────────────────────────
# 7. 错误分类：状态码不能照抄给用户
# ─────────────────────────────────────────────────────────────────────

def test_404_on_a_private_repo_says_permission_not_typo(tmp_path):
    """GitHub 对无权限的私有仓库返回 **404**，照抄「仓库不存在」会让人去查拼写。"""
    ses = FakeSession(lambda url, p: FakeResp(404, {"message": "Not Found"}))
    with pytest.raises(GI.SyncError) as ei:
        GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")
    msg = str(ei.value)
    assert "404" in msg
    assert "权限" in msg or "私有" in msg
    assert "repo" in msg.lower()


def test_401_says_token_invalid(tmp_path):
    ses = FakeSession(lambda url, p: FakeResp(401, {"message": "Bad credentials"}))
    with pytest.raises(GI.SyncError) as ei:
        GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")
    assert "token" in str(ei.value).lower()


def test_403_rate_limit_is_distinguished_from_permission(tmp_path):
    """403 有两种：限流（x-ratelimit-remaining: 0）与权限不足。混为一谈会误判。"""
    ses = FakeSession(lambda url, p: FakeResp(
        403, {"message": "API rate limit exceeded"},
        {"x-ratelimit-remaining": "0", "x-ratelimit-reset": "1793000000"}))
    with pytest.raises(GI.SyncError) as ei:
        GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="t")
    assert "限流" in str(ei.value)


def test_missing_repo_or_token_is_refused_before_any_request(tmp_path):
    """配置缺失要在发请求之前就拒绝 —— 空仓库名会打到一个 404 让人查半天。"""
    ses = FakeSession(lambda url, p: FakeResp(200, []))
    with pytest.raises(GI.SyncError):
        GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="", token="t")
    with pytest.raises(GI.SyncError):
        GI.sync_issues_to_local(session=ses, out_dir=tmp_path, repo="o/r", token="")
    assert ses.calls == []


# ─────────────────────────────────────────────────────────────────────
# 8. CLI
# ─────────────────────────────────────────────────────────────────────

def test_cli_sync_dispatches_without_touching_the_issue_json_cli(tmp_path, monkeypatch):
    """`python -m app.integrations.github_issues sync` 走同步分支。

    原来的 CLI 是「第一位置参数 = issue JSON 文件」，加子命令不能把它顶掉。
    """
    seen = {}

    def fake_sync(**kw):
        seen.update(kw)
        return {"fetched": 2, "written": [{"file": "GH-14-X.md", "action": "created"}],
                "unchanged": [], "stale": [], "planned": [], "index": "_index.md"}

    monkeypatch.setattr(GI, "sync_issues_to_local", fake_sync)
    rc = GI.main(["sync", "--out", str(tmp_path), "--repo", "o/r", "--token", "t"])

    assert rc == 0
    assert seen["out_dir"] == str(tmp_path)
    assert seen["repo"] == "o/r"


def test_cli_reports_failure_as_nonzero(monkeypatch, tmp_path):
    def boom(**kw):
        raise GI.SyncError("404 仓库不存在或无权访问")

    monkeypatch.setattr(GI, "sync_issues_to_local", boom)
    rc = GI.main(["sync", "--out", str(tmp_path), "--repo", "o/r", "--token", "t"])
    assert rc != 0
