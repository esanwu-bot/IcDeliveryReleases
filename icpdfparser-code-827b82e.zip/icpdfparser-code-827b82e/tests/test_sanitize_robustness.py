# -*- coding: utf-8 -*-
"""`'str'.get` 崩溃的容器级防御（2026-11-02 第三轮，P0 阻断）。

**事故**：20 件压测 4 件 `AttributeError: 'str' object has no attribute 'get'`
（`ADC08B200EB` / `ADC128D818EB_NOPB` / `CDC6CE025000ADLER` / `CDC6CE025000ADLYR`）。
trace 单跑 `ADC08B200EB` **未复现**（flash 输出非确定性，那次退化成 `empty_electrical`），
改以**静态 probe** 定位：`qc/deterministic_extract.py::core_digest` 对
`specs.electrical` 元素直接 `e.get("name")`，没有 `isinstance(dict)` 守卫。

**sanitize 的边界（本地实测）**：

| 输入 | 旧行为 | 新行为 |
|---|---|---|
| `specs.electrical = ["garbage", True, None, {...}]` | ✅ 剔除非 dict | 不变（本轮之前已覆盖） |
| `specs.electrical = "garbage"`（容器本身是 str/bool/数字/对象） | ❌ 原样保留 → 下游迭代字符/key → `.get` 崩 | **置 `[]`**（`None` 保持 `None`） |
| 重试路径 `doc = parse_json_loose(...)` | ❌ **没有再 sanitize** | 统一走 `parse_doc_clean()` |
| `specs.onboard_device_specs.electrical`（隔离桶） | ❌ 未清 | 与主表同口径清理 |

另：`core_digest` 返回的是**指纹字典**，所以"返回 str 且长度 ≥32"这条断言落在
`pins / thermal / esd / vcmi_vid` 各自的 `sha256` 上（64 位十六进制）。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import parse_datasheets as PD                                    # noqa: E402
from qc import deterministic_extract as DE                       # noqa: E402

#: 形态 A：容器本身被写成字符串
FORM_A = {"specs": {"electrical": "garbage"}, "basic_info": {"mpn": "X"}}
#: 形态 B：容器是数组，但里面混了脏元素
FORM_B = {"specs": {"electrical": ["garbage", True, None, {"name": "x", "value": "1"}]},
          "basic_info": {"mpn": "X"}}
#: 形态 C：隔离桶同样是脏的
FORM_C = {"specs": {"electrical": [{"name": "INL", "value": "1"}],
                    "absolute_max": ["x", 1, None, {"symbol": "VIN"}],
                    "ac_performance": ["y", None],
                    "onboard_device_specs": {"electrical": ["garbage", {"name": "SNR"}],
                                             "absolute_max": "garbage"},
                    "unresolved_specs": {"electrical": [True]}},
          "pin_configuration": ["p", None, {"pin": "1"}],
          "basic_info": {"mpn": "X"}}


def _assert_digest_ok(doc):
    """指纹的每个 sha256 都必须是 **str 且长度 ≥32**（不是"没抛异常"就算过）。"""
    d = DE.core_digest(doc)
    assert isinstance(d, dict), d
    for key in ("pins", "thermal", "esd", "vcmi_vid"):
        s = d[key]["sha256"]
        assert isinstance(s, str) and len(s) >= 32, (key, type(s), s)
    return d


# ── ① sanitize：形态 A / B ──
def test_form_a_container_str_becomes_empty_list():
    stats = PD.sanitize_doc(FORM_A)
    assert FORM_A["specs"]["electrical"] == [], FORM_A["specs"]["electrical"]
    assert stats.get("specs.electrical") == 1, stats


def test_form_b_dirty_elements_are_dropped():
    stats = PD.sanitize_doc(FORM_B)
    assert FORM_B["specs"]["electrical"] == [{"name": "x", "value": "1"}]
    assert stats.get("specs.electrical") == 3, stats


def test_form_c_isolation_buckets_are_cleaned():
    stats = PD.sanitize_doc(FORM_C)
    assert FORM_C["specs"]["absolute_max"] == [{"symbol": "VIN"}]
    assert FORM_C["specs"]["ac_performance"] == []
    assert FORM_C["specs"]["onboard_device_specs"]["electrical"] == [{"name": "SNR"}]
    assert FORM_C["specs"]["onboard_device_specs"]["absolute_max"] == []
    assert FORM_C["specs"]["unresolved_specs"]["electrical"] == []
    assert stats.get("specs.onboard_device_specs.absolute_max") == 1


@pytest.mark.parametrize("doc", [FORM_A, FORM_B, FORM_C])
def test_sanitized_doc_never_crashes_the_readers(doc):
    PD.sanitize_doc(doc)
    _assert_digest_ok(doc)
    DE.check_core(doc, {})
    DE.check_acceptance(doc, "ADC12DJ5200SE")
    DE.stamp_model_unverified(doc)


# ── ② 深层守卫：**不清洗**也要能活（防御纵深，别指望唯一入口永远被调用）──
@pytest.mark.parametrize("doc", [FORM_A, FORM_B, FORM_C])
def test_readers_survive_even_without_sanitize(doc):
    d = dict(doc)
    _assert_digest_ok(d)
    DE.check_core(d, {})
    DE.check_acceptance(d, "ADC12DJ5200SE")
    DE.stamp_model_unverified(d)


def test_dirty_siblings_do_not_change_the_clean_digest():
    """脏元素被跳过，干净部分的摘要必须**一字不变**（守卫不许把真行一起过滤掉）。"""
    clean = {"specs": {"electrical": [{"name": "Input common-mode voltage", "value": "0.9"}]},
             "basic_info": {}}
    dirty = {"specs": {"electrical": ["garbage",
                                      {"name": "Input common-mode voltage", "value": "0.9"},
                                      True]},
             "basic_info": {}}
    a = DE.core_digest(clean)["vcmi_vid"]
    b = DE.core_digest(dirty)["vcmi_vid"]
    assert a == b, (a, b)


def test_merge_input_limits_ignores_dirty_rows():
    sp = {"electrical": ["garbage", {"name": "X", "value": "1"}]}
    rep = DE._merge_input_limits(sp, [{
        "name": "Input common-mode voltage", "value": "0.9", "unit": "V",
        "condition": "", "min": None, "typ": 0.9, "max": None}])
    assert rep["removed"] == 0
    assert len(sp["electrical"]) == 2, sp["electrical"]


def test_validate_reports_dirty_elements_instead_of_crashing():
    """绕过 sanitize 的调用方：validate 必须报错（fail-closed），不许崩。"""
    doc = {"basic_info": {"mpn": "X", "manufacturer": "Y"},
           "specs": {"electrical": [{"name": "a"}, "garbage", {"name": "b"}]}}
    errs = PD.validate(doc)
    assert any("非对象元素" in e for e in errs), errs


# ── ③ retry 路径：解析完必须清洗 ──
def test_parse_doc_clean_sanitizes_retry_payload():
    doc, stats = PD.parse_doc_clean(
        '{"specs": {"electrical": ["garbage", true, null]}, "basic_info": {"mpn": "X"}}')
    assert isinstance(doc, dict)
    assert doc["specs"]["electrical"] == [], doc["specs"]["electrical"]
    assert stats.get("specs.electrical") == 3, stats


def test_parse_doc_clean_tolerates_non_object_root():
    doc, stats = PD.parse_doc_clean('"just a string"')
    assert doc == {}
    assert stats, "非对象根必须留痕"


def test_parse_doc_clean_keeps_clean_object_root():
    doc, stats = PD.parse_doc_clean(
        '{"specs": {"electrical": [{"name": "INL", "value": "1"}]}, "basic_info": {"mpn": "X"}}')
    assert len(doc["specs"]["electrical"]) == 1
    assert stats == {}


def test_huge_integer_payload_is_reported_as_invalid_json():
    """`json.loads` 的 >4300 位整数抛 `ValueError`（不是 JSONDecodeError）。

    实测 20 件压测 `DEM-DAI1804` 就死在这里：调用方只 `except JSONDecodeError`，
    接不住 → 整件判死。`parse_doc_clean` 负责把它翻译成 JSONDecodeError，
    让「截断/修复重试」链路接管。
    """
    import json as _json
    huge = '{"specs": {"electrical": [' + "1" * 5000 + "]}}"
    with pytest.raises(_json.JSONDecodeError):
        PD.parse_doc_clean(huge)


# ── ④ 重试稿不可用时不许顶掉原稿（ok→empty 的真因）──
def test_garbage_retry_must_not_replace_a_usable_doc():
    """红先：模型在修复轮返回裸 JSON 字符串（`sanitized_retry={"__root__": 1}`），
    `parse_doc_clean` 会给出 `{}`；若直接 `doc = 重试稿`，一份可用数据就被空卷顶掉
    —— 实测 `LM317 / LM358 / NE555 / CDC6CE040000ADLFR` 四件 ok→empty。"""
    good = {"specs": {"electrical": [{"name": "INL", "value": "1"}]},
            "basic_info": {"mpn": "X"}}
    assert PD.pick_retry_doc(good, {}) == good
    assert PD.pick_retry_doc(good, {"specs": {"electrical": []}}) == good
    assert PD.pick_retry_doc(good, {"specs": {"electrical": ["garbage"]}}) == good
    assert PD.pick_retry_doc(good, {"specs": {"electrical": "garbage"}}) == good


def test_usable_retry_still_wins():
    good = {"specs": {"electrical": [{"name": "INL", "value": "1"}]}}
    better = {"specs": {"electrical": [{"name": "INL", "value": "2"},
                                       {"name": "DNL", "value": "0.5"}]}}
    assert PD.pick_retry_doc(good, better) == better
