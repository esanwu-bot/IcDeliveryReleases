#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""融合列必须阻断（P0），不能只记一条 unresolved 就放行。

**取证**（`qc/evidence_20261031/table_audit_ADC12DJ5200SE.json`）：
ADC12DJ5200SE 的 p10 推荐工作条件表被 PyMuPDF 抽成

    header = ['', '', '', 'MIN', 'NOM', 'M', 'AX UNIT']      ← MAX 与 UNIT 并格
    row    = ['', '', 'CLK+ CLK–, SYSREF+ SYSREF–', '0 03 0\\n. .', '', '', '']
                                                     ↑ 0 / 0.3 / 0.55 挤成一格

`fused_cols()` 认出来了，但旧逻辑只 append 一条 `cell_unparsable_unresolved`
就 `continue` —— 18 条电气/绝对最大行**全部**走这条路，于是
`verification.spec_audit = "unresolved"`，等于闸门全程零判定、静默通过。

本案的教训不是"漏了一条规则"，而是**「读不出列」和「读出来发现是错的」被
当成了同一件事**。前者必须阻断：读不出就没人能保证它是对的。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import table_audit as T                                # noqa: E402


def _fused_table():
    """复刻 p10 那种竖线丢失的 ROC 表。"""
    header = ["", "", "", "MIN", "NOM", "M", "AX UNIT"]
    return {
        "page": 10, "ti": 0, "title": "Recommended Operating Conditions",
        "header": header, "hx": [0, 60, 120, 200, 260, 320, 360, 420],
        "rows": [
            header,
            ["VCMI", "Input common-mode voltage", "CLK+, CLK-, SYSREF+, SYSREF-",
             "0 03 0\n. .", "", "", "55 V\n55"],
            ["VA19", "analog 1.9-V supply", "", "18 19\n. .", "", "", "20\n.\n15 V\n15"],
        ],
        "split": False, "words_fixed": None, "xr": None,
    }


def _audit(name, value):
    tbl = _fused_table()
    entries = [{"name": name, "value": value, "unit": "V", "condition": ""}]
    return T.audit_electrical(entries, [tbl], "specs.electrical")


def test_fused_column_on_key_param_blocks():
    """关键参数（电压/温度/分辨率…）遇到融合列 → fused_column_blocking。"""
    finds = _audit("Input common-mode voltage", "0.3 to 0.55")
    kinds = [f["kind"] for f in finds]
    assert "fused_column_blocking" in kinds, f"没有阻断，实际 findings={kinds}"


def test_blocking_kind_is_not_counted_as_patched():
    """阻断类不能掉进 `patched` 桶——那会被当成「已修好」放进 ok 列表。"""
    finds = _audit("Input common-mode voltage", "0.3 to 0.55")
    blocking = [f for f in finds if f["kind"] in T.BLOCKING_KINDS]
    assert blocking, "BLOCKING_KINDS 未收录该 kind"
    assert all(not f["kind"].endswith("unresolved") for f in blocking)


def test_non_key_param_stays_unresolved():
    """非关键参数维持原样：不制造无谓的 P0 噪声。"""
    finds = _audit("Power-down current", "1.2")
    kinds = [f["kind"] for f in finds]
    assert "fused_column_blocking" not in kinds
    assert any(k.endswith("unresolved") for k in kinds)


def test_registry_knows_the_new_kind():
    """新 kind 必须登记，否则 test_finding_kinds 会判「未注册的动态产出点」。"""
    from qc import finding_kinds as FK
    assert "fused_column_blocking" in FK.TABLE_AUDIT_KINDS
