"""阶段 ① 门禁：74 功能表校验 / 签核状态 / 功能判定（G1–G8）。"""
import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import function_table as FT      # noqa: E402

TABLE = Path(ROOT / "qc" / "74_function_codes.json")


def load_real():
    return FT.load(TABLE)


def signed(table: dict, reviewer: str = "wuxiaoxian",
           at: str = "2026-10-29T14:00:00+08:00") -> dict:
    """测试夹具：把表变成「已签核 + 哈希匹配」的合法版本（仅用于测试）。"""
    t = copy.deepcopy(table)
    t["status"] = "SIGNED"
    t["reviewed_by"] = reviewer
    t["reviewed_at"] = at
    t["content_hash"] = FT.content_hash(t)
    return t


class G1UnsignedTest(unittest.TestCase):
    """G1：未签核的表不得产生 P0 功能等价结论。"""

    def _unsigned(self):
        t = load_real()
        t["status"] = "PENDING_REVIEW"
        t["reviewed_by"] = None
        t["reviewed_at"] = None
        t.pop("signed_via", None)
        t.pop("authorization_note", None)
        t["content_hash"] = FT.content_hash(t)
        return t

    def test_unsigned_table_unusable(self):
        t = self._unsigned()
        usable, why = FT.is_usable_for_p0(t)
        self.assertFalse(usable)
        self.assertEqual(why, "table_not_signed")

    def test_unsigned_cannot_be_p0_even_if_codes_exist(self):
        t = self._unsigned()                   # 未签核，但 132/125 等条目存在
        t["functions"]["11"] = {
            "function": "AND", "inputs": 3, "schmitt": False,
            "output_type": "PUSH_PULL", "oe_polarity": "NONE",
            "family_scope": ["LVC"], "status": "EVIDENCE_BACKED",
            "sources": [{"mpn": "TEST", "pdf_sha256": "x" * 8, "page": 1,
                         "quote": "测试夹具"}],
        }                                     # 让候选也命中
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("table_unusable:table_not_signed", r["reasons"])

    def test_real_table_signature_state_is_consistent(self):
        """真实表要么未签核（不可用），要么已签核（双人不同 + 哈希匹配）。"""
        t = load_real()
        usable, why = FT.is_usable_for_p0(t)
        self.assertEqual(usable, t["status"] == "SIGNED")
        if t["status"] == "SIGNED":
            self.assertEqual(why, "ok")
            self.assertEqual(t["content_hash"], FT.content_hash(t))
            self.assertNotEqual(str(t.get("reviewed_by")), str(t.get("owner")))


class G2MissingCodeTest(unittest.TestCase):
    """G2：候选功能码不在表内 → NO_EVIDENCE。"""

    def test_code_not_in_table(self):
        r = FT.judge(signed(load_real()), "132", "999", target_family="LVC",
                     candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("candidate:code_not_in_table", r["reasons"])

    def test_unresolved_code_is_no_evidence(self):
        t = signed(load_real())
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("candidate:code_not_in_table", r["reasons"])


class G3AmbiguityTest(unittest.TestCase):
    """G3：映射冲突/歧义 → NO_EVIDENCE，不得判 INCOMPATIBLE。"""

    def test_conflict_entry_downgraded(self):
        t = signed(load_real())
        self.assertEqual(t["functions"]["240"]["status"], "CONFLICT")
        r = FT.judge(t, "125", "240", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("candidate:mapping_conflict", r["reasons"])

    def test_family_outside_scope(self):
        t = signed(load_real())
        # 04 的 family_scope 只有 AHC/AHCT，用 LVC 查不应命中
        self.assertEqual(FT.lookup(t, "04", "LVC")["kind"], "NO_EVIDENCE")


class G4CharOnlyTest(unittest.TestCase):
    """G4：仅字符位不同、无充分功能证据 → NO_EVIDENCE。"""

    def test_char_only_diff(self):
        t = signed(load_real())
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC",
                     char_only_diff=True)
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("char_only_diff", r["reasons"])


class G5HashMismatchTest(unittest.TestCase):
    """G5：内容变了但签核哈希没更新 → 拒绝使用。"""

    def test_content_changed_stale_hash(self):
        t = signed(load_real())
        t["functions"]["132"]["schmitt"] = False          # 改动内容
        usable, why = FT.is_usable_for_p0(t)
        self.assertFalse(usable)
        self.assertEqual(why, "content_hash_mismatch")
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")


class G6SamePersonTest(unittest.TestCase):
    """G6：Owner 与 Reviewer 相同 → 签核校验失败。"""

    def test_owner_equals_reviewer(self):
        t = signed(load_real(), reviewer="esan")
        issues = FT.validate(t)
        self.assertTrue(any("同名" in i for i in issues))
        usable, why = FT.is_usable_for_p0(t)
        self.assertFalse(usable)
        self.assertEqual(why, "owner_equals_reviewer")


class G7MissingAuditTest(unittest.TestCase):
    """G7：来源或审计字段缺失 → 校验失败，不允许签核。"""

    def test_missing_source(self):
        t = load_real()
        t["functions"]["132"]["sources"] = []
        issues = FT.validate(t)
        self.assertTrue(any("132: sources 为空" in i for i in issues))

    def test_missing_reviewed_at(self):
        t = signed(load_real())
        t["reviewed_at"] = None
        issues = FT.validate(t)
        self.assertTrue(any("reviewed_at" in i for i in issues))
        self.assertFalse(FT.is_usable_for_p0(t)[0])

    def test_sign_refuses_same_person(self):
        t = load_real()
        tmp = Path(ROOT / "data" / "qc" / "74fn_sign_refuse.json")
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(t, ensure_ascii=False), encoding="utf-8")
        try:
            with self.assertRaises(SystemExit):
                FT.sign(tmp, "esan", "2026-10-29T14:00:00+08:00",
                        FT.content_hash(t))
        finally:
            tmp.unlink(missing_ok=True)


class G8SignedUsableTest(unittest.TestCase):
    """G8：签核+版本+哈希匹配 → 表可用，但不自动判定候选等价。"""

    def test_signed_table_is_usable_but_not_pass(self):
        t = signed(load_real())
        usable, why = FT.is_usable_for_p0(t)
        self.assertTrue(usable, why)
        same = FT.judge(t, "132", "132", target_family="LVC", candidate_family="LVC")
        self.assertEqual(same["verdict"], "NO_CONFLICT_EVIDENCE")
        self.assertNotEqual(same["verdict"], "PASS")      # 永不返回 PASS

    def test_signed_conflict_still_no_evidence(self):
        t = signed(load_real())
        # 240 的 function（是否反相）在两族间冲突 → 不可用于 P0
        r = FT.judge(t, "240", "240", target_family="AUC", candidate_family="AUC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")
        self.assertIn("target:mapping_conflict", r["reasons"])

    def test_sign_path_writes_signed_version(self):
        t = load_real()
        tmp = Path(ROOT / "data" / "qc" / "74fn_sign_ok.json")
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(t, ensure_ascii=False), encoding="utf-8")
        try:
            out = FT.sign(tmp, "wuxiaoxian", "2026-10-29T14:00:00+08:00",
                          FT.content_hash(t))
            self.assertEqual(out["status"], "SIGNED")
            self.assertTrue(FT.is_usable_for_p0(FT.load(tmp))[0])
        finally:
            tmp.unlink(missing_ok=True)


class FamilyOverrideTest(unittest.TestCase):
    """同一功能码在不同族可以是不同器件（125：逻辑缓冲 vs FET 总线开关）。"""

    def test_override_lookup(self):
        t = signed(load_real())
        self.assertEqual(FT.lookup(t, "125", "LVC")["entry"]["function"],
                         "BUFFER_3STATE")
        self.assertEqual(FT.lookup(t, "125", "CBT")["entry"]["function"],
                         "ANALOG_SWITCH_FET")
        r = FT.judge(t, "125", "125", target_family="LVC", candidate_family="CBT")
        self.assertEqual(r["verdict"], "INCOMPATIBLE")
        self.assertTrue(any("function" in x for x in r["reasons"]))


class RealTableSanityTest(unittest.TestCase):
    def test_real_table_validates_and_covers_132(self):
        t = load_real()
        self.assertEqual(FT.validate(t), [])
        e = t["functions"]["132"]
        self.assertEqual(e["function"], "NAND")
        self.assertEqual(e["inputs"], 2)
        self.assertTrue(e["schmitt"])
        self.assertEqual(e["sources"][0]["page"], 1)
        self.assertIn("Schmitt", e["sources"][0]["quote"])

    def test_unresolved_lists_11(self):
        t = load_real()
        codes = [u["code"] for u in t["unresolved"]]
        self.assertIn("11", codes)


CAND_V4 = Path(ROOT / "qc" / "74_function_codes.v1.0.4.candidate.json")
CAND_V3 = Path(ROOT / "qc" / "74_function_codes.v1.0.3.candidate.json")
CAND = CAND_V4 if CAND_V4.is_file() else CAND_V3


@unittest.skipUnless(CAND.is_file(), "v1.0.3 候选未生成")
class CandidateV103Test(unittest.TestCase):
    """候选版本验收条件（不签核，只验证候选本身）。"""

    def _unsigned_candidate(self):
        t = FT.load(CAND)
        t["status"] = "PENDING_REVIEW"
        t["reviewed_by"] = None
        t["reviewed_at"] = None
        for k in ("signed_via", "authorization_note"):
            t.pop(k, None)
        t["content_hash"] = FT.content_hash(t)
        return t

    def test_candidate_validates_and_evidence_clean(self):
        t = FT.load(CAND)
        self.assertIn(t["status"], ("PENDING_REVIEW", "SIGNED"))
        self.assertEqual(FT.validate(t), [])
        issues = FT.verify_evidence(t, ROOT / "data" / "pdfs")
        self.assertEqual(FT.verify_evidence_summary(issues)["error"], 0)

    def test_candidate_adds_code_11(self):
        t = FT.load(CAND)
        e = t["functions"]["11"]
        self.assertEqual(e["function"], "AND")
        self.assertEqual(e["inputs"], 3)
        self.assertFalse(e["schmitt"])
        self.assertEqual(e["family_scope"], ["LVC"])
        self.assertEqual(e["sources"][0]["page"], 1)
        self.assertIn("3-Input", e["sources"][0]["quote"])
        self.assertEqual([u["code"] for u in t["unresolved"]], [])

    def test_unsigned_candidate_cannot_be_p0(self):
        t = self._unsigned_candidate()
        self.assertFalse(FT.is_usable_for_p0(t)[0])
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "NO_EVIDENCE")

    def test_signed_candidate_flags_function_mismatch(self):
        """候选若已签核，应能支撑 INCOMPATIBLE；未签核时则必须 NO_EVIDENCE。"""
        t = FT.load(CAND)
        if t["status"] != "SIGNED":
            t = signed(t)
        r = FT.judge(t, "132", "11", target_family="LVC", candidate_family="LVC")
        self.assertEqual(r["verdict"], "INCOMPATIBLE")
        reasons = " ".join(r["reasons"])
        self.assertIn("function:NAND≠AND", reasons)
        self.assertIn("inputs:2≠3", reasons)
        self.assertIn("schmitt:True≠False", reasons)

    def test_signed_v102_untouched(self):
        t = load_real()
        self.assertEqual(t["version"], "1.0.2")
        self.assertEqual(t["status"], "SIGNED")
        self.assertEqual(t["content_hash"], FT.content_hash(t))


class HashReproducibleTest(unittest.TestCase):
    def test_hash_is_reproducible(self):
        t1, t2 = load_real(), load_real()
        self.assertEqual(FT.content_hash(t1), FT.content_hash(t2))
        t2["functions"]["132"]["inputs"] = 3
        self.assertNotEqual(FT.content_hash(t1), FT.content_hash(t2))


if __name__ == "__main__":
    unittest.main()
