# -*- coding: utf-8 -*-
"""`table_audit.cell_num` —— 写盘前的「干净单值」闸门（ADAPT A12）。

背景：`patch_cols` 原来用 `to_num`（从任意文本里捞第一个数）取列值，
实测在 DAC8555 上写出两条假规格：

    '0 .7 × IOVDD'  → 0.0   → "0 MIN"   （原文是 0.7×IOVDD 公式）
    '10 20'         → 10.0  → "10 MIN"  （两格并一格，真值是 20）

所以写盘路径改用 `cell_num`：整格必须是一个数，否则返回 None，
上游把该条记成 `cell_unparsable_unresolved`。**宁可不写，绝不写错。**
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402


class TestAccepts:
    """正常数值格 —— 带不带单位、带不带正负号都要能解析。"""

    @pytest.mark.parametrize("cell,want", [
        ("4.5", 4.5),
        ("4.5 V", 4.5),
        ("-2.0", -2.0),
        ("−2.0", -2.0),          # U+2212 数学负号
        ("±1", 1.0),
        ("±0.5", 0.5),
        ("180", 180.0),
        ("0.79", 0.79),
        ("30 µA", 30.0),
        ("-40 °C", -40.0),
        ("100 %", 100.0),
        ("2.4 mA", 2.4),
        ("5.5V", 5.5),
    ])
    def test_clean_number(self, cell, want):
        assert TA.cell_num(cell) == pytest.approx(want)

    def test_empty_is_none(self):
        assert TA.cell_num("") is None
        assert TA.cell_num("   ") is None
        assert TA.cell_num(None) is None


class TestRefuses:
    """脏格子一律 None —— 这几条就是实测写错值的形态。"""

    @pytest.mark.parametrize("cell", [
        "0 .7 × IOVDD",        # 公式格（实测写成 "0 MIN"）
        "10 20",               # 两格并一格（实测写成 "10 MIN"，真值 20）
        "180 250",             # DAC8555 合并列：MIN/MAX 挤在一格
        "18 55 . .",           # extract() 字符重排后的双值
        "-0.3 to +7.0",        # 范围格
        "-0.3 ~ +7.0",
        "VCC - 1.0",           # 公式
        "0.2 ∗VCC",            # 公式（U+2217）
        "0.4 × VCC",
        "5 (Note 1)",          # 脚注混入
        "0 AVDD/2",
        "VREFH/2",
        "-",                   # 占位符
        "TBD",
    ])
    def test_dirty_cell(self, cell):
        assert TA.cell_num(cell) is None, f"{cell!r} 不该被当成数值"

    def test_two_numbers_with_units(self):
        """'4.5 V 5.5 V' 是两个值，不是 4.5。"""
        assert TA.cell_num("4.5 V 5.5 V") is None


class TestPatchGate:
    """闸门接在写盘路径上：脏格子 → 不写 columns，改报 unresolved。"""

    def _tbl(self, min_cell, typ_cell="", max_cell=""):
        return {"page": 1, "ti": 0,
                "header": ["PARAMETER", "MIN", "TYP", "MAX", "UNIT"],
                "rows": [["Supply voltage", min_cell, typ_cell, max_cell, "V"]]}

    def test_dirty_min_is_not_written(self):
        # 用带连字符的范围值才能触发 range_collapse（"4.5 to 5.5" 不在判据里，不会尝试写盘）
        e = {"name": "Supply voltage", "value": "4.5-5.5", "unit": "V"}
        finds = TA.audit_electrical([e], [self._tbl("0 .7 × IOVDD", "5", "5.5")],
                                    "specs.electrical")
        kinds = [f["kind"] for f in finds]
        assert "columns" not in e, f"脏格子还是被写了：{e.get('columns')}"
        assert "cell_unparsable_unresolved" in kinds, kinds
        assert e.get("value") == "4.5-5.5", "未写盘时原值必须原样保留"

    def test_clean_row_still_patches(self):
        e = {"name": "Supply voltage", "value": "4.5 to 5.5", "unit": "V"}
        finds = TA.audit_electrical([e], [self._tbl("4.5", "5", "5.5")],
                                    "specs.electrical")
        kinds = [f["kind"] for f in finds]
        assert "cell_unparsable_unresolved" not in kinds, kinds
        assert e.get("columns") == {"MIN": 4.5, "TYP": 5.0, "MAX": 5.5}, e.get("columns")

    def test_two_numbers_in_one_cell_is_not_written(self):
        """'4.5 5.5' 是 MIN/MAX 挤在一格 —— 真值 5.5 会被 to_num 读成 4.5。"""
        e = {"name": "Supply voltage", "value": "4.5-6", "unit": "V"}
        finds = TA.audit_electrical([e], [self._tbl("4.5 5.5", "5", "6")], "specs.electrical")
        assert "columns" not in e
        assert any(f["kind"] == "cell_unparsable_unresolved" for f in finds), \
            [f["kind"] for f in finds]


class TestFusedColumn:
    """竖线丢失：MIN/TYP/MAX 被读成一列（DAC8555 第 3 页真实形态）。"""

    def test_fused_header_detected(self):
        assert TA.fused_cols(["PARAMETER", "MIN TYP MAX", "UNIT"]) == {1}
        assert TA.fused_cols(["PARAMETER", "MIN", "TYP", "MAX", "UNIT"]) == set()

    def test_fused_table_is_not_backfilled(self):
        """融合列 + 另一列 MAX：诊断能算出两个值，但绝不能回填。

        2026-10-31：关键参数（这里 `Supply voltage` 命中 `_BLOCKING_PARAM_RE`）
        的融合列由 `cell_unparsable_unresolved` **升级为** `fused_column_blocking`。
        取证见 `qc/evidence_20261031/二次确认_取证报告_ADC12DJ5200SE.md` §2-D：
        ADC12DJ5200SE 的 p10 ROC 表 18 行全走这条分支，闸门零判定、出包。
        「不回填」的语义不变，只是不再算「没判」，而是「判定条件不成立」。
        """
        tbl = {"page": 1, "ti": 0,
               "header": ["PARAMETER", "MIN TYP MAX", "MAX", "UNIT"],
               "rows": [["Supply voltage", "0.3 0.7", "5.5", "V"]]}
        e = {"name": "Supply voltage", "value": "0.3-5.5", "unit": "V"}
        finds = TA.audit_electrical([e], [tbl], "specs.electrical")

        kinds = [f["kind"] for f in finds]
        assert "columns" not in e, f"融合列被回填了：{e.get('columns')}"
        assert kinds == ["fused_column_blocking"], kinds
        f = finds[0]
        assert f["table"] == "FUSED_COLUMN", f["table"]
        assert f["kind"] in TA.BLOCKING_KINDS
        assert e.get("value") == "0.3-5.5", "不能写盘时原值必须原样保留"

    def test_fused_table_noncritical_param_stays_unresolved(self):
        """非关键参数（Gain）融合列仍只记 unresolved —— 不该全库阻断。"""
        tbl = {"page": 1, "ti": 0,
               "header": ["PARAMETER", "MIN TYP MAX", "MAX", "UNIT"],
               "rows": [["Gain", "0.3 0.7", "5.5", "dB"]]}
        e = {"name": "Gain", "value": "0.3-5.5", "unit": "dB"}
        finds = TA.audit_electrical([e], [tbl], "specs.electrical")

        kinds = [f["kind"] for f in finds]
        assert "columns" not in e, f"融合列被回填了：{e.get('columns')}"
        assert kinds == ["cell_unparsable_unresolved"], kinds

    def test_multi_value_in_single_cell_is_rejected(self):
        """表头正常，但 MIN 格里写了 '4.5 5.0'（两格并一格）。"""
        tbl = {"page": 1, "ti": 0,
               "header": ["PARAMETER", "MIN", "TYP", "MAX", "UNIT"],
               "rows": [["Supply voltage", "4.5 5.0", "", "5.5", "V"]]}
        e = {"name": "Supply voltage", "value": "4.5-5.5", "unit": "V"}
        finds = TA.audit_electrical([e], [tbl], "specs.electrical")

        kinds = [f["kind"] for f in finds]
        assert "columns" not in e, f"多值格被回填了：{e.get('columns')}"
        assert "cell_unparsable_unresolved" in kinds, kinds


class TestIdempotentPatch:
    """一条只准写一次：原值不能被二次 patch 覆盖（ADC3910 Add. Latency 实测）。"""

    def test_double_patch_keeps_original(self):
        e = {"name": "Test Param", "value": "4", "unit": "V"}
        tbl = {"page": 1, "ti": 0,
               "header": ["PARAMETER", "MIN", "TYP", "MAX", "UNIT"],
               "rows": [["Test Param", "4", "5", "6", "V"]]}
        cols = {"MIN": 4.0, "TYP": 5.0, "MAX": 6.0}
        roles = {"MIN": "4", "TYP": "5", "MAX": "6"}
        TA.patch_cols(e, cols, roles, tbl, 0, "V")
        first = e["value"]
        TA.patch_cols(e, cols, roles, tbl, 0, "V")
        assert e["value_raw_original"] == "4", "原始值被二次覆盖了"
        assert e["value"] == first

    def test_bad_number_cell_multivalue(self):
        for c in ("18 55 . .", "24 33 . .", "079 116 . ."):
            assert TA.bad_number_cell(c) is True, c
        for c in ("1.8", "18 55", "0.2 ∗VCC", "-2.0"):
            assert TA.bad_number_cell(c) is False, c


class TestFusedSplitHelpers:
    """融合列切分的几何判据（ADAPT A13）。真实坐标取自 DAC8555 第 3 页。"""

    #: 表头 MIN/TYP/MAX 的 x 区间（来自 get_text('words')）
    BOUNDS = [(-1e9, 444.0), (444.0, 477.0), (477.0, 1e9)]

    def test_overlap_beats_center_distance(self):
        """'180' 右对齐，中心点偏右，但**零重叠**于 MIN —— 归 TYP 才对。"""
        w180 = (448.9, 0, 460.6)
        assert TA._pick_band(w180, self.BOUNDS) == 1, "180 落在 TYP 区间内"
        w18 = (421.1, 0, 430.8)
        assert TA._pick_band(w18, self.BOUNDS) == 0, "1.8 落在 MIN 区间内"
        w55 = (500.5, 0, 510.2)
        assert TA._pick_band(w55, self.BOUNDS) == 2

    def test_no_overlap_falls_back_to_distance(self):
        """完全落在区间外（比如值比列还宽）时按距离归位，不能崩。"""
        w = (1000.0, 0, 1010.0)
        assert TA._pick_band(w, self.BOUNDS) == 2

    def test_cluster_centers_splits_by_largest_gap(self):
        xs = [10, 11, 12, 50, 51, 90]
        b = TA._cluster_centers(xs, 3)
        assert len(b) == 3
        assert b[0][0] <= 10 and b[0][1] >= 12
        assert b[1][0] <= 50 and b[1][1] >= 51
        assert b[2][0] <= 90 <= b[2][1]

    def test_cluster_centers_pads_when_fewer_clusters(self):
        b = TA._cluster_centers([10, 50], 3)
        assert len(b) == 3
        assert any(lo == 0 and hi == 0 for lo, hi in b), "不足 k 簇要补空位，由调用方拒切"

    def test_band_dist_zero_inside(self):
        assert TA._band_dist(5, 0, 10) == 0
        assert TA._band_dist(-5, 0, 10) == 5
        assert TA._band_dist(15, 0, 10) == 5


class TestGarbledConditionGuard:
    """交织乱码的 condition 不许覆盖模型原文（DAC8555 第 3 页实测）。

    格子文本形如 ``'T 0po ± 0 <. 0 C0 L3 <% F 0S 0pR F, 0200h to FD00h , RL = 2kΩ , F 2'``
    —— 两行 TEST CONDITIONS 的字符互相穿插，且被截断。模型给的
    ``'To ±0.003% FSR, 0200h to FD00h, RL = 2kΩ, 0pF < CL < 200pF'`` 才是完整正确的。
    """

    GARBLED = [
        "T 0po ± 0 <. 0 C0 L3 <% F 0S 0pR F, 0200h to FD00h , RL = 2kΩ , F 2",
        "M (Ae Va Ds Du =re 5d b ,y li Rn Ee p =a 4s .s 9in 9g )t h ar no du g (Ah Vc Do Dd e",
        "M (Ae Va Ds Du =re 5d b ,y li Rn Ee p =a 4s .s 9in 9g )t",
    ]
    CLEAN = [
        "AVDD = 5V, VREF = 4.99V; AVDD = 2.7V, VREF = 2.69V",
        "VIH = IOVDD and VIL = GND",
        "VCC = 1.65V, -40°C to +85°C",
        "VREFL = GND , VREFH = AVDD = 5V",
        "16-bit Monotonic",
        "0 to 70",
    ]

    @pytest.mark.parametrize("cell", GARBLED)
    def test_detects_interleaved(self, cell):
        assert TA.looks_garbled(cell) is True

    @pytest.mark.parametrize("cell", CLEAN)
    def test_clean_text_not_flagged(self, cell):
        assert TA.looks_garbled(cell) is False

    def test_patch_keeps_model_condition_and_leaves_trace(self):
        """乱码 → 不覆盖，且留 `condition_cell_garbled` 便于回查。"""
        e = {"name": "Output voltage settling time", "value": "8",
             "condition": "To ±0.003% FSR, 0200h to FD00h, RL = 2kΩ"}
        tbl = {"page": 3, "ti": 0,
               "header": ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"],
               "rows": [["Output voltage settling time", self.GARBLED[0], "", "8", "10", "µs"]]}
        TA.patch_cols(e, {"TYP": 8.0, "MAX": 10.0},
                      {"TYP": "8", "MAX": "10", "COND": self.GARBLED[0]}, tbl, 0, "µs")
        assert e["condition"].startswith("To ±0.003% FSR"), "模型原文被乱码覆盖了"
        assert e["condition_cell_garbled"] is True, "拒绝了却不留痕，日后无法回查"

    def test_patch_takes_clean_condition(self):
        """干净 condition 照旧采用单元格原文（不能因为加了护栏就整体弃用）。"""
        e = {"name": "IOIDD", "value": "20", "condition": ""}
        tbl = {"page": 3, "ti": 0,
               "header": ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"],
               "rows": [["IOIDD", "VIH = IOVDD and VIL = GND", "", "10", "20", "µA"]]}
        TA.patch_cols(e, {"TYP": 10.0, "MAX": 20.0},
                      {"TYP": "10", "MAX": "20", "COND": "VIH = IOVDD and VIL = GND"}, tbl, 0, "µA")
        assert e["condition"] == "VIH = IOVDD and VIL = GND"
        assert "condition_cell_garbled" not in e


class TestAtomicWrite:
    """写盘必须原子：进程被杀不能留下半截 JSON。"""

    def test_replaces_and_leaves_no_tmp(self, tmp_path):
        p = tmp_path / "x.json"
        p.write_text('{"old": 1}', encoding="utf-8")
        TA.atomic_write(p, '{"new": 2}')
        assert p.read_text(encoding="utf-8") == '{"new": 2}'
        assert not (tmp_path / "x.json.tmp").exists(), "临时文件残留"

    def test_bad_json_never_half_written(self, tmp_path):
        """替换前的旧内容必须完整可读：先写 tmp，再一次性换过去。"""
        import json as _json
        p = tmp_path / "y.json"
        TA.atomic_write(p, _json.dumps({"a": list(range(50))}))
        _json.loads(p.read_text(encoding="utf-8"))      # 不该抛


class TestCellSpansColumns:
    """ADAPT A16：数据格横跨多个表头列 → 不能按该列角色写盘。

    1A1G04QDBVRG4Q1 第 5 页 ICC 行实测坐标：

        表头第二组   MIN 424.5~468.6 ｜ MAX 468.6~511.9
        数据格       424.5~511.9              ← PDF 合并成一格
        值 '20'      x 500.9~509.8            ← 实际在 MAX 的右边缘

    按表头下标取列会写出 ``ICC = 20 MIN``，而原文是 **MAX** ——
    格子干净、唯一命中、语义全错。这类只能 abstain。
    """

    #: 表头（9 列）各列的 x 区间，取自 find_tables 的 t.header.cells
    HX = [(56.7, 128.8), (128.8, 231.4), (231.4, 294.7), (294.7, 424.5), None,
          None, (424.5, 468.6), (468.6, 511.9), (511.9, 555.3)]
    #: ICC 行各格的 x 区间
    XR = [(56.7, 128.8), (128.8, 231.4), (231.4, 294.7), (294.7, 424.5), None,
          None, (424.5, 511.9), None, (511.9, 555.3)]

    def _tbl(self):
        return {"header": ["PARAMETER", "TESTCONDITIONS", "V", "T A= 25°C", "",
                           "", "MIN", "MAX", "UNIT"],
                "rows": [["ICC", "VI = VCC or GND, IO = 0", "5.5 V", "1", "", "",
                          "20", "", "µA"]],
                "hx": self.HX, "xr": [self.XR]}

    def test_merged_cell_is_detected(self):
        t = self._tbl()
        assert TA.cell_spans_columns(t, 0, 6) is True, "424.5~511.9 越过了 MIN 的右界 468.6"

    def test_aligned_cell_is_fine(self):
        t = self._tbl()
        assert TA.cell_spans_columns(t, 0, 3) is False, "TA=25°C 组合格与表头一致"
        assert TA.cell_spans_columns(t, 0, 2) is False

    def test_missing_geometry_never_blocks(self):
        """没有坐标（老数据/切分后的表）时一律不判 —— 宁可漏判也不能误杀全表。"""
        t = self._tbl()
        t["hx"], t["xr"] = [], []
        assert TA.cell_spans_columns(t, 0, 6) is False
        assert TA.cell_spans_columns(t, 99, 6) is False

    def test_small_jitter_tolerated(self):
        """栅格线抖动 1~3pt 不该判跨列。"""
        t = self._tbl()
        t["xr"] = [[(424.5, 470.0), None, None, None, None, None, (422.0, 472.0), None, None]]
        assert TA.cell_spans_columns(t, 0, 6) is False


ICC_PDF = Path(__file__).resolve().parent.parent / "data" / "pdfs" / "1A1G04QDBVRG4Q1__sn74ahc1g04-q1.pdf"


@pytest.mark.skipif(not ICC_PDF.exists(), reason="缺少 1A1G04 样本 PDF")
class TestIccRowRealPdf:
    """真 PDF 复核：ICC 行必须被识别为跨列，而不是写出 20 MIN。"""

    @pytest.mark.slow
    def test_icc_cell6_spans_min_and_max(self):
        import pymupdf
        doc = pymupdf.open(str(ICC_PDF))
        try:
            tables = TA.scan_tables(doc)
        finally:
            doc.close()
        cand = [t for t in tables if t["page"] == 5 and "ICC" in [r[0] for r in t["rows"] if r]]
        assert cand, "第 5 页电气表应含 ICC 行"
        t = cand[0]
        ri = [i for i, r in enumerate(t["rows"]) if r and r[0] == "ICC"][0]
        rm = TA.role_map(t["header"])
        assert rm.get(6) == "MIN" and rm.get(7) == "MAX", f"角色表异常：{rm}"
        assert TA.cell_spans_columns(t, ri, 6) is True, "ICC 的 20 横跨 MIN/MAX，必须拒绝按 MIN 写盘"
