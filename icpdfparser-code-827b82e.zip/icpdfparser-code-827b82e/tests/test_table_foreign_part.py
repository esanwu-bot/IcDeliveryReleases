# -*- coding: utf-8 -*-
"""A18：表标题的型号归属 —— 不许从「同族另一颗料的表」里取数。

背景（真实事故）：`74FCT162H245CTPVCT` 的 PDF 第 3 页并列三张**表头完全同构**的表：

    for CY74FCT16245T              ← 另一颗料（无 bus hold）
    for CY74FCT162245T, CY74FCT162H245T
    （电容表）

`_decide_match` 原来的规则是「按表顺序取第一张有候选的表，不跨表比较」，
于是 VOH 取到了第一张表的 `IOH=–15 mA → MIN 2.4 / TYP 3.5`；
本颗应取第二张的 `IOH=–24 mA → MIN 2.4 / TYP 3.3`。

**MIN 恰好都是 2.4**，所以 A12（干净单值）/ A16（没跨列）/ A17（值在待写列里）
三道闸门全看不出问题 —— 它们校验「值有没有落到列里」，不校验「这张表属不属于这颗料」。

修法分两层，判据都不用"猜型号"：

* `claims_part(token, mpn)`：标题 token 去掉厂商前缀后与料号有 >= 6 字符公共前缀，
  且**余量只允许空或 1~2 个纯字母**（`T`/`N` 这类温度封装后缀）。
  余量里出现数字 = 另一个产品号。所以 `CY74FCT162H245T` 算本品、
  `CY74FCT16245T`（余量 `45T`）、`CY74FCT162245T`（余量 `245T`）都不算。
* `mark_foreign_tables()`：只有在**本 PDF 里确实存在声称本品的表**时才动手；
  一张都没有（标题里没型号信息）就一个都不标 —— 那时标记任何表都是猜。

`_decide_match` 两轮：先在本品表里找，都没有候选时才因为"只命中外族表"而 abstain
（`foreign_part`）。外族表不是消失，而是不能再单独决定写什么。

**红先声明**：`test_foreign_table_is_not_used_for_write` 在修复前会写出
`{'MIN':2.4,'TYP':3.5}`（错误值）。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

HDR = ["Parameter", "Description", "TestConditions", "Min", "Typ", "Max", "Unit"]

T_BAD_TITLE = "Output Drive Characteristics for CY74FCT16245T"
T_GOOD_TITLE = "Output Drive Characteristics for CY74FCT162245T, CY74FCT162H245T"
MPN = "74FCT162H245CTPVCT"


def _tbl(page, ti, title, typ, cond):
    return {
        "page": page, "ti": ti, "header": list(HDR), "title": title,
        "rows": [list(HDR), ["VOH", "Output HIGH Voltage", cond, "2.4", typ, "", "V"]],
        "hx": [], "xr": [],
    }


def _pair():
    """同构的两张表：外族的写 3.5，本品写 3.3。"""
    return [
        _tbl(3, 0, T_BAD_TITLE, "3.5", "VCC=Min, IOH=-15 mA"),
        _tbl(3, 2, T_GOOD_TITLE, "3.3", "VCC=Min, IOH=-24 mA"),
    ]


@pytest.fixture(autouse=True)
def _clean_page():
    TA._PAGE.set(None)
    yield
    TA._PAGE.set(None)


class TestClaimsPart:
    @pytest.mark.parametrize("token,mpn,expected", [
        ("CY74FCT162H245T", MPN, True),          # 余量只有字母后缀 T
        ("CY74FCT162245T", MPN, False),          # 余量 245T 含数字 → 另一个产品号
        ("CY74FCT16245T", MPN, False),           # 余量 45T 含数字
        ("ADS7945", "ADS7945SRTER", True),       # 标题写基础型号，料号带封装后缀
        ("ADS7946", "ADS7945SRTER", False),
        ("bq2003", "BQ2003PNG4", True),
        ("74LVC1G132", "74LVC1G132DCKTG4", True),
        ("SBAS258A", "ADS5203IPFBG4", False),    # 文档号不是型号
    ])
    def test_claims(self, token, mpn, expected):
        assert TA.claims_part(token, mpn) is expected


class TestPartTokens:
    def test_requires_a_digit(self):
        assert TA.part_tokens("Output Drive Characteristics") == []
        assert TA.part_tokens(T_GOOD_TITLE) == ["CY74FCT162245T", "CY74FCT162H245T"]

    def test_doc_number_still_returned_but_not_same_family(self):
        """文档号也是 token，但不会被当成同族（`_same_family` 要求 6 字符公共前缀）。"""
        assert TA.part_tokens("SBAS258A – JUNE 2002") == ["SBAS258A"]
        assert TA.mark_foreign_tables(
            [{"page": 1, "ti": 0, "header": [], "rows": [], "hx": [], "xr": [],
              "title": "SBAS258A – JUNE 2002"}], MPN) == 0


class TestMarkForeignTables:
    def test_flags_only_the_sibling_table(self):
        bad, good = _pair()
        assert TA.mark_foreign_tables([bad, good], MPN) == 1
        assert bad.get("foreign_part") == "CY74FCT16245T"
        assert "foreign_part" not in good

    def test_no_claiming_table_means_no_flagging(self):
        """本 PDF 里一张"声称本品"的表都没有 → 不标（否则就是在猜）。"""
        bad = _tbl(3, 0, "Electrical Characteristics", "3.5", "VCC=Min")
        assert TA.mark_foreign_tables([bad], MPN) == 0
        assert "foreign_part" not in bad

    def test_empty_mpn_is_noop(self):
        assert TA.mark_foreign_tables(_pair(), "") == 0

    def test_stale_flag_is_cleared_between_parts(self):
        """同一批表对象接连过两颗料时，上一个料的标记必须清掉。

        `scan_tables` 的结果在灰度里会被缓存复用 —— 不清的话，换一颗料后
        本该可用的表还带着旧的 `foreign_part`，被降成兜底，是无声的召回损失。
        """
        bad, good = _pair()
        assert TA.mark_foreign_tables([bad, good], MPN) == 1
        assert bad.get("foreign_part")
        assert TA.mark_foreign_tables([bad, good], "TOTALLY-OTHER-PART") == 0
        assert "foreign_part" not in bad


class TestDecideMatch:
    def test_prefers_claiming_table_when_both_have_the_row(self):
        """两张表都有同一行（同条件同值）时，必须取本品那张。"""
        bad, good = _pair()
        bad["rows"][1][4] = "3.3"           # 让外族表的值也变成 3.3
        bad["rows"][1][2] = "VCC=Min, IOH=-24 mA"
        TA.mark_foreign_tables([bad, good], MPN)
        status, info = TA._decide_match([bad, good], "VOH", "VOH",
                                        cond="VCC=Min, IOH=-24 mA", val="2.4")
        assert status == "matched", status
        assert info["table"] is good, "取到了外族表"

    def test_foreign_only_becomes_foreign_part(self):
        """本品表里没有这一行时，不能退回去用外族表 —— 报 foreign_part，不写。"""
        bad, good = _pair()
        good["rows"] = [list(HDR)]              # 本品表没有 VOH 行
        TA.mark_foreign_tables([bad, good], MPN)
        status, info = TA._decide_match([bad, good], "VOH", "VOH",
                                        cond="VCC=Min, IOH=-15 mA", val="2.4")
        assert status == "foreign_part", status
        assert info["table"] is bad
        assert bad["foreign_part"] == "CY74FCT16245T"


class TestAuditWrites:
    def test_foreign_table_is_not_used_for_write(self):
        """红先：修复前这里会写出 {'MIN': 2.4, 'TYP': 3.5}。"""
        bad, good = _pair()
        TA.mark_foreign_tables([bad, good], MPN)
        e = {"name": "VOH", "value": "2.4", "unit": "V",
             "condition": "VCC=Min, IOH=-15 mA"}
        finds = TA.audit_electrical([e], [bad, good], "specs.electrical")
        cols = e.get("columns") or {}
        assert cols.get("TYP") != 3.5, "取到了外族表的 TYP 3.5"

    def test_foreign_part_finding_carries_token_and_page(self):
        """只命中外族表时：要报 table_foreign_part_unresolved，且带页码与型号证据。"""
        bad = _tbl(3, 0, T_BAD_TITLE, "3.5", "VCC=Min, IOH=-15 mA")
        good = _tbl(9, 2, T_GOOD_TITLE, "3.3", "VCC=Min, IOH=-24 mA")
        good["rows"] = [list(HDR)]              # 本品表没有 VOH 行
        TA.mark_foreign_tables([bad, good], MPN)
        e = {"name": "VOH", "value": "2.4", "unit": "V",
             "condition": "VCC=Min, IOH=-15 mA"}
        finds = TA.audit_electrical([e], [bad, good], "specs.electrical")
        hit = [f for f in finds if f["kind"] == "table_foreign_part_unresolved"]
        assert hit, [f["kind"] for f in finds]
        assert hit[0]["table"] == "CY74FCT16245T"
        assert hit[0].get("page") == 3
        assert "columns" not in e
