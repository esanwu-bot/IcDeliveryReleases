# -*- coding: utf-8 -*-
"""状态消费契约（Reviewer 阻断条件 2）。

解析入口被判过，不等于下游会照着办。本文件钉的是**消费侧**的三条：

1. `thin_accepted` 不得被当成普通 ok 之外的任何东西 —— 它只表示「解析层收下了」，
   交付侧要么原样放行，要么明确拒绝，不允许悄悄改写。
2. `parsed_core_fail` 不得进入交付：`stage_render` 的缓存捷径必须在**查缓存之前**
   被这道复核挡住，否则「当初渲染成功过」会被当成「现在仍然合格」。
3. 状态枚举只有一个字面量：`thin_accepted`（小写）。大写 `THIN_ACCEPTED` 只能是
   Python 常量名，不能作为值出现在任何比较里。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

PD = pytest.importorskip("parse_datasheets")
ST = pytest.importorskip("app.pipeline.stages")
C = pytest.importorskip("app.pipeline.contracts")

ROOT = Path(__file__).resolve().parent.parent


def _doc(*, elec: int = 3, pins: int = 0, stamp: str | None = None,
         identity: str = "chip") -> dict:
    meta = {}
    if stamp is not None:
        meta["accept_status"] = stamp
    return {
        "basic_info": {"mpn": "X1", "manufacturer": "TI",
                       "datasheet_url": "https://example.test/x.pdf",
                       "identity": identity},
        "specs": {"electrical": [{"name": f"e{i}"} for i in range(elec)]},
        "features": [], "applications": [], "alternatives": [],
        "ordering_info": [], "seo": {}, "metadata": meta,
        "pin_configuration": [{"pin": i + 1, "name": f"P{i}"} for i in range(pins)],
    }


# ---------------------------------------------------------------- 消费侧：交付闸
def test_render_gate_blocks_parsed_core_fail():
    """解析层自己判了 parsed_core_fail 的件，交付侧必须拒绝。"""
    why = ST.render_gate(_doc(stamp=PD.STATUS_PARSED_CORE_FAIL), "X1")
    assert why and "parsed_core_fail" in why


def test_render_gate_blocks_legacy_doc_with_core_errors():
    """闸门之前产出的旧 JSON 没有 accept_status，必须现场重算后拒绝。

    这是本批 3 件 core 非 pass 的形态：盘上的 JSON 没有章，只有「文件存在」。
    """
    doc = _doc(stamp=None, pins=0)
    doc["basic_info"].pop("datasheet_url")
    why = ST.render_gate(doc, "X1")
    assert why and "core_errs" in why


def test_render_gate_lets_thin_accepted_through():
    """`thin_accepted` 是解析层明确收下的芯片低规格件，交付侧不二次收紧。"""
    doc = _doc(elec=0, pins=8, stamp=PD.STATUS_THIN_ACCEPTED)
    assert ST.render_gate(doc, "X1") is None


def test_render_gate_lets_clean_doc_through():
    """干净的件必须放行（引脚也为空会被 check_core 判硬错，见下一例）。"""
    assert ST.render_gate(_doc(pins=8, stamp=PD.STATUS_OK), "X1") is None


def test_render_gate_treats_empty_pins_as_core_error():
    """引脚为空本身就是硬错 —— 这条解释了本批 DS14C89AN/NOPB 为何被判 core 非 pass。"""
    assert ST.render_gate(_doc(pins=0, stamp=PD.STATUS_OK), "X1")


class _BoomStore:
    """一旦被查缓存就炸 —— 用来证明复核排在缓存之前。"""

    def cached(self, *_a, **_kw):        # pragma: no cover - 触发即失败
        raise AssertionError("复核必须排在缓存查询之前，否则旧产物会命中缓存变 done")

    def begin(self, *_a, **_kw):
        return None

    def record(self, *_a, **_kw):
        return None


def test_stage_render_checks_gate_before_cache():
    """缓存里有记录也不能先返回：闸门不过就是不过。"""
    ctx = ST.Ctx(mpn="X1", doc=_doc(stamp=PD.STATUS_PARSED_CORE_FAIL),
                 item={"id": 1, "mpn": "X1", "mpn_key": "X1", "meta": "{}"},
                 state=_BoomStore())
    res = ST.stage_render(ctx)
    assert res.status == C.STATUS_FAILED, res.status
    assert res.detail.get("blocked") is True


# ---------------------------------------------------------------- 枚举唯一性
def test_thin_status_value_is_lowercase():
    assert PD.STATUS_THIN_ACCEPTED == "thin_accepted"
    assert PD.STATUS_PARSED_CORE_FAIL == "parsed_core_fail"
    for v in (PD.STATUS_OK, PD.STATUS_THIN_ACCEPTED, PD.STATUS_PARSED_CORE_FAIL):
        assert v == v.lower(), f"状态值必须全小写：{v}"


def test_no_uppercase_status_value_used_anywhere():
    """`THIN_ACCEPTED` 只能当常量名（STATUS_THIN_ACCEPTED），不能当值。

    做法：找出所有等于 "THIN_ACCEPTED" 的字符串字面量（带引号的），必须为零。
    """
    import re
    pat = re.compile(r"""['"]THIN_ACCEPTED['"]""")
    hits = []
    for p in list(ROOT.glob("*.py")) + list((ROOT / "app").rglob("*.py")) \
            + list((ROOT / "qc").rglob("*.py")) + list((ROOT / "worker").rglob("*.py")):
        if pat.search(p.read_text(encoding="utf-8", errors="ignore")):
            hits.append(str(p.relative_to(ROOT)))
    assert not hits, f"这些文件仍把大写当状态值：{hits}"


def test_stage_map_is_whitelist():
    """白名单语义不变：未列出的值一律 failed。"""
    assert C.llm_status_to_stage("parsed_core_fail") == C.STATUS_FAILED
    assert C.llm_status_to_stage("thin_accepted") == C.STATUS_OK
    assert C.llm_status_to_stage("whatever_new") == C.STATUS_FAILED


# ---------------------------------------------------------------- 写盘唯一入口
def test_batch_ingest_uses_the_same_gate():
    """Batch 回填曾是绕过 final_gate 的第二条写盘路径，现在必须过闸。"""
    src = (ROOT / "app" / "services" / "batch.py").read_text(encoding="utf-8")
    i_gate = src.index("pd.final_gate(doc, core_errs)")
    i_write = src.index("out.write_text(")
    assert i_gate < i_write, "batch.py 里 final_gate 必须排在写盘之前"
