#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""1102-V2 P1：`metadata.core_validation` 必须区分「没有数据」与「数据被隔离」。

`check_core()` 只看结构错误与列角色错误。AC 脏行被 `qc/ac_quarantine.py`
搬进 `specs.unresolved_ac_rows` 之后，错误清单归零，于是状态又写回 `"pass"`。
下游读到 `core_validation="pass"` + 空 AC 表，会理解成「这份手册没有 AC 参数」，
而事实是**有 6 条，只是列角色没核验、被主动扣下了**。

口径（`qc/core_validation.py`）：
* 有隔离行 → `pass_with_quarantine` + `quarantine_count`；
* 没有隔离行 → `pass`，并清掉陈旧计数；
* 有真错误 → 保留错误清单，隔离不允许把错误洗成 pass。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import delivery_bundle as DB                                  # noqa: E402
from qc import stage_release as SR                             # noqa: E402

ALL_ART = ["json", "html", "symbol", "pdf"]


def _dirty_ac(i: int) -> dict:
    """V11 实测形态：单位 `dB` 占了 MAX 数值格，MIN 有数、TYP 空。"""
    return {"symbol": "SNR" if i % 2 == 0 else "SFDR",
            "parameter": "SNR Signal-to-noise ratio" if i % 2 == 0
                         else "SFDR Spurious-free dynamic range",
            "conditions": f"At fIN = 10 kHz; {70 + i} QROW{i}",
            "min": f"{70 + i}.5", "typ": "", "max": "dB", "unit": "",
            "row_sha256": f"dirty-row-{i}"}


def _board_doc() -> dict:
    """最小可装配的板卡件：源文档是器件手册，芯片参数在板载器件桶。"""
    return {
        "basic_info": {"mpn": "ADS8568EVM-PDK",
                       "identity": "evaluation_board",
                       "identity_state": "BOARD_CONFIRMED",
                       "device_datasheet_url":
                           "https://www.ti.com/lit/ds/symlink/ads8568.pdf"},
        "specs": {"scope": "onboard_device",
                  "electrical": [], "absolute_max": [],
                  "ac_performance": [], "thermal": [], "esd": []},
        "pin_configuration": [],
        # D4（2026-11-04）：装配产物必须带 `pin_validation`，缺失即 BLOCKED。
        "metadata": {"pin_validation": {"status": "passed"}},
    }


def _quarantine(doc: dict, n: int) -> None:
    doc["specs"]["unresolved_ac_rows"] = [_dirty_ac(i) for i in range(n)]


def test_core_validation_marks_pass_with_quarantine():
    doc = _board_doc()
    _quarantine(doc, 6)
    rep = SR._revalidate(doc, "ADS8568EVM-PDK")

    meta = doc["metadata"]
    assert meta["core_validation"] == "pass_with_quarantine"
    assert meta["quarantine_count"] == 6
    assert rep["recomputed"] == "pass_with_quarantine"
    assert rep["quarantine_count"] == 6


def test_core_validation_clean_doc_stays_plain_pass():
    doc = _board_doc()
    SR._revalidate(doc, "ADS8568EVM-PDK")

    meta = doc["metadata"]
    assert meta["core_validation"] == "pass"
    assert "quarantine_count" not in meta, "没有隔离行时不该凭空出现计数"


def test_core_validation_errors_are_not_hidden_by_quarantine():
    """有真错误时仍返回错误清单：quarantine 不允许把错误洗成 pass。"""
    doc = _board_doc()
    doc["basic_info"]["device_datasheet_url"] = ""
    _quarantine(doc, 2)

    SR._revalidate(doc, "ADS8568EVM-PDK")

    meta = doc["metadata"]
    assert isinstance(meta["core_validation"], list)
    assert any("datasheet_url" in e for e in meta["core_validation"])
    assert meta["quarantine_count"] == 2


def test_core_validation_drops_stale_count_when_quarantine_cleared():
    doc = _board_doc()
    doc["metadata"] = {"core_validation": "pass_with_quarantine",
                       "quarantine_count": 6}
    SR._revalidate(doc, "ADS8568EVM-PDK")

    meta = doc["metadata"]
    assert meta["core_validation"] == "pass"
    assert "quarantine_count" not in meta


def test_core_validation_at_parse_is_not_overwritten_on_rerun():
    """第二趟装配不把真正的解析时状态冲成上一次的重算值。"""
    doc = _board_doc()
    doc["metadata"] = {"core_validation": "pass"}
    _quarantine(doc, 1)
    SR._revalidate(doc, "ADS8568EVM-PDK")
    assert doc["metadata"]["core_validation_at_parse"] == "pass"

    doc["metadata"]["core_validation"] = "pass_with_quarantine"
    SR._revalidate(doc, "ADS8568EVM-PDK")
    assert doc["metadata"]["core_validation_at_parse"] == "pass"


def test_gate_and_release_state_treat_quarantine_as_pending():
    """打包侧不得把 `pass_with_quarantine` 读成「完整通过」。"""
    doc = _board_doc()
    _quarantine(doc, 6)
    SR._revalidate(doc, "ADS8568EVM-PDK")

    gate, why = DB._gate(doc)
    assert gate == "UNRESOLVED"
    assert "pass_with_quarantine" in why
    assert "6" in why, "闸门原因要带上隔离行数，否则读不出扣了几条"

    facts = {"verdict": "pass", "anchor_gate": "pass"}
    assert DB._release_state(doc, ALL_ART, True, facts) == "PACKAGING_PASSED"
