#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Issue 回帖（AGENT.md §18 最后一步：修复完必须到单子上回帖汇报）。

为什么要有独立的 reply 路径：建单有 labels / 三层去重 / 台账，回帖只是把一段
人写的证据贴上去。把回帖硬塞进 `create_issue` 会让去重逻辑把评论当成第二次建单。

这里守四条：
1. **POST 目标必须是 `/issues/{n}/comments`**，不是 `/issues`；
2. **返回 `html_url`** —— 帖子真的落库的唯一凭据；
3. **非 2xx 必须抛错**（脚本返回成功而帖子没发出去是最坏的失败）；
4. `--dry-run` 不发网络请求，只打印请求体。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.integrations import github_issues as GH                   # noqa: E402


class _Resp:
    def __init__(self, code: int, payload: dict | None = None, text: str = ""):
        self.status_code = code
        self._payload = payload or {}
        self.text = text

    def json(self):
        return self._payload


class _Session:
    def __init__(self, code: int = 201, payload: dict | None = None):
        self.calls: list[dict] = []
        self._code = code
        self._payload = payload or {"id": 123, "html_url": "https://github.com/x/y/issues/14#issuecomment-123",
                                    "created_at": "2026-11-03T14:00:00Z",
                                    "body": "hi"}

    def post(self, url, json=None, headers=None, timeout=None):
        self.calls.append({"url": url, "json": json, "headers": headers, "timeout": timeout})
        return _Resp(self._code, self._payload)


def test_reply_posts_to_comments_endpoint_with_bearer():
    s = _Session()
    res = GH.reply_issue(14, "### 修复汇报", repo="esanwu-bot/x", token="t", session=s)
    call = s.calls[0]
    assert call["url"] == "https://api.github.com/repos/esanwu-bot/x/issues/14/comments"
    assert call["json"] == {"body": "### 修复汇报"}
    assert call["headers"]["Authorization"] == "Bearer t"
    assert res["html_url"].endswith("#issuecomment-123")
    assert res["comment_id"] == 123


def test_reply_dry_run_makes_no_request():
    res = GH.reply_issue(14, "body", repo="esanwu-bot/x", token="t", dry_run=True)
    assert res["dry_run"] and res["request"]["method"] == "POST"
    assert res["request"]["url"].endswith("/repos/esanwu-bot/x/issues/14/comments")


def test_reply_rejects_empty_body():
    with pytest.raises(ValueError):
        GH.reply_issue(14, "   ", repo="esanwu-bot/x", token="t", dry_run=True)


def test_reply_non_2xx_must_raise():
    """403/404 不许静默返回成功 —— 帖子没发出去等于没汇报。"""
    s = _Session(code=403, payload={})
    with pytest.raises(RuntimeError) as e:
        GH.reply_issue(14, "body", repo="esanwu-bot/x", token="t", session=s)
    assert "403" in str(e.value) and "#14" in str(e.value)


def test_reply_cli_dry_run_prints_request(capsys):
    rc = GH.main(["reply", "--id", "14", "--body", "hi", "--dry-run",
                  "--repo", "esanwu-bot/x"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert out["request"]["url"].endswith("/issues/14/comments")


def test_reply_cli_reads_body_file(tmp_path, capsys):
    p = tmp_path / "body.md"
    p.write_text("### 修复汇报\n- 提交 d5ab14c", encoding="utf-8")
    rc = GH.main(["reply", "--id", "23", "--body-file", str(p), "--dry-run",
                  "--repo", "esanwu-bot/x"])
    assert rc == 0
    out = json.loads(capsys.readouterr().out)
    assert "d5ab14c" in out["request"]["json"]["body"]
