#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""温度字段三处口径冲突的归一化用例（Reviewer A5）。

**取证**：ADC12DJ5200SE 同一件 JSON 里同一事实有三条互不知情的记录 ——

    specs.temperature.operating            = "not_specified"
    specs.unresolved_specs.temperature     = {"operating": "-40°C to 85°C"}
    specs.electrical[16] Operating free-air temperature = "-40 to 85 °C"

页面渲染取的是第三条（电气表那一行），于是「字段未落位但页面照常出数」。
Reviewer 把原因写成"渲染器挖了 unresolved 兜底"——**实测不成立**：
`json_to_txt.py` 对 `unresolved_specs` 的引用数是 0。真实缺陷是**三条记录不同步**。

所以修法不是改渲染层，而是在写盘前把「电气表那一行」认成唯一事实源，
反过来把 temperature / unresolved_specs 对齐。取电气行是因为它带单位、带条件、
且已经过 `table_audit` 的行级核对。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import postprocess_qwen as PP                            # noqa: E402


def _doc(elec=None, amax=None):
    return {
        "specs": {
            "electrical": elec or [],
            "absolute_max": amax or [],
            "temperature": {"operating": "not_specified", "storage": "not_specified"},
            "unresolved_specs": {
                "scope": "unresolved",
                "temperature": {"operating": "-40°C to 85°C", "storage": "-65°C to 150°C"},
            },
        }
    }


def test_operating_temp_taken_from_electrical_row():
    doc = _doc(elec=[{"name": "Operating free-air temperature", "value": "-40 to 85", "unit": "°C"}])
    changed = PP.normalize_temperature(doc)
    sp = doc["specs"]
    assert sp["temperature"]["operating"] == "-40°C to 85°C"
    # 被真值覆盖的那个字段必须从 unresolved 里消失，否则仍是两条互相矛盾的口径
    assert "operating" not in ((sp.get("unresolved_specs") or {}).get("temperature") or {})
    assert changed and any(a["field"] == "temperature.operating" for a in changed)


def test_storage_temp_taken_from_abs_max_row():
    doc = _doc(amax=[{"name": "Storage temperature (Tstg)", "value": "-65 to 150", "unit": "°C"}])
    PP.normalize_temperature(doc)
    assert doc["specs"]["temperature"]["storage"] == "-65°C to 150°C"


def test_never_invents_when_row_missing():
    """电气表没有这一行 → 一个字都不许改（宁可 not_specified，也不能自造）。"""
    doc = _doc(elec=[{"name": "Resolution", "value": "12", "unit": "bit"}])
    before = dict(doc["specs"]["temperature"])
    changed = PP.normalize_temperature(doc)
    assert doc["specs"]["temperature"] == before
    assert not changed


def test_placeholder_row_does_not_win():
    """电气行是 not_specified 时不能拿它覆盖 unresolved 里的真值。"""
    doc = _doc(elec=[{"name": "Operating free-air temperature",
                      "value": "not_specified", "unit": "°C"}])
    PP.normalize_temperature(doc)
    assert doc["specs"]["temperature"]["operating"] == "not_specified"


def test_already_consistent_is_idempotent():
    doc = _doc(elec=[{"name": "Operating free-air temperature", "value": "-40 to 85", "unit": "°C"}])
    PP.normalize_temperature(doc)
    snapshot = dict(doc["specs"])
    changed = PP.normalize_temperature(doc)
    assert not changed, "第二次调用不该再报改动"
    assert doc["specs"]["temperature"] == snapshot["temperature"]


def test_junction_temperature_is_not_operating_ambient():
    """Tj 是结温，不是工作环境温度 —— 拿它顶 TA 会直接把 -40~85 写成 125。"""
    doc = _doc(elec=[{"name": "Operating junction temperature", "value": "125", "unit": "°C"}])
    PP.normalize_temperature(doc)
    assert doc["specs"]["temperature"]["operating"] == "not_specified"
