"""qc/evidence_verify.py 离线单测：batch-verify 十项重校验 + 单字段放行高风险。

不发网络请求；PDF 用 fitz 现场生成（确定性文本）；DB 用临时 SQLite（复用 app/db.py DDL）。
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import evidence_verify as EV                    # noqa: E402


def _pdf(path: Path, texts: dict) -> Path:
    """texts: {页码(1起): 文本}"""
    import fitz
    d = fitz.open()
    for _ in range(max(texts) if texts else 1):
        d.new_page()
    for pno, t in texts.items():
        d[pno - 1].insert_text((72, 72), t)
    d.save(path)
    d.close()
    return path


class VerifyTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="evtest_"))
        os.environ["ICPDF_WORKBENCH_DB"] = str(self.tmp / "t.sqlite3")
        os.environ["ICPDF_AUTH_USER"] = "esan"
        for m in [m for m in list(sys.modules) if m.startswith("app")]:
            del sys.modules[m]
        from app import db                              # noqa: E402
        self.db = db
        db.q1("SELECT 1")
        EV.ensure_cols(db)
        self.pdf = _pdf(self.tmp / "t.pdf",
                        {1: "IOIDD 10 uA MAX  portable audio buffer low power wide supply range"})
        self._old_pdf = EV._pdf_path
        EV._pdf_path = lambda mpn: str(self.pdf)

        db.x("INSERT INTO source_evidence(mpn,manufacturer,status,identity_status,created_at,"
             "updated_at) VALUES('T1','TI','field_review','pending',?,?)",
             (db.qc_now(), db.qc_now()))
        db.x("INSERT INTO source_document(source_tier,source_type,is_official,pdf_sha256,"
             "page_count,identity_status,created_at,updated_at)"
             " VALUES('P0','datasheet_pdf',1,'aa',1,'verified',?,?)",
             (db.qc_now(), db.qc_now()))
        db.x("UPDATE source_evidence SET document_id=1 WHERE id=1")
        gid = db.x("INSERT INTO gold_set(version,mpn,pdf_sha256,status,created_at,updated_at)"
                   " VALUES('v1','T1','aa','draft',?,?)", (db.qc_now(), db.qc_now()))
        self.gid = gid
        self.f_hi = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                         "cond,status) VALUES(?,?,?,?,?,'','pending')",
                         (gid, "electrical[3].value", "IOIDD", "10", "µA"))
        self.f_lo = db.x("INSERT INTO gold_field(gold_id,field_path,field_name,expected,unit,"
                         "cond,status) VALUES(?,?,?,?,?,'','pending')",
                         (gid, "features[0]", "feature", "portable", ""))
        self.fe_hi = db.x("INSERT INTO source_field_evidence(evidence_id,document_id,"
                          "gold_field_id,field_path,page_number,evidence_quote,"
                          "verification_status,created_at)"
                          " VALUES(1,1,?,'electrical[3].value',1,'10 uA','ready',?)",
                          (self.f_hi, db.qc_now()))
        self.fe_lo = db.x("INSERT INTO source_field_evidence(evidence_id,document_id,"
                          "gold_field_id,field_path,page_number,evidence_quote,"
                          "verification_status,created_at)"
                          " VALUES(1,1,?,'features[0]',1,'portable','ready',?)",
                          (self.f_lo, db.qc_now()))

    def tearDown(self):
        try:
            EV._pdf_path = self._old_pdf
            c = getattr(self.db._local, "conn", None)
            if c:
                c.close()
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    # ---- 批量：高风险必须被拒 ----
    def test_high_risk_rejected_in_batch(self):
        rep = EV.batch_verify(self.db, 1, [self.fe_hi, self.fe_lo], "u", dry=True)
        rj = {r["id"]: r["reason"] for r in rep["rejected"]}
        self.assertTrue(rj[self.fe_hi].startswith("high_risk:"), rj)
        self.assertEqual([v["id"] for v in rep["verified"]], [self.fe_lo])

    def test_batch_writes_verified_and_logs(self):
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u")
        row = self.db.q1("SELECT verification_status, reviewer FROM source_field_evidence "
                         "WHERE id=?", (self.fe_lo,))
        self.assertEqual((row["verification_status"], row["reviewer"]), ("verified", "u"))
        gf = self.db.q1("SELECT status FROM gold_field WHERE id=?", (self.f_lo,))
        self.assertEqual(gf["status"], "verified")           # 绑定 Gold 自动同步
        acts = [r["action"] for r in self.db.q("SELECT action FROM source_verification_log")]
        self.assertIn("field_verify_batch", acts)
        self.assertIn("batch_verify", acts)
        self.assertEqual(len(rep["verified"]), 1)

    def test_dry_no_write(self):
        EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        row = self.db.q1("SELECT reviewer FROM source_field_evidence WHERE id=?", (self.fe_lo,))
        self.assertFalse((row["reviewer"] or "").strip())

    def test_idempotent_already(self):
        EV.batch_verify(self.db, 1, [self.fe_lo], "u")
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u")
        self.assertEqual(len(rep["already"]), 1)
        self.assertFalse(rep["verified"])

    def test_not_in_this_card(self):
        rep = EV.batch_verify(self.db, 1, [9999], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "not_in_this_card")

    def test_batch_cap(self):
        rep = EV.batch_verify(self.db, 1, list(range(1, 300)), "u", dry=True)
        self.assertTrue(all(r["reason"] == "batch_cap_exceeded" for r in rep["rejected"]))

    def test_empty_ids(self):
        self.assertEqual(EV.batch_verify(self.db, 1, [], "u", dry=True)["error"],
                         "field_ids_empty")

    # ---- quote 回打 PDF（防错页/防编造）----
    def test_quote_not_on_page(self):
        self.db.x("UPDATE source_field_evidence SET evidence_quote='不存在的文本' WHERE id=?",
                  (self.fe_lo,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "quote_not_on_page")

    def test_page_out_of_range(self):
        self.db.x("UPDATE source_field_evidence SET page_number=99 WHERE id=?", (self.fe_lo,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "page_out_of_range")

    def test_numeric_mismatch_rejected(self):
        # quote 在页内（"10 uA"）但与 Gold expected 数值不符（99）→ 不放行
        self.db.x("UPDATE gold_field SET expected='99' WHERE id=?", (self.f_hi,))
        rep = EV.verify_one(self.db, self.fe_hi, "u", dry=True)
        self.assertEqual(rep["reason"], "quote_vs_expected_mismatch")

    def test_quote_missing_and_page_missing(self):
        self.db.x("UPDATE source_field_evidence SET evidence_quote=' ' WHERE id=?", (self.fe_lo,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "quote_missing")
        self.db.x("UPDATE source_field_evidence SET page_number=0 WHERE id=?", (self.fe_lo,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "page_missing")

    # ---- 单字段：放行高风险 ----
    def test_verify_one_allows_high_risk(self):
        r = EV.verify_one(self.db, self.fe_hi, "u")
        self.assertTrue(r.get("verified"), r)
        row = self.db.q1("SELECT verification_status, reviewer FROM source_field_evidence "
                         "WHERE id=?", (self.fe_hi,))
        self.assertEqual((row["verification_status"], row["reviewer"]), ("verified", "u"))

    # ---- SHA 一致性 ----
    def test_sha_mismatch(self):
        self.db.x("UPDATE gold_set SET pdf_sha256='bb' WHERE id=?", (self.gid,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "sha_mismatch_gold")

    def test_conflict_status_individual(self):
        self.db.x("UPDATE source_field_evidence SET verification_status='conflict_draft' "
                  "WHERE id=?", (self.fe_lo,))
        rep = EV.batch_verify(self.db, 1, [self.fe_lo], "u", dry=True)
        self.assertEqual(rep["rejected"][0]["reason"], "status_conflict_draft_individual")

    def test_high_risk_list_and_batchable(self):
        hr = EV.list_high_risk(self.db, 1)
        self.assertEqual([x["id"] for x in hr], [self.fe_hi])
        self.assertTrue(hr[0]["text"])
        self.assertEqual(EV.batchable(self.db, 1), [self.fe_lo])

    # ---- A 组：候选预填 + 人工填证据后核验 ----
    def test_field_candidates(self):
        self.db.x("UPDATE source_field_evidence SET candidates_json=? WHERE id=?",
                  (json.dumps([{"page": 3, "quote": "10 uA", "table": 0, "row": 2, "col": 1}],
                              ensure_ascii=False), self.fe_hi))
        c = EV.field_candidates(self.db, self.fe_hi)
        self.assertEqual(c["field_path"], "electrical[3].value")
        self.assertEqual(c["mpn"], "T1")
        self.assertEqual(c["evidence_id"], 1)
        self.assertEqual(c["top"]["page"], 3)
        self.assertEqual(len(c["candidates"]), 1)
        self.assertIsNone(EV.field_candidates(self.db, 999999))

    def test_field_candidates_empty_json(self):
        c = EV.field_candidates(self.db, self.fe_lo)
        self.assertEqual(c["candidates"], [])
        self.assertIsNone(c["top"])

    def test_verify_one_accepts_manual_evidence(self):
        """A 组弹窗：人工填 page/quote → 先更新该行再核验。"""
        self.db.x("UPDATE source_field_evidence SET page_number=0, evidence_quote='' WHERE id=?",
                  (self.fe_hi,))
        r = EV.verify_one(self.db, self.fe_hi, "esan", page_number=1, evidence_quote="10 uA")
        self.assertTrue(r.get("verified"), r)
        row = self.db.q1("SELECT page_number, evidence_quote, reviewer FROM "
                         "source_field_evidence WHERE id=?", (self.fe_hi,))
        self.assertEqual(row["page_number"], 1)
        self.assertEqual(row["evidence_quote"], "10 uA")
        self.assertEqual(row["reviewer"], "esan")

    def test_verify_one_manual_quote_still_checked_on_page(self):
        """人工填的 quote 也必须能在原厂 PDF 该页命中（回打校验不绕过）。"""
        r = EV.verify_one(self.db, self.fe_hi, "esan", page_number=1,
                          evidence_quote="99 mA 编造值")
        self.assertTrue(r.get("rejected"))
        self.assertEqual(r["reason"], "quote_not_on_page")     # 编造值打不到原厂页

    def test_verify_one_manual_quote_on_page_but_value_mismatch(self):
        """quote 在页内但与 expected 数值不符 → 仍被拒（数值三向）。"""
        self.db.x("UPDATE gold_field SET expected='99' WHERE id=?", (self.f_hi,))
        r = EV.verify_one(self.db, self.fe_hi, "esan", page_number=1, evidence_quote="10 uA")
        self.assertEqual(r["reason"], "quote_vs_expected_mismatch")

    def test_verify_one_manual_wrong_page_rejected(self):
        r = EV.verify_one(self.db, self.fe_hi, "esan", page_number=9,
                          evidence_quote="10 uA")
        self.assertEqual(r["reason"], "page_out_of_range")

    def test_mark_conflict_blocks_freeze(self):
        out = EV.mark_conflict(self.db, self.fe_lo, "PDF 实为 portable 之外", "esan")
        self.assertEqual(out["status"], "conflict")
        st = self.db.q1("SELECT verification_status FROM source_field_evidence WHERE id=?",
                        (self.fe_lo,))["verification_status"]
        self.assertEqual(st, "conflict")
        acts = [x["action"] for x in self.db.q("SELECT action FROM source_verification_log")]
        self.assertIn("field_conflict", acts)

    def test_mark_conflict_requires_reason(self):
        with self.assertRaises(ValueError):
            EV.mark_conflict(self.db, self.fe_lo, "  ", "esan")

    # ---- 高风险：裸数字 quote 不算原文证据 ----
    def test_high_risk_numeric_only_quote_rejected(self):
        """quote="10" 虽在页内，但纯数字无法证明行归属 → 高风险拒。"""
        self.db.x("UPDATE source_field_evidence SET evidence_quote='10' WHERE id=?",
                  (self.fe_hi,))
        r = EV.verify_one(self.db, self.fe_hi, "esan")
        self.assertEqual(r["reason"], "quote_numeric_only")
        # 带上单位/文字即可通过
        r2 = EV.verify_one(self.db, self.fe_hi, "esan", page_number=1,
                           evidence_quote="IOIDD 10 uA")
        self.assertTrue(r2.get("verified"), r2)

    # ---- 裁决 conflict_draft（解死锁）----
    def _to_conflict(self, fid=None):
        self.db.x("UPDATE source_field_evidence SET verification_status='conflict_draft',"
                  " reviewer='', evidence_quote='Figure 6-8' WHERE id=?", (fid or self.fe_hi,))

    def test_resolve_use_pdf_updates_gold_and_ready(self):
        self._to_conflict()
        out = EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan",
                                  expected="10", page_number=1,
                                  evidence_quote="IOIDD 10 uA",
                                  reason="以 p1 IOIDD 行为准（复核截图 2026-10-27）")
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["old_expected"], "10")
        row = self.db.q1("SELECT verification_status, reviewer, page_number, evidence_quote,"
                         " notes FROM source_field_evidence WHERE id=?", (self.fe_hi,))
        self.assertEqual(row["verification_status"], "ready")
        self.assertEqual((row["reviewer"] or ""), "")          # 裁决 != 核验
        self.assertEqual(row["page_number"], 1)
        self.assertEqual(row["evidence_quote"], "IOIDD 10 uA")
        self.assertIn("IOIDD", row["notes"])
        acts = [x["action"] for x in self.db.q("SELECT action FROM source_verification_log")]
        self.assertIn("field_resolve_use_pdf", acts)

    def test_resolve_use_pdf_changes_gold_expected(self):
        self._to_conflict()
        out = EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan",
                                  expected="12", page_number=1,
                                  evidence_quote="IOIDD 10 uA", reason="真值 12")
        self.assertEqual(out["expected"], "12")
        gf = self.db.q1("SELECT expected FROM gold_field WHERE id=?", (self.f_hi,))
        self.assertEqual(gf["expected"], "12")

    def test_resolve_use_pdf_quote_must_hit_pdf(self):
        self._to_conflict()
        out = EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan",
                                  expected="PDIP-8", page_number=1,
                                  evidence_quote="PDIP-8 | 8", reason="x")
        self.assertEqual(out["error"], "quote_not_on_page")
        st = self.db.q1("SELECT verification_status FROM source_field_evidence WHERE id=?",
                        (self.fe_hi,))["verification_status"]
        self.assertEqual(st, "conflict_draft")                  # 未落库
        gf = self.db.q1("SELECT expected FROM gold_field WHERE id=?", (self.f_hi,))
        self.assertEqual(gf["expected"], "10")

    def test_resolve_keep_gold_keeps_expected(self):
        self._to_conflict()
        out = EV.resolve_conflict(self.db, self.fe_hi, "keep_gold", "esan",
                                  reason="Gold 值有订购表行支撑，quote 待补")
        self.assertTrue(out["ok"], out)
        gf = self.db.q1("SELECT expected FROM gold_field WHERE id=?", (self.f_hi,))
        self.assertEqual(gf["expected"], "10")
        st = self.db.q1("SELECT verification_status FROM source_field_evidence WHERE id=?",
                        (self.fe_hi,))["verification_status"]
        self.assertEqual(st, "ready")

    def test_resolve_dry_no_write(self):
        self._to_conflict()
        out = EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan", expected="12",
                                  page_number=1, evidence_quote="IOIDD 10 uA",
                                  reason="dry", dry=True)
        self.assertTrue(out["dry"])
        self.assertEqual(self.db.q1("SELECT verification_status FROM source_field_evidence "
                                    "WHERE id=?", (self.fe_hi,))["verification_status"],
                         "conflict_draft")

    def test_resolve_requires_reason_and_action(self):
        self._to_conflict()
        with self.assertRaises(ValueError):
            EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan", expected="12",
                                page_number=1, evidence_quote="IOIDD 10 uA", reason="  ")
        with self.assertRaises(ValueError):
            EV.resolve_conflict(self.db, self.fe_hi, "auto", "esan", reason="x")

    def test_resolve_rejects_non_conflict_row(self):
        out = EV.resolve_conflict(self.db, self.fe_hi, "keep_gold", "esan", reason="x")
        self.assertEqual(out["error"], "not_conflict")

    def test_resolve_blocks_frozen_gold(self):
        self._to_conflict()
        self.db.x("UPDATE gold_set SET status='frozen' WHERE id=?", (self.gid,))
        out = EV.resolve_conflict(self.db, self.fe_hi, "use_pdf", "esan", expected="12",
                                  page_number=1, evidence_quote="IOIDD 10 uA", reason="x")
        self.assertEqual(out["error"], "gold_frozen")


if __name__ == "__main__":
    unittest.main()