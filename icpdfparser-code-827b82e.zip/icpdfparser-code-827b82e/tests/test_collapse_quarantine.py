# -*- coding: utf-8 -*-
"""列塌缩隔离：判出来之后，那批行**必须真的从页面上消失**。

`table_audit.audit_column_collapse` 只影响事实表结论，`specs.thermal` 里
「只取第一列、没写封装条件」的行照样会被渲染出去。外审判词是「客户不可用」，
所以隔离器是最后一道闸 —— 没测试的闸等于没闸。

这组用例只桩 `scan_tables`（PDF → 表格结构，不是被测逻辑），
**`audit_column_collapse` 用真实实现**：否则「能拦住」就只是桩在点头。
四个必测面：坏数据 / 空数据 / 多封装列（不许误杀）/ 探测失败（不许静默放行）。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import collapse_quarantine as CQ     # noqa: E402
from qc import table_audit as TA             # noqa: E402


# ─────────────────────────────────────────────────────────────────────
# 真实表结构：NE555 热阻表，6 个封装列
# ─────────────────────────────────────────────────────────────────────

NE555_TABLE = {"page": 5, "rows": [
    ["", "", "D (SOIC)", "FK (LCCC)", "JG (CDIP)", "P (PDIP)", "PS (SO)", "PW (TSSOP)", ""],
    ["RθJA", "Junction-to-ambient thermal resistance",
     "125.4", "92.2", "125.0", "98.5", "124.5", "164.2", "°C/W"],
    ["RθJC(top)", "Junction-to-case (top) thermal resistance",
     "64.9", "67.6", "73.3", "77.8", "61.2", "70.5", "°C/W"],
    ["RθJB", "Junction-to-board thermal resistance",
     "73.2", "66.7", "114.9", "61.0", "79.3", "104.8", "°C/W"],
    ["ψJT", "Junction-to-top characterization parameter",
     "14.3", "61.6", "44.4", "43.9", "16.5", "8.2", "°C/W"],
    ["ψJB", "Junction-to-board characterization parameter",
     "72.1", "66.5", "106.6", "60.3", "77.8", "103.1", "°C/W"],
]}

#: 坏数据：5 条参数全部只取第一列（D 列），`condition` 全空。
COLLAPSED = [
    {"name": "RθJA", "value": "125.4", "unit": "°C/W", "condition": ""},
    {"name": "RθJC(top)", "value": "64.9", "unit": "°C/W", "condition": ""},
    {"name": "RθJB", "value": "73.2", "unit": "°C/W", "condition": ""},
    {"name": "ψJT", "value": "14.3", "unit": "°C/W", "condition": ""},
    {"name": "ψJB", "value": "72.1", "unit": "°C/W", "condition": ""},
]

#: 同一张表按封装展开后（6 列 × 1 行示范）：`condition` 里点了封装名。
EXPANDED = [
    {"name": "RθJA", "value": v, "unit": "°C/W", "condition": c}
    for v, c in [("125.4", "D (SOIC) 8 PINS"), ("92.2", "FK (LCCC) 20 PINS"),
                 ("125.0", "JG (CDIP) 8 PINS"), ("98.5", "P (PDIP) 8 PINS"),
                 ("124.5", "PS (SO) 8 PINS"), ("164.2", "PW (TSSOP) 8 PINS")]
]


@pytest.fixture
def pdf_stub(tmp_path):
    """`detect` 只要求「这个路径是个文件」；真正的 scan_tables 被桩掉了。"""
    p = tmp_path / "sut.pdf"
    p.write_bytes(b"%PDF-1.7 stub")
    return p


class _Doc:
    """`pymupdf.open()` 的替身：`detect` 里用的是 `with … as fd`。"""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _patch(monkeypatch, tables):
    """桩掉 PDF → 表格结构这一段（不是被测逻辑）。

    `pymupdf.open` 也要桩：假 PDF 打不开，`detect` 会在 open 处就抛异常，
    `scan_tables` 永远不被调用 —— 那样测的就成了「桩有没有生效」。
    """
    import pymupdf

    monkeypatch.setattr(pymupdf, "open", lambda *a, **k: _Doc())
    if isinstance(tables, BaseException):
        def boom(fd):
            raise tables
        monkeypatch.setattr(TA, "scan_tables", boom)
    else:
        monkeypatch.setattr(TA, "scan_tables", lambda fd: tables)


# ─────────────────────────────────────────────────────────────────────
# 1. 坏数据：必须拦住
# ─────────────────────────────────────────────────────────────────────

def test_collapsed_rows_are_moved_out_of_the_visible_container():
    """判出来之后，`specs.thermal` 必须是空 —— 留在原地等于没隔离。"""
    doc = {"specs": {"thermal": [dict(r) for r in COLLAPSED]},
           "metadata": {"column_collapse": {"detected": True, "containers": ["thermal"]}}}

    st = CQ.quarantine(doc)

    assert doc["specs"]["thermal"] == [], "可见容器必须清空"
    bucket = doc["specs"][CQ.ISOLATION]
    assert len(bucket) == 5
    assert st["quarantined"] == 5
    # 原始行原样保留：复核方要能翻包看到「扣了什么、为什么扣」
    assert {r["name"] for r in bucket} == {"RθJA", "RθJC(top)", "RθJB", "ψJT", "ψJB"}
    assert all(r["quarantined_from"] == "thermal" for r in bucket)
    assert all("column_collapse" in r["quarantine_reason"] for r in bucket)
    assert doc["metadata"]["column_collapse_state"]["detected"] is True


def test_detect_flags_the_collapsed_json_through_the_real_auditor(monkeypatch, pdf_stub):
    """端到端：真实判据 + 真实表结构 → 必须产出一条 `column_collapse`。

    这里 `scan_tables` 是桩，但 `audit_column_collapse` 是**真的** ——
    桩掉被测判据，测试就只是在给自己点头。
    """
    _patch(monkeypatch, [NE555_TABLE])
    doc = {"specs": {"thermal": [dict(r) for r in COLLAPSED]}}

    finds = CQ.detect(doc, pdf_stub)

    kinds = [f.get("kind") for f in finds]
    assert "column_collapse" in kinds, f"塌缩 JSON 没被拦住：{finds}"
    hit = [f for f in finds if f["kind"] == "column_collapse"][0]
    assert hit["path"] == "specs.thermal"
    assert hit["table"]["rows_collapsed"] == 5


# ─────────────────────────────────────────────────────────────────────
# 2. 多封装列（正确展开）：不许误杀
# ─────────────────────────────────────────────────────────────────────

def test_expanded_rows_are_not_quarantined(monkeypatch, pdf_stub):
    """按封装展开、`condition` 写了封装名 → 不是塌缩。

    误杀的代价是把**已经修好的**数据撤下页面，比不拦更糟：
    客户看到的是空白，而问题其实已经解决了。
    """
    _patch(monkeypatch, [NE555_TABLE])
    doc = {"specs": {"thermal": [dict(r) for r in EXPANDED]}}

    finds = CQ.detect(doc, pdf_stub)
    assert finds == []

    doc["metadata"] = {}
    assert CQ.quarantine(doc) == {}
    assert len(doc["specs"]["thermal"]) == 6, "正常展开的行必须原样留在页面上"
    assert CQ.ISOLATION not in doc["specs"]


# ─────────────────────────────────────────────────────────────────────
# 3. 空数据 / 幂等
# ─────────────────────────────────────────────────────────────────────

def test_nothing_detected_means_no_bucket_is_created():
    """空数据不许凭空造出一个隔离桶 —— 渲染层会因此多一个空段落。"""
    doc = {"specs": {"thermal": [dict(r) for r in EXPANDED]}}
    assert CQ.quarantine(doc) == {}
    assert CQ.ISOLATION not in doc["specs"]
    assert CQ.count(doc) == 0


def test_quarantine_is_idempotent():
    """跑第二遍不许把同一批行再搬一次（复核方会以为有两份数据）。"""
    doc = {"specs": {"thermal": [dict(r) for r in COLLAPSED]},
           "metadata": {"column_collapse": {"detected": True, "containers": ["thermal"]}}}
    CQ.quarantine(doc)
    st2 = CQ.quarantine(doc)

    assert st2["quarantined"] == 0
    assert len(doc["specs"][CQ.ISOLATION]) == 5, "行数不许翻倍"


def test_detect_without_a_readable_pdf_returns_nothing():
    """没有原件就无从判断，返回空而不是抛异常 —— 装配不该因为缺 PDF 中断。"""
    assert CQ.detect({"specs": {}}, None) == []
    assert CQ.detect({"specs": {}}, "Z:/不存在的/文件.pdf") == []


def test_detection_failure_is_recorded_not_silently_passed(monkeypatch, pdf_stub):
    """探测炸了 ≠ 没有塌缩。必须留一条 `detect_error`，让人看见这个盲区。

    返回 `[]` 会让装配层以为「审计通过」，把一批没验过的行当合格品发出去。
    """
    _patch(monkeypatch, RuntimeError("PDF 解析失败"))
    finds = CQ.detect({"specs": {"thermal": [dict(r) for r in COLLAPSED]}}, pdf_stub)

    assert [f["kind"] for f in finds] == ["column_collapse_detect_error"]


# ─────────────────────────────────────────────────────────────────────
# 4. CLI：落盘与 dry-run
# ─────────────────────────────────────────────────────────────────────

def test_main_writes_the_quarantine_back_to_disk(tmp_path, monkeypatch, pdf_stub):
    _patch(monkeypatch, [NE555_TABLE])
    p = tmp_path / "NE555.json"
    p.write_text(json.dumps({"specs": {"thermal": [dict(r) for r in COLLAPSED]}},
                            ensure_ascii=False), encoding="utf-8")

    rc = CQ.main(["--json", str(p), "--pdf", str(pdf_stub)])
    saved = json.loads(p.read_text(encoding="utf-8"))

    assert rc == 0
    assert saved["specs"]["thermal"] == []
    assert len(saved["specs"][CQ.ISOLATION]) == 5


def test_main_dry_run_leaves_the_file_untouched(tmp_path, monkeypatch, pdf_stub):
    _patch(monkeypatch, [NE555_TABLE])
    p = tmp_path / "NE555.json"
    raw = json.dumps({"specs": {"thermal": [dict(r) for r in COLLAPSED]}}, ensure_ascii=False)
    p.write_text(raw, encoding="utf-8")

    CQ.main(["--json", str(p), "--pdf", str(pdf_stub), "--dry-run"])

    assert p.read_text(encoding="utf-8") == raw
