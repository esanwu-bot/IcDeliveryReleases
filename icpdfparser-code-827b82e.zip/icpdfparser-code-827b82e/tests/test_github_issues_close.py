# -*- coding: utf-8 -*-
"""GitHub 回帖与关单：发出去 / 关掉了，都必须**有凭据**。

这组用例守的是「修完之后队列真的清空了」这条闭环：

1. **关单没成功却返回成功** —— 下一轮 `sync` 仍把它当 open 拉下来，`next`
   还会把它派给本地 Agent，已修完的活被反复返工，队列越用越假。
2. **回帖没发出去却返回成功** —— 人打开工单看不到任何证据，只能当没修。
3. **空正文** —— GitHub 会拒，但错误信息埋在 422 的 JSON 里，不如自己先拦。
4. **关单原因写成 `not_planned`** —— 人扫一眼会以为「不修了」，与事实相反。
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.integrations import github_issues as GI      # noqa: E402


# ─────────────────────────────────────────────────────────────────────
# 假 GitHub：按方法 + URL 分派
# ─────────────────────────────────────────────────────────────────────

class FakeResp:
    def __init__(self, status: int = 200, payload=None):
        self.status_code = status
        self._payload = {} if payload is None else payload
        self.text = json.dumps(self._payload, ensure_ascii=False)

    def json(self):
        return self._payload


class FakeSession:
    def __init__(self, handler):
        self.handler = handler
        self.calls: list[dict] = []

    def post(self, url, json=None, headers=None, timeout=None):
        self.calls.append({"method": "POST", "url": url, "json": json or {}})
        return self.handler("POST", url, json or {})

    def patch(self, url, json=None, headers=None, timeout=None):
        self.calls.append({"method": "PATCH", "url": url, "json": json or {}})
        return self.handler("PATCH", url, json or {})

    def get(self, url, params=None, headers=None, timeout=None):
        self.calls.append({"method": "GET", "url": url, "params": params or {}})
        return self.handler("GET", url, {})


def _ok_comments(method, url, payload):
    return FakeResp(201, {"id": 9001, "html_url": "https://github.com/o/r/issues/14#c9001",
                          "created_at": "2026-11-03T07:00:00Z",
                          "body": payload.get("body")})


def _ok_close(method, url, payload):
    return FakeResp(200, {"number": 14, "state": "closed",
                          "state_reason": payload.get("state_reason"),
                          "closed_at": "2026-11-03T07:00:00Z",
                          "html_url": "https://github.com/o/r/issues/14"})


# ─────────────────────────────────────────────────────────────────────
# 1. 回帖
# ─────────────────────────────────────────────────────────────────────

def test_comment_posts_to_the_comments_endpoint_and_returns_the_url():
    """回帖必须回一个**能点开**的 html_url —— 那是它真的落库的唯一凭据。"""
    ses = FakeSession(_ok_comments)
    res = GI.comment_issue(14, "A22 已修", repo="o/r", token="t", session=ses)

    assert ses.calls[0]["method"] == "POST"
    assert ses.calls[0]["url"].endswith("/repos/o/r/issues/14/comments")
    assert ses.calls[0]["json"] == {"body": "A22 已修"}
    assert res["html_url"].startswith("https://github.com/")
    assert res["comment_id"] == 9001


def test_comment_is_the_same_code_path_as_reply():
    """`comment_issue` 是 `reply_issue` 的薄壳，行为必须一致。

    两份实现迟早漂移（一份加了长度校验、另一份没加），而回帖恰好是
    「内容超长被 GitHub 静默截断」最容易出事的路径。
    """
    body = "x" * (GI.MAX_COMMENT + 1)
    for fn in (GI.comment_issue, GI.reply_issue):
        with pytest.raises(ValueError):
            fn(14, body, repo="o/r", token="t", session=FakeSession(_ok_comments))


def test_empty_comment_is_refused_before_any_request():
    ses = FakeSession(_ok_comments)
    with pytest.raises(ValueError):
        GI.comment_issue(14, "   ", repo="o/r", token="t", session=ses)
    assert ses.calls == []


def test_comment_dry_run_does_not_hit_the_network():
    ses = FakeSession(_ok_comments)
    res = GI.comment_issue(14, "正文", repo="o/r", token="t", session=ses, dry_run=True)
    assert res["dry_run"] is True
    assert ses.calls == []


def test_comment_failure_is_not_reported_as_success():
    """4xx 必须抛错。返回成功等于「人以为发上去了，其实没发」。"""
    ses = FakeSession(lambda m, u, p: FakeResp(422, {"message": "Validation Failed"}))
    with pytest.raises(RuntimeError) as ei:
        GI.comment_issue(14, "正文", repo="o/r", token="t", session=ses)
    assert "422" in str(ei.value)
    assert "#14" in str(ei.value)


# ─────────────────────────────────────────────────────────────────────
# 2. 关单
# ─────────────────────────────────────────────────────────────────────

def test_close_patches_state_closed_with_completed_reason():
    """`state_reason` 必须是 `completed`：写成 `not_planned` 人一眼看成「不修了」。"""
    ses = FakeSession(_ok_close)
    res = GI.close_issue(14, repo="o/r", token="t", session=ses)

    call = ses.calls[0]
    assert call["method"] == "PATCH"
    assert call["url"].endswith("/repos/o/r/issues/14")
    assert call["json"] == {"state": "closed", "state_reason": "completed"}
    assert res["state"] == "closed"
    assert res["state_reason"] == "completed"


def test_close_reports_the_real_state_returned_by_github():
    """不信本地拼的字符串，只信服务端回来的 `state`。"""
    ses = FakeSession(lambda m, u, p: FakeResp(200, {"state": "open",
                                                     "state_reason": None}))
    res = GI.close_issue(14, repo="o/r", token="t", session=ses)
    assert res["state"] == "open", "服务端说没关，就不能报成已关"


def test_close_failure_raises_with_status_and_number():
    ses = FakeSession(lambda m, u, p: FakeResp(404, {"message": "Not Found"}))
    with pytest.raises(RuntimeError) as ei:
        GI.close_issue(14, repo="o/r", token="t", session=ses)
    msg = str(ei.value)
    assert "404" in msg and "#14" in msg


def test_close_dry_run_does_not_hit_the_network():
    ses = FakeSession(_ok_close)
    res = GI.close_issue(14, repo="o/r", token="t", session=ses, dry_run=True)
    assert res["request"]["json"]["state"] == "closed"
    assert ses.calls == []


def test_close_refuses_to_run_without_repo_or_token():
    """配置缺失要在发请求之前拒绝 —— 空仓库名会打到一个 404 让人查半天。"""
    ses = FakeSession(_ok_close)
    with pytest.raises(RuntimeError):
        GI.close_issue(14, repo="", token="t", session=ses)
    with pytest.raises(RuntimeError):
        GI.close_issue(14, repo="o/r", token="", session=ses)
    assert ses.calls == []


# ─────────────────────────────────────────────────────────────────────
# 3. CLI
# ─────────────────────────────────────────────────────────────────────

def test_close_cli_closes_every_id(monkeypatch, capsys):
    """一次关多张：回帖+关单是成对动作，逐张敲命令最容易漏掉最后一单。"""
    seen = []

    def fake_close(n, **kw):
        seen.append(n)
        return {"dry_run": False, "issue": n, "state": "closed",
                "state_reason": kw.get("state_reason"), "html_url": f"u{n}"}

    monkeypatch.setattr(GI, "close_issue", fake_close)
    rc = GI.main(["close", "--id", "14", "23", "--repo", "o/r", "--token", "t"])

    assert rc == 0
    assert seen == [14, 23]
    assert "已关单 #14" in capsys.readouterr().out


def test_close_cli_keeps_going_after_one_failure_and_exits_nonzero(monkeypatch, capsys):
    """一张失败不能中断其余：否则 14 成功、23 静默没关，人还以为都关了。"""
    calls = []

    def fake_close(n, **kw):
        calls.append(n)
        if n == 14:
            raise RuntimeError("404")
        return {"dry_run": False, "issue": n, "state": "closed",
                "state_reason": "completed", "html_url": "u"}

    monkeypatch.setattr(GI, "close_issue", fake_close)
    rc = GI.main(["close", "--id", "14", "23", "--repo", "o/r", "--token", "t"])

    assert calls == [14, 23], "第二张仍要尝试"
    assert rc != 0, "有失败就必须非零退出"


def test_close_subcommand_does_not_break_the_issue_json_cli():
    """`close` 分派不能顶掉「第一位置参数 = issue JSON 文件」的旧用法。"""
    args = ["nothere.json"]
    with pytest.raises(FileNotFoundError):
        GI.main(args)


def test_close_cli_dry_run_prints_request(capsys):
    rc = GI.main(["close", "--id", "14", "--repo", "o/r", "--token", "t", "--dry-run"])
    out = capsys.readouterr().out
    assert rc == 0
    assert '"state": "closed"' in out
