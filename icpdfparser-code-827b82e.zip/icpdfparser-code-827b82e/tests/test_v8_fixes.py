"""V8：V7 复审【新-1】【新-2】【新-3】的回归锁。

这四条都是"看起来对、跑起来错"的类型，靠人工读代码很难发现，全部固化成断言：

1. **数值等价的写法差异** —— JSON 的 `-5.0` 经 `_num_keys` 收成 `-5`，
   原文印 `–5.0`，旧正则 `(?<![\\d.])-5(?![\\d.])` 永远匹配不上；
   于是"两个数找到一个、另一个找不到"。
2. **一个没中 ≠ 一个都没有** —— 旧 `_derive` 把"部分命中"也判成 `not_found`，
   再配上"建议排除"，等于让人删掉一条正确参数。
3. **`not_found` 的默认处置** —— 排除不可逆，必须先由人翻页确认。
4. **列位没定不许给行级结论** —— 指纹是整行文本算的，把脚注吃进去也一致。
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "qc"))

import fact_acceptance as FA  # noqa: E402


# ── 1. 数值等价写法 ────────────────────────────────────────────
def test_num_forms_covers_trailing_zero_variants():
    assert "-5.0" in FA._num_forms("-5")
    assert "-5" in FA._num_forms("-5.0")
    # 非零小数不互通：`-5` 不能当成 `-5.25`
    assert "-5.25" not in FA._num_forms("-5")
    assert "-5" not in FA._num_forms("-5.25")


def test_token_pages_matches_padded_zero():
    """原文 `–5.0` 必须能被 JSON 的 `-5` 找到（V7 复审【新-1】的真实故障）。"""
    idx = ["Supply voltage HVSS to AGND -18 0.3",
           "Input negative supply voltage -16.5 -15.0 -5.0 V"]
    assert FA._token_pages(idx, "-5") == {2}
    assert FA._token_pages(idx, "-16.5") == {2}


def test_token_pages_does_not_match_other_decimals():
    idx = ["Differential input voltage -5.25 V"]
    assert FA._token_pages(idx, "-5") == set()


def test_token_pages_returns_union_of_equivalent_forms():
    """两种等价写法出现在不同页时，页码要并集，不能"第一种命中就返回"。"""
    idx = ["value -5.0 V", "value -5 V"]
    assert FA._token_pages(idx, "-5") == {1, 2}


# ── 2. 部分命中不得判 not_found ─────────────────────────────────
def test_partial_hit_is_not_not_found():
    ev = FA._Evidence(pdf_sha256="x" * 64, page=9,
                      nums={"-16.5", "-5"}, nums_found=False, nums_any=True,
                      extra="未在原文找到：-5")
    verdict, _ = FA._derive(ev)
    assert verdict == "partial", "找到一个、差一个不能判成『原文没有』"


def test_zero_hit_still_not_found():
    ev = FA._Evidence(pdf_sha256="x" * 64, page=9,
                      nums={"1.23"}, nums_found=False, nums_any=False)
    verdict, _ = FA._derive(ev)
    assert verdict == "not_found"


# ── 3. not_found 的处置建议 ────────────────────────────────────
def test_not_found_suggests_human_review_not_exclude():
    row = {"verdict": "not_found", "source": "model_unverified", "missing_cols": []}
    assert FA._suggest_action(row) == "human_review"


def test_partial_also_human_review():
    row = {"verdict": "partial", "source": "", "missing_cols": []}
    assert FA._suggest_action(row) == "human_review"


# ── 4. 列位没定不许给行级结论 ───────────────────────────────────
def test_missing_cols_downgrades_row_verdict():
    verdict, note = FA._downgrade_for_missing_cols("verified_row", ["min", "max"])
    assert verdict == "verified_value"
    assert "min/max" in note


def test_missing_cols_keeps_already_weak_verdict():
    verdict, _ = FA._downgrade_for_missing_cols("value_on_label_page", ["min"])
    assert verdict == "value_on_label_page"


def test_no_missing_cols_keeps_row_verdict():
    verdict, note = FA._downgrade_for_missing_cols("verified_row", [])
    assert (verdict, note) == ("verified_row", "")


# ── 5. 行带：多格合起来覆盖本行数值 ─────────────────────────────
def _ln(text, x0, y, x1):
    return {"text": text, "bbox": [x0, y, x1, y + 10], "win": 1}


def test_band_row_covers_values_split_across_cells():
    """`–16.5 –15.0 –5.0` 分在三格里，行带要能把三格合起来判覆盖。"""
    pages = {9: [_ln("HVSS", 57.0, 497.5, 78.8),
                 _ln("Input negative supply voltage", 112.4, 497.5, 216.5),
                 _ln("-16.5", 300.0, 497.5, 330.0),
                 _ln("-15.0", 340.0, 497.5, 370.0),
                 _ln("-5.0", 380.0, 497.5, 410.0)]}
    got = FA._band_row(pages, "Input Negative Supply Voltage (HVSS)",
                       {"-16.5", "-5"}, 9)
    assert got is not None
    assert got["page"] == 9
    assert got["bbox"][0] <= 112.4 and got["bbox"][2] >= 410.0


def test_band_row_refuses_ambiguous_fallback():
    """整串能命中多行、且每行都对得上数值时不猜 —— 也不许退到更弱的写法硬凑。

    （若只有一行对得上数值，那是数值在消歧，属于正常锚定，见下一条用例。）
    """
    pages = {9: [_ln("Analog supply voltage", 112.0, 100.0, 210.0),
                 _ln("Analog supply voltage", 112.0, 300.0, 210.0),
                 _ln("4.5", 300.0, 100.0, 330.0),
                 _ln("4.5", 300.0, 300.0, 330.0)]}
    assert FA._band_row(pages, "Analog Supply Voltage (AVDD)", {"4.5"}, 9) is None


def test_band_row_uses_values_to_disambiguate():
    """同名两行时，数值只对得上其中一行 —— 这是消歧，不是猜。"""
    pages = {9: [_ln("Analog supply voltage", 112.0, 100.0, 210.0),
                 _ln("Analog supply voltage", 112.0, 300.0, 210.0),
                 _ln("4.5", 300.0, 100.0, 330.0),
                 _ln("5.5", 300.0, 300.0, 330.0)]}
    got = FA._band_row(pages, "Analog Supply Voltage (AVDD)", {"4.5"}, 9)
    assert got is not None
    assert got["bbox"][1] == pytest.approx(100.0)


def test_label_needles_drops_parenthetical():
    needles = FA._label_needles("Input Negative Supply Voltage (HVSS)")
    assert needles[0] == "input negative supply voltage (hvss)"
    assert "input negative supply voltage" in needles


# ── 6. sha_input 必须能直接重算出指纹 ───────────────────────────
def test_band_sha_input_recomputes_fingerprint():
    """复审【新-6】：给了公式也 0/9 能重算，是因为没说「行文本」怎么取。

    现在直接把归一化输入串放进 `sha_input` 列，`sha256(sha_input)` 就是那个指纹，
    复核方逐字节对得上。
    """
    import hashlib

    pages = {9: [_ln("Input negative supply voltage", 112.4, 497.5, 216.5),
                 _ln("-16.5", 300.0, 497.5, 330.0),
                 _ln("-5.0", 380.0, 497.5, 410.0)]}
    got = FA._band_row(pages, "Input Negative Supply Voltage (HVSS)",
                       {"-16.5", "-5"}, 9)
    assert got is not None
    assert hashlib.sha256(got["sha_input"].encode("utf-8")).hexdigest() \
        == got["row_sha256"]


def test_paragraph_sha_input_recomputes_fingerprint():
    import hashlib

    text = "Analog input voltage   AVDD + 0.3   V"
    sha = FA._para_fingerprint(9, text)
    want = hashlib.sha256(FA._para_input(9, text).encode("utf-8")).hexdigest()
    assert want == sha


def test_dash_normalisation_covers_all_five_variants():
    """复审点名的五个破折号必须都能归一到 ASCII 连字符。

    `_DASHES` 从 V4 起就覆盖 U+2013/2014/2212/2012/FE63；这条把它钉住 ——
    以后再有人怀疑「是不是没归一」，跑这一条就有答案。
    """
    for ch in "\u2013\u2014\u2212\u2012\ufe63":
        assert FA._norm(f"{ch}16.5") == "-16.5"
        assert FA._norm(f"{ch}5") == "-5"


def test_token_pages_finds_en_dash_value():
    """原文写成 en-dash（U+2013）时，用 ASCII 写法也要能查到那一页。"""
    idx = [FA._norm("Input negative supply voltage HVSS \u201316.5 \u201315.0 \u20135.0")]
    assert FA._token_pages(idx, "-16.5") == {1}      # 页码 1-based
    assert FA._token_pages(idx, "-5") == {1}
