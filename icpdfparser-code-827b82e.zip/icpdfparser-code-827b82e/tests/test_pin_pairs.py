"""qc.pin_pairs 单测：差分对错位检测 + 假阳性闸（Unicode 破折号 / 单侧极性）。

背景：这条规则用于「名字顺序与脚号错位」的独立检出，历史上最大的坑是
负端用 Unicode 破折号（– / −）书写，正则只认 ASCII '-'，导致负端整批漏收、
bank 里只剩 '+'，于是把所有正常件都判成「同极性成对」。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc.pin_pairs import (audit_pin_pairs, collect_banks,  # noqa: E402
                          normalize_name, summarize)


def _doc(pairs) -> dict:
    """pairs: [(pin, name), ...]"""
    return {"pin_configuration": [{"pin": p, "name": n} for p, n in pairs]}


class PinPairsTest(unittest.TestCase):
    def test_normal_pairs_pass(self):
        doc = _doc([(1, "RX0+"), (2, "RX0-"), (3, "RX1+"), (4, "RX1-")])
        self.assertEqual(audit_pin_pairs(doc), [])

    def test_prefix_grouped_names_are_caught(self):
        """名字按前缀分组重排（先全部 +，再全部 -）→ 同通道 P/N 脚号被拉开。"""
        doc = _doc([(1, "RX0+"), (2, "RX1+"), (3, "RX0-"), (4, "RX1-")])
        finds = audit_pin_pairs(doc)
        self.assertEqual({f["kind"] for f in finds}, {"pin_pair_broken"})
        self.assertEqual(len(finds), 1)                  # 每 bank 一条，不用逐对刷屏
        self.assertIn("间距恒为 2", finds[0]["json"])

    def test_mixed_deltas_are_not_reported(self):
        """间距各不相同 = 封装布线不对称（QFN 两侧各放一半），不得判错位。"""
        doc = _doc([(14, "OA1+"), (38, "OA0-"), (39, "OA0+"), (48, "OA1-")])
        self.assertEqual(audit_pin_pairs(doc), [])

    def test_ball_grid_package_skipped(self):
        """球栅封装脚号是网格坐标，同通道 P/N 常隔一整行，不能按相邻性推断。"""
        doc = _doc([(8, "DA3+"), (10, "DA2+"), (20, "DA3-"), (22, "DA2-")])
        doc["specs"] = {"package": {"type": "292-Pin FCBGA", "pins": 292}}
        self.assertEqual(audit_pin_pairs(doc), [])
        # 去掉球栅标记后同一份数据会被判为「间距恒为 12」
        doc2 = _doc([(8, "DA3+"), (10, "DA2+"), (20, "DA3-"), (22, "DA2-")])
        self.assertEqual(audit_pin_pairs(doc2)[0]["kind"], "pin_pair_broken")

    def test_duplicate_lane_is_skipped(self):
        """多通道共用前缀（OUT0± 在 A/B 两通道各出现一次）→ 配对逻辑不成立，跳过。"""
        doc = _doc([(26, "OUT3+"), (27, "OUT2-"), (28, "OUT2+"), (29, "OUT3-"),
                    (39, "OUT3-"), (40, "OUT3+"), (41, "OUT2-"), (42, "OUT2+")])
        self.assertEqual(audit_pin_pairs(doc), [])

    def test_unicode_dash_is_not_false_positive(self):
        """负端写成 en dash / minus sign 时不得漏收（历史上的假阳性根因）。"""
        for dash in ("\u2013", "\u2212", "\u2014", "\uff0d"):
            doc = _doc([(1, "RX0+"), (2, f"RX0{dash}"),
                        (3, "RX1+"), (4, f"RX1{dash}")])
            self.assertEqual(audit_pin_pairs(doc), [],
                             f"破折号 {hex(ord(dash))} 被误判")

    def test_single_polarity_is_soft_finding(self):
        """bank 只有 '+' 时不判错位，只报 pin_polarity_missing（P2 级、交人工）。"""
        doc = _doc([(1, "RX0+"), (2, "RX1+"), (3, "RX2+"), (4, "RX3+")])
        finds = audit_pin_pairs(doc)
        self.assertEqual([f["kind"] for f in finds], ["pin_polarity_missing"])

    def test_odd_or_small_banks_are_skipped(self):
        """不足两对、或数量为奇数时不判（单端信号常见），避免误报。"""
        self.assertEqual(audit_pin_pairs(_doc([(1, "RX0+"), (2, "RX0-")])), [])
        self.assertEqual(audit_pin_pairs(
            _doc([(1, "RX0+"), (2, "RX1+"), (3, "RX0-")])), [])

    def test_banks_are_isolated(self):
        """不同 bank 各自成对，不跨 bank 混排。"""
        doc = _doc([(1, "INA0+"), (2, "INA0-"), (8, "OUTB0+"), (9, "OUTB0-")])
        self.assertEqual(audit_pin_pairs(doc), [])

    def test_multi_digit_lane(self):
        doc = _doc([(1, "CH10+"), (2, "CH10-"), (3, "CH11+"), (4, "CH11-")])
        self.assertEqual(audit_pin_pairs(doc), [])

    def test_non_string_pin_ignored(self):
        doc = {"pin_configuration": [
            {"pin": "1", "name": "RX0+"}, {"pin": "2", "name": "RX0-"},
            {"pin": "3", "name": "RX1+"}, {"pin": "4", "name": "RX1-"}]}
        self.assertEqual(audit_pin_pairs(doc), [])      # 脚号非 int，整批不判

    def test_normalize_name(self):
        self.assertEqual(normalize_name("  RX0\u2013 "), "RX0-")
        self.assertEqual(normalize_name(None), "")

    def test_collect_banks(self):
        banks = collect_banks(_doc([(1, "RX0+"), (2, "RX0\u2013"), (3, "VDD")]))
        self.assertEqual(banks, {"RX": [(1, "0", "+"), (2, "0", "-")]})

    def test_summarize_splits_two_kinds(self):
        doc = _doc([(1, "RX0+"), (2, "RX1+"), (3, "RX0-"), (4, "RX1-")])
        poles = _doc([(10, "TX0+"), (11, "TX1+"), (12, "TX2+"), (13, "TX3+")])
        s = summarize(audit_pin_pairs(doc) + audit_pin_pairs(poles))
        self.assertEqual(s["broken_pairs"], 1)
        self.assertEqual(s["polarity_missing"], 1)
        self.assertEqual(s["banks"], {"RX": 1})         # 只有真错位计入 bank 分布


if __name__ == "__main__":
    unittest.main()
