# -*- coding: utf-8 -*-
"""最终稿复验与核心错误阻断（batch100 暴露的解析状态机缺陷）。

事故形态：`doc` 在落盘前被改多次（确定性抽取原地覆盖、修复稿整份替换、
兜底模型替换、身份归一），而 `validate()` 只在「模型初稿」和「第一次
修复稿」上跑过。于是 BQ24715EVM-115 / ADS122U04EVM 的
`core_validation` 明明白白记着三条硬错，顶层 `status` 却是 `ok`。

本文件的用例把四件事钉住：
1. `ok` 必须同时满足「最终稿通过 validate」与「core_errs 为空」；
2. 结构不过 → failed，且错误串前缀保持 `PARSE_FAILED: `；
3. 结构过但核心有硬错 → `parsed_core_fail`，**不得**等于 `ok`；
4. `parsed_core_fail` 在阶段映射里落进 failed，下游不会继续流转。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

PD = pytest.importorskip("parse_datasheets")
C = pytest.importorskip("app.pipeline.contracts")


def _doc(n_elec: int = 3, *, pins: int = 0, identity: str | None = None) -> dict:
    bi = {"mpn": "X1", "manufacturer": "TI"}
    if identity is not None:
        bi["identity"] = identity
    return {
        "basic_info": bi,
        "specs": {"electrical": [{"name": f"e{i}"} for i in range(n_elec)]},
        "features": [], "applications": [], "alternatives": [],
        "ordering_info": [], "seo": {}, "metadata": {},
        "pin_configuration": [{"pin": i + 1, "name": f"P{i}"} for i in range(pins)],
    }


def test_clean_doc_and_no_core_errs_is_ok():
    st, errs = PD.final_gate(_doc(), [])
    assert (st, errs) == ("ok", [])


def test_core_errs_block_ok_status():
    """核心硬错误存在时，绝不能因为「JSON 能解析」就标 ok。"""
    st, errs = PD.final_gate(_doc(), ["pin_configuration 为空"])
    assert st == "parsed_core_fail", st
    assert st != "ok"
    assert errs == []


def test_final_validate_failure_is_failed_not_ok():
    """确定性处理把电气表清空后，最终稿必须被判 failed。"""
    doc = _doc(0)
    st, errs = PD.final_gate(doc, [])
    assert st == "failed", st
    assert any("specs.electrical only" in e for e in errs), errs


def test_final_gate_wins_over_core_errs():
    """结构与核心同时不过时，报结构错误（更上游、更可定位）。"""
    st, errs = PD.final_gate(_doc(0), ["pin_configuration 为空"])
    assert st == "failed"
    assert errs


def test_parsed_core_fail_is_distinct_constant():
    assert PD.STATUS_PARSED_CORE_FAIL == "parsed_core_fail"
    assert PD.STATUS_PARSED_CORE_FAIL != PD.STATUS_OK


def test_parsed_core_fail_maps_to_failed_stage():
    """阶段映射是白名单：只有 ok / thin_accepted / skipped 算通过。"""
    assert C.llm_status_to_stage("ok") == C.STATUS_OK
    assert C.llm_status_to_stage("skipped") == C.STATUS_SKIPPED
    assert C.llm_status_to_stage("parsed_core_fail") == C.STATUS_FAILED
    assert C.llm_status_to_stage("invalid_json") == C.STATUS_FAILED
    assert C.llm_status_to_stage("") == C.STATUS_FAILED


def test_thin_accepted_does_not_shrink_the_pass_set():
    """`thin_accepted` 只是把标签写诚实，放行范围与改动前必须完全一致。

    ACCEPT_THIN 放行的板卡在改动前是 `ok`、阶段映射为 ok；改动后叫
    `thin_accepted`，阶段映射**仍然**是 ok。若映射成 failed，等于借这次
    修复顺手收紧 ACCEPT_THIN、把 batch100 里 7 件正常板卡判死 —— 那不是
    本轮授权范围。
    """
    assert C.llm_status_to_stage("thin_accepted") == C.STATUS_OK


def test_both_entrypoints_use_the_same_gate():
    """`parse_one` 与 `parse_pdf` 必须调同一个 final_gate，不许各写一套。

    光断言"两边都出现 final_gate"不够：薄件参数漏传一边时，同一份板卡 PDF
    走 CLI 是 ok、走 worker 是 failed。所以连 `thin_allowed=` 一起断言。
    """
    import re
    root = Path(__file__).resolve().parent.parent
    one = (root / "parse_datasheets.py").read_text(encoding="utf-8")
    two = (root / "app" / "services" / "pipeline.py").read_text(encoding="utf-8")
    pat_one = re.compile(r"final_gate\(doc, core_errs,\s*thin_allowed=")
    pat_two = re.compile(r"pd\.final_gate\(doc, core_errs,\s*thin_allowed=")
    assert pat_one.search(one), "parse_one 未把 thin_allowed 传给 final_gate"
    assert pat_two.search(two), "parse_pdf 未把 thin_allowed 传给 final_gate"


def test_legacy_statuses_unchanged():
    """不改历史口径：invalid_json / failed / skipped 的字面值保持原样。"""
    assert PD.STATUS_OK == "ok"
    src = Path(__file__).resolve().parent.parent / "parse_datasheets.py"
    text = src.read_text(encoding="utf-8")
    assert 'PARSE_FAILED: invalid_json' in text or "invalid_json (" in text


# --------------------------------------------------------------------------
# ACCEPT_THIN 语义错位（板卡不能借「低规格芯片」的通道进门）
# 全部是红先用例：写的时候代码还没有守卫，先跑红，再加守卫转绿。
# --------------------------------------------------------------------------
def test_board_with_zero_elec_and_zero_pins_cannot_go_ok():
    """板卡 + 正式桶 0 电气 + 0 引脚 → 绝不能经 ACCEPT_THIN 变成 ok。

    红的形态：BQ24715EVM-115 / ADS122U04EVM / AFE7950 / TPS65131EVM-063 等
    9 件就是这个形状 —— 板卡的零电气零引脚是**诚实空**，不是「规格少」。
    """
    doc = _doc(0, pins=0, identity="evaluation_board")
    st, errs = PD.final_gate(doc, [], thin_allowed=True)
    assert st == "failed", st
    assert st != "ok" and st != PD.STATUS_THIN_ACCEPTED
    assert any("specs.electrical only" in e for e in errs), errs


def test_board_identity_guard_is_identity_not_content():
    """守卫按身份判，不按「有没有引脚」判。

    板卡就算把引脚抽出来（pins=10），没有电气表也不能走薄件通道 ——
    否则又是拿板卡内容去冒充芯片规格。
    """
    doc = _doc(0, pins=10, identity="evaluation_board")
    st, _ = PD.final_gate(doc, [], thin_allowed=True)
    assert st == "failed", st


def test_board_with_real_elec_is_still_ok():
    """守卫不误伤真有参数的板卡：正式桶 >= 3 就照常 ok。"""
    doc = _doc(5, pins=0, identity="evaluation_board")
    st, errs = PD.final_gate(doc, [], thin_allowed=True)
    assert (st, errs) == ("ok", [])


def test_development_kit_also_guarded():
    """`BOARD_TYPES` 里的另一支（development_kit）同样受守卫约束。"""
    doc = _doc(0, identity="development_kit")
    st, _ = PD.final_gate(doc, [], thin_allowed=True)
    assert st == "failed", st


def test_chip_low_spec_thin_still_accepted():
    """芯片低规格件（有引脚兜底）旧行为不回退：仍按薄件收下。"""
    doc = _doc(0, pins=8, identity="chip")
    st, errs = PD.final_gate(doc, [], thin_allowed=True)
    assert (st, errs) == (PD.STATUS_THIN_ACCEPTED, [])


def test_chip_thin_without_flag_still_fails():
    """没有薄件标记时，芯片也不能被自动放行 —— 守卫不扩大放行面。"""
    doc = _doc(0, pins=8, identity="chip")
    st, errs = PD.final_gate(doc, [], thin_allowed=False)
    assert st == "failed", st
    assert errs


def test_unknown_identity_keeps_old_behavior():
    """身份缺失时不拿猜测拒件：保持旧行为（按芯片对待）。

    这是显式的 fail-open，写在这里是为了让后来人一眼看到边界，而不是以为
    守卫对任何 doc 都无条件生效。
    """
    doc = _doc(0, pins=8)          # 没有 basic_info.identity
    st, _ = PD.final_gate(doc, [], thin_allowed=True)
    assert st == PD.STATUS_THIN_ACCEPTED
