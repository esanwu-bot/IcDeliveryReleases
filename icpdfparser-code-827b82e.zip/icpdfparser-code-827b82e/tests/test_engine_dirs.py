"""引擎对比目录口径单测：docstrange 必须读字段级 JSON（data/ab_odl/docstrange），
Markdown 缓存（data/ds_md）不参与对比；.alts/.seo/pre_audit/_* 产物被排除。
"""
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import goldset as gs                       # noqa: E402


class EngineDirTest(unittest.TestCase):
    def test_docstrange_dir_is_json_ab_dir(self):
        self.assertEqual(gs.ENGINE_DIRS["docstrange"], ["data/ab_odl/docstrange"])
        self.assertNotIn("data/ds_md", gs.ENGINE_DIRS["docstrange"])

    def test_pymupdf_falls_back_to_production(self):
        self.assertEqual(gs.ENGINE_DIRS["pymupdf"], ["data/ab_odl/pymupdf", "data/parsed"])

    def test_engine_docs_reads_json_only(self):
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            d = tmp / "data" / "ab_odl" / "docstrange"
            d.mkdir(parents=True)
            (d / "BUF634PG4.json").write_text("{}", encoding="utf-8")
            (d / "BUF634PG4_1a2b3c4d.json").write_text("{}", encoding="utf-8")
            (d / "BUF634PG4.md").write_text("# md", encoding="utf-8")
            (d / "AM26C32.alts.json").write_text("{}", encoding="utf-8")
            (d / "AM26C32.seo.json").write_text("{}", encoding="utf-8")
            old = gs.ROOT
            gs.ROOT = tmp
            try:
                docs = gs._engine_docs("docstrange")
            finally:
                gs.ROOT = old
            self.assertIn("BUF634PG4", docs)       # 哈希后缀被归一
            self.assertTrue(docs["BUF634PG4"].name.endswith(".json"))
            self.assertNotIn("AM26C32", docs)      # alts/seo 排除
            self.assertFalse(any(p.suffix == ".md" for p in docs.values()))

    def test_missing_engine_dir_returns_empty(self):
        with tempfile.TemporaryDirectory() as td:
            old = gs.ROOT
            gs.ROOT = Path(td)
            try:
                self.assertEqual(gs._engine_docs("opendataloader"), {})
            finally:
                gs.ROOT = old


if __name__ == "__main__":
    unittest.main()
