# -*- coding: utf-8 -*-
"""finding 的 `page` 字段（红先用例）。

背景：Review 指出「人工队列拿到的是无证据的红灯」。查下来问题是分层的 ——

* `row_ambiguous_unresolved` **有** page（`_ambiguous_finding` 自己补的）
* 其余 8 类（`cell_unparsable` / `range_collapse` / `qualifier_loss` / `row_mispair` /
  `unit_dimension` / `condition_leak` / `value_unsupported` / `footnote_missing`）
  **都没有**，页码只写在 entry 的 `source` 里，要人工 join 才看得到

修法用 ContextVar 而不是给 `finding()` 加第 5 个参数：模块里 15 处调用点逐个加
既冗长又必漏；更关键的是**不能**把 `finding` 包成局部 helper ——
`finding_kinds_audit` 靠扫描 `finding(path, "kind", ...)` 的字面量登记 kind，
包一层会让扫描失明（那是曾经出过假绿的防线）。

**红先声明**：`test_findings_carry_table_page` 在修复前是红的（KeyError: 'page'）。

另有一条必须守住的边界：`_PAGE` 是全局的，`audit_electrical` 退出时会残留最后一张表
的页码。若不在装订/引脚审计前清掉，`package_mismatch` / `pin_mismatch` 会带一个
**错误的**页码 —— 比没有页码更糟，人工会照着错页去翻。见 `test_page_cleared_before_ordering`。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

HDR = ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]
PDF = Path(__file__).resolve().parent.parent / "qc" / "pdfs" / "ADS7812B_1K__ads7812.pdf"


@pytest.fixture(autouse=True)
def _clean_page():
    """每个用例前后都把 `_PAGE` 归零 —— 它是全局状态，不隔离会互相污染。"""
    TA._PAGE.set(None)
    yield
    TA._PAGE.set(None)


def _tbl(page):
    return {"page": page, "ti": 0, "header": HDR,
            "rows": [["VOH", "", "2.4", "", "3.3", "V"]], "hx": [], "xr": []}


class TestFindingPage:
    """`finding()` 本身：有上下文就带，没上下文就不写（不猜页码）。"""

    def test_carries_page_when_set(self):
        TA._PAGE.set(7)
        assert TA.finding("p", "range_collapse", "1", {})["page"] == 7

    def test_omits_page_when_unset(self):
        assert "page" not in TA.finding("p", "range_collapse", "1", {})


class TestAuditElectricalPage:
    """`audit_electrical` 产生的 finding 要带**这张表**的页码。"""

    def test_findings_carry_table_page(self):
        e = {"name": "VOH", "value": "2.4 - 3.3", "unit": "V"}
        finds = TA.audit_electrical([e], [_tbl(7)], "specs.electrical")
        assert finds, "前置：这条必须产生 finding"
        assert all(f.get("page") == 7 for f in finds), [f.get("page") for f in finds]

    def test_multiple_tables_each_carry_own_page(self):
        """两张表分别在第 3、第 9 页 —— 各条 finding 不能串页。"""
        t1 = _tbl(3)
        t2 = {"page": 9, "ti": 1, "header": HDR,
              "rows": [["VOL", "", "0.1", "", "0.2", "V"]], "hx": [], "xr": []}
        e1 = {"name": "VOH", "value": "2.4 - 3.3", "unit": "V"}
        e2 = {"name": "VOL", "value": "0.1 - 0.2", "unit": "V"}
        finds = TA.audit_electrical([e1, e2], [t1, t2], "specs.electrical")
        by_json = {f["json"]: f.get("page") for f in finds}
        assert by_json.get("2.4 - 3.3") == 3
        assert by_json.get("0.1 - 0.2") == 9

    def test_unmatched_has_no_page(self):
        """匹配不到任何表 → 本来就没有页码可言，不许瞎填。"""
        e = {"name": "Totally Unknown Param", "value": "1"}
        finds = TA.audit_electrical([e], [_tbl(7)], "specs.electrical")
        un = [f for f in finds if f["kind"] == "table_unresolved"]
        assert un, [f["kind"] for f in finds]
        assert "page" not in un[0]

    def test_fused_early_exit_still_carries_page(self):
        """融合列条在 `continue` 前就 return，但它在 set 之后 —— 页码要带上。

        2026-10-31：`VOH` 命中 `_BLOCKING_PARAM_RE`（`\\bvoh\\b`），kind 从
        `cell_unparsable_unresolved` 升级为 `fused_column_blocking`。
        本用例验的是**页码传递**，与 kind 无关 —— 两种 kind 都算数。
        """
        tbl = {"page": 4, "ti": 0, "header": ["PARAMETER", "TESTCONDITIONS", "MIN TYP MAX", "UNIT"],
               "rows": [["VOH", "", "2.4 3.3", "V"]], "hx": [], "xr": []}
        e = {"name": "VOH", "value": "2.4", "unit": "V"}
        finds = TA.audit_electrical([e], [tbl], "specs.electrical")
        bad = [f for f in finds
               if f["kind"] in ("cell_unparsable_unresolved", "fused_column_blocking")]
        assert bad and bad[0].get("page") == 4, bad


class TestNoCrossPage:
    """装订/引脚审计不经过表，不能继承上一段残留的页码。"""

    def test_page_cleared_before_ordering(self, monkeypatch):
        if not PDF.exists():
            pytest.skip("缺基线 PDF")
        # 表扫描置空：本用例只验页码传递，不需要真表（否则要跑 40 页）
        monkeypatch.setattr(TA, "scan_tables", lambda doc, max_pages=None: [])
        seen = {}
        real = TA.audit_ordering

        def spy(doc, tables, req):
            seen["page"] = TA._PAGE.get()
            return real(doc, tables, req)

        monkeypatch.setattr(TA, "audit_ordering", spy)
        # 先人为制造残留
        TA._PAGE.set(42)
        TA.audit_json({"basic_info": {"mpn": "X"},
                       "specs": {"electrical": [], "absolute_max": []}}, str(PDF))
        assert seen["page"] is None, "装订审计前必须清掉残留页码"
