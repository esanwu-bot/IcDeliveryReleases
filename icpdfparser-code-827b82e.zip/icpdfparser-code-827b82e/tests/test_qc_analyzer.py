"""pandas QC Analyzer 离线单测（合成矩阵 + 临时 SQLite）。"""
import csv
import json
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import feedback as FB          # noqa: E402
from app.services import qc_analyzer as QA       # noqa: E402

MATRIX_COLS = [
    "mpn", "item_id", "batch_id", "brand", "status", "fail_count",
    "warn_count", "fail_codes", "warn_codes", "mpn_mismatch",
    "pdf_sha_mismatch", "electrical_row_bad", "electrical_empty", "json_mpn",
    "pdf_name", "pdf_rev", "pdf_sha256_item", "pdf_sha256_file",
    "facts_pdf_hash", "facts_parse_timestamp", "facts_model", "gold_status",
    "root_cause_group", "root_cause_groups", "fix_class", "pdf_has_ec_text",
]


class FakeDB:
    def __init__(self, path: Path):
        self.c = sqlite3.connect(str(path))
        self.c.row_factory = sqlite3.Row
        self.c.executescript(FB.DDL + QA.DDL)
        self.c.commit()

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None

    def x(self, sql, args=()):
        cur = self.c.execute(sql, args)
        self.c.commit()
        return cur.lastrowid if cur.lastrowid else cur.rowcount


def _row(**kw):
    d = {c: "" for c in MATRIX_COLS}
    d.update({"brand": "Texas Instruments", "pdf_rev": "A",
              "pdf_sha256_item": "a" * 64, "pdf_sha256_file": "a" * 64,
              "facts_pdf_hash": "a" * 64, "facts_model": "qwen-flash"})
    d.update(kw)
    return d


class AnalyzerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = FakeDB(Path(self.tmp.name) / "qca.sqlite3")
        self.matrix = Path(self.tmp.name) / "matrix.csv"
        rows = [
            _row(mpn="IC-I1", item_id="1", batch_id="b1", status="FAIL",
                 fail_count="1", fail_codes="ELECTRICAL_ROW_BAD",
                 electrical_row_bad="True",
                 root_cause_groups="I_解析结构缺陷（电气表行）",
                 fix_class="parser_fix_then_rerun_item_batch",
                 pdf_name="IC-I1.pdf", pdf_has_ec_text="True"),
            _row(mpn="IC-I2", item_id="2", batch_id="b2", status="FAIL",
                 fail_count="1", fail_codes="ELECTRICAL_EMPTY",
                 electrical_empty="True",
                 root_cause_groups="I_解析结构缺陷（电气表行）",
                 fix_class="parser_fix_then_rerun_item_batch",
                 pdf_name="IC-I2.pdf", pdf_has_ec_text="True"),
            _row(mpn="IC-A3", item_id="3", batch_id="b3", status="FAIL",
                 fail_count="1", fail_codes="MPN_MISMATCH",
                 mpn_mismatch="True", pdf_sha_mismatch="True",
                 root_cause_groups="A3_型号错配（可能 PDF/关联错误）",
                 fix_class="source_pdf_recovery_or_human",
                 pdf_name="IC-A3.pdf"),
            _row(mpn="IC-OK", item_id="4", batch_id="b4", status="PASS"),
            _row(mpn="IC-WARN", item_id="5", batch_id="b4", status="WARN",
                 warn_count="2", warn_codes="LANG_JA_MISSING"),
        ]
        with self.matrix.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=MATRIX_COLS)
            w.writeheader()
            w.writerows(rows)
        self.pdf_root = Path(self.tmp.name) / "pdfs"
        self.pdf_root.mkdir()
        for n in ("IC-I1.pdf", "IC-I2.pdf", "IC-A3.pdf"):
            (self.pdf_root / n).write_bytes(b"%PDF-1.4 fake")

        self.issue = FB.create_issue(self.db, {
            "issue_key": "CF-TEST-001", "title": "IC-I1 电气表行错",
            "description": "TYP 被合并", "category": "ELECTRICAL_TABLE",
            "severity": "P1_HIGH", "reporter": "customer",
            "source": "CUSTOMER", "required_evidence": "PDF 页码/表头/原文",
            "acceptance_criteria": "TYP/MAX 分列且人工验收",
            "root_cause_hypothesis": "列角色丢失",
        }, "tester")
        FB.add_sample(self.db, "CF-TEST-001", {
            "batch_id": "b1", "mpn": "IC-I1",
            "field_path": "electrical[0].value",
            "original_pdf_sha256": "a" * 64,
            "facts_source_sha256": "b" * 64,
            "parser_version": "qwen-flash",
            "rule_version": "matrix-v1",
            "expected_value": "TYP/MAX 分列", "actual_value": "合并",
        }, "tester")
        FB.add_regression(self.db, "CF-TEST-001", {
            "run_key": "r-test:CF-TEST-001", "scope_type": "SAMPLE",
            "scope_description": "IC-I1 fixture", "result": "FAIL",
            "total_cases": 1, "passed_cases": 0, "failed_cases": 1,
            "failure_summary": "cols_roles_any2",
        }, "tester")
        self.sig_patch = mock.patch.object(
            QA, "pdf_signals",
            side_effect=lambda p: {"pdf_has_ec_text": "YES",
                                   "electrical_parse_status": "HAS_EC_TEXT",
                                   "table_structure_type": "CONDITIONAL_MIN_TYP_MAX"})
        self.sig_patch.start()

    def tearDown(self):
        self.sig_patch.stop()
        self.db.c.close()
        self.tmp.cleanup()

    def _run(self, filters=None, persist=True):
        return QA.run_analysis(self.db, filters or {}, self.matrix, None,
                               self.pdf_root, "tester", persist=persist)

    def test_run_analysis_outputs(self):
        s = self._run()
        self.assertEqual(s["inventory"]["matrix_fail"], 3)
        self.assertEqual(s["inventory"]["feedback_issues"], 1)
        self.assertEqual(s["electrical"]["total"], 2)
        self.assertEqual(s["headline"]["electrical_items"], 2)
        codes = {r["error_code"] for r in s["electrical"]["rows"]}
        self.assertEqual(codes, {"ELECTRICAL_ROW_BAD", "ELECTRICAL_EMPTY"})
        self.assertTrue(any("MPN_MISMATCH" in a["reasons"]
                            for a in s["identity_source"]["items"]))
        layers = {c["candidate_layer"] for c in s["root_cause_candidates"]}
        self.assertTrue(any("电气表" in x for x in layers))
        keys = {t["task_key"] for t in s["tasks"]}
        self.assertIn("QCA-FB-CF-TEST-001", keys)
        self.assertTrue(any(k.startswith("QCA-MX-") for k in keys))
        self.assertTrue(any(k.startswith("QCA-EC-") for k in keys))
        self.assertEqual(s["regression"]["total"], 1)
        self.assertEqual(s["regression"]["pass_rate"], 0.0)
        self.assertEqual(s["regression"]["coverage"][0]["last_result"], "FAIL")
        brand = s["distributions"]["by_brand"][0]
        self.assertEqual(brand["total"], 5)
        self.assertEqual(brand["fail"], 3)
        self.assertAlmostEqual(brand["fail_rate"], 0.6, places=4)

    def test_status_all_filter(self):
        s = self._run({"status": "ALL"})
        self.assertEqual(s["inventory"]["matrix_rows"], 5)
        self.assertEqual(s["inventory"]["matrix_warn"], 1)

    def test_persistence_and_compare(self):
        a = self._run()
        runs = QA.list_runs(self.db)
        self.assertEqual(len(runs), 1)
        loaded = QA.get_run(self.db, a["run_key"])
        self.assertEqual(loaded["snapshot_id"], a["snapshot_id"])
        FB.transition(self.db, "CF-TEST-001", "TRIAGED", "分诊", "tester")
        b = self._run()
        cmp_ = QA.compare_runs(self.db, a["run_key"], b["run_key"])
        self.assertTrue(any(x["issue_key"] == "CF-TEST-001"
                            and x["change"] == "STATUS_CHANGED"
                            for x in cmp_["status_changes"]))

    def test_export_bundle(self):
        s = self._run()
        blob = QA.export_bundle(s)
        zp = Path(self.tmp.name) / "bundle.zip"
        zp.write_bytes(blob)
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for n in ("manifest.json", "00_inventory.csv",
                      "01_issue_distribution.csv",
                      "02_identity_source_anomalies.csv",
                      "03_root_cause_candidates.csv",
                      "04_electrical_crosstabs.csv",
                      "04b_electrical_rows.csv",
                      "05_regression_coverage.csv",
                      "05b_regression_failures.csv",
                      "06_engineering_tasks.csv",
                      "06_engineering_tasks.xlsx", "README.txt"):
                self.assertIn(n, names)
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            self.assertEqual(manifest["run_key"], s["run_key"])
            data = z.read("06_engineering_tasks.csv").decode("utf-8-sig")
            self.assertIn("QCA-FB-CF-TEST-001", data)
            self.assertNotIn(str(self.tmp.name), data)

    def test_tasks_csv_and_xlsx(self):
        s = self._run()
        text = QA.tasks_csv(s)
        self.assertIn("QCA-EC-", text)
        self.assertTrue(text.splitlines()[0].startswith("index,task_key,priority"))
        data = QA.tasks_xlsx(s)
        self.assertTrue(data.startswith(b"PK"))


if __name__ == "__main__":
    unittest.main()
