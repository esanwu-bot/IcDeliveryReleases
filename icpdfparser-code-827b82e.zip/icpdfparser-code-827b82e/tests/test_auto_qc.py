"""30 件/批自动 r1–r6 QC 流水线离线单测。

覆盖：
  * 正常批次产出 ZIP/报告/audit，交付历史可识别；
  * 缺 PDF 时 auto_qc=FAIL、L1=FAIL；
  * ZIP 内不暴露服务器绝对路径；
  * 交付历史优先使用 audit 里的 zip SHA/大小（不重算大 ZIP）。
"""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import auto_qc as AQ                  # noqa: E402
from qc import delivery_history as DH         # noqa: E402


def _write(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(data, encoding="utf-8")


def make_item(data_dir: Path, iid: int, mpn: str, with_pdf=True) -> dict:
    safe = AQ._safe_name(mpn)
    pdf = data_dir / "pdfs" / (safe + "__x.pdf")
    if with_pdf:
        _write(pdf, b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<<>>\nendobj\n")
    js = data_dir / "parsed" / (safe + "_abc.json")
    facts = {
        "basic_info": {"mpn": mpn, "manufacturer": "Texas Instruments"},
        "specs": {
            "electrical": [
                {"name": "Bandwidth", "value": "1", "unit": "MHz", "condition": ""},
                {"name": "Supply", "value": "5", "unit": "V", "condition": ""},
            ],
            "package": {"type": "SOIC-8", "pins": 8, "dimensions": ""},
        },
        "pin_configuration": [{"pin": i, "name": "P%d" % i} for i in range(1, 9)],
        "multi_language": {k: {"description": mpn} for k in ("ja", "ko", "de", "es")},
        "seo": {"title_en": mpn},
        "features": ["x"], "applications": ["y"],
        "ordering_info": [{"mpn": mpn}],
    }
    _write(js, json.dumps(facts, ensure_ascii=False))
    txt = data_dir / "txt" / (safe + ".txt")
    _write(txt, "<p>%s</p>" % mpn)
    for lang in ("ja", "ko", "de", "es"):
        _write(data_dir / "txt" / ("%s.%s.txt" % (safe, lang)), "<p>%s</p>" % mpn)
    sym = data_dir / "symbols" / (safe + ".html")
    _write(sym, "<svg>%s</svg>" % mpn)
    seo = data_dir / "seo" / (safe + ".json")
    _write(seo, json.dumps({"title_en": mpn}))
    altj = data_dir / "alts" / (safe + ".json")
    alth = data_dir / "alts" / (safe + ".html")
    _write(altj, json.dumps({"mpn": mpn, "items": []}))
    _write(alth, "<div>%s</div>" % mpn)
    sha = hashlib.sha256(pdf.read_bytes()).hexdigest() if with_pdf else ""
    return {
        "id": iid, "mpn": mpn, "brand": "Texas Instruments", "status": "done",
        "pdf_path": str(pdf) if with_pdf else "", "pdf_sha256": sha,
        "json_path": str(js), "txt_path": str(txt), "symbol_path": str(sym),
        "seo_path": str(seo), "alt_json_path": str(altj),
        "alt_html_path": str(alth), "meta": "{}",
    }


class AutoQCTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name) / "data"
        self.out = Path(self.tmp.name) / "qc"
        for d in ("pdfs", "parsed", "txt", "symbols", "seo", "alts"):
            (self.data / d).mkdir(parents=True)
        self.items = [
            make_item(self.data, 1, "T1"),
            make_item(self.data, 2, "T2"),
        ]

    def tearDown(self):
        self.tmp.cleanup()

    def test_batch_outputs_and_history(self):
        batch = {"batch_id": "qc30-20260102-0001", "item_ids": [1, 2]}
        res = AQ.run_batch(batch, self.items, self.data, self.out, {},
                           include_pdf=True, hash_pdf=True, pdf_probe="none")
        self.assertEqual(res["auto"]["status"], "PASS")
        d = self.out / batch["batch_id"]
        self.assertTrue((d / "manifest.csv").is_file())
        self.assertTrue((d / "核验报告.md").is_file())
        self.assertTrue((d / "qc_quality_audit.json").is_file())
        audit = json.loads((d / "qc_quality_audit.json").read_text(encoding="utf-8"))
        self.assertFalse(audit["release_approved"])
        self.assertEqual(audit["layers"]["L3"]["status"], "NOT_CHECKED")
        self.assertEqual(audit["release_gates"]["RELEASE_APPROVED"]["status"], "FAIL")
        self.assertEqual(len(audit["details"]["zip_sha256"]), 64)
        self.assertIn("r1–r6", (d / "核验报告.md").read_text(encoding="utf-8"))
        b = DH.get_batch(batch["batch_id"], self.out)
        self.assertIsNotNone(b)
        self.assertEqual(b["auto_qc"]["status"], "PASS")
        self.assertEqual(b["sample_count"], 2)
        self.assertEqual(b["fields_total"], 8)
        self.assertEqual(b["zip"]["sha256"], audit["details"]["zip_sha256"])

    def test_zip_has_no_absolute_paths(self):
        batch = {"batch_id": "qc30-20260102-0002", "item_ids": [1]}
        AQ.run_batch(batch, self.items[:1], self.data, self.out, {},
                     include_pdf=True, hash_pdf=True, pdf_probe="none")
        import zipfile
        zp = next((self.out / batch["batch_id"]).glob("*.zip"))
        with zipfile.ZipFile(zp) as z:
            qi = json.loads(z.read("qc_items.json").decode("utf-8"))
            self.assertEqual(qi[0]["artifacts"]["json"], "T1_abc.json")
            self.assertNotIn("/app/", z.read("qc_items.json").decode("utf-8"))
            self.assertIn("T1/T1.pdf", z.namelist())

    def test_missing_pdf_fails(self):
        bad = make_item(self.data, 3, "T3", with_pdf=False)
        batch = {"batch_id": "qc30-20260102-0003", "item_ids": [3]}
        res = AQ.run_batch(batch, [bad], self.data, self.out, {},
                           include_pdf=False, hash_pdf=False, pdf_probe="none")
        self.assertEqual(res["auto"]["status"], "FAIL")
        d = self.out / batch["batch_id"]
        audit = json.loads((d / "qc_quality_audit.json").read_text(encoding="utf-8"))
        self.assertEqual(audit["auto_qc"]["fail_items"], 1)
        self.assertEqual(audit["layers"]["L1"]["status"], "FAIL")

    def test_history_zip_sha_is_cached(self):
        batch = {"batch_id": "qc30-20260102-0004", "item_ids": [1]}
        AQ.run_batch(batch, self.items[:1], self.data, self.out, {},
                     include_pdf=True, hash_pdf=True, pdf_probe="none")
        with mock.patch.object(DH, "_sha256", side_effect=AssertionError("不应重算 ZIP")):
            b = DH.get_batch(batch["batch_id"], self.out)
        self.assertEqual(b["zip"]["size"], (self.out / batch["batch_id"] /
                                            b["zip"]["name"]).stat().st_size)

    def test_family_inherited_identity(self):
        self.assertTrue(AQ._family_inherited("ADC12DJ5200SEEVM", "ADC12DJ5200SE"))
        self.assertTrue(AQ._family_inherited("ADS9212EVM", "ADS9212"))
        self.assertTrue(AQ._family_inherited("ADC3140EVM-PDK", "TLV320ADC3140"))
        self.assertFalse(AQ._family_inherited("2MTR-DYNO", "TMS320F2806x"))
        self.assertFalse(AQ._family_inherited("ADS8900BEVM-PDK", "OPA625"))


if __name__ == "__main__":
    unittest.main()
