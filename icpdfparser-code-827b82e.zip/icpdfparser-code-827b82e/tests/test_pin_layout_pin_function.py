#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""D4：`PIN | FUNCTION`（多封装列 + 描述）引脚表的确定性抽取。

Phase 1.7.1 遗留问题：LM317 的引脚表不是 `NAME | NO.` 两列，而是

    PIN / I/O / DESCRIPTION / NAME / TO-220 (Legacy Chip) / TO-263 / SOT-223
    ADJUST  1 1 1  —  Output voltage adjustment pin. Connect to a resistor divider…
    INPUT   3 3 3  I  Input voltage pin for the regulator.
    OUTPUT  2, TAB 2, TAB 2, TAB  O  Output voltage pin for the regulator.

`extract_pins` 只认 `NAME` 紧跟 `NO.` 的表头，所以 LM317 实测抽出 0 条，
引脚只能靠模型给（模型方差）。本文件先写成会红的用例：要求 3 条、
名称→引脚号正确，并且**功能描述绝不能被当成引脚名**。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                      # noqa: E402

LM317_PDF = ROOT / "data" / "pdfs" / "LM317__lm317.pdf"


class _Page:
    def __init__(self, lines):
        self._text = "\n".join(lines)

    def get_text(self):
        return self._text


#: LM317 p5 文本层行序（含三张封装俯视图 —— 它们**不是**引脚表，
#: 解析必须从 `PIN … NAME …` 表头之后开始，不能把俯视图里的 ADJUST/OUTPUT 当成行）。
LM317_PIN_PAGE = [
    "5 Pin Configuration and Functions",
    "1", "2", "3",
    "ADJUST", "OUTPUT", "INPUT", "OUTPUT", "4",
    "Figure 5-1. DCY Package, 4-Pin SOT-223 (Top View)",
    "3", "2", "1",
    "INPUT", "OUTPUT", "ADJUST", "OUTPUT",
    "Figure 5-2. KCS or KCT Package, 3-Pin TO-220",
    "(Top View), Legacy Chip",
    "3", "2", "1",
    "INPUT", "OUTPUT", "ADJUST", "OUTPUT",
    "Figure 5-3. KTT Package, 3-Pin TO-263 (Top View)",
    "Pin Functions, Metal Can Packages",
    "PIN", "I/O", "DESCRIPTION", "NAME",
    "TO-220", "(Legacy Chip)", "TO-263", "SOT-223",
    "ADJUST", "1", "1", "1", "—",
    "Output voltage adjustment pin. Connect to a",
    "resistor divider to set VOUT.",
    "INPUT", "3", "3", "3", "I",
    "Input voltage pin for the regulator.",
    "OUTPUT", "2, TAB", "2, TAB", "2, TAB", "O",
    "Output voltage pin for the regulator.",
    "www.ti.com", "LM317", "SLVS044Z – SEPTEMBER 1997 – REVISED APRIL 2025",
]

#: 描述行后面跟着数字（最容易被误认成「名字 + 引脚号」的形态）。
BOGUS_DESCRIPTION = [
    "PIN", "I/O", "DESCRIPTION", "NAME", "SOT-223",
    "Output voltage adjustment pin.", "2", "3",
    "resistor divider to set VOUT.",
]


def test_lm317_pin_function_layout_extracts_three_pins():
    pins = DE.extract_pins([_Page(LM317_PIN_PAGE)])
    assert len(pins) == 3, pins
    by_name = {p["name"]: p["pin"] for p in pins}
    assert by_name == {"ADJUST": "1", "INPUT": "3", "OUTPUT": "2"}
    desc = {p["name"]: p["description"] for p in pins}
    assert desc["ADJUST"].startswith("Output voltage adjustment pin.")
    assert desc["INPUT"] == "Input voltage pin for the regulator."
    assert desc["OUTPUT"] == "Output voltage pin for the regulator."


def test_function_description_is_never_a_pin_name():
    """描述句 + 数字也不许拼出一条「引脚」：名字必须是短大写符号。"""
    pins = DE.extract_pins([_Page(BOGUS_DESCRIPTION)])
    assert pins == [], pins


def test_package_drawings_before_table_are_ignored():
    """表头之前的封装俯视图（ADJUST/OUTPUT/INPUT + 数字）不能产生引脚。"""
    page_only_drawings = _Page(LM317_PIN_PAGE[:27])
    assert DE.extract_pins([page_only_drawings]) == []


@pytest.mark.skipif(not LM317_PDF.exists(), reason="缺少 LM317 原件")
def test_real_lm317_pdf_extracts_three_pins():
    import pymupdf
    with pymupdf.open(str(LM317_PDF)) as doc:
        pins = DE.extract_pins(doc)
    assert len(pins) == 3
    assert {p["name"]: p["pin"] for p in pins} == {
        "ADJUST": "1", "INPUT": "3", "OUTPUT": "2"}
    assert all(p["page"] == 5 for p in pins)
