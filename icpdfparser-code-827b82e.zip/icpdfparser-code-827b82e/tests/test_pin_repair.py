"""P0-6：球位集合与 PDF 功能映射校验；真实集成仅修改内存副本。"""
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import pytest

import symbol_svg as S
from qc import pin_repair as PR
from qc.scope_contract import BOARD_TYPES

ROOT = Path(__file__).resolve().parents[1]
PDF = ROOT / "data/pdfs/ADC12DJ5200SEAAV__adc12dj5200se.pdf"
JSON = ROOT / "data/acceptance_20261030/parsed/ADC12DJ5200SE.json"
BALLS = {f"{r}{c}" for r in "ABCDEFGHJKLM" for c in range(1, 13)}


@pytest.fixture
def pdf_rows():
    # 合成原表只用于单元测试，不冒充真实器件的功能签核。
    return [{"pin": b, "name": f"SIGNAL_{b}", "function": "I", "description": f"PDF input {b}.",
             "source": {"pdf_sha256": "a" * 64, "page": 4, "page_base": 1,
                        "table": 0, "table_index": 0, "row": i + 2, "index_base": 0,
                        "bbox": [10, 20 + i, 400, 21 + i], "scope": "device",
                        "subject_mpn": "ADC12DJ5200SE", "package_ball_count": 144,
                        "table_name": "Table 4-1"}}
            for i, b in enumerate(sorted(BALLS, key=PR._ball_key))]


@pytest.fixture
def document(pdf_rows):
    return {"basic_info": {"mpn": "ADC12DJ5200SE", "identity": "chip"},
            "specs": {"scope": "device", "package": {"type": "FCBGA144", "pins": 144}},
            "pin_configuration": copy.deepcopy(pdf_rows), "pin_scope": "device"}


def use_pdf(monkeypatch, rows):
    monkeypatch.setattr(PR, "ball_pins_from_pdf", lambda *args, **kwargs: copy.deepcopy(rows))


def repair(doc):
    return PR.repair_bga_pins(doc, PDF)


def assert_unresolved(doc, report):
    assert report["status"] == report["action"] == "unresolved"
    assert doc["pin_scope"] == "unresolved"
    assert doc["pin_configuration"] == []
    assert S.pins_of(doc) == []
    page = S.render_page(doc)
    assert "BGA 球位待核" in page
    assert "工程验收通过" in page
    assert "<svg" not in page and "<img" not in page
    assert "PIN1" not in page and "schematic symbol" not in page


def test_complete_letters_are_revalidated(monkeypatch, pdf_rows, document):
    use_pdf(monkeypatch, pdf_rows)
    report = repair(document)
    assert report["action"] == "rebuilt"
    assert report["status"] == report["input_validation"]["status"] == "pass"
    assert report["expected_count"] == report["actual_count"] == report["covered_count"] == 144
    assert set(report["expected_balls"]) == set(report["actual_balls"]) == set(report["covered_balls"]) == BALLS
    assert PR.bga_pin_validation(document)["status"] == "pass"
    assert len(S.pins_of(document)) == 144


@pytest.mark.parametrize("damage", ["missing", "duplicate", "wrong_name", "wrong_function", "old_description", "numeric"])
def test_old_wrong_mapping_is_repaired_not_format_pass(monkeypatch, pdf_rows, document, damage):
    use_pdf(monkeypatch, pdf_rows)
    old = document["pin_configuration"]
    if damage == "missing":
        old.pop()
    elif damage == "duplicate":
        old[-1] = copy.deepcopy(old[0])
    elif damage == "numeric":
        document["pin_configuration"] = [{"pin": i, "name": "wrong", "description": "wrong"}
                                         for i in range(1, 16)]
        document["specs"]["package"]["pins"] = 15
    else:
        field = {"wrong_name": "name", "wrong_function": "function", "old_description": "description"}[damage]
        old[0][field] = "旧错误内容"
    snapshot = copy.deepcopy(document["pin_configuration"])
    report = repair(document)
    assert report["input_validation"]["status"] == "fail"
    assert report["status"] == "pass" and report["action"] == "rebuilt"
    assert document["pin_configuration"] == pdf_rows
    assert document["specs"]["package"]["pins"] == 144
    assert document["metadata"]["pin_repair_history"][0]["old_pin_configuration"] == snapshot
    assert "旧错误内容" not in str(document["pin_configuration"])
    if damage in ("wrong_name", "wrong_function", "old_description"):
        assert report["input_validation"]["mapping_mismatches"]
    if damage == "duplicate":
        assert report["input_validation"]["duplicate_balls"] == ["A1"]
    if damage == "missing":
        assert report["input_validation"]["missing_balls"] == ["M12"]


def test_missing_sources_never_count_as_input_pass(monkeypatch, pdf_rows, document):
    use_pdf(monkeypatch, pdf_rows)
    for pin in document["pin_configuration"]:
        pin.pop("source")
    report = repair(document)
    assert report["input_validation"]["status"] == "fail"
    assert report["input_validation"]["source_unverified_count"] == 144
    assert report["status"] == "pass"


@pytest.mark.parametrize("damage", ["missing", "duplicate_same", "duplicate_conflict", "wrong_set", "bad_source", "missing_function", "wrong_subject", "wrong_count"])
def test_bad_pdf_never_rebuilt_pass(monkeypatch, pdf_rows, document, damage):
    rows = copy.deepcopy(pdf_rows)
    if damage == "missing":
        rows.pop()
    elif damage.startswith("duplicate"):
        rows.append(copy.deepcopy(rows[0]))
        if damage == "duplicate_conflict":
            rows[-1]["name"] = "OTHER_FUNCTION"
    elif damage == "wrong_set":
        rows[-1]["pin"] = "I12"
    elif damage == "bad_source":
        rows[0]["source"]["bbox"] = None
    elif damage == "missing_function":
        rows[0]["function"] = ""
    elif damage == "wrong_subject":
        for row in rows:
            row["source"]["subject_mpn"] = "ANOTHER_IC"
    else:
        for row in rows:
            row["source"]["package_ball_count"] = 15
    use_pdf(monkeypatch, rows)
    report = repair(document)
    assert_unresolved(document, report)
    assert report["expected_count"] == 144
    if damage == "missing":
        assert report["actual_count"] == report["covered_count"] == 143
        assert report["missing_balls"] == ["M12"]
    if damage.startswith("duplicate"):
        assert report["duplicate_balls"] == ["A1"]
        assert report["actual_entries"] == 145 and report["actual_count"] == 144
        assert report["covered_count"] == 143
    if damage == "wrong_subject":
        assert report["covered_count"] == 0
    if damage == "wrong_set":
        assert report["missing_balls"] == ["M12"] and report["extra_balls"] == ["I12"]


def test_pdf_missing_does_not_keep_old_engineering_symbol(document, tmp_path):
    report = PR.repair_bga_pins(document, tmp_path / "missing.pdf")
    assert_unresolved(document, report)
    assert "pdf_missing" in report["reasons"]
    assert report["expected_count"] == 144 and report["covered_count"] == 0


def test_corrupt_pdf_returns_unresolved(document, tmp_path):
    pdf = tmp_path / "corrupt.pdf"
    pdf.write_bytes(b"not a pdf")
    report = PR.repair_bga_pins(document, pdf)
    assert_unresolved(document, report)
    assert any(r.startswith("pdf_extract_error:") for r in report["reasons"])


@pytest.mark.parametrize("scope", ["unverified_dropped", "unresolved", None, "onboard_device"])
def test_unverified_bga_scope_never_numeric_fallback(document, scope):
    document["pin_scope"] = scope
    document["pin_configuration"] = []
    page = S.render_page(document)
    assert "BGA 球位待核" in page
    assert "PIN1" not in page and "<svg" not in page
    assert S._typical_pins("FCBGA-144") == 0
    assert S._typical_pins("WLCSP") == 0


@pytest.mark.parametrize("damage", ["missing", "duplicate", "name", "function", "description", "source", "numeric", "wrong_count"])
def test_stale_pass_is_not_authority_to_draw(monkeypatch, pdf_rows, document, damage):
    use_pdf(monkeypatch, pdf_rows)
    assert repair(document)["status"] == "pass"
    pins = document["pin_configuration"]
    if damage == "missing":
        pins.pop()
    elif damage == "duplicate":
        pins[-1] = copy.deepcopy(pins[0])
    elif damage == "source":
        pins[0]["source"]["page"] = 0
    elif damage == "numeric":
        pins[0]["pin"] = "1"
    elif damage == "wrong_count":
        document["specs"]["package"]["pins"] = 15
    else:
        pins[0][damage] = "错误值"
    assert PR.bga_pin_validation(document)["status"] == "unresolved"
    assert "BGA 球位待核" in S.render_page(document)
    assert S.pins_of(document) == []
    preview = S.preview_page([("ADC12DJ5200SE", document)])
    assert "BGA 球位待核" in preview and "schematic symbol" not in preview


@pytest.mark.parametrize("identity", BOARD_TYPES)
@pytest.mark.parametrize("basic_key", ["basic_info", "basic"])
def test_all_shared_board_types_use_canonical_view(identity, basic_key):
    doc = {basic_key: {"mpn": "BOARD_TEST", "identity": identity, "device_mpn": "ONBOARD_IC"},
           "specs": {"scope": "board", "package": {"type": "QFN", "pins": 144}},
           "pin_scope": "device", "pin_configuration": [{"pin": 1, "name": "BAD"}, {"pin": 2, "name": "BAD"}]}
    original = copy.deepcopy(doc)
    assert S.BOARD_TYPES is BOARD_TYPES
    page = S.render_page(doc)
    assert "板卡 / 模块类" in page and "ONBOARD_IC" in page
    assert "schematic symbol" not in page and "<svg" not in page
    assert doc == original


def test_bga_candidates_keep_source_even_without_old_pins(monkeypatch, pdf_rows, document):
    use_pdf(monkeypatch, pdf_rows[:-1])
    document["pin_configuration"] = []
    report = repair(document)
    assert_unresolved(document, report)
    candidates = document["metadata"]["pin_repair_history"][-1]["pdf_candidates"]
    assert len(candidates) == 143
    assert all(p["source"]["page_base"] == 1 for p in candidates)


def test_bga_from_legacy_package_lookup_still_blocks_numeric_symbols(document):
    document["specs"]["package"]["type"] = ""
    document["basic_info"]["description"] = "144-ball BGA"
    document["pin_configuration"] = [{"pin": i, "name": f"BAD{i}"} for i in range(1, 16)]
    assert S.pins_of(document) == []
    assert "BGA 球位待核" in S.render_page(document)


def test_bga_alias_conflict_is_canonical_block(monkeypatch, pdf_rows, document):
    use_pdf(monkeypatch, pdf_rows)
    repair(document)
    document["basic"] = {"mpn": "ANOTHER_IC", "identity": "chip"}
    assert "BGA 球位待核" in S.render_page(document)


def test_non_bga_keeps_legacy_behavior(monkeypatch):
    doc = {"basic_info": {"mpn": "LEGACY"}, "specs": {"package": {"type": "SOIC", "pins": 8}},
           "pin_configuration": []}
    before = copy.deepcopy(doc)
    assert PR.repair_bga_pins(doc, "missing.pdf")["action"] == "not_bga"
    assert doc == before
    calls = []
    monkeypatch.setattr(S, "footprint_svg", lambda pins, *args: calls.append(pins) or "legacy footprint")
    assert "legacy footprint" in S.render_page(doc)
    assert calls[-1] == [(i, f"PIN{i}") for i in range(1, 9)]
    doc["specs"]["package"]["pins"] = 0
    assert "legacy footprint" in S.render_page(doc)
    assert calls[-1] == [(i, f"PIN{i}") for i in range(1, 9)]
    doc["pin_configuration"] = [{"pin": 0, "name": "A"}, {"pin": 0, "name": "B"}]
    assert S.pins_of(doc) == [(1, "A"), (2, "B")]


def test_bga_functions_do_not_guess_geometry(monkeypatch, pdf_rows, document, tmp_path):
    use_pdf(monkeypatch, pdf_rows)
    repair(document)
    # 即便旧共享图已存在，也不能把功能表签核升级为封装几何签核。
    (tmp_path / "FCBGA-144.svg").write_text("MISLEADING_SHARED_FOOTPRINT", encoding="utf-8")
    (tmp_path / "FCBGA-144.3d.svg").write_text("MISLEADING_SHARED_3D", encoding="utf-8")
    page = S.render_page(document, pkg_dir=tmp_path)
    assert "schematic symbol" in page
    assert "PIN1" not in page and "<img" not in page
    assert "占位图" in page
    assert "<circle" not in S.footprint_svg([(i, "BAD") for i in range(1, 145)], "FCBGA-144", 144)
    assert "<circle" not in S.model3d_svg([], "FCBGA-144")


@pytest.fixture(scope="module")
def real_pdf_evidence():
    if not PDF.is_file() or not JSON.is_file():
        pytest.skip("真实 ADC PDF 或候选 JSON 缺失；集成项未检查")
    pytest.importorskip("pymupdf")
    return PR.ball_pins_from_pdf(PDF), PDF.read_bytes(), JSON.read_bytes()


@pytest.mark.slow
def test_real_pdf_all_144_source_rows_mapping_and_coverage(monkeypatch, real_pdf_evidence):
    import pymupdf

    rows, pdf_before, json_before = real_pdf_evidence
    assert len(rows) == 64
    use_pdf(monkeypatch, rows)
    doc = json.loads(json_before.decode("utf-8"))
    report = repair(doc)
    assert report["status"] == "pass"
    assert report["expected_count"] == report["actual_count"] == report["covered_count"] == 144
    assert set(report["expected_balls"]) == set(report["actual_balls"]) == set(report["covered_balls"]) == BALLS
    assert report["missing_balls"] == report["extra_balls"] == report["duplicate_balls"] == []
    pins = doc["pin_configuration"]
    assert len(pins) == len({p["pin"] for p in pins}) == 144
    assert {p["source"]["page"] for p in pins} == {4, 5, 6, 7, 8}
    assert {p["source"]["table_name"] for p in pins} == {"Table 4-1"}
    assert {p["source"]["pdf_sha256"] for p in pins} == {hashlib.sha256(pdf_before).hexdigest()}
    assert PR.bga_pin_validation(doc)["status"] == "pass"
    # 独立读取原页文本 blocks 校对四列；不用 repair 的 words 重拼实现生成期望值。
    compact = lambda text: re.sub(r"\s+", "", text).replace("–", "-").replace("—", "-")
    checked_rows = set()
    table_cells = {}
    row_text = {}
    with pymupdf.open(PDF) as pdf:
        for p in pins:
            source = p["source"]
            assert source["page_base"] == 1 and source["scope"] == "device"
            key = (source["page"], source["table"], source["row"])
            checked_rows.add(key)
            page = pdf[source["page"] - 1]
            table_key = key[:2]
            if table_key not in table_cells:
                table = page.find_tables().tables[source["table"]]
                table_cells[table_key] = [list(row.cells) for row in table.rows]
            if key not in row_text:
                cells = table_cells[table_key][source["row"]]
                row_text[key] = [page.get_text("text", clip=pymupdf.Rect(c)) for c in cells]
            text = row_text[key]
            assert compact(p["name"]) == compact(text[0])
            assert p["pin"] in re.findall(r"\b[A-Z]{1,2}\d{1,2}\b", text[1])
            assert compact(p["function"]) == compact(text[2])
            assert compact(p["description"]) == compact(text[3])
    assert len(checked_rows) == 64
    by_pin = {p["pin"]: p for p in pins}
    assert by_pin["F1"]["name"] == "CLK+" and by_pin["F1"]["function"] == "I"
    assert "common ground plane (GND)" in by_pin["A1"]["description"]
    assert Counter(p["function"] for p in pins) == Counter({"—": 51, "O": 39, "I": 54})
    symbol = S.render_page(doc)
    drawn = re.findall(r'<text[^>]*fill="#c0392b">([A-Z]{1,2}\d{1,2})</text>', symbol)
    assert len(drawn) == 144 and set(drawn) == BALLS
    assert "PIN1" not in symbol and "<img" not in symbol
    assert PDF.read_bytes() == pdf_before and JSON.read_bytes() == json_before


def test_real_pdf_truncated_extraction_does_not_fake_full_coverage(monkeypatch, real_pdf_evidence):
    rows, _, json_before = real_pdf_evidence
    use_pdf(monkeypatch, [r for r in rows if r["source"]["page"] < 8])
    doc = json.loads(json_before.decode("utf-8"))
    report = repair(doc)
    assert_unresolved(doc, report)
    assert report["expected_count"] == 144
    assert report["actual_count"] < 144 and report["missing_balls"]
