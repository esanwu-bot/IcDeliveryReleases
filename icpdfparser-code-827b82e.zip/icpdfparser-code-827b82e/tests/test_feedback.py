"""客户反馈闭环 V1 业务规则离线单测（SQLite 临时库）。"""
import json
import sqlite3
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import feedback as FB       # noqa: E402


class FakeDB:
    def __init__(self, path: Path):
        self.c = sqlite3.connect(str(path))
        self.c.row_factory = sqlite3.Row
        self.c.executescript(FB.DDL)
        self.c.commit()

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None

    def x(self, sql, args=()):
        cur = self.c.execute(sql, args)
        self.c.commit()
        return cur.lastrowid if cur.lastrowid else cur.rowcount


class FeedbackTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = FakeDB(Path(self.tmp.name) / "fb.sqlite3")
        self.db.c.executescript(
            "CREATE TABLE item(mpn TEXT,brand TEXT,pdf_path TEXT,pdf_url TEXT,"
            "pdf_sha256 TEXT);"
            "CREATE TABLE gold_set(mpn TEXT,status TEXT);")
        self.db.c.execute("INSERT INTO item VALUES('T1','TI','/app/data/pdfs/T1.pdf',"
                          "'https://ti.com/x.pdf','b'*64)")
        self.db.c.commit()
        self.issue = FB.create_issue(self.db, {
            "title": "电气参数表格错列",
            "description": "电流上限被解析为功耗",
            "category": "ELECTRICAL_TABLE",
            "severity": "P1_HIGH",
            "reporter": "user:qa",
        }, "user:qa")
        self.key = self.issue["issue"]["issue_key"]

    def tearDown(self):
        self.db.c.close()
        self.tmp.cleanup()

    def _ready(self):
        self.db.x("UPDATE customer_feedback_issue SET status='PENDING_HUMAN_ACCEPTANCE' "
                  "WHERE issue_key=?", (self.key,))
        sample = FB.add_sample(self.db, self.key, {
            "batch_id": "qc30-20261028-0451", "mpn": "T1",
            "field_path": "specs.electrical[2].value", "expected_value": "24 mA",
            "actual_value": "24 mW", "original_pdf_sha256": "a" * 64,
        }, "user:qa")
        ev = FB.add_evidence(self.db, self.key, {
            "sample_link_id": sample["id"], "evidence_type": "MANUFACTURER_PDF",
            "document_title": "Datasheet", "document_sha256": "b" * 64,
            "page_number": 8, "quote_text": "Maximum supply current 24 mA",
        }, "user:qa")
        FB.review_evidence(self.db, ev["id"], {
            "review_status": "VERIFIED", "review_reason": "页码与原文一致",
        }, "user:qc")
        FB.add_fix(self.db, self.key, {"summary": "修正列映射",
                                       "commit_sha": "abc123"}, "user:dev")
        FB.add_regression(self.db, self.key, {
            "run_key": "run-1", "scope_type": "SAMPLE",
            "scope_description": "T1 单样本", "result": "PASS",
            "total_cases": 1, "passed_cases": 1, "failed_cases": 0,
        }, "user:dev")
        return sample

    def test_full_flow(self):
        sample = self._ready()
        acc = FB.acceptance(self.db, self.key, {
            "sample_link_id": sample["id"], "decision": "ACCEPT",
            "scope_description": "电气字段与页面", "reason": "证据/回归一致",
        }, "user:qc")
        self.assertEqual(acc["decision"], "ACCEPT")
        self.assertEqual(FB._sample(self.db, sample["id"])["acceptance_status"],
                         "ACCEPTED")
        # PENDING_HUMAN_ACCEPTANCE -> ACCEPTED -> CLOSED
        FB.transition(self.db, self.key, "ACCEPTED", "样本验收完成", "user:qc")
        closed = FB.close_issue(self.db, self.key, {"reason": "全部样本验收"},
                                "user:qc")
        self.assertEqual(closed["issue"]["status"], "CLOSED")
        self.assertTrue(closed["issue"]["closed_at"])
        self.assertGreaterEqual(len(closed["audit"]), 7)

    def test_acceptance_requires_regression_and_evidence(self):
        sample = FB.add_sample(self.db, self.key, {
            "batch_id": "b1", "mpn": "T1",
        }, "user:qa")
        with self.assertRaises(FB.FeedbackError) as e:
            FB.acceptance(self.db, self.key, {
                "sample_link_id": sample["id"], "decision": "ACCEPT",
                "scope_description": "x", "reason": "y",
            }, "user:qc")
        self.assertEqual(e.exception.code, "REGRESSION_REQUIRED")
        FB.add_regression(self.db, self.key, {
            "run_key": "run-x", "scope_type": "SAMPLE",
            "scope_description": "x", "result": "PASS",
            "total_cases": 1, "passed_cases": 1, "failed_cases": 0,
        }, "user:dev")
        with self.assertRaises(FB.FeedbackError) as e2:
            FB.acceptance(self.db, self.key, {
                "sample_link_id": sample["id"], "decision": "ACCEPT",
                "scope_description": "x", "reason": "y",
            }, "user:qc")
        self.assertEqual(e2.exception.code, "EVIDENCE_REQUIRED")

    def test_invalid_transition_and_close(self):
        with self.assertRaises(FB.FeedbackError) as e:
            FB.transition(self.db, self.key, "CLOSED", "x", "user:qa")
        self.assertEqual(e.exception.code, "INVALID_TRANSITION")
        FB.add_sample(self.db, self.key, {"batch_id": "b1", "mpn": "T1"},
                      "user:qa")
        self.db.x("UPDATE customer_feedback_issue SET status='ACCEPTED' "
                  "WHERE issue_key=?", (self.key,))
        with self.assertRaises(FB.FeedbackError) as e2:
            FB.close_issue(self.db, self.key, {"reason": "x"}, "user:qc")
        self.assertEqual(e2.exception.code, "SAMPLES_PENDING")

    def test_batch_summary_and_dashboard(self):
        self._ready()
        s = FB.batch_summary(self.db, "qc30-20261028-0451")
        self.assertEqual(s["issues"], 1)
        self.assertEqual(s["samples"], 1)
        self.assertTrue(s["release_blocked"])
        d = FB.dashboard(self.db)
        self.assertEqual(d["total"], 1)
        self.assertEqual(d["blocking"], 1)
        self.assertGreaterEqual(d["samples"], 1)
        bm = FB.batch_map(self.db, ["qc30-20261028-0451", "none"])
        self.assertEqual(bm["qc30-20261028-0451"]["issues"], 1)
        self.assertEqual(bm["qc30-20261028-0451"]["blocking"], 1)

    def test_grouping(self):
        rows = FB.list_issues(self.db, {"category": "ELECTRICAL_TABLE"})
        self.assertEqual(rows["total"], 1)
        self.assertEqual(rows["items"][0]["sample_count"], 0)
        rows2 = FB.list_issues(self.db, {"batch_id": "qc30-20261028-0451"})
        self.assertEqual(rows2["total"], 0)

    def test_export_bundle(self):
        self._ready()
        qc_dir = Path(self.tmp.name) / "qc"
        b = qc_dir / "qc30-20261028-0451"
        b.mkdir(parents=True)
        (b / "qc_quality_audit.json").write_text(json.dumps({
            "layers": {k: {"status": "PASS"} for k in ("L1", "L2", "L3", "L4")},
            "release_gates": {
                "PACKAGE_PASS": {"status": "PASS"},
                "PROVENANCE_PASS": {"status": "PASS"},
                "DATA_SEMANTICS_PASS": {"status": "NOT_CHECKED"},
                "DOWNSTREAM_PASS": {"status": "PASS"},
                "RELEASE_APPROVED": {"status": "FAIL"},
            },
            "release_approved": False,
        }), encoding="utf-8")
        blob = FB.export_bundle(self.db, {}, qc_dir)
        zp = Path(self.tmp.name) / "export.zip"
        zp.write_bytes(blob)
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for n in ("manifest.json", "issues.csv", "samples.csv", "evidence.csv",
                      "regressions.csv", "audit_events.csv", "delivery_gates.csv",
                      "source_files.csv", "field_diff.csv"):
                self.assertIn(n, names)
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            self.assertEqual(manifest["row_counts"]["issues.csv"], 1)
            self.assertEqual(manifest["row_counts"]["samples.csv"], 1)
            self.assertEqual(manifest["row_counts"]["regressions.csv"], 1)
            gates = z.read("delivery_gates.csv").decode("utf-8-sig")
            self.assertIn("qc30-20261028-0451", gates)
            self.assertIn("NOT_CHECKED", gates)
            text = z.read("samples.csv").decode("utf-8-sig")
            self.assertIn("NOT_CHECKED", text)
            self.assertNotIn(str(self.tmp.name), text)
            self.assertIn("HAS_FIELD_PATH", text)
            fd = z.read("field_diff.csv").decode("utf-8-sig")
            self.assertIn("DIFF_UNVERIFIED", fd)
            regs = z.read("regressions.csv").decode("utf-8-sig")
            self.assertIn("run-1", regs)
            self.assertTrue(regs.splitlines()[1].startswith("1,1,1,"))

    def test_export_manifest_counts_multiline_fields(self):
        """字段含换行时 manifest 行数仍按记录数，不按文本行数。"""
        FB.update_issue(self.db, self.key,
                        {"reproduction_steps": "第一行\n第二行"}, "user:qa")
        blob = FB.export_bundle(self.db, {})
        zp = Path(self.tmp.name) / "export2.zip"
        zp.write_bytes(blob)
        with zipfile.ZipFile(zp) as z:
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            self.assertEqual(manifest["row_counts"]["issues.csv"], 1)
            self.assertEqual(manifest["row_counts"]["evidence.csv"], 0)
            text = z.read("issues.csv").decode("utf-8-sig")
            self.assertIn("第一行", text)


if __name__ == "__main__":
    unittest.main()
