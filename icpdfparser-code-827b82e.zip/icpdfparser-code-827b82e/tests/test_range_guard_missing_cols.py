# -*- coding: utf-8 -*-
"""`range_origin=column_roles_verified` 与「缺列」互斥 —— ADS1201U 这条 P0 的回归闸。

判据（Issue #4 / V9 复审 P0-1）：原表印着

    Differential Input Voltage Range | With VBIAS(1) | -20 | See Note 2 | +20 | V

`TYP` 格是脚注，MIN/MAX 是「剩下的两格」推出来的，事实表记
`missing_cols=min,max`。列位没定，就不许在 JSON 里声称列角色已核验 ——
**不管 `fact_verdict` 是强是弱**。

改之前 `qc/range_guard.py` 只判 `fact_verdict ∈ WEAK_VERDICTS`：结论一旦是
`verified_row`（或压根没跑事实表同步），带着 `missing_cols` 的行照样留着
`range_origin=column_roles_verified` 和一段能读的 `{min,max}`，下游照投毒不误。
这里把那条缝锁死。
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from qc import range_guard as RG


def _row(origin="column_roles_verified", verdict="verified_row", missing=None,
         with_range=True):
    """造一条「输入范围」子行；`missing=None` 表示字段压根不存在。"""
    row = {
        "name": "Differential Input Voltage Range",
        "condition": "With VBIAS(1)",
        "verification": {"fact_verdict": verdict},
    }
    if missing is not None:
        row["verification"]["missing_cols"] = missing
    if origin:
        row["range_origin"] = origin
    if with_range:
        row["range"] = {"min": "-20", "max": "+20"}
    return row


def test_missing_cols_blocks_trusted_even_with_strong_verdict():
    """核心反例：`verified_row` + `missing_cols=min,max` 也不许声称已核验。"""
    row = _row(verdict="verified_row", missing="min,max")
    assert RG.is_trusted(row) is False
    assert RG.safe_range(row) is None


def test_weak_verdict_without_missing_cols_still_blocked():
    """不回退：`verified_value` 这条老判据照旧生效。"""
    assert RG.is_trusted(_row(verdict="verified_value", missing=None)) is False


def test_clean_row_stays_trusted():
    """不误伤：结论强 + 没缺列的行照旧能读。"""
    row = _row(verdict="verified_row", missing="")
    assert RG.is_trusted(row) is True
    assert RG.safe_range(row) == {"min": "-20", "max": "+20"}


@pytest.mark.parametrize("missing", [None, "", "  ", ","])
def test_empty_missing_cols_is_not_missing(missing):
    """空串 / 只有逗号 / 字段不存在 —— 都不算缺列，不许误判成矛盾。"""
    assert RG._missing_cols(_row(missing=missing)) == []
    assert RG.is_trusted(_row(verdict="verified_row", missing=missing)) is True


def test_enforce_strips_only_the_contradiction():
    """物理抹除只打矛盾行，同表里干净的那条一个字不动。"""
    doc = {"specs": {"electrical": [
        _row(verdict="verified_row", missing="min,max"),
        _row(verdict="verified_row", missing=""),
    ]}}
    report = RG.enforce(doc)
    assert report["n_stripped"] == 1
    bad, good = doc["specs"]["electrical"]
    assert "range" not in bad
    assert bad["range_origin"] == RG.UNVERIFIED
    assert "min" in bad["range_note"] and "max" in bad["range_note"]
    assert good["range"] == {"min": "-20", "max": "+20"}
    assert good["range_origin"] == "column_roles_verified"


def test_other_origins_untouched():
    """守边界：闸只管 `column_roles_verified`，别的来源不在这条规则里。"""
    doc = {"specs": {"electrical": [
        _row(origin="pdf_columns", verdict="verified_row", missing="min,max"),
    ]}}
    assert RG.enforce(doc)["n_stripped"] == 0
    assert RG.is_trusted(_row(origin="pdf_columns", verdict="verified_row",
                              missing="min,max")) is True


def test_missing_cols_on_row_level_also_counts():
    """事实表写在行上的 `missing_cols`（没同步进 verification）同样算数。"""
    row = _row(verdict="verified_row")
    row["missing_cols"] = "typ"
    assert RG.is_trusted(row) is False
