#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""table_audit 数值单元格重建的回归测试（ADAPT A10）。

背景：`pymupdf.Table.extract()` 对右对齐数值列会**重排字符**。
BQ2003 第 10 页 IIZ 行，`get_text("words")` 里明明是 `-2.0` / `2.0`，
`extract()` 却给出 `'20\\n- .'` / `'20\\n.'`。`to_num` 取到 20.0，
`patch_cols` 就把 `columns` 写成 `{MIN: 20, MAX: 20}` —— 原文是 `-2.0 / 2.0`。

修法：只对被判定重排的格子，用该行的 cell bbox 从 words 按坐标重拼。
"""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import table_audit as T  # noqa: E402

PDF = ROOT / "data" / "pdfs" / "BQ2003PNG4__bq2003.pdf"


class TestBadNumberCell:
    """判据只认「小数点/符号被挪位」三种形态，不碰公式格与占位符。"""

    @pytest.mark.parametrize("cell", [
        "20\n- .",      # -2.0
        "45 .",         # 4.5
        "55 .",         # 5.5
        "075 .",        # 0.75
        "20\n.",        # 2.0
        "50 - .",       # -5.0
        "VCC 1 .0 -",   # VCC - 1.0
    ])
    def test_reshuffled_cells_are_flagged(self, cell):
        assert T.bad_number_cell(cell) is True

    @pytest.mark.parametrize("cell", [
        "-2.0",         # 本来就正确的负数
        "4.5",
        "70",
        "±1",
        "-",            # 占位符
        "",             # 空
        "0 .2 ∗VCC",    # 公式格：to_num 得 0.2 是可接受的既有行为，不动它
        "Outputs unloaded",
    ])
    def test_clean_cells_are_not_flagged(self, cell):
        assert T.bad_number_cell(cell) is False

    def test_minus_at_head_is_not_a_reshuffle(self):
        """'-70' 是正常负号，不能被当成「符号挪位」。"""
        assert T.bad_number_cell("-70") is False
        assert T.bad_number_cell("-0.3 to +7.0") is False


@pytest.mark.skipif(not PDF.exists(), reason="缺少 bq2003 样本 PDF")
class TestRepairFromWords:

    @pytest.mark.slow
    def test_iiz_row_numbers_are_recovered(self):
        import pymupdf
        doc = pymupdf.open(str(PDF))
        try:
            tables = T.scan_tables(doc)
        finally:
            doc.close()
        # 第 10 页那张 7 列表（Symbol/Parameter/Minimum/Typical/Maximum/Unit/Notes）
        cand = [t for t in tables
                if t["page"] == 10 and len(T.role_map(t["header"])) >= 4]
        assert cand, "第 10 页应抽出 7 列规格表"
        rows = {r[0]: r for r in cand[0]["rows"] if r}
        assert "IIZ" in rows, "IIZ 行应在表内"
        # 原文 -2.0 / - / 2.0；修复前是 '20 - .' / '-' / '20 .'
        assert T.to_num(rows["IIZ"][2]) == -2.0
        assert T.to_num(rows["IIZ"][4]) == 2.0

    @pytest.mark.slow
    def test_supply_voltage_decimals_are_recovered(self):
        import pymupdf
        doc = pymupdf.open(str(PDF))
        try:
            tables = T.scan_tables(doc)
        finally:
            doc.close()
        cand = [t for t in tables if t["page"] == 10 and len(T.role_map(t["header"])) >= 4]
        rows = {r[0]: r for r in cand[0]["rows"] if r}
        # 修复前是 '45 .' / '50 .' / '55 .'（to_num -> 45 / 50 / 55，差 10 倍）
        assert [T.to_num(rows["VCC"][i]) for i in (2, 3, 4)] == [4.5, 5.0, 5.5]
