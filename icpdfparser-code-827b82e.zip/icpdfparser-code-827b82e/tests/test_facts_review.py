"""r6 facts 语义裁决台账（只读生成）离线单测。

验证边界：
  * Gold `not_specified` + facts 旧值 → 只登记待审，不修改值；
  * 来源类型可区分「分销类目」与「旧修订/其他封装」；
  * facts 源 SHA 与 canonical 不一致、item.pdf_sha256 与当前 PDF 不一致会出现在诊断；
  * 人工抽查/五语/视觉保持 NOT_CHECKED，RELEASE_APPROVED=false。
"""
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import facts_review as FR                  # noqa: E402

DDL = """
CREATE TABLE gold_set (
  id INTEGER PRIMARY KEY, version TEXT, mpn TEXT, manufacturer TEXT,
  pdf_name TEXT, pdf_sha256 TEXT, doc_rev TEXT, status TEXT, note TEXT);
CREATE TABLE gold_field (
  id INTEGER PRIMARY KEY, gold_id INTEGER, field_path TEXT, field_name TEXT,
  expected TEXT, unit TEXT, cond TEXT, page_no INTEGER, evidence TEXT,
  status TEXT, verified_by TEXT, verified_at TEXT);
CREATE TABLE item (
  id INTEGER PRIMARY KEY, mpn TEXT, pdf_path TEXT, pdf_sha256 TEXT,
  pdf_bytes INTEGER, json_path TEXT, meta TEXT);
CREATE TABLE source_field_evidence (
  id INTEGER PRIMARY KEY, evidence_id INTEGER, document_id INTEGER,
  gold_field_id INTEGER, field_path TEXT, page_number INTEGER,
  table_name TEXT, row_key TEXT, column_key TEXT, cell_value TEXT,
  evidence_quote TEXT, verification_status TEXT, reviewer TEXT,
  verified_at TEXT, notes TEXT, engine TEXT);
"""

CANON = "e" * 64
OLD = "1" * 64


class FakeDB:
    def __init__(self, path):
        self.c = sqlite3.connect(str(path))
        self.c.row_factory = sqlite3.Row
        self.c.executescript(DDL)

    def q(self, sql, args=()):
        return [dict(r) for r in self.c.execute(sql, args)]

    def q1(self, sql, args=()):
        r = self.c.execute(sql, args).fetchone()
        return dict(r) if r else None


class FactsReviewTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        (self.base / "parsed").mkdir()
        (self.base / "txt").mkdir()
        (self.base / "pdfs").mkdir()
        self.db = FakeDB(self.base / "db.sqlite3")
        c = self.db.c
        c.execute("INSERT INTO gold_set VALUES(7,'v1','BUF634PG4','Texas Instruments',"
                  "'BUF634PG4__buf634_revB.pdf',?,'B','frozen','note')", (CANON,))
        c.execute("INSERT INTO gold_set VALUES(11,'v1','DAC8555IPWG4','Texas Instruments',"
                  "'DAC8555IPWG4__dac8555.pdf',?,'','frozen','')", (CANON,))
        rows = [
            (1, 7, "basic_info.category", "category", "not_specified", "", "分销分类", 1,
             "title", "verified", "user:admin", ""),
            (2, 7, "electrical[18].value", "PSRR", "not_specified", "dB",
             "Rev B 仅曲线；64 dB 来自 Rev C", 8, "Figure 8", "verified", "user:admin", ""),
            (3, 7, "electrical[20].value", "headroom", "not_specified", "V",
             "Rev C p7", 5, "EC", "verified", "user:admin", ""),
            (4, 11, "basic_info.category", "category", "not_specified", "", "分销分类", 1,
             "title", "verified", "user:admin", ""),
        ]
        for r in rows:
            c.execute("INSERT INTO gold_field VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", r)
        c.execute("INSERT INTO item VALUES(1,'BUF634PG4',?,?,?,?,?)",
                  (str(self.base / "pdfs" / "buf.pdf"), OLD, 123,
                   str(self.base / "parsed" / "BUF634PG4_old.json"), "{}"))
        c.execute("INSERT INTO item VALUES(2,'DAC8555IPWG4',?,?,?,?,?)",
                  ("", CANON, 456,
                   str(self.base / "parsed" / "DAC8555IPWG4_old.json"), "{}"))
        c.commit()
        el = [{"name": "x", "value": "0", "unit": ""} for _ in range(23)]
        el[18] = {"name": "PSRR", "value": "64", "unit": "dB"}
        el[20] = {"name": "headroom", "value": "1.6", "unit": "V"}
        facts = {
            "basic_info": {"category": "Integrated Circuits (ICs) / Amplifiers"},
            "specs": {"electrical": el},
            "metadata": {"pdf_hash": OLD, "parse_timestamp": "2026-10-23T18:50:08+08:00",
                         "r4_patch": {"at": "2026-10-28T07:35:45+08:00", "sha256": CANON,
                                      "changes": [{"path": "specs.package.type"}]}},
        }
        (self.base / "parsed" / "BUF634PG4_old.json").write_text(
            json.dumps(facts), encoding="utf-8")
        (self.base / "parsed" / "DAC8555IPWG4_old.json").write_text(
            json.dumps({"basic_info": {"category": "Integrated Circuits (ICs) / Analog"},
                        "specs": {"electrical": []},
                        "metadata": {"pdf_hash": CANON}}), encoding="utf-8")
        (self.base / "pdfs" / "buf.pdf").write_bytes(b"not a real pdf")

    def tearDown(self):
        self.db.c.close()
        self.tmp.cleanup()

    def test_adjudication_is_read_only_and_classified(self):
        fields, diags, canon = FR.collect_adjudication(
            self.db, ["BUF634PG4", "DAC8555IPWG4"], self.base / "parsed",
            self.base / "pdfs")
        self.assertEqual(len(fields), 4)
        by_path = {f["field_path"]: f for f in fields}
        self.assertEqual(by_path["basic_info.category"]["source_type"],
                         "distributor_taxonomy")
        self.assertEqual(by_path["electrical[18].value"]["source_type"],
                         "legacy_revision_other_package")
        for f in fields:
            self.assertFalse(f["canonical_pdf_verified"])
            self.assertFalse(f["publish_as_canonical"])
            self.assertEqual(f["verification_status"], "pending_review")
            self.assertEqual(f["decision"], "")
        self.assertFalse(canon["BUF634PG4"]["facts_source_matches_canonical"])
        codes = {d["code"] for d in diags}
        self.assertIn("FACTS_SOURCE_NOT_CANONICAL", codes)
        self.assertIn("ITEM_PDF_SHA_MISMATCH", codes)

    def test_build_ledger_stays_unapproved(self):
        led = FR.build_ledger(self.db, ["BUF634PG4", "DAC8555IPWG4"],
                              self.base / "parsed", self.base / "txt",
                              self.base / "pdfs")
        self.assertFalse(led["release_approved"])
        self.assertEqual(led["adjudication"]["summary"]["fields"], 4)
        self.assertEqual(led["adjudication"]["summary"]["pending_review"], 4)
        self.assertFalse(led["adjudication"]["summary"]["facts_modified"])
        self.assertFalse(led["adjudication"]["summary"]["gold_modified"])
        self.assertEqual(led["release_gates"]["PACKAGE_PASS"]["status"], "PASS")
        self.assertEqual(led["release_gates"]["DATA_SEMANTICS_PASS"]["status"],
                         "NOT_CHECKED")
        self.assertEqual(led["release_gates"]["RELEASE_APPROVED"]["status"], "FAIL")
        self.assertEqual(led["translation"]["summary"]["total"], 10)
        self.assertEqual(led["visual"]["human_review"]["status"], "NOT_CHECKED")
        md = FR.render_markdown(led)
        self.assertIn("待人工", md)
        self.assertIn("RELEASE_APPROVED", md)
        self.assertIn("不修改", md)

    def test_resolve_path(self):
        facts = {"basic_info": {"category": "x"},
                 "specs": {"electrical": [{"value": "1"}, {"value": "2"}]}}
        self.assertEqual(FR.resolve_path(facts, "basic_info.category"), "x")
        self.assertEqual(FR.resolve_path(facts, "specs.electrical[1].value"), "2")
        self.assertIsNone(FR.resolve_path(facts, "specs.electrical[9].value"))
        self.assertIsNone(FR.resolve_path(facts, "missing.path"))


class AuditArtifactTest(unittest.TestCase):
    """v2 报告/audit 静态产物一致性（防止把待审写成全绿）。"""

    def test_release_gates_and_counts(self):
        audit = json.loads((ROOT / "r6_quality_audit.json").read_text(encoding="utf-8"))
        self.assertEqual(audit["audit_version"], 2)
        self.assertFalse(audit["release_approved"])
        self.assertEqual(audit["layers"]["L1"]["PASS"], 13)
        self.assertEqual(audit["release_gates"]["PACKAGE_PASS"]["status"], "PASS")
        self.assertEqual(audit["release_gates"]["PROVENANCE_PASS"]["status"],
                         "NOT_CHECKED")
        self.assertEqual(audit["release_gates"]["DATA_SEMANTICS_PASS"]["status"],
                         "NOT_CHECKED")
        self.assertEqual(audit["release_gates"]["DOWNSTREAM_PASS"]["status"], "FAIL")
        self.assertEqual(audit["release_gates"]["RELEASE_APPROVED"]["status"], "FAIL")
        self.assertEqual(audit["supplemental_summary"]["total"], 7)
        self.assertEqual(audit["details"]["facts_review"]["fields"], 6)
        self.assertFalse(audit["details"]["facts_review"]["facts_modified"])

    def test_ledger_and_report(self):
        led = json.loads((ROOT / "docs" / "r6字段语义裁决清单.json").read_text(encoding="utf-8"))
        self.assertEqual(led["adjudication"]["summary"]["fields"], 6)
        self.assertEqual(led["adjudication"]["summary"]["pending_review"], 6)
        self.assertFalse(led["release_approved"])
        for f in led["adjudication"]["fields"]:
            self.assertFalse(f["publish_as_canonical"])
            self.assertEqual(f["verification_status"], "pending_review")
        report = (ROOT / "docs" / "r6核验报告.md").read_text(encoding="utf-8")
        self.assertIn("RELEASE_APPROVED", report)
        self.assertIn("r6字段语义裁决清单.md", report)
        self.assertIn("NOT_CHECKED", report)


if __name__ == "__main__":
    unittest.main()
