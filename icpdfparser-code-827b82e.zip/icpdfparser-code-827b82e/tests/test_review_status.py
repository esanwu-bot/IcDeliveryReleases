"""纯函数状态推导的单测：P0/P1 门禁、证据闸、空报告与旧格式的区分。

守住的点：
  1. advisory / P2 / 缺 severity 的条目都不进 P0/P1；缺 severity 是报告不合规；
  2. 「有效空报告」= QA_PASS，「缺字段/被截断」= INCOMPLETE/LEGACY_UNRESOLVED；
  3. 批次 rollup：缺报告不得被「已知 P1」盖住，更不能变绿。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import review_status as RS      # noqa: E402


def finding(sev, advisory=False, kind="k"):
    return {"kind": kind, "severity": sev, "advisory": advisory,
            "evidence": {"quote": "x"}}


def report(verdict, rule=(), llm=()):
    return {"mpn": "X", "verdict": verdict,
            "rule_findings": list(rule), "llm_findings": list(llm),
            "rule_version": "r6", "review_version": "2"}


class AnalyzeTest(unittest.TestCase):
    def test_missing_report_is_incomplete(self):
        for bad in (None, {}, "x", []):
            a = RS.analyze(bad)
            self.assertEqual(RS.STATUS_INCOMPLETE, a["status_code"])
            self.assertEqual(1, a["incomplete_checks"])

    def test_valid_empty_report_is_qa_pass(self):
        a = RS.analyze(report("PASS"))
        self.assertEqual(RS.STATUS_QA_PASS, a["status_code"])
        self.assertEqual(0, a["incomplete_checks"])

    def test_rule_p1_is_still_warn(self):
        a = RS.analyze(report("WARN", rule=[finding("P1")]))
        self.assertEqual(RS.STATUS_STILL_WARN, a["status_code"])
        self.assertEqual(1, a["p1"])
        self.assertEqual("r6", a["rule_version"])

    def test_rule_p0_is_blocked(self):
        a = RS.analyze(report("FAIL", rule=[finding("P0")]))
        self.assertEqual(RS.STATUS_BLOCKED, a["status_code"])

    def test_llm_p1_counts_but_advisory_does_not(self):
        a = RS.analyze(report("WARN", llm=[finding("P1"),
                                           finding("P1", advisory=True),
                                           finding("P2", advisory=True)]))
        self.assertEqual(1, a["p1"])
        self.assertEqual(2, a["advisory"])
        self.assertEqual(RS.STATUS_STILL_WARN, a["status_code"])

    def test_p2_only_is_qa_pass(self):
        a = RS.analyze(report("WARN", rule=[finding("P2")]))
        self.assertEqual(RS.STATUS_QA_PASS, a["status_code"])
        self.assertEqual(1, a["p2"])

    def test_finding_without_severity_is_not_defaulted_to_p1(self):
        a = RS.analyze(report("WARN", rule=[{"kind": "x"}]))
        self.assertEqual(RS.STATUS_INCOMPLETE, a["status_code"])
        self.assertEqual(0, a["p1"])
        self.assertEqual(1, a["incomplete_checks"])

    def test_truncated_report_is_incomplete(self):
        """FAIL 却数不出 P0（报告被截断/改写）→ 不猜结论。"""
        a = RS.analyze(report("FAIL", rule=[finding("P1")]))
        self.assertEqual(RS.STATUS_INCOMPLETE, a["status_code"])
        self.assertIn("verdict_consistency", a["reason"])

    def test_pass_with_findings_is_incomplete(self):
        a = RS.analyze(report("PASS", rule=[finding("P1")]))
        self.assertEqual(RS.STATUS_INCOMPLETE, a["status_code"])

    def test_missing_findings_keys_is_legacy_unresolved(self):
        a = RS.analyze({"verdict": "PASS", "mpn": "X"})
        self.assertEqual(RS.STATUS_LEGACY_UNRESOLVED, a["status_code"])

    def test_legacy_findings_array_is_derived(self):
        a = RS.analyze({"verdict": "FAIL", "findings": [finding("P0")]})
        self.assertEqual("legacy_findings", a["format"])
        self.assertEqual(RS.STATUS_BLOCKED, a["status_code"])

    def test_legacy_findings_without_severity_is_incomplete(self):
        a = RS.analyze({"verdict": "PASS", "findings": [{"kind": "x"}]})
        self.assertEqual(RS.STATUS_INCOMPLETE, a["status_code"])


class RollupTest(unittest.TestCase):
    def test_blocked_wins(self):
        self.assertEqual(RS.STATUS_BLOCKED, RS.rollup(
            [RS.STATUS_QA_PASS, RS.STATUS_STILL_WARN, RS.STATUS_BLOCKED]))

    def test_missing_report_never_rolls_up_to_pass(self):
        self.assertEqual(RS.STATUS_INCOMPLETE, RS.rollup(
            [RS.STATUS_QA_PASS] * 29 + [RS.STATUS_INCOMPLETE]))

    def test_evidence_gap_outranks_warn(self):
        self.assertEqual(RS.STATUS_LEGACY_UNRESOLVED, RS.rollup(
            [RS.STATUS_STILL_WARN, RS.STATUS_LEGACY_UNRESOLVED]))
        self.assertEqual(RS.STATUS_INCOMPLETE, RS.rollup(
            [RS.STATUS_STILL_WARN, RS.STATUS_INCOMPLETE]))

    def test_all_green(self):
        self.assertEqual(RS.STATUS_QA_PASS, RS.rollup([RS.STATUS_QA_PASS] * 3))

    def test_unknown_code_is_incomplete(self):
        self.assertEqual(RS.STATUS_INCOMPLETE, RS.rollup(["REVIEWED_FIXED"]))
        self.assertEqual(RS.STATUS_INCOMPLETE, RS.rollup([]))

    def test_counts(self):
        c = RS.counts([{"status_code": RS.STATUS_BLOCKED},
                       {"status_code": RS.STATUS_QA_PASS},
                       {"status_code": "NOPE"}])
        self.assertEqual(1, c[RS.STATUS_BLOCKED])
        self.assertEqual(1, c[RS.STATUS_QA_PASS])
        self.assertEqual(1, c[RS.STATUS_INCOMPLETE])


if __name__ == "__main__":
    unittest.main()
