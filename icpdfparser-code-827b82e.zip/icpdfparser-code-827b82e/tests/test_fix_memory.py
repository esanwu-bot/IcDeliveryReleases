"""修复经验库单测：抽取优先级 + append-only 追加格式。

全部在临时目录里跑，不碰真实的 docs/qc/型号修复日志_handoff.md。
"""
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from worker import fix_memory as FM       # noqa: E402

SAMPLE = """# 型号修复日志（handoff）

> 前言说明。

---

## DS80PCI402EVK/NOPB（CF-QC28-012 · 2026-10-28）

定位：TI 评估板。
根因：esc 执行两遍，渲染成 `T&amp;amp;R`。

## LM358

普通运放，无板卡问题。

"""


def write_log(tmp: Path, text: str = SAMPLE) -> Path:
    p = tmp / FM.LOG_REL
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return p


class SplitTest(unittest.TestCase):
    def test_split_sections(self):
        secs = FM.split_sections(SAMPLE)
        titles = [t for t, _ in secs]
        self.assertIn("DS80PCI402EVK/NOPB（CF-QC28-012 · 2026-10-28）", titles)
        self.assertIn("LM358", titles)


class LoadTest(unittest.TestCase):
    def test_same_mpn_first(self):
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        r = FM.load_experience("DS80PCI402EVK/NOPB",
                               ["double_escape_multi"], root=tmp)
        self.assertTrue(r["ok"])
        self.assertEqual(r["same_mpn"], 1)
        self.assertIn("DS80PCI402EVK", r["text"])
        self.assertIn("T&amp;amp;R", r["text"])

    def test_related_by_kind(self):
        """不同型号但同类 kind → 也能借到经验（跨型号检索）。"""
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        r = FM.load_experience("SOME-OTHER-CHIP", ["double_escape_multi"], root=tmp)
        self.assertTrue(r["ok"])
        self.assertEqual(r["same_mpn"], 0)
        self.assertIn("esc 执行两遍", r["text"])       # 靠关键词命中借到经验

    def test_no_match_is_empty(self):
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        r = FM.load_experience("NOPE-1", ["package_mismatch"], root=tmp)
        # LM358 段落没有任何命中词 → 抽不到东西是正确行为，不能硬塞全库
        self.assertFalse(r["ok"] or r["text"].strip().endswith("LM358"))

    def test_missing_log(self):
        tmp = Path(tempfile.mkdtemp())
        r = FM.load_experience("X", ["pin_mismatch"], root=tmp)
        self.assertFalse(r["ok"])
        self.assertEqual(r["reason"], "log_missing")

    def test_budget_truncates(self):
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        r = FM.load_experience("DS80PCI402EVK/NOPB", [], max_chars=60, root=tmp)
        self.assertLessEqual(len(r["text"]), 400)     # 不因截断而爆炸


class AppendTest(unittest.TestCase):
    def test_append_creates_section(self):
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        plan = {"verdict": "FAIL", "actions": [
            {"id": "A1", "kind": "board_package_mismatch", "worker": "fix_identity",
             "status": "done", "changed": ["basic_info.identity", "specs.package.type"],
             "note": ""},
            {"id": "A2", "kind": "pin_mismatch", "worker": "fix_pin_rebuild",
             "status": "manual", "changed": [], "note": "pin_count_mismatch:40vs54"},
        ]}
        out = FM.append_experience("NEWCHIP-1", 1, plan,
                                   verdict_before="FAIL", root=tmp)
        self.assertTrue(out["ok"])
        text = (tmp / FM.LOG_REL).read_text(encoding="utf-8")
        self.assertIn("NEWCHIP-1 · 自动修复 round 1", text)
        self.assertIn("修前 verdict `FAIL`", text)
        self.assertIn("fix_identity", text)
        # 原有内容必须原样保留（append-only）
        self.assertIn("DS80PCI402EVK/NOPB（CF-QC28-012 · 2026-10-28）", text)
        self.assertIn("LM358", text)
        self.assertIn("### 逐条结果", text)

    def test_append_is_additive(self):
        """连写两轮：两轮都在，且顺序正确（后写的在后）。"""
        tmp = Path(tempfile.mkdtemp())
        write_log(tmp)
        plan = {"verdict": "WARN", "actions": [
            {"id": "A1", "kind": "double_escape_multi", "worker": "fix_escape",
             "status": "done", "changed": ["features[0]"], "note": ""}]}
        FM.append_experience("CHIP-2", 1, plan, root=tmp)
        FM.append_experience("CHIP-2", 2, plan, root=tmp)
        text = (tmp / FM.LOG_REL).read_text(encoding="utf-8")
        self.assertIn("round 1", text)
        self.assertIn("round 2", text)
        self.assertLess(text.index("round 1"), text.index("round 2"))

    def test_creates_file_when_missing(self):
        tmp = Path(tempfile.mkdtemp())
        plan = {"actions": [{"id": "A1", "kind": "x", "worker": "manual_review",
                             "status": "manual"}]}
        out = FM.append_experience("FIRST-1", 1, plan, root=tmp)
        self.assertTrue(out["ok"])
        self.assertTrue((tmp / FM.LOG_REL).is_file())

    def test_lessons_are_derived_not_boilerplate(self):
        """经验要来自实际执行结果（有 changed 才写），不能全是空话。"""
        tmp = Path(tempfile.mkdtemp())
        plan = {"actions": [
            {"id": "A1", "kind": "board_package_mismatch", "worker": "fix_identity",
             "status": "done", "changed": ["basic_info.identity"], "note": ""},
            {"id": "A2", "kind": "package_mismatch", "worker": "manual_review",
             "status": "manual", "changed": [], "note": ""}]}
        FM.append_experience("CHIP-3", 1, plan, root=tmp)
        text = (tmp / FM.LOG_REL).read_text(encoding="utf-8")
        self.assertIn("device_scope", text)
        self.assertIn("package_mismatch", text)
        self.assertIn("人工确认", text)


if __name__ == "__main__":
    unittest.main()
