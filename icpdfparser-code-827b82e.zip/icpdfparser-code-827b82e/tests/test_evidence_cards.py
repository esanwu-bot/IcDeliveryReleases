"""629 件证据卡工作清单生成器离线单测（不读生产数据）。"""
import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import evidence_cards as EC          # noqa: E402

FIELDS = [
    "evidence_card_id", "rule_version", "mpn", "item_id", "batch_id", "brand",
    "status", "root_cause_group", "root_cause_groups", "fix_class",
    "suggested_action", "json_mpn", "pdf_name", "pdf_rev", "pdf_sha256_item",
    "pdf_sha256_file", "facts_pdf_hash", "facts_parse_timestamp", "facts_model",
    "mpn_mismatch", "pdf_sha_mismatch", "electrical_row_bad", "electrical_empty",
    "pdf_has_ec_text", "fail_codes", "warn_codes", "gold_status", "human_verdict",
    "human_reviewer", "human_reviewed_at", "evidence_pdf_page", "evidence_quote",
    "adjudication_reason", "repair_status", "fail_count", "warn_count",
]


def make_worklist(path: Path):
    rows = [
        {"evidence_card_id": "EC-1", "mpn": "T1EVM", "item_id": "1",
         "batch_id": "b1", "brand": "TI", "status": "FAIL",
         "root_cause_group": "A1_板卡/模块映射到组件 PDF（源关联/业务口径）",
         "root_cause_groups": "A1", "fix_class": "source_mapping_business_review",
         "json_mpn": "T1", "pdf_name": "T1EVM.pdf", "fail_codes": "MPN_MISMATCH"},
        {"evidence_card_id": "EC-2", "mpn": "T2", "item_id": "2",
         "batch_id": "b2", "brand": "TI", "status": "FAIL",
         "root_cause_group": "E_PDF 文件被替换/版本漂移",
         "root_cause_groups": "E", "fix_class": "source_pdf_replacement_verify",
         "pdf_name": "T2.pdf", "fail_codes": "PDF_SHA_MISMATCH",
         "pdf_sha_mismatch": "True"},
        {"evidence_card_id": "EC-3", "mpn": "T3", "item_id": "3",
         "batch_id": "b3", "brand": "TI", "status": "FAIL",
         "root_cause_group": "I_解析结构缺陷（电气表行）",
         "root_cause_groups": "I", "fix_class": "parser_fix_then_rerun_item_batch",
         "pdf_name": "T3.pdf", "fail_codes": "ELECTRICAL_EMPTY",
         "electrical_empty": "True"},
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in FIELDS})


class EvidenceCardsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.wl = self.base / "worklist.csv"
        make_worklist(self.wl)
        self.matrix = self.base / "matrix.json"
        self.matrix.write_text(json.dumps({"rows": [
            {"item_id": 1, "root_cause_group": "A1_x"},
            {"item_id": 2, "root_cause_group": "E_x"},
            {"item_id": 3, "root_cause_group": "I_x"},
        ]}), encoding="utf-8")
        self.out = self.base / "out"
        self.data = self.base / "data"
        (self.data / "pdfs").mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_cards_and_outputs(self):
        wl, fields = EC._load_csv(self.wl)
        mat = EC._load_matrix(self.matrix)
        cards = EC.build_cards(wl, mat, self.data, probe_pdf=False)
        self.assertEqual(len(cards), 3)
        for c in cards:
            self.assertEqual(c["human_verdict"], "")
            self.assertEqual(c["evidence_pdf_page"], "")
            self.assertEqual(c["machine_probe_status"], "SKIPPED")
            self.assertEqual(c["repair_status"], "PENDING_HUMAN_REVIEW")
            self.assertTrue(c["automation_class"])
        s = EC.summarize(cards)
        self.assertEqual(s["total"], 3)
        self.assertEqual(s["human_filled"]["verdict_filled"], 0)
        self.assertEqual(s["by_group_batches"], {
            "A1_板卡/模块映射到组件 PDF（源关联/业务口径）": 1,
            "E_PDF 文件被替换/版本漂移": 1,
            "I_解析结构缺陷（电气表行）": 1})
        outs = EC.write_outputs(cards, s, self.out, fields)
        for p in outs:
            self.assertTrue(p.is_file(), p)
        with (self.out / "repair_worklist.csv").open(encoding="utf-8-sig") as f:
            self.assertEqual(len(list(csv.DictReader(f))), 3)
        md = (self.out / "evidence_card_summary.md").read_text(encoding="utf-8")
        self.assertIn("人工裁决 **0/3**", md)
        self.assertIn("未修改 facts", md)
        plan = (self.out / "regression_plan.md").read_text(encoding="utf-8")
        self.assertIn("全量重跑", plan)
        self.assertIn("A3", plan)

    def test_probe_no_pdf(self):
        pr = EC._pdf_probe(None, {"mpn": "X", "json_mpn": "Y"})
        self.assertEqual(pr["machine_probe_status"], "NO_PDF")


if __name__ == "__main__":
    unittest.main()
