#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""G2 回归：多封装/分组引脚表必须抽全，不能静默漏脚。

2026-11-03 Reviewer G2 点名：
  * ADS42JB49SEK 历史 64 脚，候选解析只剩 33（模型把功能组当脚号）；
  * LM358 历史 8 脚，候选解析只剩 2（`IN1–`/`IN2+` 被名字正则挡掉）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as DE                   # noqa: E402

ADS42 = ROOT / "data" / "pdfs" / "ADS42JB49SEK__ads42jb49.pdf"
LM358 = ROOT / "data" / "pdfs" / "LM358__lm358.pdf"


@pytest.mark.skipif(not ADS42.exists(), reason="缺少 ADS42JB49SEK 原件")
def test_ads42_grouped_pin_table_expands_to_64_physical_pins():
    import pymupdf
    with pymupdf.open(str(ADS42)) as doc:
        pins = DE.extract_pins(doc)
    assert len(pins) == 64, f"实得 {len(pins)} 脚"
    assert {p["pin"] for p in pins} == {str(i) for i in range(1, 65)}
    assert all(p["name"] for p in pins)
    # AGND 是 9 个脚的分组行，必须展开成 9 条，而不是 1 条
    agnd = [p for p in pins if p["name"] == "AGND"]
    assert len(agnd) == 9, agnd


@pytest.mark.skipif(not LM358.exists(), reason="缺少 LM358 原件")
def test_lm358_name_first_layout_keeps_the_8_pin_package():
    import pymupdf
    with pymupdf.open(str(LM358)) as doc:
        pins = DE.extract_pins(doc)
    assert len(pins) == 8, f"实得 {len(pins)} 脚"
    by_name = {p["name"]: p["pin"] for p in pins}
    assert by_name["IN1–"] == "2"
    assert by_name["IN1+"] == "3"
    assert by_name["IN2–"] == "6"
    assert by_name["IN2+"] == "5"
    assert by_name["OUT1"] == "1"
    assert by_name["OUT2"] == "7"
    assert by_name["V–"] == "4"
    assert by_name["V+"] == "8"
    assert all("LCCC(1)" in (p.get("pins_by_package") or {}) for p in pins)
