# -*- coding: utf-8 -*-
"""方案 ① 红先测试：电气表所在页必须「强制保底」进预算（1102-V3.4）。

背景（实测）：`ADC08B200EB.pdf` 42 页 / SNAS388F，是纯芯片 Datasheet，
但 16 页预算下模型交出空电气表。要区分两种可能：
  A. 电气表页根本没进上下文 → 选页缺陷（本文件要钉死的行为）；
  B. 进了上下文但 flash 抽不出来 → 模型缺陷（应由 A/B 测试判定）。

本测试只断言 A：**只要正文里存在 Electrical Characteristics 表头，
该页必须出现在 select_pages 的结果里**，且不能因此挤掉 thermal / ESD /
absolute maximum / ordering 这些已有强制页。

**尚未实现**：当前 `MANDATORY_PAGE_KEYS` 不含电气表头，故预期红。
"""
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PD = pytest.importorskip("parse_datasheets")

#: 16 页 / 50k 的默认预算（方案 ① 不改预算，只改「谁必须进」）
BUDGET = (16, 50_000)


def _doc(n_pages: int, elec_at: int, extra: dict | None = None):
    """造 (页索引, 文本) 序列（**0 基索引**，渲染成 "--- Page i+1 ---"）。

    `elec_at` 用 1 基页码（便于对着 PDF 说话），内部换算成索引。
    """
    fill = "parameter table row " * 120          # ≈ 2500 chars
    extra = extra or {}
    pages = [(i, extra.get(i, fill)) for i in range(n_pages)]
    idx = elec_at - 1
    pages[idx] = (idx, "ELECTRICAL CHARACTERISTICS  VDD = 5 V, TA = 25 C\n" + fill)
    return pages


def _selected(text: str) -> set:
    return {int(n) for n in re.findall(r"--- Page (\d+) ---", text)}


def test_electrical_page_is_forced_in_under_budget_pressure():
    """42 页文档、电气表在 p31、前面塞满引脚表 → 仍必须选中 p31。"""
    pages = _doc(42, 31)
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    assert 31 in _selected(text), f"电气表页被挤掉了，选中={sorted(_selected(text))}"
    assert used <= BUDGET[0]


def test_electrical_page_survives_many_high_rank_pages():
    """前 20 页全是 Pin Functions/Features（高优先档），电气表在 p35。"""
    pin = "PIN FUNCTIONS terminal functions signal descriptions " + "pin row " * 150
    pages = [(i, pin) for i in range(35)]          # 0..34 → 渲染成 Page 1..35
    pages[34] = (34, "ELECTRICAL CHARACTERISTICS  " + "row " * 150)   # Page 35
    pages += [(i, pin) for i in range(35, 42)]
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    assert 35 in _selected(text), f"选中={sorted(_selected(text))}"
    assert used <= BUDGET[0]


def test_electrical_force_does_not_drop_existing_mandatory_pages():
    """强制电气页不能挤掉 thermal / ESD / absolute max / ordering（已有强制页）。"""
    pages = _doc(42, 20)                            # 电气表在 Page 20（索引 19）
    pages[3] = (3, "ABSOLUTE MAXIMUM RATINGS " + "row " * 150)       # Page 4
    pages[8] = (8, "THERMAL INFORMATION RθJA " + "row " * 150)       # Page 9
    pages[9] = (9, "ESD RATINGS HBM CDM " + "row " * 150)            # Page 10
    pages[40] = (40, "ORDERING INFORMATION package marking " + "row " * 150)  # Page 41
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    got = _selected(text)
    for must in (4, 9, 10, 20, 41):
        assert must in got, f"p{must} 丢了，选中={sorted(got)}"
    assert used <= BUDGET[0]


def test_short_doc_with_electrical_early_is_unchanged():
    """短文档（电气表在第 4 页）不受影响，页数不膨胀。"""
    pages = _doc(10, 4)
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    assert 4 in _selected(text)
    assert used <= 10


def test_split_line_heading_is_still_mandatory():
    """标题被排版拆行（`ELECTRICAL\\nCHARACTERISTICS`）也必须命中强制保底。

    TI 手册里这种拆行很常见；只按单行子串匹配会让保底静默失效。
    """
    fill = "row " * 300
    pages = [(i, fill) for i in range(40)]
    pages[30] = (30, "ELECTRICAL\nCHARACTERISTICS\nVDD = 5 V\n" + fill)   # Page 31
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    assert 31 in _selected(text), f"选中={sorted(_selected(text))}"
    assert used <= BUDGET[0]


def test_all_electrical_subsections_are_kept():
    """电气表被拆成 DC / Power / AC 多节时，**每节的首页**都必须保住。

    实测 ADC12QJ1600ALREP（151 页）：只保住 DC（p11/p12），
    Power（p13）与 AC（p15–19）整段掉出 16 页预算 → 模型只看到半张表。
    这里把「连续多页电气续表吃满 rank3 配额」的形态也造出来（p11–p30 全是电气页），
    确保 Power/AC 的首页不是靠配额侥幸进来的。
    """
    fill = "row " * 300
    pages = [(i, fill) for i in range(151)]
    for i in range(10, 30):                                  # p11..p30：电气续表
        pages[i] = (i, "ELECTRICAL CHARACTERISTICS: DC SPECIFICATIONS (continued)\n" + fill)
    pages[32] = (32, "ELECTRICAL CHARACTERISTICS: POWER CONSUMPTION\n" + fill)   # p33
    pages[34] = (34, "ELECTRICAL CHARACTERISTICS: AC SPECIFICATIONS\n" + fill)   # p35
    text, used, _dropped = PD.select_pages(pages, *BUDGET)
    got = _selected(text)
    for must in (33, 35):
        assert must in got, f"p{must} 丢了，选中={sorted(got)}"
    assert used <= BUDGET[0]
