# -*- coding: utf-8 -*-
"""ADAPT A17：写盘前「值必须落在即将写入的那三列里」（红先用例）。

背景（12 件基线逐条回填核对时抓到，共 20 条写盘里 2 条是脏的）：

    ADC3910S065IRSMT  Add. Latency  value=4
        行 ['', '', '4', '60', '', '']  →  写成 MIN=60
    BQ24300DSGR       High-level input current  value=15
        匹配到的行是 VIH（输入电压）→  写成 MIN=1.4

两者的共同点：`value_supported` 通过了（值在**这一行的某个格**里），
但写盘只写 MIN/TYP/MAX —— 值不在那三格里，写下去就是用别的数字顶掉模型的值。

**红先声明**：本文件第一个用例在修复前是红的 —— 旧实现走 D1d `row_mispair`
把 `columns` 写成 `{'MIN': 60.0}`，且一个 unresolved 都不报。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

HDR = ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]


def _tbl(rows, **extra):
    d = {"page": 1, "ti": 0, "header": HDR, "rows": rows, "hx": [], "xr": []}
    d.update(extra)
    return d


class TestValueOutsideColumns:
    """值在行里、但不在要写入的那三列 → 必须 abstain，且只报一个 kind。"""

    #: 复现 ADC3910：值 4 出现在**另一行**，旧实现因此走 D1d 把 MIN=60 写进去
    ROWS = [["Add. Latency", "", "", "60", "", "ns"],
            ["Other Param", "", "4", "", "", "ns"]]

    def test_blocks_write_and_reports_value_unsupported(self):
        e = {"name": "Add. Latency", "value": "4", "unit": "ns"}
        finds = TA.audit_electrical([e], [_tbl(self.ROWS)], "specs.electrical")
        assert "columns" not in e, "值不在 MIN/TYP/MAX 里却写了 columns"
        assert e.get("column_origin") is None
        kinds = [f["kind"] for f in finds]
        assert kinds == ["value_unsupported_unresolved"], kinds

    def test_no_duplicate_cell_unparsable(self):
        """格子是干净的，不该同时报 cell_unparsable_unresolved（同一缺陷一个 kind）。"""
        e = {"name": "Add. Latency", "value": "4", "unit": "ns"}
        finds = TA.audit_electrical([e], [_tbl(self.ROWS)], "specs.electrical")
        assert not [f for f in finds if f["kind"] == "cell_unparsable_unresolved"]

    def test_value_already_consistent_is_not_touched(self):
        """值就在列里 → 没有可修的偏差，不许凭空写盘。"""
        e = {"name": "Add. Latency", "value": "60", "unit": "ns"}
        finds = TA.audit_electrical([e], [_tbl(self.ROWS)], "specs.electrical")
        assert "columns" not in e
        assert not [f for f in finds if not f["kind"].endswith("_unresolved")]


class TestColumnOrigin:
    """AGENT §11.5：写出去的 columns_raw 必须带 origin，否则 G0 不认它是 PDF 列证据。"""

    ROWS = [["VOH", "", "2.4", "", "3.3", "V"]]

    def test_successful_patch_carries_origin(self):
        e = {"name": "VOH", "value": "2.4 - 3.3", "unit": "V"}
        finds = TA.audit_electrical([e], [_tbl(self.ROWS)], "specs.electrical")
        assert [f["kind"] for f in finds] == ["range_collapse"]
        assert e["columns"] == {"MIN": 2.4, "MAX": 3.3}
        # 变异即红：把期望改成 BOGUS 会立刻失败，说明这条断言真的在判值
        assert e["column_origin"] == "pdf_header_anchors"

    def test_origin_vocabulary_is_single_source(self):
        """与 `qc/five_stage.py` 共用 `qc/column_origins.py`，两边都不许再写字面量。

        变异即红：把任一处改回 `"pdf_header_anchors"` 字面量，这条立刻失败。
        这正是要防的形态 —— 字段有值、门禁放行、来源是错的，比缺字段更难发现。
        """
        from qc.column_origins import COLUMN_ORIGINS

        root = Path(__file__).resolve().parent.parent
        for name in ("five_stage.py", "table_audit.py"):
            src = (root / "qc" / name).read_text(encoding="utf-8")
            assert "column_origins" in src, f"{name} 没引用单源词表"
            assert '"pdf_header_anchors"' not in src, f"{name} 还有硬编码 origin 字面量"
        assert "pdf_header_anchors" in COLUMN_ORIGINS


class TestColumnOriginDispatch:
    """同一个 `columns_raw`，三条来源必须能区分开。

    起因：`patch_cols` 原来无条件写 `pdf_header_anchors`。而 A13 切分出来的列
    边界来自 x 簇聚类、且切分后 `hx` 被清空（A16 对这张表整体失效），
    A10 重拼的格值也不是 `extract()` 原值 —— 两者都被标成"表头锚点"，
    等于向 G0 宣称"这批列有跨列校验兜底"，而事实没有。
    """

    ROWS = [["VOH", "", "2.4", "", "3.3", "V"]]

    def _patched(self, **extra):
        e = {"name": "VOH", "value": "2.4 - 3.3", "unit": "V"}
        TA.audit_electrical([e], [_tbl(self.ROWS, **extra)], "specs.electrical")
        return e

    def test_default_is_header_anchors(self):
        e = self._patched()
        assert e["columns"] == {"MIN": 2.4, "MAX": 3.3}, "前置：这条得真写盘"
        assert e["column_origin"] == "pdf_header_anchors"

    def test_split_table_marks_x_split(self):
        e = self._patched(split=True)
        assert e["column_origin"] == "pdf_x_split"

    def test_words_repair_marks_words_repair(self):
        e = self._patched(words_fixed=True)
        assert e["column_origin"] == "pdf_words_repair"

    def test_split_wins_over_words_repair(self):
        """切分重新定义了列，比"个别格被重拼"更根本 —— 优先记切分。"""
        e = self._patched(split=True, words_fixed=True)
        assert e["column_origin"] == "pdf_x_split"

    def test_origin_is_in_vocabulary(self):
        from qc.column_origins import COLUMN_ORIGINS

        for extra in ({}, {"split": True}, {"words_fixed": True}):
            e = self._patched(**extra)
            assert e["column_origin"] in COLUMN_ORIGINS, (extra, e["column_origin"])


class TestBadCellStillReported:
    """`_cells_ok_raw` 分支不能把 A12 的脏格报警一起吞掉。"""

    def test_formula_cell_reports_cell_unparsable(self):
        rows = [["VREFL Voltage", "", "0", "", "AVDD/2", "V"]]
        e = {"name": "VREFL Voltage", "value": "0", "unit": "V"}
        finds = TA.audit_electrical([e], [_tbl(rows)], "specs.electrical")
        bad = [f for f in finds if f["kind"] == "cell_unparsable_unresolved"]
        assert bad, [f["kind"] for f in finds]
        assert "columns" not in e
