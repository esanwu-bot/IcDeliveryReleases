"""步 5b：「Features 条目混入 electrical」检测 → 自动过滤的闭环。

起因：prompt v2 的 dry-run 里 DAC37J84IAAV 出现 10 处 `value` 回灌 `name`
（如 "Sinx/x Correction Filters"），原文来自 **Features 章节**而非电气表。

闭环链路：
    review._rule_checks 产出 kind=electrical_like_feature
        → tasks.ACTION_TEMPLATES 映射到 worker=fix_elec_drop_feature
        → fixers.fix_elec_drop_feature 移出并挂 metadata.elec_dropped_features

两条纪律在此固化：
  1. **手工与自动必须一致**：`audit_electrical_rows` 手工审计报几行，规则层就
     必须报几行。两者一旦分叉，说明有一侧换了判据——这是本项目已经犯过两次
     的「取证源不一致」类错误。
  2. **映射表必须自洽**：`ACTION_TEMPLATES` 里的每个 worker 都必须在 `FIXERS`
     里存在。写错名字不会报错，只会静默退化成人工处理，极难发现。
"""
import json
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.services import review as RV                          # noqa: E402
from worker import tasks as T                                  # noqa: E402
from worker import fixers as FX                                # noqa: E402
from qc import electrical_classify as EC                       # noqa: E402


def _snap(doc: dict, mpn: str = "X123") -> dict:
    """构造 `_rule_checks` 能吃的最小快照（其余检查在无文本时自动跳过）。"""
    return {"mpn": mpn, "json": doc, "txt_en": "", "lang_txt": {},
            "pdf_text": ""}


def _kinds(doc: dict, mpn: str = "X123") -> set:
    return {f["kind"] for f in RV._rule_checks(_snap(doc, mpn))}


def _elec(rows: list) -> dict:
    return {"basic_info": {"mpn": "X123"},
            "specs": {"electrical": rows}}


def _echo_count_from_finding(doc: dict) -> int:
    """从规则层 finding 的 message 里取回过滤行数（契约：'有 N 行'）。"""
    for f in RV._rule_checks(_snap(doc)):
        if f["kind"] == "electrical_like_feature":
            m = re.search(r"有 (\d+) 行", f["message"])
            if m:
                return int(m.group(1))
    return 0


# ── 规则层产出 ──────────────────────────────────────────────────────────

def test_rule_emits_kind_when_echo_rows_present():
    """三件套都非空 → #4 不会响，必须靠 4b 这条单独判。"""
    doc = _elec([
        {"name": "Sinx/x Correction Filters", "value": "Sinx/x Correction Filters",
         "unit": ""},
        {"name": "ICC", "value": "5", "unit": "mA"},
    ])
    assert "electrical_like_feature" in _kinds(doc)
    assert _echo_count_from_finding(doc) == 1


def test_rule_silent_on_clean_electrical():
    """干净件不得产出该 kind——否则会把整批件的 verdict 从 PASS 拖成 WARN。"""
    doc = _elec([{"name": "VIH", "value": "2.0", "unit": "V"},
                 {"name": "ICC", "value": "5", "unit": "mA"}])
    assert "electrical_like_feature" not in _kinds(doc)


def test_rule_silent_on_not_specified():
    """`not_specified` 是「原表无此格」的明确降级，不是缺陷，不报警。"""
    doc = _elec([{"name": "VIH", "value": "not_specified", "unit": "V"},
                 {"name": "ICC", "value": "5", "unit": "mA"}])
    assert "electrical_like_feature" not in _kinds(doc)


def test_rule_does_not_flag_real_electrical_with_feature_like_name():
    """真电气行即使名字像 Features（含 enable/correction）也不得误报。

    这是关键词版判据的必败样本：`Chip enable access time | 70 | ns`。
    """
    doc = _elec([
        {"name": "Chip enable access time", "value": "70", "unit": "ns"},
        {"name": "Output enable to output valid", "value": "35", "unit": "ns"},
        {"name": "Sinx/x correction ratio", "value": "0.1", "unit": "dB"},
    ])
    assert "electrical_like_feature" not in _kinds(doc)


# ── 映射表自洽（防静默失效）────────────────────────────────────────────

def test_electrical_like_feature_maps_to_registered_fixer():
    tmpl = T.ACTION_TEMPLATES.get("electrical_like_feature")
    assert tmpl is not None, "缺少 electrical_like_feature 映射"
    assert tmpl["worker"] == "fix_elec_drop_feature"
    assert tmpl["worker"] in FX.FIXERS, "worker 名未在 FIXERS 注册，会静默退化为人工"


def test_electrical_like_feature_has_category():
    assert T._KIND_CATEGORY.get("electrical_like_feature") == "ELECTRICAL_TABLE"


def test_all_action_template_workers_are_registered():
    """不变量：任何 worker 拼错名字都要在单测期炸，而不是上线后静默人工化。"""
    missing = sorted({t["worker"] for t in T.ACTION_TEMPLATES.values()
                      if t["worker"] != "manual_review"
                      and t["worker"] not in FX.FIXERS})
    assert missing == [], f"ACTION_TEMPLATES 引用了未注册的 fixer: {missing}"


def test_whitelist_covers_fixer_changes():
    """fixer 实际会改的路径必须全在白名单里，否则 commit() 抛 PermissionError
    → 整次修复作废。这是把「映射」和「fixer 行为」绑死的回归测试。"""
    tmpl = T.ACTION_TEMPLATES["electrical_like_feature"]
    doc = _elec([{"name": "On-Chip Very Low Jitter PLL",
                  "value": "On-Chip Very Low Jitter PLL", "unit": ""}])
    ctx = {"mpn": "X123", "doc": doc, "action": {},
           "allowed_paths": tmpl["allowed"]}
    # 只验证白名单逻辑，不落盘
    FX.validate_changes(ctx, ["specs.electrical",
                              "metadata.elec_dropped_features"])


# ── 端到端：手工 == 自动 ────────────────────────────────────────────────

def _v2_artifact(mpn: str) -> Path:
    return ROOT / "data" / "qc" / "prompt_dryrun" / "v2" / f"{mpn}.json"


def test_manual_and_auto_agree_on_dac37j84(tmp_path):
    """用户指定的验证点：DAC37J84 的 v2 产物，手工与自动必须都报 10 处。"""
    p = _v2_artifact("DAC37J84IAAV")
    if not p.is_file():
        pytest.skip("缺少 v2 dry-run 产物，跳过实证对照")
    doc = json.loads(p.read_text(encoding="utf-8"))

    manual = len(EC.audit_electrical_rows(doc))
    auto = _echo_count_from_finding(doc)
    assert manual == 10, f"手工审计应为 10，实际 {manual}"
    assert auto == manual, f"自动({auto}) 与手工({manual}) 不一致，判据分叉"


def test_auto_fix_clears_the_finding_and_is_idempotent(tmp_path, monkeypatch):
    """跑完过滤后规则层不得再报，且二次运行零改动。"""
    p = _v2_artifact("DAC37J84IAAV")
    if not p.is_file():
        pytest.skip("缺少 v2 dry-run 产物，跳过实证对照")
    doc = json.loads(p.read_text(encoding="utf-8"))
    before = len((doc.get("specs") or {}).get("electrical") or [])

    tmpl = T.ACTION_TEMPLATES["electrical_like_feature"]
    ctx = {"mpn": "DAC37J84IAAV", "doc": doc, "action": {},
           "allowed_paths": tmpl["allowed"], "json_path": tmp_path / "X.json"}
    monkeypatch.setattr(FX, "commit", lambda c, ch: None)

    r1 = FX.fix_elec_drop_feature(ctx)
    after = len(doc["specs"]["electrical"])
    assert before - after == 10
    assert r1["next_task"] == "render_item"
    assert doc["metadata"]["elec_dropped_features"]
    assert "electrical_like_feature" not in _kinds(doc, "DAC37J84IAAV")

    r2 = FX.fix_elec_drop_feature(ctx)
    assert r2["changed"] == [] and r2["note"] == "no_echo_rows"


def test_v1_artifacts_are_never_touched():
    """零误伤底线：v1 产物（生产基线）一件都不许被过滤。"""
    v1 = sorted((ROOT / "data" / "qc" / "prompt_dryrun" / "v1").glob("*.json"))
    if not v1:
        pytest.skip("缺少 v1 dry-run 产物，跳过零误伤校验")
    for p in v1:
        doc = json.loads(p.read_text(encoding="utf-8"))
        assert EC.audit_electrical_rows(doc) == [], f"{p.name} 出现误伤"
