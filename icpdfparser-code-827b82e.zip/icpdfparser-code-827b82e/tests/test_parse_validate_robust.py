# -*- coding: utf-8 -*-
"""`validate()` 必须能对坏结构返回错误，而不是替坏输入崩溃。

实测 ADS7815UE4：模型把 `specs` 写成字符串（而非对象），
`(doc.get("specs") or {}).get(...)` 直接抛
`AttributeError: 'str' object has no attribute 'get'`，
整件被判失败、白烧一次模型调用，且错误信息指向类型崩溃而不是真实原因。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

PD = pytest.importorskip("parse_datasheets")


def _ok_doc():
    return {
        "basic_info": {"mpn": "X1", "manufacturer": "TI"},
        "specs": {"electrical": [{"name": "a"}, {"name": "b"}, {"name": "c"}]},
        "features": [], "applications": [], "alternatives": [],
        "ordering_info": [], "seo": {}, "metadata": {},
        "pin_configuration": [],
    }


def test_good_doc_has_no_errors():
    assert PD.validate(_ok_doc()) == []


def test_specs_as_string_does_not_crash():
    doc = _ok_doc()
    doc["specs"] = "…模型输出了字符串…"
    errs = PD.validate(doc)
    assert any("specs 不是对象" in e for e in errs), errs


def test_basic_info_as_string_does_not_crash():
    doc = _ok_doc()
    doc["basic_info"] = "Texas Instruments"
    errs = PD.validate(doc)
    assert any("basic_info 不是对象" in e for e in errs), errs


def test_electrical_as_string_is_reported():
    doc = _ok_doc()
    doc["specs"]["electrical"] = "not-a-list"
    errs = PD.validate(doc)
    assert any("electrical 不是数组" in e for e in errs), errs


def test_empty_electrical_is_reported():
    doc = _ok_doc()
    doc["specs"]["electrical"] = []
    errs = PD.validate(doc)
    assert any("only 0 items" in e for e in errs), errs


# ---------------------------------------------------------------- 桶口径
# 口径：**正式桶计分，隔离区只记账**。
#   · 正式桶 = specs.<container> + specs.onboard_device_specs.<container>
#     （板卡件的电气参数由模型放进板载桶，主桶为空是正常形态）
#   · 隔离区 = specs.unresolved_specs.* + specs.unresolved_ac_rows
#     （被 pass_with_quarantine 扣押的问题行，绝不计分）
# batch100 实测：7 件板卡电气全在板载桶（主桶 0），旧口径把它们判成「没抽到」。


def _board(rows: int) -> dict:
    doc = _ok_doc()
    doc["specs"] = {"electrical": [],
                    "onboard_device_specs": {
                        "electrical": [{"name": f"p{i}"} for i in range(rows)]}}
    return doc


def test_board_onboard_bucket_passes_gate():
    """板载桶 >=3 必须放过 —— 这是板卡件的正常形态。"""
    errs = PD.validate(_board(17))
    assert not any("specs.electrical only" in e for e in errs), errs


def test_chip_both_formal_buckets_empty_fails():
    """芯片两个正式桶都空 -> 照旧报错。"""
    doc = _ok_doc()
    doc["specs"] = {"electrical": [], "onboard_device_specs": {"electrical": []}}
    errs = PD.validate(doc)
    assert any(e.startswith("specs.electrical only") for e in errs), errs


def test_quarantine_only_does_not_pass_and_is_accounted():
    """只有隔离区有行 -> **不能过**，且必须显式记账（区分真空 vs 全被扣押）。"""
    doc = _ok_doc()
    doc["specs"] = {
        "electrical": [],
        "onboard_device_specs": {"electrical": []},
        "unresolved_specs": {"electrical": [{"name": f"q{i}"} for i in range(8)]},
    }
    errs = PD.validate(doc)
    assert any(e.startswith("specs.electrical only") for e in errs), errs
    assert any("withheld_in_quarantine=8" in e for e in errs), errs


def test_withheld_is_not_counted_toward_threshold():
    """正式桶 1 条 + 隔离区 8 条 != 9 条。隔离区不参与阈值。"""
    doc = _ok_doc()
    doc["specs"] = {
        "electrical": [{"name": "a"}],
        "unresolved_specs": {"electrical": [{"name": f"q{i}"} for i in range(8)]},
        "unresolved_ac_rows": [{"name": "ac1"}, {"name": "ac2"}],
    }
    errs = PD.validate(doc)
    hits = [e for e in errs if e.startswith("specs.electrical only")]
    assert hits, errs
    assert "only 1 items" in hits[0], hits
    assert any("withheld_in_quarantine=10" in e for e in errs), errs


def test_formal_counts_do_not_double_count():
    """主桶与板载桶分别计数、不合并进同一分母；返回值可逐容器归因。"""
    doc = _ok_doc()
    doc["specs"] = {
        "electrical": [{"name": "m1"}, {"name": "m2"}],
        "onboard_device_specs": {"electrical": [{"name": "b1"}]},
        "absolute_max": [{"name": "am"}],
        "ac_performance": [],
    }
    n = PD.spec_formal_counts(doc)
    assert n["electrical"] == 3, n
    assert n["absolute_max"] == 1, n
    assert n["ac_performance"] == 0, n
    assert n["_withheld"] == 0, n


def test_error_prefix_kept_for_accept_thin():
    """前缀必须原样保留：pipeline 靠它判「只差电气条数」的软错误。"""
    doc = _ok_doc()
    doc["specs"] = {"electrical": []}
    err = next(e for e in PD.validate(doc) if "electrical only" in e)
    assert err.startswith("specs.electrical only"), err
    assert "(<3)" in err, err
