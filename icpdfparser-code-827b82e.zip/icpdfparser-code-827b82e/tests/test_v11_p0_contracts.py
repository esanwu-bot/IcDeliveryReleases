# -*- coding: utf-8 -*-
"""V11 P0 数据契约：AC 脏行物理隔离 + `unresolved` 不得生成正式 `range`。

两条都是「JSON 说一套、页面/事实表说另一套」的契约漏洞：

1. `ADS8568EVM-PDK` 的 AC 续页表被列带切错，6 条 SNR/SFDR 行写成
   `min="73.9" / typ="" / max="dB"` —— 单位串占了 MAX 数值格。渲染层照原样
   把 `dB` 印在 MAX 列，客户会把它当成一个「上限」。
   修法是把这些行说明白地**搬出** `specs.ac_performance`，放进
   `specs.unresolved_ac_rows` 隔离；渲染层/API 只读正式容器。

2. `ADS1201U-1/1K` 的 `Differential Input Voltage Range (With VBIAS)` 行
   `verification.status="unresolved"`、`range_note` 写着「列角色未核验」，
   却仍带着 `range={"min": "-20", "max": "+20"}`。同一件事两种状态。
   修法是：`unresolved` 行绝不允许出现正式 `range`，只能留
   `unverified_range_candidate`；渲染层与事实表都不得把候选当正式区间读。

用例全部手写假 JSON，不依赖任何真实交付文件（V10 包只用于人工复现）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import json_to_db as DB                                   # noqa: E402
import json_to_txt as J                                   # noqa: E402
from qc import ac_quarantine as AQ                        # noqa: E402
from qc import deterministic_extract as DE                # noqa: E402
from qc import fact_acceptance as FA                      # noqa: E402
from qc import normalize_doc as ND                        # noqa: E402
from qc import postprocess_qwen as PP                     # noqa: E402
from qc import range_guard as RG                          # noqa: E402


#: 6 条脏行的形态与 V10 实测一致：MAX 格是单位 `dB`，UNIT 格反而是空的。
DIRTY_AC = [
    {"symbol": "SNR" if i % 2 == 0 else "SFDR",
     "parameter": "SNR Signal-to-noise ratio" if i % 2 == 0
                  else "SFDR Spurious-free dynamic range",
     "conditions": f"At fIN = 10 kHz; {70 + i} QROW{i}",
     "min": f"{70 + i}.5", "typ": "", "max": "dB", "unit": "",
     "value_shape": "LH", "page": 13 + i,
     "row_sha256": f"dirty-row-{i}"}
    for i in range(6)
]

CLEAN_AC = {
    "symbol": "THD",
    "parameter": "Total harmonic distortion",
    "conditions": "At fIN = 10 kHz; 777 CLEANROW",
    "min": "-94", "typ": "", "max": "", "unit": "dB",
    "value_shape": "L", "page": 12, "row_sha256": "clean-row",
}


def _ac_doc(rows: list[dict]) -> dict:
    """最小可渲染的板卡页：AC 表在主容器，电气/最大值为空。"""
    return {
        "basic_info": {"mpn": "ADS8568EVM-PDK", "identity": "evaluation_board",
                       "manufacturer": "Texas Instruments"},
        "specs": {"scope": "onboard_device", "ac_performance": rows,
                  "electrical": [], "absolute_max": []},
        "pin_configuration": [],
    }


# ─────────────────────────────────────────────────────────────────────
# 任务一：AC 脏行物理隔离
# ─────────────────────────────────────────────────────────────────────

def test_quarantine_moves_dirty_rows_out_of_official_container():
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    rep = AQ.quarantine(doc)

    assert rep["n_quarantined"] == 6
    assert [r["row_sha256"] for r in doc["specs"]["ac_performance"]] == ["clean-row"]
    isolated = doc["specs"]["unresolved_ac_rows"]
    assert len(isolated) == 6
    for row in isolated:
        assert row["quarantined_from"] == "ac_performance"
        assert "MAX" in row["quarantine_reason"]
        assert row["max"] == "dB"          # 原样保留证据，不改写脏值


def test_quarantine_is_idempotent():
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    first = AQ.quarantine(doc)
    second = AQ.quarantine(doc)
    assert first["n_quarantined"] == 6
    assert second["n_quarantined"] == 0
    assert len(doc["specs"]["unresolved_ac_rows"]) == 6


def test_check_ac_integrity_is_clean_after_quarantine():
    """既有 AC 列角色闸门在隔离后必须归零 —— 隔离就是它的可执行出口。"""
    dirty = [dict(r) for r in DIRTY_AC]
    assert len(DE.check_ac_integrity(dirty)) == 6

    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    AQ.quarantine(doc)
    assert DE.check_ac_integrity(doc["specs"]["ac_performance"]) == []


def test_renderer_never_shows_quarantined_rows():
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    AQ.quarantine(doc)
    html = J.render(doc, "en")
    for i in range(6):
        assert f"QROW{i}" not in html, f"隔离行 QROW{i} 仍被渲染"
    assert "CLEANROW" in html
    assert "-94" in html


def test_renderer_filters_dirty_rows_before_json_is_rewritten():
    """渲染层自己也要拦：老 JSON 还没被隔离时也不许把 `dB` 印进 MAX 列。"""
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    html = J.render(doc, "en")
    for i in range(6):
        assert f"QROW{i}" not in html, f"脏行 QROW{i} 绕过了渲染层拦截"
    assert "CLEANROW" in html


def test_api_omits_quarantine_container():
    """API 只吐正式规格；隔离区是内部治理，不得混进 `spec` 明细。"""
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    AQ.quarantine(doc)
    rows = DB.detail_rows(doc)["spec"]
    sections = {r[0] for r in rows}
    assert "unresolved_ac_rows" not in sections
    assert "ac_performance" in sections
    # 正式容器只剩 1 条干净行；隔离容器整体不参与 API 明细。
    assert len([r for r in rows if r[0] == "ac_performance"]) == 1
    for i in range(6):
        assert f"QROW{i}" not in {r[5] for r in rows if r[5]}


def test_api_filters_dirty_rows_before_json_is_rewritten():
    """API 出口也要拦：旧 JSON 只跑入库、没跑隔离时同样不许吐出脏行。"""
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    rows = DB.detail_rows(doc)["spec"]
    assert len([r for r in rows if r[0] == "ac_performance"]) == 1


def test_quarantine_cli_writes_atomically(tmp_path):
    p = tmp_path / "ADS8568EVM-PDK.json"
    p.write_text(json.dumps(_ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)]),
                            ensure_ascii=False), encoding="utf-8")
    assert AQ.main([str(p)]) == 0
    got = json.loads(p.read_text(encoding="utf-8"))
    assert len(got["specs"]["ac_performance"]) == 1
    assert len(got["specs"]["unresolved_ac_rows"]) == 6
    assert not list(tmp_path.glob("*.tmp")), "原子写留下了临时文件"


def test_normalize_pipeline_applies_both_contracts():
    """管线级回归：不传 PDF 时也要隔离 AC 脏行、抹掉 unresolved 的 range。"""
    doc = _ac_doc([dict(r) for r in DIRTY_AC] + [dict(CLEAN_AC)])
    doc["basic_info"] = {"mpn": "ADS-TEST", "identity": "device"}
    doc["specs"]["scope"] = "device"
    doc["specs"]["electrical"] = [{
        "name": "Differential Input Voltage Range",
        "value": "-20 to +20", "unit": "V", "condition": "With VBIAS(1)",
        "range": {"min": "-20", "max": "+20"},
        "range_origin": "derived_from_value",
        "verification": {"status": "unresolved",
                         "reason": "column_roles_not_verified"},
    }]
    acts = ND.normalize(doc, None)
    assert acts["ac_quarantine"]["n_quarantined"] == 6
    assert [r["row_sha256"] for r in doc["specs"]["ac_performance"]] == ["clean-row"]
    assert len(doc["specs"]["unresolved_ac_rows"]) == 6
    assert acts["range_stripped"] == 1
    row = doc["specs"]["electrical"][0]
    assert "range" not in row
    assert row["unverified_range_candidate"] == {"min": "-20", "max": "+20"}


# ─────────────────────────────────────────────────────────────────────
# 任务二：`unresolved` 不得生成正式 range
# ─────────────────────────────────────────────────────────────────────

def test_normalize_ranges_marks_unresolved_without_formal_range():
    entries = [{"name": "Differential Input Voltage Range",
                "value": "-20 to +20", "unit": "V", "condition": "With VBIAS(1)"}]
    PP.normalize_ranges(entries)
    row = entries[0]
    assert "range" not in row, "unresolved 行仍生成了正式 range.min/max"
    assert row["unverified_range_candidate"] == {"min": "-20", "max": "+20"}
    assert row["verification"] == {"status": "unresolved",
                                   "reason": "column_roles_not_verified"}
    assert row["value"] == "-20 to +20"


def test_normalize_ranges_respects_input_range_unverified_columns():
    """`_input_range_row` 已经明确「TYP 是脚注」，二次规范化不得把 range 加回来。"""
    src = {"cond": "With VBIAS(1)", "page": 2, "bbox": [1, 2, 3, 4],
           "row_sha256": "r", "min": "-20", "max": "+20", "typ": "See Note 2",
           "unit": "V"}
    row = DE._input_range_row("Differential Input Voltage Range", src, "V")
    assert "range" not in row
    PP.normalize_ranges([row])
    assert "range" not in row
    assert row["unverified_range_candidate"] == {"min": "-20", "max": "+20"}
    assert row["range_origin"] == "column_roles_unverified"
    assert row["verification"]["status"] == "audited_deterministic"


def test_range_guard_strips_unresolved_range_whatever_the_origin():
    row = {"name": "Differential Input Voltage Range", "value": "-20 to +20",
           "range": {"min": "-20", "max": "+20"},
           "range_origin": "derived_from_value",
           "verification": {"status": "unresolved",
                            "reason": "column_roles_not_verified"}}
    doc = {"specs": {"electrical": [row]}}
    rep = RG.enforce(doc)
    assert rep["n_stripped"] == 1
    assert "range" not in row
    assert row["unverified_range_candidate"] == {"min": "-20", "max": "+20"}
    assert row["range_origin"] == RG.UNVERIFIED
    assert RG.safe_range(row) is None


def test_range_guard_refuses_trusted_origin_with_unresolved_status():
    row = {"range": {"min": "0", "max": "+5"},
           "range_origin": "pdf_columns",
           "verification": {"status": "unresolved"}}
    assert RG.is_trusted(row) is False
    assert RG.safe_range(row) is None


def test_renderer_range_text_does_not_read_unresolved_range():
    row = {"value": "", "range": {"min": "-20", "max": "+20"},
           "range_origin": "derived_from_value",
           "verification": {"status": "unresolved"}}
    assert J._range_text(row) == "", "渲染层把 unresolved 的 range 当正式区间读了"


def test_fact_acceptance_does_not_replay_unresolved_range():
    row = {"name": "Differential Input Voltage Range", "value": "",
           "range": {"min": "-20", "max": "+20"},
           "range_origin": "derived_from_value",
           "verification": {"status": "unresolved"}}
    assert FA._row_numbers(row) == [], "事实表仍把 unresolved range 当可回打数值"

    good = {"name": "Absolute Input Voltage Range", "value": "",
            "range": {"min": "0", "max": "5"},
            "range_origin": "column_roles_verified",
            "verification": {"status": "audited_row_anchored"}}
    assert FA._row_numbers(good) == ["0", "5"], "干净的 range 不能被误伤"
