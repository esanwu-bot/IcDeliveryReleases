"""finding kind 单一事实源的不变量测试。

设计（两道防线，缺一不可）：

1. **源码扫描 ⊆ 注册表** —— 抓「新增规则忘了注册」。
   扫描器按 ``finding_kinds.ENGINE_SOURCES`` 的配置走，三套引擎三种写法：
   dict 值 / 第 4 个位置参数 / 第 2 个位置参数。
   （曾用「扫 ``kind=`` 关键字参数」的写法，三处全扫出 0 个 → 空集 ⊆ 任何集合
   → 假绿。假绿比红危险，这条教训写在这里。）

2. **下界锁死** —— 抓「注册表被误改空/误缩水」。扫描只能发现新增，
   发现不了删除；``len() >= MIN`` 补上这个缺口。

另加：ACTION_TEMPLATES 键 ⊆ 生产侧（拼错名字不报错、只静默退化成人工，
AGENT.md §5 已犯过一次）。
"""
import re
import warnings
from pathlib import Path

import pytest

from qc import finding_kinds as FK

ROOT = Path(__file__).resolve().parent.parent


# ══════════════════════════════════════════════════════════════════
# 1. 源码扫描 ⊆ 注册表（抓新增）
# ══════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("engine", list(FK.ENGINE_SOURCES))
def test_engine_source_kinds_registered(engine):
    cfg = FK.ENGINE_SOURCES[engine]
    path = ROOT / cfg["path"]
    assert path.is_file(), (
        "%s 不存在。路径变了请更新 qc/finding_kinds.py::ENGINE_SOURCES。"
        % cfg["path"])

    actual, dynamic = FK.scan_engine(engine)
    assert actual, (
        "%s 扫出 0 个字面量——扫描方式与源码写法不匹配，测试会假绿。"
        "请检查 ENGINE_SOURCES[%r] 的 how/key/func/index。"
        % (cfg["path"], engine))

    unknown = actual - FK._KNOWN[engine]                # noqa: SLF001
    assert not unknown, (
        "\n%s 里有未注册的产出：%s\n"
        "  解决：在 qc/finding_kinds.py::%s 补充，并上调 LOWER_BOUNDS。\n"
        "  一次性动作，补完永久稳定。"
        % (cfg["path"], sorted(unknown),
           "AUTO_QC_CODES" if engine == "auto_qc" else
           ("REVIEW_KINDS" if engine == "review" else "TABLE_AUDIT_KINDS")))

    allowed = FK.DYNAMIC_ALLOWED.get(engine, {})
    uncovered = {d for d in dynamic
                 if d not in allowed and not FK.is_auto_qc_code(_sample(d))}
    assert not uncovered, (
        "\n%s 有未登记的动态产出点：%s\n"
        "  若是运行时拼接的 code → 加进 AUTO_QC_CODE_PATTERNS；\n"
        "  若是 LLM 直通之类无法枚举的 → 加进 DYNAMIC_ALLOWED 并写明原因。"
        % (cfg["path"], sorted(uncovered)))


def _sample(expr: str) -> str:
    """把 ``'ART_%s_MISSING' % key.upper()`` 还原成样例串。"""
    import re
    m = re.match(r"""^['"](.+)['"]\s*%\s*(.+)$""", expr.strip())
    if not m:
        return ""
    return m.group(1).replace("%s", "XX" if "upper" in m.group(2) else "X")


# ══════════════════════════════════════════════════════════════════
# 2. 下界锁死（抓删除/缩水）
# ══════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("engine", sorted(FK.LOWER_BOUNDS))
def test_registry_lower_bound(engine):
    got = len(FK._KNOWN[engine])                        # noqa: SLF001
    want = FK.LOWER_BOUNDS[engine]
    assert got >= want, (
        "%s 注册表只有 %d 个，实测下界 %d。若确为缩减，先确认再同步下调 "
        "LOWER_BOUNDS，不要为了让测试变绿直接删断言。" % (engine, got, want))


# ══════════════════════════════════════════════════════════════════
# 3. ACTION_TEMPLATES 键 ⊆ 生产侧（拼错静默失效的防线）
# ══════════════════════════════════════════════════════════════════

def test_action_templates_keys_registered():
    path, var = FK.ACTION_TEMPLATES_SOURCE
    keys = FK.scan_action_kinds(ROOT / path)
    assert keys, "%s 里没扫到 %s 的键（可能被重构），需人工核" % (path, var)

    unknown = keys - FK.PRODUCERS
    assert not unknown, (
        "\nACTION_TEMPLATES 有键没有任何生产侧：%s\n"
        "  这些模板永远不会命中。若是 review/table_audit/LLM 的 kind → 补进"
        "对应集合；若是特殊路由键 → 加进 ACTION_TEMPLATES_SPECIAL。\n"
        "  （拼错不报错、只静默退化成人工，5b 踩过。）" % sorted(unknown))


def test_action_templates_declared_snapshot_matches_source():
    """ACTION_KINDS 快照必须与源码一致——防止快照腐化成摆设。"""
    path, var = FK.ACTION_TEMPLATES_SOURCE
    keys = FK.scan_action_kinds(ROOT / path)
    assert keys == FK.ACTION_KINDS, (
        "ACTION_KINDS 快照与 %s 不一致：\n  源码多出：%s\n  快照多出：%s"
        % (var, sorted(keys - FK.ACTION_KINDS),
           sorted(FK.ACTION_KINDS - keys)))


# ══════════════════════════════════════════════════════════════════
# 4. LLM 词表（review.RULES_TEXT）与注册表一致
# ══════════════════════════════════════════════════════════════════

def test_llm_prompt_kinds_registered():
    path = ROOT / FK.LLM_PROMPT_SOURCE[0]
    prompt = FK.scan_llm_prompt_kinds(path)
    assert prompt, "RULES_TEXT 里没抠到 kind 词表，正则可能失效"
    assert not (prompt - FK.LLM_KINDS), (
        "提示词里有未注册的 kind：%s" % sorted(prompt - FK.LLM_KINDS))


def test_llm_fallback_kind_registered():
    """模型不给 kind 时写的兜底值必须被认作合法 llm kind。"""
    assert FK.is_known("llm_finding", "llm")
    assert FK.normalize("llm_finding") == "llm_finding"


# ══════════════════════════════════════════════════════════════════
# 5. 等价类内部一致
# ══════════════════════════════════════════════════════════════════

def test_equivalence_both_sides_registered():
    for canonical, mapping in FK.EQUIVALENCES.items():
        for engine, name in mapping.items():
            if name is None:
                continue
            assert engine in FK._KNOWN, (                   # noqa: SLF001
                "等价类 %r 指向未知 engine=%r" % (canonical, engine))
            assert FK.is_known(name, engine), (
                "等价类 %r 的 %s 侧 %r 不在该引擎注册表里"
                % (canonical, engine, name))


def test_normalize_roundtrip():
    for canonical, mapping in FK.EQUIVALENCES.items():
        for name in mapping.values():
            if name is not None:
                assert FK.normalize(name) == canonical, (
                    "normalize(%r) 返回 %r，应为 %r"
                    % (name, FK.normalize(name), canonical))


def test_normalize_self_for_registered_names():
    """注册表里每个名字都必须能 normalize 到某个 canonical（不能是 None）。"""
    for engine in ("review", "table_audit", "llm"):
        for name in FK._KNOWN[engine]:                  # noqa: SLF001
            assert FK.normalize(name) is not None, (
                "%s 的 %r 无法归一" % (engine, name))


def test_normalize_unknown_returns_none():
    assert FK.normalize("not_a_real_kind_xyz") is None
    assert FK.normalize("") is None


def test_no_ambiguous_alias():
    """同一名字不能指向两个 canonical（构造期已 raise，这里守住）。"""
    seen = {}
    for canonical, mapping in FK.EQUIVALENCES.items():
        for name in mapping.values():
            if name is None:
                continue
            assert seen.get(name, canonical) == canonical, (
                "名字 %r 同时映射到 %r 和 %r" % (name, seen[name], canonical))
            seen[name] = canonical


# ══════════════════════════════════════════════════════════════════
# 6. 已登记分歧（只登记不改行为，测试守住不被悄悄删掉）
# ══════════════════════════════════════════════════════════════════

def test_conflicts_are_documented():
    ids = {c["id"] for c in FK.CONFLICTS}
    # 这四条都是实测确认过的分歧，删掉任何一条都必须有对应修复
    for must in ("condition_leak_naming_split",
                 "row_incomplete_bucketing",
                 "sentinel_opposite_semantics",
                 "electrical_like_feature_severity"):
        assert must in ids, "已确认分歧 %r 被删除；若已修复请同步删除本断言" % must


def test_condition_leak_split_still_visible():
    """table_audit 产 condition_leak、ACTION 认 electrical_condition_leak。

    这是「拼错名字静默退化成人工」的第二个实例，且已在生产里。
    修它要改 ACTION_TEMPLATES 的键（行为变更），故此处只守住「可见」。
    """
    assert FK.is_known("condition_leak", "table_audit")
    assert FK.is_known("electrical_condition_leak", "action")
    assert FK.normalize("condition_leak") == FK.normalize(
        "electrical_condition_leak") == "condition_leak"


# ══════════════════════════════════════════════════════════════════
# 7. check_known 三分支
# ══════════════════════════════════════════════════════════════════

def test_check_known_strict_raises():
    with pytest.raises(ValueError, match="未注册"):
        FK.check_known({"totally_new_kind"}, "review", strict=True)


def test_check_known_nonstrict_warns():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        unknown = FK.check_known({"totally_new_kind"}, "review")
        assert unknown == {"totally_new_kind"}
        assert any("未注册" in str(x.message) for x in w)


def test_check_known_unknown_engine_raises():
    with pytest.raises(ValueError, match="未知 engine"):
        FK.check_known(set(), "no_such_engine")


def test_check_known_accepts_registered():
    FK.check_known({"electrical_field_missing"}, "review", strict=True)
    FK.check_known({"MPN_MISMATCH"}, "auto_qc", strict=True)
    FK.check_known({"row_mispair"}, "table_audit", strict=True)
    FK.check_known({"ART_TXT_MISSING"}, "auto_qc", strict=True)


# ══════════════════════════════════════════════════════════════════
# 8. import 零 stdout（server 进程安全，AGENT.md §4）
# ══════════════════════════════════════════════════════════════════

def test_import_no_stdout(capsys):
    import importlib
    importlib.reload(FK)
    assert capsys.readouterr().out == ""


# ══════════════════════════════════════════════════════════════════
# 9. 跨引擎一致性：同一判据必须报出同样的行数（#2 的核心）
# ══════════════════════════════════════════════════════════════════
# 注册表只能统一**命名**；命名统一了但判据分叉，照样一个报 3 行一个报 5 行。
# 这一节验证 review._rule_checks 与 auto_qc.check_item 对同一份 JSON
# 报出相同的 ECHO 行数。两者共用 qc.electrical_classify，理应相等；
# 一旦不等，说明有一侧换了判据（AGENT.md §5「取证源不一致」类错误）。

import json as _json
import re as _re
import tempfile as _tempfile

_ECHO_ROWS = [
    {"name": "Sinx/x Correction Filters", "value": "Sinx/x Correction Filters", "unit": ""},
    {"name": "Low Power Consumption", "value": "Low Power Consumption", "unit": ""},
    {"name": "On-Chip Reference Buffer", "value": "On-Chip Reference Buffer", "unit": ""},
]
_CLEAN_ROWS = [
    {"name": "Supply Voltage", "value": "5", "unit": "V"},
    {"name": "Bandwidth", "value": "1", "unit": "GHz"},
]


def _doc(n_echo: int) -> dict:
    return {
        "basic_info": {"mpn": "PARITY1", "manufacturer": "Texas Instruments"},
        "specs": {"electrical": _CLEAN_ROWS + _ECHO_ROWS[:n_echo],
                  "package": {"type": "SOIC-8", "pins": 8}},
        "pin_configuration": [{"pin": i, "name": "P%d" % i} for i in range(1, 9)],
        "multi_language": {k: {"description": "x"} for k in ("ja", "ko", "de", "es")},
        "seo": {"title_en": "PARITY1"},
    }


def _review_echo_count(doc: dict) -> int:
    from app.services import review as RV
    snap = {"mpn": "PARITY1", "json": doc, "txt_en": "", "lang_txt": {},
            "pdf_text": ""}
    for f in RV._rule_checks(snap):
        if f.get("kind") == "electrical_like_feature":
            m = _re.search(r"有 (\d+) 行", f.get("message") or "")
            return int(m.group(1)) if m else -1
    return 0


def _auto_qc_echo_count(doc: dict) -> int:
    from qc import auto_qc as AQ
    tmp = _tempfile.mkdtemp(prefix="parity_")
    d = Path(tmp) / "data"
    for sub in ("pdfs", "parsed", "txt", "symbols", "seo", "alts"):
        (d / sub).mkdir(parents=True)
    js = d / "parsed" / "PARITY1.json"
    js.write_text(_json.dumps(doc), encoding="utf-8")
    item = {"id": 1, "mpn": "PARITY1", "brand": "Texas Instruments",
            "pdf_path": "", "pdf_sha256": "", "json_path": str(js),
            "txt_path": "", "symbol_path": "", "seo_path": "",
            "alt_json_path": "", "alt_html_path": ""}
    res = AQ.check_item(item, d, None, hash_pdf=False, probe_pdf=False)
    for f in res["findings"]:
        if f.get("code") == "ELECTRICAL_LIKE_FEATURE":
            m = _re.match(r"(\d+)/\d+ 行", f.get("detail") or "")
            return int(m.group(1)) if m else -1
    return 0


@pytest.mark.parametrize("n_echo", [0, 1, 2, 3])
def test_electrical_like_feature_count_agrees(n_echo):
    doc = _doc(n_echo)
    rv = _review_echo_count(doc)
    aq = _auto_qc_echo_count(doc)
    assert rv == aq, (
        "同一份 JSON，review 报 %d 行、auto_qc 报 %d 行（期望 %d）。\n"
        "  两者共用 qc.electrical_classify，理论上必须相等；\n"
        "  不等说明有一侧换了判据/加了前置过滤——先查清再改，不要直接放宽断言。"
        % (rv, aq, n_echo))


# ══════════════════════════════════════════════════════════════════
# 10. 被推翻的判断必须保留（append-only 精神）
# ══════════════════════════════════════════════════════════════════

def test_retracted_judgments_preserved():
    """任何条目的 retracted 一旦存在，就不能被静默删除。

    这是本模块的「踩坑历史」防线：下一个 agent 要能看到
    「曾经有人这么判断过、后来被推翻了」，否则只会看到正确答案，
    不知道有人踩过（AGENT.md §5.3）。

    遍历式而非硬编码：早先只查 `CONFLICTS[0]`，第 2、3 条加 retracted
    时不会被覆盖——那正是本测试要防的事，却在第一条之后就失效了。
    没有 retracted 的条目 `c.get("retracted", [])` 返回空列表、循环零次、
    通过：不是每条冲突都有被推翻的历史，只有踩过坑的才有。
    """
    # 下界：当前至少有一条留档。全部删光 = 历史清零，必须红——
    # 否则「遍历式」会变成「删掉 retracted 就自动通过」，比原来更弱
    # （原来硬编码 CONFLICTS[0]，至少守住了这一条）。与 LOWER_BOUNDS 同一套思路。
    assert any(c.get("retracted") for c in FK.CONFLICTS), (
        "所有 CONFLICTS 的 retracted 都被删了——踩坑历史清零。"
        "若确实已无被推翻的判断，请同步更新本断言并说明原因。")

    for c in FK.CONFLICTS:
        for r in c.get("retracted", []):
            # 结构完整：缺任一字段 = 无法追溯
            for key in ("claim", "why_wrong", "root_cause", "retracted_at"):
                assert key in r, (
                    f"CONFLICTS[{c['id']}].retracted 缺字段 {key!r}。"
                    f"retracted 必须机器可读，不能只写一句自由文本。")
            # 非空且不是占位符
            for key in ("claim", "why_wrong", "root_cause"):
                v = (r.get(key) or "").strip()
                assert v and v not in ("todo", "tbd", "待补"), (
                    f"CONFLICTS[{c['id']}].retracted[{key!r}] 为空或占位符")
            # retracted_at 是日期串（不严格要求 ISO，但必须像日期）
            assert re.match(r"\d{4}-\d{2}-\d{2}", str(r["retracted_at"])), (
                f"CONFLICTS[{c['id']}].retracted.retracted_at 不是日期："
                f"{r['retracted_at']!r}")


def test_conflict_entries_have_required_fields():
    for c in FK.CONFLICTS:
        for k in ("id", "kind", "detail", "impact", "fix"):
            assert c.get(k), "冲突 %r 缺字段 %r" % (c.get("id"), k)
        assert c["kind"] in ("NAMING", "SEMANTIC", "SEVERITY", "ARCHITECTURE",
                             "DEFECT"), (
            "冲突 %r 的 kind=%r 不在已知分类里" % (c["id"], c["kind"]))
