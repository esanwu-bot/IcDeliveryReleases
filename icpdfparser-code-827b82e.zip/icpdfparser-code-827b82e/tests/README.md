# tests — 离线单测

原则：**不联网、不写生产库、不改仓库文件**（全部使用临时目录）。

```powershell
python -m unittest discover -s tests -v
```

| 文件 | 覆盖 |
|---|---|
| `test_ds_cloud.py` | docstrange 云端安全边界：开关默认关闭、来源白名单、`uploads/客户` 路径拒绝、凭据缺失/过期、`--dry-run` 不联网、`--allow-cloud` 不放宽白名单 |
| `test_engine_dirs.py` | 引擎对比口径：`docstrange` 只读 `data/ab_odl/docstrange/*.json`（`data/ds_md/*.md` 不参与）、哈希后缀归一、`.alts/.seo` 排除、目录缺失返回空 |
| `test_source_evidence.py` | 原厂证据卡：官方域名白名单（`ti.com.evil.com` 拒绝）、第三方来源不通过、官方 PDF 未覆盖后缀→`source_unresolved`、字段缺页码/核验人不得核验、冻结守卫 8 条、SHA 复用不合并核验历史、target_fields 未覆盖整件不得冻结 |
| `test_cheatsheet.py` | 核验单规则引擎 + Gold 核验口径：Pass 分组、`electrical[i].value`/`pin[i].name`（1 起）定位、电源脚/电流类=高风险、`has_quote`、import 零 stdout；守卫：verified 需**页码+证据**双必填、高风险须 quote、冲突可写 PDF 正确值、补录带证据直达 verified、状态机审计动作名 |
| `test_high_risk.py` | 高风险分类器：身份/封装/电流量纲/电源范围/关键电气/脚注/电源脚/方向脚/极限供电命中码；叙述类与普通引脚可批量；import 零 stdout |
| `test_evidence_verify.py` | batch-verify 十项重校验：高风险入批量被拒、dry 不写库、写库同步 Gold + 台账两类 action、幂等 already、**quote 回打 PDF**（防错页/编造）、数值三向不符转单件、SHA 不一致、batch_cap、单字段放行高风险；**高风险裸数字 quote 拒**（`quote_numeric_only`）；**裁决 `conflict_draft`**（`use_pdf` 改 Gold 草稿值+quote 回打、`keep_gold` 保留、dry 零写入、缺理由/错状态/冻结样本拒绝、裁决不写 reviewer） |
| `test_evidence_chain.py` | E1–E4 机器起草：登记(SHA/页数/文本层/tier)、预检只出报告不置 verified、E3 定位+未定位落 `ocr_pending`、**幂等不重复插**、**人工已处置行不被覆盖**、E4 标 `conflict_draft` 且不改 Gold、就绪度守卫逐项、`_path_get`；**E3 值定位守卫**（`SOIC-8` 不再抽出 `-8`、图号 `Figure 6-8` 不成候选、数字 token 边界 `15` 不命中 `150`、裸数字行不算证据、负数仍可定位） |
| `test_freeze_precheck.py` | 冻结前置自查 G1–G10：全绿就绪、各红项（unresolved/身份/非官方/覆盖型号/未核验证据/页码/核验人/SHA/target 粒度/pending 残留）、服务端复核行一致与不一致两种渲染、退出码 0/1/3、`--all` 批量、**只读性**（跑完各表计数不变、台账零写入）、import 零 stdout |
| `test_attach_worklist.py` | 补挂接 + 必须人工量：`attach_list` 带定位/模板/风险、空缺失、`--emit-attach` jsonl；执行器建**草稿**（pending/无 reviewer/page 0）、target **并集不删现有**、幂等二次全 skipped、dry 零写入、坏行跳过；挂接后 **G9 转绿而 G5 仍红**（草稿≠核验）；worklist 分组 A/B/C/D/F/E + `clicks_est`、全绿点击 0、只读性、无卡返回 None |
| `test_mdpreview.py` | Markdown→HTML 预览（浏览器渲染态，替代源码态）：标题 1–4、表格（分隔行判定 / `\\|` 还原 / 无分隔行退化为段落）、列表/引用/分隔线/代码块、粗体/行内代码/仅 http 链接、**转义安全**（`<script>` 不得成标签）、`to_html` 含 `<style>`+打印按钮、import 与渲染零 stdout |
| `test_i18n_restore.py` | i18n 回填工具：只新增 `multi_language` 一个顶层键、旧键深度相等（改动即该件拒写）、备份哈希须等于写前源、备份已存在即拒（不静默覆盖）、`--do-write` 必须配 `--i-understand`、`--verify-only` 与写互斥、`--expect-count` 钉死件数、单件 FAIL 即整批非 0、幂等重跑 `SKIP_ALREADY`、交付件 schema（三字段必填 / `features`·`applications` 选填且须为列表） |

| `test_reparse_carry.py` | 重解析的顶层键守卫（2026-10-28 丢多语言回归）：`multi_language` 整块深拷贝回带、新解析只回部分语言时按语种补齐且新值优先、旧无则不凭空补造、`top_key_loss` 只查必齐备/必带回两组、端到端跑 `main()` 断言「缺键即把旧内容写回文件 + 退出码 1」、正常合并保留多语言且订货行与人工字段不被冲掉 |

新增测试只需放入本目录、命名 `test_*.py`，直接继承 `unittest.TestCase`（无需安装 pytest）。
Windows 下用临时 SQLite 的用例**必须在 `tearDown` 关连接**，否则临时文件被锁。
