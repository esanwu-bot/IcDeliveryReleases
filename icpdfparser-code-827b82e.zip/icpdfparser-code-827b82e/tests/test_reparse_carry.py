"""reparse_ordering 的顶层键守卫：2026-10-28 丢 multi_language 的回归用例。

背景（docs/qc/i18n_loss_scope_20261029.md）：重解析把模型返回的新 doc 整体落盘，
而 `ICPDF_LANGS` 未设置时 prompt 明确要求「不要输出 multi_language」，
`_carry_over` 又只回带 `basic_info` / `specs.package` 两组字段——于是每重解析一件
就丢一件多语言，235 件就是这么没的。

这里钉住两条：
1. `_carry_over` 必须把 `multi_language` 整块带回（含「新解析只回了一部分语言」）；
2. 带回来之后仍缺顶层键，就必须整件回滚、把旧内容写回文件，且退出码非 0。

本地跑：python -m unittest tests.test_reparse_carry -v
"""
from __future__ import annotations

import contextlib
import copy
import importlib
import io
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import reparse_ordering as R                    # noqa: E402

LANGS = ("ja", "ko", "de", "es")


def _ml():
    return {lg: {"title": "t-" + lg, "description": "d-" + lg, "meta": "m-" + lg}
            for lg in LANGS}


def old_doc() -> dict:
    """旧 doc：订货行只有 1 行，但带 multi_language 和人工修正字段。"""
    return {
        "basic_info": {"mpn": "X1", "manufacturer": "TI", "identity": "manual"},
        "specs": {"electrical": [],
                  "package": {"type": "VQFN", "onboard_device": "board"}},
        "features": ["old"], "applications": ["old-app"],
        "pin_configuration": [],
        "ordering_info": [{"mpn": "X1"}], "alternatives": [],
        "seo": {"title_en": "x"}, "metadata": {"pdf_hash": "deadbeef"},
        "multi_language": _ml(),
    }


def model_new_doc() -> dict:
    """ICPDF_LANGS 未设置时模型的真实输出形状：9 个顶层键，没有 multi_language。"""
    d = copy.deepcopy(old_doc())
    d.pop("multi_language")
    d["basic_info"].pop("identity")
    d["specs"]["package"].pop("onboard_device")
    d["features"] = ["new"]
    d["ordering_info"] = [{"mpn": "X1"}, {"mpn": "X2"}, {"mpn": "X3"}]
    return d


class CarryOverTest(unittest.TestCase):
    def test_new_doc_without_multi_language_gets_it_back(self):
        old, new = old_doc(), model_new_doc()
        kept = R._carry_over(old, new)
        self.assertIn("multi_language", kept)
        self.assertEqual(new["multi_language"], _ml())

    def test_carried_multi_language_is_a_copy(self):
        old, new = old_doc(), model_new_doc()
        R._carry_over(old, new)
        new["multi_language"]["ja"]["title"] = "changed"
        self.assertEqual(old["multi_language"]["ja"]["title"], "t-ja")

    def test_partial_new_languages_do_not_drop_old_ones(self):
        old, new = old_doc(), model_new_doc()
        new["multi_language"] = {"ja": {"title": "fresh", "description": "d",
                                       "meta": "m"}}
        kept = R._carry_over(old, new)
        self.assertEqual(set(new["multi_language"]), set(LANGS))
        self.assertEqual(new["multi_language"]["ja"]["title"], "fresh")
        self.assertEqual(new["multi_language"]["de"], old["multi_language"]["de"])
        self.assertIn("multi_language(ko,de,es)", kept)

    def test_basic_info_and_package_still_carried(self):
        old, new = old_doc(), model_new_doc()
        kept = R._carry_over(old, new)
        self.assertEqual(new["basic_info"]["identity"], "manual")
        self.assertIn("basic_info.identity", kept)
        self.assertEqual(new["specs"]["package"]["onboard_device"], "board")
        self.assertIn("specs.package.onboard_device", kept)

    def test_multi_language_absent_in_old_is_not_invented(self):
        old = old_doc()
        old.pop("multi_language")
        new = model_new_doc()
        kept = R._carry_over(old, new)
        self.assertNotIn("multi_language", new)
        self.assertNotIn("multi_language", kept)


class TopKeyLossTest(unittest.TestCase):
    def test_loss_detected_before_carry_over(self):
        self.assertEqual(R.top_key_loss(old_doc(), model_new_doc()),
                         ["multi_language"])

    def test_carry_over_closes_the_loss(self):
        old, new = old_doc(), model_new_doc()
        R._carry_over(old, new)
        self.assertEqual(R.top_key_loss(old, new), [])

    def test_missing_required_key_detected(self):
        old, new = old_doc(), model_new_doc()
        new.pop("seo")
        R._carry_over(old, new)
        self.assertEqual(R.top_key_loss(old, new), ["seo"])

    def test_key_that_old_never_had_is_not_loss(self):
        old = old_doc()
        old.pop("multi_language")
        self.assertEqual(R.top_key_loss(old, model_new_doc()), [])


class GuardRollbackTest(unittest.TestCase):
    """跑真正的 main()：新解析丢顶层键时，文件必须还原、退出码非 0。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.parsed = self.dir / "parsed"
        self.parsed.mkdir()
        self.pdfs = self.dir / "pdfs"
        self.pdfs.mkdir()
        (self.pdfs / "X1__ds.pdf").write_bytes(b"%PDF-1.4\n")
        self.backup = self.dir / "backup"
        self.target = self.parsed / "X1_deadbeef.json"

    def tearDown(self):
        self.tmp.cleanup()

    def _orderables(self, doc):
        return doc.get("ordering_info") or []

    def _run(self, new_doc: dict) -> tuple[int, str]:
        self.target.write_text(json.dumps(old_doc(), ensure_ascii=False),
                               encoding="utf-8")

        def fake_parse_pdf(pdf, mpn):
            # parse_pdf 先把新 doc 写到同名文件，这里如实模拟
            self.target.write_text(json.dumps(new_doc, ensure_ascii=False),
                                   encoding="utf-8")
            return {"status": "ok", "doc": copy.deepcopy(new_doc)}

        fake = types.ModuleType("app.services.pipeline")
        fake.parse_pdf = fake_parse_pdf
        # 别的用例会清掉 sys.modules 里 app* 的条目，这里现取一次并同时钉住
        # sys.modules，否则 main() 里的 `from app.services import pipeline`
        # 会重新导入真 pipeline，去开那份假 PDF。
        services = importlib.import_module("app.services")
        buf = io.StringIO()
        with mock.patch.object(R.BI, "classify",
                              return_value={"state": R.BI.INCOMPLETE}), \
             mock.patch.object(R.BI, "orderables", side_effect=self._orderables), \
             mock.patch.object(R, "_order_pages", return_value=[3]), \
             mock.patch.object(services, "pipeline", fake, create=True), \
             mock.patch.dict(sys.modules, {"app.services.pipeline": fake}), \
             contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
            rc = R.main(["--data-dir", str(self.parsed), "--pdfs", str(self.pdfs),
                         "--backup", str(self.backup), "--apply", "--workers", "1",
                         "--mpn", "X1"])
        return rc, buf.getvalue()

    def test_key_loss_rolls_back_and_exits_non_zero(self):
        new = model_new_doc()
        new.pop("seo")                     # 带回来也补不上的结构性丢失
        rc, out = self._run(new)
        self.assertEqual(rc, 1, out)
        self.assertIn("顶层键丢失 seo", out)
        on_disk = json.loads(self.target.read_text(encoding="utf-8"))
        self.assertEqual(on_disk, old_doc())

    def test_merged_doc_keeps_multi_language_and_exits_zero(self):
        rc, _ = self._run(model_new_doc())
        self.assertEqual(rc, 0)
        on_disk = json.loads(self.target.read_text(encoding="utf-8"))
        self.assertEqual(on_disk["multi_language"], _ml())
        self.assertEqual(len(on_disk["ordering_info"]), 3)
        self.assertEqual(on_disk["features"], ["new"])
        self.assertEqual(on_disk["basic_info"]["identity"], "manual")


if __name__ == "__main__":
    unittest.main()
