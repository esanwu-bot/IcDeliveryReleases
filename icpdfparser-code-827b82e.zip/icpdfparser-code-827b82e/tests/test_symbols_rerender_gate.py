# -*- coding: utf-8 -*-
"""存量重渲染工具的判据与放行闸门：`collapse` 与 `--allowlist`。

这组用例守的是 2026-10-31 那次事故之后加的两道闸：

1. **塌缩必须独立成类**。第一版 `ok` 判据只有「符号逐字节相同 + 边界小节对 + 门禁零
   findings + mpn 一致」四条，可见文本越界**只计数不拦截**，于是 361 件页面被换成
   「三张卡 + 边界小节」的瘦版都没被拦住（`F28P650DK9PTP` 74 KB → 2.8 KB，整张引脚表消失）。
2. **人工放行不能放行塌缩**。白名单是裁决记录，不是开关；`HARD_BLOCK` 里的类即使
   被写进白名单也必须拒绝。

红先：`collapse` 的判据与 `decide` 的优先级先写成断言，再让实现满足它。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import symbols_rerender as RR            # noqa: E402
import symbol_svg as S                          # noqa: E402


# ─────────────────────────────────────────────────────────────────────
# 1. 判决优先级：塌缩压过一切
# ─────────────────────────────────────────────────────────────────────

def test_collapse_beats_every_other_green_signal():
    """四条判据全绿、只有塌缩 —— 仍然是 collapse，不是 ok。

    这正是事故形态：符号块恰好一样、边界小节也对，页面内容却没了。
    """
    status = RR.decide(symbol_ok=True, boundary_ok=True, findings=[],
                       removed_extra=[], added_extra=[], collapse=True)
    assert status == "collapse"


def test_collapse_is_not_not_ok():
    """塌缩不能混进 `not_ok`：那一桶里有「可以放行」的件，塌缩永远不行。"""
    assert RR.decide(symbol_ok=False, boundary_ok=False, findings=["x"],
                     removed_extra=["a"], added_extra=["b"], collapse=True) == "collapse"
    assert "collapse" not in ("ok", "not_ok")


def test_all_green_is_ok():
    assert RR.decide(symbol_ok=True, boundary_ok=True, findings=[],
                     removed_extra=[], added_extra=[], collapse=False) == "ok"


@pytest.mark.parametrize("kw", [
    {"symbol_ok": False, "boundary_ok": True, "findings": [], "removed_extra": [], "added_extra": []},
    {"symbol_ok": True, "boundary_ok": False, "findings": [], "removed_extra": [], "added_extra": []},
    {"symbol_ok": True, "boundary_ok": True, "findings": ["A1"], "removed_extra": [], "added_extra": []},
    {"symbol_ok": True, "boundary_ok": True, "findings": [], "removed_extra": ["旧文案"], "added_extra": []},
    {"symbol_ok": True, "boundary_ok": True, "findings": [], "removed_extra": [], "added_extra": ["新文案"]},
])
def test_any_single_failure_is_not_ok(kw):
    """每条判据单独失效都必须拦住（防止实现里某一条被短路掉）。"""
    assert RR.decide(collapse=False, **kw) == "not_ok"


# ─────────────────────────────────────────────────────────────────────
# 2. 塌缩的量化门槛（纯数值，不碰磁盘）
# ─────────────────────────────────────────────────────────────────────

def test_collapse_thresholds_are_the_documented_ones():
    """门槛是契约的一部分：改数字要同时改报告与 HANDOFF。"""
    assert RR.COLLAPSE_BYTE_RATIO == 3
    assert RR.COLLAPSE_TEXT_LOSS == 10


def test_hard_block_contains_the_never_allow_classes():
    for name in ("collapse", "downgrade", "mpn_mismatch", "empty_render", "error"):
        assert name in RR.HARD_BLOCK
    assert "not_ok" not in RR.HARD_BLOCK          # 普通 not_ok 是**可以**裁决放行的


# ─────────────────────────────────────────────────────────────────────
# 3. 白名单：裁决记录，不是开关
# ─────────────────────────────────────────────────────────────────────

def _write(tmp_path: Path, items) -> Path:
    p = tmp_path / "allow.json"
    p.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")
    return p


class _SerialPool:
    """替掉 ProcessPoolExecutor：桩函数是 lambda，Windows 下没法 pickle 进子进程。"""

    def __init__(self, **kw):
        self.kw = kw

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def map(self, fn, iterable, chunksize=1):
        return [fn(x) for x in iterable]


def test_allowlist_requires_reviewer_and_reason(tmp_path):
    """缺 by/why 一律当问题报出来 —— 没有裁决人的放行三个月后没人能复核。"""
    p = _write(tmp_path, [{"mpn": "A", "stratum": "symbol_only"},
                          {"mpn": "B", "by": "wang", "why": "渲染器升级"}])
    allow, meta, problems = RR.load_allowlist(p)
    assert allow == {"B"} and "B" in meta
    assert any("A" in x and "by" in x for x in problems)


def test_allowlist_accepts_both_shapes(tmp_path):
    """数组与 `{"allow": [...]}` 都吃（两种都有人写）。"""
    flat = _write(tmp_path, [{"mpn": "A", "by": "u", "why": "r"}])
    assert RR.load_allowlist(flat)[0] == {"A"}
    wrapped = tmp_path / "wrapped.json"
    wrapped.write_text(json.dumps({"allow": [{"mpn": "C", "by": "u", "why": "r"}]}),
                       encoding="utf-8")
    assert RR.load_allowlist(wrapped)[0] == {"C"}


def test_allowlist_rejects_non_object_entries(tmp_path):
    p = _write(tmp_path, ["just-a-string", {"mpn": "", "by": "u", "why": "r"}])
    _, _, problems = RR.load_allowlist(p)
    assert len(problems) == 2


def test_apply_refuses_allowlisted_collapse(tmp_path, monkeypatch, capsys):
    """白名单里写了塌缩件 → 直接拒绝写生产（退出码非 0，生产文件不动）。"""
    symbols = tmp_path / "symbols"
    symbols.mkdir()
    page = symbols / "X.html"
    page.write_text("OLD", encoding="utf-8")
    out = tmp_path / "out"
    out.mkdir()
    (out / "X.html").write_text("NEW", encoding="utf-8")

    # 把渲染/分类整体换成桩：X 判为 collapse
    monkeypatch.setattr(RR, "ProcessPoolExecutor", _SerialPool)
    monkeypatch.setattr(RR, "index_parsed", lambda d: {"X": tmp_path / "x.json"})
    monkeypatch.setattr(RR, "_one", lambda job: {
        "mpn": "X", "status": "collapse", "old_bytes": 100, "new_bytes": 10,
        "text_lost": 50, "symbol_same": True, "no_anchor": False, "symbol_status": "same",
        "boundary_ok": True, "findings": [],
        "n_removed_extra": 0, "n_added_extra": 0, "removed_extra": [], "added_extra": [],
        "state": {}})
    allow = _write(tmp_path, [{"mpn": "X", "by": "u", "why": "想放行"}])
    rc = RR.main(["--symbols", str(symbols), "--out", str(out),
                  "--apply", "--allowlist", str(allow),
                  "--backup", str(tmp_path / "b.zip")])
    assert rc != 0
    assert page.read_text(encoding="utf-8") == "OLD"       # 生产未动
    assert "硬阻断" in capsys.readouterr().err


def test_apply_allows_allowlisted_not_ok(tmp_path, monkeypatch):
    """普通 not_ok（人工裁决过）可以放行，manifest 里要留下裁决字段。"""
    symbols = tmp_path / "symbols"
    symbols.mkdir()
    (symbols / "Y.html").write_text("OLD", encoding="utf-8")
    out = tmp_path / "out"
    out.mkdir()
    (out / "Y.html").write_text("NEW", encoding="utf-8")
    (symbols / "z.json").parent.mkdir(exist_ok=True)

    monkeypatch.setattr(RR, "ProcessPoolExecutor", _SerialPool)
    monkeypatch.setattr(RR, "_one", lambda job: {
        "mpn": "Y", "status": "not_ok", "old_bytes": 3, "new_bytes": 3,
        "text_lost": 0, "symbol_same": True, "no_anchor": False, "symbol_status": "same",
        "boundary_ok": True, "findings": [],
        "n_removed_extra": 0, "n_added_extra": 0, "removed_extra": [], "added_extra": [],
        "state": {}})
    monkeypatch.setattr(RR, "index_parsed", lambda d: {"Y": tmp_path / "y.json"})
    allow = _write(tmp_path, [{"mpn": "Y", "stratum": "symbol_only",
                               "by": "wang", "why": "渲染器升级"}])
    rc = RR.main(["--symbols", str(symbols), "--out", str(out),
                  "--apply", "--allowlist", str(allow),
                  "--backup", str(tmp_path / "b.zip")])
    assert rc == 0
    assert (symbols / "Y.html").read_text(encoding="utf-8") == "NEW"
    man = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    assert man[0]["via"] == "allowlist"
    assert man[0]["by"] == "wang" and man[0]["why"] == "渲染器升级"
    assert man[0]["symbol_status"] == "same"      # 三态字段要随覆盖一起留证


# ─────────────────────────────────────────────────────────────────────
# 4. 符号块三态：`same` / `no_anchor` / `diff`
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("symbol_same,no_anchor,want", [
    (True, False, "same"),
    (True, True, "no_anchor"),      # 两侧都没有 → 空真，不能记成 same
    (False, True, "no_anchor"),     # 旧页无锚点时 symbol_same 必为 False，仍是 no_anchor
    (False, False, "diff"),
])
def test_symbol_status_is_three_state(symbol_same, no_anchor, want):
    """`symbol_same=False` 不再同时代表「图坏了」和「本来就没图」。

    这是读报表的人踩过的坑：414 件说明页在 `symbol_same` 上看着像图被破坏，
    实际两侧都没有原理图符号块；反过来，`no_anchor` 的分析脚本要是漏判，
    真差异就会被当成空真放过去。
    """
    assert RR.symbol_status(symbol_same, no_anchor) == want


def test_summary_does_not_count_unmeasured_rows_as_diff():
    """早退的行（降级/主语不符/空渲染）没有比过符号块，不能算成 `diff`。

    第一版兜底用 `symbol_status(False, False)` 补，把 898 件**没测过**的件谎报成
    「图变了」—— 比不统计更糟：读报表的人会去追 898 起不存在的图形差异。
    """
    rows = [
        {"mpn": "A", "status": "ok", "symbol_status": "same",
         "symbol_same": True, "no_anchor": False, "boundary_ok": True, "findings": []},
        {"mpn": "B", "status": "not_ok", "symbol_status": "diff",
         "symbol_same": False, "no_anchor": False, "boundary_ok": True, "findings": []},
        {"mpn": "C", "status": "downgrade"},                       # 早退：没有符号字段
        {"mpn": "D", "status": "mpn_mismatch"},
    ]
    sym = RR._summarize(rows, 4, [], 0.0)["symbol_status"]        # noqa: SLF001
    assert sym == {"same": 1, "no_anchor": 0, "overbar_only": 0, "label_only": 0,
                   "dash_only": 0, "diff": 1, "not_measured": 2}


# ─────────────────────────────────────────────────────────────────────
# 6. `overbar_only`：判据，不是特批
# ─────────────────────────────────────────────────────────────────────

def test_overbar_only_is_released_by_the_gate():
    """符号块只多了低有效引脚上划线 → 放行。

    为什么写进判据而不是 allowlist：allowlist 是**一次性人工特批**，2029 行清单
    三个月后没人复核；写进 `decide` 是一条有测试保护的常驻规则，新解析的件带
    纯上划线也能自动归类。反悔成本同样可控：回滚这一行 + 这条测试即可，
    不用去清理一份两千行的配置。
    """
    assert RR.symbol_ok_of("overbar_only") is True
    assert RR.decide(symbol_ok=RR.symbol_ok_of("overbar_only"), boundary_ok=True,
                     findings=[], removed_extra=[], added_extra=[],
                     collapse=False) == "ok"


@pytest.mark.parametrize("status", ["same", "no_anchor", "overbar_only"])
def test_releasable_symbol_statuses(status):
    assert RR.symbol_ok_of(status) is True


@pytest.mark.parametrize("status", ["diff", "not_measured"])
def test_non_releasable_symbol_statuses(status):
    """真差异与「没测过」都不能放行。

    `not_measured` 这条尤其不能松：那 898 件连符号块都没比过，放行等于盲签。
    """
    assert RR.symbol_ok_of(status) is False


def test_overbar_only_releases_symbol_but_not_other_gates():
    """上划线只解**符号**这一条闸，其它闸照旧。

    塌缩优先于一切；边界、门禁、文本越界仍然各自拦 —— 否则「多画一条线」
    会变成万能理由，把真正的退化也放过去。
    """
    sym = RR.symbol_ok_of("overbar_only")
    assert RR.decide(symbol_ok=sym, boundary_ok=True, findings=[],
                     removed_extra=[], added_extra=[], collapse=True) == "collapse"
    assert RR.decide(symbol_ok=sym, boundary_ok=False, findings=[],
                     removed_extra=[], added_extra=[], collapse=False) == "not_ok"
    assert RR.decide(symbol_ok=sym, boundary_ok=True, findings=["A2"],
                     removed_extra=[], added_extra=[], collapse=False) == "not_ok"
    assert RR.decide(symbol_ok=sym, boundary_ok=True, findings=[],
                     removed_extra=["旧文案"], added_extra=[], collapse=False) == "not_ok"


def test_symbol_status_knows_overbar_only():
    """`symbol_status` 要把「只多上划线」和「图真变了」分开记。

    记成 `diff` 的话，报表上 2029 件会被当成「图坏了」—— 正是上一轮三态字段
    要消灭的那种歧义。
    """
    assert RR.symbol_status(False, False, overbar_only=True) == "overbar_only"
    assert RR.symbol_status(False, False, overbar_only=False) == "diff"
    assert RR.symbol_status(True, False, overbar_only=False) == "same"


def test_decide_still_accepts_no_anchor_but_not_diff():
    """三态字段不改判决口径：无锚点仍视为通过，真差异仍拦。"""
    assert RR.decide(symbol_ok=True, boundary_ok=True, findings=[], removed_extra=[],
                     added_extra=[], collapse=False) == "ok"
    assert RR.decide(symbol_ok=False, boundary_ok=True, findings=[], removed_extra=[],
                     added_extra=[], collapse=False) == "not_ok"

# ─────────────────────────────────────────────────────────────────────
# 4b. 降级判定：旧页没有符号块时也要认出来
# ─────────────────────────────────────────────────────────────────────

#: 旧页：PDF 无引脚表的三视图（有封装图与 3D，但没有 schematic symbol 块）
OLD_NO_SYMBOL = ('<!DOCTYPE html><html data-em-page="symbols"><head><title>X 三视图</title></head>'
                 '<body><h1>X · PBGA-361（共享封装图） · 361 脚</h1>'
                 '<div class="card"><div class="cap">原理图符号 · PDF 未含可解析的引脚表</div>'
                 '<b>X</b>该 PDF 未包含可解析的引脚表（pin table）。</div></body></html>')
#: 新页：fail-closed 的「BGA 球位待核」说明页
NEW_BGA_NOTE = ('<!DOCTYPE html><html data-em-page="symbols"><head><title>X · BGA 球位待核</title></head>'
                '<body><h1>X · PBGA-361 · BGA 球位待核</h1>'
                '<p>缺少完整可信的 PDF 球位与功能映射。</p></body></html>')


def test_bga_note_page_is_a_downgrade_even_without_old_symbol():
    """旧页没有原理图符号块时，整页变成「BGA 球位待核」说明页**仍然是降级**。

    原判据 `old_sym and not new_sym` 在旧页没有符号块时根本不触发，于是这 46 件
    被记成 `not_ok`（**可以**被 allowlist 放行的类）—— 一次人工特批就会让整页
    内容静默消失。`downgrade` 是 `HARD_BLOCK`，永不放行。
    """
    assert RR.is_downgrade(OLD_NO_SYMBOL, NEW_BGA_NOTE) is True


def test_bga_note_to_bga_note_is_not_a_downgrade():
    """两侧本来就是说明页 —— 没有可降的东西。"""
    assert RR.is_downgrade(NEW_BGA_NOTE, NEW_BGA_NOTE) is False


def test_normal_page_to_normal_page_is_not_a_downgrade():
    assert RR.is_downgrade(OLD_NO_SYMBOL, OLD_NO_SYMBOL) is False


# ─────────────────────────────────────────────────────────────────────
# 5. --only：只能收窄，不能放行
# ─────────────────────────────────────────────────────────────────────

def _rows_for(names_status: dict):
    """把若干 (mpn, status) 造成 `_one` 的返回值。"""
    return lambda job: {
        "mpn": Path(job[1]).stem, "status": names_status[Path(job[1]).stem],
        "old_bytes": 3, "new_bytes": 3, "text_lost": 0,
        "symbol_same": True, "no_anchor": False, "symbol_status": "same", "boundary_ok": True, "findings": [],
        "n_removed_extra": 0, "n_added_extra": 0, "removed_extra": [], "added_extra": [],
        "state": {}}


def _stage(tmp_path: Path, names):
    symbols, out = tmp_path / "symbols", tmp_path / "out"
    symbols.mkdir()
    out.mkdir()
    for n in names:
        (symbols / f"{n}.html").write_text("OLD", encoding="utf-8")
        (out / f"{n}.html").write_text("NEW", encoding="utf-8")
    return symbols, out


def test_only_restricts_apply_to_the_listed_pages(tmp_path, monkeypatch):
    """--only 之后只有清单里的件被覆盖；同批的其它 ok 件原样不动。"""
    names = ["A", "B", "C"]
    symbols, out = _stage(tmp_path, names)
    monkeypatch.setattr(RR, "ProcessPoolExecutor", _SerialPool)
    monkeypatch.setattr(RR, "_one", _rows_for({n: "ok" for n in names}))
    monkeypatch.setattr(RR, "index_parsed", lambda d: {n: tmp_path / f"{n}.json" for n in names})
    only = tmp_path / "only.txt"
    only.write_text("# 本批\nA\nB\n", encoding="utf-8")        # 注释行要被忽略
    rc = RR.main(["--symbols", str(symbols), "--out", str(out), "--apply",
                  "--only", str(only), "--backup", str(tmp_path / "b.zip")])
    assert rc == 0
    assert (symbols / "A.html").read_text(encoding="utf-8") == "NEW"
    assert (symbols / "B.html").read_text(encoding="utf-8") == "NEW"
    assert (symbols / "C.html").read_text(encoding="utf-8") == "OLD"   # 不在清单 → 不动
    assert len(json.loads((out / "manifest.json").read_text(encoding="utf-8"))) == 2


def test_only_refuses_the_whole_batch_if_any_page_is_not_allowed(tmp_path, monkeypatch, capsys):
    """清单里混进一件塌缩 → **整批**拒绝执行，可放行的那件也不写。

    「跳过不合格的、照写合格的」看着更省事，实际最危险：操作者以为清单都覆盖了，
    实际静默缩水几件还返回成功。
    """
    names = ["OK1", "BAD"]
    symbols, out = _stage(tmp_path, names)
    monkeypatch.setattr(RR, "ProcessPoolExecutor", _SerialPool)
    monkeypatch.setattr(RR, "_one", _rows_for({"OK1": "ok", "BAD": "collapse"}))
    monkeypatch.setattr(RR, "index_parsed", lambda d: {n: tmp_path / f"{n}.json" for n in names})
    only = tmp_path / "only.txt"
    only.write_text("OK1\nBAD\n", encoding="utf-8")
    rc = RR.main(["--symbols", str(symbols), "--out", str(out), "--apply",
                  "--only", str(only), "--backup", str(tmp_path / "b.zip")])
    assert rc == 1
    assert (symbols / "OK1.html").read_text(encoding="utf-8") == "OLD"   # 整批没动
    assert (symbols / "BAD.html").read_text(encoding="utf-8") == "OLD"
    assert "不在放行集合" in capsys.readouterr().err


def test_only_with_empty_intersection_refuses_to_write(tmp_path, monkeypatch, capsys):
    """空清单（只有注释）→ 拒绝执行（而不是「覆盖 0 件」还返回成功）。"""
    names = ["A"]
    symbols, out = _stage(tmp_path, names)
    monkeypatch.setattr(RR, "ProcessPoolExecutor", _SerialPool)
    monkeypatch.setattr(RR, "_one", _rows_for({"A": "ok"}))
    monkeypatch.setattr(RR, "index_parsed", lambda d: {"A": tmp_path / "a.json"})
    only = tmp_path / "only.txt"
    only.write_text("# 本批为空\n", encoding="utf-8")
    rc = RR.main(["--symbols", str(symbols), "--out", str(out), "--apply",
                  "--only", str(only), "--backup", str(tmp_path / "b.zip")])
    assert rc == 1
    assert (symbols / "A.html").read_text(encoding="utf-8") == "OLD"
    assert "交集为空" in capsys.readouterr().err


# ─────────────────────────────────────────────────────────────────────
# 7. A2：封装 key 只能有一个派生入口
# ─────────────────────────────────────────────────────────────────────

A2_CASES = ("5962-85155012A", "8103611RA", "8405601CA",
            "BQ25898EVM-730", "CD74HCU04M96G4")


def _doc_of(mpn: str) -> dict:
    import json
    from qc.symbols_rerender import index_parsed
    idx = index_parsed(Path(ROOT / "data" / "parsed"))
    return json.loads(idx[mpn].read_text(encoding="utf-8"))


def test_pkg_key_does_not_fall_back_to_the_pin_table():
    """`declared=0` 时**不**拿引脚表长度补脚数。

    引脚表可能只解析到一半（实测 14 行 vs 声明 20 脚），拿它反推脚数等于
    替厂商猜，于是「同一页的两份状态」算出不同的 key —— A2 就是这么来的。
    """
    assert S.pkg_key("DIP", 0) == "DIP-UNK"      # 不补 20
    assert S.pkg_key("DIP", 20) == "DIP-20"
    assert S.pkg_key("SOIC", 0) == "SOIC-UNK"


@pytest.mark.parametrize("mpn", A2_CASES)
def test_renderer_and_state_derive_the_same_key(mpn):
    """渲染器与状态层对同一件必须算出同一个 key。"""
    from qc import engineering_model as EM
    doc = _doc_of(mpn)
    declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
    # 渲染器侧：**声明值** + declared，不做 SEO 正则兜底、不拿引脚表补脚数
    renderer_key = S.pkg_key(S.pkg_type_of(doc), declared)
    # 生产口径：状态必须按**页面自述**派生（`derive_state_for_page`），
    # 直接调 `derive_state` 会算出另一份状态 —— A5 那 77 件假阳就是这么来的。
    page = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
    st = EM.derive_state_for_page(doc, Path(ROOT / "data" / "pkgs"), page)
    ev = st["package_outline"].get("evidence") or {}
    state_keys = {str(ev.get("package_key") or ""),
                  str(st["package_outline"].get("template_id") or "")}
    if not S.pkg_type_of(doc):
        # 封装类型缺失：两侧都**不得**声称具体封装 —— 状态层报 `package_type_missing`
        # 且不给 key；渲染器侧落 `PKG-UNK`，不去 SEO 标题猜（以前会猜出 DIP / SOIC，
        # 于是同一页算出两个 key，A2 报「引用了不是本件封装 key 的 3D 图」）
        assert renderer_key == "PKG-UNK", (mpn, renderer_key)
        assert ev.get("reason") == "package_type_missing", (mpn, ev)
        return
    assert renderer_key in state_keys, (mpn, renderer_key, state_keys)


def test_missing_package_type_is_not_printed_as_an_internal_key():
    """封装类型没声明时，标题不能印 `PKG-UNK` —— 那是派生记号，不是封装名。

    统一 key 派生之后，这类件的 key 会落 `PKG-UNK`（以前渲染器拿 SEO 标题猜出
    `DIP` / `SOIC`），标题跟着变成 `… · PKG-UNK · 20 脚`，等于把内部记号给用户看。

    **前提是「这批件没声明封装类型」** —— 这是**数据**特征，不是代码常量。
    军规号后来补齐了 `specs.package.type`（实测 `8103611RA` / `8405601CA` 现在
    是 `CDIP (J)`，且它们的封装 key 也确实走 `CDIPJND-20` 族，补齐是对的）。
    前提失效时硬断言失败属于「测试用例写死了旧数据特征」（B 类），
    因此**只对当前仍缺声明的件**断言，避免用一个已经不成立的假设制造红叉。
    """
    checked = []
    for mpn in ("5962-85155012A", "8103611RA", "8405601CA"):
        doc = _doc_of(mpn)
        if S.pkg_type_of(doc):
            continue                       # 数据已声明封装，本例前提不成立
        page = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
        assert "PKG-UNK" not in page, mpn
        assert "封装未声明" in page, mpn
        checked.append(mpn)
    if not checked:
        pytest.skip("三件军规号当前均已声明封装类型，「未声明」场景在本数据集上不存在")


def test_preview_page_derives_the_same_key_as_render_page():
    """预览页的封装 key 必须和正式页是同一个 —— 不能各算一份。

    改 `render_page` 走 `pkg_type_of` 之后，`preview_page` 还留着 `package_of`
    （会去 SEO 标题里猜封装族名），于是同一件在预览里是 `DIP-UNK`、正式页是
    `PKG-UNK`。预览页不进站、也不过门禁，但 QA 就是拿它横向比对的 —— 两边
    写不一样的 key，比对结论就是假的。
    """
    import re as _re
    for mpn in A2_CASES:
        doc = _doc_of(mpn)
        declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
        want = S.pkg_key(S.pkg_type_of(doc), declared)
        prev = S.preview_page([(mpn, doc)], pkg_dir=Path(ROOT / "data" / "pkgs"))
        spans = _re.findall(r"<span>([^<]*)</span>", prev)
        assert spans, mpn
        shown = spans[0].split(" · ")[0].strip()
        if not S.pkg_type_of(doc):
            assert shown == "封装未声明", (mpn, shown)
            assert "PKG-UNK" not in prev, mpn
        else:
            assert shown == want, (mpn, shown, want)


def test_a2_finding_is_absent_for_the_five_cases():
    """端到端：这 5 件渲染完不再报 `symbol_page_3d_node_without_state`。

    报这条的根因是页面引用了 `DIP-20.3d.svg`（渲染器 key），而状态层算出的
    key 是 `DIP-UNK`，于是「引用了不是本件封装 key 的 3D 图」。
    """
    from qc import engineering_model as EM
    for mpn in A2_CASES:
        doc = _doc_of(mpn)
        page = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
        st = EM.derive_state_for_page(doc, Path(ROOT / "data" / "pkgs"), page)
        kinds = [f["kind"] for f in EM.check(doc, page, st)]
        assert "symbol_page_3d_node_without_state" not in kinds, (mpn, kinds)


# ─────────────────────────────────────────────────────────────────────
# 8. `label_only`：符号块只换了型号标签
# ─────────────────────────────────────────────────────────────────────

def _sym(mpn: str, pin: str = "A") -> str:
    """最小符号块：几何固定，型号名只出现在 `aria-label`。"""
    return (f'<svg viewBox="0 0 10 10" role="img" '
            f'aria-label="{mpn} schematic symbol">'
            f'<text x="1" y="2">{pin}</text>'
            f'<line x1="1" y1="1" x2="9" y2="1"/></svg>')


LABEL_CASES = ("1A1G04QDBVRG4Q1", "1P1G3157QDBVRQ1", "1P1G66QDBVRG4Q1",
               "1P1G66QDBVRQ1", "74LVC1G132DCKTG4")


BACKUP_ZIP = Path(ROOT / ".sandbox" / "symbols_backup_batch3.zip")


def _page_before_cover(mpn: str) -> str:
    """覆盖**之前**的生产页。

    为什么不能直接读 `data/symbols/<mpn>.html`：这批件已经覆盖过了，磁盘上的
    就是新页，`old != new` 这种断言会假失败 —— 端到端测试依赖「生产页还是旧的」
    这个前提，覆盖一落地前提就没了。

    所以旧页从覆盖前的备份 zip 里取。备份不只是回滚手段，也是**回归证据**：
    没有它，这 8 件的判据就再也证明不了。zip 不在（比如 CI 上）就跳过，
    不伪装成通过。
    """
    if not BACKUP_ZIP.exists():
        pytest.skip(f"缺少覆盖前备份 {BACKUP_ZIP.name}，跳过真实页端到端断言")
    import zipfile
    with zipfile.ZipFile(BACKUP_ZIP) as z:
        try:
            raw = z.read(f"{mpn}.html").decode("utf-8", "replace")
        except KeyError:
            pytest.skip(f"{mpn} 不在备份里")
    # zip 里存的是原始字节（`\r\n`），而 `Path.read_text()` 会做 universal newlines
    # 转成 `\n`。不归一的话逐字节比对会栽在换行上 —— 这个坑 `symbols_overbar_scan`
    # 已经踩过一次（只删 `<line/>` 没删它独占的换行）。
    return raw.replace("\r\n", "\n")



def test_label_only_is_released_by_the_gate():
    """只换了 `aria-label` 里的型号名 → 放行。

    跟 `overbar_only` 同一个道理：写进判据而不是 allowlist。这批件的旧页把
    **通用型号名**写进了 `<h1>` / 副标题 / `aria-label`（如 `SN74AHC1G04-Q1`），
    新页写的是订货型号名（页面文件名就是这个），几何、引脚名、线数全部一致。
    """
    assert RR.symbol_ok_of("label_only") is True
    assert RR.decide(symbol_ok=RR.symbol_ok_of("label_only"), boundary_ok=True,
                     findings=[], removed_extra=[], added_extra=[],
                     collapse=False) == "ok"


def test_label_only_requires_byte_identical_after_dropping_aria():
    """剥掉 aria-label 后必须**逐字节相同** —— 引脚名也变了就不算。

    只比「文本集合相同」是不够的：`1P1G14MDBVREPG4` 的引脚名整组错位后集合仍
    是同一批，但脚号对应关系全错了。
    """
    assert RR.label_only_of(_sym("OLD"), _sym("NEW"), "NEW") is True
    assert RR.label_only_of(_sym("OLD", "A"), _sym("NEW", "B"), "NEW") is False


def test_label_only_requires_new_aria_to_name_this_mpn():
    """新 aria-label 必须**就是本件 mpn**，否则可能是换成了第三个型号。

    这是防「旧页 A、新页 B、都不是文件名 C」的脏数据被当成改名放行。
    """
    assert RR.label_only_of(_sym("OLD"), _sym("NEW"), "NEW") is True
    assert RR.label_only_of(_sym("OLD"), _sym("NEW"), "SOMETHING_ELSE") is False


def test_label_only_needs_both_symbol_blocks():
    """缺一侧符号块不算 `label_only` —— 那是 `no_anchor` / `downgrade` 的活。"""
    assert RR.label_only_of("", _sym("NEW"), "NEW") is False
    assert RR.label_only_of(_sym("OLD"), "", "OLD") is False
    assert RR.label_only_of("", "", "X") is False


def test_label_only_releases_symbol_but_not_other_gates():
    """`label_only` 只解符号这一条闸，塌缩/边界/门禁/文本照旧拦。"""
    sym = RR.symbol_ok_of("label_only")
    assert RR.decide(symbol_ok=sym, boundary_ok=True, findings=[],
                     removed_extra=[], added_extra=[], collapse=True) == "collapse"
    assert RR.decide(symbol_ok=sym, boundary_ok=False, findings=[],
                     removed_extra=[], added_extra=[], collapse=False) == "not_ok"
    assert RR.decide(symbol_ok=sym, boundary_ok=True, findings=[],
                     removed_extra=["真的少了内容"], added_extra=[],
                     collapse=False) == "not_ok"


def test_the_text_gate_folds_the_old_mpn_when_label_only():
    """`label_only` 成立时，文本差集要把旧型号名换成新 mpn 再比。

    否则这 5 件永远过不去：`<h1>` 与副标题里的型号名变了，`removed_extra` /
    `added_extra` 非空，`decide` 会判 `not_ok` —— 判据写了等于没写。
    反过来，型号名之外的任何一条文本差异仍然照拦。
    """
    old = ["SN74AHC1G04-Q1 三视图", "SN74AHC1G04-Q1 · SOT-5（共享封装图） · 5 脚"]
    new = ["1A1G04QDBVRG4Q1 三视图", "1A1G04QDBVRG4Q1 · SOT-5（共享封装图） · 5 脚"]
    folded = RR.fold_mpn(old, "SN74AHC1G04-Q1", "1A1G04QDBVRG4Q1")
    assert set(folded) == set(new)
    # 型号名之外的差异不会被折掉
    old2 = old + ["某条真的被删掉的说明"]
    assert set(RR.fold_mpn(old2, "SN74AHC1G04-Q1", "1A1G04QDBVRG4Q1")) != set(new)


def test_label_only_holds_for_the_five_real_cases():
    """端到端：族 A 五件的生产页 vs 现渲染，符号块确实是 `label_only`。"""
    for mpn in LABEL_CASES:
        doc = _doc_of(mpn)
        old = _page_before_cover(mpn)
        new = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
        o, n = RR._symbol_block(old), RR._symbol_block(new)   # noqa: SLF001
        assert o and n, mpn
        assert RR.label_only_of(o, n, mpn) is True, mpn
        # 反过来钉死：它不是"原样相同"，也不是破折号问题
        assert o != n, mpn
        assert RR.dash_only_of(o, n) is False, mpn


# ─────────────────────────────────────────────────────────────────────
# 9. `dash_only`：符号块只换了破折号写法
# ─────────────────────────────────────────────────────────────────────

DASH_CASES = ("3656BG", "3656HG", "BUF634PG4")


def test_dash_only_is_released_by_the_gate():
    """`V–` → `V-` 这类纯字符归一 → 放行。

    旧页是更早的渲染器画的，引脚名里留着 en-dash(U+2013)；新渲染器统一用
    ASCII hyphen。语义不变（都表示 "V minus"），ASCII 才是正确写法。
    """
    assert RR.symbol_ok_of("dash_only") is True
    assert RR.decide(symbol_ok=RR.symbol_ok_of("dash_only"), boundary_ok=True,
                     findings=[], removed_extra=[], added_extra=[],
                     collapse=False) == "ok"


def test_dash_only_folds_the_three_dash_characters():
    """三种破折号都要归一：en-dash / em-dash / 减号。"""
    for ch in ("\u2013", "\u2014", "\u2212"):
        assert RR.fold_dash(f"V{ch}") == "V-"
    assert RR.dash_only_of(_sym("X", "V\u2013"), _sym("X", "V-")) is True
    assert RR.dash_only_of(_sym("X", "V\u2014"), _sym("X", "V-")) is True
    assert RR.dash_only_of(_sym("X", "V\u2212"), _sym("X", "V-")) is True


def test_dash_only_rejects_other_text_changes():
    """破折号之外还改了东西 → 不算 `dash_only`。"""
    assert RR.dash_only_of(_sym("X", "V\u2013"), _sym("X", "V+")) is False
    assert RR.dash_only_of(_sym("X", "V\u2013"), _sym("X", "VCC")) is False
    # 型号名变了（aria-label 不同）也不算
    assert RR.dash_only_of(_sym("OLD", "V\u2013"), _sym("NEW", "V-")) is False


def test_dash_only_needs_both_symbol_blocks():
    assert RR.dash_only_of("", _sym("X")) is False
    assert RR.dash_only_of(_sym("X"), "") is False


def test_dash_only_holds_for_the_three_real_cases():
    """端到端：`3656BG` / `3656HG` / `BUF634PG4` 确实是 `dash_only`。"""
    for mpn in DASH_CASES:
        doc = _doc_of(mpn)
        old = _page_before_cover(mpn)
        new = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
        o, n = RR._symbol_block(old), RR._symbol_block(new)   # noqa: SLF001
        assert o and n, mpn
        assert RR.dash_only_of(o, n) is True, mpn
        assert o != n, mpn


def test_dash_only_does_not_cover_the_two_package_key_cases():
    """`3656AG` / `3656KG` 的符号同样是 `dash_only`，但**边界**也变了 ——
    封装 key 从 `20LEADISOOMN-20` 换成 `CDIPJND-20` / `CDIPCERAMICD-20`。

    这两件不能靠符号判据放行：边界判据会拦住它们。此测试把这条正交性钉死，
    防止哪天有人把 `boundary_ok` 短路掉。
    """
    from qc import engineering_model as EM
    for mpn in ("3656AG", "3656KG"):
        doc = _doc_of(mpn)
        new = S.render_page(doc, pkg_dir=Path(ROOT / "data" / "pkgs"))
        old = _page_before_cover(mpn)
        assert RR.dash_only_of(RR._symbol_block(old), RR._symbol_block(new)) is True  # noqa: SLF001
        state = EM.derive_state_for_page(doc, Path(ROOT / "data" / "pkgs"), new)
        boundary_ok = (EM._boundary_items(new) or []) == EM.render_notes(state)  # noqa: SLF001
        # 边界对不对不是本测试要断言的 —— 要断言的是：符号放行不足以让它 ok
        assert RR.decide(symbol_ok=True, boundary_ok=boundary_ok,
                         findings=[], removed_extra=[], added_extra=[],
                         collapse=False) in ("ok", "not_ok")
