# -*- coding: utf-8 -*-
"""上划线扫描器的分类判据。

这组用例守的是一个很窄的问题：**符号块「只多了一笔上划线」和「图被改了」必须分开**。
前者 2029 件、可批量合入；后者一件都不能放过。

红先过的两个坑：
1. 只删 `<line/>` 标签、不删它独占的那一行换行 → 剥离结果永远比旧块多一个 `\n`，
   于是 2030 件「纯上划线」全被误判成 `overbar_plus_other`（实测踩过）。
2. 用 `difflib` 的相似度判断「差不多一样」→ 0.98 的相似度里可能藏着坐标变化。
   这里坚持逐字节：剥离后必须 `==` 旧块。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc.symbols_overbar_scan import classify_pair        # noqa: E402

SVG_HEAD = ('<svg xmlns="http://www.w3.org/2000/svg" role="img" '
            'aria-label="{mpn} schematic symbol">\n')
BAR = ('<line x1="52.0" y1="36.0" x2="68.8" y2="36.0" '
       'stroke="#1f6f5c" stroke-width="1.4"/>\n')
OTHER_LINE = '<line x1="8" y1="45.0" x2="42" y2="45.0" stroke="#c0392b" stroke-width="2"/>\n'


def _page(mpn: str, body: str) -> str:
    return ("<html><body>" + SVG_HEAD.format(mpn=mpn) + body + "</svg></body></html>")


BASE = ('<text x="52" y="50.1" fill="#1f6f5c">1OE</text>\n'
        '<text x="52" y="88.1" fill="#1f6f5c">2OE</text>\n')


def test_overbar_only_is_detected():
    """旧块 + 一笔上划线 == 新块 → overbar_only，且数得清笔数。"""
    old = _page("X", BASE)
    new = _page("X", BASE + BAR)
    assert classify_pair(old, new) == ("overbar_only", 1)


def test_overbar_only_handles_several_bars():
    old = _page("X", BASE)
    new = _page("X", BASE + BAR + BAR.replace("52.0", "52.0").replace("36.0", "74.0"))
    assert classify_pair(old, new) == ("overbar_only", 2)


def test_identical_blocks_are_reported_as_identical():
    page = _page("X", BASE)
    assert classify_pair(page, page) == ("identical", 0)


def test_extra_non_overbar_line_is_not_overbar_only():
    """加了线但不写上划线签名 —— 不是这一批能碰的东西。"""
    old = _page("X", BASE)
    new = _page("X", BASE + OTHER_LINE)
    assert classify_pair(old, new) == ("line_added_not_overbar", 0)


def test_removed_line_blocks_the_class():
    """少了一条线：不是「纯新增」，哪怕同时加了上划线。"""
    old = _page("X", BASE + OTHER_LINE)
    new = _page("X", BASE + BAR)
    assert classify_pair(old, new) == ("line_removed", 0)


def test_overbar_plus_other_change_is_not_pure():
    """上划线加了、文字也改了 —— 只增一笔之外还有别的事，必须留在 not_ok。"""
    old = _page("X", BASE)
    new = _page("X", BASE.replace("2OE", "2G") + BAR)
    assert classify_pair(old, new) == ("overbar_plus_other", 0)


def test_missing_symbol_block_is_not_counted():
    """一侧没有 `schematic symbol` 块 → 不进这个统计（空真没有「新增一笔」可言）。"""
    old = "<html><body>no symbol here</body></html>"
    new = _page("X", BASE + BAR)
    assert classify_pair(old, new) == ("no_symbol_block", 0)
