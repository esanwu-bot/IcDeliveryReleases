"""`next` 子命令（挑选下一个待修工单 → 生成 next_task.md）的离线用例。

全部不联网：镜像用 tmp_path 现造，`verify` 用假 session。
理由同质审单测 —— 这条链路决定「本地 Agent 明天改哪张单」，判据错了不是 bug，
是让它去改错的东西。
"""

from __future__ import annotations

import json

import pytest

from app.integrations import github_issues as GH


def _md(number: int, mpn: str, *, state: str = "OPEN", sev: str = "severity:P0",
        items: list[tuple[str, str, str]] | None = None, page: str = "p5",
        bbox: str = "[58.9, 366.0, 508.9, 374.8]", row: str = "RθJA 124.7@196 181.4@238") -> str:
    """造一份与 sync 产物同构的镜像（只保留解析器真正读的字段）。"""
    items = items or [("P0", "多列塌缩", "RθJA 只抽一列，原文有 8 列")]
    total = len(items)
    p0 = sum(1 for x in items if x[0] == "P0")
    # 标题前缀要跟标签一致：真实的 [CMD] 单标题里没有 `/P0`，否则解析器会误当质审单。
    prefix = "[质审/P0]" if sev == "severity:P0" else "[CMD]"
    lines = [
        f"# GH-{number} · {prefix} {mpn} · 发现 {total} 项严重缺陷",
        "",
        "| 项 | 值 |",
        "|---|---|",
        f"| 编号 | #{number} |",
        f"| 状态 | **{state}** |",
        f"| 标签 | `qa-audit` `auto-generated` `{sev}` |",
        f"| 链接 | https://github.com/o/r/issues/{number} |",
        f"| MPN | `{mpn}` |",
        f"| 缺陷数 | {total}（P0 ×{p0} / P1 ×{total - p0}） |",
        "| 本轮结论 | reject |",
        "",
        "## 正文",
        "",
    ]
    lines += [f"- [ ] [{s}/{c}] {t}" for s, c, t in items]
    lines += ["", "### 逐条详情", ""]
    for i, (s, c, t) in enumerate(items, 1):
        lines += [
            f"#### {i}. `[{s}/{c}]` {t.split(' ')[0]}",
            "",
            f"- **页码**：{page} · bbox `{bbox}`",
            "",
            "**原文证据（bbox 切片）**",
            "",
            "```text",
            "【表头】",
            "PARAMETER | MIN | TYP",
            "【目标行】",
            row,
            "```",
            "",
        ]
    return "\n".join(lines)


def _write(root, name: str, text: str):
    p = root / name
    p.write_text(text, encoding="utf-8")
    return p


@pytest.fixture()
def mirrors(tmp_path):
    d = tmp_path / "issues"
    d.mkdir()
    _write(d, "GH-18-ADS1675REF.md", _md(18, "ADS1675REF"))
    _write(d, "GH-23-LM358.md", _md(23, "LM358"))
    _write(d, "GH-19-OLD.md", _md(19, "OLD", state="CLOSED"))
    _write(d, "GH-17-CMD.md", _md(17, "delivery-batch20", sev="auto-trigger"))
    return d


def test_picks_latest_open_p0(mirrors, tmp_path):
    """最新＝编号最大；已关闭的、以及没有 severity:P0 的 [CMD] 单都不算。"""
    res = GH.build_next_task_prompt(issues_dir=mirrors, out_path=tmp_path / "t.md",
                                    verify=False)
    assert res["issue"]["number"] == 23
    assert res["issue"]["mpn"] == "LM358"
    assert res["written"] and res["changed"]


def test_template_matches_the_agreed_shape(mirrors, tmp_path):
    """四段结构、前 5 条 checklist 原文、修复要求四条 —— 一字不能少。"""
    out = tmp_path / "t.md"
    GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)
    text = out.read_text(encoding="utf-8")

    assert "# 待修任务：#23 LM358 · 1 项缺陷" in text
    assert "## 核心 checklist" in text
    assert "## 相关证据" in text
    assert "## 修复要求" in text
    assert "1. 修改 Prompt / table_audit，按 AGENT.md 规则修复" in text
    assert "2. 本地用 LM358 跑 dry-run 验证通过" in text
    assert "3. 提交时 commit message 带 `fixes #23`" in text
    assert "4. 提交后调用 reply_to_issue 回复结果" in text


def test_checklist_is_capped_at_five(tmp_path):
    """一张 12 条的单不能把整个文件撑满 —— 只给前 5 条，其余回工单看。"""
    d = tmp_path / "issues"
    d.mkdir()
    items = [("P0", "多列塌缩", f"参数{i} 只抽一列") for i in range(1, 13)]
    _write(d, "GH-30-BIG.md", _md(30, "BIG", items=items))

    out = tmp_path / "t.md"
    GH.build_next_task_prompt(issues_dir=d, out_path=out, verify=False)
    text = out.read_text(encoding="utf-8")
    assert text.count("- [ ] ") == 5
    assert "参数1 " in text and "参数5 " in text and "参数6 " not in text


def test_evidence_carries_page_bbox_and_source_row(mirrors, tmp_path):
    """证据要能直接定位：页码 + bbox + 原文那一行，缺一个 Trae 就得自己翻 PDF。"""
    out = tmp_path / "t.md"
    GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)
    text = out.read_text(encoding="utf-8")

    assert "p5 · bbox `[58.9, 366.0, 508.9, 374.8]`" in text
    assert "原文：`RθJA 124.7@196 181.4@238`" in text


def test_second_run_does_not_rewrite(mirrors, tmp_path):
    """同一份内容不重写 —— mtime 不变，守护脚本才不会被自己的写入叫醒。"""
    out = tmp_path / "t.md"
    first = GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)
    before = out.stat().st_mtime_ns

    second = GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)
    assert first["sha"] == second["sha"]
    assert second["changed"] is False and second["written"] is False
    assert out.stat().st_mtime_ns == before


def test_content_change_bumps_sha(mirrors, tmp_path):
    """内容变了（比如换了一张单）就必须重写，否则 Trae 会一直修旧任务。"""
    out = tmp_path / "t.md"
    a = GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)
    _write(mirrors, "GH-99-NEWER.md", _md(99, "NEWER"))
    b = GH.build_next_task_prompt(issues_dir=mirrors, out_path=out, verify=False)

    assert a["sha"] != b["sha"]
    assert b["issue"]["number"] == 99 and b["changed"] is True


def test_no_candidate_writes_explicit_empty(tmp_path):
    """没有 P0 时要写「无」，不能留着上一张单 —— 否则会被反复修同一个问题。"""
    d = tmp_path / "issues"
    d.mkdir()
    _write(d, "GH-7-X.md", _md(7, "X", sev="auto-trigger"))
    out = tmp_path / "t.md"
    res = GH.build_next_task_prompt(issues_dir=d, out_path=out, verify=False)

    assert res["issue"] is None
    assert "# 待修任务：无" in out.read_text(encoding="utf-8")
    assert "issue=none" in out.read_text(encoding="utf-8")


def test_closed_on_github_but_open_in_mirror_is_skipped(tmp_path):
    """镜像只在 open 时更新，关单不会回写 —— 必须用线上状态复核，否则会修已关的单。"""
    d = tmp_path / "issues"
    d.mkdir()
    _write(d, "GH-23-LM358.md", _md(23, "LM358"))
    _write(d, "GH-22-YR.md", _md(22, "YR"))

    class FakeSession:
        def get(self, url, params=None, headers=None, timeout=None):
            n = int(url.rsplit("/", 1)[-1])
            state = "closed" if n == 23 else "open"
            return type("R", (), {"status_code": 200, "json": lambda self=None, s=state: {
                "state": s, "labels": [{"name": "severity:P0"}]}})()

    res = GH.build_next_task_prompt(issues_dir=d, out_path=tmp_path / "t.md",
                                    verify=True, repo="o/r", token="t",
                                    session=FakeSession())
    assert res["stale"] == [23]
    assert res["issue"]["number"] == 22


def test_parse_rejects_markdown_without_number(tmp_path):
    """解析不出编号就当没有 —— 挑错一张比少挑一张贵得多。"""
    p = _write(tmp_path, "GH-x.md", "# 随便写点什么\n\n没有表格，也没有编号。")
    assert GH.parse_issue_markdown(p.read_text(encoding="utf-8"), p) is None


def test_next_cli_writes_file(mirrors, tmp_path, capsys):
    """CLI 一条命令就要能出文件，方便 `sync + next` 两步流水线。"""
    out = tmp_path / "t.md"
    code = GH.main(["next", "--issues", str(mirrors), "--out", str(out),
                    "--no-verify", "--json"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["issue"]["number"] == 23 and payload["changed"] is True
    assert out.is_file()
