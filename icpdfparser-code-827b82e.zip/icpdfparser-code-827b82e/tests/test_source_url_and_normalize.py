#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V4 复审三个 P0 的回归用例（溯源链接 / 温度单位 / 核验状态 / 闸门列）。

这三条都是**改代码就能修、不需要重跑模型**的问题，所以判据必须落在代码里，
否则下一次重构又会悄悄退回去：

* 新-1 `datasheet_url` 丢失 —— 查表按整文件名，而本地文件名前半段是**请求号**，
  不同批次会变（`ADC12DJ5200SEEVM` → `ADC12DJ5200SEAAV`），整名比对必然落空。
* 新-2 符号页退化 —— 确定性抽取写不进 `bbox` / `subject_mpn`，符号页 fail-closed
  退化成「待核」占位页（59,789 B → 1,294 B）。
* 新-3 核验覆盖 4/38 —— 34 条模型行没有 `verification`，页面 `†` 消失。

标尺：TI ADC12DJ5200SE Rev. C（`SLVSGH5C`）+ ADS1201U-1/1K。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D                          # noqa: E402
from qc import normalize_doc as ND                                 # noqa: E402
from qc import source_url as SU                                    # noqa: E402

PDF_ADC = ROOT / "data" / "pdfs" / "ADC12DJ5200SEAAV__adc12dj5200se.pdf"
PDF_ADS = ROOT / "data" / "pdfs" / "ADS1201U-1_1K__ads1201.pdf"

needs_adc = pytest.mark.skipif(not PDF_ADC.exists(), reason="缺少 ADC 标尺 PDF")
needs_ads = pytest.mark.skipif(not PDF_ADS.exists(), reason="缺少 ADS1201 标尺 PDF")


# ─────────────────────────────────────────────────────────────────────
# 1. 溯源链：文件名键必须容忍请求号不同
# ─────────────────────────────────────────────────────────────────────
def test_doc_key_ignores_requested_mpn_prefix():
    """`__` 之前是请求订货号，会随批次变；键只能取 `__` 之后的 PDF 本体名。"""
    a = SU.doc_key("ADC12DJ5200SEAAV__adc12dj5200se.pdf")
    b = SU.doc_key("ADC12DJ5200SEEVM__adc12dj5200se.pdf")
    assert a == b == "adc12dj5200se.pdf"


def test_doc_key_falls_back_to_bare_name():
    assert SU.doc_key("ads1201.pdf") == "ads1201.pdf"


def test_resolve_hits_manifest_across_requested_mpns():
    """V4 的真实形态：文件叫 AAV，manifest 记的是 EVM，仍须命中原始出处。"""
    url_map = {"adc12dj5200se.pdf": "https://www.ti.com/lit/ds/symlink/adc12dj5200se.pdf"}
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE"}}
    url, src = SU.resolve(doc, "ADC12DJ5200SEAAV__adc12dj5200se.pdf", url_map)
    assert url == "https://www.ti.com/lit/ds/symlink/adc12dj5200se.pdf"
    assert src == "manifest"


def test_resolve_mpn_rule_requires_ti_doc_number():
    """没有 TI 文档号就不许拼 ti.com 链接 —— 凭料号前缀猜会把别家件指到 TI 上。"""
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE"}}
    url, src = SU.resolve(doc, "whatever.pdf", {}, "no doc number here")
    assert (url, src) == ("", "unknown")

    url, src = SU.resolve(doc, "whatever.pdf", {}, "footer SLVSGH5C page 4")
    assert url == "https://www.ti.com/lit/ds/symlink/adc12dj5200se.pdf"
    assert src == "mpn_rule"


def test_resolve_uses_device_mpn_not_ordering_code():
    """拼 URL 用器件型号：`adc12dj5200seaav.pdf` 是不存在的文件。"""
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE", "requested_mpn": "ADC12DJ5200SEAAV"}}
    url, _ = SU.resolve(doc, "x.pdf", {}, "SLVSGH5C")
    assert "seaav" not in url.lower()


def test_fill_keeps_existing_url_and_tags_source():
    doc = {"basic_info": {"datasheet_url": "https://example.com/a.pdf"}}
    act = SU.fill(doc, "x.pdf", {"x.pdf": "https://example.com/b.pdf"})
    assert act["action"] == "kept"
    assert doc["basic_info"]["datasheet_url"] == "https://example.com/a.pdf"
    assert doc["basic_info"]["datasheet_url_source"] == "prefilled"


# ─────────────────────────────────────────────────────────────────────
# 2. 空链接必须挡住出包（Reviewer 要求写进核心断言）
# ─────────────────────────────────────────────────────────────────────
def _chip_doc(**bi):
    base = {"mpn": "X", "identity": "chip", "datasheet_url": "https://e.com/x.pdf"}
    base.update(bi)
    return {"basic_info": base,
            "specs": {"electrical": [{"name": "Resolution", "value": "12"}],
                      "thermal": [{"name": "RθJA", "value": "23.9"}],
                      "esd": [{"name": "HBM", "value": "±2000"}]},
            "pin_configuration": [{"pin": "A1"}]}


def test_check_core_blocks_empty_datasheet_url():
    errs = D.check_core(_chip_doc(datasheet_url=""))
    assert any("datasheet_url" in e for e in errs)


def test_check_core_accepts_device_datasheet_url_for_boards():
    """板卡件的链接在 `device_datasheet_url`（identity_scope 搬过去的），也算有。"""
    doc = _chip_doc(datasheet_url="", identity="evaluation_board",
                    device_datasheet_url="https://e.com/ug.pdf")
    assert D.check_core(doc) == []


def test_check_core_url_check_runs_before_board_exemption():
    """板卡豁免不能把溯源链一起豁免 —— V4 丢链接的正是两件板卡。"""
    doc = _chip_doc(datasheet_url="", identity="evaluation_board")
    errs = D.check_core(doc)
    assert any("datasheet_url" in e for e in errs)


# ─────────────────────────────────────────────────────────────────────
# 3. 温度单位：必须带 °C（无单位 = 错数据）
# ─────────────────────────────────────────────────────────────────────
@needs_adc
def test_temperature_keeps_celsius_unit():
    import pymupdf
    with pymupdf.open(str(PDF_ADC)) as d:
        got = D.extract_temperature(d)
    assert got["operating"] == "-40°C to 85°C"


@needs_adc
def test_temperature_row_anchor_skips_table_caption():
    """表标题也含这几个词；锚在行首才读得到数字（用 search 会返回空）。"""
    import pymupdf
    with pymupdf.open(str(PDF_ADC)) as d:
        assert D.extract_temperature(d).get("page") == 10


@needs_ads
def test_temperature_handles_en_dash_and_temperature_range_header():
    """ADS1201 的写法是 `TEMPERATURE RANGE / Specified Performance / –40 / +85`。"""
    import pymupdf
    with pymupdf.open(str(PDF_ADS)) as d:
        assert D.extract_temperature(d)["operating"] == "-40°C to +85°C"


@needs_adc
def test_fill_temperature_is_idempotent():
    import pymupdf
    doc = {"specs": {"temperature": {"operating": "-40 to 85"}}}
    with pymupdf.open(str(PDF_ADC)) as d:
        first = D.fill_temperature(doc, d)
        second = D.fill_temperature(doc, d)
    assert first["changed"] is True
    assert second["changed"] is False
    assert doc["specs"]["temperature"]["operating"] == "-40°C to 85°C"


# ─────────────────────────────────────────────────────────────────────
# 4. 核验状态：模型行必须被标记，确定性行不许被反咬
# ─────────────────────────────────────────────────────────────────────
def test_stamp_marks_rows_without_status():
    doc = {"specs": {"electrical": [
        {"name": "Resolution", "value": "12"},
        {"name": "VCMI", "value": "0 to 0.55",
         "verification": {"status": "audited_deterministic"}},
    ], "absolute_max": [{"name": "Junction Temperature", "value": "150"}]}}
    rep = D.stamp_model_unverified(doc)
    assert rep["stamped"] == 2
    statuses = [r["verification"]["status"] for r in doc["specs"]["electrical"]]
    assert statuses == ["model_unverified", "audited_deterministic"]


def test_stamp_is_idempotent():
    doc = {"specs": {"electrical": [{"name": "a", "value": "1"}], "absolute_max": []}}
    assert D.stamp_model_unverified(doc)["stamped"] == 1
    assert D.stamp_model_unverified(doc)["stamped"] == 0


def test_model_unverified_renders_dagger():
    """页面角标：`model_unverified` 含 unverified 字样，走字面兜底也能命中。

    `specs.scope` / `basic_info.identity` 不能省：`canonical_view()` 会把 scope
    判不出来的行整批搬进 `unresolved_specs`，页面就成了空壳（断言失败但原因
    跟核验标记无关）。
    """
    import json_to_txt as J
    doc = {"basic_info": {"mpn": "X", "category": "Data Converter",
                          "subcategory": "ADC", "identity": "chip",
                          "datasheet_url": "https://e.com/x.pdf"},
           "specs": {"scope": "device",
                     "electrical": [{"name": "Resolution", "value": "12", "unit": "Bits",
                                     "verification": {"status": "model_unverified"}}],
                     "absolute_max": []},
           "pin_configuration": []}
    html = J.render(doc, "en")
    assert "pd-verify-note" in html
    assert "†" in html


# ─────────────────────────────────────────────────────────────────────
# 5. BGA 球位不许被确定性抽取覆盖（否则符号页 fail-closed 退化）
# ─────────────────────────────────────────────────────────────────────
@needs_adc
def test_apply_deterministic_leaves_bga_pins_alone():
    """BGA 球位的唯一权威是 pin_repair：它带 bbox / subject_mpn，这里给不出。"""
    import pymupdf
    doc = {"basic_info": {"mpn": "ADC12DJ5200SE"},
           "specs": {"package": {"type": "FCBGA (144)", "pins": 144}},
           "pin_configuration": [{"pin": "A1", "name": "AGND",
                                  "source": {"page": 4, "method": "deterministic"}}]}
    with pymupdf.open(str(PDF_ADC)) as d:
        rep = D.apply_deterministic(doc, d)
    assert rep["pins"]["skipped"] == "bga_owned_by_pin_repair"
    assert doc["pin_configuration"] == [{"pin": "A1", "name": "AGND",
                                         "source": {"page": 4, "method": "deterministic"}}]


# ─────────────────────────────────────────────────────────────────────
# 6. 归一：应力行归位 + 幂等
# ─────────────────────────────────────────────────────────────────────
def test_normalize_demotes_peak_rf_power_to_absmax():
    """P0-3 余项：应力额定值不许留在「推荐工作条件」里。"""
    doc = {"basic_info": {"mpn": "X", "identity": "chip",
                          "datasheet_url": "https://e.com/x.pdf"},
           "specs": {
               "electrical": [{"name": "Peak RF Input Power", "value": "26.25", "unit": "dBm"},
                              {"name": "Resolution", "value": "12", "unit": "Bits"}],
               "absolute_max": [{"name": "Peak RF Input Power (INA, INB)",
                                 "value": "26.25", "unit": "dBm"}]}}
    acts = ND.normalize(doc)
    assert acts["stress_demoted"][0]["action"] == "MOVE_TO_ABSMAX"
    assert [e["name"] for e in doc["specs"]["electrical"]] == ["Resolution"]


def test_normalize_keeps_same_name_different_value_rows():
    """`Supply Voltage (VA19)` 在 ROC 与 AbsMax 同名不同值，两条都必须留。"""
    doc = {"basic_info": {"mpn": "X", "identity": "chip",
                          "datasheet_url": "https://e.com/x.pdf"},
           "specs": {"electrical": [{"name": "Supply Voltage (VA19)",
                                     "value": "1.8 to 2.0", "unit": "V"}],
                     "absolute_max": [{"name": "Supply Voltage (VA19)",
                                       "value": "-0.3 to 2.35", "unit": "V"}]}}
    ND.normalize(doc)
    assert len(doc["specs"]["electrical"]) == 1


def test_normalize_is_idempotent():
    doc = {"basic_info": {"mpn": "X", "identity": "chip",
                          "datasheet_url": "https://e.com/x.pdf"},
           "specs": {"electrical": [{"name": "Peak RF Input Power",
                                     "value": "26.25", "unit": "dBm"}],
                     "absolute_max": [{"name": "Peak RF Input Power (INA, INB)",
                                       "value": "26.25", "unit": "dBm"}]}}
    ND.normalize(doc)
    second = ND.normalize(doc)
    assert not second.get("stress_demoted")
    assert second["verification"]["stamped"] == 0


# ─────────────────────────────────────────────────────────────────────
# 7. manifest 闸门列
# ─────────────────────────────────────────────────────────────────────
def test_gate_blocked_without_source_url():
    import delivery_bundle as B
    gate, why = B._gate({"basic_info": {"datasheet_url": ""}, "specs": {}})
    assert gate == "BLOCKED" and "no_datasheet_url" in why


def test_gate_blocked_when_pins_quarantined():
    import delivery_bundle as B
    doc = {"basic_info": {"datasheet_url": "https://e.com/x.pdf"},
            "specs": {}, "metadata": {"pin_validation": {"status": "unresolved"}}}
    assert B._gate(doc)[0] == "BLOCKED"


def test_gate_unresolved_when_core_validation_failed():
    import delivery_bundle as B
    doc = {"basic_info": {"datasheet_url": "https://e.com/x.pdf"},
            "specs": {}, "metadata": {"core_validation": ["specs.thermal 为空"]}}
    assert B._gate(doc)[0] == "UNRESOLVED"


def test_gate_patched_when_normalize_changed_content():
    import delivery_bundle as B
    doc = {"basic_info": {"datasheet_url": "https://e.com/x.pdf"}, "specs": {},
           "metadata": {"core_validation": "pass",
                        "normalize": {"stress_demoted": [{"action": "MOVE_TO_ABSMAX"}]}}}
    gate, why = B._gate(doc)
    assert gate == "PATCHED" and "stress_demoted" in why


def test_gate_clean_when_nothing_to_report():
    import delivery_bundle as B
    doc = {"basic_info": {"datasheet_url": "https://e.com/x.pdf"}, "specs": {},
           "metadata": {"core_validation": "pass", "normalize": {}}}
    assert B._gate(doc)[0] == "CLEAN"
