# -*- coding: utf-8 -*-
"""1102-V3.3 三条回退的回归测试（100 件灰度暴露的问题）。

① 选页预算必须**默认退回** 16 页 / 50k：
   32 页 / 100k 让 qwen-flash 注意力涣散，`empty_electrical` 大面积出现。
② System prompt 必须把 `specs.electrical` 排在最前（顺序即 token 优先级）。
③ 灰度抽样必须排除评估板（EVM/EVAL/PDK/BOOST/KIT/MODULE…）。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

PD = pytest.importorskip("parse_datasheets")
SG = pytest.importorskip("qc.sample_gray")


# ── ① 预算回退 ──
def test_budget_does_not_widen_by_default(monkeypatch):
    monkeypatch.delenv("ICPDF_ADAPTIVE_BUDGET", raising=False)
    assert PD.adaptive_budget(222) == (PD.MAX_PAGES, PD.MAX_CHARS)
    assert PD.adaptive_budget(5000) == (16, 50_000)


def test_budget_widening_requires_explicit_optin(monkeypatch):
    """复现 V3.2 行为必须是显式开关，不能是默认行为。"""
    monkeypatch.setenv("ICPDF_ADAPTIVE_BUDGET", "1")
    assert PD.adaptive_budget(222) == (32, 100_000)
    # 小文档即使在开关打开时也不放大
    assert PD.adaptive_budget(30) == (PD.MAX_PAGES, PD.MAX_CHARS)


def test_select_pages_keeps_default_budget_for_huge_doc(monkeypatch):
    """入口层也要守住：不能偷偷用 32 页。`pages` 的真实形态是 (页码, 文本) 元组。"""
    monkeypatch.delenv("ICPDF_ADAPTIVE_BUDGET", raising=False)
    pages = [(i, f"page {i} electrical characteristics " + "x" * 3000) for i in range(1, 201)]
    text, used, truncated = PD.select_pages(pages)
    assert used <= 16, used


# ── ② prompt 顺序 ──
def test_prompt_puts_electrical_before_features():
    s = PD.SYSTEM_PROMPT
    i_elec = s.index("specs.electrical")
    i_feat = s.index("features / applications") if "features / applications" in s else s.index("`features`")
    assert i_elec < i_feat, "electrical 必须排在 features 之前（顺序即 token 优先级）"
    assert "输出顺序强制" in s


# ── ③ 抽样排除板卡 ──
@pytest.mark.parametrize("mpn", [
    "ADC122S101EVAL", "ADC081S021EVAL", "BOOSTXL-C2KLED", "ADS8568EVM-PDK",
    "TPS7A02EVM-150", "LM358EVK", "XLR-DEMO", "SOM-MODULE",
])
def test_board_like_is_excluded(mpn):
    assert SG.is_board_like(mpn) is True


@pytest.mark.parametrize("mpn", ["LM358", "ADS1286U", "BQ79614PAPRQ1", "74FCT16244CTPVCTG4"])
def test_chip_like_is_kept(mpn):
    assert SG.is_board_like(mpn) is False


# ── ④ 板卡预路由（只有【板卡型号 且 无芯片级电气表】才跳过）──
def test_board_kit_without_elec_table_is_routed_out():
    assert PD.board_expected_empty("ADC122S101EVAL", "Features ... General Description ...") is True
    assert PD.board_expected_empty("CC3220S-LAUNCHXL", "Board overview, jumpers") is True


def test_eval_with_real_elec_table_is_not_dropped():
    """少数 EVAL 件确实带电气表 —— 不能一刀切跳过。"""
    text = "Electrical Characteristics  VDD = 5 V, TA = 25 C ..."
    assert PD.board_expected_empty("ADC122S101EVAL", text) is False


def test_dev_board_is_never_routed_out():
    """`ADC08D1520DEV_NOPB` 实测 elec=113 —— DEV 不在板卡白名单里。"""
    assert PD.is_board_kit("ADC08D1520DEV_NOPB") is False
    assert PD.board_expected_empty("ADC08D1520DEV_NOPB", "no table here") is False


def test_chip_without_markers_is_not_routed_out():
    """纯芯片件即使正文缺词，也不能走板卡分流（那是芯片抽取缺陷，要修抽取）。"""
    assert PD.board_expected_empty("LM358", "no table here") is False


# ── ⑤ 全局防御性清洗（模型把纯文本塞进对象数组）──
def test_sanitize_drops_string_entries_in_object_arrays():
    doc = {"specs": {"electrical": ["Note 1: TA = 25°C", {"name": "VCC", "value": "5"}],
                     "thermal": ["RθJA = 120", {"name": "RθJA", "value": "120"}],
                     "esd": None},
           "pin_configuration": ["A1 AGND", {"pin": "A1", "name": "AGND"}],
           "features": [{"text": "x"}, "16-bit"],
           "applications": [None, "Industrial"]}
    stats = PD.sanitize_doc(doc)
    assert stats["specs.electrical"] == 1
    assert stats["specs.thermal"] == 1
    assert stats["pin_configuration"] == 1
    assert stats["features"] == 1
    assert stats["applications"] == 1
    assert [e["name"] for e in doc["specs"]["electrical"]] == ["VCC"]
    assert doc["features"] == ["16-bit"] and doc["applications"] == ["Industrial"]
    assert doc["specs"]["esd"] is None, "非数组容器不该被改写"


def test_sanitize_is_noop_on_clean_doc():
    doc = {"specs": {"electrical": [{"name": "VCC"}]}, "features": ["16-bit"],
           "pin_configuration": [{"pin": "A1"}]}
    assert PD.sanitize_doc(doc) == {}
    assert doc["specs"]["electrical"] == [{"name": "VCC"}]


def test_sanitize_survives_specs_as_string():
    """`specs` 本身是 str/bool 时不能崩，且必须归一成 `{}` 并留痕。"""
    doc = {"specs": "oops", "features": ["ok"]}
    stats = PD.sanitize_doc(doc)
    assert stats == {"specs": 1}
    assert doc["specs"] == {}, "specs 必须被归一成对象，否则下游 .get() 仍会崩"

    doc2 = {"specs": True}
    assert PD.sanitize_doc(doc2) == {"specs": 1}
    assert doc2["specs"] == {}


# ── ⑥ 正文层面的板卡证据（型号看不出 EVAL/EVM 时靠它兜底）──
def test_board_detected_from_pdf_text_even_if_name_is_chip_like():
    """`ADC08B200EB`/`2MTR-DYNO`/`ADS1675REF` 后缀看不出板卡，正文才是证据。"""
    text = "This evaluation board is designed ... User's Guide SLAU123"
    assert PD.board_expected_empty("ADC08B200EB", text) is True
    assert PD.board_expected_empty("2MTR-DYNO", text) is True


def test_elec_table_still_wins_over_board_text():
    """有芯片级电气表 → 即使正文提到 evaluation board 也不能分流。"""
    text = "This evaluation board ... Electrical Characteristics VDD = 5 V"
    assert PD.board_expected_empty("ADC08B200EB", text) is False


# ── ⑦ 标量冒充对象（package/temperature/seo/metadata）──
def test_sanitize_normalizes_scalar_objects():
    doc = {"specs": {"package": "48-WQFN", "temperature": None,
                     "electrical": [{"name": "VCC"}]},
           "metadata": "conf 0.9", "seo": ["x"]}
    stats = PD.sanitize_doc(doc)
    assert stats["specs.package"] == 1 and stats["metadata"] == 1 and stats["seo"] == 1
    assert doc["specs"]["package"] == {} and doc["metadata"] == {}
    assert doc["specs"]["temperature"] is None, "None 不强行改写成 {}"


# ── ⑧ 薄件豁免开关（ICPDF_ACCEPT_THIN）──
def test_accept_thin_is_off_by_default(monkeypatch):
    monkeypatch.delenv("ICPDF_ACCEPT_THIN", raising=False)
    assert PD.accept_thin("ADC08B200EB", "This evaluation board ...") is False


def test_accept_thin_allows_board_when_enabled(monkeypatch):
    monkeypatch.setenv("ICPDF_ACCEPT_THIN", "1")
    assert PD.accept_thin("ADC122S101EVAL", "no electrical header here") is True


def test_accept_thin_refuses_chip_datasheet_mentioning_eval_board(monkeypatch):
    """真实 Datasheet 也会出现 'evaluation board'（评估套件章节）——不能因此豁免。

    实测 `ADC08B200EB` 纯芯片手册被正文特征误判成薄件，写盘成 elec=0。
    """
    monkeypatch.setenv("ICPDF_ACCEPT_THIN", "1")
    assert PD.accept_thin("ADC08B200EB", "This evaluation board ...") is False
    assert PD.accept_thin("ADC08B200EB", "ELECTRICAL CHARACTERISTICS ...") is False


def test_accept_thin_still_rejects_pure_chip(monkeypatch):
    """纯芯片件缺表是真缺陷，豁免不能放它过去。"""
    monkeypatch.setenv("ICPDF_ACCEPT_THIN", "1")
    assert PD.accept_thin("LM358", "no table here") is False


# ── ⑨ 文本层乱码闸门（ERR_OCR_REQUIRED，不烧 Token）──
def test_garbled_text_is_detected():
    junk = "".join(chr(0x2500 + (i % 40)) for i in range(2000))   # 制表符/框线噪声
    assert PD.text_is_garbled(junk) is True


def test_clean_datasheet_text_is_not_garbled():
    text = ("ELECTRICAL CHARACTERISTICS  VDD = 5 V, TA = 25 C  "
            "Supply voltage min 4.5 max 5.5 unit V. Input current typ 1 mA. "
            "Output voltage range test condition. ") * 30
    assert PD.text_is_garbled(text) is False


def test_short_text_never_flagged():
    assert PD.text_is_garbled("VCC 5 V") is False


# ── ⑩ 兜底路由的触发证据（只有上下文确有电气表才允许升级模型）──
def test_context_has_elec_table_true():
    assert PD.context_has_elec_table("... ELECTRICAL CHARACTERISTICS table ...") is True
    assert PD.context_has_elec_table("Recommended Operating Conditions") is True


def test_context_has_elec_table_false():
    """没有表头证据就不该升级模型（否则等于拿贵模型赌运气）。"""
    assert PD.context_has_elec_table("Features / Description / Pin Functions") is False
    assert PD.context_has_elec_table("") is False


# ── ⑪ sanitize 覆盖不变量：任何非法类型都必须 fail-closed（不静默吞、不崩）──
NON_DICT = [True, False, "x", [], 42]
BAD_ENTRY = [True, "x", 42, None]


@pytest.mark.parametrize("specs", NON_DICT)
def test_specs_any_non_dict_becomes_object(specs):
    doc = {"specs": specs, "features": ["ok"]}
    stats = PD.sanitize_doc(doc)
    assert isinstance(doc["specs"], dict), f"specs={specs!r} 未被归一"
    assert stats.get("specs") == 1


@pytest.mark.parametrize("elec", [True, False, "x", 42, {"a": 1}])
def test_electrical_container_non_list_becomes_empty_list(elec):
    """2026-11-02 决定变更：旧契约是「容器不是数组时不清洗、交给 validate」，
    但 `for e in "garbage"` 会迭代字符，随后 `e.get(...)` 抛 `'str'.get`。
    实测 20 件压测 4 件正是这么死的 —— 现在一律归一成 `[]`（`None` 保持 `None`）。"""
    doc = {"specs": {"electrical": elec}}
    stats = PD.sanitize_doc(doc)
    assert doc["specs"]["electrical"] == [], f"{elec!r} 未被归一"
    assert stats.get("specs.electrical") == 1


@pytest.mark.parametrize("bad", BAD_ENTRY)
def test_electrical_bad_elements_are_dropped(bad):
    doc = {"specs": {"electrical": [bad, {"name": "VCC", "value": "5"}]}}
    stats = PD.sanitize_doc(doc)
    assert stats.get("specs.electrical") == 1
    assert [e for e in doc["specs"]["electrical"] if isinstance(e, dict)] == \
        [{"name": "VCC", "value": "5"}]
