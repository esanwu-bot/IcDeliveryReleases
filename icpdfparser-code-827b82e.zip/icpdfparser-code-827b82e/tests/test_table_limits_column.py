# -*- coding: utf-8 -*-
"""ADC08B200EB 结构修复：TI 老式 `Limits` 合并列 + 脚注段落冒充表头（2026-11-02）。

**取证**（真实 PDF `data/pdfs/ADC08B200EB__adc08b200.pdf`，`page.find_tables()` 默认策略）：

    p8 t0 rows=32 cols=6
      names（PyMuPDF 认定的表头）= ['50% duty cycle, OEDGE/TEN = 1, Buf 25°C (1)(2)', '',
                                    'ffer and PLL bypassed. Boldface limits apply for TJ = T',
                                    'TMIN to TM', 'MAX: all oth', 'her limits TJ =']
      extract()[0]（真表头）      = ['Parameter', '', 'TestConditions', 'Typ(3)', 'Limits (3)', 'Units (Limits)']
      extract()[1]                = ['HD3', '3rdHarmonicDistortion', 'f IN = 10 MHz , V IN = FS −0 .25 dB', '−62', '', 'dBc']

**结论：这张表有完整竖线，也不是合并单元格把列头搞乱** —— 两个独立的结构性缺陷：

1. `header_roles()` 只认 `MIN/TYP/MAX` 字面：`Limits (3)` 一个角色都数不到，
   真表头只数到 1 个角色（`Typ(3)`），`pick_header` 的 `>= 2` 不成立 → 表头没认出来。
2. 表头上方那段脚注被 `t.header.names` 当成了列名；`picked` 为空时
   `choose_header` 维持 `names` 优先 → 脚注段落当了表头，真表头行留在数据里，
   **所有列下标错位一格**。p9 更糟：窗口里第一行数据
   `['f C1','MaximumInputClockRate','PLLDisabled','210','200','MHz(min)']`
   因为 `maximum` 命中（正则没有词边界）+ `MHz(min)` 命中 MIN，被升级成表头，
   真正的表头 row0 反而被当成数据。

修复后要求：
* `Limits (3)` 是**伪角色** `LIMITS`（不写 MIN/MAX，先认出来）；
* `Units (Limits)` 仍然是 UNIT（不能被 `limits` 抢走）；
* 表头必须落在真表头行，脚注段落 / 数据行都不许冒充；
* `Limits` 列的值按**单位格里的 `(min)` / `(max)`** 确定性拆成 MIN/MAX，
  判不出侧别就 `cell_unparsable_unresolved (LIMITS_COLUMN)`，**绝不猜**。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

#: p8/p9 的真实表头（`find_tables().extract()[0]`）
LIMITS_HDR = ["Parameter", "", "TestConditions", "Typ(3)", "Limits (3)", "Units (Limits)"]

#: p8 表头上方那段脚注被切成的 6 片（`t.header.names` 原样）
NOTE_FRAGS_P8 = [
    "50% duty cycle, OEDGE/TEN = 1, Buf 25°C (1)(2)",
    "",
    "ffer and PLL bypassed. Boldface limits apply for TJ = T",
    "TMIN to TM",
    "MAX: all oth",
    "her limits TJ =",
]

#: p8 t0 前两行数据（原文，含小数点被文本层丢掉的形态）
HD3_ROW = ["HD3", "3rdHarmonicDistortion",
           "f IN = 10 MHz , V IN = FS −0 .25 dB", "−62", "", "dBc"]
IA_ROW = ["I A", "AnalogSupplyCurrent", "f IN = 50 MHz", "76.8", "88.3", "mA(max)"]
INL_ROW = ["INL", "Integral Non-Linearity", "", "±0.55", "±1.3", "LSB(max)"]
IN_VOLT_ROW = ["V IN", "InputVoltage", "", "1.6", "V RB", "V(min)"]

#: p9 第一行数据（含 `MaximumInputClockRate` + `MHz(min)` 两个"假表头证据"）
FC1_ROW = ["f C1", "MaximumInputClockRate", "PLLDisabled", "210", "200", "MHz(min)"]


class TestLimitsRole:
    def test_limits_header_is_a_role(self):
        """红先：`Limits (3)` 现在是 0 个角色 → 真表头数不到 2 个。"""
        assert TA.header_roles("Limits (3)") == ["LIMITS"], "Limits 列没被认出来"
        assert TA.header_roles("Typ(3)") == ["TYP"]

    def test_units_limits_is_still_unit(self):
        """`Units (Limits)` 的 `limits` 在括号里，不许抢 UNIT 的角色。"""
        assert TA.header_roles("Units (Limits)") == [], "单位列被当成数值列"
        rm = TA.role_map(["Units (Limits)"])
        assert rm == {0: "UNIT"}, rm

    def test_role_map_of_the_real_header(self):
        rm = TA.role_map(LIMITS_HDR)
        assert rm == {2: "COND", 3: "TYP", 4: "LIMITS", 5: "UNIT"}, rm

    def test_role_words_inside_longer_words_are_not_roles(self):
        """`MaximumInputClockRate` 不是 MAX 列 —— 正则必须带词边界。"""
        assert TA.header_roles("MaximumInputClockRate") == []
        assert TA.header_roles("MinimumInputClockRate") == []
        assert TA.header_roles("Maximum") == ["MAX"]
        assert TA.header_roles("Minimum") == ["MIN"]

    def test_limits_column_is_not_treated_as_two_numeric_roles(self):
        """`Limits` 只有一个角色，不能被算成融合列（融合列会整表弃权）。"""
        assert TA.fused_cols(LIMITS_HDR) == set()
        assert TA.grouped_num_roles(LIMITS_HDR) == set()


class TestPickHeaderWithLimits:
    def test_real_ti_header_is_picked(self):
        """红先：`Typ` + `Limits` 必须算 2 个角色，才能过 `>= 2` 的门槛。"""
        rows = [list(LIMITS_HDR), list(HD3_ROW), list(IA_ROW)]
        header, data = TA.pick_header(rows)
        assert header == LIMITS_HDR, f"真表头没认出来：{header}"
        assert data == [HD3_ROW, IA_ROW]

    def test_data_row_with_role_words_is_not_promoted(self):
        """p9 事故：数据行里的 `MaximumInputClockRate` / `MHz(min)` 不是表头证据。

        窗口里只有数据行、没有真表头时，宁可"没表头"也不许把数据行升级成表头。
        """
        rows = [list(FC1_ROW), ["tCL", "MinimumCLKLowTime", "(4)", "", "1.7", "ns(min)"]]
        assert TA.pick_header(rows) == ([], rows)

    def test_note_fragments_lose_to_the_real_header(self):
        """红先：`names` 是脚注段落、真表头在 row0 时，必须让位。"""
        rows = [list(LIMITS_HDR), list(HD3_ROW)]
        header, data, from_names, _meta = TA.choose_header(list(NOTE_FRAGS_P8), rows)
        assert from_names is False, "脚注段落又当了表头"
        assert header == LIMITS_HDR
        assert data == [HD3_ROW], "真表头行还留在数据里"

    def test_note_fragments_are_not_header_like(self):
        assert TA.header_like(NOTE_FRAGS_P8) is False


class TestLimitsColumnSplit:
    """`Limits` 合并列 → MIN/MAX 的确定性拆分。判不出侧别一律 unresolved。"""

    def test_single_value_with_max_marker(self):
        got, flag = TA.limits_column_split("±1.3", "LSB(max)")
        assert got == {"MIN": None, "MAX": 1.3}, got
        assert flag == "side:max"

    def test_single_value_with_min_marker(self):
        got, flag = TA.limits_column_split("1.7", "ns(min)")
        assert got == {"MIN": 1.7, "MAX": None}, got
        assert flag == "side:min"

    def test_two_values_with_both_markers(self):
        got, flag = TA.limits_column_split("0.3 0.55", "mV(min) mV(max)")
        assert got == {"MIN": 0.3, "MAX": 0.55}, got
        assert flag == "two_sided"

    def test_blank_cell_is_not_dirty(self):
        got, flag = TA.limits_column_split("", "dBc")
        assert got == {"MIN": None, "MAX": None}
        assert flag == "blank"
        assert TA.limits_column_split("-", "dBc")[1] == "blank"

    def test_two_values_without_side_markers_are_unresolved(self):
        """两个数却不知道哪个是 MIN —— 顺序不能猜。"""
        got, flag = TA.limits_column_split("0.3 0.55", "V")
        assert got == {"MIN": None, "MAX": None}
        assert flag.startswith("unresolved:")

    def test_single_value_without_side_marker_is_unresolved(self):
        got, flag = TA.limits_column_split("±3", "%")
        assert got == {"MIN": None, "MAX": None}
        assert flag.startswith("unresolved:")

    def test_formula_cell_is_unresolved(self):
        """`V RB` 这种引用式限值不是数 —— 不许当 0 写下去。"""
        got, flag = TA.limits_column_split("V RB", "V(min)")
        assert got == {"MIN": None, "MAX": None}
        assert flag.startswith("unresolved:")

    def test_footnote_marker_is_not_a_value(self):
        """`(3)` 这种脚注号不能被当成数值。"""
        got, flag = TA.limits_column_split("2.4 (3)", "V(max)")
        assert got == {"MIN": None, "MAX": 2.4}, got
        assert flag == "side:max"


class TestLimitsInDiagnostics:
    """LIMITS 不能只活在写盘层：诊断/裁决层必须与写盘同源（否则又是双口径）。

    旧实现里 `_num_cells` 只认 MIN/TYP/MAX → 表里只有 `Typ + Limits` 时，
    Limits 格**完全不参与** value 支撑判定；而若把整格交给 `to_num`，
    `'−8.0 0'` 会取成 8.0（左半值）—— 极性错、值也错。
    """

    def _rm(self):
        return TA.role_map(LIMITS_HDR)

    def test_limits_cell_counts_as_value_evidence(self):
        """红先：`88.3` 只出现在 Limits 格，旧实现判「这行不支持」。"""
        rm = self._rm()
        assert TA.value_supported(list(IA_ROW), rm, "88.3") is True, "Limits 格没进数值证据"

    def test_num_values_splits_two_sided_limits(self):
        """红先：`−8.0 0` 必须拆成 −8.0 与 0，不许取左半/正数。"""
        rm = self._rm()
        row = ["FSE", "FullScaleError", "", "−3.9", "−8.0 0", "mV(min) mV(max)"]
        vals = TA.num_values(row, rm)
        assert -8.0 in vals and 0.0 in vals, vals
        assert 8.0 not in vals, vals

    def test_num_values_ignores_blank_limits(self):
        rm = self._rm()
        vals = TA.num_values(list(HD3_ROW), rm)
        assert vals == [62.0] or vals == [-62.0], vals

    def test_no_numeric_role_still_falls_back_to_row(self):
        """守旧行为：表头一个数值角色都没有时，仍按整行取数（不许退化成"永不支持"）。"""
        row = ["Bandwidth", "500 MHz"]
        assert TA.value_supported(row, {}, "500") is True


class TestAuditWritesLimitsColumns:
    """端到端：`Limits` 列拆出来后，写盘要落到 columns 上，脏格要留痕。"""

    @pytest.fixture(autouse=True)
    def _clean_page(self):
        TA._PAGE.set(None)
        yield
        TA._PAGE.set(None)

    def _tbl(self, *rows):
        return {"page": 8, "ti": 0, "title": "POWER SUPPLY CHARACTERISTICS",
                "header": list(LIMITS_HDR), "rows": [list(r) for r in rows],
                "hx": [], "xr": [], "split": False, "words_fixed": True}

    def test_typ_and_max_from_limits_column(self):
        """`76.8 TYP` + `88.3 (max)` → columns 写出 TYP 与 MAX（旧实现只认 TYP）。"""
        e = {"name": "AnalogSupplyCurrent", "value": "88.3", "unit": "mA",
             "condition": "f IN = 50 MHz"}
        finds = TA.audit_electrical([e], [self._tbl(IA_ROW)], "specs.electrical")
        assert e.get("columns") == {"TYP": 76.8, "MAX": 88.3}, e.get("columns")
        assert e["columns_raw"]["MAX"] == "88.3", e["columns_raw"]
        assert e.get("limits_column", {}).get("split") == "side:max"
        assert any(f["kind"] == "qualifier_loss" for f in finds), finds

    def test_blank_limits_cell_stays_typ_only(self):
        """HD3 行：`Limits` 格是空的 → 只写 TYP，不产生伪 MIN/MAX。"""
        e = {"name": "3rdHarmonicDistortion", "value": "-62", "unit": "dBc",
             "condition": "f IN = 10 MHz"}
        finds = TA.audit_electrical([e], [self._tbl(HD3_ROW)], "specs.electrical")
        assert "columns" not in e, e.get("columns")
        assert not any(f["kind"] == "cell_unparsable_unresolved" for f in finds), finds

    def test_two_numbers_two_sides_write_both(self):
        e = {"name": "Integral Non-Linearity", "value": "0.55", "unit": "LSB",
             "condition": ""}
        finds = TA.audit_electrical([e], [self._tbl(INL_ROW)], "specs.electrical")
        # 单边限值（LSB(max)）→ 只写 MAX，不凭空造 MIN
        assert e.get("columns") == {"TYP": 0.55, "MAX": 1.3}, e.get("columns")
        assert any(f["kind"] == "qualifier_loss" for f in finds), finds

    def test_unreadable_limits_cell_is_reported_not_written(self):
        """`V RB` 引用式限值 → `LIMITS_COLUMN` 留痕，整条不写（A12 纪律）。"""
        e = {"name": "InputVoltage", "value": "1.6", "unit": "V", "condition": ""}
        finds = TA.audit_electrical([e], [self._tbl(IN_VOLT_ROW)], "specs.electrical")
        assert "columns" not in e, e.get("columns")
        kinds = [(f["kind"], f.get("table")) for f in finds]
        assert ("cell_unparsable_unresolved", "LIMITS_COLUMN") in kinds, kinds
