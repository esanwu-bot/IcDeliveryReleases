#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""确定性抽取的用例（真实 PDF 断言，不是 mock）。

**为什么这些用例必须跑真 PDF**：本模块存在的理由就是「模型同输入两次运行结果
不同」（pins 64 vs 144、ESD `+2000` vs `±2000`、VCMI 全缺 vs 三条齐全）。
用 mock 测等于把要防的不确定性重新引进来 —— 这里断言的是**从原件抽出来的
确定值**，跑一百次都必须一样。

标尺：TI ADC12DJ5200SE Rev. C（`SLVSGH5C`），FCBGA-144。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D                          # noqa: E402

PDF = ROOT / "data" / "pdfs" / "ADC12DJ5200SEAAV__adc12dj5200se.pdf"

pytestmark = pytest.mark.skipif(not PDF.exists(), reason="缺少标尺 PDF")


@pytest.fixture(scope="module")
def doc():
    import pymupdf
    d = pymupdf.open(str(PDF))
    yield d
    d.close()


# ---------------------------------------------------------------- 引脚
def test_pins_are_expanded_to_all_144_balls(doc):
    """成组行必须展开：69 行里 10 行是成组的（`AGND` 一行覆盖 39 个球位）。"""
    pins = D.extract_pins(doc)
    assert len(pins) == 144
    assert len({p["pin"] for p in pins}) == 144, "球位号必须唯一"


def test_pin_field_is_ball_number_not_sequence(doc):
    """`pin` 必须是球位号（A1/G11/M12），不是 1..144 的序号。

    v4 实测是 64 条纯序号 —— 序号看起来像脚号，却让球位网格整张失效。
    """
    pins = D.extract_pins(doc)
    assert all(D.BALL_RE.fullmatch(p["pin"]) for p in pins)
    assert {p["pin"] for p in pins} >= {"A1", "M12", "G11"}


def test_pin_description_keeps_word_spacing(doc):
    """描述必须带空格：`find_tables` 会吃成 `Analogsupplyground`。"""
    pins = D.extract_pins(doc)
    agnd = next(p for p in pins if p["name"] == "AGND")
    assert agnd["description"].startswith("Analog supply ground.")
    assert "Tie AGND and DGND" in agnd["description"]


def test_pin_description_has_no_page_footer(doc):
    pins = D.extract_pins(doc)
    assert not any("SLVSGH5C" in p["description"] for p in pins)
    assert not any("Submit Document Feedback" in p["description"] for p in pins)


# ---------------------------------------------------------------- 热阻 / ESD
def test_thermal_matches_datasheet(doc):
    """RθJA 23.9 / RθJC(top) 0.8 / RθJB 8.4 / ψJT 0.23 / ψJB 8.4。

    `find_tables` 在这里会把小数位融合（`023.` 分不清是 0.23 还是 02.3），
    所以必须走文本层 —— 这条用例守的就是这个选择。
    """
    th = {x["name"]: x["value"] for x in D.extract_thermal(doc)}
    assert th == {"RθJA": "23.9", "RθJC(top)": "0.8", "RθJB": "8.4",
                  "ψJT": "0.23", "ψJB": "8.4"}


def test_esd_keeps_plus_minus_sign(doc):
    """HBM `±2000` / CDM `±500` —— 丢符号会把双向耐压读成单向上限。"""
    esd = {x["name"]: x["value"] for x in D.extract_esd(doc)}
    assert esd == {"HBM": "±2000", "CDM": "±500"}


# ---------------------------------------------------------------- VCMI / VID
def test_vcmi_lower_bound_is_zero(doc):
    """Reviewer P0-1：VCMI 下限必须是 0，不是 0.3。"""
    rows = [x for x in D.extract_input_limits(doc) if "Common-Mode" in x["name"]]
    assert len(rows) == 3, "CLK± / SYSREF± / TMSTP± 三组各一条"
    assert all(x["value"] == "0 to 0.55" for x in rows)
    assert all(x["min"] == "0" and x["max"] == "0.55" for x in rows)


def test_vid_is_0_4_to_2_0(doc):
    rows = [x for x in D.extract_input_limits(doc) if "Differential" in x["name"]]
    assert rows and rows[0]["value"] == "0.4 to 2.0"
    assert rows[0]["unit"] == "VPP-DIFF"


@pytest.mark.slow
def test_deterministic_is_stable_across_calls(doc):
    """同一份 PDF 连续抽两次，结果必须逐字节一致 —— 这是本模块存在的全部理由。"""
    a = D.apply_deterministic({"specs": {"electrical": []}}, doc)
    b = D.apply_deterministic({"specs": {"electrical": []}}, doc)
    assert a == b


# ---------------------------------------------------------------- 校验器
def test_check_core_passes_on_deterministic_output(doc):
    # `datasheet_url` 是 V4 复审后新增的通用断言（溯源链不能断）。夹具得给上，
    # 否则这里测的就不是"确定性输出是否完整"，而是"夹具缺字段"。
    d = {"basic_info": {"datasheet_url": "https://www.ti.com/lit/ds/symlink/adc12dj5200se.pdf"},
         "specs": {"electrical": []}}
    D.apply_deterministic(d, doc)
    assert D.check_core(d) == []


def test_check_core_catches_bad_vcmi(doc):
    """型号级验收点搬到 `check_acceptance` 后，判据不变、位置变。

    之所以要分开：把 ADC12DJ5200SE 的 `0 to 0.55` / `0.4 to 2.0` 写进通用校验，
    会让别的型号全被误判 —— `ADS1201U-1/1K` 根本没有 VCMI/VID 行，
    `ADS8568EVM-PDK` 的 VCMI 是 `-4 VREF to 4 VREF` 且属评估板。
    """
    d = {"specs": {"electrical": [
        {"name": "Input common-mode voltage", "value": "0.3 to 0.55", "unit": "V"}]},
         "pin_configuration": [{"pin": "A1"}], }
    d["specs"]["thermal"] = [{"name": "RθJA", "value": "23.9"}]
    d["specs"]["esd"] = [{"name": "HBM", "value": "±2000"}]
    errs = D.check_acceptance(d, "ADC12DJ5200SE")
    assert any("VCMI" in e for e in errs)
    assert any("VID" in e for e in errs)


def test_check_acceptance_unknown_mpn_is_silent():
    """没登记验收点的型号返回空 —— 不套用别人的指标。"""
    assert D.check_acceptance({"specs": {}}, "LM358") == []


def test_check_core_skips_board_pages():
    """评估板页没有本型号引脚表与芯片级参数，不该被判失败。

    但**溯源链不豁免**：板卡件正是 V4 丢链接的那两件，所以这里给了
    `device_datasheet_url`（板卡件的链接被 identity_scope 搬过去的那一格）。

    **AC 列角色闸门同样不豁免**（V9 实测）：板卡的 AC 表就是板载器件的芯片级
    参数，`ADS8568EVM-PDK` 的 `min="73.9"/typ=""/max="dB"` 正是靠「板卡在
    check_core 里提前 return」绕过闸门、直接流进页面的。所以这里必须给板卡喂
    脏 AC 数据，断言引脚校验仍豁免、而 AC 校验**照样执行并报错**。
    """
    d = {"basic_info": {"identity": "evaluation_board",
                        "device_datasheet_url": "https://www.ti.com/lit/ug/slvu967a/slvu967a.pdf"},
         "specs": {"scope": "onboard_device",
                   "ac_performance": [
                       {"symbol": "SNR", "conditions": "At fIN = 10 kHz; 73",
                        "min": "73.9", "typ": "", "max": "dB", "unit": "",
                        "value_shape": "LH", "row_sha256": "deadbeef"}]},
         "pin_configuration": []}
    errs = D.check_core(d)
    # 引脚表豁免：板卡本就没有本型号引脚表
    assert not any("pin_configuration" in e for e in errs), errs
    # 溯源链有 device_datasheet_url，不该报断链
    assert not any("datasheet_url 为空" in e for e in errs), errs
    # AC 闸门必须执行：单位串占了 MAX 格
    assert any("MAX" in e and "dB" in e for e in errs), errs


def test_apply_replaces_sequence_pins_with_balls(doc):
    """模型交出的 1..64 序号必须被确定性结果整体替换成 144 个球位。

    这是 v4 的真实形态（64 条纯序号）。校验器**不能**简单拒绝纯数字脚号 ——
    SOIC/QFN 本来就是 1..N。真正的判据是「PDF 里是球位表时，结果必须也是球位」，
    而那要看过 PDF 才知道，所以由 apply_deterministic 直接覆盖，不靠校验器猜。
    """
    d = {"specs": {"electrical": []},
         "pin_configuration": [{"pin": str(i)} for i in range(1, 65)]}
    D.apply_deterministic(d, doc)
    pins = [p["pin"] for p in d["pin_configuration"]]
    assert len(pins) == 144
    assert all(D.BALL_RE.fullmatch(p) for p in pins)


# ---------------------------------------------------------------- AC 列角色闸门
def test_ac_rows_have_no_duplicate_fingerprint(doc):
    """元宝 7.5 分复审 P0：82 行里 18 条逐字节重复。

    重复的根因是「按文本 y 聚类切行」把一条逻辑行拆成 3~4 条，叠上单值纵向
    传播就变成完全相同的记录。现在行锚点是 y 边界并集，一条原始行只出一条。
    """
    rows = D.extract_ac_performance(doc)
    assert rows, "AC 表没抽到任何行"
    fps = [r["row_sha256"] for r in rows]
    assert len(fps) == len(set(fps)), f"有 {len(fps) - len(set(fps))} 条重复原始行"
    assert D.check_ac_integrity(rows) == []


def test_ac_single_value_rows_never_fill_min_and_max(doc):
    """48/82 行 `min == typ == max` 是把 TYP 横向复制进 MIN/MAX。

    TI 的 AC 表绝大多数行只印 TYP 一格；三列同值只能是伪造。
    这里断言：抽出来的每一行都带 `value_shape`，且没有任何一行三列同值。
    """
    rows = D.extract_ac_performance(doc)
    assert all(r.get("value_shape") for r in rows), "缺 value_shape，闸门没有判据"
    same = [r for r in rows if r["min"] and r["min"] == r["typ"] == r["max"]]
    assert not same, f"仍有 {len(same)} 行 MIN=TYP=MAX"


def test_ac_integrity_gate_rejects_old_1102_shape():
    """旧数据（无 value_shape、MIN=MAX）必须被闸门拦下，不能静默放行。"""
    old = [{"symbol": "SFDR", "conditions": "fIN = 2397 MHz; AIN = –3 dBFS",
            "min": "67", "typ": "67", "max": "67", "unit": "dBFS"}]
    errs = D.check_ac_integrity(old)
    assert any("MIN=TYP=MAX" in e for e in errs), errs


def test_ac_integrity_gate_rejects_shape_mismatch():
    """`value_shape` 与实填不符 = 有人事后改过列，闸门必须报。"""
    row = {"symbol": "SNR", "conditions": "x", "min": "50", "typ": "53.5",
           "max": "60", "unit": "dBFS", "value_shape": "T", "row_sha256": "a"}
    assert any("value_shape" in e for e in D.check_ac_integrity([row]))


def test_ac_integrity_rejects_unit_string_in_value_cell():
    """V9 的 `max="dB"`：单位串占了 MAX 格，`value_shape="LH"` 与实填自洽。

    只比对 `value_shape` 判不出来（shape="LH"、filled="LH" 完全相等），
    三列又互不相等等价于「没横向复制」—— 必须再验一次「填的是不是数」。
    """
    rows = [{"symbol": "SNR", "conditions": "At fIN = 10 kHz; 73",
             "min": "73.9", "typ": "", "max": "dB", "unit": "",
             "value_shape": "LH", "row_sha256": "a"}]
    errs = D.check_ac_integrity(rows)
    assert any("MAX" in e and "dB" in e for e in errs), errs


def test_ac_num_cell_accepts_numeric_and_rejects_unit():
    """数值格口径：空 / 纯数字（含 ±、−、小数、科学计数）合法，单位串不合法。

    ESD 的 `±2000` 必须算合法数值形态 —— 它是双向耐压，丢掉 ± 就成了单向上限。
    """
    for good in ("", "73.9", "-0.3", "+2000", "±2000", "−2000", "1.5e3"):
        assert D._ac_num_cell(good), good
    for bad in ("dB", "See Note 2", "°C/W", "typ"):
        assert not D._ac_num_cell(bad), bad


# ---------------------------------------------------------------- amax 列角色
def test_absolute_max_roles_are_column_verified(doc):
    """15 条 amax 的 MIN/MAX 必须由表头判定的列角色给出，不是从字符串切的。

    夹具从 PDF 自己长出来（`extract_spec_rows` 的 param/cond 当 JSON 名），
    这样测的是**匹配逻辑**本身，不依赖任何一次归一化的落盘产物。
    """
    rows = D.extract_spec_rows(doc[8])
    assert len(rows) == 15, f"p9 抽出 {len(rows)} 行，标尺是 15"
    items = []
    for r in rows:
        lo, hi = r["min"], r["max"]
        items.append({
            "name": r["cond"] or r["param"],
            "unit": r["unit"],
            "value": f"{lo} to {hi}" if (lo and hi) else (lo or hi),
            "range": {"min": lo, "max": hi},
            "range_origin": "derived_from_value",
            "verification": {"status": "unresolved",
                             "reason": "column_roles_not_verified"},
        })
    d = {"specs": {"absolute_max": items}}
    res = D.fill_absolute_max(d, doc)
    assert res["checked"] == 15
    assert res["unmatched"] == [], f"还有没匹配上的行：{res['unmatched']}"
    for item in d["specs"]["absolute_max"]:
        assert item["range_origin"] == "column_roles_verified"
        assert item["verification"]["status"] == "audited_deterministic"
        assert "bbox" in item["source"] and "row_sha256" in item["source"]


def test_absolute_max_single_value_never_fills_min(doc):
    """单值行（Tj=150 / PMAX=26.25）只能是上限，MIN 必须留空。"""
    rows = D.extract_spec_rows(doc[8])
    single = [r for r in rows if not r["min"] and r["max"]]
    assert single, "标尺页应当有单值行"
    for r in single:
        assert r["min"] == "", f"{r['param']} 的单值被同时填进了 MIN"
    # 从字符串拆的时候也一样：`26.25` 不是 `0 to 26.25`
    assert D._split_value_range("26.25") == ("", "26.25")
    assert D._split_value_range("-0.3 to 2.35") == ("-0.3", "2.35")
