"""引脚表抽取的纯逻辑单测（不需要 PDF、不依赖 pymupdf）。

重点测 DS80PCI402EVK/NOPB 事故的两条：
  * 一格多脚：NAME=`OUTB_0+, OUTB_0-, …` + NUMBER=`1, 2, …` 必须**按下标 zip**，
    绝不能「先排全部 +、再排全部 -」；
  * 数量对不上就不猜（跳过该行），只有一个名字挂多脚（VDD）才广播。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import pdf_pin_table as PT       # noqa: E402


def mat(*rows):
    return [list(r) for r in rows]


HEADER = ["PIN", "", "I/O, TYPE", "DESCRIPTION"]
SUBHDR = ["NAME", "NUMBER", "I/O, TYPE", "DESCRIPTION"]


class PairingTest(unittest.TestCase):
    def test_comma_parallel_lists_zip_in_order(self):
        """TI 版式：名字与脚号同格并列，顺序一一对应。"""
        m = mat(HEADER, SUBHDR,
                ["OUTB_0+, OUTB_0-, OUTB_1+, OUTB_1-", "1, 2, 3, 4", "O", "bank B"],
                ["INA_0+, INA_0-", "10, 11", "I", "bank A in"],
                ["EQA1, EQA0", "19, 20", "I", "equalization"],
                ["RATE, RXDET", "21, 22", "I", "control"],
                ["VDD", "9, 14, 36", "P", "supply"])
        rows = PT._rows_from_table(m)
        head = [(r["pin"], r["name"]) for r in rows][:4]
        self.assertEqual(head, [(1, "OUTB_0+"), (2, "OUTB_0-"),
                                (3, "OUTB_1+"), (4, "OUTB_1-")])

    def test_never_groups_by_polarity(self):
        """绝对不能产出「先全部 + 再全部 -」（审核打回的那个 P0）。"""
        m = mat(HEADER, SUBHDR,
                ["OUTA_3-, OUTA_3+, OUTA_2-, OUTA_2+", "28, 29, 30, 31", "O", "x"],
                ["OUTA_1-, OUTA_1+, OUTA_0-, OUTA_0+", "32, 33, 34, 35", "O", "x"],
                ["INB_3-, INB_3+, INB_2-, INB_2+", "37, 38, 39, 40", "I", "x"],
                ["INB_1-, INB_1+, INB_0-, INB_0+", "42, 43, 44, 45", "I", "x"])
        rows = PT._rows_from_table(m)
        names = [r["name"] for r in rows]
        self.assertEqual(names[:4], ["OUTA_3-", "OUTA_3+", "OUTA_2-", "OUTA_2+"])
        self.assertEqual(PT.assert_interleaved(rows), [])

    def test_length_mismatch_is_skipped_not_guessed(self):
        m = mat(HEADER, SUBHDR,
                ["A_0+, A_0-", "1, 2, 3", "I", "x"],
                ["B_0+, B_0-", "4, 5", "I", "x"],
                ["C_0+, C_0-", "6, 7", "I", "x"],
                ["D_0+, D_0-", "8, 9", "I", "x"])
        rows = PT._rows_from_table(m)
        names = [r["name"] for r in rows]
        self.assertNotIn("A_0+", names)          # 数量对不上，跳过
        self.assertIn("B_0+", names)

    def test_single_name_many_pins_broadcast(self):
        """VDD 挂在多个脚上：名字只有 1 个、脚号多个 → 广播。"""
        m = mat(HEADER, SUBHDR,
                ["VDD", "9, 14, 36", "P", "supply"],
                ["GND", "12, 13", "P", "ground"],
                ["ENSMB", "48", "I", "control"],
                ["SDA", "49", "I/O", "smbus"])
        rows = PT._rows_from_table(m)
        got = {r["pin"]: r["name"] for r in rows}
        self.assertEqual(got[9], "VDD")
        self.assertEqual(got[14], "VDD")
        self.assertEqual(got[36], "VDD")
        self.assertEqual(got[12], "GND")

    def test_range_name_is_not_broadcast(self):
        """`AD0-AD3` + `54, 53, 47, 46`：代表 4 个不同名字，脚号还是倒序的，
        展开必然靠猜。实测（DS80PCI402EVK）会把 46/54 全写成 AD0-AD3，
        盖掉 PIN MODE 段真正的 EQB0/DEMB1 —— 必须跳过该行。"""
        m = mat(HEADER, SUBHDR,
                ["AD0-AD3", "54, 53, 47, 46", "I, 4-LEVEL", "SMBus address"],
                ["EQB0, EQB1", "46, 47", "I, 4-LEVEL", "eq bank B"],
                ["DEMB0, DEMB1", "53, 54", "I, 4-LEVEL", "de-emphasis bank B"],
                ["ENSMB", "48", "I", "ctrl"])
        got = {r["pin"]: r["name"] for r in PT._rows_from_table(m)}
        self.assertEqual(got[46], "EQB0")
        self.assertEqual(got[47], "EQB1")
        self.assertEqual(got[53], "DEMB0")
        self.assertEqual(got[54], "DEMB1")

    def test_electrical_table_rejected(self):
        """MIN/MAX/UNIT 表也有数字列，但不能被当引脚表。"""
        m = mat(["", "MIN", "MAX", "UNIT"],
                ["Supply Voltage", "2.375", "2.625", "V"],
                ["Input current", "1", "2", "uA"],
                ["Output current", "3", "4", "uA"],
                ["Temp", "5", "6", "C"])
        self.assertEqual(PT._rows_from_table(m), [])

    def test_no_number_column(self):
        m = mat(["NAME", "DESC"], ["VDD", "supply"], ["GND", "ground"],
                ["VCC", "power"], ["VSS", "gnd"])
        self.assertEqual(PT._rows_from_table(m), [])


class InterleaveTest(unittest.TestCase):
    def _rows(self, pairs):
        return [{"pin": p, "name": n} for p, n in pairs]

    def test_grouped_order_is_flagged(self):
        rows = self._rows([(1, "OUTA_0+"), (2, "OUTA_1+"), (3, "OUTA_2+"),
                           (4, "OUTA_0-"), (5, "OUTA_1-"), (6, "OUTA_2-")])
        bad = PT.assert_interleaved(rows)
        self.assertTrue(bad)
        self.assertIn("OUTA", bad[0])

    def test_interleaved_order_passes(self):
        rows = self._rows([(1, "OUTA_0+"), (2, "OUTA_0-"), (3, "OUTA_1+"),
                           (4, "OUTA_1-")])
        self.assertEqual(PT.assert_interleaved(rows), [])

    def test_single_polarity_not_flagged(self):
        rows = self._rows([(1, "CLK_0+"), (2, "CLK_1+")])
        self.assertEqual(PT.assert_interleaved(rows), [])

    def test_empty(self):
        self.assertEqual(PT.assert_interleaved([]), ["empty"])


class HelperTest(unittest.TestCase):
    def test_parts_and_num_list(self):
        self.assertEqual(PT._parts("1, 2 ,3"), ["1", "2", "3"])
        self.assertTrue(PT._is_num_list("1, 2, 3"))
        self.assertFalse(PT._is_num_list("2.375, 2.625"))
        self.assertFalse(PT._is_num_list(""))
        self.assertTrue(PT._is_name_list("OUTB_0+, OUTB_0-"))
        self.assertFalse(PT._is_name_list("Supply Voltage"))

    def test_minus_and_dash_normalized(self):
        self.assertEqual(PT._norm("OUTA_3\u2013"), "OUTA_3-")   # en dash
        self.assertEqual(PT._norm("OUTA_3\u2212"), "OUTA_3-")   # minus sign


if __name__ == "__main__":
    unittest.main()
