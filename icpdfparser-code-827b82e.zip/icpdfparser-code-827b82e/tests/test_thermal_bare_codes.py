# -*- coding: utf-8 -*-
"""CDC6C 系列（`SNAS843D`）的两处排版差异：裸封装码、参数名与描述同行。

同一张热阻表在 TI 手册里有两种排版，旧实现只认第一种：

1. **封装码带括号名**（LM317 / NE555 / LM358）：`DCY (SOT-223) 4 PINS`
2. **只有裸封装码 + 裸引脚数**（CDC6C）：`DLE` / `DLF` / `DLX` / `DLY` + `4` `4` `4` `4`

第 2 种旧实现逐行 match 括号，四列全被跳过 → 塌缩成 1 列且 `condition` 为空。
同一份手册里 `RθJC(top) Junction-to-case (top) thermal resistance` 还把参数名与
描述印在**一行**，整串归一后查表查不到 → 整条参数被静默漏掉。两项合起来正是
工单 #20/#21/#22 的全部 P0。
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import deterministic_extract as D     # noqa: E402


class _Page:
    def __init__(self, lines, number=6):
        self._text = "\n".join(lines)
        self.number = number

    def get_text(self):
        return self._text


#: CDC6C p6 文本层（`SNAS843D`），逐字照抄。
CDC_PAGE = [
    "6.5 Thermal Information",
    "THERMAL METRIC(1)",
    "CDC6C",
    "UNIT",
    "DLE", "DLF", "DLX", "DLY",
    "4", "4", "4", "4",
    "RθJA", "Junction-to-ambient thermal resistance",
    "151.8", "151.7", "180.3", "189.1", "°C/W",
    "RθJC(top) Junction-to-case (top) thermal resistance",
    "89.5", "99.3", "116.2", "137.3", "°C/W",
    "RθJB", "Junction-to-board thermal resistance",
    "72.2", "64.4", "85.5", "85", "°C/W",
]


def test_bare_package_codes_become_columns():
    """`DLE / DLF / DLX / DLY` 后面没有任何括号名，四列仍然要认出来。"""
    rows = D.extract_thermal([_Page(CDC_PAGE)])
    rja = [r for r in rows if r["name"] == "RθJA"]

    assert [r["value"] for r in rja] == ["151.8", "151.7", "180.3", "189.1"]
    assert [r["condition"] for r in rja] == [
        "DLE 4 PINS", "DLF 4 PINS", "DLX 4 PINS", "DLY 4 PINS"]


def test_bare_code_condition_has_no_empty_parentheses():
    """`DLE ()` 会让复核方以为封装名漏读了 —— 没有就干脆不写括号。"""
    rows = D.extract_thermal([_Page(CDC_PAGE)])
    assert all("()" not in r["condition"] for r in rows)


def test_param_name_and_description_on_one_line_is_matched():
    """`RθJC(top) Junction-to-case…` 挤成一行时不许整条漏掉。

    这条是「关键参数缺失」类工单的真实根因：不是源文档没有，是匹配写死了整行相等。
    """
    rows = D.extract_thermal([_Page(CDC_PAGE)])
    rjc = [r for r in rows if r["name"] == "RθJC(top)"]

    assert len(rjc) == 4
    assert [r["value"] for r in rjc] == ["89.5", "99.3", "116.2", "137.3"]


def test_multi_line_and_single_line_styles_agree():
    """同一张表里两种排版混排（RθJA 两行、RθJC(top) 一行）都要正常。"""
    rows = D.extract_thermal([_Page(CDC_PAGE)])
    names = [r["name"] for r in rows]

    assert names.count("RθJA") == 4
    assert names.count("RθJC(top)") == 4
    assert names.count("RθJB") == 4
    assert D.unresolved_rows() == []


# ─────────────────────────────────────────────────────────────────────
# 防误伤：没有「≥2 个裸码 + 引脚数对齐」时不许凭空造列
# ─────────────────────────────────────────────────────────────────────

def test_stray_uppercase_words_do_not_become_package_columns():
    """单列表头里混着零散大写词（脚注标记、器件名）时不许造出封装列。

    造出列的后果比塌缩更糟：值会被按列切分，每一行都变成错的，而且看起来
    「有封装条件」，复核方反而不容易发现。
    """
    page = _Page([
        "6.5 Thermal Information",
        "THERMAL METRIC(1)",
        "CDC6C",
        "UNIT",
        "TI", "NA",                     # 两个零散大写词，不是封装码
        "RθJA", "Junction-to-ambient thermal resistance",
        "151.8", "151.7", "°C/W",
    ])
    rows = D.extract_thermal([page])

    assert len(rows) == 1, "退化成单列，只出一条"
    assert rows[0]["condition"] == "", "没有封装信息就留空，不许编"


def test_bare_codes_with_mismatched_pin_counts_are_rejected():
    """码有 4 个、引脚数只有 2 个 → 对不齐就不认，宁可退化成单列。"""
    page = _Page([
        "6.5 Thermal Information",
        "THERMAL METRIC(1)",
        "CDC6C",
        "UNIT",
        "DLE", "DLF", "DLX", "DLY",
        "4", "4",                       # 只有 2 个引脚数
        "RθJA", "Junction-to-ambient thermal resistance",
        "151.8", "151.7", "180.3", "189.1", "°C/W",
    ])
    rows = D.extract_thermal([page])

    assert all("PINS" not in r["condition"] for r in rows)


# ─────────────────────────────────────────────────────────────────────
# 真实 PDF
# ─────────────────────────────────────────────────────────────────────

CDC_PDF = ROOT / "data" / "pdfs" / "CDC6CE025000ADLYR__cdc6c.pdf"


@pytest.mark.skipif(not CDC_PDF.exists(), reason="缺少 CDC6C 原件")
def test_real_cdc6c_extracts_twenty_rows():
    """5 个参数 × 4 个封装 = 20 行；修复前只有 4 行且 RθJC(top) 整条缺失。"""
    import pymupdf
    with pymupdf.open(str(CDC_PDF)) as doc:
        rows = D.extract_thermal(doc)

    assert len(rows) == 20
    assert {r["name"] for r in rows} == {"RθJA", "RθJC(top)", "RθJB", "ψJT", "ψJB"}
    assert all(r["condition"].endswith("PINS") for r in rows)
