# -*- coding: utf-8 -*-
"""v4 表选择：资格闸门 + 跨表最高分 + 表级并列自证（红先）。

五条用例全部来自 2026-11-03 的 ADS42JB49SEK 真实勘查（同 JSON + 同 PDF + 同 HEAD
的只读复算），不是凭空造的正则：

  1. `VID`：p11 得分 105，p3（修订历史）80。v3 按表序选了 p3 → v4 必须选 p11。
  2. `Global power-down`：两张合格表并列 155 → 用 value_supported 自证选 p11。
  3. `Analog power`：引脚表得分 130 > 电气表 80，但引脚表无资格 → 必须选 p11。
  4. `Pin Capacitance`：首列是 Pin，但表头有完整数值角色 → **不得剔除**。
  5. fused 表头（`MIN TYP MAX` 挤一格）：A19 认出表头后必须**重新获得资格**。

用法：python -m pytest tests/test_table_decide_v4.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pytest                                              # noqa: E402

from qc import postprocess_qwen as PP                      # noqa: E402
from qc import table_audit as TA                           # noqa: E402


@pytest.fixture(autouse=True)
def _force_v4():
    """v4 目前是 experimental 臂（默认 v3，见 HANDOFF 2026-11-03 的两级表头阻塞）。

    本文件的用例全部是 v4 语义：显式打开，跑完还原，避免污染同进程的其他用例。
    """
    old = TA.MATCH_V4
    TA.MATCH_V4 = True
    try:
        yield
    finally:
        TA.MATCH_V4 = old


def _tbl(page, ti, header, rows, title="", **extra):
    t = {"page": page, "ti": ti, "header": header, "rows": rows, "title": title,
         "xr": [], "hx": [], "split": False, "words_fixed": False}
    t.update(extra)
    return t


#: 本品电气表（p11）：完整三角色表头
ELEC_HDR = ["", "PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]
#: 引脚功能表（p6）：只有 I/O 与描述，没有数值角色 → 无资格
PIN_HDR = ["PIN", "I/O", "FUNCTION", "DESCRIPTION"]
#: 修订历史表（p3）：没有数值角色 → 无资格
REV_HDR = ["", "Revision History", "", ""]
#: 寄存器字段表：只有位号与描述 → 无资格
REG_HDR = ["Bit", "Field", "Type", "Reset", "Description"]


def test_vid_must_not_lose_to_revision_history():
    """证据：p11=105 却被 p3=80 抢走（表序更靠前）。"""
    rev = _tbl(3, 1, REV_HDR, [["•", "Changed From VID to VPP in Table 7.7", "", ""]])
    elec = _tbl(11, 0, ELEC_HDR,
                [["", "VID Differential input voltage", "Default (after reset)", "2", "", "2.5", "V PP"]])
    tables = [rev, elec]

    status, info = TA.decide_table(tables, "VID", "VID", "Default after reset", "2 to 2")
    assert status == "matched"
    assert (info["table"]["page"], info["table"]["ti"]) == (11, 0)

    # 回滚臂必须还原旧行为（证明这条用例真的在测 v4，而不是本来就这样）
    old = TA.MATCH_V4
    TA.MATCH_V4 = False
    try:
        st3, inf3 = TA.decide_table(tables, "VID", "VID", "Default after reset", "2 to 2")
        assert (st3, inf3["table"]["page"]) == ("matched", 3)
    finally:
        TA.MATCH_V4 = old


def test_table_tie_broken_by_value_supported():
    """两张合格表并列 155 → 谁的数值格能解释 value 就选谁。"""
    a = _tbl(11, 0, ELEC_HDR,
             [["", "Global power down", "", "", "", "160", "uA"]])
    b = _tbl(12, 0, ELEC_HDR,
             [["", "Global power down", "", "80", "", "120", "uA"]])
    st, info = TA.decide_table([b, a], "", "Global power down", "", "160")
    assert st == "matched"
    assert (info["table"]["page"], info["ri"]) == (11, 0)

    # 两边都解释不了 → 不猜，报 row_ambiguous_unresolved + table_tie
    st2, info2 = TA.decide_table([a, b], "", "Global power down", "", "999")
    assert st2 == "ambiguous_tie"
    assert info2.get("reason") == "table_tie"
    assert [t["page"] for t in info2["tables"]] == [11, 12]


def test_pin_table_with_higher_score_still_loses():
    """引脚表得分更高（130 > 80），资格闸门必须挡住它。"""
    pin = _tbl(6, 0, PIN_HDR, [["AVDD", "I", "Supply", "Analog power supply pin"]])
    elec = _tbl(11, 0, ELEC_HDR, [["", "Analogpower", "", "", "231", "", "mW"]])
    st, info = TA.decide_table([pin, elec], "", "Analog power", "", "231")
    assert st == "matched"
    assert (info["table"]["page"], info["table"]["ti"]) == (11, 0)


def test_pin_capacitance_table_keeps_eligibility():
    """反例：首列是 Pin，但它是合法电气表（完整 MIN/TYP/MAX），绝不能剔除。"""
    tbl = _tbl(14, 0, ["PARAMETER", "TEST CONDITIONS", "MIN", "TYP", "MAX", "UNIT"],
               [["Pin capacitance", "Per pin", "", "1.5", "", "pF"]])
    assert TA.table_has_value_roles(tbl) is True
    st, info = TA.decide_table([tbl], "", "Pin capacitance", "Per pin", "1.5")
    assert st == "matched" and info["ri"] == 0


def test_fused_header_regains_eligibility_after_a19():
    """A19：`MIN TYP MAX` 挤在一格 —— 表头仍要算 3 个角色，不得与 A19 互斥。"""
    hdr = ["Parameter", "Test Conditions", "MIN TYP MAX", "Unit"]
    tbl = _tbl(5, 0, hdr, [["INL", "After gain error", "-3.9 0 5.5", "LSB"]])
    assert 2 in TA.fused_cols(hdr)                 # 确认它确实是融合列（A19 场景）
    assert TA.table_has_value_roles(tbl) is True   # 但资格必须成立


def test_identical_duplicate_tables_are_equivalent():
    """同内容重复表（BUF634 p5/p6/p7/p8 四张同表）：选第一张即可，不报 unresolved。

    证据：四张表得分都是 130、候选行逐格相同；选哪张写出来都一样。
    这类并列不是"无法判定"，是**等价物**，报 ambiguous 只会白耗人工。
    """
    row = ["", "Quiescent Current", "IO = 0 mA", "", "", "15", "mA"]
    a = _tbl(5, 0, ELEC_HDR, [list(row)])
    b = _tbl(7, 0, ELEC_HDR, [list(row)])
    c = _tbl(8, 0, ELEC_HDR, [list(row)])
    st, info = TA.decide_table([a, b, c], "", "Quiescent Current", "IO = 0 mA", "15")
    assert st == "matched"
    assert info["table"]["page"] == 5


def test_resolve_rowrefs_uses_the_same_single_entry():
    """消除平行实现：postprocess 的行锚点必须走 decide_table（否则修两遍）。"""
    rev = _tbl(3, 1, REV_HDR, [["•", "Changed From VID to VPP", "", ""]])
    elec = _tbl(11, 0, ELEC_HDR,
                [["", "VID Differential input voltage", "Default (after reset)", "2", "", "2.5", "V PP"]])
    refs = PP.resolve_rowrefs(
        [{"symbol": "VID", "name": "VID", "condition": "Default after reset", "value": "2 to 2"}],
        [rev, elec])
    assert refs == [(11, 0, 0)]


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
