# -*- coding: utf-8 -*-
"""`fused_cols`：识别被 pymupdf 劈到列边界上的表头词（红先用例）。

背景 —— ADC3910 p12 t0（Timing Requirements）实测：

    PDF 上表头是   | CONDITIONS |  MIN  NOM  MAX  | UNIT |
    但 find_tables 按**文字 bbox** 切列，把一个词劈到了列边界：
    header = ['PARAMETER', '', 'TESTCONDITIONS', 'MIN', 'NOM MA', 'X UNIT']
                  ''            ← 'MA|X' 是 MAX 被劈成两半
    hx[3] = (430.7, 458.4)   MIN     hx[4] = (458.4, 505.4)  'NOM MA'
    xr[13][3] = (430.7, 505.4)   ← 数据格覆盖整段（PDF 里三词本来就在一列里）

后果链：
1. `role_map` 认不出 `'NOM MA'`（`\\bmax\\b` 匹配不上 `ma`）→ 该列不进数值列
2. 值 `'60'` 被算在 index 3（MIN 列）名下，但它的 bbox 横跨到 index 4
3. `fused_cols` 也没命中（一列里一个角色都认不出，不是"≥2 个角色"）
4. 最后靠 A16 的 `SPANS_MULTIPLE_ROLES` 兜底拒写 —— 拦住了，但**理由是错的**：
   这不是"值跑出了列"，而是"表头一个词跨在列边界上，这一整段不可分"

**红先声明**：`test_split_role_word_is_fused` / `test_split_role_word_covers_both_columns`
在修复前是红的 —— 旧 `fused_cols` 用 `\\bmax\\b` 逐列匹配，`'NOM MA'` 一个角色都认不出。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

#: ADC3910 的实际表头（逐字取自 `scan_tables`）
HDR_ADC3910 = ["PARAMETER", "", "TESTCONDITIONS", "MIN", "NOM MA", "X UNIT"]


class TestSplitRoleWord:
    """一个角色词被劈到两列边界上 → 这两列都必须判 fused（整表 abstain）。"""

    def test_split_role_word_is_fused(self):
        """`'NOM MA'` + `'X UNIT'` = NOM|MAX|UNIT 被劈开，必须判融合。"""
        got = TA.fused_cols(HDR_ADC3910)
        assert got, f"没识别出被劈开的 MAX：{HDR_ADC3910} → {got}"

    def test_split_role_word_covers_both_columns(self):
        """劈在边界上的词，两侧列都不可分 —— 只标一半会让另一半被当普通列。"""
        got = TA.fused_cols(HDR_ADC3910)
        assert {4, 5} <= got, f"劈开的 MAX 两侧列应都判 fused，实际 {got}"

    def test_split_role_word_interior_only(self):
        """MIN 列（index 3）本身是完整的，不该被连坐。"""
        assert 3 not in TA.fused_cols(HDR_ADC3910)


class TestFusedNoFalsePositive:
    """判据放宽后最容易出的事：把正常表误伤成融合列，整批写盘被静默掐掉。"""

    #: 全项目测试夹具都在用的标准表头 —— 它被判 fused 会让所有写盘用例一起红
    HDR_NORMAL = ["PARAMETER", "TESTCONDITIONS", "MIN", "TYP", "MAX", "UNIT"]

    def test_normal_header_not_fused(self):
        assert TA.fused_cols(self.HDR_NORMAL) == set()

    def test_intact_fused_still_detected(self):
        """DAC8555 形态（三词挤一列、词本身完整）不能因为放宽而漏掉。"""
        hdr = ["PARAMETER", "TESTCONDITIONS", "MIN TYP MAX", "UNIT"]
        assert 2 in TA.fused_cols(hdr)

    def test_unit_adjacent_to_min_not_fused(self):
        """`UNIT` 后接 `MIN`：两个完整词，拼不出 'min'，不许误判。"""
        hdr = ["PARAMETER", "", "UNIT", "MIN"]
        assert TA.fused_cols(hdr) == set()

    def test_typ_then_ical_not_confused_with_max(self):
        """`TYP` + `ICAL` 是 TYPICAL 被劈开 → 该判 fused（同一条判据的另一形态）。"""
        hdr = ["PARAMETER", "", "TYP", "ICAL", "MAX", "UNIT"]
        got = TA.fused_cols(hdr)
        assert {2, 3} <= got, f"TYP|ICAL 应判 fused，实际 {got}"
