# -*- coding: utf-8 -*-
"""劈开词表头 + 脏单位格：为什么这张表必须 abstain，而不是被"修好"。

真身：`DRV81620-Q1EVM` p10/p12。表头在 PDF 里是

    ['PARAMETER', '', 'TEST CONDITIONS', 'MIN', 'TYP', 'MA', 'X UNIT']

`MAX` 被列边界劈成 `'MA'`(idx5) + `'X'`(idx6)，`'X'` 还和 `UNIT` 粘成一格。
数据本身是规整的（MIN/TYP/MAX 各在自己的列里），坏的只有**表头标签**，
外加单位格脏：r11 是 `'5 Ω 4'`，r20 是 `'0 16 °C'`。

两条独立的结论，都用测试钉住：

**① 表头劈开 → 必须整表 abstain，不许"只写 MIN/TYP"**
修 `fused_cols` 之前，`\\bmax\\b` 命不中 `'ma'`，MAX 角色整列丢失。
后果**取决于条目自己的值落在哪一列**（实测）：

| R DS(ON) 的值 | 修复前 | 修复后 |
|---|---|---|
| `0.4`（MIN） | **写出 `{'MIN':0.4,'TYP':0.7}`，MAX 静默丢失**，只报 `qualifier_loss` | 一条不写 |
| `0.7`（TYP） | 同上，同样只报 `qualifier_loss` | 一条不写 |
| `0.95`（MAX） | `value_unsupported_unresolved`（交人工） | 一条不写 |

也就是说：**值命中 MIN/TYP 时是最坏情形** —— 半张表被当成完整答案写下去，
finding 里连"角色不可分"都没提。现在 `_roles_split_across` 认得出 {5,6}，
`audit_electrical` 走 `cell_unparsable_unresolved` + `table="FUSED_COLUMN"` 整条跳过。

**② `split_fused_rows`（A13）帮不上这种形态 —— 记作已知限制**
A13 切的是「一列里装多角色的值」（DAC8555 的 `'MIN TYP MAX'` 一列三值）。
本形态每个角色**已有自己的列**，只是标签被劈开，`header_roles('MA')` 为空、
`len(roles) < 2`，A13 直接返回 None（见 `test_a13_returns_none_for_half_word`）。
想修只能做「跨列半词重拼表头」，那会改动 `hx`/列边界推断，风险高于收益；
当前 abstain 已保证不误写，所以**不扩 A13**，把它写成限制而不是半成品。

**③ 脏单位格影响面 = 0 条写盘**
`'5 Ω 4'` / `'0 16 °C'` 只出现在这三张融合列表上，而这三张表全部 abstain：
50 件灰度里 `DRV81620` 的 `write_cols=10` 全部来自 p6/p11/p13，
`cell_bad_fused=8`。所以不清洗单位格（清洗要猜哪部分是单位，属"猜"），
只用 `test_dirty_unit_cell_is_never_written` 守住"永不写出"。
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from qc import table_audit as TA  # noqa: E402

#: PDF 里的原样表头（`MAX` 被劈成 'MA' + 'X'，且 'X' 与 'UNIT' 同格）
HDR_SPLIT = ["PARAMETER", "", "TEST CONDITIONS", "MIN", "TYP", "MA", "X UNIT"]
#: 同一张表换成完好表头 —— 只改标签，用来做对照
HDR_CLEAN = ["PARAMETER", "", "TEST CONDITIONS", "MIN", "TYP", "MAX", "UNIT"]

ROWS = [
    ["R DS(ON)", "ON resistance", "TJ = 25 °C", "0.4", "0.7", "0.95", "5 Ω 4"],
    ["TOTW", "Thermal warning", "", "120", "160", "200", "0 16 °C"],
]


@pytest.fixture(autouse=True)
def _clean_page():
    TA._PAGE.set(None)
    yield
    TA._PAGE.set(None)


def _tbl(header, rows=None):
    return {"page": 10, "ti": 0, "header": list(header),
            "rows": [list(r) for r in (rows or ROWS)], "hx": [], "xr": []}


class TestSplitWordHeaderFlagged:
    def test_half_word_columns_are_flagged(self):
        got = TA.fused_cols(HDR_SPLIT)
        assert {5, 6} <= got, got
        assert 3 not in got and 4 not in got, "MIN/TYP 是完好列，不该被连坐"

    def test_clean_header_is_not_flagged(self):
        assert TA.fused_cols(HDR_CLEAN) == set()


class TestTableAbstainsNotSilentlyDropsMax:
    def test_whole_table_abstains(self):
        e = {"name": "R DS(ON)", "value": "0.95", "unit": "Ω"}
        finds = TA.audit_electrical([e], [_tbl(HDR_SPLIT)], "specs.electrical")
        kinds = [(f["kind"], f.get("table")) for f in finds]
        assert ("cell_unparsable_unresolved", "FUSED_COLUMN") in kinds, kinds

    @pytest.mark.parametrize("val", ["0.4", "0.7", "0.95"])
    def test_no_columns_written(self, val):
        """关键：不是"写成 MIN/TYP 两条"，是一条都不写。

        `0.4` / `0.7` 是修复前的**静默丢失**点（值命中 MIN/TYP 就会写出半张表），
        `0.95` 是修复前的 `value_unsupported` 点 —— 三种都要一律不写。
        """
        e = {"name": "R DS(ON)", "value": val, "unit": "Ω"}
        TA.audit_electrical([e], [_tbl(HDR_SPLIT)], "specs.electrical")
        assert "columns" not in e and "columns_raw" not in e, e

    def test_clean_header_does_not_produce_fused_finding(self):
        """对照组：同样的行、只把表头标签补全，就不该再报 FUSED_COLUMN。"""
        e = {"name": "R DS(ON)", "value": "0.95", "unit": "Ω"}
        finds = TA.audit_electrical([e], [_tbl(HDR_CLEAN)], "specs.electrical")
        assert all(f.get("table") != "FUSED_COLUMN" for f in finds), finds


class TestDirtyUnitCellNeverWritten:
    @pytest.mark.parametrize("row_i,dirty", [(0, "5 Ω 4"), (1, "0 16 °C")])
    def test_dirty_unit_cell_is_never_written(self, row_i, dirty):
        tbl = _tbl(HDR_SPLIT)
        assert tbl["rows"][row_i][-1] == dirty        # 前置：脏格确实在表里
        e = {"name": tbl["rows"][row_i][0], "value": "0.95", "unit": "Ω"}
        TA.audit_electrical([e], [tbl], "specs.electrical")
        assert "columns" not in e
        assert e.get("unit") == "Ω", "脏单位格不许污染条目自己的 unit"


class TestA13CannotSplitHalfWord:
    def test_a13_returns_none_for_half_word(self):
        """A13 的判据是「一列里能分出 >=2 个角色」；'MA' 一个角色都不算 → 放弃。"""
        roles = TA.header_roles("MA")
        assert len(roles) < 2, roles
        got = TA.split_fused_rows(None, None, [r for r in ROWS], HDR_SPLIT, 5, roles)
        assert got is None

    def test_a13_returns_none_for_unit_cell(self):
        roles = TA.header_roles("X UNIT")
        got = TA.split_fused_rows(None, None, [r for r in ROWS], HDR_SPLIT, 6, roles)
        assert got is None
