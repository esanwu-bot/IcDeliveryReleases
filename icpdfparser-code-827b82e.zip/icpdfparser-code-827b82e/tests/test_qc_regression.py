"""qc_regression 断言三态单测（④ 拆分 001/006 断言）。

背景：`cols_roles_any2` 要求 `electrical[].columns` 含 ≥2 个 MIN/TYP/MAX，
但该字段只有 `qc/table_audit.py --write` 会写，LLM 抽取链路从不产出
（抽样 1500 件命中 0）→ 001/006 结构性永远失败，把真缺陷（缺行/缺值）淹掉。

拆法：A（现有链路必须能过）/ B（依赖 table_audit --write，没跑就算 NOT_CHECKED）。
断言结果必须是三态 True / False / None，None 不能当成失败。
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from qc import qc_regression as R               # noqa: E402


def _res(doc):
    return {"patched_doc": doc, "findings": [], "lint": []}


def _doc(rows):
    return {"specs": {"electrical": rows}}


class AssertTristateTest(unittest.TestCase):
    # ------------------------------------------------- 断言 A：现有链路
    def test_a_passes_with_value_and_marker(self):
        d = _doc([{"name": "Forward voltage", "value": "0.3 to 0.7", "unit": "V",
                   "condition": "IF = 100 mA; typ=0.5"}])
        self.assertTrue(R.eval_assert(["value_roles_marker"], _res(d)))

    def test_a_fails_on_empty_value(self):
        """v1 prompt 下 value 为空的情形：A 必须红，这样才能真实反映 G1 的问题。"""
        d = _doc([{"name": "ICC", "value": "", "unit": "uA",
                   "condition": "VCC=Max.; typ=5; max=500"},
                  {"name": "VIH", "value": "2.0", "unit": "V", "condition": ""}])
        self.assertFalse(R.eval_assert(["value_roles_marker"], _res(d)))

    def test_a_fails_without_roles_marker(self):
        d = _doc([{"name": "VOH", "value": "3.3", "unit": "V", "condition": ""}])
        self.assertFalse(R.eval_assert(["value_roles_marker"], _res(d)))

    def test_a_fails_on_no_electrical(self):
        self.assertFalse(R.eval_assert(["value_roles_marker"], _res(_doc([]))))

    def test_a_accepts_not_specified_as_filled(self):
        """占位符行统一填 not_specified，不算空值（但要有 min/typ/max 标识）。"""
        d = _doc([{"name": "PSRR", "value": "not_specified", "unit": "dB",
                   "condition": "typ=80"}])
        self.assertTrue(R.eval_assert(["value_roles_marker"], _res(d)))

    # ------------------------------------------- 断言 B：依赖 table_audit
    def test_b_is_not_checked_without_columns_layer(self):
        d = _doc([{"name": "ICC", "value": "500", "unit": "uA", "condition": "typ=5"}])
        self.assertIsNone(R.eval_assert(["cols_roles_any2"], _res(d)))

    def test_b_fails_when_layer_present_but_roles_missing(self):
        d = _doc([{"name": "ICC", "value": "500", "columns": {"TYP": 5.0}}])
        self.assertFalse(R.eval_assert(["cols_roles_any2"], _res(d)))

    def test_b_passes_with_two_or_more_roles(self):
        d = _doc([{"name": "ICC", "value": "500",
                   "columns": {"TYP": 5.0, "MAX": 500.0}}])
        self.assertTrue(R.eval_assert(["cols_roles_any2"], _res(d)))

    # ------------------------------------------------------- 三态不混淆
    def test_none_is_not_treated_as_failure(self):
        """跑批时 `not eval_assert(...)` 会把 None 当失败，必须按 False 过滤。"""
        d = _doc([{"name": "ICC", "value": "500"}])
        vals = [R.eval_assert(a, _res(d))
                for a in (["value_roles_marker"], ["cols_roles_any2"])]
        self.assertEqual(vals, [False, None])
        self.assertEqual([a for a, v in zip(["a", "b"], vals) if v is False], ["a"])
        self.assertEqual([a for a, v in zip(["a", "b"], vals) if v is None], ["b"])


if __name__ == "__main__":
    unittest.main()
