"""自动修复器单测：白名单闸、各 fixer 的确定性与「不越权」纪律。

这些测试全部走纯函数（fixers.py 的 ctx 只需 doc + json_path + allowed_paths），
不依赖 Redis / Celery / 真实 PDF，所以能在 CI 里秒级跑完。
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from worker import fixers as FX            # noqa: E402


def make_ctx(doc: dict, allowed: list[str], tmp: Path, **kw) -> dict:
    jp = tmp / "X.json"
    jp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    ctx = {"mpn": kw.pop("mpn", "X123"), "doc": doc, "json_path": jp,
           "allowed_paths": allowed, "alts": kw.pop("alts", {}),
           "pdf_text": kw.pop("pdf_text", ""),
           "action": kw.pop("action", {}), "original": json.loads(json.dumps(doc))}
    ctx.update(kw)
    return ctx


def reload(ctx) -> dict:
    return json.loads(ctx["json_path"].read_text(encoding="utf-8"))


class PathToolTest(unittest.TestCase):
    def test_parse_and_get_set(self):
        doc = {"a": {"b": [{"c": 1}, {"c": 2}]}}
        self.assertEqual(FX.parse_path("a.b[1].c"), ["a", "b", 1, "c"])
        self.assertEqual(FX.get_path(doc, "a.b[1].c"), 2)
        self.assertTrue(FX.set_path(doc, "a.b[0].c", 9))
        self.assertEqual(doc["a"]["b"][0]["c"], 9)
        # 父级不存在时不擅自造结构
        self.assertFalse(FX.set_path(doc, "nope.x", 1))

    def test_walk_strings(self):
        doc = {"a": "x", "b": ["y", {"c": "z"}], "n": 3}
        paths = dict(FX.walk_strings(doc))
        self.assertEqual(paths["a"], "x")
        self.assertEqual(paths["b[0]"], "y")
        self.assertEqual(paths["b[1].c"], "z")
        self.assertNotIn("n", paths)

    def test_path_allowed(self):
        self.assertTrue(FX.path_allowed("any.thing", ["*"]))
        self.assertTrue(FX.path_allowed("specs.package.type", ["specs.package"]))
        self.assertTrue(FX.path_allowed("specs.electrical[3].value", ["specs.electrical"]))
        self.assertTrue(FX.path_allowed("pin_configuration[0].device_scope",
                                        ["pin_configuration.*.device_scope"]))
        self.assertFalse(FX.path_allowed("basic_info.mpn", ["specs.electrical"]))
        self.assertFalse(FX.path_allowed("anything", []))

    def test_whitelist_raises(self):
        """越权必须抛错——这是防「fixer 顺手改坏 facts」的唯一硬闸。"""
        ctx = make_ctx({"specs": {"electrical": []}}, ["specs.electrical"],
                       Path(tempfile.mkdtemp()))
        with self.assertRaises(PermissionError):
            FX.validate_changes(ctx, ["basic_info.mpn"])


class EscapeFixerTest(unittest.TestCase):
    def test_double_escape_normalized(self):
        """多层转义要一路解到稳定（&amp;amp; → &），否则下次再跑又变。"""
        doc = {"features": ["LARGE T&amp;amp;R"], "basic_info": {"mpn": "X"}}
        ctx = make_ctx(doc, ["*"], Path(tempfile.mkdtemp()))
        out = FX.fix_escape(ctx)
        self.assertIn("features[0]", out["changed"])
        self.assertEqual(reload(ctx)["features"][0], "LARGE T&R")
        self.assertEqual(out["next_task"], "render_item")

    def test_idempotent(self):
        """再跑一次不应产生新改动（unescape 幂等的关键性质）。"""
        doc = {"features": ["T&amp;R"]}
        ctx = make_ctx(doc, ["*"], Path(tempfile.mkdtemp()))
        FX.fix_escape(ctx)
        out2 = FX.fix_escape(ctx)
        self.assertEqual(out2["changed"], [])

    def test_no_escape_is_noop(self):
        ctx = make_ctx({"a": "plain"}, ["*"], Path(tempfile.mkdtemp()))
        out = FX.fix_escape(ctx)
        self.assertEqual(out["changed"], [])
        self.assertEqual(out["note"], "no_escape_found")

    def test_render_layer_residue_counts_as_repair(self):
        """JSON 干净、旧产物有残留：修复动作是重渲染，也要记一笔。

        记成 `render:txt` 而不是 []：产物确实要被重新生成，算一次真实修复；
        若不记，「修好了」会一直显示成「没修」（NE555 的形态）。
        """
        ctx = make_ctx({"a": "plain"}, ["*"], Path(tempfile.mkdtemp()))
        ctx["txt_has_escape"] = True
        out = FX.fix_escape(ctx)
        self.assertEqual(out["changed"], ["render:txt"])
        self.assertTrue(out.get("render_only"))
        self.assertEqual(out["next_task"], "render_item")
        self.assertEqual(reload(ctx), {"a": "plain"})     # JSON 一字未改


class UnitFixerTest(unittest.TestCase):
    def test_strip_duplicated_unit(self):
        doc = {"specs": {"electrical": [
            {"name": "Iq", "value": "10 mA", "unit": "mA"},
            {"name": "Vout", "value": "5", "unit": "V"},
        ]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()))
        out = FX.fix_unit_duplicated(ctx)
        self.assertEqual(out["changed"], ["specs.electrical[0].value"])
        self.assertEqual(reload(ctx)["specs"]["electrical"][0]["value"], "10")

    def test_mismatched_unit_untouched(self):
        """value 里单位与 unit 字段不一致时不猜（可能是真错，交人工）。"""
        doc = {"specs": {"electrical": [{"name": "P", "value": "10 mW", "unit": "mA"}]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()))
        self.assertEqual(FX.fix_unit_duplicated(ctx)["changed"], [])


class ElecShapeTest(unittest.TestCase):
    def test_missing_fields_marked_not_invented(self):
        doc = {"specs": {"electrical": [{"name": "Iq", "value": "10", "unit": ""}]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()))
        out = FX.fix_elec_shape(ctx)
        row = reload(ctx)["specs"]["electrical"][0]
        self.assertEqual(row["unit"], "not_specified")
        self.assertIn("field_missing:unit", row["quality_warning"])
        self.assertIn("specs.electrical[0].unit", out["changed"])

    def test_complete_row_untouched(self):
        doc = {"specs": {"electrical": [{"name": "Iq", "value": "10", "unit": "uA"}]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()))
        self.assertEqual(FX.fix_elec_shape(ctx)["changed"], [])


class ElecRowTest(unittest.TestCase):
    def test_condition_from_pdf(self):
        doc = {"specs": {"electrical": [{"name": "Iq", "value": "1", "unit": "mA"}]}}
        pdf = ("Electrical Characteristics\nIq quiescent current\n"
               "over operating free-air temperature range unless otherwise noted\n")
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()),
                       pdf_text=pdf, action={"kind": "condition_leak"})
        out = FX.fix_elec_row(ctx)
        row = reload(ctx)["specs"]["electrical"][0]
        self.assertTrue(row.get("condition"))
        self.assertIn("specs.electrical[0].condition", out["changed"])

    def test_no_pdf_evidence_only_warns(self):
        """没有原文佐证时只挂 warning，绝不编条件。"""
        doc = {"specs": {"electrical": [{"name": "Iq", "value": "1", "unit": "mA"}]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()),
                       pdf_text="", action={"kind": "condition_leak"})
        out = FX.fix_elec_row(ctx)
        row = reload(ctx)["specs"]["electrical"][0]
        self.assertNotIn("condition", row)
        self.assertTrue(any("condition_unresolved" in w
                            for w in row.get("quality_warning") or []))
        self.assertEqual(out["note"], "condition_unresolved")

    def test_never_touches_value_or_unit(self):
        doc = {"specs": {"electrical": [{"name": "Iq", "value": "1", "unit": "mW"}]}}
        ctx = make_ctx(doc, ["specs.electrical"], Path(tempfile.mkdtemp()),
                       pdf_text="Iq over operating free-air temperature range",
                       action={"kind": "unit_dimension"})
        FX.fix_elec_row(ctx)
        row = reload(ctx)["specs"]["electrical"][0]
        self.assertEqual(row["value"], "1")
        self.assertEqual(row["unit"], "mW")          # 值级不动，交证据卡


class IdentityFixerTest(unittest.TestCase):
    def test_board_marked(self):
        doc = {"basic_info": {"mpn": "DS80PCI402EVK/NOPB"},
               "specs": {"package": {"type": "WQFN-54", "pins": 54}},
               "pin_configuration": [{"pin": 1, "name": "VDD"}]}
        ctx = make_ctx(doc, ["basic_info.identity", "basic_info.device_mpn",
                             "basic_info.datasheet_scope",
                             "specs.package.type", "specs.package.original_type",
                             "pin_configuration.*.device_scope"],
                       Path(tempfile.mkdtemp()), mpn="DS80PCI402EVK/NOPB")
        out = FX.fix_identity(ctx)
        d = reload(ctx)
        self.assertEqual(d["basic_info"]["identity"], "evaluation_board")
        # 必须是 PCB 形态：写 not_specified 会被 review 的 board_package_mismatch 判 P0
        self.assertEqual(d["specs"]["package"]["type"],
                         "Evaluation Board (assembled PCB)")
        self.assertEqual(d["basic_info"]["device_mpn"], "DS80PCI402")
        self.assertEqual(d["basic_info"]["datasheet_scope"], "onboard_device")
        self.assertEqual(d["specs"]["package"]["original_type"], "WQFN-54")
        self.assertEqual(d["pin_configuration"][0]["device_scope"], "onboard_device")
        self.assertIn("specs.package.type", out["changed"])

    def test_plain_chip_untouched(self):
        """普通芯片不能被误标成板（否则是灾难性误修）。"""
        doc = {"basic_info": {"mpn": "LM358"},
               "specs": {"package": {"type": "SOIC-8", "pins": 8}}}
        ctx = make_ctx(doc, ["basic_info.identity", "specs.package.type"],
                       Path(tempfile.mkdtemp()), mpn="LM358")
        out = FX.fix_identity(ctx)
        self.assertEqual(out["changed"], [])
        self.assertEqual(out["note"], "not_a_board")
        self.assertNotIn("identity", reload(ctx)["basic_info"])

    def test_board_via_alts_flag(self):
        doc = {"basic_info": {"mpn": "XYZ-1"},
               "specs": {"package": {"type": "SOIC-8"}}}
        ctx = make_ctx(doc, ["basic_info.identity", "basic_info.device_mpn",
                             "basic_info.datasheet_scope",
                             "specs.package.type",
                             "specs.package.original_type"],
                       Path(tempfile.mkdtemp()), mpn="XYZ-1",
                       alts={"board": True})
        out = FX.fix_identity(ctx)
        self.assertIn("basic_info.identity", out["changed"])


class MpnRewriteTest(unittest.TestCase):
    def test_restore_requested_mpn(self):
        doc = {"basic_info": {"mpn": "TPS7A02"}}
        ctx = make_ctx(doc, ["basic_info.mpn", "basic_info.device_mpn",
                             "basic_info.identity"],
                       Path(tempfile.mkdtemp()), mpn="DS80PCI402EVK/NOPB")
        out = FX.fix_mpn_rewritten(ctx)
        d = reload(ctx)["basic_info"]
        self.assertEqual(d["mpn"], "DS80PCI402EVK/NOPB")
        self.assertEqual(d["device_mpn"], "TPS7A02")
        self.assertIn("basic_info.mpn", out["changed"])

    def test_same_mpn_noop(self):
        doc = {"basic_info": {"mpn": "LM358"}}
        ctx = make_ctx(doc, ["basic_info.mpn"], Path(tempfile.mkdtemp()), mpn="LM358")
        self.assertEqual(FX.fix_mpn_rewritten(ctx)["changed"], [])


class TemplateFixerTest(unittest.TestCase):
    def test_template_only_rerender(self):
        """模板类问题不改 JSON，只触发重渲染——否则下次重渲染又被覆盖。

        `changed` 记的是 `render:template`（产物要重新生成，即一次真实修复动作），
        不是 JSON 路径：所以 JSON 必须原样不动，也不走 commit/白名单。
        不记这一条的话，渲染层修好的件永远进不了「已 review 并已修复」。
        """
        doc = {"features": ["a"]}
        ctx = make_ctx(doc, [], Path(tempfile.mkdtemp()))
        out = FX.fix_template_render(ctx)
        self.assertEqual(out["changed"], ["render:template"])
        self.assertTrue(out.get("render_only"))
        self.assertEqual(out["next_task"], "render_item")
        self.assertEqual(reload(ctx), doc)


class ManualFixerTest(unittest.TestCase):
    def test_manual_never_writes(self):
        doc = {"basic_info": {"mpn": "X"}}
        ctx = make_ctx(doc, [], Path(tempfile.mkdtemp()))
        out = FX.fix_manual(ctx)
        self.assertTrue(out["manual"])
        self.assertEqual(out["changed"], [])
        self.assertEqual(reload(ctx), doc)
        self.assertEqual(out["next_task"], "")


class RestoreTest(unittest.TestCase):
    def test_restore_by_prefix(self):
        tmp = Path(tempfile.mkdtemp())
        data = tmp / "data"
        (data / "parsed").mkdir(parents=True)
        (data / "txt").mkdir(parents=True)
        bdir = data / "qc" / "fix_backups" / "X" / "20261028-000000"
        bdir.mkdir(parents=True)
        (bdir / "X.json").write_text('{"a":1}', encoding="utf-8")
        (bdir / "txt__X.txt").write_text("hello", encoding="utf-8")

        out = FX.restore("X", bdir, data)
        self.assertEqual(out["restored"], 2)
        self.assertEqual((data / "parsed" / "X.json").read_text(encoding="utf-8"),
                         '{"a":1}')
        self.assertEqual((data / "txt" / "X.txt").read_text(encoding="utf-8"), "hello")


class BackupTest(unittest.TestCase):
    def test_backup_dir_unique(self):
        tmp = Path(tempfile.mkdtemp())
        d1 = FX.backup_dir_for("A/B", tmp)
        self.assertIn("A_B", str(d1))
        self.assertTrue(d1.is_dir())


if __name__ == "__main__":
    unittest.main()
