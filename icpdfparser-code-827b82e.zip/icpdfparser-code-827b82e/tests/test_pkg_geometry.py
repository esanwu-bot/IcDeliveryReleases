#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""封装几何：从机械图抽取 → 2D 球阵 / 3D 等轴测出图 → 状态升级。

守的是三件事：
1. **抽不出来就不许画**（fail-closed 没被这轮改动松掉）；
2. **抽出来就要画对**（球数、行列、pitch、body 都来自标注，且带页码证据）；
3. **画了图状态就要认**（否则边界小节与页面自相矛盾，客户第一眼就看出来）。

`data/pdfs/` 与 `qc/pdfs/` 都不入 git，所以只有真正读 PDF 的那条用 `skipif`；
其余用夹具几何，保证复核方 clone 下来就能跑。
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import symbol_svg as S
from qc import engineering_model as EM
from qc import pkg_geometry as PG

ROOT = Path(__file__).resolve().parent.parent
PDF = ROOT / "data" / "pdfs" / "ADC12DJ5200SEAAV__adc12dj5200se.pdf"


# ─────────────────────────────────────────────────────────────────────
# 夹具：ADC12DJ5200SE / FCBGA-144 第 177 页（图纸 AAV0144A 4219578/D）
# 数值照抄抽取结果，供不依赖 PDF 的用例使用；PDF 在的时候另有断言核对真实性。
# ─────────────────────────────────────────────────────────────────────

def geom() -> dict:
    vals = {
        "family": "FCBGA",
        "body_x": {"min": 9.85, "max": 10.15, "nominal": 10.0},
        "body_y": {"min": 9.85, "max": 10.15, "nominal": 10.0},
        "height": {"min": 1.7, "max": 1.91},
        "standoff": {"min": 0.325, "max": 0.405},
        "pitch": 0.8,
        "span": {"x": 8.8, "y": 8.8},
        "ball_diameter": {"min": 0.41, "max": 0.51},
        "ball_count": 144,
        "rows": 12,
        "cols": 12,
        "drawing_code": "AAV0144A",
        "drawing_no": "4219578/D",
    }
    checks = [{"name": n, "ok": True, "detail": ""} for n in
              ("unit_mm", "height_matches_title", "pitch_span_rows", "ball_count_grid",
               "body_gt_span", "height_ge_standoff", "ball_dia_lt_pitch",
               "body_corroborated", "pins_match_ball_count")]
    return {
        "schema": PG.SCHEMA,
        "status": "extracted",
        **vals,
        "checks": checks,
        "evidence": {"pdf_sha256": "0" * 64, "page": 177,
                     "title": "FCBGA - 1.91 mm max height",
                     "drawing_code": "AAV0144A", "drawing_no": "4219578/D",
                     "spans": [{"text": "10.15", "bbox": [296.1, 112.9, 315.9, 123.8]}]},
        "source_sha256": "a" * 64,
    }


def bga_doc(**over) -> dict:
    """一份能走通 BGA 完整渲染分支的文档（球位映射 pass、144 球、pin_scope=device）。"""
    balls = [f"{r}{c}" for r in "ABCDEFGHJKLM" for c in range(1, 13)]
    doc = {
        "basic_info": {"mpn": "ADC12DJ5200SE", "identity": "chip"},
        "specs": {"package": {"type": "FCBGA (144)", "pins": 144, "dimensions": "10mm x 10mm"}},
        "pin_configuration": [{"pin": b, "name": "AGND", "description": "ground"} for b in balls],
        # pin_scope 与 pin_validation 是 BGA 球位门禁的输入：缺一项就会被判 unresolved，
        # 页面直接退回「BGA 球位待核」，测不到三视图。
        "pin_scope": "device",
        "metadata": {"pin_validation": {"status": "pass", "balls": 144,
                                        "expected_balls": balls}},
    }
    doc.update(over)
    return doc


@pytest.fixture()
def with_geom() -> dict:
    doc = bga_doc()
    PG.attach(doc, geom())
    return doc


# ─────────────────────────────────────────────────────────────────────
# 1. 抽取器（真实 PDF；不在则跳过）
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not PDF.is_file(), reason="原始 PDF 不入库（data/pdfs 被 gitignore）")
def test_extract_real_pdf_matches_mechanical_drawing():
    g = PG.extract(PDF, expected_pins=144)
    assert g and g["status"] == "extracted"
    assert g["drawing_code"] == "AAV0144A"
    assert g["drawing_no"] == "4219578/D"
    assert g["evidence"]["page"] == 177
    assert g["body_x"]["nominal"] == 10.0
    assert (g["height"]["min"], g["height"]["max"]) == (1.7, 1.91)
    assert (g["standoff"]["min"], g["standoff"]["max"]) == (0.325, 0.405)
    assert g["pitch"] == 0.8
    assert (g["ball_diameter"]["min"], g["ball_diameter"]["max"]) == (0.41, 0.51)
    assert (g["rows"], g["cols"], g["ball_count"]) == (12, 12, 144)
    assert all(c["ok"] for c in g["checks"])


@pytest.mark.skipif(not PDF.is_file(), reason="原始 PDF 不入库")
def test_extract_is_deterministic():
    a = PG.extract(PDF, expected_pins=144)
    b = PG.extract(PDF, expected_pins=144)
    assert a["source_sha256"] == b["source_sha256"]
    assert json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)


@pytest.mark.skipif(not PDF.is_file(), reason="原始 PDF 不入库")
def test_extract_rejects_pin_count_mismatch():
    """声明的球数与图上 `144X` 对不上 → 不采信（互证失败即整份作废）。"""
    assert PG.extract(PDF, expected_pins=256) is None


def test_extract_missing_file_returns_none(tmp_path):
    assert PG.extract(tmp_path / "nope.pdf") is None


# ─────────────────────────────────────────────────────────────────────
# 2. 几何入口的 fail-closed
# ─────────────────────────────────────────────────────────────────────

def test_geometry_of_reads_attached(with_geom):
    assert PG.geometry_of(with_geom)["ball_count"] == 144


def test_geometry_of_drops_entry_with_failed_check(with_geom):
    with_geom["specs"]["package"]["geometry"]["checks"][0]["ok"] = False
    assert PG.geometry_of(with_geom) is None


def test_geometry_of_drops_incomplete_entry(with_geom):
    del with_geom["specs"]["package"]["geometry"]["pitch"]
    assert PG.geometry_of(with_geom) is None


def test_geometry_of_drops_wrong_schema(with_geom):
    with_geom["specs"]["package"]["geometry"]["schema"] = "other/v9"
    assert PG.geometry_of(with_geom) is None


def test_attach_none_removes_key(with_geom):
    PG.attach(with_geom, None)
    assert "geometry" not in with_geom["specs"]["package"]
    assert PG.geometry_of(with_geom) is None


# ─────────────────────────────────────────────────────────────────────
# 3. 绘制：真实尺寸、无占位图、标记齐全
# ─────────────────────────────────────────────────────────────────────

def test_footprint_draws_real_grid():
    svg = S.bga_footprint_svg(geom())
    assert svg.count("<circle") == 144 + 1          # 144 球 + 1 脚标记
    assert 'data-em-geometry="ball-grid"' in svg
    for word in ("10.00 × 10.00 mm", "12×12 = 144 ball", "0.80", "0.41", "FCBGA"):
        assert word in svg
    assert "占位图" not in svg


def test_footprint_ball_geometry_follows_pitch():
    """球心间距必须等于 pitch×scale —— 间距画错就等于尺寸画错。"""
    import re

    svg = S.bga_footprint_svg(geom())
    balls = re.findall(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="([\d.]+)"', svg)
    balls = [(float(x), float(y)) for x, y, r in balls if float(r) > 4]   # 排除 1 脚标记
    assert len(balls) == 144, f"应画出 144 个球，实得 {len(balls)}"
    xs = sorted(set(round(x, 2) for x, _ in balls))
    assert len(xs) == 12, f"应恰好 12 列球，实得 {len(xs)}"
    gaps = [round(b - a, 2) for a, b in zip(xs, xs[1:])]
    # 坐标保留两位小数，间距会有 ±0.1 的舍入抖动；用容差而不是全等。
    assert max(gaps) - min(gaps) <= 0.2, f"列间距不一致：{sorted(set(gaps))}"
    # body 10mm 铺满约 194px → 每 mm 约 19px；pitch 0.8mm → 约 15~16px
    assert 10 < gaps[0] < 30


def test_3d_draws_isometric_body():
    svg = S.bga_3d_svg(geom())
    assert 'data-em-geometry="3d"' in svg
    assert svg.count("<polygon") >= 3                # 两个侧面 + 顶面
    assert svg.count("<ellipse") == 144
    assert "球面朝上" in svg and "1.91" in svg
    assert "占位图" not in svg


def test_3d_standoff_keeps_three_decimals():
    """0.405 用两位小数会变成 0.40 —— 等于改写标注，必须三位。"""
    assert "0.405" in S.bga_3d_svg(geom())


def test_placeholder_still_used_without_geometry():
    """没有几何时照旧出占位图：这轮没有把红线松掉。"""
    fp = S.footprint_svg([(i, "X") for i in range(1, 145)], "FCBGA (144)", 144)
    m3 = S.model3d_svg([(i, "X") for i in range(1, 145)], "FCBGA (144)")
    assert "封装占位图" in fp and "3D 占位图" in m3
    assert "data-em-geometry" not in fp + m3


def test_shared_pkg_inlines_instead_of_linking():
    """交付包不挂在站点上：共享图必须内联，否则站内绝对路径就是裂图。"""
    pkg_dir = ROOT / "data" / "pkgs"
    if not (pkg_dir / "SOIC-16.svg").is_file():
        pytest.skip("共享封装图库不在")
    doc = {
        "basic_info": {"mpn": "ADS1201U-1/1K", "identity": "chip"},
        "specs": {"package": {"type": "SOIC-16", "pins": 16}},
        "pin_configuration": [{"pin": i, "name": f"P{i}"} for i in range(1, 17)],
        "metadata": {"pin_validation": {"status": "pass"}},
    }
    linked = S.render_page(doc, pkg_dir)
    inlined = S.render_page(doc, pkg_dir, inline_pkg=True)
    assert '<img src="/upload/pkg' in linked
    assert "<img src=" not in inlined
    assert inlined.count("<svg") >= 3               # 符号 + 封装 + 3D 全内联


# ─────────────────────────────────────────────────────────────────────
# 4. 状态：有几何才升级，没有仍然 fail-closed
# ─────────────────────────────────────────────────────────────────────

def test_state_upgrades_with_geometry(with_geom):
    st = EM.derive_state(with_geom)
    assert st["package_outline"]["status"] == "extracted"
    assert st["geometry_3d"]["status"] == "generated"
    assert st["geometry_3d"]["source_hash"] == "a" * 64
    assert st["geometry_3d"]["evidence"]["page"] == 177


def test_state_stays_fail_closed_without_geometry():
    st = EM.derive_state(bga_doc())
    assert st["geometry_3d"]["status"] == "not_generated"
    assert st["package_outline"]["status"] == "not_checked"


def test_render_notes_names_the_drawing(with_geom):
    notes = " ".join(EM.render_notes(EM.derive_state(with_geom)))
    assert "第 177 页" in notes and "AAV0144A" in notes
    assert "未生成" not in notes


def test_render_notes_distinguishes_illustration():
    """画了示意图的页面不能只印「未生成」——那与页面上的图直接打架。"""
    doc = {
        "basic_info": {"mpn": "ADS1201U-1/1K", "identity": "chip"},
        "specs": {"package": {"type": "SOIC-16", "pins": 16}},
        "pin_configuration": [{"pin": i, "name": f"P{i}"} for i in range(1, 17)],
        "metadata": {"pin_validation": {"status": "pass"}},
    }
    note = " ".join(EM.render_notes(EM.derive_state(doc)))
    assert "3D 模型与球阵几何未生成：无可信来源" in note     # 原句保留
    assert "示意" in note                                  # 但仍要说明那是什么


def test_panel_captions_follow_state(with_geom):
    caps = EM.panel_captions(EM.derive_state(with_geom))
    assert caps["footprint"] == "按原厂机械图尺寸绘制"
    assert caps["model3d"] == "按原厂机械图尺寸绘制"


# ─────────────────────────────────────────────────────────────────────
# 5. 整页：客户看到的东西
# ─────────────────────────────────────────────────────────────────────

def test_page_has_no_placeholder_and_passes_gate(with_geom, monkeypatch):
    # 球位门禁（bga_pin_validation）要求原厂 PDF 在场才能复核，与本用例无关：
    # 这里只验「拿到几何之后页面画成什么样」，把它放行。
    monkeypatch.setattr(S, "bga_pin_validation",
                        lambda doc: {"status": "pass", "reasons": []})
    page = S.render_page(with_geom)
    assert "占位图" not in page
    assert 'data-em-geometry="ball-grid"' in page
    assert 'data-em-geometry="3d"' in page
    assert "按原厂机械图尺寸绘制" in page
    findings = EM.check(with_geom, page, EM.derive_state(with_geom))
    assert findings == [], findings


def test_page_boundary_matches_state(with_geom):
    """A5：边界小节的文案必须逐条等于 `render_notes(state)`，不许有第二个事实源。"""
    page = S.render_page(with_geom)
    st = EM.derive_state(with_geom)
    items = EM._boundary_items(page)                        # noqa: SLF001
    assert items == EM.render_notes(st)
