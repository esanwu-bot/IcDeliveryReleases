#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""electrical 行来源分类的单测。

**这批用例的核心目的是防假阳性回归**。关键词版检测器曾在两个标准时序参数上
翻车（`enable` 是名词"使能"，不是 Features 动词），所以下面的
「必须判为真电气」用例比「必须报警」的用例更重要——宁可漏检，不可假阳。

基线实测（10 件 v1 + v2 产物）：误报 0 条，
v2 报 10 条 ECHO_NAME 全部集中在 DAC37J84IAAV。

用法：D:/Program Files (x86)/python/python.exe -m pytest tests/test_electrical_classify.py -q
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc import electrical_classify as EC                     # noqa: E402
from qc import sentinels as S                                # noqa: E402


# ── 必须判为真电气（防假阳性回归）─────────────────────────────────────────

def test_chip_enable_access_time_is_real():
    """`enable` 是名词"使能"，这是标准时序参数，绝不许报警。"""
    row = {"name": "Chip enable access time", "value": "70",
           "unit": "ns", "condition": "tACE; output load A"}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


def test_output_enable_to_output_valid_is_real():
    row = {"name": "Output enable to output valid", "value": "35",
           "unit": "ns", "condition": "tOE; output load A"}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


def test_chip_enable_to_output_low_z_is_real():
    row = {"name": "Chip enable to output in low Z", "value": "5",
           "unit": "ns", "condition": "tCLZ; output load B"}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


def test_sscg_clock_support_not_flagged():
    """DS90C365AMT 实证：`support` 是 "clock support" 的名词部分，value 有数值。

    unit 为空所以不满足可测量特征，落 INSUFFICIENT_EVIDENCE——**关键是不报警**，
    这正是「宁可漏检不可假阳」的预期行为（关键词版会把它误报成 Features）。
    """
    row = {"name": "SSCG", "value": "100kHz ±2.5%/−5%", "unit": "",
           "condition": "Spread spectrum clock support; f = 25MHz"}
    cls = EC.classify_electrical_row(row)
    assert cls not in EC.ALARM_CLASSES


def test_long_name_with_not_specified_value_not_flagged():
    """AFE4490RHAT 实证：name 很长但那是真参数（v2 带上了 section 前缀），
    value=not_specified 是合法降级，不能当 Features 描述。"""
    row = {"name": "Performance, Total integrated noise current, "
                   "input referred, 5-µA PD current range",
           "value": "not_specified", "unit": "", "condition": "PRF = 1200 Hz"}
    assert EC.classify_electrical_row(row) != EC.FEATURE_DESCRIPTION
    assert EC.classify_electrical_row(row) not in EC.ALARM_CLASSES


def test_long_name_with_empty_value_not_flagged():
    """v1 的 DAC37J84 实证：name 长但 value 空，是真参数名不是描述句。
    **name 长 ≠ Features 描述**。"""
    row = {"name": "Wideband Digital Quadrature Modulator Correction",
           "value": "", "unit": "", "condition": ""}
    assert EC.classify_electrical_row(row) not in EC.ALARM_CLASSES


def test_range_value_with_unit_is_real():
    row = {"name": "Chip enable recovery time", "value": "40~120",
           "unit": "ms", "condition": "tCER"}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


def test_negative_value_with_unit_is_real():
    row = {"name": "VIL", "value": "-0.3", "unit": "V", "condition": ""}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


# ── 必须报警（真阳性）───────────────────────────────────────────────────

def test_echo_name_is_flagged():
    """DAC37J84IAAV 的典型形态：value 就是 name 本身。"""
    row = {"name": "Sinx/x Correction Filters",
           "value": "Sinx/x Correction Filters", "unit": "", "condition": ""}
    assert EC.classify_electrical_row(row) == EC.ECHO_NAME


def test_echo_name_truncated_is_flagged():
    """value 是 name 的截断（模型输出被截），同样算回灌。"""
    row = {"name": "Independent Complex Mixers with 48-bit NCO",
           "value": "Independent Complex Mixers wit", "unit": "", "condition": ""}
    assert EC.classify_electrical_row(row) == EC.ECHO_NAME


def test_long_description_value_is_flagged():
    """value 是完整的描述句（长且无数字）→ Features 描述。"""
    row = {"name": "Feature", "unit": "", "condition": "",
           "value": "A high-performance low jitter PLL simplifies clocking "
                    "of the device without significant impact"}
    assert EC.classify_electrical_row(row) == EC.FEATURE_DESCRIPTION


# ── 证据不足不报警 ──────────────────────────────────────────────────────

def test_insufficient_evidence_no_alarm():
    row = {"name": "Supply switch-over voltage", "value": "VBC",
           "unit": "V", "condition": ""}
    # unit 是 V 但 value 无数字 → 不满足可测量特征；也不回灌、非长描述句
    assert EC.classify_electrical_row(row) == EC.INSUFFICIENT_EVIDENCE
    assert EC.classify_electrical_row(row) not in EC.ALARM_CLASSES


def test_non_dict_row_no_alarm():
    assert EC.classify_electrical_row("not a dict") == EC.INSUFFICIENT_EVIDENCE


# ── 可测量特征的边界 ────────────────────────────────────────────────────

def test_measurable_requires_non_blank_unit():
    row = {"name": "ICC", "value": "5", "unit": "not_specified"}
    assert EC.has_measurable_characteristics(row) is False


def test_measurable_requires_numeric_value():
    row = {"name": "ICC", "value": "typical", "unit": "mA"}
    assert EC.has_measurable_characteristics(row) is False


def test_measurable_ok():
    row = {"name": "ICC", "value": "5", "unit": "mA"}
    assert EC.has_measurable_characteristics(row) is True


# ── 已知盲区：固化当前行为，不是期望行为 ────────────────────────────────

def test_blindspot_fabricated_value_is_judged_real():
    """**已知盲区**：v1 的「无依据编数」会被判成 REAL_ELECTRICAL，抓不到。

    AFE4490RHAT v1 产物：`Power Dissipation = 2.3 mW`（PDF 真值 2.84 mW，
    但 p14 没进上下文，模型自己编了个像样的数）。这行有 unit、有数值、
    不回灌、非描述句 —— 本模块没有上下文可查，结构上识别不了。

    这条固化的是**当前行为**而非期望行为：将来若补上带上下文的编数检测，
    这条会失败，正好提醒你判据语义变了，需要同步更新文档与下游预期。
    """
    row = {"name": "Power Dissipation", "value": "2.3 mW", "unit": "mW",
           "condition": "at 3.0-V Supply"}
    assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


def test_blindspot_noise_params_also_judged_real():
    """同理：v1 的 `NFB = 1.2 nARMS`、`VO(shield) = 0.9 V` 也都漏网。"""
    for row in ({"name": "NFB", "value": "1.2 nARMS", "unit": "nARMS"},
                {"name": "I-V Amplifier, VO(shield)", "value": "0.9 V", "unit": "V"}):
        assert EC.classify_electrical_row(row) == EC.REAL_ELECTRICAL


# ── 整件审计 ────────────────────────────────────────────────────────────

def test_audit_returns_only_alarm_rows():
    doc = {"specs": {"electrical": [
        {"name": "Chip enable access time", "value": "70", "unit": "ns"},
        {"name": "Sinx/x Correction Filters",
         "value": "Sinx/x Correction Filters", "unit": ""},
        {"name": "VIL", "value": "-0.3", "unit": "V"},
    ]}}
    hits = EC.audit_electrical_rows(doc)
    assert len(hits) == 1
    assert hits[0]["index"] == 1
    assert hits[0]["sub_class"] == EC.ECHO_NAME


# ── 后处理过滤（worker/fixers.py::fix_elec_drop_feature）──────────────────

def _run_fixer(doc: dict, monkeypatch) -> tuple[dict, int, int]:
    """跑过滤 fixer，返回 `(结果, 剩余行数, 过滤行数)`。

    **必须用 monkeypatch 而不是直接赋值**：直接 `F.commit = ...` 会永久改掉
    模块属性，同批跑的 `tests/test_fixers.py` 会拿到这个假 commit 而整片失败
    （实测一次挂了 7 项）。monkeypatch 会在用例结束后自动回滚。
    """
    from worker import fixers as F
    calls: list = []
    monkeypatch.setattr(F, "commit", lambda ctx, changed: calls.append(changed))
    res = F.fix_elec_drop_feature({"doc": doc, "action": {}})
    n = len((doc.get("specs") or {}).get("electrical") or [])
    dropped = (doc.get("metadata") or {}).get("elec_dropped_features") or []
    return res, n, len(dropped)


def test_fixer_drops_echo_rows_and_keeps_evidence(monkeypatch):
    """DAC37J84 形态：回灌行被移出，dropped 明细留在 metadata。"""
    doc = {"specs": {"electrical": [
        {"name": "Sinx/x Correction Filters",
         "value": "Sinx/x Correction Filters", "unit": ""},
        {"name": "JTAG Boundary Scan", "value": "JTAG Boundary Scan", "unit": ""},
        {"name": "ICC", "value": "5", "unit": "mA"},
    ]}}
    _res, n, nd = _run_fixer(doc, monkeypatch)
    assert n == 1 and nd == 2
    assert doc["specs"]["electrical"][0]["name"] == "ICC"
    assert doc["metadata"]["elec_dropped_features"][0]["name"] == \
        "Sinx/x Correction Filters"


def test_fixer_does_not_touch_real_electrical(monkeypatch):
    """真参数（含 enable 这种"像 Features"的词）一律不过滤。"""
    doc = {"specs": {"electrical": [
        {"name": "Chip enable access time", "value": "70", "unit": "ns"},
        {"name": "Output enable to output valid", "value": "35", "unit": "ns"},
        {"name": "VIH", "value": "2.0", "unit": "V"},
    ]}}
    _res, n, nd = _run_fixer(doc, monkeypatch)
    assert n == 3 and nd == 0


def test_fixer_noop_when_nothing_to_drop(monkeypatch):
    doc = {"specs": {"electrical": [{"name": "ICC", "value": "5", "unit": "mA"}]}}
    res, n, nd = _run_fixer(doc, monkeypatch)
    assert n == 1 and nd == 0 and res["note"] == "no_echo_rows"


# ── 哨兵表 ──────────────────────────────────────────────────────────────

def test_sentinels_not_specified_is_blank_but_distinct():
    assert S.is_blank("not_specified") and S.is_not_specified("not_specified")
    assert S.is_blank("n/a") and not S.is_not_specified("n/a")


def test_sentinels_dashes_and_empty():
    for v in ("-", "—", "–", "", None):
        assert S.is_blank(v)


def test_sentinels_real_value_not_blank():
    assert not S.is_blank("5 mA")
    assert not S.is_blank("−0.3 to 3.63")
