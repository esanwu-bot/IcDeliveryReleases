"""阶段 B：parse 模型 A/B 测试脚本。

对比 qwen-flash（基线）vs qwen3.7-flash（实验组）在 50 件样本上的表现。
产物隔离保存到 data/parsed_abtest_<timestamp>/，不覆盖正式 data/parsed/。

用法：
    python ab_parse_test.py                    # 跑 50 件（默认）
    python ab_parse_test.py --sample 10        # 只跑 10 件冒烟
    python ab_parse_test.py --baseline qwen-flash --experiment qwen3.7-flash
"""
import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# 确保可以导入项目模块
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app.services import pipeline as PL
from app import config
import parse_datasheets as pd


def sha256(p: Path) -> str:
    """计算文件 SHA-256。"""
    import hashlib
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def select_samples(n: int) -> list[dict]:
    """从 data/parsed/ 选 n 件样本（优先已知问题件）。

    返回 [{"mpn": str, "pdf": Path, "sha256": str, "reason": str}, ...]
    """
    parsed_dir = ROOT / "data" / "parsed"
    pdfs_dir = ROOT / "data" / "pdfs"

    # 优先选的型号（已知问题或复杂器件）
    priority_mpns = [
        "BUF634PG4",       # 评估板误判
        "74LVC1G132DCKTG4", # 替代料功能误判
        "5962-9053801PA",   # 复杂逻辑
        "CDC6CE02x",        # 病态啰嗦
        "DAC8555IPWG4",     # 条件泄漏
        "AM26C32IDG4",      # 引脚表复杂
        "LM317",            # 经典器件
        "NE555",            # 经典器件
    ]

    samples = []
    seen = set()

    # 先加优先件
    for mpn_prefix in priority_mpns:
        if len(samples) >= n:
            break
        for jp in parsed_dir.glob(f"{mpn_prefix}*.json"):
            mpn = jp.stem.rsplit("_", 1)[0]
            if mpn in seen:
                continue
            # 找对应 PDF
            pdf_candidates = list(pdfs_dir.glob(f"{mpn}*.pdf"))
            if not pdf_candidates:
                continue
            pdf = pdf_candidates[0]
            samples.append({
                "mpn": mpn,
                "pdf": pdf,
                "sha256": sha256(pdf),
                "reason": f"priority:{mpn_prefix}",
            })
            seen.add(mpn)
            if len(samples) >= n:
                break

    # 补齐到 n 件
    if len(samples) < n:
        for jp in sorted(parsed_dir.glob("*.json")):
            if len(samples) >= n:
                break
            mpn = jp.stem.rsplit("_", 1)[0]
            if mpn in seen:
                continue
            pdf_candidates = list(pdfs_dir.glob(f"{mpn}*.pdf"))
            if not pdf_candidates:
                continue
            pdf = pdf_candidates[0]
            samples.append({
                "mpn": mpn,
                "pdf": pdf,
                "sha256": sha256(pdf),
                "reason": "random",
            })
            seen.add(mpn)

    return samples[:n]


def run_single(model: str, mpn: str, pdf: Path, out_dir: Path) -> dict:
    """用指定模型跑一件，返回结果 dict。"""
    # 临时设置模型
    orig_model = os.environ.get("ICPDF_MODEL_PARSE", "")
    os.environ["ICPDF_MODEL_PARSE"] = model

    try:
        t0 = time.perf_counter()
        rec = PL.parse_pdf(pdf, mpn)
        latency_ms = int((time.perf_counter() - t0) * 1000)

        # 提取关键指标
        llm_calls = rec.get("llm_calls", [])
        parse_calls = [c for c in llm_calls if c.get("stage") == "parse"]
        repair_calls = [c for c in llm_calls if c.get("stage") == "repair"]

        total_in = sum(c.get("usage", {}).get("prompt_tokens", 0) for c in parse_calls)
        total_out = sum(c.get("usage", {}).get("completion_tokens", 0) for c in parse_calls)
        truncated = any("truncat" in c.get("error", "").lower() for c in parse_calls)
        json_ok = rec.get("status") != "failed" and not rec.get("error", "").startswith("PARSE_FAILED")

        result = {
            "mpn": mpn,
            "model": model,
            "latency_ms": latency_ms,
            "status": rec.get("status"),
            "error": rec.get("error", ""),
            "json_ok": json_ok,
            "truncated": truncated,
            "parse_calls": len(parse_calls),
            "repair_calls": len(repair_calls),
            "input_tokens": total_in,
            "output_tokens": total_out,
            "llm_calls": llm_calls,
        }

        # 保存完整记录
        out_file = out_dir / f"{mpn}.json"
        out_file.write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")

        return result
    finally:
        # 恢复原环境变量
        if orig_model:
            os.environ["ICPDF_MODEL_PARSE"] = orig_model
        else:
            os.environ.pop("ICPDF_MODEL_PARSE", None)


def compute_cost(model: str, in_tokens: int, out_tokens: int) -> float:
    """按北京档价格算成本（元）。"""
    prices = {
        "qwen-flash": (0.15, 1.5),
        "qwen3.7-flash": (0.2, 0.8),
        "qwen3.8-flash": (0.8, 2.7),
        "qwen3.7-plus": (2.0, 8.0),
    }
    pin, pout = prices.get(model, (0.15, 1.5))
    return in_tokens * pin / 1e6 + out_tokens * pout / 1e6


def generate_report(results: list[dict], out_dir: Path) -> None:
    """生成对比报告。"""
    by_model = {}
    for r in results:
        m = r["model"]
        by_model.setdefault(m, []).append(r)

    report_lines = [
        "# Parse 模型 A/B 测试报告",
        "",
        f"- 生成时间：{datetime.now().isoformat(timespec='seconds')}",
        f"- 样本数：{len(results)}",
        f"- 输出目录：{out_dir}",
        "",
        "## 汇总指标",
        "",
        "| 指标 | 基线 | 实验组 |",
        "|---|---|---|",
    ]

    models = sorted(by_model.keys())
    if len(models) < 2:
        report_lines.append("| （不足两个模型） | — | — |")
    else:
        baseline = by_model[models[0]]
        experiment = by_model[models[1]]

        def stats(rs):
            n = len(rs)
            json_ok = sum(1 for r in rs if r["json_ok"])
            truncated = sum(1 for r in rs if r["truncated"])
            avg_in = sum(r["input_tokens"] for r in rs) / n if n else 0
            avg_out = sum(r["output_tokens"] for r in rs) / n if n else 0
            avg_lat = sum(r["latency_ms"] for r in rs) / n if n else 0
            total_cost = sum(compute_cost(r["model"], r["input_tokens"], r["output_tokens"]) for r in rs)
            return {
                "n": n,
                "json_ok": json_ok,
                "json_ok_pct": 100 * json_ok / n if n else 0,
                "truncated": truncated,
                "truncated_pct": 100 * truncated / n if n else 0,
                "avg_in": avg_in,
                "avg_out": avg_out,
                "avg_lat": avg_lat,
                "total_cost": total_cost,
            }

        b = stats(baseline)
        e = stats(experiment)

        report_lines.append(f"| 样本数 | {b['n']} | {e['n']} |")
        report_lines.append(f"| JSON 成功率 | {b['json_ok_pct']:.1f}% | {e['json_ok_pct']:.1f}% |")
        report_lines.append(f"| 截断率 | {b['truncated_pct']:.1f}% | {e['truncated_pct']:.1f}% |")
        report_lines.append(f"| 平均输入 token | {b['avg_in']:.0f} | {e['avg_in']:.0f} |")
        report_lines.append(f"| 平均输出 token | {b['avg_out']:.0f} | {e['avg_out']:.0f} |")
        report_lines.append(f"| 平均延迟 (ms) | {b['avg_lat']:.0f} | {e['avg_lat']:.0f} |")
        report_lines.append(f"| 总成本 (元) | ¥{b['total_cost']:.4f} | ¥{e['total_cost']:.4f} |")

    report_lines += [
        "",
        "## 逐件明细",
        "",
        "| 型号 | 模型 | JSON | 截断 | 输入 | 输出 | 延迟 | 成本 |",
        "|---|---|---|---|---|---|---|---|",
    ]

    for r in sorted(results, key=lambda x: (x["mpn"], x["model"])):
        cost = compute_cost(r["model"], r["input_tokens"], r["output_tokens"])
        report_lines.append(
            f"| {r['mpn']} | {r['model']} | {'OK' if r['json_ok'] else 'FAIL'} | "
            f"{'TRUNC' if r['truncated'] else '-'} | {r['input_tokens']} | "
            f"{r['output_tokens']} | {r['latency_ms']}ms | {cost:.6f} |"
        )

    report_lines += [
        "",
        "## 异常清单",
        "",
    ]

    anomalies = [r for r in results if not r["json_ok"] or r["truncated"]]
    if anomalies:
        for r in anomalies:
            report_lines.append(f"- **{r['mpn']}** ({r['model']}): {r['error'] or 'truncated'}")
    else:
        report_lines.append("（无异常）")

    report_text = "\n".join(report_lines)
    (out_dir / "report.md").write_text(report_text, encoding="utf-8")
    print(f"\n报告已写入 {out_dir / 'report.md'}")


def main():
    ap = argparse.ArgumentParser(description="Parse 模型 A/B 测试")
    ap.add_argument("--sample", type=int, default=50, help="样本数（默认 50）")
    ap.add_argument("--baseline", default="qwen-flash", help="基线模型（默认 qwen-flash）")
    ap.add_argument("--experiment", default="qwen3.7-flash", help="实验模型（默认 qwen3.7-flash）")
    args = ap.parse_args()

    # 创建输出目录
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = ROOT / "data" / f"parsed_abtest_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "baseline").mkdir()
    (out_dir / "experiment").mkdir()

    print(f"输出目录：{out_dir}")
    print(f"基线：{args.baseline}")
    print(f"实验：{args.experiment}")
    print(f"样本数：{args.sample}")

    # 选样本
    samples = select_samples(args.sample)
    print(f"\n已选 {len(samples)} 件样本")

    # 保存样本清单
    manifest = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "baseline": args.baseline,
        "experiment": args.experiment,
        "samples": [
            {"mpn": s["mpn"], "pdf": s["pdf"].name, "sha256": s["sha256"], "reason": s["reason"]}
            for s in samples
        ],
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    # 跑实验
    results = []
    for i, s in enumerate(samples, 1):
        print(f"\n[{i}/{len(samples)}] {s['mpn']}")
        print(f"  基线 {args.baseline}...", end=" ", flush=True)
        r_base = run_single(args.baseline, s["mpn"], s["pdf"], out_dir / "baseline")
        results.append(r_base)
        print(f"JSON={'OK' if r_base['json_ok'] else 'FAIL'} out={r_base['output_tokens']} {r_base['latency_ms']}ms")

        print(f"  实验 {args.experiment}...", end=" ", flush=True)
        r_exp = run_single(args.experiment, s["mpn"], s["pdf"], out_dir / "experiment")
        results.append(r_exp)
        print(f"JSON={'OK' if r_exp['json_ok'] else 'FAIL'} out={r_exp['output_tokens']} {r_exp['latency_ms']}ms")

    # 生成报告
    generate_report(results, out_dir)

    print(f"\n完成。产物保存在 {out_dir}")


if __name__ == "__main__":
    main()
