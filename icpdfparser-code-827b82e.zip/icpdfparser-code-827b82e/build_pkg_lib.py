#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""封装图库：按 package_type 批量预生成封装图 / 3D，全站型号共用。

为什么能共用
------------
封装图（俯视焊盘排布）只由**封装规格**决定，和具体型号无关：
TI 的 SOIC-16 和 ADI 的 SOIC-16 是同一套 JEDEC 尺寸，画出来一模一样。
所以不该每个型号各画一张，而是：

    598,891 个型号  →  去重后几百种 (族, 脚数)  →  每种生成一张 SVG  →  型号页引用

原理图符号不能共享——它带引脚名（AVDD / REFEN / GPIO2），是型号特有的。

三个子命令
----------
    --plan     从库里统计「现有型号需要哪些封装」，按型号数排序
    --preset   额外列出常见封装全集（不依赖已有型号，提前备好）
    --build    生成 data/pkgs/{KEY}.svg 与 {KEY}.3d.svg
    --report   覆盖率：多少型号能命中共享封装图

KEY 形如 `TSSOP-38` / `VQFN-64` / `FCBGA-144`，由 `symbol_svg.canon_pkg()` 归一。

用法
----
    python build_pkg_lib.py --plan
    python build_pkg_lib.py --build                 # 只生成库里有的
    python build_pkg_lib.py --build --preset        # 连常见封装一起备好
    python build_pkg_lib.py --report
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

import symbol_svg as S
from json_to_db import Db, resolve_dsn

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "data" / "pkgs"
PARSED = ROOT / "data" / "parsed"

# 常见封装全集：拿到百万型号之前先把这些备好，型号来了直接命中，不用等生成。
# 只列标准封装；板卡/模块类（PCB / BoosterPack）每块都不同，不预生成。
PRESET = {
    "SOIC": [8, 14, 16],
    "SOP": [8, 16],
    "SSOP": [16, 20, 28],
    "TSSOP": [8, 14, 16, 20, 24, 28, 38, 48, 56],
    "MSOP": [8, 10, 12, 16],
    "QFN": [16, 20, 24, 28, 32, 40, 48, 56, 64, 72],
    "VQFN": [16, 20, 24, 32, 40, 48, 64],
    "DFN": [6, 8, 10, 12],
    "VSON": [4, 6, 8, 10],
    "LQFP": [32, 44, 48, 64, 80, 100, 144],
    "TQFP": [32, 44, 48, 64, 80, 100],
    "BGA": [36, 49, 64, 100, 144, 196, 256, 324, 400],
    "FCBGA": [144, 256, 400, 484],
    "LGA": [16, 24, 28],
    "DIP": [8, 14, 16, 20, 28, 40],
    "SOT": [3, 5, 6, 23],          # 23 是 SOT-23 本体号，实际 3 脚，单独保留
}


def need_from_db(db: Db) -> list[dict]:
    """从库里统计：每个封装 key 被多少型号用到、样例型号是谁。"""
    db.ex("SELECT pkg_type, pkg_pins, mpn FROM doc WHERE pkg_type<>''")
    acc: dict[str, dict] = {}
    for pkg_type, pins, mpn in db.cur.fetchall():
        key = S.canon_pkg(pkg_type, int(pins or 0))
        fam = S.pkg_family(key)
        if fam == "other":                     # 板卡/模块不共享
            continue
        a = acc.setdefault(key, {"key": key, "family": fam, "pins": 0,
                                 "raw": set(), "models": []})
        a["pins"] = max(a["pins"], int(pins or 0))
        a["raw"].add(pkg_type)
        if len(a["models"]) < 4:
            a["models"].append(mpn)
    return _finalize(acc)


def _finalize(acc: dict[str, dict]) -> list[dict]:
    """把 {key: 累加器} 收敛成按 key 排好的列表。"""
    for a in acc.values():
        a["n_models"] = len(a["models"])
        a["raw"] = " | ".join(sorted(a["raw"]))
    return sorted(acc.values(), key=lambda x: (-x["n_models"], x["key"]))


def need_from_json() -> list[dict]:
    """不连库时，直接从 data/parsed/*.json 统计。"""
    acc: dict[str, dict] = {}
    for f in sorted(PARSED.glob("*.json")):
        doc = json.loads(f.read_text(encoding="utf-8"))
        pins = S.pins_of(doc)
        if not pins:
            continue
        pkg = S.package_of(doc, len(pins))
        declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
        key = S.canon_pkg(pkg, declared or len(pins))
        fam = S.pkg_family(key)
        if fam == "other":
            continue
        mpn = (doc.get("basic_info") or {}).get("mpn") or f.stem
        a = acc.setdefault(key, {"key": key, "family": fam, "pins": 0,
                                 "raw": set(), "models": []})
        a["pins"] = max(a["pins"], declared or len(pins))
        a["raw"].add(pkg)
        if len(a["models"]) < 4:
            a["models"].append(mpn)
    return _finalize(acc)


def preset_keys() -> list[dict]:
    out = []
    for fam, counts in PRESET.items():
        for n in counts:
            key = f"{fam}-{n}"
            out.append({"key": key, "family": S.pkg_family(key), "pins": n,
                        "n_models": 0, "raw": "(preset)", "models": []})
    return out


def fake_pins(n: int) -> list[tuple[int, str]]:
    """共享封装图只需要脚号，不需要引脚名——这正是它可以跨型号复用的原因。"""
    return [(i, "") for i in range(1, n + 1)]


def build(keys: list[dict], out: Path) -> tuple[int, int, list[str]]:
    """生成封装图 + 3D。返回 (成功, 失败, 失败明细)。"""
    out.mkdir(parents=True, exist_ok=True)
    ok = bad = 0
    errs: list[str] = []
    for it in keys:
        key, n, fam = it["key"], it["pins"], it["family"]
        if not n:
            errs.append(f"{key} 缺脚数，跳过")
            bad += 1
            continue
        pins = fake_pins(n)
        try:
            fp = S.footprint_svg(pins, key, n)
            md = S.model3d_svg(pins, key)
        except Exception as e:                          # 单个封装画挂了不该拖垮整批
            errs.append(f"{key} 生成异常：{e}")
            bad += 1
            continue
        # 回归校验：图上脚号必须和声明脚数一一对应
        err = S.verify_footprint(pins, key, n)
        if err:
            errs.append(f"{key} 校验失败：{err}")
            bad += 1
            continue
        (out / f"{key}.svg").write_text(fp, encoding="utf-8")
        (out / f"{key}.3d.svg").write_text(md, encoding="utf-8")
        ok += 1
    return ok, bad, errs


def write_index(keys: list[dict], out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    with (out / "index.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["key", "family", "pins", "n_models", "raw_types", "sample_models",
                    "footprint", "model3d"])
        for it in sorted(keys, key=lambda x: (x["family"], x["pins"], x["key"])):
            w.writerow([it["key"], it["family"], it["pins"], it["n_models"], it["raw"],
                        " / ".join(it["models"]),
                        f"{it['key']}.svg", f"{it['key']}.3d.svg"])


def write_wall(keys: list[dict], out: Path) -> Path:
    """生成 _index.html：所有封装图的「墙」，同目录相对引用，双击就能看全貌。"""
    out.mkdir(parents=True, exist_ok=True)
    by_fam: dict[str, list[dict]] = {}
    for it in keys:
        by_fam.setdefault(it["family"], []).append(it)
    order = {"dual": 0, "qfn": 1, "qfp": 2, "grid": 3, "sot": 4}
    blocks = []
    for fam in sorted(by_fam, key=lambda f: (order.get(f, 9), f)):
        items = sorted(by_fam[fam], key=lambda x: x["pins"])
        cards = []
        for it in items:
            note = f'{it["pins"]} 脚'
            if it.get("n_models"):
                note += f' · {it["n_models"]} 型号'
            cards.append(
                f'<div class="c"><div class="k">{it["key"]}</div>'
                f'<img src="{it["key"]}.svg" alt="{it["key"]} 封装图" loading="lazy" />'
                f'<img src="{it["key"]}.3d.svg" alt="{it["key"]} 3D" loading="lazy" />'
                f'<div class="n">{note}</div></div>')
        blocks.append(f'<h2>{fam} · {len(items)} 种</h2>'
                      f'<div class="g">{"".join(cards)}</div>')
    html = ('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
            "<title>封装图库</title><style>"
            "body{margin:0;padding:24px;background:#f4f6f8;"
            "font-family:-apple-system,'Segoe UI',Arial,sans-serif;color:#222}"
            "h1{font-size:18px;margin:0 0 4px}"
            "p.sub{color:#5b6673;font-size:13px;margin:0 0 20px}"
            "h2{font-size:14px;color:#5b6673;margin:26px 0 10px;font-weight:600}"
            ".g{display:flex;flex-wrap:wrap;gap:12px}"
            ".c{background:#fff;border:1px solid #e3e7ec;border-radius:8px;padding:8px;"
            "width:186px;text-align:center}"
            ".c img{width:80px;height:80px;vertical-align:middle}"
            ".k{font-size:12px;font-weight:600;margin-bottom:4px}"
            ".n{font-size:11px;color:#8a939c;margin-top:4px}"
            "</style></head><body>"
            f"<h1>封装图库 · {len(keys)} 种</h1>"
            '<p class="sub">按 package_type 归一后批量预生成。左为封装俯视，右为 3D 示意。'
            "全站同封装型号共用一张，不再逐型号生成。</p>"
            + "".join(blocks) + "</body></html>")
    p = out / "_index.html"
    p.write_text(html, encoding="utf-8")
    return p


def cmd_plan(keys: list[dict], extra: list[dict]) -> None:
    print(f"\n{'=' * 74}\n按封装统计（现有型号需要的）\n{'=' * 74}")
    if not keys:
        print("  库里没有封装数据，先跑 json_to_db.py --load")
        return
    print(f"{'封装 key':<14}{'族':<7}{'脚数':>5}{'型号数':>7}  原始写法 / 样例")
    for it in sorted(keys, key=lambda x: (-x["n_models"], x["key"])):
        print(f"{it['key']:<14}{it['family']:<7}{it['pins']:>5}{it['n_models']:>7}  "
              f"{it['raw'][:34]}  {' / '.join(it['models'][:2])}")

    # 一个型号写多个封装的（"64-VQFN or 64-LQFP"、"LQFP / HTQFP"）要提醒：现在只按第一个生成
    multi = [it for it in keys
             if re.search(r"\s+or\s+|\s*/\s*", it["raw"], re.I)]
    if multi:
        print("\n  ⚠️ 这些型号声明了多个封装，当前只按第一个生成（页面显示哪个取决于实际采购型号）：")
        for it in multi:
            print(f"     {it['key']:<12} ← {it['raw']}")

    if extra:
        print(f"\n{'=' * 74}\n常见封装全集（preset，提前备好）\n{'=' * 74}")
        print(f"  共 {len(extra)} 种，尚未生成")
        fams: dict[str, list[str]] = {}
        for it in extra:
            # 按封装名（VQFN/QFN/DFN…）分组，不能按 family——family 会把它们并成 qfn
            fams.setdefault(it["key"].split("-")[0], []).append(str(it["pins"]))
        for fam, ns in sorted(fams.items()):
            print(f"  {fam:<8} {', '.join(ns)}")
    print()


def cmd_report(keys: list[dict], out: Path, total_models: int) -> None:
    print(f"\n{'=' * 74}\n封装图库覆盖率\n{'=' * 74}")
    have = {p.stem for p in out.glob("*.svg") if not p.name.endswith(".3d.svg")} if out.exists() else set()
    print(f"  图库文件   {len(have)} 个 -> {out}")
    hit = [it for it in keys if it["key"] in have]
    miss = [it for it in keys if it["key"] not in have]
    n_hit = sum(it["n_models"] for it in hit)
    print(f"  型号覆盖   {n_hit}/{total_models} 个型号能命中共享封装图"
          f"（{n_hit / total_models * 100:.0f}%）" if total_models else "")
    if miss:
        print(f"\n  缺图（{len(miss)} 种）：")
        for it in sorted(miss, key=lambda x: -x["n_models"]):
            print(f"    {it['key']:<14} {it['family']:<7} {it['pins']:>4} 脚  "
                  f"{it['n_models']} 型号")
        print("\n  → 跑 --build 补上")
    else:
        print("  全部命中")
    print()


def main() -> int:
    ap = argparse.ArgumentParser(description="按 package_type 批量生成封装图库")
    ap.add_argument("--db", default="", help="mysql | sqlite | DSN；默认 mysql")
    ap.add_argument("--src", choices=["db", "json"], default="db", help="统计来源")
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--plan", action="store_true", help="只看要生成哪些")
    ap.add_argument("--preset", action="store_true", help="附带常见封装全集")
    ap.add_argument("--build", action="store_true", help="生成 SVG")
    ap.add_argument("--report", action="store_true", help="覆盖率")
    ap.add_argument("--all", action="store_true", help="一次跑完 plan + build + report")
    a = ap.parse_args()
    if a.all:
        a.plan = a.build = a.report = True
    if not any([a.plan, a.build, a.report]):
        ap.print_help()
        return 0

    out = Path(a.out)
    total = 0
    if a.src == "json":
        keys = need_from_json()
        total = len(list(PARSED.glob("*.json")))
    else:
        try:
            db = Db(resolve_dsn(a))
        except Exception as e:
            print(f"连不上库（{e}），改用 --src json 也能统计")
            return 1
        try:
            keys = need_from_db(db)
            db.ex("SELECT COUNT(*) FROM doc")
            total = db.cur.fetchone()[0]
        finally:
            db.close()

    extra = []
    if a.preset:
        existing = {k["key"] for k in keys}
        extra = [p for p in preset_keys() if p["key"] not in existing]

    if a.plan:
        cmd_plan(keys, extra)

    if a.build:
        target = keys + extra
        print(f"生成 {len(target)} 种封装图 -> {out}")
        ok, bad, errs = build(target, out)
        write_index(keys + extra, out)
        wall = write_wall(keys + extra, out)
        print(f"完成：成功 {ok} / 失败 {bad}")
        print(f"总览 -> {wall}")
        for e in errs[:10]:
            print(f"  ✗ {e}")
        print(f"索引 -> {out / 'index.csv'}")

    if a.report:
        cmd_report(keys, out, total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
