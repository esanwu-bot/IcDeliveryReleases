#!/usr/bin/env python
"""站内商品目录 → 内链索引（替代手写的 products.csv）。

输入：站点导出的 .xls（title / brand_name / link 三列，可能分多个 sheet）
输出：data/products.sqlite3（表 catalog：key 归一化料号 / mpn / brand / url）

    python build_product_index.py --src "E:/docs/Integrated Circuits (ICs).xls"
    python build_product_index.py --src ... --csv data/products.csv   # 同时导出 CSV

归一化口径与 alternatives.py 的 norm() 一致：只留字母数字并大写，
这样 AD8606ARMZ-R7 与站点 slug ad8606armzr7 天然对齐。
"""
from __future__ import annotations

import argparse
import csv
import re
import sqlite3
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "data" / "products.sqlite3"

DDL = """
DROP TABLE IF EXISTS catalog;
CREATE TABLE catalog (
    key  TEXT PRIMARY KEY,    -- 归一化料号（去非字母数字，大写）
    base TEXT,                -- 剥掉包装后缀，用于同族匹配
    mpn  TEXT,
    brand TEXT,
    url  TEXT
);
"""


PACK_SUFFIX = re.compile(
    r"(?:-?R[1-7]|-?RL-?|TR|CT|T&R|REEL|TAPE|BULK|TRAY|-?E2|-?E3|-?ND|-?DKR)$", re.I)


def norm(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def base_of(s: str) -> str:
    t = re.sub(r"\s+", "", (s or "").upper())
    prev = None
    while prev != t:
        prev = t
        t = PACK_SUFFIX.sub("", t)
    return norm(t)


def read_xls(path: Path):
    import xlrd
    bk = xlrd.open_workbook(str(path), on_demand=True)
    for name in bk.sheet_names():
        sh = bk.sheet_by_name(name)
        rows = sh.nrows
        start = 0
        # 首个 sheet 有表头；后续 sheet 直接是数据
        if rows and str(sh.cell_value(0, 0)).strip().lower() == "title":
            start = 1
        for r in range(start, rows):
            yield (str(sh.cell_value(r, 0)), str(sh.cell_value(r, 1)), str(sh.cell_value(r, 2)))
        bk.unload_sheet(name)


MYSQL_DDL = [
    """CREATE TABLE IF NOT EXISTS catalog (
        k      VARCHAR(64)  NOT NULL,          -- 归一化料号（= sqlite 的 key，MySQL 里 key 是保留字）
        base   VARCHAR(64)  NOT NULL DEFAULT '',
        mpn    VARCHAR(128) NOT NULL,
        brand  VARCHAR(128) NOT NULL DEFAULT '',
        url    VARCHAR(512) NOT NULL,
        PRIMARY KEY (k),
        KEY idx_base (base)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
]


def to_mysql(dsn: str, sqlite_db: Path, batch: int = 5000) -> None:
    """把已建好的 sqlite 目录灌进 MySQL（5.7 兼容，utf8mb4）。"""
    import pymysql

    p = dsn_parts(dsn)
    db = pymysql.connect(host=p["host"], port=p["port"], user=p["user"],
                         password=p["password"], charset="utf8mb4", autocommit=False,
                         local_infile=False)
    cur = db.cursor()
    cur.execute("CREATE DATABASE IF NOT EXISTS icpdf DEFAULT CHARSET utf8mb4 "
                "COLLATE utf8mb4_general_ci")
    cur.execute("USE icpdf")
    for stmt in MYSQL_DDL:
        cur.execute(stmt)
    db.commit()

    cur.execute("SELECT COUNT(*) FROM catalog")
    before = cur.fetchone()[0]
    cur.execute("TRUNCATE TABLE catalog")       # 全量重建，避免脏行残留
    db.commit()

    src = sqlite3.connect(f"file:{sqlite_db.as_posix()}?mode=ro", uri=True)
    t0, n = time.time(), 0
    cur.execute("SET unique_checks=0")
    while True:
        chunk = src.execute("SELECT key,base,mpn,brand,url FROM catalog LIMIT ? OFFSET ?",
                            (batch, n)).fetchall()
        if not chunk:
            break
        cur.executemany("INSERT INTO catalog (k,base,mpn,brand,url) VALUES (%s,%s,%s,%s,%s)",
                        chunk)
        db.commit()
        n += len(chunk)
        if n % 100000 == 0:
            print(f"  mysql {n} rows {time.time() - t0:.0f}s", flush=True)
    cur.execute("SET unique_checks=1")
    cur.execute("ANALYZE TABLE catalog")
    cur.execute("SELECT COUNT(*) FROM catalog")
    total = cur.fetchone()[0]
    print(f"mysql rows={total} (was {before}) {time.time() - t0:.1f}s -> icpdf.catalog")
    src.close()
    db.close()


def dsn_parts(dsn: str) -> dict:
    """mysql://root:root@127.0.0.1:3306/icpdf"""
    from urllib.parse import unquote, urlsplit
    u = urlsplit(dsn if "://" in dsn else "mysql://" + dsn)
    return {"host": u.hostname or "127.0.0.1", "port": u.port or 3306,
            "user": unquote(u.username or "root"), "password": unquote(u.password or "")}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="", help="站点导出的 xls/xlsx（title, brand_name, link）")
    ap.add_argument("--csv", default="", help="额外导出 CSV 路径")
    ap.add_argument("--to-mysql", nargs="?", const="mysql://root:root@127.0.0.1:3306/icpdf",
                    default="", metavar="DSN", help="把现有 sqlite 目录灌进 MySQL")
    a = ap.parse_args()

    if a.to_mysql:
        to_mysql(a.to_mysql, DB)
        return

    if not a.src:
        raise SystemExit("需要 --src，或用 --to-mysql 从现有 sqlite 导入")
    src = Path(a.src)
    if not src.exists():
        raise SystemExit(f"missing {src}")

    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.executescript("PRAGMA journal_mode=WAL; PRAGMA synchronous=OFF;" + DDL)

    t0, seen, rows, skipped = time.time(), set(), 0, 0
    batch = []

    def flush():
        con.executemany(
            "INSERT OR REPLACE INTO catalog (key,base,mpn,brand,url) VALUES (?,?,?,?,?)", batch)
        con.commit()
        batch.clear()

    for title, brand, link in read_xls(src):
        mpn = title.strip()
        url = link.strip()
        if not mpn or not url.lower().startswith("http"):
            skipped += 1
            continue
        k = norm(mpn)
        if not k or k in seen:
            skipped += 1
            continue
        seen.add(k)
        # 只保留相对路径，和站内 href 口径一致
        rel = url.split("in-fortune.com", 1)[1] if "in-fortune.com" in url else url
        batch.append((k, base_of(mpn), mpn, brand.strip(), rel))
        rows += 1
        if len(batch) >= 20000:
            flush()
    flush()

    con.executescript("CREATE INDEX IF NOT EXISTS idx_catalog_base ON catalog(base);")
    con.commit()
    total = con.execute("SELECT COUNT(*) FROM catalog").fetchone()[0]

    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["mpn", "url"])
            for mpn, url in con.execute("SELECT mpn,url FROM catalog ORDER BY mpn"):
                w.writerow([mpn, url])
        print(f"csv -> {a.csv}")

    print(f"rows={rows} unique={total} skipped={skipped} {time.time() - t0:.1f}s -> {DB}")
    con.close()


if __name__ == "__main__":
    main()
