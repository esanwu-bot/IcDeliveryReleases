<!-- next-task: issue=phase1-7-1-review sha=847d002848a6f8c1 at=2026-11-03T19:05:00Z mirror=- url=- -->

# 当前主任务：Phase 1.7.1 **待独立 Reviewer 终审**

> 架构 Agent 已完成 D1/D2/D3 与三件冻结样本复跑，**未批准** V2 生产灰度、
> **未生成** V3、未改 `release_status`。现在等独立复核，不再由实现方自证。

## 一、结论（实现方自述，仅供复核起点）

| 项 | 状态 | 提交 / 证据 |
|---|---|---|
| D1 确定性后处理接入 V2 | **PASS** | `27bdd02` + `88d023e`；`evidence/s1-lm317.json` |
| D2 LLM Usage 记账 | **PASS** | `4951c4b`；`evidence/d2-llm-usage.json` |
| D3 板卡字段级主体归属 | **PASS** | `35d4e62` + `9beeb7d`；`evidence/s2-ads8568evm-pdk.json` |
| 样本 1 LM317 | **PASS** | thermal 34 / 占位符 0 / pins 3 |
| 样本 2 ADS8568EVM-PDK | **PASS** | thermal 11 + esd 2 全 `onboard_device`；发布视图主容器 0/0 |
| 样本 3 DAC8568EVM | **PASS** | `skipped`，0 次模型调用、无 JSON |
| 生产零污染 | **PASS** | `data/parsed` 指纹复跑前后一致 |
| 本地测试 | **PASS** | 受影响面 205 passed + scope_contract 36 passed |

完整报告：`docs/qc/phase171/VERDICT.md`（含逐项测试输出、真实样本数值、风险与回滚）。

## 二、Reviewer 复核清单（建议按序）

1. **服务器同构复跑**：`docs/qc/phase17/harness/p17.sh` + `run_s1/s2/s3.sh`（`/tmp/p17`、
   Redis DB8、`icpdf/app:latest`）。重点：Fetch 幂等、五阶段接力、状态流转、异常短路、
   生产容器/数据零污染。本机只做了单件复跑与阶段单测，**这一步不能省**。
2. **追加一件真实板卡 UG 样本**：本轮 ADS8568EVM-PDK 的 PDF 是器件手册（SBAS543），
   `board_user_guide` 分支只有单测覆盖（建议 SBAU193E）。
3. **D3 发布视图抽查**：用 `qc.scope_contract.canonical_view` 渲染板卡件，确认板卡页
   不再出现芯片热阻/ESD；`board` 行仍在主容器；`ambiguous` 行进 `unresolved_specs`。
4. **D2 对账**：拿网关侧真实 usage 与 `llm_usage` 表逐条比对（模型 / prompt / completion /
   耗时 / attempt），确认重试与修复调用不漏记、不重复。
5. **D1 差异说明**：核对 `parse_pdf` 与 `parse_one` 的确定性调用顺序（校验 → 覆盖 →
   核心校验 → 重试 → 再覆盖），确认无复制判据。

## 三、禁止事项（本阶段）

- 不批准 V2 提升 / 扩大灰度；不生成 `delivery-batch20-eval-V3`；
- 不改 `release_status` 与人工签核；
- 不覆盖正式生产数据；不把 `PIPELINE_PASS` 升级为 `CONTENT_APPROVED` / `RELEASE_APPROVED`；
- 实现方在 Reviewer 出结论前不再改动 D1–D3 相关代码。

## 四、通过之后的顺序

1. Reviewer 出 `Phase 1.7.1 verdict`；
2. 8 件重新解析 → 重渲染（HTML/JSON/TXT/symbols）→ 更新 staging；
3. V3 打包 + 63 项自检 → 推发布仓库 → 触发 GitHub `[CMD]` 自动质审；
4. 处理新增 Issue，再走独立内容签核与发布批准。
