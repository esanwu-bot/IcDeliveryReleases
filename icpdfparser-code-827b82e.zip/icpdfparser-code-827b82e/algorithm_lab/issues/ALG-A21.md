# ALG-A21 · 两级表头合并

| 项 | 值 |
|---|---|
| 状态 | **RESOLVED_EXPERIMENTAL** |
| 立项日 | 2026-11-03 |
| 结项日 | 2026-11-03 |
| 提交 | `d9c57b8` `feat(table): A21 两级表头合并（choose_header 按列并两行，5/6 验收通过）` |
| 影响面 | `qc/table_audit.py` 表头规范化层（打分/门槛/资格判据未改） |
| 默认臂 | **v3**（`MATCH_V4=False`）。v4 仍 experimental，本轮**不切默认** |

---

## 1 问题

`74LVC1G132DCKTG4` 的真电气表（`p6/t0`，score 171）在 v4 资格闸门下被判 **False**，
整表出局，只剩 `p4`/`p5` 两张 50 分的供电电压表并列 → 该件 20 条参数从 `matched`
降级为 `ambiguous`。

**根因是两级表头**，不是打分也不是门槛：

```
row0 = PARAMETER | (空) | TEST CONDITIONS | V | –40°C to +85°C | … | UNIT
row1 = (空)      | (空) | (空)            | CC| MIN | TYP(1) | MAX | …
```

`choose_header` 读的是 `t.header.names`，PyMuPDF 只给 `row0`。数值角色
（MIN/TYP/MAX）全在 `row1`，于是 `header_roles` 全空 → `table_has_value_roles()`
判 False → 真表拿不到资格。

> 旁证：v3 在 74LVC 上的那些 `matched` 指向的是 `p4/p5` 供电电压表（score 50），
> 属于**错的 matched**。v4 把它们降级为 `ambiguous` 是变诚实，不是变差。

## 2 夹具核实（指令里的 "G6" 是笔误）

- `data/pdfs` 里**没有** `74LVC1G132DCKTG6`，被误杀的样本是 **G4**。
- `74LVC1G132DCKTG4__sn74lvc1g132.pdf`：1,182,185 B，SHA-256
  `FAE33D78FE46834AB99230AAA1106F58321F23CF06C65BE9CF08EA9C0DBCB623`
- `DBVRG4` / `DCKRG4` 与 G4 **同一份 PDF、同一 SHA** —— 三个封装号共用一份
  datasheet，**不是三个独立样本**。
- `DBVTG4__SN74LVC1G132_Dec.2013.pdf`：892,074 B，SHA-256
  `FCCF40853434F968CF106E2325DF423B5A4463172CB9FD590478A92AEA259E1C` = **第二份独立样本**。
  A21 后它也长出 level=2 表头（`p4/t0`，标题 `Electrical Characteristics`），
  `VT+` → `p4/t0`。独立样本同样受益。

## 3 代码位置

| 位置 | 作用 |
|---|---|
| `qc/table_audit.py:707` `_merge_two_level_header(top, second)` | **按列**合并紧邻两行：`'V'+'CC' → 'V CC'`、`'–40°C to +85°C'+'MIN' → '–40°C to +85°C MIN'`。MIN/TYP/MAX/UNIT 的**列下标不变**，不跨列继承、不猜 |
| `qc/table_audit.py:748-765` `choose_header()` | 触发条件：当前表头角色数 = 0 **且** 下一行角色数 ≥ 2 **且** 列数相等。命中后返回合并表头 + `rows[2:]` + `from_names=True` |
| `qc/table_audit.py:703-704` `HEADER_MERGE` | 开关，默认开；`ICPDF_HEADER_MERGE=0` 为回滚臂/红先演示臂 |
| `qc/table_audit.py:917-918` | 表 dict 新增 `header_source_rows`（`[0,1]`）与 `header_level_count`（2），供审计追溯 |

**纪律**：`table_has_value_roles()` 里**没有**加任何型号例外；打分、门槛、资格判据
一字未改。只在表头规范化层动。

## 4 红先测试

`tests/test_table_header_two_level.py`（**9 条**，全绿；`ICPDF_HEADER_MERGE=0` 时 3 条转红）：

| # | 用例 | 断言 |
|---|---|---|
| 1 | `test_two_level_header_merge_meta` | 合并元数据 `[0,1]` / level=2 + 角色 MIN/TYP/MAX + 角色列位置（第 4、7 列是 MIN） |
| 2 | `test_lvc_four_parameters_hit_p6` | VT+ / VT– / VOH / VOL 四条命中 `p6/t0` |
| 3 | `test_supply_tables_must_not_gain_roles` | **反例**：`p4/p5` 供电电压表不得因合并长出 TYP（它们本来只有 MIN/MAX） |
| 4 | `test_buf634_duplicate_tables_stay_ambiguous` | **反例**：BUF634 同分不同行的重复表保持 `table_tie`（移交 A22） |
| 5 | `test_regression_a19_fused_header_unchanged` | 回归：A19 融合表头原状 |
| 6 | `test_regression_a20_limits_unchanged` | 回归：A20 `Limits` 原状 |
| 7 | `test_regression_single_level_and_no_role_unchanged` | 回归：单级表头 / 无角色表原状 |
| 8 | `test_regression_switch_off_restores_old_behavior` | `ICPDF_HEADER_MERGE=0` 回到旧行为（红先臂） |
| 9 | `test_real_pdf_p6_now_eligible` | 真实 PDF 集成：`p6/t0` 合并后 `header_level_count=2` 且获得资格 |

### 4.1 过程中抓到的真回归（已修）

把 `from_names` 分支改成「只有 `off>0` 才下移 xr」时，`off==0` 的普通表被误清成
`xr=[]` / `hx=[]` → **A16 跨列校验整片关闭**。真实 PDF 用例
`tests/test_table_cell_num.py::TestIccRowRealPdf::test_icc_cell6_spans_min_and_max`
（"ICC 的 20 横亘 MIN/MAX，必须拒绝按 MIN 写盘"）当场变红，证明这道防线有效。
修法：`off==0` 保持 `xr_use = xr`、`hx = t.header.cells`。

## 5 A/B 结果（同 cohort：19 件 / 770 条）

| 臂 | matched | ambiguous | unmatched | foreign | patched | unresolved |
|---|---|---|---|---|---|---|
| v3 | 601 | 110 | 59 | 0 | 4 | 413 |
| **v4 (A21)** | **616** | **95** | **59** | 0 | **5** | **367** |

## 6 六条验收（5 绿 1 红）

| # | 标准 | 结果 |
|---|---|---|
| 1 | matched ≥ 601 | **616** ✓ |
| 2 | unmatched ≤ 59 | **59** ✓ |
| 3 | 74LVC 20 条全转 matched | **16/20**（4 条仍 ambiguous）✗ |
| 4 | BUF634 5 条仍 ambiguous | ✓（那 5 条保留；总 ambiguous 7 含 2 条 v3 本就 ambiguous） |
| 5 | 没有任何已知真表资格误杀 | ✓（unmatched 59 不变；剩余 4 条是**行级并列**，不是资格误杀） |
| 6 | 不许放宽判据 | ✓（只动表头合并；打分/门槛/资格判据未改） |

**第 3 条为什么差 4 条**：`VOH`/`VOL` 的真实行在 `p5/t1`（Operating Conditions），
但 `p4/t0`（Absolute Maximum Ratings）的 `VO Voltage range applied to any output…`
行同样命中（125 分）→ **表级并列**，`value_supported` 两边都能解释该值 → 按规则报
`table_tie`。这是**表型问题**，需要 A22 的「表型分权 / 跳过 absmax」裁决，
不在 A21 范围。

## 7 结项结论

- **状态 `RESOLVED_EXPERIMENTAL`**：代码已落地、红先全绿、方向性收益明确
  （matched 601→616、unresolved 413→367），但六条验收差一条，**不切默认**。
- v4 的 616 只是「进入人工核对」的门票，不是「可以上线」的结论。
- `write=True` 继续关闭。
- 后续动作：证据人工核对见 `docs/qc/A21_matched_evidence.md`（112 条）；
  剩余 4 条由 **ALG-A22** 承接。

## 8 质量指标三分（严禁混用）

| 指标 | 定义 | 当前值 |
|---|---|---|
| **Parse Recall** | PDF 原表有多少行被模型抽出来 | 52%（ADS42 53/102），单独立项，本轮不动 |
| **Table Match Precision** | 抽出来的行有多少落到正确的 PDF 表/行 | 见 112 条逐条证据，人工核对 |
| **Decision Coverage** | 多少条目得到明确判定 | v4 616 matched / 95 ambiguous / 59 unmatched（770） |
