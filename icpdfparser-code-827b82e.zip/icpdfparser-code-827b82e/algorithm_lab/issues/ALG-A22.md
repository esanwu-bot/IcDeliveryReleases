# ALG-A22 · Absolute Maximum Ratings 与 Operating Conditions 表型竞争

| 项 | 值 |
|---|---|
| 状态 | **A22-a 表型竞争：OPEN（仅立项）**；**A22-b 热阻多封装列塌缩：FIXED_LOCAL（2026-11-03）** |
| 立项日 | 2026-11-03 |
| 来源 | A21 六条验收第 3 条未过（`74LVC 20 条全转 matched` 实测 16/20）；A22-b 来自 DSH 质审 Issue #14 LM317 / #23 LM358 |
| 承接 | `ALG-A21.md`（两级表头合并，RESOLVED_EXPERIMENTAL） |
| 影响面 | A22-a：`qc/table_audit.py` 表选择层（表型分权）；A22-b：`parse_datasheets.py` 提示词 + `qc/deterministic_extract.py` + `qc/table_audit.py` 列塌缩判据 |

---

## 1 现象

`74LVC1G132DCKTG4` 在 A21 后仍有 **4 条**保持 `ambiguous`：

| 参数 | v3 | v4 (A21 后) | 期望 |
|---|---|---|---|
| `VOH High-level output voltage` | `matched(p4)` | `ambiguous_tie` | `matched(p5/t1)` |
| `VOH High-level output voltage` | `matched(p4)` | `ambiguous_tie` | `matched(p5/t1)` |
| `VOL Low-level output voltage` | `matched(p4)` | `ambiguous_tie` | `matched(p5/t1)` |
| `VOL Low-level output voltage` | `matched(p4)` | `ambiguous_tie` | `matched(p5/t1)` |

> 注意 v3 的 `matched(p4)` **本身就是错的**：p4 是 Absolute Maximum Ratings，
> 不是直流输出特性表。v4 把它降级为 `ambiguous` 是变诚实，不是变差。
> 真正的问题是「诚实之后没有能力选出正确的那张表」。

## 2 机理（表型竞争，不是行级判据问题）

| 表 | 页/表 | 命中行 | 分数 |
|---|---|---|---|
| `Absolute Maximum Ratings` | `p4/t0` | `VO Voltage range applied to any output …` | **125** |
| `Operating Conditions` / DC Characteristics | `p5/t1` | `VOH` / `VOL` 真实行 | 同量级 |

两张表分数并列 → `decide_table()` 无法单点胜出 → 报 `table_tie`；
`value_supported()` 在两边都能解释该值（absmax 的 VO 范围确实覆盖 VOH 数值），
所以**按现有规则必须报 ambiguous**。这是规则的正确行为，错的是「两张表同权」这件事。

**根因**：`_score_table()` 只看「表里有没有该参数名的行 / 数值能不能解释」，
**不看这张表在语义上是不是该参数的归属表**。Absolute Maximum Ratings 收的是
**极限值**（不得超越的边界），Operating Conditions 收的是**工作特性**（VOH/VOL 实测值）。
二者数值范围天然重叠，靠分数分不开。

## 3 红先要求（**先写测试，后改代码**）

任何实现前必须先有下面这些**当前会失败**的用例：

1. **正例**：`74LVC1G132DCKTG4` 的 `VOH` / `VOL` 四条必须解析到 `p5/t1`，
   **不得**落到 `p4/t0`。用真实 header/rows 构造，不用合成数据。
2. **反例（防矫枉过正）**：真正的 absmax 参数（`VO` 绝对范围、`Tj`、`Tstg`、
   `VIN` 极限）**不得**被推到 Operating Conditions。判据必须双向，否则只是把错
   从一边挪到另一边。
3. **反例（防白名单）**：不许出现按型号/MPN 的硬编码例外。判据必须落在**表型**
   （表标题语义 / 表所在页的上下文 / 参数族归属），不落在具体料号。
4. **不许放宽判据**：`value_supported()`、`table_has_value_roles()` 的口径不得放松；
   也不许把 `table_tie` 直接改判成「取第一个」。
5. **回归**：A21 的 `matched=616` 不得回退；`unmatched ≤ 59` 不得上升；
   BUF634 的 5 条重复表用例（`table_tie`）必须保持原状。

## 4 候选方案（仅记录，**未选型、未实现**）

| 方案 | 思路 | 风险 |
|---|---|---|
| A 表型分权 | `_score_table()` 给 absmax 表一个负向权重（如 ×0.6），只在**竞争**时生效 | 权重是拍的，需 A/B 证明不误伤真 absmax 参数 |
| B 候选集排除 | 参数族为「直流输出特性」时，把 absmax 表从候选集中剔除 | 参数族表需要维护，且 `VOH` 这类名字在不同厂命名不一 |
| C 表标题语义 | 从表标题/章节标题判表型（`Absolute Maximum` / `Operating Conditions`） | 依赖标题抽取质量，标题为空时退化 |
| D 双向约束 | absmax 只接受「极限语义」参数（`Max`/`Rating`/`Range` 关键词），DC 表只接受特性参数 | 关键词规则脆，容易误杀 |

选型必须由 A/B 数据决定（同 cohort 19 件 / 770 条），**不接受"看起来对"**。

## 5 本轮动作

**零代码改动。** 本文档只做立案与红先要求登记。A22 开工前需架构师确认：
① 选哪个方案方向；② 红先用例是否够（是否要补 BUF634 的重复表一并处理，
那是同一类"同分不同行"问题的另一个形态）。

## 6 与 A21 的边界

- A21 管**表头**（一行不够就并两行），A22 管**表型**（并完了还要选对表）。
- A21 的 5 绿 1 红结论不因 A22 立案而改变；A21 仍是 `RESOLVED_EXPERIMENTAL`。
- 在 A22 出结果前，v4 的 616 只能作为「进入人工核对」的门票，**不切默认**。

---

## 7 A22-b 落地：热阻多封装列塌缩 + RθJA 缺失（2026-11-03，Issue #14 / #23）

### 7.1 根因（两条，与 A22-a 的表型竞争无关）

1. **列塌缩是抽取器的机械缺陷，不是模型不听话。**
   旧 `deterministic_extract.extract_thermal()` 的算法是「遇到参数名后向下找第一个纯数值」，
   等于**只读第一列**。LM317 热阻表 4 列（DCY/KCS/KCT/KTT）、LM358 8 列
   （D/DGK/P/PS/PW/DDF/FK/JG），交付 JSON 只剩第一列，另外几列整列消失。
   更糟的是占位符 `NA` / `—` 被跳过：LM317 Legacy 的 `RθJC(bot)` DCY 列印 `NA`，
   0.1（KCS 列）被当成 DCY 的值 —— **静默错列**。
2. **`RθJA` 缺失是键写死，不是原文没有。**
   TI 新手册印 `Rθ(JA)`，旧实现用 `line in THERMAL_KEYS`（`RθJA`）直接比字符串，
   一条都匹配不上。LM317 p7 明明白白有 `Rθ(JA)` 行，页面却没有 RθJA。

### 7.2 改动

| 文件 | 改动 |
|---|---|
| `parse_datasheets.py` | 提示词新增 4d 补强（`Rθ(JA)` 与 `RθJA` 同项、RθJA 必抽）+ 4e/4f（多封装列逐列展开、condition 写列头原文、同名不同封装不是重复行） |
| `qc/deterministic_extract.py` | `thermal_package_columns()` 按文本行序读列定义（`findall` 一行多列、单字母码、引脚数对齐）；`extract_thermal()` 逐列展开、`condition` 写 `表名; 封装码 (封装名) 引脚数`、占位符占列不落行；`_thermal_norm` 让 `Rθ(JA)` == `RθJA`；脚注 `LM2904V(2)` 不得被读成 `V (2)` 列 |
| `qc/table_audit.py` | `package_columns()` + `audit_column_collapse()`：多封装表只取第一列且 condition 未写封装 → `column_collapse`（阻断）；结论写入 `metadata.column_collapse` 供事实表/隔离器消费 |
| `qc/collapse_quarantine.py` | 装配阶段把塌缩容器搬进 `specs.unresolved_column_collapse`（渲染层不认识该桶，宁可不印裸数字） |
| `qc/fact_acceptance.py` / `qc/stage_release.py` | 事实表新增 `column_collapse` 结论级（排在坐标证据之前）；主动扣下的容器按 `pass_with_quarantine` 处理，不误判成抽取失败 |
| `app/qa/controller.py` / `app/reviewers/qwen_reviewer.py` | 评审上下文补「同参数全部 JSON 行」；`coverage_line` 按原文数值个数与 condition 数判「展开 vs 塌缩」，避免修好后仍被误判 |
| `qc/finding_kinds.py` | 注册 `column_collapse`（TABLE_AUDIT_KINDS 25） |

### 7.3 本机验证（实测，不写「应该」）

| 件 | 抽取结果 | 关键值 | 列塌缩判据 |
|---|---|---|---|
| LM317（`SLVS044Z` p7） | **34 行**（Legacy 4 列 + New 2 列） | RθJA 6 条；`New Chip; KTT (TO-263) 3 PINS` RθJC(top)=**43.6**（Issue 原句要的那一列）；Legacy DCY RθJC(bot) 缺失、KCS=0.1 落在 KCS 列 | 真实 `find_tables` 认 4/2 列，`audit_column_collapse=[]` |
| LM358（`SLOS068AB` p5） | **42 行**（8 封装 × 5 + RθJC(bot) 2 条） | RθJA 8 条（124.7 / 181.4 / 80.9 / 116.9 / 171.7 / 164.3 / 84.0 / 112.4）；RθJC(bot) `FK (LCCC) 20 PINS`=**10.6**、`JG (CDIP) 8 PINS`=**22.3**（按 x 坐标 451/494 与列头 446/490 对齐） | `find_tables` 认 8 列，`audit_column_collapse=[]` |
| NE555（Issue #15 同根因） | **32 行**（6 封装 × 5 + RθJC(bot) 2 条） | 单字母码 `D`/`P` 不再丢列 | `find_tables` 认 6 列，`audit_column_collapse=[]` |

回归（只列本次跑过的）：
`tests/test_thermal_columns.py` 全绿（16 条合成 + 3 条真实 PDF）；
`tests/test_deterministic_extract.py` + `tests/test_qa_pipeline.py` 71 passed；
`tests/test_finding_kinds.py` 32 passed；
`tests/test_table_audit_*` / `tests/test_table_finding_page.py` 46 passed；
`tests/test_1102_fact_sync.py` + `tests/test_facts_review.py` 15 passed；
`tests/test_fact_acceptance_mpns.py` 2 passed。

### 7.4 边界与遗留

- **A22-b 不切默认、不写盘**：修复走「重解析 + 确定性抽取」，不重解人工校对件。
  `table_audit --write` 的 `locate_row_ignores_qualifier` 限制（§11.4）未被本改动绕过。
- **未做同 cohort A/B**：本机只验 3 件真实 PDF 与合成夹具；19 件 / 770 条灰度的
  matched/ambiguous 指标必须在下一轮实测后才能写进结论（§5.8 分母纪律）。
- **A22-a 表型竞争仍未落地**：`VOH`/`VOL` 落到 absmax 的表级并列问题保持 OPEN，
  与本节的列塌缩是两件事，不得因为 A22-b 变绿而误判 A22-a 已修。
