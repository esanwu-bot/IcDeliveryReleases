# GitHub Issue 同步索引

- 仓库：`esanwu-bot/IcDeliveryReleases`
- 过滤：标签 `qa-audit`，状态 `open`
- 最后同步：2026-11-03 08:09 UTC
- 件数：2

> 本文件由 `python -m app.integrations.github_issues sync` 生成，不要手工编辑。
> 逐件详情见同目录 `GH-*.md`。

| 编号 | 标题 | 状态 | 标签 | 更新 | 文件 |
|---|---|---|---|---|---|
| [#15](https://github.com/esanwu-bot/IcDeliveryReleases/issues/15) | [质审/P0] NE555 · 发现 9 项严重缺陷 | open | `qa-audit` `auto-generated` `severity:P0` | 2026-11-03 08:08 UTC | `GH-15-NE555-发现-9-项严重缺陷.md` |
| [#18](https://github.com/esanwu-bot/IcDeliveryReleases/issues/18) | [质审/P0] ADS1675REF · 发现 7 项严重缺陷 | open | `qa-audit` `auto-generated` `severity:P0` | 2026-11-03 08:08 UTC | `GH-18-ADS1675REF-发现-7-项严重缺陷.md` |

## 本地有、本次未返回

这些文件仍在目录里（**没有自动删除**）。原因可能是 issue 已关闭，
或者只是不再带该标签 —— 仍然是有价值的记录，删不删由人定：

- `GH-14-LM317-发现-12-项严重缺陷.md`
- `GH-16-质审自动化-delivery-batch20-eval-V2.md`
- `GH-17-质审自动化-delivery-batch20-eval-V2.md`
- `GH-19-ADS42JB49SEK-发现-7-项严重缺陷.md`
- `GH-20-CDC6CE025000ADLET-发现-5-项严重缺陷.md`
- `GH-21-CDC6CE025000ADLFR-发现-5-项严重缺陷.md`
- `GH-22-CDC6CE025000ADLYR-发现-5-项严重缺陷.md`
- `GH-23-LM358-发现-10-项严重缺陷.md`
