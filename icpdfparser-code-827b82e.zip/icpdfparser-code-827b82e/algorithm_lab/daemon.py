"""人机协同总线：`next_task.md` 一变，就把人叫醒。

定位
----
DSH 在服务器上跑质审、开单；`sync` + `next` 把最新一张 P0 单渲染成本地文件；
本模块只做最后一件事 —— **文件变了就通知人**。Trae 没有 CLI 送 prompt 的能力
（`trae-cn --help` 是原版 VS Code CLI，无 `--command`/`--chat`），所以这里走兜底：
复用窗口并定位到文件 → 全文进剪贴板 → Toast 提醒 → 人 Ctrl+V。

三条设计约束
------------
* **防抖 1.5s。** 一次保存会触发多个文件事件（写临时文件、替换、属性变化），
  不合并就会连弹三次 Toast。
* **sha 幂等。** `next` 在首行埋了 ``<!-- next-task: issue=N sha=… -->``。
  sha 没变就不叫醒人 —— 这是**防自唤醒死循环的最后一道**：日志写入、编辑器
  预览都可能再次触发事件，而这份文件本身也在被监听范围里。
* **红线：本模块不碰远端。** 全程没有推送动作，也不会强推远端分支。要建分支
  只能显式给 `--branch`，且只建 `fix/GH-<N>`、不做提交 —— 提交与 PR 由人决定。

用法
----
    pythonw algorithm_lab/daemon.py            # 常驻（开机自启用这个）
    python  algorithm_lab/daemon.py --once     # 处理当前文件后退出（调试）
    python  algorithm_lab/daemon.py --poll     # 没装 watchdog 时的轮询兜底
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
import tokenize
from logging.handlers import RotatingFileHandler
from pathlib import Path

#: 被监听的目标。相对仓库根，脚本自己也从这里推根目录。
DEFAULT_TASK = "algorithm_lab/next_task.md"
DEFAULT_LOG = "algorithm_lab/daemon.log"

#: 仓库根（本文件在 `<repo>/algorithm_lab/` 下）。
#: 开机自启时 `pythonw` 的 CWD 往往是 `system32`，相对路径按 CWD 解析必然指空，
#: 所以这里一律按仓库根解析 —— 否则守护进程会「正常启动、永远静默」。
_REPO_ROOT = Path(__file__).resolve().parent.parent


def _resolve(path: str | Path) -> Path:
    """相对路径按仓库根解析，绝对路径原样返回。"""
    p = Path(path)
    return p if p.is_absolute() else (_REPO_ROOT / p)
#: 一次保存往往连发好几个事件；1.5s 内只认最后一次。
DEBOUNCE_S = 1.5
#: 轮询兜底的间隔（watchdog 不可用时）。
POLL_S = 2.0
LOG_MAX_BYTES = 1024 * 1024
LOG_BACKUPS = 3

#: `next` 写的首行标记：`<!-- next-task: issue=23 sha=941ac41a1b97d1fd at=… -->`
_MARK = re.compile(r"next-task:\s*issue=(?P<issue>[\w-]+)\s+sha=(?P<sha>\w+)")

_TOAST_TITLE = "工单已就绪"
_TOAST_MSG = "请切到 Trae 粘贴（内容已在剪贴板）"


# ---------------------------------------------------------------- 读文件
def read_task(path: str | Path) -> dict:
    """读目标文件，返回 `{sha, issue, content, empty}`。

    sha 优先取首行标记里的值（`next` 算好的，与内容严格对应）；
    标记缺失（比如有人手写了别的文件）时退回按内容自算 —— 宁可多叫醒一次，
    也不要因为格式不同就彻底静默。
    """
    p = Path(path)
    if not p.is_file():
        return {"sha": "", "issue": "", "content": "", "empty": True}
    try:
        content = p.read_text(encoding="utf-8")
    except OSError:
        return {"sha": "", "issue": "", "content": "", "empty": True}
    first = content.splitlines()[0] if content else ""
    m = _MARK.search(first)
    sha = m.group("sha") if m else hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
    return {"sha": sha, "issue": (m.group("issue") if m else ""),
            "content": content, "empty": not content.strip()}


# ---------------------------------------------------------------- 系统动作
def copy_to_clipboard(text: str) -> bool:
    """把文本放进 Windows 剪贴板（CF_UNICODETEXT）。

    用 ctypes 而不是 `clip.exe`：`clip` 走控制台代码页，中文在 GBK 环境下会被
    替换成问号 —— 而这份内容恰恰全是中文。也不引入 pyperclip 这类新依赖，
    守护脚本要在开机自启里跑，依赖越少越好。
    """
    if os.name != "nt":
        return False
    try:
        import ctypes
        from ctypes import wintypes

        k32, u32 = ctypes.windll.kernel32, ctypes.windll.user32
        k32.GlobalAlloc.restype = wintypes.HGLOBAL
        k32.GlobalLock.restype = ctypes.c_void_p
        k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]

        if not u32.OpenClipboard(None):
            return False
        try:
            u32.EmptyClipboard()
            buf = ctypes.create_unicode_buffer(text)
            size = ctypes.sizeof(buf)
            handle = k32.GlobalAlloc(0x0002, size)      # GMEM_MOVEABLE
            if not handle:
                return False
            ptr = k32.GlobalLock(handle)
            ctypes.memmove(ptr, buf, size)
            k32.GlobalUnlock(handle)
            return bool(u32.SetClipboardData(13, handle))  # CF_UNICODETEXT
        finally:
            u32.CloseClipboard()
    except Exception:                                    # noqa: BLE001
        return False


def find_trae() -> str:
    """找 Trae CN 的 CLI 入口（`bin\\trae-cn.cmd`）。

    顺序：环境变量 `TRAE_CLI` → PATH → 常见安装位置。找不到就返回空串，
    调用方据此降级为「只弹 Toast + 剪贴板」，不因为没装 Trae 就整个守护失效。
    """
    for env in ("TRAE_CLI", "TRAE_CN_CLI"):
        v = os.environ.get(env)
        if v and Path(v).exists():
            return v
    for name in ("trae-cn.cmd", "trae-cn", "trae.cmd", "trae"):
        found = _which(name)
        if found:
            return found
    for base in (r"D:\Program Files (x86)\Trae CN", r"C:\Program Files\Trae CN",
                 os.path.expandvars(r"%LOCALAPPDATA%\Programs\Trae CN"),
                 os.path.expandvars(r"%LOCALAPPDATA%\Programs\Trae")):
        for name in ("trae-cn.cmd", "trae.cmd"):
            p = Path(base) / "bin" / name
            if p.exists():
                return str(p)
    return ""


def _which(name: str) -> str:
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if not d:
            continue
        p = Path(d) / name
        if p.exists():
            return str(p)
    return ""


def open_in_trae(cli: str, task_path: str | Path) -> bool:
    """复用窗口并定位到文件。失败只返回 False，不抛 —— 通知人这件事不能因为
    编辑器没起来就中断。"""
    if not cli:
        return False
    target = f"{Path(task_path).resolve()}:1"
    try:
        subprocess.Popen([cli, "-r", "-g", target],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return True
    except Exception:                                    # noqa: BLE001
        return False


def _ps_script() -> str:
    """Windows Toast 的 PowerShell 脚本。

    标题与正文从**环境变量**读，不拼进脚本字符串 —— 内容里全是中文和反引号，
    拼进去必然被 PowerShell 的引号/转义规则咬到。
    """
    return (
        "[Windows.UI.Notifications.ToastNotificationManager,"
        " Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null;"
        "$t = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent("
        "[Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
        "$x = $t.GetElementsByTagName('text');"
        "$x.Item(0).AppendChild($t.CreateTextNode($env:DSH_TOAST_TITLE)) | Out-Null;"
        "$x.Item(1).AppendChild($t.CreateTextNode($env:DSH_TOAST_MSG)) | Out-Null;"
        "$n = [Windows.UI.Notifications.ToastNotification]::new($t);"
        "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
        "'{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe'"
        ").Show($n);"
    )


def toast(title: str = _TOAST_TITLE, message: str = _TOAST_MSG) -> bool:
    """弹 Windows Toast。失败返回 False（调用方仍会写日志）。"""
    if os.name != "nt":
        return False
    env = dict(os.environ, DSH_TOAST_TITLE=title, DSH_TOAST_MSG=message)
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
             "-Command", _ps_script()],
            capture_output=True, timeout=20, env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode == 0
    except Exception:                                    # noqa: BLE001
        return False


# ---------------------------------------------------------------- 红线自检
#: 黑名单函数自身的函数名。它是整个文件里**唯一**允许拼出这些词的地方，
#: 所以扫描时要把它的函数体整段摘掉，否则它会自己命中自己。
_SELF_EXEMPT = ("_forbidden_ops",)


def _forbidden_ops() -> tuple[str, ...]:
    """本模块绝不能出现的远端写操作。

    拼写法是刻意的：源码里不留这些词的字面量（连 grep 都扫不到），单测直接扫
    源码断言这一点。如果哪天有人加了一行推送，`_redline_violation()` 会在启动
    时就把它拦下来，而不是等它把东西推上去之后才发现。
    """
    w = "pu" + "sh"
    # 每个词都拆成片段：这份清单本身也在被扫描的源码里，写全了就会自己命中自己。
    return (w, "--fo" + "rce", f"-f or" + "igin")


def _skip_lines(source: str) -> set[int]:
    """算出「不属于可执行代码」的行号：docstring 与黑名单函数的函数体。

    为什么不是全文件扫：注释和 docstring 里写「这里不推送」「别强推」是完全正常
    的说明，一律当违规等于逼人不敢写注释；真正危险的是**会被执行的代码**里出现
    远端写调用。
    """
    tree = ast.parse(source)
    skip: set[int] = set()

    def span(node) -> range:
        start = node.lineno
        end = getattr(node, "end_lineno", None) or start
        return range(start, end + 1)

    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            body = getattr(node, "body", None) or []
            if body and isinstance(body[0], ast.Expr) \
                    and isinstance(body[0].value, ast.Constant) \
                    and isinstance(body[0].value.value, str):
                skip |= set(span(body[0]))              # docstring 整段
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name in _SELF_EXEMPT:
            skip |= set(span(node))                     # 黑名单函数整段
    return skip


def _normalize(text: str) -> str:
    """把 `'pu' + 'sh'` 这类拆写还原成一个词。

    不做这一步，`"git", "pu" + "sh"` 就能绕过检查 —— 拆开写本来只是为了不让
    检查器命中自己，不能同时变成后门。引号、加号、空白全部去掉，统一小写。
    """
    return re.sub(r"[\s'\"]+|\+", "", text).lower()


def _executable_text(source: str) -> str:
    """只留会被执行的代码：剥掉注释、docstring、黑名单函数，其余原样拼回。"""
    skip = _skip_lines(source)
    parts: list[str] = []
    for tok in tokenize.generate_tokens(io.StringIO(source).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.start[0] in skip:
            continue
        parts.append(tok.string)
    return "".join(parts)


def _redline_violation(source: str | None = None) -> str:
    """扫自身可执行代码，返回命中的禁用操作（空串表示干净）。

    只看代码不看注释：注释里出现「不推送」是说明，代码里出现推送才是事故。
    源码语法都不成立时退回整段粗查 —— 宁可误报，也不放行一段读不懂的东西。
    """
    if source is None:
        try:
            source = Path(__file__).read_text(encoding="utf-8")
        except OSError:
            return ""
    try:
        body = _normalize(_executable_text(source))
    except (SyntaxError, tokenize.TokenError):
        body = _normalize(source)
    for bad in _forbidden_ops():
        if bad and _normalize(bad) in body:
            return bad
    return ""


# ---------------------------------------------------------------- 总线
class Bus:
    """把「文件变了」翻译成「叫醒人」，带防抖与 sha 幂等。

    参数全部可注入（`open_fn` / `notify_fn` / `schedule`），这样单测不需要
    真起编辑器、真弹 Toast、真等 1.5 秒。
    """

    def __init__(self, task_path: str | Path = DEFAULT_TASK, *,
                 debounce: float = DEBOUNCE_S,
                 trae_cli: str | None = None,
                 open_fn=None, clipboard_fn=None, toast_fn=None,
                 schedule=None, logger: logging.Logger | None = None,
                 branch: bool = False, repo: str | Path | None = None):
        self.task_path = Path(task_path)
        self.debounce = float(debounce)
        self.trae_cli = find_trae() if trae_cli is None else trae_cli
        self.open_fn = open_fn or (lambda cli, p: open_in_trae(cli, p))
        self.clipboard_fn = clipboard_fn or copy_to_clipboard
        self.toast_fn = toast_fn or toast
        self.schedule = schedule or self._timer
        self.log = logger or logging.getLogger("next-task-daemon")
        self.branch = branch
        self.repo = Path(repo or self.task_path.parent.parent)
        self.last_sha = ""
        self.fired = 0
        self._pending = None

    # -- 防抖 ------------------------------------------------------
    def _timer(self, delay: float, fn):
        t = threading.Timer(delay, fn)
        t.daemon = True
        t.start()
        return t

    def on_event(self) -> None:
        """收到一次文件事件：重置计时器，1.5s 内没有新事件才真正处理。"""
        if self._pending is not None and hasattr(self._pending, "cancel"):
            try:
                self._pending.cancel()
            except Exception:                            # noqa: BLE001
                pass
        self._pending = self.schedule(self.debounce, self.fire)

    # -- 真正处理 --------------------------------------------------
    def fire(self) -> dict:
        """读文件 → 比 sha → 决定要不要叫醒人。返回处理结果（供日志与单测）。"""
        task = read_task(self.task_path)
        if task["empty"]:
            self.log.info("目标文件不存在或为空，忽略")
            return {"action": "ignored", "reason": "empty"}
        if task["sha"] == self.last_sha:
            # 幂等：同一份内容不重复叫醒。这一步同时挡住了「日志写入触发事件 →
            # 又处理一次」和「编辑器打开文件触发事件」两种自激。
            self.log.debug("sha 未变（%s），忽略", task["sha"])
            return {"action": "ignored", "reason": "same-sha", "sha": task["sha"]}
        if task["issue"] == "none":
            # 没有待修工单时 next 会写「无」，这时候不该叫人起床。
            self.last_sha = task["sha"]
            self.log.info("没有待修工单（issue=none），不唤醒")
            return {"action": "ignored", "reason": "no-task", "sha": task["sha"]}

        self.last_sha = task["sha"]
        self.fired += 1
        copied = self.clipboard_fn(task["content"])
        opened = self.open_fn(self.trae_cli, self.task_path) if self.trae_cli else False
        title = _TOAST_TITLE
        msg = _TOAST_MSG if opened else f"{_TOAST_MSG}（没找到 Trae，请手动打开）"
        toasted = self.toast_fn(title, msg)
        branch_info = {}
        if self.branch and task["issue"].isdigit():
            branch_info = prepare_branch(self.repo, int(task["issue"]), logger=self.log)

        self.log.info("唤醒人：issue=%s sha=%s clipboard=%s trae=%s toast=%s",
                      task["issue"], task["sha"], copied, opened, toasted)
        return {"action": "notified", "sha": task["sha"], "issue": task["issue"],
                "clipboard": copied, "opened": opened, "toast": toasted,
                "branch": branch_info}

    # -- 轮询兜底 --------------------------------------------------
    def poll_once(self) -> dict:
        """不打事件、直接看内容是否变过（watchdog 不可用时的替代）。"""
        return self.fire()


def prepare_branch(repo: str | Path, number: int, *,
                   logger: logging.Logger | None = None) -> dict:
    """建（或复用）`fix/GH-<N>` 分支，然后**停手**。

    只做 `switch -c`，不提交、不推送 —— 改动内容与提交时机由人决定。
    任何失败都只记日志：分支建不出来不该影响「叫醒人」这件正事。
    """
    log = logger or logging.getLogger("next-task-daemon")
    name = f"fix/GH-{number}"
    try:
        cur = subprocess.run(["git", "-C", str(repo), "rev-parse", "--abbrev-ref", "HEAD"],
                             capture_output=True, text=True, timeout=15)
        if cur.returncode == 0 and cur.stdout.strip() == name:
            return {"branch": name, "created": False, "reason": "already-on"}
        r = subprocess.run(["git", "-C", str(repo), "switch", "-c", name],
                           capture_output=True, text=True, timeout=30)
        ok = r.returncode == 0
        log.info("分支 %s：%s", name, "已创建" if ok else f"失败 {(r.stderr or '').strip()[:120]}")
        return {"branch": name, "created": ok,
                "reason": "" if ok else (r.stderr or "").strip()[:200]}
    except Exception as e:                               # noqa: BLE001
        log.warning("建分支失败（忽略）：%s", e)
        return {"branch": name, "created": False, "reason": str(e)[:200]}


# ---------------------------------------------------------------- 运行模式
def setup_logging(log_path: str | Path = DEFAULT_LOG, *, verbose: bool = False) -> logging.Logger:
    log = logging.getLogger("next-task-daemon")
    if log.handlers:                                     # 重复 setup 不叠加 handler
        return log
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    h = RotatingFileHandler(log_path, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUPS,
                            encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(h)
    return log


def run_watch(bus: Bus, task_path: str | Path) -> int:
    """watchdog 常驻：只监听目标文件的改动事件。"""
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError:
        bus.log.error("没装 watchdog（pip install watchdog），退化为轮询模式")
        return run_poll(bus)

    class Handler(FileSystemEventHandler):
        def on_any_event(self, event):                   # noqa: D102
            if getattr(event, "is_directory", False):
                return
            if Path(getattr(event, "src_path", "")).name == Path(task_path).name:
                bus.on_event()

    obs = Observer()
    obs.schedule(Handler(), str(Path(task_path).resolve().parent), recursive=False)
    obs.start()
    bus.log.info("开始监听 %s（防抖 %.1fs，Trae=%s）", task_path, bus.debounce,
                 bus.trae_cli or "未找到")
    try:
        while True:
            time.sleep(1.0)
    except KeyboardInterrupt:
        bus.log.info("收到中断，退出")
    finally:
        obs.stop()
        obs.join(timeout=5)
    return 0


def run_poll(bus: Bus, interval: float = POLL_S) -> int:
    """没有 watchdog 时的兜底：按间隔看内容 sha 有没有变。"""
    bus.log.info("轮询模式，每 %.1fs 检查一次 %s", interval, bus.task_path)
    try:
        while True:
            bus.poll_once()
            time.sleep(interval)
    except KeyboardInterrupt:
        bus.log.info("收到中断，退出")
    return 0


def main(argv: list[str] | None = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                    # noqa: BLE001
        pass
    ap = argparse.ArgumentParser(
        prog="daemon.py", description="监听 next_task.md，变了就叫醒人（不碰远端）")
    ap.add_argument("--task", default=DEFAULT_TASK, help=f"监听的文件（默认 {DEFAULT_TASK}）")
    ap.add_argument("--log", default=DEFAULT_LOG, help=f"日志文件（默认 {DEFAULT_LOG}）")
    ap.add_argument("--debounce", type=float, default=DEBOUNCE_S, help="防抖秒数（默认 1.5）")
    ap.add_argument("--once", action="store_true", help="处理当前文件后退出（调试用）")
    ap.add_argument("--poll", action="store_true", help="强制轮询模式（不依赖 watchdog）")
    ap.add_argument("--interval", type=float, default=POLL_S, help="轮询间隔秒数")
    ap.add_argument("--branch", action="store_true",
                    help="顺带建 fix/GH-<N> 分支（只建分支，不提交、不推送）")
    ap.add_argument("--no-toast", action="store_true", help="不弹 Toast（只写日志/剪贴板）")
    ap.add_argument("--dry-run", action="store_true",
                    help="只打印会做什么，不真的开窗口/写剪贴板/弹窗")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args(argv)

    bad = _redline_violation()
    if bad:
        print(f"拒绝启动：源码里出现被禁止的远端写操作 {bad!r}", file=sys.stderr)
        return 3

    log = setup_logging(_resolve(a.log), verbose=a.verbose)
    task_path = _resolve(a.task)
    bus = Bus(task_path, debounce=a.debounce, logger=log, branch=a.branch,
              repo=task_path.parent.parent)
    if a.dry_run:
        bus.open_fn = lambda cli, p: (log.info("dry-run：会打开 %s", p), True)[1]
        bus.clipboard_fn = lambda text: (log.info("dry-run：剪贴板 %d 字符", len(text)), True)[1]
        bus.toast_fn = lambda t, m: (log.info("dry-run：Toast %r / %r", t, m), True)[1]
    elif a.no_toast:
        bus.toast_fn = lambda t, m: False

    if a.once:
        res = bus.poll_once()
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if a.poll:
        return run_poll(bus, a.interval)
    return run_watch(bus, a.task)


if __name__ == "__main__":
    raise SystemExit(main())
