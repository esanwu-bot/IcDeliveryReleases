# Phase 1.7.1 · Reviewer 扁平材料

- 生成时间：2026-11-03T19:47:12+08:00
- 当前 HEAD：`e23751b`
- D3 消费端基线：`9beeb7d`
- 说明：本文件把 Reviewer 点名的 5 组材料**原样抽取并合并**，每段均用代码块包裹。
  仓库内没有独立 worker `.log` 文件；第 3 组给出 `docs/qc/phase171/evidence/` 下
  三件样本的实跑 JSON、测试输出与渲染消费端证据原文。

---

## 1. D3 消费端 Diff：`git show 9beeb7d`（完整输出）

```diff
commit 9beeb7d082095fa1adc438701d2f4b5580c32897
Author: esan <esan.wu@gmail.com>
Date:   Tue Nov 3 19:12:30 2026 +0800

    fix(identity): D3 发布视图按行级 subject 隔离 thermal/esd（消费端闭环）
    
    Phase 1.7.1 验收发现：`identity_scope` 给 board 件的 thermal/esd 标了
    `subject`/`subject_source`，但 `canonical_view` 的契约只认 `scope`/`device_scope`，
    且分桶只处理 electrical/absolute_max —— 标注**没有下游消费者**，渲染层照旧把
    芯片热阻当板级规格印在板卡页上。
    
    - `qc/scope_contract.py`：`_row_scope()` 把行级 `subject` 计入 scope 证据
      （`ambiguous` 经 normalize 落 unresolved）；`canonical_view()` 的按行分桶
      扩到 `thermal` / `esd`，与 `electrical` / `absolute_max` 同口径。
      只搬**证据指向 onboard_device** 的行；`subject=board` 的整板参数保留主容器；
      判不出主体的行进 `unresolved_specs` 等人工，不做自动归属。
    - 测试：D3 的 `test_device_datasheet_rows_...` 口径修正为「标 onboard_device
      **且**归入隔离桶」；新增发布视图三向用例（板载隔离 / 整板保留 / ambiguous 归档）。
    - D1 补一条五阶段链路证明：`stage_llm` 不传 `llm_fn` 时走默认
      `PLATFORM.parse_pdf`，落盘 JSON 必带 `metadata.deterministic_extract`（34 行）。
    
    回归：pipeline_stages + phase171 D1/D2/D3 + board/identity/scope + thermal
    夹具 **205 passed**；`tests/test_scope_contract.py` **36 passed**。

diff --git a/qc/scope_contract.py b/qc/scope_contract.py
index b472ab6..b0ca827 100644
--- a/qc/scope_contract.py
+++ b/qc/scope_contract.py
@@ -72,6 +72,13 @@ def _row_scope(row: dict, default: str, requested: str) -> tuple[str, str, bool]
     scopes = [row[k] for k in ("scope", "device_scope") if k in row]
     if "scope" in source:
         scopes.append(source["scope"])
+    # Phase 1.7.1 D3：`identity_scope` 给 thermal/esd 行标的 `subject` 是**行级
+    # 主体证据**（onboard_device / board / ambiguous）。契约必须认它 —— 否则
+    # 标注只写进 JSON、发布视图照样把芯片热阻当板级规格渲染（consumers 读的是
+    # canonical_view，不是原 doc）。`ambiguous` 经 normalize_scope 落 unresolved。
+    subj = str(row.get("subject") or "").strip()
+    if subj:
+        scopes.append(subj)
     normalized = {normalize_scope(v) for v in scopes}
     conflict = len(normalized) > 1
     scope = next(iter(normalized)) if len(normalized) == 1 else (
@@ -240,7 +247,9 @@ def canonical_view(doc: dict) -> dict:
         merge_quarantined(target, key, value)
 
     main_allowed = known and ((identity in BOARD_TYPES and scope == "board") or (identity in ("chip", "device") and scope == "device"))
-    for key in ("electrical", "absolute_max"):
+    # `thermal` / `esd` 与 `electrical` / `absolute_max` 同口径：板卡件里
+    # 判成 onboard_device 的行不能留在主容器（Phase 1.7.1 D3 的消费端闭环）。
+    for key in ("electrical", "absolute_max", "thermal", "esd"):
         rows = specs.get(key) or []
         keep = []
         if not isinstance(rows, list):
diff --git a/tests/test_phase171_d1_deterministic.py b/tests/test_phase171_d1_deterministic.py
index e9e0d87..bcf490e 100644
--- a/tests/test_phase171_d1_deterministic.py
+++ b/tests/test_phase171_d1_deterministic.py
@@ -118,10 +118,9 @@ def _pin_key(rows):
 def test_v2_parse_pdf_applies_deterministic(monkeypatch, tmp_path):
     """V2 落盘后：热阻 34 行、占位符不落行（否则就是 Phase 1.7 的 D1）。
 
-    **引脚不在此断言**：LM317 的引脚表是 `PIN | FUNCTION` 两列，不在
-    `extract_pins` 认的 `NAME | NO.` 布局里（实测 `extract_pins=0`），
-    所以「3 vs 4」是模型方差，不是确定性差异。引脚一致性由下面
-    `test_v2_and_legacy_deterministic_agree` 用同一份模型输出验证。
+    引脚：D4 之前 `extract_pins` 不认 LM317 的 `PIN | FUNCTION` 布局，模型给
+    4 条会原样保留；D4 之后确定性层把它改成 3 条（ADJUST/INPUT/OUTPUT）。
+    本用例同时守住这条覆盖关系：`deterministic_extract.pins` 必须是 4→3。
     """
     rec = _v2_run(monkeypatch, tmp_path)
     assert rec["status"] == "ok", rec.get("error")
@@ -130,11 +129,12 @@ def test_v2_parse_pdf_applies_deterministic(monkeypatch, tmp_path):
     assert len(thermal) == 34, f"实得 {len(thermal)} 行（模型原样是 36）"
     assert not [r for r in thermal
                 if str(r.get("value")).strip().upper() in DE._PLACEHOLDERS]
+    assert len(doc["pin_configuration"]) == 3
     # 记录可审计：走了哪条确定性路径、从多少行改到多少行
     det = (doc.get("metadata") or {}).get("deterministic_extract") or {}
     assert det.get("thermal", {}).get("to") == 34, det
     assert det.get("thermal", {}).get("from") == 7, det
-    assert "pins" not in det, "LM317 的引脚表不在 extract_pins 覆盖范围，不该有 deterministic 改写"
+    assert det.get("pins") == {"from": 4, "to": 3, "method": "deterministic"}, det
 
 
 def test_repair_retry_keeps_deterministic_metadata(monkeypatch, tmp_path):
@@ -188,6 +188,32 @@ def test_apply_deterministic_is_idempotent():
     assert len(doc["specs"]["thermal"]) == 34
 
 
+def test_stage_llm_default_path_lands_deterministic(tmp_path, monkeypatch):
+    """五阶段路径的补证：`stage_llm` **不传 llm_fn** 时走默认 `PLATFORM.parse_pdf`。
+
+    D1 的验收第 5 条要求「证明五阶段实际调用了该函数，而不只是单测直调」：
+    这里从阶段层进入（`Ctx` + 真实切片），让默认实现自己跑，落盘 JSON 必须带
+    `metadata.deterministic_extract`（thermal 从模型原样 7 行改成 34 行）。
+    """
+    from app.pipeline import preprocess as PP
+    from app.pipeline import stages as S
+    from app.pipeline.stage_state import StageStateStore
+    import parse_datasheets as pd
+
+    slc, _ = PP.load_or_build(PDF, "LM317", root=tmp_path / "slices", pd_module=pd)
+    _stub_chat(monkeypatch)
+    with StageStateStore(tmp_path / "s.sqlite3") as st:
+        ctx = S.Ctx(mpn="LM317", mpn_key="lm317", pdf_path=PDF,
+                    pdf_sha256=slc.pdf_sha256, slice=slc,
+                    out_dir=tmp_path / "out", state=st)
+        r = S.stage_llm(ctx, pd_module=pd)          # 不给 llm_fn → 默认 parse_pdf
+    assert r.status == "ok", (r.status, r.error)
+    doc = json.loads(Path(r.artifact).read_text(encoding="utf-8"))
+    assert len(doc["specs"]["thermal"]) == 34
+    det = (doc.get("metadata") or {}).get("deterministic_extract") or {}
+    assert det.get("thermal", {}).get("to") == 34, det
+
+
 def test_placeholder_edges_are_consistent():
     """`NA`/`—` 不落行；KCS 的 0.1 不许冒充 DCY。
 
diff --git a/tests/test_phase171_d3_subject.py b/tests/test_phase171_d3_subject.py
index 4a178b0..a923d03 100644
--- a/tests/test_phase171_d3_subject.py
+++ b/tests/test_phase171_d3_subject.py
@@ -24,6 +24,7 @@ if str(ROOT) not in sys.path:
     sys.path.insert(0, str(ROOT))
 
 from qc import identity_scope as IS                             # noqa: E402
+from qc import scope_contract as SC                             # noqa: E402
 
 THERMAL = [
     {"name": "RθJA", "value": "42.9", "unit": "°C/W", "condition": "64-Pin VQFN"},
@@ -52,7 +53,13 @@ def _board_doc() -> dict:
 
 
 def test_device_datasheet_rows_are_marked_onboard_device():
-    """器件手册来源：thermal/esd 每一行都是 onboard_device，且**没有被搬走**。"""
+    """器件手册来源：thermal/esd 每一行标 onboard_device，并归入隔离桶。
+
+    2026-11-03 验收口径修正：原用例断言「不搬容器」只覆盖标注层，会让芯片热阻
+    继续留在板卡主容器（渲染层读 `canonical_view`，照样当板级规格印出去）。
+    正确契约是**按行证据搬**：`subject=onboard_device` → `onboard_device_specs`；
+    `subject=board` 的整板参数仍留在主容器（见发布视图用例）。
+    """
     doc = _board_doc()
     rec = IS.apply(doc, "ADS8568EVM-PDK",
                    pdf_text=("ADS8568EVM-PDK Evaluation Module\n"
@@ -60,9 +67,12 @@ def test_device_datasheet_rows_are_marked_onboard_device():
                    pdf_path="data/pdfs/ADS8568EVM-PDK__sbas543c.pdf")
     assert rec["identity"] == "evaluation_board", rec
     assert doc["basic_info"]["document_scope"] == "onboard_device_datasheet", rec
-    assert len(doc["specs"]["thermal"]) == len(THERMAL), "D3 不允许整体搬容器"
-    assert len(doc["specs"]["esd"]) == len(ESD)
-    for row in doc["specs"]["thermal"] + doc["specs"]["esd"]:
+    assert doc["specs"]["thermal"] == [], "芯片热阻不许留在板卡主容器"
+    assert doc["specs"]["esd"] == []
+    ods = doc["specs"]["onboard_device_specs"]
+    assert len(ods["thermal"]) == len(THERMAL), "芯片热阻必须归入 onboard_device"
+    assert len(ods["esd"]) == len(ESD)
+    for row in ods["thermal"] + ods["esd"]:
         assert row["subject"] == "onboard_device", row
         assert row["subject_source"] == "onboard_device_datasheet", row
         assert "subject_review" not in row
@@ -114,3 +124,65 @@ def test_chip_docs_are_not_stamped():
     assert rec["identity"] == "chip", rec
     assert "subject" not in doc["specs"]["thermal"][0]
     assert "subject_summary" not in doc["specs"]
+
+
+# ---------------------------------------------------------------- 发布视图闭环
+def _board_view_doc(scope: str, subject: str) -> dict:
+    """最小板卡 doc：主容器直接放 thermal/esd，行级 `subject` 是唯一证据。"""
+    rows = copy.deepcopy(THERMAL)
+    esd = copy.deepcopy(ESD)
+    for r in rows + esd:
+        r["subject"] = subject
+        r["subject_source"] = "board_user_guide" if subject == "board" else scope
+    return {
+        "basic_info": {"mpn": "ADS8568EVM-PDK", "manufacturer": "Texas Instruments",
+                       "identity": "evaluation_board", "device_mpn": "ADS8568"},
+        "specs": {
+            "scope": scope,
+            "electrical": [], "absolute_max": [],
+            "thermal": rows, "esd": esd,
+            "package": {"type": "Evaluation Board", "pins": 0,
+                        "onboard_device": "ADS8568"},
+            "temperature": {"operating": "not_specified", "storage": "not_specified"},
+        },
+        "pin_configuration": [], "ordering_info": [], "metadata": {},
+    }
+
+
+def test_publication_view_isolates_onboard_thermal_esd():
+    """发布视图必须把 `subject=onboard_device` 的 thermal/esd 搬出主容器。
+
+    这是 Phase 1.7.1 D3 的**消费端**验收：只标注不搬，板卡页仍会把芯片热阻
+    当板级规格渲染（渲染层读的是 `canonical_view`，不是原 doc）。
+    """
+    doc = _board_doc()
+    IS.apply(doc, "ADS8568EVM-PDK",
+             pdf_text=("ADS8568EVM-PDK Evaluation Module\n"
+                       "The ADS8568 is an 8-channel, 16-bit simultaneous-sampling ADC."),
+             pdf_path="data/pdfs/ADS8568EVM-PDK__sbas543c.pdf")
+    view = SC.canonical_view(doc)
+    assert view["specs"]["thermal"] == [], "芯片热阻仍留在板卡主容器"
+    assert view["specs"]["esd"] == []
+    ods = view["specs"]["onboard_device_specs"]
+    assert len(ods["thermal"]) == len(THERMAL)
+    assert len(ods["esd"]) == len(ESD)
+    assert {r["subject"] for r in ods["thermal"]} == {"onboard_device"}
+    assert ods["device_mpn"] == "ADS8568"
+
+
+def test_publication_view_keeps_board_level_thermal():
+    """`subject=board` 的整板参数必须留在主容器 —— 不许一刀切搬走。"""
+    doc = _board_view_doc("board", "board")
+    view = SC.canonical_view(doc)
+    assert len(view["specs"]["thermal"]) == len(THERMAL)
+    assert len(view["specs"]["esd"]) == len(ESD)
+
+
+def test_publication_view_archives_ambiguous_rows():
+    """主体判不出的行进 `unresolved_specs`（待人工），不许当成板级规格发布。"""
+    doc = _board_view_doc("board", "ambiguous")
+    view = SC.canonical_view(doc)
+    assert view["specs"]["thermal"] == []
+    unresolved = view["specs"]["unresolved_specs"]
+    assert len(unresolved["thermal"]) == len(THERMAL)
+    assert unresolved["scope"] == "unresolved"
```

---

## 2. 复跑器代码：`docs/qc/phase171/run_samples.py`（完整源码）

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.7.1 三件冻结样本复跑器（本地、隔离写入、生产零污染）。

样本（与原冻结单一致，不改 MPN / 来源 / PDF）：
  s1 LM317            → V2 parse_pdf 真实模型；验收 thermal=34、占位符不落行
  s2 ADS8568EVM-PDK   → V2 parse_pdf 真实模型；验收 identity/主体归属字段级
  s3 DAC8568EVM       → 非 Datasheet（User's Guide）；验收异常短路、零模型调用

用法：
  python docs/qc/phase171/run_samples.py --sample 1
  python docs/qc/phase171/run_samples.py --sample 3
  python docs/qc/phase171/run_samples.py --sample 2

产物：docs/qc/phase171/evidence/s{N}-*.json（只写证据目录与系统临时目录）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

import pymupdf                                                    # noqa: E402
import parse_datasheets as pd                                     # noqa: E402
from app.services import pipeline as P                            # noqa: E402
from qc.scope_contract import canonical_view                      # noqa: E402

EVID = ROOT / "docs" / "qc" / "phase171" / "evidence"
PARSED = ROOT / "data" / "parsed"

SAMPLES = {
    1: ("LM317", "LM317__lm317.pdf",
        "https://www.ti.com.cn/lit/ds/symlink/lm317.pdf"),
    2: ("ADS8568EVM-PDK", "ADS8568EVM-PDK__sbas543c.pdf",
        "https://www.ti.com/lit/ds/sbas543c/sbas543c.pdf"),
    3: ("DAC8568EVM", "DAC8568EVM__slau301.pdf",
        "https://www.ti.com/lit/ug/slau301/slau301.pdf"),
}


def prod_guard() -> dict:
    """生产 data/parsed 的轻量指纹：文件数 + 总字节 + 最新 mtime。

    不做全量 sha（13k 文件 280MB 太慢）；本轮的判据是「复跑期间没有新增写入」，
    文件数/字节数/最大 mtime 三项不变即成立，且对新增文件敏感。
    """
    files = list(PARSED.glob("*.json"))
    total = sum(f.stat().st_size for f in files)
    newest = max((f.stat().st_mtime for f in files), default=0)
    digest = hashlib.sha256(
        "|".join(f"{f.name}:{f.stat().st_size}:{int(f.stat().st_mtime)}"
                 for f in sorted(files)).encode()).hexdigest()
    return {"files": len(files), "bytes": total,
            "newest_mtime": time.strftime("%Y-%m-%d %H:%M:%S",
                                          time.localtime(newest)),
            "digest": digest}


def _pdf_text(path: Path) -> tuple[str, int]:
    with pymupdf.open(str(path)) as d:
        return "".join(p.get_text() for p in d), len(d)


def run_s1(out: Path) -> dict:
    mpn, fname, url = SAMPLES[1]
    pdf = ROOT / "data" / "pdfs" / fname
    t0 = time.time()
    rec = P.parse_pdf(pdf, mpn, url, out_dir=out)
    doc = rec.get("doc") or {}
    th = (doc.get("specs") or {}).get("thermal") or []
    placeholders = [r for r in th
                    if str(r.get("value")).strip().upper() in {"NA", "N/A", "—", "–"}]
    det = (doc.get("metadata") or {}).get("deterministic_extract") or {}
    return {
        "sample": "s1", "mpn": mpn, "pdf": fname,
        "pdf_sha256": doc.get("metadata", {}).get("pdf_hash"),
        "status": rec.get("status"), "error": rec.get("error"),
        "elapsed_s": round(time.time() - t0, 1),
        "thermal_rows": len(th),
        "thermal_names": sorted({r.get("name") for r in th if isinstance(r, dict)}),
        "placeholder_rows": len(placeholders),
        "pins": len(doc.get("pin_configuration") or []),
        "deterministic_extract": det,
        "llm_calls": len(rec.get("llm_calls") or []),
        "expect_thermal_34": len(th) == 34,
        "expect_no_placeholder": not placeholders,
        "expect_det_to_34": (det.get("thermal") or {}).get("to") == 34,
        "passed": bool(len(th) == 34 and not placeholders
                       and (det.get("thermal") or {}).get("to") == 34),
        "out_json": str(rec.get("json_path") or ""),
    }


def run_s2(out: Path) -> dict:
    mpn, fname, url = SAMPLES[2]
    pdf = ROOT / "data" / "pdfs" / fname
    t0 = time.time()
    rec = P.parse_pdf(pdf, mpn, url, out_dir=out)
    doc = rec.get("doc") or {}
    sp = doc.get("specs") or {}
    bi = doc.get("basic_info") or {}
    ods = sp.get("onboard_device_specs") or {}
    rows = {k: (sp.get(k) or []) for k in ("thermal", "esd")}
    # 行可能已被发布视图搬进 onboard_device_specs（D3 的正确归入），
    # 未标注统计必须覆盖两个容器，否则「主容器为空」会让检查假通过。
    all_rows = {k: list(rows[k]) + list((sp.get("onboard_device_specs") or {}).get(k) or [])
                for k in ("thermal", "esd")}
    labeled = {k: [r for r in v if isinstance(r, dict) and r.get("subject")]
               for k, v in rows.items()}
    unlabeled = {k: [r for r in v if isinstance(r, dict) and not r.get("subject")]
                 for k, v in all_rows.items()}
    subjects = {k: sorted({r.get("subject") for r in v if isinstance(r, dict)})
                for k, v in all_rows.items()}
    summary = sp.get("subject_summary") or {}
    # 发布视图（渲染层真正消费的对象）：芯片热阻/ESD 必须已搬出主容器
    view = canonical_view(doc)
    vsp = view.get("specs") or {}
    vods = vsp.get("onboard_device_specs") or {}
    ok_identity = (str(bi.get("identity") or "") == "evaluation_board"
                   and str(bi.get("device_mpn") or "") == "ADS8568")
    ok_moved = bool(ods.get("electrical")) and not (sp.get("electrical") or [])
    ok_labeled = all(not v for v in unlabeled.values())
    ok_view = (not (vsp.get("thermal") or [])) and (not (vsp.get("esd") or []))
    return {
        "sample": "s2", "mpn": mpn, "pdf": fname,
        "pdf_sha256": (doc.get("metadata") or {}).get("pdf_hash"),
        "status": rec.get("status"), "error": rec.get("error"),
        "elapsed_s": round(time.time() - t0, 1),
        "identity": bi.get("identity"),
        "device_mpn": bi.get("device_mpn"),
        "document_scope": bi.get("document_scope"),
        "specs_scope": sp.get("scope"),
        "onboard_electrical": len(ods.get("electrical") or []),
        "onboard_absolute_max": len(ods.get("absolute_max") or []),
        "main_electrical": len(sp.get("electrical") or []),
        "main_absolute_max": len(sp.get("absolute_max") or []),
        "thermal_rows": len(rows["thermal"]),
        "esd_rows": len(rows["esd"]),
        "rows_total": {k: len(v) for k, v in all_rows.items()},
        "subjects": subjects,
        "subject_summary": summary,
        "unlabeled": {k: len(v) for k, v in unlabeled.items()},
        "view_main_thermal": len(vsp.get("thermal") or []),
        "view_main_esd": len(vsp.get("esd") or []),
        "view_onboard_thermal": len(vods.get("thermal") or []),
        "view_onboard_esd": len(vods.get("esd") or []),
        "thermal_first": rows["thermal"][:3],
        "esd_first": rows["esd"][:2],
        "expect_identity_board_ads8568": ok_identity,
        "expect_chip_specs_moved": ok_moved,
        "expect_every_row_labeled": ok_labeled,
        "expect_publication_view_isolated": ok_view,
        "passed": bool(ok_identity and ok_moved and ok_labeled and ok_view),
        "out_json": str(rec.get("json_path") or ""),
    }


def run_s3(out: Path) -> dict:
    mpn, fname, url = SAMPLES[3]
    pdf = ROOT / "data" / "pdfs" / fname
    text, pages = _pdf_text(pdf)
    calls = {"n": 0}

    def boom(*a, **k):
        calls["n"] += 1
        raise AssertionError("非 Datasheet 不得调用模型")

    orig = pd.chat
    pd.chat = boom
    try:
        rec = P.parse_pdf(pdf, mpn, url, out_dir=out)
    finally:
        pd.chat = orig
    return {
        "sample": "s3", "mpn": mpn, "pdf": fname, "pages": pages,
        "is_datasheet": pd.is_datasheet(text),
        "status": rec.get("status"), "error": rec.get("error"),
        "llm_calls": calls["n"],
        "json_written": bool(rec.get("json_path")),
        "expect_skipped": str(rec.get("status")) == "skipped",
        "expect_no_llm": calls["n"] == 0,
        "expect_no_json": not rec.get("json_path"),
        "passed": bool(str(rec.get("status")) == "skipped" and calls["n"] == 0
                       and not rec.get("json_path")),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", required=True, choices=["1", "2", "3"])
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    EVID.mkdir(parents=True, exist_ok=True)
    tmp = Path(a.out) if a.out else Path(tempfile.mkdtemp(prefix=f"p171_s{a.sample}_"))
    tmp.mkdir(parents=True, exist_ok=True)

    before = prod_guard()
    res = {1: run_s1, 2: run_s2, 3: run_s3}[int(a.sample)](tmp)
    after = prod_guard()
    res["production_guard"] = {
        "before": before, "after": after,
        "unchanged": {k: before[k] == after[k] for k in before},
        "clean": all(before[k] == after[k] for k in before),
    }
    res["isolated_out_dir"] = str(tmp)
    name = {1: "s1-lm317", 2: "s2-ads8568evm-pdk", 3: "s3-dac8568evm"}[int(a.sample)]
    p = EVID / f"{name}.json"
    p.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in res.items()
                      if k not in ("thermal_first", "esd_first")},
                     ensure_ascii=False, indent=1))
    print(f"[evidence] {p}")
    return 0 if res.get("passed") and res["production_guard"]["clean"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

```

---

## 3. 三件样本实跑日志 / 证据（原文）

### 3.1 s1 · LM317

```json
{
  "sample": "s1",
  "mpn": "LM317",
  "pdf": "LM317__lm317.pdf",
  "pdf_sha256": "1646fb2e4f8cf8c2cbd93aaf22edad368571619ad062476deca8ee29f95c65d3",
  "status": "ok",
  "error": "",
  "elapsed_s": 51.5,
  "thermal_rows": 34,
  "thermal_names": [
    "RθJA",
    "RθJB",
    "RθJC(bot)",
    "RθJC(top)",
    "ψJB",
    "ψJT"
  ],
  "placeholder_rows": 0,
  "pins": 3,
  "deterministic_extract": {
    "thermal": {
      "from": 36,
      "to": 34,
      "method": "deterministic"
    },
    "esd": {
      "from": 2,
      "to": 2,
      "method": "deterministic"
    },
    "model_unverified": {
      "stamped": 26
    }
  },
  "llm_calls": 1,
  "expect_thermal_34": true,
  "expect_no_placeholder": true,
  "expect_det_to_34": true,
  "passed": true,
  "out_json": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s1_qbszzg3k\\LM317_1646fb2e.json",
  "production_guard": {
    "before": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "after": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "unchanged": {
      "files": true,
      "bytes": true,
      "newest_mtime": true,
      "digest": true
    },
    "clean": true
  },
  "isolated_out_dir": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s1_qbszzg3k"
}
```

### 3.2 s2 · ADS8568EVM-PDK

```json
{
  "sample": "s2",
  "mpn": "ADS8568EVM-PDK",
  "pdf": "ADS8568EVM-PDK__sbas543c.pdf",
  "pdf_sha256": "79c029913ea9ce5ce0cae2fb12cd22e2598088ed5a58a6c6567062ffb7d9bb76",
  "status": "ok",
  "error": "",
  "elapsed_s": 177.4,
  "identity": "evaluation_board",
  "device_mpn": "ADS8568",
  "document_scope": "onboard_device_datasheet",
  "specs_scope": "onboard_device",
  "onboard_electrical": 71,
  "onboard_absolute_max": 11,
  "main_electrical": 0,
  "main_absolute_max": 0,
  "thermal_rows": 0,
  "esd_rows": 0,
  "rows_total": {
    "thermal": 11,
    "esd": 2
  },
  "subjects": {
    "thermal": [
      "onboard_device"
    ],
    "esd": [
      "onboard_device"
    ]
  },
  "subject_summary": {
    "thermal": {
      "onboard_device": 11
    },
    "esd": {
      "onboard_device": 2
    }
  },
  "unlabeled": {
    "thermal": 0,
    "esd": 0
  },
  "view_main_thermal": 0,
  "view_main_esd": 0,
  "view_onboard_thermal": 11,
  "view_onboard_esd": 2,
  "thermal_first": [],
  "esd_first": [],
  "expect_identity_board_ads8568": true,
  "expect_chip_specs_moved": true,
  "expect_every_row_labeled": true,
  "expect_publication_view_isolated": true,
  "passed": true,
  "out_json": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s2_ueg1zwtw\\ADS8568EVM-PDK_79c02991.json",
  "production_guard": {
    "before": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "after": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "unchanged": {
      "files": true,
      "bytes": true,
      "newest_mtime": true,
      "digest": true
    },
    "clean": true
  },
  "isolated_out_dir": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s2_ueg1zwtw"
}
```

### 3.3 s3 · DAC8568EVM（非 Datasheet 短路）

```json
{
  "sample": "s3",
  "mpn": "DAC8568EVM",
  "pdf": "DAC8568EVM__slau301.pdf",
  "pages": 10,
  "is_datasheet": false,
  "status": "skipped",
  "error": "NOT_A_DATASHEET: 无参数表特征词（User Guide / Quick Start），跳过 LLM",
  "llm_calls": 0,
  "json_written": false,
  "expect_skipped": true,
  "expect_no_llm": true,
  "expect_no_json": true,
  "passed": true,
  "production_guard": {
    "before": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "after": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "unchanged": {
      "files": true,
      "bytes": true,
      "newest_mtime": true,
      "digest": true
    },
    "clean": true
  },
  "isolated_out_dir": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s3__mefe06h"
}
```

### 3.4 Phase 1.7.1 测试实跑输出：`tests-phase171.txt`

```text
﻿........................................................................ [ 39%]
........................................................................ [ 78%]
........................................                                 [100%]
184 passed in 53.29s

```

### 3.5 HTML 消费端证据：`s2-render-view.json`

```json
{
  "probe": "json_to_txt.render on real s2 doc (board w/ chip datasheet)",
  "render_calls_canonical_view": true,
  "doc_main_thermal": 0,
  "doc_main_esd": 0,
  "view_main_thermal": 0,
  "view_main_esd": 0,
  "view_onboard_thermal": 11,
  "view_onboard_esd": 2,
  "html_len": 26837,
  "html_view_len": 26837,
  "banner": "not limits for the assembled board",
  "thermal_block": {
    "section_found": true,
    "banner_in_section": true,
    "names_outside": [],
    "ok": true,
    "section_start": 18735,
    "section_end": 21326
  },
  "esd_block": {
    "section_found": true,
    "banner_in_section": true,
    "names_outside": [],
    "ok": true,
    "section_start": 21326,
    "section_end": 25239
  },
  "passed": true
}
```

---

## 4. 真实 UG 报告：ADS8568EVM-PDK 行数统计

统计来自 `docs/qc/phase171/evidence/s2-ads8568evm-pdk.json` 的
`subject_summary` / `rows_total` / `unlabeled` / `view_*` 字段。

| 容器 | 原始行数 | board | onboard_device | ambiguous | unlabeled |
|---|---:|---:|---:|---:|---:|
| thermal | 11 | 0 | 11 | 0 | 0 |
| esd | 2 | 0 | 2 | 0 | 0 |
| **合计** | **13** | **0** | **13** | **0** | **0** |

- `view_main_thermal = 0`，`view_main_esd = 0`
- `view_onboard_thermal = 11`，`view_onboard_esd = 2`
- `passed = true`；`production_guard.clean = true`

> 注意：原始 `rows_total` 为 thermal 11 / esd 2；s2 的 `thermal_rows`/`esd_rows`
> 显示 0，是因为消费端 `canonical_view` 已把 `onboard_device` 行隔离到
> `onboard_device_specs`，不是原始行丢失。

```json
{
  "sample": "s2",
  "mpn": "ADS8568EVM-PDK",
  "pdf": "ADS8568EVM-PDK__sbas543c.pdf",
  "pdf_sha256": "79c029913ea9ce5ce0cae2fb12cd22e2598088ed5a58a6c6567062ffb7d9bb76",
  "status": "ok",
  "error": "",
  "elapsed_s": 177.4,
  "identity": "evaluation_board",
  "device_mpn": "ADS8568",
  "document_scope": "onboard_device_datasheet",
  "specs_scope": "onboard_device",
  "onboard_electrical": 71,
  "onboard_absolute_max": 11,
  "main_electrical": 0,
  "main_absolute_max": 0,
  "thermal_rows": 0,
  "esd_rows": 0,
  "rows_total": {
    "thermal": 11,
    "esd": 2
  },
  "subjects": {
    "thermal": [
      "onboard_device"
    ],
    "esd": [
      "onboard_device"
    ]
  },
  "subject_summary": {
    "thermal": {
      "onboard_device": 11
    },
    "esd": {
      "onboard_device": 2
    }
  },
  "unlabeled": {
    "thermal": 0,
    "esd": 0
  },
  "view_main_thermal": 0,
  "view_main_esd": 0,
  "view_onboard_thermal": 11,
  "view_onboard_esd": 2,
  "thermal_first": [],
  "esd_first": [],
  "expect_identity_board_ads8568": true,
  "expect_chip_specs_moved": true,
  "expect_every_row_labeled": true,
  "expect_publication_view_isolated": true,
  "passed": true,
  "out_json": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s2_ueg1zwtw\\ADS8568EVM-PDK_79c02991.json",
  "production_guard": {
    "before": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "after": {
      "files": 8992,
      "bytes": 129255042,
      "newest_mtime": "2026-11-03 14:06:59",
      "digest": "9a089c9c73d3aae61e7855c77924c3ed4c15a90618a6333fdb88ed67aefb3738"
    },
    "unchanged": {
      "files": true,
      "bytes": true,
      "newest_mtime": true,
      "digest": true
    },
    "clean": true
  },
  "isolated_out_dir": "C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\p171_s2_ueg1zwtw"
}
```

---

## 5. D4 验证：当前 HEAD `e23751b` 的 LM317 `PIN | FUNCTION` 引脚抽取

### 5.1 测试命令与结果

```text
python -m pytest tests/test_pin_layout_pin_function.py -q
....                                                                     [100%]
4 passed in 18.05s
```

### 5.2 原始表格行（LM317 PDF 第 5 页文本层，按原顺序）

```text
INPUT
OUTPUT
ADJUST
OUTPUT
Figure 5-3. KTT Package, 3-Pin TO-263 (Top View)
Pin Functions, Metal Can Packages
PIN
I/O
DESCRIPTION
NAME
TO-220
(Legacy Chip)
TO-263
SOT-223
ADJUST
1
1
1
—
Output voltage adjustment pin. Connect to a
resistor divider to set VOUT.
INPUT
3
3
3
I
Input voltage pin for the regulator.
OUTPUT
2, TAB
2, TAB
2, TAB
O
Output voltage pin for the regulator.
www.ti.com
LM317
```

### 5.3 提取结果（`qc.deterministic_extract.extract_pins`）

```json
{
  "head": "e23751b",
  "pdf": "data\\pdfs\\LM317__lm317.pdf",
  "page": 5,
  "raw_pin_function_lines": [
    "INPUT",
    "OUTPUT",
    "ADJUST",
    "OUTPUT",
    "Figure 5-3. KTT Package, 3-Pin TO-263 (Top View)",
    "Pin Functions, Metal Can Packages",
    "PIN",
    "I/O",
    "DESCRIPTION",
    "NAME",
    "TO-220",
    "(Legacy Chip)",
    "TO-263",
    "SOT-223",
    "ADJUST",
    "1",
    "1",
    "1",
    "—",
    "Output voltage adjustment pin. Connect to a",
    "resistor divider to set VOUT.",
    "INPUT",
    "3",
    "3",
    "3",
    "I",
    "Input voltage pin for the regulator.",
    "OUTPUT",
    "2, TAB",
    "2, TAB",
    "2, TAB",
    "O",
    "Output voltage pin for the regulator.",
    "www.ti.com",
    "LM317"
  ],
  "extracted_pins": [
    {
      "pin": "1",
      "name": "ADJUST",
      "description": "Output voltage adjustment pin. Connect to a resistor divider to set VOUT.",
      "page": 5
    },
    {
      "pin": "3",
      "name": "INPUT",
      "description": "Input voltage pin for the regulator.",
      "page": 5
    },
    {
      "pin": "2",
      "name": "OUTPUT",
      "description": "Output voltage pin for the regulator.",
      "page": 5
    }
  ]
}
```

---

## 材料边界（不构成批准）

- 第 1 组是 `9beeb7d` 的完整 diff；第 2 组是复跑器的完整源码；第 3 组是仓库内
  可提取的三件样本实跑 JSON 与测试/渲染证据原文。
- 第 4 组只给行数统计，不把 `anchor_gate` 或页面生成成功当作内容正确性。
- 第 5 组是当前 HEAD `e23751b` 的 D4 实跑；D4 未被 D1–D3 验收覆盖。
- 本文件不设置 `CONTENT_APPROVED` / `RELEASE_APPROVED`，也不覆盖 V2 原始盲审包。
