#!/usr/bin/env python
"""解析后的 JSON -> 三视图（原理图符号 / 封装 / 3D 模型），全部程序化生成。

为什么要自己画，而不是从 PDF 切图、也不是用 AI 生图：
  1. 切图：PDF 里的图风格各异、带压缩噪声、改不了配色、缩放就糊，且一半 datasheet 根本没画。
  2. AI 生图：扩散模型不保证引脚数、编号顺序、1 脚标记正确 —— 硬件图错一个脚就是事故。
  3. 程序化：pin_configuration 已经是结构化的（pin/name/description），
     渲染成 SVG 后矢量、可换主题、可缓存复用，同一型号永远长一样。

用法:
    python symbol_svg.py                    # 全部有 pin 数据的 JSON
    python symbol_svg.py --only ADS1201
    python symbol_svg.py --out data/symbols
"""
from __future__ import annotations

import argparse
import html as _html
import json
import re
from pathlib import Path

from qc import engineering_model as EM
from qc import pkg_geometry as PG
from qc.pin_repair import bga_pin_validation, is_bga
from qc.scope_contract import BOARD_TYPES, canonical_view

ROOT = Path(__file__).resolve().parent
PARSED = ROOT / "data" / "parsed"
OUT = ROOT / "data" / "symbols"

# 配色取自线上详情页（浅底）
C_BOX = "#fdfbd4"        # 符号体淡黄
C_BOX_LINE = "#8b1a1a"   # 符号体深红边框
C_PIN = "#c0392b"        # 引脚红
C_NAME = "#1f6f5c"       # 引脚名墨绿
C_TEXT = "#222222"
C_PAD = "#c0392b"        # 焊盘
C_OUTLINE = "#e91e8c"    # 封装外形框（洋红，EDA 惯例）
C_MUTED = "#8a8a8a"


def esc(s) -> str:
    return _html.escape(str(s or ""), quote=True)


def clip(s: str, n: int = 13) -> str:
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _pin_sort_key(k):
    """BGA 球号（A1/B2/AA3）与数字脚号都能排序。"""
    s = str(k).strip().upper()
    m = re.fullmatch(r"([A-Z]{1,2})(\d{1,2})", s)
    if m:
        return (1, len(m.group(1)), m.group(1), int(m.group(2)))
    try:
        return (0, int(s), "", 0)
    except ValueError:
        return (2, 0, s, 0)


def pins_of(doc: dict) -> list[tuple[object, str]]:
    """pin_configuration -> [(pin_no, name)]，去重、按脚号排序。

    板卡/EVM 类文档的引脚编号常常全是 0（PDF 里只有「J1-VBUS / J1-GND」这类
    位号，没有真实脚号）。按脚号去重后会塌成 1 条，三视图整页就不生成了。
    这里对「原始条目 >= 2 但去重后 < 2」的情况改用位置序号兜底，
    保证板卡也能画出端子排布图。

    **BGA 球号必须原样保留**：`ADC12DJ5200SE` 是 FCBGA-144，模型曾把球号
    1..15 当成脚号；修成 A1/A2/B2… 后不能在这里被 `int()` 丢掉 —— 否则
    三视图会用 1..144 的「未命名脚」重画，等于换一种方式造假。
    """
    if is_bga(package_of(doc, 0)):
        doc = canonical_view(doc)
        if bga_pin_validation(doc)["status"] != "pass":
            return []
        return sorted([(p["pin"], clip(p["name"])) for p in doc["pin_configuration"]],
                      key=lambda kv: _pin_sort_key(kv[0]))
    raw = doc.get("pin_configuration")
    if not isinstance(raw, list):
        return []
    acc: dict[object, str] = {}
    for p in raw:
        if not isinstance(p, dict):
            continue
        pin = str(p.get("pin")).strip()
        if not pin:
            continue
        if re.fullmatch(r"\d+", pin):
            key: object = int(pin)
        elif re.fullmatch(r"[A-Za-z]{1,2}\d{1,2}", pin):
            key = pin.upper()
        else:
            continue
        acc.setdefault(key, clip(p.get("name") or f"PIN{pin}"))
    if len(acc) < 2 and len(raw) >= 2:
        # 脚号不可用（多半全是 0）-> 用出现顺序编号，名字保留
        fallback: dict[int, str] = {}
        i = 0
        for p in raw:
            if not isinstance(p, dict):
                continue
            i += 1
            fallback.setdefault(i, clip(p.get("name") or f"PIN{i}"))
        if len(fallback) >= 2:
            return sorted(fallback.items(), key=lambda kv: _pin_sort_key(kv[0]))
    return sorted(acc.items(), key=lambda kv: _pin_sort_key(kv[0]))


def package_of(doc: dict, n: int) -> str:
    """封装名：优先取解析出的 specs.package.type，兜底才去 seo 标题里正则捞。"""
    pkg = (doc.get("specs") or {}).get("package") or {}
    t = str(pkg.get("type") or "").strip()
    if t:
        # "64-VQFN or 64-LQFP" -> 取第一个；"38-TSSOP" -> 保持
        return re.split(r"\s+or\s+", t)[0].strip()
    blob = " ".join(str(doc.get(k) or "") for k in ("seo", "basic_info"))
    m = re.search(r"\b(SOIC|SSOP|TSSOP|MSOP|QFN|VQFN|WQFN|LQFP|TQFP|QFP|BGA|DIP|SOP|SOT-?\d*|DFN|LGA)"
                  r"-?(\d+)?", blob, re.I)
    if m:
        return f"{m.group(1).upper()}{'-' + m.group(2) if m.group(2) else ''}"
    return f"{n}-Pin"


# ---------------------------------------------------------------- 1. 原理图符号
_LOW_DESC = re.compile(r"active[\s-]*low|低电平有效|低有效|asserted[\s-]*low", re.I)
_LOW_NAME = re.compile(r"^(?:~|/|!)|#$")


def active_low_of(doc: dict) -> set[str]:
    """低有效信号名集合。

    三个来源，按可靠性排序：显式 `active_low` 字段 > 名称前缀（`~INT` / `/INT` /
    `INT#`）> 描述里的 "Active Low"。描述里有就够用了——PDF 的 Pin Functions
    表基本都会写这一句，而名称前缀在解析时往往已经被剥掉。
    """
    out: set[str] = set()
    for p in (doc.get("pin_configuration") or []):
        if not isinstance(p, dict):
            continue
        name = str(p.get("name") or "").strip()
        if not name:
            continue
        flag = p.get("active_low")
        bare = name.lstrip("~/!").rstrip("#").strip().upper()
        if flag is True or (isinstance(flag, str)
                            and flag.strip().lower() in ("true", "yes", "1")):
            out.add(bare)
            continue
        if _LOW_NAME.search(name):
            out.add(bare)
            continue
        if _LOW_DESC.search(str(p.get("description") or "")):
            out.add(bare)
    return out


def symbol_svg(pins: list[tuple[int, str]], title: str = "",
               active_low: set[str] | None = None) -> str:
    """原理图符号。`active_low` 里的信号名画上划线（低有效）。"""
    active_low = {s.upper() for s in (active_low or ())}
    n = len(pins)
    n_left = (n + 1) // 2
    left = pins[:n_left]
    right = list(reversed(pins[n_left:]))          # DIP 镜像：右侧自上而下是 N..N/2+1
    rows = max(len(left), len(right), 1)
    # 脚多时自动压缩行距与字号，避免 64 脚画成 1200px 的长条
    pitch = 38 if rows <= 10 else max(19, round(380 / rows))
    fs = 14.5 if rows <= 10 else max(10.0, 14.5 * pitch / 38)
    stub, margin = 34, 26
    box_w = 268
    box_h = rows * pitch
    w = box_w + 2 * stub + 16
    h = box_h + 2 * margin
    bx, by = 8 + stub, margin

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="max-width:100%;height:auto" '
         f'role="img" aria-label="{esc(title or "schematic symbol")}">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<rect x="{bx}" y="{by}" width="{box_w}" height="{box_h}" rx="2" '
         f'fill="{C_BOX}" stroke="{C_BOX_LINE}" stroke-width="2.4"/>']

    def draw(pin_no: int, name: str, y: float, side: str) -> None:
        if side == "L":
            x0, x1 = bx - stub, bx
            tx, anchor = bx + 10, "start"
        else:
            x0, x1 = bx + box_w, bx + box_w + stub
            tx, anchor = bx + box_w - 10, "end"
        o.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x1}" y2="{y:.1f}" '
                 f'stroke="{C_PIN}" stroke-width="2"/>')
        o.append(f'<circle cx="{x0}" cy="{y:.1f}" r="3.6" fill="{C_PIN}"/>')
        o.append(f'<text x="{(x0 + x1) / 2:.1f}" y="{y - pitch * 0.19:.1f}" text-anchor="middle" '
                 f'font-family="Arial,Helvetica,sans-serif" font-size="{fs * 0.8:.1f}" '
                 f'fill="{C_PIN}">{pin_no}</text>')
        o.append(f'<text x="{tx}" y="{y + fs * 0.35:.1f}" text-anchor="{anchor}" '
                 f'font-family="Arial,Helvetica,sans-serif" font-size="{fs:.1f}" '
                 f'fill="{C_NAME}">{esc(name)}</text>')
        # 低有效信号（INT/RESET/CS…）按惯例加上划线。用显式 line 而不是
        # text-decoration="overline"：老 Chromium（2345 之类）对 SVG 的
        # text-decoration 支持不稳，画线是唯一确定能看见的做法。
        bare = name.strip().upper().lstrip("~/").rstrip("#_")
        if bare in active_low:
            wpx = len(name.strip()) * fs * 0.58
            x_from = tx if anchor == "start" else tx - wpx
            o.append(f'<line x1="{x_from:.1f}" y1="{y - fs * 0.62:.1f}" '
                     f'x2="{x_from + wpx:.1f}" y2="{y - fs * 0.62:.1f}" '
                     f'stroke="{C_NAME}" stroke-width="1.4"/>')

    for i, (num, name) in enumerate(left):
        draw(num, name, by + pitch / 2 + i * pitch, "L")
    for i, (num, name) in enumerate(right):
        draw(num, name, by + pitch / 2 + i * pitch, "R")

    # 中线分隔（图二的虚线，纯装饰）
    if n > 4:
        o.append(f'<line x1="{bx + box_w / 2}" y1="{by + 6}" x2="{bx + box_w / 2}" '
                 f'y2="{by + box_h - 6}" stroke="{C_BOX_LINE}" stroke-width="1" '
                 f'stroke-dasharray="5 5" opacity="0.35"/>')
    o.append("</svg>")
    return "\n".join(o)


# ---------------------------------------------------------------- 2. 封装
def pkg_family(pkg: str) -> str:
    """封装族。决定焊盘排布：两侧 / 四面 / 阵列 / 板卡。

    顺序不能乱：VQFN 含 QFN，TSSOP 含 SSOP，必须先判更具体的。
    """
    p = (pkg or "").upper()
    if any(k in p for k in ("BGA", "LGA", "WLCSP", "CSP", "FLIP")):
        return "grid"
    if any(k in p for k in ("QFN", "DFN", "SON", "UQFN")):
        return "qfn"                       # 四面焊盘，无外伸引脚
    if "QFP" in p:
        return "qfp"                       # 四面引脚，海鸥翼外伸
    if any(k in p for k in ("SOIC", "SOP", "SSOP", "MSOP", "DIP")):
        return "dual"
    if any(k in p for k in ("SOT", "SC70", "SC-70", "SOD", "TO-")):
        return "sot"
    if any(k in p for k in ("PCB", "BOARD", "BOOSTERPACK", "MODULE", "KIT")):
        return "other"
    return "dual"


# 封装族名，长的在前：匹配时必须先试 VQFN 再试 QFN，否则永远命中短的。
FAMILIES = (
    "WLCSP", "FCBGA", "PBGA", "UBGA", "FBGA", "BGA", "LGA", "CSP", "FLIP",
    "HVQFN", "WQFN", "UQFN", "VQFN", "TQFN", "QFN", "VSON", "USON", "WSON", "DFN", "SON",
    "HTQFP", "TQFP", "LQFP", "QFP",
    "TSSOP", "VSSOP", "HVSSOP", "SSOP", "MSOP", "QSOP", "TVSOP", "TSOP", "SOIC", "SOP",
    "PDIP", "DIP", "SC70", "SOT", "SOD",
)


def canon_pkg(raw: str, pins: int = 0) -> str:
    """封装类型归一 -> `族-脚数`，如 `TSSOP-38` / `VQFN-64` / `FCBGA-144`。

    这是「按封装批量生成」的关键：同一个 `SOIC-16`，不管它是 TI 还是 ADI 的，
    封装图完全一样（JEDEC 标准尺寸），所以只需生成一张，全站型号共用。

    归一要处理的实际写法：
        `64-VQFN or 64-LQFP`  -> VQFN-64（多封装取第一个）
        `FCBGA (144)`         -> FCBGA-144
        `38-TSSOP`            -> TSSOP-38
        `LQFP / HTQFP`        -> LQFP-80（名字里没脚数，靠 specs.package.pins 补）
        `4-VSON`              -> VSON-4

    脚数优先取 `specs.package.pins`（解析出的权威值），名字里的数字只做兜底——
    `SOT-23-5` 这种名字里的第一个数字是 23 不是 5，靠名字取会错。
    """
    s = (raw or "").upper().strip()
    if not s:
        return "PKG-UNK"
    # 板卡/模块类没有标准封装，也不该共享图（每块板都不一样），先单独摘出来
    if any(k in s for k in ("PCB", "PRINTED CIRCUIT", "BOARD", "BOOSTERPACK",
                            "MODULE", "KIT", "EVALUATION", "DONGLE")):
        return "PCB-UNK"
    # 多封装写法：取第一个
    first = re.split(r"\s+OR\s+|\s*/\s*|\s*,\s*|\s+AND\s+", s)[0].strip()
    fam = ""
    for f in FAMILIES:
        if re.search(rf"(?<![A-Z]){f}(?![A-Z])", first):
            fam = f
            break
    if not fam:
        # 兜底：把非字母数字剔掉当族名，至少不会互相覆盖
        fam = re.sub(r"[^A-Z0-9]+", "", first)[:12] or "PKG"
    n = int(pins or 0)
    if not n:
        m = re.search(r"\d+", first)
        n = int(m.group()) if m else 0
    return f"{fam}-{n}" if n else f"{fam}-UNK"


def pkg_key(raw: str, declared_pins: int) -> str:
    """封装 key 的**唯一**派生入口：渲染器与状态层都必须走这里。

    为什么必须只有一个入口：以前渲染器用 ``canon_pkg(pkg, declared or len(pins))``、
    状态层用 ``_canon(pkg, declared)``，``declared=0`` 时一个拿引脚表长度补脚数、
    一个不补，于是同一页算出两个 key —— 页面引用 ``DIP-20.3d.svg``，
    状态却说本件的 key 是 ``DIP-UNK``，门禁 A2 报「引用了不是本件封装 key 的 3D 图」。
    实测全库只有 9 件两侧不一致（其中 0 件是已覆盖页），但每一件都是这种自相矛盾。

    **不拿引脚表长度兜底**：引脚表可能只解析到一半（实测 14 行 vs 声明 20 脚），
    拿它反推脚数等于替厂商猜，画出来的共享封装图会张冠李戴。
    ``declared`` 缺失就老实落 ``-UNK``，由状态层把「封装类型/脚数未声明」说出来。
    """
    return canon_pkg(raw, declared_pins)


def pkg_type_of(doc: dict) -> str:
    """封装类型的**声明值**（`specs.package.type`）—— 不做任何兜底猜测。

    与 `package_of` 的区别：`package_of` 在 type 缺失时会去 SEO 标题里正则捞一个
    封装族名、甚至编出 ``{n}-Pin``。画轮廓时兜底可以接受，**派生 key 时不行** ——
    状态层只看声明值（type 缺失就是 `package_type_missing`），两侧一个猜一个不猜，
    同一页就会算出两个 key，门禁 A2 报「引用了不是本件封装 key 的 3D 图」。

    实测全库只有 4 件走得上这个兜底（7718 件 type 有值），改动面可控。

    **不在这里拆 "A or B"**：拆了会把 `100-LQFP or 108-BGA` 变成 `100-LQFP`，
    状态层据此认定「有签核共享模板 LQFP-100」，而规格书写的是二选一 —— 一个
    不确定的声明被当成了确定结论（实测 `EKI-LM3S9B92` 就是这样把文案退回成
    旧副标题的）。多封装写法的拆分由 `canon_pkg` 内部负责，两侧 key 仍然一致。
    """
    return str(((doc.get("specs") or {}).get("package") or {}).get("type") or "").strip()


def _quad_groups(pins: list[tuple[int, str]]):
    """四面包装的脚位分组（逆时针：左边自上而下 → 下边自左而右 → 右边自下而上 → 上边自右而左）。"""
    n = len(pins)
    k = max(1, -(-n // 4))                  # ceil(n/4)
    return (pins[0:k], pins[k:2 * k], pins[2 * k:3 * k], pins[3 * k:4 * k], k)


def footprint_svg(pins: list[tuple[int, str]], pkg: str = "", declared: int = 0,
                  geom: dict | None = None) -> str:
    fam = pkg_family(pkg)
    n = len(pins)
    if fam == "other":
        return _board_svg(pkg)
    if fam == "grid":
        return _grid_svg(pins, pkg, declared, geom)
    if fam in ("qfn", "qfp"):
        # 脚少的 DFN/VSON 实际是两侧排布（4 脚 = 2+2，6 脚 = 3+3），
        # 只有 4 的倍数且脚数够多才按四面画
        quad = n % 4 == 0 and n >= 8
        return _quad_svg(pins, pkg, fam) if quad else _dual_svg(pins, pkg)
    return _dual_svg(pins, pkg)


def _pad_label(o: list[str], num: int, cx: float, cy: float, fs: float) -> None:
    o.append(f'<text x="{cx:.1f}" y="{cy + fs * 0.36:.1f}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="{fs:.1f}" '
             f'fill="#ffffff">{num}</text>')


def _dual_svg(pins: list[tuple[int, str]], pkg: str) -> str:
    """两侧封装（SOIC/SOP/TSSOP/DIP/SOT）：本体居中，左右两列焊盘。"""
    n = len(pins)
    half = (n + 1) // 2
    left = pins[:half]
    right = list(reversed(pins[half:]))
    rows = max(len(left), len(right), 1)
    pad_w, pad_h = 44, 14
    pitch = max(27, pad_h + 8)
    body_w, gap, margin = 92, 14, 20
    w = margin * 2 + pad_w * 2 + gap * 2 + body_w
    h = margin * 2 + rows * pitch
    lx, rx = margin, w - margin - pad_w
    bx = lx + pad_w + gap

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="max-width:100%;height:auto" '
         f'role="img" aria-label="{esc(pkg or "package")} footprint (dual)">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<rect x="8" y="8" width="{w - 16}" height="{h - 16}" fill="none" '
         f'stroke="{C_OUTLINE}" stroke-width="1.6"/>',
         f'<rect x="{bx}" y="{margin - 6}" width="{body_w}" height="{h - 2 * margin + 12}" rx="3" '
         f'fill="#fafafa" stroke="#d9dde2" stroke-width="1"/>']

    for i, (num, _) in enumerate(left):
        y = margin + 6 + i * pitch
        o.append(f'<rect x="{lx}" y="{y}" width="{pad_w}" height="{pad_h}" rx="2.5" fill="{C_PAD}"/>')
        _pad_label(o, num, lx + pad_w / 2, y + pad_h / 2, 9)
    for i, (num, _) in enumerate(right):
        y = margin + 6 + i * pitch
        o.append(f'<rect x="{rx}" y="{y}" width="{pad_w}" height="{pad_h}" rx="2.5" fill="{C_PAD}"/>')
        _pad_label(o, num, rx + pad_w / 2, y + pad_h / 2, 9)

    o.append(f'<circle cx="{bx + 13}" cy="{margin + 8}" r="4.5" fill="{C_OUTLINE}"/>')
    o.append(f'<text x="{bx + body_w / 2}" y="{h - 14}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="10.5" fill="{C_MUTED}">{esc(pkg)}</text>')
    o.append("</svg>")
    return "\n".join(o)


def _quad_svg(pins: list[tuple[int, str]], pkg: str, fam: str) -> str:
    """四面包装（QFN/DFN/VSON 无外伸引脚，QFP/LQFP 海鸥翼外伸）。"""
    left, bottom, right, top, k = _quad_groups(pins)
    pitch = 15
    pad_th = 11
    pad_len = 22 if fam == "qfn" else 28
    side = max(110, k * pitch + 24)
    margin = 26
    w = h = side + margin * 2
    bx = by = margin
    out = pad_len if fam == "qfp" else 0          # 外伸长度
    fs = max(7.0, min(9.0, pitch * 0.6))

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="max-width:100%;height:auto" '
         f''
         f'role="img" aria-label="{esc(pkg or "package")} footprint (quad)">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<rect x="{bx - out - 6}" y="{by - out - 6}" width="{side + 2 * out + 12}" '
         f'height="{side + 2 * out + 12}" fill="none" stroke="{C_OUTLINE}" stroke-width="1.6"/>',
         f'<rect x="{bx}" y="{by}" width="{side}" height="{side}" rx="4" '
         f'fill="#fafafa" stroke="#d9dde2" stroke-width="1"/>']

    # 左边：自上而下
    for i, (num, _) in enumerate(left):
        y = by + pitch * (i + 0.5) + (side - k * pitch) / 2 - pad_th / 2
        x = bx - out
        o.append(f'<rect x="{x}" y="{y:.1f}" width="{pad_len}" height="{pad_th}" rx="1.5" fill="{C_PAD}"/>')
        _pad_label(o, num, x + pad_len / 2, y + pad_th / 2, fs)
    # 下边：自左而右
    for i, (num, _) in enumerate(bottom):
        x = bx + pitch * (i + 0.5) + (side - k * pitch) / 2 - pad_th / 2
        y = by + side - (pad_len - out)
        o.append(f'<rect x="{x:.1f}" y="{y}" width="{pad_th}" height="{pad_len}" rx="1.5" fill="{C_PAD}"/>')
        _pad_label(o, num, x + pad_th / 2, y + pad_len / 2, fs)
    # 右边：自下而上
    for i, (num, _) in enumerate(right):
        y = by + side - pitch * (i + 0.5) - (side - k * pitch) / 2 - pad_th / 2
        x = bx + side - (pad_len - out)
        o.append(f'<rect x="{x}" y="{y:.1f}" width="{pad_len}" height="{pad_th}" rx="1.5" fill="{C_PAD}"/>')
        _pad_label(o, num, x + pad_len / 2, y + pad_th / 2, fs)
    # 上边：自右而左
    for i, (num, _) in enumerate(top):
        x = bx + side - pitch * (i + 0.5) - (side - k * pitch) / 2 - pad_th / 2
        y = by - out
        o.append(f'<rect x="{x:.1f}" y="{y}" width="{pad_th}" height="{pad_len}" rx="1.5" fill="{C_PAD}"/>')
        _pad_label(o, num, x + pad_th / 2, y + pad_len / 2, fs)

    # 1 脚标记（左上角外侧）+ 中央散热焊盘（QFN 才有）
    o.append(f'<circle cx="{bx + 10}" cy="{by + 10}" r="4.5" fill="{C_OUTLINE}"/>')
    if fam == "qfn" and side > 90:
        ep = side * 0.42
        o.append(f'<rect x="{bx + (side - ep) / 2:.1f}" y="{by + (side - ep) / 2:.1f}" '
                 f'width="{ep:.1f}" height="{ep:.1f}" rx="3" fill="#f0d3d3" stroke="{C_PAD}" '
                 f'stroke-width="1" stroke-dasharray="4 3"/>')
    o.append(f'<text x="{w / 2}" y="{h - 8}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="10.5" fill="{C_MUTED}">'
             f'{esc(pkg)} · {len(pins)} 脚 · 每边 {k}</text>')
    o.append("</svg>")
    return "\n".join(o)


def _grid_svg(pins: list[tuple[int, str]], pkg: str, declared: int = 0,
              geom: dict | None = None) -> str:
    """BGA：有原厂机械图抽出来的几何就按真实尺寸画；没有则出占位图（fail-closed）。

    「有几何」指 `qc.pkg_geometry.geometry_of()` 认可的那份（结构完整 + 互证全过）。
    没有它就**不许**画球阵——画出来必然是拍的，正是红线要防的东西。
    """
    if is_bga(pkg):
        if geom:
            return bga_footprint_svg(geom)
        return _bga_placeholder(pkg, "footprint")
    import math
    n_parsed = len(pins)
    n = declared if declared >= n_parsed else n_parsed
    cols = max(2, math.ceil(math.sqrt(n)))
    rows = max(1, math.ceil(n / cols))
    pitch = max(5.0, min(15.0, 168 / max(cols, rows)))
    r = max(1.6, pitch * 0.31)
    margin = 26
    w = margin * 2 + (cols - 1) * pitch + 16
    h = margin * 2 + (rows - 1) * pitch + 16 + 18      # 底部留一行放标注
    ox = margin + 8
    oy = margin + 8

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="max-width:100%;height:auto" '
         f'role="img" aria-label="{esc(pkg or "package")} BGA grid">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<rect x="8" y="8" width="{w - 16}" height="{h - 16}" fill="none" '
         f'stroke="{C_OUTLINE}" stroke-width="1.6"/>',
         f'<rect x="16" y="16" width="{w - 32}" height="{h - 32}" rx="3" fill="#fafafa" '
         f'stroke="#d9dde2" stroke-width="1"/>']
    for i in range(n):
        c, r_ = i % cols, i // cols
        o.append(f'<circle cx="{ox + c * pitch:.1f}" cy="{oy + r_ * pitch:.1f}" '
                 f'r="{r:.1f}" fill="{C_PAD}"/>')
    o.append(f'<circle cx="22" cy="22" r="3.4" fill="{C_OUTLINE}"/>')
    o.append(f'<text x="{w / 2}" y="{h - 6}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="9.5" fill="{C_MUTED}">'
             f'{rows}×{cols} 阵列 · {n} 球</text>')
    o.append("</svg>")
    return "\n".join(o)


# ------------------------------------------------------- 2b. BGA 按真实尺寸出图
#
# 此前网格族（BGA/LGA/CSP）一律出占位图，红线是「无球列、无几何来源，不猜」。
# 那条线本身没错，但把「没有来源」和「没去找」混成了一件事：TI 数据手册末页的
# PACKAGE OUTLINE 就是带尺寸的机械图，`qc/pkg_geometry.py` 把它读成了结构化的
# 几何（并逐条互证）。拿到几何之后，球阵与立体图就是**按标注出的尺寸画**，
# 不是猜 —— 所以这两张图带 `data-em-geometry` 标记，且只在 state 允许时出现。

#: BGA 行标惯例：跳过 I / O / Q（与 TI 机械图一致：12 行 = A..M 去掉 I）。
_ROW_SKIP = frozenset("IOQ")


def _grid_letters(n: int) -> list[str]:
    out: list[str] = []
    for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        if ch in _ROW_SKIP:
            continue
        out.append(ch)
        if len(out) >= n:
            break
    return out


def _mm(v, nd: int = 2) -> str:
    try:
        return f"{float(v):.{nd}f}"
    except (TypeError, ValueError):
        return str(v)


def bga_footprint_svg(geom: dict) -> str:
    """2D 俯视球阵：body 外框 + 真实 pitch 的球阵 + 行/列标 + 1 脚切角。

    所有几何量都来自 `geom`（原厂机械图，带页码与 bbox 证据）。尺寸缺失的那几项
    **不补默认值**：少一项就整体降级回占位图，由调用方决定。
    """
    D = float(geom["body_x"]["nominal"])
    E = float(geom["body_y"]["nominal"])
    pitch = float(geom["pitch"])
    rows, cols = int(geom["rows"]), int(geom["cols"])
    bmax = float(geom["ball_diameter"]["max"])
    bmin = float(geom["ball_diameter"]["min"])

    w, h = 340, 262
    left, top, right, bottom = 34, 22, 14, 46
    aw, ah = w - left - right, h - top - bottom
    scale = min(aw / D, ah / E)
    bw, bh = D * scale, E * scale
    bx = left + (aw - bw) / 2
    by = top + (ah - bh) / 2

    pitch_px = pitch * scale
    r = bmax / 2 * scale
    span_x = (cols - 1) * pitch_px
    span_y = (rows - 1) * pitch_px
    ox = bx + (bw - span_x) / 2
    oy = by + (bh - span_y) / 2

    # 1 脚切角（左上），边长取 0.8mm 等效，且不超过本体 1/5
    ch = min(0.8 * scale, min(bw, bh) / 5)
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" '
         f'height="{h}" style="max-width:100%;height:auto" role="img" '
         f'data-em-geometry="ball-grid" '
         f'aria-label="{esc(geom.get("family") or "BGA")} {_mm(D)}×{_mm(E)}mm '
         f'{rows}×{cols} ball grid">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<path d="M{bx + ch:.1f} {by:.1f} H{bx + bw:.1f} V{by + bh:.1f} '
         f'H{bx:.1f} V{by + ch:.1f} Z" fill="#fafafa" stroke="{C_OUTLINE}" '
         f'stroke-width="1.6"/>',
         f'<circle cx="{bx + ch * 0.45:.1f}" cy="{by + ch * 0.45:.1f}" r="3" '
         f'fill="{C_OUTLINE}"/>']

    for i in range(rows):
        for j in range(cols):
            cx = ox + j * pitch_px
            cy = oy + i * pitch_px
            o.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.2f}" '
                     f'fill="{C_PAD}" stroke="#8e2a20" stroke-width="0.5"/>')

    letters = _grid_letters(rows)
    for i, ch_ in enumerate(letters):
        o.append(f'<text x="{bx - 6:.1f}" y="{oy + i * pitch_px + 2.4:.1f}" '
                 f'text-anchor="end" font-family="Arial,Helvetica,sans-serif" '
                 f'font-size="7" fill="{C_MUTED}">{ch_}</text>')
    for j in range(cols):
        o.append(f'<text x="{ox + j * pitch_px:.1f}" y="{by - 5:.1f}" '
                 f'text-anchor="middle" font-family="Arial,Helvetica,sans-serif" '
                 f'font-size="7" fill="{C_MUTED}">{j + 1}</text>')

    o.append(f'<text x="{w / 2}" y="{h - 26}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="10.5" fill="{C_TEXT}">'
             f'{esc(geom.get("family") or "BGA")} · {_mm(D)} × {_mm(E)} mm · '
             f'{rows}×{cols} = {geom["ball_count"]} ball</text>')
    o.append(f'<text x="{w / 2}" y="{h - 10}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="10" fill="{C_MUTED}">'
             f'pitch e {_mm(pitch)} mm · 球径 ⌀{_mm(bmin)}~{_mm(bmax)} mm · '
             f'图纸 {esc(geom.get("drawing_code") or "—")}</text>')
    o.append("</svg>")
    return "\n".join(o)


def _iso(x: float, y: float, z: float, S: float, ox: float, oy: float) -> tuple[float, float]:
    """标准等轴测投影：x 轴向右下、y 轴向左下、z 轴向上。

    调用方约定 **z=A 是球面**（把封装翻过来画），于是可见的顶面就是焊球面 ——
    这既保留了等轴测的立体感，又让 144 个球真的看得到，不必用「透视」那种
    说不清的画法。
    """
    c = 0.8660254037844387
    return (x - y) * c * S + ox, (x + y) * 0.5 * S - z * S + oy


def bga_3d_svg(geom: dict) -> str:
    """3D 等轴测：按 body / 总高 / pitch / 球径 画带厚度的本体，球面朝上铺满真实球阵。

    高度按真实比例（10×10×1.91 本来就薄），不夸大 —— 夸大会让图好看但说谎。
    厚度靠侧面明暗与顶面高光区分，而不是靠把 1.91 画成 4。
    """
    D = float(geom["body_x"]["nominal"])
    E = float(geom["body_y"]["nominal"])
    A = float(geom["height"]["max"])
    stand = float(geom["standoff"]["max"])
    pitch = float(geom["pitch"])
    rows, cols = int(geom["rows"]), int(geom["cols"])
    bmax = float(geom["ball_diameter"]["max"])

    w, h = 340, 262
    c = 0.8660254037844387
    shape_h = (D + E) * 0.5 + A
    S = min(300 / ((D + E) * c), 200 / shape_h)
    ox, oy = w / 2, 24 + A * S
    P = lambda x, y, z: _iso(x, y, z, S, ox, oy)                 # noqa: E731

    def poly(pts, fill, stroke="", op=1.0, sw=0.9):
        d = " ".join(f"{p[0]:.2f},{p[1]:.2f}" for p in pts)
        st = f' stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"' if stroke else ""
        return f'<polygon points="{d}" fill="{fill}" fill-opacity="{op}"{st}/>'

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" '
         f'height="{h}" style="max-width:100%;height:auto" role="img" '
         f'data-em-geometry="3d" '
         f'aria-label="{esc(geom.get("family") or "BGA")} isometric {_mm(D)}×{_mm(E)}×{_mm(A)}mm">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         '<defs>'
         '<linearGradient id="bg3a" x1="0" y1="0" x2="0.3" y2="1">'
         '<stop offset="0" stop-color="#4a4a4a"/><stop offset="1" stop-color="#232323"/>'
         '</linearGradient>'
         '<linearGradient id="bg3b" x1="0" y1="0" x2="0.3" y2="1">'
         '<stop offset="0" stop-color="#333"/><stop offset="1" stop-color="#141414"/>'
         '</linearGradient>'
         '<linearGradient id="bg3top" x1="0" y1="0" x2="0.75" y2="1">'
         '<stop offset="0" stop-color="#3d3d3d"/><stop offset="1" stop-color="#2a2a2a"/>'
         '</linearGradient>'
         '<radialGradient id="bg3ball" cx="0.36" cy="0.3" r="0.75">'
         '<stop offset="0" stop-color="#f0cfc6"/><stop offset="0.55" stop-color="#c97362"/>'
         '<stop offset="1" stop-color="#8e3a2c"/></radialGradient>'
         '</defs>']

    # 两个朝向观察者的侧面（画在顶面之前：离观察者更远）
    o.append(poly([P(D, 0, 0), P(D, E, 0), P(D, E, A), P(D, 0, A)],
                  "url(#bg3a)", "#0e0e0e"))
    o.append(poly([P(0, E, 0), P(D, E, 0), P(D, E, A), P(0, E, A)],
                  "url(#bg3b)", "#0e0e0e"))

    # 顶面 = 球面（z=A）
    o.append(poly([P(0, 0, A), P(D, 0, A), P(D, E, A), P(0, E, A)],
                  "url(#bg3top)", "#0e0e0e"))

    # 球阵：真实 pitch / 球径。等轴测下圆压成椭圆，纵向再压 0.5。
    r = bmax / 2 * S
    x0 = (D - (cols - 1) * pitch) / 2
    y0 = (E - (rows - 1) * pitch) / 2
    for i in range(rows):
        for j in range(cols):
            px, py = P(x0 + j * pitch, y0 + i * pitch, A)
            o.append(f'<ellipse cx="{px:.2f}" cy="{py:.2f}" rx="{r:.2f}" '
                     f'ry="{r * 0.52:.2f}" fill="url(#bg3ball)" '
                     f'stroke="#7d2f24" stroke-width="0.35"/>')

    # 1 脚标记：球面上的 A1 角（切角三角形，与 2D 图呼应）
    ax, ay = P(x0, y0, A)
    o.append(f'<polygon points="{ax - r * 1.2:.2f},{ay - r * 1.5:.2f} '
             f'{ax + r * 1.1:.2f},{ay - r * 0.45:.2f} '
             f'{ax - r * 0.6:.2f},{ay + r * 0.7:.2f}" '
             f'fill="none" stroke="#f0cfc6" stroke-width="1.2"/>')

    # 长宽标注：贴两条前缘，落在图形外侧
    def label(px, py, text, anchor="middle"):
        return (f'<text x="{px:.1f}" y="{py:.1f}" text-anchor="{anchor}" '
                f'font-family="Arial,Helvetica,sans-serif" font-size="9" '
                f'fill="{C_MUTED}">{text}</text>')

    mx, my = P(D, E / 2, 0)
    o.append(label(mx + 4, my + 13, f"{_mm(D)} mm", anchor="start"))
    mx2, my2 = P(D / 2, E, 0)
    o.append(label(mx2 - 4, my2 + 13, f"{_mm(E)} mm", anchor="end"))

    o.append(label(w / 2, h - 24,
                   f'{esc(geom.get("family") or "BGA")} · {_mm(D)} × {_mm(E)} × '
                   f'{_mm(A)} mm · 球面朝上（等轴测示意）'))
    o.append(label(w / 2, h - 8,
                   f'{rows}×{cols} = {geom["ball_count"]} ball · pitch {_mm(pitch)} mm · '
                   f'A1 standoff {_mm(stand, 3)} mm · '
                   f'图纸 {esc(geom.get("drawing_code") or "—")}'))
    o.append("</svg>")
    return "\n".join(o)


#: BGA 占位图的两张卡。旧版两卡**画同一张图、印同一句话**（那句主语还是「封装几何」），
#: 既在 3D 卡上说错了对象，又把一条边界断言硬编码进 SVG —— 与下方「工程模型边界」小节
#: 并存就是第二个事实源（A5「边界文案只能由 state 派生」正是为了掐掉这种第二事实源）。
#: 现在每张卡只说自己的对象，理由一律指向边界小节，不在这里重复断言。
_BGA_PLACEHOLDER_ROLES: dict[str, dict[str, str]] = {
    "footprint": {"alt": "package placeholder", "title": "封装占位图",
                  "note": "此格不绘制图形，理由见下方「工程模型边界」。"},
    "model3d": {"alt": "3D placeholder", "title": "3D 占位图",
                "note": "此格无立体模型，理由见下方「工程模型边界」。"},
}


def _bga_placeholder(pkg: str, role: str) -> str:
    """网格族占位图：**不复述边界断言**，只说明这一格不画东西、理由在下方小节。

    红线保持：无球列、无焊盘、无 3D 节点、无 `data-em-geometry` 标记、不含任何数值+单位
    （A1/A2 判据都靠这个），也不出现「未核验/待核」字样（A3 的作用对象）。
    """
    spec = _BGA_PLACEHOLDER_ROLES.get(role) or _BGA_PLACEHOLDER_ROLES["footprint"]
    label = f"{pkg} {spec['alt']}".strip()
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 340 180" '
        f'role="img" aria-label="{esc(label)}">'
        '<rect width="340" height="180" fill="#fff"/>'
        '<rect x="10" y="10" width="320" height="160" rx="4" fill="none" '
        f'stroke="{C_OUTLINE}" stroke-width="1.2" stroke-dasharray="6 5" opacity="0.55"/>'
        f'<text x="170" y="70" text-anchor="middle" fill="{C_TEXT}" '
        f'font-size="15">{esc(pkg)} · {spec["title"]}</text>'
        f'<text x="170" y="108" text-anchor="middle" fill="{C_MUTED}" '
        f'font-size="11.5">{spec["note"]}</text></svg>')


def _boundary_section(state: dict) -> str:
    """「工程模型边界」小节：逐条由 ``EM.render_notes`` 生成。

    渲染器**禁止**在这里或其它任何位置手写这些字样（门禁 A5 会逐字比对；
    `tests/test_engineering_model.py` 另有源码级断言）。空列表也照样输出小节，
    否则门禁无法区分「没有要说的」与「漏印了」。
    """
    items = "".join(f"<li>{esc(n)}</li>" for n in EM.render_notes(state))
    return (
        '<section class="em-boundary" data-em-boundary="engineering-model" '
        'style="max-width:1080px;margin:16px auto 0;background:#fff;border:1px solid #e3e7ec;'
        'border-radius:8px;padding:12px 16px">'
        '<h2 style="font-size:13px;margin:0 0 8px;color:#5b6673;text-align:left">工程模型边界</h2>'
        f'<ul style="margin:0;padding-left:18px;font-size:12px;color:#5b6673;'
        f'line-height:1.8;text-align:left">{items}</ul></section>')


def _bga_unverified_page(mpn: str, pkg: str, reasons: list[str], state: dict | None = None) -> str:
    return (
        '<!DOCTYPE html><html lang="zh-CN" data-em-page="symbols"><head><meta charset="utf-8">'
        f'<title>{esc(mpn)} · BGA 球位待核</title></head>'
        '<body style="font-family:Arial,sans-serif;padding:28px;line-height:1.8">'
        f'<h1>{esc(mpn)} · {esc(pkg)} · BGA 球位待核</h1>'
        '<p>缺少完整可信的 PDF 球位与功能映射，或已有映射未通过校验。'
        '不生成原理图符号、封装球阵列或 3D 模型；不猜脚号或典型球数。</p>'
        f'<p>验证状态：unresolved；原因：{esc(", ".join(reasons))}</p>'
        '<p>请先完成原 PDF 逐球核验。此说明页不是工程验收通过。</p>'
        f'{_boundary_section(state or {})}</body></html>')


def _board_svg(pkg: str) -> str:
    """模块/开发板：没有标准封装，画个板卡轮廓，明确标注不适用。"""
    w = h = 260
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" style="max-width:100%;height:auto" '
         f'role="img" aria-label="{esc(pkg or "module")} board outline">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<rect x="30" y="40" width="{w - 60}" height="{h - 100}" rx="6" fill="#eef3f7" '
         f'stroke="{C_OUTLINE}" stroke-width="1.6"/>']
    for cx, cy in ((48, 58), (w - 48, 58), (48, h - 78), (w - 48, h - 78)):
        o.append(f'<circle cx="{cx}" cy="{cy}" r="6" fill="#ffffff" stroke="#9aa4ad" stroke-width="1.4"/>')
    o.append(f'<rect x="{w / 2 - 34}" y="{h / 2 - 26}" width="68" height="52" rx="3" '
             f'fill="#333333" opacity="0.75"/>')
    o.append(f'<text x="{w / 2}" y="{h - 30}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="11" fill="{C_MUTED}">'
             f'{esc(pkg)}</text>')
    o.append(f'<text x="{w / 2}" y="{h - 14}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="10" fill="{C_MUTED}">'
             f'模块/开发板，无标准封装图</text>')
    o.append("</svg>")
    return "\n".join(o)


def _board_3d(pkg: str) -> str:
    """模块/开发板：画一块薄板，不是芯片本体。"""
    w, h = 340, 250
    cx, cy = w / 2, h / 2 + 10
    bw, bh, depth = 190, 96, 26
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
         f'style="max-width:100%;height:auto" '
         f'role="img" aria-label="{esc(pkg or "board")} 3D model">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<polygon points="{cx - bw / 2},{cy - bh / 2} {cx + bw / 2},{cy - bh / 2} '
         f'{cx + bw / 2},{cy + bh / 2} {cx - bw / 2},{cy + bh / 2}" fill="#1f6b4a"/>',
         f'<polygon points="{cx - bw / 2},{cy - bh / 2} {cx - bw / 2 + depth},{cy - bh / 2 - depth} '
         f'{cx + bw / 2 + depth},{cy - bh / 2 - depth} {cx + bw / 2},{cy - bh / 2}" fill="#2f8a61"/>',
         f'<polygon points="{cx + bw / 2},{cy - bh / 2} {cx + bw / 2 + depth},{cy - bh / 2 - depth} '
         f'{cx + bw / 2 + depth},{cy + bh / 2 - depth} {cx + bw / 2},{cy + bh / 2}" fill="#14513a"/>']
    # 板上元件示意
    for dx, dy, ww, hh in ((-58, -18, 52, 36), (18, -26, 40, 30), (30, 16, 34, 20)):
        o.append(f'<rect x="{cx + dx}" y="{cy + dy}" width="{ww}" height="{hh}" rx="3" fill="#2b2b2b"/>')
    for dx in (-70, 70):
        o.append(f'<circle cx="{cx + dx}" cy="{cy - 26}" r="7" fill="#f2f2f2" stroke="#9aa4ad" stroke-width="1"/>')
        o.append(f'<circle cx="{cx + dx}" cy="{cy + 26}" r="7" fill="#f2f2f2" stroke="#9aa4ad" stroke-width="1"/>')
    o.append(f'<text x="{w / 2}" y="{h - 10}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="11" fill="{C_MUTED}">'
             f'{esc(pkg)} · 板卡示意</text>')
    o.append("</svg>")
    return "\n".join(o)


# ---------------------------------------------------------------- 3. 3D 模型
def model3d_svg(pins: list[tuple[int, str]], pkg: str = "",
                geom: dict | None = None) -> str:
    """3D 示意：黑色锥形本体 + 米色海鸥翼引脚（对齐华秋 EDA 模型页的观感）。

    PDF 里没有 3D 数据，这一张只能按封装族程序化画；要真渲染需接 EDA 模型库。
    两侧/海鸥翼：侧向引脚；QFN：无外伸引脚，只在下沿露焊盘；板卡：画板。
    BGA 例外：若拿到了原厂机械图抽出的几何（body/总高/standoff/pitch/球径/球数），
    就按那些尺寸画等轴测，不再出占位图——那是**按标注画**，不是猜。
    """
    if is_bga(pkg):
        if geom:
            return bga_3d_svg(geom)
        return _bga_placeholder(pkg, "model3d")
    fam = pkg_family(pkg)
    n = len(pins)
    w, h = 340, 262
    cx, cy = w / 2, h / 2 + 4
    if fam == "other":
        return _board_3d(pkg)

    if fam in ("qfn", "grid"):
        bw, bh, taper = 126, 96, 5          # 无引脚封装：方、薄
    else:
        bw, bh, taper = 96, 132, 9          # 有侧向引脚：窄而高，接近参考图比例
    top_w = bw - 2 * taper
    top_y, bot_y = cy - bh / 2, cy + bh / 2

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
         f'style="max-width:100%;height:auto" role="img" '
         f'aria-label="{esc(pkg or "package")} 3D model">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         '<defs>',
         '<linearGradient id="b3d" x1="0" y1="0" x2="0.85" y2="1">'
         '<stop offset="0" stop-color="#3a3a3a"/><stop offset="0.35" stop-color="#1b1b1b"/>'
         '<stop offset="1" stop-color="#050505"/></linearGradient>',
         '<linearGradient id="lead" x1="0" y1="0" x2="0" y2="1">'
         '<stop offset="0" stop-color="#efe9dc"/><stop offset="0.5" stop-color="#d8d0bf"/>'
         '<stop offset="1" stop-color="#b3a992"/></linearGradient>',
         '<radialGradient id="shd"><stop offset="0" stop-color="#000" stop-opacity="0.16"/>'
         '<stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>',
         '</defs>',
         # 落地阴影
         f'<ellipse cx="{cx}" cy="{bot_y + 14}" rx="{bw * 0.78:.0f}" ry="16" fill="url(#shd)"/>']

    def lead(y: float, sgn: int, th: float) -> None:
        """一根海鸥翼引脚：横段 + 外端下折的小脚。"""
        x0 = cx + sgn * (bw / 2 - 6)
        x1 = x0 + sgn * 30
        lo, hi = min(x0, x1), max(x0, x1)
        o.append(f'<rect x="{lo:.1f}" y="{y:.1f}" width="{30}" height="{th:.1f}" rx="2" '
                 f'fill="url(#lead)" stroke="#a99f88" stroke-width="0.6"/>')
        # 下折脚
        fx = x1 - sgn * 3 - (4 if sgn < 0 else 0)
        o.append(f'<path d="M{fx:.1f},{y + th:.1f} h6 v6 h-6 z" fill="#c4bba6" '
                 f'stroke="#a99f88" stroke-width="0.6"/>')

    if fam in ("dual", "sot", "qfp"):
        per_side = max(2, (n + 1) // 2)
        # 引脚组必须完全落在本体高度内，否则会从本体上方/下方戳出来
        pitch = min(21.0, (bh - 18) / max(1, per_side - 1))
        th = max(4.2, min(9.0, pitch * 0.52))
        span = pitch * (per_side - 1)
        y0 = cy - span / 2
        for i in range(per_side):
            y = y0 + i * pitch - th / 2
            lead(y, -1, th)
            lead(y, 1, th)

    # 本体：上窄下宽的锥形，圆角靠同色描边模拟
    o.append(f'<polygon points="{cx - top_w / 2},{top_y} {cx + top_w / 2},{top_y} '
             f'{cx + bw / 2},{bot_y} {cx - bw / 2},{bot_y}" fill="url(#b3d)" '
             f'stroke="#0a0a0a" stroke-width="9" stroke-linejoin="round"/>')
    # 左侧高光 + 顶面窄边
    o.append(f'<polygon points="{cx - top_w / 2 + 3},{top_y + 4} {cx - bw / 2 + 4},{bot_y - 3} '
             f'{cx - bw / 2 + 12},{bot_y - 3} {cx - top_w / 2 + 10},{top_y + 4}" '
             f'fill="#ffffff" opacity="0.07"/>')
    o.append(f'<polygon points="{cx - top_w / 2},{top_y} {cx - top_w / 2 + 13},{top_y - 13} '
             f'{cx + top_w / 2 + 13},{top_y - 13} {cx + top_w / 2},{top_y}" fill="#4f4f4f"/>')

    if fam == "qfn":
        import math
        k = max(3, min(10, math.ceil(math.sqrt(n))))
        step = (bw - 22) / k
        for i in range(k):
            x = cx - bw / 2 + 11 + i * step
            o.append(f'<rect x="{x:.1f}" y="{bot_y - 4}" width="{step * 0.5:.1f}" height="8" '
                     f'rx="1.5" fill="url(#lead)" stroke="#a99f88" stroke-width="0.5"/>')
    elif fam == "grid":
        for r in range(4):
            for c in range(7):
                o.append(f'<circle cx="{cx - 48 + c * 16:.1f}" cy="{top_y - 4 + r * 4:.1f}" '
                         f'r="1.7" fill="#8b8272"/>')

    # 1 脚凹点（左上）
    dx, dy = cx - top_w / 2 + 22, top_y - 6
    o.append(f'<ellipse cx="{dx}" cy="{dy}" rx="8.5" ry="3.6" fill="#8d8476"/>')
    o.append(f'<ellipse cx="{dx}" cy="{dy - 1.2}" rx="5.8" ry="2.2" fill="#6b6357"/>')
    o.append(f'<text x="{w / 2}" y="{h - 8}" text-anchor="middle" '
             f'font-family="Arial,Helvetica,sans-serif" font-size="11" fill="{C_MUTED}">'
             f'{esc(pkg)} · 3D 示意</text>')
    o.append("</svg>")
    return "\n".join(o)



# ---------------------------------------------------------------- 三图合成一页
PANELS = [("原理图符号", "由 pin_configuration 生成", "symbol"),
          ("封装", "按封装类型 + 脚数生成", "footprint"),
          ("3D 模型", "按封装类型程序化绘制", "model3d")]


def _no_pins_card(mpn: str, declared: int, uncertain: bool = False) -> str:
    """引脚表没解析出来时的原理图符号格：给说明卡片，而不是留空。"""
    if uncertain:
        tail = (f"封装按 <b>{declared}</b> 脚参考封装绘制，<br>"
                "<b>脚数未从 PDF 确认</b>，请以原始 Datasheet 为准。")
    else:
        tail = (f"封装与 3D 模型按规格书声明的 <b>{declared}</b> 脚绘制，<br>"
                "引脚功能请以原始 Datasheet 的引脚表为准。")
    return (
        '<div style="padding:36px 18px;color:#5b6673;font-size:13px;line-height:1.7">'
        f"<b style='color:#222'>{esc(mpn)}</b><br>"
        "该 PDF 未包含可解析的引脚表（pin table），<br>"
        "因此无法生成带引脚名的原理图符号。<br><br>"
        f"{tail}"
        "</div>")


def _is_board_name(pkg: str) -> bool:
    """封装名是否属于「板卡/模块」这类没有标准封装的东西。

    注意 `EVM` 要单独判：很多板卡的封装字段就写「EVM」，不含
    EVALUATION / BOARD 等关键词，但同样没有标准封装。
    """
    p = (pkg or "").upper()
    if re.search(r"(?<![A-Z])EVM(?![A-Z])", p):
        return True
    return any(k in p for k in ("PCB", "BOARD", "MODULE", "KIT", "BOOSTERPACK",
                                "REFERENCE", "EVALUATION", "DONGLE", "CARD"))


# 封装族 -> 常见脚数。仅在「封装名已知但脚数没解析出来」时用于画一版参考封装。
TYPICAL_PINS = {
    "WCSP": 30, "CSP": 36, "WLCSP": 30, "BGA": 144, "FCBGA": 144, "UBGA": 100,
    "QFN": 32, "VQFN": 32, "TQFN": 32, "WQFN": 32, "UQFN": 32, "HVQFN": 40,
    "DFN": 8, "VSON": 6, "WSON": 6, "USON": 6, "SON": 8,
    "SOIC": 8, "SOP": 8, "SSOP": 20, "TSSOP": 16, "VSSOP": 8, "MSOP": 8,
    "LQFP": 64, "TQFP": 64, "QFP": 64, "SOT": 3, "DIP": 8, "YFF": 32,
}


def _typical_pins(pkg: str) -> int:
    """按封装族猜一个常见脚数（0 = 猜不出）。名字里的数字优先。"""
    if is_bga(pkg):
        return 0
    s = (pkg or "").upper()
    m = re.search(r"(\d+)", s)
    if m:
        n = int(m.group(1))
        if 2 <= n <= 400:
            return n
    for fam, n in TYPICAL_PINS.items():
        if re.search(rf"(?<![A-Z]){fam}(?![A-Z])", s):
            return n
    return 0


def _board_page(mpn: str, pkg_name: str, onboard: str = "", state: dict | None = None) -> str:
    """板卡类三视图页：给说明与关键规格，而不是空白或 404。

    pkg_name 是**本型号的形态**（如 Evaluation Board (assembled PCB)）；
    onboard 是板上器件的型号与封装，必须分开写，否则会被读成「本型号封装是 WQFN」。
    """
    body = (
        '<div style="padding:28px 20px;color:#5b6673;font-size:13px;line-height:1.8">'
        f"<b style='color:#222'>{esc(mpn)}</b><br>"
        f"封装类型：{esc(pkg_name or 'Board / Module')}<br>"
        + (f"板载器件：{esc(onboard)}<br>" if onboard else "")
        + "<br>"
        "该型号是评估板 / 参考板 / 模块类产品，<br>"
        "没有单一标准封装，也不存在唯一的引脚定义，<br>"
        "因此不生成封装图与 3D 模型。<br><br>"
        "实际使用的芯片型号、板级连接与引脚定义，<br>"
        "请以原始 Datasheet / 用户指南为准。"
        "</div>")
    return "\n".join([
        '<!DOCTYPE html><html lang="zh-CN" data-em-page="symbols" '
        'data-em-subject="board"><head><meta charset="utf-8">',
        f"<title>{esc(mpn)} 三视图</title>",
        "<style>",
        "body{margin:0;padding:24px;background:#f4f6f8;"
        "font-family:-apple-system,'Segoe UI',Arial,sans-serif;color:#222}",
        ".card{background:#fff;border:1px solid #e3e7ec;border-radius:8px;padding:16px;"
        "max-width:1080px;margin:0 auto}",
        ".cap{font-size:13px;color:#5b6673;margin:0 0 8px}",
        "h1{font-size:17px;margin:0 0 16px;text-align:center}",
        ".note{font-size:12px;color:#8a939c;margin-top:16px;text-align:center}",
        "</style></head><body>",
        f"<h1>{esc(mpn)} · 板卡 / 模块类（无标准封装）</h1>",
        '<div class="card"><div class="cap">封装说明</div>',
        body,
        "</div>",
        _boundary_section(state or {}),
        '<p class="note">板卡与模块没有唯一封装与引脚定义，故不生成三视图图形；'
        "芯片级规格请查阅对应芯片的 Datasheet。</p>",
        "</body></html>",
    ])


def render_page(doc: dict, pkg_dir: Path | None = None,
                url_prefix: str = "/upload/pkg", inline_pkg: bool = False) -> str:
    """生成三视图页。

    pkg_dir 给定时，封装和 3D 两格改成**引用共享封装图**（`{KEY}.svg`），不再内联生成：
    封装图只由 (族, 脚数) 决定，跟型号无关，598,891 个型号去重后只有几百种。
    原理图符号必须内联——它带引脚名，是型号特有的。

    ``inline_pkg``：把共享图**内联**进页面，而不是写 `<img src="/upload/pkg/…">`。
    交付包必须开这个 —— 包是脱离站点打开的，站内绝对路径在那里就是裂图
    （实测 V8 的 ADS1201U 页面中间/右边两格全是空框）。
    """
    raw_pkg = package_of(doc, 0)
    view = canonical_view(doc)
    identity = str((view.get("basic_info") or {}).get("identity") or "")
    bga = is_bga(raw_pkg)
    # 非 BGA 芯片保留旧行为；BGA 和规范板卡身份统一消费发布契约。
    if bga or identity in BOARD_TYPES:
        doc = view
    mpn = (doc.get("basic_info") or {}).get("mpn") or ""
    # 三产物状态的**唯一**派生点：符号 / 封装轮廓 / 3D 球阵几何各自独立。
    # 派生不落库，只喂给卡片副标题与「工程模型边界」小节（文案唯一来源在 EM）。
    state = EM.derive_state(doc, pkg_dir)
    if bga and identity not in BOARD_TYPES:
        validation = bga_pin_validation(doc)
        if validation["status"] != "pass":
            return _bga_unverified_page(mpn, raw_pkg, validation["reasons"], state)
    pins = pins_of(doc)
    declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)

    # 身份为评估板 / 参考板 / 模块时，即便带出了板载器件的引脚表，也不能画成
    # 「本型号的封装与引脚」—— 引脚属于板载器件，不属于这块板。直接在入口短路，
    # 否则下面的 `len(pins) < 2` 判断会被板载引脚数绕过（CF-QC28-012）。
    _pkg_raw = str(((doc.get("specs") or {}).get("package") or {}).get("type") or "").strip()
    _identity = str((doc.get("basic_info") or {}).get("identity") or "").strip().lower()
    if _identity in BOARD_TYPES or _is_board_name(_pkg_raw):
        _pkg_obj = (doc.get("specs") or {}).get("package") or {}
        _onb = str(_pkg_obj.get("onboard_device") or "").strip()
        if _onb and _pkg_obj.get("onboard_package"):
            mounted = _pkg_obj.get("onboard_package_status") == "mounted_verified"
            note = _pkg_obj["onboard_package"] if mounted else (
                f"{_pkg_obj['onboard_package']}（数据手册封装选项，未确认实际焊装）")
            _onb = f"{_onb} · {note}"
        # 本分支已判定为板卡/模块页（identity 或封装名）；状态跟着页面主体走。
        return _board_page(mpn, _pkg_raw, _onb,
                           EM.derive_state(doc, pkg_dir, board_subject=True))

    # 引脚表没解析出来（PDF 里没有 pin table）时，用封装声明的总脚数兜底：
    # 画一个「未命名引脚」的封装与 3D，原理图符号格改成说明文字。
    # 这样三视图三格仍然齐全，不至于整个产物缺失。
    unnamed = False
    uncertain_pins = False
    if len(pins) < 2 and declared >= 2:
        pins = [(i, f"PIN{i}") for i in range(1, declared + 1)]
        unnamed = True
    if len(pins) < 2:
        # 板卡 / 参考板 / 模块：既无引脚表也无脚数声明，物理上没有标准封装可画。
        # 但交付清单承诺三视图这一件，所以给一份说明页（不是空白页）。
        pkg_name = str(((doc.get("specs") or {}).get("package") or {}).get("type") or "").strip()
        if _is_board_name(pkg_name):
            # 这里已按封装名判为板卡页（不是新增推断）；状态跟着页面主体走，
            # 否则会出现「页说板卡、状态说芯片缺模板」的自相矛盾页（门禁 A4）。
            return _board_page(mpn, pkg_name, "",
                               EM.derive_state(doc, pkg_dir, board_subject=True))
        # 封装名已知但脚数没解析出来（WCSP / QFN / YFF 这类）：
        # 用族名对应的典型脚数画一版参考封装，并明确标注脚数未确认。
        guess = _typical_pins(pkg_name)
        if guess >= 2:
            pins = [(i, f"PIN{i}") for i in range(1, guess + 1)]
            declared = guess
            unnamed = True
            uncertain_pins = True
            # 脚数是按族名猜的 → 封装 key 不可信，模板臂关闭（否则文案会声称
            # 「按共享模板 X 绘制」而实际是内联绘制）
            state = EM.derive_state(doc, pkg_dir, pins_unconfirmed=True)
        else:
            return ""
    pkg = package_of(doc, len(pins))
    # key 只用**声明值** + `declared`：引脚表长度与 SEO 正则都不参与
    # （见 `pkg_key` / `pkg_type_of`），否则页面算一份 key、状态层算另一份，A2 就是这么来的。
    key = pkg_key(pkg_type_of(doc), declared)
    fam = pkg_family(key)
    # 原厂机械图抽出的几何（可能没有）。**取不到就是取不到**：下面两条绘制入口
    # 只有拿到它才画球阵/立体图，否则照旧出占位图 —— 不拿默认值凑。
    geom = PG.geometry_of(doc)

    if unnamed:
        # 没有真实引脚名，原理图符号画不出来，改为说明卡片
        svgs = {"symbol": _no_pins_card(mpn, declared, uncertain_pins),
                "footprint": footprint_svg(pins, pkg, declared, geom),
                "model3d": model3d_svg(pins, pkg, geom)}
        shared = ""
    else:
        low = active_low_of(doc)
        svgs = {"symbol": symbol_svg(pins, f"{mpn} schematic symbol", active_low=low)}
        shared = ""
    # unnamed（脚数未确认）时不能引用共享封装图 —— 共享图按真实脚数画，
    # 与猜出来的脚数可能对不上，宁可内联绘制。
    if pkg_dir and fam != "other" and not uncertain_pins and not bga:   # BGA 功能表不证明共享封装几何
        if (Path(pkg_dir) / f"{key}.svg").exists() and \
           (Path(pkg_dir) / f"{key}.3d.svg").exists():
            shared = key
            if inline_pkg:
                # 交付包脱离站点打开：内联，避免站内绝对路径变成裂图
                svgs["footprint"] = (Path(pkg_dir) / f"{key}.svg").read_text(encoding="utf-8")
                svgs["model3d"] = (Path(pkg_dir) / f"{key}.3d.svg").read_text(encoding="utf-8")
            else:
                alt = f"{esc(key)} package outline, shared across models"
                svgs["footprint"] = (f'<img src="{url_prefix}/{key}.svg" width="320" '
                                     f'height="320" alt="{alt}" loading="lazy" '
                                     f'decoding="async" style="max-width:100%;height:auto" />')
                svgs["model3d"] = (f'<img src="{url_prefix}/{key}.3d.svg" width="320" '
                                   f'height="320" alt="{esc(key)} 3D model" loading="lazy" '
                                   f'decoding="async" style="max-width:100%;height:auto" />')
    if not shared and not unnamed:
        svgs["footprint"] = footprint_svg(pins, pkg, declared, geom)
        svgs["model3d"] = model3d_svg(pins, pkg, geom)

    # 标题上的脚数以封装声明为准（BGA 常只解析出少量关键脚）
    n_show = declared if declared > len(pins) else len(pins)
    if unnamed:
        if uncertain_pins:
            pin_note = f"{declared} 脚（引脚表未解析出，脚数按封装族参考值绘制，未确认）"
        else:
            pin_note = f"{declared} 脚（引脚表未从 PDF 解析出，按封装声明脚数绘制）"
    else:
        pin_note = f"{n_show} 脚" + (f"（已解析 {len(pins)} 个）" if n_show > len(pins) else "")
    # 封装类型没声明时别把内部 key（`PKG-UNK`）印到标题上 ——
    # 那是派生用的记号，不是给人看的封装名。实测 4 件（7718 件 type 有值）。
    pkg_note = ("封装未声明" if not pkg_type_of(doc)
                else f"{esc(key)}" + ("（共享封装图）" if shared else ""))

    # 页面自述它按哪个主体渲染：板卡页 / 脚数按族名猜（模板臂关闭）。
    # 门禁侧据此用**同样的参数**派生状态，否则「页面用 board_subject=True 派生的文案」
    # 与「review 用默认参数派生的状态」会分叉 —— 实测 7725 页里有 77 页 A5 假阳。
    _self = "" if not uncertain_pins else ' data-em-pins="unconfirmed"'
    parts = ['<!DOCTYPE html><html lang="zh-CN" data-em-page="symbols"'
             f'{_self}><head><meta charset="utf-8">',
             f"<title>{esc(mpn)} 三视图</title>",
             "<style>",
             "body{margin:0;padding:24px;background:#f4f6f8;"
             "font-family:-apple-system,'Segoe UI',Arial,sans-serif;color:#222}",
             ".grid{display:flex;gap:16px;flex-wrap:wrap;max-width:1080px;margin:0 auto}",
             ".card{flex:1 1 300px;background:#fff;border:1px solid #e3e7ec;border-radius:8px;"
             "padding:12px 12px 6px;text-align:center}",
             ".cap{font-size:13px;color:#5b6673;margin:2px 0 10px}",
             ".note{font-size:12px;color:#8a939c;margin-top:6px}",
             "h1{font-size:17px;margin:0 0 16px;text-align:center}",
             "</style></head><body>",
             f"<h1>{esc(mpn)} · {pkg_note} · {pin_note}</h1>", '<div class="grid">']
    # 卡片副标题只允许由状态派生（EM.panel_captions）；模板臂 / 有 3D 示意的臂沿用默认文案。
    # 副标题归 EM；卡内**图形**的说明文字归渲染器，但同样不得复述边界断言：
    # 旧版 BGA 两卡画同一张图、都印「封装几何未核验」，2026-10-31 已换成按卡分工的占位图
    # （`_bga_placeholder`），断言只在下方边界小节说一次。
    caps = EM.panel_captions(state, renders_3d_illustration=not bga)
    for title, sub, k in PANELS:
        if k in caps:
            sub = caps[k]
        if unnamed and k == "symbol":
            sub = "PDF 未含可解析的引脚表"
        parts.append(f'<div class="card"><div class="cap">{title} · {sub}</div>'
                     f'{svgs[k]}</div>')
    parts.append("</div>")
    parts.append(_boundary_section(state))
    tail = ("全部由解析出的 JSON 程序化生成（SVG 矢量），不是 PDF 切图，也不是 AI 生图。"
            "同型号永远一致，可换主题、可缓存。")
    if shared:
        tail += f"　封装与 3D 取自共享封装图库（{esc(key)}），全站同封装型号共用一张。"
    parts.append(f'<p class="note" style="text-align:center;max-width:1080px;margin:16px auto 0">{tail}</p>')
    parts.append("</body></html>")
    return "\n".join(parts)


def verify_footprint(pins: list[tuple[int, str]], pkg: str, declared: int = 0) -> str:
    """回归校验：封装图上画出的脚号必须与 pin_configuration 一一对应。

    踩过的坑：QFN 曾按两侧封装画（只出左右两列），4 脚 VSON 曾按四面各 1 脚画。
    这个检查能把「画错排布」挡在交付前。
    """
    fam = pkg_family(pkg)
    if fam not in ("dual", "sot", "qfn", "qfp"):
        return ""                                  # 阵列/板卡不标脚号
    svg = footprint_svg(pins, pkg, declared)
    drawn = sorted(int(t) for t in re.findall(r"<text[^>]*>(\d+)</text>", svg))
    want = sorted(p[0] for p in pins)
    if drawn != want:
        missing = sorted(set(want) - set(drawn))
        extra = sorted(set(drawn) - set(want))
        return f"脚号不匹配 缺{missing[:6]} 多{extra[:6]}"
    if fam in ("qfn", "qfp") and len(pins) % 4 == 0 and len(pins) >= 8:
        # 四面封装必须真的走四面分支、且四边都分到脚，否则说明退化成了两侧
        if "footprint (quad)" not in svg:
            return "应为四面封装却画成两侧"
        sides = _quad_groups(pins)[:4]
        empty = [s for s, g in zip("LBRT", sides) if not g]
        if empty:
            return f"四面封装有边无脚：{''.join(empty)}"
    return ""


def preview_page(docs: list[tuple[str, dict]], pkg_dir: Path | None = None,
                 url_prefix: str = "/upload/pkg") -> str:
    """把所有型号的三视图汇总到一页，方便横向比对（QA 用，不进站）。"""
    rows = []
    for mpn, doc in docs:
        pkg_raw = package_of(doc, 0)
        view = canonical_view(doc)
        if is_bga(pkg_raw) or (view.get("basic_info") or {}).get("identity") in BOARD_TYPES:
            page = render_page(doc, pkg_dir, url_prefix)
            rows.append(f'<tr><th>{esc(mpn)}</th><td colspan="3">'
                        f'<iframe title="{esc(mpn)} 三视图校验" srcdoc="{esc(page)}" '
                        'width="900" height="480" style="border:0"></iframe></td></tr>')
            continue
        pins = pins_of(doc)
        if len(pins) < 2:
            continue
        pkg = package_of(doc, len(pins))
        declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
        n_show = max(declared, len(pins))
        # 与 `render_page` 同一个派生入口：预览页是 QA 横向比对的依据，
        # 它算出另一个 key 就等于比对了一份不存在的封装。
        key = pkg_key(pkg_type_of(doc), declared)
        use_shared = (pkg_dir is not None and pkg_family(key) != "other"
                      and (Path(pkg_dir) / f"{key}.svg").exists())
        if use_shared:
            fp = f'<img src="{url_prefix}/{key}.svg" width="300" height="300" alt="{esc(key)}" />'
            md = f'<img src="{url_prefix}/{key}.3d.svg" width="300" height="300" alt="{esc(key)} 3D" />'
        else:
            fp = footprint_svg(pins, pkg, declared)
            md = model3d_svg(pins, pkg)
        cells = [symbol_svg(pins, mpn), fp, md]
        tds = "".join(f'<td>{c}</td>' for c in cells)
        # 封装没声明时同样不能把 `PKG-UNK` 这种派生记号印出来
        key_note = "封装未声明" if not pkg_type_of(doc) else esc(key)
        rows.append(f'<tr><th>{esc(mpn)}<span>{key_note} · {n_show} 脚 · '
                    f'{pkg_family(key)}</span></th>{tds}</tr>')
    head = "".join(f"<th>{t}</th>" for t in ("原理图符号", "封装", "3D 模型"))
    return ('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
            "<title>三视图横向比对</title><style>"
            "body{margin:0;padding:24px;background:#f4f6f8;"
            "font-family:-apple-system,'Segoe UI',Arial,sans-serif;color:#222}"
            "h1{font-size:17px;margin:0 0 16px}"
            "table{border-collapse:separate;border-spacing:12px;margin:0 auto}"
            "th{font-size:13px;color:#5b6673;font-weight:600;padding-bottom:4px}"
            "tbody th{text-align:left;white-space:nowrap;font-size:13px;vertical-align:middle}"
            "tbody th span{display:block;font-weight:400;color:#8a939c;font-size:12px;margin-top:4px}"
            "td{background:#fff;border:1px solid #e3e7ec;border-radius:8px;"
            "padding:10px;text-align:center;vertical-align:middle}"
            "</style></head><body>"
            f"<h1>三视图横向比对 · {len(rows)} 个型号</h1><table><thead><tr><th></th>"
            f"{head}</tr></thead><tbody>{''.join(rows)}</tbody></table>"
            '<p style="text-align:center;color:#8a939c;font-size:12px;margin-top:18px">'
            "全部由解析出的 JSON 程序化生成（SVG 矢量），不是 PDF 切图，也不是 AI 生图。</p>"
            "</body></html>")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=str(PARSED))
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--only", default="")
    ap.add_argument("--preview", action="store_true",
                    help="额外输出 _preview.html：所有型号三视图横向比对")
    ap.add_argument("--pkg-lib", default="", help="共享封装图目录；给了就引用而不内联生成")
    ap.add_argument("--pkg-url", default="/upload/pkg", help="共享封装图的站内 URL 前缀")
    ap.add_argument("--inline-pkg", action="store_true",
                    help="把共享封装图内联进页面（交付包必须开：包不挂在站点上，站内路径会裂图）")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    n_ok = 0
    bad = 0
    bga_notes = 0
    seen: list[tuple[str, dict]] = []
    for f in sorted(Path(a.src).glob("*.json")):
        if a.only and a.only.lower() not in f.name.lower():
            continue
        doc = json.loads(f.read_text(encoding="utf-8"))
        page = render_page(doc, Path(a.pkg_lib) if a.pkg_lib else None, a.pkg_url,
                           inline_pkg=a.inline_pkg)
        mpn = (doc.get("basic_info") or {}).get("mpn") or f.stem
        stem = re.sub(r"[^A-Za-z0-9._-]+", "_", mpn)
        if not page:
            print(f"SKIP {mpn:<24} 无 pin_configuration")
            continue
        (out / f"{stem}.html").write_text(page, encoding="utf-8")
        n_ok += 1
        seen.append((mpn, doc))
        pins = pins_of(doc)
        pkg = package_of(doc, len(pins))
        declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
        err = verify_footprint(pins, pkg, declared)
        if is_bga(pkg):
            # 只统计「没有原厂几何、仍出占位图」的 BGA；有几何的已经按标注画出来了，
            # 不该再被算成「几何未核验」（那会让 CLI 汇总结论与页面自相矛盾）。
            if not PG.geometry_of(doc):
                bga_notes += 1
            validation = bga_pin_validation(canonical_view(doc))
            if validation["status"] != "pass":
                err = "BGA unresolved: " + ", ".join(validation["reasons"])
        bad += bool(err)
        print(f"{'BAD ' if err else 'OK  '} {mpn:<24} pins={len(pins):<3} "
              f"{pkg:<22} {pkg_family(pkg):<5} {err}")
    if a.preview and seen:
        (out / "_preview.html").write_text(
            preview_page(seen, Path(a.pkg_lib) if a.pkg_lib else None, a.pkg_url),
            encoding="utf-8")
        print(f"preview -> {out / '_preview.html'}")
    summary = f"　{bad} 份校验未通过" if bad else ("　球位验证完成" if bga_notes else "　封装校验全通过")
    if bga_notes:
        summary += f"；{bga_notes} 份 BGA 无原厂机械图几何，仍出占位图"
    print(f"\n{n_ok} 份 -> {out}" + summary)
    if bad:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
