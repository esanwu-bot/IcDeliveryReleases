import sys, time, json
sys.path.insert(0, '.')
from app import db

def snap():
    d = {r['status']: r['c'] for r in db.q("SELECT status, COUNT(*) c FROM item GROUP BY status")}
    llm = db.q("SELECT COUNT(*) n, SUM(CASE WHEN ok=0 THEN 1 ELSE 0 END) bad FROM llm_usage WHERE created_at >= datetime('now','-10 minutes')")
    r429 = db.q("SELECT COUNT(*) n FROM llm_usage WHERE created_at >= datetime('now','-10 minutes') AND error LIKE '%429%'")
    return d, llm[0]['n'], llm[0]['bad'], r429[0]['n']

d0, n0, b0, r0 = snap()
t0 = time.time()
print('T0 done=%d nodata=%d failed=%d queued=%d | llm10=%d bad=%d r429=%d' % (
    d0.get('done',0), d0.get('nodata',0), d0.get('failed',0), d0.get('queued',0), n0, b0, r0))
print('--- 等待 600 秒 ---')
time.sleep(600)
d1, n1, b1, r1 = snap()
dt = (time.time()-t0)/60
print('T1 done=%d nodata=%d failed=%d queued=%d | llm10=%d bad=%d r429=%d' % (
    d1.get('done',0), d1.get('nodata',0), d1.get('failed',0), d1.get('queued',0), n1, b1, r1))
print('=== 增量 (%.1f 分钟) ===' % dt)
print('done  +%d  (%.2f 个/分钟)' % (d1.get('done',0)-d0.get('done',0), (d1.get('done',0)-d0.get('done',0))/dt))
print('nodata+%d' % (d1.get('nodata',0)-d0.get('nodata',0)))
print('failed+%d' % (d1.get('failed',0)-d0.get('failed',0)))
print('llm调用 +%d  (%.2f 次/分钟)' % (n1-n0, (n1-n0)/dt))
print('429 错误 %d 次' % r1)
