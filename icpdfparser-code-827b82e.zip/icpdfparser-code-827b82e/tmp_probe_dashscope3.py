#!/usr/bin/env python
"""百炼真实体量（11k prompt / 6k output）+ 更高并发，找拐点（临时脚本）。

tmp_probe_dashscope2.py 的 filler 只撑到 1.8k prompt，离生产 11k 还差 6 倍。
本脚本按「字符数 -> 约 token 数」反推，用 4x 长的 filler 撑到 ~11k prompt，
再把并发推到 48/64，看真实配额拐点在哪。
同时对照 enable_thinking 开/关的输出 token 差。
用法: python tmp_probe_dashscope3.py
"""
from __future__ import annotations

import os
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
for name in (".env.local", ".env"):
    p = ROOT / name
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"
KEY = os.getenv("DASHSCOPE_API_KEY", "")
MODEL = os.getenv("DASHSCOPE_MODEL", "qwen-flash")
TIMEOUT = 300
SYS = "You are a JSON emitter. Output ONLY valid JSON matching the schema."

UNIT = ("Reference excerpt from a multi-page power-management datasheet: the device "
        "integrates a buck converter, an LDO, two comparators, a programmable "
        "switching frequency and a spread-spectrum option. Absolute maximum ratings "
        "are listed per supply rail with junction temperature limits, storage "
        "temperature range and ESD ratings. ")


def build_prompt(reps: int) -> str:
    tail = ("Generate a technical datasheet fragment for a buck converter IC. "
            "Output JSON with keys: mpn(str), manufacturer(str), description(str), "
            "features(list of 8 str), electrical(dict of 10 key->num), "
            "package(str), pins(list of 24 obj {num:int,name:str,description:str}). "
            "Each pin description must be 25-40 words of realistic engineering prose. "
            "Each feature must be 18-28 words. The description must be 200-300 words. "
            "Electrical values must be realistic numbers with units.")
    return UNIT * reps + tail


def one(_i: int, reps: int, thinking: bool) -> dict:
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYS},
                     {"role": "user", "content": build_prompt(reps)}],
        "temperature": 0.1,
        "max_tokens": 8000,
        "response_format": {"type": "json_object"},
        "enable_thinking": thinking,
    }
    t0 = time.perf_counter()
    try:
        r = requests.post(f"{BASE}/chat/completions",
                          headers={"Authorization": f"Bearer {KEY}",
                                   "Content-Type": "application/json"},
                          json=payload, timeout=TIMEOUT)
        dt = time.perf_counter() - t0
        if r.status_code != 200:
            return {"ok": False, "code": r.status_code, "secs": dt,
                    "err": r.text[:220], "ct": 0, "pt": 0}
        u = r.json().get("usage", {})
        return {"ok": True, "code": 200, "secs": dt,
                "pt": u.get("prompt_tokens", 0), "ct": u.get("completion_tokens", 0),
                "err": ""}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "code": 0, "secs": time.perf_counter() - t0,
                "err": f"{type(e).__name__}: {e}"[:220], "ct": 0, "pt": 0}


def run(n: int, label: str, reps: int, thinking: bool = False) -> dict:
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=n) as pool:
        futs = [pool.submit(one, i, reps, thinking) for i in range(n)]
        for f in as_completed(futs):
            res.append(f.result())
    wall = time.time() - t0
    ok = [x for x in res if x["ok"]]
    bad = [x for x in res if not x["ok"]]
    limited = [x for x in bad if x["code"] == 429 or "429" in x["err"]
               or "rate" in x["err"].lower() or "throttl" in x["err"].lower()]
    secs = sorted(x["secs"] for x in ok)
    p50 = statistics.median(secs) if secs else 0
    p90 = secs[int(len(secs) * 0.9) - 1] if len(secs) > 1 else (secs[0] if secs else 0)
    ct = sum(x.get("ct", 0) for x in ok)
    pt = sum(x.get("pt", 0) for x in ok)
    print(f"\n[{label}] 并发={n} 墙钟={wall:.1f}s")
    print(f"  成功 {len(ok)}/{n}  限流 {len(limited)}  其他失败 {len(bad)-len(limited)}")
    print(f"  延迟 p50={p50:.1f}s p90={p90:.1f}s max={max(secs) if secs else 0:.1f}s")
    print(f"  RPM={len(ok)/wall*60:.1f}  prompt均值={pt//max(1,len(ok))} "
          f"输出均值={ct//max(1,len(ok))} 总输出={ct}")
    if limited:
        print(f"  429样本: {limited[0]['err'][:200]}")
    if bad and not limited:
        print(f"  失败样本: {bad[0]['err'][:200]}")
    return {"n": n, "ok": len(ok), "limited": len(limited), "p50": p50, "p90": p90,
            "wall": wall, "rpm": len(ok) / wall * 60,
            "ct_avg": ct // max(1, len(ok)), "pt_avg": pt // max(1, len(ok))}


if __name__ == "__main__":
    assert KEY, "DASHSCOPE_API_KEY 未配置"
    print(f"model={MODEL}")
    print("=== 校准 prompt 体量（单发，thinking off）===")
    for reps in (60, 120):
        r = run(1, f"reps={reps}", reps)
    print("\n=== 真实体量阶梯并发 ===")
    rows = []
    for n in (16, 32, 48):
        rows.append(run(n, f"并发{n}", 120))
        time.sleep(10)
    print("\n=== 汇总 ===")
    for r in rows:
        print(f"  并发{r['n']:>3} 成功{r['ok']:>3} 限流{r['limited']:>3} "
              f"p50={r['p50']:>6.1f}s p90={r['p90']:>6.1f}s RPM={r['rpm']:>6.1f} "
              f"pt={r['pt_avg']} out={r['ct_avg']}")
