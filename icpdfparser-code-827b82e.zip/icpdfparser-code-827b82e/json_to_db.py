#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""解析结果落表：data/parsed/*.json -> MySQL 8 / SQLite。

为什么不能只留 JSON 文件
------------------------
1. **复查**：要问「哪些型号没写工作电压」「谁的引脚数对不上封装声明」「规格项命名有几种写法」，
   JSON 只能一个个 open()，几万个型号就没法看了。落表后一句 SQL 出结果。
2. **重修**：改一个规格值，改一行就够，不用整份重新生成；改完 `--export` 回写 JSON 再重跑页面。
3. **追溯**：`raw_json` 原文留底 + `doc_change` 字段级审计，改坏了能回放、能查是谁改的。

表结构（8 张）
-------------
    doc            一型号一行，窄表（只放要筛选的列 + 摘要）
    doc_raw        原文留底，单独放（避免主表被大字段撑肥、扫表变慢）
    doc_spec       规格明细长表 section/name/value/unit/cond
    doc_pin        引脚
    doc_ordering   订购信息
    doc_alt        替代型号
    doc_list       列表类 feature / application / seo_keyword
    doc_i18n       多语言 title/description/meta
    doc_change     修订审计（字段级 old -> new）

为什么规格用长表而不是拆成列
--------------------------
各家 datasheet 的规格项命名根本不统一：`Supply Voltage` / `VCC` / `Operating Supply Voltage`
/ `Supply Voltage Range` 可能指同一件事，也可能不是。拆成固定列必然越改越乱、且每来一家新厂
就得 ALTER TABLE。长表 + name 索引才能跨型号做「这个字段谁没写」这类复查。

用法
----
    python json_to_db.py --init                     建库建表
    python json_to_db.py --load                     全量入库（幂等，内容变了自动升版）
    python json_to_db.py --load --only ADS          只灌匹配的文件
    python json_to_db.py --report                   质量/缺口报表
    python json_to_db.py --export --mpn ADS1201U    从表回写 JSON 到 data/rebuilt/
    python json_to_db.py --sql "SELECT ..."         任意查询（复查用）

后端
----
    --db mysql      本地默认 root:root@127.0.0.1:3306/icpdf（简写）
    --db sqlite     默认，落 data/parsed.sqlite3
    --db mysql://user:pass@host:port/icpdf        完整 DSN
    也可用环境变量 ICPDF_DB，命令行 --db 优先。
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote, urlsplit

from qc import ac_quarantine

ROOT = Path(__file__).resolve().parent
PARSED = ROOT / "data" / "parsed"
REBUILT = ROOT / "data" / "rebuilt"
MANIFEST = ROOT / "data" / "manifest.csv"
SQLITE_PATH = ROOT / "data" / "parsed.sqlite3"

# 本地开发默认值。生产请用 --db 完整 DSN 或 ICPDF_DB 环境变量，不要把密码写进代码。
LOCAL_MYSQL = "mysql://root:root@127.0.0.1:3306/icpdf"


# ------------------------------------------------------------------ 连接
def dsn_parts(dsn: str) -> dict:
    """mysql://root:root@127.0.0.1:3306/icpdf -> 各段。"""
    u = urlsplit(dsn if "://" in dsn else "mysql://" + dsn)
    return {
        "host": u.hostname or "127.0.0.1",
        "port": u.port or 3306,
        "user": unquote(u.username or "root"),
        "password": unquote(u.password or ""),
        "database": (u.path or "/icpdf").lstrip("/") or "icpdf",
    }


class Db:
    """薄封装：屏蔽 sqlite / pymysql 的占位符与 DDL 差异。"""

    def __init__(self, dsn: str):
        self.dsn = dsn
        self.is_mysql = dsn.startswith("mysql")
        if self.is_mysql:
            import pymysql
            p = dsn_parts(dsn)
            self.con = pymysql.connect(host=p["host"], port=p["port"], user=p["user"],
                                       password=p["password"], database=p["database"],
                                       charset="utf8mb4", autocommit=False)
            self.ph = "%s"
        else:
            path = SQLITE_PATH if dsn in ("sqlite", "", "sqlite:") else Path(dsn.split("sqlite:///")[-1])
            self.con = sqlite3.connect(str(path))
            self.con.execute("PRAGMA journal_mode=WAL")
            self.con.execute("PRAGMA synchronous=NORMAL")
            self.ph = "?"
        self.cur = self.con.cursor()

    def ex(self, sql: str, args=()):
        self.cur.execute(sql, args)
        return self.cur

    def many(self, sql: str, rows: list):
        if rows:
            self.cur.executemany(sql, rows)

    def commit(self):
        self.con.commit()

    def close(self):
        self.con.close()

    def table_exists(self, name: str) -> bool:
        if self.is_mysql:
            self.ex("SELECT COUNT(*) FROM information_schema.tables "
                    "WHERE table_schema=DATABASE() AND table_name=%s", (name,))
        else:
            self.ex("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (name,))
        return self.cur.fetchone()[0] > 0


# ------------------------------------------------------------------ DDL
# 索引一律单独建：SQLite 不支持建表语句里的内联 KEY。
MYSQL_DDL = [
    """CREATE TABLE IF NOT EXISTS doc (
        id             BIGINT       NOT NULL AUTO_INCREMENT,
        requested_mpn  VARCHAR(128) NOT NULL DEFAULT ''  COMMENT '请求料号（manifest 来的，页面主键）',
        mpn            VARCHAR(128) NOT NULL             COMMENT '解析出的型号，可能被模型改写',
        brand          VARCHAR(128) NOT NULL DEFAULT '',
        category       VARCHAR(128) NOT NULL DEFAULT '',
        subcategory    VARCHAR(128) NOT NULL DEFAULT '',
        description    TEXT         NULL,
        datasheet_url  VARCHAR(1024) NOT NULL DEFAULT '',
        pkg_type       VARCHAR(128) NOT NULL DEFAULT '',
        pkg_pins       INT          NOT NULL DEFAULT 0,
        pkg_dimensions VARCHAR(128) NOT NULL DEFAULT '',
        temp_operating VARCHAR(64)  NOT NULL DEFAULT '',
        temp_storage   VARCHAR(64)  NOT NULL DEFAULT '',
        pdf_sha256     CHAR(64)     NOT NULL DEFAULT '',
        pdf_path       VARCHAR(512) NOT NULL DEFAULT '',
        json_path      VARCHAR(512) NOT NULL DEFAULT '',
        model_version  VARCHAR(64)  NOT NULL DEFAULT '',
        confidence     DECIMAL(4,3) NOT NULL DEFAULT 0    COMMENT '模型自评置信度 0~1',
        parsed_at      DATETIME     NULL,
        revision       INT          NOT NULL DEFAULT 1    COMMENT '重修次数，改一次 +1',
        status         VARCHAR(16)  NOT NULL DEFAULT 'parsed'
                       COMMENT 'parsed/reviewed/verified/published/rejected',
        note           TEXT         NULL,
        raw_sha256     CHAR(64)     NOT NULL DEFAULT ''   COMMENT '原文指纹，判断是否变过',
        created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_mpn_pdf (mpn, pdf_sha256),
        KEY idx_requested (requested_mpn),
        KEY idx_brand (brand),
        KEY idx_status (status),
        KEY idx_conf (confidence),
        KEY idx_pkg (pkg_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='型号解析主表'""",

    """CREATE TABLE IF NOT EXISTS doc_raw (
        doc_id  BIGINT NOT NULL,
        json    LONGTEXT NOT NULL COMMENT '模型原始输出，重修可回放',
        PRIMARY KEY (doc_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='原文留底'""",

    """CREATE TABLE IF NOT EXISTS doc_spec (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        section VARCHAR(32) NOT NULL COMMENT 'electrical/absolute_max/...',
        seq     SMALLINT NOT NULL DEFAULT 0,
        name    VARCHAR(255) NOT NULL,
        value   TEXT NULL,
        unit    VARCHAR(64) NOT NULL DEFAULT '',
        cond    VARCHAR(255) NULL COMMENT '测试条件；NULL=原文无此键，空串=原文有但为空。cond 避开保留字 condition',
        PRIMARY KEY (id),
        KEY idx_doc (doc_id, section),
        KEY idx_name (name(64)),
        KEY idx_sec_name (section, name(64))
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='规格明细（长表，字段名不固定）'""",

    """CREATE TABLE IF NOT EXISTS doc_pin (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        seq     SMALLINT NOT NULL DEFAULT 0 COMMENT '原始数组下标；pin_no 会重复（板卡连接器 J1-1/J2-1），不能拿它排序',
        pin_no  INT NOT NULL,
        name    VARCHAR(255) NOT NULL DEFAULT '',
        description TEXT NULL,
        PRIMARY KEY (id),
        KEY idx_doc (doc_id, seq)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='引脚定义'""",

    """CREATE TABLE IF NOT EXISTS doc_ordering (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        seq     SMALLINT NOT NULL DEFAULT 0,
        mpn     VARCHAR(128) NOT NULL DEFAULT '',
        package VARCHAR(128) NOT NULL DEFAULT '',
        packaging VARCHAR(64) NOT NULL DEFAULT '',
        moq     INT NOT NULL DEFAULT 0,
        marking VARCHAR(128) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY idx_doc (doc_id),
        KEY idx_mpn (mpn)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='订购信息'""",

    """CREATE TABLE IF NOT EXISTS doc_alt (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        seq     SMALLINT NOT NULL DEFAULT 0,
        mpn     VARCHAR(128) NOT NULL DEFAULT '',
        manufacturer VARCHAR(128) NOT NULL DEFAULT '',
        reason  TEXT NULL,
        PRIMARY KEY (id),
        KEY idx_doc (doc_id),
        KEY idx_mpn (mpn)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='替代型号'""",

    """CREATE TABLE IF NOT EXISTS doc_list (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        kind    VARCHAR(24) NOT NULL COMMENT 'feature/application/seo_keyword',
        seq     SMALLINT NOT NULL DEFAULT 0,
        value   TEXT NOT NULL,
        PRIMARY KEY (id),
        KEY idx_doc (doc_id, kind)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='列表类段落'""",

    """CREATE TABLE IF NOT EXISTS doc_i18n (
        doc_id  BIGINT NOT NULL,
        lang    CHAR(5) NOT NULL,
        title   VARCHAR(512) NOT NULL DEFAULT '',
        description TEXT NULL,
        meta    VARCHAR(1024) NOT NULL DEFAULT '',
        PRIMARY KEY (doc_id, lang)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='多语言文案'""",

    """CREATE TABLE IF NOT EXISTS doc_change (
        id      BIGINT NOT NULL AUTO_INCREMENT,
        doc_id  BIGINT NOT NULL,
        rev     INT NOT NULL,
        field   VARCHAR(255) NOT NULL COMMENT '扁平路径，如 specs.electrical[3].value',
        old_value TEXT NULL,
        new_value TEXT NULL,
        actor   VARCHAR(64) NOT NULL DEFAULT '',
        reason  VARCHAR(255) NOT NULL DEFAULT '',
        changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_doc (doc_id, rev)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
      COMMENT='修订审计'""",
]

SQLITE_DDL = [
    """CREATE TABLE IF NOT EXISTS doc (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        requested_mpn  TEXT NOT NULL DEFAULT '',
        mpn            TEXT NOT NULL,
        brand          TEXT NOT NULL DEFAULT '',
        category       TEXT NOT NULL DEFAULT '',
        subcategory    TEXT NOT NULL DEFAULT '',
        description    TEXT,
        datasheet_url  TEXT NOT NULL DEFAULT '',
        pkg_type       TEXT NOT NULL DEFAULT '',
        pkg_pins       INTEGER NOT NULL DEFAULT 0,
        pkg_dimensions TEXT NOT NULL DEFAULT '',
        temp_operating TEXT NOT NULL DEFAULT '',
        temp_storage   TEXT NOT NULL DEFAULT '',
        pdf_sha256     TEXT NOT NULL DEFAULT '',
        pdf_path       TEXT NOT NULL DEFAULT '',
        json_path      TEXT NOT NULL DEFAULT '',
        model_version  TEXT NOT NULL DEFAULT '',
        confidence     REAL NOT NULL DEFAULT 0,
        parsed_at      TEXT,
        revision       INTEGER NOT NULL DEFAULT 1,
        status         TEXT NOT NULL DEFAULT 'parsed',
        note           TEXT,
        raw_sha256     TEXT NOT NULL DEFAULT '',
        created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        UNIQUE (mpn, pdf_sha256)
    )""",
    "CREATE TABLE IF NOT EXISTS doc_raw (doc_id INTEGER PRIMARY KEY, json TEXT NOT NULL)",
    """CREATE TABLE IF NOT EXISTS doc_spec (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        section TEXT NOT NULL, seq INTEGER NOT NULL DEFAULT 0,
        name TEXT NOT NULL, value TEXT, unit TEXT NOT NULL DEFAULT '',
        cond TEXT)""",
    """CREATE TABLE IF NOT EXISTS doc_pin (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        seq INTEGER NOT NULL DEFAULT 0,
        pin_no INTEGER NOT NULL, name TEXT NOT NULL DEFAULT '', description TEXT)""",
    """CREATE TABLE IF NOT EXISTS doc_ordering (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        seq INTEGER NOT NULL DEFAULT 0, mpn TEXT NOT NULL DEFAULT '',
        package TEXT NOT NULL DEFAULT '', packaging TEXT NOT NULL DEFAULT '',
        moq INTEGER NOT NULL DEFAULT 0, marking TEXT NOT NULL DEFAULT '')""",
    """CREATE TABLE IF NOT EXISTS doc_alt (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        seq INTEGER NOT NULL DEFAULT 0, mpn TEXT NOT NULL DEFAULT '',
        manufacturer TEXT NOT NULL DEFAULT '', reason TEXT)""",
    """CREATE TABLE IF NOT EXISTS doc_list (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        kind TEXT NOT NULL, seq INTEGER NOT NULL DEFAULT 0, value TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS doc_i18n (
        doc_id INTEGER NOT NULL, lang TEXT NOT NULL,
        title TEXT NOT NULL DEFAULT '', description TEXT,
        meta TEXT NOT NULL DEFAULT '', PRIMARY KEY (doc_id, lang))""",
    """CREATE TABLE IF NOT EXISTS doc_change (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER NOT NULL,
        rev INTEGER NOT NULL, field TEXT NOT NULL, old_value TEXT, new_value TEXT,
        actor TEXT NOT NULL DEFAULT '', reason TEXT NOT NULL DEFAULT '',
        changed_at TEXT NOT NULL DEFAULT (datetime('now','localtime')))""",
]

SQLITE_IDX = [
    "CREATE INDEX IF NOT EXISTS idx_doc_req ON doc(requested_mpn)",
    "CREATE INDEX IF NOT EXISTS idx_doc_brand ON doc(brand)",
    "CREATE INDEX IF NOT EXISTS idx_doc_status ON doc(status)",
    "CREATE INDEX IF NOT EXISTS idx_doc_conf ON doc(confidence)",
    "CREATE INDEX IF NOT EXISTS idx_doc_pkg ON doc(pkg_type)",
    "CREATE INDEX IF NOT EXISTS idx_spec_doc ON doc_spec(doc_id, section)",
    "CREATE INDEX IF NOT EXISTS idx_spec_name ON doc_spec(name)",
    "CREATE INDEX IF NOT EXISTS idx_spec_sec_name ON doc_spec(section, name)",
    "CREATE INDEX IF NOT EXISTS idx_pin_doc ON doc_pin(doc_id, seq)",
    "CREATE INDEX IF NOT EXISTS idx_ord_doc ON doc_ordering(doc_id)",
    "CREATE INDEX IF NOT EXISTS idx_ord_mpn ON doc_ordering(mpn)",
    "CREATE INDEX IF NOT EXISTS idx_alt_doc ON doc_alt(doc_id)",
    "CREATE INDEX IF NOT EXISTS idx_alt_mpn ON doc_alt(mpn)",
    "CREATE INDEX IF NOT EXISTS idx_list_doc ON doc_list(doc_id, kind)",
    "CREATE INDEX IF NOT EXISTS idx_chg_doc ON doc_change(doc_id, rev)",
]


TABLES = ("doc_change", "doc_i18n", "doc_list", "doc_alt", "doc_ordering",
          "doc_pin", "doc_spec", "doc_raw", "doc")


def drop_db(db: Db) -> None:
    """删表重建用。数据都能从 data/parsed/*.json 重灌，所以开发期可以随时重来。"""
    for t in TABLES:
        db.ex(f"DROP TABLE IF EXISTS {t}")
    db.commit()
    print(f"已删除 {len(TABLES)} 张表")


VIEWS = [
    # 每型号各段条数：一眼看出谁缺段。用派生表 LEFT JOIN 而不是相关子查询，
    # 否则百万行时每个型号要跑 7 次子查询。
    """CREATE VIEW v_doc_gap AS
       SELECT d.id, d.requested_mpn, d.mpn, d.pkg_type, d.pkg_pins,
              d.confidence, d.status, d.revision,
              COALESCE(s.n, 0)  AS n_spec,
              COALESCE(p.n, 0)  AS n_pin,
              COALESCE(o.n, 0)  AS n_order,
              COALESCE(a.n, 0)  AS n_alt,
              COALESCE(f.n, 0)  AS n_feature,
              COALESCE(ap.n, 0) AS n_app,
              COALESCE(i.n, 0)  AS n_lang
       FROM doc d
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_spec     GROUP BY doc_id) s  ON s.doc_id  = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_pin      GROUP BY doc_id) p  ON p.doc_id  = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_ordering GROUP BY doc_id) o  ON o.doc_id  = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_alt      GROUP BY doc_id) a  ON a.doc_id  = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_list WHERE kind='feature'     GROUP BY doc_id) f  ON f.doc_id  = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_list WHERE kind='application' GROUP BY doc_id) ap ON ap.doc_id = d.id
       LEFT JOIN (SELECT doc_id, COUNT(*) n FROM doc_i18n     GROUP BY doc_id) i  ON i.doc_id  = d.id""",

    # 规格项命名清单：为「同义词归一」做准备。electrical 有 122 种写法，
    # 不归一就没法做跨型号的「工作电压对比」。
    """CREATE VIEW v_spec_name AS
       SELECT section, name, COUNT(*) AS n, COUNT(DISTINCT doc_id) AS docs
       FROM doc_spec GROUP BY section, name""",
]


def init_db(db: Db) -> None:
    for stmt in (MYSQL_DDL if db.is_mysql else SQLITE_DDL):
        db.ex(stmt)
    if not db.is_mysql:
        for stmt in SQLITE_IDX:
            db.ex(stmt)
    for stmt in VIEWS:
        # SQLite 没有 CREATE OR REPLACE VIEW，统一先删后建
        name = re.search(r"VIEW\s+(\w+)", stmt).group(1)
        db.ex(f"DROP VIEW IF EXISTS {name}")
        db.ex(stmt)
    db.commit()
    n = sum(1 for t in TABLES if db.table_exists(t))
    print(f"建表完成：{n}/{len(TABLES)} 张表 + {len(VIEWS)} 个视图（{db.dsn}）")


# ------------------------------------------------------------------ 扁平化 / diff
def flat(obj, pre: str = "", out: dict | None = None) -> dict:
    """把 JSON 拍平成 {路径: 标量}，用于字段级 diff。"""
    if out is None:
        out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            flat(v, f"{pre}.{k}" if pre else k, out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            flat(v, f"{pre}[{i}]", out)
    else:
        out[pre] = "" if obj is None else str(obj)
    return out


_MISS = object()          # 哨兵：区分「键不存在」和「值为空」


def diff_flat(old: dict, new: dict) -> list[tuple[str, str | None, str | None]]:
    """返回 [(字段路径, 旧值, 新值)]。

    新增的键 old_value=None，删掉的键 new_value=None，这样审计里一眼能看出是加是删。
    """
    rows = []
    for k in sorted(set(old) | set(new)):
        a, b = old.get(k, _MISS), new.get(k, _MISS)
        if a != b:
            rows.append((k, None if a is _MISS else a, None if b is _MISS else b))
    return rows


# ------------------------------------------------------------------ 型号来源
def load_manifest() -> dict[str, str]:
    """sha256 -> 请求料号。JSON 里的 mpn 可能被模型改写，靠这个找回原请求型号。"""
    if not MANIFEST.exists():
        return {}
    out = {}
    with MANIFEST.open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            sha = (r.get("sha256") or "").strip()
            if sha:
                out[sha] = (r.get("mpn") or "").strip()
    return out


def stem_mpn(path: Path) -> str:
    """`ADS1201U-1_1K_0805d187.json` -> `ADS1201U-1_1K`（去掉尾部 8 位 hash）。"""
    return re.sub(r"_[0-9a-f]{8}$", "", path.stem)


def parse_ts(s: str) -> str | None:
    """ISO8601 -> 'YYYY-MM-DD HH:MM:SS'。

    MySQL 的 DATETIME 不收带时区的 '2026-10-22T14:06:55+08:00'（报 1292），
    所以先归到本地时区再去掉 tzinfo。SQLite 存文本，同一个格式也能直接用。
    """
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


# ------------------------------------------------------------------ 入库
def _rel(p: Path) -> str:
    """尽量存项目内相对路径（换机器也好认），不在项目内就存绝对路径。"""
    try:
        return str(Path(p).resolve().relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(Path(p).resolve()).replace("\\", "/")


def doc_row(doc: dict, req_mpn: str, json_path: Path, raw: str) -> dict:
    bi = doc.get("basic_info") or {}
    sp = doc.get("specs") or {}
    pk = sp.get("package") or {}
    tp = sp.get("temperature") or {}
    md = doc.get("metadata") or {}
    conf = md.get("confidence")
    try:
        conf = round(float(conf), 3)
    except (TypeError, ValueError):
        conf = 0.0
    try:
        pins = int(pk.get("pins") or 0)
    except (TypeError, ValueError):
        pins = 0
    return {
        "requested_mpn": req_mpn,
        "mpn": (bi.get("mpn") or "").strip() or stem_mpn(json_path),
        "brand": (bi.get("manufacturer") or "").strip(),
        "category": (bi.get("category") or "").strip(),
        "subcategory": (bi.get("subcategory") or "").strip(),
        "description": bi.get("description") or "",
        "datasheet_url": (bi.get("datasheet_url") or "").strip(),
        "pkg_type": (pk.get("type") or "").strip(),
        "pkg_pins": pins,
        "pkg_dimensions": (pk.get("dimensions") or "").strip(),
        "temp_operating": (tp.get("operating") or "").strip(),
        "temp_storage": (tp.get("storage") or "").strip(),
        "pdf_sha256": (md.get("pdf_hash") or "").strip(),
        "json_path": _rel(json_path),
        "model_version": (md.get("model_version") or "").strip(),
        "confidence": conf,
        "parsed_at": parse_ts((md.get("parse_timestamp") or "").strip()),
        "raw_sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
    }


#: 治理层隔离区，不是可展示的规格表。`detail_rows()` 按 `specs` 下所有 list
#: 泛化取行，必须显式跳过 —— 否则隔离行会从 API 的 `spec` 明细重新流出去。
_QUARANTINE_SECTIONS = frozenset({"unresolved_ac_rows"})


def detail_rows(doc: dict) -> dict[str, list]:
    """把一份 JSON 拆成各明细表的行（不含 doc_id，插入时补）。"""
    sp = doc.get("specs") or {}
    specs = []
    # 规格项散落在 specs.<section>[] 里，section 名不固定（electrical / absolute_max / 未来还会有别的）
    for section, items in sp.items():
        if section in _QUARANTINE_SECTIONS:
            continue
        if not isinstance(items, list):
            continue
        if section == ac_quarantine.AC:
            # 旧 JSON 可能还没跑隔离；API 出口也不能把 `max="dB"` 这类行
            # 当正式规格写进 `doc_spec`。
            items = ac_quarantine.filter_rows(items)
        for i, it in enumerate(items):
            if not isinstance(it, dict):
                continue
            # cond 用 None 表示「原文压根没有 condition 键」，空串表示「有键但值为空」。
            # 这个区别必须留住，否则回写 JSON 时会把缺失的键补成空串，round-trip 就不干净了。
            cond = str(it["condition"])[:255] if "condition" in it else None
            specs.append((section, i, str(it.get("name") or "")[:255],
                          None if it.get("value") is None else str(it.get("value")),
                          str(it.get("unit") or "")[:64], cond))

    pins = []
    for i, p in enumerate(doc.get("pin_configuration") or []):
        if not isinstance(p, dict):
            continue
        try:
            no = int(str(p.get("pin")).strip())
        except (TypeError, ValueError):
            continue
        pins.append((i, no, str(p.get("name") or "")[:255], p.get("description") or ""))

    orders = []
    for i, o in enumerate(doc.get("ordering_info") or []):
        if not isinstance(o, dict):
            continue
        try:
            moq = int(o.get("moq") or 0)
        except (TypeError, ValueError):
            moq = 0
        orders.append((i, str(o.get("mpn") or "")[:128], str(o.get("package") or "")[:128],
                       str(o.get("packaging") or "")[:64], moq, str(o.get("marking") or "")[:128]))

    alts = []
    for i, a in enumerate(doc.get("alternatives") or []):
        if not isinstance(a, dict):
            continue
        alts.append((i, str(a.get("mpn") or "")[:128],
                     str(a.get("manufacturer") or "")[:128], a.get("reason") or ""))

    lists = []
    for i, v in enumerate(doc.get("features") or []):
        if str(v).strip():
            lists.append(("feature", i, str(v)))
    for i, v in enumerate(doc.get("applications") or []):
        if str(v).strip():
            lists.append(("application", i, str(v)))
    for i, v in enumerate((doc.get("seo") or {}).get("keywords") or []):
        if str(v).strip():
            lists.append(("seo_keyword", i, str(v)))

    i18n = []
    for lang, blk in (doc.get("multi_language") or {}).items():
        if not isinstance(blk, dict):
            continue
        i18n.append((str(lang)[:5], str(blk.get("title") or "")[:512],
                     blk.get("description") or "", str(blk.get("meta") or "")[:1024]))

    return {"spec": specs, "pin": pins, "order": orders,
            "alt": alts, "list": lists, "i18n": i18n}


DOC_COLS = ["requested_mpn", "mpn", "brand", "category", "subcategory", "description",
            "datasheet_url", "pkg_type", "pkg_pins", "pkg_dimensions", "temp_operating",
            "temp_storage", "pdf_sha256", "json_path", "model_version", "confidence",
            "parsed_at", "raw_sha256"]


def find_doc(db: Db, mpn: str, sha: str) -> tuple[int, int, str] | None:
    db.ex(f"SELECT id, revision, raw_sha256 FROM doc WHERE mpn={db.ph} AND pdf_sha256={db.ph}",
          (mpn, sha))
    r = db.cur.fetchone()
    return (int(r[0]), int(r[1]), r[2] or "") if r else None


def insert_detail(db: Db, doc_id: int, d: dict) -> None:
    """明细整体替换：先删后插。比逐行 diff 简单可靠，量级也不大（每型号几十行）。"""
    for t in ("doc_spec", "doc_pin", "doc_ordering", "doc_alt", "doc_list", "doc_i18n"):
        db.ex(f"DELETE FROM {t} WHERE doc_id={db.ph}", (doc_id,))
    if d["spec"]:
        db.many(f"INSERT INTO doc_spec (doc_id,section,seq,name,value,unit,cond) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id,) + r for r in d["spec"]])
    if d["pin"]:
        db.many(f"INSERT INTO doc_pin (doc_id,seq,pin_no,name,description) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph})", [(doc_id,) + r for r in d["pin"]])
    if d["order"]:
        db.many(f"INSERT INTO doc_ordering (doc_id,seq,mpn,package,packaging,moq,marking) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id,) + r for r in d["order"]])
    if d["alt"]:
        db.many(f"INSERT INTO doc_alt (doc_id,seq,mpn,manufacturer,reason) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id,) + r for r in d["alt"]])
    if d["list"]:
        db.many(f"INSERT INTO doc_list (doc_id,kind,seq,value) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id, k, i, v) for k, i, v in d["list"]])
    if d["i18n"]:
        db.many(f"INSERT INTO doc_i18n (doc_id,lang,title,description,meta) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id,) + r for r in d["i18n"]])


def load_one(db: Db, path: Path, manifest: dict[str, str], actor: str = "load") -> tuple[str, int]:
    """入库一份 JSON。返回 (动作, doc_id)。动作：new / same / rev。"""
    raw = path.read_text(encoding="utf-8")
    try:
        doc = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"  ✗ {path.name} JSON 坏了：{e}")
        return "bad", 0

    sha = ((doc.get("metadata") or {}).get("pdf_hash") or "").strip()
    req = manifest.get(sha) or stem_mpn(path)
    row = doc_row(doc, req, path, raw)
    hit = find_doc(db, row["mpn"], row["pdf_sha256"])

    if hit is None:
        cols = ",".join(DOC_COLS)
        ph = ",".join([db.ph] * len(DOC_COLS))
        db.ex(f"INSERT INTO doc ({cols}) VALUES ({ph})", tuple(row[c] for c in DOC_COLS))
        doc_id = int(db.cur.lastrowid)
        db.ex(f"INSERT INTO doc_raw (doc_id,json) VALUES ({db.ph},{db.ph})", (doc_id, raw))
        insert_detail(db, doc_id, detail_rows(doc))
        return "new", doc_id

    doc_id, rev, old_sha = hit
    if old_sha == row["raw_sha256"]:
        return "same", doc_id                      # 内容没变，什么都不做

    # 内容变了：升版 + 字段级审计
    db.ex(f"SELECT json FROM doc_raw WHERE doc_id={db.ph}", (doc_id,))
    r = db.cur.fetchone()
    old_doc = json.loads(r[0]) if r else {}
    changes = diff_flat(flat(old_doc), flat(doc))
    new_rev = rev + 1
    sets = ",".join(f"{c}={db.ph}" for c in DOC_COLS)
    db.ex(f"UPDATE doc SET {sets}, revision={db.ph} WHERE id={db.ph}",
          tuple(row[c] for c in DOC_COLS) + (new_rev, doc_id))
    db.ex(f"UPDATE doc_raw SET json={db.ph} WHERE doc_id={db.ph}", (raw, doc_id))
    if changes:
        db.many(f"INSERT INTO doc_change (doc_id,rev,field,old_value,new_value,actor,reason) "
                f"VALUES ({db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph},{db.ph})",
                [(doc_id, new_rev, f,
                  None if a is None else str(a)[:65535],
                  None if b is None else str(b)[:65535],
                  actor, "JSON 重新解析")
                 for f, a, b in changes])
    insert_detail(db, doc_id, detail_rows(doc))
    return "rev", doc_id


def cmd_load(db: Db, only: str, actor: str = "load", batch: int = 500,
             src: str = "") -> None:
    manifest = load_manifest()
    src_dir = Path(src) if src else PARSED
    files = sorted(src_dir.glob("*.json"))
    if only:
        files = [f for f in files if only.lower() in f.name.lower()]
    stat = {"new": 0, "same": 0, "rev": 0, "bad": 0}
    for i, f in enumerate(files, 1):
        act, did = load_one(db, f, manifest, actor)
        stat[act] += 1
        flag = {"new": "新增", "same": "未变", "rev": "升版", "bad": "失败"}[act]
        if len(files) <= 30 or act != "same":        # 量大时别把「未变」刷满屏
            print(f"  {flag}  {f.name:<42} doc_id={did}")
        # 分批提交：几十万份一次性事务会把 undo log 撑爆、回滚也慢
        if i % batch == 0:
            db.commit()
            print(f"  … 已处理 {i}/{len(files)}")
    db.commit()
    print(f"\n入库完成：新增 {stat['new']} / 升版 {stat['rev']} / "
          f"未变 {stat['same']} / 失败 {stat['bad']}（manifest 命中 {len(manifest)} 条）")


# ------------------------------------------------------------------ 导出（重修回写）
def cmd_export(db: Db, mpn: str) -> None:
    """从表重建 JSON。重修后跑这个，再重跑 json_to_txt / symbol_svg 出页面。"""
    REBUILT.mkdir(parents=True, exist_ok=True)
    where, args = "", ()
    if mpn:
        where = f"WHERE d.mpn={db.ph} OR d.requested_mpn={db.ph}"
        args = (mpn, mpn)
    db.ex(f"SELECT d.id, d.mpn FROM doc d {where} ORDER BY d.id", args)
    targets = db.cur.fetchall()
    if not targets:
        print("没有匹配的型号")
        return

    for doc_id, name in targets:
        db.ex(f"SELECT json FROM doc_raw WHERE doc_id={db.ph}", (doc_id,))
        r = db.cur.fetchone()
        if not r:
            print(f"  ✗ {name} 缺原文，跳过")
            continue
        doc = json.loads(r[0])                      # 以原文为骨架，保住未落表的字段

        # 用表里的值覆盖——表是重修后的真相
        db.ex(f"SELECT section,name,value,unit,cond FROM doc_spec WHERE doc_id={db.ph} "
              f"ORDER BY section,seq", (doc_id,))
        secs: dict[str, list] = {}
        for section, nm, val, unit, cond in db.cur.fetchall():
            item = {"name": nm, "value": val, "unit": unit}
            if cond is not None:                    # None=原文没这个键，才省略；空串要原样写回
                item["condition"] = cond
            secs.setdefault(section, []).append(item)
        for section in (doc.get("specs") or {}):
            if isinstance(doc["specs"][section], list) and section in secs:
                doc["specs"][section] = secs.pop(section)
        doc.setdefault("specs", {}).update(secs)

        db.ex(f"SELECT pin_no,name,description FROM doc_pin WHERE doc_id={db.ph} "
              f"ORDER BY seq", (doc_id,))
        doc["pin_configuration"] = [{"pin": n, "name": nm, "description": de}
                                    for n, nm, de in db.cur.fetchall()]

        db.ex(f"SELECT mpn,package,packaging,moq,marking FROM doc_ordering "
              f"WHERE doc_id={db.ph} ORDER BY seq", (doc_id,))
        doc["ordering_info"] = [{"mpn": m, "package": p, "packaging": pk,
                                 "moq": q, "marking": mk}
                                for m, p, pk, q, mk in db.cur.fetchall()]

        db.ex(f"SELECT mpn,manufacturer,reason FROM doc_alt WHERE doc_id={db.ph} "
              f"ORDER BY seq", (doc_id,))
        doc["alternatives"] = [{"mpn": m, "manufacturer": f, "reason": rz}
                               for m, f, rz in db.cur.fetchall()]

        db.ex(f"SELECT kind,value FROM doc_list WHERE doc_id={db.ph} ORDER BY kind,seq",
              (doc_id,))
        buckets: dict[str, list] = {"feature": [], "application": [], "seo_keyword": []}
        for k, v in db.cur.fetchall():
            buckets.setdefault(k, []).append(v)
        doc["features"] = buckets["feature"]
        doc["applications"] = buckets["application"]
        doc.setdefault("seo", {})["keywords"] = buckets["seo_keyword"]

        db.ex(f"SELECT lang,title,description,meta FROM doc_i18n WHERE doc_id={db.ph}",
              (doc_id,))
        doc["multi_language"] = {lg: {"title": t, "description": de, "meta": m}
                                 for lg, t, de, m in db.cur.fetchall()}

        stem = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
        out = REBUILT / f"{stem}.json"
        out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  ✓ {name} -> {out.relative_to(ROOT)}")
    print(f"\n导出 {len(targets)} 份 -> {REBUILT.relative_to(ROOT)}/")


# ------------------------------------------------------------------ 报表
def cmd_report(db: Db) -> None:
    """复查用的几张表：总量、缺口、型号改写、规格命名混乱、低置信度。"""
    def q(sql, args=()):
        db.ex(sql, args)
        return db.cur.fetchall()

    total, = q("SELECT COUNT(*) FROM doc")[0]
    if not total:
        print("库里还没有数据，先 --load")
        return
    print(f"\n{'=' * 78}\n解析结果库概览　共 {total} 个型号\n{'=' * 78}")

    print("\n【1】按状态")
    for st, n in q("SELECT status, COUNT(*) FROM doc GROUP BY status ORDER BY 2 DESC"):
        print(f"  {st:<12} {n:>6}")

    print("\n【2】各段完整度（有内容的型号数 / 总数）")
    for label, sql in [
        ("规格 electrical", "SELECT COUNT(DISTINCT doc_id) FROM doc_spec WHERE section='electrical'"),
        ("规格 absolute_max", "SELECT COUNT(DISTINCT doc_id) FROM doc_spec WHERE section='absolute_max'"),
        ("引脚定义", "SELECT COUNT(DISTINCT doc_id) FROM doc_pin"),
        ("订购信息", "SELECT COUNT(DISTINCT doc_id) FROM doc_ordering"),
        ("替代型号", "SELECT COUNT(DISTINCT doc_id) FROM doc_alt"),
        ("核心特性", "SELECT COUNT(DISTINCT doc_id) FROM doc_list WHERE kind='feature'"),
        ("应用领域", "SELECT COUNT(DISTINCT doc_id) FROM doc_list WHERE kind='application'"),
        ("多语言", "SELECT COUNT(DISTINCT doc_id) FROM doc_i18n"),
    ]:
        n, = q(sql)[0]
        bar = "█" * round(n / total * 20)
        print(f"  {label:<18} {n:>3}/{total:<3} {bar}")

    print("\n【3】型号被模型改写（请求料号 ≠ 解析型号）")
    rows = q("SELECT requested_mpn, mpn, confidence FROM doc "
             "WHERE requested_mpn<>'' AND requested_mpn<>mpn ORDER BY requested_mpn")
    if rows:
        for a, b, c in rows:
            print(f"  {a:<26} -> {b:<26} conf={c}")
    else:
        print("  无")

    print("\n【4】封装声明脚数 vs 实际解析脚数")
    rows = q("SELECT d.mpn, d.pkg_type, d.pkg_pins, COUNT(p.id) AS n FROM doc d "
             "LEFT JOIN doc_pin p ON p.doc_id=d.id "
             "GROUP BY d.id, d.mpn, d.pkg_type, d.pkg_pins "
             "HAVING d.pkg_pins>0 ORDER BY d.pkg_pins DESC")
    for m, t, decl, n in rows:
        if n == 0:
            mark = "　← 无引脚数据（解析漏了）"
        elif n < decl:
            mark = "　← 仅解析出关键脚"
        elif n > decl:
            mark = "　← 解析数超声明（疑似串页）"
        else:
            mark = ""
        print(f"  {m:<26} {str(t):<22} 声明 {decl:>3} / 解析 {n:>3}{mark}")

    print("\n【5】规格项命名（同一 section 下有多少种写法，越多越难做跨型号对比）")
    rows = q("SELECT section, COUNT(DISTINCT name) AS k, COUNT(*) AS n FROM doc_spec "
             "GROUP BY section ORDER BY k DESC")
    for sec, k, n in rows:
        print(f"  {sec:<16} {k:>3} 种命名 / {n:>4} 条记录")

    print("\n【6】低置信度（< 0.8，建议进人工队列）")
    rows = q(f"SELECT mpn, confidence, status FROM doc WHERE confidence<0.8 ORDER BY confidence")
    if rows:
        for m, c, st in rows:
            print(f"  {m:<26} conf={c:<6} {st}")
    else:
        print("  无")

    print("\n【7】修订历史")
    rows = q("SELECT id, mpn, revision FROM doc WHERE revision>1 ORDER BY revision DESC")
    if rows:
        for did, m, rev in rows:
            print(f"  doc_id={did:<5} {m:<26} 已重修 {rev - 1} 次")
        print("\n  明细（最近 10 条）：")
        rows = q("SELECT c.doc_id, c.rev, c.field, c.old_value, c.new_value "
                 "FROM doc_change c ORDER BY c.id DESC LIMIT 10")
        for did, rev, f, ov, nv in rows:
            ov = (ov or "")[:28]
            nv = (nv or "")[:28]
            print(f"    doc={did} r{rev} {f:<40} {ov!r} -> {nv!r}")
    else:
        print("  无（都是首次入库）")
    print()


# ------------------------------------------------------------------ 入口
def resolve_dsn(a: argparse.Namespace) -> str:
    """默认走本地 MySQL（项目约定）；--db sqlite 可退回单文件库。"""
    d = (a.db or os.environ.get("ICPDF_DB") or "mysql").strip()
    if d == "mysql":
        return LOCAL_MYSQL
    return d


def main() -> None:
    ap = argparse.ArgumentParser(description="解析结果落表（MySQL 8 / SQLite）")
    ap.add_argument("--db", default="", help="mysql | sqlite | 完整 DSN；默认 mysql，也可用 ICPDF_DB")
    ap.add_argument("--batch", type=int, default=500, help="--load 每多少份提交一次")
    ap.add_argument("--init", action="store_true", help="建库建表")
    ap.add_argument("--reset", action="store_true", help="先删表再建（数据可从 JSON 重灌）")
    ap.add_argument("--load", action="store_true", help="JSON -> 库（幂等）")
    ap.add_argument("--export", action="store_true", help="库 -> JSON（重修回写）")
    ap.add_argument("--report", action="store_true", help="质量/缺口报表")
    ap.add_argument("--sql", default="", help="执行一条查询并打印结果")
    ap.add_argument("--only", default="", help="--load 时只处理文件名匹配的")
    ap.add_argument("--mpn", default="", help="--export 时指定型号")
    ap.add_argument("--actor", default="load", help="--load 写审计时的操作人")
    ap.add_argument("--src", default="", help="--load 的源目录，默认 data/parsed；改完 data/rebuilt 用这个灌回")
    a = ap.parse_args()

    if not any([a.init, a.load, a.export, a.report, a.sql, a.reset]):
        ap.print_help()
        return

    dsn = resolve_dsn(a)
    try:
        db = Db(dsn)
    except Exception as e:                          # 连不上时别甩一屏栈，直接给可执行的下一步
        print(f"连不上 {dsn}：{e}")
        print("　MySQL 没起？换文件库跑：--db sqlite")
        return 1
    try:
        if a.reset:
            drop_db(db)
            init_db(db)
        if a.init:
            init_db(db)
        if a.load:
            if not db.table_exists("doc"):
                init_db(db)
            cmd_load(db, a.only, a.actor, a.batch, a.src)
        if a.export:
            cmd_export(db, a.mpn)
        if a.report:
            cmd_report(db)
        if a.sql:
            db.ex(a.sql)
            rows = db.cur.fetchall()
            cols = [c[0] for c in db.cur.description] if db.cur.description else []
            if cols:
                print("\t".join(cols))
                for r in rows:
                    print("\t".join("" if v is None else str(v) for v in r))
            print(f"-- {len(rows)} 行")
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
