#!/usr/bin/env python
"""一键续跑：worker 停机 / 换机部署后，把所有非终态件按进度智能路由重投。

    python requeue_all.py --dry    # 只统计分布，不动库不投递
    python requeue_all.py          # 清空三条队列 -> 按路由重投

路由规则（不浪费已完成的阶段）：
    json_path 文件在 -> render_item   （解析已完成，只差渲染）
    pdf_path  文件在 -> llm_item      （PDF 已下载，只差解析）
    其余              -> fetch_item   （从头跑）

注意事项：
  * 只在 worker 全部停止后执行，否则会把在跑任务重复投递；
  * 先清空 icpdf_fetch / icpdf / icpdf_render 三条队列，防止残留消息与新投重复；
  * failed / nodata 不在此列（属终态），重跑走工作台「解析未完成」按钮。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config, db                                    # noqa: E402
from app.services import dispatch                              # noqa: E402

MID = ("pending", "queued", "resolving", "downloading", "parsing", "rendering")
QUEUES = (config.FETCH_QUEUE, config.CELERY_QUEUE, config.RENDER_QUEUE)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true", help="只统计，不投递")
    a = ap.parse_args()

    marks = ",".join("?" * len(MID))
    rows = db.q(f"SELECT id, mpn_key, status, pdf_path, json_path FROM item "
                f"WHERE status IN ({marks})", MID)
    print(f"非终态共 {len(rows)} 件")

    plan: list[tuple[str, str]] = []               # (mpn_key, kind)
    stat = {"render_item": 0, "llm_item": 0, "fetch_item": 0}
    for r in rows:
        jp = config.resolve_artifact(r["json_path"] or "", config.PARSED)
        pp = config.resolve_artifact(r["pdf_path"] or "", config.PDFS)
        if r["json_path"] and jp.exists():
            kind = "render_item"
        elif r["pdf_path"] and pp.exists():
            kind = "llm_item"
        else:
            kind = "fetch_item"
        stat[kind] += 1
        plan.append((r["mpn_key"], kind))
    for k, n in stat.items():
        print(f"  -> {k:12s} {n}")

    if a.dry:
        print("dry 模式：未投递")
        return

    # 清残留队列，避免与新投重复
    try:
        import redis
        rd = redis.Redis.from_url(config.REDIS_URL)
        deleted = rd.delete(*QUEUES)
        print(f"已清空队列 {QUEUES}（deleted={deleted}）")
    except Exception as e:                                     # noqa: BLE001
        print(f"警告：清队列失败（{e}）——若 Redis 里有残留消息会重复执行，请先确认")

    for key, kind in plan:
        dispatch.submit(kind, key)
    print(f"已重投 {len(plan)} 件，worker 启动后即开始消费")


if __name__ == "__main__":
    main()
