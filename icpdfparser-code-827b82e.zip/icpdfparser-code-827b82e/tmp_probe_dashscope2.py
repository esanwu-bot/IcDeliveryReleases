#!/usr/bin/env python
"""实测百炼在「生产体量」下的并发上限与拐点（临时脚本）。

背景：tmp_probe_dashscope.py 用小载荷测出并发16零限流、RPM 81、延迟不涨。
但生产 prompt 是 11k tokens、输出 6k tokens，负载重得多，必须按真实体量复测，
否则会得出「并发可以无限加」的错误结论。

两轮：
  A) 生产体量（长 prompt + 要求长输出）阶梯并发 8/16/24/32
  B) 找到并发上限后，横扫 enable_thinking 开/关，量化思考 token 的占比
用法: python tmp_probe_dashscope2.py
"""
from __future__ import annotations

import os
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
for name in (".env.local", ".env"):
    p = ROOT / name
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"
KEY = os.getenv("DASHSCOPE_API_KEY", "")
MODEL = os.getenv("DASHSCOPE_MODEL", "qwen-flash")
TIMEOUT = 300

SYS = "You are a JSON emitter. Output ONLY valid JSON matching the schema."


def build_prompt(big: bool) -> str:
    """big=True 时逼近生产体量：长上下文 + 要求长输出。"""
    filler = ("Reference excerpt from a multi-page power-management datasheet: "
              "the device integrates a buck converter, an LDO, two comparators, "
              "a programmable switching frequency and a spread-spectrum option. "
              "Absolute maximum ratings are listed per supply rail with junction "
              "temperature limits, storage temperature range and ESD ratings. ") * (28 if big else 3)
    tail = ("Generate a technical datasheet fragment for a buck converter IC. "
            "Output JSON with keys: mpn(str), manufacturer(str), description(str), "
            "features(list of 6 str), electrical(dict of 8 key->num), "
            "package(str), pins(list of 20 obj {num:int,name:str,description:str}). "
            "Each pin description must be 20-35 words of realistic engineering prose. "
            "Each feature must be 15-25 words. The description must be 150-220 words. "
            "Electrical values must be realistic numbers with units.")
    return filler + tail


def one(_i: int, big: bool, thinking: bool) -> dict:
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYS},
                     {"role": "user", "content": build_prompt(big)}],
        "temperature": 0.1,
        "max_tokens": 8000,
        "response_format": {"type": "json_object"},
        "enable_thinking": thinking,
    }
    t0 = time.perf_counter()
    try:
        r = requests.post(f"{BASE}/chat/completions",
                          headers={"Authorization": f"Bearer {KEY}",
                                   "Content-Type": "application/json"},
                          json=payload, timeout=TIMEOUT)
        dt = time.perf_counter() - t0
        if r.status_code != 200:
            return {"ok": False, "code": r.status_code, "secs": dt,
                    "err": r.text[:220], "ct": 0, "pt": 0}
        u = r.json().get("usage", {})
        return {"ok": True, "code": 200, "secs": dt,
                "pt": u.get("prompt_tokens", 0), "ct": u.get("completion_tokens", 0),
                "err": ""}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "code": 0, "secs": time.perf_counter() - t0,
                "err": f"{type(e).__name__}: {e}"[:220], "ct": 0, "pt": 0}


def run(n: int, label: str, big: bool = True, thinking: bool = False) -> dict:
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=n) as pool:
        futs = [pool.submit(one, i, big, thinking) for i in range(n)]
        for f in as_completed(futs):
            res.append(f.result())
    wall = time.time() - t0
    ok = [x for x in res if x["ok"]]
    bad = [x for x in res if not x["ok"]]
    limited = [x for x in bad if x["code"] == 429 or "429" in x["err"]
               or "rate" in x["err"].lower() or "throttl" in x["err"].lower()]
    secs = sorted(x["secs"] for x in ok)
    p50 = statistics.median(secs) if secs else 0
    p90 = secs[int(len(secs) * 0.9) - 1] if len(secs) > 1 else (secs[0] if secs else 0)
    ct = sum(x.get("ct", 0) for x in ok)
    pt = sum(x.get("pt", 0) for x in ok)
    print(f"\n[{label}] 并发={n} 墙钟={wall:.1f}s")
    print(f"  成功 {len(ok)}/{n}  限流 {len(limited)}  其他失败 {len(bad)-len(limited)}")
    print(f"  延迟 p50={p50:.1f}s p90={p90:.1f}s max={max(secs) if secs else 0:.1f}s")
    print(f"  达成 RPM={len(ok)/wall*60:.1f}  prompt均值={pt//max(1,len(ok))} "
          f"输出均值={ct//max(1,len(ok))}")
    if limited:
        print(f"  429样本: {limited[0]['err'][:200]}")
    if bad and not limited:
        print(f"  失败样本: {bad[0]['err'][:200]}")
    return {"n": n, "ok": len(ok), "limited": len(limited), "p50": p50, "p90": p90,
            "wall": wall, "rpm": len(ok) / wall * 60,
            "ct_avg": ct // max(1, len(ok)), "pt_avg": pt // max(1, len(ok))}


if __name__ == "__main__":
    assert KEY, "DASHSCOPE_API_KEY 未配置"
    print(f"model={MODEL}  === A) 生产体量阶梯并发 ===")
    rows = []
    for n in (8, 16, 24, 32):
        rows.append(run(n, f"生产体量 并发{n}"))
        time.sleep(8)
    print("\n=== A 汇总 ===")
    for r in rows:
        print(f"  并发{r['n']:>3} 成功{r['ok']:>3} 限流{r['limited']:>3} "
              f"p50={r['p50']:>6.1f}s p90={r['p90']:>6.1f}s RPM={r['rpm']:>6.1f} "
              f"out={r['ct_avg']}")
