#!/usr/bin/env python
"""Datasheet PDF -> in-fortune 详情页 JSON.

路线 A（默认，已跑通）：本地免费文本层抽取 + OpenAI 兼容网关单次调用（Agnes AI）
路线 B（备用）：生成 DashScope/百炼 Batch JSONL，离线提交、5 折异步跑批

用法:
    python parse_datasheets.py --dir data/pdfs --limit 3
    python parse_datasheets.py --dir data/pdfs --workers 4
    python parse_datasheets.py --dir data/pdfs --emit-batch batch_input.jsonl   # 备用路线

设计要点（对应方案文档）:
  * 只在本地抽"参数页"，不把 50 页整本塞给模型 -> 省 70% token
  * response_format=json_object + 严格 schema + 一次修复重试
  * 校验必填（mpn / manufacturer / electrical>=3），失败给结构化 error code
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import random
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
PDF_DIR = ROOT / "data" / "pdfs"
OUT_DIR = ROOT / "data" / "parsed"

# 「请求料号」覆盖表：PDF 文件名 / 文件名派生料号 → 真正的交付订货号。
# 为什么需要：mpn_from_name() 只能从 PDF 文件名推料号，而同族手册共用一份 PDF
# （`ADS1271IPWG4__ads1271.pdf` 里同时有 ADS1271IPW / ADS1271IPWR），
# 于是重解析出来的料号永远是文件名那个，挂不到交付包的行上。实测 5/5 全错。
# 由 --requested-mpn / --requested-mpn-file 填充，键统一小写。
REQ_MPN_MAP: dict[str, str] = {}
NO_OVERWRITE = False


def _req_key(s: str) -> str:
    """覆盖表的键归一：小写，`/`、`#`、空白统一成 `_`。

    不做这步会对不上：`mpn_from_name()` 把文件名里的 `_` 还原成 `/`，
    于是 `DAC0800LCMX_NOPB__snas538c.pdf` 的派生料号是 `DAC0800LCMX/NOPB`，
    用户按习惯写 `DAC0800LCMX_NOPB` 就查不到。
    """
    return re.sub(r"[/#\s]+", "_", (s or "").strip().lower())


def requested_mpn_for(pdf: Path, derived: str) -> str:
    """查覆盖表：先按完整文件名，再按去扩展名的文件名，最后按派生料号。"""
    return (REQ_MPN_MAP.get(_req_key(pdf.name))
            or REQ_MPN_MAP.get(_req_key(pdf.stem))
            or REQ_MPN_MAP.get(_req_key(derived))
            or "")


def load_requested_mpn(spec: str, path: str) -> None:
    """解析覆盖表。``spec`` 形如 ``PDF或料号=订货号,...``；``path`` 为 CSV（pdf,mpn 两列）。"""
    for item in (spec or "").replace("，", ",").split(","):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            raise SystemExit(f"--requested-mpn 格式应为 KEY=MPN，收到 {item!r}")
        k, v = item.split("=", 1)
        REQ_MPN_MAP[_req_key(k)] = v.strip()
    if path:
        with open(path, encoding="utf-8-sig") as fh:
            for row in csv.reader(fh):
                if len(row) < 2 or not row[0].strip() or _req_key(row[0]) in ("pdf", "filename", "mpn"):
                    continue
                REQ_MPN_MAP[_req_key(row[0])] = row[1].strip()
    if REQ_MPN_MAP:
        print(f"请求料号覆盖表 {len(REQ_MPN_MAP)} 条")
MANIFEST = ROOT / "data" / "manifest.csv"

# ---------------------------------------------------------------- 配置
def load_env() -> None:
    """读 .env（不覆盖已存在的真实环境变量）。"""
    for name in (".env.local", ".env"):
        p = ROOT / name
        if not p.exists():
            continue
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()

AGNES_BASE = os.getenv("AGNES_API_BASE", "https://apihub.agnes-ai.com/v1").rstrip("/")
AGNES_KEY = os.getenv("AGNES_API_KEY", "")
AGNES_MODEL = os.getenv("AGNES_MODEL", "agnes-3.0-flash")
DASHSCOPE_BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DASHSCOPE_KEY = os.getenv("DASHSCOPE_API_KEY", "")
DASHSCOPE_MODEL = os.getenv("DASHSCOPE_MODEL", "qwen-flash")


def model_for(stage: str) -> str:
    """按环节取模型名：优先 ICPDF_MODEL_<STAGE>，回退 DASHSCOPE_MODEL。

    用于 parse / repair / review / alternatives / fix 等环节的独立配置。
    不设环节级变量时行为与旧配置完全一致（回退到 DASHSCOPE_MODEL）。
    """
    stage_env = os.getenv("ICPDF_MODEL_" + stage.upper(), "").strip()
    if stage_env:
        return stage_env
    return DASHSCOPE_MODEL


# 主力网关：默认百炼（DashScope）；没配百炼 key 才回退 agnes。
# agnes 免费档限速 4~5 次/分钟，只配作备用（--backend agnes / ICPDF_BACKEND=agnes）。
BACKEND = os.getenv("ICPDF_BACKEND", "dashscope" if DASHSCOPE_KEY else "agnes").strip().lower()
if BACKEND == "dashscope" and DASHSCOPE_KEY:
    API_BASE, API_KEY, MODEL = DASHSCOPE_BASE, DASHSCOPE_KEY, model_for("parse")
else:
    API_BASE, API_KEY, MODEL = AGNES_BASE, AGNES_KEY, AGNES_MODEL

# Qwen3 系思考开关：思考 token 全部计入 completion_tokens 与耗时。
# llm_usage 实测 qwen-flash completion 均值 6478（agnes 同 schema 输出仅 2986），
# 差值疑似思考开销，A/B 验证后定论。默认关。
# 仅 DashScope 请求带该参数（agnes 网关不认识，chat() 有 400 去参重发兜底）。
ENABLE_THINKING = os.getenv("ICPDF_ENABLE_THINKING", "0").strip().lower() in ("1", "true", "yes", "on")

# 页数上限从 12 提到 14：电气档要 6 页才能补回旧实现抽到的电气章节，
# 3（head）+ 3（订货）+ 2（引脚）+ 6（电气）= 14。代价是字符 +8.9%（实测）。
#
# 14 → 16（2026-10-31 晚）：跨页续表规则（select_pages 阶段四）必须配这份预算，
# 否则是零和 —— 实测 ADC12DJ5200SE 在 14 页下加入引脚续页 p6–p8 后，
# 被挤掉的正好是电气续页 p12/p13（VCM/VID 两行就在 p12）。放到 16 页后
# 选中 [1..13, 40, 174, 175]：球位并集 144/144、RθJA/HBM/VCMI/VID 全在，
# 文本 49.6k 字符（比 14 页的 44.3k 只多 12%），仍在本字符预算内。
MAX_PAGES = 16

# 字符预算 32000 → 50000（2026-10-31）。
# 证据：ADC12DJ5200SE（180 页）的 `Thermal Information` 表头绝对偏移 31922、
# `RθJA` 行 32006，旧预算 32000 **正好切在 "RθJA Junction-to-ambient thermal resi"
# 三个字母上** —— 表头进了 prompt，数值全丢，页面因此缺 RθJA/RθJC/RθJB。
# 抬到 50000 后同一份 PDF 的 p1-10 关键表可整页装下（实测占用 ~32.7k）。
# 成本侧：prompt 只增 18k 字符（≈5k token），相对单件 12k 输出上限可忽略。
MAX_CHARS = 50_000
# 单次输出上限：大 datasheet（prompt>7k，如 CDC6CE02x 全 ordering_info）关思考后
# 答案会超 8000 被截断（A/B 实测 3/10 失败）。qwen-flash 输出上限 16384。
MAX_TOKENS = int(os.getenv("ICPDF_MAX_TOKENS", "12000"))

# PDF 文本抽取后端：pymupdf（默认）| pypdf | opendataloader | docstrange
# opendataloader 需 pip install opendataloader-pdf + Java 11+；markdown 缓存落 data/odl_md/
PDF_BACKEND = os.getenv("ICPDF_PDF_BACKEND", "pymupdf").strip().lower()
ODL_MD_DIR = ROOT / "data" / "odl_md"
# docstrange（NanoNets，云端模式会把 PDF 上传其服务器）装在仓库外隔离 venv，
# 避免其 numpy<2 / torch / easyocr 依赖污染主环境
DS_MD_DIR = ROOT / "data" / "ds_md"
DS_PY = ROOT.parent / "dsenv" / "Scripts" / "python.exe"
# 大 ADC/DAC 文档（prompt>10k）12k 仍会截断，首次失败后用模型输出上限重试一次
RETRY_MAX_TOKENS = int(os.getenv("ICPDF_RETRY_MAX_TOKENS", "16384"))
TIMEOUT = 240
RETRIES = 3

# ---- 429 限流退避
# 网关的 free tier 是按速率（QPS/token）限流的，并发一高就会返回
# "You've reached the API rate limit for free users"。
# 通用重试的 2^attempt 秒退避太短：十个线程一起退避、一起重试，
# 会形成惊群，把限流一直顶住。这里改成 429 专用退避（更长、带抖动），
# 并且在多个线程之间共享一个「冷却闸门」——有人被限流时，其余线程一起等。
RATE_LIMIT_RETRIES = int(os.getenv("AGNES_RATE_LIMIT_RETRIES", "5"))
RATE_LIMIT_BACKOFF = float(os.getenv("AGNES_RATE_LIMIT_BACKOFF", "8"))
RATE_LIMIT_MAX_WAIT = float(os.getenv("AGNES_RATE_LIMIT_MAX_WAIT", "90"))
RATE_LIMIT_JITTER = float(os.getenv("AGNES_RATE_LIMIT_JITTER", "4"))

# 主动限速（令牌桶）：网关的 free tier 按速率限流，实测 6 并发约 3.3 次/分钟
# 能跑、10 并发 3.3 分钟就被 429 顶回来，阈值大致在 4~5 次/分钟。
# 设为 0 表示不限速（适合已升级 Token Plan 的 key）。
RATE_LIMIT_RPM = float(os.getenv("AGNES_RATE_LIMIT_RPM", "4"))
RATE_LIMIT_BURST = int(os.getenv("AGNES_RATE_LIMIT_BURST", "2"))


# ---- L2 多网关 / 多 key 加权路由
# 每把 key 一个独立路由（独立配额池、独立令牌桶与冷却闸），按权重分流；
# 429/5xx 自动换路重试。默认一条 dashscope 路由；agnes 仅在显式配置时参与。
#   ICPDF_DASHSCOPE_KEYS=k1,k2   多把百炼 key 并池（未指定权重时均分）
#   ICPDF_LLM_ROUTES=dashscope:9,agnes:1   显式权重（覆盖均分）
# 设 ICPDF_LLM_ROUTES 前请确认对应 key 的配额，别把慢网关打成主路。
def _route_known() -> dict[str, dict]:
    known: dict[str, dict] = {}
    ds_keys = [k.strip() for k in os.getenv("ICPDF_DASHSCOPE_KEYS", "").split(",") if k.strip()]
    if DASHSCOPE_KEY and DASHSCOPE_KEY not in ds_keys:
        ds_keys.insert(0, DASHSCOPE_KEY)
    for i, k in enumerate(ds_keys):
        name = "dashscope" if i == 0 else f"dashscope{i + 1}"
        known[name] = {"name": name, "base": DASHSCOPE_BASE, "key": k,
                       "model": DASHSCOPE_MODEL,
                       "rpm": float(os.getenv("DASHSCOPE_RATE_LIMIT_RPM", "0")),
                       "burst": int(os.getenv("DASHSCOPE_RATE_LIMIT_BURST", "8"))}
    if AGNES_KEY:
        known["agnes"] = {"name": "agnes", "base": AGNES_BASE, "key": AGNES_KEY,
                          "model": AGNES_MODEL, "rpm": RATE_LIMIT_RPM,
                          "burst": RATE_LIMIT_BURST}
    return known


def _routes_from_env() -> list[dict]:
    known = _route_known()
    spec = os.getenv("ICPDF_LLM_ROUTES", "").strip()
    picked: list[dict] = []
    if spec:
        for part in spec.split(","):
            name, _, w = part.partition(":")
            name = name.strip().lower()
            if name not in known:
                continue
            r = dict(known[name])
            try:
                r["weight"] = max(0.0, float((w or "1").strip() or "1"))
            except ValueError:
                r["weight"] = 1.0
            if r["weight"] > 0:
                picked.append(r)
    if not picked:
        name = BACKEND if BACKEND in known else ("dashscope" if "dashscope" in known else "agnes")
        if name in known:
            r = dict(known[name])
        else:                                   # 没有任何 key：保留占位路由，调用时报 401
            r = {"name": name, "base": API_BASE, "key": "", "model": MODEL,
                 "rpm": 0.0, "burst": 1}
        r["weight"] = 1.0
        picked = [r]
    for r in picked:
        r["tokens"] = float(r["burst"])
        r["last"] = time.monotonic()
        r["gate"] = 0.0
    return picked


ROUTES = _routes_from_env()
_route_lock = threading.Lock()


def _route_acquire(route: dict) -> None:
    """取该路由的一枚令牌；桶空则按该路由自己的 RPM 等待（各 key 配额独立）。"""
    rpm = route.get("rpm") or 0
    if rpm <= 0:
        return
    per_call = 60.0 / rpm
    burst = float(route.get("burst") or 1)
    while True:
        with _route_lock:
            now = time.monotonic()
            elapsed = now - route["last"]
            route["last"] = now
            route["tokens"] = min(burst, route["tokens"] + elapsed * (rpm / 60.0))
            if route["tokens"] >= 1.0:
                route["tokens"] -= 1.0
                return
            need = (1.0 - route["tokens"]) * per_call
        time.sleep(max(0.05, need))


def _route_gate_wait(route: dict) -> float:
    with _route_lock:
        return max(0.0, route["gate"] - time.monotonic())


def _route_pause(route: dict, seconds: float) -> None:
    with _route_lock:
        route["gate"] = max(route["gate"], time.monotonic() + seconds)


def _pick_route(exclude: set[str]) -> dict:
    pool = [r for r in ROUTES if r["name"] not in exclude] or ROUTES
    total = sum(r["weight"] for r in pool) or 1.0
    x = random.uniform(0.0, total)
    for r in pool:
        x -= r["weight"]
        if x <= 0:
            return r
    return pool[-1]


def use_single_route(name: str) -> None:
    """CLI --backend 显式选路：忽略加权配置，固定走选定网关。"""
    global ROUTES
    known = _route_known()
    if name not in known:
        return
    r = dict(known[name])
    r.update(weight=1.0, tokens=float(r["burst"]), last=time.monotonic(), gate=0.0)
    ROUTES = [r]


def _is_rate_limit(err: Exception) -> bool:
    text = str(err)
    return "429" in text or "rate limit" in text.lower() or "too many" in text.lower()

# 多语种输出：默认关闭。multi_language（ja/ko/de/es）占输出 token 的约 17%，
# 站上不上的语言没必要让模型写。要开就设 ICPDF_LANGS=ja,ko（逗号分隔）。
LANG_NAMES = {"ja": "日文", "ko": "韩文", "de": "德文", "es": "西文",
              "fr": "法文", "pt": "葡文", "ru": "俄文", "it": "意文"}
LANGS = [x.strip().lower() for x in
         os.getenv("ICPDF_LANGS", "").replace("，", ",").split(",") if x.strip()]

# ---------------------------------------------------------------- Schema
SCHEMA_BASE = """{
  "basic_info": {
    "mpn": "制造商料号，如 CDC6CE040000ADLFR",
    "manufacturer": "制造商全称，如 Texas Instruments",
    "category": "一级分类，如 Integrated Circuits (ICs) / Oscillators",
    "subcategory": "二级分类，如 Programmable Oscillators",
    "description": "一句话产品描述（英文，50-100 词以内，含核心参数）",
    "datasheet_url": "PDF 原始链接，未知填空字符串"
  },
  "specs": {
    "electrical": [{"name": "参数名", "value": "数值(字符串)", "unit": "单位", "condition": "测试条件，无则空字符串"}],
    "absolute_max": [{"name": "参数名", "value": "数值(字符串)", "unit": "单位"}],
    "thermal": [{"name": "热阻参数名，如 RθJA / RθJC(top) / ψJT", "value": "数值(字符串)", "unit": "单位，如 °C/W", "condition": "封装/表变体条件，如 `New Chip; DCY (SOT-223) 4 PINS`；单封装单表留空字符串"}],
    "esd": [{"name": "ESD 测试项，如 HBM / CDM", "value": "数值(字符串)", "unit": "单位，如 V"}],
    "package": {"type": "封装类型，如 4-VDFN", "pins": 引脚数(整数), "dimensions": "尺寸，如 3.2mm x 2.5mm"},
    "temperature": {"operating": "工作温度范围，如 -40°C to 85°C", "storage": "存储温度范围"}
  },
  "features": ["产品特性，一条一项，保留原文关键指标"],
  "applications": ["应用领域"],
  "pin_configuration": [{"pin": 引脚号(整数), "name": "引脚名", "description": "功能说明"}],
  "ordering_info": [{"mpn": "完整可订购料号", "package": "封装", "marking": "丝印", "moq": 最小起订量(整数,未知填 0), "packaging": "包装方式"}],
  "alternatives": [{"mpn": "替代料号", "manufacturer": "制造商", "reason": "替代原因"}],
  "seo": {
    "title_en": "英文 SEO 标题(<=60字符,含品牌型号核心参数)",
    "title_zh": "中文 SEO 标题",
    "meta_description_en": "英文 meta description(150-160 字符)",
    "meta_description_zh": "中文 meta description(80-100 字)",
    "keywords": ["关键词"]
  },
  "metadata": {"pdf_hash": "", "parse_timestamp": "", "model_version": "", "confidence": 0.0}
}"""


def _schema_hint() -> str:
    """按 LANGS 拼 schema：不需要多语种时整块不出现，别让模型白写。"""
    tail = ('  "metadata": {"pdf_hash": "", "parse_timestamp": "", "model_version": "", '
            '"confidence": 0.0}\n}')
    if not LANGS:
        return SCHEMA_BASE
    items = []
    for code in LANGS:
        name = LANG_NAMES.get(code, code)
        items.append(f'    "{code}": {{"description": "{name}描述", "title": "{name} SEO 标题", '
                     f'"meta": "{name} meta description"}}')
    ml = '  "multi_language": {\n' + ",\n".join(items) + "\n  },\n"
    return SCHEMA_BASE.rsplit("  " + '"metadata"', 1)[0] + ml + tail


SCHEMA_HINT = _schema_hint()

LANG_RULE = (
    "multi_language 只输出这些语言：" + "、".join(LANGS) + "，不要输出未要求的语言。"
    if LANGS else
    "不要输出 multi_language 字段（本站只上中英文）。"
)

# ── 电气表数值列规则（版本化）────────────────────────────────────────────
# v1：没有 MIN/TYP/MAX 三列的处理规则。实测后果：模型在「严禁推算」的约束下遇到
#     三列时不选，直接把 value 留空——全库 8,990 件里 I 组 56 件中 37 件是这个形态
#     （证据：`ICC | Quiescent Current | — | 5 | 500 | µA` 抽成 value=""）。
# v2：补齐三列塌缩与多封装列选列规则。上线前必须过「10 件 dry-run 抽样」门禁
#     （修复率 ≥80%、占位符误判 ≤1/10、下限约束参数不得被改坏）。
# 默认 v1：v2 的 10 件 dry-run 门禁（修复率/占位符误判/下限参数/行数塌缩）
# 2026-10-28 首轮结果是 FAIL（占位符误判 6 处 + AM5746ABZXEA 行数 13→0），
# 所以默认仍走 v1。门禁全过后把默认值改成 v2，并同步本注释与 HANDOFF。
#
# v3（2026-10-31，默认）：只加**三条安全规则**，不带 v2 那套会导致行数塌缩的
# 「多封装选列」逻辑，所以不必等 v2 的门禁：
#   · 三列取值：MIN 与 MAX 都有值 → 取 MIN to MAX，禁止拿 TYP/NOM 顶 MIN
#     （ADC12DJ5200SE 的 VCMI 0/0.3/0.55 被写成 "0.3 to 0.55"、VID 0.4/1.0/2.0
#      被写成 "1.0 to 2.0"，两处下限都被抬高，直接改变工程师的可用范围）；
#   · 条件与数值同源：禁止拿 Features 的数值拼 ROC 的条件
#     （-1.25 dBm 出自 p1 Features，条件出自 p10 且对应 -1.5 dBm）；
#   · Abs Max 与 electrical 分家（+26.25 dBm 是 PMAX(INx) 应力值，不是工作参数）。
PROMPT_VERSION = os.getenv("ICPDF_PROMPT_VERSION", "v3").strip().lower()

ELEC_RULES_V1 = ""

ELEC_RULES_V2 = """3b. 该行有 MIN / TYP / MAX 三列时，按以下顺序决定 value，不得留空：
    - 三列全为占位符（-、—、N/A、空） → value = "not_specified"，condition 保留列名占位符
    - 只有一列有值 → value = 该列原文
    - MIN 与 MAX 都有值（范围型，如门限区间、Vpp 范围） → value = "<min原文>~<max原文>",
      condition 末尾追加 "; min=<min原文>, max=<max原文>"
    - 只有 TYP 有值 → value = TYP 原文（典型值），condition 末尾追加 "; typ=<typ原文>"
    - MIN 与 TYP 有值、MAX 为空 → value = MIN 原文（下限约束的典型组合，如增益/带宽门限），
      condition 末尾追加 "; typ=<typ原文>"
    - TYP 与 MAX 有值、MIN 为空 → value = MAX 原文（上限约束的典型组合，如功耗/漏电流），
      condition 末尾追加 "; typ=<typ原文>"
    - 只有 MIN 有值、无法确认是门限还是范围下界 → value = MIN 原文，
      condition 末尾追加 "; note=MIN only, treat as lower bound"
    注意：不要一律取 MAX。VIH（输入高电平门限）、开环增益、带宽是下限约束，
    只有 MIN 列有值，按 MAX 取会把已经抽对的参数改坏。
3c. 若引脚表按封装分多列给出脚号，先按本件 package.type 匹配列名（SOIC/SSOP/PDIP/LCCC 等）；
    匹配不上时取「最大脚号 ≤ package.pins」的那一列，不要默认取第一列。
    取错列会表现为脚号超出 package.pins（如 16 脚件出现 18/20 号）。
"""

# v3：只加三条安全规则。刻意**不**复用 v2 的「多封装选列」，因为 v2 的 dry-run
# 门禁是栽在那一块（AM5746ABZXEA 行数 13→0）。三条规则各自对应一条已取证的事故：
ELEC_RULES_V3 = """3b. 三列数值（MIN / TYP / MAX）取值，不得留空：
    - MIN 与 MAX 都有值 → value = "<MIN原文> to <MAX原文>"。
      **绝对不得用 TYP/NOM 顶替 MIN**：MIN 列写 0 就是 0，不能因为 0 看起来像
      脚注号、占位符或"没填"就跳过它去取 NOM。下限被抬高是最坏的一类错误。
    - 只有 MIN 有值 → value = MIN 原文，condition 末尾追加 "; min only"。
    - 只有 MAX 有值 → value = MAX 原文。
    - 只有 TYP 有值 → value = TYP 原文，condition 末尾追加 "; typ"。
    - 三列都是占位符（-、—、N/A、空） → value = "not_specified"。
3c. 条件与数值必须**同源（同一行）**：value 只能取该行同一行内的数值。
    严禁把 Features / Description / 标题段落里的数值，拼到推荐工作条件表的
    condition 上；也严禁反过来。某行只有条件没有数值时 value 填 "not_specified"，
    不要从别处借一个数来凑。
3d. absolute_max 只收 Absolute Maximum Ratings 表（**不含**其下的 ESD Ratings 小节，
    ESD 归 esd 容器）。严禁把应力额定值（Peak RF input power、Tj、Tstg、IMAX、PMAX 等）
    写进 electrical；反之 electrical 的正常工作参数也不许写进 absolute_max。
    同一参数在 Features 与 Abs Max 都出现时（如 Peak RF input power），
    **以 Abs Max 为准**，并保留其全部限定条件（如 "ZS = 50 Ω, up to 21 days"）。
"""

ELEC_RULES = {"v2": ELEC_RULES_V2, "v3": ELEC_RULES_V3}.get(PROMPT_VERSION, ELEC_RULES_V1)

SYSTEM_PROMPT = f"""你是电子元器件 Datasheet 解析专家。从给定 PDF 文本中抽取结构化数据，严格输出 JSON。

规则：
0. **输出顺序强制**：先写 `specs.electrical`（最优先，必须覆盖整张电气表），再写
   `absolute_max` / `thermal` / `esd`，最后才写 `features` / `applications` /
   `pin_configuration` / `seo`。**严禁**为了凑 features/description/SEO 文案而压缩
   或截断 electrical —— 电气表是首要产物，宁可 features 只写 3 条。
   100 件灰度实测：把 features/description 写在前面会让 flash 把 token 全花在废话上，
   电气数组直接交白卷（empty_electrical）。
1. 只输出 JSON 对象，不要 markdown 代码块，不要解释，不要新增/遗漏任何 key。
2. 所有 key 必须存在；未知的标量填空字符串 ""，未知数组填空数组 []，未知整数填 0。
3. electrical 取 Electrical Characteristics / Recommended Operating Conditions / Switching Characteristics 表，尽量覆盖表中全部参数（一般 8-25 项）；数值与单位分开，测试条件原样写进 condition。
4. absolute_max 取 Absolute Maximum Ratings 表。package.pins 必须是整数（从 Pin Functions 表或封装名推断）。
4b. 严禁插值、推算、估算：value 必须是表中该型号所在行的原文数值；表中没有对应行就跳过该项，不要用"约/典型/介于"之类的自造数值。
4c. 若文本中是范围值（如 -0.3 to 3.63），value 保留范围原文，unit 只放单位。
4d. thermal 只取 Thermal Information 表（RθJA / RθJC / RθJB / ψJT / ψJB），esd 只取
    ESD Ratings 表（HBM / CDM）。这两类**各有专属容器**：严禁把它们写进
    electrical 或 absolute_max；原文没有对应表时填空数组 []，不要从正文段落里借数。
    **参数名按原文写法保留**：原文印 `Rθ(JA)` 与 `RθJA` 是同一项，不得因为多了
    括号就跳过；`RθJA`（结到环境）是必抽项，热阻表里有就必须出条目（Issue #14）。
    ESD 数值必须保留原文的 `±` 号：原文 ±2000 V 就写 `±2000`，**不得写成 `+2000`**
    或 `2000` —— 丢符号会把「正负双向耐压」读成「单向上限」。
4e. **多封装列必须逐列展开（严禁只抽第一列）**：热阻表 / 电气表的表头出现多个
    封装列时（如 `DCY (SOT-223) | KCS (TO-220) | KCT (TO-220) | KTT (TO-263)`，
    或 `LM317 (Legacy Chip) | LM317 (New Chip)`），**每一列都要单独出一条**，
    并把该列的表头文字原样写进 `condition`。只抽第一列等于把另外几个封装的
    热阻/参数全部丢掉，页面会给出一个没有适用封装的裸数字 —— 这是数据造假，
    不是简化。同一页出现**多张同名的表**（如 `6.4 Thermal Information (Legacy
    Chip)` 与 `6.5 Thermal Information (New Chip)`）时，两张都要抽，并用表名
    区分 `condition`。单元格印 `NA` / `—` / `–` 的，**跳过该列该行**，不要拿
    相邻列的数字顶上。
4f. 同一参数在不同封装列下数值不同是正常的，不是重复行；不要因为「名字一样」
    就只留一条。
4g. **严禁整条参数漏掉**：热阻表里出现的每一条参数（RθJA / RθJC(top) /
    RθJC(bot) / RθJB / ψJT / ψJB）都必须至少产出一行。整条参数一条都不出现，
    与「只抽第一列」是同一等级的缺陷 —— 客户会以为这颗料没这项指标。
    若某参数在表里只剩占位符（全是 `NA` / `—`），才允许该参数为空。
4h. **MIN / TYP / MAX 是三列，不是「一个范围」**：表头有 MIN/TYP/MAX 三列时，
    同一参数**每一列有值就单独出一条**，并在 `condition` 末尾写明列角色
    （如 `TA = 25°C; TYP`）。**严禁**把 MIN 与 MAX 连写成 `8.8 to 11.2` ——
    那是把两列压成一个虚构区间：MIN 8.8 与 MAX 11.2 之间并不存在「任意值都合规」
    的含义，客户按它设计会误判。只有**原文同一单元格里本来就印着 `a to b`**
    （单格范围值，如输入电压范围）时，才允许 value 写成范围。
    同理 `±0.3` 落在 TYP 列就写 `condition: …; TYP`，不得标成 MIN。
{ELEC_RULES}5. features / applications 保留原文要点，一条一项，不要合并成一段。
6. pin_configuration 覆盖 Pin Functions 表全部引脚；**pin 字段必须填表中 NO. 列的
   脚号/球位号原文**（如 `A1`、`G11`、`M12`），严禁用 1、2、3… 这样的序号代替 ——
   序号看起来像脚号，却会让球位网格（BGA/FCBGA）整张失效。若表里确有纯数字脚号
   （如 SOIC 的 1-8），才填数字。ordering_info 取 Ordering Information /
   Package Option Addendum 全部行（不要只留一行）。
7. alternatives 只填 PDF 里明确写到的替代/相关型号，没有就 []。
8. description 与 SEO 文案基于原文事实撰写，禁止编造参数；{LANG_RULE}
9. metadata.confidence 用 0-1 表示你对本次抽取的整体置信度（表格残缺、扫描件、型号不符时给低分）。

输出 JSON 结构（字段含义见注释，实际输出不要带注释）：
{SCHEMA_HINT}"""

USER_TMPL = """料号提示：{mpn}
文件名：{fname}
文本层页数：{pages_used}/{pages_total}

--- PDF 文本开始 ---
{text}
--- PDF 文本结束 ---

请输出 JSON。"""

REQUIRED = ["basic_info", "specs", "features", "applications", "pin_configuration",
            "ordering_info", "alternatives", "seo", "metadata"]
if LANGS:
    REQUIRED.insert(8, "multi_language")


# ---------------------------------------------------------------- 文本抽取
# 页选择优先级：先命中先占预算。订货表排最前——它是料号身份的原厂证据，
# 而 TI/ADI 几乎都把它放在文档末尾（实测 284 页的 F280037CSPTR 在第 246 页、
# 103 页的 6PAIC3104IRHBRQ1 在第 95 页）。旧的「只读前 12 页」把它整段丢掉，
# 模型只能从封面那张一行小表挤出一条 ordering_info。
PAGE_PRIORITY: tuple[tuple[str, ...], ...] = (
    ("ordering information", "package option addendum", "orderable information",
     "ordering information table"),
    ("pin functions", "terminal functions", "pin configuration", "signal descriptions"),
    ("electrical characteristics", "recommended operating", "absolute maximum",
     "switching characteristics", "dc characteristics", "thermal information"),
    ("device comparison", "specifications", "features", "description"),
)

# 每档最多占几页 + 电气档的字符保底。
#
# 为什么电气档要有字符保底：只给页数配额不够——`RANK_QUOTA` 限制的是页数，
# 而预算是按字符算的，一页引脚表能有一万字符，照样把 MAX_CHARS 吃满。
# 而选页是按 (rank, page) 排的，rank 1/2 排在前面先花钱，rank 3（电气）排最后
# 只能捡剩余。228 件重解析实测：221 件触发预算裁剪，71 件电气页直接落选，
# 去重电气签名净减 769。
#
# 额度不是拍脑袋定的：`qc/tune_page_budget.py` 在同一批 228 份真实 PDF 上横比了
# 8 种组合（见 docs/qc/重解析批次电气损失诊断_228件_20261028.csv）。(3,2,6) + 14 页
# + 14k 保底是「电气恢复最多、订货页一页不掉」的拐点：电气页 3.66→5.37/件，
# 订货页 2.72→2.71，字符 25.6k→27.9k（+8.9%），低于旧实现基线的件 81→13。
# 再往上加（(3,2,7)/15 页）电气只多 0.47 页，订货页反而掉到 2.57，不划算。
RANK_QUOTA = (3, 2, 6)

# 电气档字符保底：保底阶段先给 rank 3 攒够这么多字符，再按档补其余页。
# 短文档攒不满也不会浪费——没用完的额度自动回到全局预算给别的档。
ELEC_FLOOR_CHARS = 14_000

# 全文扫页上限（超大附件兜底，避免 800 页的机械手册把解析拖死）
PAGE_SCAN_CAP = 800

# 强制入列的关键页（2026-10-31）：命中这些标题的页**不受档位配额约束**，
# 页数/字符预算不够时**踢掉低档页腾位置**，而不是把它丢掉。
#
# 为什么单独拉一条硬规则：RANK_QUOTA 是按「档」给页数的，同一档里 6 个名额
# 按页号升序取，Thermal Information 这种排在章节末尾的表天然排最后。实测
# ADC12DJ5200SE：热阻表在 p10 末尾被字符预算切掉；ESD Ratings 在 p9 被模型
# 漏抽；订货表在 p175 被 12 页上限挡在门外 —— 三类缺口三个原因，但都能被
# 「这一页必须进」这一条规则兜住（预算不够就让位）。
MANDATORY_PAGE_KEYS: tuple[str, ...] = (
    "thermal information",
    "esd ratings",
    # 1102-V3.4：电气表页必须保底。红先测试实证（42 页手册电气表在 p31 时，
    # 选中集合 [2..16, 32] —— p31 本体被挤掉，只留下它的续页），
    # 这正是 `ADC08B200EB` 空电气表的真因：不是模型不行，是表页没进上下文。
    #
    # V3.5 升级为「按子节各保首页」：TI 手册常把电气表拆成 DC / Power / AC /
    # Timing 四段，只保「第一页」会保住 DC 却丢掉 Power/AC 整段（实测
    # ADC12QJ1600ALREP：p11/p12 进上下文，p13 与 p15–p19 全掉出预算）。
    "dc specifications",
    "power consumption",
    "ac specifications",
    "timing requirements",
    "switching characteristics",
    "electrical characteristics",      # 没有子节命名的文档兜底
    "absolute maximum ratings",
    "ordering information",
    "package option addendum",
    "orderable information",
)

# 强制页总数上限：14 页配额下留 5 页给关键表，其余仍归正常档位分配。
# 不设上限时，连续十几页的 POA 会把 14 页配额全吃掉（见 tests/test_select_pages.py）。
# V3.5 提到 9：热阻 + ESD + DC + Power + AC + Timing + 电气兜底 + 绝对最大 + 订货。
# 同一页常同时命中多个 key（`electrical characteristics: dc specifications`），
# 去重后实际占用通常只有 5–7 页。
MANDATORY_MAX_PAGES = 9

# 跨页续表的追加上限（见 select_pages 阶段四）。
# 事故标尺：ADC12DJ5200SE 的 `Table 4-1. Pin Functions` 横跨 p4–p8 共 5 页，
# 引脚档配额只有 2 页 —— 只喂 p4/p5 时模型交出 32 条引脚，而 p4–p8 的球位
# 并集正好 144 条（旧版按「前 12 页」取，天然含全，所以这是 10-28 选页重写
# 引入的回归，不是模型变差）。追加超过 4 页说明这张表长得离谱，
# 与其吃光预算，不如保留预算给电气表并如实标记 truncated。
CONT_MAX_PAGES = 4


def _ec_pick_order(cands: list, quota: int, gap: int = 2) -> list:
    """电气档（rank=3）的取页顺序：**最长连续块的尾页提到最前**，其余按页号升序。

    为什么需要：EC 表常跨页连载（AFE4490RHAT 从 p8 续到 p14），而功耗、噪声
    这类参数恰好排在**续表尾部**。按页号升序取前 N 页会把尾巴永远切掉——
    AFE4490 的 rank=3 候选 11 个（p4,5,8,9,10,11,12,13,14,39,72），配额 6 页时
    升序只拿到 p4~p11，POWER DISSIPATION 表所在的 p14 必然落选。实测后果：
    该件 v1 因此**编造** 2.3 mW、v2 因此标 `not_specified`——都不是模型取值
    能力问题，是压根没看到那张表。

    为什么不是简单「全表首尾各半」：超长文档（AM5746ABZXEA 有 81 个 rank3
    候选）的"尾部"是 p420/424/449 这类**文档末尾附录**，不是 EC 续表，
    简单取尾会把预算从真表区（p158~209）挪到附录上。所以要先按页码连续性
    分块，只在**块内**做首尾各半，块间按块长比例分配配额。

    单块文档（如 DAC39J82IAAV 的 10 个候选连成一整块）会自然退化成
    「整块首尾各半」，覆盖度不降。**页数配额与字符预算都不变，成本不变。**
    """
    ordered = sorted(cands, key=lambda x: x[1])
    if quota <= 0 or len(ordered) <= quota:
        return ordered

    # 按页码连续性分块（间隔 <= gap 视作同一块）
    blks: list[list] = []
    for c in ordered:
        if blks and c[1] - blks[-1][-1][1] <= gap:
            blks[-1].append(c)
        else:
            blks.append([c])

    # 只把**最长块的尾页**提到最前，其余仍按页号升序。
    #
    # 为什么不按块长比例分配配额：实测在 AFE4490 上会退步——比例分配给
    # p39 / p72 各留 1 页，字符预算下 p13 先被选中占位，p14 反而挤不进去
    # （选中 [4,5,8,13]，p14 落选）。只提一个尾页不占额外预算，最省。
    longest = max(blks, key=len)
    tail = longest[-1]
    return [tail] + [c for c in ordered if c[1] != tail[1]]


def _parse_int_map(raw: str) -> dict[str, int]:
    """解析 `MPN=32,MPN2=28` 形式的按件覆盖表。"""
    out: dict[str, int] = {}
    for part in (raw or "").split(","):
        k, _, v = part.partition("=")
        k, v = k.strip().upper(), v.strip()
        if k and v.isdigit() and int(v) > 0:
            out[k] = int(v)
    return out


# 按 mpn 单独覆盖页/字符预算。
#
# 为什么需要：体量差异极大——AFE4490RHAT 98 页、AM5746ABZXEA 474 页，
# 而 74FCT162841CTPACT 只有 15 页。为照顾少数超长文档抬高全局 `MAX_PAGES`，
# 会让**全库每一件**都多花钱；而全局收紧又救不了那些件。所以例外要按件给。
#
# 用法（环境变量，逗号分隔）：
#   ICPDF_MAX_PAGES_OVERRIDE="AM5746ABZXEA=40,DLPC8445AMD=60"
#   ICPDF_MAX_CHARS_OVERRIDE="AM5746ABZXEA=90000"
MAX_PAGES_OVERRIDE = _parse_int_map(os.getenv("ICPDF_MAX_PAGES_OVERRIDE", ""))
MAX_CHARS_OVERRIDE = _parse_int_map(os.getenv("ICPDF_MAX_CHARS_OVERRIDE", ""))

#: 评估板/套件型号特征（1102-V3.3 板卡预路由）。
#: 100 件灰度实测：board 层 processed 21 件全部 empty_electrical（100%），
#: chip 层只有 55% —— 板卡件白烧 API 钱，必须先分流。
#: 注意**不含 DEV**：`ADC08D1520DEV_NOPB` 这类 DEV 板其实带完整电气表（实测 elec=113），
#: 误杀会丢真数据。
BOARD_KIT_TOKENS = ("EVAL", "EVM", "EMK", "LAUNCHXL", "TESTER", "PDK", "BOOST", "KIT", "XLR")
#: 芯片级电气表特征词：板卡手册通常没有
_BOARD_TABLE_MARKERS = ("electrical characteristics", "recommended operating",
                        "switching characteristics", "electrical specifications")
#: 正文层面的评估板证据（型号看不出时靠它兜底，见 `board_expected_empty`）
_BOARD_DOC_MARKERS = ("evaluation board", "evaluation module", "evaluation kit",
                      "user's guide", "users guide", "evm user", "daughter card",
                      "this evaluation")


def is_board_kit(name: str) -> bool:
    up = (name or "").upper()
    return any(t in up for t in BOARD_KIT_TOKENS)


def board_expected_empty(name: str, text: str) -> bool:
    """评估板/套件 **且** 正文没有芯片级电气表 → 不值得进重型抽取。

    判定有两条独立证据，命中任一即可（两者都必须叠加「无电气表」这个否决条件，
    否则会误杀少数确实带电气表的 EVAL 件）：

    ① 型号特征：`...EVAL` / `...EVM` / `...LAUNCHXL` …
    ② **正文特征**：出现 "evaluation board / evaluation module / user's guide"。
       这条是 100 件灰度逼出来的：`ADC08B200EB`、`2MTR-DYNO`、`ADS1675REF`
       这些型号后缀（EB / DYNO / REF）看不出是板卡，但正文就是评估板手册，
    只靠型号正则永远拦不住。
    """
    low = (text or "").lower()
    if any(k in low for k in _BOARD_TABLE_MARKERS):
        return False                       # 有芯片级电气表 → 一律不放行分流
    if is_board_kit(name):
        return True
    return any(k in low for k in _BOARD_DOC_MARKERS)


def text_is_garbled(text: str, min_chars: int = 400) -> bool:
    """文本层乱码检测（1102-V3.4）：明显不可读的抽取结果不该进 LLM。

    判据刻意保守（只抓「几乎不可读」）：字符构成比 < 0.45，或常见技术词命中 < 6。
    正常英文 Datasheet 这两项都远高于阈值；中文/日文表可用 `isalnum()` 兜住。
    命中即打 `ERR_OCR_REQUIRED` 跳过重型抽取，省 Token，留给 OCR/视觉通道。
    """
    sample = (text or "")[:8000]
    if len(sample) < min_chars:
        return False
    ok = sum(1 for ch in sample if ch.isalnum() or ch in " .-±°µ%/×()[]:,")
    ratio = ok / len(sample)
    common = len(re.findall(
        r"\b(voltage|current|frequency|temperature|input|output|pin|min|max|typ|"
        r"unit|characteristics|table|supply|range|test)\b", sample.lower()))
    return ratio < 0.45 or common < 6


def context_has_elec_table(text: str) -> bool:
    """上下文里到底有没有电气表头 —— 兜底路由的**唯一**放行证据。

    没有证据就升级模型 = 拿贵模型赌运气；有证据仍空 = 模型确实读不动。
    """
    low = (text or "").lower()
    return any(k in low for k in ("electrical characteristics", "recommended operating conditions"))


#: 兜底模型：**默认关闭**（空串）。只有显式设置 `ICPDF_MODEL_PARSE_FALLBACK` 才启用。
#: 历史：曾默认 `qwen3.7-plus`，而生产 `deploy/.env` 里并没有这个键 ——
#: 等于生产环境在**未授权**的情况下每件 empty 都自动花 plus 的钱（§8.3 成本敞口）。
#: 兼容旧名 `ICPDF_FALLBACK_MODEL`；两者都未设或设为空串 → 关闭。
FALLBACK_MODEL = os.getenv("ICPDF_MODEL_PARSE_FALLBACK",
                           os.getenv("ICPDF_FALLBACK_MODEL", "")).strip()


def accept_thin(name: str, text: str) -> bool:
    """`ICPDF_ACCEPT_THIN=1` 时，**板卡**件允许「无电气表」落盘。

    判定必须同时满足三条，缺一不可：
      ① 开关打开；
      ② 型号命中板卡特征（EVAL/EVM/PDK/…）—— 不能只看正文，因为真实 Datasheet
         里也会出现 "evaluation board"（相关工具/评估套件章节），
         实测 `ADC08B200EB` 就是纯芯片手册却被正文特征误判成薄件、写盘成 elec=0；
      ③ 正文确实没有电气表头（真缺表才叫薄件）。
    """
    if os.getenv("ICPDF_ACCEPT_THIN", "0").strip() != "1":
        return False
    if not is_board_kit(name):
        return False
    low = (text or "").lower()
    return not any(k in low for k in _BOARD_TABLE_MARKERS)


def adaptive_budget(total_pages: int) -> tuple[int, int]:
    """选页预算：**默认不放大**（1102-V3.3 回退）。

    历史：V3.2 曾对 >100 页文档放宽到 32 页 / 100k 字符，理由是
    `BQ79614PAPRQ1`（222 页）在 16 页预算下电气行 57 → 22。
    **但 100 件灰度证明这个放宽是错的**：qwen-flash 面对 32 页上下文
    注意力涣散，`empty_electrical` 大面积激增（守卫被迫整批回滚）。
    结论：flash 的**有效上下文**远小于它的窗口，喂得越多抽得越少。

    因此默认退回 `16 页 / 50k`；确需放宽的超长手册走按件白名单：
      ICPDF_MAX_PAGES_OVERRIDE="AM5746ABZXEA=40"
      ICPDF_MAX_CHARS_OVERRIDE="AM5746ABZXEA=90000"
    需要复现 V3.2 行为时显式置 `ICPDF_ADAPTIVE_BUDGET=1`。
    """
    if os.getenv("ICPDF_ADAPTIVE_BUDGET", "0") == "1" and total_pages > 100:
        return 32, 100_000
    return MAX_PAGES, MAX_CHARS


def select_pages(pages, max_pages: int = MAX_PAGES, max_chars: int = MAX_CHARS):
    """挑要送给模型的页：前 3 页打底，再按 `PAGE_PRIORITY` 补关键页。

    返回 `(文本, 选中页数, 是否被预算裁掉)`。
    **整页取舍，不做半页截断**：旧实现用 `out[:max_chars]` 切字符串，会把排在
    后面的订货表切成半个表，比不给更糟。

    两阶段分配（这是 228 件实测逼出来的，不是拍脑袋）：
      阶段一 保底：先给电气档攒够 `ELEC_FLOOR_CHARS`，防止它被前面的档挤光；
      阶段二 补充：head 打底，再按 (档位, 页码) 用**剩余**预算填充。
    保底没用完的额度不会浪费——阶段二本来就在同一份全局预算里花。
      阶段三 强制：`MANDATORY_PAGE_KEYS` 命中的页（热阻/ESD/绝对最大/订货）
    无论落在哪一档、排序多靠后，都必须入列；页数或字符预算不够时**踢掉
    最低优先级的非强制页**腾位置，而不是把它丢掉（2026-10-31 补）。
    """
    head: list[tuple[int, int, str]] = []
    ranked: list[tuple[int, int, str]] = []
    mandatory: dict[int, str] = {}
    alltext: dict[int, str] = {}          # 阶段四查续页用（pages 是生成器，不能回看）
    # 自适应预算：调用方没显式覆盖时，按文档规模自动放宽（百页级手册 16 页不够用）。
    # 必须先物化成 list 再取总数 —— `pages` 可能是生成器，先 max() 会把它耗尽。
    if max_pages == MAX_PAGES and max_chars == MAX_CHARS:
        pages = list(pages)
        _total = max((i for i, _ in pages), default=0)
        max_pages, max_chars = adaptive_budget(_total)
    for i, text in pages:
        if i >= PAGE_SCAN_CAP:
            break
        if not text.strip():
            continue
        alltext[i] = text
        # 标题可能被排版拆行（`ELECTRICAL\nCHARACTERISTICS`），先归一空白再匹配，
        # 否则强制保底会静默失效（实测 TI 手册里这种拆行很常见）。
        # 归一化与目录页判据都走 `qc/page_filters`，和取证探针共用一份词表。
        try:
            from qc.page_filters import normalize_ws as _nws
            low = _nws(text)
        except Exception:                                  # noqa: BLE001
            low = re.sub(r"\s+", " ", text.lower())
        if any(k in low for k in MANDATORY_PAGE_KEYS):
            mandatory[i] = text
        if i < 3:
            head.append((0, i, text))
            continue
        rank = len(PAGE_PRIORITY) + 1
        for n, keys in enumerate(PAGE_PRIORITY, start=1):
            if any(k in low for k in keys):
                rank = n
                break
        ranked.append((rank, i, text))

    # 电气档按「首尾各半」重排取页顺序，其余档仍按页号升序。
    # 映射成「档内优先序号」而不是直接改列表，这样阶段一/阶段二共用同一个排序键。
    ec_seq: dict[int, int] = {}
    if len(RANK_QUOTA) >= 3:
        ec_cands = [r for r in ranked if r[0] == 3]
        for pos, r in enumerate(_ec_pick_order(ec_cands, RANK_QUOTA[2])):
            ec_seq[r[1]] = pos

    def _rank_key(x: tuple) -> tuple:
        return (x[0], ec_seq.get(x[1], x[1]))

    chosen: list[tuple[int, str]] = []
    chosen_rank: dict[int, int] = {}
    chars, dropped = 0, False
    taken: dict[int, int] = {}
    pages_left = max_pages

    def _take(rank: int, i: int, text: str) -> None:
        nonlocal chars, pages_left
        chosen.append((i, text))
        chosen_rank[i] = rank
        taken[rank] = taken.get(rank, 0) + 1
        chars += len(text)
        pages_left -= 1

    # ---- 阶段一：电气档字符保底 ----
    # 只保电气档：订货档靠阶段二的档位顺序本来就能优先拿到预算，
    # 引脚档页数已被 RANK_QUOTA 压到 2 页，两者都不需要额外保底。
    if len(RANK_QUOTA) >= 3:
        floor_got = 0
        for rank, i, text in sorted([r for r in ranked if r[0] == 3], key=_rank_key):
            if floor_got >= ELEC_FLOOR_CHARS or taken.get(3, 0) >= RANK_QUOTA[2]:
                break
            if pages_left <= 0 or chars + len(text) > max_chars:
                break
            floor_got += len(text)
            _take(rank, i, text)

    # ---- 阶段二：head 打底 + 按档补充 ----
    for rank, i, text in head + sorted(ranked, key=_rank_key):
        if any(i == ci for ci, _ in chosen):
            continue
        quota = RANK_QUOTA[rank - 1] if 1 <= rank <= len(RANK_QUOTA) else 99
        if taken.get(rank, 0) >= quota:
            continue
        if pages_left <= 0 or chars + len(text) > max_chars:
            dropped = True
            continue
        _take(rank, i, text)

    # ---- 阶段三：强制关键页（热阻/ESD/绝对最大/订货）----
    # 这三类页在真实文档里几乎总排在章节末尾：热阻在 ROC 之后、ESD 在 Abs Max
    # 之后、订货表在全文最后几页。只靠「档位 + 页码升序」拿不到它们，只能硬保。
    #
    # **每类只保首页 + 全局封顶**：TI 的 POA 常常连续十几页都是
    # `PACKAGE OPTION ADDENDUM`（实测 18 页 × 18k 字符），全保会把预算吃光、
    # 把电气页挤掉——这正是 `test_continuous_poa_pages_do_not_exhaust_budget`
    # 守的那条线。真实订货表就在这一组的首页，保首页足够。
    mand_by_key: dict[str, list[int]] = {}
    for i in sorted(mandatory):
        low = mandatory[i].lower()
        # 目录页也含章节标题（"Electrical Characteristics .... 5"），
        # 若不排除，强制位会被目录页占掉，真正的表页反而进不来。
        if "table of contents" in low or "contents of this document" in low:
            continue
        for k in MANDATORY_PAGE_KEYS:
            if k in low:
                mand_by_key.setdefault(k, []).append(i)
                break
    mand_keep: list[int] = []
    for k in MANDATORY_PAGE_KEYS:                 # 按 key 声明顺序即优先级
        if len(mand_keep) >= MANDATORY_MAX_PAGES:
            break
        pages_of_k = mand_by_key.get(k) or []
        if pages_of_k:
            mand_keep.append(pages_of_k[0])
    mand_keep = list(dict.fromkeys(mand_keep))[:MANDATORY_MAX_PAGES]

    def _evict(cands: list[tuple[int, str]], key) -> None:
        """踢掉一个非强制页，同步回滚 chars/taken/pages_left。"""
        nonlocal chars, pages_left
        victim = max(cands, key=key)
        chosen.remove(victim)
        rank_v = chosen_rank.pop(victim[0], 99)
        taken[rank_v] = max(0, taken.get(rank_v, 0) - 1)
        chars -= len(victim[1])
        pages_left += 1

    for i in mand_keep:
        if any(i == ci for ci, _ in chosen):
            continue
        text = mandatory[i]
        # 页数不够：踢最低档（档位号最大）→ 同档取页码最大者
        while len(chosen) >= max_pages:
            cands = [c for c in chosen if c[0] not in mand_keep]
            if not cands:
                break
            _evict(cands, lambda c: (chosen_rank.get(c[0], 99), c[0]))
        # 字符不够：踢最长的那页（腾出的空间最大，且不损关键页）
        while chars + len(text) > max_chars:
            cands = [c for c in chosen if c[0] not in mand_keep]
            if not cands:
                break
            _evict(cands, lambda c: (len(c[1]), c[0]))
        if len(chosen) >= max_pages or chars + len(text) > max_chars:
            dropped = True          # 腾不出位置，如实标记被裁，不假装成功
            continue
        _take(99, i, text)          # rank=99：强制页不占任何档位配额

    # ---- 阶段四：跨页续表（2026-10-31 补，治 pins 144→32 的回归）----
    # 一张表被排版切成多页时，续页开头会带 `(continued)`。这类页和它的前一页
    # 是**同一条数据**的两半：只给前半，模型不会说「我没看到」，
    # 而是照着前半交出一份**看起来完整、实际只有一半**的引脚表 —— 静默失效。
    # 所以只要前一页已入选，续页就必须一起入选；配额不适用（rank=99），
    # 名额不够时按阶段三的同一套规则踢最低档页，而不是把续页丢掉。
    def _is_cont(text: str) -> bool:
        return "(continued)" in text[:200].lower()

    cont_pages: list[int] = []
    grew = True
    while grew and len(cont_pages) < CONT_MAX_PAGES:
        grew = False
        # 关键：已收集的续页也算「已占用」，否则链式续页（p5→p6→p7→p8）
        # 只会前进一页就断 —— chosen 在这一轮还没被改写。
        taken_idx = {ci for ci, _ in chosen} | set(cont_pages)
        for ci in sorted(taken_idx):
            nxt = ci + 1
            if (nxt in alltext and nxt not in taken_idx
                    and nxt not in cont_pages and _is_cont(alltext[nxt])):
                cont_pages.append(nxt)
                grew = True
                if len(cont_pages) >= CONT_MAX_PAGES:
                    break

    for i in cont_pages:
        text = alltext[i]
        while len(chosen) >= max_pages:
            cands = [c for c in chosen if c[0] not in mand_keep and c[0] not in cont_pages]
            if not cands:
                break
            _evict(cands, lambda c: (chosen_rank.get(c[0], 99), c[0]))
        while chars + len(text) > max_chars:
            cands = [c for c in chosen if c[0] not in mand_keep and c[0] not in cont_pages]
            if not cands:
                break
            _evict(cands, lambda c: (len(c[1]), c[0]))
        if len(chosen) >= max_pages or chars + len(text) > max_chars:
            dropped = True
            continue
        _take(99, i, text)

    chosen.sort()
    out = "".join(f"\n--- Page {i + 1} ---\n{t}" for i, t in chosen)
    return out, len(chosen), dropped


def _pyfitz():
    """优先 `pymupdf`（新 API），退回旧的 `fitz` —— 消除 FutureWarning 噪音。"""
    try:
        import pymupdf as fitz  # type: ignore
        return fitz
    except ImportError:
        import fitz  # type: ignore
        return fitz


def _iter_pages(path: Path):
    """优先 PyMuPDF（若环境有），否则退回 pypdf。返回 (总页数, 逐页文本生成器)。"""
    try:
        fitz = _pyfitz()
        doc = fitz.open(path)
        return len(doc), ((i, doc[i].get_text()) for i in range(len(doc)))
    except ImportError:
        import logging
        logging.getLogger("pypdf").setLevel(logging.ERROR)   # 屏蔽 fontTools 字体告警
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        return len(reader.pages), ((i, p.extract_text() or "") for i, p in enumerate(reader.pages))


# ---------------------------------------------------------------- OpenDataLoader 后端
# ODL markdown 无页标记，改按标题分节选"参数相关"内容（等价 PAGE_PRIORITY 的页筛选意图）
# top view/function table 是老 SN74 系引脚图与真值表的通用标题写法（无 Pin Configuration 节）
ODL_KEEP = ("electrical characteristics", "absolute maximum", "recommended operating",
            "switching characteristics", "dc characteristics", "pin configuration",
            "pin functions", "terminal functions", "ordering information",
            "orderable information", "package option addendum", "package information",
            "device comparison", "specifications", "features", "thermal information",
            "top view", "function table")

_MD_HEAD = re.compile(r"(?m)^#{1,6} ")


def odl_convert(pdfs: list[Path], out_dir: Path | None = None) -> int:
    """批量 PDF -> ODL Markdown（一次 JVM 转完，产物 {stem}.md 落缓存）。返回本次新转数量。"""
    out_dir = out_dir or ODL_MD_DIR
    todo = [p for p in pdfs if p and not (out_dir / f"{p.stem}.md").exists()]
    if not todo:
        return 0
    import opendataloader_pdf                      # 懒加载：默认后端无需安装
    out_dir.mkdir(parents=True, exist_ok=True)
    opendataloader_pdf.convert(input_path=[str(p) for p in todo],
                               output_dir=str(out_dir), format="markdown")
    return len(todo)


def _md_pick(md: str, max_chars: int) -> tuple[str, int]:
    """markdown 后端共用：文档头 + 标题命中 ODL_KEEP 的节；超出 max_chars 停止。"""
    lines = md.splitlines()
    heads = [i for i, ln in enumerate(lines) if _MD_HEAD.match(ln)]
    first = heads[0] if heads else len(lines)
    blocks: list[tuple[str, list[str]]] = [("", lines[:first])]
    for n, i in enumerate(heads):
        end = heads[n + 1] if n + 1 < len(heads) else len(lines)
        blocks.append((lines[i], lines[i:end]))
    picked: list[str] = []
    for title, block in blocks:
        if title:
            low = title.lower() + " " + " ".join(block[:3]).lower()
            if not any(k in low for k in ODL_KEEP):
                continue
        txt = "\n".join(block).strip()
        if txt:
            picked.append(txt)
            if sum(len(t) for t in picked) > max_chars:
                break
    out = "\n\n".join(picked)
    # 整块回退，不做 `out[:max_chars]` 半块切：切一半的表比不给更糟
    # （旧实现在 ADC12DJ5200SE 上把热阻表切在 "RθJA … resi" 三个字母处）。
    while len(out) > max_chars and len(picked) > 1:
        picked.pop()
        out = "\n\n".join(picked)
    if len(out) < 2000:
        # 老格式（Harris/90s TI）常无标题结构：选取过小说明节匹配失效，退回全文截断
        return md.strip()[:max_chars], 1
    return out, len(picked)


_DS_CLI = ROOT / "qc" / "ds_cloud.py"   # 走新版 /api/v1/extract/async（旧 /extract 已废弃返回 429）


def ds_convert(pdfs: list[Path], out_dir: Path | None = None) -> int:
    """docstrange 云端模式：PDF -> Markdown（需仓库外 venv E:\\workspace\\dsenv 已装 requests）。

    认证：先 `docstrange login` 生成 ~/.docstrange/credentials.json（首次需浏览器确认），
    或设置 NANONETS_API_KEY。云端按页计费（$0.01/页；免费层 lifetime 500 页）。

    安全边界：显式选择 `--pdf-backend docstrange` 即视为确认上云，这里传
    ICPDF_DS_CLOUD=1；但 qc/ds_cloud.py 仍会做来源白名单与敏感路径检查
    （uploads/客户目录一律拒绝）。转换耗时/页数以 `[docstrange] <mpn> {metric}`
    转发到 stderr，A/B 实验须把它与下游 LLM 成本分开记账。
    """
    import subprocess
    out_dir = out_dir or DS_MD_DIR
    todo = [p for p in pdfs if p and not (out_dir / f"{p.stem}.md").exists()]
    if not todo:
        return 0
    if not DS_PY.exists():
        print(f"[docstrange] venv missing: {DS_PY}", file=sys.stderr)
        return 0
    out_dir.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, ICPDF_DS_CLOUD="1")     # 后端显式选择 = 确认上云
    for p in todo:                                 # 云端逐份调用（大 datasheet 可达数十分钟）
        md = out_dir / f"{p.stem}.md"
        try:
            r = subprocess.run([str(DS_PY), str(_DS_CLI), str(p), str(md)],
                               capture_output=True, text=True, timeout=3600, env=env)
            if r.returncode != 0:
                print(f"[docstrange] failed {p.name}: {r.stderr[-300:]}", file=sys.stderr)
            for line in (r.stderr or "").splitlines():
                if line.startswith("[ds-metric]"):
                    print(f"[docstrange] {p.stem} {line[len('[ds-metric]'):].strip()}",
                          file=sys.stderr)
        except Exception as e:                     # noqa: BLE001
            print(f"[docstrange] error {p.name}: {e}", file=sys.stderr)
    return len(todo)


def _extract_md_cached(path: Path, md_dir: Path, converter, max_chars: int) -> tuple[str, int, int, bool]:
    """markdown 类后端（opendataloader/docstrange）共用：读缓存（缺则单件补转）-> 分节选取；页数用 fitz 取。"""
    md = md_dir / f"{path.stem}.md"
    if not md.exists():
        try:
            converter([path])
        except Exception:                          # noqa: BLE001  venv/Java 缺失、转换失败
            return "", 0, 0, False
    try:
        fitz = _pyfitz()
        total = len(fitz.open(path))
    except Exception:                              # noqa: BLE001
        total = 0
    if not md.exists():
        return "", total, 0, False
    text, used = _md_pick(md.read_text(encoding="utf-8"), max_chars)
    return text, total, used, bool(text.strip())


def extract_pdf_text(path: Path, max_pages: int = MAX_PAGES, max_chars: int = MAX_CHARS):
    # 按件覆盖优先。放在这里而不是各调用点，是为了让 batch / pipeline / CLI
    # 四条路径都自动生效，不用逐个传参（见 MAX_PAGES_OVERRIDE 注释）。
    _key = mpn_from_name(path.name).upper()
    max_pages = MAX_PAGES_OVERRIDE.get(_key, max_pages)
    max_chars = MAX_CHARS_OVERRIDE.get(_key, max_chars)
    if PDF_BACKEND == "opendataloader":
        return _extract_md_cached(path, ODL_MD_DIR, odl_convert, max_chars)
    if PDF_BACKEND == "docstrange":
        return _extract_md_cached(path, DS_MD_DIR, ds_convert, max_chars)
    total, pages = _iter_pages(path)
    out, used, truncated = select_pages(pages, max_pages, max_chars)
    if truncated:
        out += "\n...[Truncated]"
    return out, total, used, bool(out.strip())


DS_MARKERS = ("electrical characteristics", "absolute maximum", "recommended operating",
              "switching characteristics", "dc characteristics")


def is_datasheet(text: str) -> bool:
    """没有参数表特征词的，多半是 User Guide / Quick Start，别浪费 LLM 调用。"""
    low = text.lower()
    return any(m in low for m in DS_MARKERS)


# ---------------------------------------------------------------- 模型调用
def chat(messages: list[dict], *, json_mode: bool = True, max_tokens: int | None = None,
         temperature: float = 0.1, model: str | None = None, base: str | None = None,
         key: str | None = None, enable_thinking: bool | None = None,
         route: dict | None = None) -> tuple[str, dict]:
    """调一次 chat/completions。

    不指定 base/key/model 时按 ROUTES 加权选路（L2 多 key/多网关并池），
    429 时优先换到没试过的路（配额池独立），全试过才原地退避；
    显式传 base/key/model 则固定单路（CLI、A/B 脚本）。
    返回的 usage 带 _route/_base/_model，调用方据此记录真实网关。
    """
    explicit = bool(base or key or model)
    tried: set[str] = set()
    last: Exception | None = None
    rate_hits = 0

    def _fixed_route() -> dict:
        return {"name": "explicit", "base": base or API_BASE, "key": key or API_KEY,
                "model": model or MODEL, "rpm": 0.0, "burst": 1,
                "tokens": 1.0, "last": time.monotonic(), "gate": 0.0}

    for attempt in range(1, RETRIES + 1):
        rt = route or (_fixed_route() if explicit else _pick_route(tried))
        tried.add(rt["name"])
        is_dashscope = "dashscope" in rt["base"]
        url = f"{rt['base']}/chat/completions"
        payload = {"model": rt["model"], "messages": messages,
                   "temperature": temperature, "max_tokens": max_tokens or MAX_TOKENS}
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        if is_dashscope:
            # 默认关思考（快路径）；repair 可显式开思考兜底（见 parse_one / pipeline.parse_pdf）
            payload["enable_thinking"] = ENABLE_THINKING if enable_thinking is None else enable_thinking
        headers = {"Authorization": f"Bearer {rt['key']}", "Content-Type": "application/json"}
        try:
            gate = _route_gate_wait(rt)
            if gate > 0:
                time.sleep(gate)
            _route_acquire(rt)
            r = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
            # 网关不认识的参数逐个降级重发（response_format / enable_thinking）
            for drop in ("response_format", "enable_thinking"):
                if r.status_code == 400 and drop in payload:
                    payload.pop(drop)
                    _route_acquire(rt)             # 降级重发也算一次调用，同样要过桶
                    r = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
            if r.status_code != 200:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
            data = r.json()
            u = data.get("usage", {}) or {}
            u.update(_route=rt["name"], _base=rt["base"], _model=rt["model"])
            return data["choices"][0]["message"]["content"], u
        except Exception as e:                     # noqa: BLE001 - 网关会偶发断连
            last = e
            if _is_rate_limit(e):
                # 限流不是故障，是「现在太快了」。退避要够长，并让所有线程一起等。
                rate_hits += 1
                if rate_hits > RATE_LIMIT_RETRIES:
                    raise
                wait = min(RATE_LIMIT_MAX_WAIT,
                           RATE_LIMIT_BACKOFF * (2 ** (rate_hits - 1))
                           + random.uniform(0, RATE_LIMIT_JITTER))
                _route_pause(rt, wait)
                # 还有没试过的路由 → 立刻换路（另一家配额独立，别陪它一起等）
                if not explicit and len(tried) < len(ROUTES):
                    continue
                time.sleep(wait)
                continue
            if attempt < RETRIES:
                time.sleep(2 ** attempt)
    raise last if last else RuntimeError("chat failed")


FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.M)


def parse_json_loose(content: str) -> dict:
    txt = FENCE.sub("", content).strip()
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", txt, re.S)
        if not m:
            raise
        return json.loads(m.group(0))


def _as_dict(v) -> dict:
    """模型把容器写成字符串时（`"specs": "..."`）不要崩，返回空 dict。

    实测 `ADS7815UE4` 崩在 `'str' object has no attribute 'get'`：
    `(doc.get("specs") or {}).get("electrical")` 在 `specs` 是 str 时直接抛异常，
    整件被判失败、白烧一次模型调用。校验层必须**能对坏输入给出错误**，
    而不是替坏输入崩溃（崩溃还会掩盖真正原因）。
    """
    return v if isinstance(v, dict) else {}


#: 只允许「数组里放对象」的容器：出现字符串/数字一律剔除（模型幻觉的典型形态）。
_DICT_ARRAY_KEYS = (("specs", "electrical"), ("specs", "absolute_max"), ("specs", "thermal"),
                    ("specs", "esd"), ("specs", "ac_performance"), ("pin_configuration",), ("ordering_info",),
                    ("alternatives",))
#: 只允许「数组里放字符串」的容器：出现对象/None 一律剔除。
_STR_ARRAY_KEYS = (("features",), ("applications",))
#: **必须是对象**的容器：被模型写成字符串时归一成 `{}`（否则下游 `.get()` 崩）。
_DICT_SCALAR_KEYS = (("basic_info",), ("metadata",), ("seo",), ("specs",),
                     ("specs", "package"), ("specs", "temperature"))


def sanitize_doc(doc: dict) -> dict:
    """剔除脏元素，返回 `{路径: 剔除条数}`；没有脏数据时返回空 dict。

    为什么在入口做、而不是在各消费端各加一层：`parse` → `table_audit` →
    `postprocess` → 渲染 四个阶段都要遍历这些数组，任何一处漏了 `isinstance`
    都会抛 `AttributeError: 'str' object has no attribute 'get'`。
    在**唯一入口**清洗一次，比在四处补防御更可靠，也不会漏阶段。
    """
    if not isinstance(doc, dict):
        # 根不是对象（模型回了 JSON 字符串/数组）：无法就地归一。
        # 真正的归一在 `parse_doc_clean()`；这里只保证**不替坏输入崩溃**。
        return {"__root__": 1}
    dropped: dict[str, int] = {}
    # `specs` 本身被写成字符串/布尔时，下游所有 `.get()` 都会崩；必须先归一成对象。
    if "specs" in doc and not isinstance(doc.get("specs"), dict):
        doc["specs"] = {}
        dropped["specs"] = 1
    # 标量冒充对象：`specs.package` / `specs.temperature` / `seo` / `metadata` 被模型
    # 写成字符串时，下游任意 `.get()` 都会抛 AttributeError（且报错点离真因很远）。
    for path in _DICT_SCALAR_KEYS:
        parent, key = doc, path[0]
        if len(path) == 2:
            parent, key = _as_dict(doc.get(path[0])), path[1]
            if not parent:
                continue
        val = parent.get(key) if isinstance(parent, dict) else None
        if val is not None and not isinstance(val, dict):
            parent[key] = {}
            dropped[".".join(path)] = 1
    for path in _DICT_ARRAY_KEYS:
        parent, key = doc, path[0]
        if len(path) == 2:
            parent, key = _as_dict(doc.get(path[0])), path[1]
        if not isinstance(parent, dict):
            continue
        if key not in parent:
            continue
        arr = parent.get(key)
        if arr is None:
            # `None` 不是脏容器：保持 None，让 validate 按"缺数组"报错（语义不变）。
            continue
        if not isinstance(arr, list):
            # **容器本身**被写成字符串/对象/数字：下游 `for e in arr` 要么迭代字符、
            # 要么迭代 dict 的 key，两种都会在 `e.get(...)` 处崩。
            # 这是 2026-11-02 压测 4 件 `'str'.get` 崩溃暴露的第二条边界
            # （第一条是 list 内元素，早已覆盖）。
            parent[key] = []
            dropped[".".join(path)] = 1
            continue
        keep = [e for e in arr if isinstance(e, dict)]
        if len(keep) != len(arr):
            parent[key] = keep
            dropped[".".join(path)] = len(arr) - len(keep)
    for path in _STR_ARRAY_KEYS:
        arr = doc.get(path[0])
        if not isinstance(arr, list):
            continue
        keep = [e for e in arr if isinstance(e, str)]
        if len(keep) != len(arr):
            doc[path[0]] = keep
            dropped[path[0]] = len(arr) - len(keep)
    # 隔离桶（`specs.onboard_device_specs` / `specs.unresolved_specs`）里的同类数组
    # 也要清：它们同样进审计与渲染，脏元素一样在 `e.get(...)` 处崩。
    specs_box = doc.get("specs")
    if isinstance(specs_box, dict):
        for box_key in ("onboard_device_specs", "unresolved_specs"):
            box = specs_box.get(box_key)
            if not isinstance(box, dict):
                continue
            for arr_key in ("electrical", "absolute_max", "ac_performance"):
                if arr_key not in box:
                    continue
                arr = box.get(arr_key)
                if arr is None:
                    continue
                tag = f"specs.{box_key}.{arr_key}"
                if not isinstance(arr, list):
                    box[arr_key] = []
                    dropped[tag] = 1
                    continue
                keep = [e for e in arr if isinstance(e, dict)]
                if len(keep) != len(arr):
                    box[arr_key] = keep
                    dropped[tag] = len(arr) - len(keep)
    return dropped


def parse_doc_clean(content: str) -> tuple[dict, dict]:
    """解析 + 清洗**一体化**：每一次 `parse_json_loose` 都必须走这里。

    为什么单开一个函数而不是在每个调用点补一行：`parse_one` 里有 **5 条**
    `parse_json_loose` 路径（首次 / 两次截断重试 / 校验修复重试 / 核心字段修复重试），
    只有首次那一条旁边写了 `sanitize_doc`。实测 20 件压测里 4 件
    `AttributeError: 'str' object has no attribute 'get'` —— 模型第二次输出的脏数组
    直接进了下游 `.get()`。把"解析"和"清洗"焊死在一起，重试路径就漏不掉了。

    根不是对象时返回 `{}`（可被 `validate` 判失败、走修复重试），
    **绝不**把 str/list 根留在下游。
    """
    try:
        doc = parse_json_loose(content)
    except ValueError as e:
        # `json.loads` 遇到 **>4300 位**的整数会抛 `ValueError`
        # （"Exceeds the limit (4300 digits) for integer string conversion"），
        # 它不是 `JSONDecodeError` 的子类，调用方的 `except json.JSONDecodeError`
        # 接不住 → 整件直接判死（实测 `DEM-DAI1804` 就是这个形态，2026-11-02 压测）。
        # 这里统一翻译成 JSONDecodeError，让既有的「截断/修复重试」链路接管。
        raise json.JSONDecodeError(str(e)[:200], content[:80], 0) from e
    stats = sanitize_doc(doc)
    if not isinstance(doc, dict):
        return {}, dict(stats or {}, __root__=1)
    return doc, stats


def pick_retry_doc(current: dict, candidate: dict) -> dict:
    """重试稿能不能替换原稿：必须是对象，且**至少有一条电气行（dict）**。

    为什么需要这道闸：`parse_doc_clean()` 对「非对象根」返回 `{}`（这本身是对的，
    总比把 str/list 留在下游崩掉强）。但**核心字段重试**那条路径会直接
    `doc = 重试稿` —— 模型偶尔在修复轮返回一个裸 JSON 字符串，
    于是空 `{}` 把一份已经可用的原稿顶掉，`empty_electrical` 判死。
    实测 `LM317 / LM358 / NE555 / CDC6CE040000ADLFR` 四件 ok→empty 就是这个形态
    （诊断日志里 `sanitized_retry={"__root__": 1}`）。

    所以：重试稿不可用 → **保留原稿**（拿少一条字段，也不能拿空卷）。
    """
    if isinstance(candidate, dict):
        sp = candidate.get("specs")
        if isinstance(sp, dict):
            elec = sp.get("electrical")
            if isinstance(elec, list) and any(isinstance(e, dict) for e in elec):
                return candidate
    return current


#: 正式桶：这些桶里的行可以计入「到底抽到没有」的判定。
#: `None` 代表 `specs.<container>` 本身。
FORMAL_BUCKETS = (None, "onboard_device_specs")
#: 隔离区：被 `pass_with_quarantine` 扣押的问题行，**只记账、绝不计分**。
#: 让它们参与阈值判定 = 用脏行替坏数据买门票（V11 修过同一个洞）。
QUARANTINE_BUCKETS = ("unresolved_specs",)
#: 逐行容器。三处口径（validate / fact_acceptance / json_to_txt）必须同名同序。
SPEC_CONTAINERS = ("electrical", "absolute_max", "ac_performance")


def spec_formal_counts(doc: dict) -> dict:
    """正式桶行数 + 隔离区扣押数。

    * 正式桶 = 主表 + `onboard_device_specs`（板卡件的电气参数住这里）；
    * `_withheld` = `unresolved_specs.*` + `unresolved_ac_rows` 的行数，
      **不并入任何计分项**，只为把「真空」和「抽到了但全被扣押」区分开。

    `parse_one`（线下）与 `parse_pdf`（链路）都调 `validate()`，而 `validate()`
    调本函数 —— 判据只有一份，不会出现「线下全绿、线上全红」。
    """
    sp = _as_dict(doc.get("specs"))
    out: dict[str, int] = {}
    for c in SPEC_CONTAINERS:
        n = 0
        main = sp.get(c)
        if isinstance(main, list):
            n += len(main)
        ob = sp.get("onboard_device_specs")
        if isinstance(ob, dict):
            arr = ob.get(c)
            if isinstance(arr, list):
                n += len(arr)
        out[c] = n
    w = 0
    for b in QUARANTINE_BUCKETS:
        box = sp.get(b)
        if isinstance(box, dict):
            for c in SPEC_CONTAINERS:
                arr = box.get(c)
                if isinstance(arr, list):
                    w += len(arr)
    acres = sp.get("unresolved_ac_rows")
    if isinstance(acres, list):
        w += len(acres)
    out["_withheld"] = w
    return out


#: 顶层状态语义（与 `rec["status"]` 一一对应）
STATUS_OK = "ok"
#: JSON 可解析、结构通过 validate，但**核心字段有硬错误**。
#: 存在的意义：`ok` 不能再被"盖个章就算了"冒充。装配入口只认 `ok`，
#: 这个状态一律不得当成正常结果消费。
STATUS_PARSED_CORE_FAIL = "parsed_core_fail"
#: 结构通过、电气不足但按 `ACCEPT_THIN` 放行的薄件（板卡/UG 无电气表）。
#: **不伪装成 ok**：它表示「解析层愿意收」，不表示「装配可用」。
#: 装配准入是否阻断，是另一道独立的闸（本轮不动）。
STATUS_THIN_ACCEPTED = "thin_accepted"


def _identity_is_board(doc: dict) -> bool:
    """身份落库后的结论是不是板卡。判据只认 `qc.scope_contract.BOARD_TYPES`。

    不在这里另抄一份 EVM/EVAL 正则：那会变成第三套板卡判据，模型改一次、
    正则改两次，三边迟早说不到一处。`IS.apply()` 在 gate 之前已经把
    `basic_info.identity` 写进 doc，直接读那一个字段。

    身份缺失（IS 抛错 / 老 JSON 没这字段）时返回 False，也就是「按芯片对待」。
    这是**故意的**：真值未知时保留旧行为，不拿一个没证据的猜测去拒件。
    """
    try:
        from qc.scope_contract import BOARD_TYPES       # noqa: PLC0415
        ident = str((doc.get("basic_info") or {}).get("identity") or "").strip()
        return ident in BOARD_TYPES
    except Exception:                                    # noqa: BLE001
        return False


def final_gate(doc: dict, core_errs: list[str],
               *, thin_allowed: bool = False) -> tuple[str, list[str]]:
    """落盘前的最终判定 —— **验收对象必须是即将落盘的那个对象**。

    为什么必须单独有这么一道闸：`doc` 在落盘前会被改很多次 ——
    确定性抽取原地覆盖、结构修复稿整份替换、核心修复稿再替换、
    兜底模型再替换、身份归一。此前只在「模型初稿」和「第一次修复稿」
    上跑过 validate，修复之后的确定性处理**没有再验**，于是出现过这样的件：
    `core_validation` 明确记着「datasheet_url 为空 / 引脚为空 / 电气为空」
    三条硬错，顶层 `status` 却是 `ok`（batch100 的 BQ24715EVM-115、
    ADS122U04EVM）。

    返回 `(status, errs)`：
      * `errs` 非空、且不属于可放行的薄件 → `("failed", errs)`；
      * `errs` 只剩「电气条数不足」、`thin_allowed`、且**不是板卡**
        → `("thin_accepted", [])`；
      * `errs` 空、`core_errs` 非空 → `("parsed_core_fail", [])`；
      * 两者皆空 → `("ok", [])`。

    板卡为什么被挡在 `thin_accepted` 之外（2026-11-04 收口）
    ------------------------------------------------------------------
    `ACCEPT_THIN` 的语义是「**芯片**但规格少」（连接器/晶振/无源件），判据却是
    文件名/正文里的 EVM/EVAL —— 于是唯一被它放行的恰恰是板卡。板卡的零电气零
    引脚是**诚实空**（板卡本来就没有器件级电气表），把它当成「低规格芯片」放进来，
    污染的是下游 `auto_qc` r3、渲染身份列与交付 manifest 的 identity/scope，
    不是数量。所以板卡不借这条通道：要么有真参数（走正常 validate），要么判
    failed 进隔离待重判。
    """
    errs = validate(doc)
    if errs:
        only_thin = all(e.startswith("specs.electrical only")
                        or e.startswith("withheld_in_quarantine") for e in errs)
        if thin_allowed and only_thin and not _identity_is_board(doc):
            # 薄件：电气表本来就没有，用引脚/特性兜底；状态如实标成 thin_accepted
            return STATUS_THIN_ACCEPTED, []
        return "failed", errs
    if core_errs:
        return STATUS_PARSED_CORE_FAIL, []
    return STATUS_OK, []


def validate(doc: dict) -> list[str]:
    errs = []
    if not isinstance(doc, dict):
        return ["not an object"]
    for k in REQUIRED:
        if k not in doc:
            errs.append(f"missing key: {k}")
    for k in ("basic_info", "specs"):
        if k in doc and not isinstance(doc.get(k), dict):
            errs.append(f"{k} 不是对象（模型返回了 {type(doc.get(k)).__name__}）")
    bi = _as_dict(doc.get("basic_info"))
    if not str(bi.get("mpn", "")).strip():
        errs.append("basic_info.mpn empty")
    if not str(bi.get("manufacturer", "")).strip():
        errs.append("basic_info.manufacturer empty")
    sp = _as_dict(doc.get("specs"))
    el = sp.get("electrical")
    if not isinstance(el, list):
        if el is not None:
            errs.append("specs.electrical 不是数组")
        el = []
    # 口径：**正式桶计分，隔离区只记账**。
    #
    # 板卡件（EVM / PDK / 用户指南）的电气参数由模型放进 `onboard_device_specs`，
    # 主桶 `specs.electrical` 为空是**正常形态**，不是「一条都没抽到」；
    # 而 `unresolved_specs` / `unresolved_ac_rows` 是被 `pass_with_quarantine`
    # 扣押的问题行（如 AC 表 `max="dB"`、SFDR 被 withhol​d），**绝不计分** ——
    # 把扣押行加进「抽到没有」的判定，等于让脏行替坏数据买门票。
    # 全系统只有本函数原先不认正式桶：`qc/fact_acceptance.BUCKETS`、
    # `qc/fact_status_sync.BUCKETS`、`app/services/seo_image` 都认。
    #
    # 错误串前缀保持 `specs.electrical only` 不变：`app/services/pipeline.py`
    # 按这个前缀把它归入「软错误」再决定是否走 ACCEPT_THIN 放行。
    n_spec = spec_formal_counts(doc)
    if n_spec["electrical"] < 3:
        errs.append(f"specs.electrical only {n_spec['electrical']} items (<3)")
        if n_spec["_withheld"]:
            # 区分「真空」与「全被扣押」：后者不是模型没抽到，是抽到了但不合格。
            errs.append(f"withheld_in_quarantine={n_spec['_withheld']} (not counted)")
    # 排障纵深：即便某个调用方绕过 `sanitize_doc`，也要在验证层把「数组里混脏元素」
    # 判成错误（而不是让它在下游 `e.get(...)` 处崩成 AttributeError）。
    # 注意：**类型校验只在这里做**（`sanitize_doc` 的职责），`check_core` 只管值。
    for key in ("electrical", "absolute_max", "ac_performance"):
        arr = sp.get(key)
        if arr is None or not isinstance(arr, list):
            continue
        bad = sum(1 for e in arr if not isinstance(e, dict))
        if bad:
            errs.append(f"specs.{key} 含 {bad} 个非对象元素")
    return errs


# ---------------------------------------------------------------- 单文件处理
def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for ch in iter(lambda: f.read(1 << 20), b""):
            h.update(ch)
    return h.hexdigest()


# 溯源链（`datasheet_url`）的口径只有一处：`qc/source_url.py`。
# 解析管线与装配管线共用，避免「解析时填对、装配时冲掉」。
from qc import source_url as SU                                  # noqa: E402

_doc_key = SU.doc_key


def load_url_map() -> dict[str, str]:
    return SU.load_url_map(MANIFEST)


def resolve_datasheet_url(doc: dict, pdf_name: str, url_map: dict[str, str],
                          pdf_text: str = "") -> tuple[str, str]:
    return SU.resolve(doc, pdf_name, url_map, pdf_text)


def mpn_from_name(name: str) -> str:
    return name.split("__")[0].replace("_", "/") if "__" in name else name.replace(".pdf", "")


def parse_one(pdf: Path, url_map: dict[str, str]) -> dict:
    t0 = time.time()
    derived = mpn_from_name(pdf.name)
    req = requested_mpn_for(pdf, derived)      # 交付订货号；空则退回文件名派生料号
    mpn = req or derived
    if req and req != derived:
        print(f"  [料号] {pdf.name} → 派生 {derived!r}，按交付订货号 {req!r} 落库")
    rec = {"mpn": mpn, "pdf": pdf.name, "status": "failed", "error": "", "confidence": 0.0,
           "electrical": 0, "pins": 0, "out": "", "secs": 0.0, "pages": "", "usage": {}}
    try:
        text, total, used, has_text = extract_pdf_text(pdf)
        rec["pages"] = f"{used}/{total}"
        # 选页留痕（1102-V3.4）：把真实选中的页号落盘，取证脚本才能判
        # 「电气页在不在预算内」，否则只能报 need_rerun_with_dump（实测踩过）。
        rec["selected_pages"] = [int(n) for n in re.findall(r"--- Page (\d+) ---", text)]
        if not has_text:
            rec["error"] = "PDF_UNREADABLE: 无文本层（需 OCR）"
            return rec
        if not is_datasheet(text):
            rec["status"] = "skipped"
            rec["error"] = "NOT_A_DATASHEET: 无参数表特征词（User Guide / Quick Start），跳过 LLM"
            return rec
        # 文本层乱码 → 直接判 OCR 需求，不烧 Token（乱码喂给模型只会产出幻觉）。
        if text_is_garbled(text):
            rec["status"] = "failed"
            rec["error"] = ("ERR_OCR_REQUIRED: 文本层乱码（字母数字占比过低/技术词稀少），"
                            "跳过 LLM，待 OCR 或视觉通道")
            return rec
        # 板卡预路由（1102-V3.3）：评估板/套件且正文无芯片级电气表 → 不进 LLM。
        # 不是「失败」，是「本来就没有」，单独记 board_expected_empty，别污染 empty 率。
        if board_expected_empty(pdf.name, text) or board_expected_empty(mpn, text):
            rec["status"] = "board_expected_empty"
            rec["error"] = ("BOARD_PROFILE: 评估板/套件手册未见芯片级电气表，"
                            "跳过重型抽取（不计入 empty_electrical 失败率）")
            return rec
        pdf_hash = sha256(pdf)

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": USER_TMPL.format(
                mpn=mpn, fname=pdf.name, pages_used=used, pages_total=total, text=text)},
        ]
        # temperature=0：采样稳定性第一道闸。qwen-flash 在 0.1 下同输入两次运行
        # 结果不同（electrical 19 vs 23），降到 0 后仍不能保证完全一致 ——
        # 所以真正兜底的是 qc/deterministic_extract.py，不是这个参数。
        content, usage = chat(messages, temperature=0.0)
        rec["usage"] = usage
        try:
            doc, clean_stats = parse_doc_clean(content)
        except json.JSONDecodeError:
            # 达到 max_tokens 时 JSON 会在中途断掉，解析失败不等于文档不能解析；
            # 加额度重来一次（features 压短给正文留空间），仍失败才判死。
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "上次输出在 JSON 中途被 max_tokens 截断。请重新输出完整 "
                                            "JSON（只输出 JSON，保持全部 key）；features 每条控制在 120 字以内。"},
            ]
            content, usage2 = chat(messages, temperature=0.0, max_tokens=RETRY_MAX_TOKENS)
            rec["usage"] = usage2
            try:
                doc, clean_stats = parse_doc_clean(content)
            except json.JSONDecodeError:
                # 1102-V3.2：第二次**仍被截断**时再给一次修复机会。
                # 旧实现在这里直接让异常冒到外层 → 只报 `invalid_json`，
                # 长文档（ADC12QJ1600-SP 151 页）因此白烧两次调用就判死。
                # 第三次把输出预算全部让给 electrical（features 压到 60 字）。
                messages += [
                    {"role": "assistant", "content": content[:6000]},
                    {"role": "user", "content": "仍被 max_tokens 截断。请**只输出 JSON**，"
                                                "数组元素数量与原文一致；features 每条 ≤ 60 字，"
                                                "优先完整输出 specs.electrical。"},
                ]
                content, usage3 = chat(messages, temperature=0.0,
                                       max_tokens=RETRY_MAX_TOKENS)
                rec["usage"] = usage3
                try:
                    doc, clean_stats = parse_doc_clean(content)
                except json.JSONDecodeError as e:
                    rec["error"] = f"PARSE_FAILED: invalid_json_after_2_retries ({e})"
                    rec["raw"] = content[:2000]
                    return rec
        # 1102-V3.3 全局防御性清洗：模型会把纯文本塞进对象数组
        # （`specs.electrical: ["Note 1: ...", {...}]`），下游任何 `e.get(...)`
        # 都会抛 `AttributeError: 'str' object has no attribute 'get'`，
        # 而且一个脏元素就能让整件判死。入口统一剔除并留痕，别让脏数据流到下一阶段。
        #
        # 1102-V3.4（2026-11-02 第三轮）：清洗已内置在 `parse_doc_clean()` 里 ——
        # 上面**每一次** `parse_json_loose` 都被替换成它，重试路径不再漏清洗
        # （20 件压测 4 件 `'str'.get` 崩溃的真因就是"重试后没再 sanitize"）。
        if clean_stats:
            rec["sanitized"] = clean_stats
            print(f"  [清洗] {pdf.name}: " + ", ".join(f"{k}-{v}" for k, v in clean_stats.items()))
        errs = validate(doc)
        if errs:                                  # 一次修复重试
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "上面的 JSON 有问题：" + "；".join(errs) +
                 "。请修正并重新输出完整 JSON（只输出 JSON，保持全部 key）。"},
            ]
            content, usage2 = chat(messages, temperature=0.0, enable_thinking=True,
                                   max_tokens=RETRY_MAX_TOKENS)
            rec["usage"] = usage2
            doc, clean_stats_retry = parse_doc_clean(content)
            if clean_stats_retry:
                rec["sanitized_retry"] = clean_stats_retry
            errs = validate(doc)
            if errs:
                rec["error"] = "PARSE_FAILED: " + "; ".join(errs)
                rec["raw"] = content[:2000]
                return rec

        # ---- 确定性抽取：pins / thermal / esd / VCMI / VID 不经模型 ----
        # 见 qc/deterministic_extract.py 的模块说明：qwen-flash 同一份 prompt、
        # 同一份 PDF 两次运行结果不同（pins 64 vs 144、ESD `+2000` vs `±2000`、
        # VCMI 全缺 vs 三条齐全）。客户会用 Codex 复跑，**不可复现比算错更致命**。
        # 这四类结构确定（表格边界清楚、列语义明确），一律改代码抽取；
        # 模型只负责电气表里真正难结构化的行。
        from qc import deterministic_extract as DE              # noqa: PLC0415
        det_rep: dict = {}
        try:
            import pymupdf as _fitz                             # noqa: PLC0415
            _fd = _fitz.open(str(pdf))
            try:
                det_rep = DE.apply_deterministic(doc, _fd)
            finally:
                _fd.close()
        except ImportError:
            det_rep = {"skipped": "pymupdf 不可用，确定性抽取未执行"}
        except Exception as e:                                  # noqa: BLE001
            det_rep = {"error": f"{type(e).__name__}: {e}"[:200]}

        # 核心字段校验：通用结构 + 型号级验收点。
        # 型号级那部分必须分开（`check_acceptance`）：把 ADC12DJ5200SE 的
        # `0 to 0.55` / `0.4 to 2.0` 塞进通用校验会让别的型号全被误判。
        core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)
        if core_errs:
            messages += [
                {"role": "assistant", "content": content[:6000]},
                {"role": "user", "content": "核心字段不达标：" + "；".join(core_errs) +
                 "。请修正并重新输出完整 JSON（只输出 JSON，保持全部 key）。"},
            ]
            content, usage2 = chat(messages, temperature=0.0, enable_thinking=True,
                                   max_tokens=RETRY_MAX_TOKENS)
            rec["usage"] = usage2
            doc_new, clean_stats_retry2 = parse_doc_clean(content)
            if clean_stats_retry2:
                rec["sanitized_retry"] = clean_stats_retry2
            kept_old = pick_retry_doc(doc, doc_new) is doc
            if kept_old:
                # 重试稿是空卷/裸字符串：**不许顶掉原稿**（否则 ok→empty，实测 4 件）。
                rec["retry_doc_rejected"] = True
            else:
                doc = doc_new
            try:
                _fd = _fitz.open(str(pdf))
                try:
                    det_rep = DE.apply_deterministic(doc, _fd)
                finally:
                    _fd.close()
            except Exception:                                   # noqa: BLE001
                pass
            core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)

        # metadata 由流水线补齐（不信任模型对 hash/时间的判断）
        # 模型可能把 metadata / basic_info 输出成**字符串**（`"..."`）。`setdefault` 只会
        # 原样返回那个 str，随后的 `.update()` / `.get()` 就抛 AttributeError ——
        # 100 件灰度里 ADC08B200EB、551013276-001_NOPB 等件正是这么死的。
        # 一律用 `_as_dict` 归一（同上的 `specs` 处理）。
        meta = doc["metadata"] = _as_dict(doc.get("metadata"))
        try:
            conf = float(meta.get("confidence") or 0)
        except (TypeError, ValueError):
            conf = 0.0
        meta.update({
            "pdf_hash": pdf_hash,
            "parse_timestamp": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
            "model_version": MODEL,
            "prompt_version": PROMPT_VERSION,
            "confidence": round(max(0.0, min(1.0, conf)), 2),
            # 这条路径以前不写 requested_mpn，导致身份映射的 A 级判据（requested_mpn）
            # 完全不可用，只能退回 B 级 basic_info.mpn / C 级 pdf_hash。
            # app/services/pipeline.py:167 与 batch.py:255 是写的，这里补齐。
            "requested_mpn": mpn,
        })
        # 确定性抽取的改动摘要 + 核心字段校验结果，都写进 metadata 供审计。
        meta["deterministic_extract"] = det_rep
        meta["selected_pages"] = rec.get("selected_pages") or []
        # 1102-V2 P1：有 AC 隔离行时不能只写 "pass" —— 那会被下游读成
        # 「原厂没有 AC 参数」。口径见 `qc/core_validation.py`。
        from qc import core_validation as _CV                      # noqa: PLC0415
        meta["core_validation"] = _CV.stamp(meta, doc, core_errs or _CV.PASS)
        bi = doc["basic_info"] = _as_dict(doc.get("basic_info"))
        if not bi.get("datasheet_url"):
            _url, _src = resolve_datasheet_url(doc, pdf.name, url_map, text)
            bi["datasheet_url"] = _url
            # 来源标签落盘：客户一眼能看出这个链接是抓取时记下的原始出处，
            # 还是按 TI 手册规则拼的，还是压根没定出来。
            bi["datasheet_url_source"] = _src

        # 身份落库 + 板卡口径归一。不写这一步，下游三个渲染器都只能按「裸芯片」
        # 出页面（json_to_txt / symbol_svg 的 is_board 读的就是 basic_info.identity）：
        # 评估板共用板上器件 datasheet 时，会被渲染成「48 脚 WQFN 封装的芯片」。
        try:
            from qc import identity_scope as IS                      # noqa: PLC0415
            rec["identity"] = IS.apply(doc, mpn, pdf_text=text, pdf_path=pdf)
        except Exception as e:                                       # noqa: BLE001
            meta["identity_scope_error"] = f"{type(e).__name__}: {e}"[:200]

        # BGA 球位：`repair_bga_pins` 是唯一权威 —— `apply_deterministic` 对 BGA
        # 主动让路（见 qc/deterministic_extract.apply_deterministic 的注释）。
        #
        # 必须排在 `identity_scope` **之后**：校验的第一条就是「主体是不是已核验
        # 的器件」（identity ∈ chip/device），身份没落库时任何 BGA 都会判
        # `subject_is_not_verified_device`，球位被清零。
        # V4 就是漏了这一步：JSON 里 144 球（无溯源）与符号页「待核」并存，
        # 同一包内两处对同一事实给出相反结论（Reviewer V4 新-2）。
        try:
            from qc import pin_repair as PR                          # noqa: PLC0415
            pin_rep = PR.repair_bga_pins(doc, pdf)
            rec["pin_repair"] = {"action": pin_rep.get("action"),
                                 "status": pin_rep.get("status"),
                                 "pins": pin_rep.get("pins"),
                                 "reasons": pin_rep.get("reasons")}
        except Exception as e:                                       # noqa: BLE001
            doc.setdefault("metadata", {})["pin_repair_error"] = (
                f"{type(e).__name__}: {e}"[:200])

        OUT_DIR.mkdir(parents=True, exist_ok=True)
        out = OUT_DIR / f"{mpn.replace('/', '_')}_{pdf_hash[:8]}.json"
        if NO_OVERWRITE and out.exists():
            rec["status"] = "skipped"
            rec["error"] = f"EXISTS: {out.name} 已存在（--no-overwrite）"
            return rec
        # 核心字段指纹：必须在**所有改写之后**算（identity_scope / pin_repair
        # 都会动 pin_configuration），否则指纹描述的不是落盘内容。
        # 客户拿 Codex 复跑时，直接比这四个 sha256 就能自证一致，
        # 不需要装本仓库的 qc/determinism_check.py。
        # 句柄必须重新取：`IS.apply()` 会把 `doc["metadata"]` 换成新 dict，
        # 上面那个 `meta` 变量已经指向旧对象，往里写等于写进黑洞（实测踩过：
        # core_validation 在、core_sha256 不见）。
        # 模型可能把 metadata / basic_info 输出成**字符串**（`"..."`）。`setdefault` 只会
        # 原样返回那个 str，随后的 `.update()` / `.get()` 就抛 AttributeError ——
        # 100 件灰度里 ADC08B200EB、551013276-001_NOPB 等件正是这么死的。
        # 一律用 `_as_dict` 归一（同上的 `specs` 处理）。
        meta = doc["metadata"] = _as_dict(doc.get("metadata"))
        try:
            from qc import deterministic_extract as _DE             # noqa: PLC0415
            meta["core_sha256"] = _DE.core_digest(doc)
        except Exception as e:                                       # noqa: BLE001
            meta["core_sha256_error"] = f"{type(e).__name__}: {e}"[:200]
        # 空电气拒收（1102-V3.2）：模型没抽出电气表时**不落盘**，让上层保留旧 JSON。
        # 实测 `ADC12QJ1600ALREP`：deterministic 抽到 thermal=3/esd=2，但电气整表为空；
        # 这种「半成品」写盘后会覆盖掉原本 12 行的旧数据，是比解析失败更坏的形态。
        #
        # 1102-V3.3 薄件豁免：`ICPDF_ACCEPT_THIN=1` 且文档是评估板/User Guide 时，
        # 「本来就没有电气表」不该判失败——保留 features/ordering/基础信息落盘即可
        # （实测 `ADC08B200EB` 是 EB 评估板，交白卷是诚实的）。
        empty_elec = not (_as_dict(doc.get("specs")).get("electrical") or [])
        # 兜底路由（1102-V3.4）：上下文**确有电气表头**却仍空 → 升级到 plus 重抽 **1 次**。
        # 成本控制：只在有证据时触发（`context_has_elec_table`），且不做重试循环；
        # 重抽仍空则维持 PARSE_FAILED，旧 JSON 不被覆盖（守卫兜底）。
        if empty_elec and context_has_elec_table(text) and FALLBACK_MODEL:
            print(f"  [兜底] {pdf.name}: 电气表在上下文仍空 → {FALLBACK_MODEL} 重抽 1 次")
            usage_fb: dict = {}
            try:
                content_fb, usage_fb = chat(messages, temperature=0.0,
                                            model=FALLBACK_MODEL,
                                            max_tokens=RETRY_MAX_TOKENS)
                doc_fb, _clean_fb = parse_doc_clean(content_fb)
            except Exception as e:                 # noqa: BLE001  兜底失败不影响主判定
                print(f"  [兜底] {FALLBACK_MODEL} 调用/解析失败: {type(e).__name__}: {e}")
                doc_fb = None
            if usage_fb:
                print(f"  [兜底] usage={json.dumps(usage_fb, ensure_ascii=False)[:300]}")
            if isinstance(doc_fb, dict) and doc_fb:
                if _as_dict(doc_fb.get("specs")).get("electrical"):
                    doc = doc_fb
                    meta = doc["metadata"] = _as_dict(doc.get("metadata"))
                    meta["fallback"] = {"model": FALLBACK_MODEL,
                                        "reason": "empty_elec_with_context",
                                        "usage": usage_fb}
                    rec["usage_fb"] = usage_fb
                    rec["fallback_model"] = FALLBACK_MODEL
                    empty_elec = False
                    print(f"  [兜底] {FALLBACK_MODEL} 成功：elec="
                          f"{len(_as_dict(doc.get('specs')).get('electrical') or [])}")
        if empty_elec and not accept_thin(pdf.name, text):
            rec["error"] = ("PARSE_FAILED: empty_electrical"
                            "（模型未产出电气表，拒绝落盘以保留旧 JSON）")
            rec["raw"] = json.dumps(doc, ensure_ascii=False)[:2000]
            return rec
        if empty_elec:
            meta["accept_thin"] = True            # 薄件：板卡/UG 无电气表，允许落盘
            rec["thin"] = "board_or_ug_no_elec"
        # ---- 落盘前的最终复验（唯一 choke point）----------------------
        # 到这里 doc 至少被改过两次：确定性抽取原地覆盖、修复稿整份替换、
        # 兜底模型替换。任何改动之后都必须重验，所以 core_errs 在**这里**
        # 重算一次，而不是沿用前面算过的值。
        core_errs = DE.check_core(doc, det_rep) + DE.check_acceptance(doc, mpn)
        # 薄件放行沿用本入口既有规则（`accept_thin` / 前面 empty_elec 分支的标记），
        # 不新造判据；判成薄件时状态是 thin_accepted，不伪装成 ok。
        thin_allowed = bool(meta.get("accept_thin")) or bool(rec.get("thin")) \
            or accept_thin(pdf.name, text)
        status_final, errs_final = final_gate(doc, core_errs, thin_allowed=thin_allowed)
        if status_final == "failed":
            rec["error"] = "PARSE_FAILED: " + "; ".join(errs_final)
            rec["raw"] = json.dumps(doc, ensure_ascii=False)[:2000]
            return rec

        # 把**验收结论**写进 JSON 本身，而不是只留在 rec 里。
        # 理由：rec 是这一次调用的返回，JSON 才是常年躺在 data/parsed 的物证。
        # 下游（render / 装配 / 重试）读的是 JSON，若看不到这一件当初凭什么被
        # 判过，就只能靠「文件存在」猜 —— 那就是这次事故的起点。
        meta["accept_status"] = status_final
        if core_errs:
            meta["accept_core_errs"] = list(core_errs)

        out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")

        rec.update(status=status_final, out=str(out.relative_to(ROOT)),
                   confidence=meta["confidence"],
                   electrical=len((_as_dict(doc.get("specs")).get("electrical")) or []),
                   pins=len(doc.get("pin_configuration") or []))
        if status_final == STATUS_PARSED_CORE_FAIL:
            # 留证据：这一件为什么不是 ok。装配入口只认 ok，不看这个列表，
            # 但排查时必须能一眼看出是「结构性通过、核心不通过」。
            rec["core_errs"] = list(core_errs)
    except json.JSONDecodeError as e:
        rec["error"] = f"PARSE_FAILED: invalid_json ({e})"
    except Exception as e:                        # noqa: BLE001
        if os.getenv("ICPDF_TRACE", "0").strip() == "1":
            import traceback
            traceback.print_exc()
        rec["error"] = f"{type(e).__name__}: {e}"[:300]
    finally:
        rec["secs"] = round(time.time() - t0, 1)
    return rec


# ---------------------------------------------------------------- 备用路线：百炼 Batch
def emit_batch(pdfs: list[Path], out_path: Path) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        for i, pdf in enumerate(pdfs):
            text, total, used, ok = extract_pdf_text(pdf)
            if not ok:
                continue
            body = {
                "custom_id": f"req-{i}-{pdf.stem}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": DASHSCOPE_MODEL,
                    "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                                 {"role": "user", "content": USER_TMPL.format(
                                     mpn=mpn_from_name(pdf.name), fname=pdf.name,
                                     pages_used=used, pages_total=total, text=text)}],
                    "response_format": {"type": "json_object"},
                    "temperature": 0.1,
                    "max_tokens": MAX_TOKENS,
                    "enable_thinking": ENABLE_THINKING,
                },
            }
            f.write(json.dumps(body, ensure_ascii=False) + "\n")
    print(f"batch jsonl -> {out_path}  ({len(pdfs)} reqs)  model={DASHSCOPE_MODEL}")


# ---------------------------------------------------------------- main
def write_summary(rows: list[dict]) -> Path:
    """按 pdf 文件名合并（多次运行不清空历史结果）。"""
    csv_path = OUT_DIR / "_summary.csv"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    merged: dict[str, dict] = {}
    if csv_path.exists():
        with open(csv_path, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                merged[r.get("pdf", "")] = r
    for r in rows:
        merged[r["pdf"]] = {k: r.get(k, "") for k in FIELDS}
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for k in sorted(merged):
            w.writerow(merged[k])
    return csv_path


FIELDS = ["mpn", "pdf", "status", "error", "confidence", "electrical", "pins",
          "pages", "secs", "out"]


def rebuild_summary() -> list[dict]:
    """从已生成的 JSON 反推汇总行（用于补写历史记录）。"""
    hash2pdf = {}
    if MANIFEST.exists():
        with open(MANIFEST, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                hash2pdf[r["sha256"][:8]] = Path(r["local_path"]).name
    rows = []
    for p in sorted(OUT_DIR.glob("*.json")):
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except Exception:                          # noqa: BLE001
            continue
        h8 = p.stem.rsplit("_", 1)[-1]
        rows.append({
            "mpn": mpn_from_name(hash2pdf.get(h8, p.stem)),
            "pdf": hash2pdf.get(h8, p.name),
            "status": "ok", "error": "", 
            "confidence": doc.get("metadata", {}).get("confidence", ""),
            "electrical": len((doc.get("specs") or {}).get("electrical") or []),
            "pins": len(doc.get("pin_configuration") or []),
            "pages": "", "secs": "", "out": str(p.relative_to(ROOT)),
        })
    return rows


def main() -> None:
    global PDF_BACKEND, OUT_DIR
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(PDF_DIR))
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--emit-batch", default="", help="生成百炼 Batch JSONL（备用路线）")
    ap.add_argument("--only", default="", help="只处理文件名包含该子串的 PDF（逗号分隔=任一命中）")
    ap.add_argument("--backend", choices=["agnes", "dashscope"], default="dashscope",
                    help="模型网关：dashscope（阿里云百炼，默认）或 agnes")
    ap.add_argument("--pdf-backend", choices=["pymupdf", "pypdf", "opendataloader", "docstrange"], default=PDF_BACKEND,
                    help=f"PDF 文本抽取后端（默认 {PDF_BACKEND}；opendataloader 需装包+Java 11+，docstrange 需 dsenv venv 云端模式）")
    ap.add_argument("--out-dir", default="", help="JSON 输出目录（默认 data/parsed；A/B 对比可指定独立目录）")
    ap.add_argument("--requested-mpn", default="",
                    help="请求料号覆盖表：KEY=MPN,KEY=MPN。KEY 可写 PDF 文件名或文件名派生料号。"
                         "解「同族手册共用一份 PDF 导致料号只能是文件名」的问题")
    ap.add_argument("--requested-mpn-file", default="", help="同上，CSV 两列 pdf,mpn（带表头则自动跳过）")
    ap.add_argument("--no-overwrite", action="store_true",
                    help="目标 JSON 已存在则跳过，不覆盖（重解析防误伤生产时建议开着）")
    ap.add_argument("--rebuild-summary", action="store_true", help="从已生成 JSON 补写汇总表")
    a = ap.parse_args()

    PDF_BACKEND = a.pdf_backend
    if a.out_dir:
        OUT_DIR = Path(a.out_dir).resolve()   # 必须绝对路径：parse_one 里要 relative_to(ROOT)
    if a.requested_mpn or a.requested_mpn_file:
        load_requested_mpn(a.requested_mpn, a.requested_mpn_file)
    if a.no_overwrite:
        global NO_OVERWRITE
        NO_OVERWRITE = True

    if a.rebuild_summary:
        p = write_summary(rebuild_summary())
        print(f"summary rebuilt -> {p}")
        return

    pdfs = sorted(Path(a.dir).glob("*.pdf"))
    if a.only:
        keys = [k.strip().lower() for k in a.only.split(",") if k.strip()]
        pdfs = [p for p in pdfs if any(k in p.name.lower() for k in keys)]
    if a.limit:
        pdfs = pdfs[:a.limit]
    if not pdfs:
        sys.exit(f"no pdf in {a.dir}")
    if a.emit_batch:
        emit_batch(pdfs, Path(a.emit_batch))
        return
    global API_BASE, API_KEY, MODEL
    if a.backend == "dashscope":
        if not DASHSCOPE_KEY:
            sys.exit("DASHSCOPE_API_KEY 未配置（写到 .env.local）")
        API_BASE, API_KEY, MODEL = DASHSCOPE_BASE, DASHSCOPE_KEY, DASHSCOPE_MODEL
    else:
        if not AGNES_KEY:
            sys.exit("AGNES_API_KEY 未配置（写到 .env.local）")
        API_BASE, API_KEY, MODEL = AGNES_BASE, AGNES_KEY, AGNES_MODEL
    if not API_KEY:
        sys.exit("API key 未配置（写到 .env.local）")
    use_single_route(a.backend)                 # 显式选路，忽略 ICPDF_LLM_ROUTES

    if PDF_BACKEND == "opendataloader":
        n = odl_convert(pdfs)                   # 一次 JVM 批量预转，线程内只读缓存
        print(f"odl pre-convert: {n} new markdown -> {ODL_MD_DIR}")
    elif PDF_BACKEND == "docstrange":
        n = ds_convert(pdfs)                    # 云端逐份预转，线程内只读缓存
        print(f"docstrange pre-convert: {n} new markdown -> {DS_MD_DIR}")

    print(f"model={MODEL} base={API_BASE} files={len(pdfs)} workers={a.workers} pdf_backend={PDF_BACKEND}")
    url_map = load_url_map()
    rows = []
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = {ex.submit(parse_one, p, url_map): p for p in pdfs}
        for f in as_completed(futs):
            # 单件异常绝不能带走整批（1102-V3.3）：`f.result()` 会把 worker 内
            # **未被 parse_one 捕获**的异常重新抛到主线程，旧的写法直接让 20 件的
            # 批量在第一个崩溃件上整体退出（实测 _gray20_run 只出了 1 条 ERR 就停）。
            p = futs[f]
            try:
                r = f.result()
            except Exception as e:                 # noqa: BLE001
                if os.getenv("ICPDF_TRACE", "0").strip() == "1":
                    import traceback
                    traceback.print_exc()
                r = {"mpn": mpn_from_name(p.name), "pdf": p.name, "status": "failed",
                     "error": f"WORKER_CRASH: {type(e).__name__}: {e}"[:300],
                     "confidence": 0.0, "electrical": 0, "pins": 0, "out": "",
                     "secs": 0.0, "pages": "", "usage": {}}
            rows.append(r)
            mark = {"ok": "OK  ", "skipped": "SKIP"}.get(r["status"], "ERR ")
            print(f"[{mark}] {r['mpn']:<24} {r['secs']:>6.1f}s  conf={r['confidence']:<4} "
                  f"elec={r['electrical']:<3} pins={r['pins']:<3} "
                  f"{(r['error'] or r['out'])[:70]}")

    rows.sort(key=lambda x: x["mpn"])
    csv_path = write_summary(rows)
    ok = sum(1 for r in rows if r["status"] == "ok")
    print(f"\nsuccess {ok}/{len(rows)}  summary -> {csv_path}")


if __name__ == "__main__":
    main()
