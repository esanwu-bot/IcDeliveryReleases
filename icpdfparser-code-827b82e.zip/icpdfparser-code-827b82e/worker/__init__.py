"""Celery worker 包。"""
