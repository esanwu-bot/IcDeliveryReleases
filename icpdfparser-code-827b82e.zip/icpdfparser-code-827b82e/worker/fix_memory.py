"""修复经验库：读写 docs/qc/型号修复日志_handoff.md。

两个用途：
  1. **修复前读**：把同型号 / 同类 kind 的历史经验抽出来，注入 LLM 修复的
     上下文——让修复不是从零开始猜，而是「上次这类问题是怎么定位、怎么修的、
     哪些坑踩过」；
  2. **每轮修复后追加**：把本轮做了什么、改了什么、卡在哪、结论是什么写回去，
     形成可复用的经验（append-only，只在末尾加 section，不重写既有内容）。

为什么经验要进文件而不是进 prompt 常量：这份 md 是人和 agent 共同的修复台账
（AGENT.md §1 纪律：修复完成而未写入本文件视为未交付），自动修复读它 = 和历史
对齐口径；写它 = 让下一次（可能还是人工）能接上。
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from app import config

LOG_REL = Path("docs") / "qc" / "型号修复日志_handoff.md"

# kind → 检索关键词：经验段落里出现这些词就算相关（用于跨型号借经验）
KIND_HINTS = {
    "identity_board_unresolved": ["评估板", "EVM", "EVK", "判板", "identity", "板卡"],
    "board_identity_missing": ["评估板", "EVM", "EVK", "判板", "identity"],
    "board_package_mismatch": ["评估板", "封装", "package", "WQFN", "判板"],
    "mpn_rewritten": ["MPN", "型号被替换", "板载器件", "device_mpn"],
    "double_escape_multi": ["转义", "escape", "&amp;", "esc 执行两遍", "双层"],
    "escape_entity_in_json": ["转义", "escape", "&amp;", "JSON 残留"],
    "unit_duplicated": ["单位重复", "mA mA", "unit"],
    "electrical_field_missing": ["条件列", "condition", "表格", "electrical"],
    "unit_dimension": ["单位", "unit", "量纲"],
    "electrical_condition_leak": ["条件列", "condition", "@VIN", "表格条件"],
    "row_mispair": ["错行", "行序", "表格", "pin9"],
    "pin_mismatch": ["引脚", "pin_configuration", "引脚映射", "乱序", "复合名"],
    "pin_pair_broken": ["差分对", "pin_pair", "错位", "物理相邻", "脚号"],
    "i18n_english_residue": ["多语言", "multi_language", "未翻译", "ja", "es", "de"],
    "hero_overview_duplicate": ["Hero", "Overview", "重复", "首句"],
    "features_boilerplate": ["Benefits", "凑数", "重复文案"],
    "faq_boilerplate": ["FAQ", "套话", "凑数"],
    "package_mismatch": ["封装", "package", "WLP", "SOIC"],
}


def log_path(root: Path | None = None) -> Path:
    return Path(root or config.ROOT) / LOG_REL


# ---------------------------------------------------------------- 硬规则（常驻）
# 与 `load_experience()` 的区别：那些是「按 kind 检索到的历史段落」，可能检索不到；
# 这些是**每次都注入**的不变量——来自 DS80PCI402EVK/NOPB 修复事故（第一版审核不通过：
# 引脚表按极性分组重排、断言自证、symbols 仍是芯片封装图）。它们不是建议，是闸门：
# 违反其中任何一条的改动都不允许落盘。
#
# 放常量而不是只放 md 里，是因为检索靠关键词命中，跨型号时极易漏；
# 这几条错了会静默产出"看起来对"的错数据，代价远高于多几百字上下文。
HARD_RULES = (
    ("引脚顺序", "差分对 P/N 必须保持 PDF 视觉行序（同一行的 OUTB_0+ / OUTB_0- 相邻）。"
                "严禁「先全部 +、再全部 -」的分组重排；脚号与名字必须来自同一次版面读取，"
                "不许一处取号、另一处取名。"),
    ("抽表方式", "TI 手册/EVK 的重叠文本对象会让 find_tables().extract() 返回字符交错串"
                "（`O O O OU U U U…`），get_text('text') 的行正则也会丢列。"
                "引脚表只认 qc/pdf_pin_table.py 的 span 坐标法（visual row → 脚号列 → 行×列取格）。"),
    ("断言自证", "校验真值不得取自修复输入本身。至少要有：独立人工转录锚点、"
                "结构断言（配对/唯一/数量）、以及用旧数据跑一遍能报错的**反例检测**。"
                "「52/52 通过」若用的是同一份错数据，等于没验。"),
    ("身份先行", "评估板/模块先定 basic_info.identity 与 device_mpn，再谈引脚；"
                "板级不做裸芯片引脚图，封装字段写板卡形态并把板载器件单列一行。"),
    ("转义分层", "`&amp;amp;` 是 esc 执行了两遍 → 修共享模板 + 重渲染；"
                "不要逐件洗 JSON，下次重渲染会覆盖回去。JSON 里单层 `&amp;` 是合法实体，不是缺陷。"),
    ("去重比对", "Hero/Overview 必须共享同一句、比对时忽略空白；hero 截断要落在句末标点，"
                "不然宁可整句复用——半句截断（`… de salida que soporta tasas …`）比重复更难读。"),
    ("条件列", "电气表空 condition 只补可核验的 condition_note；命中不到 PDF 原文就挂 warning，"
                "绝不编造测试条件。"),
    ("不猜值", "值级/封装/身份未核实一律交人工。自动修复只做结构与展示层，"
                "改了「看起来更合理」的数值就是引入新缺陷。"),
)


def hard_rules(max_chars: int = 1800) -> str:
    """常驻硬规则文本（注入 LLM 修复上下文用）。"""
    parts = ["【硬规则·来自 DS80PCI402EVK/NOPB 修复事故，违反即禁止落盘】"]
    used = len(parts[0])
    for name, body in HARD_RULES:
        line = f"- {name}：{body}"
        if used + len(line) > max_chars and len(parts) > 1:
            break
        parts.append(line)
        used += len(line) + 1
    return "\n".join(parts)


def _read(path: Path) -> str:
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def split_sections(text: str) -> list[tuple[str, str]]:
    """按 `## ` 二级标题切段，返回 [(标题, 正文)]。文件的 `# 一级标题` 归入前言。"""
    out: list[tuple[str, str]] = []
    cur_title, cur_lines = "", []
    for line in text.splitlines():
        if line.startswith("## "):
            if cur_title or cur_lines:
                out.append((cur_title, "\n".join(cur_lines)))
            cur_title, cur_lines = line[3:].strip(), []
        else:
            cur_lines.append(line)
    if cur_title or cur_lines:
        out.append((cur_title, "\n".join(cur_lines)))
    return out


def load_experience(mpn: str, kinds: list[str] | None = None,
                    max_chars: int = 6000, root: Path | None = None) -> dict:
    """抽取相关经验。

    优先级：
      1. 同 MPN 的段落（最相关，整段给）；
      2. 命中 kind 关键词的段落（跨型号借经验，按命中数排序）；
    超长时按段落边界截断，不切断句子。
    """
    path = log_path(root)
    text = _read(path)
    if not text:
        return {"ok": False, "reason": "log_missing", "text": "", "sections": []}

    mpn_up = str(mpn or "").upper()
    kinds = kinds or []
    words: set[str] = set()
    for k in kinds:
        words.update(KIND_HINTS.get(k, []))
    words = {w for w in words if w}

    same, related = [], []
    for title, body in split_sections(text):
        blob = f"{title}\n{body}"
        if mpn_up and (mpn_up in title.upper() or mpn_up in blob.upper()):
            same.append((title, body))
            continue
        hits = sum(1 for w in words if w.lower() in blob.lower())
        if hits:
            related.append((hits, title, body))

    related.sort(key=lambda x: -x[0])
    picked = same + [(t, b) for _h, t, b in related[:3]]

    parts: list[str] = []
    used = 0
    for title, body in picked:
        chunk = f"## {title}\n{body.strip()}"
        if used + len(chunk) > max_chars and parts:
            break
        parts.append(chunk)
        used += len(chunk)

    return {"ok": bool(parts), "text": "\n\n".join(parts),
            "sections": [t for t, _ in picked],
            "same_mpn": len(same), "related": len(related), "path": str(path)}


def _fmt_action(a: dict) -> str:
    ident = a.get("id") or "?"
    kind = a.get("kind") or "?"
    worker = a.get("worker") or "?"
    st = a.get("status") or "pending"
    changed = a.get("changed") or []
    note = a.get("note") or ""
    head = f"- `{ident}` **{kind}** → `{worker}` : {st}"
    if changed:
        shown = ", ".join(changed[:4]) + ("…" if len(changed) > 4 else "")
        head += f"（改 {len(changed)} 处：{shown}）"
    if note:
        head += f" — {note}"
    return head


def append_experience(mpn: str, round_: int, plan: dict,
                      verdict_before: str = "", verdict_after: str = "",
                      extra: str = "", root: Path | None = None) -> dict:
    """把一轮自动修复的结果追加到日志（append-only，只在末尾加 `##` section）。"""
    path = log_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    actions = plan.get("actions") or []
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    done = [a for a in actions if a.get("status") == "done"]
    skipped = [a for a in actions if a.get("status") == "skipped"]
    manual = [a for a in actions if a.get("status") == "manual"]
    failed = [a for a in actions if a.get("status") not in ("done", "skipped", "manual")]

    lines = [f"## {mpn} · 自动修复 round {round_}（{ts} · system:auto_fix）", ""]
    meta = []
    if verdict_before:
        meta.append(f"修前 verdict `{verdict_before}`")
    if verdict_after:
        meta.append(f"修后 `{verdict_after}`")
    meta.append(f"actions {len(actions)}（done {len(done)} / skipped {len(skipped)}"
                f" / manual {len(manual)} / 未完成 {len(failed)}）")
    lines += ["> " + "，".join(meta), ""]

    if actions:
        lines += ["### 逐条结果", ""]
        lines += [_fmt_action(a) for a in actions]
        lines.append("")

    # 结论 / 经验：从实际结果归纳，不写空话
    lessons: list[str] = []
    for a in done:
        if a.get("kind") == "identity_board_unresolved" or a.get("worker") == "fix_identity":
            lessons.append("身份判定为评估板后，引脚表自动获得 `device_scope=onboard_device`，"
                           "无需重建引脚（重建反而会丢板载器件上下文）。")
        if a.get("worker") == "fix_escape" and a.get("changed"):
            lessons.append("双重转义 `unescape` 一层即恢复正确显示，证明根因是「转义执行两遍」"
                           "而非数据本身脏——修渲染层比逐件洗数据更彻底。")
        if a.get("worker") == "fix_elec_row" and "condition" in " ".join(a.get("changed") or []):
            lessons.append("条件列能从 PDF 原文窗口命中时直接补，比让模型自由生成可靠；"
                           "命中不到就只挂 warning，绝不编造测试条件。")
        if a.get("worker") == "fix_template_render":
            lessons.append("Hero/Overview、Benefits、FAQ 这类重复是模板层问题，"
                           "改共享模板后重渲染即收敛；逐件改 JSON 会被下次重渲染覆盖。")
    for a in manual:
        if a.get("kind") in ("package_mismatch", "identity_unverified"):
            lessons.append(f"`{a.get('kind')}` 属值级/身份未核实，自动修复不参与，"
                           f"必须走证据卡或人工确认。")
    if extra:
        lessons.append(extra.strip())

    if lessons:
        lines += ["### 经验", ""]
        seen = set()
        for s in lessons:
            if s in seen:
                continue
            seen.add(s)
            lines.append(f"- {s}")
        lines.append("")

    block = "\n".join(lines).rstrip() + "\n\n"

    # append-only：绝不读改写全文件
    need_sep = False
    if path.is_file() and path.stat().st_size > 0:
        tail = _read(path)[-8:]
        need_sep = not tail.endswith("\n\n") and not tail.endswith("---\n")
    with path.open("a", encoding="utf-8") as f:
        if need_sep:
            f.write("\n")
        f.write(block)

    return {"ok": True, "path": str(path), "section": f"{mpn} · 自动修复 round {round_}",
            "done": len(done), "manual": len(manual)}
