"""自动修复器：白名单约束 + 备份 + 审计留痕的纯函数集合。

设计纪律（与项目既有约束一致）：
  1. **不碰 facts 的值**——只改结构 / 呈现 / 身份标记。值级问题一律交人工
     （gold_field_update 守卫那一套），这里不做「猜一个更好的数值」；
  2. 每个 fixer 只能改 `action.allowed_paths` 里的路径，越界直接抛
     PermissionError，由 commit() 统一拦截（比「信任调用方」务实）；
  3. 写盘前必须先备份（parsed json + txt/alts/seo/symbols 同名产物），
     备份目录写进 fix_plan.log.jsonl，供事后 restore；
  4. fixer 是纯函数：入参 ctx，返回 {changed, next_task, note}，不做 IO 之外的事，
     方便单测（tests/test_fixers.py 就是按这个签名的）。

fixer 清单见 FIXERS，kind → fixer 的映射在 worker/tasks.py:ACTION_TEMPLATES。
"""
from __future__ import annotations

import html
import json
import os
import re
import shutil
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any

from app import config
from parse_datasheets import model_for

# ---------------------------------------------------------------- 路径工具


_TOKEN = re.compile(r"([^.\[\]]+)|\[(\d+)\]")


def parse_path(path: str) -> list[str | int]:
    """把 `a.b[0].c` / `a.*.c` 拆成 ['a','b',0,'c'] / ['a','*','c']。"""
    out: list[str | int] = []
    for m in _TOKEN.finditer(str(path or "")):
        if m.group(1) is not None:
            out.append(m.group(1))
        else:
            out.append(int(m.group(2)))
    return out


def get_path(doc: Any, path: str) -> Any:
    cur = doc
    for k in parse_path(path):
        if isinstance(k, int):
            if not isinstance(cur, list) or k >= len(cur):
                return None
            cur = cur[k]
        else:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(k)
    return cur


def set_path(doc: Any, path: str, value: Any) -> bool:
    """按 path 写值；父级不存在时返回 False（不擅自造结构）。"""
    keys = parse_path(path)
    if not keys:
        return False
    cur = doc
    for k in keys[:-1]:
        if isinstance(k, int):
            if not isinstance(cur, list) or k >= len(cur):
                return False
            cur = cur[k]
        else:
            if not isinstance(cur, dict) or k not in cur:
                return False
            cur = cur[k]
    last = keys[-1]
    if isinstance(last, int):
        if not isinstance(cur, list) or last >= len(cur):
            return False
        cur[last] = value
        return True
    if not isinstance(cur, dict):
        return False
    cur[last] = value
    return True


def walk_strings(node: Any, path: str = "") -> list[tuple[str, str]]:
    """产出所有字符串叶子及其路径（用于 escape 归一）。"""
    out: list[tuple[str, str]] = []
    if isinstance(node, dict):
        for k, v in node.items():
            out.extend(walk_strings(v, f"{path}.{k}" if path else str(k)))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            out.extend(walk_strings(v, f"{path}[{i}]"))
    elif isinstance(node, str):
        out.append((path, node))
    return out


def path_allowed(path: str, allowed: list[str]) -> bool:
    """白名单匹配（按 token 逐段比，避免 `a[0].c` 与 `a.*.c` 写法差异漏判）。

    支持：
      `*`       全放行
      `a.b`     该路径及其子路径（`a.b` 放行 `a.b.c`、`a.b[0].c`）
      `a.*.c`   中间任意一段（含索引段）
      `a.*`     末段为 `*` 时表示「a 下任意深度」
    """
    if not allowed:
        return False
    if "*" in allowed:
        return True
    pt = tuple(parse_path(path))
    if not pt:
        return False
    for a in allowed:
        at = tuple(parse_path(a))
        if not at:
            continue
        if at[-1] == "*":                       # 末段通配 = 任意深度
            head = at[:-1]
            if pt[:len(head)] == head:
                return True
            continue
        n = min(len(at), len(pt))
        if all(av == "*" or str(av) == str(pv) for av, pv in zip(at[:n], pt[:n])):
            return True                         # 完全相等或 prefix
    return False


def validate_changes(ctx: dict, changed: list[str]) -> None:
    """越权检查：任何不在 allowed_paths 的路径直接抛错，整次修复作废并回滚。"""
    allowed = ctx.get("allowed_paths") or []
    for p in changed:
        if not path_allowed(p, allowed):
            raise PermissionError(f"fixer 试图修改非白名单路径: {p}")


# ---------------------------------------------------------------- 备份 / 落盘


def backup_dir_for(mpn: str, data_dir: Path | None = None) -> Path:
    data_dir = Path(data_dir or config.DATA)
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(mpn or "")).upper()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    d = data_dir / "qc" / "fix_backups" / safe / stamp
    d.mkdir(parents=True, exist_ok=True)
    return d


def _artifact_siblings(stem: str, data_dir: Path) -> list[Path]:
    """json 之外需要一起备份的产物（txt/多语 txt/alts/seo/symbols）。"""
    out: list[Path] = []
    for sub in ("txt", "alts", "seo", "symbols"):
        d = data_dir / sub
        if not d.is_dir():
            continue
        for p in d.glob(f"{stem}*"):
            if p.is_file():
                out.append(p)
    return out


def restore(mpn: str, backup_dir: str | Path, data_dir: Path | None = None) -> dict:
    """从备份目录恢复产物，返回恢复明细（供人工回滚）。

    备份命名规则：主 JSON 用原名；同名产物加 `<子目录>__` 前缀（避免 alts/x.json
    与 parsed/x.json 撞名）。恢复时按前缀放回对应目录，去掉前缀。
    """
    data_dir = Path(data_dir or config.DATA)
    bdir = Path(backup_dir)
    if not bdir.is_dir():
        raise FileNotFoundError(f"备份目录不存在: {bdir}")

    subdirs = {"txt": data_dir / "txt", "alts": data_dir / "alts",
               "seo": data_dir / "seo", "symbols": data_dir / "symbols"}
    restored: list[str] = []
    for p in sorted(bdir.iterdir()):
        if not p.is_file():
            continue
        name = p.name
        dest_dir = data_dir / "parsed"
        if "__" in name:
            tag, real = name.split("__", 1)
            if tag in subdirs:
                dest_dir, name = subdirs[tag], real
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest_dir / name)
        restored.append(str(dest_dir / name))
    return {"mpn": mpn, "restored": len(restored), "files": restored}


def _read_pdf_excerpt(pdf_path: Path, pages: int = 6, max_chars: int = 20000) -> str:
    if not pdf_path or not Path(pdf_path).is_file():
        return ""
    try:
        import fitz  # pymupdf
    except Exception:                                            # noqa: BLE001
        return ""
    try:
        doc = fitz.open(str(pdf_path))
        try:
            text = "\n".join(p.get_text("text") for p in doc[:pages])
        finally:
            doc.close()
        return text[:max_chars]
    except Exception:                                            # noqa: BLE001
        return ""


def preflight(mpn: str, action: dict, plan: dict, data_dir: Path | None = None,
              db=None) -> dict:
    """备份 + 载入 doc + 可选 PDF 文本。失败返回 {ok: False, reason}。"""
    data_dir = Path(data_dir or config.DATA)
    if db is None:
        from app import db as _db
        db = _db
    row = db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1", (mpn, mpn))
    if not row:
        return {"ok": False, "reason": "item_not_found"}

    jp = config.resolve_artifact(row.get("json_path") or "", config.PARSED)
    if not jp.is_file():
        return {"ok": False, "reason": "parsed_json_missing"}
    doc = json.loads(jp.read_text(encoding="utf-8"))
    if not isinstance(doc, dict):
        return {"ok": False, "reason": "parsed_json_invalid"}

    bdir = backup_dir_for(mpn, data_dir)
    shutil.copy2(jp, bdir / jp.name)
    for p in _artifact_siblings(jp.stem, data_dir):
        # 同名产物可能撞名（alts/x.json 与 parsed/x.json），加目录前缀避免覆盖
        tag = p.parent.name
        shutil.copy2(p, bdir / f"{tag}__{p.name}")

    pdf_text = ""
    if action.get("requires_pdf_text"):
        pdf = config.resolve_artifact(row.get("pdf_path") or "", config.PDFS)
        pdf_text = _read_pdf_excerpt(pdf)

    # 经验注入：常驻硬规则（不依赖检索命中）+ 同型号/同类 kind 的历史段落。
    # 硬规则必须无条件给：跨型号时关键词检索经常漏，而这几条错了会静默出错数据。
    experience = ""
    try:
        from worker.fix_memory import hard_rules, load_experience
        rules = hard_rules()
        exp = load_experience(mpn, [str(action.get("kind") or "")],
                              max_chars=4000)
        hist = exp.get("text") or ""
        experience = (rules + ("\n\n" + hist if hist else "")).strip()
    except Exception:                                            # noqa: BLE001
        experience = ""

    # 渲染产物里是否还有转义残留（区分「数据脏」和「旧产物」的关键判别）
    txt_esc, txt_evidence = _txt_has_escape(dict(row), data_dir)

    # LLM 兜底配置（ICPDF_FIX_LLM=0 可整体关掉，关掉时 fixer 只走确定性规则）
    llm_cfg: dict = {}
    if os.getenv("ICPDF_FIX_LLM", "1") != "0":
        _key = os.getenv("DASHSCOPE_API_KEY", "").strip()
        if _key:
            llm_cfg = {
                "key": _key,
                "base": os.getenv("DASHSCOPE_BASE",
                                  "https://dashscope.aliyuncs.com/compatible-mode/v1"),
                "model": model_for("fix"),
            }

    return {
        "ok": True, "mpn": mpn, "row": dict(row),
        "mpn_key": row.get("mpn_key") or "", "safe": jp.stem,
        "json_path": jp, "backup_dir": bdir, "data_dir": data_dir,
        "doc": doc, "original": deepcopy(doc),
        "pdf_text": pdf_text,
        "experience": experience, "llm": llm_cfg,
        "txt_has_escape": txt_esc, "txt_escape_evidence": txt_evidence,
        "action": action, "plan": plan,
        "allowed_paths": action.get("allowed_paths") or [],
        "alts": _load_alts(row, data_dir),
    }


def _load_alts(row: dict, data_dir: Path) -> dict:
    p = config.resolve_artifact(row.get("alt_json_path") or "", config.ALTS)
    if not p.is_file():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def commit(ctx: dict, changed: list[str]) -> None:
    """校验白名单后写盘（调用方保证 changed 准确）。"""
    if not changed:
        return
    validate_changes(ctx, changed)
    ctx["json_path"].write_text(
        json.dumps(ctx["doc"], ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------- 各 fixer

BOARD_TOKENS = ("EVM", "EVK", "EMK", "EVB", "EVAL", "KIT", "BOARD",
                "MODULE", "PDK", "DYNO", "PGMA")

_UNIT_RE = re.compile(r"^\s*([-+]?\d+(?:\.\d+)?)\s*([a-zA-Z%µμ°Ω][a-zA-Z0-9%/·^\-]*)\s*$")


def _looks_like_board(mpn: str, package_type: str) -> bool:
    up = str(mpn or "").upper()
    if any(t in up for t in BOARD_TOKENS):
        return True
    return str(package_type or "").upper().startswith("PCB")


_ESC_RESIDUE = re.compile(r"&(?:amp;){2,}|&amp;(?:lt|gt|quot|#\d+);")


def _txt_has_escape(row: dict, data_dir: Path) -> tuple[bool, str]:
    """检查渲染产物（txt）里是否还有转义残留；返回 (有残留, 命中片段)。"""
    tp = config.resolve_artifact(row.get("txt_path") or "", config.TXT)
    if not tp.is_file():
        # txt_path 为空时按 stem 猜（跨机/老数据兜底）
        jp = config.resolve_artifact(row.get("json_path") or "", config.PARSED)
        if jp.stem:
            cand = Path(data_dir) / "txt" / f"{jp.stem}.txt"
            tp = cand if cand.is_file() else tp
    if not tp.is_file():
        return False, ""
    try:
        t = tp.read_text(encoding="utf-8", errors="ignore")[:800_000]
    except OSError:
        return False, ""
    m = _ESC_RESIDUE.search(t)
    if not m:
        return False, ""
    return True, t[max(0, m.start() - 40): m.end() + 20]


def fix_escape(ctx: dict) -> dict:
    """HTML 实体转义归一。

    两种情况分开处理（这一步判别很关键）：
      * **JSON 里有转义** → 数据脏，unescape 到稳定（幂等）；
      * **JSON 干净、只有 txt 有** → 是渲染层把 esc 执行了两遍留下的旧产物，
        改 JSON 一点用都没有，正确动作是重渲染（模板修好后自然消失）。
    """
    doc = ctx["doc"]
    changed: list[str] = []
    for path, val in walk_strings(doc):
        if "&" not in val:
            continue
        # 循环解到稳定（最多 3 层）：产物里出现 &amp;amp; 说明转义被执行了两遍，
        # 只解一层会留下 &amp;，下次再跑又会变——那就不是幂等修复了。
        fixed = val
        for _ in range(3):
            nxt = html.unescape(fixed)
            if nxt == fixed:
                break
            fixed = nxt
        if fixed != val and set_path(doc, path, fixed):
            changed.append(path)
        if len(changed) >= 500:                     # 日志防爆
            break
    if changed:
        commit(ctx, changed)
        return {"changed": changed, "next_task": "render_item", "note": "json_unescaped"}

    # JSON 干净 → 旧产物是渲染层残留，重渲染即修好。
    # 这里记 `render:*` 作为「确有修复动作」的证据：JSON 没改（所以不 commit、
    # 不过白名单），但产物确实要被重新生成。不记的话，渲染层缺陷永远进不了
    # 「已 review 并已修复」——修好了却显示没修，比不修更容易误导。
    if ctx.get("txt_has_escape"):
        return {"changed": ["render:txt"], "render_only": True,
                "next_task": "render_item", "note": "render_layer_escape_only"}
    return {"changed": [], "next_task": "render_item", "note": "no_escape_found"}


def fix_unit_duplicated(ctx: dict) -> dict:
    """value 里重复带了单位（`10 mA` + unit=`mA`）→ 剥离 value 里的单位。

    确定性修复：只在 `value` 能完整解析成「数字 + 与 unit 相同的单位」时动手，
    其余情况不动（不猜）。
    """
    doc = ctx["doc"]
    elec = ((doc.get("specs") or {}).get("electrical") or [])
    changed: list[str] = []
    for i, row in enumerate(elec):
        if not isinstance(row, dict):
            continue
        val = str(row.get("value") or "").strip()
        unit = str(row.get("unit") or "").strip()
        if not val or not unit:
            continue
        m = _UNIT_RE.match(val)
        if not m:
            continue
        num, u = m.group(1), m.group(2)
        if u.lower() != unit.lower():
            continue
        path = f"specs.electrical[{i}].value"
        if set_path(doc, path, num):
            changed.append(path)
    if changed:
        commit(ctx, changed)
    return {"changed": changed, "next_task": "render_item",
            "note": "" if changed else "no_duplicated_unit"}


def fix_elec_shape(ctx: dict) -> dict:
    """electrical 行缺 name/value/unit → 缺失字段标 `not_specified`，不编造数值。

    值是否存在只有证据卡能定，这里只把「形状」补成渲染层能吃的结构，
    并挂 quality_warning 让下游/人工一眼看到。
    """
    doc = ctx["doc"]
    elec = ((doc.get("specs") or {}).get("electrical") or [])
    changed: list[str] = []
    for i, row in enumerate(elec):
        if not isinstance(row, dict):
            continue
        miss = [k for k in ("name", "value", "unit") if not str(row.get(k, "")).strip()]
        if not miss:
            continue
        for k in miss:
            p = f"specs.electrical[{i}].{k}"
            if set_path(doc, p, "not_specified"):
                changed.append(p)
        warns = row.get("quality_warning")
        if not isinstance(warns, list):
            warns = []
            row["quality_warning"] = warns
            changed.append(f"specs.electrical[{i}].quality_warning")
        tag = f"field_missing:{','.join(miss)}"
        if tag not in warns:
            warns.append(tag)
    if changed:
        commit(ctx, changed)
    return {"changed": changed, "next_task": "render_item",
            "note": "" if changed else "shape_ok"}


def fix_elec_drop_feature(ctx: dict) -> dict:
    """electrical 里的 Features 条目（`value` 回灌 `name`）→ 移出并留证据。

    起因：prompt v2 的 dry-run 里 DAC37J84IAAV 出现 10 处 `value` 就是 `name`
    本身（如 "Sinx/x Correction Filters"），原文来自 **Features 章节**而不是
    电气表。这类行既没有可测量的值，又会让下游把「特性标题」当成参数渲染。

    **为什么是「移出 + 留证据」而不是直接删**：
    - dropped 明细挂 `metadata.elec_dropped_features`，能回看过滤了什么，
      发现误伤可从明细恢复；
    - 不新增 electrical 行内字段，schema 不变（review 的 schema 红线不会响）。

    只处理 `ECHO_NAME`，不处理 `FEATURE_DESCRIPTION`——后者是「value 为长
    描述句」，实测 10 件里 0 命中，判据样本还太少，先不动。
    """
    try:
        from qc import electrical_classify as _CLS         # noqa: PLC0415
    except Exception:                                      # noqa: BLE001
        return {"changed": [], "next_task": "", "note": "classifier_unavailable"}

    doc = ctx["doc"]
    sp = doc.get("specs") or {}
    rows = list(sp.get("electrical") or [])
    kept: list = []
    dropped: list = []
    for r in rows:
        if _CLS.classify_electrical_row(r) == _CLS.ECHO_NAME:
            dropped.append({
                "name": str((r or {}).get("name") or "")[:120],
                "value": str((r or {}).get("value") or "")[:120],
                "reason": "value 回灌 name，原文来自 Features/描述性章节",
            })
        else:
            kept.append(r)
    if not dropped:
        return {"changed": [], "next_task": "", "note": "no_echo_rows"}

    sp["electrical"] = kept
    meta = doc.get("metadata")
    if not isinstance(meta, dict):
        meta = {}
        doc["metadata"] = meta
    meta["elec_dropped_features"] = dropped
    changed = ["specs.electrical", "metadata.elec_dropped_features"]
    commit(ctx, changed)
    return {"changed": changed, "next_task": "render_item",
            "note": f"dropped {len(dropped)} feature-like rows"}


_COND_HINT = re.compile(
    r"(over\s+(?:the\s+)?(?:operating\s+)?(?:free[- ]air\s+)?temperature[^.;\n]{0,90}"
    r"|at\s+T[A-Z]\s*=\s*[^,;\n]{0,40}"
    r"|(?:unless\s+otherwise\s+noted)[^.;\n]{0,60}"
    r"|V(?:CC|DD|IN|S)\s*=\s*[^,;\n]{0,30})", re.I)


def _norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def _llm_condition(ctx: dict, row_name: str, pdf_text: str) -> str:
    """规则命中不到时，让模型从原文里摘条件——但必须能引用原文（子串校验）。

    防幻觉的硬约束：模型返回的 `quote` 必须是 `pdf_text` 的逐字子串（忽略空白），
    否则整条丢弃。这样即使模型编了一个「看起来合理」的条件，也过不了校验。
    经验（ctx["experience"]）一并给进去，让它按历史定位方式找，而不是自由发挥。
    """
    cfg = ctx.get("llm") or {}
    if not cfg.get("key") or not pdf_text or not row_name:
        return ""
    seg = ""
    m = re.search(re.escape(row_name), pdf_text, re.I)
    if m:
        seg = pdf_text[max(0, m.start() - 300): m.end() + 900]
    if not seg:
        seg = pdf_text[:1200]
    exp = str(ctx.get("experience") or "")[:2500]
    sys_p = ('你是 datasheet 电气表条件抽取器。只从用户给的原文里摘录，'
             '不许改写、不许推测、不许补全。输出 JSON：'
             '{"condition": "...", "quote": "..."}。'
             'condition 是该行参数对应的测试条件原文（例如 over operating free-air '
             'temperature range unless otherwise noted / TA = 25°C / VIN = 3.3 V）；'
             'quote 必须是原文的逐字子串，用于校验。找不到就给空字符串。')
    user = (f"参数名：{row_name}\n\n"
            f"历史经验（只参考定位方式，不要照抄别的型号的结论）：\n{exp or '（无）'}\n\n"
            f"原文片段：\n{seg}")
    try:
        import requests
        r = requests.post(
            str(cfg.get("base") or "").rstrip("/") + "/chat/completions",
            headers={"Authorization": f"Bearer {cfg['key']}",
                     "Content-Type": "application/json"},
            json={"model": cfg.get("model"),
                  "messages": [{"role": "system", "content": sys_p},
                               {"role": "user", "content": user}],
                  "temperature": 0, "max_tokens": 400,
                  "response_format": {"type": "json_object"},
                  "enable_thinking": False},
            timeout=60)
        if r.status_code != 200:
            return ""
        content = (r.json().get("choices") or [{}])[0].get("message", {}).get("content", "")
        obj = json.loads(re.sub(r"^```(?:json)?|```$", "", content.strip(),
                                flags=re.M).strip() or "{}")
        cond = str(obj.get("condition") or "").strip()
        quote = str(obj.get("quote") or "").strip()
        if not cond or not quote:
            return ""
        if _norm_ws(quote) not in _norm_ws(pdf_text):
            return ""                                # 引用校验失败 → 丢弃
        return cond[:120]
    except Exception:                                            # noqa: BLE001
        return ""


def fix_elec_row(ctx: dict) -> dict:
    """condition 类问题：**只改 condition**，且必须有 PDF 原文佐证；否则只挂 warning。

    value / unit 一律不碰（那是证据卡 + Gold 的地盘）。
    """
    doc = ctx["doc"]
    action = ctx.get("action") or {}
    ev = action.get("evidence") or {}
    elec = ((doc.get("specs") or {}).get("electrical") or [])
    changed: list[str] = []

    idx = ev.get("index")
    targets = []
    if isinstance(idx, int) and 0 <= idx < len(elec):
        targets = [idx]
    elif ev.get("field"):
        m = re.match(r"specs\.electrical\[(\d+)\]", str(ev["field"]))
        if m:
            targets = [int(m.group(1))]
    if not targets:
        targets = list(range(len(elec)))

    pdf_text = ctx.get("pdf_text") or ""
    for i in targets:
        row = elec[i] if i < len(elec) else None
        if not isinstance(row, dict):
            continue
        if str(row.get("condition") or "").strip():
            continue                                 # 已有条件，不覆盖
        name = str(row.get("name") or "")
        cand = ""
        if pdf_text and name:
            # 在该行名称附近找条件语（前后 200 字符窗口）
            for m in re.finditer(re.escape(name), pdf_text, re.I):
                win = pdf_text[max(0, m.start() - 120): m.end() + 200]
                hit = _COND_HINT.search(win)
                if hit:
                    cand = " ".join(hit.group(1).split())[:120]
                    break
        if not cand:
            # 规则命中不到 → 模型兜底（带原文引用校验 + 历史经验）
            cand = _llm_condition(ctx, name, pdf_text)
        if not cand:
            warns = row.get("quality_warning")
            if not isinstance(warns, list):
                warns = []
                row["quality_warning"] = warns
                changed.append(f"specs.electrical[{i}].quality_warning")
            tag = f"condition_unresolved:{action.get('kind') or 'condition'}"
            if tag not in warns:
                warns.append(tag)
            continue
        p = f"specs.electrical[{i}].condition"
        if set_path(doc, p, cand):
            changed.append(p)
    if changed:
        commit(ctx, changed)
    resolved = [c for c in changed if c.endswith(".condition")]
    return {"changed": changed, "next_task": "render_item",
            "note": f"condition_resolved={len(resolved)}" if resolved else "condition_unresolved"}


def fix_identity(ctx: dict) -> dict:
    """评估板/套件身份修正：标 identity、清掉不属于该板的芯片封装、给引脚标归属。

    只在「确实像板」时才动手（MPN 形态 或 alternatives.board 为真 或 封装是 PCB*），
    否则返回 no_change——不猜身份。
    """
    doc = ctx["doc"]
    alts = ctx.get("alts") or {}
    pkg = ((doc.get("specs") or {}).get("package") or {})
    pkg_type = str(pkg.get("type") or "")
    mpn = ctx["mpn"]

    # 身份口径与 review/pipeline 共用一个判定器（证据优先：不在订货表 + 板卡后缀）
    info = {}
    try:
        from qc import board_identity as BI
        info = BI.classify(mpn, doc, pkg_type,
                           str((doc.get("basic_info") or {}).get("manufacturer") or ""),
                           str(ctx.get("pdf_text") or ""))
    except Exception:                                            # noqa: BLE001
        info = {}
    board = bool(info.get("identity") in ("evaluation_board", "development_kit")) \
        or (alts.get("board") is True) or _looks_like_board(mpn, pkg_type)
    if not board:
        return {"changed": [], "next_task": "render_item", "note": "not_a_board"}

    changed: list[str] = []
    bi = doc.get("basic_info")
    if not isinstance(bi, dict):
        bi = {}
        doc["basic_info"] = bi
    if str(bi.get("identity") or "") != "evaluation_board":
        bi["identity"] = "evaluation_board"
        changed.append("basic_info.identity")

    # 板载器件：判定器能推出来就写上（页面要能说清「这是哪颗芯片的板」）
    dev = str(info.get("device_mpn") or "")
    if not dev:
        # 订货表推不出时退到「剥掉板卡后缀的家族根」：DS80PCI402EVK -> DS80PCI402
        try:
            from qc import board_identity as _BI
            dev = _BI.family_root(mpn)
        except Exception:                                        # noqa: BLE001
            dev = ""
    if dev and str(bi.get("device_mpn") or "") != dev:
        bi["device_mpn"] = dev
        changed.append("basic_info.device_mpn")
    # 这份说明书讲的是板载器件，不是板本身：必须声明覆盖范围
    if str(bi.get("datasheet_scope") or "") != "onboard_device":
        bi["datasheet_scope"] = "onboard_device"
        changed.append("basic_info.datasheet_scope")

    # 板上芯片的封装不能当成本型号的封装：保留原值到 package.original_type 供追溯。
    # 注意不能写 not_specified —— review 的 board_package_mismatch 要求 PCB* 形态，
    # 写 not_specified 会让「修好的」产物立刻被判 P0。
    if pkg_type and not pkg_type.upper().startswith("PCB"):
        pkg["original_type"] = pkg_type
        changed.append("specs.package.original_type")
        pkg["type"] = "Evaluation Board (assembled PCB)"
        changed.append("specs.package.type")

    # 板载器件的引脚保留（对维修/替代有用），但标明归属，避免被当成型号引脚
    pins = doc.get("pin_configuration") or []
    for i, p in enumerate(pins):
        if not isinstance(p, dict):
            continue
        if p.get("device_scope") == "onboard_device":
            continue
        p["device_scope"] = "onboard_device"
        changed.append(f"pin_configuration[{i}].device_scope")

    if changed:
        commit(ctx, changed)
    return {"changed": changed, "next_task": "render_item", "note": "board_marked"}


def fix_alts_filter(ctx: dict) -> dict:
    """替代料 JSON 里 match=miss 的条目必须丢弃（README 口径）。

    只在「数组里确实有 miss 行」时动手，且只删这些行、不动其余字段；
    原数组备份到 `dropped_miss`，审计能看出删了什么。
    """
    alts = ctx.get("alts") or {}
    rows = alts.get("alternatives") or []
    miss = [r for r in rows if isinstance(r, dict)
            and str(r.get("match") or "") == "miss"]
    if not miss:
        return {"changed": [], "next_task": "", "note": "no_miss"}

    keep = [r for r in rows if not (isinstance(r, dict)
                                    and str(r.get("match") or "") == "miss")]
    alts["alternatives"] = keep
    alts["dropped_miss"] = [str(r.get("mpn") or "") for r in miss]
    path = None
    try:
        path = config.resolve_artifact((ctx.get("row") or {}).get("alt_json_path") or "",
                                       config.ALTS)
    except Exception:                                            # noqa: BLE001
        path = None
    if not path or not path.is_file():
        path = config.ALTS / ((ctx.get("safe") or ctx["mpn"]) + ".json")
    path.write_text(json.dumps(alts, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"changed": ["data:alts.json"], "next_task": "",
            "note": "dropped %d miss rows" % len(miss)}


def fix_seo_shared(ctx: dict) -> dict:
    """seo.json 补共享分类图标注（多个应用领域复用同一张图时必须说明）。"""
    row = ctx.get("row") or {}
    try:
        path = config.resolve_artifact(row.get("seo_path") or "", config.SEO)
    except Exception:                                            # noqa: BLE001
        path = None
    if not path or not path.is_file():
        path = config.SEO / ((ctx.get("safe") or ctx["mpn"]) + ".json")
    if not path.is_file():
        return {"changed": [], "next_task": "", "note": "no_seo"}
    try:
        seo = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"changed": [], "next_task": "", "note": "seo_unreadable"}
    imgs = seo.get("images") or []
    by: dict[str, list[str]] = {}
    for r in imgs:
        icon = str((r or {}).get("image") or "")
        if icon:
            by.setdefault(icon, []).append(str((r or {}).get("application") or ""))
    shared = {k: v for k, v in by.items() if len(v) > 1}
    if not shared and "shared_icon_count" in seo:
        return {"changed": [], "next_task": "", "note": "no_shared"}
    seo["shared_category_icon"] = bool(shared)
    seo["shared_icon_count"] = len(shared)
    seo["shared_by_applications"] = shared
    seo["distinct_images"] = sorted(by)
    seo["distinct_image_count"] = len(by)
    path.write_text(json.dumps(seo, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"changed": ["data:seo.json"], "next_task": "",
            "note": "shared=%d/%d" % (len(shared), len(imgs))}


def fix_mpn_rewritten(ctx: dict) -> dict:
    """basic_info.mpn 被换成板载器件号 → 保请求 MPN，把器件号挪到 device_mpn。

    只在两者确实不同且请求 MPN 非空时动手；不改任何别的字段。
    """
    doc = ctx["doc"]
    bi = doc.get("basic_info")
    if not isinstance(bi, dict):
        return {"changed": [], "next_task": "render_item", "note": "no_basic_info"}
    want = str(ctx["mpn"] or "").strip()
    have = str(bi.get("mpn") or "").strip()
    if not want or not have or want == have:
        return {"changed": [], "next_task": "render_item", "note": "mpn_ok"}
    changed = []
    if not str(bi.get("device_mpn") or "").strip():
        bi["device_mpn"] = have
        changed.append("basic_info.device_mpn")
    bi["mpn"] = want
    changed.append("basic_info.mpn")
    # 身份随之标为板：型号号本身对不上时，只有板卡语境说得通
    alts = ctx.get("alts") or {}
    if (alts.get("board") is True or _looks_like_board(want, "")) \
            and str(bi.get("identity") or "") != "evaluation_board":
        bi["identity"] = "evaluation_board"
        changed.append("basic_info.identity")
    commit(ctx, changed)
    return {"changed": changed, "next_task": "render_item", "note": "mpn_restored"}


def fix_template_render(ctx: dict) -> dict:
    """模板层问题（hero/overview 重复、features/faq 凑数）：不改本件 JSON，只重渲染。

    这类问题的根因在共享模板（json_to_txt.py），逐件改 JSON 既无效也会被下次
    重渲染覆盖。正确做法是模板改完后重渲染受影响的件——这里就只触发重渲染。

    返回 `render:template` 表示「修复动作 = 重新生成产物」。它不算 JSON 改动
    （不走 commit、不过白名单），但算一次真实修复：重渲染后复审若仍不过，
    会被「修后必须重审通过」这条卡住，不会误标成已修复。
    """
    return {"changed": ["render:template"], "render_only": True,
            "next_task": "render_item", "note": "template_only_rerender"}


_PIN_LINE = re.compile(
    r"^\s*(\d{1,3})\s+([A-Z][A-Z0-9_/+.\-]{0,15})\s{1,}(\S.{5,120})$", re.M)

# DAP/散热焊盘：不是信号脚，脚号常不在数字列里，重抽表时要单独保留
_PAD_NAME = re.compile(r"^(?:DAP|EP|EPAD|PAD|THERMAL_?PAD|THERMALPAD|GNDPAD)$", re.I)
_PAD_TYPE = "thermal_pad"


def _pin_gate(doc: dict, rows: list[dict]) -> list[str]:
    """重建前的结构闸（DS80PCI402EVK 踩过的坑，逐条反着写）。

    1. **顺序闸**：差分对必须视觉交错，不许「先 P 后 N」；
    2. **不倒退闸**：新表的差分对问题数不得多于旧表（修完必须更好，不能更差）；
    3. **唯一闸**：脚号不许重复（跨页重复抽表会撞号）。

    这三条都只看 JSON 自身结构，不碰 PDF、不依赖修复输入当"真值"，
    所以不会重演「用错数据自证正确」那次事故。
    """
    bad: list[str] = []
    pins = [r.get("pin") for r in rows]
    if len(set(pins)) != len(pins):
        bad.append("dup_pins")
    if not all(isinstance(r.get("pin"), int) and r["pin"] > 0 for r in rows):
        bad.append("pin_not_int")
    if not all(str(r.get("name") or "").strip() for r in rows):
        bad.append("name_empty")
    try:
        from qc.pdf_pin_table import assert_interleaved
        bad.extend("interleave:" + s for s in assert_interleaved(rows))
    except Exception:                                            # noqa: BLE001
        pass
    try:
        from qc.pin_pairs import audit_pin_pairs
        new = len(audit_pin_pairs({"pin_configuration": rows,
                                   "specs": doc.get("specs") or {}}))
        old = len(audit_pin_pairs({"pin_configuration": doc.get("pin_configuration") or [],
                                   "specs": doc.get("specs") or {}}))
        if new > old:
            bad.append(f"pin_pair_regressed:{old}->{new}")
    except Exception:                                            # noqa: BLE001
        pass
    return bad


def fix_pin_rebuild(ctx: dict) -> dict:
    """从 PDF 按**版面坐标**重建 pin_configuration（保守版）。

    顺序语义是这一步的命门：TI 的引脚表是多列并排布局，同一视觉行里
    `OUTB_0+` 与 `OUTB_0-` 相邻。用 `find_tables().extract()` 或文字行正则都会
    得到「先全部 +、再全部 -」，值域看着正常但整组错位——DS80PCI402EVK/NOPB
    第一版修复就是这么错的。所以这里只认 `qc/pdf_pin_table.extract()`
    （span 坐标 → 视觉行 → 引脚号列 → 行×列取格），并用 `_pin_gate` 兜底：
    顺序不交错、或差分对问题比修前更多，一律不落盘、交人工。

    接受条件（缺一不可，任一条不满足就交人工）：
      1. 抽出 ≥8 行且脚号唯一、可排序；
      2. 与 package.pins 声明数相差 ≤10%（多/少太多说明抽错表）；
      3. 结构闸 `_pin_gate` 通过（交错 + 不倒退）；
      4. 与原引脚表差异显著（否则重写无意义，还会触发渲染循环）。
    """
    doc = ctx["doc"]
    row = ctx.get("row") or {}
    pdf = config.resolve_artifact(row.get("pdf_path") or "", config.PDFS)
    if not pdf.is_file():
        return {"changed": [], "next_task": "render_item",
                "note": "no_pdf_file"}

    ext = {}
    try:
        from qc.pdf_pin_table import extract
        ext = extract(pdf)
    except Exception as e:                                       # noqa: BLE001
        ext = {"ok": False, "rows": [], "rejected": f"extract_failed:{type(e).__name__}"}

    rows: list[dict] = []
    method = "dict_spans"
    if ext.get("ok"):
        rows = [{"pin": int(r["pin"]), "name": r["name"],
                 "description": r.get("description") or ""}
                for r in ext["rows"]]
    else:
        # 退路：老正则（只吃 pdf_text）。它同样可能按极性分组，所以照样过结构闸；
        # 闸不过就直接交人工——宁可少修，不可修错。
        pdf_text = ctx.get("pdf_text") or ""
        if not pdf_text:
            return {"changed": [], "next_task": "render_item",
                    "note": f"no_pin_table:{ext.get('rejected') or 'no_text'}"}
        seg = pdf_text
        m = re.search(r"(pin\s+(?:functions|configuration|description|assignment)s?)",
                      pdf_text, re.I)
        if m:
            seg = pdf_text[m.start(): m.start() + 6000]
        for mm in _PIN_LINE.finditer(seg):
            num, name, desc = mm.group(1), mm.group(2), mm.group(3).strip()
            if name.upper() in ("MIN", "MAX", "TYP", "UNIT", "NOTE") and len(name) <= 3 and not desc:
                continue
            rows.append({"pin": int(num), "name": name, "description": desc[:200]})
        rows.sort(key=lambda r: r["pin"])
        method = "text_regex"

    if len(rows) < 8:
        return {"changed": [], "next_task": "render_item",
                "note": f"pin_table_too_small:{len(rows)}"}

    declared = int(((doc.get("specs") or {}).get("package") or {}).get("pins") or 0)
    if declared and abs(len(rows) - declared) > max(2, int(declared * 0.10)):
        return {"changed": [], "next_task": "render_item",
                "note": f"pin_count_mismatch:{len(rows)}vs{declared}"}

    # 散热焊盘不在数字列里，按名字从旧表原样带过来（不新造、不丢）
    carried = [r for r in (doc.get("pin_configuration") or [])
               if isinstance(r, dict) and _PAD_NAME.match(str(r.get("name") or ""))]
    have = {r["pin"] for r in rows}
    for c in carried:
        if c.get("pin") not in have:
            rows.append({**c, "pin_type": _PAD_TYPE})
    rows.sort(key=lambda r: int(r.get("pin") or 0))

    gate = _pin_gate(doc, rows)
    if gate:
        return {"changed": [], "next_task": "render_item",
                "note": "pin_gate_rejected:" + "|".join(gate[:4])}

    old = doc.get("pin_configuration") or []
    old_keys = {(int(r.get("pin") or 0), str(r.get("name") or "").upper()) for r in old
                if isinstance(r, dict)}
    new_keys = {(r["pin"], r["name"].upper()) for r in rows}
    if len(new_keys ^ old_keys) < max(3, int(len(old_keys) * 0.6)):
        return {"changed": [], "next_task": "render_item",
                "note": "no_significant_diff"}

    doc["pin_configuration"] = rows
    commit(ctx, ["pin_configuration"])
    return {"changed": ["pin_configuration"], "next_task": "render_item",
            "note": f"pins_rebuilt:{len(rows)}:{method}"
                    f":pages{ext.get('pages') or '-'}"}



def fix_manual(ctx: dict) -> dict:
    """不该自动修的（值级 / 身份未核实）——明确返回人工，不制造改动。"""
    return {"changed": [], "next_task": "", "note": "manual_review",
            "manual": True}


FIXERS = {
    "fix_escape": fix_escape,
    "fix_unit_duplicated": fix_unit_duplicated,
    "fix_elec_shape": fix_elec_shape,
    "fix_elec_drop_feature": fix_elec_drop_feature,
    "fix_elec_row": fix_elec_row,
    "fix_identity": fix_identity,
    "fix_mpn_rewritten": fix_mpn_rewritten,
    "fix_template_render": fix_template_render,
    "fix_pin_rebuild": fix_pin_rebuild,
    "fix_alts_filter": fix_alts_filter,
    "fix_seo_shared": fix_seo_shared,
    "manual_review": fix_manual,
}
