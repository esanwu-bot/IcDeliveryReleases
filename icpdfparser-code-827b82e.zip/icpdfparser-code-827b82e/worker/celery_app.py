"""Celery 应用定义。broker / result backend 都用本地 Redis。"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from celery import Celery                                    # noqa: E402
from kombu import Queue                                      # noqa: E402

from app import config                                       # noqa: E402

app = Celery(
    "icpdf",
    broker=config.REDIS_URL,
    backend=config.REDIS_URL,
    include=["worker.tasks"],
)

# 队列显式声明：不声明也能跑（apply_async(queue=...) 会让 broker 自动建队列），
# 但「队列名拼错」就会变成一条永远没人消费的消息，只有到压测结束数不对才发现。
# 声明之后，名字不一致在 worker 启动时就能看出来。
# 五个队列 = 老的三段（fetch / llm / render）+ 五段链路新增的两个 CPU 段
# （preprocess 抽文本、audit 裁表核对）。顺序按链路走向排，日志里好读。
QUEUES = (
    Queue(config.FETCH_QUEUE),
    Queue(config.PREPROCESS_QUEUE),
    Queue(config.CELERY_QUEUE),
    Queue(config.AUDIT_QUEUE),
    Queue(config.RENDER_QUEUE),
)

# 任务名（不是 kind）-> 队列。dispatch.submit 会显式传 queue=，这里是第二道保险：
# 有人直接 apply_async() 不写队列时，仍然落到该去的队列，而不是默认的 llm 队列
# —— 那会让一次「切片」占住最贵的槽位。
TASK_ROUTES = {f"icpdf.{kind}": {"queue": q} for kind, q in config.TASK_QUEUE.items()}

app.conf.update(
    task_default_queue=config.CELERY_QUEUE,
    task_queues=QUEUES,
    task_routes=TASK_ROUTES,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    broker_connection_retry_on_startup=True,
    result_expires=7 * 24 * 3600,
    timezone="Asia/Shanghai",
    enable_utc=False,
    task_soft_time_limit=1800,
    task_time_limit=2400,
    # Windows 上 prefork 不可靠，默认用线程池（本链路几乎全是网络与模型等待）
    worker_pool=os.getenv("ICPDF_POOL", "threads"),
    worker_concurrency=config.LLM_WORKERS,
    worker_hijack_root_logger=False,
    # 任务被 worker 意外中断时立刻回队，而不是等 visibility_timeout
    task_reject_on_worker_lost=True,
    # acks_late 下 unacked 消息的可见性超时：必须大于单个型号的最长解析时间
    # （实测最慢 558s），否则会被重复投递给另一个 worker，白烧 token。
    broker_transport_options={"visibility_timeout": 1800},
)

# QC 回归 beat：每日 03:30 跑 qc_regression 11 件夹具（ICPDF_QC_BEAT=1 开启）。
# 走 render 队列（本地 PyMuPDF CPU 任务），fetch/llm 队列零新增。
if config.QC_BEAT:
    from celery.schedules import crontab

    app.conf.beat_schedule = {
        "qc-regression-daily": {
            "task": "icpdf.qc_regression_tick",
            "schedule": crontab(hour=3, minute=30),
            "options": {"queue": config.RENDER_QUEUE},
        },
    }
