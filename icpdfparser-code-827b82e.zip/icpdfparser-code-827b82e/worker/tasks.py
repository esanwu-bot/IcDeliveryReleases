"""Celery 任务：每个任务都是一个纯函数 + 一层 @app.task 包装。

纯函数放在 FUNCS 里，Redis 不可用时工作台会用线程池直接调它们（降级模式），
所以两条执行路径的行为必须完全一致。
"""
from __future__ import annotations

import contextlib
import json
import os
import sys
import time
import traceback

from app import config, db
from app.services import catalog_index, dispatch, images, packager, pipeline
from worker.celery_app import app


# ---------------------------------------------------------------- 纯函数
def parse_item(mpn_key: str, force: bool = False, manual_url: str = "") -> dict:
    """兼容入口：单进程顺序跑完 fetch->llm->render 全链路（旧队列消息 / 降级模式）。"""
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))
    if not item:
        return {"ok": False, "reason": "not_found"}
    # 这里刻意不再写 "queued"：状态由 `fetch_stage` 里的原子领取推进，
    # 抢在它前面写一次会把 done 踩掉（去重判据就再也看不到 done 了）。
    try:
        return pipeline.run_item(item, force=force, manual_url=manual_url)
    except Exception as e:                                       # noqa: BLE001
        db.touch_status(item["id"], "failed", "任务异常", 100,
                        f"{type(e).__name__}: {e}")
        db.add_event("任务异常", kind="error", item_id=item["id"],
                     detail=traceback.format_exc()[-3000:])
        return {"ok": False, "reason": "exception", "error": str(e)}


def fetch_item(mpn_key: str, force: bool = False, manual_url: str = "") -> dict:
    """L1 槽位分离·阶段1：采集+下载（fetch 队列，高并发纯网络 IO）。

    成功后投递 llm_item 接力；失败/去重跳过即终态，不往下游投。
    """
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))
    if not item:
        return {"ok": False, "reason": "not_found"}
    # 这里不许先改状态：`fetch_stage` 的去重判据读的是上面这个快照，
    # 一旦抢在它前面写 "queued"，done 就被降级，下一次投递会真的重下一遍。
    # 「已入队」由 API 投递处（routes._queue / reparse）写，worker 已经在跑了。
    try:
        r = pipeline.fetch_stage(item, force=force, manual_url=manual_url)
    except Exception as e:                                       # noqa: BLE001
        db.touch_status(item["id"], "failed", "下载阶段异常", 100, f"{type(e).__name__}: {e}")
        db.add_event("下载阶段异常", kind="error", item_id=item["id"],
                     detail=traceback.format_exc()[-3000:])
        return {"ok": False, "reason": "exception", "error": str(e)}
    if r.get("ok") and not r.get("skipped"):
        # 唯一的灰度和分叉点：V2 关着就走老单链，开着才多两步（切片 / 复核）。
        # 这里刻意只改「接力给谁」，下载逻辑一行没动 —— 回滚开关就能退回老路径。
        dispatch.submit("preprocess_item" if config.PIPELINE_V2 else "llm_item", mpn_key)
    return r


def llm_item(mpn_key: str) -> dict:
    """L1 槽位分离·阶段2：LLM 解析（llm 队列，贵槽位只干模型调用）。"""
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))
    if not item:
        return {"ok": False, "reason": "not_found"}
    if not item.get("pdf_path") or not config.resolve_artifact(item["pdf_path"], config.PDFS).exists():
        db.touch_status(item["id"], "failed", "PDF 缺失", 100, "fetch 阶段未产出 PDF")
        return {"ok": False, "reason": "no_pdf"}
    try:
        r = pipeline.llm_stage(item)
    except Exception as e:                                       # noqa: BLE001
        db.touch_status(item["id"], "failed", "解析阶段异常", 100, f"{type(e).__name__}: {e}")
        db.add_event("解析阶段异常", kind="error", item_id=item["id"],
                     detail=traceback.format_exc()[-3000:])
        return {"ok": False, "reason": "exception", "error": str(e)}
    if r.get("ok"):
        dispatch.submit("render_item", mpn_key)
    return r


def render_item(mpn_key: str) -> dict:
    """L1 槽位分离·阶段3：交付物料渲染（render 队列，本地产物）。"""
    item = db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))
    if not item:
        return {"ok": False, "reason": "not_found"}
    if not item.get("json_path"):
        return {"ok": False, "reason": "no_json"}       # 不改状态：llm 未产出，等重跑
    try:
        doc = json.loads(config.resolve_artifact(item["json_path"], config.PARSED)
                         .read_text(encoding="utf-8"))
        return pipeline.finish_item(item, doc)
    except Exception as e:                                       # noqa: BLE001
        db.touch_status(item["id"], "failed", "渲染阶段异常", 100, f"{type(e).__name__}: {e}")
        db.add_event("渲染阶段异常", kind="error", item_id=item["id"],
                     detail=traceback.format_exc()[-3000:])
        return {"ok": False, "reason": "exception", "error": str(e)}


# ---------------------------------------------------------------- 五段链路（V2）
#
# 旧链：fetch_item -> llm_item -> render_item
# 新链：fetch_item -> preprocess_item -> llm_item_v2 -> audit_item_v2 -> render_item_v2
#
# 两条链**共用 fetch_item**，只在接力点分叉（config.PIPELINE_V2）。这样灰度回滚
# 只需要把开关拨回去，不用回滚代码。
#
# 阶段实现全部在 `app/pipeline/stages.py`，这里只做三件**接线**的事：
#   1. 把 item 行拼成 `Ctx` —— 跨进程传不了对象，切片和 JSON 都只能从磁盘读；
#   2. 把 `StageResult` 翻译回 `item` 的业务状态（工作台要看进度条和阶段文案）；
#   3. 按「成功才往下投」的语义接力下一个阶段。
# 这里**不做任何算法判断**：要不要跳过、算不算失败、JSON 长什么样，全部由阶段层
# 决定。任务层一旦开始"顺手判断一下"，就会出现两套口径。
#
# `app.pipeline` 全部惰性 import：V2 关着的时候，worker 进程的导入面和接线前
# 完全一样，不会因为多了这条链路而多加载 PyMuPDF 抽取相关的模块。


def _v2_item(mpn_key: str) -> dict | None:
    return db.q1("SELECT * FROM item WHERE mpn_key=?", (mpn_key,))


def _v2_pdf(item: dict):
    """item 行 -> 当前机器上真实存在的 PDF 路径；没有就返回 None。

    不能直接 `config.resolve_artifact(item["pdf_path"], ...)`：字段为空时它返回
    `Path("")`，而 `Path("")` 在 Python 里等于当前目录、`is_file()` 为假但
    `exists()` 为真 —— 直接传下去会让下游以为"PDF 就在这儿"，报的错全在别处。
    """
    from pathlib import Path as _P
    stored = item.get("pdf_path") or ""
    if not stored:
        return None
    p = _P(config.resolve_artifact(stored, config.PDFS))
    return p if p.is_file() else None


def _v2_ctx(item: dict):
    """item 行 -> 阶段层 `Ctx`。"""
    from app.pipeline import stages as ST
    return ST.Ctx(
        mpn=str(item.get("mpn") or ""),
        mpn_key=str(item.get("mpn_key") or ""),
        pdf_path=_v2_pdf(item),
        pdf_sha256=str(item.get("pdf_sha256") or ""),
        url=str(item.get("pdf_url") or ""),
        item=item,
    )


def _v2_json(item: dict):
    """item 行里已落库的 JSON 路径（存在才算）。"""
    from pathlib import Path as _P
    stored = item.get("json_path") or ""
    if not stored:
        return None, ""
    p = _P(config.resolve_artifact(stored, config.PARSED))
    return (p if p.is_file() else None), str(p)


def _v2_attach_slice(ctx) -> bool:
    """把磁盘上的切片挂到 ctx 上。找不到就返回 False，**不在这里重抽**。

    为什么不在 LLM 阶段偷偷重抽：那会绕过 preprocess 的阶段账（`pipeline_stage`
    里就没有这一行的 attempts/产物），事后查"这份切片是哪次抽的"就查不到。
    缺切片的正确处置是让调度方补投 preprocess_item。
    """
    from app.pipeline import slice_store as SS
    if ctx.pdf_path is None:
        return False
    sha = ctx.pdf_sha256
    if not sha:
        import parse_datasheets as pd                       # noqa: PLC0415
        sha = pd.sha256(ctx.pdf_path)
        ctx.pdf_sha256 = sha
    slc = SS.find_slice(ctx.mpn, sha, root=ctx.slice_root)
    if slc is None:
        return False
    ctx.slice = slc
    return True


def _v2_out(res, next_: str = "") -> dict:
    return {"ok": res.ok, "stage": res.stage, "status": res.status,
            "idem_key": res.idem_key, "ms": res.ms, "error": res.error,
            "detail": dict(res.detail or {}), "next": next_}


def _v2_settle(item: dict, res) -> None:
    """阶段停住了 -> 把业务态写成对应的终态。

    映射规则（与老链保持一致，不新造状态）：
      skipped  -> `skipped`（不是 datasheet，链路到此为止）
      blocked  -> `failed` （缺前置/需 OCR；老链这种情况也是 failed + 原因）
      failed   -> `failed`
    """
    from app.pipeline import contracts as C
    st = "skipped" if res.status == C.STATUS_SKIPPED else "failed"
    label = C.STAGE_LABELS.get(res.stage, res.stage)
    db.touch_status(item["id"], st, f"{label}未通过", 100, (res.error or "")[:2000])
    db.add_event(f"{label}终止：{res.status}", kind="error" if st == "failed" else "skip",
                 item_id=item["id"], detail=(res.error or "")[:2000])


def _v2_begin(item: dict, res) -> None:
    """阶段跑完 -> 落一条事件（事件流是事后复盘链路唯一的时序证据）。"""
    from app.pipeline import contracts as C
    label = C.STAGE_LABELS.get(res.stage, res.stage)
    db.add_event(f"{label}完成：{res.status} {res.ms}ms", kind="stage",
                 item_id=item["id"],
                 detail=json.dumps(res.detail or {}, ensure_ascii=False)[:2000])


def preprocess_item(mpn_key: str) -> dict:
    """五段链路·阶段2：PDF -> 文本切片（preprocess 队列，纯 CPU）。"""
    item = _v2_item(mpn_key)
    if not item:
        return {"ok": False, "reason": "not_found"}
    from app.pipeline import stages as ST
    ctx = _v2_ctx(item)
    if ctx.pdf_path is None:
        db.touch_status(item["id"], "failed", "PDF 缺失", 100, "preprocess 阶段未取到 PDF")
        return {"ok": False, "stage": "preprocess", "status": "blocked", "reason": "no_pdf"}
    db.touch_status(item["id"], "parsing", "文本切片", 38)
    res = ST.stage_preprocess(ctx)
    _v2_begin(item, res)
    if res.stopped:
        _v2_settle(item, res)
        return _v2_out(res)
    db.touch_status(item["id"], "parsing", "切片完成，等待模型解析", 42)
    dispatch.submit("llm_item_v2", mpn_key)
    return _v2_out(res, "llm_item_v2")


def llm_item_v2(mpn_key: str) -> dict:
    """五段链路·阶段3：模型解析（llm 队列，贵槽位）。

    与老 `llm_item` 的区别只有一个：文本**来自已落盘的切片**，不再现抽。
    模型、prompt、校验、修复全部还是 `pipeline.parse_pdf()` 那一份实现。
    """
    item = _v2_item(mpn_key)
    if not item:
        return {"ok": False, "reason": "not_found"}
    from app.pipeline import contracts as C
    from app.pipeline import stages as ST
    ctx = _v2_ctx(item)
    if ctx.pdf_path is None:
        db.touch_status(item["id"], "failed", "PDF 缺失", 100, "llm 阶段未取到 PDF")
        return {"ok": False, "stage": "llm", "status": "blocked", "reason": "no_pdf"}
    if not _v2_attach_slice(ctx):
        db.touch_status(item["id"], "failed", "缺少切片", 100,
                        "preprocess 未产出切片；请补投 preprocess_item")
        return {"ok": False, "stage": "llm", "status": "blocked", "reason": "no_slice"}
    db.touch_status(item["id"], "parsing", "LLM 解析 PDF", 45)
    res = ST.stage_llm(ctx)
    _v2_begin(item, res)
    if res.stopped:
        _v2_settle(item, res)
        return _v2_out(res)
    # JSON 路径必须落库：下游 audit/render 是**另一个进程**，只能从 item 行拿。
    # 但 `parse_ms` / `parse_count` 只在**真的调了模型**时更新：缓存命中写成一次
    # 24ms 的解析，会把「解析次数」和「解析耗时」两个指标同时做假 —— 而灰度期
    # 恰恰是靠这两个数判断有没有重复烧 token。
    if ctx.json_path:
        fields: dict = {"json_path": ctx.json_path}
        if res.status == C.STATUS_OK:
            fields.update(parse_ms=res.ms, last_parsed_at=db.now(),
                          parse_count=(item.get("parse_count") or 0) + 1)
        db.set_item(item["id"], **fields)
    db.touch_status(item["id"], "rendering", "解析完成，等待确定性复核", 60)
    dispatch.submit("audit_item_v2", mpn_key)
    return _v2_out(res, "audit_item_v2")


@contextlib.contextmanager
def _qc_stdout_guard():
    """让 `qc/table_audit.py` 能在 Celery 进程里被 import。

    `table_audit` 在**模块级**把 `sys.stdout` 重包成 UTF-8 的 `TextIOWrapper`，
    需要 `sys.stdout.buffer`；而 Celery 默认把 stdout 换成 `LoggingProxy`
    （没有 buffer），于是 import 就 `AttributeError: 'LoggingProxy' object has
    no attribute 'buffer'` —— 这不是审计逻辑的问题，是运行环境的问题。
    实测这就是五段链路第一次跑 audit 段失败的唯一原因。

    三个选项与取舍：
      · 改 `qc/table_audit.py` 的输出层：它同时服务工作台 / 命令行 / 批处理，
        风险外溢；而且 `qc/` 当前有别人未提交的改动，这轮不该碰。
      · 关掉 Celery 的 stdouts 重定向：所有任务的 print 立刻消失，日志没法看。
      · 局部补一个带 buffer 的 stdout，用完换回：影响面只有这一次审计调用。
    取第三个：审计阶段的 stdout 只是诊断噪声，丢进 BytesIO 不影响任何判定。
    """
    import io as _io                                        # noqa: PLC0415
    old = sys.stdout
    if getattr(old, "buffer", None) is None:
        sys.stdout = _io.TextIOWrapper(_io.BytesIO(), encoding="utf-8",
                                       errors="replace", line_buffering=True)
    try:
        yield
    finally:
        sys.stdout = old


def audit_item_v2(mpn_key: str) -> dict:
    """五段链路·阶段4：确定性表格复核（audit 队列，纯 CPU，只取证不改 JSON）。

    `write` 恒为 False —— 链路自动打补丁会让「模型输出」与「机检修正后」两种
    JSON 混在一起，事后无法区分哪条结论是模型给的、哪条是规则改的。
    双 Qwen 的事实级复核留到 Phase 1.8；`fact_status_sync` 会改 JSON，同属算法
    变更，本次接线不接。
    """
    item = _v2_item(mpn_key)
    if not item:
        return {"ok": False, "reason": "not_found"}
    from app.pipeline import stages as ST
    ctx = _v2_ctx(item)
    jp, jp_str = _v2_json(item)
    if jp is None:
        db.touch_status(item["id"], "failed", "缺少解析结果", 100, "llm 阶段未产出 JSON")
        return {"ok": False, "stage": "audit", "status": "blocked", "reason": "no_json"}
    ctx.json_path = jp_str
    db.touch_status(item["id"], "rendering", "确定性复核", 68)
    with _qc_stdout_guard():
        res = ST.stage_audit(ctx)
    _v2_begin(item, res)
    if res.stopped:
        _v2_settle(item, res)
        return _v2_out(res)
    dispatch.submit("render_item_v2", mpn_key)
    return _v2_out(res, "render_item_v2")


def render_item_v2(mpn_key: str) -> dict:
    """五段链路·阶段5：交付物料渲染（render 队列，本地产物）。"""
    item = _v2_item(mpn_key)
    if not item:
        return {"ok": False, "reason": "not_found"}
    from app.pipeline import contracts as C
    from app.pipeline import stages as ST
    ctx = _v2_ctx(item)
    jp, jp_str = _v2_json(item)
    if jp is None:
        # 不改状态：llm 未产出，等重跑（与老 render_item 同一处置）
        return {"ok": False, "stage": "render", "status": "blocked", "reason": "no_json"}
    ctx.json_path = jp_str
    db.touch_status(item["id"], "rendering", "生成交付物料", 72)
    res = ST.stage_render(ctx)
    _v2_begin(item, res)
    if res.status == C.STATUS_CACHED:
        # 缓存命中 = 这次没跑 `finish_item`，而 `done` 恰恰是它在结尾写的。
        # 不补这一下，一件已经交付完的货会因为一条重复消息停在 `rendering`：
        # 工作台上看起来像卡住了，统计里则少一件已完成。
        # 缓存判据本身已经核过产物文件存在，这里写 done 不是假装成功。
        db.touch_status(item["id"], "done", "交付物已生成（缓存命中）", 100)
    if res.stopped:
        _v2_settle(item, res)
    return _v2_out(res)


def parse_many(mpn_keys: list[str], force: bool = False) -> dict:
    ok = fail = 0
    for k in mpn_keys:
        r = parse_item(k, force=force)
        ok += 1 if r.get("ok") else 0
        fail += 0 if r.get("ok") else 1
    return {"ok": ok, "failed": fail, "total": len(mpn_keys)}


def build_catalog(batch_id: int, path: str) -> dict:
    def progress(pct: int, msg: str) -> None:
        db.x("UPDATE batch SET progress=?, note=? WHERE id=?", (pct, msg, batch_id))

    try:
        db.x("UPDATE batch SET status='running', progress=1, note='开始建索引' WHERE id=?", (batch_id,))
        info = catalog_index.build_catalog(Path(path), progress=progress)
        db.x("UPDATE batch SET status='ready', progress=100, note=? WHERE id=?",
             (f"索引 {info['unique']:,} 条 / {info['secs']}s", batch_id))
        db.add_event(f"内链索引重建完成：{info['unique']:,} 条", kind="catalog", batch_id=batch_id)
        return info
    except Exception as e:                                       # noqa: BLE001
        db.x("UPDATE batch SET status='failed', note=? WHERE id=?", (str(e)[:400], batch_id))
        db.add_event("内链索引重建失败", kind="error", batch_id=batch_id,
                     detail=traceback.format_exc()[-3000:])
        return {"ok": False, "error": str(e)}


def import_images(batch_id: int, path: str) -> dict:
    try:
        info = images.import_table(Path(path), batch_id=batch_id)
        db.x("UPDATE batch SET status='ready', progress=100, note=? WHERE id=?",
             (f"{info['categories']} 类", batch_id))
        return info
    except Exception as e:                                       # noqa: BLE001
        db.x("UPDATE batch SET status='failed', note=? WHERE id=?", (str(e)[:400], batch_id))
        db.add_event("图片命名表导入失败", kind="error", batch_id=batch_id, detail=str(e))
        return {"ok": False, "error": str(e)}


def export_batch(batch_id: int, name: str = "") -> dict:
    b = db.q1("SELECT * FROM batch WHERE id=?", (batch_id,))
    label = name or (b["filename"] if b else f"batch{batch_id}")
    p = packager.zip_batch(batch_id, label)
    db.kv_set(f"export:batch:{batch_id}", json.dumps({"path": str(p), "at": db.now()}))
    db.add_event(f"批次导出 {p.name}", kind="export", batch_id=batch_id)
    return {"path": str(p), "bytes": p.stat().st_size}


# ---------------------------------------------------------------- QC（质量审计）
def _qc_action(kind: str, tool: str = "table_audit") -> str:
    """finding kind -> 台账处置：badge 只标不改；unresolved 不猜；其余确定性覆盖。"""
    if tool == "lint":
        return "debt(render)"
    if kind == "identity_unverified":
        return "badge"
    if kind.endswith("unresolved"):
        return "unresolved"
    return "patched"


def _qc_log_finding(run_id: int, mpn: str, f: dict, tool: str, operator: str) -> None:
    """qc_finding + qc_audit_log 双写（append-only，只 INSERT）。"""
    act = _qc_action(f["kind"], tool)
    jv = json.dumps(f.get("json"), ensure_ascii=False)
    tv = json.dumps(f.get("table"), ensure_ascii=False)
    db.x("INSERT INTO qc_finding(run_id,mpn,kind,path,json_val,table_val,action,tool,created_at) "
         "VALUES(?,?,?,?,?,?,?,?,?)",
         (run_id, mpn, f["kind"], f.get("path", ""), jv, tv, act, tool, db.qc_now()))
    db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,tool,operator,created_at) "
         "VALUES(?,?,?,?,?,?,?,?,?,?)",
         (run_id, mpn, f["kind"], f.get("path", ""), jv, tv, act, tool, operator, db.qc_now()))


def _qc_run_rollup(run_id: int, *, status: str = "running") -> None:
    """一件完成后原子汇总 qc_run；全部件数完成时落终态（qc_run 是状态机，允许 UPDATE）。"""
    db.x(
        "UPDATE qc_run SET parts_done=parts_done+1,"
        " findings=(SELECT count(*) FROM qc_finding WHERE run_id=?1),"
        " patched=(SELECT count(*) FROM qc_finding WHERE run_id=?1 AND action='patched'),"
        " unresolved=(SELECT count(*) FROM qc_finding WHERE run_id=?1 AND action='unresolved'),"
        " duration_s=CAST((julianday('now','localtime')-julianday(created_at))*86400 AS REAL),"
        " status=CASE WHEN parts_done+1>=parts THEN"
        "   CASE WHEN ?2<>'running' THEN ?2"
        "        WHEN EXISTS(SELECT 1 FROM qc_audit_log WHERE run_id=?1"
        "                   AND action='missing' AND kind<>'part_missing') THEN 'fail'"
        "        WHEN EXISTS(SELECT 1 FROM qc_audit_log WHERE run_id=?1 AND kind='part_missing')"
        "             AND parts_done+1=(SELECT count(*) FROM qc_audit_log WHERE run_id=?1"
        "                               AND kind='part_missing') THEN 'missing'"
        "        ELSE 'ok' END"
        " ELSE status END "
        "WHERE id=?1", (run_id, status))


def qc_audit_item(mpn: str, run_id: int = 0, write: bool = False,
                  scope: str = "facts", operator: str = "auto") -> dict:
    """单件确定性表格复核审计：包装 qc/table_audit.py。

    dry 默认（write=False 只出报告）；write=True 时备份 .pre_audit 后写回补丁，
    并按客户约束只投 render_item 重渲染（不重解 PDF）。qc 延迟 import，
    避免工作台进程加载时被 qc 工具箱的 stdout 包装器接管。
    """
    from qc import table_audit as TA
    from qc import qc_regression as QR
    from app.services import parts as parts_svc

    if not run_id:
        run_id = db.x("INSERT INTO qc_run(mode,scope,dry,parts,status,operator,created_at) "
                      "VALUES('single',?,?,1,'running',?,?)",
                      (scope, 0 if write else 1, operator, db.qc_now()))
    try:
        loc = TA.locate_paths(mpn)
        if not loc:
            db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,"
                 "tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                 (run_id, mpn, "part_missing", "-", "-", "-", "missing", "table_audit",
                  operator, db.qc_now()))
            _qc_run_rollup(run_id, status="missing")
            return {"mpn": mpn, "status": "missing"}
        doc = json.loads(__import__("pathlib").Path(loc["json"]).read_text(encoding="utf-8"))
        res = TA.audit_json(doc, loc["pdf"], write=write,
                            requested=loc["requested"], src_json=loc["json"])
        for f in res["findings"]:
            _qc_log_finding(run_id, loc["requested"], f, "table_audit", operator)
        if "render" in (scope or ""):                 # 渲染层 lint 债务也进台账
            for l in QR.lint_txt(loc["requested"]):
                _qc_log_finding(run_id, loc["requested"], l, "lint", operator)
        n = len(res["findings"])
        if write and "render" in (scope or ""):       # 补丁后只重渲染，不碰 fetch/llm
            dispatch.submit("render_item", parts_svc.key_of(loc["requested"]))
        _qc_run_rollup(run_id)
        return {"mpn": loc["requested"], "findings": n, "write": bool(write)}
    except Exception as e:                            # noqa: BLE001
        db.add_event(f"QC 审计异常 {mpn}", kind="error", detail=traceback.format_exc()[-3000:])
        db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,"
             "tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
             (run_id, mpn, "audit_error", "-", "-", str(e)[:400], "missing", "table_audit",
              operator, db.qc_now()))
        _qc_run_rollup(run_id, status="fail")
        return {"mpn": mpn, "status": "error", "error": str(e)}


def qc_regression_tick(run_id: int = 0, write: bool = False,
                       operator: str = "beat(03:30)", extra: str = "",
                       post: bool = False) -> dict:
    """11 件回归夹具：subprocess 跑 qc/qc_regression.py，逐件落台账，红绿即状态。

    beat 每日 03:30（ICPDF_QC_BEAT=1）自动触发；也可由工作台手动投递。
    extra：反馈闭环导出的附加夹具（data/qc/regression_fixtures.json），与基础夹具合并跑；
    post：修补后复验口径（期望缺陷已消失，防回归）。
    """
    import subprocess
    import sys as _sys

    if not run_id:
        run_id = db.x("INSERT INTO qc_run(mode,scope,dry,parts,status,operator,created_at) "
                      "VALUES('regression',?,?,11,'running',?,?)",
                      ("facts", 0 if write else 1, operator, db.qc_now()))
    cmd = [_sys.executable, "-u", str(config.ROOT / "qc" / "qc_regression.py")]
    if write:
        cmd.append("--write")
    if extra:
        cmd += ["--extra", extra]
    if post:
        cmd.append("--post")
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=str(config.ROOT), timeout=1200)
        out = p.stdout or ""
    except Exception as e:                             # noqa: BLE001
        db.add_event("QC 回归执行异常", kind="error", detail=traceback.format_exc()[-3000:])
        db.x("UPDATE qc_run SET parts_done=parts, status='fail', duration_s=0 WHERE id=?", (run_id,))
        return {"exit": -1, "error": str(e)}
    import re as _re
    fails = 0
    parsed = 0
    for m in _re.finditer(r"^\[(.+?)\] (PASS|FAIL|MISSING) (.*)$", out, _re.M):
        parsed += 1
        mpn, verdict, rest = m.group(1), m.group(2).lower(), m.group(3)
        fails += verdict != "pass"
        db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,action,"
             "tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
             (run_id, mpn, "regression", "-", rest[:600], "-", verdict,
              "qc_regression", operator, db.qc_now()))
    if not parsed:                                     # 子进程没跑起来（如 stdout 崩溃）：不许空转判 ok
        db.add_event("QC 回归无输出", kind="error", detail=(p.stderr or "")[-1500:])
        db.x("UPDATE qc_run SET parts_done=parts, status='fail', "
             "duration_s=CAST((julianday('now','localtime')-julianday(created_at))*86400 AS REAL) "
             "WHERE id=?", (run_id,))
        return {"exit": p.returncode, "fails": 0, "tail": (p.stderr or "")[-800:]}
    if fails:
        db.x("UPDATE qc_run SET parts_done=parts, status='fail', unresolved=?, "
             "duration_s=CAST((julianday('now','localtime')-julianday(created_at))*86400 AS REAL) "
             "WHERE id=?", (fails, run_id))
    else:
        db.x("UPDATE qc_run SET parts_done=parts, status='ok', "
             "duration_s=CAST((julianday('now','localtime')-julianday(created_at))*86400 AS REAL) "
             "WHERE id=?", (run_id,))
    rd = config.DATA / "qc"
    if rd.exists():
        reps = sorted(rd.glob("regression-*.json"), key=lambda x: x.stat().st_mtime)
        if reps:
            db.x("UPDATE qc_run SET report_path=? WHERE id=?", (str(reps[-1]), run_id))
    return {"exit": p.returncode, "fails": fails, "tail": out[-800:]}


# ================================================================ 自动修复闭环
#
# 编排：review_item → fix_dispatch（生成 plan）→ fix_apply（逐 action 执行）
#        → render_item（重渲染）→ fix_finalize（round+1 重审 / 超轮次转人工）
#
# 三道硬闸（都不依赖调用方自觉）：
#   1. allowed_paths 白名单：fixer 改了白名单外的路径 → PermissionError → 整次作废；
#   2. 轮次上限 FIX_MAX_ROUNDS：到顶不再自动修，转 customer_feedback 交人工；
#   3. preflight 备份：每次动手前把 json + 同名产物复制到 data/qc/fix_backups/。

# kind → (fixer, 允许改的路径, 前置条件, 是否需要 PDF 文本)
# 这张表是「针对性处理」的落点：不在这里的 kind 一律人工，不猜。
ACTION_TEMPLATES = {
    # 纯确定性：展示层转义，改哪都不影响数值语义
    "double_escape_multi": dict(worker="fix_escape", allowed=["*"], pre=[]),
    "escape_entity_in_json": dict(worker="fix_escape", allowed=["*"], pre=[]),
    "unit_duplicated": dict(worker="fix_unit_duplicated",
                            allowed=["specs.electrical"], pre=[]),
    # 形状：缺字段补 not_specified，不编数值
    "electrical_field_missing": dict(worker="fix_elec_shape",
                                     allowed=["specs.electrical"], pre=[]),
    # Features 条目混入电气表：移出并挂 metadata.elec_dropped_features 留证据
    "electrical_like_feature": dict(worker="fix_elec_drop_feature",
                                    allowed=["specs.electrical",
                                             "metadata.elec_dropped_features"],
                                    pre=[]),
    # condition 类：只改 condition，且要有 PDF 原文
    "unit_dimension": dict(worker="fix_elec_row",
                           allowed=["specs.electrical"], pre=[], needs_pdf=True),
    "electrical_condition_leak": dict(worker="fix_elec_row",
                                      allowed=["specs.electrical"], pre=[],
                                      needs_pdf=True),
    "row_mispair": dict(worker="fix_elec_row",
                        allowed=["specs.electrical"], pre=[], needs_pdf=True),
    # 模板层：不改本件 JSON，只重渲染
    "hero_overview_duplicate": dict(worker="fix_template_render", allowed=[], pre=[]),
    "features_boilerplate": dict(worker="fix_template_render", allowed=[], pre=[]),
    "faq_boilerplate": dict(worker="fix_template_render", allowed=[], pre=[]),
    # 身份：判板 + 清芯片封装 + 标引脚归属
    "identity_board_unresolved": dict(worker="fix_identity",
                                      allowed=["basic_info.identity",
                                               "basic_info.device_mpn",
                                               "basic_info.datasheet_scope",
                                               "specs.package.type",
                                               "specs.package.original_type"],
                                      pre=[]),
    # 身份待核验/冲突/证据不全：一律不自动改身份，交人工（docs/规则库落地参考.md）
    "identity_review": dict(worker="manual_review", allowed=[], pre=["human_accept"]),
    "identity_conflict": dict(worker="manual_review", allowed=[], pre=["human_accept"]),
    "identity_evidence_incomplete": dict(worker="manual_review", allowed=[],
                                          pre=["human_accept"]),
    # 板卡证据已在 datasheet 里（BOARD_CONFIRMED）却没标 identity：可以确定性修
    "board_confirmed_unmarked": dict(worker="fix_identity",
                                     allowed=["basic_info.identity",
                                              "basic_info.device_mpn",
                                              "basic_info.datasheet_scope",
                                              "specs.package.type",
                                              "specs.package.original_type"],
                                     pre=[]),
    # 替代料 JSON 里的 miss 行 / SEO 共享图标注：数据层确定性修
    "alts_json_has_miss": dict(worker="fix_alts_filter", allowed=[], pre=[]),
    "seo_shared_icon_unmarked": dict(worker="fix_seo_shared", allowed=[], pre=[]),
    # 渲染层 sentinel 泄露：只重渲染（json 里的 not_specified 是库内正确口径）
    "sentinel_leaked_to_copy": dict(worker="fix_template_render", allowed=[], pre=[]),
    "board_identity_missing": dict(worker="fix_identity",
                                   allowed=["basic_info.identity",
                                            "basic_info.device_mpn",
                                            "basic_info.datasheet_scope",
                                            "specs.package.type",
                                            "specs.package.original_type"],
                                   pre=[]),
    "board_package_mismatch": dict(worker="fix_identity",
                                   allowed=["basic_info.identity",
                                            "basic_info.device_mpn",
                                            "specs.package.type",
                                            "specs.package.original_type",
                                            "pin_configuration.*.device_scope"],
                                   pre=[]),
    "mpn_rewritten": dict(worker="fix_mpn_rewritten",
                          allowed=["basic_info.mpn", "basic_info.device_mpn",
                                   "basic_info.identity"],
                          pre=[]),
    # 需重抽表：保守版（脚数对得上 + 差异显著才接受）
    "pin_mismatch": dict(worker="fix_pin_rebuild",
                         allowed=["pin_configuration"],
                         pre=["identity_resolved"], needs_pdf=True),
    # 差分对错位：整组脚号与名字顺序不一致，唯一确定解是从 PDF 引脚表重建；
    # 同样走保守闸（脚数对得上 + 差异显著），拿不到 PDF 原文就交人工
    "pin_pair_broken": dict(worker="fix_pin_rebuild",
                            allowed=["pin_configuration"],
                            pre=["identity_resolved"], needs_pdf=True),
    # 引脚编号超界/重复：16 脚封装出现 17 号脚，说明重建把行数撑爆了。
    # 自动重建正是元凶之一，不能再自动跑一遍——必须人工对 PDF 引脚表核对。
    "pin_count_mismatch": dict(worker="manual_review", allowed=[], pre=[]),
    # 值级 / 身份未核实：一律人工，绝不自动改
    "package_mismatch": dict(worker="manual_review", allowed=[], pre=[]),
    "identity_unverified": dict(worker="manual_review", allowed=[], pre=[]),
    "i18n_english_residue": dict(worker="manual_review", allowed=[], pre=[]),
    # 只有单侧极性：可能本来就是单端信号，改错代价高于不改，交人工
    "pin_polarity_missing": dict(worker="manual_review", allowed=[], pre=[]),
    # 符号页「工程模型边界」：文案 / 几何 / 状态三者不一致。
    # 修法不是改文案（文案是 derive_state 的派生物），而是先定状态来源——
    # 球阵几何要可信来源、板卡身份要核验、模板要签核，全属人工裁决，故一律 manual。
    "symbol_page_geometry_unsupported": dict(worker="manual_review", allowed=[],
                                             pre=["human_accept"]),
    "symbol_page_3d_node_without_state": dict(worker="manual_review", allowed=[],
                                              pre=["human_accept"]),
    "symbol_page_outline_text_conflict": dict(worker="manual_review", allowed=[],
                                              pre=["human_accept"]),
    "symbol_page_board_state_mismatch": dict(worker="manual_review", allowed=[],
                                             pre=["human_accept"]),
    "symbol_page_boundary_text_drift": dict(worker="manual_review", allowed=[],
                                            pre=["human_accept"]),
}

SEV_ORDER = {"P0": 0, "P1": 1, "P2": 2}

_KIND_CATEGORY = {
    "identity_board_unresolved": "IDENTITY_PACKAGE",
    "board_identity_missing": "IDENTITY_PACKAGE",
    "board_package_mismatch": "IDENTITY_PACKAGE",
    "package_mismatch": "IDENTITY_PACKAGE",
    "mpn_rewritten": "IDENTITY_PACKAGE",
    "electrical_field_missing": "ELECTRICAL_TABLE",
    "electrical_like_feature": "ELECTRICAL_TABLE",
    "unit_duplicated": "ELECTRICAL_TABLE",
    "unit_dimension": "ELECTRICAL_TABLE",
    "electrical_condition_leak": "ELECTRICAL_TABLE",
    "row_mispair": "ELECTRICAL_TABLE",
    "pin_mismatch": "PIN_MAPPING",
    "pin_pair_broken": "PIN_MAPPING",
    "pin_polarity_missing": "PIN_MAPPING",
    # 2026-10-29 补：有 action 模板但没进映射，转人工时会落到 OTHER 兜底类别
    "pin_count_mismatch": "PIN_MAPPING",
    "i18n_english_residue": "TRANSLATION",
    "hero_overview_duplicate": "DUPLICATE_CONTENT",
    "features_boilerplate": "DUPLICATE_CONTENT",
    "faq_boilerplate": "DUPLICATE_CONTENT",
    "double_escape_multi": "RENDER_ASSET",
    "escape_entity_in_json": "RENDER_ASSET",
    # 符号页工程模型边界：页面与状态不一致，归渲染/资源类
    "symbol_page_geometry_unsupported": "RENDER_ASSET",
    "symbol_page_3d_node_without_state": "RENDER_ASSET",
    "symbol_page_outline_text_conflict": "RENDER_ASSET",
    "symbol_page_board_state_mismatch": "RENDER_ASSET",
    "symbol_page_boundary_text_drift": "RENDER_ASSET",
}


def _fix_plans_dir() -> "object":
    d = config.DATA / "qc" / "fix_plans"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _safe(mpn: str) -> str:
    import re as _re
    return _re.sub(r"[^A-Za-z0-9._-]", "_", str(mpn or "")).upper()


def _now_iso() -> str:
    from datetime import datetime
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _write_plan(path, plan: dict) -> None:
    """原子写（先写临时文件再替换），避免并发读到半个 plan。"""
    from pathlib import Path as _P
    p = _P(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def _read_plan(path) -> dict:
    from pathlib import Path as _P
    p = _P(path)
    if not p.is_file():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


@contextlib.contextmanager
def _plan_lock(path, timeout: float = 30.0):
    """跨进程独占锁（O_CREAT|O_EXCL 落 sidecar 文件，Linux/Windows 同一套）。

    为什么必须锁：`fix_dispatch` 会把 8 个 ready action 一次性投出去，worker 是
    多进程/多线程并发执行的。每个 `fix_apply` 原来是「读 plan → 改自己那条 →
    整份写回」，后写的人用旧快照覆盖前写的人——实测 TMDXDOCK28377D 的 A1/A4/A9
    明明 apply 成功了，plan 里却回退成 pending，于是「全部终结」永远不成立、
    `fix_finalize` 不触发、重审不跑、状态停在「修了未验」。
    """
    from pathlib import Path as _P
    lp = _P(str(path) + ".lock")
    t0 = time.time()
    while True:
        try:
            fd = os.open(str(lp), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            break
        except FileExistsError:
            if time.time() - t0 > timeout:
                raise TimeoutError(f"plan lock timeout: {lp}")
            time.sleep(0.05)
    try:
        yield
    finally:
        try:
            os.unlink(str(lp))
        except OSError:
            pass


_TERMINAL = ("done", "skipped", "manual")


def _patch_action(path, action_id: str, fields: dict) -> tuple[dict, bool]:
    """在锁内「重读 → 只改指定 action → 写回」，返回 (最新 plan, 是否全部终结)。

    只合并给定字段，不动别人写进去的状态——这是并发下不丢更新的关键。
    """
    with _plan_lock(path):
        plan = _read_plan(path)
        for a in plan.get("actions") or []:
            if a.get("id") == action_id:
                a.update(fields)
                break
        _write_plan(path, plan)
        done = bool(plan.get("actions")) and all(
            a.get("status") in _TERMINAL for a in plan["actions"])
    return plan, done


def _release_blocked(path, plan: dict) -> list[str]:
    """前置条件已满足的待办动作重新投出去（原实现只投一次，被阻塞的会永远 pending）。"""
    fired: list[str] = []
    mpn = ""
    with _plan_lock(path):
        plan = _read_plan(path)
        mpn = str(plan.get("mpn") or "")
        changed = False
        for a in plan.get("actions") or []:
            if a.get("status") != "pending" or a.get("dispatched"):
                continue
            blocked, why = _blocked(a, plan.get("actions") or [])
            if blocked:
                a["note"] = why
                changed = True
                continue
            a["dispatched"] = True
            changed = True
            fired.append(a["id"])
        if changed:
            _write_plan(path, plan)
    for aid in fired:
        dispatch.submit("fix_apply", mpn, aid, str(path))
    return fired



def _append_fix_log(mpn: str, round_: int, record: dict) -> None:
    p = _fix_plans_dir() / f"{_safe(mpn)}.fix_plan.log.jsonl"
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now_iso(), "round": round_, **record},
                           ensure_ascii=False) + "\n")


def _blocked(action: dict, actions: list[dict]) -> tuple[bool, str]:
    """前置条件检查。返回 (是否阻塞, 原因)。

    identity_resolved：同 plan 里还有未完成的 fix_identity → 阻塞
                       （引脚表属于哪个器件取决于身份先定，顺序不能反）。
    """
    pres = action.get("preconditions") or []
    if "identity_resolved" in pres:
        for a in actions:
            if a.get("worker") == "fix_identity" and a.get("status") not in (
                    "done", "skipped", "manual"):
                return True, "identity_not_resolved"
    return False, ""


def _audit_fix(mpn: str, action: dict, changed: list[str],
               backup_dir: str, note: str = "") -> None:
    """自动修复的 append-only 审计（只抹 qc_audit_log，不造假 qc_run 汇总行）。

    kind=auto_fix 与 review.py 的 kind=llm_review 区分开，便于按 kind 抽检；
    operator=system:auto_fix 便于按 actor 筛出「机器自动改过的件」。
    """
    try:
        db.x("INSERT INTO qc_audit_log(run_id,mpn,kind,path,json_val,table_val,"
             "action,tool,operator,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
             (0, mpn, "auto_fix", backup_dir or "",
              json.dumps({"action_id": action.get("id"),
                          "kind": action.get("kind"),
                          "worker": action.get("worker"),
                          "severity": action.get("severity"),
                          "changed": (changed or [])[:50],
                          "note": note or ""}, ensure_ascii=False),
              "-", "fixed", "worker/fixers.py", "system:auto_fix", _now_iso()))
    except Exception:                                            # noqa: BLE001
        pass                                                     # 审计失败不阻断修复


def review_item(mpn: str, round_: int = 1, with_pdf_text: bool = False,
                force: bool | None = None, auto_fix: bool = True) -> dict:
    """审查单型号产物；verdict 非 PASS 且 auto_fix 时装自动修复。

    round_>1（修复后重审）默认 force=True 强制重算——否则会吃到上一轮的
    缓存报告，修复效果永远看不见。
    """
    from app.services import review as RV
    out_dir = config.DATA / "qc" / "reviews"
    if force is None:
        force = round_ > 1
    try:
        res = RV.run_review(db, mpn, data_dir=config.DATA, out_dir=out_dir,
                            with_pdf_text=with_pdf_text, write_db=True,
                            operator="system:auto_fix", force=force)
    except RV.ReviewError as e:
        db.add_event("审查失败", kind="error",
                     detail=f"{mpn} {e.code}: {e.message}")
        return {"ok": False, "mpn": mpn, "reason": e.code, "error": e.message}

    out = {"ok": True, "mpn": mpn, "round": round_,
           "verdict": res.get("verdict"),
           "rule": len(res.get("rule_findings") or []),
           "llm": len(res.get("llm_findings") or []),
           "cached": bool(res.get("cached"))}
    if auto_fix and res.get("verdict") in ("WARN", "FAIL"):
        dispatch.submit("fix_dispatch", mpn, round_)
        out["dispatched"] = "fix_dispatch"
    return out


def fix_dispatch(mpn: str, round_: int = 1) -> dict:
    """读 review.json → 生成 fix_plan → 只投「前置已满足」的 action。"""
    from app.services import review as RV
    out_dir = config.DATA / "qc" / "reviews"
    rj = RV.report_paths(out_dir, _safe(mpn))["json"]
    if not rj.is_file():
        return {"ok": False, "mpn": mpn, "reason": "review_json_missing"}
    review = json.loads(rj.read_text(encoding="utf-8"))

    # rule + llm 合并：同 (kind, field) 只留最严重的一条，避免重复修
    merged: dict[tuple, dict] = {}
    for f in (review.get("rule_findings") or []) + (review.get("llm_findings") or []):
        if not isinstance(f, dict):
            continue
        kind = str(f.get("kind") or "llm_finding")
        ev = f.get("evidence") or {}
        key = (kind, ev.get("field") or ev.get("field_path") or "")
        prev = merged.get(key)
        if not prev or SEV_ORDER.get(f.get("severity"), 9) < \
                SEV_ORDER.get(prev.get("severity"), 9):
            merged[key] = f
    findings = sorted(merged.values(),
                      key=lambda x: SEV_ORDER.get(x.get("severity"), 9))

    actions = []
    for i, f in enumerate(findings[:config.FIX_MAX_ACTIONS], 1):
        kind = str(f.get("kind") or "llm_finding")
        tmpl = ACTION_TEMPLATES.get(kind)
        if not tmpl:
            actions.append({"id": f"A{i}", "kind": kind,
                            "severity": f.get("severity") or "P1",
                            "evidence": f.get("evidence") or {},
                            "worker": "manual_review", "allowed_paths": [],
                            "preconditions": [], "requires_pdf_text": False,
                            "fallback": "manual_review", "status": "pending",
                            "note": "unknown_kind"})
            continue
        actions.append({
            "id": f"A{i}", "kind": kind,
            "severity": f.get("severity") or "P1",
            "evidence": f.get("evidence") or {},
            "worker": tmpl["worker"],
            "allowed_paths": tmpl["allowed"],
            "preconditions": tmpl["pre"],
            "requires_pdf_text": tmpl.get("needs_pdf", False),
            "fallback": tmpl.get("fallback"),
            "status": "pending",
        })

    plan = {"mpn": mpn, "round": round_, "review_json": str(rj),
            "verdict": review.get("verdict"), "created_at": _now_iso(),
            "max_rounds": config.FIX_MAX_ROUNDS, "actions": actions}
    pp = _fix_plans_dir() / f"{_safe(mpn)}.round{round_}.fix_plan.json"
    _write_plan(pp, plan)

    ready, blocked, manual = [], [], []
    for a in actions:
        if a["worker"] == "manual_review":
            a["status"] = "manual"
            manual.append(a["id"])
            continue
        is_blocked, why = _blocked(a, actions)
        if is_blocked:
            a["note"] = why
            blocked.append(a["id"])
            continue
        ready.append(a)

    for a in ready:
        a["dispatched"] = True          # 防 _release_blocked 重复投递
    _write_plan(pp, plan)
    for a in ready:
        dispatch.submit("fix_apply", mpn, a["id"], str(pp))
    # 一个可自动执行的都没有 → 直接进 finalize（交人工 / 重审）
    if not ready:
        dispatch.submit("fix_finalize", mpn, round_)

    _append_fix_log(mpn, round_, {"event": "dispatch", "actions": len(actions),
                                  "ready": len(ready), "blocked": len(blocked),
                                  "manual": len(manual),
                                  "verdict": review.get("verdict")})
    return {"ok": True, "mpn": mpn, "round": round_, "actions": len(actions),
            "ready": len(ready), "blocked": len(blocked), "manual": len(manual),
            "plan": str(pp)}


def fix_apply(mpn: str, action_id: str, plan_path: str) -> dict:
    """执行单个 action：三道硬闸 → fixer → 白名单校验 → 落盘 → 投下游。"""
    from pathlib import Path as _P
    from worker.fixers import FIXERS, preflight

    pp = _P(plan_path)
    if not pp.is_file():
        return {"ok": False, "reason": "plan_missing"}
    plan = _read_plan(pp)
    action = next((a for a in plan.get("actions") or [] if a.get("id") == action_id), None)
    if not action:
        return {"ok": False, "reason": "action_not_found"}
    if action.get("status") in ("done", "manual", "skipped"):
        return {"ok": True, "mpn": mpn, "action": action_id, "skipped": action["status"]}

    # 闸 1：轮次上限
    if int(plan.get("round") or 1) > config.FIX_MAX_ROUNDS:
        _append_fix_log(mpn, plan.get("round"), {
            "event": "rejected", "action_id": action_id,
            "reason": "round_exceeded"})
        dispatch.submit("fix_finalize", mpn, plan.get("round"))
        return {"ok": False, "reason": "round_exceeded"}

    # 闸 2：前置条件
    is_blocked, why = _blocked(action, plan.get("actions") or [])
    if is_blocked:
        _patch_action(pp, action_id, {"note": why})
        _append_fix_log(mpn, plan.get("round"), {
            "event": "blocked", "action_id": action_id, "reason": why})
        return {"ok": False, "reason": why, "deferred": True}

    # 闸 3：备份 + 载入（失败即人工，不硬来）
    ctx = preflight(mpn, action, plan)
    if not ctx.get("ok"):
        _patch_action(pp, action_id, {"status": "manual", "note": ctx.get("reason")})
        _append_fix_log(mpn, plan.get("round"), {
            "event": "preflight_failed", "action_id": action_id,
            "reason": ctx.get("reason")})
        dispatch.submit("fix_finalize", mpn, plan.get("round"))
        return {"ok": False, "reason": ctx.get("reason")}

    fn = FIXERS.get(action.get("worker") or "")
    if fn is None:
        _patch_action(pp, action_id, {"status": "manual", "note": "no_fixer"})
        return {"ok": False, "reason": "no_fixer"}

    import time as _t
    t0 = _t.time()
    try:
        result = fn(ctx)
    except PermissionError as e:
        # 白名单越权：这次改动直接作废（fixer 已 raise 在 commit 之前，未落盘）
        _patch_action(pp, action_id,
                      {"status": "manual", "note": f"whitelist_violation: {e}"})
        _append_fix_log(mpn, plan.get("round"), {
            "event": "whitelist_violation", "action_id": action_id,
            "error": str(e)[:200]})
        dispatch.submit("fix_finalize", mpn, plan.get("round"))
        return {"ok": False, "reason": "whitelist_violation", "error": str(e)}
    except Exception as e:                                       # noqa: BLE001
        _patch_action(pp, action_id,
                      {"status": "manual", "note": f"exception: {type(e).__name__}"})
        _append_fix_log(mpn, plan.get("round"), {
            "event": "error", "action_id": action_id,
            "error": f"{type(e).__name__}: {e}"[:300],
            "backup_dir": str(ctx.get("backup_dir") or "")})
        dispatch.submit("fix_finalize", mpn, plan.get("round"))
        return {"ok": False, "reason": "exception", "error": str(e)}

    changed = result.get("changed") or []
    status = "done" if changed else "skipped"
    note = result.get("note") or ""
    bdir = str(ctx.get("backup_dir") or "")
    _plan_now, all_terminal = _patch_action(pp, action_id, {
        "status": status, "changed": changed, "note": note, "backup_dir": bdir})
    action["status"], action["changed"] = status, changed
    action["note"], action["backup_dir"] = note, bdir

    _append_fix_log(mpn, plan.get("round"), {
        "event": "apply", "action_id": action_id, "kind": action.get("kind"),
        "worker": action.get("worker"), "changed": changed[:50],
        "note": note, "backup_dir": bdir,
        "duration_s": round(_t.time() - t0, 3)})

    # 审计台账（append-only）
    _audit_fix(mpn, action, changed, bdir, note)

    # 投下游：需要重渲染就重渲染（改了 JSON 必须重渲染，否则页面还是旧内容）
    next_task = result.get("next_task") or ""
    if next_task:
        args = (ctx.get("mpn_key") or "",) if next_task in (
            "render_item", "llm_item", "fetch_item") else (mpn,)
        dispatch.submit(next_task, *args)

    # 有动作刚解锁（如身份已定 → 引脚表才能重建）就地补投，否则它会永远 pending
    released = _release_blocked(pp, _plan_now)
    if released:
        all_terminal = False

    # 全部 action 收口 → finalize（触发 round+1 重审 / 转人工）
    if all_terminal:
        dispatch.submit("fix_finalize", mpn, plan.get("round"))

    return {"ok": True, "mpn": mpn, "action": action_id,
            "changed": changed, "note": note,
            "backup_dir": bdir, "released": released}


def _last_apply_ts(mpn: str) -> str:
    """本轮最后一次 apply 的时间戳（用于判断渲染产物是否新鲜）。"""
    p = _fix_plans_dir() / f"{_safe(mpn)}.fix_plan.log.jsonl"
    if not p.is_file():
        return ""
    last = ""
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(rec, dict) and rec.get("event") == "apply":
                last = str(rec.get("ts") or last)
    except OSError:
        return ""
    return last


def _ensure_render_fresh(mpn: str, since_ts: str) -> dict:
    """重审前确认渲染产物比修复新；不新就在本进程里同步重渲染一次。

    为什么需要这一步：`render:*` 类修复（模板层/渲染层）改的是产物、不是 JSON，
    而 `fix_apply` 投的 `render_item` 在另一个队列。直接投 `review_item` 会抢跑，
    复审读到的还是旧 txt，于是「修好了」被记成「修了仍不过」——这是会把
    「已 review 并已修复」整批清零的静默错误。宁可同步渲染一次也不让它竞态。
    """
    from datetime import datetime
    try:
        row = db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1",
                    (mpn, mpn))
    except Exception:                                            # noqa: BLE001
        return {"ok": False, "reason": "db_error"}
    if not row:
        return {"ok": False, "reason": "item_missing"}
    tp = config.resolve_artifact(row.get("txt_path") or "", config.TXT)
    if not tp.is_file():
        cand = config.TXT / ("%s.txt" % (row.get("mpn_key") or mpn))
        tp = cand if cand.is_file() else tp
    fresh = False
    if tp.is_file() and since_ts:
        try:
            m = datetime.fromtimestamp(tp.stat().st_mtime).astimezone()
            a = datetime.fromisoformat(since_ts.replace("Z", "+00:00"))
            fresh = m >= a
        except (ValueError, OSError):
            fresh = False
    if fresh:
        return {"ok": True, "rendered": False, "txt": str(tp)}
    key = row.get("mpn_key") or mpn
    if not key:
        return {"ok": False, "reason": "mpn_key_missing"}
    try:
        render_item(key)
        return {"ok": True, "rendered": True, "txt": str(tp)}
    except Exception as e:                                       # noqa: BLE001
        return {"ok": False, "reason": f"{type(e).__name__}: {e}"[:200]}


def fix_finalize(mpn: str, round_: int = 1, verdict_after: str = "") -> dict:
    """收口：把本轮经验写回日志 → 未到轮次上限就重审 → 到顶转人工。"""
    rnd = int(round_ or 1)
    plan: dict = {}
    pp = _fix_plans_dir() / f"{_safe(mpn)}.round{rnd}.fix_plan.json"
    if pp.is_file():
        plan = _read_plan(pp)

    # 经验沉淀：每轮一次，写进 docs/qc/型号修复日志_handoff.md（append-only）
    exp = {}
    try:
        from worker.fix_memory import append_experience
        exp = append_experience(mpn, rnd, plan,
                                verdict_before=plan.get("verdict") or "",
                                verdict_after=verdict_after)
    except Exception as e:                                       # noqa: BLE001
        db.add_event("修复经验写入失败", kind="error",
                     detail=f"{mpn} round{rnd}: {type(e).__name__}: {e}")

    exceed = rnd >= config.FIX_MAX_ROUNDS
    if exceed:
        promoted = _promote_to_customer_feedback(mpn, rnd, "max_rounds_reached")
        _append_fix_log(mpn, rnd, {"event": "finalize", "promoted": promoted,
                                   "reason": "max_rounds_reached",
                                   "experience": exp.get("section") or ""})
        return {"ok": True, "mpn": mpn, "round": rnd, "promoted": promoted,
                "experience": exp.get("section") or ""}

    # 有 render:* 修复时，先确保产物已重新生成，再投重审（否则复审会抢跑）
    render_note = {}
    render_only = [a for a in (plan.get("actions") or [])
                   if any(str(c).startswith("render:") for c in (a.get("changed") or []))]
    if render_only:
        render_note = _ensure_render_fresh(mpn, _last_apply_ts(mpn))

    dispatch.submit("review_item", mpn, rnd + 1, False)
    _append_fix_log(mpn, rnd, {"event": "finalize", "next": f"review_round{rnd + 1}",
                               "experience": exp.get("section") or "",
                               "render": render_note})
    return {"ok": True, "mpn": mpn, "round": rnd, "next": f"review_round{rnd + 1}",
            "experience": exp.get("section") or "", "render": render_note}


def _promote_to_customer_feedback(mpn: str, round_: int, reason: str) -> dict:
    """多轮不收敛 → 建 customer_feedback_issue（source=INTERNAL_QC）。"""
    from app.services import feedback, review as RV
    if not config.FIX_AUTO_PROMOTE:
        return {"ok": False, "reason": "auto_promote_disabled"}
    rj = RV.report_paths(config.DATA / "qc" / "reviews", _safe(mpn))["json"]
    review = {}
    if rj.is_file():
        try:
            review = json.loads(rj.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            review = {}
    findings = (review.get("rule_findings") or []) + (review.get("llm_findings") or [])
    if not findings:
        return {"ok": False, "reason": "no_findings"}
    kinds = [str(f.get("kind") or "") for f in findings if isinstance(f, dict)]
    sev = "P0_BLOCKER" if "P0" in {f.get("severity") for f in findings} else "P1_HIGH"
    cat = "OTHER"
    for k in kinds:
        if k in _KIND_CATEGORY:
            cat = _KIND_CATEGORY[k]
            break
    key = f"CF-FIX-{_safe(mpn)[:24]}-R{round_}"
    payload = {
        "issue_key": key,
        "title": f"{mpn} 自动修复 {round_} 轮未收敛",
        "description": (f"自动修复环跑满 {config.FIX_MAX_ROUNDS} 轮后仍有 "
                        f"{len(findings)} 条 finding。原因：{reason}。\n"
                        f"kinds: {', '.join(sorted(set(kinds))[:8])}\n"
                        f"review: {rj.name}"),
        "category": cat, "severity": sev, "source": "INTERNAL_QC",
        "root_cause_hypothesis": "自动修复覆盖面不足或需值级判定（需证据卡）",
    }
    try:
        issue = feedback.create_issue(db, payload, "system:auto_fix")
        return {"ok": True, "issue_key": issue.get("issue_key", key)}
    except Exception as e:                                       # noqa: BLE001
        return {"ok": False, "reason": f"{type(e).__name__}: {e}"[:200]}


def fix_restore(mpn: str, backup_dir: str) -> dict:
    """人工回滚入口：把某个备份目录的产物恢复回去，并重渲染。"""
    from worker.fixers import restore
    out = restore(mpn, backup_dir)
    row = db.q1("SELECT * FROM item WHERE mpn=? OR mpn_key=? ORDER BY id LIMIT 1", (mpn, mpn))
    if row and row.get("mpn_key"):
        dispatch.submit("render_item", row["mpn_key"])
    _append_fix_log(mpn, 0, {"event": "restore", "backup_dir": backup_dir,
                             "restored": out.get("restored")})
    return out


FUNCS = {
    "parse_item": parse_item,
    "fetch_item": fetch_item,
    "llm_item": llm_item,
    "render_item": render_item,
    "preprocess_item": preprocess_item,
    "llm_item_v2": llm_item_v2,
    "audit_item_v2": audit_item_v2,
    "render_item_v2": render_item_v2,
    "parse_many": parse_many,
    "build_catalog": build_catalog,
    "import_images": import_images,
    "export_batch": export_batch,
    "qc_audit_item": qc_audit_item,
    "qc_regression_tick": qc_regression_tick,
    "review_item": review_item,
    "fix_dispatch": fix_dispatch,
    "fix_apply": fix_apply,
    "fix_finalize": fix_finalize,
    "fix_restore": fix_restore,
}


# ---------------------------------------------------------------- Celery 包装
@app.task(name="icpdf.parse_item", bind=True)
def t_parse_item(self, mpn_key: str, force: bool = False, manual_url: str = "") -> dict:
    return parse_item(mpn_key, force=force, manual_url=manual_url)


@app.task(name="icpdf.fetch_item", bind=True)
def t_fetch_item(self, mpn_key: str, force: bool = False, manual_url: str = "") -> dict:
    return fetch_item(mpn_key, force=force, manual_url=manual_url)


@app.task(name="icpdf.llm_item", bind=True)
def t_llm_item(self, mpn_key: str) -> dict:
    return llm_item(mpn_key)


@app.task(name="icpdf.render_item", bind=True)
def t_render_item(self, mpn_key: str) -> dict:
    return render_item(mpn_key)


# -- 五段链路（V2）。任务名带 _v2 后缀，与旧任务分名不分队列：
# 旧 worker 只认 `icpdf.llm_item`，即使新旧消息落进同一个 Redis 队列，
# 也不会被旧进程执行到一半才发现参数对不上。
@app.task(name="icpdf.preprocess_item", bind=True)
def t_preprocess_item(self, mpn_key: str) -> dict:
    return preprocess_item(mpn_key)


@app.task(name="icpdf.llm_item_v2", bind=True)
def t_llm_item_v2(self, mpn_key: str) -> dict:
    return llm_item_v2(mpn_key)


@app.task(name="icpdf.audit_item_v2", bind=True)
def t_audit_item_v2(self, mpn_key: str) -> dict:
    return audit_item_v2(mpn_key)


@app.task(name="icpdf.render_item_v2", bind=True)
def t_render_item_v2(self, mpn_key: str) -> dict:
    return render_item_v2(mpn_key)


@app.task(name="icpdf.parse_many")
def t_parse_many(mpn_keys: list[str], force: bool = False) -> dict:
    return parse_many(mpn_keys, force=force)


@app.task(name="icpdf.build_catalog")
def t_build_catalog(batch_id: int, path: str) -> dict:
    return build_catalog(batch_id, path)


@app.task(name="icpdf.import_images")
def t_import_images(batch_id: int, path: str) -> dict:
    return import_images(batch_id, path)


@app.task(name="icpdf.export_batch")
def t_export_batch(batch_id: int, name: str = "") -> dict:
    return export_batch(batch_id, name)


@app.task(name="icpdf.qc_audit_item", bind=True)
def t_qc_audit_item(self, mpn: str, run_id: int = 0, write: bool = False,
                    scope: str = "facts", operator: str = "auto") -> dict:
    return qc_audit_item(mpn, run_id=run_id, write=write, scope=scope, operator=operator)


@app.task(name="icpdf.qc_regression_tick")
def t_qc_regression_tick(run_id: int = 0, write: bool = False,
                         operator: str = "beat(03:30)", extra: str = "",
                         post: bool = False) -> dict:
    return qc_regression_tick(run_id=run_id, write=write, operator=operator,
                              extra=extra, post=post)


@app.task(name="icpdf.review_item", bind=True, max_retries=2)
def t_review_item(self, mpn: str, round_: int = 1,
                  with_pdf_text: bool = False, force=None,
                  auto_fix: bool = True) -> dict:
    return review_item(mpn, round_=round_, with_pdf_text=with_pdf_text,
                       force=force, auto_fix=auto_fix)


@app.task(name="icpdf.fix_dispatch", bind=True, max_retries=2)
def t_fix_dispatch(self, mpn: str, round_: int = 1) -> dict:
    return fix_dispatch(mpn, round_=round_)


@app.task(name="icpdf.fix_apply", bind=True, max_retries=1)
def t_fix_apply(self, mpn: str, action_id: str, plan_path: str) -> dict:
    return fix_apply(mpn, action_id, plan_path)


@app.task(name="icpdf.fix_finalize", bind=True)
def t_fix_finalize(self, mpn: str, round_: int = 1, verdict_after: str = "") -> dict:
    return fix_finalize(mpn, round_=round_, verdict_after=verdict_after)


@app.task(name="icpdf.fix_restore")
def t_fix_restore(mpn: str, backup_dir: str) -> dict:
    return fix_restore(mpn, backup_dir)


CELERY_TASKS = {
    "parse_item": t_parse_item,
    "fetch_item": t_fetch_item,
    "llm_item": t_llm_item,
    "render_item": t_render_item,
    "preprocess_item": t_preprocess_item,
    "llm_item_v2": t_llm_item_v2,
    "audit_item_v2": t_audit_item_v2,
    "render_item_v2": t_render_item_v2,
    "parse_many": t_parse_many,
    "build_catalog": t_build_catalog,
    "import_images": t_import_images,
    "export_batch": t_export_batch,
    "qc_audit_item": t_qc_audit_item,
    "qc_regression_tick": t_qc_regression_tick,
    "review_item": t_review_item,
    "fix_dispatch": t_fix_dispatch,
    "fix_apply": t_fix_apply,
    "fix_finalize": t_fix_finalize,
    "fix_restore": t_fix_restore,
}
