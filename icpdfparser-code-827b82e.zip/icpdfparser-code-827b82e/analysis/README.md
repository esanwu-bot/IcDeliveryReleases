# 客户反馈分析包（pandas 只读脚本）

> 工作台内生产版见 `app/services/qc_analyzer.py` + `/api/qe/analyzer/v1`
> 与「pandas QC 分析」视图；本脚本用于离线复现同一导出包的分析结果。

工作台「客户反馈闭环 → 导出分析包」生成 ZIP（issues/samples/evidence/regressions/
audit_events/delivery_gates/source_files/field_diff + manifest）。

```bash
pip install pandas
python analysis/analyze_feedback_export.py ./export_dir \
  --seed-csv ./data/seed_feedback_11.csv --out ./analysis_out
```

主要输出：

- `02_traceability_gaps.csv`：缺 PDF SHA / 字段路径 / 修订版本 / parser·rule 版本 /
  expected·actual / 已核验证据 / 回归 / 人工验收的样本清单；
- `03b_ec_table_structure_groups.csv`：`pdf_has_ec_text × electrical_parse_status ×
  table_structure_type` 分组；
- `05_regression_failures.csv`：回归失败清单；
- `04_issue_workstream_suggestions.csv`：按关键词的启发式处理建议。

`pdf_has_ec_text` / `table_structure_type` 由导出时读取 PDF 文本层的关键词启发式生成
（MIN/TYP/MAX、CONDITIONS），只用于分组排查，**不是已核验的表格解析结论**。

输出为用户排查线索：批次/MPN 分布、证据缺口、回归失败清单、按关键词的
启发式处理建议；**不自动判定根因，也不自动关闭问题**。
