#!/usr/bin/env python3
"""Analyze an IcPdfParser feedback export bundle with pandas.

Expected input directory contains any subset of:
  issues.csv, samples.csv, evidence.csv, regressions.csv, audit_events.csv,
  delivery_gates.csv. The script is read-only and writes derived reports only.

Usage:
  python analyze_feedback_export.py ./export_bundle --out ./analysis_out
  python analyze_feedback_export.py ./export_bundle --seed-csv ../data/seed_feedback_11.csv --out ./analysis_out
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import pandas as pd

FILES = ["issues", "samples", "evidence", "regressions", "audit_events", "delivery_gates"]

def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists(): return pd.DataFrame()
    try: return pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    except UnicodeDecodeError: return pd.read_csv(path, dtype=str, keep_default_na=False, encoding="gb18030")

def col(df, *names):
    for n in names:
        if n in df.columns: return n
    return None

def norm_bool(s):
    return s.astype(str).str.strip().str.lower().isin(["1","true","yes","y","是","pass"])

def save(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("export_dir", type=Path, help="Directory containing CSV exports")
    ap.add_argument("--out", type=Path, default=Path("feedback_analysis_out"))
    ap.add_argument("--seed-csv", type=Path, default=None, help="Optional screenshot-derived seed list for reference only")
    args=ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    data={name:read_csv(args.export_dir/f"{name}.csv") for name in FILES}
    issues,samples,evidence,regs,audit,gates=(data[k] for k in FILES)
    seed=read_csv(args.seed_csv) if args.seed_csv else pd.DataFrame()
    summary=[]
    for name,df in data.items(): summary.append({"dataset":name,"rows":len(df),"columns":len(df.columns),"present":bool(len(df) or len(df.columns))})
    save(pd.DataFrame(summary),args.out/"00_dataset_inventory.csv")

    # Issue-level groupings, only when those fields exist in the export.
    for label,df,candidates in [
        ("issue_status",issues,("status",)),("issue_category",issues,("category","issue_type")),
        ("issue_severity",issues,("severity",)),("issue_assignee",issues,("assignee","owner")),
        ("sample_batch",samples,("batch_id","batch","batch_key")),
        ("sample_mpn",samples,("mpn","part_number")),
        ("sample_regression_status",samples,("regression_status","regression_result")),
        ("sample_acceptance_status",samples,("acceptance_status","human_acceptance")),
        ("sample_pdf_has_ec_text",samples,("pdf_has_ec_text",)),
        ("sample_electrical_parse_status",samples,("electrical_parse_status",)),
        ("sample_table_structure_type",samples,("table_structure_type",)),
        ("evidence_status",evidence,("review_status","status","evidence_status")),
        ("regression_result",regs,("result","status","outcome")),
        ("delivery_gate_status",gates,("gate_status","status","result"))]:
        c=col(df,*candidates)
        if c:
            out=df[c].replace("","(空值)").value_counts(dropna=False).rename_axis(c).reset_index(name="count")
            save(out,args.out/f"group_{label}.csv")

    # 电气表异常按“文本层 × 解析状态 × 表格结构”分组（只做分组，不判根因）。
    ec_cols=[col(samples,n) for n in ("pdf_has_ec_text","electrical_parse_status",
                                      "table_structure_type")]
    if len(samples) and all(ec_cols):
        grouped=(samples.groupby(ec_cols,dropna=False).size()
                 .reset_index(name="count").sort_values("count",ascending=False))
        save(grouped,args.out/"03b_ec_table_structure_groups.csv")

    # Join samples to issues by issue_id when possible; preserve all rows.
    iid_i=col(issues,"id","issue_id"); iid_s=col(samples,"issue_id","feedback_issue_id")
    if iid_i and iid_s and len(issues) and len(samples):
        joined=samples.merge(issues,left_on=iid_s,right_on=iid_i,how="left",suffixes=("_sample","_issue"))
        save(joined,args.out/"01_samples_with_issue.csv")

    # Detect evidence/traceability gaps. These are review queues, not verdicts.
    if len(samples):
        gaps=samples.copy(); checks=[]
        for name,aliases in {
            "missing_pdf_sha":("original_pdf_sha256","pdf_sha256","source_pdf_sha256"),
            "missing_field_path":("field_path","json_path","target_field"),
            "missing_source_revision":("source_revision","pdf_revision","document_revision"),
            "missing_parser_version":("parser_version",),
            "missing_rule_version":("rule_version",),
            "missing_expected_or_actual":("expected_value","actual_value"),
            "missing_evidence":("evidence_status",),
            "missing_regression":("regression_status","regression_result"),
            "pending_acceptance":("acceptance_status","human_acceptance"),
            "ec_text_not_checked":("pdf_has_ec_text",),
            "table_structure_unclassified":("table_structure_type",)}.items():
            c=col(gaps,*aliases)
            if c:
                text=gaps[c].astype(str).str.strip()
                if name=="missing_expected_or_actual":
                    a=col(gaps,"expected_value"); b=col(gaps,"actual_value")
                    bad=((gaps[a].astype(str).str.strip().eq("") |
                          gaps[b].astype(str).str.strip().eq(""))
                         if (a and b) else text.eq(""))
                elif name in ("missing_evidence","missing_regression","pending_acceptance"):
                    bad=text.isin(["","MISSING","NOT_RUN","NOT_CHECKED","PENDING"])
                elif name in ("ec_text_not_checked","table_structure_unclassified"):
                    bad=text.isin(["","NOT_CHECKED","NOT_CLASSIFIED"])
                else:
                    bad=text.eq("")
                gaps[name]=bad
                checks.append(name)
        if checks:
            gaps["traceability_gap_count"]=gaps[checks].sum(axis=1)
            save(gaps[gaps["traceability_gap_count"]>0],args.out/"02_traceability_gaps.csv")

    # Compare MPN mismatches against PDF hash mismatches, if columns exist.
    if len(samples):
        mpn_flag=col(samples,"mpn_mismatch","identity_mismatch","mpn_match")
        sha_flag=col(samples,"pdf_sha_mismatch","sha_mismatch","pdf_hash_mismatch")
        if mpn_flag and sha_flag:
            mm=norm_bool(samples[mpn_flag]) if mpn_flag!="mpn_match" else ~norm_bool(samples[mpn_flag])
            sm=norm_bool(samples[sha_flag])
            cross=pd.crosstab(mm.map({True:"MPN_MISMATCH",False:"MPN_MATCH"}),sm.map({True:"PDF_SHA_MISMATCH",False:"PDF_SHA_MATCH"}),dropna=False).reset_index()
            save(cross,args.out/"03_mpn_vs_pdf_sha_crosscheck.csv")

    # Technical-work suggestions are deliberately heuristic and never auto-close issues.
    src=issues.copy()
    if len(src):
        title_c=col(src,"title","summary","issue_title")
        desc_c=col(src,"description","customer_description","actual_behavior")
        cat_c=col(src,"category","issue_type")
        text_series=(src[title_c].astype(str)+" "+src[desc_c].astype(str)) if title_c and desc_c else (src[title_c].astype(str) if title_c else pd.Series([""]*len(src)))
        patterns=[
            (r"mpn|sku|identity|型号|订购|后缀|封装|package|alias","IDENTITY_SOURCE_MAPPING","核对精确MPN、订购表、封装与来源版本；先补身份证据"),
            (r"min|max|typ|unit|电流|电压|功耗|条件|脚注|electrical|表格|错列|错行","ELECTRICAL_TABLE_STRUCTURE","比对原PDF表头/行列/条件/单位/脚注；按表格结构建回归"),
            (r"pin|引脚|gnd|vcc|t/r|方向|有效电平|符号图","PIN_MAPPING_LOGIC","核对目标封装pin table、功能表和符号图，不跨封装复用"),
            (r"faq|seo|正文|多语言|translation|重复|overview|benefits|图片|render","DOWNSTREAM_TEMPLATE_CONTENT","沿 facts→正文/SEO/FAQ/翻译/渲染依赖定位，优先重生成受影响产物"),
        ]
        suggestions=[]
        for t in text_series.fillna(""):
            hit=[(code,action) for pat,code,action in patterns if re.search(pat,t,re.I)]
            suggestions.append((hit[0][0],hit[0][1]) if hit else ("MANUAL_TRIAGE","先复现并补充字段路径、证据与版本，再决定技术处理路径"))
        src["analysis_suggested_workstream"]=[x[0] for x in suggestions]
        src["analysis_suggested_next_step"]=[x[1] for x in suggestions]
        src["analysis_note"]="启发式建议；必须由工程人员结合原厂证据确认，不构成根因判定"
        save(src,args.out/"04_issue_workstream_suggestions.csv")

    # Regression fail queue
    if len(regs):
        rc=col(regs,"result","status","outcome")
        if rc:
            failed=regs[regs[rc].astype(str).str.upper().isin(["FAIL","FAILED","ERROR","BLOCKED"]) ]
            save(failed,args.out/"05_regression_failures.csv")

    # Screenshot-derived seed list is a worklist, not system-of-record data.
    if len(seed):
        save(seed,args.out/"06_seed_feedback_reference.csv")
        if "category" in seed.columns:
            save(seed.groupby("category",dropna=False).size().rename("count").reset_index(),args.out/"07_seed_category_counts.csv")

    manifest={"script":"analyze_feedback_export.py","mode":"read-only analysis","input_dir":str(args.export_dir),"output_dir":str(args.out),"row_counts":{k:len(v) for k,v in data.items()},"seed_rows":len(seed),"warning":"Heuristic output is for triage only. Never use it to auto-verify, freeze, accept, or close issues."}
    (args.out/"analysis_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
if __name__=="__main__": main()
