#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
translate_i18n.py — 多语言二遍翻译 + doc_i18n SQL 种子导出（轻量链路）

背景
----
交付包 13,504 型号中仅 208 个带 multi_language(ja/ko/de/es)（ICPDF_LANGS 窗口期残留）。
本脚本对缺口型号的三个 SEO 字段做批量机翻并回写 JSON，再导出 doc_i18n SQL 种子：

    title       <- seo.title_en
    meta        <- seo.meta_description_en
    description <- basic_info.description

部署路径（服务器 159.89.190.225，数据在 /www/wwwroot/icpdfparser/data/parsed）：
    1. scp 本脚本到服务器，python3 scan → 出缺口统计与成本估算
    2. python3 translate（API key 就位后）→ 原地回写 multi_language，断点续跑
    3. python3 export → deploy/icpdf_ddl.sql + deploy/seed_doc_i18n.sql
    4. 服务器 MySQL 建库建表（DDL），json_to_db.py 全量入库后导入种子；
       种子按 requested_mpn 回查 doc.id，幂等可重放
    5. （可选）delivery_bundle.py 换新输出目录重打交付包

用法
----
    python3 translate_i18n.py scan    [--data-dir DIR] [--scope seo|full]
    python3 translate_i18n.py translate [--scope seo|full] [--provider google|llm|mock]
                                       [--limit N] [--concurrency 8] [--dry-run] [--backup]
    python3 translate_i18n.py export [--out-dir deploy]
    python3 translate_i18n.py verify [--sample 20]

scope：
    seo  = title/description/meta 三字段（doc_i18n 种子层）
    full = 递增追加 features[]/applications[]（详情页正文卡片/应用格），按字段增量不重翻；
           checkpoint 用独立文件 translate_state_full.jsonl，与 v1 互不干扰

环境变量：
    ICPDF_TRANSLATE_PROVIDER   google | llm | mock
    ICPDF_TRANSLATE_API_KEY    Google v2 API key 或 LLM API key
    ICPDF_TRANSLATE_BASE_URL   LLM 用，OpenAI 兼容端点（如 dashscope compatible-mode）
    ICPDF_TRANSLATE_MODEL      LLM 用，模型名（如 qwen-flash）
    ICPDF_DATA_DIR             数据目录（默认 ./data）

仅用 Python 标准库，服务器 python3 可直接跑。
"""

import argparse
import html
import json
import os
import random
import re
import shutil
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

# ------------------------------------------------------------------ 常量

LANGS_DEFAULT = ["ja", "ko", "de", "es"]
# doc_i18n 列序（json_to_db.py MYSQL_DDL）：doc_id, lang, title, description, meta
FIELD_MAP = {"title": ("seo", "title_en"),
             "meta": ("seo", "meta_description_en"),
             "description": ("basic_info", "description")}
HASH_SUFFIX = re.compile(r"_[0-9a-f]{8}$")
UTF8 = {"Content-Type": "application/json; charset=utf-8"}

_print_lock = threading.Lock()


def log(msg):
    with _print_lock:
        print(msg, flush=True)


def stem_mpn(path: Path) -> str:
    """与 json_to_db.py stem_mpn 保持一致：去掉 8 位哈希后缀"""
    return HASH_SUFFIX.sub("", path.stem)


# ------------------------------------------------------------------ HTTP

def http_post_json(url, payload, headers, tries=4, timeout=60):
    body = json.dumps(payload).encode("utf-8")
    for attempt in range(1, tries + 1):
        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            if e.code in (429, 500, 502, 503, 504) and attempt < tries:
                wait = 2 ** attempt + random.random()
                log(f"  [http {e.code}] 第{attempt}次重试，等 {wait:.1f}s: {detail}")
                time.sleep(wait)
                continue
            raise RuntimeError(f"HTTP {e.code}: {detail}") from e
        except (urllib.error.URLError, TimeoutError) as e:
            if attempt < tries:
                time.sleep(2 ** attempt + random.random())
                continue
            raise RuntimeError(f"网络错误: {e}") from e
    raise RuntimeError("unreachable")


# ------------------------------------------------------------------ Provider

class BaseProvider:
    """translate(texts, target) -> [译文]，与 texts 等长"""

    name = "base"

    def translate(self, texts, target):
        raise NotImplementedError


class MockProvider(BaseProvider):
    """不调 API：译文 = [target] + 原文，用于 dry-run 验证链路"""

    name = "mock"

    def translate(self, texts, target):
        return [f"[{target}] {t}" for t in texts]


class GoogleV2Provider(BaseProvider):
    """Google Translation API v2（basic），API key 鉴权。
    注意：v2 不支持术语表，型号保号靠回写前校验兜底。"""

    name = "google"
    BATCH_TEXTS = 32          # v2 单请求最多 128 段，保守取 32
    BATCH_CHARS = 24000       # v2 单请求 30k 码点，留余量

    def __init__(self, api_key):
        self.url = ("https://translation.googleapis.com/language/translate/v2"
                    f"?key={api_key}")

    def _batch(self, texts, target):
        payload = {"q": texts, "target": target, "source": "en", "format": "text"}
        resp = http_post_json(self.url, payload, UTF8)
        out = resp["data"]["translations"]
        return [html.unescape(t["translatedText"]) for t in out]

    def translate(self, texts, target):
        results, batch = [], []
        for t in texts:
            if len(t) > 2800:  # v2 单段上限附近截断保护
                t = t[:2800]
            batch.append(t)
            if len(batch) >= self.BATCH_TEXTS or sum(map(len, batch)) >= self.BATCH_CHARS:
                results += self._batch(batch, target)
                batch = []
        if batch:
            results += self._batch(batch, target)
        if len(results) != len(texts):
            raise RuntimeError(f"google 返回段数 {len(results)} != 输入 {len(texts)}")
        return results


class LLMProvider(BaseProvider):
    """OpenAI 兼容 /chat/completions，一次翻一个型号的三字段。
    提示词内置术语约束：型号/品牌/参数符号保留原文。"""

    name = "llm"

    SYSTEM = ("You are a professional translator for electronics component "
              "datasheet SEO copy. Translate strictly into the target language. "
              "Keep MPN part numbers, brand names, units and symbols EXACTLY as "
              "in the source. Output ONLY a JSON object with the same keys, "
              "no markdown, no explanations.")

    def __init__(self, api_key, base_url, model):
        self.api_key = api_key
        self.model = model
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.headers = {**UTF8, "Authorization": f"Bearer {api_key}"}

    def _call(self, fields, target):
        lang_name = {"ja": "Japanese", "ko": "Korean",
                     "de": "German", "es": "Spanish"}[target]
        payload = {
            "model": self.model,
            "temperature": 0,
            "messages": [
                {"role": "system", "content": self.SYSTEM},
                {"role": "user", "content":
                    f"Target language: {lang_name}\n"
                    f"Translate this JSON: {json.dumps(fields, ensure_ascii=False)}"},
            ],
        }
        resp = http_post_json(self.url, payload, self.headers)
        content = resp["choices"][0]["message"]["content"].strip()
        content = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.M).strip()
        out = json.loads(content)
        if not isinstance(out, dict):
            raise RuntimeError(f"LLM 返回非对象: {content[:120]}")
        return out

    def translate(self, texts, target, field_keys=None):
        """texts 为一组的多个字段；field_keys 与 texts 对应，返回同序译文"""
        if field_keys is None:
            field_keys = [f"f{i}" for i in range(len(texts))]
        fields = {k: t for k, t in zip(field_keys, texts)}
        out = self._call(fields, target)
        return [str(out.get(k, "")) for k in field_keys]


def build_provider(args):
    name = args.provider or os.environ.get("ICPDF_TRANSLATE_PROVIDER", "")
    if args.dry_run or name == "mock":
        log("[provider] mock（dry-run，不调 API）")
        return MockProvider()
    key = os.environ.get("ICPDF_TRANSLATE_API_KEY", "")
    if not key:
        sys.exit("缺 ICPDF_TRANSLATE_API_KEY。先 export 再跑，或 --dry-run 验证链路。")
    if name == "google":
        log("[provider] Google Translate v2")
        return GoogleV2Provider(key)
    if name == "llm":
        base = os.environ.get("ICPDF_TRANSLATE_BASE_URL", "")
        model = os.environ.get("ICPDF_TRANSLATE_MODEL", "")
        if not (base and model):
            sys.exit("LLM provider 需要 ICPDF_TRANSLATE_BASE_URL 和 ICPDF_TRANSLATE_MODEL")
        log(f"[provider] LLM {model} @ {base}")
        return LLMProvider(key, base, model)
    sys.exit(f"未知 provider: {name}（可选 google | llm | mock）")


# ------------------------------------------------------------------ 扫描

def iter_main_jsons(data_dir: Path):
    for p in sorted(data_dir.glob("*.json")):
        if p.name.endswith(".alts.json") or p.name.endswith(".seo.json"):
            continue
        yield p


def load_checkpoint(state_file: Path, scope: str = "seo"):
    done = {}  # key -> set(langs)，只计入同 scope 的记录
    if state_file.exists():
        for line in state_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                if rec.get("scope", "seo") != scope:
                    continue
                done.setdefault(rec["key"], set()).update(rec.get("langs", []))
            except (json.JSONDecodeError, KeyError):
                continue
    return done


def scan_models(data_dir: Path, langs, checkpoint=None, scope="seo"):
    """返回 (items, stats)。scope=seo 翻 3 个 SEO 字段；full 追加 features/applications"""
    items, stats = [], {"total": 0, "full": 0, "partial": 0, "missing": 0,
                        "skipped_done": 0, "chars": {"title": 0, "meta": 0, "description": 0,
                                                     "features": 0, "applications": 0},
                        "field_missing": {"title": 0, "meta": 0, "description": 0}}
    for p in iter_main_jsons(data_dir):
        try:
            art = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            log(f"[scan] 跳过坏文件 {p.name}: {e}")
            continue
        stats["total"] += 1
        key = stem_mpn(p)
        ml = art.get("multi_language")
        ml = ml if isinstance(ml, dict) else {}
        # 源字段：SEO 3 字段 +（full）features/applications 列表
        src = {}
        for out_key, (sec, field) in FIELD_MAP.items():
            val = ((art.get(sec) or {}).get(field) or "").strip()
            if val:
                src[out_key] = val
                stats["chars"][out_key] += len(val)
            else:
                stats["field_missing"][out_key] += 1
        src_feats = [str(x).strip() for x in (art.get("features") or []) if str(x).strip()]
        src_apps = [str(x).strip() for x in (art.get("applications") or []) if str(x).strip()]
        if scope == "full":
            src["features"] = src_feats
            src["applications"] = src_apps

        def _lang_ok(lang):
            e = ml.get(lang)
            if not isinstance(e, dict) or not e.get("title"):
                return False
            if scope == "full":
                if src_feats and not e.get("features"):
                    return False
                if src_apps and not e.get("applications"):
                    return False
            return True

        have = {lang for lang in langs if _lang_ok(lang)}
        need = [lang for lang in langs if lang not in have]
        if checkpoint and need:
            need = [lang for lang in need if lang not in checkpoint.get(key, set())]
        if not need:
            if have:
                stats["full"] += 1
            else:
                stats["skipped_done"] += 1  # checkpoint 标记完成但 JSON 缺失（如恢复过备份）
            continue
        if have:
            stats["partial"] += 1
        else:
            stats["missing"] += 1
        if scope == "full":
            stats["chars"]["features"] += sum(len(x) for x in src_feats)
            stats["chars"]["applications"] += sum(len(x) for x in src_apps)
        base = {k: v for k, v in src.items() if isinstance(v, str) and v}
        if not base and not src_feats and not src_apps:
            continue
        items.append({"key": key, "path": p, "need": need, "src": src,
                      "mpn": (art.get("basic_info") or {}).get("mpn") or key})
    return items, stats


def print_scan_stats(stats, langs, n_items):
    log(f"\n===== 扫描结果 =====")
    log(f"主 JSON 总数      : {stats['total']}")
    log(f"四语齐全          : {stats['full']}")
    log(f"部分缺失          : {stats['partial']}")
    log(f"完全缺失          : {stats['missing']}")
    log(f"本次待翻译型号    : {n_items}")
    for k in ("title", "meta", "description", "features", "applications"):
        if stats["chars"].get(k) or k in ("title", "meta", "description"):
            miss = stats["field_missing"].get(k, "-") if k in stats["field_missing"] else "-"
            log(f"  {k:<13} 缺字段型号 {miss:>6} | 源字符 {stats['chars'].get(k, 0):>9,}")
    total_chars = sum(stats["chars"].values())
    log(f"\n----- 成本估算（源字符 {total_chars:,}，×{len(langs)} 个目标语种）-----")
    log(f"Google v2 ($20/百万字符): ≈ ${total_chars * len(langs) * 20 / 1e6:,.1f}")
    log(f"LLM 粗估 (≈{total_chars * len(langs) / 4:,.0f} 输出 tokens): 按各家单价计")
    log(f"mock/断点: state 文件记录已翻译型号，中断重跑自动续。")


def cmd_scan(args, langs):
    data_dir = Path(args.data_dir)
    state_file = Path(args.state_file) if args.state_file else _default_state(data_dir, args.scope)
    checkpoint = load_checkpoint(state_file, args.scope)
    items, stats = scan_models(data_dir, langs, checkpoint, args.scope)
    print_scan_stats(stats, langs, len(items))


def _default_state(data_dir: Path, scope: str) -> Path:
    name = "translate_state.jsonl" if scope == "seo" else "translate_state_full.jsonl"
    return data_dir.parent / name


def _check_no_other_instance():
    """full/v1 并发保护：已有 translate 进程在跑则拒绝启动（防止同文件写冲突）"""
    if sys.platform == "win32":
        return
    try:
        out = os.popen("pgrep -f 'translate_i18n.py translate'").read().strip()
    except Exception:
        return
    others = [pid for pid in out.splitlines() if pid.strip() and pid.strip() != str(os.getpid())]
    if others:
        sys.exit(f"已有翻译进程在跑（PID {','.join(others)}）。同目录 JSON 回写会互相覆盖，请等它结束再跑。")


# ------------------------------------------------------------------ 翻译回写

def backup_once(path: Path, backup_dir: Path):
    dst = backup_dir / path.name
    if not dst.exists():
        shutil.copy2(path, dst)


def _code_tokens(s):
    """提取“元器件编号样”token：字母开头、含数字、长度≥5（如 SN74LVC1G08-EP、SOT-23）"""
    toks = re.findall(r"[A-Za-z][A-Za-z0-9]*[0-9][A-Za-z0-9\-]*", s)
    return [t for t in toks if len(t) >= 5]


def _norm(s):
    return re.sub(r"[^A-Z0-9]", "", s.upper())


def _missing_codes(src_text, trans_text):
    n = _norm(trans_text or "")
    return [t for t in _code_tokens(src_text) if _norm(t) not in n]


def _flatten_src(src):
    """把 {str 字段, list 字段} 拍平成等长对齐的 (keys, texts)，列表项键为 features_0/…"""
    keys, texts = [], []
    for k, v in src.items():
        if isinstance(v, list):
            for i, item in enumerate(v):
                keys.append(f"{k}_{i}")
                texts.append(item)
        elif v:
            keys.append(k)
            texts.append(v)
    return keys, texts


def _rebuild_result(keys, outs, src):
    """把对齐译文重组回 {str 字段: str, list 字段: list}；列表缺项回退源文本"""
    result = {"features": [None] * len(src.get("features") or []),
              "applications": [None] * len(src.get("applications") or [])}
    for k, v in zip(keys, outs):
        base, _, idx = k.rpartition("_")
        if idx.isdigit() and base in ("features", "applications"):
            result[base][int(idx)] = v
        else:
            result[k] = v
    for listk in ("features", "applications"):
        src_list = src.get(listk) or []
        if result[listk]:
            result[listk] = [t if t else src_list[i] for i, t in enumerate(result[listk])]
        elif src_list:
            result[listk] = list(src_list)
    return result


def translate_one(provider, item, langs, backup_dir=None, scope="seo"):
    """翻译单型号：只翻缺失语种；成功后原子回写 JSON 并返回 checkpoint 记录"""
    p = item["path"]
    art = json.loads(p.read_text(encoding="utf-8"))
    src = item["src"]
    # scope=seo 只翻 3 字段；full 追加 features/applications（只补缺，已有字段不重翻）
    pack_src = src
    if scope == "seo":
        pack_src = {k: v for k, v in src.items() if isinstance(v, str)}

    ml = art.get("multi_language")
    ml = ml if isinstance(ml, dict) else {}

    added, warnings = {}, []
    for lang in item["need"]:
        existing = ml.get(lang) if isinstance(ml.get(lang), dict) else {}
        # 增量：已有字段不重翻（v1 的 title/description/meta 直接沿用）
        pack = dict(pack_src)
        for f in ("title", "meta", "description"):
            if existing.get(f):
                pack.pop(f, None)
        keys, texts = _flatten_src(pack)
        if not texts:
            continue  # 该语种需要的内容已齐（如只有 title 缺 features，但源无 features）
        if isinstance(provider, LLMProvider):
            outs = provider.translate(texts, lang, keys)
        else:
            outs = provider.translate(texts, lang)
        if len(outs) != len(texts):
            raise RuntimeError(f"{item['key']} {lang}: 译文数不匹配")
        result = _rebuild_result(keys, outs, pack)
        entry, changed = {}, False
        # 校验：译文必须保住源文本中的元器件编号 token（型号/封装），失号回退英文并告警
        if "title" in result:
            lost = _missing_codes(src.get("title", ""), result["title"])
            if lost:
                entry["title"] = src["title"]
                warnings.append(f"{item['key']}.{lang}: title 丢编号 "
                                f"{lost[:3]}，回退英文")
            else:
                entry["title"] = result["title"]
            changed = True
        for soft_field in ("description", "meta"):
            if result.get(soft_field):
                lost = _missing_codes(src.get(soft_field, ""), result[soft_field])
                if lost:
                    warnings.append(f"{item['key']}.{lang}: {soft_field} 丢编号 "
                                    f"{lost[:3]}（保留译文）")
                entry[soft_field] = result[soft_field]
                changed = True
        if scope == "full":
            for listk in ("features", "applications"):
                tgt_list = result.get(listk) or []
                if pack_src.get(listk) and tgt_list:
                    entry[listk] = [str(x).strip() for x in tgt_list if str(x).strip()]
                    changed = True
                    for i, (orig, got) in enumerate(zip(pack_src[listk], entry[listk])):
                        lost = _missing_codes(orig, got)
                        if lost:
                            warnings.append(f"{item['key']}.{lang}: {listk}[{i}] 丢编号 "
                                            f"{lost[:3]}（保留译文）")
        if not changed:
            raise RuntimeError(f"{item['key']}.{lang}: 无有效产出")
        ml[lang] = {**existing, **entry}  # 合并保留已有字段（v1/先前产物）
        added[lang] = True

    if not added:
        raise RuntimeError(f"{item['key']}: 无任何语种产出")

    art["multi_language"] = ml
    if backup_dir:
        backup_once(p, backup_dir)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(art, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, p)
    return {"key": item["key"], "langs": sorted(added), "warnings": warnings}


def cmd_translate(args, langs):
    scope = args.scope
    data_dir = Path(args.data_dir)
    if args.dry_run:
        # 沙箱模式：真实数据只读，mock 译文写进副本目录，不产生 checkpoint 污染
        limit = args.limit or 5
        sandbox = data_dir.parent / (data_dir.name + "_dryrun")
        if sandbox.exists():
            shutil.rmtree(sandbox)
        sandbox.mkdir(parents=True)
        items, stats = scan_models(data_dir, langs, scope=scope)
        items = items[: limit]
        for it in items:
            shutil.copy2(it["path"], sandbox / it["path"].name)
            it["path"] = sandbox / it["path"].name
        data_dir = sandbox
        log(f"[dry-run] 沙箱目录: {sandbox}（{len(items)} 型号，真实数据不动）")
        state_file = sandbox / "translate_state.jsonl"  # 状态留沙箱内，不污染正式 checkpoint
    else:
        state_file = Path(args.state_file) if args.state_file else _default_state(data_dir, scope)
        _check_no_other_instance()  # 互斥：同一时刻只允许一个 translate 进程
    checkpoint = load_checkpoint(state_file, scope)
    provider = build_provider(args)
    if not args.dry_run:
        items, stats = scan_models(data_dir, langs, checkpoint, scope)
        if args.limit:
            items = items[: args.limit]
    if not items:
        log("没有待翻译型号（或全部已在 checkpoint）。")
        return
    log(f"待翻译 {len(items)} 型号，scope={scope}，provider={provider.name}，"
        f"concurrency={args.concurrency}，state={state_file}")
    if not args.dry_run and not args.yes:
        log("确认执行请加 --yes（正式跑将调用付费 API）。本次仅打印清单。")
        for it in items[:5]:
            log(f"  例: {it['key']} -> {','.join(it['need'])}")
        return

    backup_dir = data_dir / "parsed_backup_i18n" if args.backup else None
    if backup_dir:
        backup_dir.mkdir(exist_ok=True)
    state_fp = state_file.open("a", encoding="utf-8")
    state_lock = threading.Lock()
    done = fail = 0
    t0 = time.time()

    def worker(item):
        nonlocal done, fail
        try:
            rec = translate_one(provider, item, langs, backup_dir, scope)
            with state_lock:
                state_fp.write(json.dumps(
                    {"key": rec["key"], "langs": rec["langs"], "provider": provider.name,
                     "scope": scope, "ts": time.strftime("%Y-%m-%dT%H:%M:%S")},
                    ensure_ascii=False) + "\n")
                state_fp.flush()
            for w in rec["warnings"]:
                log(f"  [warn] {w}")
            done += 1
        except Exception as e:
            fail += 1
            log(f"  [fail] {item['key']}: {e}")

    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futs = [pool.submit(worker, it) for it in items]
        for i, fut in enumerate(as_completed(futs), 1):
            if i % 25 == 0 or i == len(items):
                rate = i / max(time.time() - t0, 1e-9)
                log(f"进度 {i}/{len(items)}（{rate:.1f} 型号/s，失败 {fail}）")
    state_fp.close()
    log(f"完成 {done}，失败 {fail}。state: {state_file}")
    if fail:
        log("失败型号未记 checkpoint，直接重跑本命令即可续跑。")


# ------------------------------------------------------------------ SQL 导出

DOC_I18N_DDL = """CREATE TABLE IF NOT EXISTS doc_i18n (
    doc_id  BIGINT NOT NULL,
    lang    CHAR(5) NOT NULL,
    title   VARCHAR(512) NOT NULL DEFAULT '',
    description TEXT NULL,
    meta    VARCHAR(1024) NOT NULL DEFAULT '',
    PRIMARY KEY (doc_id, lang)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT='多语言文案'"""

DOC_DDL = """CREATE TABLE IF NOT EXISTS doc (
    id             BIGINT       NOT NULL AUTO_INCREMENT,
    requested_mpn  VARCHAR(128) NOT NULL DEFAULT '',
    mpn            VARCHAR(128) NOT NULL,
    brand          VARCHAR(128) NOT NULL DEFAULT '',
    category       VARCHAR(128) NOT NULL DEFAULT '',
    subcategory    VARCHAR(128) NOT NULL DEFAULT '',
    description    TEXT         NULL,
    datasheet_url  VARCHAR(1024) NOT NULL DEFAULT '',
    pkg_type       VARCHAR(128) NOT NULL DEFAULT '',
    pkg_pins       INT          NOT NULL DEFAULT 0,
    pkg_dimensions VARCHAR(128) NOT NULL DEFAULT '',
    temp_operating VARCHAR(64)  NOT NULL DEFAULT '',
    temp_storage   VARCHAR(64)  NOT NULL DEFAULT '',
    pdf_sha256     CHAR(64)     NOT NULL DEFAULT '',
    pdf_path       VARCHAR(512) NOT NULL DEFAULT '',
    json_path      VARCHAR(512) NOT NULL DEFAULT '',
    model_version  VARCHAR(64)  NOT NULL DEFAULT '',
    confidence     DECIMAL(4,3) NOT NULL DEFAULT 0,
    parsed_at      DATETIME     NULL,
    revision       INT          NOT NULL DEFAULT 1,
    status         VARCHAR(16)  NOT NULL DEFAULT 'parsed',
    note           TEXT         NULL,
    raw_sha256     CHAR(64)     NOT NULL DEFAULT '',
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_mpn_pdf (mpn, pdf_sha256),
    KEY idx_requested (requested_mpn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  COMMENT='型号解析主表'"""


def sql_escape(s):
    s = s.replace("\\", "\\\\").replace("'", "\\'")
    s = s.replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n")
    return s.replace("\x00", "")


def cmd_export(args, langs):
    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1) DDL：建库建表（doc + doc_i18n；其余表由 json_to_db.py 全量入库时补齐）
    ddl_path = out_dir / "icpdf_ddl.sql"
    ddl_path.write_text(
        "-- icpdf 结果库建库建表（多语言二次修正配套）\n"
        "-- 用法: mysql -uroot -p < icpdf_ddl.sql\n"
        "-- doc 全量数据仍走 json_to_db.py --db mysql 入库\n"
        "CREATE DATABASE IF NOT EXISTS icpdf "
        "CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;\n"
        "USE icpdf;\n" + DOC_DDL + ";\n" + DOC_I18N_DDL + ";\n",
        encoding="utf-8")
    log(f"DDL 已导出: {ddl_path}")

    # 2) 种子：INSERT...SELECT 按 requested_mpn 回查 doc.id，幂等可重放
    seed_path = out_dir / "seed_doc_i18n.sql"
    n_rows = n_models = 0
    with seed_path.open("w", encoding="utf-8", newline="\n") as fp:
        fp.write("-- doc_i18n 多语言种子（title/description/meta, ja/ko/de/es）\n"
                 "-- 前提: doc 表已由 json_to_db.py 入库（按 requested_mpn 回查 id）\n"
                 "-- 用法: mysql -uroot -p icpdf < seed_doc_i18n.sql   （幂等可重放）\n"
                 "SET NAMES utf8mb4;\n")
        for p in iter_main_jsons(data_dir):
            try:
                art = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            ml = art.get("multi_language")
            if not isinstance(ml, dict) or not ml:
                continue
            key = stem_mpn(p)
            n_models += 1
            for lang in sorted(ml.keys()):
                e = ml[lang]
                if not isinstance(e, dict):
                    continue
                title = sql_escape(str(e.get("title") or ""))
                desc = sql_escape(str(e.get("description") or ""))
                meta = sql_escape(str(e.get("meta") or ""))
                fp.write(
                    f"INSERT INTO doc_i18n (doc_id, lang, title, description, meta) "
                    f"SELECT d.id, '{lang}', '{title}', '{desc}', '{meta}' "
                    f"FROM doc d WHERE d.requested_mpn = '{sql_escape(key)}' "
                    f"ON DUPLICATE KEY UPDATE title = VALUES(title), "
                    f"description = VALUES(description), meta = VALUES(meta);\n")
                n_rows += 1
    size_mb = seed_path.stat().st_size / 1048576
    log(f"种子已导出: {seed_path}（{n_models} 型号，{n_rows} 行，{size_mb:.1f} MB）")


# ------------------------------------------------------------------ 校验

CJK_RE = {
    "ja": re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]"),
    "ko": re.compile(r"[\uac00-\ud7af]"),
}


def cmd_verify(args, langs):
    data_dir = Path(args.data_dir)
    items, stats = scan_models(data_dir, langs)
    print_scan_stats(stats, langs, len(items))
    log("\n----- 抽检 -----")
    checked = 0
    for p in iter_main_jsons(data_dir):
        try:
            art = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        ml = art.get("multi_language")
        if not isinstance(ml, dict):
            continue
        key = stem_mpn(p)
        src_title = (art.get("seo") or {}).get("title_en") or ""
        for lang, e in sorted(ml.items()):
            if not isinstance(e, dict) or not e.get("title"):
                continue
            issues = []
            lost = _missing_codes(src_title, e.get("title"))
            if lost:
                issues.append(f"丢编号 {lost[:3]}")
            if "&#" in e.get("title", "") or "&#" in e.get("meta", ""):
                issues.append("残留 HTML 实体")
            pat = CJK_RE.get(lang)
            if pat and not pat.search(e.get("title", "") + e.get("description", "")):
                issues.append(f"未见 {lang} 本地字符")
            if e.get("title", "").startswith("["):
                issues.append("疑似 mock 前缀")
            tag = " / ".join(issues) if issues else "OK"
            log(f"  {key}.{lang}: {tag}")
            checked += 1
            if checked >= args.sample * len(langs):
                return
        if checked >= args.sample * len(langs):
            return


# ------------------------------------------------------------------ CLI

def main():
    ap = argparse.ArgumentParser(description="多语言二遍翻译 + doc_i18n 种子导出")
    ap.add_argument("command", choices=["scan", "translate", "export", "verify"])
    ap.add_argument("--data-dir", default=os.environ.get("ICPDF_DATA_DIR", "./data/parsed"))
    ap.add_argument("--langs", default=",".join(LANGS_DEFAULT),
                    help="逗号分隔，默认 ja,ko,de,es")
    ap.add_argument("--scope", choices=["seo", "full"], default="seo",
                    help="seo=3 个 SEO 字段；full=追加 features/applications（增量，不重翻已有字段）")
    ap.add_argument("--state-file", default="",
                    help="checkpoint 文件；默认按 scope 自动（seo: translate_state.jsonl / full: translate_state_full.jsonl）")
    ap.add_argument("--provider", default=None, help="google | llm | mock")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 个型号（试跑）")
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--dry-run", action="store_true", help="mock provider，不调 API")
    ap.add_argument("--yes", action="store_true", help="正式执行确认开关")
    ap.add_argument("--backup", action="store_true", help="首次改写前备份原 JSON")
    ap.add_argument("--out-dir", default="./deploy", help="export 输出目录")
    ap.add_argument("--sample", type=int, default=20, help="verify 抽检条数")
    args = ap.parse_args()

    langs = [x.strip() for x in args.langs.split(",") if x.strip()]
    data_dir = Path(args.data_dir)
    if not data_dir.is_dir():
        sys.exit(f"数据目录不存在: {data_dir}")
    log(f"数据目录: {data_dir.resolve()} | 语种: {','.join(langs)}")

    {"scan": cmd_scan, "translate": cmd_translate,
     "export": cmd_export, "verify": cmd_verify}[args.command](args, langs)


if __name__ == "__main__":
    main()
