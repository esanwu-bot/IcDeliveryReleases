#!/usr/bin/env python
"""一次性修复脚本：worker 中断后残留的中间态型号，重新投回队列。

worker 被强杀时，手上的任务不会写回终态，item 会永远停在 resolving/parsing，
看起来像"卡住"。这里把它们状态改回 queued 并重新投递。
"""
import sys

sys.path.insert(0, r"E:\workspace\IcPdfParser")

from app import db
from app.services import dispatch

MID = ("resolving", "parsing", "rendering", "downloading", "queued")
marks = ",".join("?" * len(MID))
rows = db.q(f"SELECT id,mpn,mpn_key,status,stage FROM item WHERE status IN ({marks}) "
            "AND status<>'queued'", tuple(MID))
print("待修复中间态:", len(rows))
n = 0
for r in rows:
    db.x("UPDATE item SET status='queued', stage='等待执行', progress=1, error='', "
         "updated_at=? WHERE id=?", (db.now(), r["id"]))
    dispatch.submit("parse_item", r["mpn_key"], False, "")
    n += 1
    print(f"  重投 {r['mpn']}  (原状态 {r['status']} / {r['stage']})")
print("已重投:", n)
