#!/usr/bin/env python
"""真实生产链路端到端测速（临时脚本）：用真实 PDF + 生产 prompt 测百炼 parse 延迟。

前面的探针用的是人造 prompt。这里直接调 parse_datasheets 的生产函数
（真实 PDF -> 抽文本 -> 生产 system/user prompt -> chat -> JSON），
测：
  1) 单件端到端耗时、prompt/completion token（thinking off vs on）
  2) 并发 N 下的真实件/小时吞吐（生产 prompt 真实体量）

产物写到 data/parsed_bench/，不动 data/parsed/，不写 llm_usage。
用法: python tmp_bench_real.py [并发数]
"""
from __future__ import annotations

import os
import shutil
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import parse_datasheets as pd

ROOT = pd.ROOT
OUT = ROOT / "data" / "parsed_bench"
OUT.mkdir(parents=True, exist_ok=True)   # 不删目录，避免触发删除保护

# 强制走百炼 + 关思考
pd.API_BASE, pd.API_KEY, pd.MODEL = pd.DASHSCOPE_BASE, pd.DASHSCOPE_KEY, pd.DASHSCOPE_MODEL
pd.OUT_DIR = OUT
pd.TIMEOUT = 300

CONC = int(sys.argv[1]) if len(sys.argv) > 1 else 16
NSAMPLE = int(sys.argv[2]) if len(sys.argv) > 2 else CONC

# 挑有本地 PDF 的样本
pdfs = sorted((ROOT / "data" / "pdfs").glob("*.pdf"))
if not pdfs:
    sys.exit("data/pdfs 下没有 PDF")
print(f"[setup] backend=dashscope model={pd.MODEL} thinking={pd.ENABLE_THINKING} "
      f"候选PDF={len(pdfs)} 并发={CONC}")

# 生产 prompt 的上下文长度以 MAX_PAGES/MAX_CHARS 为准，这里用生产默认值
print(f"[info] MAX_PAGES={pd.MAX_PAGES} MAX_CHARS={pd.MAX_CHARS}")

# monkeypatch 记录每次 chat 的 usage 与耗时
_calls: list[dict] = []
_orig_chat = pd.chat


def _wrapped(messages, **kw):
    t0 = time.perf_counter()
    content, usage = _orig_chat(messages, **kw)
    _calls.append({"secs": time.perf_counter() - t0,
                   "pt": (usage or {}).get("prompt_tokens", 0),
                   "ct": (usage or {}).get("completion_tokens", 0)})
    return content, usage


pd.chat = _wrapped


def one(pdf: Path) -> dict:
    t0 = time.perf_counter()
    try:
        out = pd.parse_one(pdf, pd.load_url_map())
        return {"ok": out.get("status") != "failed", "secs": time.perf_counter() - t0,
                "mpn": pdf.stem, "err": out.get("error", "")}
    except Exception as e:                                   # noqa: BLE001
        return {"ok": False, "secs": time.perf_counter() - t0,
                "mpn": pdf.stem, "err": f"{type(e).__name__}: {e}"[:180]}


if __name__ == "__main__":
    sample = pdfs[:NSAMPLE]
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=CONC) as pool:
        futs = [pool.submit(one, p) for p in sample]
        for f in as_completed(futs):
            res.append(f.result())
    wall = time.time() - t0
    ok = [x for x in res if x["ok"]]
    secs = sorted(x["secs"] for x in ok)
    p50 = statistics.median(secs) if secs else 0
    p90 = secs[int(len(secs) * 0.9) - 1] if len(secs) > 1 else 0
    ct = [c["ct"] for c in _calls]
    pt = [c["pt"] for c in _calls]
    cs = [c["secs"] for c in _calls]
    # 真正过了 LLM 的件数 = chat 次数（parse 一次 + 可能的 repair 一次）
    llm_items = len(_calls)
    print(f"\n=== 生产链路 并发{CONC} 样本{len(sample)} ===")
    print(f"  产出成功 {len(ok)}/{len(res)}  墙钟 {wall:.1f}s")
    print(f"  单件耗时 p50={p50:.1f}s p90={p90:.1f}s max={max(secs) if secs else 0:.1f}s")
    print(f"  chat 次数={llm_items}  prompt均值={sum(pt)//max(1,len(pt))} "
          f"completion均值={sum(ct)//max(1,len(ct))} chat耗时均值={sum(cs)/max(1,len(cs)):.1f}s")
    print(f"  >>> 真 LLM 吞吐 = {llm_items/wall*3600:.0f} 次/小时")
    print(f"  >>> 全链路吞吐 = {len(ok)/wall*3600:.0f} 件/小时")
    for x in res:
        if not x["ok"]:
            print(f"  失败 {x['mpn']}: {x['err']}")
