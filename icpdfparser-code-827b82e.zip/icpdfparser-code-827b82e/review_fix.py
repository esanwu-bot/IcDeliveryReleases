#!/usr/bin/env python
"""review-fix：状态汇总 / 分批物化成交付批次（CLI）。

用法
----
  python review_fix.py status                       # 各状态计数 + 待成批件数
  python review_fix.py list --state blocked         # 逐型号列出（blocked/warn/pass/incomplete/pending/all）
  python review_fix.py build --size 30 --max-batches 1
  python review_fix.py build --size 30 --dry-run    # 只算分片，不落盘

口径（详见 qc/review_status.py）
-------------------------------
状态只看最近一次复审报告的有效 findings：P0>0 阻断 / 只有 P1 警告 / 都没有才算
机器检查通过；报告缺失、缺字段、verdict 与计数不自洽的一律标「证据不完整」。
修复动作只作旁证（fix_applied），不再是状态依据。

产出的批次目录 `data/qc/rf-YYYYMMDD-NNN/` 与既有交付批次同构
（manifest.csv + 核验报告.md + *quality_audit.json + zip），会被
`/api/qe/deliveries` 直接列出。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from qc import review_fix as RF       # noqa: E402

BASE = ROOT / "data" / "qc"

_STATE_NOTE = {
    RF.NOT_REVIEWED: "还没有 review 报告",
    RF.REVIEWED_NEEDS_FIX: "审出问题但无实际修复（含 changed=[] 的空修）",
    RF.FIXED_UNVERIFIED: "修了但未重审（判定滞后）",
    RF.FIXED_NOT_CONVERGED: "跑满轮次未收敛，已转客户反馈闭环",
    RF.FIXED_STILL_FAIL: "修了但重审仍阻断",
    RF.REVIEWED_CLEAN: "审过且无需修复",
}


def _print_status(st: dict) -> None:
    print("推导口径：%s" % st["status_rule_version"])
    print("  审过的型号        %d" % st["reviewed"])
    print("  阻断（P0 未清）   %d" % st["blocked"])
    print("  警告（P1 未清）   %d" % st["still_warn"])
    print("  机器检查通过      %d" % st["qa_pass"])
    print("  证据不完整        %d" % st["incomplete"])
    print("  已成批 / 待成批   %d / %d" % (st["batched"], st["pending"]))
    print("  批次目录          %d" % st["batches"])
    if st["by_state"]:
        print("  —— 内部诊断态（不外露为列表状态）——")
        for k, v in sorted(st["by_state"].items(), key=lambda kv: -kv[1]):
            print("    %-22s %5d  %s" % (k, v, _STATE_NOTE.get(k, "")))


def cmd_status(_a) -> int:
    _print_status(RF.summary(BASE))
    return 0


def _pick(rows: list[dict], state: str) -> list[dict]:
    code = {"blocked": RF.STATUS_BLOCKED,
            "warn": RF.STATUS_STILL_WARN,
            "pass": RF.STATUS_QA_PASS}.get(state)
    if code:
        return [r for r in rows if r["status_code"] == code]
    if state == "incomplete":
        return [r for r in rows if r["status_code"] in (RF.STATUS_INCOMPLETE,
                                                        RF.STATUS_LEGACY_UNRESOLVED)]
    if state == "pending":
        assigned = RF.load_index(BASE).get("assigned") or {}
        return [r for r in rows if r["reviewed"] and r["mpn"] not in assigned]
    return rows


def cmd_list(a) -> int:
    rows = _pick(RF.scan(BASE), a.state)
    rows.sort(key=lambda r: (r.get("fixed_at") or r.get("reviewed_at") or "",
                             r["mpn"]))
    if a.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        print("（无）")
        return 0
    print("%-28s %-34s %-4s %-4s %-6s %s"
          % ("型号", "状态", "P0", "P1", "改动", "修复时间"))
    for r in rows:
        print("%-28s %-34s %-4d %-4d %-6d %s" % (
            r["mpn"][:28], r["status_label"] or r["status_code"],
            r["p0"], r["p1"], r.get("fixes") or 0, r.get("fixed_at") or "—"))
    print("\n共 %d 件" % len(rows))
    return 0


def cmd_build(a) -> int:
    out = RF.build_next(BASE, size=a.size, max_batches=a.max_batches,
                        dry_run=a.dry_run)
    if out.get("skipped_reason"):
        print("没有待成批的型号（%s）" % out["skipped_reason"])
        return 0
    print("候选 %d 件，每批 %d，计划 %d 批"
          % (out["candidates"], out["size"], out["planned_batches"]))
    if a.dry_run:
        for i, p in enumerate(out.get("plan") or [], 1):
            print("  第 %d 批：%d 件  %s%s"
                  % (i, p["size"], ", ".join(p["mpns"][:4]),
                     " …" if p["size"] > 4 else ""))
        print("（dry-run，未落盘）")
        return 0
    for b in out.get("built") or []:
        print("  ✓ %s  %d 件  %.2f MB  %s  %s"
              % (b["batch"], b["mpns"], b["bytes"] / 1048576.0,
                 b.get("status_code") or "—", b["path"]))
        if b.get("missing_artifacts"):
            print("    ! 缺产物：%s" % ", ".join(b["missing_artifacts"][:6]))
    print("剩余待成批：%d 件" % (out.get("remaining") or 0))
    return 0


def cmd_rebuild(a) -> int:
    """按已有批次的 manifest.csv 重打：状态按当前复审报告重算，不用旧清单。"""
    d = Path(a.batch)
    if not d.is_dir():
        d = BASE / a.batch
    batch, rows = RF.read_batch(d)
    fresh = {m: RF.derive(BASE, m) for m in (r["mpn"] for r in rows)}
    for r in rows:
        r.update({k: v for k, v in fresh[r["mpn"]].items()
                  if k in ("status_code", "status_label", "p0", "p1", "p2",
                           "incomplete_checks", "fix_applied", "fixes", "round",
                           "fixed_at", "reviewed_at", "verdict_before",
                           "verdict_after")})
    out = RF.build_batch(BASE, rows, batch=batch, force=True)
    print("%s 重打：%d 件 → %s（%s）" % (batch, out["mpns"], out["path"],
                                       out.get("status_code")))
    print("  ZIP %.2f MB  %s" % ((out.get("bytes") or 0) / 1048576.0,
                                 out.get("zip")))
    if out.get("missing_artifacts"):
        print("  ! 缺产物：%s" % ", ".join(out["missing_artifacts"][:6]))
    if out.get("missing_pdf"):
        print("  ! 缺 PDF：%s" % ", ".join(out["missing_pdf"][:6]))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="review-fix 状态汇总 / 分批")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("status", help="各状态计数").set_defaults(fn=cmd_status)

    lp = sub.add_parser("list", help="逐型号列出")
    lp.add_argument("--state", default="all",
                    choices=["all", "pending", "blocked", "warn", "pass",
                             "incomplete"])
    lp.add_argument("--json", action="store_true")
    lp.set_defaults(fn=cmd_list)

    bp = sub.add_parser("build", help="分批物化成交付批次")
    bp.add_argument("--size", type=int, default=30)
    bp.add_argument("--max-batches", type=int, default=1, dest="max_batches")
    bp.add_argument("--dry-run", action="store_true", dest="dry_run")
    bp.set_defaults(fn=cmd_build)

    rp = sub.add_parser("rebuild", help="按已有批次重打（口径变更后刷新状态）")
    rp.add_argument("batch", help="批次号或批次目录")
    rp.set_defaults(fn=cmd_rebuild)

    a = ap.parse_args(argv)
    if not getattr(a, "fn", None):
        a = ap.parse_args((argv or []) + ["status"])
    return a.fn(a)


if __name__ == "__main__":
    raise SystemExit(main())
