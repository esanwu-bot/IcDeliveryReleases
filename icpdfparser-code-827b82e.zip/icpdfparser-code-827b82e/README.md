# IcPdfParser

元器件 Datasheet 流水线：**Excel 料号表 → 抓 PDF → 解析成结构化 JSON → 渲染成网站详情页 HTML 片段**（含替代型号内链与三视图）。

以 TI 料号表（110,271 行）为样本跑通，链路可平移到其他原厂。

> **工作台入口**：`python run_server.py` → <http://127.0.0.1:8000>
> 上传型号表即可排队跑完整链路（采集 → 解析 → 交付物料 → 预览 → 打包），详见 [`WORKBENCH.md`](WORKBENCH.md)。
>
> **接手请先读 [`HANDOFF.md`](HANDOFF.md)**（环境、数据契约、排障、待办）。
> 逐型号交付状态见 [`单个详情页交付清单.md`](单个详情页交付清单.md)（由 `delivery_report.py` 自动生成）。

## 目录

```
run_server.py           FastAPI 工作台入口（/ 打开管理界面）
run_worker.py           Celery worker 入口（消费 icpdf 队列）
start_workbench.ps1     Windows 一键启动/自检（Redis + worker + web）
stop.ps1               一键关停（server / worker / redis），支持 -DryRun / -KeepRedis
start_workbench.bat    同上，简易 bat 版
app/                    工作台：api / services（采集·流水线·图片SEO·打包）/ static
worker/                 Celery 应用与任务
parse_datasheets.py     PDF → JSON（本地抽文本层 + 单次 LLM 调用）
json_to_txt.py          JSON → 详情页 .txt（HTML 片段，按型号命名）
alternatives.py         替代型号：站内目录候选 → 目录内 AI 排序 → 渲染 5 列表格
symbol_svg.py           JSON → 三视图（原理图符号 / 封装 / 3D 示意，纯 SVG）
build_pkg_lib.py        按 package_type 批量预生成封装图库（同封装型号共用一张）
build_product_index.py  站内商品导出 → data/products.sqlite3（可再灌 MySQL）
delivery_report.py      产物盘点 → 单个详情页交付清单.md
json_to_db.py           JSON → MySQL 解析结果库（复查 / 重修 / 字段级审计）
pipeline/               链接解析与下载（第 0 步）
  resolver.py           URL 规范化 + 原厂规则库 + 料号直拼
  fetcher.py            下载（按 host 限并发、重试、%PDF 验真、sha256）
  extract.py            xlsx → 链接表（SQLite）
  cli.py                extract | download | probe | report
data/parsed/            解析结果 JSON + _summary.csv
data/txt/               渲染结果 {型号}.txt
data/alts/              替代型号 JSON + HTML + _missing_links.csv
data/symbols/           三视图 HTML
data/seo/               图片 SEO 清单（alt / title / 文件名）
data/pkgs/              共享封装图库（{KEY}.svg + {KEY}.3d.svg + _index.html 图墙）
data/workbench.sqlite3  工作台库（批次 / 型号任务 / 采集轨迹 / 事件，gitignore）
data/rebuilt/           从库导出的可编辑 JSON（重修用，gitignore）
data/products.sqlite3   站内目录 598,891 条（gitignore，用 build_product_index.py 重建）
sql/schema.sql          icpdf 库结构备份（9 表 + 2 视图，不含数据）
```

## 工作台（Web）

```bash
python run_server.py          # http://127.0.0.1:8000
python run_worker.py          # 另开一个窗口；Windows 用线程池
# 或 .\start_workbench.ps1（Redis + worker + web 一起拉起来；-Status 自检），停止用 .\stop.ps1
```

三份输入、三块能力：

| 输入 | 作用 |
|---|---|
| 客户型号表（xlsx/xls/csv） | 型号清单，按归一化料号全库去重入库 |
| 站内商品目录导出表 | 内链候选池；AI 只在其中排序（`data/products.sqlite3`） |
| 应用领域图片命名表 | 图片 SEO 的 alt / title / 文件名词表 |

一条链路：**采集各平台 Datasheet 链接 → 下载（%PDF 验真 + sha256）→ LLM 解析 → 详情页片段
→ 替代型号内链 → 三视图 → 图片 SEO**，每个型号 7 件交付物，可预览、可单件下载、可整包 ZIP。

任务走 Celery + Redis；Redis 不可用时自动降级为进程内线程池。
细节与排障见 [`WORKBENCH.md`](WORKBENCH.md)。

## 用法

```bash
# 1) 建链接表（110k 行约 60s）
python -m pipeline.cli extract
# 2) 分层抽样下载 10 份
python -m pipeline.cli download --limit 10 --stratified
# 3) PDF → JSON
python parse_datasheets.py --workers 3
# 4) JSON → 详情页 txt
python json_to_txt.py
# 5) 替代型号（先自检匹配器，再批量）
python alternatives.py --selftest
python alternatives.py --workers 3
# 6) 三视图（原理图符号 / 封装 / 3D）
python build_pkg_lib.py --all --preset   # 先按封装批量生成共享图库（85 种 / 1.5 MB）
python symbol_svg.py --pkg-lib data/pkgs # 详情页引用共享图，不再逐型号内联
# 7) 产物盘点 → 交付清单
python delivery_report.py
# 8) 解析结果落表（MySQL 8，复查/重修都靠它）
python json_to_db.py --init            # 建 9 表 + 2 视图
python json_to_db.py --load            # 幂等入库，内容变了自动升版
python json_to_db.py --report          # 缺口 / 型号改写 / 脚数对不上 / 命名混乱
# 重修闭环：导出 → 改 JSON → 灌回（自动 diff + 记审计）
python json_to_db.py --export
python json_to_db.py --load --src data/rebuilt --actor reviewer
# 备用网关：阿里云百炼
python parse_datasheets.py --backend dashscope
```

依赖：`openpyxl requests pypdf xlrd pymysql`（有 PyMuPDF 会自动优先使用）。
模型网关在 `.env.local` 配置，走 OpenAI 兼容协议：

```
AGNES_API_KEY=...
AGNES_API_BASE=https://apihub.agnes-ai.com/v1
AGNES_MODEL=agnes-3.0-flash
```

`.env.local` 已在 `.gitignore` 中，不入库。

## 抓取侧已验证的规则

| 来源 | 规则 |
|---|---|
| TI 网关 `suppproductinfo.tsp?gotoUrl=.../lit/gpn/<gpn>` | 请求 `/lit/gpn/<gpn>` 会 301 直跳当前 datasheet PDF |
| TI `lit/ds/symlink/<x>.pdf` | 料号稳定别名，去掉 `ts=` / `ref_url=` 后即为规范链接 |
| Rochester `rocelec.widen.net/view/pdf/<id>/<f>` | HTML 查看页，换 `/content/<id>/pdf/<f>` 才是文件本体 |
| DigiKey `mm.digikey.com/.../docus/...pdf` | 可直连，但部分已失效（抽样命中 62%），需回源原厂 |
| z2data | https 证书链异常，走 http 可取 |

抽样命中率：ti_symlink 88%、ti_lit 88%、widen 88%、z2data 100%、digikey 62%、other 12%。

## 解析侧要点

- 只抽参数页（`electrical characteristics` / `absolute maximum` / `pin functions` 等关键词，≤12 页 ≤32k 字符），省 token。
- `response_format=json_object` 强制 JSON，校验 10 个必填 key + `electrical ≥ 3`，失败自动修复重试一次。
- 无参数表特征词的文档直接判 `NOT_A_DATASHEET` 跳过，不调用模型（User Guide / Quick Start 这类）。
- 严禁模型插值：`value` 必须是表中原值，缺行就跳过该项。

## 替代型号（Alternative Parts）

工作台链路（catalog-first）：`datasheet ordering_info → 站内目录候选 → 必要时目录内 AI 排序 → 渲染`。

- **AI 不再自由生成料号**。候选池全部来自 `data/products.sqlite3`，模型只能在给定清单内
  挑选/排序/解释；输出必须原样命中候选 MPN，否则丢弃。站内目录没覆盖该系列时不调模型、
  不猜料号，直接产出「目录未覆盖」片段（旧模式实测提案过并不存在的 `nRF9050`）。
- **评估板/套件**（料号含 `EVM/EVK/EMK/EVB/EVAL/KIT/BOARD/MODULE` 或封装为 `PCB-UNK`）
  不参与芯片级替代：先从料号反推板载器件（`CC1020EMK-868 → CC1020`、
  `BQ25895EVM-664 → BQ25895`）再查目录，只输出板载器件的站内链接；整块板不拿芯片替代，也不调 AI。
- 线上段落结构（`#equivalent`）是 5 列表格：Part Number / Brand / Type / Package / Key Feature，
  只输出站内目录命中的 Part Number，输出 `<a href="/products/detail/{slug}-{id}" target="_blank">`。
  URL 规律：`slug = MPN 去非字母数字并小写`（`AD8606ARMZ-R7` → `ad8606armzr7`）。
- 匹配器两级：`exact`（归一化全等）+ `family`（剥掉 -R7/RL/TR/REEL 等包装后缀后同族）。
  工作台的前缀候选另加 `prefix_safe` 边界：短的一方后面紧跟数字视为另一颗芯片，
  所以 `LM35` 不会命中 `LM358`，而 `LM358DR` 可以命中 `LM358D`。
  自检用例见 `alternatives.py --selftest`（含 `0685T0750-01`、`LTM8053IY-1#PBF` 这类带符号料号）。
- AI 按需：`ordering_info` 的内链命中 ≥ `ICPDF_ALTS_MIN`（默认 3）就跳过；
  `ICPDF_ALTS_AI=always` 只强制做目录内排序，不再放开自由生成；
  `ICPDF_ALTS_POOL` 控制喂给模型的候选数上限（默认 60）。
- 每个候选再用本地料号库（10.8 万条）标 `verified`；未命中的进
  `data/alts/_missing_links.csv`（命令行批量模式）作为补货/入库清单。
- 站内目录索引：`data/products.sqlite3`（598,891 条，表 `catalog`）。
  由站点导出的 `Integrated Circuits (ICs).xls` 经 `build_product_index.py` 建成；
  `--index` 支持 sqlite3（默认）/ csv（种子）/ `mysql://root:root@127.0.0.1:3306/icpdf` 三种后端。
  注意该导出受 Excel 97 的 65.5 万行上限截断，实测有线上真页查不到，需换不截断的导出。

## 三视图（原理图符号 / 封装 / 3D）

`symbol_svg.py` 从 `pin_configuration` 与 `specs.package` 程序化生成 SVG，**不切 PDF 图、不用 AI 生图**——
引脚数/编号/1 脚标记必须精确，且同型号要能缓存复用。PDF 里没有 3D 数据，3D 一格是按封装类型画的等轴测示意。
无 `pin_configuration` 的文档（评估板类）自动跳过。

## 已知问题

- EVM / 整机类 PDF 会让模型把 `basic_info.mpn` 改写成板载真实器件（`2MTR-DYNO` → `TMS320F28062`）。页面主键应保留请求料号，需要 `device_mpn` 字段区分。
- 详情页的 Technical Insight / FAQ 目前是规则拼装，尚未接 LLM 润色。
