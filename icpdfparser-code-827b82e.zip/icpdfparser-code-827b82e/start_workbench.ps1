﻿<#
.SYNOPSIS
    IcPdfParser 工作台一键启动脚本（Redis + Celery worker + FastAPI）。

.DESCRIPTION
    依次做四件事：
      1. 找可用的 Python（优先项目 venv）并自检依赖；
      2. 确认 6379 上的 Redis 可用，没起就用 tools\redis 的便携版拉起；
      3. 启动 Celery worker（消费 icpdf 队列）；
      4. 启动 FastAPI 工作台，等 /api/health 通了再打开浏览器。

    Redis 起不来不影响使用：工作台会自动降级为进程内线程池，
    只是任务不能跨进程分发、重启会丢队列。

.EXAMPLE
    .\start_workbench.ps1
    默认端口 8000、解析并发 2、自动开浏览器。

.EXAMPLE
    .\start_workbench.ps1 -Port 8080 -Workers 3

.EXAMPLE
    .\start_workbench.ps1 -Status
    只做环境自检，不启动任何进程。

.EXAMPLE
    .\start_workbench.ps1 -Stop
    停掉本目录启动过的 server / worker / redis。

.NOTES
    Windows PowerShell 5.1 兼容。若提示脚本被禁止运行，用：
        powershell -ExecutionPolicy Bypass -File .\start_workbench.ps1
#>
param(
    [int]$Port = 8000,
    [int]$Workers = 2,
    [switch]$NoBrowser,
    [switch]$NoRedis,
    [switch]$Status,
    [switch]$Stop
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$script:step = 1

function Step($msg) { Write-Host ("[{0}] {1}" -f $script:step, $msg) -ForegroundColor Cyan; $script:step++ }
function Ok($msg)   { Write-Host ("      {0}" -f $msg) -ForegroundColor DarkGreen }
function Warn($msg) { Write-Host ("      {0}" -f $msg) -ForegroundColor Yellow }
function Err($msg)  { Write-Host ("      {0}" -f $msg) -ForegroundColor Red }

function Test-Port {
    param([string]$TargetHost = '127.0.0.1', [int]$TargetPort, [int]$TimeoutMs = 700)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($TargetHost, $TargetPort, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            $client.EndConnect($iar)
            return $true
        }
        return $false
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Find-Python {
    $candidates = @(
        'C:\Users\Administrator\.workbuddy-ai\binaries\python\envs\default\Scripts\python.exe',
        (Join-Path $Root '.venv\Scripts\python.exe'),
        (Join-Path $Root 'venv\Scripts\python.exe')
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Get-Health {
    param([int]$TargetPort)
    try {
        $r = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/api/health" -f $TargetPort) -TimeoutSec 2
        return $r
    } catch {
        return $null
    }
}

function Get-OwnProcess {
    <# 只挑本目录启动过的进程，避免误杀别的项目同名的 python。 #>
    $keys = @('run_server.py', 'run_worker.py', 'icpdf.conf')
    $list = @()
    try {
        $procs = Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='redis-server.exe' OR Name='cmd.exe'" -ErrorAction Stop
    } catch {
        return $list
    }
    foreach ($p in $procs) {
        $cl = $p.CommandLine
        if (-not $cl) { continue }
        if ($cl -notlike "*$Root*" -and $cl -notlike '*run_server.py*' -and $cl -notlike '*run_worker.py*') { continue }
        foreach ($k in $keys) {
            if ($cl -like "*$k*") { $list += $p; break }
        }
    }
    return $list
}

# ============================================================ -Stop
if ($Stop) {
    # 关停逻辑统一在 stop.ps1，这里只做转发，避免两套实现漂移
    $stopScript = Join-Path $Root 'stop.ps1'
    if (Test-Path $stopScript) {
        & $stopScript -Port $Port -Yes
    } else {
        Warn "找不到 stop.ps1，请直接结束 python / redis-server 进程"
    }
    return
}

# ============================================================ 环境自检
Step "环境自检"
$Python = Find-Python
if (-not $Python) {
    Err "没找到 Python。请安装 Python 3.11+，或在本目录建 .venv 后重试。"
    exit 1
}
$ver = & $Python -c "import sys; print('.'.join(map(str, sys.version_info[:3])))" 2>$null
Ok ("Python {0}" -f $ver)
Ok $Python

$depCheck = & $Python -c "import fastapi, uvicorn, celery, redis, openpyxl, pypdf, xlrd; print('ok')" 2>&1
if ($depCheck -notmatch '^ok') {
    Err "依赖不全，先执行：`"$Python`" -m pip install -r requirements.txt"
    Warn ($depCheck -join ' ')
    exit 1
}
Ok "依赖齐全（fastapi / uvicorn / celery / redis / openpyxl / pypdf / xlrd）"

$indexDb = Join-Path $Root 'data\products.sqlite3'
if (Test-Path $indexDb) {
    $mb = [math]::Round((Get-Item $indexDb).Length / 1MB, 1)
    Ok ("内链索引 {0} MB" -f $mb)
} else {
    Warn "内链索引缺失（data\products.sqlite3），工作台「数据源」页可上传站内目录重建"
}

$workDb = Join-Path $Root 'data\workbench.sqlite3'
if (Test-Path $workDb) { Ok ("工作台库 {0} MB" -f [math]::Round((Get-Item $workDb).Length / 1MB, 1)) }

# ============================================================ 状态模式
if ($Status) {
    Step "运行状态"
    $redisUp = Test-Port -TargetPort 6379
    if ($redisUp) { Ok "Redis 6379：通" } else { Warn "Redis 6379：不通（工作台会降级为线程池）" }

    $h = Get-Health -TargetPort $Port
    if ($h) {
        Ok ("Web {0}：已在运行（队列模式 {1}）" -f $Port, $h.mode)
    } else {
        Warn ("Web {0}：未启动" -f $Port)
    }

    $running = Get-OwnProcess
    if ($running.Count -gt 0) {
        foreach ($p in $running) {
            $tag = '进程'
            if ($p.CommandLine -like '*run_server.py*') { $tag = 'server' }
            elseif ($p.CommandLine -like '*run_worker.py*') { $tag = 'worker' }
            elseif ($p.CommandLine -like '*icpdf.conf*') { $tag = 'redis' }
            Ok ("PID {0}  {1}  ({2})" -f $p.ProcessId, $p.Name, $tag)
        }
    } else {
        Warn "没有本目录启动的后台进程"
    }
    return
}

# ============================================================ Redis
if (-not $NoRedis) {
    Step "Redis"
    if (Test-Port -TargetPort 6379) {
        Ok "6379 已在监听，复用现有 Redis"
    } else {
        $redisExe = Join-Path $Root 'tools\redis\redis-server.exe'
        $redisConf = Join-Path $Root 'tools\redis\icpdf.conf'
        if ((Test-Path $redisExe) -and (Test-Path $redisConf)) {
            Start-Process -FilePath $redisExe -ArgumentList @($redisConf) `
                -WorkingDirectory (Join-Path $Root 'tools\redis') -WindowStyle Minimized
            $waited = 0
            while (-not (Test-Port -TargetPort 6379) -and $waited -lt 10) {
                Start-Sleep -Milliseconds 500
                $waited++
            }
            if (Test-Port -TargetPort 6379) { Ok "便携版 Redis 已启动（tools\redis）" }
            else { Warn "Redis 启动失败，将降级为进程内线程池" }
        } else {
            Warn "没找到 tools\redis\redis-server.exe，将降级为进程内线程池"
        }
    }
} else {
    Warn "已指定 -NoRedis，跳过 Redis 检查（需要降级线程池模式）"
}

# ============================================================ Celery worker
Step "Celery worker"
$WorkerPid = $null
$already = Get-OwnProcess | Where-Object { $_.CommandLine -like '*run_worker.py*' }
if ($already) {
    $WorkerPid = $already[0].ProcessId
    Ok ("已在运行（PID {0}），不重复启动" -f $WorkerPid)
} else {
    $workerCmd = '""{0}" -u run_worker.py -c {1}"' -f $Python, $Workers
    $wk = Start-Process -FilePath 'cmd.exe' -ArgumentList "/k $workerCmd" -WorkingDirectory $Root -PassThru
    Start-Sleep -Milliseconds 800
    $child = Get-CimInstance Win32_Process -Filter ("ParentProcessId=" + $wk.Id) -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($child) { $WorkerPid = $child.ProcessId } else { $WorkerPid = $wk.Id }
    Ok ("已启动（并发 {0}），窗口标题 icpdf-worker，PID {1}" -f $Workers, $WorkerPid)
}

# ============================================================ FastAPI
Step "工作台服务"
$h = Get-Health -TargetPort $Port
if ($h) {
    Ok ("端口 {0} 已有工作台在跑（队列模式 {1}），直接复用" -f $Port, $h.mode)
} elseif (Test-Port -TargetPort $Port) {
    Warn ("端口 {0} 被其他程序占用，请用 -Port 换一个端口" -f $Port)
    exit 1
} else {
    $serverCmd = '""{0}" -u run_server.py --port {1}"' -f $Python, $Port
    Start-Process -FilePath 'cmd.exe' -ArgumentList "/k $serverCmd" -WorkingDirectory $Root | Out-Null

    $waited = 0
    while (-not (Get-Health -TargetPort $Port) -and $waited -lt 40) {
        Start-Sleep -Milliseconds 500
        $waited++
    }
    $h = Get-Health -TargetPort $Port
    if ($h) { Ok ("已就绪：http://127.0.0.1:{0}（队列模式 {1}）" -f $Port, $h.mode) }
    else {
        Err "服务在 20 秒内没有就绪，看那个 cmd 窗口的报错，或查 data\_server.log"
        exit 1
    }
}

# ============================================================ 收尾
# 记下 PID，stop.ps1 据此精确关停（不靠命令行模糊匹配）
$srvPid = $null
try {
    $conn = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop | Select-Object -First 1
    if ($conn) { $srvPid = $conn.OwningProcess }
} catch { $srvPid = $null }

$redisPid = $null
$redisProc = Get-CimInstance Win32_Process -Filter "Name='redis-server.exe'" -ErrorAction SilentlyContinue |
             Where-Object { $_.CommandLine -like '*icpdf.conf*' } | Select-Object -First 1
if ($redisProc) { $redisPid = $redisProc.ProcessId }

$pidFile = Join-Path $Root 'data\workbench.pids'
$lines = @(
    ("port={0}" -f $Port),
    ("server={0}" -f $srvPid),
    ("worker={0}" -f $WorkerPid),
    ("redis={0}" -f $redisPid),
    ("started={0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
)
Set-Content -Path $pidFile -Value $lines -Encoding ASCII
Ok ("PID 记录 -> {0}" -f $pidFile)

if (-not $NoBrowser) { Start-Process ("http://127.0.0.1:{0}" -f $Port) | Out-Null }

Write-Host ""
Write-Host "----------------------------------------" -ForegroundColor DarkGray
Write-Host (" 工作台  http://127.0.0.1:{0}" -f $Port)
Write-Host " 停止    .\stop.ps1"
Write-Host " 自检    .\start_workbench.ps1 -Status"
Write-Host "----------------------------------------" -ForegroundColor DarkGray
