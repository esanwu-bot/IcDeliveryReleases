"""Global config for the datasheet pipeline."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
XLSX = ROOT / "Texas Instruments.xlsx"
DATA = ROOT / "data"
DB = DATA / "icpdf.sqlite3"
PDF_DIR = DATA / "pdfs"
MANIFEST = DATA / "manifest.csv"
REPORT = DATA / "report.md"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
HEADERS = {
    "User-Agent": UA,
    "Accept": "application/pdf,text/html;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

# per-host politeness: max concurrent requests per hostname
HOST_CONCURRENCY = int(os.getenv("ICPDF_HOST_CONCURRENCY", "3"))

# 被封站点换镜像：ICPDF_HOST_REWRITE="www.ti.com=www.ti.com.cn"
# DigitalOcean 机房 IP 访问 www.ti.com 被 Akamai 按 IP 段返回 403，www.ti.com.cn 可正常取到同一份 PDF。
HOST_REWRITE = {
    old.strip(): new.strip()
    for old, _, new in (x.partition("=") for x in os.getenv("ICPDF_HOST_REWRITE", "").split(","))
    if old.strip() and new.strip()
}
TIMEOUT = (10, 45)          # connect, read
RETRIES = 3
BACKOFF = 1.8               # seconds, exponential
MIN_PDF_BYTES = 8 * 1024    # anything smaller is not a real datasheet
