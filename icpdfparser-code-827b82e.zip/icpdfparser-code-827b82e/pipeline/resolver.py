"""URL canonicalisation + source classification.

The whole point: the same datasheet shows up as dozens of URLs (tracking
params, digikey CDN vs TI alias, gateway redirects). Canonicalise first,
otherwise dedup never works.
"""
import re
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit, unquote

TRACKING = {
    "ts", "ref_url", "utm_source", "utm_medium", "utm_campaign", "utm_term",
    "utm_content", "hqs", "elqtrackid", "elqtrack", "_ga", "t.download", "u",
    "distid", "srsltid", "gclid",
}


def canon(url: str) -> str:
    """Strip tracking params, normalise scheme/host, drop fragment."""
    p = urlsplit(url.strip())
    scheme = "https" if p.scheme in ("http", "https") else p.scheme
    netloc = p.netloc.lower()
    q = {
        k: v for k, v in parse_qs(p.query, keep_blank_values=False).items()
        if k.lower() not in TRACKING
    }
    return urlunsplit((scheme, netloc, p.path, urlencode(q, True), ""))


def doc_key(url: str) -> str:
    """Stable identity of the *target document* for queue-level dedup.

    Two levels of dedup exist on purpose:
      - doc_key  : same request target  -> don't fetch twice
      - pdf_hash : same bytes           -> same datasheet reached via different hosts
    """
    if not url:
        return "none"
    st = source_type(url)
    if st == "ti_gateway":
        gpn = _gpn_from_gateway(url)
        if gpn:
            return f"ti.com/gpn/{gpn}"
    return canon(url)


def source_type(url: str) -> str:
    u = url.lower()
    if not u:
        return "no_url"
    path = urlsplit(u).path          # only the PATH decides the type; ?ref_url= may contain anything
    if "suppproductinfo" in path:
        return "ti_gateway"
    if "/lit/ds/symlink/" in path:
        return "ti_symlink"
    if "/lit/ds/" in path:
        return "ti_lit"
    if "/lit/ug/" in path or "/lit/an/" in path or "/lit/wp/" in path or "/lit/ml/" in path:
        return "ti_lit_doc"          # user guide / app note / whitepaper, not a datasheet
    if "mm.digikey.com" in u:
        return "digikey_cdn"
    if "widen.net" in u:
        return "widen_rocelec"
    if "z2data" in u:
        return "z2data"
    return "other"


def _gpn_from_gateway(url: str) -> str | None:
    """ti.com/general/docs/suppproductinfo.tsp?gotoUrl=...%2Flit%2Fgpn%2F<gpn>"""
    q = parse_qs(urlsplit(url).query)
    goto = (q.get("gotoUrl") or q.get("gotourl") or [""])[0]
    goto = unquote(goto)                      # may be double encoded
    if "gotoUrl=" in goto:
        goto = unquote(goto.split("gotoUrl=", 1)[1])
    m = re.search(r"/lit/(?:gpn|ds/symlink)/([A-Za-z0-9_\-.]+?)(?:\.pdf)?/?$", goto, re.I)
    return m.group(1).lower() if m else None


def candidates(raw_url: str) -> list[tuple[str, str]]:
    """Ordered resolution chain for one raw URL. Returns [(stage, url), ...]."""
    raw_url = (raw_url or "").strip()
    out: list[tuple[str, str]] = []
    st = source_type(raw_url)

    if st == "ti_gateway":
        gpn = _gpn_from_gateway(raw_url)
        if gpn:
            # /lit/gpn/<gpn> 301s straight to the current datasheet PDF
            out.append(("ti_gpn_probe", f"https://www.ti.com/lit/gpn/{gpn}"))
            out.append(("ti_symlink_pattern", f"https://www.ti.com/lit/ds/symlink/{gpn}.pdf"))
    elif st == "ti_symlink":
        out.append(("ti_symlink", canon(raw_url)))
    elif st == "ti_lit":
        out.append(("ti_lit", canon(raw_url)))
    elif st == "digikey_cdn":
        out.append(("digikey_cdn", canon(raw_url)))
    elif st == "widen_rocelec":
        # /view/pdf/<id>/<file>.pdf is an HTML viewer; /content/<id>/pdf/<file>.pdf is the file
        m = re.search(r"/view/pdf/([^/]+)/(.+)$", raw_url, re.I)
        if m:
            out.append(("widen_content", f"https://rocelec.widen.net/content/{m.group(1)}/pdf/{m.group(2)}"))
        out.append(("widen_direct", canon(raw_url)))
    elif st == "z2data":
        c = canon(raw_url)
        out.append(("z2data", c))
        if c.startswith("https://"):
            out.append(("z2data_http", "http://" + c[8:]))   # broken TLS chain upstream
    elif st == "no_url":
        pass
    else:
        out.append(("passthrough", canon(raw_url)))
    return out


def mpn_patterns(mfr: str, mpn: str) -> list[tuple[str, str]]:
    """Vendor URL pattern library + prefix trimming (HEAD-validated by caller).

    Used when the sheet has no usable link (5,168 rows) or every stage above failed.
    """
    mfr = (mfr or "").lower()
    mpn = re.sub(r"[^A-Za-z0-9\-]", "", (mpn or "")).lower()
    if not mpn:
        return []
    # progressively trim package/tape suffixes: drv632pwr -> drv632, tms320f28062f -> tms320f28062
    bases, cur = [], mpn
    for _ in range(3):
        trimmed = re.sub(r"(?:[a-z]{1,3}\d{0,3}|r2|reel|tr|ct)$", "", cur)
        if trimmed == cur or len(trimmed) < 4:
            break
        bases.append(trimmed)
        cur = trimmed
    stems = [mpn] + bases

    out = []
    for s in stems:
        if mfr.startswith("texas") or mfr == "ti":
            out.append(("ti_pattern", f"https://www.ti.com/lit/ds/symlink/{s}.pdf"))
        elif mfr.startswith("st"):
            out.append(("st_pattern", f"https://www.st.com/resource/en/datasheet/{s}.pdf"))
        elif mfr.startswith("microchip"):
            out.append(("microchip_pattern", f"https://ww1.microchip.com/downloads/en/DeviceDoc/{s}.pdf"))
        elif mfr.startswith("analog") or mfr == "adi":
            out.append(("adi_pattern", f"https://www.analog.com/media/en/technical-documentation/data-sheets/{s}.pdf"))
        elif mfr.startswith("onsemi") or mfr.startswith("on semi"):
            out.append(("onsemi_pattern", f"https://www.onsemi.com/pdf/datasheet/{s}-d.pdf"))
    return out
