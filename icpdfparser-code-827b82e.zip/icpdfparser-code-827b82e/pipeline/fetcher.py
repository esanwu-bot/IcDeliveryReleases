"""Fetch layer: per-host politeness, retry/backoff, PDF magic validation, sha256."""
import hashlib
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit

import requests
import urllib3

from . import config

urllib3.disable_warnings()

_local = threading.local()
_host_locks: dict[str, threading.Semaphore] = {}
_guard = threading.Lock()


def session() -> requests.Session:
    s = getattr(_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers.update(config.HEADERS)
        _local.s = s
    return s


def host_slot(host: str) -> threading.Semaphore:
    with _guard:
        if host not in _host_locks:
            _host_locks[host] = threading.Semaphore(config.HOST_CONCURRENCY)
        return _host_locks[host]


class NotPdf(Exception):
    pass


def _looks_pdf(head: bytes, ctype: str) -> bool:
    return head.startswith(b"%PDF") or ("pdf" in (ctype or "").lower() and not head.lstrip()[:1] == b"<")


def rewrite_url(url: str) -> str:
    """按 config.HOST_REWRITE 把被封站点换到可用镜像（如 www.ti.com -> www.ti.com.cn）。

    TI 网关的 gotoUrl 是查询串里的完整地址，一并替换；负向前瞻避免把
    已经是 www.ti.com.cn 的地址二次替换。
    """
    for old, new in config.HOST_REWRITE.items():
        url = re.sub(rf"{re.escape(old)}(?!\.[A-Za-z])", new, url)
    return url


def fetch_pdf(url: str, dest: Path, retries: int | None = None,
              deadline: float | None = None) -> dict:
    """Download one URL to dest. Raises NotPdf / requests exceptions.

    retries 缺省用 config.RETRIES（命令行口径）；工作台传更小的值，
    避免一次下载失败就把并发槽位占上两分钟。deadline 是 monotonic 绝对时间，
    给定时单次请求和重试都不能越过它 —— 采集预算必须硬生效，否则一条慢链
    会把 fetch 槽位占到 2 分钟以上。

    Returns {final_url, bytes, sha256, http_status}.
    """
    url = rewrite_url(url)
    host = urlsplit(url).netloc.lower()
    tries = retries if retries is not None else config.RETRIES
    last = None
    for attempt in range(1, tries + 1):
        if deadline is not None:
            remain = deadline - time.monotonic()
            if remain <= 1.0:
                raise last if last else TimeoutError("fetch deadline exceeded")
            timeout = (min(config.TIMEOUT[0], remain), min(config.TIMEOUT[1], remain))
        else:
            timeout = config.TIMEOUT
        r = None
        try:
            with host_slot(host):
                r = session().get(url, timeout=timeout, stream=True,
                                  allow_redirects=True, verify=False)
                status = r.status_code
                if status not in (200, 206):
                    r.close()
                    raise requests.HTTPError(f"HTTP {status}")
                ctype = r.headers.get("Content-Type", "")
                chunks = r.iter_content(64 * 1024)
                head = b""
                h = hashlib.sha256()
                size = 0
                dest.parent.mkdir(parents=True, exist_ok=True)
                tmp = dest.with_suffix(dest.suffix + ".part")
                with open(tmp, "wb") as f:
                    for ch in chunks:
                        if not ch:
                            continue
                        if deadline is not None and time.monotonic() > deadline:
                            raise requests.Timeout("fetch deadline exceeded")
                        if size == 0:
                            head = ch[:8]
                            if not _looks_pdf(head, ctype):
                                f.close()
                                tmp.unlink(missing_ok=True)
                                r.close()
                                raise NotPdf(f"not a pdf: ctype={ctype!r} head={head!r}")
                        f.write(ch)
                        h.update(ch)
                        size += len(ch)
                r.close()
                if size < config.MIN_PDF_BYTES:
                    tmp.unlink(missing_ok=True)
                    raise NotPdf(f"too small: {size} bytes")
                os.replace(tmp, dest)
                return {"final_url": r.url, "bytes": size, "sha256": h.hexdigest(),
                        "http_status": status}
        except NotPdf:
            raise
        except Exception as e:                      # noqa: BLE001 - network is messy
            last = e
            if r is not None:
                try:
                    r.close()
                except Exception:                   # noqa: BLE001
                    pass
            dest.with_suffix(dest.suffix + ".part").unlink(missing_ok=True)
            if attempt < tries and (deadline is None or time.monotonic() < deadline):
                time.sleep(config.BACKOFF ** attempt)
    raise last if last else RuntimeError("unknown fetch failure")


def probe(url: str) -> tuple[bool, str]:
    """Cheap validation used by the pattern-library stage (HEAD, then 5-byte GET)."""
    url = rewrite_url(url)
    try:
        with host_slot(urlsplit(url).netloc.lower()):
            r = session().head(url, timeout=(8, 20), allow_redirects=True, verify=False)
            if r.status_code in (200, 206) and "pdf" in r.headers.get("Content-Type", "").lower():
                return True, r.url
            r = session().get(url, timeout=(8, 20), allow_redirects=True, verify=False,
                              headers={"Range": "bytes=0-4"}, stream=True)
            ok = r.status_code in (200, 206) and r.raw.read(5).startswith(b"%PDF")
            final = r.url
            r.close()
            return ok, final
    except Exception as e:                          # noqa: BLE001
        return False, f"{type(e).__name__}"
