"""Datasheet resolution & archiving pipeline."""
