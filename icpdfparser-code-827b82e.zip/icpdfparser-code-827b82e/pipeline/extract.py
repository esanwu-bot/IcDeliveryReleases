"""Step 0 of the pipeline: xlsx -> link table (with canonical URL + doc key)."""
import collections
import sqlite3
import sys

import openpyxl

from . import config, resolver, store


def run() -> None:
    if not config.XLSX.exists():
        sys.exit(f"missing workbook: {config.XLSX}")

    config.DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(config.DB, timeout=60)
    # bulk-load tuning: no rollback journal, indexes built afterwards
    con.executescript("""
        PRAGMA journal_mode=OFF;
        PRAGMA synchronous=OFF;
        PRAGMA temp_store=MEMORY;
        PRAGMA cache_size=-200000;
        DROP TABLE IF EXISTS links;
        CREATE TABLE links (
            id INTEGER PRIMARY KEY,
            mpn TEXT NOT NULL,
            brand TEXT,
            package TEXT,
            raw_url TEXT,
            source TEXT,
            canon_url TEXT,
            doc_key TEXT
        );
    """)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS docs (
            doc_key TEXT PRIMARY KEY, mpn TEXT, source TEXT, raw_url TEXT,
            final_url TEXT, pdf_hash TEXT, bytes INTEGER, path TEXT,
            http_status INTEGER, attempts INTEGER DEFAULT 0, status TEXT,
            error TEXT, fetched_at TEXT
        );
    """)
    con.commit()

    wb = openpyxl.load_workbook(config.XLSX, read_only=True, data_only=True)
    ws = wb.worksheets[0]
    batch, total, stats = [], 0, collections.Counter()

    def flush():
        con.executemany(
            "INSERT INTO links (mpn,brand,package,raw_url,source,canon_url,doc_key) "
            "VALUES (?,?,?,?,?,?,?)", batch)
        con.commit()
        batch.clear()

    for row in ws.iter_rows(min_row=2, values_only=True):
        cells = list(row) + [None] * 6
        mpn, brand, pkg, _pack, _desc, url = cells[:6]
        if not mpn:
            continue
        raw = str(url).strip() if url else ""
        st = resolver.source_type(raw)
        c = resolver.canon(raw) if raw else ""
        batch.append((str(mpn).strip(), brand, pkg, raw, st, c,
                      resolver.doc_key(c) if c else f"none/{str(mpn).lower()}"))
        stats[st] += 1
        total += 1
        if len(batch) >= 10000:
            flush()
    flush()
    wb.close()

    con.executescript("""
        CREATE INDEX IF NOT EXISTS idx_links_key ON links(doc_key);
        CREATE INDEX IF NOT EXISTS idx_links_mpn ON links(mpn);
        PRAGMA journal_mode=WAL;
    """)
    con.commit()

    uniq_docs = con.execute("SELECT COUNT(DISTINCT doc_key) FROM links").fetchone()[0]
    uniq_urls = con.execute("SELECT COUNT(DISTINCT canon_url) FROM links WHERE canon_url<>''").fetchone()[0]
    print(f"rows={total}  unique_canon_urls={uniq_urls}  unique_doc_keys={uniq_docs}")
    for k, v in stats.most_common():
        print(f"  {v:>7}  {k}")
    con.close()
