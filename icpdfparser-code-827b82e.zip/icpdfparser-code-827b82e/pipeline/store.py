"""SQLite store: link table + document table (the 'link table' from the plan)."""
import sqlite3
from datetime import datetime, timezone

from .config import DB

DDL = """
CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY,
    mpn TEXT NOT NULL,
    brand TEXT,
    package TEXT,
    raw_url TEXT,
    source TEXT,
    canon_url TEXT,
    doc_key TEXT
);
CREATE INDEX IF NOT EXISTS idx_links_key ON links(doc_key);
CREATE INDEX IF NOT EXISTS idx_links_mpn ON links(mpn);

CREATE TABLE IF NOT EXISTS docs (
    doc_key TEXT PRIMARY KEY,
    mpn TEXT,
    source TEXT,              -- stage that resolved it
    raw_url TEXT,
    final_url TEXT,           -- after redirects
    pdf_hash TEXT,
    bytes INTEGER,
    path TEXT,
    http_status INTEGER,
    attempts INTEGER DEFAULT 0,
    status TEXT,              -- ok | failed | skipped_dup
    error TEXT,
    fetched_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_docs_status ON docs(status);
"""


def connect() -> sqlite3.Connection:
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=30)
    con.executescript(DDL)
    con.row_factory = sqlite3.Row
    return con


def now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def upsert_doc(con, row: dict) -> None:
    cols = ",".join(row)
    ph = ",".join("?" * len(row))
    upd = ",".join(f"{k}=excluded.{k}" for k in row if k != "doc_key")
    con.execute(
        f"INSERT INTO docs ({cols}) VALUES ({ph}) "
        f"ON CONFLICT(doc_key) DO UPDATE SET {upd}",
        list(row.values()),
    )
    con.commit()
