"""CLI: extract | download | report.

    python -m pipeline.cli extract
    python -m pipeline.cli download --limit 10 --stratified
    python -m pipeline.cli report
"""
import argparse
import csv
import re
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urlsplit

from . import config, extract, fetcher, resolver, store

PRIORITY = ["ti_symlink", "ti_lit", "ti_gateway", "digikey_cdn", "widen_rocelec",
            "z2data", "other", "no_url"]


# ---------------------------------------------------------------- selection
def pick_rows(con: sqlite3.Connection, limit: int, stratified: bool) -> list[sqlite3.Row]:
    done = {r[0] for r in con.execute("SELECT doc_key FROM docs WHERE status='ok'")}
    q = ("SELECT l.* FROM links l JOIN (SELECT doc_key, MIN(id) mid FROM links GROUP BY doc_key) "
         "t ON l.id=t.mid ORDER BY l.id")
    rows = [r for r in con.execute(q) if r["doc_key"] not in done]
    if not stratified:
        return rows[:limit]
    buckets: dict[str, list] = {k: [] for k in PRIORITY}
    for r in rows:
        buckets.setdefault(r["source"], []).append(r)
    out, i = [], 0
    while len(out) < limit and any(buckets.values()):
        for k in PRIORITY:
            if buckets.get(k) and len(out) < limit:
                out.append(buckets[k].pop(0))
        i += 1
        if i > 10000:
            break
    return out


# ---------------------------------------------------------------- one row
def safe(s: str, n: int = 60) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)[:n].strip("_")


def process(con_factory, row: sqlite3.Row, seen_hashes: set[str]) -> dict:
    con = con_factory()
    mpn, raw = row["mpn"], row["raw_url"] or ""
    stages = resolver.candidates(raw)
    if row["source"] == "no_url":
        stages = []
    stages += resolver.mpn_patterns(row["brand"], mpn)

    tried, last_err = [], None
    for stage, url in stages:
        dest_name = f"{safe(mpn)}__{safe(Path(urlsplit(url).path).stem)}.pdf"
        dest = config.PDF_DIR / dest_name
        try:
            info = fetcher.fetch_pdf(url, dest)
        except fetcher.NotPdf as e:
            tried.append(f"{stage}:notpdf")
            last_err = str(e)
            continue
        except Exception as e:                                  # noqa: BLE001
            tried.append(f"{stage}:{type(e).__name__}")
            last_err = f"{type(e).__name__}: {e}"[:300]
            continue

        if info["sha256"] in seen_hashes:
            dest.unlink(missing_ok=True)
            rec = dict(doc_key=row["doc_key"], mpn=mpn, source=stage, raw_url=raw,
                       final_url=info["final_url"], pdf_hash=info["sha256"],
                       bytes=info["bytes"], path="", http_status=info["http_status"],
                       attempts=len(tried) + 1, status="skipped_dup", error=None,
                       fetched_at=store.now())
            store.upsert_doc(con, rec)
            con.close()
            return rec
        seen_hashes.add(info["sha256"])
        rec = dict(doc_key=row["doc_key"], mpn=mpn, source=stage, raw_url=raw,
                   final_url=info["final_url"], pdf_hash=info["sha256"],
                   bytes=info["bytes"], path=str(dest.relative_to(config.ROOT)),
                   http_status=info["http_status"], attempts=len(tried) + 1,
                   status="ok", error=None, fetched_at=store.now())
        store.upsert_doc(con, rec)
        con.close()
        return rec

    rec = dict(doc_key=row["doc_key"], mpn=mpn, source=", ".join(tried) or "none",
               raw_url=raw, final_url=None, pdf_hash=None, bytes=0, path="",
               http_status=None, attempts=len(tried), status="failed",
               error=last_err, fetched_at=store.now())
    store.upsert_doc(con, rec)
    con.close()
    return rec


def download(limit: int, stratified: bool, workers: int) -> None:
    config.PDF_DIR.mkdir(parents=True, exist_ok=True)
    con = store.connect()
    rows = pick_rows(con, limit, stratified)
    seen = {r[0] for r in con.execute("SELECT pdf_hash FROM docs WHERE status='ok'")}
    print(f"target={limit} selected={len(rows)} workers={workers}")

    ok = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(process, store.connect, r, seen): r for r in rows}
        for f in as_completed(futs):
            r = f.result()
            flag = {"ok": "OK ", "skipped_dup": "DUP", "failed": "ERR"}[r["status"]]
            print(f"[{flag}] {r['mpn']:<24} {r['source']:<24} "
                  f"{(r['path'] or r['error'] or '')[:70]}")
            if r["status"] == "ok":
                ok += 1
    print(f"\ndownloaded_ok={ok}")


# ---------------------------------------------------------------- coverage probe
def probe_sample(per_source: int, workers: int) -> None:
    """Cheap hit-rate estimation: HEAD/Range check only, no full download."""
    con = store.connect()
    picks = []
    for st in PRIORITY:
        rows = list(con.execute(
            "SELECT * FROM links WHERE source=? GROUP BY doc_key LIMIT ?", (st, per_source)))
        picks += rows
    print(f"probing {len(picks)} rows ({per_source}/source) ...")

    def one(r):
        stages = resolver.candidates(r["raw_url"] or "")
        if r["source"] == "no_url":
            stages = []
        stages += resolver.mpn_patterns(r["brand"], r["mpn"])
        for stage, url in stages[:3]:
            ok, info = fetcher.probe(url)
            if ok:
                return r["source"], stage, True
        return r["source"], (stages[0][0] if stages else "none"), False

    res: dict[str, list] = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for st, stage, ok in ex.map(one, picks):
            res.setdefault(st, []).append((ok, stage))
    print(f"\n{'source':<16} {'hit':>4} {'n':>4} {'rate':>6}  winning stage")
    for st in PRIORITY:
        if st not in res:
            continue
        arr = res[st]
        ok = sum(1 for x in arr if x[0])
        wins = {}
        for good, stage in arr:
            if good:
                wins[stage] = wins.get(stage, 0) + 1
        top = max(wins, key=wins.get) if wins else "-"
        print(f"{st:<16} {ok:>4} {len(arr):>4} {ok/len(arr)*100:>5.0f}%  {top}")


def report() -> None:
    con = store.connect()
    rows = list(con.execute("SELECT * FROM docs WHERE status='ok' ORDER BY fetched_at"))
    with open(config.MANIFEST, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["mpn", "source", "final_url", "sha256", "bytes", "local_path", "fetched_at"])
        for r in rows:
            w.writerow([r["mpn"], r["source"], r["final_url"], r["pdf_hash"],
                        r["bytes"], r["path"], r["fetched_at"]])
    total_rows = con.execute("SELECT COUNT(*) FROM links").fetchone()[0]
    uniq_docs = con.execute("SELECT COUNT(DISTINCT doc_key) FROM links").fetchone()[0]
    st = {r[0]: r[1] for r in con.execute("SELECT status, COUNT(*) FROM docs GROUP BY status")}
    src = list(con.execute("SELECT source, COUNT(*), SUM(bytes) FROM docs WHERE status='ok' "
                           "GROUP BY source ORDER BY 2 DESC"))
    print(f"links={total_rows} unique_docs={uniq_docs} docs={st} manifest={config.MANIFEST}")
    for s, c, b in src:
        print(f"  {c:>3} {s:<22} {(b or 0)/1e6:.2f} MB")


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("extract")
    d = sub.add_parser("download")
    d.add_argument("--limit", type=int, default=10)
    d.add_argument("--stratified", action="store_true")
    d.add_argument("--workers", type=int, default=4)
    sub.add_parser("report")
    p = sub.add_parser("probe")
    p.add_argument("--per-source", type=int, default=8)
    p.add_argument("--workers", type=int, default=6)
    a = ap.parse_args()

    if a.cmd == "extract":
        extract.run()
    elif a.cmd == "download":
        download(a.limit, a.stratified, a.workers)
    elif a.cmd == "probe":
        probe_sample(a.per_source, a.workers)
    else:
        report()


if __name__ == "__main__":
    main()
