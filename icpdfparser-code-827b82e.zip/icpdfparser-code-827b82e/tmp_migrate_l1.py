#!/usr/bin/env python
"""L1 队列迁移（一次性）：清掉旧 icpdf 队列里的全链路 parse_item 消息，
按 DB 中的真实状态重投到 fetch/llm/render 三段队列。

DB 是唯一真相源，队列消息只是派发快照；重投后积压量应与 status='queued' 对数。
用法：python tmp_migrate_l1.py [--dry-run]
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import redis                                              # noqa: E402

from app import config, db                               # noqa: E402

FETCH_LIKE = ("queued", "resolving", "downloading")
LLM_LIKE = ("parsing",)
RENDER_LIKE = ("rendering",)


def main() -> None:
    dry = "--dry-run" in sys.argv
    r = redis.Redis.from_url(config.REDIS_URL)
    old = int(r.llen(config.CELERY_QUEUE))
    print(f"[queue] {config.CELERY_QUEUE} 旧消息 {old} 条（parse_item 全链路）")

    rows = db.q(
        "SELECT id, mpn_key, status FROM item WHERE status IN (?,?,?,?,?) ORDER BY id",
        FETCH_LIKE + LLM_LIKE + RENDER_LIKE)
    counts = {"fetch_item": 0, "llm_item": 0, "render_item": 0}
    for row in rows:
        if row["status"] in FETCH_LIKE:
            counts["fetch_item"] += 1
        elif row["status"] in LLM_LIKE:
            counts["llm_item"] += 1
        else:
            counts["render_item"] += 1
    print(f"[db] 待重投 {len(rows)} 件：{counts}")
    if dry:
        return

    # 旧消息全部作废（同批型号会在下面按阶段重投，不会丢件）
    r.delete(config.CELERY_QUEUE)
    print(f"[queue] 已清空 {config.CELERY_QUEUE}")

    from app.services import dispatch

    for i, row in enumerate(rows, 1):
        status = row["status"]
        if status in LLM_LIKE:
            kind = "llm_item"
        elif status in RENDER_LIKE:
            kind = "render_item"
        else:
            kind = "fetch_item"
            if status != "queued":
                db.x("UPDATE item SET status='queued', stage='等待执行', progress=1, "
                     "updated_at=? WHERE id=?", (db.now(), row["id"]))
        dispatch.submit(kind, row["mpn_key"])
        if i % 2000 == 0:
            print(f"  重投 {i}/{len(rows)} ...")
    print(f"[done] 重投完成 {len(rows)} 件：{counts}")
    for q in (config.FETCH_QUEUE, config.CELERY_QUEUE, config.RENDER_QUEUE):
        print(f"[queue] {q} = {r.llen(q)}")


if __name__ == "__main__":
    main()
