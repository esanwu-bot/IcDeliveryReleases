﻿<#
.SYNOPSIS
    停止 IcPdfParser 工作台相关进程（FastAPI / Celery worker / 便携 Redis）。

.DESCRIPTION
    关停顺序：FastAPI 服务 -> Celery worker -> Redis（可用 -KeepRedis 保留）。
    定位进程的三条依据，按可靠性排序：
      1. data\workbench.pids（start_workbench.ps1 启动时写入，最精确）；
      2. 监听 -Port 的进程（只认命令行带 run_server.py 的，避免误杀别的服务）；
      3. 命令行含 run_worker.py / icpdf.conf 的进程（兜底手工启动的情况）。
    执行前会列出将要停止的进程；不带 -Yes 时需要确认。

.EXAMPLE
    .\stop.ps1                  # 确认后停止 server / worker / redis
    .\stop.ps1 -Yes             # 跳过确认
    .\stop.ps1 -KeepRedis       # 保留 Redis（下次启动更快）
    .\stop.ps1 -DryRun          # 只看看会停哪些，不动手

.NOTES
    Windows PowerShell 5.1 兼容，脚本存为 UTF-8 with BOM。
#>
param(
    [int]$Port = 8000,
    [switch]$KeepRedis,
    [switch]$Yes,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Ok($msg)   { Write-Host ("  [OK] {0}" -f $msg) -ForegroundColor DarkGreen }
function Info($msg) { Write-Host ("  {0}" -f $msg) -ForegroundColor Gray }
function Warn($msg) { Write-Host ("  [!] {0}" -f $msg) -ForegroundColor Yellow }
function Head($msg) { Write-Host $msg -ForegroundColor Cyan }

function Test-PortOpen {
    param([int]$TargetPort, [int]$TimeoutMs = 600)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect('127.0.0.1', $TargetPort, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            $client.EndConnect($iar)
            return $true
        }
        return $false
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

# ============================================================ 1. 收集候选
Head "定位工作台进程"

$pidFile = Join-Path $Root 'data\workbench.pids'
$fromFile = @{}
if (Test-Path $pidFile) {
    foreach ($line in (Get-Content $pidFile)) {
        if ($line -match '^\s*(\w+)\s*=\s*(\d+)\s*$') {
            $fromFile[$matches[1]] = [int]$matches[2]
        }
    }
    Info ("读取 {0}" -f $pidFile)
} else {
    Info "没有 PID 记录（可能是手工启动或已停止），改用端口与命令行匹配"
}

$allProcs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
$cands = @()

function Add-Cand {
    param([int]$ProcId, [string]$Role, $Proc)
    foreach ($c in $script:cands) { if ($c.ProcId -eq $ProcId) { return } }
    if (-not $Proc) { $Proc = $allProcs | Where-Object { $_.ProcessId -eq $ProcId } | Select-Object -First 1 }
    if (-not $Proc) { return }
    $script:cands += [pscustomobject]@{
        ProcId  = $ProcId
        Name    = $Proc.Name
        Role    = $Role
        Parent  = $Proc.ParentProcessId
        CmdLine = $Proc.CommandLine
    }
}

# 1.1 PID 文件
if ($fromFile.ContainsKey('server')) { Add-Cand -ProcId $fromFile['server'] -Role 'server' }
if ($fromFile.ContainsKey('worker')) { Add-Cand -ProcId $fromFile['worker'] -Role 'worker' }
if ($fromFile.ContainsKey('redis') -and -not $KeepRedis) { Add-Cand -ProcId $fromFile['redis'] -Role 'redis' }

# 1.2 监听 Port 的进程（必须确认是 run_server.py）
try {
    $conn = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop | Select-Object -First 1
    if ($conn) {
        $owner = $allProcs | Where-Object { $_.ProcessId -eq $conn.OwningProcess } | Select-Object -First 1
        if ($owner -and $owner.CommandLine -like '*run_server.py*') {
            Add-Cand -ProcId $owner.ProcessId -Role 'server' -Proc $owner
        } elseif ($owner) {
            Warn ("端口 {0} 被 {1}(PID {2}) 占用，但不是 run_server.py，跳过" -f $Port, $owner.Name, $owner.ProcessId)
        }
    }
} catch {
    Info ("端口 {0} 当前无监听" -f $Port)
}

# 1.3 命令行兜底
foreach ($p in $allProcs) {
    if (-not $p.CommandLine) { continue }
    if ($p.CommandLine -like '*run_worker.py*' -and $p.Name -eq 'python.exe') {
        Add-Cand -ProcId $p.ProcessId -Role 'worker' -Proc $p
    }
    if (-not $KeepRedis -and $p.CommandLine -like '*icpdf.conf*') {
        Add-Cand -ProcId $p.ProcessId -Role 'redis' -Proc $p
    }
    # 手工用 tools\redis 起的实例（没带 conf 参数）：按可执行文件路径判断，
    # 没启动 conf 时只取本目录下的 redis-server，绝不碰系统服务里那个
    if (-not $KeepRedis -and $p.Name -eq 'redis-server.exe' -and $p.ExecutablePath) {
        if ($p.ExecutablePath -like ("*" + $Root + "*")) {
            Add-Cand -ProcId $p.ProcessId -Role 'redis' -Proc $p
        }
    }
}

# 1.4 一并带上承载它们的 cmd 窗口（否则 python 被杀、黑窗口还留着）
$extra = @()
foreach ($c in $cands) {
    if (-not $c.Parent) { continue }
    $par = $allProcs | Where-Object { $_.ProcessId -eq $c.Parent } | Select-Object -First 1
    if (-not $par) { continue }
    if ($par.Name -ne 'cmd.exe') { continue }
    if ($par.CommandLine -notlike '*run_server.py*' -and $par.CommandLine -notlike '*run_worker.py*' -and $par.CommandLine -notlike '*redis-server*') { continue }
    $exists = $false
    foreach ($c2 in $cands) { if ($c2.ProcId -eq $par.ProcessId) { $exists = $true } }
    foreach ($e in $extra) { if ($e.ProcId -eq $par.ProcessId) { $exists = $true } }
    if (-not $exists) {
        $extra += [pscustomobject]@{
            ProcId = $par.ProcessId; Name = $par.Name; Role = 'cmd'; Parent = $par.ParentProcessId
            CmdLine = $par.CommandLine
        }
    }
}
$cands += $extra

# ============================================================ 2. 展示
if ($cands.Count -eq 0) {
    Ok "没有发现运行中的工作台进程"
    if (Test-PortOpen -TargetPort $Port) { Warn ("但端口 {0} 仍被占用，可用 netstat 查看" -f $Port) }
    if (Test-PortOpen -TargetPort 6379) { Info "Redis 6379 仍在运行（-KeepRedis 或非本目录实例）" }
    if (Test-Path $pidFile) { Remove-Item $pidFile -Force -ErrorAction SilentlyContinue }
    return
}

$order = @{ 'server' = 0; 'worker' = 1; 'redis' = 2; 'cmd' = 3 }
$cands = $cands | Sort-Object { $order[$_.Role] }

Head "将停止以下进程"
foreach ($c in $cands) {
    $cmd = ''
    if ($c.CmdLine) { $cmd = $c.CmdLine; if ($cmd.Length -gt 96) { $cmd = $cmd.Substring(0, 96) + '...' } }
    Write-Host ("  {0,-7} PID {1,-7} {2,-14} {3}" -f $c.Role, $c.ProcId, $c.Name, $cmd) -ForegroundColor White
}

if ($DryRun) {
    Warn "DryRun：仅列出，未执行停止"
    return
}

if (-not $Yes) {
    $ans = ''
    try { $ans = Read-Host "确认停止以上进程？输入 y 继续" } catch { $ans = '' }
    if ($ans -notmatch '^(y|yes)$') {
        Warn "已取消"
        return
    }
}

# ============================================================ 3. 停止
Head "停止中"
$failed = @()
foreach ($c in $cands) {
    try {
        $p = Get-Process -Id $c.ProcId -ErrorAction Stop
        Stop-Process -Id $c.ProcId -Force -ErrorAction Stop
        Ok ("{0}  PID {1}  {2} 已停止" -f $c.Role, $c.ProcId, $c.Name)
    } catch {
        $msg = $_.Exception.Message
        if ($msg -like '*Cannot find*' -or $msg -like '*找不到*' -or $msg -like '*no process*') {
            Info ("{0}  PID {1} 已不存在" -f $c.Role, $c.ProcId)
        } else {
            $failed += ("PID {0} {1}: {2}" -f $c.ProcId, $c.Name, $msg)
            Warn ("{0}  PID {1} 停止失败：{2}" -f $c.Role, $c.ProcId, $msg)
        }
    }
}

# ============================================================ 4. 校验
Head "校验端口"
$waited = 0
while ((Test-PortOpen -TargetPort $Port) -and $waited -lt 12) {
    Start-Sleep -Milliseconds 300
    $waited++
}
if (Test-PortOpen -TargetPort $Port) {
    Warn ("端口 {0} 仍在监听（可能有别的实例）" -f $Port)
} else {
    Ok ("端口 {0} 已释放" -f $Port)
}

if (-not (Test-PortOpen -TargetPort 6379)) {
    Ok "Redis 6379 已停止"
} elseif ($KeepRedis) {
    Info "Redis 6379 按 -KeepRedis 保留"
} else {
    Info "Redis 6379 仍在运行（不是本目录启动的实例）"
}

if (Test-Path $pidFile) {
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    Ok "已清理 data\workbench.pids"
}

Write-Host ""
if ($failed.Count -gt 0) {
    Warn ("有 {0} 个进程未能停止，请用管理员身份重试" -f $failed.Count)
    exit 1
}
Ok "工作台已停止"
