# AGENT.md — IcPdfParser 项目 Agent 规则

> 给在本仓库工作的所有 agent（含未来的你）。违反铁律 = 返工。

## 1. HANDOFF 与交付定义

- **1.1** 每次工作收尾必须追加 `HANDOFF.md` 新段：`## <日期> 当日清单（<主题>）`，含三块：执行工作清单（改了哪些文件、为什么）、验证结果（实测数据，不写"应该没问题"）、经验与后续（踩坑 + 遗留）。
- **1.2** 结论先行：每段第一行给一句话结论，再展开证据。
- **1.3** append-only：只追加，不改写、不删除历史段。修正旧结论时在新段说明，或对结构化条目用 `retracted` 字段留档（见 §5.14）。
- **1.4** 没写 HANDOFF 段的工作视为未交付。
- **1.5** 并行协作提交边界：
  - `HANDOFF.md` 只允许单独成 `docs:` 提交，禁止与代码混提；
  - 自己的主题提交不得夹带他人未提交段落/文件；工作区含他人未提交内容时，本段只追加、不提交，并在段末注明。
- **1.6** 体积治理：`HANDOFF` 超过可读阈值时，将整段历史**移动**（不是删除）到 `HANDOFF-archive-YYYYMM.md`，append-only 语义在归档内延续；移动动作本身在 HANDOFF 记一行。
- **1.7** HANDOFF 里的一切计数、哈希、时间窗必须实测后写入（见 §5.8 分母纪律）；"总数减已知部分"推出来的数禁止入档。

## 2. 项目铁律（客户约束与写盘纪律）

### 2.1 写盘、备份与原子性

- 补丁默认只走 `render_item` 重渲染；**永不重解 PDF**（重解 = 覆盖人工校对成果）。
- 例外通道（唯一合法重解/整文档写回路径）：隔离 staging 目录 + 双开关（CLI `--do-write --i-understand` 或 API `confirm=true`）+ 备份不覆盖 + 源/备份/写后三哈希留档 + 单独授权 + HANDOFF 登记。缺任何一项视为违规写盘。
- 备份后缀单一事实源（门禁脚本判"备份缺失"必须按"建立条件"判，不得一刀切）：

| 工具 | 备份形态 | 建立条件 |
| --- | --- | --- |
| `table_audit --write` | `{文件名}.pre_audit`（即 `X.json.pre_audit`） | 首次写盘必建；已存在不覆盖 |
| `postprocess_qwen --write` | `{stem}.pre_pp.json` | 仅当实际改动（`merged_rows>0`） |
| `qc_diff` 回滚 | `{sn}.json.pre_revert` | 每次回滚 |
| `i18n_restore` / `v4_writeback` | 具名批次目录（如 `parsed_backup_batch1/`） | 写前；目录已有同名 = 该件 FAIL |

- 一切文件写盘走原子写：同目录 `tmp` + `fsync` + `os.replace()`；终态只有"旧内容"或"新内容"。
- QC 台账（`qc_run` / `qc_finding` / `qc_audit_log` 及一切 append-only 表）代码路径只 `INSERT`，禁 `UPDATE` / `DELETE`；dry-run 空转不许伪造通过（`parsed==0` 保护）。
- QC 时间戳一律 `db.qc_now()`；`db.now()` 的 ISO `+08:00` 后缀会让 `julianday()` 算错 8 小时。

### 2.2 人工专属红线（机器不得越界）

- 以下动作**只能人工**执行，机器只产出草稿/就绪/歧义/冲突草稿：`identity=verified`、字段 `verified`、Gold `freeze`、冲突裁决（`use_pdf` / `keep_gold`）、`release_status=approved`、P0 阻断解除、74 功能表签核（owner ≠ reviewer；agent 代理签核仅限该表版本、必须 `--delegation` 留授权说明、且先跑 `validate` + `verify-evidence` 零错误）。
- 机器可写形态仅限：`draft` / `ready` / `ambiguous` / `conflict_draft` / `not_checked` / `unresolved` / `not_applicable`。

### 2.3 整文档写回顶层键守卫

- 任何整文档写回（重解析、合并、回填、翻译注入）：顶层键集合**只增不减**；旧文档存在的关键契约键（含 `multi_language`）缺失 = 整件回滚 + 退出码非 0 + 明细记丢失键名。
- 批处理翻译/重跑必须使用独立 `--state-file`；复用生产 checkpoint 会把已-done 件静默跳过（235 件丢多语言事故的同类陷阱）。

## 3. 提交规则

- **3.1** 白名单逐项 `git add`；禁 `git add -A` / `git add .`。
- **3.2** 永不入库：调试脚本（`_*.py`、`data/_*.py`）、运行日志、数据库与快照、打包产物、运行时数据（`data/parsed/`、`data/txt/`、`data/qc/`…）、`qc/pdfs/`、`deploy/*.sql`（可由 `translate_i18n.py export` 重生）——由 `.gitignore` 管，status 里看到也不加。
- **3.3** 例外入库（如用户明确要求将某运行时目录入库）必须在 HANDOFF 登记并使原句作废。
- **3.4** commit message 语义化（`feat:` / `fix:` / `docs:` / `chore:`），一次提交一个主题。
- **3.5** 服务器无 Codeup 凭证：增量 `git bundle`（用 ref 名，`<sha>..<sha>` 会报 empty bundle）+ `fetch` + `merge --ff-only`；凭证不落服务器命令行/配置。

## 4. 环境与运维纪律

### 4.1 本机 Windows + PowerShell

- 无 `&&`，用 `;`；无 `head`，用 `Select-Object -First N`。
- `python -c "..."` 内嵌引号/正则必被吃：复杂脚本写临时 `.py` 执行，跑完删除。
- `subprocess` 包 stdout 必须幂等（`_qc_utf8` 标记）且带 `line_buffering=True`：重复包装会被 GC 连底关闭共享 buffer；无 `line_buffering` 会让重定向日志全程 0 字节、看似卡死。
- Celery/Redis 不可用时走进程内 inline 降级，不是故障。

### 4.2 服务器容器

- `docker compose` 必须带 `-f deploy/docker-compose.yml`（根目录无 compose 文件）。
- `up -d --build` ≠ 镜像真换：验镜像内容用 `docker run --rm <img> sed -n '<行>' /app/<file>`；必要时 `--no-cache` 探针镜像。
- 服务器手工 `scp` 覆盖受版本控制文件会挡 `--ff-only`：先 `git checkout --` 再合并。
- 容器内跑脚本：`docker exec -w /app -e PYTHONPATH=/app`；宿主机 python3 无第三方依赖。
- **本机（服务器 `dsh` 账号）跑全量测试的唯一通道**：
  `sudo -n /usr/local/bin/icpdf-pytest "$DSH_SUPERAGENT_DIR"`
  只跑单文件加路径参数，如 `sudo -n /usr/local/bin/icpdf-pytest "$DSH_SUPERAGENT_DIR" tests/test_x.py -q`。
  这条命令已在 sudoers 里放行；**直接调 `docker` 会 `permission denied`**（dsh 不在 docker 组，这是刻意的最小授权）。
  它固定用 `icpdf/test:latest` 镜像、只读挂载 `data/parsed|pdfs|alts`，并以 worktree 属主 uid 运行 —— 生成文件不会变成 root。
- PowerShell → SSH → `docker exec python -c` 三层引号必坏：改 base64 传脚本或 `grep` / `ls` 验证。
- `curl /api/health` 返回"未登录"≠ 服务死；存活看 `docker compose ps`。
- Celery 优雅停：`app.control.broadcast('shutdown')`；禁 `taskkill /F`（消息 30 分钟不可见）。
- 迁移顺序：先 `data/*.sqlite3` + 非 PDF 产物 → 起 server 见数据 → 再传 `data/pdfs` → 最后 `requeue_all.py` + 起 worker；提前起 worker 会白下载。
- 跨机路径一律经 `resolve_artifact()`（反斜杠归一 + 目录+文件名回退）；DB 里的 Windows 绝对路径不得直接 `Path().exists()` 判死。
- 部署前备份：`workbench-pre-<sha>-<date>.sqlite3`；stash 具名（`pre-deploy-*`）；不盲目 `stash pop`。
- 跨机迁移用流式 `tar | ssh tar -x`；禁 `tar -a -f x.zip`（Windows bsdtar 会写残缺中央目录）。

### 4.3 hang / 假死判定顺序

终端"执行中"不是卡死证据。按序交叉验证：exit code → 产物文件 mtime → 日志末端 → CPU 是否增长；确认真 stall 后才允许切换本地确定性脚本兜底。日志 0 字节先查 `line_buffering`，不是先杀进程。

## 5. QC 判据纪律

- **5.1** 计数口径：判断错误只数我们自己下错的判断（当前账：7 次 = 取证不足 ×6 + 违反 append-only ×1）；代码缺陷登记 `CONFLICTS` 的 `DEFECT` 类，不计入。新错误追加，不改写旧账。
- **5.2** 根因规律：六次取证不足里五次是同一动作——用间接证据（页数范围/来源层级/另一侧 docstring/数值是否整齐）代替直接证据（代码/PDF 原文）。结论"看着像对的"的时候，恰恰是最该去取原始证据的时候。
- **5.3** 判据取证源必须是**模型实际看到的输入**（`select_pages()` 选出的上下文），不是原始文件全文；两者不一致时判据会"惩罚诚实、奖励幻觉"。
- **5.4** 判据产出必须带原因码；每次跑留存档（`data/qc/gates/…`），是改判据后唯一可回溯的事实源。
- **5.5** 改完判据必须人工核对一遍报警清单再进下一轮。
- **5.6** 验证选页结果用输出里的 `--- Page N ---` 标记精确解析；禁"页内片段指纹"反查。
- **5.7** 检测器优先可测量特征（unit + 数值），不用关键词（`enable` / `select` / `output` / `support` 在参数名与 Features 里都高频，无极性可分）。
- **5.8** 分母必须实测：凡"总数减已知部分"得来的数，单独实测后才可写文档/下结论。
- **5.9** 验证脚本逐列/逐字段成员判定；禁"多列值拼成一串查连续子串"（`['IOVDD','','1.8','','5.5','']` 必然查不到 → 正确写盘被标错）。
- **5.10** 判据/裁决改动必须附原文片段供人工复核，不能只给布尔结论。
- **5.11** 库内两套 review 引擎，加规则前先确认接哪条线：

| 引擎 | 产出字段 | 命名 | 谁在用 |
| --- | --- | --- | --- |
| `app/services/review.py::_rule_checks` | `kind` | 小写 snake_case | 自动修复闭环（`review_item` → `fix_dispatch`） |
| `qc/auto_qc.py` r1–r4 | `code` | 大写 | 批量 QC / `qc_regression` |

  `fix_dispatch` 只认 `kind`：加在 `auto_qc` 的规则对自动修复闭环无效；新缺陷要自动修复必须 `_rule_checks` 加规则 + `ACTION_TEMPLATES` / `_KIND_CATEGORY` 加映射，两处缺一不可。映射表 worker 名拼错只静默退化成人工 → 用不变量单测兜住。

- **5.12** 证据状态四分类（不可混用）：

| 状态 | 含义 | 处理 |
| --- | --- | --- |
| `EVIDENCE_INCOMPLETE` | 证据不足以支持完整可靠结论 | 保留原始证据，转人工/定向补证 |
| `PDF_UNLOCATABLE` | 当前 PDF 文本提取找不到证据 | 查术语/版面/OCR/文档身份；不得写成"该 PDF 没有此信息" |
| `PAGE_NOT_SELECTED` | 证据页未进模型上下文 | 评估选页/定向补页 |
| `SELECTED_NOT_EXTRACTED` | 页已选中但未形成字段 | 查提示词/表格解析/字段映射 |

  纪律：前两者与后两者修复手段完全不同，禁混；"旧 JSON 有、新 JSON 没有"不足以单独证明退化（先核旧值在 PDF 有无可靠原文、来源页是否被选中）。

- **5.13** 选页预算纪律：固定预算下任何"某类页优先"都是零和再分配；改善判据是"关键数值 + 适用条件 + 参数单位"同时入上下文的比例，不是选中电气页数；配对率比覆盖率重要（错误条件下的参数比漏参数更危险）；T3（>100 页）长文档走分段重解或诚实标 `EVIDENCE_INCOMPLETE`，调优先级救不回。
- **5.14** finding kind 单一事实源：
  - 注册表 `qc/finding_kinds.py` 是唯一事实源。具体计数以注册表与 `LOWER_BOUNDS` 为准，本文与 HANDOFF 不复述数字（V1 的 21/29/17/28 写法作废——计数必腐烂）。
  - 新增 kind/code 先补注册表再写引擎；AST 扫描断言必须先断言"扫到的非空集"（`assert actual`），否则空集 ⊆ 任何集合 = 假绿；`LOWER_BOUNDS` 防缩水。
  - `ACTION_TEMPLATES` 键 ⊆ review ∪ table_audit ∪ LLM（不是 ⊆ `REVIEW_KINDS`；若干键只由 LLM 产出）。
  - 动态产出点（`%` 拼接 code、LLM 直通）登记进 patterns 并写明原因。
  - `CONFLICTS`：已确认分歧只登记、不改行为（改判据需单独授权）；错误判断不删除，用 `retracted: {claim, why_wrong, root_cause, retracted_at}` 留档；改写 `detail` / `impact` 时旧判断必须搬进 `retracted`；`test_retracted_judgments_preserved` 守历史不被静默删除。
  - 命名统一 ≠ 判据统一：判据一致性靠"同一输入双跑比对"测试。
  - 模块 import 零 stdout（server 进程安全），已固化测试。

- **5.15** 事实验收只有**一个**状态推导机（V6 起）：`qc/fact_acceptance.py::_derive()`。
  - 证据等级是**严格单调阶梯**，从高到低：`verified_row`(5) / `verified_paragraph`(4) /
    `verified_value`(4) / `verified`(4) / `value_on_label_page`(3) / `value_in_pdf`(2) /
    `partial`(1) / `unchecked`(0) / `not_found`(-1)。**不许在分支里就地拼结论** ——
    加一级就改阶梯，不改 if。
  - 字段按结论**白名单**发放（`_EMIT_RULES`）：`row_sha256` 只许出现在 `verified_row`、
    `paragraph_sha256` 只许出现在 `verified_paragraph`、`bbox` 只许出现在坐标级结论。
  - 两条不变式由 `_check_consistency()` 逐行核，违反让程序返回 3：
    **`row_sha256` 非空 ⟺ `verified_row`**；**`bbox` 非空 ⟺ 坐标级结论**。
    看到「有哈希却不是行级」或「有坐标却是弱结论」，那是缺陷，不是风格。
  - 页面 `†` **只认 `facts_verdicts.json`**，不许读 JSON 自己的 `verification.status`；
    键是 `label ␟ 条件`（AC 表同一 parameter 有 10 条，只按 label 打会把一条弱证据
    扩散成十次），前缀回退取**最弱**那条。
  - 判据严不等于判据对：`VA19` 这类 MIN/TYP/MAX 三列行，JSON 摘成 `min to max` 后
    与重放行**永不**数值全等（重放行多印 typ 与脚注标号）→ 用**子集判据** + 剥脚注，
    否则「三列行」会被结构性地全部误判为「只到同页」。V5 就是这么错的。

## 6. 测试纪律

- **6.1** 新增/修改任何代码后跑全量测试。判定标准是**相对基线无新增失败**；既有失败必须点名归因（他人未提交线 / 缺失产物 / 已登记缺陷），不得以"要求零失败"阻塞他人主题，也不得对新增失败视而不见。
- **6.2** 打补丁一律 pytest `monkeypatch`；禁直接赋值（永久改模块属性，同批测试拿假实现，单文件跑看不出来）。
- **6.3** 造测试数据必须复现生产形态（页眉、关键词、内容结构）；简化骨架通过的测试是假绿。
- **6.4** 解释器不写死绝对路径：本地 = 装有 pymupdf/pandas/numpy/pytest 的解释器；服务器 = `docker run --rm -v … pytest` 或容器内 exec。
  **在 DSH 执行器里（`dsh` 账号）一律用 §4.2 的 `icpdf-pytest` 通道**，不要自己拼 `docker run`；
  该通道已挂好真实 `data/parsed|pdfs|alts`，裸跑 `pytest tests/`（不带挂载）会因仓库内 PDF 为空产生一批假红叉。
- **6.5** 红先原则：新门禁/新判据必须先在已知坏输入（历史错值、脏输入、负例）上红过，修复后转绿才可信任；从未红过的绿不作验收证据。关键断言做变异测试（把期望改成 `BOGUS` 必须失败）。
- **6.6** 夹具与灰度样本是两批件时，必须在结论里写明交集/覆盖关系；夹具跑绿 ≠ 被改件被测到。
- **6.7 基线对比必须在「有 data/ 的同一棵树」里做**。`git worktree add` 出来的基线目录没有 `data/parsed|pdfs|alts`，
  依赖真实样本的用例会集体 skip、未跟踪的测试文件根本不存在，跑出来的"失败数"比主树低——拿它当基线会**伪造"新增失败"**
  （实测因此误报 4 条）。正确做法：把主树改动备份到 `/tmp` 并 `sha256sum` 存档 → 主树 `git checkout --` 到基线 commit →
  同机同环境跑同一命令 → `sha256sum -c` 校验后把改动拷回。基线与被测两边**必须同环境、同挂载、同命令**，
  且要报 `collected / passed / failed / skipped` 四个数，不接受"全量通过"这种模糊表述。
- **6.8 `-m "not slow"` 不是验收口径，只是提速手段**。去选集合会藏起真失败的慢用例（实测 `-m "not slow"` 比全量少 1 条真红：
  `test_table_cell_num::test_icc_cell6_spans_min_and_max` 早已打 slow）。收网验收一律以全量结果为准，快集只用于改一行代码后的冒烟。


## 7. 交接对象

`HANDOFF.md`（全部交接历史）；`README.md` / `WORKBENCH.md` / `DEPLOY.md`（运行与部署）；`qc/`（质量审计工具箱，`qc/json/` 夹具基线入库）；`docs/qc/`（判据、修复日志、核验记录）。

## 8. 批量流水线、熔断与模型路由

- **8.1** 核心心法：用高级 Agent 探索并固化脚本；**绝不用高级 Agent 充当批量流水线工人**。确定性脚本是主力，大模型只在边界失效时定向救援。
- **8.2** 漏斗式 cascade：主链路 `qwen-flash` + JSON Schema 强约束（最低 `json_object` + 后校验重试自愈；支持处用 strict json_schema）→ 本地规则层（`table_audit` 补丁 / `postprocess` 合并 / `pin_repair`）→ 仲裁层按需唤醒（JEV / 高级视觉 / 指定页证据）。高价模型全量跑批量 = 禁止。
- **8.3** 模型路由 env：`ICPDF_MODEL_PARSE/REVIEW/REPAIR/ALTERNATIVES/FIX/INTENT/PLANNER`。路由变更必须附离线评测证据（symbol 完整率、拆分率、unresolved 率、`row_missing` 召回传感器、成本与延迟），用环境开关做 A/B 臂（`ICPDF_MATCH_RULE` 等）；manifest 记录开关实际值，不猜未固定值。
- **8.4** JEV/语义裁判硬约束：前置安检——没有任何候选行能 `value_supported` 解释该值时不发请求；后置——被选中的行必须能解释该值，否则当作没选；低置信度一律 abstain。**绝不降级为猜测。**
- **8.5** 熔断：按 §4.3 顺序交叉验证后才切换确定性兜底；定向核验禁"重解整份 PDF"，强制"指定页 + 限时 + 缓存证据"；禁盲目引入重型 OCR 全篇重跑；本地依赖缺失时把验证 bundle 到服务器 Docker 执行。
- **8.6** P0 阻断禁止自动解除；Agent 任务带预算上限（步数/LLM 调用/超时/成本）；工具权限分级（只读/候选写/受限写/追加写）并留审计事件。

## 9. 身份与 scope 契约

- **9.1** 四个独立维度：商品身份（卖的是什么）/ 文档种类（手里这份 PDF 是什么）/ 行级 scope（这一行描述谁）/ 引脚归属。任一维度的确认不自动授予其它维度。
- **9.2** canonical 枚举：`device | board | onboard_device | subcircuit | unresolved`；writer、TXT、symbols、audit、delivery 五端共同消费同一枚举；缺 scope / 非法枚举 / 别名冲突 → fail-closed（进待核或说明页），不回退裸芯片/裸板级表。
- **9.3** `BOARD_CONFIRMED` 只确认商品身份：≠ 当前 PDF 是板卡指南，≠ 表中每行都是整板参数。`document_kind=board_user_guide` 需要独立证据（订购 literal / 标题页 / 章节点名）。
- **9.4** 剥离契约：板卡且无指南佐证 → `electrical` / `features` / `temperature` 迁入 `onboard_device_specs`，主字段空或 `not_specified`。剥离是风险控制，不是真值修复：隔离区同样接受数值审计，搬走的行必须有完整验证链。
- **9.5** 行级归属：全局 scope 不替代逐行裁决——MOSFET/具名器件参数归具名器件；板外形尺寸不进芯片尺寸字段；子电路条件不写成整板统参。
- **9.6** 芯片页反向隔离：EVM/板卡订购行分离进 `related_evaluation_boards`（保留原行供核验）；不得称板卡为"仅封装/包装不同的芯片订购变体"；芯片封装选项不挂到板卡对象上。
- **9.7** BGA 零容忍：`pin_configuration.pin` 禁纯数字；PDF 无 BALL 坐标表 → 清空并标 `unverified_dropped`；`already_ball` 分支仍必须校验集合（缺球/重复/错功能/无来源）；validation 非 pass → symbols 页禁 `PIN1..PINn` 数字兜底、不猜封装几何、不画 PIN1。
- **9.8** 契约回放：`validate_contract()` 会回放已存储 findings；身份/scope 修正后必须先 `refresh_contract_findings()`（归档旧发现再重算），否则过期阻断会复活打穿已重建的事实。
- **9.9** 板卡参数归属用 **`row["attribution"]`**，**不许复用 `row["scope"]`**（2026-11-01 V5）。
  - `scope` 是 §9.2 的契约枚举，`canonical_view()` 拿它决定「这一行留主表还是搬隔离桶」；
    写进词表外的值（如 `board_level`）会被 `normalize_scope()` 归一成 `unresolved`，
    然后整行被搬进 `unresolved_specs` —— **不报错、不告警，表只是空了**。
    1101-V5 真的踩过：`BOOST-DRV8711` 唯一一条真整板参数 `Voltage Range 8.2 to 52 V`
    就这样从页面上消失。
  - `attribution` 的词表是 `board_level | onboard_device | unresolved`，语义是
    「这一行描述整板还是板载器件」，由 `qc/board_scope.py` 判定，与 `scope` 正交。
  - 判据顺序**先板级后器件级**：`Power Input Voltage` 里也有 `voltage`，
    顺序反了会把它判成片内参数。
  - 合同层**只搬** `electrical` / `absolute_max` / `temperature` / `pin_configuration`，
    `ac_performance` / `thermal` / `esd` 不在搬运范围 —— 渲染层必须自己按 `attribution`
    收口，否则板卡页会把芯片的 ESD 能力印成整板能力。
  - 回归测试：`tests/test_board_scope.py`（含「整板行不得被搬出主表」）。

## 10. 渲染与受控话术纪律

- **10.1** view model 单消费点：主表/洞察/FAQ/SEO/package/notice/读屏/多语 override/symbols 全部消费同一份经契约验证的 view model；板卡 + `onboard_device|unresolved` 时任何段落不得消费主 electrical/amax/温区；非空残留计数写入校验与隔离说明；归档不静默删除、不假称已搬移。
- **10.2** 受控话术证据裁决（取代布尔子串命中）：词边界 + 确定性归一（大小写/连字符/Ω/ohm）+ 否定/未装/可选处理；拆 claim 类型（`motor_output` / `led_string` / `signal_connector` / `clock_input` / `clock_source` / `termination`）；scope 裁决：板载芯片参数只产器件级注意事项，不授予板级接口事实；`SMA` ≠ oscillator、`jitter` ≠ onboard oscillator、`50Ω`/termination ≠ 时钟口；无证据 → 省略受控检查点或只给通用建议；无来源的排名/因果断言（"最常见故障""最快损坏方式"）删除。
- **10.3** 单一事实源：渲染与验收 lint import 同一个证据分类函数；词表/归一/优先级/scope 规则只允许一份；检查器复制第二份词表 = 违规。
- **10.4** 渲染禁忌：连字符切断长句（`8.2–52 V`）；相邻卡片标题与描述复读（desc 置空）；sentinel（`not_specified` 等）在 value 与 unit 两侧都要吞（V1 只吞 unit 侧的缺口已修并登记）；半句风险走 `board_fact_plain`；未知封装禁回退 "Evaluation Board" 填芯片封装位；板卡页不承诺 pinout（含读屏摘要）。
- **10.5** i18n 完整性：回退事件登记 `requested_lang/actual_lang/key/reason`；回退计数非 0 ⇒ `i18n_complete` 不得为 true；目标语言缺产物/静态缺键/叙述缺译/未检查分别登记；只交英文必须明写"非英语不在本次范围/未通过"，禁以 `None` 或静默回退冒充 complete。

## 11. 数值审计与写盘纪律

- **11.1** 诊断与写盘分离：诊断用 `to_num`（捞第一个数），写盘用 `cell_num`（整格干净单值）；两者**故意不同**——用 `cell_num` 算诊断会让"格子脏"吞掉该报的 `range_collapse`。blank 格（空串 / `-` / `—` / `N/A`）= "这列没值"，不是脏。
- **11.2** 结构 abstain：`fused_cols`（表头一格多角色）、`cell_spans_columns`（数据格 x 区间跨表头列，记 `SPANS_MULTIPLE_ROLES`）→ 整表/整条不回填；列数对不上时宁可不判不误判。
- **11.3** 唯一性闸门：候选 = 并列最高分行；同一 (表, 行) 被多条认领 → 全部 ambiguous（先到先得 = 隐式优先级）；`row_ambiguous_unresolved` 必须以 `_unresolved` 结尾（否则分流把它算成 patched = 静默通过）。
- **11.4** `locate_row_ignores_qualifier` 是活缺陷（按模式/保护域/条件拆子行的器件稳定取错行）：在"限定词约束 + 一行一匹配 + 选不出报 unresolved"落地并通过 11 件回归前，生产 `write=True` 保持关闭；抽样显示开启即 3~7 成件被写错且"有页码有 MIN 列"极难事后发现。"唯一命中" ≠ "语义正确"。
- **11.5** columns 来源门禁：`columns_raw` 无 `origin` 或 `origin=derived_from_value` 不是 PDF 列证据；未审计规范化只写展示候选；G0 必须查 origin；已有污染列回收再审，不得"字段已有所以跳过"。
- **11.6** `_range_text` 优先级：已审计原列 > range（仅当来源支持、确为 MIN/MAX 且无 TYP）；冲突 → finding + 阻断，不静默选值；零判空用 `is not None`。
- **11.7** `value_raw_original` 幂等：一条只准写一次（`_writable()` + `patch_cols` 兜底）；二次覆盖 = 涂改后悔药。
- **11.8** condition 双写治理：`table_audit` 的 COND 列可覆盖 `fix_elec_row` 写的 condition；覆盖时必须补 `condition_overwritten` finding（记 old/new），不禁止覆盖但必须可追溯。乱码 condition 不覆盖 + `condition_cell_garbled` 留痕。
- **11.9** 写盘灰度：只允许沙箱（`--write --box`，不碰 `data/parsed`、不碰 sqlite）；FACTS 侧车随 `src_json` 一起重定向（worker initializer），防侧漏生产 `data/facts`。
- **11.10** 开启任何写盘前的三件套：限定词修复落地 + 夹具回归不劣化 + 灰度 diff 逐 finding 解释。

## 12. 验收门禁 G0–G3 与打包

### 12.1 门禁统一定义（V1 的"G1 语义一致 / G2 渲染差分"命名作废；渲染差分并入 G3）

| 门禁 | 必须检查 | 不能当作通过条件 |
| --- | --- | --- |
| **G0 反静默/覆盖** | 每条数值条目有 columns（origin 合法）或有 unresolved finding 解释；allowlist 精确；必需物料齐备；来源与输出哈希绑定 | 有 columns 即可、缺件 continue、`None`/unresolved 等于 pass |
| **G1 参数正确** | PDF 原表行/列角色、范围/典型/最大、量纲、参考地、供电公式与条件；球位功能真值 | 字符串改 "to"、球号匹配正则、SVG 存在 |
| **G2 对象一致** | 请求/文档/行/子电路/板载器件/订购对象；writer × TXT × symbols × facts 逐键一致 | `BOARD_CONFIRMED` 即全行 board、靠封装名猜对象 |
| **G3 来源与输出支持** | 每个受控 claim 有正确 scope 证据；overview/表/FAQ/SEO/notice/读屏/语言变体互一致（含渲染 diff 报告证明该删的删、该留的留）；包内逐成员哈希 | HTML 任意位置 SMA 子串即失败、120 字符附近有 onboard 即豁免 |

### 12.2 结果五态

`pass` / `fail` / `unresolved` / `not_checked` / `not_applicable`；未知不得伪装 pass；关键工程值 unresolved/not_checked 必须阻断该工程声明；可发布降级项须人工批准并在清单标明，不称"完整工程验收通过"。

### 12.3 验收管线绑定

`acceptance_rebuild` 必须调用 `table_audit.audit_json`（数值审计绑定）；audit / facts / 渲染同 `run_id`；manifest 记录 `json_to_txt_sha256` / `table_audit_sha256` / `identity_scope_sha256` / `run_id` / 开关实际值。旧 audit 文件单独存在 ≠ 当前产物被审过。

### 12.4 打包纪律

- fresh staging 装配；既有交付目录一经产出即不可变；禁原地"刷新"/覆盖（含 `delivery_bundle` 的 skip-in-place、`acceptance_rebuild --force` 直删 out 目录）；新 run 写新 staging，校验后发布。
- allowlist 精确到请求型号；`--limit N` 不得替代 allowlist；删一件/错用全局旧文件/旧 ZIP 成员与新清单不一致 → 打包失败。
- manifest 逐成员：`relative_path/size/sha256/source_hash/source_scope/verification/zip_member`；最终包哈希单独记录（禁循环哈希）；ZIP 成员正斜杠、无路径穿越、逐成员 CRC 校验完成后才宣布交付。
- **强制纳入 PDF 原件**：每个型号目录下**必须**包含对应原厂 PDF（`<safe_name>.pdf`）。
  `delivery_bundle.py` 装配时校验其存在，缺件直接抛错、不出包；`manifest` 逐成员计入该文件，
  并给出 `pdf_included` / `pdf_sha256_recorded` / `pdf_sha256_packaged` / `pdf_hash_match` 四项。
  **严禁只交付 JSON/HTML 而无 PDF 原件。** 理由是复核方无法独立重算、无法逐行对照，
  只能「相信」发布说明 —— 1101 就是因此被判「不能视为重新核验」。
  三条口径（哈希必须对得上 / 二进制用原始字节哈希 / 版权与不再分发）见 §16.8。
- **自证链强断言（V6 起，硬约束）**：`manifest.json` 里**每一个** `sha256` 与**每一项**
  关键指标，都必须在出包前拿**包内实际文件**重算比对；有一项不符就中断打包并报错，
  不产出「看起来完整」的包。
  - 实现是 `qc/bundle_selfcheck.py`，由 `delivery_bundle.bundle_acceptance()` 在末尾调用。
    **它刻意不复用打包器的哈希函数** —— 共用则函数写错时自检跟着一起错，那不叫校验。
    两边各自维护一份 `ANCHORED_VERDICTS`，`tests/test_bundle_selfcheck.py` 锁死相等。
  - 重算项：成员 `sha256`/`size`（文本 CRLF→LF、PDF/ZIP 原始字节）、
    `i18n_complete`/`i18n_coverage`（**从侧车读，禁用打包器里的旧变量**）、
    `data_anchor`（随包 `facts_audit.csv` 逐行数）、`pdf_sha256_packaged`/`pdf_hash_match`、
    `artifacts`（`present` 计数）、ZIP 内成员哈希与非法路径、报告的 `zip_sha256`/`verified_members`。
  - 复核方可跑同一条命令复现结论：`python qc/bundle_selfcheck.py --out <包根>`。
  - 这条断言必须**在已知坏包上红过**才可信任（V5 包跑它会红：报告写 `not_checked`
    而清单已有实测覆盖率）。从未红过的绿不作验收证据（§6.5）。
- **i18n 口径两个字段，不许合并**：`i18n_coverage` 是**机器实测**
  （多少 key 有译文、多少回退英文，取所有语言里**最低**的）；`i18n_content_review`
  是**人工审校**（译文读得对不对）。V5 把两者塞进同一个 `i18n_validation`，
  于是「覆盖率 1.0」被读成「多语已验收」。覆盖率 1.0 只证明「没有回退到英文」。
- README 禁写"json+html 齐备即可上线"；文件完整只是 G0 的一部分。
- 打包校验通过 ≠ 工程验收通过；`release_status=approved` 人工专属。

- **ZIP 字节数只有一个出口（1102-V2 起）**：任何文档里引用分卷 ZIP 的大小，
  都必须等于**最终落盘文件**的字节数，取值走 `delivery_bundle.final_zip_metrics()`。
  它先断言目录里没有残留 `*.part`（`.part` 阶段的大小不是最终大小），再从同一处
  返回 `(sha256, size)`，`包校验报告.json` 只能引用这两个数。
  - 反面教材：V11 的发布仓库根 README 写 `12,123,616 B`，报告是 `12,124,048`，
    差 432 字节 —— 前者是中间值，后者才是终值。复核方一算就对不上。
  - 文档侧由 `qc/bundle_selfcheck._check_doc_byte_claims()` 拦：凡「提到 ZIP 又给了
    带千分位字节数」的行，必须等于实际大小；**包外文档**（发布仓库根 README）用
    `--extra-doc` 一起过同一条规则 —— 只在包里查等于没查，出错的那份就在包外。
- **隔离行必须在交付说明里有脚注（1102-V2 起）**：某型号存在 `specs.unresolved_*`
  非空容器（当前是 AC 脏行）时，`render_delivery_note()` 必须在实测表**下方**自动
  生成一行「注：`<型号>` 有 N 行 AC 数据（`specs.unresolved_ac_rows`）因列角色未核验
  被物理隔离…」，`_check_delivery_note()` 第 ④ 条按「注：」开头 + 型号 + 容器名 +
  条数逐项核。
  - 理由：隔离是对的，但**上表行数会因此变小**。没有这句话，复核方拿
    `facts_audit` 总行数去减上表，差额会被读成「漏审计」—— 明明做对了却被判错，
    比不做还糟。条数写错（隔离数变了、脚注没跟着改）同样要红。

## 13. 标准单件 SOP（六阶段，上一阶段红 = 禁入下一阶段）

1. **智能抽取**：主模型 + JSON Schema 强约束；非法 JSON 重试/阻断，禁非标格式入下游。
2. **后处理与物理审计**：`postprocess_qwen` 合并（PDF 同一行硬判据 + `SKIP_VALUES_NOT_IN_ROW`）；`split_fused_rows` 默认关、开需沙箱验值；`cell_spans_columns` 跨列拒写；跑 G0 反静默扫描。
3. **语义仲裁（按需）**：`ambiguous_tie` → JEV（前置/后置 `value_supported` 安检）；几何疑难 → 指定页证据或视觉仲裁（双证据一致才写）。
4. **身份隔离**：`identity_scope` / `board_identity` 判定；剥离契约；BGA 清零规则；`refresh_contract_findings()` 归档重算。
5. **SSOT 固化与渲染**：facts 侧车；view model 单消费点；受控话术证据裁决；i18n 回退登记。*注：当前生产渲染仍消费 parsed JSON，为已登记技术债；新增消费者必须接 facts；本条不构成绕过 facts 的理由。*
6. **终极验收**：G0–G3 全绿 + §12 打包规则；验收器红先（坏 fixture 必红）；退出码即门禁（0 全绿 / 1 有红 / 3 无证据）。

## 14. 指定页取证与缓存

- **14.1** 核对一行参数不得扫描整份 PDF：`qc/page_evidence.extract_pages(pdf, pages, timeout_s=8)`；页码由调用方显式给出（1-based）；仅 `status=ok` 缓存可复用；缓存键 = PDF SHA-256 + 页码 + 提取器版本（`pymupdf-words-v1`）；超时/越页/半截结果不是证据。
- **14.2** 列角色用词坐标锚点，不用会融合多行的 `find_tables()`；字符串 `80 to 100` 不能推断 MIN/MAX；相邻行常数不能替换公式；MIN/TYP/MAX 保持角色标签不压成范围。
- **14.3** 球位/封装等结构事实：文字层 + 坐标取证即可，不猜；图形连线与几何未核验就明示未核验。

## 15. QC 核心实体心智模型（名词释义）

在修改或排查 QC 模块时，必须先建立以下概念认知：

- **PDF vs Parsed JSON**：PDF 是唯一物理事实源；`parsed JSON` 是 LLM 的初步口供，**允许包含幻觉和错位**。
- **Facts JSON (SSOT)**：经过审计后的单一事实源。**下游模板渲染只能读它，绝不准读 `parsed JSON`。**
- **Finding (发现项)**：审计引擎产出的原子异常记录（如 `range_collapse`）。任何规则都必须产出 Finding。
- **Unresolved**：机器不敢修、必须交人工的 Finding。**它是反假绿的核心，验收门禁必须拦截任何非白名单的 unresolved。**
- **Fixture (回归夹具)**：防退化锚点（如 `fix11_models.txt`）。改任何底层规则，必须跑通夹具。**夹具断言只写规则期望，不写逐型号补丁。**
- **Gold Set (黄金标准)**：人工基于原厂 PDF 逐字核验的终极真理。机器只能写草稿，不能写 Gold。

> 详细实体流转关系见 `docs/QC_ARCHITECTURE.md`。

## 16. 交付产物发布仓库（GitHub）

- **16.1 目录命名**：交付产物一律 `data/delivery-YYYYMMDD`（当日首版）；
  同一天再次打包按序递增 `data/delivery-YYYYMMDD-V2` / `-V3` …。
  **日期永远是打包当天的实际日期**：同一天迭代只加 `-Vn`，**不许**把日期写成次日
  （1101 当天真的产出过 `delivery-20261102` 与 `delivery-20261102-V2` 两个次日目录，
  与历史 `delivery-20261031-V2…V4` 的口径自相矛盾，已改回 `delivery-20261101-V2/-V3`）。
  该纪律由 `delivery_bundle.check_delivery_name()` 强制：未来日期直接 `ap.error` 退出，
  不给参数就自动取当天第一个空闲目录（`next_delivery_dir()`）。
  历史命名 `delivery-20261030-fixed` / `delivery-20261030-i18n` 属例外，不新增同类后缀名。
- **16.1a 测试包不得占用正式序列（硬性）**：`delivery-YYYYMMDD-VX` 是**对外正式交付序列**，
  只收通过全套自检、可发给复核方的包。抽样测试、灰度验证、内测用的包一律用
  `test-YYYYMMDD-batchXX`（如 `test-20261102-batch20`）或 `staging-<用途>-YYYYMMDD` 前缀。
  **不得**为了省事把测试包排进 `delivery-` 序列。
  理由：`-V2/-V3/-V4` 的含义是「对外的第几版」，测试包一旦插进去，序号追溯就会指错包，
  复核方按 V 号找版本必然踩空。
  - **16.1a-1 `-eval` 例外（2026-11-03 起，硬性）**：**带 `-eval` 后缀的包允许推 GitHub
    发布仓库**，不受本条「测试包不推发布仓库」的限制。
    理由：推发布仓库的目的之一就是**给外部大型模型做盲审**，盲审对象天然是灰度件，
    而不是已签核的正式版；把灰度件挡在门外，等于把盲审通道关掉。
    - 命名形态两种，**必须以 `-eval` 结尾**：
      `delivery-YYYYMMDD-eval`（带日期）或 `delivery-<用途>-eval`
      （如 `delivery-batch20-eval`，批次名代替日期）。
    - 机器判据：`delivery_bundle.is_eval_package(name)`（正则 `_EVAL_DIR_RE`）。
      **`-eval` 是「非正式、可盲审」的唯一机器可判标识**，不要用 README 里的一句话代替。
    - `-eval` 包**仍然不占用 `-Vn` 序列**，也**不得**在包内声明 `release_status` 为
      `approved`；`engineering_validation` 恒为 `not_approved`。
    - 除 `-eval` 外，其余灰度/测试包照旧不推发布仓库（留在本地或服务器比对）。
    - `delivery-<8位日期>-<其它后缀>`（不带 `-eval`）仍一律拒绝，
      `check_delivery_name()` 会给出指向本条的错误文案。
- **16.2 只新增不改写**：沿用 §12.4 —— 既有交付目录一经产出即不可变，新 run 写新目录。
  发布仓库里也是**只追加新目录**，不修改、不删除已推送的任何一版（可回溯是对外交付的底线）。
- **16.3 发布目标**：打包校验通过后，产物必须提交推送到
  `https://github.com/esanwu-bot/IcDeliveryReleases`（与主仓库 Codeup `origin` **分离**的远端，
  本地 remote 名固定为 `github`）。**主仓库永不入库交付产物**（§3.2），两个仓库职责不混。
- **16.4 凭证纪律（硬性）**：token 只存在本机 `.env.local` 的 `GITHUB_RELEASE_TOKEN`
  （该文件已被 `.gitignore` 管住）。**禁止**写进 `AGENT.md` / 任何入库文件 / 命令行回显 / 提交信息。
  推送一律走进程内注入。**git over HTTPS 只认 Basic（token 当密码），
  `AUTHORIZATION: Bearer` 会被判 `invalid credentials`（实测，见 HANDOFF 2026-10-31）**：

  ```bash
  TOKEN=$(python -c "import pathlib;print(next(l.split('=',1)[1].strip() for l in pathlib.Path('.env.local').read_text(encoding='utf-8').splitlines() if l.strip().startswith('GITHUB_RELEASE_TOKEN')))")
  AUTH=$(printf 'esanwu-bot:%s' "$TOKEN" | base64 -w0)
  git -c http.extraheader="AUTHORIZATION: basic $AUTH" push -u github main
  ```

  `Bearer` 只对 REST API（`curl -H "Authorization: Bearer $TOKEN"`）有效，别混用。

- **16.4a 网络推送兜底（硬性，1102 起）**：本地环境（Windows / 代理 / 受限网络）直接
  `git push` 到 GitHub 极易遭遇 **TLS 握手失败或超时**（实测 `schannel: failed to receive
  handshake`、DNS 被劫持到 `198.18.0.0/15` 黑洞段）。
  - **标准动作**：所有发往 GitHub 的交付包，**优先**打成 `git bundle`（或 tar）传送到
    生产服务器（`root@159.89.190.225:/www/wwwroot/icpdfparser`），由海外服务器直接
    推送 GitHub。服务器出站实测可达（`api.github.com` HTTP 200）。
    bundle 走**增量**（`git bundle create x.bundle main --not <远端 main sha>`，用 ref 名，
    `<sha>..<sha>` 会报 empty bundle）；大包上传用 `scp` 时允许后台续传，**必须比对
    两端 md5** 后再执行推送脚本。
  - **判定标准**：本地 `git push` **超过 30 秒无响应**，或报 `schannel handshake` /
    `SSL/TLS connection failed`，**立刻中止**，无缝切到服务器推送通道；
    **绝不反复在本地重试**（重试只会消耗时间并放大「以为推上去了」的错觉）。
  - 凭证：token 由服务器侧从临时文件读取（`chmod 600`，用后 `rm -f`），
    不出现在命令行回显、不写入服务器 git 配置；推送脚本与本机 `.env.local` 分离。
  - 推送后必须做**独立复核**：`git ls-remote` 比对远端 main 与新提交 sha，
    再用 `raw.githubusercontent.com/<sha>/<目录>/manifest.json` 拉一次核对关键字段
    （`anchor_gate` / `zip_sha256`），不以「push 输出没有报错」作为成功证据。

- **16.5 发布仓库内容边界**：只放交付目录（`manifest.*` / `README.md` / `交付说明.md` /
  `修复方案.md` / `包校验报告.json` / `facts_audit.*` / `risk_queue.csv` /
  `回复Reviewer.md` / `part-XXXX-of-YYYY.zip|rar` + 解压目录）。
  不入库源码、数据库、staging 中间产物。
  **PDF 原件（`<型号>/<型号>.pdf`）必须包含在目录内**，用于支撑 Reviewer 与客户的
  独立溯源核验（一份数据配一份源文件），随分卷一起进发布仓库；
  除此之外的 PDF（抓取缓存、未入包的其他手册）仍不入库。口径见 §16.8。
- **16.5a 大体积包不进 Git 仓库（2026-11-04 起，硬性）**：GitHub 单文件硬上限
  **100 MB**。任何单个 `part-*.zip` / 交付压缩包超过 100 MB 时，**禁止**提交进
  `IcDeliveryReleases`（`git push` 会被服务端拒绝，且历史 blob 会永久污染仓库）。
  - 发布仓库只推**台账与说明**：`manifest.csv` / `manifest.json` / `README.md` /
    `facts_audit.*` / `risk_queue.csv` / `包校验报告.json` 等小文件，以及需要随包
    送审的纯代码 ZIP（体积受限、内容稳定）。
  - 大体积物理包**留在服务器文件系统**（生产路径 `/www/wwwroot/icpdfparser/data/<包名>/`），
    或托管到阿里云 OSS / 宝塔静态站点对外提供下载链接。
  - 建 `[CMD]` 工单时，**必须在 Issue 正文写明物理包的绝对路径或外部下载链接**，
    并声明体积与「不随 Git 分发」，否则 DSH 按仓库内容拉包必然扑空。
  - 例外：Git LFS 经明确授权并对复核方说明 `git lfs pull` 后方可启用；未经授权一律
    走本条的「台账入库 + 大包外挂」路径。
- **16.5b 超过 100 MB 按批次拆独立大包（2026-11-04 立规，下版实施）**：
  不再用 `part-XXXX-of-YYYY.zip` 这种分卷命名表达「同一批被切碎的体积」——
  分卷会让人误读成不同交付批次。规模化交付统一按**批次**拆成互不重叠的独立大包：
  `batch<X>-v<N>.zip`（例 `batch100-v1.zip` / `batch100-v2.zip`），每卷是一个
  可独立解压、独立校验、独立送审的完整包，且每卷 < 100 MB 或按上条外挂。
  - 每卷自带 `manifest.csv` / `README.md`，卷与卷之间型号集合不得重叠。
  - 这是 `delivery_bundle.py` 下一版重构的**核心需求**：验收模式
    `bundle_acceptance()` 目前把 shard 写死为 `part-0001-of-0001`（见
    `delivery_bundle.py:1249/1893`），不受 `--per-shard` 控制，91 件 387 MB 源 PDF
    必然压成单个约 380 MB 的 ZIP。改造需同时保留流水线凭证闸门 `PS.require()`。
- **16.8 原厂 PDF 随包（1102 起，硬性）**：
  每个型号目录必须带 `<型号>/<型号>.pdf` 原厂原件，缺件**不出包**（`bundle_acceptance` 直接抛错）。
  理由：1101 及之前包内只有 JSON 与哈希记录，复核方无法独立重算、无法逐行对照，
  只能「相信」发布说明 —— 复审据此判定该包「不能视为重新核验」。

  三条口径：
  1. **哈希必须对得上**。manifest 同时给 `pdf_sha256_recorded`（源 JSON 解析时记录）、
     `pdf_sha256_packaged`（包内实测）、`pdf_hash_match`（两者是否一致）。
     `pdf_hash_match=false` → `gate=BLOCKED`。随包原件与被解析的不是同一份文件时，
     它的存在比不放更误导。
  2. **PDF 用原始字节哈希**（`_sha256_raw`），文本物料仍用 `sha256(CRLF→LF)`。
     二进制里 0x0D 0x0A 是内容的一部分，归一一次哈希就变了。
  3. **版权口径**：随包只为让复核方独立验真，不改变原厂文档的权利归属；
     交付说明须注明「PDF 版权归原厂，仅供本批验收复核使用，不得单独再分发」。
     若某型号的原厂条款不允许再分发，该型号改为**只给哈希 + 官方下载链接**，
     并在 manifest 记 `pdf_included=false` 与原因 —— 不得为了凑齐而绕过。
- **16.9 逐行事实验收表随包**：`facts_audit.csv` / `facts_audit.json` / `risk_queue.csv`
  由 `qc/fact_acceptance.py` 生成，逐行记录「值是否出现在原厂 PDF、在第几页、
  是否与参数名同页」。`facts_verdict` 写进 manifest；
  `release_state` 的 `DATA_VALIDATED` 一级**只认这份表**，没有表就是 `unchecked`，不得当通过。
  - **`facts_verdict=pass` 不等于参数全对**（2026-11-01 V5 起）：`pass` 只表示
    「没有编造的数值」，同页命中（`value_on_label_page`）也算 pass —— 而 180 页的
    手册里「同页」几乎是必然的，证明不了这一行属于哪个表格行、哪一列。
  - **`DATA_VALIDATED` 的判据是 `data_anchor` 分子等于分母**：每一行有数值的工程参数
    都必须达到 `verified_row` / `verified_value` / `verified`（锚到原厂表的具体行，
    带 `bbox` + `row_sha256`，可从 PDF 重放）。达不到就停在 `PACKAGING_PASSED`，
    缺口写进 manifest 的 `data_anchor` 列（`已锚定/总行数`）。
  - 写说明时**不许**把 `verdict=pass` 表述成「已逐行核对」。它没这个意思。
- **16.6 失败必须如实登记**：网络不可达 / 凭证失效 / 仓库不存在时，
  **不得伪造推送成功**，按 §1.7 把实测错误（HTTP 码、exit code、解析到的 IP）写进 HANDOFF，
  并把产物留在本地待推。
- **16.7 README 同步**：每推一版，同步更新发布仓库根 `README.md` 的目录表
  （日期 / 型号数 / 物料齐备度 / `release_status`）。
## 17. 交付包发布与自动质审触发（CI/CD 强制约束）

**背景**：DSH（自动化执行器）通过轮询 GitHub Issue 接收质审任务。为了免去人工手动提单，交付包的发布动作必须与质审触发动作强绑定。

**强制约束**：
1. **触发条件**：当 `delivery_bundle.py` 或任何打包脚本将新的交付包（包含 `manifest.json`）推送到 `https://github.com/esanwu-bot/IcDeliveryReleases` 仓库（且推送成功）后。
2. **必执行动作**：脚本必须立即调用 GitHub REST API（`POST /repos/esanwu-bot/IcDeliveryReleases/issues`），自动创建一个 `[CMD]` 类型的 Issue。
3. **Issue 规范**：
   - 标题：`[CMD] 质审自动化 - <批次/包名>`
   - 标签：`qa-audit`, `auto-trigger`
   - 正文（模板）：
     ```text
     @esanwu-bot 检测到新包发布。
     包名：<包名>
     路径：delivery-<包名>
     请拉取最新代码，执行双 Qwen 质审（dry-run 和 --push）。
     ```
   **为什么 @ 的是 `esanwu-bot` 而不是某个「agent-dsh」**：`esanwu-bot` 是 DSH
   实际登录的 GitHub 账号，DSH 的 GitHub Source 判断「有人在叫我」的判据就是
   正文/评论里出现 `@esanwu-bot`（源码里是 `body.includes('@' + login)`）。
   `agent-dsh` 在 GitHub 上不存在（`GET /users/agent-dsh` → 404），@ 它不会
   产生任何通知，等于没喊人。同理：**自己账号建的 Issue 不会通知自己**，
   所以自动建的 [CMD] 单要真正触发 DSH，光靠建单不够，得让 `@esanwu-bot`
   出现在 DSH 会读的地方（Issue 正文、或在单下追加一条含 `@esanwu-bot` 的评论）。
4. **实现位置**：唯一入口是 `app/integrations/github_issues.py::trigger_auto_qa()`
   （内部转 `app/integrations/release_notify.py::notify`）。别的脚本只 import 它，
   不要各自去拼 Issue —— 建单规范散在多处，改一次漏三处。
5. **建单前必须验明包已推送**：`HEAD == origin/main`、包目录在提交树里、工作区干净。
   三项任一不成立就拒绝建单（`NotifyError`），否则 DSH 会去拉一个还不存在的包。
6. **默认 dry-run**：CLI 不给 `--push` 永远是 dry-run。自动建单会污染仓库。
7. **标签前置条件**：仓库需存在 `qa-audit` 与 `auto-trigger` 两个标签。
   GitHub 对 issue 里写了但**标签不存在**的情况是**静默丢弃**（201 但 labels 为空），
   `create_issue()` 会用 `ensure_labels()` 自动补齐；补齐失败只告警不阻断建单，
   去重由正文 marker + 本地台账保证，不依赖标签。

## 18. 缺陷修复闭环与 GitHub Issue 回复规范（强制约束）

**背景**：DSH 负责发现缺陷并创建 GitHub Issue，本地开发 Agent（如 Trae/Codex）接手修复。为了防止“代码修了但工单没关”造成信息孤岛，必须强制实行“修复-验证-回复”三步闭环。

**强制约束**：
1. **谁修复，谁回复**：任何针对 `[质审/...]` 或 `[BUG]` 标签 Issue 的修复，责任 Agent 必须在代码推送后，主动向原 Issue 追加评论。
2. **Commit Message 联动（自动回复）**：在本地提交修复代码时，Commit Message 的尾部**必须**包含 `fixes #<issue_id>` 或 `closes #<issue_id>`（例如：`fix(qc): 修复多列塌缩 fixes #14`）。推送到 GitHub 后，系统会自动在 Issue #14 下生成代码关联留痕。
3. **验证结果回帖（手动 API 回复）**：若修复涉及本地环境验证（如重跑双 Qwen 质审），责任 Agent 必须在推送成功后，调用工具将验证结果回帖到 Issue 中，并补充详细证据。
4. **统一回复模板**：
   ```text
   ### 修复汇报
   - **修复分支/提交**：`<branch_name>` / `<commit_hash>`
   - **根因分析**：<简述根因>
   - **验证结果**：<附上本地测试报告或截图路径>
   - **结论**：缺陷已修复，等待复测。
   ```
5. **不许口头关闭**：Issue 的关闭以「代码已推送 + 验证结果已回帖」为前提；
   只写「已修复」而不留提交号与证据的回复，视为未修复。

## 19. 开工前置同步规范（Pre-flight Sync Protocol）

**背景**：当前开发环境存在多端并发（本地 Agent 写代码，DSH 服务器端跑测试并追加 `HANDOFF.md`）。若本地 Agent 不先拉取远端最新代码就直接开工，会导致基于旧上下文开发，或在提交时强制覆盖服务器端的最新交接日志，引发灾难性的 Git 冲突。

**强制约束**：
1. **任何实质性开发任务启动前，第一句命令必须是同步**：
   ```bash
   git pull --rebase origin main
   ```
2. **同步一律用 `--rebase`**：默认的 `git pull`（merge）在多端并发下会制造
   无意义的合并提交，还会把别人的提交顺序搅乱。本地有未提交改动时先
   `git stash` 或先建一个 WIP 提交，**不要**带着脏工作区 rebase。
3. **绝不覆盖服务器端追加的 `HANDOFF.md`**：DSH 在服务器上追加交接日志，
   冲突时保留双方内容后手工整合。禁止 `git checkout --theirs`、禁止
   `git push --force`、禁止 `reset --hard` 到同步前的提交。
4. **推送前再同步一次**：`git pull --rebase origin main` → 跑相关测试 →
   `git push origin main`；被远端拒绝就 rebase 后重试，**不许加 `--force`**。
5. **开工先读交接**：先读 `HANDOFF.md` 与 `.workbuddy/memory/<当天>.md`，
   确认有没有别人正在改同一批文件，再动手。多端并发下「不知道对方在改什么」
   是冲突的唯一来源。
## 20. 本地接单（sync + next，两个命令）

**背景**：DSH 在服务器上跑质审、开单；本地 Agent（Trae）跑在 Windows 上，
不能轮询 GitHub。两边靠 `algorithm_lab/` 这个中间目录接力。

**约定**：
1. **`sync`** 把 GitHub 上的 `qa-audit` 单拉成本地 Markdown 镜像：
   `python -m app.integrations.github_issues sync`
2. **`next`** 挑出最新一张 open 的 `severity:P0` 单，生成
   `algorithm_lab/next_task.md`（四段：核心 checklist / 相关证据 / 修复要求）：
   `python -m app.integrations.github_issues next`
3. 把 `next_task.md` 交给本地 Agent 即开工 —— **人工只需这两步**。

**两个必须知道的坑**：
- `sync` 只拉 open 的单，**已关闭单的镜像不会回写**，会一直显示 `OPEN`。
  所以 `next` 默认会打一次 GitHub 复核（`--no-verify` 可关）；镜像状态不可尽信。
- `next_task.md` 首行是 `<!-- next-task: issue=N sha=... -->`。
  **不要手工改这个文件** —— 守护脚本按 `sha` 做幂等，手改会让 sha 对不上，
  导致重复唤醒本地 Agent。要改就改 GitHub 上的 issue，再 `sync` + `next`。

**红线（对本地 Agent）**：只允许提交到 `fix/GH-<N>` 分支并开 PR，
**禁止**直接 `git push origin main`、禁止自行合并。

## 21. 标准化流水线与基建工具（强制优先使用）

**背景**：Batch 100 实战中，隔离台账、哈希计算、坏件剔除都是手写脚本一件件算的，
同一个判据在三处各写一遍，改一处忘两处，于是暴露状态机漏洞与交付口径不一致
（假薄件放行、板卡零电气被当成低规格芯片）。这段能力已固化为 `tools/` 下的标准 CLI。

**铁律**：除调试外，任何人/Agent 严禁手写脚本处理批量清洗、打包与出报告。
必须优先调用下列工具；工具覆盖不到的场景，先补工具，再跑批，不许「先手搓一版顶着」。

### 21.1 安检前置门禁（强制）

解析产出 JSON 后，**禁止直接进入装配流程（`qc/stage_release.py`）**，必须先跑：

```bash
# 1) 先看：谁会被拦、谁是板卡诚实空（默认干跑，只出报告不动文件）
python tools/icpdf_quarantine.py --src <staging_dir>

# 2) 确认后真移：隔离件移出 <staging_dir>，台账写 <out_dir>
python tools/icpdf_quarantine.py --src <staging_dir> --out <out_dir> --apply
```

只有该工具产出的 `allowlist.csv`、`quarantine.csv`、`quarantine_ledger.json`
才能作为准入依据；装配流程只承认 `admission ∈ {normal, allowlist_board}` 的件。

落地要点（按工具实际签名，勿按记忆写）：

- 参数是 `--src` / `--out`，**不是** `--input` / `--output`。
- **默认干跑**：不加 `--apply` 只写台账、不移文件；「干净目录」不是它产出的，
  它是在 `--src` 内把隔离件移走，并把台账写到 `--out`（默认 `<src>/../_quarantine`）。
- `--src` 可以是含 `parsed/` 的装配根，也可以是平铺 JSON 目录。
- 台账跨运行合并；`--force` 会丢弃历史 `runs/items`，非重建台账不要用。
- 退出码：`0` 无件需隔离、`1` 有件被隔离、`2` 输入/环境错误。

绕过此门禁直接装配，视为违规。

### 21.2 合规封存（强制）

打包完成后，必须用一键封存工具解决哈希自指与外部复核问题：

```bash
python tools/icpdf_seal.py --dir <delivery_dir>
```

**当前状态：工具尚未上线**（截至 2026-11-04，仓库内无 `tools/icpdf_seal.py`），
上线后本条即转为强制。上线前的封存一律走 `qc/hash_chain.sh`——它先打印命令
再打印原始输出，数值一次算定，末尾 `tr -d '\r'` 统一行尾。复核记录必须放在
ZIP **之外**：记录一旦进包，写出 ZIP 哈希的瞬间就构成自指。

### 21.3 一键出报告（强制）

严禁手动复制粘贴，也严禁让大模型「凭空生成」清单。清单只能从产物快照读取：

```bash
python tools/icpdf_report.py --manifest <manifest.csv>
```

**当前状态：工具尚未上线**（截至 2026-11-04，仓库内无 `tools/icpdf_report.py`）。
上线前，交付清单只能由 `manifest.csv` / `results_enriched.csv` 逐行生成，
并在报告里写清源 CSV 的路径与 sha256；任何未标注数据源的清单按违规处理。

### 21.4 违规判定

不使用 `tools/icpdf_quarantine.py` 而产生的包，在 Reviewer 审查时出现
「空身份未拦截」或「板卡薄件绕过」，责任 Agent 承担返工重跑的代价。
所有对外交付包，其隔离台账必须由该工具生成并入库。
