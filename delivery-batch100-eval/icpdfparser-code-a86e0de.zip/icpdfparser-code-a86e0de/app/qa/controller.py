"""质审调度器 —— 把三路结论汇成一个可执行的判断，并决定要不要建单。

三路输入，各自量的是不同的东西，**不允许互相顶替**：

| 来源 | 量什么 | 典型盲区 |
|---|---|---|
| Deterministic（`facts_audit.csv` / `table_audit` findings） | 数值能不能在原文重放出来 | 重放得出、但列归属错（0.1 从 KCS 列搬到 DCY 列照样「重放成功」） |
| qwen-long（原文校对） | 这一格的值与列归属对不对 | 只看得到给它的那一行；看不到「整块参数缺失」 |
| qwen-max（逻辑审查） | 表型与结构对不对 | 看不到原文，只能对照机器扫出的参数名清单 |

判决策略（写死，不许调用方放宽）：

* **一票否决 → `reject`**：qwen-long 判 `mismatch` 且 confidence ≥ 0.6，
  或 qwen-max 报出任何 `P0`。任一路说「数据错到会误导选型」就够。
* **严重分歧 → `disputed`**：没有否决票，但确定性审计说「行行重放成功」而
  评委提出了问题。这类最危险 —— 机器全绿、人工一眼能看出错。
* 否则 `accept`（**只表示本轮没查出问题，不是合格证**）。

`accept` / `disputed` / `reject` 是**本轮质审结论**，与交付包的
`release_state`（发布阶梯）不是一个东西，不得互相替代。
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator

from app.integrations import github_issues as GH
from app.reviewers import qwen_reviewer as QR

#: 确定性审计里算「证据不足」的结论。这些行优先送评委 —— 先把最可能错的
#: 挑出来问，而不是按 JSON 顺序从头问起（那样永远问不到热阻表）。
#: `blocked` 是 JSON 汇总口径里的同义状态（不在 CSV 里出现），一并算弱证据。
WEAK_VERDICTS = {"unresolved", "unchecked", "not_found", "model_unverified",
                 "partial", "blocked"}

#: 一票否决的门槛。低于它只记 `disputed`，避免模型一句含糊的 mismatch 就阻断。
VETO_CONFIDENCE = 0.6

#: 确定性审计的 finding kind → 默认严重度。**没列出的一律 P1**：
#: 机器认不出的问题不该被自动升成「会误导选型」，那要靠人判。
#: 进 P0 的只有那些「值本身已经错了/串了」的形态，证据见 qc/table_audit.py 各调用点。
DET_KIND_SEVERITY = {
    "fused_column_blocking": "P0",     # MIN/TYP/MAX 挤在一格，读不出列角色
    "range_collapse": "P0",            # 取值范围塌成一端
    "row_mispair": "P0",               # 行错配：数值挂到了别的参数上
    "option_conflation": "P0",         # 封装/选项混同
    "direction_reversal": "P0",        # 方向反转（MIN/MAX 互换）
    "condition_leak": "P0",            # 条件串行：上一行的 condition 漏到本行
    "qualifier_loss": "P0",            # 限定条件丢失
    "pin_mismatch": "P0",              # 引脚错配
}


def _label_from_path(path: str) -> str:
    """从 `electrical[3].VCMI` 抠出 `VCMI`。

    `table_audit.finding()` 的 path 形如 `{scope}[{i}].{sym or param}`，
    点后面就是参数名 —— 工单里写 `electrical[3].VCMI` 复核方还得自己去 JSON
    里数下标，写 `VCMI` 才能和原文表头对上。
    """
    p = str(path or "")
    return p.rsplit(".", 1)[-1].strip() if p else ""


def _short(v: Any, limit: int = 120) -> str:
    if isinstance(v, (dict, list)):
        try:
            s = json.dumps(v, ensure_ascii=False)
        except (TypeError, ValueError):
            s = str(v)
    else:
        s = str(v if v is not None else "")
    s = " ".join(s.split())
    return s[:limit] + ("…" if len(s) > limit else "")


@dataclass(frozen=True)
class Facts:
    """事实表的**已解析**形态：CSV 逐行、JSON 汇总，两者可以只有一样。

    为什么要这层：`--facts` 传的是 CSV 还是 JSON，取决于出包脚本当时写了哪个。
    让调用方记住「必须传 CSV」是把实现细节漏给使用者，DSH 第一次跑就传错了。
    这里把两种输入收敛成一个对象，读取方只认 `rows` / 两个路径，不再各自解 CSV
    （原来有三处重复解析，改一处忘两处就是分叉）。
    """

    csv_path: Path | None = None
    json_path: Path | None = None
    rows: tuple[dict, ...] = ()
    note: str = ""

    @property
    def found(self) -> bool:
        return bool(self.csv_path or self.json_path or self.rows)


def _rows_from_json(blob: dict) -> list[dict]:
    """JSON 汇总里**唯一**带逐条信息的字段是 `blocked`。

    它是人读字符串（`"Signal-to-noise ratio (SNR) (have=weak, need=paragraph_anchor)"`），
    没有 bbox、没有页码。所以这条路径是**降级**的：能告诉评委「这几条没达标」，
    但工单里指不到原文那一格。有 CSV 时永远优先用 CSV。
    """
    out: list[dict] = []
    for mpn, rec in (blob.get("mpns") or {}).items():
        for s in (rec.get("blocked") or []):
            text = str(s)
            label = re.sub(r"\s*\(have=.*$", "", text).strip() or text
            out.append({"mpn": mpn, "container": "", "label": label, "cond": "",
                        "verdict": "blocked", "page": "", "bbox": "",
                        "kind": "", "note": text})
    return out


def resolve_facts(path: str | Path | None) -> Facts:
    """把 `--facts` 的两种输入收敛成一个 `Facts`。

    * `.csv` → 本体，若同目录有同名 `.json` 一并带上（`verdict` / `anchor_gate` 在
      JSON 里更权威，CSV 只有行级结论）。
    * `.json` → 优先用**同目录同名 CSV** 取逐行证据（这是唯一能给出 bbox 的来源）；
      没有同名 CSV 时，退化为「汇总 + `blocked` 清单」，并在 `note` 里写明缺什么。
    """
    if not path:
        return Facts()
    p = Path(path)
    if p.suffix.lower() == ".json":
        if not p.is_file():
            raise FileNotFoundError(f"--facts 指向的 JSON 不存在：{p}")
        sib = p.with_suffix(".csv")
        if sib.is_file():
            return Facts(csv_path=sib, json_path=p,
                         note=f"传的是 JSON，逐行证据取同目录 {sib.name}")
        blob: dict = {}
        try:
            blob = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise ValueError(f"--facts 的 JSON 无法解析：{p}（{e}）") from e
        rows = _rows_from_json(blob)
        return Facts(json_path=p, rows=tuple(rows),
                     note=("传的是 JSON 且同目录没有同名 CSV：只有汇总与 blocked 清单"
                           f"（全表 {len(rows)} 条），缺 bbox/页码"))
    if not p.is_file():
        raise FileNotFoundError(f"--facts 指向的 CSV 不存在：{p}")
    js = p.with_suffix(".json")
    return Facts(csv_path=p, json_path=js if js.is_file() else None)


def _iter_rows(facts: Facts, mpn: str) -> Iterator[dict]:
    """按 mpn 过滤出逐行证据：有 `rows` 用 `rows`，否则读 CSV。"""
    if facts.rows:
        for r in facts.rows:
            if str(r.get("mpn") or "") == mpn:
                yield r
        return
    if facts.csv_path and facts.csv_path.is_file():
        with open(facts.csv_path, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                if str(r.get("mpn") or "") == mpn:
                    yield r


def _as_facts(facts: Facts | str | Path | None) -> Facts:
    return facts if isinstance(facts, Facts) else resolve_facts(facts)


@dataclass
class QAReport:
    mpn: str
    pdf_sha256: str
    decision: str
    severity: str
    reasons: list[str] = field(default_factory=list)
    deterministic: dict = field(default_factory=dict)
    qwen_long: list[dict] = field(default_factory=list)
    qwen_max: dict = field(default_factory=dict)
    issue: dict | None = None

    def as_dict(self) -> dict:
        return {
            "mpn": self.mpn, "pdf_sha256": self.pdf_sha256,
            "decision": self.decision, "severity": self.severity,
            "reasons": self.reasons, "deterministic": self.deterministic,
            "qwen_long": self.qwen_long, "qwen_max": self.qwen_max,
            "issue": self.issue,
        }


# ---------------------------------------------------------------- 确定性侧
def load_deterministic(mpn: str, facts: Facts | str | Path | None,
                       doc: dict | None = None) -> dict:
    """读确定性审计：事实表逐行结论 + JSON 里 `metadata.audit` 的 findings。

    `facts` 可以是 CSV 路径、JSON 路径或已解析的 `Facts` —— 两种格式都由
    `resolve_facts()` 收敛，这里不区分调用方传了哪种。
    `facts_audit.json` 的 `verdict` / `anchor_gate` 优先于 CSV 统计：
    它由 `qc/fact_acceptance.py` 推导，CSV 只用来数分布与挑弱行。
    """
    f = _as_facts(facts)
    out: dict[str, Any] = {"n_rows": 0, "counts": {}, "weak_rows": [],
                           "anchor_gate": "", "verdict": "unchecked",
                           "findings": [], "finding_kinds": {},
                           "source": f.note}
    counts: dict[str, int] = {}
    weak: list[dict] = []
    for r in _iter_rows(f, mpn):
        v = str(r.get("verdict") or "unchecked")
        counts[v] = counts.get(v, 0) + 1
        if v in WEAK_VERDICTS:
            weak.append({"label": r.get("label"), "cond": r.get("cond"),
                         "verdict": v, "page": r.get("page"),
                         "bbox": r.get("bbox"),
                         # 容器/kind 用来把「弱证据」写成人话：
                         # 「thermal 有 5 行只做了行锚定」比「5 行证据不足」有用
                         "container": r.get("container"),
                         "kind": r.get("kind"),
                         "note": r.get("note") or ""})
    out["n_rows"] = sum(counts.values())
    out["counts"] = counts
    out["weak_rows"] = weak

    if f.json_path and f.json_path.is_file():
        try:
            blob = json.loads(f.json_path.read_text(encoding="utf-8"))
            rec = (blob.get("mpns") or {}).get(mpn) or {}
            out["verdict"] = str(rec.get("verdict") or out["verdict"])
            out["anchor_gate"] = str(rec.get("anchor_gate") or "")
            # JSON 是汇总口径的权威来源。**只在没有逐行 CSV 时**用它覆盖行数：
            # 有 CSV 时行数以实际读到的为准（那是工单里逐条引用的东西）。
            if not f.csv_path and rec:
                out["n_rows"] = int(rec.get("n_rows") or out["n_rows"])
                if isinstance(rec.get("counts"), dict) and rec["counts"]:
                    out["counts"] = {str(k): int(v) for k, v in rec["counts"].items()}
        except (OSError, ValueError):
            pass
    # JSON 自带的结构审计（table_audit 写回的 findings）也要汇总：
    # 它是「机器已经发现的问题」，评委没提不代表不存在。
    if isinstance(doc, dict):
        findings = ((doc.get("metadata") or {}).get("audit") or {}).get("findings") or []
        kinds: dict[str, int] = {}
        for f in findings:
            k = str((f or {}).get("kind") or "")
            if k:
                kinds[k] = kinds.get(k, 0) + 1
        out["findings"] = findings
        out["finding_kinds"] = kinds
    return out


# ---------------------------------------------------------------- 送审行
def _fact_coords(mpn: str, facts: Facts | str | Path | None) -> dict[tuple[str, str], dict]:
    """从事实表建 `(label, cond) → {page, bbox, verdict, container}` 索引。

    bbox 的唯一来源。没有它，评委只能判 `unsure(skipped)`，工单也写不出页码。
    JSON-only 输入没有 bbox，这里返回空索引 —— 调用方据此走「定位失败」分支，
    而不是拿到一个假的 bbox。
    """
    coords: dict[tuple[str, str], dict] = {}
    for r in _iter_rows(_as_facts(facts), mpn):
        raw = str(r.get("bbox") or "").strip()
        bbox: list[float] = []
        if raw:
            try:
                bbox = [float(x) for x in json.loads(raw)] if raw.startswith("[") \
                    else [float(x) for x in raw.replace(",", " ").split()]
            except (ValueError, TypeError):
                bbox = []
        pg = str(r.get("page") or "")
        coords[(str(r.get("label") or ""), str(r.get("cond") or ""))] = {
            "bbox": bbox if len(bbox) == 4 else [],
            "page": int(pg) if pg.isdigit() else None,
            "verdict": str(r.get("verdict") or ""),
            "container": str(r.get("container") or ""),
        }
    return coords


def pick_items(doc: dict, mpn: str, facts: Facts | str | Path | None,
               focus: str = "thermal,electrical", limit: int = 8) -> list[dict]:
    """挑要送 qwen-long 的行：**弱证据优先**，其次按容器顺序。

    bbox 从事实表按 `(label, cond)` 取 —— 没有 bbox 的行会被评委直接判
    `unsure(skipped)`，所以这里先排序，把能取证的行排前面。
    """
    coords = _fact_coords(mpn, facts)

    items: list[dict] = []
    for container in [c.strip() for c in focus.split(",") if c.strip()]:
        for row in ((doc.get("specs") or {}).get(container) or []):
            if not isinstance(row, dict):
                continue
            cond = str(row.get("condition") or "")
            c = coords.get((str(row.get("name") or ""), cond)) or {}
            items.append({
                "mpn": mpn, "container": container,
                "label": row.get("name"), "value": row.get("value"),
                "unit": row.get("unit"), "condition": cond,
                "column_role": row.get("column_role") or "",
                "page": c.get("page"), "bbox": c.get("bbox") or [],
                "fact_verdict": c.get("verdict") or "",
            })
    # 稳定排序：弱证据在前，其余保持原序（不按字母排 —— 表内顺序本身是证据）。
    items.sort(key=lambda it: 0 if it["fact_verdict"] in WEAK_VERDICTS else 1)
    return items[:limit] if limit else items


# ---------------------------------------------------------------- 判断
def _vetoes(long_rows: list[dict], max_res: dict) -> list[str]:
    out: list[str] = []
    for r in long_rows:
        if r.get("verdict") == "mismatch" and float(r.get("confidence") or 0) >= VETO_CONFIDENCE:
            out.append(f"qwen-long 判 mismatch（{r.get('label')}，"
                       f"confidence={r.get('confidence')}）："
                       f"{str(r.get('reason') or '')[:120]}")
    for it in (max_res.get("issues") or []):
        if str(it.get("severity")).upper() == "P0":
            out.append(f"qwen-max 报 P0（{it.get('kind')}）："
                       f"{str(it.get('detail') or '')[:120]}")
    return out


def decide(long_rows: list[dict], max_res: dict, det: dict) -> tuple[str, str, list[str]]:
    """返回 `(decision, severity, reasons)`。"""
    reasons: list[str] = []
    veto = _vetoes(long_rows, max_res)
    if veto:
        return "reject", "P0", veto

    soft: list[str] = []
    for r in long_rows:
        if r.get("verdict") == "mismatch":
            soft.append(f"qwen-long 判 mismatch 但置信度不足"
                        f"（{r.get('label')}，confidence={r.get('confidence')}）")
    for it in (max_res.get("issues") or []):
        soft.append(f"qwen-max 报 {it.get('severity')}（{it.get('kind')}）："
                    f"{str(it.get('detail'))[:100]}")
    if soft:
        if str(det.get("verdict") or "") in ("pass", "verified"):
            reasons.append("确定性审计全绿而评委提出问题 —— 严重分歧")
        reasons += soft
        return "disputed", "P1", reasons

    if det.get("weak_rows"):
        reasons.append(f"确定性审计有 {len(det['weak_rows'])} 行证据不足，"
                       f"但评委未发现问题（不等于无问题）")
    reasons.append("本轮三路均未发现问题（仅代表本轮，不代表放行）")
    return "accept", "P1", reasons


# ---------------------------------------------------------------- 取证（缺失类问题）
def locate_text(pdf_path: str | Path, needle: str) -> dict:
    """在 PDF 里定位一段文本，返回 `{page, bbox}`；找不到返回空。

    用于「参数整块缺失」类工单：JSON 里没有这一行，自然没有 bbox，
    但原文里**有** —— 去原文把那几个字找出来，工单才有页码可指。
    """
    if not needle:
        return {}
    pymupdf, doc = QR._open_pdf(pdf_path)
    try:
        for i in range(doc.page_count):
            hits = doc[i].search_for(needle)
            if hits:
                r = hits[0]
                return {"page": i + 1, "bbox": [round(r.x0, 1), round(r.y0, 1),
                                                round(r.x1, 1), round(r.y1, 1)]}
    finally:
        doc.close()
    return {}


def _sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _sibling_rows(doc: dict, item: dict, coords: dict | None = None) -> list[dict]:
    """同一参数、**同一原文行**的全部 JSON 行（含本条）。

    多封装表的一行在原文里本来就是 N 个数（`DCY | KCS | KCT | KTT`），
    按封装展开后 JSON 有 N 条。只把其中一条交给 qwen-long，它看到原文行有
    N 个数、JSON 只有 1 个，必然判「只抽了第一列」—— 2026-11-03 实测
    LM317/NE555 修复后仍被这么判，根因是**评审上下文缺了一块**，不是抽错。

    「同一原文行」按 `(page, bbox)` 判，**不能只按参数名**：LM317 的 Legacy 与
    New 两张表在**同一页**，参数名相同，按名字全取会把 New Chip 的 39.3 塞进
    Legacy 那条的评审里，评委因此误判「抽取器把两种芯片混进同一原文行」
    （实测 qwen-long 就是这么判 mismatch 的）。
    参数名归一与 `table_audit._thermal_like_key` 同口径（`Rθ(JA)` == `RθJA`）。
    """
    specs = doc.get("specs") or {}
    key = re.sub(r"[\s()]", "", str(item.get("label") or "")).upper()
    rows: list[dict] = []
    if not key:
        return rows
    for container in ("thermal", "electrical", "absolute_max"):
        for r in specs.get(container) or []:
            if not isinstance(r, dict):
                continue
            if re.sub(r"[\s()]", "", str(r.get("name") or "")).upper() != key:
                continue
            rows.append({"value": r.get("value"), "unit": r.get("unit") or "",
                         "condition": r.get("condition") or "",
                         "name": r.get("name")})

    def _coord(row: dict) -> dict:
        if not coords:
            return {}
        return (coords.get((str(row.get("name") or ""),
                            str(row.get("condition") or ""))) or {})

    if coords and item.get("bbox") and item.get("page"):
        same = [r for r in rows
                if _coord(r).get("bbox") == item["bbox"]
                and _coord(r).get("page") == item.get("page")]
        if len(same) >= 2:
            return [{k: v for k, v in r.items() if k != "name"} for r in same]
    return [{k: v for k, v in r.items() if k != "name"} for r in rows]


def _label_rows(doc: dict, label: str) -> list[dict]:
    """JSON 里与 `label` 同名的行（参数名按 `Rθ(JA)` == `RθJA` 归一）。"""
    key = re.sub(r"[\s()]", "", str(label or "")).upper()
    out: list[dict] = []
    if not key:
        return out
    for v in (doc.get("specs") or {}).values():
        if not isinstance(v, list):
            continue
        for row in v:
            if isinstance(row, dict) and \
                    re.sub(r"[\s()]", "", str(row.get("name") or "")).upper() == key:
                out.append(row)
    return out


def _container_of(doc: dict, row: dict) -> str:
    for k, v in (doc.get("specs") or {}).items():
        if isinstance(v, list) and any(isinstance(r, dict) and r is row for r in v):
            return k
    return ""


def reconcile_logic_issues(doc: dict, res: dict) -> dict:
    """把 qwen-max 里**被 JSON 事实直接否证**的条目剔出结论，并留痕。

    理由很硬：模型这两条判词都能用一次字典查询证明是假命题 ——
      * `missing_key_param`「参数在 JSON 中缺失」：RθJC(bot) 在 LM317 有 4 条、
        NE555 有 2 条（其余封装原文印 `N/A`，按纪律就该缺）；
      * `condition_missing`「多封装表的行没有写 condition」：它点名的
        THRES/RESET/DISCH 在 JSON 里各只有一条，根本不属于「多封装表的一行」；
      * `column_collapse_suspect`「只有一条且 condition 为空」：LM317 的
        RθJC(bot) 实测 4 条、条件全非空；NE555 点名的是电气单值行，电气表的
        列塌缩由确定性审计（`table_audit.audit_column_collapse`，同一份判据）负责。
    这不是放宽判据：**判据本身（整块缺失 / 多封装表 / 只抽第一列）不变**，
    只是执行前先用事实核对一遍。被剔的条目原样写进 `filtered_issues`，工单/报告里看得见。
    """
    kept: list[dict] = []
    dropped: list[dict] = []
    for it in (res.get("issues") or []):
        kind = str(it.get("kind") or "")
        label = str(it.get("label") or "")
        parts = [p.strip() for p in re.split(r"[,，、;；]", label) if p.strip()]
        rows = _label_rows(doc, label)
        counts = [len(_label_rows(doc, p)) for p in parts]
        why = ""
        if kind == "missing_key_param" and rows:
            why = f"该参数在 JSON 里有 {len(rows)} 条，不是整块缺失"
        elif (kind == "condition_missing" and counts and any(counts)
              and all(c <= 1 for c in counts)):
            why = "点名的参数在 JSON 里各自只有一条，不属于「多封装表的行」"
        elif kind == "column_collapse_suspect" and rows:
            # 判据要求「同一参数只有一条**且 condition 为空**」。JSON 事实是
            # 多条 / 有 condition，前提就不成立（LM317 的 RθJC(bot) 实测 4 条、
            # 条件全非空，模型仍报「只有一条且 condition 为空」）。
            if len(rows) > 1 or any(str(r.get("condition") or "").strip() for r in rows):
                why = (f"该参数在 JSON 里有 {len(rows)} 条、"
                       f"condition {'非空' if rows else '空'}，不符合「只抽第一列」形态")
            elif all(_container_of(doc, r) == "electrical" for r in rows):
                # 电气表的多封装列由确定性审计（find_tables 结构，同一份判据）
                # 负责；电气的单值行本来就不印 condition，不构成塌缩。
                why = "点名的参数都在电气容器，且电气列塌缩由确定性审计判定"
        if why:
            dropped.append({**it, "rejected_by": "json_lookup", "note": why})
        else:
            kept.append(it)
    out = dict(res)
    out["issues"] = kept
    if dropped:
        out["filtered_issues"] = dropped
    if out.get("verdict") != "skipped":
        out["verdict"] = "suspect" if kept else "pass"
    return out


# ---------------------------------------------------------------- 主流程
def run_qa(*, mpn: str, json_path: str | Path, pdf_path: str | Path,
           facts_csv: Facts | str | Path | None = None,
           focus: str = "thermal,electrical",
           limit: int = 8, chat_fn: Callable[..., dict] | None = None,
           env: dict[str, str] | None = None,
           skip_logic: bool = False) -> QAReport:
    """跑一件：确定性 → qwen-long 逐行 → qwen-max 结构 → 判断 → 建单。

    `facts_csv` 取名保留历史签名，但**已接受 JSON**：`.json` / `.csv` 都行，
    由 `resolve_facts()` 收敛（DSH 传 JSON 就是这个原因）。
    """
    doc = json.loads(Path(json_path).read_text(encoding="utf-8"))
    pdf_sha = str((doc.get("metadata") or {}).get("pdf_hash") or "") or _sha256(pdf_path)

    facts = _as_facts(facts_csv)
    coords = _fact_coords(mpn, facts)
    det = load_deterministic(mpn, facts, doc)
    items = pick_items(doc, mpn, facts, focus, limit)
    long_rows = [QR.review_row(it, pdf_path,
                               siblings=_sibling_rows(doc, it, coords),
                               chat_fn=chat_fn, env=env) for it in items]

    if skip_logic:
        max_res = {"reviewer": QR.MODEL_LOGIC, "verdict": "skipped",
                   "reason": "调用方要求跳过逻辑审查", "issues": []}
    else:
        hints = QR.thermal_labels_in_pdf(pdf_path)
        max_res = QR.review_doc(doc, mpn=mpn, pdf_label_hints=hints,
                                chat_fn=chat_fn, env=env)
        max_res = reconcile_logic_issues(doc, max_res)

    decision, severity, reasons = decide(long_rows, max_res, det)
    report = QAReport(mpn=mpn, pdf_sha256=pdf_sha, decision=decision,
                      severity=severity, reasons=reasons,
                      deterministic=det, qwen_long=long_rows, qwen_max=max_res)

    if decision != "accept":
        report.issue = build_issue_from(report, doc=doc, pdf_path=pdf_path,
                                        facts=facts)
    return report


# ---------------------------------------------------------------- 建单（一件一单）
def _locate(pdf_path: str | Path, label: str,
            coords: dict[tuple[str, str], dict]) -> dict:
    """给一个参数名找页码：先查事实表（便宜），再回 PDF 搜（贵但更全）。"""
    key = (label, "")
    c = coords.get(key) or {}
    if c.get("page"):
        return {"page": c["page"], "bbox": c.get("bbox") or []}
    for (lb, _cond), v in coords.items():
        if lb == label and v.get("page"):
            return {"page": v["page"], "bbox": v.get("bbox") or []}
    try:
        return locate_text(pdf_path, label) if label else {}
    except Exception:                                    # noqa: BLE001
        # 定位失败不该让整张单建不出来：页码退回占位并在详情里写明。
        return {}


def collect_defects(report: QAReport, *, doc: dict, pdf_path: str | Path,
                    facts: Facts | str | Path | None = None,
                    facts_csv: Facts | str | Path | None = None) -> list[dict]:
    """把三路结论归一成**同一个缺陷清单**。

    三路各自量的是不同的东西（见模块 docstring），所以这里不合并「结论」，
    只合并「待修条目」：一条 defect = 一个要人去改的具体位置。
    同一位置被两路同时指出时，由 `GH.merge_defects()` 按 `(label, 类别)` 去重。

    `facts` 与 `facts_csv` 是同一个东西的两个名字（旧调用方还在传后者）。
    """
    coords = _fact_coords(report.mpn, facts if facts is not None else facts_csv)
    det = report.deterministic or {}
    out: list[dict] = []

    # ── 一、qwen-long：原文校对。mismatch 才建条目，agree/unsure 不凑数 ──
    for r in report.qwen_long or []:
        if r.get("verdict") != "mismatch":
            continue
        ev = r.get("evidence") or {}
        vals = ev.get("values") or []
        conf = float(r.get("confidence") or 0.0)
        label = str(r.get("label") or "")
        multi = len(vals) > 1
        if multi:
            # 多列塌缩的关键证据是「原文不止一个值」，这是机器计数，不改写模型结论
            cols = "、".join(f"{v.get('text')}@{float(v.get('x') or 0):.0f}" for v in vals)
            detail = (f"只抽一列，原文有 {len(vals)} 列（{cols}）；"
                      f"JSON 写作 {r.get('json_value')} {r.get('json_unit') or ''}".strip())
        else:
            detail = (f"JSON 写作 {r.get('json_value')} {r.get('json_unit') or ''}，"
                      f"原文为 {r.get('expected_value')} {r.get('expected_unit') or ''}"
                      f"（{r.get('expected_column') or '列未知'} 列）")
        out.append({
            "source": "qwen-long",
            "kind": r.get("kind") or "qwen_long_mismatch",
            "category": "多列塌缩" if multi else "",
            # 置信度不足的 mismatch 只算 P1：`decide()` 也只在 ≥0.6 时才一票否决，
            # 两处判据必须是同一个门槛，否则工单级别与决策级别会打架。
            "severity": "P0" if conf >= VETO_CONFIDENCE else "P1",
            "label": label,
            "detail": detail,
            "expected": (f"{r.get('expected_value')} {r.get('expected_unit') or ''}"
                         f"（{r.get('expected_column') or '列未知'}）").strip(),
            "current": (f"{r.get('json_value')} {r.get('json_unit') or ''}"
                        f"（{r.get('json_column') or '未标注列'}）").strip(),
            "page": ev.get("page") or _locate(pdf_path, label, coords).get("page"),
            "bbox": ev.get("bbox") or [],
            "evidence": {"header": ev.get("header"), "row": ev.get("row")},
            "confidence": r.get("confidence"),
            "note": str(r.get("reason") or ""),
        })

    # ── 二、qwen-max：逻辑审查。缺失/重复/塌缩/混入都在 issues 里 ──
    for it in (report.qwen_max.get("issues") or []):
        label = str(it.get("label") or "")
        loc = _locate(pdf_path, label, coords) if label else {}
        page = loc.get("page")
        detail = str(it.get("detail") or "").strip()
        if not page:
            detail = (detail + "（原文定位失败，页码为占位，需人工在原文核对）").strip()
        out.append({
            "source": "qwen-max",
            "kind": it.get("kind") or "logic_unspecified",
            "severity": it.get("severity") or "P1",
            "label": label or (report.mpn if not label else ""),
            "detail": detail or f"结构不符（kind={it.get('kind')}）",
            "expected": str(it.get("expected") or ""),
            "current": str(it.get("current") or ""),
            "page": page or 1,
            "bbox": loc.get("bbox") or [],
        })

    # ── 三、确定性审计：机器已经发现的表结构问题 + 证据闸门 ──
    for f in (det.get("findings") or []):
        kind = str((f or {}).get("kind") or "")
        path = str((f or {}).get("path") or "")
        cat = GH.KIND_LABEL.get(kind) or kind or "结构问题"
        out.append({
            "source": "deterministic",
            "kind": kind or "finding",
            "severity": DET_KIND_SEVERITY.get(kind, "P1"),
            "label": _label_from_path(path) or path or kind,
            "detail": (f"机器审计在 `{path or '?'}` 判 {cat}："
                       f"JSON 为 {_short((f or {}).get('json'))}，"
                       f"原文/表中为 {_short((f or {}).get('table'))}"),
            "page": (f or {}).get("page") or 1,
            "bbox": [],
        })

    weak = det.get("weak_rows") or []
    gate = str(det.get("anchor_gate") or "")
    if weak and (gate == "blocked" or str(det.get("verdict") or "") in ("partial", "fail")):
        by_container: dict[str, int] = {}
        for w in weak:
            by_container[str(w.get("container") or "?")] = \
                by_container.get(str(w.get("container") or "?"), 0) + 1
        spread = "、".join(f"{k} {v}" for k, v in sorted(by_container.items(),
                                                         key=lambda kv: -kv[1]))
        first = next((w for w in weak if w.get("page")), {})
        pg = int(str(first.get("page"))) if str(first.get("page") or "").isdigit() else 1
        out.append({
            "source": "deterministic",
            "kind": "anchor_gate_blocked",
            "severity": "P1",
            "label": "（整件）证据等级",
            "detail": (f"{len(weak)} 行证据未达门槛（{spread}），"
                       f"facts_verdict={det.get('verdict')} / anchor_gate={gate or '—'}；"
                       f"这些行的数值未被独立核验，不得当作已确认"),
            "page": pg,
            "bbox": [],
        })
    return GH.merge_defects(out)


def _models_of(report: QAReport) -> dict:
    """工单抬头要的「模型版本」：优先网关回的真实快照名，拿不到退回角色常量。"""
    long_m = next((r.get("model") for r in (report.qwen_long or []) if r.get("model")), "")
    max_m = (report.qwen_max or {}).get("model") or ""
    return {QR.MODEL_EVIDENCE: long_m or QR.MODEL_EVIDENCE,
            QR.MODEL_LOGIC: max_m or QR.MODEL_LOGIC}


def build_issue_from(report: QAReport, *, doc: dict, pdf_path: str | Path,
                     facts: Facts | str | Path | None = None,
                     facts_csv: Facts | str | Path | None = None) -> dict:
    """把该件的**全部**缺陷合成一张工单（一件一单 + Checklist）。

    旧版「挑最该修的那一条」是错的：同件的多列塌缩与缺 RθJA 往往同源
    （都是热阻表没读全），拆成两张单反而没人看到因果关系。
    """
    defects = collect_defects(report, doc=doc, pdf_path=pdf_path,
                              facts=facts if facts is not None else facts_csv)
    return GH.build_issue(mpn=report.mpn, pdf_sha256=report.pdf_sha256,
                          defects=defects, decision=report.decision,
                          models=_models_of(report), reasons=report.reasons,
                          deterministic=_det_view(report.deterministic))


def _det_view(det: dict) -> dict:
    """工单里只放「对照用」的机器结论，不放整张弱证据行表。

    弱证据行的价值在于**计数**（「28 行没核验」），逐行贴进工单只会把
    Checklist 挤到几十行以下 —— 需要逐行的场合请直接看 `facts_audit.csv`。
    """
    return {"verdict": det.get("verdict"), "n_rows": det.get("n_rows"),
            "counts": det.get("counts"), "anchor_gate": det.get("anchor_gate"),
            "finding_kinds": det.get("finding_kinds")}


# ---------------------------------------------------------------- CLI
def main(argv: list[str] | None = None) -> int:
    import argparse
    import sys
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser(
        description="交付质审：确定性 + 双 Qwen + 工单（默认 dry-run，不发网络请求）")
    ap.add_argument("--mpn", required=True)
    ap.add_argument("--json", required=True, help="待审的型号 JSON")
    ap.add_argument("--pdf", required=True, help="对应原版 PDF")
    ap.add_argument("--facts", default="",
                    help="事实表：facts_audit.csv **或** facts_audit.json（都行）。"
                         "传 JSON 时优先取同目录同名 CSV 拿逐行 bbox/页码；"
                         "没有同名 CSV 就退化成「汇总 + blocked 清单」，"
                         "工单里会写明缺哪些定位信息。")
    ap.add_argument("--focus", default="thermal,electrical")
    ap.add_argument("--limit", type=int, default=8)
    ap.add_argument("--skip-logic", action="store_true")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true",
                   help="只打印即将发送的请求体，不发网络请求（**默认行为**，写出来只为明确）")
    g.add_argument("--push", action="store_true",
                   help="真的推到 GitHub 建单（不给就永远是 dry-run）")
    ap.add_argument("--out", default="", help="报告与工单 JSON 落盘目录")
    a = ap.parse_args(argv)

    if a.dry_run and a.push:                              # 互斥组已挡，双保险
        ap.error("--dry-run 与 --push 不能同时给")
    dry_run = not a.push                                  # `--dry-run` 只是把默认值写明

    try:
        rep = run_qa(mpn=a.mpn, json_path=a.json, pdf_path=a.pdf,
                     facts_csv=a.facts or None, focus=a.focus, limit=a.limit,
                     skip_logic=a.skip_logic)
    except (FileNotFoundError, ValueError) as e:
        # 路径/格式错在这里一次性说清，不要等跑到一半才崩。
        ap.error(str(e))

    out: dict[str, Any] = rep.as_dict()
    if rep.issue:
        out["dispatch"] = GH.create_issue(rep.issue, dry_run=dry_run,
                                          out_dir=a.out or None)
    if a.out:
        p = Path(a.out) / f"qa-{a.mpn}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
