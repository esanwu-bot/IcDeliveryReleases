#!/usr/bin/env python
"""按交付口径打包已完成型号：总清单 + 分卷 zip。

    python delivery_bundle.py                    # 1000 件/卷，含 PDF 原件
    python delivery_bundle.py --no-pdf           # 只打 JSON/HTML/三视图/SEO（体积小很多）
    python delivery_bundle.py --limit 20         # 冒烟：只打 20 件
    python delivery_bundle.py --per-shard 500 --out data/exports/delivery-20261024

产物：
    <out>/manifest.csv            全量清单（含缺失项与 quality_warning）
    <out>/README.md               交付说明与验收口径
    <out>/part-0001-of-0014.zip   每卷 <per-shard> 个型号，目录结构 <型号>/<产物>

PDF 用 ZIP_STORED（PDF 本身已压缩，deflate 只烧 CPU 不省体积），文本产物才 deflate。
分卷先写 .part 再改名，重跑会跳过已完成分卷。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import shutil
import sys
import time
import zipfile
from datetime import date, datetime
from pathlib import Path, PurePosixPath

from app import config, db
from app.services import packager
from app.services.parts import safe_name
from qc import ac_quarantine
from qc import core_validation as CV

PDF_KEY = "pdf"


#: 交付目录名纪律（AGENT.md §16.1）：`delivery-YYYYMMDD` 是**当日**首版，
#: 同一天再打就递增 `-V2` / `-V3`。日期**永远是当天实际日期**，
#: 不许因为「这是下一版」就把日期写成明天 —— 1101 那天真的出现过
#: `delivery-20261102` 和 `delivery-20261102-V2` 两个次日目录。
#: 1102-V3.1 起允许**点分补丁位**（`-V3.1`）：重打 V3 只修一处时，
#: 对外说明里「V3 的补丁版」的语义必须能落到目录名上；只认整数会把
#: 这种包逼成 V4，版本追溯反而更难。整数形态（`-V3` / `-V4`）照旧。
_DELIVERY_DIR_RE = re.compile(r"^delivery-(\d{8})(?:-V(\d+(?:\.\d+)?))?$")

#: 已发布过、不重命名的历史例外（AGENT.md §16.1 末段）。它们不合新规矩但也不改，
#: 一律放行，否则会误伤已推送出去的包。
_HISTORICAL_EXCEPTIONS = frozenset({
    "delivery-20261030-fixed",
    "delivery-20261030-i18n",
})

#: **`-eval` 后缀 = 可入发布仓库的灰度/盲审包**（AGENT.md §16.1a，2026-11-03 起）。
#: 允许三种形态：`delivery-YYYYMMDD-eval`（带日期）、`delivery-<用途>-eval`
#: （如 `delivery-batch20-eval`，批次名代替日期），以及它们的迭代版
#: `-eval-V2` / `-eval-V3`（盲审返修必须能区分第几轮，不能原地覆盖）。
#: 共同点是**必须含 `-eval` 段** —— 这是「这包不是正式版本、可被外部盲审」的
#: 唯一机器可判标识。`-CANDIDATE` 后缀是 2026-11-03 Reviewer 明确要求的
#: **V3 候选包标记**：它只能加在 `-eval` 包上，明示「候选物料、未批准」，
#: 不允许单独用于正式包（正式包仍只认 `delivery-YYYYMMDD[-Vn]`）。
_EVAL_DIR_RE = re.compile(
    r"^delivery-(?:\d{8}|[a-z0-9][a-z0-9-]*)-eval(?:-V\d+)?"
    r"(?:-CANDIDATE)?(?:-FINAL)?$")


def is_eval_package(name: str) -> bool:
    """目录名是否声明为 `-eval` 灰度/盲审包（决定能不能推 GitHub 发布仓库）。"""
    return bool(_EVAL_DIR_RE.match(name))


def check_delivery_name(out: Path, today: date | None = None) -> str | None:
    """目录名合规返回 None，不合规返回给操作员看的错误文案。

    校验三类：
    1. `delivery-YYYYMMDD[-Vn[.m]]` 的日期不能是未来（§16.1）；
    2. `delivery-<8位日期>-<其它后缀>` 一律拒绝（§16.1a）—— 测试包/灰度包
       不许占用正式序列，否则 `-V2/-V3` 的「对外第几版」含义就废了。
       **唯一例外是 `-eval` 后缀**（见 `_EVAL_DIR_RE`）：它不占用 `-Vn` 序列，
       且以 `-eval` 明示「非正式、供盲审」，因此允许存在、也允许推发布仓库。
    3. 没有日期段的自由名字（如 `delivery-demo`）不判。
    """
    if is_eval_package(out.name):
        # `-eval` 包同样不允许用未来日期（`delivery-20270101-eval` 是排期错误）。
        m_ev = re.match(
            r"^delivery-(\d{8})-eval(?:-V\d+)?(?:-CANDIDATE)?(?:-FINAL)?$",
            out.name)
        if m_ev:
            today = today or date.today()
            try:
                day = datetime.strptime(m_ev.group(1), "%Y%m%d").date()
            except ValueError:
                return f"目录名里的日期不是合法日期：{out.name}"
            if day > today:
                return (f"灰度包也不能使用未来日期：{out.name}"
                        f"（今天是 {today:%Y%m%d}）")
        return None
    m = _DELIVERY_DIR_RE.match(out.name)
    if not m:
        if (re.match(r"^delivery-\d{8}", out.name)
                and out.name not in _HISTORICAL_EXCEPTIONS):
            return (f"目录名占用了正式交付序列：{out.name}。"
                    f"正式包只允许 delivery-YYYYMMDD 或 delivery-YYYYMMDD-Vn"
                    f"（补丁版可写 -Vn.m，如 -V3.1）；"
                    f"测试/灰度包请用 test-YYYYMMDD-batchXX 或 "
                    f"staging-<用途>-YYYYMMDD（AGENT.md §16.1a）；"
                    f"要推 GitHub 供外部盲审的灰度包必须带 -eval 后缀"
                    f"（如 delivery-YYYYMMDD-eval / delivery-batch20-eval）")
        return None
    today = today or date.today()
    try:
        day = datetime.strptime(m.group(1), "%Y%m%d").date()
    except ValueError:
        return f"目录名里的日期不是合法日期：{out.name}"
    if day > today:
        return (f"交付目录不能使用未来日期：{out.name}（今天是 {today:%Y%m%d}）。"
                f"当日迭代请用 delivery-{today:%Y%m%d}-V2 / -V3 …")
    return None


def next_delivery_dir(root: Path, today: date | None = None) -> Path:
    """当天第一个空闲的交付目录：`delivery-YYYYMMDD`，已存在就 `-V2`/`-V3`…"""
    today = today or date.today()
    base = f"delivery-{today:%Y%m%d}"
    p = Path(root) / base
    if not p.exists():
        return p
    n = 2
    while (Path(root) / f"{base}-V{n}").exists():
        n += 1
    return Path(root) / f"{base}-V{n}"

README = """# IcPdfParser 交付包

由 `delivery_bundle.py` 从工作台数据库与 `data/` 实际产物生成，清单与磁盘一致。

## 目录结构

```
manifest.csv                 全量清单（状态、来源、PDF sha256、产物缺失项、quality_warning）
part-XXXX-of-YYYY.zip        分卷交付包，每卷 {per_shard} 个型号
  <型号>/<型号>.pdf          Datasheet 原件（--no-pdf 时不含）
  <型号>/<型号>.json         结构化 JSON（唯一事实来源，含 multi_language 四语）
  <型号>/<型号>.html         详情页 HTML 片段（10 段，英文）
  <型号>/<型号>.ja.html      详情页 HTML 片段（日语变体，叙述段本地化）
  <型号>/<型号>.ko.html      详情页 HTML 片段（韩语变体，叙述段本地化）
  <型号>/<型号>.de.html      详情页 HTML 片段（德语变体，叙述段本地化）
  <型号>/<型号>.es.html      详情页 HTML 片段（西班牙语变体，叙述段本地化）
  <型号>/<型号>.alts.json    替代型号候选
  <型号>/<型号>.alts.html    替代型号内链片段（无可用内链时缺失）
  <型号>/<型号>.symbols.html 三视图（原理图符号/封装/3D，缺引脚数据时缺失）
  <型号>/<型号>.seo.json     图片 SEO 清单
```

多语言说明：变体页的规格表/绝对最大值/引脚等符号数值段与英文页一致（全球通用）；
hero/概述/特性/应用等叙述段取自 JSON 的 `multi_language`。语言变体属增强项，
某型号变体缺失时站点应回退英文页。

## 页面片段与 SEO 侧车（交付契约）

HTML **是内容片段，不是整页**：每个 `.html` 以 `<div class="pd-wrap">` 开头，
**不含** `<html>` / `<head>` / `<title>` / `<meta name="description">` /
`<link rel="canonical">` / `hreflang` / JSON-LD。这是契约，不是缺漏 ——
片段由独立站前端框架套壳时注入头部。

因此：标题/meta/keywords 在 `<型号>.seo.json` 的 `page` 节点；多语叙述段在各语种
片段内；片段 `<h1>` 已使用 `seo.json` 对应语种标题（注入管线只接到 h1，未接 head）。
**复核时请勿**把「片段没有 `<title>`」判为缺陷，应判「框架是否注入」。
若需求方要求整页交付，须先改本契约并同步渲染层。

`manifest.csv` 的 `missing` 列列出该型号缺失的产物键；`quality_warning` 非空表示
低规格交付（电气参数少于 3 条，但引脚表或特性列表成规模）。

`gate` / `gate_reasons` 是**逐件闸门状态**（V5/1101 起补回，V4 缺这一列导致
「ADC 是否已解 BLOCKED」无从判断）：

| `gate` | 含义 | 判据 |
|---|---|---|
| `BLOCKED` | 不得上线 | 无 `datasheet_url`（溯源链断），或引脚映射被隔离（`pin_validation != pass`） |
| `UNRESOLVED` | 核心校验未过，或有被隔离的未核数据 | `metadata.core_validation` 非 `pass`（含 `pass_with_quarantine`） |
| `PATCHED` | 有确定性修补痕迹 | 温度补单位 / 应力行归位 / 链接回填 / 球位重建（明细见 `gate_reasons`） |
| `CLEAN` | 以上全无 | — |

`gate` 只是**已有证据的汇总列**，不是工程验收结论；`release_status` 恒为
`not_approved`，人工批准是另一件事。

## 核验状态与可复现性（V4 起）

- 电气表 / 绝对最大表里带 `†` 的行，表示**管线自己判定该行未核验**：
  `condition_unverified`（条件串与数值不同源）、`column_roles_not_verified`
  （列角色未对上）、`not_checked`（本轮未复核），或 **`model_unverified`**
  （该行由语言模型抽取，未经确定性抽取/逐格核验）。
  表头上方会给出「N 项未核验」提示条。这是披露，不是渲染缺陷 ——
  没有 `†` 才需要怀疑是不是标记漏了。
- **`model_unverified` 不代表值错**，只说明来源是模型而不是代码。本包的核心字段
  （球位 / 热阻 / ESD / VCMI / VID）由确定性抽取产出，标的是 `audited_deterministic`，
  不带 `†`；其余电气行与绝对最大行一律带 `†`。
- 每个 `<型号>.json` 的 `metadata.core_sha256` 记录四个核心字段
  （`pin_configuration` / `specs.thermal` / `specs.esd` / VCMI+VID）的 sha256。
  复跑同一份 PDF 后比这四个值即可判断产物是否可复现；**不一致请拒收并回报**，
  不要用「本次看着对」验收。
- `basic_info.datasheet_url` 为空**不是**允许的缺省值：`check_core()` 会直接判失败
  （见上表 `BLOCKED`）。板卡件的链接在 `device_datasheet_url`，页面会指向它。
- **绝对最大表自 V3 起可靠性降级**：V3 起其中多数行被管线标为未核验。
  V2 时代「6/6 正确」的结论**不适用于 V3 及以后的包**，请勿沿用。

## 验收口径

- **可上线**：`json` 与 `html` 齐备（缺三视图/替代内链属于增强项缺口），
  且 `gate` 不是 `BLOCKED`。
- **不可上线**：缺 `json` 或 `html`，或 `gate = BLOCKED`（无源 PDF 链接 /
  引脚映射被隔离），这类型号不应出现在本包（本包只收 `done`）。

## 说明

- 应用领域图片是站内共享素材（`app-*.png`），不在每型号目录内。
- 型号中的 `/`、`#`、空格在文件名中替换为 `_`，页面主键仍用原始型号。
- 分卷之间互不依赖，可并行分发/校验。
"""


#: 身份状态里可视为「已审核」的取值。其余（`IDENTITY_REVIEW` / `BOARD_REVIEW` /
#: `UNKNOWN`）都表示归属未定，不得进入可交付状态。
IDENTITY_APPROVED_STATES = frozenset({"IDENTITY_SUPPORTED", "BOARD_CONFIRMED"})


def _gate(doc: dict, pdf_match: bool | None = None) -> tuple[str, str]:
    """逐件闸门状态 + 原因。四态：`BLOCKED` / `UNRESOLVED` / `PATCHED` / `CLEAN`。

    V3 的 manifest 有这一列，V4 掉了，Reviewer 就无法判断「ADC 是否已解 BLOCKED」
    （新-5 第三条）。判据只用**产物内已有的证据**，不引入新推断：

    * `BLOCKED`    —— 溯源链断（无 `datasheet_url`）、引脚被隔离
      （`pin_validation.status != pass`），或随包 PDF 与记录的 `pdf_hash` 不是同一份。
      这几条是"页面不该上线"的硬伤。
    * `UNRESOLVED` —— 核心校验未过（`metadata.core_validation` 非 pass），
      或有被隔离的未核数据（`pass_with_quarantine`，原因里带
      `quarantine_count`），或**身份未审核**（`identity_state` 不在已批准集合）。
    * `PATCHED`    —— 有确定性修补痕迹（归一改过内容 / 引脚被重建）。
    * `CLEAN`      —— 以上全无。

    **身份为什么算 UNRESOLVED 而不算 CLEAN**：1101 包的 `ADS8568EVM-PDK` 带着
    `IDENTITY_REVIEW` 落了 `CLEAN`，Reviewer 判为"`CLEAN` 被误读成身份已通过"。
    身份归属未定时，页面参数该记在器件还是整板本身就还没定，比"缺个修补"严重，
    不能和「什么都没发生」共用一个状态。

    **这不是工程验收结论**，只是把已有证据汇总成一列，方便复核方定位。
    """
    bi = doc.get("basic_info") or {}
    meta = doc.get("metadata") or {}
    reasons: list[str] = []

    if not (str(bi.get("datasheet_url") or "").strip()
            or str(bi.get("device_datasheet_url") or "").strip()):
        reasons.append("no_datasheet_url")
    pv = meta.get("pin_validation") or {}
    # D4 硬闸（2026-11-04）：老契约 pass（BGA，pin_repair 写）与新契约 passed
    # （非 BGA，deterministic_extract 写）都算过闸；failed/unverified 一样 BLOCKED
    # —— 印证 Reviewer「PIN 验证失败不允许通过内容审批」。
    #
    # **缺失也 BLOCKED**（同日补）：V3-CANDIDATE 的 7 件该字段全为空，`_gate`
    # 却全判 CLEAN —— 「没有这道闸的记录」被读成了「这道闸放行了」。装配期
    # `stage_release` 现在会重放 `apply_pin_gate`，新包不该再出现空值；
    # 空值只可能意味着重放没跑，那正是必须拦住的状态。
    if not isinstance(pv, dict) or not pv:
        reasons.append("pin_validation=missing")
    elif pv.get("status") not in ("pass", "passed"):
        reasons.append("pin_validation=" + str(pv.get("status")))
    if pdf_match is False:
        reasons.append("pdf_hash_mismatch")
    if reasons:
        return "BLOCKED", ";".join(reasons)

    cv = meta.get("core_validation")
    if cv and cv != CV.PASS:
        # `pass_with_quarantine` 不是「通过」：它表示 AC 脏行被搬进了隔离区，
        # 数据还在、只是不敢发布。归到 UNRESOLVED 是刻意的 fail-closed ——
        # 把被扣下的数据当成「没有数据」才是复审说的误导。
        if cv == CV.PASS_WITH_QUARANTINE:
            n = meta.get("quarantine_count")
            reasons.append(f"core_validation={cv}({n})" if n
                           else f"core_validation={cv}")
            return "UNRESOLVED", ";".join(reasons)
        return "UNRESOLVED", ";".join(cv if isinstance(cv, list) else [str(cv)])

    ident = str(bi.get("identity_state") or "").strip()
    if ident and ident not in IDENTITY_APPROVED_STATES:
        return "UNRESOLVED", f"identity_state={ident}"

    patched = []
    norm = meta.get("normalize") or {}
    if norm.get("stress_demoted"):
        patched.append("stress_demoted")
    if norm.get("temperature", {}).get("changed"):
        patched.append("temperature_unit")
    if norm.get("datasheet_url", {}).get("action") == "filled":
        patched.append("datasheet_url_filled")
    if (norm.get("pin_repair") or {}).get("action") == "rebuilt":
        patched.append("pins_rebuilt")
    if patched:
        return "PATCHED", ";".join(patched)
    return "CLEAN", ""


#: 发布状态阶梯（只进不退）。**前三级可由产物证据自动判定，后两级必须人工签核** ——
#: 自动化不得自称已通过内容审核或已获准发布，那正是 1101 包被批的"结构测试全过、
#: 客户仍发现关键参数错误"的成因。Reviewer 建议的五级，与 `qc/facts_review.py`
#: 已有的 PACKAGE_PASS / PROVENANCE_PASS / DATA_SEMANTICS_PASS / DOWNSTREAM_PASS /
#: RELEASE_APPROVED 同构，这里取对交付物更直观的一套命名。
RELEASE_LADDER = ("PACKAGING_PASSED", "DATA_VALIDATED", "IDENTITY_APPROVED",
                  "CONTENT_APPROVED", "RELEASE_APPROVED")

#: 交付包的**全量语言**。`i18n_complete=true` 要求这五种**都真的渲染出 HTML** ——
#: 少一种就不叫「多语言完整」（2026-11-03 外审 V2：只交 en 的包曾在清单里
#: 写着 complete=true，因为旧判据只看「侧车里每种语言都没回退」，单元素恒真）。
REQUIRED_LANGS = ("en", "ja", "ko", "de", "es")

#: 引脚使用边界（2026-11-04 外审）。三处必须同时出现：`manifest.json`、
#: `README.md` 速览、《交付说明.md》。只在 README 写等于没写 —— 客户读的是清单。
PIN_USAGE_NOTICE = (
    "`pin_validation=unverified`、或仅作总数对账的 `passed`，其引脚数据"
    "**仅供预览**，绝对不可用于自动接线、封装选型或逆向工程；"
    "需要接线级可用性时，必须逐脚对照原厂 PDF 并由人工签核。")

#: `manifest.csv` 的列顺序 = 复核方的阅读顺序。抽成模块级常量是为了可被用例锁死：
#: 漏一列不会有任何异常，只会让某个结论「只存在于 JSON 里」——
#: 2026-11-04 的 `content_signoff` 就是这样漏掉的（records 里有、CSV 里没有）。
MANIFEST_COLUMNS = (
    "mpn", "safe_name", "brand", "status", "release_status", "release_state",
    # 人工签核三列紧跟 `release_state`：只把 `content_signoff` 写进 `records`
    # 而漏在 CSV 里，等于「跨级放行只在 JSON 里可见」——复核方打开 Excel 看到
    # `CONTENT_APPROVED` 会默认机器也验过了。两维必须相邻：`gate` 记机器判了什么，
    # `content_signoff` 记人判了什么。
    "content_signoff", "content_signoff_by", "content_signoff_note",
    "gate", "gate_reasons",
    # AC 容器状态四列。与 `gate` 相邻是刻意的：`gate=BLOCKED` 时
    # 复核方第一眼要看的正是这四格（见 `container_state()`）。
    "formal_container_integrity", "ac_data_state",
    "container_state_source", "container_state_match",
    "facts_verdict", "facts_note", "facts_rows",
    # V7：`data_anchor` 一列拆成四列 + 闸门结论。顺序即阅读顺序：
    # 先看行级，再看正文级，再看（明确标注的）容器级，最后看闸门。
    "row_anchor", "paragraph_anchor", "container_verified",
    "coord_anchor", "anchor_gate",
    "document_subject", "data_subject", "document_scope", "subject_match",
    "identity", "identity_state",
    "scope", "artifacts", "missing", "html_languages", "missing_html_languages",
    "i18n_complete", "i18n_coverage", "pin_desc_exempt",
    "pdf_included", "pdf_hash_match",
    "pdf_sha256_recorded", "pdf_sha256_packaged",
)


def _i18n_sidecar(src: Path, m: str) -> dict:
    """读 `txt/{m}.i18n.json`（`json_to_txt.py` 渲染时落盘）。

    打包器是「只装配已有物料」模式，**不允许在打包时重渲染一遍**来算覆盖率，
    所以 `i18n_complete` 只能从侧车读。侧车缺失时返回 `{}`，
    调用方据此写 `not_checked` —— 缺证据就说缺，不猜。
    """
    p = src / "txt" / f"{m}.i18n.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _i18n_fields(side: dict) -> dict:
    """把侧车压成 manifest 的两列：`i18n_complete` 与 `i18n_coverage`。

    覆盖率取**所有语言里最低**的那一个：只报最好看的数字等于没报。

    V2（2026-11-03 外审）两条硬规则：

    1. **`i18n_complete=true` 的唯一条件是 `html_languages` 长度等于 5。**
       旧实现是「侧车里每种语言的 `i18n_complete` 都是 True」—— 只跑 en 时
       侧车只有 `{"en": {complete: True}}`，`all()` 对单元素恒真，于是
       **只交了英文的包在清单里写着「多语言完整」**。这是自欺，不是笔误。
    2. **`i18n_coverage` 的空值落 `0.0`，不落空字符串。**
       空串在 Excel 里是空单元格，复核方无法区分「没测」与「测了是 0」，
       而 `0.0` 明确表示「实测覆盖率是零」。缺侧车才是 `not_checked`。
    """
    langs = (side.get("languages") or {}) if isinstance(side, dict) else {}
    if not langs:
        return {"i18n_complete": "not_checked", "i18n_coverage": "0.0"}
    ratios = [v.get("i18n_coverage", {}).get("ratio")
              for v in langs.values()
              if isinstance(v.get("i18n_coverage"), dict)]
    ratios = [r for r in ratios if isinstance(r, (int, float))]
    # 「完整」= 五种语言**都真的渲染出 HTML**，且每种都没有回退。
    complete = (set(langs) >= set(REQUIRED_LANGS)
                and all(v.get("i18n_complete") is True for v in langs.values()))
    return {
        "i18n_complete": "true" if complete else "false",
        "i18n_coverage": f"{min(ratios):.4f}" if ratios else "0.0",
    }


def _machine_rungs(doc: dict, facts: dict | None) -> tuple[bool, bool]:
    """两个**机器**档位各自是否达成：`(data_ok, identity_ok)`。

    拆出来是因为 `_release_state()`（定档）与 `_content_signoff()`（留痕）
    必须用**同一份**判据。两边各算一次，改了一边忘了另一边，就会得出
    「档位写着 `CONTENT_APPROVED`、注脚却说没跨级」这种自相矛盾 ——
    而这类自相矛盾正是复审最不能接受的东西（见 V8 复审 新-2）。
    """
    meta = doc.get("metadata") or {}
    bi = doc.get("basic_info") or {}
    data_ok = (CV.is_clean_pass(meta.get("core_validation"))
               and (facts or {}).get("verdict") == "pass"
               and (facts or {}).get("anchor_gate") == "pass")
    identity_ok = str(bi.get("identity_state") or "").strip() in IDENTITY_APPROVED_STATES
    return data_ok, identity_ok


def _content_signoff(doc: dict, facts: dict | None,
                     signoff: dict | None) -> dict:
    """人工内容审批这一维度的**独立记录**（2026-11-04 用户裁决）。

    `anchor_gate` 与 `content_approved` 量的不是一件事：前者是「机器有没有拿到
    坐标级证据」，后者是「专家有没有逐字段看过内容」。把两者压成一个字段，
    就会把「没举证」读成「没审过」，或反过来把「人工签了」读成「机器过了」。

    所以这里**只读不改**：`facts` / `anchor_gate` 的任何结论都不动，
    只额外输出三样东西供 manifest 与 README 并列展示。

    取值：

    * `NONE`                     —— 没有签核文件，或 `content_approved` 不是 `true`
    * `APPROVED`                 —— 签核了，且机器档位本来也走到了（无警告）
    * `APPROVED (with warnings)` —— 签核了，但**跨过**了 `DATA_VALIDATED` 这一机器档位
      （典型：`anchor_gate=blocked`）。这一档必须在清单里显式写明豁免理由，
      否则下游会把 `CONTENT_APPROVED` 读成「机器也验过了」。
    * `APPROVED (blocked: identity)` —— 签核了，但身份硬门禁没过，**不许**升档。
      身份错了，内容审得再细也是白审；这条不能跨。
    """
    so = signoff or {}
    if so.get("content_approved") is not True:
        return {"content_signoff": "NONE", "content_signoff_by": "",
                "content_signoff_note": ""}
    data_ok, identity_ok = _machine_rungs(doc, facts)
    by = str(so.get("signoff_by") or "").strip()
    at = str(so.get("signed_at") or "").strip()
    if not identity_ok:
        return {
            "content_signoff": "APPROVED (blocked: identity)",
            "content_signoff_by": by,
            "content_signoff_note": (
                "人工已签内容审批，但 identity_state 不在放行集合内，"
                "身份硬门禁不可跨 —— release_state 不升档"),
        }
    if data_ok:
        return {"content_signoff": "APPROVED", "content_signoff_by": by,
                "content_signoff_note": ""}
    # 注脚 = 逐件豁免理由 + **固定结论句**。
    # 固定句不能省：README 速览里印的就是它，而 manifest 与 README 必须说同一件事。
    # 只写签核人自定义的 `waiver`，复核方就得自己去推断「这算不算机器没验过」。
    _base = "机器审计未获坐标证据（anchor_gate=blocked），由人工专家强签放行"
    _waiver = str(so.get("waiver") or "").strip()
    # 签核人自己的措辞里常带同一句结论，拼起来会读成「强签放行；…强签放行」。
    # 去掉尾部的重复表述，只留前半段的逐件事实。
    _waiver = re.sub(r"[，,；;]?\s*由人工专家强签放行[。.]?$", "", _waiver).strip()
    _note = f"{_waiver}；{_base}" if _waiver else _base
    return {
        "content_signoff": "APPROVED (with warnings)",
        "content_signoff_by": by,
        "content_signoff_note": _note + (f"（签署日期 {at}）" if at else ""),
    }


def _release_state(doc: dict, have: list[str], pdf_match: bool | None,
                   facts: dict | None = None,
                   signoff: dict | None = None) -> str:
    """该型号**已达到**的最高发布状态；未达第一级时返回 `NOT_PACKAGED`。

    * `PACKAGING_PASSED` —— 四件必带物料齐备，且随包 PDF 与 `pdf_hash` 一致。
      只证明「包是完整的、原件没被换过」，**不证明参数正确**。
    * `DATA_VALIDATED`   —— `core_validation=pass`（**不含** `pass_with_quarantine`）、
      事实验收表无 MISMATCH，**且精度闸通过**（`anchor_gate=pass`）：每条有数值的
      工程参数都达到了它那个载体要求的证据等级 —— 表格参数要 `row_anchor`，
      正文参数要 `paragraph_anchor`。V7 起 `verified`（容器级复现，无坐标）
      **不再计入**达标；V6 就是在这里放水，ADS8568EVM-PDK 14 行全无坐标却拿到了
      满分锚定率。
    * `IDENTITY_APPROVED`—— 身份状态已审核（`IDENTITY_SUPPORTED` / `BOARD_CONFIRMED`）。
    * `CONTENT_APPROVED` / `RELEASE_APPROVED` —— 只认人工签核文件，代码不代签。
      `content_approved=true` 允许**跨过** `DATA_VALIDATED`（机器无坐标证据），
      但**不跨**身份门禁；跨级痕迹见 `_content_signoff()`。
    """
    if not {"json", "html", "symbol", "pdf"} <= set(have) or pdf_match is not True:
        return "NOT_PACKAGED"
    state = "PACKAGING_PASSED"
    data_ok, identity_ok = _machine_rungs(doc, facts)
    if data_ok:
        state = "DATA_VALIDATED"
    if state == "DATA_VALIDATED" and identity_ok:
        state = "IDENTITY_APPROVED"
    # 人工签核通道（2026-11-04 用户裁决「独立维度记录」）。
    # `content_approved` 与 `anchor_gate` 是两个维度：机器拿不到坐标证据
    # ≠ 专家没审过内容。后者由签核文件表态，因此允许**跨过 `DATA_VALIDATED`
    # 这一机器档位**直接落 `CONTENT_APPROVED`。三条边界写死在这里：
    #   ① 底层 `anchor_gate` / `facts` 的结论一个字都不改（`_gate` 照旧 BLOCKED）；
    #   ② **身份不可跨** —— 身份错了，内容审得再细也是白审（硬门禁）；
    #   ③ 跨级一事必须在 manifest 与 README 留痕，见 `_content_signoff()`。
    if (signoff or {}).get("content_approved") is True and identity_ok:
        state = "CONTENT_APPROVED"
    if state == "CONTENT_APPROVED" and (signoff or {}).get("release_approved") is True:
        state = "RELEASE_APPROVED"
    return state


#: 结论 → 证据等级。必须与 `qc/fact_acceptance.py::GRADE_OF` 一致（有用例锁死）。
#: V7 起 **容器级 `verified` 不算锚定** —— 这正是 8.9 分复审的 P0：
#: 它能把「名字+数值能在 PDF 里复现」写成「锚定到了原厂表的具体行」。
ANCHORED_VERDICTS = ("verified_row", "verified_paragraph", "verified_value")

#: 等级计数从 `facts_audit.json` 的哪几个键取。V7 的 `grades` 是等级，
#: 旧包只有 `counts`（按结论），两者都要能读 —— 但旧包读出来会缺 `grades`，
#: 于是走 `counts` 的映射，结果一样：容器级不进坐标列。
_GRADE_KEYS = ("row_anchor", "paragraph_anchor", "coord_no_fingerprint",
               "container_verified", "weak", "no_value")


def _anchor_columns(facts: dict) -> dict:
    """把事实表压成 manifest 的几列 —— **一列只表达一个证据等级**。

    V6 只有一列 `data_anchor`，把「坐标 + 行指纹」「正文条目」「容器级复现」
    加在一起写成 `108/108`。数字好看，但它回答不了复核方唯一关心的问题：
    这 108 条里有多少条能翻到 PDF 的某一行。

    V7 拆成：
    * `row_anchor`         —— 坐标 + 可重放行指纹（最强，表格参数的门槛）
    * `paragraph_anchor`   —— 坐标 + 正文条目指纹（正文参数的门槛）
    * `container_verified` —— 名字+数值可复现，**无坐标**（不许进上面两列）
    * `coord_anchor`       —— 上面两列 + 有坐标但无指纹的行（坐标级合计）
    * `anchor_gate`        —— pass / blocked，`DATA_VALIDATED` 只认它
    """
    facts = facts or {}
    total = facts.get("n_rows")
    gate = str(facts.get("anchor_gate") or "")
    if not isinstance(total, int) or not total:
        return {"row_anchor": "", "paragraph_anchor": "",
                "container_verified": "", "coord_anchor": "",
                "anchor_gate": gate}
    grades = facts.get("grades")
    if not isinstance(grades, dict):
        # 旧包（v3 事实表）只有按结论的 counts：就地折算等级，不猜。
        counts = facts.get("counts") or {}
        from qc.fact_acceptance import grade_of as _grade_of   # noqa: PLC0415
        grades = {g: 0 for g in _GRADE_KEYS}
        for verdict, n in counts.items():
            g = _grade_of(verdict)
            grades[g] = grades.get(g, 0) + int(n or 0)
    n = {g: int(grades.get(g) or 0) for g in _GRADE_KEYS}
    coord = n["row_anchor"] + n["paragraph_anchor"] + n["coord_no_fingerprint"]
    return {
        "row_anchor": f'{n["row_anchor"]}/{total}',
        "paragraph_anchor": f'{n["paragraph_anchor"]}/{total}',
        "container_verified": f'{n["container_verified"]}/{total}',
        "coord_anchor": f"{coord}/{total}",
        "anchor_gate": gate,
    }


def _subject_fields(doc: dict) -> dict:
    """文档主体 vs 请求型号 —— 芯片手册被用来交付评估板时必须写明。

    ADS8568EVM-PDK 的原厂 PDF 是 **ADS8568 芯片**数据手册（SBAS543C），
    14 条参数全是芯片的。板卡身份还在 `IDENTITY_REVIEW`，数据却已进
    `DATA_VALIDATED` —— 复审读成「板卡数据已完整验收」，这是误读，
    但根因是我们没把主体写出来。
    """
    bi = doc.get("basic_info") or {}
    requested = str(bi.get("mpn") or "")
    # 只有「文档对象是板载器件」时，主体才是那颗芯片；板卡自己的用户指南
    # 主体就是板卡 —— 否则 `BOOST-DRV8711` 会被标成 `subject_match=false`，
    # 造成一个不存在的身份冲突（实测踩到）。
    onboard_doc = str(bi.get("document_scope") or "") == "onboard_device_datasheet"
    default_subject = (str(bi.get("device_mpn") or "") or requested) if onboard_doc \
        else requested
    doc_subject = str(bi.get("document_subject") or "") or default_subject
    data_subject = str(bi.get("data_subject") or "") or doc_subject
    return {
        "document_subject": doc_subject,
        "data_subject": data_subject,
        "document_scope": str(bi.get("document_scope") or ""),
        "subject_match": (not requested) or (data_subject == requested),
    }


def _manifest_row(it: dict, arts: list[dict], no_pdf: bool = False) -> dict:
    try:
        meta = json.loads(it.get("meta") or "{}")
    except (TypeError, ValueError):
        meta = {}
    keys = [k for k, _, _, _ in packager.ARTIFACTS if not (no_pdf and k == PDF_KEY)]
    have = {a["key"] for a in arts if a["exists"] and a["key"] in keys}
    return {
        "mpn": it["mpn"], "brand": it.get("brand", ""), "status": it.get("status", ""),
        "provider": it.get("provider", ""), "pdf_url": it.get("pdf_url", ""),
        "pdf_sha256": it.get("pdf_sha256", ""),
        "last_parsed_at": it.get("last_parsed_at", ""),
        "parse_count": it.get("parse_count") or 0,
        "artifacts": f"{len(have)}/{len(keys)}",
        "missing": ";".join(k for k in keys if k not in have),
        "quality_warning": meta.get("quality_warning", ""),
    }


def _add(z: zipfile.ZipFile, path: str | Path, arcname: str) -> int:
    path = Path(path)
    ctype = zipfile.ZIP_STORED if path.suffix.lower() == ".pdf" else zipfile.ZIP_DEFLATED
    z.write(path, arcname, compress_type=ctype)
    return path.stat().st_size


ACCEPTANCE_MPNS = (
    "ADS8568EVM-PDK", "BOOST-DRV8711", "BOOSTXL-C2KLED",
    "ADC12DJ5200SE", "ADS1201U-1_1K",
)


#: 哈希口径（必须写进包校验报告，否则复核方会把它当成哈希错误）。
#: 2026-10-31 实测：同一份 `ADC12DJ5200SE.html`，本机磁盘/ZIP 是 38476 B（776 个
#: CRLF）→ `752afff8…`；`git clone` 后变 37700 B（全 LF）→ `df10bcd6…`。
#: 内容逐行相同，差异 100% 来自换行符。所以算哈希前统一归一化为 LF，
#: 保证「源文件 / 独立目录 / ZIP 成员」三处在任何平台都得出同一个值。
HASH_RULE = ("文本物料 sha256(CRLF→LF normalized)；PDF 与 ZIP 按原始字节 sha256，"
             "二进制不做归一（归一一次哈希就变了，复核方用 sha256sum 永远对不上）")


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b.replace(b"\r\n", b"\n")).hexdigest()


def _sha256(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def _sha256_raw(path: Path) -> str:
    """原始字节哈希，**不做换行归一**。

    只用于二进制（PDF）。文本才需要 CRLF→LF 归一：PDF 里 0x0D 0x0A 是内容的一部分，
    归一一次就把哈希改掉了，反而对不上 `metadata.pdf_hash`。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _text_len(path: Path) -> int:
    """文本物料按 CRLF→LF 归一后计长（与 `_sha256` 同一口径）。"""
    return len(path.read_bytes().replace(b"\r\n", b"\n"))


def _raw_len(path: Path) -> int:
    """二进制按原始字节计长（与 `_sha256_raw` 同一口径）。"""
    return len(path.read_bytes())


#: 交付说明里那张家表的表头。自检按**这一行**定位表格，逐格与 manifest 比对。
#: 表头写死在两处（渲染 / 校验）比"正则随便抓数字"可靠：抓错一次就是误红。
#: `facts_verdict` 是 V9 加的第七列：复核方 新-2 的原话是「同一件同时标
#: `facts_verdict=pass` 和 `anchor_gate=blocked` 容易误读」—— 那就把两个结论
#: 并排印在同一张表上，读者不必再去 manifest 里对照。
NOTE_TABLE_HEAD = ("| 型号 | 审计行数 | row_anchor | paragraph_anchor | weak "
                   "| anchor_gate | facts_verdict | release_state | content_signoff |")


def final_zip_metrics(out: Path, zip_path: Path) -> tuple[str, int]:
    """返回最终 ZIP 的 `(sha256, size)` —— 只认**落盘之后**的那一份。

    V11 的 432 字节差就是「报告取终值、文档抄中间值」：`12,123,616` 是 `.part`
    阶段的大小，`12,124,048` 才是最终文件。取值只留这一个出口，任何想引用
    ZIP 大小的地方都必须调它，否则就会再抄错一次。
    """
    leftovers = sorted(p.name for p in Path(out).glob("*.part"))
    if leftovers:
        raise RuntimeError(f"存在未替换的临时 ZIP，拒绝写校验报告：{leftovers}")
    if not Path(zip_path).is_file():
        raise RuntimeError(f"ZIP 未落盘：{zip_path}")
    return _sha256_raw(Path(zip_path)), Path(zip_path).stat().st_size


def isolation_rows(doc: dict) -> list[tuple[str, int]]:
    """这份 JSON 里被**物理隔离**的行：`[(容器名, 行数), ...]`，无隔离返回空表。

    只认 `specs` 下以 `unresolved_` 开头的列表容器 —— 这是本项目的隔离约定
    （`qc/ac_quarantine.ISOLATION` 就是 `unresolved_ac_rows`）。为什么不在交付说明里
    写死"AC"：隔离层以后可能扩到别的容器，写死会让新容器静默漏披露。
    """
    specs = (doc or {}).get("specs") or {}
    out: list[tuple[str, int]] = []
    for key, val in specs.items():
        if isinstance(val, list) and val and key.startswith("unresolved_"):
            out.append((key, len(val)))
    return out


def isolation_note(mpn: str, items: list[tuple[str, int]]) -> str:
    """交付说明里那行脚注。措辞固定，自检按「注：」开头 + 型号 + 数字核对。"""
    seg = "、".join(
        f"{n} 行{' AC ' if k == ac_quarantine.ISOLATION else ''}数据（`specs.{k}`）"
        for k, n in items)
    return (f"注：`{mpn}` 有 {seg}因列角色未核验被物理隔离，"
            f"不计入上表「审计行数」；页面相应段为空表并已披露原因，"
            f"原始行保留在 JSON 中可逐条复核。")


def container_state(doc: dict) -> dict:
    """AC 容器状态的机器可读四件套（含来源与自洽核对）。

    `formal_container_integrity` / `ac_data_state` 是 `qc/ac_quarantine.py` 落盘时
    写进 `metadata` 的权威值。这里**不重写判据**，只做两件事：

    1. 老 JSON 没跑过隔离时缺这两个键 → 就地按 `ac_quarantine.formal_container_integrity()`
       重算（用的就是定义本身，不另写一套；两套判据迟早会分叉）。
    2. **无论如何都重算一遍做交叉核对**。manifest 写 `pass` 而 JSON 里躺着脏行，
       比缺字段更糟：复核方会照着 `pass` 直接放行。所以 `container_state_match=false`
       必须能把 `gate` 打成 `BLOCKED`，而不是只印一行提示。

    来源要标出来：`metadata` = 源文件自带（可追溯到隔离那一步），
    `recomputed` = 打包时补算（说明该 JSON 从没跑过隔离，本身就是一个缺口）。
    """
    meta = (doc or {}).get("metadata") or {}
    specs = (doc or {}).get("specs") or {}
    recomputed_integrity = ac_quarantine.formal_container_integrity(doc)
    isolated = specs.get(ac_quarantine.ISOLATION)
    recomputed_state = ("withheld" if isinstance(isolated, list) and isolated
                        else "not_withheld")
    rec_integrity = str(meta.get("formal_container_integrity") or "")
    rec_state = str(meta.get("ac_data_state") or "")
    integrity = rec_integrity or recomputed_integrity
    state = rec_state or recomputed_state
    return {
        "formal_container_integrity": integrity,
        "ac_data_state": state,
        "container_state_source": ("metadata" if (rec_integrity and rec_state)
                                   else "recomputed"),
        "container_state_match": (integrity == recomputed_integrity
                                  and state == recomputed_state),
        # 只用于 mismatch 时写进 gate_reasons，不进 manifest 列。
        "recomputed": f"{recomputed_integrity}/{recomputed_state}",
    }


def _rel_to_root(p: Path, root: Path) -> str:
    """清单里只记**相对装配根**的路径（2026-11-03 外审 P1 的补刀）。

    上一版只把 `source_root` / `output_root` 换成了目录名，`members[].source`
    仍然写着 `E:\\workspace\\IcPdfParser\\data\\staging_...\\ADS1675REF.json`。
    复核方翻 `members` 数组照样能看到打包机的盘符与用户名 —— 脱敏只做一半，
    比不做更难看。相对路径既保留溯源能力（「这份物料在装配根的哪个位置」），
    又不泄露本机结构。取不到相对关系时退化成文件名，绝不回吐绝对路径。
    """
    try:
        return p.resolve().relative_to(root.resolve()).as_posix()
    except (ValueError, OSError):
        return p.name


def _inject_batch_note(text: str, note: str, anchor: str) -> str:
    """把「本批次说明」插到 `anchor` 小节之前。

    为什么要有这个入口：包里有几类事实**无法从产物自动推导** —— 例如某个请求型号
    在最终轮是 `empty_electrical`、被同批次的另一个型号顶替。这类说明如果靠手工
    改 README，下一轮重打包就丢了；写进生成器才能跟着包一起重算、一起被自检覆盖。

    `anchor` 找不到时追加到文末，不静默丢弃（丢一段说明比位置不对更糟）。
    """
    if not note:
        return text
    block = note.strip() + "\n\n"
    idx = text.find(anchor)
    if idx < 0:
        return text.rstrip() + "\n\n" + block
    return text[:idx] + block + text[idx:]


def render_delivery_note(version: str, rows: list[dict], risk_counts: dict,
                         batch_note: str = "") -> str:
    """按本包实测数据渲染《交付说明.md》。

    为什么必须生成而不是随包复制：说明文档是复核方读包的第一入口，它一旦落后于
    manifest，复核方会拿着旧结论去质问新数据（V7 的 P0：包是 V7，说明仍是 V6，
    写着 `ADS8568EVM-PDK 14/14 / DATA_VALIDATED`，而实际是 21/49 / blocked）。
    手写文档靠"下次记得改"，就一定会有忘的那一次 —— 改成生成，忘不了。
    """
    # 签核实况决定「这是什么」这段怎么写。写死「`CONTENT_APPROVED` 未申请」会在
    # 已签核的包上留一句过期话 —— 复核方读到它，会认为说明没跟上签核（V3.1 外审）。
    _n_signed = sum(1 for r in rows
                    if "APPROVED" in str(r.get("signoff") or ""))
    _signoff_lines = ([
        f"- `CONTENT_APPROVED`：**{_n_signed} 件已由人工专家完成签核（限定维度）**，"
        "逐件批准/放弃的维度见下文「受限数据发布」表",
        "- `RELEASE_APPROVED`：**未申请**，发布放行仍待 Reviewer 签核",
    ] if _n_signed else [
        "- `CONTENT_APPROVED` / `RELEASE_APPROVED` 未申请，需人工签核",
    ])
    lines = [
        f"# 交付说明（{version}）",
        "",
        "> 本文件由 `delivery_bundle.py` 在打包时**按本包的 manifest 与 facts_audit",
        "> 实测数据生成**，不含手写数字。凡是与 `manifest.csv` 冲突的旧版说明一律作废。",
        "",
        "## 这是什么",
        "",
        f"本批 {len(rows)} 型号的详情页物料与解析 JSON 的**复核候选包**，不是已批准上线的正式版本。",
        "",
        f"- `release_status` 全部 `not_approved`（本包 `mpn_count={len(rows)}`）",
        *_signoff_lines,
        "- `i18n_complete` / `i18n_coverage` 为**实测值**，打包时从侧车重算",
        "",
        "**打包校验通过不等于工程验收通过，不应直接上线或用于电路设计。**",
        "",
        "> **本包是「受限数据发布包」，不是完整规格书。** 每个型号只有下文明确列出的",
        "> 维度被人工批准；未列出的维度**不构成任何形式的规格承诺**。",
        "> `anchor_gate=blocked`（5/5 件）与引脚使用边界警告在本包内**依然生效**，",
        "> 不因签核而被解除。",
        "",
        "> **本包已包含全部原厂 PDF 原件**（`<型号>/<型号>.pdf`），复核方可对照包内",
        "> PDF 逐行复核任意一条参数，不需要外部下载、也不需要相信清单里的哈希。",
        "> **复核方请用 raw 源或 commit 固定 URL 取文件，不要用 CDN 缓存路径。**",
        "> 复审方在 V5 / V8 / V10 三轮里都被 CDN 缓存坑过：同一路径反复返回",
        "> `403` / `502`、`pdk.json` 首轮返回 0 字节、同一文件要重试三次才拿到内容。",
        "> 拿到的不是包里的字节时，任何结论都不成立。",
        "",
        "",
        "## 出厂前 clone 复跑（每次出包必做）",
        "",
        "出包后一律按**复核方视角**重跑一遍：从发布仓库**全新 `git clone`** 到独立",
        "目录（不复用打包工作区），再用包内自带的 `qc/bundle_selfcheck.py` 从克隆",
        "出来的文件**独立重算**一遍自检。",
        "",
        "这样做的原因很实在：打包工作区里残留的缓存、未提交的改动、以及本机与仓库",
        "之间的口径差异，都会让「我这台机器上是绿的」变成一句没有意义的话。",
        "**只有从仓库克隆出来的那份通过了，这次出包才算通过。**",
        "",
        "本轮复跑记录（克隆的 commit + 自检结果）写在**发布仓库根目录的 `README.md`**，",
        "不在本包内 —— 记录只有在包推送之后才可能产生，把它写进包里必然是自证。",
        "复核方请对照该记录。",
        "",
        "## 受限数据发布：逐件批准的维度与放弃的维度",
        "",
        "签核不是「整件通过」。下表是本包**唯一**的批准范围，按 `signoff.json` 逐件实测生成。",
        "`(n/m anchored)` 指该容器里达到坐标级证据的条数；未到 `m/m` 的整段都不在批准范围内。",
        "",
        "| 型号 | 批准的维度 | 放弃 / 未覆盖的维度 |",
        "|---|---|---|",
    ]
    for r in rows:
        _ap = "<br>".join(f"`{x}`" for x in (r.get("approved_dims") or [])) or "（空）"
        _ex = "<br>".join(f"`{x}`" for x in (r.get("excluded_dims") or [])) or "（空）"
        lines.append(f"| `{r['mpn']}` | {_ap} | {_ex} |")
    lines += [
        "",
        "**在上表「批准的维度」之外的一切用法都不在批准范围内**，具体地：",
        "",
        "- **`anchor_gate=blocked` 依然生效**：机器审计未获坐标级证据，未达标清单逐条写在",
        "  `facts_audit.json::mpns.*.blocked`，本包一个字都没有把它改成 `pass`。",
        "- **引脚使用边界依然生效**：见下方本节末尾的强警告；`electrical_pin_mapping_unverified`",
        "  已逐件写进 `excluded_dimensions`，不因签核而解除。",
        "- **不得包装成完整规格书**：本包是「受限数据发布包」，未列维度不构成规格承诺，",
        "  不可用于自动接线、封装选型、逆向工程或对外规格宣传。",
        "",
        "## 本包实测（数据源：本包 `manifest.csv` + `facts_audit.json`）",
        "",
        f"> **引脚使用边界**：{PIN_USAGE_NOTICE}",
        "",
        NOTE_TABLE_HEAD,
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        # 末列 `content_signoff` 与 `release_state` 紧邻：只见状态不见签核，
        # 复核方会把「人工强签」读成「机器验过」（2026-11-04）。
        lines.append(
            f"| `{r['mpn']}` | {r['n_rows']} | {r['row']} | {r['para']} "
            f"| {r['weak']} | {r['gate']} | {r['verdict']} | {r['state']} "
            f"| {r.get('signoff') or 'NONE'} |")
    # 隔离脚注：上表的「审计行数」是**正式容器**的行数，被隔离的行不在里面。
    # 不写这句，复核方会拿 `facts_audit` 的总行数与上表相减，然后把差额当成漏审计。
    # 文案由 `isolation_note()` 统一产出，自检按同一段文字核对（见
    # `qc/bundle_selfcheck._check_delivery_note` 的第 ④ 条）。
    _isolated = [r for r in rows if r.get("isolated")]
    if _isolated:
        lines.append("")
        for r in _isolated:
            lines.append(isolation_note(r["mpn"], r["isolated"]))
    lines += [
        "",
        "## AC 脏行隔离状态（机器可读，`manifest.csv` 有同名列）",
        "",
        "| 型号 | formal_container_integrity | ac_data_state | 状态来源 | 自洽核对 |",
        "|---|---|---|---|---|",
    ]
    for r in rows:
        # 老调用方（单测里手搓的 rows）可能没有这四格 —— 缺就印 `-`，不要编一个
        # 看起来正常的值出来；`cs_match` 只有明确为 False 才印 mismatch。
        _m = r.get("cs_match")
        _mark = "-" if _m is None else ("ok" if _m else "**mismatch**")
        lines.append(
            f"| `{r['mpn']}` | {r.get('integrity') or '-'} "
            f"| {r.get('ac_state') or '-'} | {r.get('cs_source') or '-'} | {_mark} |")
    lines += [
        "",
        "`formal_container_integrity=pass` **只**表示正式容器里没有脏 AC 行、也没有",
        "无独立溯源的逃逸 AC 行 —— 它不表示参数正确，更不等于放行。",
        "`ac_data_state=withheld` 表示该型号的 AC 数据被**主动扣押**在",
        "`specs.unresolved_ac_rows`：页面相应段是空表并已披露原因，原始行完整保留在",
        "JSON 里，复核方可逐条复核，不需要相信任何一句总结。",
        "",
        "`状态来源=metadata` 表示这两个值是解析/隔离那一步写进源文件的；",
        "`recomputed` 表示该 JSON 从没跑过 `qc/ac_quarantine.py`，这两个值是打包时按",
        "**同一套定义**补算的 —— 后者本身就是一个缺口，不要读成「已隔离」。",
        "`自洽核对=mismatch` 会直接把 `gate` 打成 `BLOCKED`：清单写着 `pass` 而源文件里",
        "躺着脏行，比缺字段更误导。",
    ]
    lines += [
        "",
        "列含义：`row_anchor` = 坐标 + 可重放行指纹（表格参数的门槛）；",
        "`paragraph_anchor` = 坐标 + 正文条目指纹（正文参数的门槛）；",
        "`weak` = 只到「值在同页/别处出现」的弱证据，已在 `risk_queue.csv` 逐条登记；",
        "`anchor_gate=blocked` 表示该型号存在未达门槛的行，`release_state` 不得进入",
        "`DATA_VALIDATED`（见下文发布阶梯）。注意 `blocked` 有两种来源：",
        "`weak`（只有「值在同页/别处出现」）与**只有坐标、没有可重放指纹**",
        "（`coord_anchor` 大于 `row_anchor` 的部分）—— 后者在表里不体现在 `weak` 列，",
        "逐条见 `facts_audit.json::mpns.*.blocked`。",
        "",
        "`facts_verdict` 与 `anchor_gate` **不是同一件事**，两个一起看才有意义：",
        "",
        "| 取值 | 含义 |",
        "|---|---|",
        "| `pass` | 无 MISMATCH（PDF 里查得到、值与交付值对得上），**且**每条都达到该载体的证据等级 |",
        "| `partial_pass` | 无 MISMATCH，但有子项未达锚定门槛 → `anchor_gate=blocked`；缺口条数见 `manifest.csv` 的 `facts_note` |",
        "| `partial` / `fail` / `unchecked` | 存在查不到或对不上的行，逐条在 `risk_queue.csv` |",
        "",
        "所以本表里 `facts_verdict=pass` 的行，其 `anchor_gate` **一定是** `pass`；",
        "出现 `blocked` 就一定是 `partial_pass` 或 `partial`，两者不会再互相打架。",
        "",
        "## `anchor_gate=pass` 证明了什么、不证明什么",
        "",
        "**这六级是叠加的，上一级不自动蕴含下一级。**",
        "",
        "| 层级 | 证明了 | **不**证明 |",
        "|---|---|---|",
        "| 坐标定位 | PDF 上确实有这个位置 | 值是否正确 |",
        "| 行 / 段落指纹 | 参数名与数值绑定到了具体载体 | 列角色、测试条件、脚注是否正确 |",
        "| 列语义核验 | MIN/TYP/MAX 等列角色 | 产品身份是否正确 |",
        "| 条件核验 | 温度、供电、测试条件 | 页面有没有错误归属 |",
        "| 身份与范围核验 | 文档对象、数据主体、产品身份一致 | 内容与语言是否已批准 |",
        "| 人工发布签核 | 责任人已审核 | —— 只有它能进正式发布 |",
        "",
        "所以：**`anchor_gate=pass` 只表示「证据载体达到门槛」，不等于参数事实已完全正确。**",
        "BOOST 两件全部是 `paragraph_anchor`，那只说明正文段落对得上，不代表板卡参数的",
        "测试条件、供电配置、适用场景已逐条核过。",
        "",
        "## 风险队列（`risk_queue.csv`）",
        "",
        f"- 共 {sum(risk_counts.values())} 行需人工处理",
    ]
    for act, n in sorted(risk_counts.items(), key=lambda kv: -kv[1]):
        lines.append(f"- `{act}`：{n} 行")
    lines += [
        "",
        "处置口径：`not_found` / `partial` / `value_in_pdf` 一律先人工翻页确认，",
        "**代码不会建议排除**（误判 `not_found` 的代价是删掉一条正确参数）。",
        "",
        "## 怎么用这个包核对",
        "",
        "1. 打开 `manifest.csv`：每件的 `row_anchor` / `paragraph_anchor` /",
        "   `container_verified` / `coord_anchor` / `anchor_gate` 五个字段，",
        "   **一个字段只表达一个证据等级**，不再用一个数字概括。",
        "2. 打开 `facts_audit.csv`：**逐行**的 PDF 回打结果。带 `bbox` 的行可以按坐标",
        "   翻回原页；带 `sha_input` 的行可以 `sha256(sha_input)` 直接重算出该行指纹。",
        "3. 打开 `risk_queue.csv`：还没解决的行与建议动作。",
        "4. 跑一遍自检：`python qc/bundle_selfcheck.py --out <包根>`（独立实现，",
        "   结论写在本文件同级的 `包校验报告.json::selfcheck`，逐项 `expected/actual/ok`）。",
        "",
        "## 发布阶梯",
        "",
        "```text",
        "PACKAGING_PASSED → DATA_VALIDATED → IDENTITY_APPROVED → CONTENT_APPROVED → RELEASE_APPROVED",
        "```",
        "",
        "- `PACKAGING_PASSED`：必带物料齐备，且随包 PDF 与 `pdf_hash` 一致。",
        "- `DATA_VALIDATED`：`anchor_gate=pass`（**只此一条，且含义见上表**）。",
        "- `IDENTITY_APPROVED`：产品身份与文档主体一致（`subject_match=true`）。",
        "- `CONTENT_APPROVED` / `RELEASE_APPROVED`：人工签核，代码不代签。",
        "",
    ]
    return _inject_batch_note("\n".join(lines), batch_note, "## 本包实测")


def bundle_acceptance(src: Path, out: Path, mpns: tuple[str, ...],
                      batch_note: str = "", batch_label: str = "",
                      attachments: tuple[str, ...] = (),
                      skipped_csv: str = "") -> dict:
    """只装配指定验收根的快照，不查数据库、不重渲染、不回退全局物料。"""
    src, out = src.resolve(), out.resolve()
    if not src.is_dir() or not out.parent.is_dir():
        raise ValueError("验收源目录及输出父目录必须存在")
    if src == out or src in out.parents or out in src.parents:
        raise ValueError("源目录与输出目录不得相同或相互包含")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError(f"输出目录不干净，拒绝覆盖：{out}")
    if not mpns or len(set(mpns)) != len(mpns):
        raise ValueError("型号清单不能为空或重复")
    if any(safe_name(m) != m or m in (".", "..") for m in mpns):
        raise ValueError("--mpns 使用安全文件名；请求原型号由JSON/manifest保留")

    # ── 流水线闸门（2026-11-03 外审 P0-1，一票否决项）────────────────────
    # 交付包必须由完整流水线产出：stage_release --normalize → fact_status_sync。
    # 这条闸门存在的唯一理由是**堵掉「拿旧 JSON 原地重打」这条近路** ——
    # 上一版包里的 JSON 是旧的、`verification` 一片空，事实表却是新的，
    # 两边的结论对不上；而打包器只校验「源文件在打包期间没变」，
    # 哈希自洽 + 内容是旧的，这是最难查的一类错。
    # 失败时错误信息里直接给出该补的命令，不让人猜。
    from qc import pipeline_stamp as PS
    PS.require(src, mpns)

    # 事实验收表与人工签核都是**外部输入**，不在本函数里现算：
    # 现算就等于自己给自己发合格证。缺文件时按「未验证」处理，不按「通过」。
    facts_map: dict = {}
    fa = src / "facts_audit.json"
    if fa.is_file():
        try:
            facts_map = (json.loads(fa.read_text(encoding="utf-8")) or {}).get("mpns") or {}
        except (ValueError, TypeError):
            facts_map = {}
    signoff_map: dict = {}
    so = src / "signoff.json"
    if so.is_file():
        try:
            signoff_map = (json.loads(so.read_text(encoding="utf-8")) or {}).get("mpns") or {}
        except (ValueError, TypeError):
            signoff_map = {}

    # 七类物料；只认本次验收目录，空/缺失不补旧数据、不伪造侧车。
    # `pdf` 是 1102 起新增的**必带项**：1101 及之前不含原件，复核方只能「相信」
    # `pdf_sha256_recorded`，无法独立重算或逐行对照，因而被判「不能视为重新核验」。
    layouts = (
        ("json", "parsed/{m}.json", ".json"),
        ("html", "txt/{m}.txt", ".html"),
        ("symbol", "symbols/{m}.html", ".symbols.html"),
        ("pdf", "pdfs/{m}.pdf", ".pdf"),
        ("alt_json", "alts/{m}.alts.json", ".alts.json"),
        ("alt_html", "alts/{m}.alts.html", ".alts.html"),
        ("seo", "seo/{m}.seo.json", ".seo.json"),
        # 多语覆盖率侧车。清单里的 `i18n_complete` / `i18n_coverage` 就是从这里取的，
        # 不随包的话复核方只能相信那两列，没法自己算一遍 —— 与「不带 PDF」同一类问题。
        ("i18n", "txt/{m}.i18n.json", ".i18n.json"),
    )
    planned, records, source_hashes = [], [], {}
    # 交付说明的行数据：**边装配边收集**，说明文档由它渲染，不抄旧模板。
    note_rows: list[dict] = []
    for m in mpns:
        jp = src / "parsed" / f"{m}.json"
        if not jp.is_file():
            raise ValueError(f"缺少请求型号JSON：{jp}")
        doc = json.loads(jp.read_text(encoding="utf-8"))
        bi, sp = doc.get("basic_info") or {}, doc.get("specs") or {}
        original = str(bi.get("mpn") or "")
        if safe_name(original) != m:
            raise ValueError(f"请求号/文件名不一致：{m} vs {original}")
        have, missing, langs = [], [], []
        for key, pattern, suffix in layouts:
            p = src / pattern.format(m=m)
            if not p.is_file():
                if key in ("json", "html", "symbol", "pdf"):
                    raise ValueError(f"缺少本次必要物料：{p}")
                missing.append(key)
                continue
            planned.append((p, f"{m}/{m}{suffix}", key))
            # 二进制走原始字节哈希，文本走 CRLF→LF 归一；两者混用会静默对不上。
            source_hashes[str(p)] = _sha256_raw(p) if key == "pdf" else _sha256(p)
            have.append(key)
        # 随包 PDF 与 JSON 记录的 `pdf_hash` 必须同一份。否则「随包原件」反而成了
        # 误导性证据：复核方拿它重算，会得出与 manifest 不同的值，比不放更糟。
        pdf_rec = {"included": "pdf" in have, "sha256": "", "match": None}
        if "pdf" in have:
            pdf_rec["sha256"] = source_hashes[str(src / "pdfs" / f"{m}.pdf")]
            want = str((doc.get("metadata") or {}).get("pdf_hash") or "")
            pdf_rec["match"] = (pdf_rec["sha256"] == want) if want else None
        for lg in packager.I18N_LANGS:
            p = src / "txt" / f"{m}.{lg}.txt"
            if p.is_file():
                planned.append((p, f"{m}/{m}.{lg}.html", f"html_{lg}"))
                source_hashes[str(p)] = _sha256(p)
                langs.append(lg)
        ml = doc.get("multi_language") or {}
        # D4 引脚硬闸汇总（2026-11-04）：从 JSON 的 `metadata.pin_validation` 摊平。
        # 缺失时写 `missing`，与 `_gate` 的 `pin_validation=missing` 同一口径。
        _pv = (doc.get("metadata") or {}).get("pin_validation") or {}
        _pin_summary = {
            "status": _pv.get("status") or "missing",
            "reason": _pv.get("reason") or "",
            "actual_count": _pv.get("actual_count"),
            "det_count": _pv.get("det_count"),
            "model_count": _pv.get("model_count"),
            "expected_count": _pv.get("expected_count"),
            "expected_counts": _pv.get("expected_counts") or {},
            "dup_names": _pv.get("dup_names") or [],
        }
        gate, gate_why = _gate(doc, pdf_rec["match"])
        # 容器状态是**闸门的一部分**，不是附注：manifest 写 `pass` 而 JSON 里有脏行，
        # 复核方会照着 `pass` 放行 —— 这种自相矛盾必须打成 BLOCKED。
        _cs = container_state(doc)
        if not _cs["container_state_match"]:
            gate = "BLOCKED"
            gate_why = "; ".join(filter(None, [
                gate_why,
                "container_state_mismatch"
                f"(recorded={_cs['formal_container_integrity']}/{_cs['ac_data_state']}"
                f", recomputed={_cs['recomputed']})"]))
        facts_rec = facts_map.get(m) or {}
        signoff_rec = signoff_map.get(m) or {}
        # 精度闸的结论**由事实表给出**（`facts_audit.json::anchor_gate`），
        # 打包器只负责搬运与呈现，不自己算 —— 自己算就是自己给自己发合格证。
        # V6 的 `anchored_all` 由这里现算，正好把容器级算了进去。
        _anchor = _anchor_columns(facts_rec)
        _subj = _subject_fields(doc)
        _side = _i18n_sidecar(src, m)
        _i18n = _i18n_fields(_side)
        rel_state = _release_state(doc, have, pdf_rec["match"], facts_rec, signoff_rec)
        # 人工内容审批是**独立维度**，与 `gate` / `anchor_gate` 并列展示，不互相覆盖
        # （2026-11-04 用户裁决）。机器审计没拿到坐标证据时 `gate` 照旧 `BLOCKED`，
        # 而 `content_signoff=APPROVED (with warnings)` 说明「专家看过并签字放行」。
        _signoff_info = _content_signoff(doc, facts_rec, signoff_rec)
        # `facts_verdict=pass` 与 `anchor_gate=blocked` 并存会让复核方读成自相矛盾
        # （V8 复审 新-2）。两者量的不是一件事：`verdict=pass` 只说「没有一条
        # MISMATCH」——PDF 里查不到、或查到的值与交付值对不上；`anchor_gate` 说的是
        # 「每条是否达到它那个载体要求的证据等级」。ADS1201U 就是典型：36 条行级
        # 指纹 + 11 条正文条目全对得上，但 `Differential Input Voltage Range`
        # 只有坐标、没有可重放的行指纹，于是闸门 blocked。结论降成 `partial_pass`
        # 并附一句人话注脚，下游不必自己猜两个字段谁说了算。
        _fv = str(facts_rec.get("verdict") or "unchecked")
        _gate_v = str(facts_rec.get("anchor_gate") or "")
        _blk = facts_rec.get("blocked") or []
        facts_note = ""
        if _fv == "pass" and _gate_v and _gate_v != "pass":
            _fv = "partial_pass"
            facts_note = (
                f"core fields pass (no MISMATCH); {len(_blk)} sub-item(s) below the "
                f"required anchor grade -> anchor_gate=blocked")
        records.append({
            "requested_mpn": original, "safe_name": m,
            "gate": gate, "gate_reasons": gate_why,
            # AC 容器状态：`formal_container_integrity` 只说容器干不干净，
            # `ac_data_state` 只说数据有没有被主动扣押，**两者都不等于放行**。
            # 见《交付说明.md》同名字段说明与 `qc/ac_quarantine.py` 模块头。
            "formal_container_integrity": _cs["formal_container_integrity"],
            "ac_data_state": _cs["ac_data_state"],
            "container_state_source": _cs["container_state_source"],
            "container_state_match": _cs["container_state_match"],
            "release_state": rel_state,
            # 与 `gate` **并列**的两个维度：机器（gate/anchor_gate）与人工（签核）。
            # 只写 `release_state` 会让「跨级放行」变成不可见 —— 复核方看到
            # `CONTENT_APPROVED` 会默认机器也验过了。
            **_signoff_info,
            "facts_verdict": _fv,
            "facts_note": facts_note,
            "facts_rows": int(facts_rec.get("n_rows") or 0),
            # D4 引脚硬闸（2026-11-04）：把状态**汇总到清单里**，不让复核方
            # 为了看引脚状态去逐个打开 7 份 JSON。`det_count` 必须一起给：
            # `passed` 只对账总数，CDC6C 实测 det=2 / model=4 仍 passed，
            # 只报 status 会让人以为每个脚都有 PDF 证据。
            "pin_validation": _pin_summary,
            **_anchor,
            "document_subject": _subj["document_subject"],
            "data_subject": _subj["data_subject"],
            "document_scope": _subj["document_scope"],
            "subject_match": _subj["subject_match"],
            "i18n_complete": _i18n["i18n_complete"],
            "i18n_coverage": _i18n["i18n_coverage"],
            "pin_desc_exempt": "true" if _side.get("pin_desc_exempt") else "false",
            "brand": bi.get("manufacturer", ""),
            "identity": bi.get("identity", "unknown"),
            "identity_state": bi.get("identity_state", "unknown"),
            "scope": sp.get("scope"),
            "pdf_sha256_recorded": (doc.get("metadata") or {}).get("pdf_hash", ""),
            "pdf_sha256_packaged": pdf_rec["sha256"],
            "pdf_hash_match": pdf_rec["match"],
            "pdf_included": pdf_rec["included"],
            "status": "review_candidate", "release_status": "not_approved",
            "artifacts": f"{len(have)}/{len(layouts)}",
            "present": have, "missing": missing,
            "html_languages": ["en"] + langs,
            "missing_html_languages": [lg for lg in packager.I18N_LANGS if lg not in langs],
            "json_language_blocks": sorted(lg for lg, block in ml.items() if block),
            "engineering_validation": "not_approved",
        })
        note_rows.append({
            "mpn": original,
            "n_rows": int(facts_rec.get("n_rows") or 0),
            "row": int((facts_rec.get("grades") or {}).get("row_anchor") or 0),
            "para": int((facts_rec.get("grades") or {}).get("paragraph_anchor") or 0),
            "weak": int((facts_rec.get("grades") or {}).get("weak") or 0),
            "gate": _anchor["anchor_gate"] or "未检查",
            "verdict": _fv,
            "state": rel_state,
            # 人工维度的结论也要进这张表：`release_state` 单独出现时，
            # `CONTENT_APPROVED` 读不出「是人工跨级签的」还是「机器验过后签的」。
            "signoff": _signoff_info["content_signoff"],
            # 受限发布声明要逐件列出「批了哪几维、放弃了哪几维」。
            # 这是 `content_approved=true` 能成立的前提 —— 不列维度就等于
            # 让读者以为「全维度都批了」，而实际批的是可枚举的几段。
            "approved_dims": list(signoff_rec.get("approved_dimensions") or []),
            "excluded_dims": list(signoff_rec.get("excluded_dimensions") or []),
            "i18n": _i18n["i18n_complete"],
            "cov": _i18n["i18n_coverage"],
            # 隔离行数（`specs.unresolved_*`）：交付说明的脚注与自检都读这里，
            # 不再各自去翻 JSON —— 一处口径，两处消费。
            "isolated": isolation_rows(doc),
            # 交付说明的「AC 隔离状态」小节按这四格渲染，自检逐格与 manifest 核对。
            "integrity": _cs["formal_container_integrity"],
            "ac_state": _cs["ac_data_state"],
            "cs_source": _cs["container_state_source"],
            "cs_match": _cs["container_state_match"],
        })
    # 随包说明：固定的两份 + 任意 `*_修复说明.md`（版本号不该写死在代码里 ——
    # 写死 `V4_修复说明.md` 时，V5 的说明会被静默丢掉）。
    # **`交付说明.md` 不再从验收根复制**：验收根里那份是上游手写的，版本一迭代
    # 就会落后于数据（V7 的 P0 正是"包是 V7、说明还是 V6，写着 14/14 与
    # DATA_VALIDATED"）。改为打包时按本包实测数据渲染，并在自检里逐格比对。
    docs = [p for p in (src / "修复方案.md",) if p.is_file()]
    docs += sorted(src.glob("*_修复说明.md"))
    # 对外答复也随包：复核方要能看见「哪条提了、怎么改的、哪条没改」，
    # 而不是只拿到一堆文件自己猜。缺件不报错（不是每个包都有答复对象）。
    docs += [p for p in (src / "回复Reviewer.md",) if p.is_file()]
    # 逐行事实验收表与风险队列也是交付物：没有它们，「值有没有出处」就只能靠说明文字。
    docs += [p for p in (src / "facts_audit.csv", src / "facts_audit.json",
                         src / "risk_queue.csv") if p.is_file()]
    for p in docs:
        planned.append((p, p.name, "supporting_document"))
        source_hashes[str(p)] = _sha256(p)

    # 签核原件随包（2026-11-04）：manifest 里的 `content_signoff` 只是**转述**。
    # 复核方要能自己看到「谁签的、哪天签的、豁免了哪一条」，否则清单写
    # `APPROVED` 就等于「听我说他签了」。原件进 `members` 后，哈希与大小
    # 自动被自检覆盖，不必再加一条专门的校验分支。
    _so_src = src / "signoff.json"
    if _so_src.is_file():
        planned.append((_so_src, "signoff.json", "signoff"))
        source_hashes[str(_so_src)] = _sha256(_so_src)

    out.mkdir(exist_ok=True)
    shard = out / "part-0001-of-0001"
    shard.mkdir()
    members = []
    for p, arc, key in planned:
        dest = shard / arc
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)  # 原字节复制：TXT只改交付扩展名，不重渲染
        # 校验也必须与记录口径一致：PDF 走原始字节，文本走 CRLF→LF 归一。
        # 混用会让 PDF 复制后「哈希不一致」——其实两边都没错，只是算法不同。
        got = _sha256_raw(dest) if key == "pdf" else _sha256(dest)
        if got != source_hashes[str(p)]:
            raise RuntimeError(f"复制哈希不一致：{arc}")
        # `size` 与 `sha256` 必须同一口径：文本按 CRLF→LF 归一后计长，PDF 取原始字节。
        # 只归一哈希不归一大小时，复核方在 autocrlf 环境 clone 出来的包会
        # 「哈希对、大小不对」，白查一轮。
        n_size = _raw_len(dest) if key == "pdf" else _text_len(dest)
        members.append({"member": arc, "key": key, "size": n_size,
                        "sha256": got, "source": _rel_to_root(p, src)})

    # ── 随包附件：核对用，不是交付物料 ─────────────────────────────────────
    # V1 的 `A21_matched_evidence.md` 是手工 `cp` 进包根的：文件在包里，但
    # manifest 没记、README 没提、自检不覆盖。复核方拿到了文件却无从判断
    # 「这是什么、该不该信、算不算交付物料」—— 「有」和「写明有」是两件事。
    # 现在附件也走生成器：进 `members`（自检因此自动覆盖哈希与大小）、
    # 进 manifest 的 `attachments`、进 README 的「随包附件」小节。
    for raw in attachments:
        p = Path(raw)
        if not p.is_file():
            raise RuntimeError(f"附件不存在：{p}")
        dest = shard / p.name
        shutil.copyfile(p, dest)
        members.append({"member": p.name, "key": "attachment",
                        "size": _text_len(dest), "sha256": _sha256(dest),
                        "source": _rel_to_root(p, src)})

    # ── 未出产物型号台账（2026-11-03 外审 P1-3）──────────────────────────
    # 「20 件进、8 件出」如果只写在 README 的一句话里，另外 12 件就没有任何痕迹：
    # 复核方无法确认它们是被**主动隔离**还是被**悄悄丢掉**。台账给每件一行
    # 型号 + 去向 + 原因码 + 运行日志原文，缺一不可。
    skipped_rows: list[dict] = []
    if skipped_csv:
        sk = Path(skipped_csv)
        if not sk.is_file():
            raise RuntimeError(f"skipped 台账不存在：{sk}")
        with sk.open(encoding="utf-8-sig", newline="") as f:
            skipped_rows = [dict(r) for r in csv.DictReader(f)]
        for dest in (out / "skipped.csv", shard / "skipped.csv"):
            shutil.copyfile(sk, dest)
        members.append({"member": "skipped.csv", "key": "skipped",
                        "size": _text_len(shard / "skipped.csv"),
                        "sha256": _sha256(shard / "skipped.csv"),
                        "source": _rel_to_root(sk, src)})

    # ── 交付说明：按本包实测数据生成（不抄验收根里的旧文档）───────────────
    risk_counts: dict[str, int] = {}
    risk_rows_total = 0
    rq = src / "risk_queue.csv"
    if rq.is_file():
        with rq.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                risk_rows_total += 1
                act = str(row.get("suggested_action") or "").strip()
                if act:
                    risk_counts[act] = risk_counts.get(act, 0) + 1
    # 事实表 / 风险队列的**行数口径**也要进清单（V8 复审 新-4）：
    # 之前自检只重算哈希与「每条记录的几列」，风险队列有多少行、事实表分母多大
    # 全靠交付说明正文里的一句话——说明写错了没人拦得住，复核方也无法重算。
    # 现在把两个计数写进 manifest，自检再拿包内 CSV 数一遍。
    _facts_rows_total = sum(int((r or {}).get("n_rows") or 0)
                            for r in (facts_map or {}).values())
    _audit_csv_rows = 0
    _fa_csv = src / "facts_audit.csv"
    if _fa_csv.is_file():
        with _fa_csv.open(encoding="utf-8-sig", newline="") as f:
            _audit_csv_rows = sum(1 for _ in csv.DictReader(f))
    facts_summary = {
        "source": "facts_audit.json + facts_audit.csv + risk_queue.csv",
        "facts_rows_total": _facts_rows_total,
        "facts_audit_rows": _audit_csv_rows,
        "risk_queue_rows": risk_rows_total,
        "n_mpns": len(mpns),
        "anchor_gate_blocked": sum(
            1 for r in (facts_map or {}).values()
            if str((r or {}).get("anchor_gate") or "") not in ("", "pass")),
    }
    note = render_delivery_note(out.name, note_rows, risk_counts, batch_note)
    for target in (out / "交付说明.md", shard / "交付说明.md"):
        target.write_text(note, encoding="utf-8")
    members.append({"member": "交付说明.md", "key": "delivery_note",
                    "size": _text_len(shard / "交付说明.md"),
                    "sha256": _sha256(shard / "交付说明.md"),
                    "source": "<generated by delivery_bundle.render_delivery_note>"})

    # 人工签核汇总（2026-11-04）：与 `facts_summary` 并列，**不合并**。
    # `gate` 与 `content_signoff` 是两个维度，任何「取最弱合成一个字段」的做法
    # 都会把「专家签了字」或「机器没举证」其中一方抹掉。
    _so_counts: dict[str, int] = {}
    for _r in records:
        _k = str(_r.get("content_signoff") or "NONE")
        _so_counts[_k] = _so_counts.get(_k, 0) + 1
    signoff_summary = {
        "counts": _so_counts,
        "signers": sorted({str(_r.get("content_signoff_by") or "")
                           for _r in records} - {""}),
        "waived": [{"mpn": _r.get("requested_mpn"),
                    "note": _r.get("content_signoff_note")}
                   for _r in records
                   if "with warnings" in str(_r.get("content_signoff") or "")],
        "policy": ("机器维度（gate / anchor_gate）与人工维度（content_signoff）并列记录；"
                   "content_signoff=APPROVED (with warnings) 的读法是"
                   "「机器审计未获坐标证据，由人工专家强签放行」，不等于机器已验过。"),
    }
    stamp = datetime.now().astimezone().isoformat(timespec="seconds")
    manifest = {
        "schema_version": "acceptance-delivery/v1", "generated_at": stamp,
        "packager_sha256": _sha256(Path(__file__)),
        # 只写目录名，不写绝对路径（2026-11-03 外审 P1）：
        # `E:\workspace\...` 这类路径会泄露打包机的目录结构、暴露内部盘符与用户名，
        # 对复核方也毫无用处（他们拿不到那台机器）。目录名足以说明「从哪个装配根来的」。
        "source_root": src.name, "output_root": out.name,
        "mode": "existing_artifacts_repackage_only", "status": "review_candidate",
        "release_status": "not_approved", "mpn_count": len(mpns),
        "shard": "part-0001-of-0001.zip", "records": records, "members": members,
        # 附件单列一份：复核方看 `mpn_count` 是 8，但 `members` 里会多出附件文件，
        # 不点名就会以为清单与型号数对不上（V1 的 A21 证据表正是这个处境）。
        "attachments": [m["member"] for m in members
                        if m.get("key") == "attachment"],
        # 未出产物型号：数量与原因分布都进清单，让「20 进 8 出」可核对。
        "skipped_count": len(skipped_rows),
        "skipped_reasons": {
            code: sum(1 for r in skipped_rows if (r.get("reason_code") or "") == code)
            for code in sorted({(r.get("reason_code") or "") for r in skipped_rows})},
        "facts_summary": facts_summary,
        # 与 `facts_summary` 并列，不合并（见上方 `signoff_summary` 注释）。
        "content_signoff_summary": signoff_summary,
        "validation_scope": "Allowlist, source hashes, ZIP paths and CRC only; not engineering acceptance",
        "release_ladder": list(RELEASE_LADDER),
        "pdf_policy": "源PDF原件随包；pdf_hash_match=false 判 BLOCKED",
        # 引脚使用边界（2026-11-04 外审）：`pin_validation` 只有 `passed` 才代表
        # 「编号连续 + 无不可解释重名 + 总数与封装表唯一可信脚数一致」，而且
        # `passed` 也只对账**总数**。把 unverified / 仅总数对账的数据拿去做自动接线，
        # 错的是接线不是数据 —— 所以这句警告要进 manifest 本体，不能只写在 README。
        "pin_usage_notice": PIN_USAGE_NOTICE,
        # `gate` 与 `anchor_gate` 是两道不同的闸，混读会把 `gate=CLEAN` 当成
        # 「机器全过」。本批两件正是 `gate=CLEAN` + `anchor_gate=blocked`，
        # 不写清这层关系，清单会被读成自相矛盾。
        "gate_semantics": (
            "`gate` 判物料硬伤与身份（溯源链/引脚硬闸/PDF 一致性/core_validation/"
            "identity_state），四态 BLOCKED|UNRESOLVED|PATCHED|CLEAN；"
            "`anchor_gate` 判每条事实是否达到其载体要求的证据等级（行坐标/段落锚/"
            "容器级）。二者不可互推：`gate=CLEAN` 不代表 `anchor_gate=pass`。"),
    }
    (out / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    columns = MANIFEST_COLUMNS
    with (out / "manifest.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=columns)
        w.writeheader()
        for rec in records:
            row = {k: rec.get(k, "") for k in columns}
            row["mpn"] = rec["requested_mpn"]
            for k in ("missing", "html_languages", "missing_html_languages"):
                row[k] = ";".join(rec[k])
            w.writerow(row)
    # 标题与速览按**本包实测**生成，不写死（2026-11-03 外审 P1）。
    # 旧标题「五型号独立目录交付包」在 8 件批次上直接是错的，外审第一眼就会
    # 认为文档与包不是同一件东西。
    # 锚定计数必须从 `records` 取：`note_rows` 里没有 `anchor_gate` 字段，
    # 从它取会得到恒 0，速览就会印出「0 件 pass / 8 件 blocked」这种反向错报。
    _n_pass = sum(1 for r in records
                  if str(r.get("anchor_gate") or "") == "pass")
    _n_block = len(records) - _n_pass
    # 引脚硬闸分布（2026-11-04）：必须从 `records[].pin_validation` 取，
    # 且 `passed` 与 `failed` 要**分开列**。把两档合成一句「引脚已核」，
    # 就是把 2 件失败藏在 2 件通过后面 —— 与 `_FACTS_RANK` 取最弱同一条纪律。
    _pin_n: dict[str, int] = {}
    for _r in records:
        _s = str((_r.get("pin_validation") or {}).get("status") or "missing")
        _pin_n[_s] = _pin_n.get(_s, 0) + 1
    _pin_line = " · ".join(f"`{k}` **{v} 件**"
                           for k, v in sorted(_pin_n.items(),
                                              key=lambda kv: (-kv[1], kv[0])))
    # 人工签核分布（2026-11-04）：与 `gate` 并列，不合并。
    # 把 `APPROVED (with warnings)` 折算成 `APPROVED` 就是「把跨级放行洗成机器通过」。
    _so_n: dict[str, int] = {}
    for _r in records:
        _s = str(_r.get("content_signoff") or "NONE")
        _so_n[_s] = _so_n.get(_s, 0) + 1
    _so_line = " · ".join(f"`{k}` **{v} 件**"
                          for k, v in sorted(_so_n.items(),
                                             key=lambda kv: (-kv[1], kv[0])))
    _signed = [r for r in records
               if str(r.get("content_signoff") or "NONE") != "NONE"]
    _signers = sorted({str(r.get("content_signoff_by") or "") for r in _signed} - {""})
    _warned = [r for r in _signed
               if "with warnings" in str(r.get("content_signoff") or "")]
    # `gate` 与 `anchor_gate` 是两个机器维度：`gate` 判物料/容器干不干净，
    # `anchor_gate` 判证据到不到位。写死「`gate` 仍为 BLOCKED」会把本来 CLEAN 的
    # 件也说成 BLACK —— 实测本批 5 件里 3 件 BLOCKED、2 件 CLEAN。
    # 所以按实况统计后并列写出，既不改结论，也不夸大。
    _gate_n: dict[str, int] = {}
    for _r in _warned:
        _g = str(_r.get("gate") or "UNKNOWN")
        _gate_n[_g] = _gate_n.get(_g, 0) + 1
    _gate_line = "、".join(f"`gate={k}` {v} 件"
                           for k, v in sorted(_gate_n.items(),
                                              key=lambda kv: (-kv[1], kv[0])))
    _signoff_block = (
        f"- 人工内容审批 `content_signoff`：{_so_line}"
        + (f"（签署人：{'、'.join(f'`{s}`' for s in _signers)}）" if _signers else "")
        + "\n"
        + ("- 签核原件随包：`part-0001-of-0001/signoff.json`（谁签、何时签、豁免哪一条，"
           "复核方可直接打开核对）\n" if _signed else "")
        + (f"- **跨级放行留痕**：**{len(_warned)} 件**的机器审计未获坐标证据"
           f"（`anchor_gate=blocked`），由人工专家强签放行 —— "
           f"机器侧结论原样保留（{_gate_line}，`anchor_gate` 未改），"
           f"`content_signoff` 为 `APPROVED (with warnings)`；"
           f"逐件豁免理由见 `manifest.csv` / `manifest.json` 的 `content_signoff_note`\n"
           if _warned else "")
        # `gate` 与 `anchor_gate` 不是同一道闸：前者查硬伤（溯源/引脚/PDF 一致性/
        # 身份），后者查证据等级。混读会把 `gate=CLEAN` 当成「机器全过」，而本批
        # 恰有两件 `gate=CLEAN` 却 `anchor_gate=blocked` —— 必须写明这层关系。
        + ("- **`gate` 与 `anchor_gate` 不同闸**：`gate` 判物料硬伤与身份，"
           "`anchor_gate` 判每条事实的证据等级；`gate=CLEAN` **不代表** "
           "`anchor_gate=pass`。本批两列均逐件列出，请分别判读\n")
    )
    _title = (f"# {batch_label} — {len(mpns)}-MPN Evaluation Delivery Package"
              if batch_label else
              f"# {len(mpns)}-MPN Evaluation Delivery Package")
    # 受限数据发布：README 是复核方读的第一个文件，批准范围必须在这里就能看见。
    # 只写「已签核」而不写「批了哪几维」，等于把受限发布读成整件合格。
    _dims_rows = [r for r in note_rows
                  if (r.get("approved_dims") or r.get("excluded_dims"))]
    _dims_md = ""
    if _dims_rows:
        _parts = ["\n### 受限数据发布：逐件批准 / 放弃的维度\n",
                  "本包是**受限数据发布包，不是完整规格书**。下表是唯一批准范围，"
                  "未列维度不构成任何规格承诺。\n",
                  "| 型号 | 批准的维度 | 放弃 / 未覆盖的维度 |",
                  "|---|---|---|"]
        for _r in _dims_rows:
            _ap = "<br>".join(f"`{x}`" for x in (_r.get("approved_dims") or [])) or "（空）"
            _ex = "<br>".join(f"`{x}`" for x in (_r.get("excluded_dims") or [])) or "（空）"
            _parts.append(f"| `{_r['mpn']}` | {_ap} | {_ex} |")
        _parts += ["",
                   "`anchor_gate=blocked` 与引脚使用边界警告在本包内**依然生效**，"
                   "不因签核而解除；详见 `交付说明.md` 同名小节。\n"]
        _dims_md = "\n".join(_parts)
    _overview = (
        "## 本包速览（打包时由 manifest 实测生成）\n\n"
        f"- 出产物型号：**{len(mpns)} 件**\n"
        f"- `anchor_gate=pass`：**{_n_pass} 件**；`anchor_gate=blocked`："
        f"**{_n_block} 件**（保留风险标记，**不等于**已通过）\n"
        f"- 引脚硬闸 `pin_validation`：{_pin_line}"
        "（`passed` 只对账总数，逐件 `det_count` 见 manifest）\n"
        f"- **引脚使用边界**：{PIN_USAGE_NOTICE}\n"
        "- 多语言：本次**仅交付 `en`**（`ja` / `ko` / `de` / `es` 未开启）\n"
        + _signoff_block
        + ("- `release_status`：**not_approved**（内容审批已签核，"
           "发布放行仍待 Reviewer 签核）\n"
           "- 本包为**正式发布候选件**，`RELEASE_APPROVED` 未签发前不得上线\n"
           if _signed else
           "- `release_status`：**not_approved**（全包，未申请人工签核）\n"
           "- 本包为**灰度盲审件**，不是正式发布版本\n")
        + (f"- 未出产物型号：**{len(skipped_rows)} 件**"
           f"（逐件型号与原因见 `skipped.csv`，不是悄悄丢弃）\n"
           if skipped_rows else "")
        + _dims_md
        + "\n")
    readme = """# 五型号独立目录交付包

## 状态与使用边界
**打包校验通过不等于工程验收通过，不应直接上线或用于电路设计。**
本模式只装配指定验收根里已经生成的物料，不查数据库、不在打包时重渲染。
参数是否已按指定页缓存修订，以随包《交付说明.md》和 manifest 的 release_status 为准。
TXT内容原字节复制为HTML，symbols文件统一为.symbols.html。
《修复方案.md》是审计要求；它本身不是修复已经完成的证明。
原47/47或83/83报告不沿用，打包校验通过不代表工程参数、对象归属或本地化验收通过。

## 组织格式

```text
manifest.csv                    本批总清单（UTF-8 BOM，Excel可打开）
manifest.json                   每件状态/缺项、物料来源与SHA-256
README.md                       本说明
修复方案.md                     已有复核方案
包校验报告.json                 ZIP路径/源哈希/CRC校验（仅打包层）
facts_audit.csv / facts_audit.json  逐行 PDF 事实验收表（有则随包）
signoff.json                    人工内容审批签核原件（有则随包；谁签/何时签/豁免哪一条）
part-0001-of-0001.zip            五件一卷，内含五个型号独立目录
part-0001-of-0001/               与ZIP相同的解压检查目录
  <型号>/<型号>.json
  <型号>/<型号>.html
  <型号>/<型号>.symbols.html
  <型号>/<型号>.pdf              原厂 PDF 原件（1102 起必带）
```

分卷根同时带总清单、说明及已有修复方案。每型号的物料集中于其独立文件夹，
不再使用parsed/txt/symbols三个平行交付目录。原型号中斜杠仅在文件名中替换为下划线，
例如ADS1201U-1/1K对应ADS1201U-1_1K；JSON和总清单保留请求型号。

## 原厂 PDF 随包（1102 起）

**本包已包含全部原厂 PDF 原件，复核方可对照包内 PDF 逐行复核任意一条参数。**

每个型号目录内附原厂 PDF 原件，复核方可**独立**重算哈希、翻到指定页逐行对照，
不必依赖清单里的 `pdf_sha256_recorded` 自证。清单同时给出两个哈希：

- `pdf_sha256_recorded` —— 源 JSON 解析时记录的哈希；
- `pdf_sha256_packaged` —— 本包内 PDF 的实测哈希（原始字节，不做换行归一）；
- `pdf_hash_match` —— 两者是否一致。**不一致即 `gate=BLOCKED`**：随包原件与被解析的
  不是同一份文件时，它的存在比不放更有误导性。

PDF 是二进制，哈希按原始字节计算；文本物料仍按 `sha256(CRLF→LF)` 归一，
两者不可混用。

## 物料缺项与语言

本批实际存在的物料以manifest为准。未发现的.alts.json、.alts.html、.seo.json
不从全局旧目录补齐，不伪造替代料或图片SEO侧车。JSON内seo/alternatives不等于这些独立物料。
PDF原件随包，清单给出记录哈希、实测哈希与是否一致三项；随包PDF哈希不一致直接BLOCKED。
源JSON可含multi_language内容，但是否已有独立ja/ko/de/es页面另列；目录名i18n是命名约定，
不是五语完整性声明。语言未检查状态为not_checked，缺少变体明确列为missing_html_languages。

### `.alts.html` 缺失时的前端契约（V6 明确）

部分型号在站内目录里**没有合格替代料**（`only_linked=True` 会滤掉所有未命中目录的
型号），此时只产出 `<型号>.alts.json`，**不生成** `<型号>.alts.html`。这不是缺件：

- `.alts.json` 是数据契约（`alternatives[]` 数组，含 `mpn` / `brand` / `url` / `relation`）；
- `.alts.html` 只是同一份数据的**静态片段**，方便直接贴进页面。

**前端请直接读取 `.alts.json` 动态渲染。** 把 `.alts.html` 当必需物料会在这些型号上
得到「缺失」的假告警；`manifest` 的 `missing` 列里 `alt_html` 就是这个含义。
无替代料时**不要**回退到全站搜索或上一批的旧片段 —— 那是把「没有」说成「有」。

### `i18n_complete` 与 `i18n_coverage`（V5 起为实测值）

V4 及之前 `i18n_complete` 恒为 `not_checked` —— 那是个占位符，不是结论。
V5 起由渲染层落盘 `<型号>.i18n.json` 侧车，打包器只读不重算（打包是「装配已有物料」模式）：

- `i18n_complete` —— `true` / `false` / `not_checked`（无侧车）。**所有语言**都无回退才为 `true`；
- `i18n_coverage` —— 实测覆盖率，取**所有语言里最低**的那个（只报最好看的数字等于没报）。
  分母 = 静态词条调用次数 + 叙述块数，分子 = 真的落到目标语言的。

### 两件事被拆开了：`i18n_coverage` 与 `i18n_content_review`（V6）

V5 的 `包校验报告.json` 里只有一个 `i18n_validation`，同时被问两个问题，于是它答
`not_checked` —— 而清单里已经有实测覆盖率。复核方一眼看出这是**自相矛盾**。
根因是两件事被塞进了一个字段：

| 字段 | 谁给结论 | 含义 |
|---|---|---|
| `i18n_coverage` | 机器（渲染层侧车） | `measured` = 覆盖率已逐语言实测；`not_checked` = 没有侧车 |
| `i18n_content_review` | 人工语言审校 | `not_reviewed` = 本管线**不做**译文质量审校，只看覆盖率 |

**覆盖率不等于译文质量**：`ratio=1.0` 只说明「没有回退到英文」，不说明「译得对」。
需要语言审校时，它是一条独立工序，不能由这个字段代签。

### 自证链自检（V6 起强制，V7 起结论落盘）

打包最后一步会跑 `qc/bundle_selfcheck.py`：把 `manifest.json` 里的每个 `sha256`、
`i18n_complete` / `i18n_coverage` / `row_anchor` / `paragraph_anchor` /
`container_verified` / `anchor_gate` / `pdf_hash_match` / `artifacts`
都从**包内文件重算一遍**，任何一项对不上就中断打包。

**自检结论写在 `包校验报告.json` 的 `selfcheck` 字段里**（逐项
`item / expected / actual / ok` + 总体 `passed`）—— 脚本本体不进包
（本仓库只放交付物，不放源码），但每一条断言的期望值与实算值都随包给出，
复核方可以挑任意一条自己去核，不必相信「我们跑过了」这句话。

> V6 的 README 写过「脚本就在包里」，而包内 62 个成员里没有 `.py`。
> 那是声明与产物不符 —— V7 已改成「结论落盘」这个可核的形式。

### `paragraph_sha256` 重算口径（V7 起文档化）

`row_sha256` 与 `paragraph_sha256` 是两套不同的归一化，别混用：

| 字段 | 适用 | 计算式 |
|---|---|---|
| `row_sha256` | 表格行 | 由确定性抽取器给出：`sha256(page / 表标题 / 左上角坐标"x,y"(1 位小数) / 符号 / min / typ / max / 单位)`，以竖线连接 |
| `paragraph_sha256` | 正文条目 | `sha256("page|" + lower(collapse_ws(translate_dashes(line_text))))` |

`translate_dashes` 把 `– — − ‒ ﹣` 统一成 `-`；`collapse_ws` 把连续空白压成一个空格；
`line_text` 是 PyMuPDF `page.get_text("dict")` 里 `line` 内各 `span` 的文本直接拼接
（**不加分隔符**）。复核方拿 `facts_audit.csv` 的 `page` 翻到该页，取同一行文本即可重算：

```python
import hashlib, re
def para_sha(page: int, line_text: str) -> str:
    t = line_text.translate(str.maketrans({"\u2013":"-","\u2014":"-","\u2212":"-",
                                           "\u2012":"-","\ufe63":"-"}))
    t = " ".join(t.split()).lower()
    return hashlib.sha256(f"{page}|{t}".encode("utf-8")).hexdigest()
```

### `pin_desc_exempt`：管脚描述保留英文（豁免声明）

`pin_configuration` 的描述文字**按硬件工程标准保留英文原文**，不属于未翻译残留：
IEEE 器件手册与封装规格里，`VDD`, `AGND`, `SDO/SDI`, `No connect` 这类管脚名与
功能描述在业界按英文原样引用，译成目标语言反而与读者手上的 datasheet 对不上。

清单中 `pin_desc_exempt=true` 表示该型号适用此豁免。页面在非英文语种下也有一行小字说明，
不让读者误以为是漏翻。**除此之外的叙述段（features / applications / description /
technical insight / FAQ）不豁免**，仍按实测覆盖率考核。
V6 起该列恒为 `true` / `false` 两种取值：V5 把「不适用」写成空串，读者分不清
「不适用」和「没算」，与「`not_checked` 被当成结论」是同一类问题。
三块板的.symbols.html是板卡说明页，不伪造芯片三视图；两颗芯片符号仍须核对原厂。
应用图是站点共享素材，本包不复制公共图片，也不把图片路径视为芯片参数证据。

## 发布状态阶梯（release_state）

`gate` 只说「有没有待处理的硬伤」，`release_state` 说「走到哪一级了」。五级只进不退：
| 状态 | 判据 | 能否自动判定 |
|---|---|---|
| `PACKAGING_PASSED` | 四件必带物料齐备 + 随包PDF与记录哈希一致 | 是 |
| `DATA_VALIDATED` | `core_validation=pass`（**不含** `pass_with_quarantine`）**且**事实验收表无 MISMATCH **且**精度闸通过（`anchor_gate=pass`：表格参数达 `row_anchor`、正文参数达 `paragraph_anchor`） | 是 |
| `IDENTITY_APPROVED` | `identity_state` 为 `IDENTITY_SUPPORTED` / `BOARD_CONFIRMED` | 是 |
| `CONTENT_APPROVED` | 页面与多语言通过人工审核 | **否，只认签核** |
| `RELEASE_APPROVED` | 人工签核放行 | **否，只认签核** |

代码**不会**自称通过内容审核或获准发布：后两级只读 `signoff.json`，
没有签核就停在 `IDENTITY_APPROVED`。`identity_state=IDENTITY_REVIEW` 的型号
不会落到 `IDENTITY_APPROVED`，也不会被 `gate` 判成 `CLEAN`。

### 机器维度与人工维度**并列记录**（1104 起）

`anchor_gate` 与 `content_approved` 量的不是一件事：

* `anchor_gate` —— **机器**有没有拿到坐标级证据（表格参数 `row_anchor`、正文 `paragraph_anchor`）；
* `content_approved` —— **专家**有没有逐字段看过内容。

因此 `signoff.json` 里的 `content_approved=true` 允许 `release_state` **跨过**
`DATA_VALIDATED` 这一机器档位，直接落 `CONTENT_APPROVED`。**但只跨这一级**：
`identity_state` 不在放行集合内时一律不升档（身份错了，内容审得再细也是白审）。

跨级一事**必须留痕**，manifest 的每条 `records[]` 与本文上方「本包速览」并列给出：

| 字段 | 含义 |
|---|---|
| `gate` | 机器闸门结论。跨级放行**不改**它，仍是 `BLOCKED` |
| `anchor_gate` | 精度闸：`pass` / `blocked` |
| `content_signoff` | 人工内容审批：`NONE` / `APPROVED` / `APPROVED (with warnings)` / `APPROVED (blocked: identity)` |
| `content_signoff_by` | 签署人 |
| `content_signoff_note` | 跨级豁免理由（逐件人话），无跨级时为空 |

`APPROVED (with warnings)` 的准确读法是：**机器审计未获坐标证据，由人工专家强签放行**。
它**不等于**「机器也验过了」，也不得被下游折算成 `APPROVED` 或 `pass`。

> **封顶规则（1102-V3.2 起明写）**：某型号存在 `gate=UNRESOLVED`（例如 AC 脏行
> 被 `specs.unresolved_ac_rows` withheld、或 `core_validation=pass_with_quarantine`）时，
> 该型号的 `release_state` **封顶在 `PACKAGING_PASSED`**，**不因为 `anchor_gate=pass` 就强制升为
> `DATA_VALIDATED`**。理由：`anchor_gate` 只回答「已交付的行证据达不达门槛」，
> 不回答「有没有该交付却被扣下的数据」；后者是闸门（`gate`）的职责，两者不可互替。
> 这类型号的人工签核可以照常进行，但签核结论不得表述为「数据已完整验收」。

### `DATA_VALIDATED` 自 V5 起收紧，V7 起**按证据等级分流**（必读）

**`facts_verdict=pass` 不等于参数全对。** 它只表示「没有编造出来的数值」——
一个数只要在同一页出现过就算 pass，而 180 页的手册里「同页」几乎是必然的。
ChatGPT 8.0 复审原话：「同页命中证明不了归属」。

`facts_verdict` 有三个取值，**不要只看 `pass` 两个字**：

| 取值 | 含义 |
|---|---|
| `pass` | 无 MISMATCH，且每条都达到了该载体的证据等级（`anchor_gate=pass`） |
| `partial_pass` | **没有编造的数值，但有子项未达锚定门槛** → `anchor_gate=blocked`；缺口条目见 `facts_note` 与 `facts_audit.json::mpns.*.blocked` |
| `partial` / `fail` / `unchecked` | 存在 PDF 里查不到、或查到的值与交付值对不上的行 |

V9 起不再出现「`facts_verdict=pass` + `anchor_gate=blocked`」这种组合：
ADS1201U 曾同时写着这两句，读者只能自己猜哪个说了算（V8 复审 新-2）。
判定口径没变，变的是**结论的措辞**：`pass` 现在真的意味着闸门也过了。

V5 起要求「每一行有数值的工程参数都锚定到了原厂表的具体行」。但 V6 把
**容器级复现**（`verified`：参数名与数值能在 PDF 里复现、但没有行坐标）
也计进了这一列，于是 `ADS8568EVM-PDK` 14 行**一条坐标都没有**，清单上却写着
`14/14` 并进入 `DATA_VALIDATED`。复审原话：「弱证据冒充强证据」。

V7 起 `data_anchor` 这一列**废止**，改成分等级的四列 + 一个闸门结论：

| 列 | 含义 | 门槛 |
|---|---|---|
| `row_anchor` | 有 PDF 坐标 + 可重放的**表格行**指纹 | 表格参数的达标线 |
| `paragraph_anchor` | 有 PDF 坐标 + **正文条目**指纹（表格之外的参数只能到这一级） | 正文参数的达标线 |
| `container_verified` | 名字+数值可确定性复现，**没有坐标** —— 单独列出，不许冒充上面两列 | 永不计入达标 |
| `coord_anchor` | 上面两列 + 有坐标但无可重放指纹的行（坐标级合计） | 只作参考 |
| `anchor_gate` | `pass` / `blocked` —— `DATA_VALIDATED` 只认它 | — |

分母是「行内有数值的行」（`unchecked` 不计），分子是达到**该行载体要求**的那个等级。
表格参数只拿到正文段落证据、或者只有容器级复现，一律 `blocked`，
停在 `PACKAGING_PASSED`，缺口逐行写进 `risk_queue.csv`。

### V5 起主力件降级是**口径变化**，不是数据退步（V7 补）

V4 的 `ADC12DJ5200SE` / `ADS1201U-1/1K` 是 `IDENTITY_APPROVED`，V5 掉到
`PACKAGING_PASSED`。**参数没有变差，是尺子变严了**：V4 把「数值与参数名同页」
算作通过（`facts_verdict=pass`），V5 起改判为「未锚定」。

V6 补回了 `verified_paragraph`（正文条目级坐标），但把容器级混进了锚定率；
V7 拆开之后，凡是**只有容器级**的行会如实让闸门变红 —— 这时请对照
`container_verified` 与 `risk_queue.csv`，不要读成「这一版不如上一版」。

| `anchor_gate` | 含义 |
|---|---|
| `pass` | 每条有数值的参数都达到了自己载体的门槛 —— **只表示"证据载体达到门槛"**（可判 `DATA_VALIDATED`） |
| `blocked` | 存在未达门槛的行（条目见 `facts_audit.json::mpns.*.blocked`）—— 停在 `PACKAGING_PASSED` |
| 空 | 本包没带 `facts_audit.json`，未检查 |

**这不是退步，是把原本藏在 `pass` 里的缺口摆到台面上。**

### 六级证据层级：每级证明什么、不证明什么

`anchor_gate=pass` 常被读成「参数事实已经正确」。**不是。** 六级是叠加的，
上一级不自动蕴含下一级：

| 层级 | 证明了 | **不**证明 |
|---|---|---|
| 坐标定位 | PDF 上确实有这个位置 | 值是否正确 |
| 行 / 段落指纹 | 参数名与数值绑定到了具体载体 | 列角色（MIN/TYP/MAX）、测试条件、脚注是否正确 |
| 列语义核验 | 列角色对得上（`missing_cols` 为空） | 产品身份是否正确 |
| 条件核验 | 温度 / 供电 / 测试条件对得上 | 页面有没有错误归属 |
| 身份与范围核验 | 文档对象、数据主体、产品身份一致（`subject_match`） | 内容与语言是否已批准 |
| 人工发布签核 | 责任人已审核 | —— 只有它能进正式发布 |

因此：BOOST 两件全部是 `paragraph_anchor`，那只说明**正文段落对得上**，
不代表板卡参数的测试条件、供电配置、适用场景已逐条核过；
ADC 的 `99/108` 只能说明这些行绑到了具体表格行，不代表 AC 参数的
MIN/TYP/MAX 列语义与脚注不用复核。

## gate 四态的准确含义

`gate` 是**产物内证据的汇总**，不是验收结论。四态语义如下，请勿把 `CLEAN` 读成「已签核」：

| 取值 | 含义 | 是否可上线 |
|---|---|---|
| `BLOCKED` | 溯源链断（无源 PDF 链接）、引脚映射被隔离，或**随包 PDF 与记录的哈希不一致** | 否，不该出现在包内 |
| `UNRESOLVED` | 核心校验未过，或**身份未审核**（`IDENTITY_REVIEW` 等） | 待人工，不是通过 |
| `PATCHED` | 生成后经确定性归一改过（去应力行、补 URL、补温度单位、重建球位等），`gate_reasons` 列明改了什么 | 取决于 `release_state` |
| `CLEAN` | 上述硬伤与修补痕迹都没有 —— **只表示「没动过、没拦下」** | 仍需 `release_status` 与 `release_state` 判定 |

`PATCHED` 与 `CLEAN` 都不代表参数正确。真正的放行看 `release_status`
（本包全部为 `not_approved`）与 `release_state`（最高只到 `IDENTITY_APPROVED`，
`CONTENT_APPROVED` / `RELEASE_APPROVED` 必须人工签核）。

## 页面片段与 SEO 侧车（交付契约）

本包的 HTML **是内容片段，不是整页**：每个 `.html` 以 `<div class="pd-wrap">` 开头，
**不含** `<html>` / `<head>` / `<title>` / `<meta>` / `<link rel="canonical">` / `hreflang`。
这是契约，不是缺漏——片段由独立站前端框架套壳时注入头部。

因此：

- 标题、meta description、keywords、多语标题在 `<型号>.seo.json` 的 `page` 节点；
- 多语叙述段在 `<型号>.ja.html` / `.ko.html` / `.de.html` / `.es.html` 片段内；
- 片段里的 `<h1>` 已使用 `seo.json` 对应语种的标题（注入管线只接到 h1，未接 head）；
- 复核时**请勿**把「片段没有 `<title>`」判为缺陷，应判「框架是否注入」；
- 若需求方要求整页交付，须先改本契约并同步渲染层，不能靠片段自带头部。

## 核验状态与可复现性（V4 起）

- 电气表 / 绝对最大表里带 `†` 的行，表示**管线自己判定该行未核验**
  （`verification.status` 不是 `audited`）。表头上方给出「N 项未核验」提示条。
  这是披露，不是渲染缺陷。
- 每个 `<型号>.json` 的 `metadata.core_sha256` 记录四个核心字段
  （`pin_configuration` / `specs.thermal` / `specs.esd` / VCMI+VID）的 sha256。
  复跑同一份 PDF 后比这四个值即可判断产物是否可复现；不一致请拒收并回报。
- **绝对最大表自 V3 起可靠性降级**：V3 起多数行被标为未核验，
  V2 时代「6/6 正确」的结论不适用于 V3 及以后的包。

## 校验边界

包校验检查恰好五件、ZIP成员正斜杠无路径穿越、无重复成员、CRC正确、
源文件/独立目录/ZIP成员SHA-256相同，并保存最终ZIP的哈希。
校验报告存于ZIP外，以免报告引用最终ZIP哈希形成循环。
**哈希口径：文本物料 sha256 按 CRLF→LF 归一化后计算**，与平台无关；报告 `hash_rule` 字段
显式记录该口径。若直接对原始字节算哈希，Windows 写出的 CRLF 与 git clone 得到的 LF
会得出不同值（实测同一文件 752afff8… 与 df10bcd6…），那不是数据被改，是换行符差异。

**`manifest.json::members[].size` 与哈希同一口径**：文本取 CRLF→LF 归一后的字节数，
PDF 取原始字节数。两边口径必须一致 —— 只归一哈希不归一大小时，复核方在
`core.autocrlf=true` 的 Windows 上 clone 本仓库会看到「哈希对、大小不对」
（实测三个 `.md` 11653 → 11856），白查一轮。

**例外：PDF 与 ZIP 按原始字节哈希，不做归一。** 二进制里 0x0D 0x0A 是内容的一部分，
归一一次哈希就变了 —— 那会让复核方拿 `sha256sum` 算出的值永远对不上报告，
比不给哈希更误导。`zip_sha256` 记的就是 ZIP 文件的原始字节哈希。
"""
    # 首行标题换成按本包实测生成的标题（`_title` 自带 `# `），其余正文原样保留。
    readme = _title + readme[readme.index("\n"):]
    # 「五型号」是模板里写死的旧文案，在 8 件 / 20 件批次上直接是错的（外审 P1）。
    # 统一按本包实测件数替换，而不是逐个改模板 —— 模板里还有几处「五件」的
    # 叙述句，漏一处就又是一句假话。
    for _a, _b in (("五型号", f"{len(mpns)} 型号"),
                   ("五个型号", f"{len(mpns)} 个型号"),
                   ("五件", f"{len(mpns)} 件")):
        readme = readme.replace(_a, _b)
    readme = readme.replace("## 状态与使用边界",
                            _overview + "## 状态与使用边界", 1)
    readme = _inject_batch_note(readme, batch_note, "## 校验边界")
    # 未出产物台账（P1-3）：先插它，附件小节再插到它前面，保持「附件在后」。
    if skipped_rows:
        _sk = ["## 未出产物型号（`skipped.csv`）", "",
               f"本批共有 **{len(skipped_rows)} 件**未产出交付物。它们**不是丢失**，"
               "而是管线主动拒绝落盘（`PARSE_FAILED: empty_electrical` 时保留该型号"
               "已有 JSON，不用空结果覆盖），或按板卡手册跳过重型抽取。"
               "逐件型号、去向、原因码与运行日志原文都在 `skipped.csv` 里。", "",
               "| 型号 | 去向 | 原因码 |", "|---|---|---|"]
        for r in skipped_rows:
            _sk.append(f"| `{r.get('mpn', '')}` | {r.get('disposition', '')} | "
                       f"`{r.get('reason_code', '')}` |")
        _codes: dict[str, int] = {}
        for r in skipped_rows:
            c = r.get("reason_code") or ""
            _codes[c] = _codes.get(c, 0) + 1
        _sk += ["", "原因分布：" + "；".join(f"`{k}` {v} 件"
                                           for k, v in sorted(_codes.items())) + "。", ""]
        readme = readme.replace("## 物料缺项与语言",
                                "\n".join(_sk) + "\n## 物料缺项与语言", 1)
    # 附件小节按**实际随包的附件**生成，标题取自文件自己的第一个 `#` 标题 ——
    # 不在代码里写死「A21 证据表」这种批次专属文案（下一批会带别的附件）。
    _atts = [m["member"] for m in members if m.get("key") == "attachment"]
    if _atts:
        _lines = ["## 随包附件", "",
                  "以下文件是**核对用附件**，不是交付物料，**不计入 `mpn_count`**，"
                  "也不参与 `anchor_gate`。列出它们是为了让复核方知道「这是什么、"
                  "为什么在包里」，而不是打开 ZIP 看到一个来路不明的文件。", ""]
        for _a in _atts:
            _head = ""
            try:
                for _ln in (shard / _a).read_text(encoding="utf-8").splitlines():
                    if _ln.startswith("# "):
                        _head = _ln[2:].strip()
                        break
            except (OSError, UnicodeDecodeError):
                pass
            _lines.append(f"- `{_a}`" + (f" —— {_head}" if _head else ""))
        _lines.append("")
        _anchor = "## 未出产物型号（`skipped.csv`）" if skipped_rows else "## 物料缺项与语言"
        readme = readme.replace(_anchor, "\n".join(_lines) + "\n" + _anchor, 1)
    (out / "README.md").write_text(readme, encoding="utf-8")
    for name in ("manifest.csv", "manifest.json", "README.md"):
        shutil.copyfile(out / name, shard / name)

    zip_path = out / "part-0001-of-0001.zip"
    part = out / "part-0001-of-0001.zip.part"
    files = sorted(p for p in shard.rglob("*") if p.is_file())
    with zipfile.ZipFile(part, "x", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, p.relative_to(shard).as_posix())
    verified = []
    with zipfile.ZipFile(part) as z:
        names = z.namelist()
        if len(names) != len(set(names)) or len(names) != len(files):
            raise RuntimeError("ZIP成员数量/唯一性错误")
        if z.testzip() is not None:
            raise RuntimeError("ZIP CRC错误")
        model_dirs = set()
        for name in names:
            pp = PurePosixPath(name)
            if "\\" in name or pp.is_absolute() or ".." in pp.parts:
                raise RuntimeError(f"非法ZIP路径：{name}")
            if len(pp.parts) > 1:
                model_dirs.add(pp.parts[0])
            # 与记录口径一致：PDF 走原始字节，文本走 CRLF→LF 归一。
            raw = name.lower().endswith(".pdf")
            got = (hashlib.sha256(z.read(name)).hexdigest() if raw
                   else _sha256_bytes(z.read(name)))
            want = (_sha256_raw(shard / name) if raw else _sha256(shard / name))
            if got != want:
                raise RuntimeError(f"ZIP成员哈希错误：{name}")
            verified.append({"member": name, "sha256": got})
        if model_dirs != set(mpns):
            raise RuntimeError("ZIP型号allowlist不一致")
    key_of = {str(p): k for p, _, k in planned}
    for p, expected in source_hashes.items():
        cur = _sha256_raw(Path(p)) if key_of.get(p) == "pdf" else _sha256(Path(p))
        if cur != expected:
            raise RuntimeError(f"源文件在打包期间变化：{p}")
    part.replace(zip_path)
    # `zip_size` / `zip_sha256` 只取**最终落盘**的那一份。
    # 这不是洁癖：`.part` 阶段的大小不是最终大小，V11 交付说明里那句
    # `12,123,616 B` 就是有人把中间值抄进了文档，而 `包校验报告.json` 记的是
    # 12,124,048 —— 差 432 字节，复核方一算就对不上。所以取值统一走
    # `final_zip_metrics()`：先断言没有残留临时文件，再在同一处取两个数。
    _zip_sha, _zip_size = final_zip_metrics(out, zip_path)
    # `i18n_validation` 一列在 V5 被判「自相矛盾」：清单已经有实测覆盖率，
    # 校验报告却写 `not_checked`。根因是**两件事被塞进了一个字段**：
    # 机器能不能算出覆盖率，和人工有没有审过译文，是两条独立的结论。
    # V6 起拆开：
    #   `i18n_coverage`        —— 机器实测（有侧车即 measured，覆盖率见清单）
    #   `i18n_content_review`  —— 人工语言审校（本管线不做，恒 not_reviewed）
    _measured = sum(1 for r in records
                    if str(r.get("i18n_complete") or "") in ("true", "false"))
    report = {
        "generated_at": stamp, "packaging_validation": "pass",
        "engineering_validation": "not_approved",
        "i18n_coverage": ("measured" if _measured else "not_checked"),
        "i18n_content_review": "not_reviewed",
        "mpn_count": len(mpns), "model_directories": sorted(mpns),
        "model_artifact_count": sum(len(r["present"]) + len(r["html_languages"]) - 1 for r in records),
        "zip_member_count": len(verified), "zip_crc": "pass",
        "source_hashes_unchanged": True, "zip_sha256": _zip_sha,
        "zip_size": _zip_size, "hash_rule": HASH_RULE,
        "verified_members": verified,
    }
    (out / "包校验报告.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # 终极断言：清单里的每个数值都必须能从包内文件重算出来。
    # V5 的教训是「重出包时漏更新清单」，人一定会漏，所以这一步必须是机器。
    # 独立实现（`qc/bundle_selfcheck.py`），不复用本文件的哈希函数 ——
    # 共用同一个函数的话，函数错了自检也会跟着错。
    from qc import bundle_selfcheck as _selfcheck                   # noqa: PLC0415
    bad = _selfcheck.check(out)
    if bad:
        raise RuntimeError(
            "包内自证链不一致，拒绝出包：\n  - " + "\n  - ".join(bad[:20]))
    # 复审【新-1】：V6 把「跑过了」写成一句自述，包里既没有脚本也没有结论，
    # 复核方只能相信。V7 把逐项结论（item / expected / actual / ok + passed）
    # 直接落进本报告 —— 脚本本体仍不进包（仓库只放交付物），但**结论必须可核**。
    sc = _selfcheck.report(out)
    if not sc.get("passed"):
        raise RuntimeError("自证链结构化结论未通过："
                           + json.dumps(sc.get("items", [])[:5], ensure_ascii=False))
    report["selfcheck"] = sc
    report["self_check"] = "pass"
    report["self_check_items"] = ("members / records(锚定列+i18n+PDF哈希) / zip / "
                                  "校验报告 四组，均由 qc/bundle_selfcheck.py "
                                  "从包内文件独立重算；逐项见 `selfcheck.items`")
    (out / "包校验报告.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    # 修复方案同时放输出根，分卷内已包含同一份原字节内容。
    for p in docs:
        shutil.copyfile(p, out / p.name)
    return report


def _notify_release(a, pkg_name: str) -> None:
    """出包成功后建一张 `[CMD]` 工单，让质审流水线自己捡活（AGENT.md §17）。

    **只在包确实已推送到发布仓库时建单**（`trigger_auto_qa` 里做三关校验：
    `HEAD == origin/main`、包在提交树里、工作区干净）。

    出包本身已经成功，所以建单失败**不**把进程判死 —— 但必须响亮地说出来，
    否则「以为通知了，其实没有」比不通知更糟。
    """
    from app.integrations import github_issues as GH

    try:
        res = GH.trigger_auto_qa(pkg=pkg_name, releases_dir=a.releases_dir,
                                 dry_run=a.notify_dry_run)
    except Exception as e:                               # noqa: BLE001
        print(f"\n[警告] 未建 [CMD] 工单：{e}", file=sys.stderr)
        print(f"[提示] 把包放进 {a.releases_dir}/ 并 push 后执行：\n"
              f"       python -m app.integrations.release_notify --pkg {pkg_name} --push",
              file=sys.stderr)
        return

    if res.get("labels_dropped"):
        print(f"[警告] {res.get('labels_warning')}", file=sys.stderr)
    if res.get("dry_run"):
        print(f"[通知] dry-run：将创建工单《{res['issue']['title']}》（加 --push 语义见 "
              f"release_notify 的 --dry-run/--push）")
        print(json.dumps(res["request"]["json"], ensure_ascii=False, indent=2)[:2000])
    elif res.get("skipped"):
        print(f"[通知] 已存在同类工单，跳过：{res.get('duplicate_of')}")
    else:
        print(f"[通知] 已建工单 #{res.get('number')}：{res.get('html_url')}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--status", default="done")
    ap.add_argument("--per-shard", type=int, default=1000)
    ap.add_argument("--no-pdf", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--out", default="")
    ap.add_argument("--acceptance-root", default="",
                    help="只装配该验收根内的指定型号；不查数据库、不重渲染；输出必须干净")
    ap.add_argument("--mpns", default="",
                    help="验收模式下的安全文件名清单，逗号分隔；默认客户五件")
    ap.add_argument("--batch-label", default="",
                    help="批次标签，出现在 README 首行标题里（如 `Batch 20`）。"
                         "留空则标题只写 `<N>-MPN Evaluation Delivery Package`。"
                         "批次号是包外事实，不能从产物推导，所以由调用方显式给。")
    ap.add_argument("--batch-note", default="",
                    help="本批次说明（Markdown 文件）。原样插入 README.md 与《交付说明.md》，"
                         "用于记录无法从产物自动推导的事实（如请求型号被同批次另一型号顶替）。"
                         "说明里**不要写 ZIP 字节数**：那是打包后才知道的值，手抄必漂移。")
    ap.add_argument("--attach", action="append", default=[],
                    metavar="FILE",
                    help="随包附件（可重复）。核对用文件（如 A21 证据表），"
                         "不是交付物料：进 ZIP、进 manifest 的 `attachments`、"
                         "进 README 的「随包附件」小节、并被自检覆盖哈希与大小。"
                         "**不要手工 `cp` 进包根** —— 那样文件在包里但清单没记，"
                         "复核方无从判断它算不算交付物。")
    ap.add_argument("--skipped", default="", metavar="CSV",
                    help="未出产物型号台账（列：mpn, disposition, reason_code, "
                         "reason_zh, pdf_sha256, log_evidence）。随包写成 `skipped.csv`，"
                         "并在 README 里生成逐件表 —— 「20 件进、8 件出」不能只写在"
                         "一句话里，否则另外 12 件没有任何痕迹。")
    ap.add_argument("--notify-issue", dest="notify_issue", action="store_true",
                    default=True,
                    help="出包后自动建一张 [CMD] 质审工单（AGENT.md §17，**默认开**）。"
                         "只在该包已 staged 到 --releases-dir 并 push 后才真建单，"
                         "否则给出提示而不报错。")
    ap.add_argument("--no-notify-issue", dest="notify_issue", action="store_false",
                    help="关掉自动建单（比如只是本地出包预览、不打算发布）。")
    ap.add_argument("--releases-dir", default="data/_delivery_releases",
                    help="发布仓库的本地克隆（默认 data/_delivery_releases）。"
                         "包必须先出现在这里，才能验证「已推送」并建单。")
    ap.add_argument("--notify-dry-run", action="store_true",
                    help="配合 --notify-issue 只打印请求体，不真的建单。")
    a = ap.parse_args()

    batch_note = ""
    if a.batch_note:
        _bn = Path(a.batch_note)
        if not _bn.is_file():
            ap.error(f"--batch-note 文件不存在：{_bn}")
        batch_note = _bn.read_text(encoding="utf-8").strip()
        if not batch_note:
            ap.error(f"--batch-note 文件为空：{_bn}")

    if a.acceptance_root:
        if not a.out:
            ap.error("验收模式必须显式指定 --out")
        bad = check_delivery_name(Path(a.out))
        if bad:
            ap.error(bad)
        mpns = tuple(x.strip() for x in a.mpns.split(",") if x.strip()) if a.mpns else ACCEPTANCE_MPNS
        report = bundle_acceptance(Path(a.acceptance_root), Path(a.out), mpns,
                                   batch_note=batch_note,
                                   batch_label=a.batch_label.strip(),
                                   attachments=tuple(a.attach),
                                   skipped_csv=a.skipped)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if a.notify_issue:
            _notify_release(a, Path(a.out).name)
        return
    if a.mpns:
        ap.error("--mpns 必须配合 --acceptance-root 使用")

    if a.out:
        bad = check_delivery_name(Path(a.out))
        if bad:
            ap.error(bad)
    out = Path(a.out) if a.out else next_delivery_dir(config.EXPORTS)
    out.mkdir(parents=True, exist_ok=True)

    if a.limit:
        items = db.q("SELECT * FROM item WHERE status=? ORDER BY mpn_key LIMIT ?",
                     (a.status, a.limit))
    else:
        items = db.q("SELECT * FROM item WHERE status=? ORDER BY mpn_key", (a.status,))
    if not items:
        print(f"没有 status={a.status} 的型号")
        return

    shard_n = (len(items) + a.per_shard - 1) // a.per_shard
    print(f"型号 {len(items)} 件，分 {shard_n} 卷，每卷 {a.per_shard} 件，含 PDF={not a.no_pdf}")
    print(f"输出目录：{out}")

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(_manifest_row(items[0], [], a.no_pdf).keys()))
    w.writeheader()
    rows: list[dict] = []
    for it in items:
        row = _manifest_row(it, packager.artifacts(it), a.no_pdf)
        rows.append(row)
        w.writerow(row)
    manifest = buf.getvalue()
    (out / "manifest.csv").write_text("\ufeff" + manifest, encoding="utf-8")
    (out / "README.md").write_text(README.format(per_shard=a.per_shard), encoding="utf-8")
    print(f"清单已写：manifest.csv（{len(rows)} 行）")

    total_bytes = 0
    for shard in range(shard_n):
        chunk = items[shard * a.per_shard:(shard + 1) * a.per_shard]
        dest = out / f"part-{shard + 1:04d}-of-{shard_n:04d}.zip"
        if dest.exists():
            print(f"跳过已完成分卷 {dest.name}")
            continue
        part = dest.with_suffix(".zip.part")
        with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            z.writestr("manifest.csv", "\ufeff" + manifest)
            z.writestr("README.md", README.format(per_shard=a.per_shard))
            for it in chunk:
                stem = safe_name(it["mpn"])
                for art in packager.artifacts(it):
                    if not art["exists"]:
                        continue
                    if a.no_pdf and art["key"] == PDF_KEY:
                        continue
                    _add(z, art["path"], f"{stem}/{art['filename']}")
        part.replace(dest)
        print(f"分卷 {dest.name} 完成（{dest.stat().st_size / 1048576:.0f} MB）")

    total_bytes = sum(p.stat().st_size for p in out.glob("part-*-of-*.zip"))
    print(f"全部完成：{shard_n} 卷，{total_bytes / 1073741824:.1f} GB，目录 {out}")
    if a.notify_issue:
        _notify_release(a, out.name)


if __name__ == "__main__":
    main()
