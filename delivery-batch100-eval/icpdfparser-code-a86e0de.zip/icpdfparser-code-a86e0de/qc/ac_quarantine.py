#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AC 数据的物理隔离 —— 脏行与跨容器逃逸的 AC 参数都不能留在正式容器里。

为什么需要这一层
----------------
`ADS8568EVM-PDK` 的 AC 续页表在 V10 里抽成了 6 条

    SNR | At fIN = 10 kHz ... | min=73.9 | typ= | max=dB | unit=

`dB` 是**单位**，不是 MAX 值。原表那一行实际是 `73 / 73.9 / dB`，抽取器的
列带在续页上切错了一列，把单位顶进了 MAX 格。`value_shape="LH"` 与实填
自洽，所以只看 shape 判不出来；`qc/deterministic_extract.check_ac_integrity()`
能报错，但报错不等于数据被拦住 —— 渲染层仍会把 `dB` 印在 MAX 列。

V11 只扫了 `specs.ac_performance`。合同层（`qc/scope_contract.canonical_view`）
随后把整张 `specs.electrical` 搬进 `specs.onboard_device_specs.electrical`，
于是**同一条 AC 数据换了个容器继续发表**：AC 表说「已扣押」，电气表照常把
SNR/SFDR/THD/隔离度印给客户。1102V2 复审把这个洞定为 P0「跨容器逃逸」。

本模块做的是**物理搬运**：

1. `specs.ac_performance`（及桶内同名容器）里 MIN/TYP/MAX 格脏掉的行 →
   `specs.unresolved_ac_rows`；
2. 板卡件正式电气容器（主表 + `onboard_device_specs` / `unresolved_specs`，
   含 `devices.<MPN>` 次级器件桶）里的 **AC 类参数**，若没有独立的
   `bbox` + `row_sha256`（无法证明与原数据独立）→ 同样搬进隔离区；
3. `metadata` 落机器可读状态：`formal_container_integrity`（"pass" 只代表
   没有脏行）与 `ac_data_state`（"withheld" = 数据被主动扣押）；
4. 渲染层 / API 出口通过 `filter_rows()` / `filter_electrical_rows()` 兜底，
   旧 JSON 还没跑隔离时也不会把脏行印出去。事实表（`facts_audit` /
   `risk_queue`）刻意**在隔离前**审计，避免靠删行让分母缩水。

判据复用 `qc/deterministic_extract.ac_num_cell()`：AC 列角色闸门与隔离层必须
是同一套口径，各写一份正则早晚会分叉（AGENT.md §5.14）。

**AC 类参数的判据**（不是关键词拍脑袋）：

* `unit` 是 dB 家族（dB / dBFS / dBc / dBFS/Hz …）且行内有数值 ——
  频域量纲是可测量特征，dBm 这类功率电平刻意不收；
* 或者名称/符号命中 AC 指标词表（SNR/SFDR/THD/ENOB/NSD/IMD/PSRR/CMRR、
  signal-to-noise、spurious-free、harmonic distortion、isolation 等）——
  覆盖 `ENOB = 8.5 Bits` 这种没有 dB 单位、但明确属于 AC 表的行。

**为什么不扫芯片页的主电气表**：芯片手册的 `electrical` 里 SNR/THD/ENOB
本来就是原表内容（生产库里有数千行 dB 量纲参数），它们不是「从 AC 容器
逃逸」的无来源复制。把它们也扣押会把芯片页的真实规格删掉 —— 那是数据
丢失，不是治理。扫描范围因此是：板卡件的主电气表 + 所有板载/待核桶。

用法
----
    python qc/ac_quarantine.py data/parsed/ADS8568EVM-PDK.json
    python qc/ac_quarantine.py --dry-run data/parsed/*.json

管线内由 `qc/normalize_doc.py` 在 AC 抽取后调用；`qc/fact_status_sync.py`
在回写状态前再跑一次，保证旧 JSON 也被清掉。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qc.deterministic_extract import ac_num_cell             # noqa: E402

SCHEMA = "ac-quarantine/v2"

#: 正式 AC 容器与隔离容器的名字。隔离容器刻意留在 `specs` 下：
#: 它属于这份文档的治理记录，不是另一张要展示的规格表。
AC = "ac_performance"
ISOLATION = "unresolved_ac_rows"

#: 板卡件的「板载器件 / 待核」桶。合同层把不属于整板的行搬进这里；
#: `devices.<MPN>` 是具名次级器件的子桶（`qc/scope_contract.py`）。
BUCKETS = ("onboard_device_specs", "unresolved_specs")

#: 板卡类身份（与 `qc/board_scope.BOARD_IDENTITIES` 同口径）。
BOARD_IDENTITIES = frozenset({"evaluation_board", "reference_design",
                              "module", "board"})

#: dB 家族单位 = 频域（AC）量纲。刻意不含 dBm / dBV 这类功率/电平单位：
#: 板级 `Output Power 10 dBm` 是整板指标，不是 ADC 的 AC 性能。
AC_UNITS = frozenset({"db", "dbfs", "dbc", "dbhz", "dbfs/hz", "dbfs/√hz",
                      "dbc/hz", "dbc/√hz"})

#: AC 指标符号。只认独立 token，避免把 `SNDR` 里的 `SND` 之类误命中。
_AC_SYMBOL_RE = re.compile(
    r"(?<![A-Za-z0-9])("
    r"SNR|SFDR|SINAD|SNDR|THD(?:\s*\+\s*N)?|ENOB|NSD|IMD[0-9]?|PSRR|CMRR"
    r")(?![A-Za-z0-9])", re.I)

#: AC 指标全称（覆盖没有 dB 单位、或单位写在别处的行）。
_AC_PHRASE_RE = re.compile(
    r"signal[\s\-–]*to[\s\-–]*noise|spurious[\s\-–]*free|spur[\s\-–]*free|"
    r"dynamic\s+range|harmonic\s+distortion|inter[\s\-–]*modulation|"
    r"noise\s+spectral\s+density|effective\s+number\s+of\s+bits|"
    r"crosstalk|cross[\s\-–]*talk|"
    r"channel[\s\-–]*to[\s\-–]*channel\s+isolation|"
    r"noise\s+floor|phase\s+noise|worst\s+spur|"
    r"full[\s\-–]*scale\s+input\s+power|stop[\s\-–]*band\s+attenuation|"
    r"rejection\s+ratio", re.I)

_NUM_RE = re.compile(r"[+\-−±]?\d")


def _text(v) -> str:
    return str(v if v is not None else "").strip()


def _norm_unit(v) -> str:
    """单位归一：大小写、全角空格、微符号。"""
    return (_text(v).lower().replace("μ", "µ").replace(" ", "")
            .replace("／", "/"))


def _row_label(row: dict) -> str:
    return " ".join(_text(row.get(k)) for k in ("symbol", "parameter", "name"))


def _has_number(row: dict) -> bool:
    for key in ("value", "min", "typ", "max"):
        if _NUM_RE.search(_text(row.get(key))):
            return True
    return False


def is_ac_row(row: dict) -> bool:
    """这一行是不是 AC（频域）类参数。见模块 docstring 的两条判据。"""
    if not isinstance(row, dict):
        return False
    label = _row_label(row)
    if label and (_AC_SYMBOL_RE.search(label) or _AC_PHRASE_RE.search(label)):
        return True
    return _norm_unit(row.get("unit")) in AC_UNITS and _has_number(row)


def _source_box(row: dict) -> dict:
    src = row.get("source")
    return src if isinstance(src, dict) else {}


#: 事实表里「拿到坐标」的结论 —— 与 `qc/fact_acceptance.COORD_VERDICTS`
#: 同口径。这里刻意不 import fact_acceptance：`normalize_doc` → `ac_quarantine`
#: 是启动路径，反向 import 会把 stage_release/normalize 拖成环。
_COORD_VERDICTS = frozenset({"verified_row", "verified_paragraph", "verified_value"})


def _fact_key(row: dict) -> tuple[str, str]:
    """事实表 / 渲染层共用的键：`(label, condition)`。"""
    lab = str(row.get("name") or row.get("parameter")
              or row.get("symbol") or "").strip()
    cond = str(row.get("condition") or row.get("conditions") or "").strip()
    return lab, cond


def _evidence_for(row: dict, evidence) -> dict:
    if not evidence or not isinstance(row, dict):
        return {}
    if isinstance(evidence, dict):
        got = evidence.get(_fact_key(row))
        return got if isinstance(got, dict) else {}
    return {}


def _evidence_has_coords(ev: dict) -> bool:
    """事实表证据是否到坐标级：bbox + 行/段落指纹。

    `verified_value` 只有 bbox、没有指纹，不足以证明「这一行不是盲复制」，
    因此不单独放行；这与 V11「bbox + row_sha256 缺一不可」同口径，只是把
    段落指纹视为等价的行证据（SNR 的独立来源是 p1 汇总段落，没有表格行）。
    """
    if not isinstance(ev, dict):
        return False
    if str(ev.get("verdict") or "") not in _COORD_VERDICTS:
        return False
    return bool(ev.get("bbox")) and bool(
        ev.get("row_sha256") or ev.get("paragraph_sha256"))


def has_independent_provenance(row: dict, evidence=None) -> bool:
    """这一行有没有**自己的**坐标级证据（能证明不是原数据的盲复制）。

    两个来源都认：
    * JSON 行内 / `source` 里的 `bbox + row_sha256`（或段落指纹）；
    * 事实表（`qc/fact_acceptance`）重放出来的证据 —— 隔离发生在事实表之前，
      但 THD/SNR 的坐标证据本来就能从 PDF 重算，不能因为还没写回 JSON 就误杀。
    """
    if not isinstance(row, dict):
        return False
    src = _source_box(row)
    bbox = row.get("bbox") or src.get("bbox")
    sha = (row.get("row_sha256") or src.get("row_sha256")
           or row.get("paragraph_sha256") or src.get("paragraph_sha256"))
    if bbox and sha:
        return True
    return _evidence_has_coords(_evidence_for(row, evidence))


def escaped_reason(row: dict, evidence=None) -> str:
    """AC 参数逃进电气正式容器、且没有独立溯源的证据说明；否则空串。

    有事实表证据时，理由按证据精确到「缺坐标」还是「缺指纹」；没有事实表
    证据（旧调用 / 解析期）时保留原口径，避免把「还没审计」写成「已确认缺坐标」。
    """
    if not is_ac_row(row):
        return ""
    if has_independent_provenance(row, evidence):
        return ""
    ev = _evidence_for(row, evidence)
    if ev:
        if ev.get("bbox"):
            return ("AC 类参数出现在电气正式容器；事实表取得了坐标但缺行/段落指纹，"
                    "不能证明该行独立于原 AC 数据（缺指纹）")
        return ("AC 类参数出现在电气正式容器；事实表未取得独立坐标（bbox），"
                "无法证明该行独立于原 AC 数据（缺独立坐标）")
    return ("AC 类参数出现在电气正式容器，且没有独立的 bbox/row_sha256，"
            "无法证明与原数据独立（疑似从 AC 容器复制）")


def dirty_reason(row: dict) -> str:
    """这一行为什么不能留在正式 AC 表；干净行返回空串。

    判据只有一条：`min` / `typ` / `max` 里任何非空单元格都必须是数值。
    空串表示「原表没填这一格」，合法。
    """
    if not isinstance(row, dict):
        return ""
    for key in ("min", "typ", "max"):
        cell = _text(row.get(key))
        if not cell:
            continue
        if not ac_num_cell(cell):
            return (f"{key.upper()} 格不是数值（{cell!r}）：单位/脚注占了数值格，"
                    f"列角色错位")
    return ""


def is_dirty(row: dict) -> bool:
    return bool(dirty_reason(row))


def filter_rows(rows) -> list[dict]:
    """只留能当数值读的 AC 行；渲染层/API 的最后一道防线。"""
    return [r for r in (rows or []) if isinstance(r, dict) and not is_dirty(r)]


def filter_electrical_rows(rows, facts=None) -> list[dict]:
    """电气表出口兜底：丢掉逃逸进电气容器的、无独立溯源的 AC 行。

    只给板卡件用（芯片页主电气表里的 AC 行是原表内容，不是逃逸）。
    `facts` 是渲染层已挂上的事实表 map（`{label\x1fcond: verdict}`）：
    事实表已给坐标级结论的行必须保留，否则隔离桶为空时页面会把 THD/SNR
    无声吞掉（元宝终审的反例）。
    """
    out: list[dict] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if not escaped_reason(row):
            out.append(row)
            continue
        if isinstance(facts, dict):
            lab, cond = _fact_key(row)
            verdict = facts.get(f"{lab}\x1f{cond}")
            if verdict in _COORD_VERDICTS:
                out.append(row)
    return out


def needs_evidence(doc: dict) -> bool:
    """这份文档有没有「AC 逃逸行但缺行内溯源」——需要事实表证据才能判。"""
    specs = doc.get("specs") if isinstance(doc, dict) else None
    if not isinstance(specs, dict):
        return False
    for _source, container in _electrical_containers(specs, board=_is_board(doc)):
        for row in container.get("electrical") or []:
            if is_ac_row(row) and not has_independent_provenance(row):
                return True
    return False


def _is_board(doc: dict) -> bool:
    bi = doc.get("basic_info") if isinstance(doc, dict) else None
    if isinstance(bi, dict) and _text(bi.get("identity")) in BOARD_IDENTITIES:
        return True
    specs = doc.get("specs") if isinstance(doc, dict) else None
    if isinstance(specs, dict) and _text(specs.get("scope")) in ("board",
                                                                "onboard_device"):
        return True
    return False


def _source_containers(specs: dict):
    """产出 `(来源描述, 容器 dict)`：主表在前，隔离桶在后。"""
    yield AC, specs
    for bucket in BUCKETS:
        box = specs.get(bucket)
        if isinstance(box, dict):
            yield f"{bucket}.{AC}", box


def _electrical_containers(specs: dict, *, board: bool):
    """产出 `(来源描述, 容器 dict)`：可能出现 AC 逃逸行的正式电气容器。

    `board=True` 时连主表一起扫：合同层把主表整锅搬进板载桶，搬之前不扣，
    搬完就换了个容器继续逃。芯片页主表**不在**范围（见模块 docstring）。
    """
    if board:
        yield "electrical", specs
    for bucket in BUCKETS:
        box = specs.get(bucket)
        if not isinstance(box, dict):
            continue
        yield f"{bucket}.electrical", box
        devices = box.get("devices")
        if not isinstance(devices, dict):
            continue
        for mpn in sorted(devices):
            sub = devices[mpn]
            if isinstance(sub, dict) and isinstance(sub.get("electrical"), list):
                yield f"{bucket}.devices.{mpn}.electrical", sub


def formal_container_integrity(doc: dict, evidence=None) -> str:
    """`pass` = 正式容器里没有脏 AC 行、也没有无独立溯源的逃逸 AC 行。

    这个字段**只**回答「容器干不干净」，不回答数据对不对、也不等于放行。
    """
    specs = doc.get("specs") if isinstance(doc, dict) else None
    if not isinstance(specs, dict):
        return "pass"
    for _source, container in _source_containers(specs):
        for row in container.get(AC) or []:
            if is_dirty(row):
                return "fail"
    for _source, container in _electrical_containers(specs,
                                                     board=_is_board(doc)):
        for row in container.get("electrical") or []:
            if escaped_reason(row, evidence):
                return "fail"
    return "pass"


def _key(row: dict) -> tuple:
    """隔离区去重键。同一行被重复抽到/重复隔离时不叠加。

    AC 表形态（symbol/parameter/min/typ/max）与电气表形态（name/value/unit）
    都进键：逃逸行没有 symbol/max，只用旧键会把 4 条行全判成同一个空元组。
    """
    return tuple(str(row.get(k) or "") for k in
                 ("row_sha256", "symbol", "parameter", "name", "conditions",
                  "condition", "min", "typ", "max", "value", "unit"))


def _append_isolated(specs: dict, moved: list[dict]) -> None:
    if not moved:
        return
    isolated = specs.get(ISOLATION)
    if not isinstance(isolated, list):
        isolated = []
        specs[ISOLATION] = isolated
    seen = {_key(r) for r in isolated if isinstance(r, dict)}
    for item in moved:
        k = _key(item)
        if k in seen:
            continue
        isolated.append(item)
        seen.add(k)


def _write_metadata(doc: dict, evidence=None) -> dict:
    """落机器可读状态；返回写进去的值，便于报告与测试核对。"""
    integrity = formal_container_integrity(doc, evidence)
    isolated = (doc.get("specs") or {}).get(ISOLATION)
    state = "withheld" if isinstance(isolated, list) and isolated else "not_withheld"
    meta = doc.get("metadata")
    if not isinstance(meta, dict):
        meta = {}
        doc["metadata"] = meta
    meta["formal_container_integrity"] = integrity
    meta["ac_data_state"] = state
    return {"formal_container_integrity": integrity, "ac_data_state": state}


def _report(moved: list[dict], states: dict,
            restored: list[dict] | None = None) -> dict:
    return {
        "schema": SCHEMA,
        "n_quarantined": len(moved),
        "n_restored": len(restored or ()),
        "restored": [{"name": _text(r.get("name") or r.get("parameter")
                                    or r.get("symbol")),
                      "symbol": _text(r.get("symbol")),
                      "conditions": _text(r.get("conditions")
                                          or r.get("condition"))}
                     for r in (restored or ())],
        "quarantined": [
            {"name": _text(r.get("name") or r.get("parameter")
                           or r.get("symbol")),
             "symbol": _text(r.get("symbol")),
             "conditions": _text(r.get("conditions") or r.get("condition")),
             "max": _text(r.get("max")),
             "value": _text(r.get("value")),
             "from": _text(r.get("quarantined_from")),
             "reason": _text(r.get("quarantine_reason"))}
            for r in moved
        ],
        **states,
    }


#: 逃逸行被隔离时的理由前缀。平反只认这一类 —— 脏行（列角色错位）不平反。
_ESCAPED_PREFIX = "AC 类参数出现在电气正式容器"


def _restore_escaped(doc: dict, evidence, *, force: bool = False) -> list[dict]:
    """把误扣的逃逸行搬回原容器，返回搬回去的行。

    只处理「逃逸但无独立溯源」这一类。**脏行不平反**：MAX 格里写着 `dB`
    是列角色错位，跟有没有坐标无关，拿到 bbox 也不会变成数值。

    没有 `evidence` 时一律不动 —— 「还没审计」不等于「已经平反」。
    `force=True` 是给「重新审计」用的还原：无条件放回，之后必须重跑事实表
    重新取证，再由 `quarantine(doc, evidence)` 决定去留。
    """
    if not evidence and not force:
        return []
    specs = doc.get("specs")
    if not isinstance(specs, dict):
        return []
    iso = specs.get(ISOLATION)
    if not isinstance(iso, list) or not iso:
        return []
    targets = dict(_electrical_containers(specs, board=_is_board(doc)))
    keep: list[dict] = []
    restored: list[dict] = []
    for row in iso:
        if not isinstance(row, dict):
            keep.append(row)
            continue
        why = _text(row.get("quarantine_reason"))
        box = targets.get(_text(row.get("quarantined_from")))
        if (not why.startswith(_ESCAPED_PREFIX) or box is None
                or not isinstance(box.get("electrical"), list)):
            keep.append(row)
            continue
        if not force and escaped_reason(row, evidence):
            keep.append(row)              # 证据仍不足，继续隔离
            continue
        item = dict(row)
        item.pop("quarantined_from", None)
        item.pop("quarantine_reason", None)
        box["electrical"].append(item)
        restored.append(item)
    if restored:
        specs[ISOLATION] = keep
    return restored


def restore_escaped(doc: dict) -> list[dict]:
    """无条件把「逃逸但无溯源」的隔离行放回正式容器（重新审计前的还原）。

    **这不是平反结论。** 放回去之后必须重跑 `qc/fact_acceptance.py` 取坐标证据，
    再由 `quarantine(doc, evidence)` 决定哪些真的留下。直接放回去就收工，
    等于撤销隔离却不给理由 —— 那比原来更糟。
    """
    return _restore_escaped(doc, None, force=True)


def quarantine(doc: dict, evidence=None) -> dict:
    """把脏 AC 行与逃逸 AC 行搬进 `specs.unresolved_ac_rows`（就地修改）。

    `evidence` 可选：`{(label, condition): {verdict,bbox,row_sha256,
    paragraph_sha256}}`，来自事实表。提供了它时，事实表已锚到坐标级的行
    （THD 行指纹 / SNR 段落指纹）不会被误扣；真正缺坐标的行继续隔离，理由
    写明缺的是坐标。返回可序列化报告；`n_quarantined` 只数**这一次**新搬走
    的行，重复调用为 0。

    **隔离是可逆的**（1102-V3.1）。给了 `evidence` 时，已经躺在隔离桶里、
    当初因「逃逸但无独立溯源」被扣下、如今事实表拿到了坐标的行会被搬回原
    容器。理由：隔离发生在事实表之前，那时坐标还不存在，扣下是**当时的**
    正确判断；证据到位后不平反，就等于把「当时不知道」永久写成「确认无证据」。
    """
    specs = (doc or {}).get("specs") if isinstance(doc, dict) else None
    if not isinstance(specs, dict):
        return _report([], {"formal_container_integrity": "pass",
                            "ac_data_state": "not_withheld"})

    moved: list[dict] = []

    # ① AC 容器的脏行（V11 既有口径）
    for source, container in _source_containers(specs):
        rows = container.get(AC)
        if not isinstance(rows, list):
            continue
        keep: list[dict] = []
        for row in rows:
            if not isinstance(row, dict):
                keep.append(row)
                continue
            why = dirty_reason(row)
            if not why:
                keep.append(row)
                continue
            item = dict(row)
            item["quarantined_from"] = source
            item["quarantine_reason"] = why
            moved.append(item)
        if len(keep) != len(rows):
            container[AC] = keep

    # ② 电气容器里的跨容器逃逸（1102V2 P0）
    for source, container in _electrical_containers(specs,
                                                    board=_is_board(doc)):
        rows = container.get("electrical")
        if not isinstance(rows, list):
            continue
        keep = []
        for row in rows:
            if not isinstance(row, dict):
                keep.append(row)
                continue
            why = escaped_reason(row, evidence)
            if not why:
                keep.append(row)
                continue
            item = dict(row)
            item["quarantined_from"] = source
            item["quarantine_reason"] = why
            moved.append(item)
        if len(keep) != len(rows):
            container["electrical"] = keep

    restored = _restore_escaped(doc, evidence)
    _append_isolated(specs, moved)
    states = _write_metadata(doc, evidence)
    return _report(moved, states, restored)


def _atomic_write(path: Path, text: str) -> None:
    """同目录 tmp + fsync + os.replace：只留旧内容或新内容（AGENT.md §2.1）。"""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="把脏 AC 行与跨容器逃逸的 AC 行隔离到 specs.unresolved_ac_rows")
    ap.add_argument("paths", nargs="+", help="待处理的 JSON 文件")
    ap.add_argument("--dry-run", action="store_true", help="只报告，不写盘")
    ap.add_argument("--restore-escaped", action="store_true",
                    help="重新审计前的还原：把「逃逸但无溯源」的隔离行放回正式容器。"
                         "放回后必须重跑事实表取证，再跑一次本脚本（带 evidence）定去留")
    a = ap.parse_args(argv)
    if a.restore_escaped:
        total_r = 0
        for raw in a.paths:
            p = Path(raw)
            try:
                doc = json.loads(p.read_text(encoding="utf-8"))
            except (OSError, ValueError) as e:
                print(f"{p}: 读取失败：{e}", file=sys.stderr)
                return 2
            rows = restore_escaped(doc)
            total_r += len(rows)
            print(f"{p.name}: 还原 {len(rows)} 行（待重新取证）")
            for r in rows:
                print(f"  + {_text(r.get('name') or r.get('parameter') or r.get('symbol'))} | "
                      f"{_text(r.get('conditions') or r.get('condition'))}")
            if rows and not a.dry_run:
                _atomic_write(p, json.dumps(doc, ensure_ascii=False, indent=2))
        print(f"合计还原 {total_r} 行{'（dry-run 未写盘）' if a.dry_run else ''}")
        return 0
    total = 0
    changed = 0
    for raw in a.paths:
        p = Path(raw)
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            print(f"{p}: 读取失败：{e}", file=sys.stderr)
            return 2
        rep = quarantine(doc)
        n = rep["n_quarantined"]
        total += n
        print(f"{p.name}: 隔离 {n} 行"
              f"（integrity={rep['formal_container_integrity']}, "
              f"ac_data_state={rep['ac_data_state']}）")
        for item in rep["quarantined"]:
            print(f"  - [{item['from']}] {item['name'] or item['symbol']} | "
                  f"{item['conditions']} | {item['reason']}")
        if n and not a.dry_run:
            _atomic_write(p, json.dumps(doc, ensure_ascii=False, indent=2))
            changed += 1
    print(f"合计隔离 {total} 行；写盘 {changed} 件"
          f"{'（dry-run 未写盘）' if a.dry_run else ''}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
